import logging
from typing import List, Callable, Any, Optional
import pandas as pd
from .output_handler import OutputHandler, get_robust_predictions

logger = logging.getLogger(__name__)

def get_model_predictions_local(
    model_func: Callable, 
    input_df: pd.DataFrame,
    output_handler: Optional[OutputHandler] = None
) -> List[float]:
    if output_handler is None:
        output_handler = OutputHandler()
    
    try:
        # Use the robust prediction handler
        predictions = get_robust_predictions(model_func, input_df, output_handler)
        
        if not predictions:
            logger.warning("No predictions returned from model")
            return [None] * len(input_df)
        
        logger.info(f"Successfully obtained {len(predictions)} predictions")
        return predictions
        
    except Exception as e:
        logger.error(f"Error calling model function: {e}", exc_info=True)
        return [None] * len(input_df)

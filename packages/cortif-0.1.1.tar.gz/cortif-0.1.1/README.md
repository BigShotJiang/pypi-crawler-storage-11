# Cortif

Cortif Local Runner CLI - A command-line tool for running and monitoring machine learning models locally.

## Installation

```bash
pip install cortif
```

## Features

- Local model execution and monitoring
- Synthetic data generation for testing
- Metrics calculation and monitoring
- Interactive CLI interface
- Beautiful terminal output with Rich

## Configuration

The package supports flexible OpenAI API configuration through environment variables:

### Standard OpenAI API

```bash
export OPENAI_API_KEY="your-api-key"
export OPENAI_MODEL="gpt-4"  # Optional, defaults to gpt-4.1-nano
export OPENAI_BASE_URL="https://api.openai.com/v1"  # Optional, for custom endpoints
```

### Azure OpenAI

```bash
export OPENAI_API_KEY="your-azure-api-key"
export AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
export AZURE_OPENAI_API_VERSION="2025-01-01-preview"  # Optional, defaults to 2025-01-01-preview
export OPENAI_MODEL="gpt-4"  # Optional, defaults to gpt-4.1-nano
```

## Usage

Run the Cortif CLI:

```bash
cortif
```

## Requirements

- Python >= 3.9
- Dependencies listed in pyproject.toml

## Documentation

For more information, visit [https://docs.cortif.ai](https://docs.cortif.ai)

## License

MIT License - See LICENSE file for details

## Contact

- Homepage: [https://cortif.ai](https://cortif.ai)
- Email: team@cortif.ai

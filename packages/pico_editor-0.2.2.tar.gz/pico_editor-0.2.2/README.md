# pico Editor

A lightweight, nano-style text editor built in Python.

This project was created by master629 to make a lightweight, better version of GNU nano.

## Installation

```bash
pip install pico-editor
```

## Usage

```bash
pico <filename>
```

## Changelog

### v0.2.2
- **Bug Fix:** Resolved screen flickering/redrawing issues during fast scrolling for a smoother user experience.

### v0.2.1
- **New Features:** Implemented Find Next (Ctrl+W) and Go To Line (Ctrl+T) functionalities.
- **Search Enhancements:** Made search case-insensitive and added text highlighting for found terms.
- **UI Update:** Added new keybindings to the bottom menu bar for improved discoverability.

### v0.1.1
- **Bug Fix:** Resolved a critical issue where the cursor would become unresponsive after introducing the new UI.
- **UI Enhancement:** The editor's main text area is now enclosed in a box, visually separating it from the status bars.

### v0.1.0
- Initial release.

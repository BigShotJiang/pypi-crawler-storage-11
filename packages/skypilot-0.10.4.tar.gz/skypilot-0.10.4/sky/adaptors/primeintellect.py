"""Prime Intellect cloud adaptor."""

def show_code(filename):
    """
    Print the contents of filename to stdout.
    """
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            print(f.read(), end='')
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
    except Exception as e:
        print(f"An error occurred while reading '{filename}': {e}")

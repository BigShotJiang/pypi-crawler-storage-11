import random
import secrets
import tempfile
import os
import subprocess
import shutil
class ConstructorBase:
    def __init__(self, **code):
        self.BasePSW = []
        self.LocalCache = []
        self.BUILD = {
            'id': secrets.token_hex(random.randint(8, 16)),
        }
        self.CODE = code
        self.Build(code)
        
        
    def Build(self, code_fragments: dict):
        self.ProcessCodeFragments(code_fragments)
        while self.LocalCache:
            buildname, buildasset = self.LocalCache.pop(0)
            self.BuildAsset(buildname, buildasset)
            
        
    def ProcessCodeFragments(self, code_fragments: dict):
        for key, keyword in code_fragments.items():
            if key == "__base__":
                self.LocalCache.append((key, keyword))
            elif key == "__class__":
                self.LocalCache.append((key, keyword))
            elif key == "__func__":
                self.LocalCache.append((key, keyword))
            elif key == "__s@ref__":
                self.LocalCache.append((key, keyword))
            elif key == "__ref__":
                self.LocalCache.append((key, keyword))
            elif key == "__flagassignment__":
                self.LocalCache.append((key, keyword))
        
        
    def BuildAsset(self, asset_type, asset_data):
        self.BaseAssetsDetails = [
            'name=', 'type=', 'value=', 'classmethod='
        ]
        if asset_type == "__base__":
            self.ProcessBase(asset_data)
        elif asset_type == "__class__":
            self.ProcessClass(asset_data)
        elif asset_type == "__func__":
            self.ProcessFunction(asset_data)
        elif asset_type == "__s@ref__":
            self.ProcessStaticReference(asset_data)
        elif asset_type == "__ref__":
            self.ProcessReference(asset_data)
        elif asset_type == "__flagassignment__":
            self.ProcessFlagAssignment(asset_data)
            
            
    def ProcessBase(self, base):
        items = base.split(',')
        for item in items:
            if any(detail in item for detail in self.BaseAssetsDetails):
                self.BasePSW.append(item.strip())
        self.BUILD['base'] = {'items': items, 'processed': len(self.BasePSW)}

                


    def ProcessClass(self, class_def):
        class_parts = class_def.split(',')
        self.BUILD['class'] = {
            'name': class_parts[0] if class_parts else 'DefaultClass',
            'inheritance': class_parts[1:] if len(class_parts) > 1 else [],
            'raw': class_def
        }
    
    
    def ProcessFunction(self, func_def):
        func_parts = []
        current_func = ""
        bracket_count = 0
        for char in func_def:
            if char == '<':
                bracket_count += 1
                if bracket_count == 1:
                    current_func = ""
                    continue
            elif char == '>':
                bracket_count -= 1
                if bracket_count == 0:
                    if current_func.strip():
                        func_parts.append(current_func.strip())
                    continue
            if bracket_count > 0:
                current_func += char
        
        parsed_funcs = []
        for func in func_parts:
            if 'func(' in func:
                func_params = {}
                if 'return=' in func:
                    return_part = func.split('return=')[1].split(',')[0]
                    if ')' in return_part:
                        return_type = return_part.split(')')[0]
                    else:
                        return_type = return_part
                    func_params['return'] = return_type
                if 'name=' in func:
                    name_part = func.split('name=')[1]
                    if ',' in name_part:
                        name = name_part.split(',')[0].strip("'\"")
                    elif ')' in name_part:
                        name = name_part.split(')')[0].strip("'\"")
                    else:
                        name = name_part.strip("'\"")
                    func_params['name'] = name
                if '[init(' in func:
                    init_part = func.split('[init(')[1].split(')]')[0]
                    if 'req=str(' in init_part:
                        param_name = init_part.split('req=str(')[1].split(')')[0].strip("'\"")
                        func_params['init'] = param_name
                    else:
                        func_params['init'] = init_part
                if '] before [func(' in func:
                    code_part = func.split('] before [func(')[1]
                    if code_part.endswith(')]'):
                        code_part = code_part[:-2]
                    elif code_part.endswith(')'):
                        code_part = code_part[:-1]
                    func_params['code'] = code_part
                parsed_funcs.append(func_params)
        
        self.BUILD['functions'] = parsed_funcs
    
    
    def ProcessStaticReference(self, static_ref):
        ref_parts = static_ref.split('|')
        static_refs = []
        for ref in ref_parts:
            if '=' in ref:
                key, value = ref.split('=', 1)
                static_refs.append({'key': key.strip(), 'value': value.strip()})
        self.BUILD['static_refs'] = static_refs
    
    
    def ProcessReference(self, ref):
        ref_items = ref.split(',')
        references = []
        for item in ref_items:
            if '->' in item:
                source, target = item.split('->', 1)
                references.append({'source': source.strip(), 'target': target.strip()})
            else:
                references.append({'direct': item.strip()})
        self.BUILD['references'] = references
    
    
    def ProcessFlagAssignment(self, flag_assignment):
        flags = {}
        flag_items = flag_assignment.split(',')
        for flag in flag_items:
            if '=' in flag:
                key, value = flag.split('=', 1)
                flags[key.strip()] = value.strip()
            else:
                flags[flag.strip()] = True
        self.BUILD['flags'] = flags


class BuildConstructorWheel:
    def __init__(self, constructor: ConstructorBase):
        self.constructor = constructor
        self.generated_class = None
        self.build()
        
    def build(self):
        self.CreateDynamicClass()
        
    def CreateDynamicClass(self):
        build_data = self.constructor.BUILD
        class_name = build_data.get('class', {}).get('name', 'GeneratedClass')
        
        class_methods = {}
        if 'functions' in build_data:
            for func in build_data['functions']:
                func_name = func.get('name', 'generated_method')
                return_type = func.get('return', 'None')
                init_params = func.get('init', '')
                code = func.get('code', 'pass')
                
                if code == '**HERE A PYTHON-CODE':
                    code = f"return {return_type.lower()}() if '{return_type}' != 'None' else None"
                
                if 'return ' not in code and return_type != 'None':
                    if code.strip().startswith('return'):
                        pass
                    else:
                        code = f"return {code}"
                
                method_code = f"""
def {func_name}(self, {init_params}=None):
    {code}
"""
                try:
                    local_vars = {}
                    exec(method_code, globals(), local_vars)
                    class_methods[func_name] = local_vars[func_name]
                except Exception as e:
                    class_methods[func_name] = lambda self, *args, **kwargs: True
        
        if 'base' in build_data:
            for item in build_data['base']['items']:
                if 'name=' in item:
                    class_methods['__name__'] = item.split('name=')[1].strip()
        
        self.generated_class = type(class_name, (), class_methods)
    
    def __call__(self, *args, **kwargs):
        if self.generated_class:
            instance = self.generated_class()
            
            for key, value in kwargs.items():
                method_name = None
                for method in dir(instance):
                    if not method.startswith('_') and hasattr(instance, method):
                        method_name = method
                        break
                
                if method_name:
                    try:
                        method = getattr(instance, method_name)
                        return method(value)
                    except:
                        pass
            
            if args:
                methods = [m for m in dir(instance) if not m.startswith('_') and callable(getattr(instance, m))]
                if methods:
                    try:
                        method = getattr(instance, methods[0])
                        return method(args[0])
                    except:
                        pass
            
            return True
        return False

class ConstructorLangParser:
    def __init__(self):
        self.keywords = {
            'construct': 'def __init__',
            'method': 'def',
            'ret': 'return',
            'var': '',
            'if': 'if',
            'else': 'else',
            'elif': 'elif',
            'while': 'while',
            'for': 'for',
            'in': 'in',
            'print': 'print',
            'len': 'len',
            'str': 'str',
            'int': 'int',
            'bool': 'bool',
            'dict': 'dict',
            'list': 'list'
        }
        self.operators = {
            'eq': '==',
            'ne': '!=', 
            'gt': '>',
            'lt': '<',
            'ge': '>=',
            'le': '<=',
            'and': 'and',
            'or': 'or',
            'not': 'not',
            'add': '+',
            'sub': '-',
            'mul': '*',
            'div': '/',
            'mod': '%'
        }
    
    def ParseConstructorScript(self, script):
        lines = script.split('\n')
        python_code = []
        indent_level = 1
        base_indent = 1
        in_method = False
        
        for line in lines:
            original_line = line
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            if line.startswith('construct'):
                params = ""
                if '(' in line and ')' in line:
                    params = line.split('(')[1].split(')')[0]
                if params and not params.startswith('self'):
                    params = f'self, {params}'
                elif not params:
                    params = 'self'
                python_code.append(f"{'    ' * base_indent}def __init__({params}):")
                indent_level = base_indent + 1
                in_method = True
            
            elif line.startswith('method'):
                if in_method:
                    indent_level = base_indent
                method_part = line.replace('method ', '')
                if '(' not in method_part:
                    method_part += '(self)'
                else:
                    param_part = method_part.split('(')[1].split(')')[0]
                    method_name = method_part.split('(')[0]
                    if param_part and 'self' not in param_part:
                        method_part = f"{method_name}(self, {param_part})"
                    elif not param_part:
                        method_part = f"{method_name}(self)"
                python_code.append(f"\n{'    ' * base_indent}def {method_part}:")
                indent_level = base_indent + 1
                in_method = True
            
            elif line == 'end':
                if indent_level > base_indent + 1:
                    indent_level -= 1
            
            elif line.startswith('ret '):
                value = line[4:].strip()
                for op_name, op_symbol in self.operators.items():
                    value = value.replace(f' {op_name} ', f' {op_symbol} ')
                python_code.append(f"{'    ' * indent_level}return {value}")
            
            elif line.startswith('var '):
                assignment = line[4:].strip()
                for op_name, op_symbol in self.operators.items():
                    assignment = assignment.replace(f' {op_name} ', f' {op_symbol} ')
                python_code.append(f"{'    ' * indent_level}{assignment}")
            
            elif line.startswith('if '):
                condition = line[3:].strip()
                for op_name, op_symbol in self.operators.items():
                    condition = condition.replace(f' {op_name} ', f' {op_symbol} ')
                python_code.append(f"{'    ' * indent_level}if {condition}:")
                indent_level += 1
            
            elif line.startswith('else'):
                python_code.append(f"{'    ' * (indent_level-1)}else:")
            
            elif line.startswith('elif '):
                condition = line[5:].strip()
                for op_name, op_symbol in self.operators.items():
                    condition = condition.replace(f' {op_name} ', f' {op_symbol} ')
                python_code.append(f"{'    ' * (indent_level-1)}elif {condition}:")
        
        return '\n'.join(python_code)

class LocalTempWheelBuilder:
    def __init__(self, constructor_id):
        self.constructor_id = constructor_id
        self.temp_dir = tempfile.mkdtemp(prefix=f'constructor_{constructor_id}_')
        self.wheel_path = None
        
    def CreateWheelStructure(self, class_name, class_code):
        package_name = f"constructor_{self.constructor_id}"
        
        os.makedirs(os.path.join(self.temp_dir, package_name), exist_ok=True)
        
        init_content = f"""# Generated Constructor Package
__version__ = "1.0.0"
from .{class_name.lower()} import {class_name}
__all__ = ['{class_name}']
"""
        
        with open(os.path.join(self.temp_dir, package_name, '__init__.py'), 'w') as f:
            f.write(init_content)
        
        with open(os.path.join(self.temp_dir, package_name, f'{class_name.lower()}.py'), 'w') as f:
            f.write(class_code)
        
        setup_content = f"""from setuptools import setup, find_packages

setup(
    name="{package_name}",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.6",
    author="ConstructorFramework",
    description="Generated constructor class package",
)
"""
        
        with open(os.path.join(self.temp_dir, 'setup.py'), 'w') as f:
            f.write(setup_content)
        
        return package_name
    
    def BuildWheel(self, class_name, class_code):
        package_name = self.CreateWheelStructure(class_name, class_code)
        
        try:
            result = subprocess.run(
                ['python', 'setup.py', 'bdist_wheel'],
                cwd=self.temp_dir,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                dist_dir = os.path.join(self.temp_dir, 'dist')
                if os.path.exists(dist_dir):
                    wheels = [f for f in os.listdir(dist_dir) if f.endswith('.whl')]
                    if wheels:
                        self.wheel_path = os.path.join(dist_dir, wheels[0])
                        return self.wheel_path
            
        except Exception as e:
            pass
        
        return None
    
    def InstallWheel(self):
        if self.wheel_path and os.path.exists(self.wheel_path):
            try:
                subprocess.run(['pip', 'install', self.wheel_path], capture_output=True)
                return True
            except:
                return False
        return False
    
    def Cleanup(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

class ConstructorBuilder:
    
    def __init__(self, constructor: ConstructorBase=None, constructor_data: dict=None, use_wheel_build=False, constructor_script=None):
        self.ConstructorBase = constructor
        self.constructor_data = constructor_data
        self.use_wheel_build = use_wheel_build
        self.constructor_script = constructor_script
        self.lang_parser = ConstructorLangParser()
        self.wheel_builder = None
        
        if self.constructor_script:
            self._final = self.BuildFromScript()
        elif self.ConstructorBase:
            if self.use_wheel_build:
                self._final = self.BuildWithWheel()
            else:
                self._final = BuildConstructorWheel(self.ConstructorBase)
    
    def BuildFromScript(self):
        python_code = self.lang_parser.ParseConstructorScript(self.constructor_script)
        
        class_name = "GeneratedConstructor"
        full_code = f"class {class_name}:\n{python_code}"
        
        try:
            local_vars = {}
            exec(full_code, globals(), local_vars)
            if class_name in local_vars:
                return ConstructorScriptWheel(local_vars[class_name])
        except Exception as e:
            return None
        
        return None
    
    def BuildWithWheel(self):
        if not self.ConstructorBase:
            return None
        
        wheel = BuildConstructorWheel(self.ConstructorBase)
        self.wheel_builder = LocalTempWheelBuilder(self.ConstructorBase.BUILD['id'])
        
        class_name = self.ConstructorBase.BUILD.get('class', {}).get('name', 'GeneratedClass')
        class_code = self.GenerateClassCode(class_name)
        
        wheel_path = self.wheel_builder.BuildWheel(class_name, class_code)
        if wheel_path:
            wheel.wheel_path = wheel_path
            wheel.wheel_builder = self.wheel_builder
        
        return wheel
    
    def GenerateClassCode(self, class_name):
        build_data = self.ConstructorBase.BUILD
        
        code_lines = [f"class {class_name}:"]
        
        if 'functions' in build_data:
            for func in build_data['functions']:
                func_name = func.get('name', 'generated_method')
                init_params = func.get('init', '')
                code = func.get('code', 'pass')
                
                code_lines.append(f"    def {func_name}(self, {init_params}=None):")
                code_lines.append(f"        {code}")
        else:
            code_lines.append("    pass")
        
        return '\n'.join(code_lines)

class ConstructorScriptWheel:
    def __init__(self, generated_class):
        self.generated_class = generated_class
    
    def __call__(self, *args, **kwargs):
        if self.generated_class:
            try:
                instance = self.generated_class(*args, **kwargs)
                return instance
            except:
                return self.generated_class
        return None
            
            
if __name__ == "__main__":
    basic_sample = {
        "__base__": "name=DataProcessor,type=(1),value=active,classmethod=process",
        "__class__": "DataHandler,BaseProcessor",
        "__func__": "<func(return=bool, name='validate', lambda=NULL) -> [init(req=str('data'))] before [func(return len(data) > 0)]>,<func(return=dict, name='transform', lambda=NULL) -> [init(req=str('input'))] before [func(return {'processed': input.upper(), 'length': len(input)})]>,<func(return=str, name='execute', lambda=NULL) -> [init(req=str('command'))] before [func(return f'Executed: {command}')]>",
        "__s@ref__": "CONFIG_PATH=/config/app.cfg|DEBUG_MODE=True|MAX_RETRIES=3",
        "__ref__": "logger->system.log,cache->memory.store,validator->data.check",
        "__flagassignment__": "auto_save=True,strict_mode=False,timeout=30"
    }
    
    advanced_sample = {
        "__base__": "name=APIManager,type=(2),value=production,classmethod=handle_request",
        "__class__": "RestHandler,AsyncProcessor,SecurityMixin", 
        "__func__": "<func(return=dict, name='authenticate', lambda=NULL) -> [init(req=str('token'))] before [func(return {'valid': len(token) == 32, 'user': token[:8]})]>,<func(return=list, name='get_data', lambda=NULL) -> [init(req=str('endpoint'))] before [func(return [f'data_from_{endpoint}_{i}' for i in range(3)])]>,<func(return=bool, name='post_data', lambda=NULL) -> [init(req=str('payload'))] before [func(return len(payload) > 10)]>",
        "__s@ref__": "API_KEY=sk-1234567890abcdef|BASE_URL=https://api.example.com|VERSION=v2.1",
        "__ref__": "auth->security.auth,db->database.connection,cache->redis.client",
        "__flagassignment__": "rate_limit=True,ssl_verify=True,retry_failed=True,log_requests=False"
    }
    
    game_sample = {
        "__base__": "name=GameEngine,type=(3),value=runtime,classmethod=update",
        "__class__": "GameObject,RenderEngine,PhysicsWorld",
        "__func__": "<func(return=bool, name='spawn_entity', lambda=NULL) -> [init(req=str('entity_type'))] before [func(return entity_type in ['player', 'enemy', 'item'])]>,<func(return=int, name='calculate_damage', lambda=NULL) -> [init(req=str('attack_power'))] before [func(return int(attack_power) * 2)]>,<func(return=dict, name='get_position', lambda=NULL) -> [init(req=str('entity_id'))] before [func(return {'x': hash(entity_id) % 100, 'y': hash(entity_id) % 50})]>",
        "__s@ref__": "SCREEN_WIDTH=1920|SCREEN_HEIGHT=1080|FPS=60|GRAVITY=9.81",
        "__ref__": "renderer->graphics.engine,physics->world.simulation,input->keyboard.handler",
        "__flagassignment__": "vsync=True,fullscreen=False,debug_mode=True,collision_detection=True"
    }
    
    samples = [
        ("Basic Data Processor", basic_sample),
        ("Advanced API Manager", advanced_sample), 
        ("Game Engine", game_sample)
    ]
    
    for sample_name, sample_code in samples:
        print(f"\n=== {sample_name} ===")
        constructor = ConstructorBase(**sample_code)
        builder = ConstructorBuilder(constructor=constructor)
        finished_constructor = builder._final
        
        print(f"Build ID: {constructor.BUILD['id']}")
        print(f"Class: {constructor.BUILD.get('class', {}).get('name', 'Unknown')}")
        print(f"Functions: {len(constructor.BUILD.get('functions', []))}")
        print(f"References: {len(constructor.BUILD.get('references', []))}")
        print(f"Flags: {len(constructor.BUILD.get('flags', {}))}")
        
        if constructor.BUILD.get('functions'):
            for func in constructor.BUILD['functions']:
                print(f"  -> {func.get('name', 'unknown')}: {func.get('return', 'void')}")
        
        if sample_name == "Basic Data Processor":
            result1 = finished_constructor(data="test_input")
            result2 = finished_constructor(input="hello world")
            result3 = finished_constructor(command="process_data")
            print(f"Validate result: {result1}")
            print(f"Transform result: {result2}")
            print(f"Execute result: {result3}")
        
        elif sample_name == "Advanced API Manager":
            auth_result = finished_constructor(token="abcdef1234567890abcdef1234567890")
            data_result = finished_constructor(endpoint="users")
            post_result = finished_constructor(payload="large_data_payload_here")
            print(f"Auth result: {auth_result}")
            print(f"Data result: {data_result}")
            print(f"Post result: {post_result}")
            
        elif sample_name == "Game Engine":
            spawn_result = finished_constructor(entity_type="player")
            damage_result = finished_constructor(attack_power="15")
            pos_result = finished_constructor(entity_id="player_001")
            print(f"Spawn result: {spawn_result}")
            print(f"Damage result: {damage_result}")
            print(f"Position result: {pos_result}")
    
    print("\n=== Constructor Language Examples ===")
    
    math_script = """
construct(name, value)
    var self.name = name
    var self.value = int(value)

method add(other)
    ret self.value add other

method multiply(factor)
    ret self.value mul factor

method is_positive()
    ret self.value gt 0

method get_info()
    ret str(self.name) add ": " add str(self.value)
"""
    
    data_script = """
construct(data_source)
    var self.source = data_source
    var self.cache = dict()

method fetch(key)
    if key in self.cache
        ret self.cache[key]
    else
        var result = "data_" add str(key)
        var self.cache[key] = result
        ret result
end

method clear_cache()
    var self.cache = dict()
    ret True

method get_cache_size()
    ret len(self.cache)
"""
    
    game_script = """
construct(player_name, level)
    var self.name = player_name
    var self.level = int(level)
    var self.health = 100
    var self.experience = 0

method take_damage(damage)
    var self.health = self.health sub damage
    if self.health lt 0
        var self.health = 0
    ret self.health

method gain_exp(points)
    var self.experience = self.experience add points
    if self.experience ge 100
        var self.level = self.level add 1
        var self.experience = 0
        ret True
    ret False

method is_alive()
    ret self.health gt 0
"""
    
    lang_samples = [
        ("Math Calculator", math_script),
        ("Data Handler", data_script),
        ("Game Player", game_script)
    ]
    
    for script_name, script_code in lang_samples:
        print(f"\n--- {script_name} ---")
        
        script_builder = ConstructorBuilder(constructor_script=script_code)
        if script_builder._final:
            constructor_instance = script_builder._final
            
            if script_name == "Math Calculator":
                calc = constructor_instance("Calculator", "42")
                print(f"Add result: {calc.add(8)}")
                print(f"Multiply result: {calc.multiply(2)}")
                print(f"Is positive: {calc.is_positive()}")
                print(f"Info: {calc.get_info()}")
            
            elif script_name == "Data Handler":
                handler = constructor_instance("database")
                print(f"Fetch test: {handler.fetch('user1')}")
                print(f"Fetch again: {handler.fetch('user1')}")
                print(f"Cache size: {handler.get_cache_size()}")
                print(f"Clear cache: {handler.clear_cache()}")
            
            elif script_name == "Game Player":
                player = constructor_instance("Hero", "5")
                print(f"Take damage: {player.take_damage(30)}")
                print(f"Gain exp: {player.gain_exp(150)}")
                print(f"Is alive: {player.is_alive()}")
        else:
            print("Failed to build constructor")
    
    print("\n=== Wheel Build Example ===")
    wheel_constructor = ConstructorBase(**basic_sample)
    wheel_builder = ConstructorBuilder(constructor=wheel_constructor, use_wheel_build=True)
    wheel_final = wheel_builder._final
    
    if wheel_final:
        print(f"Wheel built successfully")
        if hasattr(wheel_final, 'wheel_path') and wheel_final.wheel_path:
            print(f"Wheel path: {wheel_final.wheel_path}")
        
        result = wheel_final(data="wheel_test")
        print(f"Wheel execution result: {result}")
        
        if hasattr(wheel_final, 'wheel_builder') and wheel_final.wheel_builder:
            wheel_final.wheel_builder.Cleanup()
            print("Wheel cleanup completed")
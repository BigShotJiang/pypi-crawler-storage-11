# License

This project is dual-licensed under the GNU Affero General Public License v3.0
(AGPL-3.0) and a Commercial License.

## For Open Source Projects (AGPL-3.0)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.

## For Commercial Projects

If you want to use this library in a proprietary/commercial application
without complying with the AGPL-3.0 terms (i.e., without releasing your
source code), you must obtain a commercial license.

See [LICENSE-COMMERCIAL.md](LICENSE-COMMERCIAL.md) for details.

**Contact:** h@kotikot.com

---

## Third-Party Licenses

This library depends on third-party packages with their own licenses.
See [LICENSE-THIRD-PARTY.md](LICENSE-THIRD-PARTY.md) for details.

---
url: https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:legge:2005-03-07;82
url_xml: https://www.normattiva.it/do/atto/caricaAKN?dataGU=20050516&codiceRedaz=005G0104&dataVigenza=20251104
dataGU: 20050516
codiceRedaz: 005G0104
dataVigenza: 20251104
---

# Codice dell'amministrazione digitale.

IL PRESIDENTE DELLA REPUBBLICA

Visti gli articoli 76, 87 e 117, secondo comma, lettera r), della Costituzione;

Visto l'articolo 14 della legge 23 agosto 1988, n. 400, recante disciplina dell'attivita' di Governo e ordinamento della Presidenza del Consiglio dei Ministri;

Visto l'articolo 10 della legge 29 luglio 2003, n. 229, recante interventi in materia di qualita' della regolazione, riassetto normativo e codificazione - legge di semplificazione 2001;

Vista la legge 7 agosto 1990, n. 241, recante nuove norme in materia di procedimento amministrativo e di diritto di accesso ai documenti amministrativi;

Visto il decreto legislativo 12 febbraio 1993, n. 39, recante norme in materia di sistemi informativi automatizzati delle amministrazioni pubbliche, a norma dell'articolo 2, comma 1, lettera mm), della legge 23 ottobre 1992, n. 421;

Visto il decreto legislativo 30 luglio 1999, n. 300, recante disciplina dell'attivita' di Governo e ordinamento della Presidenza del Consiglio dei Ministri;

Visto il testo unico delle disposizioni legislative e regolamentari in materia di documentazione amministrativa (Testo A), di cui al decreto del Presidente della Repubblica 28 dicembre 2000, n. 445;

Visto il decreto legislativo 30 marzo 2001, n. 165, recante norme generali sull'ordinamento del lavoro alle dipendenze delle amministrazioni pubbliche;

Visto il decreto legislativo 23 gennaio 2002, n. 10, recante attuazione della direttiva 1999/93/CE relativa ad un quadro comunitario per le firme elettroniche;

Visto il decreto legislativo 30 giugno 2003, n. 196, recante codice in materia di protezione dei dati personali;

Vista la legge 9 gennaio 2004, n. 4, recante disposizioni per favorire l'accesso dei soggetti disabili agli strumenti informatici;

Visto il decreto legislativo 20 febbraio 2004, n. 52, recante attuazione della direttiva 2001/115/CE che semplifica ed armonizza le modalita' di fatturazione in materia di IVA;

Vista la preliminare deliberazione del Consiglio dei Ministri, adottata nella riunione dell'11 novembre 2004;

Esperita la procedura di notifica alla Commissione europea di cui alla direttiva 98/34/CE del Parlamento europeo e del Consiglio, del 22 giugno 1998, modificata dalla direttiva 98/48/CE del Parlamento europeo e del Consiglio, del 20 luglio 1998, attuata dalla legge 21 giugno 1986, n. 317, cosi' come modificata dal decreto legislativo 23 novembre 2000, n. 427;

Acquisito il parere della Conferenza unificata, ai sensi dell'articolo 8, del decreto legislativo 28 agosto 1997, n. 281, espresso nella riunione del 13 gennaio 2005;

Sentito il Garante per la protezione dei dati personali;

Udito il parere del Consiglio di Stato, espresso dalla Sezione consultiva per gli atti normativi nell'adunanza del 7 febbraio 2005;

Acquisito il parere delle competenti Commissioni della Camera dei deputati e del Senato della Repubblica;

Vista la deliberazione del Consiglio dei Ministri, adottata nella riunione del 4 marzo 2005;

Sulla proposta del Ministro per l'innovazione e le tecnologie, di concerto con il Ministro per la funzione pubblica, con il Ministro dell'economia e delle finanze, con il Ministro dell'interno, con il Ministro della giustizia, con il Ministro delle attivita' produttive e con il Ministro delle comunicazioni;

Emana il seguente decreto legislativo:

## Capo I - PRINCIPI GENERALI

### Sezione I - Definizioni, finalita' e ambito di applicazione

#### Art. 1. - Definizioni

1. Ai fini del presente codice si intende per: 0a) AgID: l'Agenzia per l'Italia digitale di cui all'articolo 19 del decreto-legge 22 giugno 2012, n. 83, convertito, con modificazioni, dalla legge 7 agosto 2012, n. 134;

- a) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- b) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- c) carta d'identita' elettronica: il documento d'identita' munito di elementi per l'identificazione fisica del titolare rilasciato su supporto informatico dalle amministrazioni comunali con la prevalente finalita' di dimostrare l'identita' anagrafica del suo titolare;
- d) carta nazionale dei servizi: il documento rilasciato su supporto informatico per consentire l'accesso per via telematica ai servizi erogati dalle pubbliche amministrazioni;
- e) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- f) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- g) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- h) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- i) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- i-bis) copia informatica di documento analogico: il documento informatico avente contenuto identico a quello del documento analogico da cui e' tratto;
- i-ter) copia per immagine su supporto informatico di documento analogico: il documento informatico avente contenuto e forma identici a quelli del documento analogico da cui e' tratto;
- i-quater) copia informatica di documento informatico: il documento informatico avente contenuto identico a quello del documento da cui e' tratto su supporto informatico con diversa sequenza di valori binari;
- i-quinquies) duplicato informatico: il documento informatico ottenuto mediante la memorizzazione, sullo stesso dispositivo o su dispositivi diversi, della medesima sequenza di valori binari del documento originario;
- i-sexies) dati territoriali: i dati che attengono, direttamente o indirettamente, a una localita' o a un'area geografica specifica;
- l) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- l-bis) formato aperto: un formato di dati reso pubblico, documentato esaustivamente e neutro rispetto agli strumenti tecnologici necessari per la fruizione dei dati stessi;
- l-ter) dati di tipo aperto: i dati che presentano le seguenti caratteristiche: 1) sono disponibili secondo i termini di una licenza o di una previsione normativa che ne permetta l'utilizzo da parte di chiunque, anche per finalita' commerciali, in formato disaggregato; 2) sono accessibili attraverso le tecnologie dell'informazione e della comunicazione, ivi comprese le reti telematiche pubbliche e private, in formati aperti ai sensi della lettera l-bis), sono adatti all'utilizzo automatico da parte di programmi per elaboratori e sono provvisti dei relativi metadati; 3) sono resi disponibili gratuitamente attraverso le tecnologie dell'informazione e della comunicazione, ivi comprese le reti telematiche pubbliche e private, oppure sono resi disponibili ai costi marginali sostenuti per la loro riproduzione e divulgazione salvo quanto previsto dall'articolo 7 del decreto legislativo 24 gennaio 2006, n. 36;
- m) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- n) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- n-bis) Riutilizzo: uso del dato di cui all'articolo 2, comma 1, lettera e), del decreto legislativo 24 gennaio 2006, n. 36;
- n-ter) domicilio digitale: un indirizzo elettronico eletto presso un servizio di posta elettronica certificata o un servizio elettronico di recapito certificato qualificato, come definito dal regolamento (UE) 23 luglio 2014 n. 910 del Parlamento europeo e del Consiglio in materia di identificazione elettronica e servizi fiduciari per le transazioni elettroniche nel mercato interno e che abroga la direttiva 1999/93/CE, di seguito "Regolamento eIDAS",valido ai fini delle comunicazioni elettroniche aventi valore legale;
- n-quater) servizio in rete o on-line: qualsiasi servizio di una amministrazione pubblica fruibile a distanza per via elettronica;
- o) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- p) documento informatico: il documento elettronico che contiene la rappresentazione informatica di atti, fatti o dati giuridicamente rilevanti;
- p-bis) documento analogico: la rappresentazione non informatica di atti, fatti o dati giuridicamente rilevanti;
- q) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- q-bis) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- r) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- s) firma digitale: un particolare tipo di firma qualificata basata su un su un sistema di chiavi crittografiche, una pubblica e una privata, correlate tra loro, che consente al titolare ((di firma elettronica)) tramite la chiave privata ((e a un soggetto terzo)) tramite la chiave pubblica, rispettivamente, di rendere manifesta e di verificare la provenienza e l'integrita' di un documento informatico o di un insieme di documenti informatici;
- t) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- u) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- u-bis) gestore di posta elettronica certificata: il soggetto che presta servizi di trasmissione dei documenti informatici mediante la posta elettronica certificata; u-ter)LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179; u-quater) identita' digitale: la rappresentazione informatica della corrispondenza tra un utente e i suoi attributi identificativi, verificata attraverso l'insieme dei dati raccolti e registrati in forma digitale secondo le modalita' fissate nel decreto attuativo dell'articolo 64;
- v) originali non unici: i documenti per i quali sia possibile risalire al loro contenuto attraverso altre scritture o documenti di cui sia obbligatoria la conservazione, anche se in possesso di terzi;
- v-bis) posta elettronica certificata: sistema di comunicazione in grado di attestare l'invio e l'avvenuta consegna di un messaggio di posta elettronica e di fornire ricevute opponibili ai terzi;
- z) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- aa) titolare ((di firma elettronica)): la persona fisica cui e' attribuita la firma elettronica e che ha accesso ai dispositivi per la ((sua)) creazione ((nonche' alle applicazioni per la sua apposizione)) della firma elettronica;
- bb) LETTERA SOPPRESSA DAL D.LGS. 26 AGOSTO 2016, N. 179;
- cc) titolare del dato: uno dei soggetti di cui all'articolo 2, comma 2, che ha originariamente formato per uso proprio o commissionato ad altro soggetto il documento che rappresenta il dato, o che ne ha la disponibilita';
- dd) interoperabilita': caratteristica di un sistema informativo, le cui interfacce sono pubbliche e aperte, di interagire in maniera automatica con altri sistemi informativi per lo scambio di informazioni e l'erogazione di servizi;
- ee) cooperazione applicativa: la parte del Sistema Pubblico di Connettivita' finalizzata all'interazione tra i sistemi informatici dei soggetti partecipanti, per garantire l'integrazione dei metadati, delle informazioni, dei processi e procedimenti amministrativi.))
- ff) Linee guida: le regole tecniche e di indirizzo adottate secondo il procedimento di cui all'articolo 71.

1-bis. Ai fini del presente Codice, valgono le definizioni di cui all'articolo 3 del Regolamento eIDAS;

1-ter. Ove la legge consente l'utilizzo della posta elettronica certificata e' ammesso anche l'utilizzo di altro servizio elettronico di recapito certificato ((qualificato ai sensi degli articoli 3, numero 37), e 44 del Regolamento eIDAS)).

#### Art. 2. - Finalita' e ambito di applicazione

1. Lo Stato, le Regioni e le autonomie locali assicurano la disponibilita', la gestione, l'accesso, la trasmissione, la conservazione e la fruibilita' dell'informazione in modalita' digitale e si organizzano ed agiscono a tale fine utilizzando con le modalita' piu' appropriate e nel modo piu' adeguato al soddisfacimento degli interessi degli utenti le tecnologie dell'informazione e della comunicazione.

2. Le disposizioni del presente Codice si applicano:

- a) alle pubbliche amministrazioni di cui all'articolo 1, comma 2, del decreto legislativo 30 marzo 2001, n. 165, nel rispetto del riparto di competenza di cui all'articolo 117 della Costituzione, ivi comprese le autorita' di sistema portuale, nonche' alle autorita' amministrative indipendenti di garanzia, vigilanza e regolazione;
- b) ai gestori di servizi pubblici, ivi comprese le societa' quotate, in relazione ai servizi di pubblico interesse;
- c) alle societa' a controllo pubblico, come definite nel decreto legislativo 19 agosto 2016, n. 175, escluse le societa' quotate di cui all'articolo 2, comma 1, lettera p), del medesimo decreto che non rientrino nella categoria di cui alla lettera b).

2-bis. COMMA ABROGATO DAL D.LGS. 30 DICEMBRE 2010, N. 235.

3. Le disposizioni del presente Codice e le relative Linee guida concernenti il documento informatico, le firme elettroniche e i servizi fiduciari di cui al Capo II, la riproduzione e conservazione dei documenti di cui agli articoli 43 e 44, il domicilio digitale e le comunicazioni elettroniche di cui all'articolo 3-bis e al Capo IV, l'identita' digitale di cui agli articoli 3-bis e 64 si applicano anche ai privati, ove non diversamente previsto.

4. Le disposizioni di cui al capo V, concernenti l'accesso ai documenti informatici e la fruibilita' delle informazioni digitali, si applicano anche agli organismi di diritto pubblico.

5. Le disposizioni del presente Codice si applicano nel rispetto della disciplina in materia di trattamento dei dati personali e, in particolare, delle disposizioni del Codice in materia di protezione dei dati personali approvato con decreto legislativo 30 giugno 2003, n. 196;

6. Le disposizioni del presente Codice non si applicano limitatamente all'esercizio delle attivita' e funzioni di ordine e sicurezza pubblica, difesa e sicurezza nazionale, polizia giudiziaria e polizia economico-finanziaria e consultazioni elettorali , nonche' alle comunicazioni di emergenza e di allerta in ambito di protezione civile. Le disposizioni del presente Codice si applicano al processo civile, penale, amministrativo, contabile e tributario, in quanto compatibili e salvo che non sia diversamente disposto dalle disposizioni in materia di processo telematico. ((52))

6-bis. Ferma restando l'applicabilita' delle disposizioni del presente decreto agli atti di liquidazione, rettifica, accertamento e di irrogazione delle sanzioni di natura tributaria, con decreto del Presidente del Consiglio dei ministri o del Ministro delegato, adottato su proposta del Ministro dell'economia e delle finanze, sono stabiliti le modalita' e i termini di applicazione delle disposizioni del presente Codice alle attivita' e funzioni ispettive e di controllo fiscale.

------------ AGGIORNAMENTO (52) La Corte Costituzionale, con sentenza 11 dicembre 2024 - 23 gennaio 2025, n. 3 (in G.U. 1a s.s. 29/1/2025, n. 5), ha dichiarato "l'illegittimita' costituzionale degli artt. 9, terzo comma, della legge 17 febbraio 1968, n. 108 (Norme per la elezione dei Consigli regionali delle Regioni a statuto normale) e 2, comma 6, del decreto legislativo 7 marzo 2005, n. 82 (Codice dell'amministrazione digitale), nella parte in cui non prevedono per l'elettore, che non sia in grado di apporre una firma autografa per certificata impossibilita' derivante da un grave impedimento fisico o perche' si trova nelle condizioni per esercitare il voto domiciliare, la possibilita' di sottoscrivere un documento informatico con firma elettronica qualificata, cui e' associato un riferimento temporale validamente opponibile ai terzi".

### Sezione II - ((Carta della cittadinanza digitale))

#### Art. 3. - Diritto all'uso delle tecnologie

1. Chiunque ha il diritto di usare ((, in modo accessibile ed efficace,)) le soluzioni e gli strumenti di cui al presente Codice nei rapporti con i soggetti di cui all'articolo 2, comma 2, anche ai fini ((dell'esercizio dei diritti di accesso e)) della partecipazione al procedimento amministrativo, fermi restando i diritti delle minoranze linguistiche riconosciute.

1-bis. COMMA ABROGATO DAL D.LGS. 30 DICEMBRE 2010, N. 235.

1-ter. La tutela giurisdizionale davanti al giudice amministrativo e' disciplinata dal codice del processo amministrativo.

1-quater. ((COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

1-quinquies. ((COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

1-sexies. ((COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

#### Art. 3-bis. - Identita' digitale e Domicilio digitale

01. Chiunque ha il diritto di accedere ai servizi on-line offerti dai soggetti di cui all'articolo 2, comma 2, tramite la propria identita' digitale e anche attraverso il punto di accesso telematico di cui all'articolo 64-bis. (29)

1. I soggetti di cui all'articolo 2, comma 2, i professionisti tenuti all'iscrizione in albi ed elenchi e i soggetti tenuti all'iscrizione nel registro delle imprese hanno l'obbligo di dotarsi di un domicilio digitale iscritto nell'elenco di cui agli articoli 6-bis o 6-ter.

1-bis. Fermo restando quanto previsto al comma 1, chiunque ha facolta' di eleggere o modificare il proprio domicilio digitale da iscrivere nell'elenco di cui all'articolo 6-quater. Nel caso in cui il domicilio eletto risulti non piu' attivo si procede alla cancellazione d'ufficio dall'indice di cui all'articolo 6-quater secondo le modalita' fissate nelle Linee guida.

1-ter. I domicili digitali di cui ai commi 1, 1-bis e 4-quinquies sono eletti secondo le modalita' stabilite con le Linee guida. Le persone fisiche possono altresi' eleggere il domicilio digitale avvalendosi del servizio di cui all'articolo 64-bis , di quello reso disponibile on-line dall'Anagrafe nazionale della popolazione residente (ANPR) di cui all'articolo 62, ovvero recandosi presso l'ufficio anagrafe del proprio comune di residenza.

1-quater. I soggetti di cui ai commi 1 e 1-bis hanno l'obbligo di fare un uso diligente del proprio domicilio digitale e di comunicare ogni modifica o variazione del medesimo secondo le modalita' fissate nelle Linee guida. Con le stesse Linee guida, fermo restando quanto previsto ai commi 3-bis e 4-bis, sono definite le modalita' di gestione e di aggiornamento dell'elenco di cui all'articolo 6-quater anche nei casi di decesso del titolare del domicilio digitale eletto o di impossibilita' sopravvenuta di avvalersi del domicilio.

2. COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217.

3. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

3-bis. Con decreto del Presidente del Consiglio dei ministri o del Ministro delegato per la semplificazione e la pubblica amministrazione, sentiti l'AgID e il Garante per la protezione dei dati personali e acquisito il parere della Conferenza unificata, e' stabilita la data a decorrere dalla quale le comunicazioni tra i soggetti di cui all'articolo 2, comma 2, e coloro che non hanno provveduto a eleggere un domicilio digitale ai sensi del comma 1-bis, avvengono esclusivamente in forma elettronica. Con lo stesso decreto sono determinate le modalita' con le quali ai predetti soggetti e' attribuito un domicilio digitale ovvero altre modalita' con le quali, anche per superare il divario digitale, i documenti possono essere messi a disposizione e consegnati a coloro che non hanno accesso ad un domicilio digitale.

4. A decorrere dal 1° gennaio 2013, salvo i casi in cui e' prevista dalla normativa vigente una diversa modalita' di comunicazione o di pubblicazione in via telematica, le amministrazioni pubbliche e i gestori o esercenti di pubblici servizi comunicano con il cittadino esclusivamente tramite il domicilio digitale dallo stesso dichiarato ((. Per la violazione della presente disposizione si applica l'articolo 18-bis)). (28)

4-bis. Fino alla data fissata nel decreto di cui al comma 3-bis, i soggetti di cui all'articolo 2, comma 2, possono predisporre le comunicazioni ai soggetti che non hanno un domicilio digitale ovvero nei casi di domicilio digitale non attivo, non funzionante o non raggiungibile, come documenti informatici sottoscritti con firma digitale o altra firma elettronica qualificata, da conservare nei propri archivi, ed inviare agli stessi, per posta ordinaria o raccomandata con avviso di ricevimento, copia analogica di tali documenti su cui e' apposto a stampa il contrassegno di cui all'articolo 23, comma 2-bis o l'indicazione a mezzo stampa del responsabile pro tempore in sostituzione della firma autografa ai sensi dell'articolo 3 del decreto legislativo 12 febbraio 1993, n. 39 ovvero un avviso con le indicazioni delle modalita' con le quali i suddetti documenti sono messi a disposizione e consegnati al destinatario.

4-ter. Le disposizioni di cui al comma 4-bis soddisfano a tutti gli effetti di legge gli obblighi di conservazione e di esibizione dei documenti previsti dalla legislazione vigente laddove la copia analogica inviata al cittadino contenga una dicitura che specifichi che il documento informatico, da cui la copia e' tratta, e' stato predisposto come documento nativo digitale ed e' disponibile presso l'amministrazione. (28)

4-quater. La copia analogica con l'indicazione a mezzo stampa del responsabile in sostituzione della firma autografa ai sensi dell'articolo 3 del decreto legislativo 12 febbraio 1993, n. 39, soddisfa le condizioni di cui all'articolo 23, comma 2-bis, salvo i casi in cui il documento rappresenti, per propria natura, una certificazione rilasciata dall'amministrazione da utilizzarsi nei rapporti tra privati.

4-quinquies. E' possibile eleggere anche un domicilio digitale speciale per determinati atti, procedimenti o affari. In tal caso, ferma restando la validita' ai fini delle comunicazioni elettroniche aventi valore legale, colui che lo ha eletto non puo' opporre eccezioni relative alla forma e alla data della spedizione e del ricevimento delle comunicazioni o notificazioni ivi indirizzate.

5. Dall'attuazione delle disposizioni di cui al presente articolo non devono derivare nuovi o maggiori oneri a carico della finanza pubblica. (21)

------------ AGGIORNAMENTO (21) Il D.L. 21 giugno 2013, n. 69, convertito con modificazioni dalla L. 9 agosto 2013, n. 98, nel modificare l'art. 4 comma 1, del D.L. 18 ottobre 2012, n. 179, convertito con modificazioni dalla L. 17 dicembre 2012, n. 221, ha disposto (con l'art. 13, comma 2-quater) che il decreto ministeriale previsto dal presente articolo, qualora non ancora adottato e decorsi ulteriori trenta giorni dalla data di entrata in vigore della legge di conversione del D.L. 69/2013 suindicato, e' adottato dal Presidente del Consiglio dei ministri anche ove non sia pervenuto il concerto dei Ministri interessati. ------------ AGGIORNAMENTO (28) Il D.Lgs. 26 agosto 2016, n. 179 ha disposto (con l'art. 61, comma 2, lettera d)) che la parola «cittadino», ovunque ricorra, si intende come «persona fisica». Ha inoltre disposto (con l'art. 62, comma 1) che "Le disposizioni di cui ai commi 2 e 3-bis dell'articolo 3-bis del decreto legislativo n. 82 del 2005, come modificato dall'articolo 4 del presente decreto, producono effetti a partire dalla completa attuazione dell'ANPR e, comunque, non oltre il 31 dicembre 2017". ------------ AGGIORNAMENTO (29) Il D.Lgs. 13 dicembre 2017, n. 217 ha disposto (con l'art. 65, comma 1) che "Il diritto di cui all'articolo 3-bis, comma 01, e' riconosciuto a decorrere dal 1° gennaio 2018".

#### Art. 4.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

#### Art. 5. - (Effettuazione di pagamenti con modalita' informatiche)

1. I soggetti di cui all'articolo 2, comma 2, sono obbligati ad accettare, tramite la piattaforma di cui al comma 2, i pagamenti spettanti a qualsiasi titolo attraverso sistemi di pagamento elettronico, ivi inclusi, per i micro-pagamenti, quelli basati sull'uso del credito telefonico. Tramite la piattaforma elettronica di cui al comma 2, resta ferma la possibilita' di accettare anche altre forme di pagamento elettronico, senza discriminazione in relazione allo schema di pagamento abilitato per ciascuna tipologia di strumento di pagamento elettronico come definita ai sensi dell'articolo 2, punti 33), 34) e 35) del regolamento UE 2015/751 del Parlamento europeo e del Consiglio del 29 aprile 2015 relativo alle commissioni interbancarie sulle operazioni di pagamento basate su carta.

2. Al fine di dare attuazione al comma 1, la Presidenza del Consiglio dei ministri mette a disposizione, attraverso il Sistema pubblico di connettivita', una piattaforma tecnologica per l'interconnessione e l'interoperabilita' tra le pubbliche amministrazioni e i prestatori di servizi di pagamento abilitati, al fine di assicurare, attraverso gli strumenti di cui all'articolo 64, l'autenticazione dei soggetti interessati all'operazione in tutta la gestione del processo di pagamento. (29) (31) (34) (36)

2-bis. COMMA ABROGATO DAL D.L. 6 NOVEMBRE 2021, N. 152.

2-ter. I soggetti di cui all'articolo 2, comma 2, consentono di effettuare pagamenti elettronici tramite la piattaforma di cui al comma 2 anche per il pagamento spontaneo di tributi di cui all'articolo 2-bis del decreto-legge 22 ottobre 2016, n. 193, convertito, con modificazioni dalla legge 1° dicembre 2016, n. 225.

2-quater. I prestatori di servizi di pagamento abilitati eseguono pagamenti a favore delle pubbliche amministrazioni attraverso l'utilizzo della piattaforma di cui al comma 2. Resta fermo il sistema dei versamenti unitari di cui all'articolo 17 e seguenti del decreto legislativo 9 luglio 1997, n. 241, Capo III ((...)).

2-quinquies. Tramite la piattaforma di cui al comma 2, le informazioni sui pagamenti sono messe a disposizione anche del Ministero dell'economia e delle finanze - Dipartimento Ragioneria generale dello Stato.

2-sexies. La piattaforma tecnologica di cui al comma 2 puo' essere utilizzata anche per facilitare e automatizzare, attraverso i pagamenti elettronici, i processi di certificazione fiscale tra soggetti privati, tra cui la fatturazione elettronica e la memorizzazione e trasmissione dei dati dei corrispettivi giornalieri di cui agli articoli 1 e 2 del decreto legislativo 5 agosto 2015, n. 127.

2-septies. Con decreto del Presidente del Consiglio dei Ministri o del Ministro delegato per l'innovazione tecnologica e la digitalizzazione, di concerto con il Ministro dell'economia e delle finanze, sono definite le regole tecniche di funzionamento della piattaforma tecnologica e dei processi di cui al comma 2-sexies.

3. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

3-bis. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

3-ter. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

4. L'Agenzia per l'Italia digitale, sentita la Banca d'Italia, definisce linee guida per l'attuazione del presente articolo e per la specifica dei codici identificativi del pagamento di cui al comma 1 e le modalita' attraverso le quali il prestatore dei servizi di pagamento mette a disposizione dell'ente le informazioni relative al pagamento medesimo.

5. Le attivita' previste dal presente articolo si svolgono con le risorse umane, finanziarie e strumentali disponibili a legislazione vigente.

--------------- AGGIORNAMENTO (16) Il D.L. 9 febbraio 2012, n. 5, convertito con modificazioni dalla L. 4 aprile 2012, n. 35, ha disposto (con l'art. 6-ter, comma 2) che " Gli obblighi introdotti per le amministrazioni pubbliche con le disposizioni di cui al comma 1 acquistano efficacia decorsi novanta giorni dalla data di entrata in vigore della legge di conversione del presente decreto." --------------- AGGIORNAMENTO (29) Il D.Lgs. 13 dicembre 2017, n. 217 ha disposto (con l'art. 65, comma 2) che "L'obbligo per i prestatori di servizi di pagamento abilitati di utilizzare esclusivamente la piattaforma di cui all'articolo 5, comma 2, del decreto legislativo n. 82 del 2005 per i pagamenti verso le pubbliche amministrazioni decorre dal 1° gennaio 2019". --------------- AGGIORNAMENTO (31) Il D.L. 14 dicembre 2018, n. 135, convertito con modificazioni dalla L. 11 febbraio 2019, n. 12, ha disposto (con l'art. 8, comma 1) che "Ai fini dell'attuazione degli obiettivi di cui all'Agenda digitale italiana anche in coerenza con gli obiettivi dell'Agenda digitale europea, la gestione della piattaforma di cui all'articolo 5, comma 2, del decreto legislativo 7 marzo 2005, n. 82, nonche' i compiti, relativi a tale piattaforma, svolti dall'Agenzia per l'Italia digitale, sono trasferiti alla Presidenza del Consiglio dei ministri che a tal fine si avvale, se nominato, del Commissario straordinario di cui all'articolo 63, comma 1, del decreto legislativo 26 agosto 2016, n. 179". Il D.Lgs. 13 dicembre 2017, n. 217, come modificato dal D.L. 14 dicembre 2018, n. 135, convertito con modificazioni dalla L. 11 febbraio 2019, n. 12, ha disposto (con l'art. 65, comma 2) che "L'obbligo per i prestatori di servizi di pagamento abilitati di utilizzare esclusivamente la piattaforma di cui all'articolo 5, comma 2, del decreto legislativo n. 82 del 2005 per i pagamenti verso le pubbliche amministrazioni decorre dal 31 dicembre 2019". -------------- AGGIORNAMENTO (34) Il D.Lgs. 13 dicembre 2017, n. 217, come modificato dal D.L. 30 dicembre 2019, n. 162, ha disposto (con l'art. 65, comma 2) che "L'obbligo per i prestatori di servizi di pagamento abilitati di utilizzare esclusivamente la piattaforma di cui all'articolo 5, comma 2, del decreto legislativo n. 82 del 2005 per i pagamenti verso le pubbliche amministrazioni decorre dal 30 giugno 2020". --------------- AGGIORNAMENTO (36) Il D.Lgs. 13 dicembre 2017, n. 217, come modificato dal D.L. 16 luglio 2020, n. 76, ha disposto (con l'art. 65, comma 2) che "L'obbligo per i prestatori di servizi di pagamento abilitati di utilizzare esclusivamente la piattaforma di cui all'articolo 5, comma 2, del decreto legislativo n. 82 del 2005 per i pagamenti verso le pubbliche amministrazioni decorre dal 28 febbraio 2021".

#### Art. 5-bis. - (Comunicazioni tra imprese e amministrazioni pubbliche).

1. La presentazione di istanze, dichiarazioni, dati e lo scambio di informazioni e documenti, anche a fini statistici, tra le imprese e le amministrazioni pubbliche avviene esclusivamente utilizzando le tecnologie dell'informazione e della comunicazione. Con le medesime modalita' le amministrazioni pubbliche adottano e comunicano atti e provvedimenti amministrativi nei confronti delle imprese.

2. Con decreto del Presidente del Consiglio dei Ministri, su proposta del Ministro per la pubblica amministrazione e l'innovazione, di concerto con il Ministro dello sviluppo economico e con il Ministro per la semplificazione normativa, sono adottate le modalita' di attuazione del comma 1 da parte delle pubbliche amministrazioni centrali e fissati i relativi termini.

3. ((AgID)), anche avvalendosi degli uffici di cui all'articolo 17, provvede alla verifica dell'attuazione del comma 1 secondo le modalita' e i termini indicati nel decreto di cui al comma 2.

4. Il Governo promuove l'intesa con regioni ed enti locali in sede di Conferenza unificata per l'adozione degli indirizzi utili alla realizzazione delle finalita' di cui al comma 1.

#### Art. 6. - ((Utilizzo del domicilio digitale))

((

1. Le comunicazioni tramite i domicili digitali sono effettuate agli indirizzi inseriti negli elenchi di cui agli articoli 6-bis, 6-ter e 6-quater, o a quello eletto come domicilio speciale per determinati atti o affari ai sensi dell'articolo 3-bis, comma 4-quinquies. Le comunicazioni elettroniche trasmesse ad uno dei domicili digitali di cui all'articolo 3-bis producono, quanto al momento della spedizione e del ricevimento, gli stessi effetti giuridici delle comunicazioni a mezzo raccomandata con ricevuta di ritorno ed equivalgono alla notificazione per mezzo della posta salvo che la legge disponga diversamente. Le suddette comunicazioni si intendono spedite dal mittente se inviate al proprio gestore e si intendono consegnate se rese disponibili al domicilio digitale del destinatario, salva la prova che la mancata consegna sia dovuta a fatto non imputabile al destinatario medesimo. La data e l'ora di trasmissione e ricezione del documento informatico sono opponibili ai terzi se apposte in conformita' alle Linee guida.

))

1-bis. ((COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

((

1-ter. L'elenco dei domicili digitali delle imprese e dei professionisti e' l'Indice nazionale dei domicili digitali (INI-PEC) delle imprese e dei professionisti di cui all'articolo 6-bis. L'elenco dei domicili digitali dei soggetti di cui all'articolo 2, comma 2, lettere a) e b), e' l'Indice degli indirizzi della pubblica amministrazione e dei gestori di pubblici servizi, di cui all'articolo 6-ter. L'elenco dei domicili digitali delle persone fisiche e degli altri enti di diritto privato diversi da quelli di cui al primo e al secondo periodo e' l'Indice degli indirizzi delle persone fisiche e degli altri enti di diritto privato di cui all'articolo 6-quater.

1-quater. I soggetti di cui all'articolo 2, comma 2, notificano direttamente presso i domicili digitali di cui all'articolo 3-bis i propri atti, compresi i verbali relativi alle sanzioni amministrative, gli atti impositivi di accertamento e di riscossione e le ingiunzioni di cui all'articolo 2 del regio decreto 14 aprile 1910, n. 639, fatte salve le specifiche disposizioni in ambito tributario. La conformita' della copia informatica del documento notificato all'originale e' attestata dal responsabile del procedimento in conformita' a quanto disposto agli articoli 22 e 23-bis.

))

2. COMMA ABROGATO DAL D.LGS. 30 DICEMBRE 2010, N. 235.

2-bis. COMMA ABROGATO DAL D.LGS. 30 DICEMBRE 2010, N. 235.

#### Art. 6-bis. - (Indice nazionale dei domicili digitali delle imprese e dei professionisti)

1. Al fine di favorire la presentazione di istanze, dichiarazioni e dati, nonche' lo scambio di informazioni e documenti tra i soggetti di cui all'articolo 2, comma 2 e le imprese e i professionisti in modalita' telematica, e' istituito il pubblico elenco denominato Indice nazionale dei domicili digitali (INI-PEC) delle imprese e dei professionisti, presso il Ministero per lo sviluppo economico.

2. L'Indice nazionale di cui al comma 1 e' realizzato a partire dagli elenchi di indirizzi PEC costituiti presso il registro delle imprese e gli ordini o collegi professionali, in attuazione di quanto previsto dall'articolo 16 del decreto-legge 29 novembre 2008, n. 185, convertito, con modificazioni, dalla legge 28 gennaio 2009, n. 2. ((Nell'Indice nazionale sono inseriti anche i domicili digitali dei professionisti diversi da quelli di cui al primo periodo, iscritti in elenchi o registri detenuti dalle pubbliche amministrazioni e istituiti con legge dello Stato.)) I domicili digitali inseriti in tale Indice costituiscono mezzo esclusivo di comunicazione e notifica con i soggetti di cui all'articolo 2, comma 2.

2-bis. L'INI-PEC acquisisce dagli ordini e dai collegi professionali gli attributi qualificati dell'identita' digitale ai fini di quanto previsto dal decreto di cui all'articolo 64, comma 2-sexies.

3. COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217.

4. Il Ministero per lo sviluppo economico, al fine del contenimento dei costi e dell'utilizzo razionale delle risorse, sentita l'Agenzia per l'Italia digitale, si avvale per la realizzazione e gestione operativa dell'Indice nazionale di cui al comma 1 delle strutture informatiche delle Camere di commercio deputate alla gestione del registro imprese e ne definisce con proprio decreto, da emanare entro 60 giorni dalla data di entrata in vigore della presente disposizione, le modalita' di accesso e di aggiornamento.

5. Nel decreto di cui al comma 4 sono anche definite le modalita' e le forme con cui gli ordini e i collegi professionali ((nonche' le pubbliche amministrazioni)) comunicano all'Indice nazionale di cui al comma 1 tutti gli indirizzi PEC relativi ai professionisti di propria competenza e sono previsti gli strumenti telematici resi disponibili dalle Camere di commercio per il tramite delle proprie strutture informatiche al fine di ottimizzare la raccolta e aggiornamento dei medesimi indirizzi.

6. Dall'attuazione delle disposizioni di cui al presente articolo non devono derivare nuovi o maggiori oneri a carico della finanza pubblica.

#### Art. 6-ter.

(Indice ((dei domicili digitali)) delle pubbliche amministrazioni e dei gestori di pubblici servizi).

1. Al fine di assicurare la pubblicita' dei riferimenti telematici delle pubbliche amministrazioni e dei gestori dei pubblici servizi e' istituito il pubblico elenco di fiducia denominato "Indice ((dei domicili digitali)) della pubblica amministrazione e dei gestori di pubblici servizi", nel quale sono indicati ((i domicili digitali)) da utilizzare per le comunicazioni e per lo scambio di informazioni e per l'invio di documenti a tutti gli effetti di legge tra le pubbliche amministrazioni, i gestori di pubblici servizi e i privati.

2. La realizzazione e la gestione dell'Indice sono affidate all'AgID, che puo' utilizzare a tal fine elenchi e repertori gia' formati dalle amministrazioni pubbliche.

3. Le amministrazioni di cui al comma 1 ((e i gestori di pubblici servizi)) aggiornano gli indirizzi e i contenuti dell'Indice tempestivamente e comunque con cadenza almeno semestrale, secondo le indicazioni dell'AgID. La mancata comunicazione degli elementi necessari al completamento dell'Indice e del loro aggiornamento e' valutata ai fini della responsabilita' dirigenziale e dell'attribuzione della retribuzione di risultato ai dirigenti responsabili.

#### Art. 6-quater. - (Indice nazionale dei domicili digitali delle persone fisiche, dei professionisti e degli altri enti di diritto privato, non tenuti all'iscrizione in albi, elenchi o registri professionali o nel registro delle imprese)

1. E' istituito il pubblico elenco dei domicili digitali delle persone fisiche, dei professionisti e degli altri enti di diritto privato non tenuti all'iscrizione nell'indice di cui all'articolo 6-bis, nel quale sono indicati i domicili eletti ai sensi dell'articolo 3-bis, comma 1-bis. La realizzazione e la gestione del presente Indice sono affidate all'AgID, che vi provvede avvalendosi delle strutture informatiche delle Camere di commercio gia' deputate alla gestione dell'elenco di cui all'articolo 6-bis. E' fatta salva la facolta' del professionista, non iscritto in albi, registri o elenchi professionali di cui all'articolo 6-bis, di eleggere presso il presente Indice un domicilio digitale professionale e un domicilio digitale personale diverso dal primo.

2. Per i professionisti iscritti in albi ed elenchi il domicilio digitale e' l'indirizzo inserito nell'elenco di cui all'articolo 6-bis, fermo restando il diritto di eleggerne uno diverso ai sensi dell'articolo 3-bis, comma 1-bis. Ai fini dell'inserimento dei domicili dei professionisti nel predetto elenco il Ministero dello sviluppo economico rende disponibili all'AgID, tramite servizi informatici individuati nelle Linee guida, i relativi indirizzi gia' contenuti nell'elenco di cui all'articolo 6-bis.

3. AgID provvede costantemente all'aggiornamento e al trasferimento dei domicili digitali delle persone fisiche contenuti nell'elenco di cui al presente articolo nell'ANPR e il Ministero dell'interno provvede costantemente all'aggiornamento e al trasferimento dei domicili digitali delle persone fisiche contenuti ((nell'ANPR)) nell'elenco di cui al presente articolo. Le funzioni di aggiornamento e trasferimento dei dati sono svolte con le risorse disponibili a legislazione vigente, senza nuovi o maggiori oneri a carico della ((finanza pubblica)).

#### Art. 6-quinquies. - (Consultazione e accesso)

1. La consultazione on-line degli elenchi di cui agli articoli 6-bis, 6-ter e 6-quater e' consentita a chiunque senza necessita' di autenticazione. Gli elenchi sono realizzati in formato aperto.

2. L'estrazione dei domicili digitali dagli elenchi, di cui agli articoli 6-bis, 6-ter e 6-quater, e' effettuata secondo le modalita' fissate da AgID nelle Linee guida.

3. In assenza di preventiva autorizzazione del titolare dell'indirizzo, e' vietato l'utilizzo dei domicili digitali di cui al presente articolo ((per l'invio di comunicazioni commerciali, come definite dall'articolo 2, comma 1, lettera f), del decreto legislativo 9 aprile 2003, n. 70)).

4. Gli elenchi di cui agli articoli 6-bis, 6-ter e 6-quater contengono le informazioni relative alla elezione, modifica o cessazione del domicilio digitale.

#### Art. 7. - ((Diritto a servizi on-line semplici e integrati))

((01. Chiunque ha diritto di fruire dei servizi erogati dai soggetti di cui all'articolo 2, comma 2, in forma digitale e in modo integrato, tramite gli strumenti telematici messi a disposizione dalle pubbliche amministrazioni e il punto di accesso di cui all'articolo 64-bis, anche attraverso dispositivi mobili.)) ((29))

1. I soggetti di cui all'articolo 2, comma 2, provvedono alla riorganizzazione e all'aggiornamento dei servizi resi, sulla base di una preventiva analisi delle reali esigenze ((degli utenti)) e rendono disponibili ((on-line i propri servizi)) nel rispetto delle disposizioni del presente Codice e degli standard ((e dei livelli di qualita' individuati e periodicamente aggiornati dall'AgID con proprie Linee guida tenuto anche conto dell'evoluzione tecnologica)).

2. ((COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

3. Per i servizi in rete, i soggetti di cui all'articolo 2, comma 2, consentono agli utenti di esprimere la soddisfazione rispetto alla qualita', anche in termini di fruibilita', accessibilita' e tempestivita', del servizio reso all'utente stesso e pubblicano sui propri siti i dati risultanti, ivi incluse le statistiche di utilizzo.

4. In caso di violazione degli obblighi di cui al presente articolo, ((gli utenti, fermo restando il diritto di rivolgersi al difensore civico digitale di cui all'articolo 17,)) possono agire in giudizio, anche nei termini e con le modalita' stabilite nel decreto legislativo 20 dicembre 2009, n. 198.

--------------- AGGIORNAMENTO (29) Il D.Lgs. 13 dicembre 2017, n. 217 ha disposto (con l'art. 65, comma 6) che "Il diritto di cui all'articolo 7, comma 01, e' riconosciuto a decorrere dalla data di attivazione del punto di accesso di cui all'articolo 64-bis".

#### Art. 8. - Alfabetizzazione informatica dei cittadini

1. ((Lo Stato e i soggetti di cui all'articolo 2, comma 2, promuovono iniziative volte a favorire la diffusione della cultura digitale tra i cittadini con particolare riguardo ai minori e alle categorie a rischio di esclusione, anche al fine di favorire lo sviluppo di competenze di informatica giuridica e l'utilizzo dei servizi digitali delle pubbliche amministrazioni con azioni specifiche e concrete, avvalendosi di un insieme di mezzi diversi fra i quali il servizio radiotelevisivo.))

#### Art. 8-bis. - (Connettivita' alla rete Internet negli uffici e luoghi pubblici)

1. I soggetti di cui all'articolo 2, comma 2, favoriscono, in linea con gli obiettivi dell'Agenda digitale europea, la disponibilita' di connettivita' alla rete Internet presso gli uffici pubblici e altri luoghi pubblici, in particolare nei settori scolastico, sanitario e di interesse turistico, anche prevedendo che la porzione di banda non utilizzata dagli stessi uffici sia messa a disposizione degli utenti ((nel rispetto degli)) standard di sicurezza fissati dall'Agid.

2. I soggetti di cui all'articolo 2, comma 2, mettono a disposizione degli utenti connettivita' a banda larga per l'accesso alla rete Internet nei limiti della banda disponibile e con le modalita' determinate dall'AgID.

#### Art. 9. - Partecipazione democratica elettronica

1. ((I soggetti di cui all'articolo 2, comma 2,)) favoriscono ogni forma di uso delle nuove tecnologie per promuovere una maggiore partecipazione dei cittadini, anche residenti all'estero, al processo democratico e per facilitare l'esercizio dei diritti politici e civili ((e migliorare la qualita' dei propri atti, anche attraverso l'utilizzo, ove previsto e nell'ambito delle risorse disponibili a legislazione vigente, di forme di consultazione preventiva per via telematica sugli schemi di atto da adottare)).

#### Art. 10.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

#### Art. 11.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Sezione III - Organizzazione delle pubbliche amministrazioni Rapporti fra Stato, Regioni e autonomie locali

#### Art. 12. - Norme generali per l'uso delle tecnologie dell'informazione e delle comunicazioni nell'azione amministrativa

1. Le pubbliche amministrazioni nell'organizzare autonomamente la propria attivita' utilizzano le tecnologie dell'informazione e della comunicazione per la realizzazione degli obiettivi di efficienza, efficacia, economicita', imparzialita', trasparenza, semplificazione e partecipazione nel rispetto dei principi di uguaglianza e di non discriminazione, nonche' per l'effettivo riconoscimento dei diritti dei cittadini e delle imprese di cui al presente Codice in conformita' agli obiettivi indicati nel Piano triennale per l'informatica nella pubblica amministrazione di cui all'articolo 14-bis, comma 2, lettera b).

1-bis. Gli organi di Governo nell'esercizio delle funzioni di indirizzo politico ed in particolare nell'emanazione delle direttive generali per l'attivita' amministrativa e per la gestione ai sensi del comma 1 dell'articolo 14 del decreto legislativo 30 marzo 2001, n. 165, e le amministrazioni pubbliche nella redazione del piano di performance di cui all'articolo 10 del decreto legislativo 27 ottobre 2009, n. 150, dettano disposizioni per l'attuazione delle disposizioni del presente Codice.

1-ter. I dirigenti rispondono dell'osservanza ed attuazione delle disposizioni di cui al presente Codice ai sensi e nei limiti degli articoli 21 e 55 del decreto legislativo 30 marzo 2001, n. 165, ferme restando le eventuali responsabilita' penali, civili e contabili previste dalle norme vigenti. L'attuazione delle disposizioni del presente Codice e' comunque rilevante ai fini della misurazione e valutazione della performance organizzativa ed individuale dei dirigenti.

2. Le pubbliche amministrazioni utilizzano, nei rapporti interni, in quelli con altre amministrazioni e con i privati, le tecnologie dell'informazione e della comunicazione, garantendo l'interoperabilita' dei sistemi e l'integrazione dei processi di servizio fra le diverse amministrazioni nel rispetto delle Linee guida. (28)

3. Le pubbliche amministrazioni operano per assicurare l'uniformita' e la graduale integrazione delle modalita' di interazione degli utenti con i servizi informatici , ivi comprese le reti di telefonia fissa e mobile in tutte le loro articolazioni, da esse erogati, qualunque sia il canale di erogazione, nel rispetto della autonomia e della specificita' di ciascun erogatore di servizi.

3-bis. I soggetti di cui all'articolo 2, comma 2, favoriscono l'uso da parte dei lavoratori di dispositivi elettronici personali o, se di proprieta' dei predetti soggetti, personalizzabili, al fine di ottimizzare la prestazione lavorativa, nel rispetto delle condizioni di sicurezza nell'utilizzo. In caso di uso di dispositivi elettronici personali, i soggetti di cui all'articolo 2, comma 2, nel rispetto della disciplina in materia di trattamento dei dati personali, adottano ogni misura atta a garantire la sicurezza e la protezione delle informazioni e dei dati, tenendo conto delle migliori pratiche e degli standard nazionali, europei e internazionali per la protezione delle proprie reti, nonche' ((a condizione che sia data al lavoratore adeguata informazione)) sull'uso sicuro dei dispositivi, anche attraverso la diffusione di apposite linee guida, e disciplinando, tra l'altro l'uso di webcam e microfoni ((, previa informazione alle organizzazioni sindacali)).

3-ter. Al fine di agevolare la diffusione del lavoro agile quale modalita' di esecuzione del rapporto di lavoro subordinato, i soggetti di cui all'articolo 2, comma 2, lettera a), acquistano beni e progettano e sviluppano i sistemi informativi e i servizi informatici con modalita' idonee a consentire ai lavoratori di accedere da remoto ad applicativi, dati e informazioni necessari allo svolgimento della prestazione lavorativa, nel rispetto della legge 20 maggio 1970, n. 300, del decreto legislativo 9 aprile 2008, n. 81 e della legge 22 maggio 2017, n. 81, assicurando un adeguato livello di sicurezza informatica, in linea con le migliori pratiche e gli standard nazionali ed internazionali per la protezione delle proprie reti, nonche' ((a condizione che sia data al lavoratore adeguata informazione)) sull'uso sicuro degli strumenti impiegati, con particolare riguardo a quelli erogati tramite fornitori di servizi in cloud, anche attraverso la diffusione di apposite linee guida, e disciplinando anche la tipologia di attivita' che possono essere svolte ((, previa informazione alle organizzazioni sindacali)).

4. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

5. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

5-bis. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

--------------- AGGIORNAMENTO (28) Il D.Lgs. 26 agosto 2016, n. 179 ha disposto (con l'art. 11, comma 2) che "Le disposizioni di cui al comma 1, lettera b), si applicano con riferimento ai nuovi sistemi informativi delle pubbliche amministrazioni".

#### Art. 13. - Formazione informatica dei dipendenti pubblici

1. Le pubbliche amministrazioni ((, nell'ambito delle risorse finanziarie disponibili, attuano politiche di reclutamento e)) formazione del personale finalizzate alla conoscenza e all'uso delle tecnologie dell'informazione e della comunicazione, nonche' dei temi relativi all'accessibilita' e alle tecnologie assistive, ai sensi dell'articolo 8 della legge 9 gennaio 2004, n. 4.

1-bis. Le politiche di formazione di cui al comma 1 sono altresi' volte allo sviluppo delle competenze tecnologiche, di informatica giuridica e manageriali dei dirigenti, per la transizione alla modalita' operativa digitale.

#### Art. 13-bis. - (Codice di condotta tecnologica ed esperti)

1. Al fine di favorire la digitalizzazione della pubblica amministrazione e garantire il necessario coordinamento sul piano tecnico delle varie iniziative di innovazione tecnologica, i soggetti di cui all'articolo 2, comma 2, lettera a), nell'ambito delle risorse disponibili, progettano, realizzano e sviluppano i propri sistemi informatici e servizi digitali, in coerenza con gli obiettivi dell'agenda digitale italiana ed europea e nel rispetto del codice di condotta tecnologica adottato dal Capo dipartimento della struttura della Presidenza del Consiglio dei ministri competente per la trasformazione digitale, ((sentiti l'AgID)) e il nucleo per la sicurezza cibernetica di cui all'articolo 12, comma 6, del decreto legislativo 18 maggio 2018, n. 65 e acquisito il parere della Conferenza unificata di cui all'articolo 8 del decreto legislativo 28 agosto 1997, n. 281, entro sessanta giorni dall'entrata in vigore della presente disposizione.

((2. Il codice di condotta tecnologica disciplina le modalita' di progettazione, sviluppo e implementazione dei progetti, sistemi e servizi digitali delle amministrazioni pubbliche, nel rispetto del principio di non discriminazione, dei diritti e delle liberta' fondamentali delle persone e della disciplina in materia di perimetro nazionale di sicurezza cibernetica))

3. I soggetti di cui all'articolo 2, comma 2, lettera a), che avviano progetti di sviluppo dei servizi digitali sono tenuti a rispettare il codice di condotta tecnologica ((e possono avvalersi)), singolarmente o in forma associata, di uno o piu' esperti in possesso di comprovata esperienza e qualificazione professionale nello sviluppo e nella gestione di processi complessi di trasformazione tecnologica e progetti di trasformazione digitale, nel limite delle risorse progettuali disponibili a legislazione vigente per lo scopo. Il codice di condotta tecnologica indica anche le principali attivita', ivi compresa la formazione del personale, che gli esperti svolgono in collaborazione con il responsabile per la transizione digitale dell'amministrazione pubblica interessata, nonche' il limite massimo di durata dell'incarico, i requisiti di esperienza e qualificazione professionale e il trattamento economico massimo da riconoscere agli esperti. 4.Nella realizzazione ((e nello sviluppo)) dei sistemi informativi, e' sempre assicurata l'integrazione con le piattaforme abilitanti previste dagli articoli 5, 62, 64 e 64-bis, nonche' la possibilita' di accedere da remoto ad applicativi, ((dati e informazioni necessari)) allo svolgimento della prestazione lavorativa in modalita' agile, assicurando un adeguato livello di sicurezza informatica, in linea con le migliori pratiche e gli standard nazionali ed internazionali per la protezione delle proprie reti, nonche' promuovendo la consapevolezza dei lavoratori sull'uso sicuro dei suddetti sistemi informativi, anche attraverso la diffusione di apposite linee guida, e disciplinando anche la tipologia di attivita' che possono essere svolte. 5. L'AgID verifica il rispetto del codice di condotta tecnologica da parte dei soggetti interessati e puo' diffidare i soggetti a conformare la propria condotta agli obblighi previsti dal codice. La progettazione, la realizzazione e lo sviluppo di servizi digitali e sistemi informatici in violazione del codice di condotta tecnologica costituiscono mancato raggiungimento di uno specifico risultato e di un rilevante obiettivo da parte dei dirigenti responsabili delle strutture competenti e comportano la riduzione, non inferiore al 30 per cento, della retribuzione di risultato e del trattamento accessorio collegato alla performance individuale dei dirigenti competenti, oltre al divieto di attribuire premi o incentivi nell'ambito delle medesime strutture.

#### Art. 14. - Rapporti tra Stato, Regioni e autonomie locali

1. In attuazione del disposto dell'articolo 117, secondo comma, lettera r), della Costituzione, lo Stato disciplina il coordinamento informatico dei dati dell'amministrazione statale, regionale e locale, dettando anche le regole tecniche necessarie per garantire la sicurezza e l'interoperabilita' dei sistemi informatici e dei flussi informativi per la circolazione e lo scambio dei dati e per l'accesso ai servizi erogati in rete dalle amministrazioni medesime.

2. Lo Stato, le regioni e le autonomie locali promuovono le intese e gli accordi e adottano, attraverso la Conferenza unificata, gli indirizzi utili per realizzare gli obiettivi dell'Agenda digitale europea e nazionale e realizzare un processo di digitalizzazione dell'azione amministrativa coordinato e condiviso e per l'individuazione delle Linee guida. ((La Presidenza del Consiglio dei ministri, anche avvalendosi dell'AgID,)) assicura il coordinamento informatico dell'amministrazione statale, regionale e locale, con la finalita' di progettare e monitorare l'evoluzione strategica del sistema informativo della pubblica amministrazione, favorendo l'adozione di infrastrutture e standard che riducano i costi sostenuti dalle amministrazioni e migliorino i servizi erogati ((assicurando un adeguato livello di sicurezza informatica, in linea con le migliori pratiche e gli standard nazionali ed internazionali per la protezione delle proprie reti, nonche' promuovendo la consapevolezza dei lavoratori sull'uso sicuro dei suddetti sistemi informativi, anche attraverso la diffusione di apposite linee guida che disciplinano anche la tipologia di attivita' che possono essere svolte.)).

2-bis. Le regioni promuovono sul territorio azioni tese a realizzare un processo di digitalizzazione dell'azione amministrativa coordinato e condiviso tra le autonomie locali.

2-ter. Le regioni e gli enti locali digitalizzano la loro azione amministrativa e implementano l'utilizzo delle tecnologie dell'informazione e della comunicazione per garantire servizi migliori ai cittadini e alle imprese, secondo le modalita' di cui al comma 2.

3. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

3-bis. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

#### Art. 14-bis. - (Agenzia per l'Italia digitale)

1. L'Agenzia per l'Italia Digitale (AgID) e' preposta alla realizzazione degli obiettivi dell'Agenda Digitale Italiana, in coerenza con gli indirizzi dettati dal Presidente del Consiglio dei ministri o dal Ministro delegato, e con l'Agenda digitale europea. AgID, in particolare, promuove l'innovazione digitale nel Paese e l'utilizzo delle tecnologie digitali nell'organizzazione della pubblica amministrazione e nel rapporto tra questa, i cittadini e le imprese, nel rispetto dei principi di legalita', imparzialita' e trasparenza e secondo criteri di efficienza, economicita' ed efficacia. Essa presta la propria collaborazione alle istituzioni dell'Unione europea e svolge i compiti necessari per l'adempimento degli obblighi internazionali assunti dallo Stato nelle materie di competenza.

2. AgID svolge le funzioni di:

- a) emanazione di Linee guida contenenti regole, standard e guide tecniche, nonche' di indirizzo, vigilanza e controllo sull'attuazione e sul rispetto delle norme di cui al presente Codice, anche attraverso l'adozione di atti amministrativi generali, in materia di agenda digitale, digitalizzazione della pubblica amministrazione, sicurezza informatica, interoperabilita' e cooperazione applicativa tra sistemi informatici pubblici e quelli dell'Unione europea;
- b) programmazione e coordinamento delle attivita' delle amministrazioni per l'uso delle tecnologie dell'informazione e della comunicazione, mediante la redazione e la successiva verifica dell'attuazione del Piano triennale per l'informatica nella pubblica amministrazione contenente la fissazione degli obiettivi e l'individuazione dei principali interventi di sviluppo e gestione dei sistemi informativi delle amministrazioni pubbliche. Il predetto Piano e' elaborato dall'AgID, anche sulla base dei dati e delle informazioni acquisiti dai soggetti di cui all'articolo 2, comma 2, ed e' approvato dal Presidente del Consiglio dei ministri o dal Ministro delegato entro il 30 settembre di ogni anno;
- c) monitoraggio delle attivita' svolte dalle amministrazioni, ivi inclusi gli investimenti effettuati ai sensi dell'articolo 1, comma 492, lettera a-bis), della legge 11 dicembre 2016, n. 232, in relazione alla loro coerenza con il Piano triennale di cui alla lettera b) e verifica dei risultati conseguiti dalle singole amministrazioni con particolare riferimento ai costi e benefici dei sistemi informatici secondo le modalita' fissate dalla stessa Agenzia;
- d) predisposizione, realizzazione e gestione di interventi e progetti di innovazione, anche realizzando e gestendo direttamente o avvalendosi di soggetti terzi, specifici progetti in tema di innovazione ad essa assegnati nonche' svolgendo attivita' di progettazione e coordinamento delle iniziative strategiche e di preminente interesse nazionale, anche a carattere intersettoriale;
- e) promozione della cultura digitale e della ricerca anche tramite comunita' digitali regionali;
- f) rilascio di pareri tecnici, obbligatori e non vincolanti, sugli schemi di contratti e accordi quadro da parte delle pubbliche amministrazioni centrali concernenti l'acquisizione di beni e servizi relativi a sistemi informativi automatizzati per quanto riguarda la congruita' tecnico-economica, qualora il valore lordo di detti contratti sia superiore a euro 1.000.000,00 nel caso di procedura negoziata e a euro 2.000.000,00 nel caso di procedura ristretta o di procedura aperta. Il parere e' reso tenendo conto dei principi di efficacia, economicita', ottimizzazione della spesa delle pubbliche amministrazioni e favorendo l'adozione di infrastrutture condivise e standard che riducano i costi sostenuti dalle singole amministrazioni e il miglioramento dei servizi erogati, nonche' in coerenza con i principi, i criteri e le indicazioni contenuti nei piani triennali approvati. Il parere e' reso entro il termine di quarantacinque giorni dal ricevimento della relativa richiesta. Si applicano gli articoli 16 e 17-bis della legge 7 agosto 1990, n. 241, e successive modificazioni. Copia dei pareri tecnici attinenti a questioni di competenza dell'Autorita' nazionale anticorruzione e' trasmessa dall'AgID a detta Autorita';
- g) rilascio di pareri tecnici, obbligatori e vincolanti, sugli elementi essenziali delle procedure di gara bandite, ai sensi dell'articolo 1, comma 512 della legge 28 dicembre 2015, n. 208, da Consip e dai soggetti aggregatori di cui all'articolo 9 del decreto-legge 24 aprile 2014, n. 66, concernenti l'acquisizione di beni e servizi relativi a sistemi informativi automatizzati e definiti di carattere strategico nel piano triennale. Il parere e' reso entro il termine di quarantacinque giorni dal ricevimento della relativa richiesta e si applica l'articolo 17-bis della legge 7 agosto 1990, n. 241, e successive modificazioni. Ai fini della presente lettera per elementi essenziali si intendono l'oggetto della fornitura o del servizio, il valore economico del contratto, la tipologia di procedura che si intende adottare, il criterio di aggiudicazione e relativa ponderazione, le principali clausole che caratterizzano le prestazioni contrattuali. Si applica quanto previsto nei periodi da 2 a 5 della lettera f);
- h) definizione di criteri e modalita' per il monitoraggio sull'esecuzione dei contratti da parte dell'amministrazione interessata ((...));
- i) vigilanza sui servizi fiduciari ai sensi dell'articolo 17 del regolamento UE 910/2014 in qualita' di organismo a tal fine designato, sui gestori di posta elettronica certificata, sui (( soggetti di cui all'articolo 34, comma 1-bis, lettera b) )), nonche' sui soggetti, pubblici e privati, che partecipano a SPID di cui all'articolo 64; nell'esercizio di tale funzione l'Agenzia puo' irrogare per le violazioni accertate a carico dei soggetti vigilati le sanzioni amministrative di cui all'articolo 32-bis in relazione alla gravita' della violazione accertata e all'entita' del danno provocato all'utenza;
- l) ogni altra funzione attribuitale da specifiche disposizioni di legge e dallo Statuto.

3. Fermo restando quanto previsto al comma 2, AgID svolge ogni altra funzione prevista da leggi e regolamenti gia' attribuita a DigitPA, all'Agenzia per la diffusione delle tecnologie per l'innovazione ((...)).

#### Art. 15. - Digitalizzazione e riorganizzazione

1. La riorganizzazione strutturale e gestionale delle pubbliche amministrazioni volta al perseguimento degli obiettivi di cui all'articolo 12, comma 1, avviene anche attraverso il migliore e piu' esteso utilizzo delle tecnologie dell'informazione e della comunicazione nell'ambito di una coordinata strategia che garantisca il coerente sviluppo del processo di digitalizzazione.

2. In attuazione del comma 1, le pubbliche amministrazioni provvedono in particolare a razionalizzare e semplificare i procedimenti amministrativi, le attivita' gestionali, i documenti, la modulistica, le modalita' di accesso e di presentazione delle istanze da parte dei cittadini e delle imprese, assicurando che l'utilizzo delle tecnologie dell'informazione e della comunicazione avvenga in conformita' alle prescrizioni tecnologiche definite nelle ((Linee guida)).

2-bis. Le pubbliche amministrazioni nella valutazione dei progetti di investimento in materia di innovazione tecnologica tengono conto degli effettivi risparmi derivanti dalla razionalizzazione di cui al comma 2, nonche' dei costi e delle economie che ne derivano.

2-ter. Le pubbliche amministrazioni, quantificano annualmente, ai sensi dell'articolo 27, del decreto legislativo 27 ottobre 2009, n.150, i risparmi effettivamente conseguiti in attuazione delle disposizioni di cui ai commi 1 e 2. Tali risparmi sono utilizzati, per due terzi secondo quanto previsto dall'articolo 27, comma 1, del citato decreto legislativo n. 150 del 2009 e in misura pari ad un terzo per il finanziamento di ulteriori progetti di innovazione.

((

2-quater. AgID individua, nell'ambito delle Linee guida, criteri e modalita' di attuazione dei commi 2-bis e 2-ter, prevedendo che ogni pubblica amministrazione dia conto annualmente delle attivita' previste dai predetti commi nella relazione sulla gestione di cui all'articolo 11, comma 6, del decreto legislativo 23 giugno 2011, n. 118.

))

3. La digitalizzazione dell'azione amministrativa e' attuata dalle pubbliche amministrazioni con modalita' idonee a garantire la partecipazione dell'Italia alla costruzione di reti transeuropee per lo scambio elettronico di dati e servizi fra le amministrazioni dei Paesi membri dell'Unione europea.

3-bis. COMMA ABROGATO DAL D.L. 6 LUGLIO 2012, N. 95, CONVERTITO CON MODIFICAZIONI DALLA L. 7 AGOSTO 2012, N. 135.

3-ter. COMMA ABROGATO DAL D.L. 6 LUGLIO 2012, N. 95, CONVERTITO CON MODIFICAZIONI DALLA L. 7 AGOSTO 2012, N. 135.

3-quater. COMMA ABROGATO DAL D.L. 6 LUGLIO 2012, N. 95, CONVERTITO CON MODIFICAZIONI DALLA L. 7 AGOSTO 2012, N. 135.

3-quinquies. COMMA ABROGATO DAL D.L. 6 LUGLIO 2012, N. 95, CONVERTITO CON MODIFICAZIONI DALLA L. 7 AGOSTO 2012, N. 135.

3-sexies. COMMA ABROGATO DAL D.L. 6 LUGLIO 2012, N. 95, CONVERTITO CON MODIFICAZIONI DALLA L. 7 AGOSTO 2012, N. 135.

3-septies. COMMA ABROGATO DAL D.L. 6 LUGLIO 2012, N. 95, CONVERTITO CON MODIFICAZIONI DALLA L. 7 AGOSTO 2012, N. 135.

3-octies. COMMA ABROGATO DAL D.L. 6 LUGLIO 2012, N. 95, CONVERTITO CON MODIFICAZIONI DALLA L. 7 AGOSTO 2012, N. 135.

#### Art. 16. - Competenze del Presidente del Consiglio dei Ministri in materia di innovazione e tecnologie

1. Per il perseguimento dei fini di cui al presente codice, il Presidente del Consiglio dei Ministri o il Ministro delegato per l'innovazione e le tecnologie, nell'attivita' di coordinamento del processo di digitalizzazione e di coordinamento e di valutazione dei programmi, dei progetti e dei piani di azione formulati dalle pubbliche amministrazioni centrali per lo sviluppo dei sistemi informativi:

- a) definisce con proprie direttive le linee strategiche, la pianificazione e le aree di intervento dell'innovazione tecnologica nelle pubbliche amministrazioni centrali, e ne verifica l'attuazione;
- b) ((approva il piano triennale di cui all'articolo 14-bis, comma 2, lettera b), e)) valuta, sulla base di criteri e metodiche di ottimizzazione della spesa, il corretto utilizzo delle risorse finanziarie per l'informatica e la telematica da parte delle singole amministrazioni centrali;
- c) ((promuove e)) sostiene progetti di grande contenuto innovativo, di rilevanza strategica, di preminente interesse nazionale, con particolare attenzione per i progetti di carattere intersettoriale;
- d) promuove l'informazione circa le iniziative per la diffusione delle nuove tecnologie;
- e) ((stabilisce i)) criteri in tema di pianificazione, progettazione, realizzazione, gestione, mantenimento dei sistemi informativi automatizzati delle pubbliche amministrazioni centrali e delle loro interconnessioni, nonche' della loro qualita' e relativi aspetti organizzativi e della loro sicurezza.

2. Il Presidente del Consiglio dei Ministri o il Ministro delegato per l'innovazione e le tecnologie riferisce annualmente al Parlamento sullo stato di attuazione del presente codice.

#### Art. 17. - Responsabile per la transizione digitale e difensore civico digitale

1. Le pubbliche amministrazioni garantiscono l'attuazione delle linee strategiche per la riorganizzazione e la digitalizzazione dell'amministrazione definite dal Governo in coerenza con le Linee guida. A tal fine, ciascuna pubblica amministrazione affida a un unico ufficio dirigenziale generale, fermo restando il numero complessivo di tali uffici, la transizione alla modalita' operativa digitale e i conseguenti processi di riorganizzazione finalizzati alla realizzazione di un'amministrazione digitale e aperta, di servizi facilmente utilizzabili e di qualita', attraverso una maggiore efficienza ed economicita'. Al suddetto ufficio sono inoltre attribuiti i compiti relativi a:

- a) coordinamento strategico dello sviluppo dei sistemi informativi, di telecomunicazione e fonia, in modo da assicurare anche la coerenza con gli standard tecnici e organizzativi comuni;
- b) indirizzo e coordinamento dello sviluppo dei servizi, sia interni che esterni, forniti dai sistemi informativi di telecomunicazione e fonia dell'amministrazione;
- c) indirizzo, pianificazione, coordinamento e monitoraggio della sicurezza informatica relativamente ai dati, ai sistemi e alle infrastrutture anche in relazione al sistema pubblico di connettivita', nel rispetto delle regole tecniche di cui all'articolo 51, comma 1;
- d) accesso dei soggetti disabili agli strumenti informatici e promozione dell'accessibilita' anche in attuazione di quanto previsto dalla legge 9 gennaio 2004, n. 4;
- e) analisi periodica della coerenza tra l'organizzazione dell'amministrazione e l'utilizzo delle tecnologie dell'informazione e della comunicazione, al fine di migliorare la soddisfazione dell'utenza e la qualita' dei servizi nonche' di ridurre i tempi e i costi dell'azione amministrativa;
- f) cooperazione alla revisione della riorganizzazione dell'amministrazione ai fini di cui alla lettera e);
- g) indirizzo, coordinamento e monitoraggio della pianificazione prevista per lo sviluppo e la gestione dei sistemi informativi di telecomunicazione e fonia;
- h) progettazione e coordinamento delle iniziative rilevanti ai fini di una piu' efficace erogazione di servizi in rete a cittadini e imprese mediante gli strumenti della cooperazione applicativa tra pubbliche amministrazioni, ivi inclusa la predisposizione e l'attuazione di accordi di servizio tra amministrazioni per la realizzazione e compartecipazione dei sistemi informativi cooperativi;(28)
- i) promozione delle iniziative attinenti l'attuazione delle direttive impartite dal Presidente del Consiglio dei Ministri o dal Ministro delegato per l'innovazione e le tecnologie;
- j) pianificazione e coordinamento del processo di diffusione, all'interno dell'amministrazione, dei sistemi di identita' e domicilio digitale, posta elettronica, protocollo informatico, firma digitale o firma elettronica qualificata e mandato informatico, e delle norme in materia di accessibilita' e fruibilita' nonche' del processo di integrazione e interoperabilita' tra i sistemi e servizi dell'amministrazione e quello di cui all'articolo 64-bis.
- j-bis) pianificazione e coordinamento degli acquisti di soluzioni e sistemi informatici, telematici e di telecomunicazione al fine di garantirne la compatibilita' con gli obiettivi di attuazione dell'agenda digitale e, in particolare, con quelli stabiliti nel piano triennale di cui all'articolo 16, comma 1, lettera b).

1-bis. Per lo svolgimento dei compiti di cui al comma 1, le Agenzie, le Forze armate, compresa l'Arma dei carabinieri e il Corpo delle capitanerie di porto, nonche' i Corpi di polizia hanno facolta' di individuare propri uffici senza incrementare il numero complessivo di quelli gia' previsti nei rispettivi assetti organizzativi.

1-ter. Il responsabile dell'ufficio di cui al comma 1 e' dotato di adeguate competenze tecnologiche, di informatica giuridica e manageriali e risponde, con riferimento ai compiti relativi alla transizione, alla modalita' digitale direttamente all'organo di vertice politico.

1-quater. E' istituito presso l'AgID l'ufficio del difensore civico per il digitale, a cui e' preposto un soggetto in possesso di adeguati requisiti di terzieta', autonomia e imparzialita'. Chiunque puo' presentare al difensore civico per il digitale, attraverso apposita area presente sul sito istituzionale dell'AgID, segnalazioni relative a presunte violazioni del presente Codice e di ogni altra norma in materia di digitalizzazione ed innovazione della pubblica amministrazione da parte dei soggetti di cui all'articolo 2, comma 2. Il difensore civico, accertata la non manifesta infondatezza della segnalazione, la trasmette al Direttore generale dell'AgID per l'esercizio dei poteri di cui all'articolo 18-bis. PERIODO SOPPRESSO DAL D.L. 31 MAGGIO 2021, N. 77. PERIODO SOPPRESSO DAL D.L. 31 MAGGIO 2021, N. 77. PERIODO SOPPRESSO DAL D.L. 31 MAGGIO 2021, N. 77.

1-quinquies. AgID pubblica sul proprio sito una guida di riepilogo dei diritti di cittadinanza digitali previsti dal presente Codice.

1-sexies. Nel rispetto della propria autonomia organizzativa, le pubbliche amministrazioni diverse dalle amministrazioni dello Stato individuano l'ufficio per il digitale di cui al comma 1 tra quelli di livello dirigenziale oppure, ove ne siano privi, individuano un responsabile per il digitale tra le proprie posizioni apicali. In assenza del vertice politico, il responsabile dell'ufficio per il digitale di cui al comma 1 risponde direttamente a quello amministrativo dell'ente.

1-septies. I soggetti di cui al comma 1-sexies possono esercitare le funzioni di cui al medesimo comma anche in forma associata. ((E' fatta salva la facolta' di avvalersi, mediante apposite convenzioni e senza nuovi o maggiori oneri a carico della finanza pubblica, del supporto di societa' in house.))

------------- AGGIORNAMENTO (28) Il D.Lgs. 26 agosto 2016, n. 179 ha disposto (con l'art. 61, comma 2, lettera d)) che l'espressione «cittadini e imprese», ovunque ricorra, si intende come «soggetti giuridici».

#### Art. 18. - (( (Piattaforma nazionale per la governance della trasformazione digitale). ))

((

1. E' realizzata presso l'AgID una piattaforma per la consultazione pubblica e il confronto tra i portatori di interesse in relazione ai provvedimenti connessi all'attuazione dell'agenda digitale.

2. AgID identifica le caratteristiche tecnico-funzionali della piattaforma in maniera tale da garantire che la stessa sia accessibile ai portatori di interessi pubblici e privati e che sia idonea a raccogliere suggerimenti e proposte emendative in maniera trasparente, qualificata ed efficace.

3. Il Piano triennale per l'informatica nella pubblica amministrazione di cui all'articolo 14-bis e' pubblicato sulla piattaforma e aggiornato di anno in anno.

4. Tutti i soggetti di cui all'articolo 2, comma 2, lettera a), possono pubblicare sulla piattaforma i provvedimenti che intendono adottare o, qualora si tratti di provvedimenti soggetti a modifiche e aggiornamenti periodici, gia' adottati, aventi ad oggetto l'attuazione dell'agenda digitale.

5. I soggetti di cui all'articolo 2, comma 2, lettera a), tengono conto di suggerimenti e proposte emendative raccolte attraverso la piattaforma.

))

#### Art. 18-bis. - (Violazione degli obblighi di transizione digitale)

1. L'AgID esercita poteri di vigilanza, verifica, controllo e monitoraggio sul rispetto delle disposizioni del presente Codice e di ogni altra norma in materia di innovazione tecnologica e digitalizzazione della pubblica amministrazione, ivi comprese quelle contenute nelle Linee guida e nel Piano triennale per l'informatica nella pubblica amministrazione, e procede, d'ufficio ovvero su segnalazione del difensore civico digitale, all'accertamento delle relative violazioni da parte dei soggetti di cui all'articolo 2, comma 2. Nell'esercizio dei poteri di vigilanza, verifica, controllo e monitoraggio, l'AgID richiede e acquisisce presso i soggetti di cui all'articolo 2, comma 2, dati, documenti e ogni altra informazione strumentale e necessaria. La mancata ottemperanza alla richiesta di dati, documenti o informazioni di cui al secondo periodo ovvero la trasmissione di informazioni o dati parziali o non veritieri e' punita ai sensi del comma 5, con applicazione della sanzione ivi prevista ridotta della meta'.

2. L'AgID, quando dagli elementi acquisiti risulta che sono state commesse una o piu' violazioni delle disposizioni di cui al comma 1, procede alla contestazione nei confronti del trasgressore, assegnandogli un termine perentorio per inviare scritti difensivi e documentazione e per chiedere di essere sentito.

3. L'AgID, ove accerti la sussistenza delle violazioni contestate, assegna al trasgressore un congruo termine perentorio, proporzionato rispetto al tipo e alla gravita' della violazione, per conformare la condotta agli obblighi previsti dalla normativa vigente, segnalando le violazioni all'ufficio competente per i procedimenti disciplinari di ciascuna amministrazione, nonche' ai competenti organismi indipendenti di valutazione. L'AgID pubblica le predette segnalazioni su apposita area del proprio sito internet istituzionale.

4. Le violazioni accertate dall'AgID rilevano ai fini della misurazione e della valutazione della performance individuale dei dirigenti responsabili e comportano responsabilita' dirigenziale e disciplinare ai sensi degli articoli 21 e 55 del decreto legislativo 30 marzo 2001, n. 165. Resta fermo quanto previsto dagli articoli 13-bis, 50, 50-ter, 64-bis, comma 1-quinquies, del presente Codice e dall'articolo 33-septies del decreto-legge 18 ottobre 2012, n. 179, convertito, con modificazioni, dalla legge 17 dicembre 2012, n. 221.

5. In caso di mancata ottemperanza alla richiesta di dati, documenti o informazioni di cui al comma 1, ultimo periodo, ovvero di trasmissione di informazioni o dati parziali o non veritieri, nonche' di violazione degli obblighi previsti dagli articoli 5, 7, comma 3, 41, commi 2 e 2-bis, 43, comma 1-bis, 50, comma 3-ter, 50-ter, comma 5, 64, comma 3­bis, 64-bis del presente Codice, dall'articolo 65, comma 1, del decreto legislativo 13 dicembre 2017, n. 217 e dall'articolo 33-septies, comma 4, del decreto-legge 18 ottobre 2012, n. 179, convertito, con modificazioni, dalla legge 17 dicembre 2012, n. 221, ove il soggetto di cui all'articolo 2, comma 2, non ottemperi all'obbligo di conformare la condotta nel termine di cui al comma 3, l'AgID irroga la sanzione amministrativa pecuniaria nel minimo di euro 10.000 e nel massimo di euro 100.000. Si applica, per quanto non espressamente previsto dal presente articolo, la disciplina della legge 24 novembre 1981, n. 689. I proventi delle sanzioni sono versati in apposito capitolo di entrata del bilancio dello Stato per essere riassegnati allo stato di previsione della spesa del Ministero dell'economia e delle finanze a favore per il 50 per cento dell'AgID e per la restante parte al Fondo di cui all'articolo 239 del decreto-legge 19 maggio 2020, n. 34, convertito, con modificazioni, dalla legge 17 luglio 2020, n. 77.

6. Contestualmente all'irrogazione della sanzione nei casi di violazione delle norme specificamente indicate al comma 5, nonche' di violazione degli obblighi di cui all'articolo 13-bis, comma 4, l'AgID segnala la violazione alla struttura della Presidenza del Consiglio dei ministri competente per l'innovazione tecnologica e la transizione digitale che, ricevuta la segnalazione, diffida ulteriormente il soggetto responsabile a conformare la propria condotta agli obblighi previsti dalla disciplina vigente entro un congruo termine perentorio, proporzionato al tipo e alla gravita' della violazione, avvisandolo che, in caso di inottemperanza, potranno essere esercitati i poteri sostitutivi del Presidente del Consiglio dei ministri o del Ministro delegato. Decorso inutilmente il termine, il Presidente del Consiglio dei ministri o il Ministro delegato per l'innovazione tecnologica e la transizione digitale, valutata la gravita' della violazione, puo' nominare un commissario ad acta incaricato di provvedere in sostituzione. Al commissario non spettano compensi, indennita' o rimborsi. Nel caso di inerzia o ritardi riguardanti amministrazioni locali, si procede all'esercizio del potere sostitutivo di cui agli articoli 117, quinto comma, e 120, secondo comma, della Costituzione, ai sensi dell'articolo 8 della legge 5 giugno 2003, n. 131.

7. L'AgID, con proprio regolamento, disciplina le procedure di contestazione, accertamento, segnalazione e irrogazione delle sanzioni per le violazioni di cui alla presente disposizione.

8. All'attuazione della presente disposizione si provvede con le risorse umane, strumentali e finanziarie gia' previste a legislazione vigente.

((8-bis. Le disposizioni del presente articolo trovano applicazione in tutti i casi in cui l'AgID esercita poteri sanzionatori attribuiti dalla legge))

#### Art. 19.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

## Capo II - ((DOCUMENTO INFORMATICO, FIRME ELETTRONICHE, SERVIZI FIDUCIARI E TRASFERIMENTI DI FONDI))

### Sezione I - Documento informatico

#### Art. 20. - Validita' ed efficacia probatoria dei documenti informatici

1. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

((

1-bis. Il documento informatico soddisfa il requisito della forma scritta e ha l'efficacia prevista dall'articolo 2702 del Codice civile quando vi e' apposta una firma digitale, altro tipo di firma elettronica qualificata o una firma elettronica avanzata o, comunque, e' formato, previa identificazione informatica del suo autore, attraverso un processo avente i requisiti fissati dall'AgID ai sensi dell'articolo 71 con modalita' tali da garantire la sicurezza, integrita' e immodificabilita' del documento e, in maniera manifesta e inequivoca, la sua riconducibilita' all'autore. In tutti gli altri casi, l'idoneita' del documento informatico a soddisfare il requisito della forma scritta e il suo valore probatorio sono liberamente valutabili in giudizio, in relazione alle caratteristiche di sicurezza, integrita' e immodificabilita'. La data e l'ora di formazione del documento informatico sono opponibili ai terzi se apposte in conformita' alle Linee guida.

))

((

1-ter. L'utilizzo del dispositivo di firma elettronica qualificata o digitale si presume riconducibile al titolare di firma elettronica, salvo che questi dia prova contraria.

1-quater. Restano ferme le disposizioni concernenti il deposito degli atti e dei documenti in via telematica secondo la normativa, anche regolamentare, in materia di processo telematico.

))

2. COMMA ABROGATO DAL D.LGS. 30 DICEMBRE 2010, N. 235.

3. Le regole tecniche per la formazione, per la trasmissione, la conservazione, la copia, la duplicazione, la riproduzione e la validazione dei documenti informatici, nonche' quelle in materia di generazione, apposizione e verifica di qualsiasi tipo di firma elettronica, sono stabilite ((con le Linee guida)). ((PERIODO SOPPRESSO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

4. Con le medesime regole tecniche sono definite le misure tecniche, organizzative e gestionali volte a garantire l'integrita', la disponibilita' e la riservatezza delle informazioni contenute nel documento informatico.

5. Restano ferme le disposizioni di legge in materia di protezione dei dati personali.

5-bis. Gli obblighi di conservazione e di esibizione di documenti previsti dalla legislazione vigente si intendono soddisfatti a tutti gli effetti di legge a mezzo di documenti informatici, se le procedure utilizzate sono conformi alle ((Linee guida)).

#### Art. 21. - ((Ulteriori disposizioni relative ai documenti informatici, sottoscritti con firma elettronica avanzata, qualificata o digitale))

1. ((COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

2. ((COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)). 2-bis). Salvo il caso di sottoscrizione autenticata, le scritture private di cui all'articolo 1350, primo comma, numeri da 1 a 12, del codice civile, se fatte con documento informatico, sono sottoscritte, a pena di nullita', con firma elettronica qualificata o con firma digitale. Gli atti di cui all'articolo 1350, numero 13), del codice civile redatti su documento informatico o formati attraverso procedimenti informatici sono sottoscritti, a pena di nullita', con firma elettronica avanzata, qualificata o digitale ((ovvero sono formati con le ulteriori modalita' di cui all'articolo 20, comma 1-bis, primo periodo)). 2-ter. Fatto salvo quanto previsto dal decreto legislativo 2 luglio 2010, n. 110, ogni altro atto pubblico redatto su documento informatico e' sottoscritto dal pubblico ufficiale a pena di nullita' con firma qualificata o digitale. Le parti, i fidefacenti, l'interprete e i testimoni sottoscrivono personalmente l'atto, in presenza del pubblico ufficiale, con firma avanzata, qualificata o digitale ovvero con firma autografa acquisita digitalmente e allegata agli atti.

3. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

4. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

5. Gli obblighi fiscali relativi ai documenti informatici ed alla loro riproduzione su diversi tipi di supporto sono assolti secondo le modalita' definite con uno o piu' decreti del Ministro dell'economia e delle finanze, sentito il Ministro delegato per l'innovazione e le tecnologie.

#### Art. 22. - (Copie informatiche di documenti analogici).

1. I documenti informatici contenenti copia di atti pubblici, scritture private e documenti in genere, compresi gli atti e documenti amministrativi di ogni tipo formati in origine su supporto analogico, spediti o rilasciati dai depositari pubblici autorizzati e dai pubblici ufficiali, hanno piena efficacia, ai sensi degli articoli 2714 e 2715 del codice civile, se sono formati ai sensi dell'articolo 20, comma 1-bis, primo periodo. La loro esibizione e produzione sostituisce quella dell'originale.

1-bis. La copia per immagine su supporto informatico di un documento analogico e' prodotta mediante processi e strumenti che assicurano che il documento informatico abbia contenuto e forma identici a quelli del documento analogico da cui e' tratto, previo raffronto dei documenti o attraverso certificazione di processo nei casi in cui siano adottate tecniche in grado di garantire la corrispondenza della forma e del contenuto dell'originale e della copia.

2. Le copie per immagine su supporto informatico di documenti originali formati in origine su supporto analogico hanno la stessa efficacia probatoria degli originali da cui sono estratte, se la loro conformita' e' attestata da un notaio o da altro pubblico ufficiale a cio' autorizzato, secondo le Linee guida.

3. Le copie per immagine su supporto informatico di documenti originali formati in origine su supporto analogico nel rispetto delle Linee guida hanno la stessa efficacia probatoria degli originali da cui sono tratte se la loro conformita' all'originale non e' espressamente disconosciuta.

4. Le copie formate ai sensi dei commi 1, 1-bis, 2 e 3 sostituiscono ad ogni effetto di legge gli originali formati in origine su supporto analogico, e sono idonee ad assolvere gli obblighi di conservazione previsti dalla legge, salvo quanto stabilito dal comma 5.

4-bis. Le copie per immagine su supporto informatico di atti e documenti originali formati in origine su supporto analogico, depositati in procedimenti giudiziari civili definiti con provvedimento decisorio non piu' soggetto a impugnazione da almeno un anno, sono idonee ad ((assolvere agli obblighi)) di conservazione previsti dalla legge se il cancelliere vi appone la firma digitale, ne attesta la conformita' all'originale e le inserisce nel fascicolo informatico nel rispetto della normativa anche regolamentare concernente il processo civile telematico. In tali casi, si puo' procedere alla distruzione degli originali analogici, secondo le modalita' previste con decreto del Ministro della giustizia, sentiti il Garante per la protezione dei dati personali e l'Agenzia per l'Italia digitale.

5. Salvo quanto previsto dal comma 4-bis, con decreto del Presidente del Consiglio dei ministri possono essere individuate particolari tipologie di documenti analogici originali unici per le quali, in ragione di esigenze di natura pubblicistica, permane l'obbligo della conservazione dell'originale analogico oppure, in caso di conservazione sostitutiva, la loro conformita' all'originale deve essere autenticata da un notaio o da altro pubblico ufficiale a cio' autorizzato con dichiarazione da questi firmata digitalmente ed allegata al documento informatico.

6. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

#### Art. 23. - (Copie analogiche di documenti informatici).

1. Le copie su supporto analogico di documento informatico, anche sottoscritto con firma elettronica avanzata, qualificata o digitale, hanno la stessa efficacia probatoria dell'originale da cui sono tratte se la loro conformita' all'originale in tutte le sue componenti e' attestata da un pubblico ufficiale a cio' autorizzato.

2. Le copie e gli estratti su supporto analogico del documento informatico, conformi alle vigenti regole tecniche, hanno la stessa efficacia probatoria dell'originale se la loto conformita' non e' espressamente disconosciuta. Resta fermo, ove previsto l'obbligo di conservazione dell'originale informatico.

2-bis. Sulle copie analogiche di documenti informatici puo' essere apposto a stampa un contrassegno, sulla base dei criteri definiti con le ((Linee guida)), tramite il quale e' possibile accedere al documento informatico, ovvero verificare la corrispondenza allo stesso della copia analogica. Il contrassegno apposto ai sensi del primo periodo sostituisce a tutti gli effetti di legge la sottoscrizione autografa del pubblico ufficiale e non puo' essere richiesta la produzione di altra copia analogica con sottoscrizione autografa del medesimo documento informatico. ((I soggetti che procedono all'apposizione del contrassegno rendono disponibili gratuitamente sul proprio sito Internet istituzionale idonee soluzioni per la verifica del contrassegno medesimo.)).

#### Art. 23-bis. - (Duplicati e copie informatiche di documenti informatici).

1. I duplicati informatici hanno il medesimo valore giuridico, ad ogni effetto di legge, del documento informatico da cui sono tratti, se prodotti in conformita' alle ((Linee guida)).

2. Le copie e gli estratti informatici del documento informatico, se prodotti in conformita' alle vigenti ((Linee guida)), hanno la stessa efficacia probatoria dell'originale da cui sono tratte se la loro conformita' all'originale, in tutti le sue componenti, e' attestata da un pubblico ufficiale a cio' autorizzato o se la conformita' non e' espressamente disconosciuta. Resta fermo, ove previsto, l'obbligo di conservazione dell'originale informatico.

#### Art. 23-ter. - (Documenti amministrativi informatici).

1. Gli atti formati dalle pubbliche amministrazioni con strumenti informatici, nonche' i dati e i documenti informatici detenuti dalle stesse, costituiscono informazione primaria ed originale da cui e' possibile effettuare, su diversi o identici tipi di supporto, duplicazioni e copie per gli usi consentiti dalla legge.

((

1-bis. La copia su supporto informatico di documenti formati dalle pubbliche amministrazioni in origine su supporto analogico e' prodotta mediante processi e strumenti che assicurano che il documento informatico abbia contenuto identico a quello del documento analogico da cui e' tratto, previo raffronto dei documenti o attraverso certificazione di processo nei casi in cui siano adottate tecniche in grado di garantire la corrispondenza del contenuto dell'originale e della copia.

))

2. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

3. Le copie su supporto informatico di documenti formati dalla pubblica amministrazione in origine su supporto analogico ovvero da essa detenuti, hanno il medesimo valore giuridico, ad ogni effetto di legge, degli originali da cui sono tratte, se la loro conformita' all'originale e' assicurata dal funzionario a cio' delegato nell'ambito dell'ordinamento proprio dell'amministrazione di appartenenza, mediante l'utilizzo della firma digitale o di altra firma elettronica qualificata e nel rispetto delle ((Linee guida)); in tale caso l'obbligo di conservazione dell'originale del documento e' soddisfatto con la conservazione della copia su supporto informatico.

((

4. In materia di formazione e conservazione di documenti informatici delle pubbliche amministrazioni, le Linee guida sono definite anche sentito il Ministero dei beni e delle attivita' culturali e del turismo.

))

5. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

5-bis. I documenti di cui al presente articolo devono essere fruibili indipendentemente dalla condizione di disabilita' personale, applicando i criteri di accessibilita' definiti dai requisiti tecnici di cui all'articolo 11 della legge 9 gennaio 2004, n. 4.

6. Per quanto non previsto dal presente articolo si applicano gli articoli 21, 22 , 23 e 23-bis.

#### Art. 23-quater. - (( (Riproduzioni informatiche). ))

((

1. All'articolo 2712 del codice civile dopo le parole: "riproduzioni fotografiche" e' inserita la seguente: ", informatiche".

))

### Sezione II - ((Firme elettroniche, certificati e prestatori di servizi fiduciari))

#### Art. 24. - Firma digitale

1. La firma digitale deve riferirsi in maniera univoca ad un solo soggetto ed al documento o all'insieme di documenti cui e' apposta o associata.

2. L'apposizione di firma digitale integra e sostituisce l'apposizione di sigilli, punzoni, timbri, contrassegni e marchi di qualsiasi genere ad ogni fine previsto dalla normativa vigente.

3. Per la generazione della firma digitale deve adoperarsi un certificato qualificato che, al momento della sottoscrizione, non risulti scaduto di validita' ovvero non risulti revocato o sospeso.

4. Attraverso il certificato qualificato si devono rilevare, secondo le ((Linee guida)), la validita' del certificato stesso, nonche' gli elementi identificativi del titolare ((di firma digitale)) e del certificatore e gli eventuali limiti d'uso. ((Le linee guida definiscono altresi' le modalita', anche temporali, di apposizione della firma.))

4-bis. L'apposizione a un documento informatico di una firma digitale o di un altro tipo di firma elettronica qualificata basata su un certificato elettronico revocato, scaduto o sospeso equivale a mancata sottoscrizione, salvo che lo stato di sospensione sia stato annullato. La revoca o la sospensione, comunque motivate, hanno effetto dal momento della pubblicazione, salvo che il revocante, o chi richiede la sospensione, non dimostri che essa era gia' a conoscenza di tutte le parti interessate.

4-ter. Le disposizioni del presente articolo si applicano anche se la firma elettronica e' basata su un certificato qualificato rilasciato da un certificatore stabilito in uno Stato non facente parte dell'Unione europea, quando ricorre una delle seguenti condizioni:

- a) il certificatore possiede i requisiti previsti dal regolamento eIDAS ed e' qualificato in uno Stato membro;
- b) il certificato qualificato e' garantito da un certificatore stabilito nella Unione europea, in possesso dei requisiti di cui al medesimo regolamento;
- c) il certificato qualificato, o il certificatore, e' riconosciuto in forza di un accordo bilaterale o multilaterale tra l'Unione europea e Paesi terzi o organizzazioni internazionali.

#### Art. 25. - (Firma autenticata)

1. Si ha per riconosciuta, ai sensi dell'articolo 2703 del codice civile, la firma elettronica o qualsiasi altro tipo di firma ((elettronica))avanzata autenticata dal notaio o da altro pubblico ufficiale a cio' autorizzato.

2. L'autenticazione della firma elettronica, anche mediante l'acquisizione digitale della sottoscrizione autografa, o di qualsiasi altro tipo di firma elettronica avanzata consiste nell'attestazione, da parte del pubblico ufficiale, che la firma e' stata apposta in sua presenza dal titolare, previo accertamento della sua identita' personale, della validita' dell'eventuale certificato elettronico utilizzato e del fatto che il documento sottoscritto non e' in contrasto con l'ordinamento giuridico.

3. L'apposizione della firma digitale da parte del pubblico ufficiale ha l'efficacia di cui all'articolo 24, comma 2.

4. Se al documento informatico autenticato deve essere allegato altro documento formato in originale su altro tipo di supporto, il pubblico ufficiale puo' allegare copia informatica autenticata dell'originale, secondo le disposizioni dell'articolo 23((...)).

#### Art. 26.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

#### Art. 27.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

#### Art. 28.

Certificati di firma elettronica qualificata

1. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

2. In aggiunta alle informazioni previste nel Regolamento eIDAS ((...)) nel certificato di firma elettronica qualificata puo' essere inserito il codice fiscale. Per i titolari residenti all'estero cui non risulti attribuito il codice fiscale, si puo' indicare il codice fiscale rilasciato dall'autorita' fiscale del Paese di residenza o, in mancanza, un analogo codice identificativo univoco ((...)).

3. Il certificato di firma elettronica qualificata puo' contenere, ove richiesto dal titolare ((di firma elettronica)) o dal terzo interessato, le seguenti informazioni, se pertinenti e non eccedenti rispetto allo scopo per il quale il certificato e' richiesto:

- a) le qualifiche specifiche del titolare ((di firma elettronica)), quali l'appartenenza ad ordini o collegi professionali, la qualifica di pubblico ufficiale, l'iscrizione ad albi o il possesso di altre abilitazioni professionali, nonche' poteri di rappresentanza;
- b) i limiti d'uso del certificato, inclusi quelli derivanti dalla titolarita' delle qualifiche e dai poteri di rappresentanza di cui alla lettera a) ai sensi dell'articolo 30, comma 3.
- c) limiti del valore degli atti unilaterali e dei contratti per i quali il certificato puo' essere usato, ove applicabili.
- c-bis) uno pseudonimo, qualificato come tale.

3-bis. ((Le informazioni di cui al comma 3 sono riconoscibili da parte dei terzi e chiaramente evidenziati nel certificato.)) Le informazioni di cui al comma 3 possono ((anche)) essere contenute in un separato certificato elettronico e possono essere rese disponibili anche in rete. ((Con le Linee guida)) sono definite le modalita' di attuazione del presente comma, anche in riferimento alle pubbliche amministrazioni e agli ordini professionali.

4. Il titolare ((di firma elettronica)), ovvero il terzo interessato se richiedente ai sensi del comma 3, comunicano tempestivamente al certificatore il modificarsi o venir meno delle circostanze oggetto delle informazioni di cui al presente articolo.

((4-bis. Il certificatore ha l'obbligo di conservare le informazioni di cui ai commi 3 e 4 per almeno venti anni decorrenti dalla scadenza del certificato di firma.))

#### Art. 29. - ((Qualificazione dei fornitori di servizi))

1. I soggetti che intendono fornire servizi fiduciari qualificati o svolgere l'attivita' di gestore di posta elettronica certificata ((...)) presentano all'AgID domanda di qualificazione, secondo le modalita' fissate dalle Linee guida. ((PERIODO SOPPRESSO DAL D.L. 16 LUGLIO 2020, N. 76)).

2. ((Ai fini della qualificazione, i soggetti di cui al comma 1 devono possedere i requisiti di cui all'articolo 24 del Regolamento (UE) 23 luglio 2014, n. 910/2014, disporre di requisiti di onorabilita', affidabilita', tecnologici e organizzativi compatibili con la disciplina europea, nonche' di garanzie assicurative adeguate rispetto all'attivita' svolta. Con decreto del Presidente del Consiglio dei ministri, o del Ministro delegato per l'innovazione tecnologica e la digitalizzazione, sentita l'AgID, nel rispetto della disciplina europea, sono definiti i predetti requisiti in relazione alla specifica attivita' che i soggetti di cui al comma 1 intendono svolgere.)) Il predetto decreto determina altresi' i criteri per la fissazione delle tariffe dovute all'AgID per lo svolgimento delle predette attivita', nonche' i requisiti e le condizioni per lo svolgimento delle attivita' di cui al comma 1 da parte di amministrazioni pubbliche.

3. COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217. (29)

4. La domanda di qualificazione ((...)) si considera accolta qualora non venga comunicato all'interessato il provvedimento di diniego entro novanta giorni dalla data di presentazione della stessa.

5. Il termine di cui al comma 4, puo' essere sospeso una sola volta entro trenta giorni dalla data di presentazione della domanda, esclusivamente per la motivata richiesta di documenti che integrino o completino la documentazione presentata e che non siano gia' nella disponibilita' del AgID o che questo non possa acquisire autonomamente. In tale caso, il termine riprende a decorrere dalla data di ricezione della documentazione integrativa.

6. A seguito dell'accoglimento della domanda, il AgID dispone l'iscrizione del richiedente in un apposito elenco di fiducia pubblico, tenuto dal AgID stesso e consultabile anche in via telematica, ai fini dell'applicazione della disciplina in questione.

7. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

8. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

9. Alle attivita' previste dal presente articolo si fa fronte nell'ambito delle risorse del AgID, senza nuovi o maggiori oneri per la finanza pubblica. (28)

-------------- AGGIORNAMENTO (28) Il D.Lgs. 26 agosto 2016, n. 179 ha disposto (con l'art. 62, comma 5) che "Il prestatore di servizi che ha presentato la relazione di conformita', ai sensi dell'articolo 51 del regolamento eIDAS, e' considerato prestatore di servizi fiduciari qualificato a norma del predetto regolamento e dell'articolo 29 del decreto legislativo n. 82 del 2005, come modificato dall'articolo 25 del presente decreto, fino al completamento della valutazione della relazione da parte dell'AgID". --------------- AGGIORNAMENTO (29) Il D.Lgs. 13 dicembre 2017, n. 217 ha disposto (con l'art. 65, comma 8) che "Il decreto del Presidente del Consiglio dei ministri di cui all'articolo 29, comma 2, del decreto legislativo n. 82 del 2005, come modificato dal presente decreto, e' adottato entro centottanta giorni dalla data di entrata in vigore del presente decreto. Fino all'adozione del predetto decreto, restano efficaci le disposizioni dell'articolo 29, comma 3, dello stesso decreto nella formulazione previgente all'entrata in vigore del decreto legislativo 26 agosto 2016, n. 179 e dell'articolo 44-bis, commi 2 e 3, del decreto legislativo n. 82 del 2005 nella formulazione previgente all'entrata in vigore del presente decreto".

#### Art. 30. - Responsabilita' dei prestatori di servizi fiduciari qualificati, dei gestori di posta elettronica certificata, dei gestori dell'identita' digitale e dei conservatori

1. ((I prestatori di servizi fiduciari qualificati e i gestori di posta elettronica certificata, iscritti nell'elenco di cui all'articolo 29, comma 6, nonche' i gestori dell'identita' digitale e i conservatori di documenti informatici)), che cagionano danno ad altri nello svolgimento della loro attivita', sono tenuti al risarcimento, se non provano di avere adottato tutte le misure idonee a evitare il danno.

2. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

3. PERIODO SOPPRESSO DAL D.LGS. 13 DICEMBRE 2017, N. 217. Il prestatore di servizi di firma digitale o di altra firma elettronica qualificata non e' responsabile dei danni derivanti dall'uso di un certificato qualificato che ecceda i limiti eventualmente posti dallo stesso ai sensi dell'articolo 28, comma 3, a condizione che limiti d'uso e di valore siano chiaramente riconoscibili secondo quanto previsto dall'articolo 28, comma 3-bis.

#### Art. 31.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

#### Art. 32.

Obblighi del titolare ((di firma elettronica qualificata)) e del prestatore di servizi di firma elettronica qualificata

1. Il titolare del certificato di firma e' tenuto ad assicurare la custodia del dispositivo di firma o degli strumenti di autenticazione informatica per l'utilizzo del dispositivo di firma da remoto, e ad adottare tutte le misure organizzative e tecniche idonee ad evitare danno ad altri; e' altresi' tenuto ad utilizzare personalmente il dispositivo di firma.

2. Il prestatore di servizi di firma elettronica qualificata e' tenuto ad adottare tutte le misure organizzative e tecniche idonee ad evitare danno a terzi.

3. Il prestatore di servizi di firma elettronica qualificata che rilascia ((...)) certificati qualificati deve comunque:

- a) provvedere con certezza alla identificazione della persona che fa richiesta della certificazione;
- b) rilasciare e rendere pubblico il certificato elettronico nei modi o nei casi stabiliti dalle ((Linee guida)), nel rispetto del decreto legislativo 30 giugno 2003, n. 196, e successive modificazioni;
- c) specificare, nel certificato qualificato su richiesta dell'istante, e con il consenso del terzo interessato, i poteri di rappresentanza o altri titoli relativi all'attivita' professionale o a cariche rivestite, previa verifica della documentazione presentata dal richiedente che attesta la sussistenza degli stessi;
- d) attenersi alle ((Linee guida));
- e) informare i richiedenti in modo compiuto e chiaro, sulla procedura di certificazione e sui necessari requisiti tecnici per accedervi e sulle caratteristiche e sulle limitazioni d'uso delle firme emesse sulla base del servizio di certificazione;
- f) LETTERA SOPPRESSA DAL D.LGS. 30 DICEMBRE 2010, N. 235;
- g) procedere alla tempestiva pubblicazione della revoca e della sospensione del certificato elettronico in caso di richiesta da parte del titolare ((di firma elettronica qualificata)) o del terzo dal quale derivino i poteri del titolare ((di firma elettronica qualificata)) medesimo, di perdita del possesso o della compromissione del dispositivo di firma o degli strumenti di autenticazione informatica per l'utilizzo del dispositivo di firma, di provvedimento dell'autorita', di acquisizione della conoscenza di cause limitative della capacita' del titolare ((di firma elettronica qualificata)), di sospetti abusi o falsificazioni, secondo quanto previsto dalle ((Linee guida));
- h) garantire un servizio di revoca e sospensione dei certificati elettronici sicuro e tempestivo nonche' garantire il funzionamento efficiente, puntuale e sicuro degli elenchi dei certificati di firma emessi, sospesi e revocati;
- i) assicurare la precisa determinazione della data e dell'ora di rilascio, di revoca e di sospensione dei certificati elettronici;
- j) tenere registrazione, anche elettronica, di tutte le informazioni relative al certificato qualificato dal momento della sua emissione almeno per venti anni anche al fine di fornire prova della certificazione in eventuali procedimenti giudiziari;
- k) non copiare, ne' conservare, le chiavi private di firma del soggetto cui il prestatore di servizi di firma elettronica qualificata ha fornito il servizio di certificazione;
- l) predisporre su mezzi di comunicazione durevoli tutte le informazioni utili ai soggetti che richiedono il servizio di certificazione, tra cui in particolare gli esatti termini e condizioni relative all'uso del certificato, compresa ogni limitazione dell'uso, l'esistenza di un sistema di accreditamento facoltativo e le procedure di reclamo e di risoluzione delle controversie; dette informazioni, che possono essere trasmesse elettronicamente, devono essere scritte in linguaggio chiaro ed essere fornite prima dell'accordo tra il richiedente il servizio ed il prestatore di servizi di firma elettronica qualificata;
- m) utilizzare sistemi affidabili per la gestione del registro dei certificati con modalita' tali da garantire che soltanto le persone autorizzate possano effettuare inserimenti e modifiche, che l'autenticita' delle informazioni sia verificabile, che i certificati siano accessibili alla consultazione del pubblico soltanto nei casi consentiti dal titolare del certificato e che l'operatore possa rendersi conto di qualsiasi evento che comprometta i requisiti di sicurezza. Su richiesta, elementi pertinenti delle informazioni possono essere resi accessibili a terzi che facciano affidamento sul certificato.
- m-bis) garantire il corretto funzionamento e la continuita' del sistema e comunicare immediatamente a AgID e agli utenti eventuali malfunzionamenti che determinano disservizio, sospensione o interruzione del servizio stesso.

4. Il prestatore di servizi di firma elettronica qualificata e' responsabile dell'identificazione del soggetto che richiede il certificato qualificato di firma anche se tale attivita' e' delegata a terzi.

5. Il prestatore di servizi di firma elettronica qualificata raccoglie i dati personali direttamente dalla persona cui si riferiscono o, previo suo esplicito consenso, tramite il terzo, e soltanto nella misura necessaria al rilascio e al mantenimento del certificato, fornendo l'informativa prevista dall'articolo 13 del decreto legislativo 30 giugno 2003, n. 196. I dati non possono essere raccolti o elaborati per fini diversi senza l'espresso consenso della persona cui si riferiscono.

#### Art. 32-bis. - (Sanzioni per i prestatori di servizi fiduciari qualificati, per i gestori di posta elettronica certificata, per i gestori dell'identita' digitale e per i conservatori)

1. L'AgID puo' irrogare ai prestatori di servizi fiduciari qualificati, ai gestori di posta elettronica certificata, ai gestori dell'identita' digitale e ai soggetti di cui all'articolo 34, comma 1-bis, lettera b) , che abbiano violato gli obblighi del Regolamento eIDAS o del presente Codice relative alla prestazione dei predetti servizi, sanzioni amministrative in relazione alla gravita' della violazione accertata e all'entita' del danno provocato all'utenza, per importi da un minimo di euro 40.000,00 a un massimo di euro 400.000,00, fermo restando il diritto al risarcimento del maggior danno. Le sanzioni per le violazioni commesse dai soggetti di cui all'articolo 34, comma 1-bis, lettera b), sono fissate nel minimo in euro 4.000,00 e nel massimo in euro 40.000,00. Le violazioni del presente Codice idonee a esporre a rischio i diritti e gli interessi di una pluralita' di utenti o relative a significative carenze infrastrutturali o di processo del fornitore di servizio si considerano gravi. AgID, laddove accerti tali gravi violazioni, dispone altresi' la cancellazione del fornitore del servizio dall'elenco dei soggetti qualificati e il divieto di accreditamento o qualificazione per un periodo fino ad un massimo di due anni. Le sanzioni vengono irrogate dal direttore generale dell'AgID ((...)). Si applica, in quanto compatibile, la disciplina della legge 24 novembre 1981, n. 689.

1-bis. L'AgID irroga la sanzione amministrativa di cui al comma 1 e diffida i soggetti a conformare la propria condotta agli obblighi previsti dalla disciplina vigente.

2. Fatti salvi i casi di forza maggiore o di caso fortuito, qualora si verifichi un malfunzionamento nei servizi forniti dai soggetti di cui al comma 1 che determini l'interruzione del servizio, ovvero in caso di mancata o intempestiva comunicazione dello stesso disservizio a AgID o agli utenti, ai sensi dell'articolo 32, comma 3, lettera m-bis), AgID, ferma restando l'irrogazione delle sanzioni amministrative, diffida altresi' i soggetti di cui al comma 1 a ripristinare la regolarita' del servizio o ad effettuare le comunicazioni previste. Se l'interruzione del servizio ovvero la mancata o intempestiva comunicazione sono reiterati nel corso di un biennio, successivamente alla prima diffida si applica la sanzione della cancellazione dall'elenco pubblico.

3. Nei casi di cui ai commi 1, 1-bis; e 2 puo' essere applicata la sanzione amministrativa accessoria della pubblicazione dei provvedimenti di diffida o di cancellazione secondo la legislazione vigente in materia di pubblicita' legale.

4. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

#### Art. 33.

((ARTICOLO ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217))

#### Art. 34. - Norme particolari per le pubbliche amministrazioni

1. Ai fini della sottoscrizione, ove prevista, di documenti informatici di rilevanza esterna, le pubbliche amministrazioni:

- a) possono svolgere direttamente l'attivita' di rilascio dei certificati qualificati avendo a tale fine l'obbligo di qualificarsi ai sensi dell'articolo 29; tale attivita' puo' essere svolta esclusivamente nei confronti dei propri organi ed uffici, nonche' di categorie di terzi, pubblici o privati. PERIODO SOPPRESSO DAL D.LGS. 26 AGOSTO 2016, N. 179;
- b) possono rivolgersi a prestatori di servizi di firma digitale o di altra firma elettronica qualificata, secondo la vigente normativa in materia di contratti pubblici.

1-bis. Le pubbliche amministrazioni possono procedere alla conservazione dei documenti informatici:

- a) all'interno della propria struttura organizzativa;
- b) affidandola, in modo totale o parziale, nel rispetto della disciplina vigente, ad altri soggetti, pubblici o privati ((che possiedono i requisiti di qualita', di sicurezza e organizzazione individuati, nel rispetto della disciplina europea, nelle Linee guida di cui all'art 71 relative alla formazione, gestione e conservazione dei documenti informatici nonche' in un regolamento sui criteri per la fornitura dei servizi di conservazione dei documenti informatici emanato da AgID, avuto riguardo all'esigenza di assicurare la conformita' dei documenti conservati agli originali nonche' la qualita' e la sicurezza del sistema di conservazione.))

2. COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217.

3. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

4. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

5. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

#### Art. 35. - Dispositivi sicuri e procedure per la generazione della firma qualificata

1. I dispositivi sicuri e le procedure utilizzate per la generazione delle firme devono presentare requisiti di sicurezza tali da garantire che la chiave privata:

- a) sia riservata;
- b) non possa essere derivata e che la relativa firma sia protetta da contraffazioni;
- c) possa essere sufficientemente protetta dal titolare dall'uso da parte di terzi. 1-bis) Fermo restando quanto previsto dal comma 1, i dispositivi per la creazione di una firma elettronica qualificata o di un sigillo elettronico soddisfano i requisiti di cui all'Allegato II del Regolamento eIDAS.

2. I dispositivi sicuri e le procedure di cui al comma 1 devono garantire l'integrita' dei documenti informatici a cui la firma si riferisce. I documenti informatici devono essere presentati al titolare ((di firma elettronica)), prima dell'apposizione della firma, chiaramente e senza ambiguita', e si deve richiedere conferma della volonta' di generare la firma secondo quanto previsto dalle ((Linee guida)).

3. Il secondo periodo del comma 2 non si applica alle firme apposte con procedura automatica. La firma con procedura automatica e' valida se apposta previo consenso del titolare all'adozione della procedura medesima.

4. I dispositivi sicuri di firma devono essere dotati di certificazione di sicurezza ai sensi dello schema nazionale di cui al comma 5.

5. La conformita' dei requisiti di sicurezza dei dispositivi per la creazione di una firma elettronica qualificata o di un sigillo elettronico prescritti dall'Allegato II del regolamento eIDAS e' accertata, in Italia, dall'Organismo di certificazione della sicurezza informatica in base allo schema nazionale per la valutazione e certificazione di sicurezza nel settore della tecnologia dell'informazione, fissato con decreto del Presidente del Consiglio dei Ministri, o, per sua delega, del Ministro per l'innovazione e le tecnologie, di concerto con i Ministri delle comunicazioni, delle attivita' produttive e dell'economia e delle finanze. L'attuazione dello schema nazionale non deve determinare nuovi o maggiori oneri per il bilancio dello Stato. Lo schema nazionale puo' prevedere altresi' la valutazione e la certificazione relativamente ad ulteriori criteri europei ed internazionali, anche riguardanti altri sistemi e prodotti afferenti al settore suddetto. La valutazione della conformita' del sistema e degli strumenti di autenticazione utilizzati dal titolare delle chiavi di firma e' effettuata dall'Agenzia per l'Italia digitale in conformita' ad apposite linee guida da questa emanate, acquisito il parere obbligatorio dell'Organismo di certificazione della sicurezza informatica.

6. La conformita' di cui al comma 5 e' inoltre riconosciuta se accertata da un organismo all'uopo designato da un altro Stato membro e notificato ai sensi dell'articolo 30, comma 2, del Regolamento eIDAS. Ove previsto dall'organismo di cui al periodo precedente, la valutazione della conformita' del sistema e degli strumenti di autenticazione utilizzati dal titolare delle chiavi di firma e' effettuata dall'AgID in conformita' alle linee guida di cui al comma 5.

#### Art. 36. - Revoca e sospensione dei certificati qualificati

1. Il certificato qualificato deve essere a cura del certificatore:

- a) revocato in caso di cessazione dell'attivita' del certificatore salvo quanto previsto dal comma 2 dell'articolo 37;
- b) revocato o sospeso in esecuzione di un provvedimento dell'autorita';
- c) revocato o sospeso a seguito di richiesta del titolare o del terzo dal quale derivano i poteri del titolare, secondo le modalita' previste nel presente codice;
- d) revocato o sospeso in presenza di cause limitative della capacita' del titolare o di abusi o falsificazioni.

2. Il certificato qualificato puo', inoltre, essere revocato o sospeso nei casi previsti dalle ((Linee guida)) ((, per violazione delle regole tecniche ivi contenute)).

3. La revoca o la sospensione del certificato qualificato, qualunque ne sia la causa, ha effetto dal momento della pubblicazione della lista che lo contiene. Il momento della pubblicazione deve essere attestato mediante adeguato riferimento temporale.

4. Le modalita' di revoca o sospensione sono previste nelle ((Linee guida)).

#### Art. 37. - Cessazione dell'attivita'

1. ((Il prestatore di servizi fiduciari qualificato)) che intende cessare l'attivita' deve, almeno sessanta giorni prima della data di cessazione, darne avviso al ((AgID)) e informare senza indugio i titolari dei certificati da lui emessi specificando che tutti i certificati non scaduti al momento della cessazione saranno revocati.

2. Il ((prestatore)) di cui al comma 1 comunica contestualmente la rilevazione della documentazione da parte di altro ((prestatore)) o l'annullamento della stessa. L'indicazione di un ((prestatore di servizi fiduciari qualificato)) sostitutivo evita la revoca di tutti i certificati non scaduti al momento della cessazione.

3. Il ((prestatore)) di cui al comma 1 indica altro depositario del registro dei certificati e della relativa documentazione.

4. Il ((AgID)) rende nota la data di cessazione dell'attivita' del ((prestatore di cui al comma 1)) tramite l'elenco di cui all'articolo 29, comma 6.

4-bis. Qualora il ((prestatore di cui al comma 1)) cessi la propria attivita' senza indicare, ai sensi del comma 2, ((un prestatore di servizi fiduciari qualificato)) sostitutivo e non si impegni a garantire la conservazione e la disponibilita' della documentazione prevista dagli articoli 33 e 32, comma 3, lettera j) e delle ultime liste di revoca emesse, deve provvedere al deposito presso ((AgID)) che ne garantisce la conservazione e la disponibilita'.

((

4-ter. Nel caso in cui il prestatore di cui al comma 1 non ottemperi agli obblighi previsti dal presente articolo, AgID intima al prestatore di ottemperarvi entro un termine non superiore a trenta giorni. In caso di mancata ottemperanza entro il suddetto termine, si applicano le sanzioni di cui all'articolo 32-bis; le sanzioni pecuniarie previste dal predetto articolo sono aumentate fino al doppio.

))

### Sezione III - ((Trasferimenti di fondi, libri e scritture))

#### Art. 38. - Trasferimenti di fondi

1. Il trasferimento in via telematica di fondi tra pubbliche amministrazioni e tra queste e soggetti privati e' effettuato secondo le ((Linee guida)) ((, sentiti il Dipartimento della funzione pubblica, i Ministeri della giustizia e dell'economia e delle finanze, nonche')) il Garante per la protezione dei dati personali e la Banca d'Italia.

#### Art. 39. - Libri e scritture

1. I libri, i repertori e le scritture, ivi compresi quelli previsti dalla legge sull'ordinamento del notariato e degli archivi notarili, di cui sia obbligatoria la tenuta possono essere formati e conservati su supporti informatici in conformita' alle disposizioni del presente codice e secondo le ((Linee guida)).

## Capo III - ((GESTIONE, CONSERVAZIONE E ACCESSIBILITA' DEI DOCUMENTI E FASCICOLI INFORMATICI)) ((

### Sezione I - Documenti della pubblica amministrazione))

#### Art. 40. - Formazione di documenti informatici

1. Le pubbliche amministrazioni formano gli originali dei propri documenti, inclusi quelli inerenti ad albi, elenchi e pubblici registri, con mezzi informatici secondo le disposizioni di cui al presente codice e le ((Linee guida)).

2. COMMA ABROGATO DAL D.LGS. 30 DICEMBRE 2010, N. 235.

3. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

4. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

#### Art. 40-bis. - (Protocollo informatico)

1. Formano comunque oggetto di registrazione di protocollo ai sensi dell'articolo 53 del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445, le comunicazioni che ((provengono da o sono inviate a domicili digitali eletti ai sensi di quanto previsto all'articolo 3-bis,)) nonche' le istanze e le dichiarazioni di cui all'articolo 65 in conformita' alle ((Linee guida)).

#### Art. 40-ter. - (( (Sistema pubblico di ricerca documentale).))

((

1. La Presidenza del Consiglio dei ministri promuove lo sviluppo e la sperimentazione di un sistema volto a facilitare la ricerca dei documenti soggetti a obblighi di pubblicita' legale, trasparenza o a registrazione di protocollo ai sensi dell'articolo 53 del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445, e di cui all'articolo 40-bis e dei fascicoli dei procedimenti di cui all'articolo 41, nonche' a consentirne l'accesso on-line ai soggetti che ne abbiano diritto ai sensi della disciplina vigente.

))

### ((Sezione II - Gestione e conservazione dei documenti))

#### Art. 41. - Procedimento e fascicolo informatico

1. Le pubbliche amministrazioni gestiscono i procedimenti amministrativi utilizzando le tecnologie dell'informazione e della comunicazione. Per ciascun procedimento amministrativo di loro competenza, esse forniscono gli opportuni servizi di interoperabilita' ((o integrazione)), ai sensi di quanto previsto ((dagli articoli 12 e 64-bis)).

1-bis. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

2. La pubblica amministrazione titolare del procedimento raccoglie in un fascicolo informatico gli atti, i documenti e i dati del procedimento medesimo da chiunque formati; all'atto della comunicazione dell'avvio del procedimento ai sensi dell'articolo 8 della legge 7 agosto 1990, n. 241, comunica agli interessati le modalita' per esercitare in via telematica i diritti di cui all'articolo 10 della citata legge 7 agosto 1990, n. 241. (28)

2-bis. Il fascicolo informatico e' realizzato garantendo la possibilita' di essere direttamente consultato ed alimentato da tutte le amministrazioni coinvolte nel procedimento ((e dagli interessati, nei limiti ed alle condizioni previste dalla disciplina vigente, attraverso i servizi di cui agli articoli 40-ter e 64-bis)). ((Le Linee guida)) per la costituzione, l'identificazione ((, l'accessibilita' attraverso i suddetti servizi)) e l'utilizzo del fascicolo ((sono dettate dall'AgID ai sensi dell'articolo 71 e)) sono conformi ai principi di una corretta gestione documentale ed alla disciplina della formazione, gestione, conservazione e trasmissione del documento informatico, ivi comprese le regole concernenti il protocollo informatico ed il sistema pubblico di connettivita', e comunque rispettano i criteri dell'interoperabilita' e ((dell'integrazione)).

2-ter. Il fascicolo informatico reca l'indicazione:

- a) dell'amministrazione titolare del procedimento, che cura la costituzione e la gestione del fascicolo medesimo;
- b) delle altre amministrazioni partecipanti;
- c) del responsabile del procedimento;
- d) dell'oggetto del procedimento;
- e) dell'elenco dei documenti contenuti, salvo quanto disposto dal comma 2-quater.
- e-bis) dell'identificativo del fascicolo medesimo ((apposto con modalita' idonee a consentirne l'indicizzazione e la ricerca attraverso il sistema di cui all'articolo 40-ter nel rispetto delle Linee guida)).

2-quater. Il fascicolo informatico puo' contenere aree a cui hanno accesso solo l'amministrazione titolare e gli altri soggetti da essa individuati; esso e' formato in modo da garantire la corretta collocazione, la facile reperibilita' e la collegabilita', in relazione al contenuto ed alle finalita', ((dei singoli documenti. Il fascicolo informatico)) e' inoltre costituito in modo da garantire l'esercizio in via telematica dei diritti previsti dalla citata legge n. 241 del 1990 ((e dall'articolo 5, comma 2, del decreto legislativo 14 marzo 2013, n. 33, nonche' l'immediata conoscibilita' anche attraverso i servizi di cui agli articoli 40-ter e 64-bis, sempre per via telematica, dello stato di avanzamento del procedimento, del nominativo e del recapito elettronico del responsabile del procedimento. AgID detta, ai sensi dell'articolo 71, Linee guida idonee a garantire l'interoperabilita' tra i sistemi di gestione dei fascicoli dei procedimenti e i servizi di cui agli articoli 40-ter e 64-bis)).

3. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

-------------- AGGIORNAMENTO (28) Il D.Lgs. 26 agosto 2016, n. 179 ha disposto (con l'art. 61, comma 2, lettera d)) che l' espressione «chiunque», ovunque ricorra, si intende come «soggetti giuridici».

#### Art. 42. - Dematerializzazione dei documenti delle pubbliche amministrazioni

1. Le pubbliche amministrazioni valutano in termini di rapporto tra costi e benefici il recupero su supporto informatico dei documenti e degli atti cartacei dei quali sia obbligatoria o opportuna la conservazione e provvedono alla predisposizione dei conseguenti piani di sostituzione degli archivi cartacei con archivi informatici, nel rispetto delle ((Linee guida)).

#### Art. 43. - ((Conservazione ed esibizione dei documenti))

((

1. Gli obblighi di conservazione e di esibizione di documenti si intendono soddisfatti a tutti gli effetti di legge a mezzo di documenti informatici, se le relative procedure sono effettuate in modo tale da garantire la conformita' ai documenti originali e sono conformi alle Linee guida.

))

1-bis. Se il documento informatico e' conservato per legge da uno dei soggetti di cui all'articolo 2, comma 2, cessa l'obbligo di conservazione a carico dei cittadini e delle imprese che possono in ogni momento richiedere accesso al documento stesso ((ai medesimi soggetti di cui all'articolo 2, comma 2. Le amministrazioni rendono disponibili a cittadini ed imprese i predetti documenti attraverso servizi on-line accessibili previa identificazione con l'identita' digitale di cui all'articolo 64 ed integrati con i servizi di cui agli articoli 40-ter e 64-bis)).

2. Restano validi i documenti degli archivi, le scritture contabili, la corrispondenza ed ogni atto, dato o documento gia' conservati mediante riproduzione su supporto fotografico, su supporto ottico o con altro processo idoneo a garantire la conformita' dei documenti agli originali ((ai sensi della disciplina vigente al momento dell'invio dei singoli documenti nel sistema di conservazione)).

3. I documenti informatici, di cui e' prescritta la conservazione per legge o regolamento, possono essere archiviati per le esigenze correnti anche con modalita' cartacee e sono conservati in modo permanente con modalita' digitali, nel rispetto delle ((Linee guida)).

4. Sono fatti salvi i poteri di controllo del Ministero per i beni e le attivita' culturali sugli archivi delle pubbliche amministrazioni e sugli archivi privati dichiarati di notevole interesse storico ai sensi delle disposizioni del decreto legislativo 22 gennaio 2004, n. 42.

#### Art. 44.

Requisiti per la gestione e conservazione dei documenti informatici

1. Il sistema di gestione informatica dei documenti delle pubbliche amministrazioni, di cui all'articolo 52 del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445, e' organizzato e gestito, anche in modo da assicurare l'indicizzazione e la ricerca dei documenti e fascicoli informatici attraverso il sistema di cui all'articolo 40-ter nel rispetto delle Linee guida.

1-bis. Il sistema di gestione dei documenti informatici delle pubbliche amministrazioni e' gestito da un responsabile che opera d'intesa con il dirigente dell'ufficio di cui all'articolo 17 del presente Codice, il responsabile del trattamento dei dati personali di cui all'articolo 29 del decreto legislativo 30 giugno 2003, n. 196, ove nominato, e con il responsabile del sistema della conservazione dei documenti informatici delle pubbliche amministrazioni, nella definizione e gestione delle attivita' di rispettiva competenza. Almeno una volta all'anno il responsabile della gestione dei documenti informatici provvede a trasmettere al sistema di conservazione i fascicoli e le serie documentarie anche relative a procedimenti non conclusi.

1-ter. ((In tutti i casi in cui la legge prescrive obblighi di conservazione, anche a carico di soggetti privati, il sistema)) di conservazione dei documenti informatici assicura, per quanto in esso conservato, caratteristiche di autenticita', integrita', affidabilita', leggibilita', reperibilita', secondo le modalita' indicate nelle Linee guida.

1-quater. Il responsabile della conservazione, che opera d'intesa con il responsabile del trattamento dei dati personali, con il responsabile della sicurezza e con il responsabile dei sistemi informativi, puo' affidare, ai sensi dell'articolo 34, comma 1-bis, lettera b), la conservazione dei documenti informatici ad altri soggetti, pubblici o privati, che offrono idonee garanzie organizzative, e tecnologiche e di protezione dei dati personali. Il responsabile della conservazione della pubblica amministrazione, che opera d'intesa, oltre che con i responsabili di cui al comma 1-bis, anche con il responsabile della gestione documentale, effettua la conservazione dei documenti informatici secondo quanto previsto all'articolo 34, comma 1-bis.

#### Art. 44-bis.

((ARTICOLO ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)) ((29))

--------------- AGGIORNAMENTO (29) Il D.Lgs. 13 dicembre 2017, n. 217 ha disposto (con l'art. 65, comma 8) che "Il decreto del Presidente del Consiglio dei ministri di cui all'articolo 29, comma 2, del decreto legislativo n. 82 del 2005, come modificato dal presente decreto, e' adottato entro centottanta giorni dalla data di entrata in vigore del presente decreto. Fino all'adozione del predetto decreto, restano efficaci le disposizioni dell'articolo 29, comma 3, dello stesso decreto nella formulazione previgente all'entrata in vigore del decreto legislativo 26 agosto 2016, n. 179 e dell'articolo 44-bis, commi 2 e 3, del decreto legislativo n. 82 del 2005 nella formulazione previgente all'entrata in vigore del presente decreto".

## Capo IV - TRASMISSIONE INFORMATICA DEI DOCUMENTI

### Art. 45. - Valore giuridico della trasmissione

1. I documenti trasmessi da chiunque ad una pubblica amministrazione con qualsiasi mezzo telematico o informatico, idoneo ad accertarne la ((...)) provenienza, soddisfano il requisito della forma scritta e la loro trasmissione non deve essere seguita da quella del documento originale. (28)

2. Il documento informatico trasmesso per via telematica si intende spedito dal mittente se inviato al proprio gestore, e si intende consegnato al destinatario se reso disponibile all'indirizzo elettronico da questi dichiarato, nella casella di posta elettronica del destinatario messa a disposizione dal gestore.

-------------- AGGIORNAMENTO (28) Il D.Lgs. 26 agosto 2016, n. 179 ha disposto (con l'art. 61, comma 2, lettera d)) che l'espressione «chiunque», ovunque ricorra, si intende come «soggetti giuridici».

### Art. 46. - Dati particolari contenuti nei documenti trasmessi

1. Al fine di garantire la riservatezza dei dati sensibili o giudiziari di cui all'articolo 4, comma 1, lettere d) ed e), del decreto legislativo 30 giugno 2003, n. 196, i documenti informatici trasmessi ad altre pubbliche amministrazioni per via ((digitale)) possono contenere soltanto ((i dati sensibili e giudiziari consentiti)) da legge o da regolamento e indispensabili per il perseguimento delle finalita' per le quali sono acquisite.

### Art. 47.

Trasmissione dei documenti tra le pubbliche amministrazioni

1. Le comunicazioni di documenti tra le pubbliche amministrazioni avvengono mediante l'utilizzo della posta elettronica o in cooperazione applicativa; esse sono valide ai fini del procedimento amministrativo una volta che ne sia verificata la provenienza. Il documento puo' essere, altresi', reso disponibile previa comunicazione delle modalita' di accesso telematico allo stesso.

1-bis. L'inosservanza della disposizione di cui al comma 1, ferma restando l'eventuale responsabilita' per danno erariale, comporta responsabilita' dirigenziale e responsabilita' disciplinare.

2. Ai fini della verifica della provenienza le comunicazioni sono valide se:

- a) sono sottoscritte con firma digitale o altro tipo di firma elettronica qualificata;
- b) ovvero sono dotate di segnatura di protocollo di cui all'articolo 55 del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445;
- c) ovvero e' comunque possibile accertarne altrimenti la provenienza, secondo quanto previsto dalla normativa vigente o dalle ((Linee guida)). E' in ogni caso esclusa la trasmissione di documenti a mezzo fax;
- d) ovvero trasmesse attraverso sistemi di posta elettronica certificata di cui al decreto del Presidente della Repubblica 11 febbraio 2005, n. 68.

3. ((I soggetti di cui all'articolo 2, comma 2, lettere a) e b),)) provvedono ad istituire e pubblicare ((nell'Indice dei domicili digitali delle pubbliche amministrazioni e dei gestori di pubblici servizi)) almeno una casella di posta elettronica certificata per ciascun registro di protocollo. ((Le pubbliche amministrazioni)) utilizzano per le comunicazioni tra l'amministrazione ed i propri dipendenti la posta elettronica o altri strumenti informatici di comunicazione nel rispetto delle norme in materia di protezione dei dati personali e previa informativa agli interessati in merito al grado di riservatezza degli strumenti utilizzati.

### Art. 48. - (Posta elettronica certificata)

1. La trasmissione telematica di comunicazioni che necessitano di una ricevuta di invio e di una ricevuta di consegna avviene mediante la posta elettronica certificata ai sensi del decreto del Presidente della Repubblica 11 febbraio 2005, n. 68, o mediante altre soluzioni tecnologiche individuate con le Linee guida.

2. La trasmissione del documento informatico per via telematica, effettuata ai sensi del comma 1, equivale, salvo che la legge disponga diversamente, alla notificazione per mezzo della posta.

3. La data e l'ora di trasmissione e di ricezione di un documento informatico trasmesso ai sensi del comma 1 sono opponibili ai terzi se conformi alle disposizioni di cui al decreto del Presidente della Repubblica 11 febbraio 2005, n. 68, ed alle relative regole tecniche, ovvero conformi alle Linee guida. ((31))

-------------- AGGIORNAMENTO (31) Il D.Lgs. 13 dicembre 2017, n. 217, come modificato dal D.L. 14 dicembre 2018, n. 135, convertito con modificazioni dalla L. 11 febbraio 2019, n. 12, ha disposto (con l'art. 65, comma 7) che "Con decreto del Presidente del Consiglio dei ministri, sentiti l'Agenzia per l'Italia digitale e il Garante per la protezione dei dati personali, sono adottate le misure necessarie a garantire la conformita' dei servizi di posta elettronica certificata di cui agli articoli 29 e 48 del decreto legislativo del 7 marzo 2005, n. 82, al regolamento (UE) n. 910/2014 del Parlamento europeo e del Consiglio, del 23 luglio 2014, in materia di identificazione elettronica e servizi fiduciari per le transazioni elettroniche nel mercato interno e che abroga la direttiva 1999/93/CE. A far data dall'entrata in vigore del decreto di cui al primo periodo, l'articolo 48 del decreto legislativo n. 82 del 2005 e' abrogato".

### Art. 49. - Segretezza della corrispondenza trasmessa per via telematica

1. Gli addetti alle operazioni di trasmissione per via telematica di atti, dati e documenti formati con strumenti informatici non possono prendere cognizione della corrispondenza telematica, duplicare con qualsiasi mezzo o cedere a terzi a qualsiasi titolo informazioni anche in forma sintetica o per estratto sull'esistenza o sul contenuto di corrispondenza, comunicazioni o messaggi trasmessi per via telematica, salvo che si tratti di informazioni per loro natura o per espressa indicazione del mittente destinate ad essere rese pubbliche.

2. Agli effetti del presente codice, gli atti, i dati e i documenti trasmessi per via telematica si considerano, nei confronti del gestore del sistema di trasporto delle informazioni, di proprieta' del mittente sino a che non sia avvenuta la consegna al destinatario.

## Capo V - DATI DELLE PUBBLICHE AMMINISTRAZIONI ((, IDENTITA' DIGITALI, ISTANZE E SERVIZI ONLINE))

### Sezione I - Dati delle pubbliche amministrazioni

#### Art. 50. - Disponibilita' dei dati delle pubbliche amministrazioni

1. I dati delle pubbliche amministrazioni sono formati, raccolti, conservati, resi disponibili e accessibili con l'uso delle tecnologie dell'informazione e della comunicazione che ne consentano la fruizione e riutilizzazione, alle condizioni fissate dall'ordinamento, da parte delle altre pubbliche amministrazioni e dai privati; restano salvi i limiti alla conoscibilita' dei dati previsti dalle leggi e dai regolamenti, le norme in materia di protezione dei dati personali ed il rispetto della normativa comunitaria in materia di riutilizzo delle informazioni del settore pubblico.

2. Qualunque dato trattato da una pubblica amministrazione, con le esclusioni di cui all'articolo 2, comma 6, salvi i casi previsti dall'articolo 24 della legge 7 agosto 1990, n. 241, e nel rispetto della normativa in materia di protezione dei dati personali, e' reso accessibile e fruibile alle altre amministrazioni quando l'utilizzazione del dato sia necessaria per lo svolgimento dei compiti istituzionali dell'amministrazione richiedente, senza oneri a carico di quest'ultima, salvo per la prestazione di elaborazioni aggiuntive; e' fatto comunque salvo il disposto degli articoli 43, commi 4 e 71, del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445.

2-bis. Le pubbliche amministrazioni, nell'ambito delle proprie funzioni istituzionali, procedono all'analisi dei propri dati anche in combinazione con quelli detenuti da altri soggetti di cui all'articolo 2, comma 2, fermi restando i limiti di cui al comma 1. La predetta attivita' si svolge secondo le modalita' individuate dall'AgID con le Linee guida.

2-ter. Le pubbliche amministrazioni certificanti detentrici dei dati di cui al comma 1 ne assicurano la fruizione da parte dei soggetti che hanno diritto ad accedervi. Le pubbliche amministrazioni detentrici dei dati assicurano, su richiesta dei soggetti privati di cui all'articolo 2 del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445, conferma scritta della corrispondenza di quanto dichiarato con le risultanze dei dati da essa custoditi, con le modalita' di cui all'articolo 71, comma 4 del medesimo decreto. ((38))

3. COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217.

3-bis. Il trasferimento di un dato da un sistema informativo a un altro non modifica la titolarita' del dato e del trattamento, ferme restando le responsabilita' delle amministrazioni che ricevono e trattano il dato in qualita' di titolari autonomi del trattamento. ((38))

3-ter. PERIODO SOPPRESSO DAL D.L. 31 MAGGIO 2021, N. 77, CONVERTITO CON MODIFICAZIONI DALLA L. 29 LUGLIO 2021, N. 108. L'inadempimento dell'obbligo di rendere disponibili i dati ai sensi del presente articolo costituisce mancato raggiungimento di uno specifico risultato e di un rilevante obiettivo da parte dei dirigenti responsabili delle strutture competenti e comporta la riduzione, non inferiore al 30 per cento, della retribuzione di risultato e del trattamento accessorio collegato alla performance individuale dei dirigenti competenti, oltre al divieto di attribuire premi o incentivi nell'ambito delle medesime strutture. ((38))

------------- AGGIORNAMENTO (38) Il D.L. 31 maggio 2021, n. 77, convertito con modificazioni dalla L. 29 luglio 2021, n. 108 ha disposto (con l'art. 39, comma 3) che "Con esclusione della lettera c) del comma 1, l'efficacia delle disposizioni dei commi 1 e 2, i cui oneri sono a carico delle risorse previste per l'attuazione di progetti compresi nel PNRR, resta subordinata alla definitiva approvazione del PNRR da parte del Consiglio dell'Unione europea".

#### Art. 50-bis.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

#### Art. 50-ter. - (Piattaforma Digitale Nazionale Dati)

1. La Presidenza del Consiglio dei ministri promuove la progettazione, lo sviluppo e la realizzazione di una Piattaforma Digitale Nazionale Dati (PDND) finalizzata a favorire la conoscenza e l'utilizzo del patrimonio informativo detenuto, per finalita' istituzionali, dai soggetti di cui all'articolo 2, comma 2, nonche' la condivisione dei dati tra i soggetti che hanno diritto ad accedervi ai fini dell'attuazione dell'articolo 50 e della semplificazione degli adempimenti amministrativi dei cittadini e delle imprese, in conformita' alla disciplina vigente. (38)

2. La Piattaforma Digitale Nazionale Dati e' gestita dalla Presidenza del Consiglio dei ministri ed e' costituita da un'infrastruttura tecnologica che rende possibile l'interoperabilita' dei sistemi informativi e delle basi di dati delle pubbliche amministrazioni e dei gestori di servizi pubblici per le finalita' di cui al comma 1, mediante l'accreditamento, l'identificazione e la gestione dei livelli di autorizzazione dei soggetti abilitati ad operare sulla stessa, nonche' la raccolta e conservazione delle informazioni relative agli accessi e alle transazioni effettuate suo tramite. La condivisione di dati e informazioni avviene attraverso la messa a disposizione e l'utilizzo, da parte dei soggetti accreditati, di interfacce di programmazione delle applicazioni (API). Le interfacce, sviluppate dai soggetti abilitati con il supporto della Presidenza del Consiglio dei ministri e in conformita' alle Linee guida AgID in materia interoperabilita', sono raccolte nel "catalogo API" reso disponibile dalla Piattaforma ai soggetti accreditati. I soggetti di cui all'articolo 2, comma 2, sono tenuti ad accreditarsi alla piattaforma, a sviluppare le interfacce e a rendere disponibili le proprie basi dati senza nuovi o maggiori oneri per la finanza pubblica. In fase di prima applicazione, la Piattaforma assicura prioritariamente l'interoperabilita' con le basi di dati di interesse nazionale di cui all'articolo 60, comma 3-bis e con le banche dati dell'Agenzie delle entrate individuate dal Direttore della stessa Agenzia. L'AgID, sentito il Garante per la protezione dei dati personali e acquisito il parere della Conferenza unificata, di cui all'articolo 8 del decreto legislativo 28 agosto 1997, n. 281, adotta linee guida con cui definisce gli standard tecnologici e criteri di sicurezza, di accessibilita', di disponibilita' e di interoperabilita' per la gestione della piattaforma nonche' il processo di accreditamento e di fruizione del catalogo API con i limiti e le condizioni di accesso volti ad assicurare il corretto trattamento dei dati personali ai sensi della normativa vigente. (38)

2-bis. Il Presidente del Consiglio dei Ministri o il Ministro delegato per l'innovazione tecnologica e la transizione digitale, ultimati i test e le prove tecniche di corretto funzionamento della piattaforma, fissa il termine entro il quale i soggetti di cui all'articolo 2, comma 2, sono tenuti ad accreditarsi alla stessa, a sviluppare le interfacce di cui al comma 2 e a rendere disponibili le proprie basi dati. (38)

3. Nella Piattaforma Digitale Nazionale Dati non sono conservati, ne' comunque trattati, oltre quanto strettamente necessario per le finalita' di cui al comma 1, i dati, che possono essere resi disponibili, attinenti a ordine e sicurezza pubblica, difesa e sicurezza nazionale, difesa civile e soccorso pubblico, indagini preliminari, polizia giudiziaria e polizia economico-finanziaria. Non possono comunque essere conferiti, conservati, ne' trattati i dati coperti da segreto o riservati nell'ambito delle materie indicate al periodo precedente.

4. Con decreto adottato dal Presidente del Consiglio dei ministri entro sessanta giorni dalla data di entrata in vigore della presente disposizione,, di concerto con il Ministero dell'economia e delle finanze e il Ministero dell'interno, sentito il Garante per la protezione dei dati personali e acquisito il parere della Conferenza Unificata di cui all'articolo 8 del decreto legislativo 28 agosto 1997, n. 281, e' stabilita la strategia nazionale dati. Con la strategia nazionale dati sono identificate le tipologie, i limiti, le finalita' e le modalita' di messa a disposizione, su richiesta della Presidenza del Consiglio dei ministri, dei dati aggregati e anonimizzati di cui sono titolari i soggetti di cui all'articolo 2, comma 2, in apposita infrastruttura tecnologica della Piattaforma Digitale Nazionale Dati finalizzata al supporto di politiche pubbliche basate sui dati, separata dall'infrastruttura tecnologica dedicata all'interoperabilita' dei sistemi informativi di cui al comma 2. Il decreto di cui al presente comma e' comunicato alle Commissioni parlamentari competenti. (38)

5. L'inadempimento dell'obbligo di rendere disponibili e accessibili le proprie basi dati ovvero i dati aggregati e anonimizzati costituisce mancato raggiungimento di uno specifico risultato e di un rilevante obiettivo da parte dei dirigenti responsabili delle strutture competenti e comporta la riduzione, non inferiore al 30 per cento, della retribuzione di risultato e del trattamento accessorio collegato alla performance individuale dei dirigenti competenti, oltre al divieto di attribuire premi o incentivi nell'ambito delle medesime strutture.

6. L'accesso ai dati attraverso la Piattaforma Digitale Nazionale Dati non modifica la disciplina relativa alla titolarita' del trattamento, ferme restando le specifiche responsabilita' ai sensi dell'articolo 28 del Regolamento (UE) 2016/679 del Parlamento Europeo e del Consiglio del 27 aprile 2016 in capo al soggetto gestore della Piattaforma nonche' le responsabilita' dei soggetti accreditati che trattano i dati in qualita' di titolari autonomi del trattamento.

7. Resta fermo che i soggetti di cui all'articolo 2, comma 2, possono continuare a utilizzare anche i sistemi di interoperabilita' gia' ((attivi)).

8. Le attivita' previste dal presente articolo si svolgono con le risorse umane, finanziarie e strumentali disponibili a legislazione vigente.

------------- AGGIORNAMENTO (38) Il D.L. 31 maggio 2021, n. 77, convertito con modificazioni dalla L. 29 luglio 2021, n. 108 ha disposto (con l'art. 39, comma 3) che "Con esclusione della lettera c) del comma 1, l'efficacia delle disposizioni dei commi 1 e 2, i cui oneri sono a carico delle risorse previste per l'attuazione di progetti compresi nel PNRR, resta subordinata alla definitiva approvazione del PNRR da parte del Consiglio dell'Unione europea".

#### Art. 50-quater. - (Disponibilita' dei dati generati nella fornitura di servizi in concessione)

1. Al fine di promuovere la valorizzazione del patrimonio informativo pubblico, per fini statistici e di ricerca e per lo svolgimento dei compiti istituzionali delle pubbliche amministrazioni, nei contratti e nei capitolati con i quali le pubbliche amministrazioni affidano lo svolgimento di servizi in concessione e' previsto l'obbligo del concessionario di rendere disponibili all'amministrazione concedente ((, che a sua volta li rende disponibili alle altre pubbliche amministrazioni per i medesimi fini e nel rispetto dell'articolo 50,)) tutti i dati acquisiti e generati nella fornitura del servizio agli utenti e relativi anche all'utilizzo del servizio medesimo da parte degli utenti, come dati di tipo aperto ai sensi dell'articolo 1, comma 1, lettera l-ter), nel rispetto delle linee guida adottate da AgID, sentito il Garante per la protezione dei dati personali.

#### Art. 51.

Sicurezza ((e disponibilita')) dei dati, dei sistemi e delle infrastrutture delle pubbliche amministrazioni

1. Con le ((Linee guida)) sono individuate le soluzioni tecniche idonee a garantire la protezione, la disponibilita', l'accessibilita', l'integrita' e la riservatezza dei dati e la continuita' operativa dei sistemi e delle infrastrutture.

1-bis. AgID attua, per quanto di competenza e in raccordo con le altre autorita' competenti in materia, il Quadro strategico nazionale per la sicurezza dello spazio cibernetico e il Piano nazionale per la sicurezza cibernetica e la sicurezza informatica. AgID, in tale ambito:

- a) coordina, tramite il Computer Emergency Response Team Pubblica Amministrazione (CERT-PA) istituito nel suo ambito, le iniziative di prevenzione e gestione degli incidenti di sicurezza informatici;
- b) promuove intese con le analoghe strutture internazionali;
- c) segnala al Ministro per ((la semplificazione e la pubblica amministrazione)) il mancato rispetto delle regole tecniche di cui al comma 1 da parte delle pubbliche amministrazioni.

2. I documenti informatici delle pubbliche amministrazioni devono essere custoditi e controllati con modalita' tali da ridurre al minimo i rischi di distruzione, perdita, accesso non autorizzato o non consentito o non conforme alle finalita' della raccolta.

2-bis. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

((

2-ter. I soggetti di cui all'articolo 2, comma 2, aderiscono ogni anno ai programmi di sicurezza preventiva coordinati e promossi da AgID secondo le procedure dettate dalla medesima AgID con le Linee guida.

2-quater. I soggetti di cui articolo 2, comma 2, predispongono, nel rispetto delle Linee guida adottate dall'AgID, piani di emergenza in grado di assicurare la continuita' operativa delle operazioni indispensabili per i servizi erogati e il ritorno alla normale operativita'. Onde garantire quanto previsto, e' possibile il ricorso all'articolo 15 della legge 7 agosto 1990, n. 241, per l'erogazione di servizi applicativi, infrastrutturali e di dati, con ristoro dei soli costi di funzionamento. Per le Amministrazioni dello Stato coinvolte si provvede mediante rimodulazione degli stanziamenti dei pertinenti capitoli di spesa o mediante riassegnazione alla spesa degli importi versati a tale titolo ad apposito capitolo di entrata del bilancio statale))

#### Art. 52.

(Accesso telematico e riutilizzo dei dati ((...)) ).

1. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

2. I dati e i documenti che ((i soggetti di cui all'articolo 2, comma 2,)) pubblicano, con qualsiasi modalita', senza l'espressa adozione di una licenza di cui all'articolo 2, comma 1, lettera h), del decreto legislativo 24 gennaio 2006, n. 36, si intendono rilasciati come dati di tipo aperto ai sensi ((all'articolo 1, comma 1, lettere l-bis) e l-ter),)) del presente Codice, ad eccezione dei casi in cui la pubblicazione riguardi dati personali del presente Codice. ((PERIODO SOPPRESSO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

3. Nella definizione dei capitolati o degli schemi dei contratti di appalto relativi a prodotti e servizi che comportino ((la formazione, la raccolta e la gestione di dati, i soggetti di cui all'articolo 2, comma 2, prevedono clausole idonee a consentirne l'utilizzazione in conformita' a quanto previsto dall'articolo 50)).

4. Le attivita' volte a garantire l'accesso telematico e il riutilizzo dei dati delle pubbliche amministrazioni rientrano tra i parametri di valutazione della performance dirigenziale ((...)).

5. ((COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

6. ((COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

7. ((COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

8. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

9. L'Agenzia svolge le attivita' indicate dal presente articolo con le risorse umane, strumentali, e finanziarie previste a legislazione vigente.(19)

-------------- AGGIORNAMENTO (19) Il D.L. 18 ottobre 2012, n. 179, convertito con modificazioni dalla L. 17 dicembre 2012, n. 221, ha disposto (con l'art. 9, comma 3) che "In sede di prima applicazione, i regolamenti di cui all'articolo 52, comma 1, del citato decreto legislativo n. 82 del 2005, come sostituito dal comma 1 del presente articolo, sono pubblicati entro 120 giorni dalla data di entrata in vigore della legge di conversione del presente decreto-legge. Con riferimento ai documenti e ai dati gia' pubblicati, la disposizione di cui all'articolo 52, comma 2, del citato decreto legislativo n. 82 del 2005, trova applicazione entro novanta giorni dalla data di entrata in vigore della legge di conversione del presente decreto."

#### Art. 53.

Siti Internet delle pubbliche amministrazioni

1. Le pubbliche amministrazioni realizzano siti istituzionali su reti telematiche che rispettano i principi di accessibilita', nonche' di elevata usabilita' e reperibilita', anche da parte delle persone disabili, completezza di informazione, chiarezza di linguaggio, affidabilita', semplicita' di' consultazione, qualita', omogeneita' ed interoperabilita'. Sono in particolare resi facilmente reperibili e consultabili i dati di cui all'articolo 54.

1-bis. Le pubbliche amministrazioni pubblicano, ai sensi dell'articolo 9 del decreto legislativo 14 marzo 2013, n. 33, anche il catalogo dei dati e dei metadati ((...)), nonche' delle relative banche dati in loro possesso e i regolamenti che disciplinano l'esercizio della facolta' di accesso telematico e il riutilizzo di tali dati e metadati, fatti salvi i dati presenti in Anagrafe tributaria.

1-ter. Con le ((Linee guida)) sono definite le modalita' per la realizzazione e la modifica dei siti delle amministrazioni.

2. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

3. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

#### Art. 54. - (Contenuto dei siti delle pubbliche amministrazioni)

1. I siti delle pubbliche amministrazioni contengono i dati di cui al decreto legislativo 14 marzo 2013, n. 33, e successive modificazioni, recante il riordino della disciplina riguardante gli obblighi di pubblicita', trasparenza e diffusione di informazioni da parte delle pubbliche amministrazioni ((, nonche' quelli previsti dalla legislazione vigente)).

#### Art. 55.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

#### Art. 56. - Dati identificativi delle questioni pendenti dinanzi autorita' giudiziaria di ogni ordine e grado

1. I dati identificativi delle questioni pendenti dinanzi al giudice amministrativo e contabile sono resi accessibili a chi vi abbia interesse mediante pubblicazione sul sistema informativo interno e sul sito istituzionale ((...)) delle autorita' emananti.

2. Le sentenze e le altre decisioni del giudice amministrativo e contabile, rese pubbliche mediante deposito in segreteria, sono contestualmente inserite nel sistema informativo interno e sul sito istituzionale ((...)), osservando le cautele previste dalla normativa in materia di tutela dei dati personali.

2-bis. I dati identificativi delle questioni pendenti, le sentenze e le altre decisioni depositate in cancelleria o segreteria dell'autorita' giudiziaria di ogni ordine e grado sono, comunque, rese accessibili ai sensi dell'articolo 51 del codice in materia di protezione dei dati personali approvato con decreto legislativo n. 196 del 2003.

#### Art. 57.

((ARTICOLO ABROGATO DAL D.LGS. 14 MARZO 2013, N. 33)).

#### Art. 57-bis.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Sezione II - Fruibilita' dei dati

#### Art. 58.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

#### Art. 59. - Dati territoriali

1. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

2. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

3. Per agevolare la pubblicita' dei dati di interesse generale, disponibili presso le pubbliche amministrazioni a livello nazionale, regionale e locale, presso l'AgID e' istituito il Repertorio nazionale dei dati territoriali, quale infrastruttura di riferimento per l'erogazione dei servizi di ricerca dei dati territoriali, e relativi servizi, e punto di accesso nazionale ai fini dell'attuazione della direttiva 2007/2/CE (direttiva INSPIRE) per quanto riguarda i metadati.

4. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

5. ((Ai)) sensi dell'articolo 71 sono adottate, anche su proposta delle amministrazioni competenti, le regole tecniche per la definizione e l'aggiornamento del contenuto del Repertorio nazionale dei dati territoriali di cui al comma 3 nonche' per la formazione, la documentazione, lo scambio e il riutilizzo dei dati territoriali detenuti dalle amministrazioni stesse.

6. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

7. Agli oneri finanziari di cui al comma 3 si provvede con il fondo di finanziamento per i progetti strategici del settore informatico di cui all'articolo 27, comma 2, della legge 16 gennaio 2003, n. 3.

7-bis. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

#### Art. 60. - Base di dati di interesse nazionale

1. Si definisce base di dati di interesse nazionale l'insieme delle informazioni raccolte e gestite digitalmente dalle pubbliche amministrazioni, omogenee per tipologia e contenuto e la cui conoscenza e' rilevante per lo svolgimento delle funzioni istituzionali delle altre pubbliche amministrazioni, anche solo per fini statistici, nel rispetto delle competenze e delle normative vigenti e possiedono i requisiti di cui al comma 2.

2. Ferme le competenze di ciascuna pubblica amministrazione, le basi di dati di interesse nazionale costituiscono, per ciascuna tipologia di dati, un sistema informativo unitario che tiene conto dei diversi livelli istituzionali e territoriali e che garantisce l'allineamento delle informazioni e l'accesso alle medesime da parte delle pubbliche amministrazioni interessate. Tali sistemi informativi possiedono le caratteristiche minime di sicurezza, accessibilita' e interoperabilita' e sono realizzati e aggiornati secondo le Linee guida e secondo le vigenti regole del Sistema statistico nazionale di cui al decreto legislativo 6 settembre 1989, n. 322, e successive modificazioni.

2-bis. Le pubbliche amministrazioni responsabili delle basi dati di interesse nazionale consentono il pieno utilizzo delle informazioni ai soggetti di cui all'articolo 2, comma 2, secondo standard e criteri di sicurezza e di gestione definiti nelle Linee guida e mediante la piattaforma di cui all'articolo 50-ter.

2-ter. COMMA ABROGATO DAL D.L. 16 LUGLIO 2020, N. 76.

3. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

3-bis. In sede di prima applicazione , sono individuate le seguenti basi di dati di interesse nazionale:

- a) repertorio nazionale dei dati territoriali;
- b) anagrafe nazionale della popolazione residente;
- c) banca dati nazionale dei contratti pubblici di cui all'articolo 62-bis;
- d) casellario giudiziale;
- e) registro delle imprese;
- f) gli archivi automatizzati in materia di immigrazione e di asilo di cui all'articolo 2, comma 2, del decreto del Presidente della Repubblica 27 luglio 2004, n. 242;
- f-bis) Anagrafe nazionale degli assistiti (ANA);
- f-ter) anagrafe delle aziende agricole di cui all'articolo 1, comma 1, del regolamento di cui al decreto del Presidente della Repubblica 1º dicembre 1999, n. 503.
- f-quater) l'archivio nazionale dei veicoli e l'anagrafe nazionale degli abilitati alla guida di cui agli articoli 225 e 226 del decreto legislativo 30 aprile 1992, n. 285; ((38))
- f-quinquies) il sistema informativo dell'indicatore della situazione economica equivalente (ISEE) di cui all'articolo 5 del decreto-legge 6 dicembre 2011, n. 201, convertito, con modificazioni, dalla legge 22 dicembre 2011, n. 214; ((38))
- f-sexies) l'anagrafe nazionale dei numeri civici e delle strade urbane (ANNCSU), di cui all'articolo 3 del decreto-legge 18 ottobre 2012, n. 179 convertito, con modificazioni, dalla legge 17 dicembre 2012, n. 221; ((38))
- f-septies) l'indice nazionale dei domicili digitali delle persone fisiche, dei professionisti e degli altri enti di diritto privato, non tenuti all'iscrizione in albi, elenchi o registri professionali o nel registro delle imprese di cui all'articolo 6-quater. ((38))

3-ter. AgID, tenuto conto delle esigenze delle pubbliche amministrazioni e degli obblighi derivanti dai regolamenti comunitari, individua, aggiorna e pubblica l'elenco delle basi di dati di interesse nazionale, ulteriori rispetto a quelle individuate in via prioritaria dal comma 3-bis. ((38))

4. Agli oneri finanziari di cui al presente articolo si provvede con il fondo di finanziamento per i progetti strategici del settore informatico di cui all'articolo 27, comma 2, della legge 16 gennaio 2003, n. 3.

------------- AGGIORNAMENTO (38) Il D.L. 31 maggio 2021, n. 77, convertito con modificazioni dalla L. 29 luglio 2021, n. 108 ha disposto (con l'art. 39, comma 3) che "Con esclusione della lettera c) del comma 1, l'efficacia delle disposizioni dei commi 1 e 2, i cui oneri sono a carico delle risorse previste per l'attuazione di progetti compresi nel PNRR, resta subordinata alla definitiva approvazione del PNRR da parte del Consiglio dell'Unione europea".

#### Art. 61. - Delocalizzazione dei registri informatici

1. I pubblici registri immobiliari possono essere formati e conservati su supporti informatici in conformita' alle disposizioni del presente codice, secondo le ((Linee guida)), nel rispetto delle normativa speciale e dei principi stabiliti dal codice civile. In tal caso i predetti registri possono essere conservati anche in luogo diverso dall'Ufficio territoriale competente.

#### Art. 62. - (Anagrafe nazionale della popolazione residente - ANPR).

1. E' istituita presso il Ministero dell'interno l'ANPR, quale base di dati di interesse nazionale, ai sensi dell'articolo 60, che subentra all'Indice nazionale delle anagrafi (INA), istituito ai sensi del quinto comma dell'articolo 1 della legge 24 dicembre 1954, n. 1228, recante "Ordinamento delle anagrafi della popolazione residente" e all'Anagrafe della popolazione italiana residente all'estero (AIRE), istituita ai sensi della legge 27 ottobre 1988, n. 470, recante "Anagrafe e censimento degli italiani all'estero" Tale base di dati e' sottoposta ad un audit di sicurezza con cadenza annuale in conformita' alle regole tecniche di cui all'articolo 51. I risultati dell'audit sono inseriti nella relazione annuale del Garante per la protezione dei dati personali.

2. Ferme restando le attribuzioni del sindaco di cui all'articolo 54, comma 3, del testo unico delle leggi sull'ordinamento degli enti locali, approvato con il decreto legislativo 18 agosto 2000, n. 267, l'ANPR subentra altresi' alle anagrafi della popolazione residente e dei cittadini italiani residenti all'estero tenute dai comuni. Con il decreto di cui al comma 6 e' definito un piano per il graduale subentro dell'ANPR alle citate anagrafi, da completare entro il 31 dicembre 2014. Fino alla completa attuazione di detto piano, l'ANPR acquisisce automaticamente in via telematica i dati contenuti nelle anagrafi tenute dai comuni per i quali non e' ancora avvenuto il subentro. L'ANPR e' organizzata secondo modalita' funzionali e operative che garantiscono la univocita' dei dati stessi.

2-bis. L'ANPR contiene altresi' l'archivio nazionale informatizzato dei registri di stato civile tenuti dai comuni garantendo agli stessi, anche progressivamente, i servizi necessari all'utilizzo del medesimo e fornisce i dati ai fini della tenuta delle liste di cui all'articolo 1931 del codice dell'ordinamento militare di cui al decreto legislativo 15 marzo 2010, n. 66, secondo le modalita' definite con uno o piu' decreti di cui al comma 6-bis. Le modalita' e i tempi di adesione da parte dei comuni all'archivio nazionale informatizzato, con conseguente dismissione della versione analogica dei registri di stato civile, sono definiti con uno o piu' decreti di cui al comma 6-bis. (38)

2-ter. Con uno o piu' decreti di cui al comma 6-bis sono definite le modalita' di integrazione nell'ANPR delle liste elettorali e dei dati relativi all'iscrizione nelle liste di sezione di cui al decreto del Presidente della Repubblica 20 marzo 1967, n. 223. (38)

2-quater. I dati relativi alle strade urbane e ai numeri civici contenuti nell'ANPR sono costantemente allineati con i medesimi dati resi disponibili dall'Archivio nazionale dei numeri civici delle strade urbane (ANNCSU), di cui all'articolo 3 del decreto-legge 18 ottobre 2012, n. 179, convertito ((, con modificazioni,)) dalla legge 17 dicembre 2012, n. 221.

3. L'ANPR assicura ai comuni la disponibilita' dei dati, degli atti e degli strumenti per lo svolgimento delle funzioni di competenza statale attribuite al sindaco ai sensi dell'articolo 54, comma 3, del testo unico delle leggi sull'ordinamento degli enti locali di cui al decreto legislativo 18 agosto 2000, n. 267, e mette a disposizione dei comuni un sistema di controllo, gestione e interscambio, puntuale e massivo, di dati, servizi e transazioni necessario ai sistemi locali per lo svolgimento delle funzioni istituzionali di competenza comunale. Al fine dello svolgimento delle proprie funzioni, anche ampliando l'offerta dei servizi erogati on-line a cittadini e imprese, direttamente o tramite soggetti affidatari dei servizi, il Comune puo' utilizzare i dati anagrafici eventualmente detenuti localmente e costantemente allineati con ANPR al fine esclusivo di erogare o usufruire di servizi o funzionalita' non fornite da ANPR. I Comuni accedono alle informazioni anagrafiche contenute nell'ANPR, nel rispetto delle disposizioni in materia di protezione dei dati personali e delle misure di sicurezza definite con decreto del Presidente del Consiglio dei ministri ai sensi del comma 6, lettera a), per l'espletamento, anche con modalita' automatiche, delle verifiche necessarie all'erogazione dei propri servizi e allo svolgimento delle proprie funzioni. L'ANPR consente ai comuni la certificazione dei dati anagrafici nel rispetto di quanto previsto dall'articolo 33 del decreto del Presidente della Repubblica 30 maggio 1989, n. 223, anche in modalita' telematica. La certificazione dei dati anagrafici in modalita' telematica e' assicurata dal Ministero dell'Interno tramite l'ANPR mediante l'emissione di documenti digitali muniti di sigillo elettronico qualificato, ai sensi del Regolamento (UE) n. 910/2014 del Parlamento europeo e del Consiglio, del 23 luglio 2014, esenti da imposta di bollo limitatamente agli anni 2021 e 2022. I comuni inoltre possono consentire, mediante la piattaforma di cui all'articolo 50-ter ovvero anche mediante apposite convenzioni, la fruizione dei dati anagrafici da parte dei soggetti aventi diritto. L'ANPR assicura ai soggetti di cui all'articolo 2, comma 2, lettere a) e b), l'accesso ai dati contenuti nell'ANPR. L'ANPR attribuisce a ciascun cittadino un codice identificativo univoco per garantire la circolarita' dei dati anagrafici e l'interoperabilita' con le altre banche dati delle pubbliche amministrazioni e dei gestori di servizi pubblici di cui all'articolo 2, comma 2, lettere a) e b).

4. Con il decreto di cui al comma 6 sono disciplinate le modalita' di integrazione nell'ANPR dei dati dei cittadini attualmente registrati in anagrafi istituite presso altre amministrazioni nonche' dei dati relativi al numero e alla data di emissione e di scadenza della carta di identita' della popolazione residente.

5. Ai fini della gestione e della raccolta informatizzata di dati dei cittadini, i soggetti di cui all'articolo 2, comma 2, lettere a) e b), si avvalgono esclusivamente dell'ANPR, che viene integrata con gli ulteriori dati a tal fine necessari, o garantiscono un costante allineamento dei propri archivi informatizzati ((, integrati)) con il codice identificativo univoco di cui al ((comma 3,)) con le anagrafiche contenute nell'ANPR.

6. Con uno o piu' decreti del Presidente del Consiglio dei Ministri, su proposta del Ministro dell'interno, del Ministro per la pubblica amministrazione e la semplificazione e del Ministro delegato all'innovazione tecnologica, di concerto con il Ministro dell'economia e delle finanze, d'intesa con l'Agenzia per l'Italia digitale, la Conferenza permanente per i rapporti tra lo Stato, le regioni e le province autonome di Trento e di Bolzano nonche' con la Conferenza Stato - citta', di cui all'articolo 8 del decreto legislativo 28 agosto 1997, n. 281, per gli aspetti d'interesse dei comuni, sentita l'ISTAT e acquisito il parere del Garante per la protezione dei dati personali, sono stabiliti i tempi e le modalita' di attuazione delle disposizioni del presente articolo, anche con riferimento:

- a) alle garanzie e alle misure di sicurezza da adottare nel trattamento dei dati personali, alle modalita' e ai tempi di conservazione dei dati e all'accesso ai dati da parte delle pubbliche amministrazioni per le proprie finalita' istituzionali secondo le modalita' di cui all'articolo (50);
- b) ai criteri per l'interoperabilita' dell'ANPR con le altre banche dati di rilevanza nazionale e regionale, secondo le regole tecniche del sistema pubblico di connettivita' di cui al capo VIII del presente Codice, in modo che le informazioni di anagrafe, una volta rese dai cittadini, si intendano acquisite dalle pubbliche amministrazioni senza necessita' di ulteriori adempimenti o duplicazioni da parte degli stessi;
- c) all'erogazione di altri servizi resi disponibili dall'ANPR, tra i quali il servizio di invio telematico delle attestazioni e delle dichiarazioni di nascita ai sensi dell'articolo 30, comma 4, del decreto del Presidente della Repubblica 3 novembre 2000, n. 396, e della dichiarazione di morte ai sensi degli articoli 72 e 74 dello stesso decreto nonche' della denuncia di morte prevista dall'articolo 1 del regolamento di polizia mortuaria di cui al decreto del Presidente della Repubblica 10 settembre 1990, n. 285, compatibile con il sistema di trasmissione di cui al decreto del Ministro della salute in data 26 febbraio 2010, pubblicato nella Gazzetta Ufficiale n. 65 del 19 marzo 2010.

6-bis. Con uno o piu' decreti del Ministro dell'interno, adottati di concerto con il Ministro per l'innovazione tecnologica e la transizione digitale e il Ministro per la pubblica amministrazione, sentiti il Garante per la protezione dei dati personali e la Conferenza Stato-citta' ed autonomie locali, sono assicurati l'aggiornamento dei servizi resi disponibili dall'ANPR alle pubbliche amministrazioni, agli organismi che erogano pubblici servizi e ai privati, nonche' l'adeguamento e l'evoluzione delle caratteristiche tecniche della piattaforma di funzionamento dell'ANPR. (38) (21)

------------- AGGIORNAMENTO (21) Il D.L. 21 giugno 2013, n. 69, convertito con modificazioni dalla L. 9 agosto 2013, n. 98, nel modificare l'art, 2 comma 1, del D.L. 18 ottobre 2012, n. 179, convertito con modificazioni dalla L. 17 dicembre 2012, n. 221, ha disposto (con l'art. 13, comma 2-ter) che i decreti del Presidente del Consiglio dei ministri previsti dalle disposizioni di cui al presente articolo qualora non ancora adottati e decorsi ulteriori trenta giorni dalla data di entrata in vigore della legge di conversione del presente decreto, sono adottati anche ove non sia pervenuto il concerto dei Ministri interessati. ------------- AGGIORNAMENTO (38) Il D.L. 31 maggio 2021, n. 77, convertito con modificazioni dalla L. 29 luglio 2021, n. 108, ha disposto (con l'art. 39, comma 3) che "Con esclusione della lettera c) del comma 1, l'efficacia delle disposizioni dei commi 1 e 2, i cui oneri sono a carico delle risorse previste per l'attuazione di progetti compresi nel PNRR, resta subordinata alla definitiva approvazione del PNRR da parte del Consiglio dell'Unione europea".

#### Art. 62-bis. - (Banca dati nazionale dei contratti pubblici).

1.Per favorire la riduzione degli oneri amministrativi derivanti dagli obblighi informativi ed assicurare l'efficacia, la trasparenza e il controllo in tempo reale dell'azione amministrativa per l'allocazione della spesa pubblica in lavori, servizi e forniture, anche al fine del rispetto della legalita' e del corretto agire della pubblica amministrazione e prevenire fenomeni di corruzione, si utilizza la "Banca dati nazionale dei contratti pubblici" (BDNCP) ((gestita dall'Autorita' Nazionale Anticorruzione ai sensi dell'articolo 213 del decreto legislativo 18 aprile 2016, n. 50)).

#### Art. 62-ter. - (Anagrafe nazionale degli assistiti).

1. Per rafforzare gli interventi in tema di monitoraggio della spesa del settore sanitario, accelerare il processo di automazione amministrativa e migliorare i servizi per i cittadini e le pubbliche amministrazioni, e' istituita, nell'ambito del sistema informativo realizzato dal Ministero dell'economia e delle finanze in attuazione di quanto disposto dall'articolo 50 del decreto-legge 30 settembre 2003, n. 269, convertito, con modificazioni, dalla legge 24 novembre 2003, n. 326, l'Anagrafe nazionale degli assistiti (ANA).

2. L'ANA, realizzata dal Ministero dell'economia e delle finanze, in accordo con il Ministero della salute in relazione alle specifiche esigenze di monitoraggio dei livelli essenziali di assistenza (LEA), nel rispetto delle previsioni di cui al comma 5 dell'articolo 62 del presente Codice, subentra, per tutte le finalita' previste dalla normativa vigente, alle anagrafi e agli elenchi degli assistiti tenuti dalle singole aziende sanitarie locali, ai sensi dell'articolo 7 della legge 7 agosto 1982, n. 526, che mantengono la titolarita' dei dati di propria competenza e ne assicurano l'aggiornamento.

3. L'ANA assicura alla singola azienda sanitaria locale la disponibilita' dei dati e degli strumenti per lo svolgimento delle funzioni di propria competenza e garantisce l'accesso ai dati in essa contenuti da parte delle pubbliche amministrazioni per le relative finalita' istituzionali, secondo le modalita' di cui ((all'articolo 60, comma 2-bis,)) del presente Codice.

4. Con il subentro dell'ANA, l'azienda sanitaria locale cessa di fornire ai cittadini il libretto sanitario personale previsto dall'articolo 27 della legge 23 dicembre 1978, n. 833. E' facolta' dei cittadini di accedere in rete ai propri dati contenuti nell'ANA, secondo le modalita' di cui al comma 1 dell'articolo 6 del presente Codice, ovvero di richiedere presso l'azienda sanitaria locale competente copia cartacea degli stessi.

5. In caso di trasferimento di residenza del cittadino, l'ANA ne da' immediata comunicazione in modalita' telematica alle aziende sanitarie locali interessate dal trasferimento. L'azienda sanitaria locale nel cui territorio e' compresa la nuova residenza provvede alla presa in carico del cittadino, nonche' all'aggiornamento dell'ANA per i dati di propria competenza. Nessun'altra comunicazione in merito al trasferimento di residenza e' dovuta dal cittadino alle aziende sanitarie locali interessate. (28)

6. L'ANA assicura al nuovo sistema informativo sanitario nazionale realizzato dal Ministero della salute in attuazione di quanto disposto dall'articolo 87 della legge 23 dicembre 2000, n. 388, con le modalita' definite dal decreto del Presidente del Consiglio dei ministri di cui al comma 7, l'accesso ai dati e la disponibilita' degli strumenti funzionali a garantire l'appropriatezza e l'efficacia delle prestazioni di cura erogate al cittadino, nonche' per le finalita' di cui all'articolo 15, comma 25-bis, del decreto-legge 6 luglio 2012, n. 95, convertito, con modificazioni, dalla legge 7 agosto 2012, n. 135. (28)

7. Entro il 30 giugno 2014, con decreto del Presidente del Consiglio dei ministri, su proposta del Ministro della salute e del Ministro dell'economia e delle finanze, previa intesa in sede di Conferenza permanente per i rapporti tra lo Stato, le regioni e le province autonome di Trento e di Bolzano, sono stabiliti:

- a) i contenuti dell'ANA, tra i quali devono essere inclusi ((le scelte del medico di medicina generale e del pediatra di libera scelta)), il codice esenzione e il domicilio;
- b) il piano per il graduale subentro dell'ANA alle anagrafi e agli elenchi degli assistiti tenuti dalle singole aziende sanitarie locali, da completare entro il 30 giugno 2015;
- c) le garanzie e le misure di sicurezza da adottare, i criteri per l'interoperabilita' dell'ANA con le altre banche dati di rilevanza nazionale e regionale, nonche' le modalita' di cooperazione dell'ANA con banche dati gia' istituite a livello regionale per le medesime finalita', nel rispetto della normativa sulla protezione dei dati personali, di cui al decreto legislativo 30 giugno 2003, n. 196, e delle regole tecniche del sistema pubblico di connettivita', ai sensi del presente Codice.

------------ AGGIORNAMENTO (28) Il D.Lgs. 26 agosto 2016, n. 179 ha disposto (con l'art. 61, comma 2, lettera d)) che la parola «cittadino», ovunque ricorra, si intende come «persona fisica».

#### Art. 62-quater. - (( (Anagrafe nazionale dell'istruzione). ))

((

1. Per rafforzare gli interventi nel settore dell'istruzione, accelerare il processo di automazione amministrativa e migliorare i servizi per i cittadini e per le pubbliche amministrazioni, e' istituita, nell'ambito di un apposito sistema informativo denominato hubscuola, realizzato dal Ministero dell'istruzione, l'Anagrafe nazionale dell'istruzione (ANIST).

2. L'ANIST, realizzata dal Ministero dell'istruzione, subentra, per tutte le finalita' previste dalla normativa vigente, alle anagrafi e alle banche di dati degli studenti, dei docenti, del personale amministrativo, tecnico e ausiliario (ATA), delle istituzioni scolastiche e degli edifici scolastici, anche istituite a livello regionale, provinciale e locale per le medesime finalita', che mantengono la titolarita' dei dati di propria competenza e ne assicurano l'aggiornamento.

3. L'ANIST assicura alle regioni, ai comuni e alle istituzioni scolastiche la disponibilita' dei dati e degli strumenti per lo svolgimento delle funzioni di propria competenza, garantisce l'accesso ai dati in essa contenuti da parte delle pubbliche amministrazioni per le relative finalita' istituzionali e mette a disposizione del Ministero dell'interno le informazioni relative ai titoli di studio per il loro inserimento nell'ANPR.

4. Anche ai fini del comma 5 dell'articolo 62, l'ANIST e' costantemente allineata con l'ANPR per quanto riguarda i dati degli studenti e delle loro famiglie, dei docenti e del personale ATA. L'ANIST e' costantemente alimentata con i dati relativi al rendimento scolastico degli studenti attraverso l'interoperabilita' con i registri scolastici di cui all'articolo 7, comma 31, del decreto-legge 6 luglio 2012, n. 95, convertito, con modificazioni, dalla legge 7 agosto 2012, n. 135. L'ANIST, con riferimento alla codifica e al georiferimento dei numeri civici in essa contenuti, e' costantemente aggiornata attraverso l'allineamento con le risultanze dell'Archivio nazionale dei numeri civici delle strade urbane, di cui all'articolo 3 del decreto-legge 18 ottobre 2012, n. 179, convertito, con modificazioni, dalla legge 17 dicembre 2012, n. 221.

5. I cittadini, per consultare i propri dati e ottenere il rilascio di certificazioni, possono accedere all'ANIST con le modalita' di cui al comma 2-quater dell'articolo 64 ovvero tramite il punto di accesso di cui all'articolo 64-bis. L'ANIST rende disponibili i dati necessari per automatizzare le procedure di iscrizione on line alle istituzioni scolastiche di ogni ordine e grado, di cui all'articolo 7, comma 28, del decreto-legge 6 luglio 2012, n. 95, convertito, con modificazioni, dalla legge 7 agosto 2012, n. 135.

6. Con decreto del Ministro dell'istruzione, di concerto con il Ministro per l'innovazione tecnologica e la transizione digitale e con il Ministro per la pubblica amministrazione, da adottare entro il 30 settembre 2021, previa intesa in sede di Conferenza unificata di cui all'articolo 8 del decreto legislativo 28 agosto 1997, n. 281, acquisito il parere del Garante per la protezione dei dati personali, sono stabiliti:

b) le garanzie e le misure di sicurezza da adottare, le modalita' di cooperazione dell'ANIST con banche di dati istituite a livello regionale, provinciale e locale per le medesime finalita', nonche' le modalita' di alimentazione da parte dei registri scolastici di cui all'articolo 7, comma 31, del decreto-legge 6 luglio 2012, n. 95, convertito, con modificazioni, dalla legge 7 agosto 2012, n. 135, nel rispetto della normativa in materia di protezione dei dati personali e delle regole tecniche del sistema pubblico di connettivita'. L'allineamento dell'ANIST con le altre banche di dati di rilevanza nazionale, regionale, provinciale e locale avviene in conformita' alle linee guida adottate dall'AgID in materia di interoperabilita'))

#### Art. 62-quinquies. - (( (Anagrafe nazionale dell'istruzione superiore). ))

((

1. Per rafforzare gli interventi nel settore dell'universita' e della ricerca, accelerare il processo di automazione amministrativa e migliorare i servizi per i cittadini e le pubbliche amministrazioni, e' istituita, a cura del Ministero dell'universita' e della ricerca, l'Anagrafe nazionale dell'istruzione superiore (ANIS).

2. L'ANIS e' alimentata, con le modalita' individuate con il decreto di cui al comma 5, dalle istituzioni della formazione superiore, che mantengono la titolarita' dei dati di propria competenza e ne assicurano l'aggiornamento, nonche' tramite l'Anagrafe nazionale degli studenti, dei diplomati e dei laureati degli istituti tecnici superiori e delle istituzioni della formazione superiore, di cui all'articolo 1-bis del decreto-legge 9 maggio 2003, n. 105, convertito, con modificazioni, dalla legge 11 luglio 2003, n. 170. L'ANIS assicura alla singola istituzione la disponibilita' dei dati e degli strumenti per lo svolgimento delle funzioni di propria competenza e garantisce l'accesso ai dati in essa contenuti da parte delle pubbliche amministrazioni per le relative finalita' istituzionali. L'ANIS rende disponibili i dati necessari per automatizzare le procedure di iscrizione on line alle istituzioni della formazione superiore e assicura l'interoperabilita' con le altre banche di dati di rilevanza nazionale che sono di interesse del Ministero dell'universita' e della ricerca per le relative finalita' istituzionali.

3. Ai sensi del comma 5 dell'articolo 62 del presente codice, l'ANIS e' costantemente allineata con l'ANPR per quanto riguarda i dati degli studenti e dei laureati.

4. I cittadini, per consultare i propri dati e ottenere il rilascio di certificazioni, possono accedere all'ANIS mediante le modalita' di cui al comma 2-quater dell'articolo 64 ovvero tramite il punto di accesso di cui all'articolo 64-bis.

5. Con decreto del Ministro dell'universita' e della ricerca, di concerto con il Ministro per l'innovazione tecnologica e la transizione digitale e con il Ministro per la pubblica amministrazione, da adottare entro il 31 dicembre 2021, acquisito il parere del Garante per la protezione dei dati personali, sono stabiliti:

b) le garanzie e le misure di sicurezza da adottare nonche' le modalita' di alimentazione da parte delle istituzioni della formazione superiore nonche' tramite l'Anagrafe nazionale degli studenti, dei diplomati e dei laureati degli istituti tecnici superiori e delle istituzioni della formazione superiore, nel rispetto della normativa in materia di protezione dei dati personali e delle regole tecniche del sistema pubblico di connettivita'. L'allineamento dell'ANIS con l'Anagrafe nazionale degli studenti, dei diplomati e dei laureati degli istituti tecnici superiori e delle istituzioni della formazione superiore, con l'ANPR e con le altre anagrafi di interesse del Ministero dell'universita' e della ricerca per le relative finalita' istituzionali avviene in conformita' alle linee guida adottate dall'AgID in materia di interoperabilita'))

### Sezione III - ((Identita' digitali, istanze e servizi online))

#### Art. 63.

((ARTICOLO ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217))

#### Art. 64. - Sistema pubblico per la gestione delle identita' digitali e modalita' di accesso ai servizi erogati in rete dalle pubbliche amministrazioni

1. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

2. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

2-bis. Per favorire la diffusione di servizi in rete e agevolare l'accesso agli stessi da parte di cittadini e imprese, anche in mobilita', e' istituito, a cura dell'Agenzia per l'Italia digitale, il sistema pubblico per la gestione dell'identita' digitale di cittadini e imprese (SPID). (28)

2-ter. Il sistema SPID e' costituito come insieme aperto di soggetti pubblici e privati che, previo accreditamento da parte dell'AgID, secondo modalita' definite con il decreto di cui al comma 2-sexies, identificano gli utenti per consentire loro il compimento di attivita' e l'accesso ai servizi in rete.

2-quater. L'accesso ai servizi in rete erogati dalle pubbliche amministrazioni che richiedono identificazione informatica avviene tramite SPID, nonche' tramite la carta di identita' elettronica. Il sistema SPID e' adottato dalle pubbliche amministrazioni nei tempi e secondo le modalita' definiti con il decreto di cui al comma 2-sexies. Resta fermo quanto previsto dall'articolo 3-bis, comma 01.

2-quinquies. Ai fini dell'erogazione dei propri servizi in rete, e' altresi' riconosciuta ai soggetti privati, secondo le modalita' definite con il decreto di cui al comma 2-sexies, la facolta' di avvalersi del sistema SPID per la gestione dell'identita' digitale dei propri utenti, nonche' la facolta' di avvalersi della carta di identita' elettronica. L'adesione al sistema SPID ovvero l'utilizzo della carta di identita' elettronica per la verifica dell'accesso ai propri servizi erogati in rete per i quali e' richiesto il riconoscimento dell'utente esonera i predetti soggetti da un obbligo generale di sorveglianza delle attivita' sui propri siti, ai sensi dell'articolo 17 del decreto legislativo 9 aprile 2003, n. 70.

2-sexies. Con decreto del Presidente del Consiglio dei ministri, su proposta del Ministro delegato per l'innovazione tecnologica e del Ministro per la pubblica amministrazione e la semplificazione, di concerto con il Ministro dell'economia e delle finanze, sentito il Garante per la protezione dei dati personali, sono definite le caratteristiche del sistema SPID, anche con riferimento:

- a) al modello architetturale e organizzativo del sistema;
- b) alle modalita' e ai requisiti necessari per l'accreditamento dei gestori dell'identita' digitale;
- c) agli standard tecnologici e alle soluzioni tecniche e organizzative da adottare anche al fine di garantire l'interoperabilita' delle credenziali e degli strumenti di accesso resi disponibili dai gestori dell'identita' digitale nei riguardi di cittadini e imprese; (28)
- d) alle modalita' di adesione da parte di cittadini e imprese in qualita' di utenti di servizi in rete; (28)
- e) ai tempi e alle modalita' di adozione da parte delle pubbliche amministrazioni in qualita' di erogatori di servizi in rete;
- f) alle modalita' di adesione da parte delle imprese interessate in qualita' di erogatori di servizi in rete.

2-septies. COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217.

2-octies. COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217.

2-nonies. L'accesso di cui al comma 2-quater puo' avvenire anche con la carta nazionale dei servizi.

2-decies. Le pubbliche amministrazioni, in qualita' di fornitori dei servizi, usufruiscono gratuitamente delle verifiche rese disponibili dai gestori di identita' digitali e dai gestori di attributi qualificati.

2-undecies. I gestori dell'identita' digitale accreditati sono iscritti in un apposito elenco pubblico, tenuto da AgID, consultabile anche in via telematica.

2-duodecies. La verifica dell'identita' digitale con livello di garanzia almeno significativo, ai sensi dell'articolo 8, paragrafo 2, del Regolamento (UE) n. 910/2014 del Parlamento e del Consiglio europeo del 23 luglio 2014, produce, nelle transazioni elettroniche o per l'accesso ai servizi in rete, gli effetti del documento di riconoscimento equipollente, di cui all'articolo 35 del testo unico di cui al decreto del Presidente della Repubblica 28 dicembre 2000, n. 445. ((La disposizione di cui al periodo precedente si applica altresi' in caso di identificazione elettronica ai fini dell'accesso ai servizi erogati dalle pubbliche amministrazioni e dai soggetti privati tramite canali fisici)). L'identita' digitale, verificata ai sensi del presente articolo e con livello di sicurezza almeno significativo, attesta gli attributi qualificati dell'utente, ivi compresi i dati relativi al possesso di abilitazioni o autorizzazioni richieste dalla legge ovvero stati, qualita' personali e fatti contenuti in albi, elenchi o registri pubblici o comunque accertati da soggetti titolari di funzioni pubbliche, ((ovvero gli altri dati, fatti e informazioni funzionali alla fruizione di un servizio attestati da un gestore di attributi qualificati,)) secondo le modalita' stabilite da AgID con Linee guida.

3. COMMA ABROGATO DAL D.LGS. 30 DICEMBRE 2010, N. 235. (11)

3-bis. Fatto salvo quanto previsto dal comma 2-nonies, i soggetti di cui all'articolo 2, comma 2, lettera a), utilizzano esclusivamente le identita' digitali SPID e la carta di identita' elettronica ai fini dell'identificazione dei cittadini che accedono ai propri servizi in rete. Con uno o piu' decreti del Presidente del Consiglio dei ministri o del Ministro delegato per l'innovazione tecnologica e la transizione digitale e' stabilita la data a decorrere dalla quale i soggetti di cui all'articolo 2, comma 2, lettera a), utilizzano esclusivamente le identita' digitali SPID, la carta di identita' elettronica e la Carta Nazionale dei servizi per consentire l'accesso delle imprese e dei professionisti ai propri servizi in rete, nonche' la data a decorrere dalla quale i soggetti di cui all'articolo 2, comma 2, lettere b) e c) utilizzano esclusivamente le identita' digitali SPID, la carta di identita' elettronica e la carta Nazionale dei servizi ai fini dell'identificazione degli utenti dei propri servizi on-line.

((3-ter. I gestori dell'identita' digitale accreditati, in qualita' di gestori di pubblico servizio, prima del rilascio dell'identita' digitale a una persona fisica, verificano i dati identificativi del richiedente, ivi inclusi l'indirizzo di residenza e, ove disponibili, il domicilio digitale o altro indirizzo di contatto, mediante consultazione gratuita dei dati disponibili presso l'ANPR di cui all'articolo 62, anche tramite la piattaforma prevista dall'articolo 50-ter. Tali verifiche sono svolte anche successivamente al rilascio dell'identita' digitale, con cadenza almeno annuale, anche ai fini della verifica dell'esistenza in vita. Il direttore dell'AgID, previo accertamento dell'operativita' delle funzionalita' necessarie, fissa la data a decorrere dalla quale i gestori dell'identita' digitale accreditati sono tenuti ad effettuare le verifiche di cui ai precedenti periodi))

------------- AGGIORNAMENTO (11) Il D.L. 29 dicembre 2010, n. 225, convertito con modificazioni dalla L. 26 febbraio 2011, n. 10, ha disposto (con l'art. 1, comma 1), in relazione al comma 3 del presente articolo, che "E' fissato al 31 marzo 2011 il termine di scadenza dei termini e dei regimi giuridici indicati nella tabella 1 allegata con scadenza in data anteriore al 15 marzo 2011". ------------- AGGIORNAMENTO (28) Il D.Lga. 26 agosto 2016, n. 179 ha disposto (con l'art. 61, comma 2, lettera d)) che l'espressione «cittadini e imprese», ovunque ricorra, si intende come «soggetti giuridici».

#### Art. 64-bis. - (Accesso telematico ai servizi della Pubblica Amministrazione)

1. I soggetti di cui all'articolo 2, comma 2, rendono fruibili i propri servizi in rete, in conformita' alle Linee guida, tramite il punto di accesso telematico attivato presso la Presidenza del Consiglio dei ministri, senza nuovi o maggiori oneri per la finanza pubblica.

1-bis. Al fine di rendere effettivo il diritto di cui all'articolo 7, comma 01, i soggetti di cui all'articolo 2, comma 2, i fornitori di identita' digitali e i prestatori dei servizi fiduciari qualificati, in sede di evoluzione, progettano e sviluppano i propri sistemi e servizi in modo da garantire l'integrazione e l'interoperabilita' tra i diversi sistemi e servizi e con i servizi di cui ai commi 1 e 1-ter, espongono per ogni servizio le relative interfacce applicative e, al fine di consentire la verifica del rispetto degli standard e livelli di qualita' di cui all'articolo 7, comma 1, adottano gli strumenti di analisi individuati dall'AgID con le Linee guida.

1-ter. I soggetti di cui all'articolo 2, comma 2, lettera a), rendono fruibili i propri servizi in rete ((, nel rispetto del principio di neutralita' tecnologica,)) tramite applicazione su dispositivi mobili anche attraverso il punto di accesso telematico di cui al presente articolo, salvo impedimenti di natura tecnologica attestati dalla societa' di cui all'articolo 8, comma 2 del decreto-legge 14 dicembre 2018, n. 135, convertito, con modificazioni, dalla legge 11 febbraio 2019, n. 12.

1-quater. I soggetti di cui all'articolo 2, comma 2, lettera a), rendono fruibili tutti i loro servizi anche in modalita' digitale e, al fine di attuare il presente articolo, avviano i relativi progetti di trasformazione digitale entro il 28 febbraio 2021.

1-quinquies. La violazione dell'articolo 64, comma 3-bis e delle disposizioni di cui al presente articolo, costituisce mancato raggiungimento di uno specifico risultato e di un rilevante obiettivo da parte dei dirigenti responsabili delle strutture competenti e comporta la riduzione, non inferiore al 30 per cento della retribuzione di risultato e del trattamento accessorio collegato alla performance individuale dei dirigenti competenti, oltre al divieto di attribuire premi o incentivi nell'ambito delle medesime strutture.

#### Art. 64-ter. - (Piattaforma di gestione deleghe)

1. Il cittadino iscritto ((nell'ANPR)) puo' delegare l'accesso ai servizi in rete erogati dalle pubbliche amministrazioni che richiedono ((l'identificazione informatica a)) non piu' di due soggetti iscritti ((nell'ANPR)), titolari dell'identita' digitale di cui all'articolo 64, comma 2-quater, con livello di sicurezza almeno significativo.

2. ((Il cittadino presenta la delega di cui al comma 1)) tramite la piattaforma di cui al comma 5, mediante una delle modalita' previste dall'articolo 65, comma 1, o recandosi presso gli uffici del comune di residenza. La delega e' revocabile in ogni momento. Il delegante viene puntualmente informato dalla piattaforma di cui ((al comma 5 dell'esercizio)) della delega da parte del delegato.

3. Per i soggetti sottoposti alle forme di tutela previste dal codice civile nei casi di incapacita' totale o parziale a provvedere ai propri interessi, il Ministero della giustizia rende disponibile ((nella piattaforma)) di cui al comma 5, per il tramite della piattaforma di cui all'articolo 50-ter, le informazioni, ove disponibili in formato digitale idoneo, relative alla qualifica di tutore, di curatore o di amministratore di sostegno del soggetto che richiede l'accesso ai servizi in rete quale rappresentante del soggetto tutelato.

4. I gestori di identita' digitale, tramite la piattaforma di cui al comma 5, verificano l'esistenza di eventuali deleghe ((conferite)) al cittadino che effettua l'accesso ai servizi in rete erogati dalle pubbliche amministrazioni.

5. Ai fini di cui al comma 1, l'Istituto Poligrafico e Zecca dello Stato S.p.A. realizza, gestisce e cura la manutenzione della piattaforma per la gestione delle deleghe. L'accesso ai dati attraverso la piattaforma non modifica la disciplina relativa alla titolarita' del trattamento, ferme restando le specifiche responsabilita' ai sensi dell'articolo 28 del regolamento (UE) 2016/679 del Parlamento europeo e del Consiglio, del 27 aprile 2016, in capo all'Istituto Poligrafico e Zecca dello Stato S.p.A., nonche' le responsabilita' dei soggetti che trattano i dati in qualita' di titolari autonomi del trattamento. La realizzazione della piattaforma di cui al primo periodo rientra nel programma «Servizi digitali e cittadinanza digitale» del PNC di cui all'articolo 1, comma 2, lettera a), numero 1), del decreto-legge 6 maggio 2021, n. 59, convertito, con modificazioni, dalla legge 1° luglio 2021, n. 101.

6. Con decreto del Presidente del Consiglio dei ministri ovvero dell'Autorita' politica delegata in materia di innovazione tecnologica, ove nominata, adottato di concerto con il Ministro della giustizia, sentiti il Garante per la protezione dei dati personali e l'Agenzia per la cybersicurezza nazionale, sono definiti le caratteristiche tecniche, l'architettura generale, i requisiti di sicurezza, le modalita' di funzionamento della piattaforma di cui al comma 5, nonche' le tipologie di dati oggetto di trattamento e, in generale, le modalita' e le procedure per assicurare il rispetto dell'articolo 5 del regolamento (UE) 2016/679.

7. Agli oneri derivanti dalla progettazione, realizzazione e graduale messa a disposizione della piattaforma di cui al comma 5, pari a 1.589.784 euro per l'anno 2024 ed a 3.070.216 euro per l'anno 2025, si provvede a valere sulle risorse assegnate, nell'ambito del Fondo complementare al PNRR, per l'Investimento 1.4 della Missione 1, Componente 1 ((,)) di titolarita' della struttura della Presidenza del Consiglio dei ministri competente per l'innovazione tecnologica e la transizione digitale.

#### Art. 64-quater. - (Sistema di portafoglio digitale italiano - Sistema IT-Wallet)

1. Al fine di valorizzare e rafforzare l'interoperabilita' tra le banche dati pubbliche attraverso la Piattaforma Digitale Nazionale Dati (PDND) di cui all'articolo 50-ter, nonche' di favorire la diffusione e l'utilizzo di servizi in rete erogati da soggetti pubblici e privati, e' istituito il Sistema di portafoglio digitale italiano (Sistema IT-Wallet).

2. Il Sistema IT-Wallet e' costituito da una soluzione di portafoglio digitale pubblico (IT-Wallet pubblico), resa disponibile mediante il punto di accesso telematico di cui all'articolo 64-bis, nonche' da soluzioni di portafoglio digitale private (IT-Wallet privato), rese disponibili dai soggetti privati interessati, previo accreditamento da parte dell'AgID, secondo le modalita' di cui al comma 3.

3. Al fine di garantire la necessaria celere evoluzione del Sistema IT-Wallet, con decreto del Presidente del Consiglio dei ministri ovvero dell'Autorita' politica delegata in materia di innovazione tecnologica, ove nominata, adottato su proposta ((dell'AgID)) e di concerto con il Ministro dell'economia e delle finanze e con il Ministro per la pubblica amministrazione, sentite l'Agenzia per la cybersicurezza nazionale, per i profili di competenza, e la Conferenza permanente per i rapporti tra lo Stato, le regioni e le province autonome di Trento e di Bolzano, sono approvate apposite linee guida. Le linee guida di cui al primo periodo, adottate entro sessanta giorni dalla data di entrata in vigore della presente disposizione ((e)) periodicamente aggiornate, definiscono:

- a) le caratteristiche tecniche e le modalita' di adozione dell'IT-Wallet pubblico e delle soluzioni di IT-Wallet privato da parte di cittadini e imprese, nonche' la tipologia di servizi resi disponibili dalle soluzioni IT-Wallet;
- b) le modalita' di accreditamento presso l'AgID dei soggetti privati fornitori delle soluzioni IT- Wallet privato;
- c) i servizi resi disponibili alle pubbliche amministrazioni e ai soggetti privati accreditati, sia in qualita' di erogatori di servizi, sia in qualita' di erogatori di attestazioni elettroniche relative a prerogative, ((deleghe,)) caratteristiche, licenze o qualita' di persone fisiche e giuridiche, per il tramite della piattaforma di cui all'articolo-50-ter;
- d) gli standard tecnici adottati per ((garantire l'interoperabilita')) del Sistema IT-Wallet con le banche dati e i sistemi informativi della pubblica amministrazione e dei soggetti privati accreditati, inclusa la piattaforma di cui all'articolo 50-ter, anche al fine di garantire la compatibilita' dell'IT-Wallet pubblico e delle soluzioni di IT-Wallet privato con precedenti sistemi di identita' digitale e con i relativi sistemi di autenticazione per l'accesso in rete gia' predisposti;
- e) le misure da adottare sul piano tecnico e organizzativo per assicurare livelli di affidabilita', disponibilita' e sicurezza adeguati al Sistema IT-Wallet;
- f) le modalita' per la messa a disposizione del codice sorgente di tutte le componenti dell'IT- Wallet pubblico e delle soluzioni di IT-Wallet privato, ai sensi dell'articolo 69.

4. La societa' di cui all'articolo 8, comma 2, del decreto-legge 14 dicembre 2018, n. 135, convertito, con modificazioni, dalla legge 11 febbraio 2019, n. 12, e la societa' di cui all'articolo 1 del decreto legislativo 21 aprile 1999, n. 116 provvedono, nel rispetto delle linee guida di cui al comma 3 ((del presente articolo)), alla realizzazione e gestione della infrastruttura organizzativa e tecnologica necessaria per l'attuazione del Sistema ((IT-Wallet)), assicurando, in particolare, la disponibilita' dell'IT-Wallet pubblico e dei servizi necessari ai soggetti privati interessati a rendere disponibili soluzioni di IT-Wallet privato. Alla societa' di cui all'articolo 1 del decreto legislativo 21 aprile 1999, n. 116 ((, sono affidate)) la progettazione, la realizzazione, l'implementazione e la gestione dell'infrastruttura tecnologica dei sistemi ((di rilascio nonche' la certificazione)) e la verifica delle attestazioni elettroniche di identita' digitale, di quelle relative a prerogative, ((deleghe,)) caratteristiche, licenze o qualita' presenti nelle banche dati della pubblica amministrazione ((e dei registri)) fiduciari per l'accreditamento dei soggetti coinvolti nei processi di rilascio, certificazione e verifica nonche' per la verifica della validita' e la gestione del ciclo di vita delle attestazioni elettroniche. Agli oneri occorrenti per rendere disponibili da parte degli Identity provider pubblici i servizi di verifica ((di cui al secondo periodo)) del presente comma si provvede a valere sulle risorse disponibili a legislazione vigente.

5. Con decreto del Presidente del Consiglio dei ministri ovvero dell'Autorita' politica delegata in materia di innovazione tecnologica, ove nominata, adottato di concerto con il Ministro dell'economia e delle finanze e con il Ministro per la pubblica amministrazione, sentito il Garante per la protezione dei dati personali per gli aspetti di competenza, sono definiti:

- a) i compiti e le funzioni attribuiti a ciascuna delle societa' di cui al comma 4;
- b) la data a decorrere dalla quale l'IT-Wallet pubblico e' reso disponibile, nonche' il termine entro il quale i soggetti di cui all'articolo 2, comma 2, sono tenuti a rendere disponibili i dati e i documenti relativi a prerogative, ((deleghe,)) caratteristiche, licenze o qualita' di persone fisiche e giuridiche sotto forma di attestazioni elettroniche ovvero a rendere disponibili i dati e i documenti per la generazione di attestazioni elettroniche, nonche' ad avvalersi delle attestazioni elettroniche presenti nelle istanze e nelle dichiarazioni formulate nei loro confronti con esenzione dei controlli di cui al capo V del ((testo unico delle disposizioni legislative e regolamentari in materia di documentazione amministrativa, di cui al)) decreto del Presidente della Repubblica 28 dicembre 2000, n. 445;
- c) la data a decorrere dalla quale i soggetti privati accreditati possono rendere disponibili soluzioni di IT-Wallet privato;
- d) al fine di concorrere alla sostenibilita' economica del Sistema IT-Wallet a regime e ferma restando la gratuita' dell'emissione dell'IT-Wallet pubblico per cittadini e imprese, la tipologia di servizi che possono essere oggetto di remunerazione da parte del titolare del Wallet e dei soggetti privati accreditati in qualita' di erogatori di servizi, incluse le relative indicazioni di costo.

6. Agli oneri derivanti dalla progettazione, realizzazione e graduale messa a disposizione dell'infrastruttura tecnologica per l'attuazione del Sistema IT-Wallet, di cui al comma 4, pari a complessivi 102 milioni di euro per gli anni 2024, 2025 e 2026, si provvede ((,)) quanto a 69 milioni ((di euro,)) a valere sulle risorse assegnate per l'Investimento 1.3 "Dati e interoperabilita'" della Missione 1 "Digitalizzazione, innovazione, competitivita' e cultura", Componente 1 "Digitalizzazione, innovazione e sicurezza nella PA" ((, del PNRR e)), quanto a 33 milioni ((di euro,)) a valere sul Fondo per l'innovazione tecnologica e la digitalizzazione di cui all'articolo 239 del ((decreto-legge)) 19 maggio 2020, n. 34 ((, convertito, con modificazioni,)) dalla legge 17 luglio 2020, n. 77.

7. Nelle more della piena funzionalita' del Sistema ((IT-Wallet)), sono rese disponibili, a richiesta, attraverso il punto di accesso telematico di cui all'articolo 64-bis, le versioni digitali della Tessera sanitaria - Tessera europea di assicurazione di malattia (TS/TEAM), della patente di guida mobile e della Carta europea della disabilita'. La verifica di validita' di tali versioni digitali e' consentita, anche a soggetti terzi, mediante funzionalita' rese disponibili dal punto di accesso telematico. La versione digitale della TS/TEAM e' disponibile secondo le modalita' previste dal regolamento (UE) 2018/1724 del Parlamento europeo e del Consiglio, del 2 ottobre 2018, concernente lo sportello digitale unico. I dati e i documenti necessari per la generazione delle ((versioni digitali della)) patente di guida mobile e della Carta europea della disabilita' sono resi disponibili, rispettivamente, dal Ministero delle infrastrutture e trasporti e dall'Istituto nazionale ((della previdenza sociale)) (INPS) alla societa' di cui all'articolo 1 del decreto legislativo 21 aprile 1999, n. 116, per il tramite della piattaforma ((di cui all'articolo 50-ter del presente codice)). Salvo gli utilizzi previsti ((della TS/TEAM)) in qualita' di Carta Nazionale dei Servizi, la versione digitale della TS/TEAM ha lo stesso valore, per la fruizione di servizi erogati online o in presenza, del documento rilasciato dal Ministero dell'economia e delle finanze su supporto plastificato ai sensi dell'articolo 50 del decreto-legge 30 settembre 2003, n. 269, convertito, con modificazioni, dalla legge 24 novembre 2003, n. 326, e dell'articolo 11, comma 15, del decreto-legge 31 maggio 2010, n. 78, convertito, con modificazioni, dalla legge 30 luglio 2010, n. 122 . La patente di guida mobile e' la versione digitale della patente di guida di cui un conducente residente in Italia ai sensi dell'articolo 118-bis del ((codice della strada, di cui al)) decreto legislativo 30 aprile 1992, n. 285, e' titolare. Tale patente mobile consente la verifica, tramite collegamento con l'anagrafe nazionale degli abilitati alla guida di cui all'articolo 226, comma 10, del citato ((codice di cui al decreto legislativo)) n. 285 del 1992, dell'esistenza e della validita' del diritto alla guida del suo titolare ed e' equipollente a documento di identita' dello stesso. Ai fini della circolazione sul territorio nazionale la patente di guida mobile soddisfa gli obblighi di cui all'articolo 180, comma 1, lettera b), del ((codice di cui al decreto legislativo)) n. 285 del 1992.

#### Art. 65. - Istanze e dichiarazioni presentate alle pubbliche amministrazioni per via telematica

1. Le istanze e le dichiarazioni presentate per via telematica alle pubbliche amministrazioni e ai gestori dei servizi pubblici ai sensi dell'articolo 38, commi 1 e 3, del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445, sono valide:

- a) se sottoscritte mediante una delle forme di cui all'articolo 20;
- b) ovvero, quando l'istante o il dichiarante e' identificato attraverso il sistema pubblico di identita' digitale (SPID), la carta di identita' elettronica o la carta nazionale dei servizi;;
- b-bis) ovvero formate tramite il punto di accesso telematico per i dispositivi mobili di cui all'articolo 64-bis;
- c) ovvero sono sottoscritte e presentate unitamente alla copia del documento d'identita';;
- c-bis) ovvero se trasmesse dall'istante o dal dichiarante dal proprio domicilio digitale iscritto in uno degli elenchi di cui all'articolo 6-bis, 6-ter o 6-quater ovvero, in assenza di un domicilio digitale iscritto, da un indirizzo elettronico eletto presso un servizio di posta elettronica certificata o un servizio elettronico di recapito certificato qualificato, come definito dal Regolamento eIDAS. In tale ultimo caso, ((in assenza)) di un domicilio digitale iscritto, la trasmissione costituisce elezione di domicilio digitale ((speciale, ai sensi dell'articolo 3-bis, comma 4-quinquies, per gli atti e le comunicazioni a cui e' riferita l'istanza o la dichiarazione)). Sono fatte salve le disposizioni normative che prevedono l'uso di specifici sistemi di trasmissione telematica nel settore tributario;

1-bis. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

1-ter. Il mancato avvio del procedimento da parte del titolare dell'ufficio competente a seguito di istanza o dichiarazione inviate ai sensi e con le modalita' di cui al comma 1 comporta responsabilita' dirigenziale e responsabilita' disciplinare dello stesso.

2. Le istanze e le dichiarazioni di cui al comma 1 sono equivalenti alle istanze e alle dichiarazioni sottoscritte con firma autografa apposta in presenza del dipendente addetto al procedimento ;

3. COMMA ABROGATO DAL D.LGS. 30 DICEMBRE 2010, N. 235.

4. Il comma 2 dell'articolo 38 del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445, e' sostituito dal seguente: "2. Le istanze e le dichiarazioni inviate per via telematica sono valide se effettuate secondo quanto previsto dall'articolo 65 del decreto legislativo 7 marzo 2005, n. 82".

## ((...))

### Art. 66. - Carta d'identita' elettronica e carta nazionale dei servizi

1. Le caratteristiche e le modalita' per il rilascio, della carta d'identita' elettronica sono definite ((dal comma 2-bis dell'articolo 7-vicies ter del decreto-legge 31 gennaio 2005, n. 7, convertito, con modificazioni, dalla legge 31 marzo 2005, n. 43)).

2. Le caratteristiche e le modalita' per il rilascio, per la diffusione e l'uso della carta nazionale dei servizi sono definite con uno o piu' regolamenti, ai sensi dell'articolo 17, comma 2, della legge 23 agosto 1988, n. 400, adottati su proposta congiunta dei Ministri per la funzione pubblica e per l'innovazione e le tecnologie, di concerto con il Ministro dell'economia e delle finanze, sentito il Garante per la protezione dei dati personali e d'intesa con la Conferenza unificata di cui all'articolo 8 del decreto legislativo 28 agosto 1997, n. 281, nel rispetto dei seguenti principi:

- a) all'emissione della carta nazionale dei servizi provvedono, su richiesta del soggetto interessato, le pubbliche amministrazioni che intendono rilasciarla;
- b) l'onere economico di produzione e rilascio delle carte nazionale dei servizi e' a carico delle singole amministrazioni che le emettono;
- c) eventuali indicazioni di carattere individuale connesse all'erogazione dei servizi al cittadino, sono possibili nei limiti di cui al decreto legislativo 30 giugno 2003, n. 196; (28)
- d) le pubbliche amministrazioni che erogano servizi in rete devono consentirne l'accesso ai titolari delle carta nazionale dei servizi indipendentemente dall'ente di emissione, che e' responsabile del suo rilascio;
- e) la carta nazionale dei servizi puo' essere utilizzata anche per i pagamenti informatici tra soggetti privati e pubbliche amministrazioni, secondo quanto previsto dalla normativa vigente.

3. La carta d'identita' elettronica e l'analogo documento, rilasciato a seguito della denuncia di nascita e prima del compimento dell'eta' prevista dalla legge per il rilascio della carta d'identita' elettronica, devono contenere:

- a) i dati identificativi della persona;
- b) il codice fiscale.

4. La carta d'identita' elettronica e l'analogo documento, rilasciato a seguito della denuncia di nascita e prima del compimento dell'eta' prevista dalla legge per il rilascio della carta d'identita' elettronica, possono contenere, a richiesta dell'interessato ove si tratti di dati sensibili:

- a) l'indicazione del gruppo sanguigno;
- b) le opzioni di carattere sanitario previste dalla legge;
- c) i dati biometrici indicati col decreto di cui al comma 1, con esclusione, in ogni caso, del DNA;
- d) tutti gli altri dati utili al fine di razionalizzare e semplificare l'azione amministrativa e i servizi resi al cittadino, anche per mezzo dei portali, nel rispetto della normativa in materia di riservatezza; (28)
- e) le procedure informatiche e le informazioni che possono o debbono essere conosciute dalla pubblica amministrazione e da altri soggetti, occorrenti per la firma elettronica.

5. La carta d'identita' elettronica e la carta nazionale dei servizi possono essere utilizzate quali strumenti di autenticazione telematica per l'effettuazione di pagamenti tra soggetti privati e pubbliche amministrazioni, secondo le modalita' stabilite con le Linee guida, sentiti il Ministro dell'economia e delle finanze e la Banca d'Italia.

6. Con decreto del Ministro dell'interno, del Ministro per l'innovazione e le tecnologie e del Ministro dell'economia e delle finanze, sentito il Garante per la protezione dei dati personali e d'intesa con la Conferenza unificata di cui all'articolo 8 del decreto legislativo 28 agosto 1997, n. 281, sono dettate le regole tecniche e di sicurezza relative alle tecnologie e ai materiali utilizzati per la produzione della carta di identita' elettronica, del documento di identita' elettronico e della carta nazionale dei servizi, nonche' le modalita' di impiego.

7. Nel rispetto della disciplina generale fissata dai decreti di cui al presente articolo e delle vigenti disposizioni in materia di protezione dei dati personali, le pubbliche amministrazioni, nell'ambito dei rispettivi ordinamenti, possono sperimentare modalita' di utilizzazione dei documenti di cui al presente articolo per l'erogazione di ulteriori servizi o utilita'.

8. Le tessere di riconoscimento rilasciate dalle amministrazioni dello Stato ai sensi del decreto del Presidente della Repubblica 28 luglio 1967, n. 851, possono essere realizzate anche con modalita' elettroniche, nel rispetto delle Linee guida, e contenere le funzionalita' della carta nazionale dei servizi per consentire l'accesso per via telematica ai servizi erogati in rete dalle pubbliche amministrazioni.

8-bis. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

------------ AGGIORNAMENTO (28) Il D.Lgs. 26 agosto 2016, n. 179 ha disposto (con l'art. 61, comma 2, lettera d)) che la parola «cittadino», ovunque ricorra, si intende come «persona fisica».

## Capo VI - SVILUPPO, ACQUISIZIONE E RIUSO DI SISTEMI INFORMATICI NELLE PUBBLICHE AMMINISTRAZIONI

### Art. 67.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 68. - Analisi comparativa delle soluzioni

1. Le pubbliche amministrazioni acquisiscono programmi informatici o parti di essi nel rispetto dei principi di economicita' e di efficienza, tutela degli investimenti, riuso e neutralita' tecnologica, a seguito di una valutazione comparativa di tipo tecnico ed economico tra le seguenti soluzioni disponibili sul mercato:

- a) software sviluppato per conto della pubblica amministrazione;
- b) riutilizzo di software o parti di esso sviluppati per conto della pubblica amministrazione;
- c) software libero o a codice sorgente aperto;
- d) software fruibile in modalita' cloud computing;
- e) software di tipo proprietario mediante ricorso a licenza d'uso;
- f) software combinazione delle precedenti soluzioni.

1-bis. A tal fine, le pubbliche amministrazioni prima di procedere all'acquisto, secondo le procedure di cui al codice di cui al decreto legislativo ((n. 50 del 2016)), effettuano una valutazione comparativa delle diverse soluzioni disponibili sulla base dei seguenti criteri:

- a) costo complessivo del programma o soluzione quale costo di acquisto, di implementazione, di mantenimento e supporto;
- b) livello di utilizzo di formati di dati e di interfacce di tipo aperto nonche' di standard in grado di assicurare l'interoperabilita' e la cooperazione applicativa tra i diversi sistemi informatici della pubblica amministrazione;
- c) garanzie del fornitore in materia di livelli di sicurezza, conformita' alla normativa in materia di protezione dei dati personali, livelli di servizio tenuto conto della tipologia di software acquisito.

1-ter. Ove dalla valutazione comparativa di tipo tecnico ed economico, secondo i criteri di cui al comma 1-bis, risulti motivatamente l'impossibilita' di accedere a soluzioni gia' disponibili all'interno della pubblica amministrazione, o a software liberi o a codici sorgente aperto, adeguati alle esigenze da soddisfare, e' consentita l'acquisizione di programmi informatici di tipo proprietario mediante ricorso a licenza d'uso. La valutazione di cui al presente comma e' effettuata secondo le modalita' e i criteri definiti dall'AgID.

2. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

2-bis. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

3. ((COMMA ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217)).

4. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179. (28)

------------- AGGIORNAMENTO (28) Il D.Lgs. 26 agosto 2016, n. 179 ha disposto (con l'art. 61, comma 2, lettera d)) che l'espressione «chiunque» ovunque ricorra, si intende come «soggetti giuridici».

### Art. 69. - (Riuso delle soluzioni e standard aperti)

1. Le pubbliche amministrazioni che siano titolari di soluzioni e programmi informatici realizzati su specifiche indicazioni del committente pubblico, hanno l'obbligo di rendere disponibile il relativo codice sorgente, completo della documentazione e rilasciato in repertorio pubblico sotto licenza aperta, in uso gratuito ad altre pubbliche amministrazioni o ai soggetti giuridici che intendano adattarli alle proprie esigenze, salvo motivate ragioni di ordine e sicurezza pubblica, difesa nazionale e consultazioni elettorali.

2. Al fine di favorire il riuso dei programmi informatici di proprieta' delle pubbliche amministrazioni, ai sensi del comma 1, nei capitolati o nelle specifiche di progetto e' previsto, ((salvo che cio' risulti eccessivamente oneroso per comprovate ragioni di carattere tecnico-economico, che l'amministrazione committente sia sempre titolare di tutti i diritti sui programmi e i servizi delle tecnologie dell'informazione e della comunicazione, appositamente sviluppati per essa)).

((

2-bis. Al medesimo fine di cui al comma 2, il codice sorgente, la documentazione e la relativa descrizione tecnico funzionale di tutte le soluzioni informatiche di cui al comma 1 sono pubblicati attraverso una o piu' piattaforme individuate dall'AgID con proprie Linee guida.

))

### Art. 70.

((ARTICOLO ABROGATO DAL D.LGS. 13 DICEMBRE 2017, N. 217))

## Capo VII - REGOLE TECNICHE

### Art. 71. - Regole tecniche

((

1. L'AgID, previa consultazione pubblica da svolgersi entro il termine di trenta giorni, sentiti le amministrazioni competenti e il Garante per la protezione dei dati personali nelle materie di competenza, nonche' acquisito il parere della Conferenza unificata, adotta Linee guida contenenti le regole tecniche e di indirizzo per l'attuazione del presente Codice. Le Linee guida divengono efficaci dopo la loro pubblicazione nell'apposita area del sito Internet istituzionale dell'AgID e di essa ne e' data notizia nella Gazzetta Ufficiale della Repubblica italiana. Le Linee guida sono aggiornate o modificate con la procedura di cui al primo periodo.

))

1-bis. COMMA ABROGATO DAL D.LGS. 30 DICEMBRE 2010, N. 235.

1-ter. Le regole tecniche di cui al presente codice sono dettate in conformita' ai requisiti tecnici di accessibilita' di cui all'articolo 11 della legge 9 gennaio 2004, n. 4, alle discipline risultanti dal processo di standardizzazione tecnologica a livello internazionale ed alle normative dell'Unione europea.

2. COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179.

## Capo VIII - ((SISTEMA PUBBLICO DI CONNETTIVITA'))

### Art. 72.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 73. - Sistema pubblico di connettivita' (SPC)

1. Nel rispetto dell'articolo 117, secondo comma, lettera r), della Costituzione, e nel rispetto dell'autonomia dell'organizzazione interna delle funzioni informative delle regioni e delle autonomie locali il presente Capo definisce e disciplina il Sistema pubblico di connettivita' (( e cooperazione (SPC), quale insieme di infrastrutture tecnologiche e di regole tecniche che assicura l'interoperabilita' tra i sistemi informativi delle pubbliche amministrazioni, permette il coordinamento informativo e informatico dei dati tra le amministrazioni centrali, regionali e locali e tra queste e i sistemi dell'Unione europea ed e' aperto all'adesione da parte dei gestori di servizi pubblici e dei soggetti privati.))

((

2. Il SPC garantisce la sicurezza e la riservatezza delle informazioni, nonche' la salvaguardia e l'autonomia del patrimonio informativo di ciascun soggetto aderente.

))

3. La realizzazione del SPC avviene nel rispetto dei seguenti principi: ((a) sviluppo architetturale e organizzativo atto a garantire la federabilita' dei sistemi;)) b) economicita' nell'utilizzo dei servizi di rete, di interoperabilita' e di supporto alla cooperazione applicativa; ((b-bis) aggiornamento continuo del sistema e aderenza alle migliori pratiche internazionali;)) c) sviluppo del mercato e della concorrenza nel settore delle tecnologie dell'informazione e della comunicazione. (1)

3-bis. ((COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179)).

((

3-ter. Il SPC e' costituito da un insieme di elementi che comprendono:

- a) infrastrutture, architetture e interfacce tecnologiche;
- b) linee guida e regole per la cooperazione e l'interoperabilita';
- c) catalogo di servizi e applicazioni.

3-quater. Ai sensi dell'articolo 71 sono dettate le regole tecniche del Sistema pubblico di connettivita' e cooperazione, al fine di assicurarne: l'aggiornamento rispetto alla evoluzione della tecnologia; l'aderenza alle linee guida europee in materia di interoperabilita'; l'adeguatezza rispetto alle esigenze delle pubbliche amministrazioni e dei suoi utenti; la piu' efficace e semplice adozione da parte di tutti i soggetti, pubblici e privati, il rispetto di necessari livelli di sicurezza.))

------------ AGGIORNAMENTO (1) Il D.Lgs. 4 aprile 2006, n. 159 ha disposto (con l'art. 31, comma 1) che nel presente decreto legislativo l'espressione "Capo VIII" e' sostituita dalla seguente: "Capo IX" e conseguentemente la numerazione degli articoli da 72 a 76 e' sostituita dalla numerazione progressiva da 88 a 92.

### Art. 74.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 75. - Partecipazione al Sistema pubblico di connettivita'

((

1. I soggetti di cui all'articolo 2, comma 2, partecipano al SPC, salve le esclusioni collegate all'esercizio delle funzioni di ordine e sicurezza pubblica, difesa nazionale, consultazioni elettorali.

2. Chiunque puo' partecipare al SPC nel rispetto delle regole tecniche di cui all'articolo 73, comma 3-quater.

3. AgID rende gratuitamente disponibili specifiche delle interfacce tecnologiche, le linee guida, le regole di cooperazione e ogni altra informazione necessaria a garantire l'interoperabilita' del SPC con ogni soluzione informatica sviluppata autonomamente da privati o da altre amministrazioni che rispettano le regole definite ai sensi dell'articolo 73, comma 3-quater.

))

3-bis. ((COMMA ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179)).

------------ AGGIORNAMENTO (1) Il D.Lgs. 4 aprile 2006, n. 159 ha disposto (con l'art. 31, comma 1) che nel presente decreto legislativo l'espressione "Capo VIII" e' sostituita dalla seguente: "Capo IX" e conseguentemente la numerazione degli articoli da 72 a 76 e' sostituita dalla numerazione progressiva da 88 a 92.

### Art. 76. - Scambio di documenti informatici nell'ambito del Sistema pubblico diconnettivita'

1. Gli scambi di documenti informatici ((...)) nell'ambito del SPC, realizzati attraverso la cooperazione applicativa e nel rispetto delle relative procedure e regole tecniche di sicurezza, costituiscono invio documentale valido ad ogni effetto di legge. (1)

------------ AGGIORNAMENTO (1) Il D.Lgs. 4 aprile 2006, n. 159 ha disposto (con l'art. 31, comma 1) che nel presente decreto legislativo l'espressione "Capo VIII" e' sostituita dalla seguente: "Capo IX" e conseguentemente la numerazione degli articoli da 72 a 76 e' sostituita dalla numerazione progressiva da 88 a 92.

### Art. 76-bis. - (( (Costi del SPC).))

((

1. I costi relativi alle infrastrutture nazionali per l'interoperabilita' sono a carico dei fornitori, per i servizi da essi direttamente utilizzati e proporzionalmente agli importi dei relativi contratti di fornitura e una quota di tali costi e' a carico delle pubbliche amministrazioni relativamente ai servizi da esse utilizzati. L'eventuale parte del contributo di cui all'articolo 18, comma 3, del decreto legislativo 1° dicembre 2009, n. 177, che eccede la copertura dei costi diretti e indiretti, comprensivi di rimborsi per eventuali attivita' specificamente richieste dalla Consip ad AgID in relazione alle singole procedure, sostenuti dalla stessa Consip per le attivita' di centrale di committenza di cui all'articolo 4, comma 3-quater, del decreto-legge 6 luglio 2012, n. 95, convertito, con modificazioni, dalla legge 7 agosto 2012, n. 135, e' destinata a parziale copertura della quota dei costi relativi alle infrastrutture nazionali gestite da AgID.

))

### Art. 77.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 78.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 79.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 80.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 81.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 82.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 83.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 84.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 85.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 86.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 87.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

## ((Capo IX)) DISPOSIZIONI TRANSITORIE FINALI E ABROGAZIONI

### Art. 88.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 89.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))

### Art. 90. - Oneri finanziari

1. All'attuazione del ((presente Codice)) si provvede nell'ambito delle risorse previste a legislazione vigente.(1)

------------ AGGIORNAMENTO (1) Il D.Lgs. 4 aprile 2006, n. 159 ha disposto (con l'art. 31, comma 1) che nel presente decreto legislativo l'espressione "Capo VIII" e' sostituita dalla seguente: "Capo IX" e conseguentemente la numerazione degli articoli da 72 a 76 e' sostituita dalla numerazione progressiva da 88 a 92.

### Art. 91. - Abrogazioni

1. Dalla data di entrata in vigore del presente testo unico sono abrogati:

- a) il decreto legislativo 23 gennaio 2002, n. 10;
- b) gli articoli 1, comma 1, lettere t), u), v), z), aa), bb), cc), dd), ee), ff), gg), hh), ii), ll), mm), nn), oo); 2, comma 1, ultimo periodo, 6; 8; 9; 10; 11; 12; 13; 14; 17; 20; 22; 23; 24; 25; 26; 27; 27-bis; 28; 28-bis; 29; 29-bis; 29-ter; 29-quater; 29-quinquies; 29-sexies; 29-septies; 29-octies; 36, commi 1, 2, 3, 4, 5 e 6; 51; del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445 (Testo A);
- c) l'articolo 26 comma 2, lettera a), e), h), della legge 27 dicembre 2002, n. 289;
- d) articolo 27, comma 8, lettera b), della legge 16 gennaio 2003, n. 3; ;
- e) gli articoli 16, 17, 18 e 19 della legge 29 luglio 2003, n. 229.

2. Le abrogazioni degli articoli 2, comma 1, ultimo periodo, 6, commi 1 e 2; 10; 36, commi 1, 2, 3, 4, 5 e 6; del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445 (Testo A), si intendono riferite anche al decreto legislativo 28 dicembre 2000, n. 443 (Testo B).

3. Le abrogazioni degli articoli 1, comma 1, lettere t), u), v), z), aa), bb), cc), dd), ee), ff), gg), hh), ii), ll), mm), nn), oo); 6, commi 3 e 4; 8; 9; 11; 12; 13; 14; 17; 20; 22; 23; 24; 25; 26; 27; 27-bis; 28; 28-bis; 29; 29-bis; 29-ter; 29-quater; 29-quinquies; 29-sexies; 29-septies; 29-octies; 51; del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445 (Testo A), si intendono riferite anche al decreto del Presidente della Repubblica 28 dicembre 2000, n. 444 (Testo C).

((

3-bis. L'articolo 15, comma 1, della legge 15 marzo 1997, n. 59, e' abrogato.

3-ter. Il decreto legislativo 28 febbraio 2005, n. 42, e' abrogato.))

------------ AGGIORNAMENTO (1) Il D.Lgs. 4 aprile 2006, n. 159 ha disposto (con l'art. 31, comma 1) che nel presente decreto legislativo l'espressione "Capo VIII" e' sostituita dalla seguente: "Capo IX" e conseguentemente la numerazione degli articoli da 72 a 76 e' sostituita dalla numerazione progressiva da 88 a 92.

### Art. 92.

((ARTICOLO ABROGATO DAL D.LGS. 26 AGOSTO 2016, N. 179))


"""Tests for state management"""

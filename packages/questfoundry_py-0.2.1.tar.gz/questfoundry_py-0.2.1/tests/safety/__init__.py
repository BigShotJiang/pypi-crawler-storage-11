"""Tests for safety module."""

"""Tests for quality bars."""

from .impl import SpacyAnonymizerInterceptor

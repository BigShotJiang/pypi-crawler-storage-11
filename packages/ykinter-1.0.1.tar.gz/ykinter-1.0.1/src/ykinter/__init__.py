"""
一个极简的Python GUI库
基于tkinter，让GUI开发变得简单易用
"""

from .core import SimpleGUI
from .widgets import WidgetFactory
from .layout import LayoutManager
from .styles import StyleManager
from .dialogs import DialogManager
from .components import FormField, LoginForm, DataTable, ProgressDialog, CardWidget
from .utils import Validation, FileHandler

# 版本信息
__version__ = "1.0.1"
__author__ = "王子毅"

# 导出主要类
__all__ = [
    'SimpleGUI', 
    'WidgetFactory', 
    'LayoutManager', 
    'StyleManager',
    'DialogManager',
    'FormField',
    'LoginForm', 
    'DataTable', 
    'ProgressDialog', 
    'CardWidget',
    'Validation',
    'FileHandler'
]

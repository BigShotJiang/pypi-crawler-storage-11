<!-- Copyright Contributors to the Qiskit project. -->

# Code of Conduct
All members of this project agree to adhere to the [Qiskit Code of Conduct](https://github.com/Qiskit/qiskit/blob/main/CODE_OF_CONDUCT.md).

----

License: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/),
Copyright Contributors to Qiskit.

class CeleryWorkerError(Exception):
    pass

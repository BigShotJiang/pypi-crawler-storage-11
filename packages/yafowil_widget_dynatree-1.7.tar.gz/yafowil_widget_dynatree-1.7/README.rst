This is a **tree widget** for `YAFOWIL
<http://pypi.python.org/pypi/yafowil>`_ - Yet Another Form WIdget Library.

The tree-widget for yafowil utilizes the jQuery plugin `jquery.dynatree.js
<http://wwwendt.de/tech/dynatree/index.html>`_ (at
`google-code <http://code.google.com/p/dynatree/>`_).

- `Documentation <http://docs.yafowil.info/en/latest/blueprints.html#dynatree>`_
- `DEMO - see it Live <http://demo.yafowil.info/++widget++yafowil.widget.dynatree/index.html>`_


Source Code
===========

The sources are in a GIT DVCS with its main branches at
`github <http://github.com/conestack/yafowil.widget.dynatree>`_.

We'd be happy to see many forks and pull-requests to make YAFOWIL even better.


Contributors
============

- Jens Klein

- Robert Niederreiter

- Georg Bernhard

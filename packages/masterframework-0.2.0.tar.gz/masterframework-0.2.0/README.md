# Master Project 

Exposé Masterarbeit

Möglicher Titel: Entwicklung eines Frameworks und von Methoden zur Evaluierung und

Sicherheitshärtung von Large Language Models für die Codegenerierung

Problemstellung

Die Nutzung von Large Language Models zur automatisierten Codegenerierung gewinnt

zunehmend an Bedeutung und findet in allen möglichen Bereichen der Softwareentwicklung

Anwendung. Neben den vielen neuen Möglichkeiten, welche dadurch entstehen, gibt es auch

einige Herausforderungen, die beachtet werden müssen.

Durch den wachsenden Einsatz von LLMs stellt sich immer häufiger die Frage nach der

Sicherheit des automatisch generierten Codes und die Notwendigkeit, die Sicherheit von

diesem zu gewährleisten. Aktuelle Untersuchungen zeigen, dass alle dort existierenden Modelle

regelmäßig gängige Schwachstellen im generierten Code enthalten. Dies liegt unter anderem

daran, dass sie mit großen Mengen öffentlich zugänglichen Codes trainiert wurden, der

potenziell unsichere Implementierungen enthält. Besonders kritisch wird dies vor allem dann,

wenn Anwender ein übermäßiges Vertrauen, in den von LLM generierten Code haben und

diesen, ohne ihn zu überprüfen verwenden. Gerade bei Anfängern oder Personen ohne einen

Informatikhintergrund, ist es wichtig, dass der erzeugte Code nicht bereits Schwachstellen oder

unsichere Vorgehensweisen enthält. Aufgrund der laut Studien dort noch bestehenden

Sicherheitsbedenken, ist es wichtig Möglichkeiten und Methoden zu finden die die Sicherheit

des generierten Codes verbessern. Zwar existieren bereits erste Ansätze zur Härtung von LLMs

für sichere Codegenerierung, jedoch zeigen bisherige Arbeiten, dass viele Schwachstellen

weiterhin reproduziert werden und die bestehenden Ansätze nicht gezielt auf

sicherheitskritische Bereiche wie Web-Schwachstellen (z. B. OWASP-Kategorien) fokussiert

sind.

Zielsetzung und Vorgehen

Das Hauptziel dieser Arbeit ist es, Methoden zur Verbesserung der Sicherheit von LLM

generiertem Code im Bereich der Webentwicklung zu erforschen, zu bewerten und in einem

Framework umzusetzen. Insbesondere soll untersucht werden, wie sich Sicherheitsprobleme im

Kontext der OWASP Top 10 durch Optimierungen reduzieren lassen. Dafür soll ein Framework

entwickelt werden, mit welchem sich LLMs in Bezug auf Sicherheit evaluieren und vergleichen

lassen. Das Framework hat das Ziel eine systematische Möglichkeit zu bieten Experimente mit

LLMs durchzuführen, Verbesserungen an diesen zu testen und Metriken zur Auswertung zu

erheben.

Dafür soll dieses Framework eine flexible Architektur bieten, die es ermöglicht, verschiedene

Modelle und Optimierungstechniken zu integrieren und zukünftige Entwicklungen und neue

Modelle im Bereich der Codegenerierung möglichst schnell und einfach berücksichtigen zu

können. Das Framework wird programmiersprachenunabhängig konzipiert und exemplarisch für

Python und JavaScript implementiert, um zu überprüfen, ob durchgeführte Verbesserungen

auch auf andere Sprachen übertragbar sind. Zum Training und zur Auswertung werden Aufgaben

verwendet, die in der Lage sind, gängige und problematische Schwachstellen im Web Bereich zu

erzeugen.

Im Rahmen dieser Arbeit sollen verschiedene neue Verbesserungsansätze zur sicheren

Anton Müller

Exposé Masterarbeit

Codegenerierung entwickelt und analysiert werden. Die Wirksamkeit dieser Ansätze wird

anschließend durch Experimente evaluiert. Für die Experimente werden aktuelle Modelle

verwendet, wobei das Framework die Integration beliebiger Modelle erlaubt.

Zu den untersuchten Verbesserungsmethoden gehören unter anderem Retrieval Augmented

Generation (RAG), Fine-Tuning durch überwachtes und unüberwachtes Lernen mit Techniken

wie DPO und GRPO sowie die Nutzung von Feedback durch Analysewerkzeuge. Außerdem soll

getestet werden, inwiefern eine Kombination mehrerer Ansätze (RAG + Fine Tuning) zu weiteren

Verbesserungen führen kann.

Forschungsfragen: - - - - - -

Was sind die aktuellen Probleme und Ansätze bei der Sicheren Codegenerierung und

was fehlt dort noch?

Wie gut können die Vorgeschlagenen Methoden dabei helfen Schwachstellen in

generiertem Code zu vermeiden?

Inwiefern verbessert die Kombination von Methoden die Sicherheit im Vergleich zu

einzelnen Methoden?

Wie gut schneidet ein angepasstes Modell mit einer anderen Programmiersprache ab?

Wie kann ein flexibles Framework zur systematischen Evaluierung und Verbesserung der

Sicherheit von LLM-generiertem Code gestaltet werden?

Welche Metriken eignen sich am besten zur Bewertung der Sicherheit von LLM

generiertem Code?
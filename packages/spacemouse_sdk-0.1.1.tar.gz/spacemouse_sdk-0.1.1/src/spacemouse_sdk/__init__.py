"""
Spacemouse SDK - A Python SDK for spacemouse functionality.

This package provides tools and utilities for working with spacemouse devices.
"""

__version__ = "0.1.1"
__author__ = "Simon Fall"
__email__ = "your.email@example.com"

from .client import SpacemouseClient
from .exceptions import SpacemouseError, SpacemouseConnectionError

__all__ = [
    "SpacemouseClient",
    "SpacemouseError", 
    "SpacemouseConnectionError",
]
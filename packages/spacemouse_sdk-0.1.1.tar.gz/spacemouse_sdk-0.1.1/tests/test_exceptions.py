"""
Tests for spacemouse exceptions.
"""

import pytest

from spacemouse_sdk.exceptions import (
    SpacemouseError,
    SpacemouseConnectionError, 
    SpacemouseDeviceNotFoundError,
    SpacemouseConfigurationError
)


class TestSpacemouseExceptions:
    """Test cases for spacemouse custom exceptions."""

    def test_spacemouse_error_base(self):
        """Test base SpacemouseError exception."""
        message = "Base error message"
        error = SpacemouseError(message)
        
        assert str(error) == message
        assert isinstance(error, Exception)

    def test_spacemouse_connection_error(self):
        """Test SpacemouseConnectionError exception."""
        message = "Connection failed"
        error = SpacemouseConnectionError(message)
        
        assert str(error) == message
        assert isinstance(error, SpacemouseError)
        assert isinstance(error, Exception)

    def test_spacemouse_device_not_found_error(self):
        """Test SpacemouseDeviceNotFoundError exception."""
        message = "Device not found"
        error = SpacemouseDeviceNotFoundError(message)
        
        assert str(error) == message
        assert isinstance(error, SpacemouseError)
        assert isinstance(error, Exception)

    def test_spacemouse_configuration_error(self):
        """Test SpacemouseConfigurationError exception.""" 
        message = "Invalid configuration"
        error = SpacemouseConfigurationError(message)
        
        assert str(error) == message
        assert isinstance(error, SpacemouseError)
        assert isinstance(error, Exception)

    def test_exception_inheritance_chain(self):
        """Test that all exceptions properly inherit from base classes."""
        exceptions = [
            SpacemouseConnectionError("test"),
            SpacemouseDeviceNotFoundError("test"),
            SpacemouseConfigurationError("test")
        ]
        
        for exc in exceptions:
            assert isinstance(exc, SpacemouseError)
            assert isinstance(exc, Exception)

    def test_exceptions_can_be_raised_and_caught(self):
        """Test that exceptions can be properly raised and caught."""
        # Test raising and catching specific exception
        with pytest.raises(SpacemouseConnectionError):
            raise SpacemouseConnectionError("Connection test")
            
        # Test catching as base exception
        with pytest.raises(SpacemouseError):
            raise SpacemouseDeviceNotFoundError("Device test")
            
        # Test catching as generic Exception
        with pytest.raises(Exception):
            raise SpacemouseConfigurationError("Config test")
# -*- coding:utf-8 -*-
"""
@Author   : g1879
@Contact  : g1879@qq.com
@Website  : https://gitcode.com/g1879/TimePinner
@Copyright: (c) 2020 by g1879, Inc. All Rights Reserved.
"""
from time import perf_counter


class Pinner(object):
    def __init__(self, pin=False, show_everytime=True):
        self.times = []
        self.show_everytime = show_everytime
        if pin:
            self.pin('起始点')

    def pin(self, text='', all_time=False, show=None):
        now = perf_counter()
        num = 0 if all_time else -1
        prev = self.times[num][0] if self.times else now
        self.times.append((now, text))
        gap = now - prev

        if show is True or (self.show_everytime and show is None):
            p_text = f'{text}：' if text else ''
            print(f'{p_text}{gap}')

        return gap

    def skip(self):
        self.times.append((perf_counter(), False))

    def show(self, all_time=False):
        for k in self.records(all_time):
            print(f'{k[0]}：{k[1]}')

    def reset(self, text='', show=None):
        self.times = []
        self.pin(text or '起始点', show)

    def records(self, all_time=False):
        if all_time:
            return [(self.times[k][1] or f't{k}', self.times[k][0] - self.times[0][0])
                    for k in range(1, len(self.times)) if self.times[k][1] is not False]
        else:
            return [(self.times[k][1] or f't{k}', self.times[k][0] - self.times[k - 1][0])
                    for k in range(1, len(self.times)) if self.times[k][1] is not False]

    def winner(self, all_time=False):
        ts = sorted(self.records(all_time), key=lambda x: x[1])
        return ts[0] if ts else None

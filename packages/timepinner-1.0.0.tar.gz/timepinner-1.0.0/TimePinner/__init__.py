# -*- coding:utf-8 -*-
"""
@Author   : g1879
@Contact  : g1879@qq.com
@Website  : https://gitcode.com/g1879/TimePinner
@Copyright: (c) 2020 by g1879, Inc. All Rights Reserved.
"""
from .time_pinner import Pinner

__version__ = '1.0.0'

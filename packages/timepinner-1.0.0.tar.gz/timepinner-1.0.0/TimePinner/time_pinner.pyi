# -*- coding:utf-8 -*-
"""
@Author   : g1879
@Contact  : g1879@qq.com
@Website  : https://gitcode.com/g1879/TimePinner
@Copyright: (c) 2020 by g1879, Inc. All Rights Reserved.
"""
from typing import Union


class Pinner(object):
    """用于记录时间间隔的工具"""
    times: list
    show_everytime: bool

    def __init__(self, pin: bool = False, show_everytime: bool = True) -> None:
        """
        :param pin: 初始化时是否记录一个时间点
        :param show_everytime: 是否每次记录时打印时间差
        """
        ...

    def pin(self, text: str = '', all_time: bool = False, show: bool = None) -> float:
        """记录一个时间点
        :param text: 记录点说明文本
        :param all_time: 时间点与起始点的时间差，或时间点之间的时间差
        :param show: 是否打印时间差
        :return: 返回时间差
        """
        ...

    def skip(self) -> None:
        """跳过从上一个时间点到当前的时间"""
        ...

    def show(self, all_time: bool = False) -> None:
        """打印所有时间差
        :param all_time: 每个时间点与起始点的时间差，或时间点之间的时间差
        :return: None
        """
        ...

    def reset(self, text: str = '', show: bool = None) -> None:
        """清空重新开始记录
        :param text: 记录点说明文本，不传入默认为“起始点”
        :param show: 是否打印信息
        :return: None
        """
        ...

    def records(self, all_time: bool = False) -> list:
        """返回所有时间差组成的列表
        :param all_time: 每个时间点与起始点的时间差，或时间点之间的时间差
        :return: 时间节点列表
        """
        ...

    def winner(self, all_time: bool = False) -> Union[tuple, None]:
        """返回最短的时间差
        :param all_time: 每个时间点与起始点的时间差，或时间点之间的时间差
        :return: 标签与时间组成的tuple
        """
        ...

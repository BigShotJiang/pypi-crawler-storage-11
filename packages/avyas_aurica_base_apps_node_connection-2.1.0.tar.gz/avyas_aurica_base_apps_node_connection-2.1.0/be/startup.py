"""
Startup handler for node-connection app
This module is automatically called when the app is loaded
"""
import asyncio
from pathlib import Path
import sys
import os

# Add app directory to path for imports
node_be_dir = Path(__file__).parent
if str(node_be_dir) not in sys.path:
    sys.path.insert(0, str(node_be_dir))

from node_manager import get_node_manager
from node_registry import initialize_registry, get_registry


async def startup():
    """
    Startup routine - called when app is loaded
    
    1. Initializes node registry (for API domain)
    2. Connects to API domain and establishes connection
    3. Registers this node with the API domain (if execution node)
    """
    print("🔌 Node Connection Manager: Starting up...")
    
    try:
        # Initialize registry
        registry = initialize_registry()
        print("✅ Node registry initialized")
        
        # Initialize node manager
        manager = get_node_manager()
        success = await manager.startup()
        
        if success:
            print("✅ Node Connection Manager: Successfully connected to API domain")
            status = manager.get_status()
            print(f"   📍 Node ID: {status['node_id']}")
            print(f"   🌐 API Domain: {status['api_domain']}")
            print(f"   🟢 Status: {'Connected' if status['connected'] else 'Disconnected'}")
            print("   🔐 Using existing JWT authentication system")
            
            # If this is an execution node (not the API domain itself), register it
            await register_with_api_domain(manager)
        else:
            print("⚠️  Node Connection Manager: Failed to connect to API domain")
        
        return success
    except Exception as e:
        print(f"❌ Error during startup: {e}")
        import traceback
        traceback.print_exc()
        return False


async def register_with_api_domain(manager):
    """
    Register this execution node with the API domain.
    
    This sends node connection details to the API domain so it can
    be discovered and managed remotely.
    """
    import httpx
    
    # Check if we're running as an execution node (not the API domain)
    api_domain = manager.config.api_domain
    status = manager.get_status()
    node_id = status['node_id']
    
    # Determine current host
    current_host = os.environ.get("HOST", "localhost")
    current_port = os.environ.get("PORT", "8000")
    
    # Check if we're running on the production API domain
    is_production_api = "api.oneaurica.com" in current_host or "oneaurica.com" in os.environ.get("HOSTNAME", "")
    
    # If we ARE the production API domain, skip self-registration
    if is_production_api:
        print(f"   ℹ️  Running on production API domain - skipping self-registration")
        return
    
    # This is an execution node (localhost or other remote node)
    # Determine this node's URL
    node_url = os.environ.get("NODE_URL")
    if not node_url:
        # For localhost, use localhost URL
        if current_host in ["localhost", "127.0.0.1", "0.0.0.0"]:
            node_url = f"http://localhost:{current_port}"
        else:
            # For other hosts, construct URL
            node_url = f"http://{current_host}:{current_port}"
    
    print(f"   📡 Registering execution node with API domain: {api_domain}")
    print(f"      Node ID: {node_id}")
    print(f"      Node URL: {node_url}")
    
    try:
        # Get user token from environment (if available)
        # In production, this would come from the logged-in user
        auth_token = os.environ.get("AURICA_AUTH_TOKEN")
        
        if not auth_token:
            print(f"   ⚠️  No auth token available - node will be registered on first user login")
            return
        
        # Register with API domain
        async with httpx.AsyncClient(timeout=10.0) as client:
            register_url = f"{api_domain}/node-connection/api/node/register"
            
            response = await client.post(
                register_url,
                json={
                    "node_id": node_id,
                    "node_url": node_url,
                    "connection_type": "execution",
                    "capabilities": ["chat", "digital-twin"],
                    "version": "2.0.0"
                },
                headers={"Authorization": f"Bearer {auth_token}"}
            )
            
            if response.status_code == 200:
                print(f"   ✅ Successfully registered node with API domain")
            else:
                print(f"   ⚠️  Registration failed: {response.status_code} - {response.text}")
                
    except Exception as e:
        print(f"   ⚠️  Could not register with API domain: {e}")
        print(f"      Node will be registered when user first accesses it")


async def shutdown():
    """
    Shutdown routine - called when app is unloaded
    """
    print("🔌 Node Connection Manager: Shutting down...")
    
    manager = get_node_manager()
    await manager.shutdown()
    
    print("✅ Node Connection Manager: Shutdown complete")


# For backward compatibility - export the manager
def get_manager():
    """Get the global node manager instance"""
    return get_node_manager()

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "uapi"
__version__ = "1.0.0"  # x-release-please-version

import requests
import json
import re
import time
from typing import List, Dict, Any

from .models import Product, DetailProduct, extract_products_from_html
from .utils import prepare_image_request, generate_sign, read_and_encode_image


class Sync1688Session:
    def __init__(self, default_timeout: float = 30):
        self._session = None
        self._token = None
        self._token_part = None
        self.app_key = "12574478"
        self.base_url = "https://h5api.m.1688.com/h5/mtop.relationrecommend.wirelessrecommend.recommend/2.0/"
        self._initialized = False
        self.default_timeout = default_timeout
        self.cookies_dict = {}
        
        # Автоматически запускаем сессию при создании объекта
        self.start()
    
    def __enter__(self):
        if not self._initialized:
            self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    def start(self):
        if self._session:
            self.close()
        
        self._session = requests.Session()
        
        try:
            test_params = {
                "jsv": "2.7.2",
                "appKey": self.app_key,
                "t": str(int(time.time() * 1000)),
                "api": "mtop.relationrecommend.WirelessRecommend.recommend",
                "v": "2.0",
                "type": "originaljson"
            }
            
            response = self._session.get(
                self.base_url,
                params=test_params,
                timeout=self.default_timeout
            )
            
            token_cookie = self._session.cookies.get('_m_h5_tk')
            
            if token_cookie:
                self._token = token_cookie
                self._token_part = self._token.split('_')[0]
                self._initialized = True
                return True
            else:
                raise Exception("Не удалось получить токен")
            
        except Exception as e:
            self.close()
            raise Exception(f"Ошибка запуска сессии: {e}")
    
    def close(self):
        if self._session:
            self._session.close()
            self._session = None
            self._token = None
            self._token_part = None
            self._initialized = False
            self.cookies_dict = {}
    
    def _ensure_initialized(self):
        """Убедиться, что сессия инициализирована"""
        if not self._initialized or not self.is_active:
            self.start()
    
    def _get_image_id(self, image_path, timeout=None):
        self._ensure_initialized()
        
        if timeout is None:
            timeout = self.default_timeout
        
        image_b64 = read_and_encode_image(image_path)
        data_string = prepare_image_request(image_b64)
        timestamp = str(int(time.time() * 1000))
        sign = generate_sign(self._token_part, timestamp, self.app_key, data_string)
        
        params = {
            "jsv": "2.7.2",
            "appKey": self.app_key,
            "t": timestamp,
            "sign": sign,
            "api": "mtop.relationrecommend.WirelessRecommend.recommend",
            "ignoreLogin": "true",
            "prefix": "h5api",
            "v": "2.0",
            "type": "originaljson",
            "dataType": "jsonp", 
            "jsonpIncPrefix": "search1688",
            "timeout": "20000"
        }
        
        headers = {
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://s.1688.com",
            "referer": "https://s.1688.com/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        
        try:
            response = self._session.post(
                self.base_url,
                params=params,
                data={"data": data_string},
                headers=headers,
                timeout=timeout
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get("data", {}).get("success"):
                    image_id = result["data"].get("imageId")
                    if image_id:
                        return image_id
            
            return None
            
        except Exception as e:
            raise Exception(f"Ошибка при запросе: {e}")
    
    def search_by_image(self, image_path: str, timeout: float = None) -> List[Product]:
        self._ensure_initialized()
        
        if timeout is None:
            timeout = self.default_timeout
        
        image_id = self._get_image_id(image_path, timeout=timeout)
        
        if not image_id:
            return []
        
        products = self._search_by_image_id(image_id, timeout=timeout)
        return products
    
    def _search_by_image_id(self, image_id: str, timeout=None) -> List[Product]:
        self._ensure_initialized()
        
        if timeout is None:
            timeout = self.default_timeout
        
        search_url = f"https://s.1688.com/youyuan/index.htm"
        params = {
            "tab": "imageSearch",
            "imageId": image_id
        }
        
        headers = {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "accept-language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
            "referer": "https://s.1688.com/"
        }
        
        try:
            response = self._session.get(
                search_url,
                params=params,
                headers=headers,
                timeout=timeout
            )
            
            if response.status_code == 200:
                html_content = response.text
                products = extract_products_from_html(html_content)
                return products
            else:
                return []
                
        except Exception:
            return []
    
    def _get_cookies_with_requests(self):
        """Получает куки через requests запросы"""
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
                "Accept-Encoding": "gzip, deflate, br",
                "DNT": "1",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "none",
            }
            
            # Запрос к главной странице 1688
            response = self._session.get("https://www.1688.com/", headers=headers, allow_redirects=True)
            
            # Получаем куки из ответа
            for cookie in self._session.cookies:
                self.cookies_dict[cookie.name] = cookie.value
            
            # Дополнительный запрос для симуляции поведения браузера
            response = self._session.get("https://login.1688.com/", headers=headers, allow_redirects=True)
            
            # Обновляем куки
            for cookie in self._session.cookies:
                self.cookies_dict[cookie.name] = cookie.value
            
            # Запрос к API для получения дополнительных кук
            api_headers = headers.copy()
            api_headers.update({
                "Accept": "application/json, text/plain, */*",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "same-origin",
            })
            
            response = self._session.get("https://www.1688.com/api/token/init", headers=api_headers)
            
            # Обновляем куки
            for cookie in self._session.cookies:
                self.cookies_dict[cookie.name] = cookie.value
            
            # Если кук мало, добавляем базовые
            if not self.cookies_dict:
                self.cookies_dict = {
                    "cna": "Ez7rHJABCwKCAXrD2Q==",
                    "_m_h5_tk": "random_token_12345",
                    "_m_h5_tk_enc": "random_enc_token_12345",
                }
            
        except Exception:
            # Fallback на базовые куки
            self.cookies_dict = {
                "cna": "Ez7rHJABCwKCAXrD2Q==",
                "_m_h5_tk": "random_token_12345", 
                "_m_h5_tk_enc": "random_enc_token_12345",
            }
    
    def get_by_id(self, offer_id: str, timeout: float = None) -> DetailProduct:
        """Парсит товар по ID"""
        self._ensure_initialized()
        
        if timeout is None:
            timeout = self.default_timeout
        
        # Если куки еще не получены, получаем их
        if not self.cookies_dict:
            self._get_cookies_with_requests()
        
        url = f"https://detail.1688.com/offer/{offer_id}.html"
        
        cookies_str = '; '.join([f'{k}={v}' for k, v in self.cookies_dict.items()])
        
        headers = {
            "authority": "detail.1688.com",
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
            "cache-control": "max-age=0",
            "sec-ch-ua": '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "none",
            "sec-fetch-user": "?1",
            "upgrade-insecure-requests": "1",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "cookie": cookies_str
        }
        
        try:
            response = self._session.get(
                url,
                headers=headers,
                timeout=timeout  # Используем переданный timeout
            )
            
            if response.status_code == 200:
                html_content = response.text
                
                # Ищем JSON данные
                json_str = self._extract_json_string(html_content)
                
                if json_str:
                    # Исправляем JSON перед парсингом
                    fixed_json_str = self._fix_json_issues(json_str)
                    
                    try:
                        product_data = json.loads(fixed_json_str)
                        product = DetailProduct(product_data)
                        return product
                    except json.JSONDecodeError:
                        return None
                else:
                    return None
            else:
                return None
                
        except Exception:
            return None

    def _extract_json_string(self, html_content: str) -> str:
        """Извлекает JSON строку из HTML"""
        pattern = r'window\.contextPath\s*,\s*({.*?})\);'
        match = re.search(pattern, html_content, re.DOTALL)
        
        if match:
            json_str = match.group(1)
            return json_str
        
        return ""

    def _fix_json_issues(self, json_str: str) -> str:
        """Исправляет проблемы в JSON"""
        # Исправляем объект skuWeight
        sku_weight_pattern = r'"skuWeight":\s*\{[^}]+\}'
        def fix_sku_weight(match):
            sku_weight_obj = match.group(0)
            fixed = re.sub(r'(\s*)(\d+)(\s*):(\s*)', r'\1"\2"\3:\4', sku_weight_obj)
            return fixed
        
        fixed_json = re.sub(sku_weight_pattern, fix_sku_weight, json_str)
        
        # Исправляем объект skuFeatures  
        sku_features_pattern = r'"skuFeatures":\s*\{[^}]+\}'
        def fix_sku_features(match):
            sku_features_obj = match.group(0)
            fixed = re.sub(r'(\s*)(\d+)(\s*):(\s*)', r'\1"\2"\3:\4', sku_features_obj)
            return fixed
        
        fixed_json = re.sub(sku_features_pattern, fix_sku_features, fixed_json)
        
        return fixed_json

    @property
    def is_active(self):
        return self._session is not None
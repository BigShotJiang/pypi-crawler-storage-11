from dataclasses import dataclass

@dataclass
class CommitResult:
    block_cid: str
    tx_hash: str
    block_number: int

class Ledger:
    @staticmethod
    def commit(block) -> CommitResult:
        cid = f"bafybei{block.hash[:20]}"
        tx = f"0xMOCK{block.hash[:8]}"
        return CommitResult(cid, tx, 12345678)

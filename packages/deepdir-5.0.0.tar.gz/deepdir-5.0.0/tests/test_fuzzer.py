"""
Tests for fuzzer module
"""

import unittest
from unittest.mock import Mock, patch
import requests

from modules.fuzzer import Fuzzer


class TestFuzzer(unittest.TestCase):
    def setUp(self):
        self.config = Mock()
        self.config.extensions = ["php", "html"]
        self.fuzzer = Fuzzer(self.config)

    def test_pattern_generation(self):
        patterns = self.fuzzer._generate_patterns()

        # Should generate many patterns
        self.assertGreater(len(patterns), 100)

        # Should include common directories
        self.assertIn("admin", patterns)
        self.assertIn("admin/", patterns)

        # Should include extensions
        self.assertIn("admin.php", patterns)
        self.assertIn("admin.html", patterns)

    def test_smart_mutations(self):
        base_words = ["admin", "test"]
        mutations = self.fuzzer.generate_smart_mutations(base_words)

        # Should generate mutations
        self.assertGreater(len(mutations), len(base_words))

        # Should include original words
        self.assertIn("admin", mutations)
        self.assertIn("test", mutations)

        # Should include case variations
        self.assertIn("ADMIN", mutations)
        self.assertIn("Admin", mutations)

        # Should include common suffixes
        self.assertIn("_admin", mutations)
        self.assertIn("admin_", mutations)
        self.assertIn("admin2", mutations)

    @patch('requests.Session')
    def test_scan(self, mock_session_class):
        mock_session = Mock()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.content = b"test content"
        mock_response.headers = {'content-type': 'text/html'}
        mock_session.get.return_value = mock_response
        mock_session_class.return_value = mock_session

        self.fuzzer.session = mock_session

        results = self.fuzzer.scan("https://example.com")

        # Should return results
        self.assertIsInstance(results, list)

        # Should have made requests
        self.assertTrue(mock_session.get.called)

    def test_generate_patterns_includes_years(self):
        patterns = self.fuzzer._generate_patterns()

        # Should include year-based patterns
        year_patterns = [p for p in patterns if '202' in p or 'backup' in p]
        self.assertGreater(len(year_patterns), 0)


if __name__ == '__main__':
    unittest.main()
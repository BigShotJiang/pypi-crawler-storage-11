"""
Tests for configuration management
"""

import unittest
import tempfile
import json
import os
from pathlib import Path

from core.config import Config, ScanConfig


class TestScanConfig(unittest.TestCase):
    def test_default_values(self):
        config = ScanConfig()
        self.assertEqual(config.threads, 10)
        self.assertEqual(config.max_depth, 2)
        self.assertEqual(config.http_method, "GET")
        self.assertIsInstance(config.extensions, list)
        self.assertIsInstance(config.include_status_codes, list)

    def test_config_validation(self):
        config = Config()
        # Should fail with defaults (no URLs)
        self.assertFalse(config.validate())

        # Should pass with URLs
        config.config.urls = ["https://example.com"]
        self.assertTrue(config.validate())

        # Should pass with URL file
        config.config.urls = []
        config.config.url_file = "targets.txt"
        self.assertTrue(config.validate())


class TestConfig(unittest.TestCase):
    def setUp(self):
        self.config = Config()

    def test_load_from_file(self):
        config_data = {
            "threads": 20,
            "recursive": True,
            "max_depth": 5
        }

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(config_data, f)
            config_file = f.name

        try:
            self.config.load_from_file(config_file)
            self.assertEqual(self.config.config.threads, 20)
            self.assertTrue(self.config.config.recursive)
            self.assertEqual(self.config.config.max_depth, 5)
        finally:
            os.unlink(config_file)

    def test_save_to_file(self):
        self.config.config.threads = 25
        self.config.config.recursive = True

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            config_file = f.name

        try:
            self.config.save_to_file(config_file)

            # Load and verify
            with open(config_file, 'r') as f:
                data = json.load(f)

            self.assertEqual(data['threads'], 25)
            self.assertTrue(data['recursive'])
        finally:
            os.unlink(config_file)

    def test_update_from_args(self):
        class MockArgs:
            def __init__(self):
                self.threads = 15
                self.recursive = True
                self.depth = 4
                self.extensions = "php,html,js"

        args = MockArgs()
        self.config.update_from_args(args)

        self.assertEqual(self.config.config.threads, 15)
        self.assertTrue(self.config.config.recursive)
        self.assertEqual(self.config.config.max_depth, 4)
        self.assertEqual(self.config.config.extensions, ["php", "html", "js"])


if __name__ == '__main__':
    unittest.main()
"""
Tests for anti-WAF module
"""

import unittest
from unittest.mock import Mock, patch
import requests

from modules.anti_waf import AntiWAF


class TestAntiWAF(unittest.TestCase):
    def setUp(self):
        self.config = Mock()
        self.anti_waf = AntiWAF(self.config)

    def test_user_agent_rotation(self):
        session = Mock()

        # First call
        self.anti_waf.apply_techniques(session)
        first_ua = session.headers.get('User-Agent')

        # Reset for second call
        session.reset_mock()

        # Second call - might rotate
        self.anti_waf.apply_techniques(session)
        second_ua = session.headers.get('User-Agent')

        # User agents should be from the pool
        if first_ua:
            self.assertIn(first_ua, self.anti_waf.user_agents)
        if second_ua:
            self.assertIn(second_ua, self.anti_waf.user_agents)

    def test_encode_payload(self):
        payload = "admin.php"
        encoded = self.anti_waf.encode_payload(payload)

        # Should include original
        self.assertIn(payload, encoded)

        # Should include URL encoded
        self.assertIn("admin.php", encoded)  # URL encoded

        # Should include variations
        self.assertGreater(len(encoded), 1)

    def test_detect_waf(self):
        # Test Cloudflare detection
        response = Mock()
        response.headers = {'CF-RAY': '123456789'}
        response.text = "cloudflare content"

        waf = self.anti_waf.detect_waf(response)
        self.assertEqual(waf, "Cloudflare")

    def test_detect_waf_no_waf(self):
        response = Mock()
        response.headers = {'Server': 'nginx'}
        response.text = "normal content"

        waf = self.anti_waf.detect_waf(response)
        self.assertEqual(waf, "Unknown/None")

    def test_header_variations(self):
        base_headers = {'User-Agent': 'test', 'Accept': 'text/html'}

        variations = self.anti_waf.generate_header_variations(base_headers)

        # Should include original
        self.assertIn(base_headers, variations)

        # Should include case variations
        case_varied = {'user-agent': 'test', 'accept': 'text/html'}
        self.assertIn(case_varied, variations)

    def test_junk_headers(self):
        base_headers = {'User-Agent': 'test'}

        variations = self.anti_waf.generate_header_variations(base_headers)

        # Should include junk headers in some variations
        junk_found = False
        for variation in variations:
            if 'X-Forwarded-For' in variation or 'CF-Connecting-IP' in variation:
                junk_found = True
                break

        self.assertTrue(junk_found, "Should include junk headers in variations")


if __name__ == '__main__':
    unittest.main()
import string
import random
def generatePassword():
    kh = string.ascii_lowercase
    bh = string.ascii_uppercase
    dg = string.digits
    sy = string.punctuation
    adet = 9
    secim = []
    iskh = True
    isbh = True
    isdg = True
    issy = True
    if iskh:
        secim.append(kh)
    if isbh:
        secim.append(bh)
    if isdg:
        secim.append(dg)
    if issy:
        secim.append(sy)

    per = adet // len(secim)
    kalan = adet % len(secim)
    sifre = []
    for i in secim:
        sifre.extend(random.choices(i, k=per))

    sifre.extend(random.choices(secim[0], k=kalan))

    random.shuffle(sifre)
    sifre = "".join(sifre)
    return sifre

print(generatePassword())

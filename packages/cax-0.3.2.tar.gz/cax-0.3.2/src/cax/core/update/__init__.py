"""Update modules for Cellular Automata.

This module contains various update mechanisms used in Cellular Automata
implementations. These update modules are responsible for determining the
next state of each cell based on its current state and the information
gathered from its neighborhood.

Available update modules may include:
- Rule-based updates
- Neural network-based updates
- Custom update mechanisms
"""

from .mlp_update import MLPUpdate
from .nca_update import NCAUpdate
from .residual_update import ResidualUpdate
from .update import Update

__all__ = [
	"Update",
	"MLPUpdate",
	"ResidualUpdate",
	"NCAUpdate",
]

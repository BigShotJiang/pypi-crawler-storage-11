import torch
import matplotlib.pyplot as plt
import numpy as np

def show_forward_pass(model, x_input, percentile=None, show_connections=True):
    """
    Visualizes the activations of a neural network with a red–gray–green scale.
    
    Node color:
        - Red → activation < 0
        - Gray → activation = 0
        - Green → activation > 0
        - Saturation proportional to |activation|
        - If percentile is set, only neurons >= percentile are colored (others gray)
    """

    model.eval()
    
    with torch.inference_mode():
        acts = model(x_input.unsqueeze(0)) if x_input.ndim == 1 else model(x_input)
    
    if not isinstance(acts, (tuple, list)):
        acts = (acts,)
    
    input_vals = x_input.detach().numpy() if isinstance(x_input, torch.Tensor) else np.array(x_input)
    activations = [input_vals] + [a.detach().numpy()[0] if a.ndim == 2 else a.detach().numpy() for a in acts]
    
    layer_neurons = [len(a) for a in activations]
    neuroni_lista = []
    
    n_hidden = len(activations) - 2
    layer_names = ["input"] + [f"hidden{i+1}" for i in range(n_hidden)] + ["output"]
    
    for i, layer_vals in enumerate(activations):
        n_neurons = len(layer_vals)
        coords_y = np.linspace(-n_neurons/2, n_neurons/2, n_neurons)
        max_abs = np.max(np.abs(layer_vals)) + 1e-8
        
        plt.text(i, n_neurons/2 + 1, layer_names[i], fontsize=12, ha='center')
        
        # Calcola soglia percentile (anche per input)
        if percentile is not None:
            thresh = np.percentile(layer_vals, percentile)
        
        for idx, y in enumerate(coords_y):
            val = layer_vals[idx]
            
            # Modalità percentile
            if percentile is not None:
                if val >= thresh:
                    norm = np.clip(val / max_abs, -1, 1)
                    if norm >= 0:
                        color = (1 - norm, 1, 1 - norm)  # verde
                    else:
                        color = (1, 1 + norm, 1 + norm)  # rosso
                else:
                    color = "gray"
            
            # Modalità continua
            else:
                norm = np.clip(val / max_abs, -1, 1)
                if norm > 0:
                    color = (1 - norm, 1, 1 - norm)  # verde
                elif norm < 0:
                    color = (1, 1 + norm, 1 + norm)  # rosso
                else:
                    color = "gray"
            
            plt.scatter(i, y, color=color, s=500, zorder=2)
            neuroni_lista.append((i, y))
    
    if show_connections:
        for i in range(len(layer_neurons) - 1):
            actual_neurons = [t for t in neuroni_lista if t[0] == i]
            next_neurons = [t for t in neuroni_lista if t[0] == i + 1]
            for n1 in actual_neurons:
                x1, y1 = n1
                for n2 in next_neurons:
                    x2, y2 = n2
                    plt.plot([x1, x2], [y1, y2], color="gray", zorder=1, linewidth=0.5)
    
    plt.axis("off")
    plt.show()

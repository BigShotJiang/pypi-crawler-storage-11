# -*- coding: UTF-8 -*-
logger.info("Loading 52 objects to table sepa_account...")
# fields: id, partner, iban, bic, remark, primary, account_type, managed
loader.save(
    create_sepa_account(1, 220, u'EE872200221012067904', u'HABAEE2X', u'',
                        True, u'01', False))
loader.save(
    create_sepa_account(2, 221, u'EE732200221045112758', u'HABAEE2X', u'',
                        True, u'01', False))
loader.save(
    create_sepa_account(3, 222, u'EE232200001180005555', u'HABAEE2X',
                        u'Eraklilendile', True, u'01', False))
loader.save(
    create_sepa_account(4, 222, u'EE322200221112223334', u'HABAEE2X',
                        u'\xc4rikliendile', False, u'01', False))
loader.save(
    create_sepa_account(5, 222, u'EE081010002059413005', u'EEUHEE2X', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(6, 222, u'EE703300332099000006', u'FOREEE2X', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(7, 222, u'EE431700017000115797', u'NDEAEE2X', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(8, 223, u'EE382200221013987931', u'HABAEE2X', u'',
                        True, u'01', False))
loader.save(
    create_sepa_account(9, 224, u'EE522200221013264447', u'HABAEE2X', u'',
                        True, u'01', False))
loader.save(
    create_sepa_account(10, 225, u'EE202200221001178338', u'HABAEE2X', u'',
                        True, u'01', False))
loader.save(
    create_sepa_account(11, 225, u'EE781010220002715011', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(12, 225, u'EE321700017000231134', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(13, 226, u'BE46000325448336', u'BPOTBEB1', u'', True,
                        u'01', False))
loader.save(
    create_sepa_account(14, 226, u'BE81000325873924', u'BPOTBEB1', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(15, 227, u'BE79827081803833', u'ETHIBEBB', u'', True,
                        u'01', False))
loader.save(
    create_sepa_account(16, 228, u'BE98348031033293', u'BBRUBEBB', u'', True,
                        u'01', False))
loader.save(
    create_sepa_account(17, 229, u'BE38248017357572', u'GEBABEBB', u'', True,
                        u'01', False))
loader.save(
    create_sepa_account(18, 100, u'AL73552891583236787384690218', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(19, 101, u'AL66383778998922195726400092', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(20, 102, u'AD5257784281812851432256', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(21, 103, u'AT233377816198914246', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(22, 104, u'AZ72AOZV21841200481951294949', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(23, 105, u'BH50GDHO00603036234521', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(24, 106, u'BH29GWOZ41746150114337', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(25, 107, u'BE83540256917919', u'', u'', False, u'01',
                        False))
loader.save(
    create_sepa_account(26, 108, u'BE62315236188996', u'BBRUBEBB', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(27, 109, u'BE94532216847099', u'', u'', False, u'01',
                        False))
loader.save(
    create_sepa_account(28, 110, u'BE96553733406075', u'GKCCBEBB', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(29, 111, u'BA086304331850728340', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(30, 112, u'BR2701798507625253316527482W6', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(31, 113, u'BR8916505915221714901465542D6', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(32, 114, u'BG33WODO90876019575940', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(33, 115, u'BG89NKTJ64315412156435', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(34, 116, u'BG45LMDF68752666847493', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(35, 117, u'MK42869572001783450', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(36, 118, u'CY94595189933551887423183914', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(37, 119, u'CY67178463066674360903454329', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(38, 120, u'CZ9233597294072726325676', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(39, 121, u'CZ6595671096439786778328', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(40, 122, u'DK4827862790127019', u'', u'', False, u'01',
                        False))
loader.save(
    create_sepa_account(41, 123, u'DK1358026849419971', u'', u'', False, u'01',
                        False))
loader.save(
    create_sepa_account(42, 124, u'DK0905734385914385', u'', u'', False, u'01',
                        False))
loader.save(
    create_sepa_account(43, 125, u'DO64127641001569019111921598', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(44, 126, u'DO40144771611278919843152876', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(45, 127, u'DO34894434296388176648298583', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(46, 128, u'DO87947053138589917553903987', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(47, 129, u'EE436294797788261706', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(48, 130, u'EE386024163501444960', u'', u'', False,
                        u'01', False))
loader.save(
    create_sepa_account(49, 131, u'KW17RZFN7035889356330572874320', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(50, 132, u'MT48FZJE39412800316166455316545', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(51, 133, u'MC8574374915374698884193509', u'', u'',
                        False, u'01', False))
loader.save(
    create_sepa_account(52, 100, u'BE39088213644919', u'GKCCBEBB', u'', True,
                        u'01', False))

loader.flush_deferred_objects()

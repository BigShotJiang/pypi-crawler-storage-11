# -*- coding: UTF-8 -*-
logger.info("Loading 716 objects to table debts_entry...")
# fields: id, seqno, budget, account_type, account, partner, amount, actor, circa, distribute, todo, remark, description, periods, monthly_rate, bailiff
loader.save(
    create_debts_entry(1, 1, 1, u'I', 1, None, '0.00', 2, False, False, u'',
                       u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(2, 2, 1, u'I', 2, None, '200.00', 2, False, False, u'',
                       u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(3, 3, 1, u'I', 3, None, '400.00', 2, False, False, u'',
                       u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(4, 4, 1, u'I', 4, None, '600.00', 2, False, False, u'',
                       u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(5, 5, 1, u'I', 5, None, '800.00', 2, False, False, u'',
                       u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(6, 6, 1, u'I', 6, None, '1000.00', 2, False, False, u'',
                       u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(7, 7, 1, u'I', 7, None, '1200.00', 2, False, False, u'',
                       u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(8, 8, 1, u'I', 8, None, '1400.00', 2, False, False, u'',
                       u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(9, 9, 1, u'I', 9, None, '0.00', 2, False, False, u'',
                       u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(10, 10, 1, u'I', 10, None, '200.00', 2, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(11, 11, 1, u'E', 11, None, '0.00', None, False, False,
                       u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(12, 12, 1, u'E', 12, None, '5.00', None, False, False,
                       u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(13, 13, 1, u'E', 13, None, '10.00', None, False, False,
                       u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(14, 14, 1, u'E', 14, None, '15.00', None, False, False,
                       u'', u'', u'Festnetz-Telefon und Internet', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(15, 15, 1, u'E', 15, None, '20.00', None, False, False,
                       u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(16, 16, 1, u'E', 16, None, '26.00', None, False, False,
                       u'', u'Einkaufen', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(17, 18, 1, u'E', 17, None, '31.00', None, False, False,
                       u'', u'', u'TEC Busabonnement', '1', '0.00', None))
loader.save(
    create_debts_entry(18, 19, 1, u'E', 18, None, '36.00', None, False, False,
                       u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(19, 20, 1, u'E', 19, None, '41.00', None, False, False,
                       u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(20, 21, 1, u'E', 20, None, '47.00', None, False, False,
                       u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(21, 22, 1, u'E', 21, None, '0.00', None, False, False,
                       u'', u'', u'Tagesmutter & Kleinkindbetreuung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(22, 23, 1, u'E', 22, None, '5.00', None, False, False,
                       u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(23, 24, 1, u'E', 23, None, '10.00', None, False, False,
                       u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(24, 25, 1, u'E', 24, None, '15.00', None, False, False,
                       u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(25, 26, 1, u'E', 25, None, '20.00', None, False, False,
                       u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(26, 27, 1, u'E', 26, None, '26.00', None, False, False,
                       u'', u'', u'Krankenkassenbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(27, 28, 1, u'E', 27, None, '31.00', None, False, False,
                       u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(28, 29, 1, u'E', 28, None, '36.00', None, False, False,
                       u'', u'', u'Unterhaltszahlungen', '1', '0.00', None))
loader.save(
    create_debts_entry(29, 30, 1, u'E', 32, None, '41.00', None, False, False,
                       u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(30, 31, 1, u'E', 29, None, '47.00', None, False, False,
                       u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(31, 32, 1, u'E', 30, None, '0.00', None, False, False,
                       u'', u'Kino', u'Freizeit & Unterhaltung', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(32, 33, 1, u'E', 31, None, '5.00', None, False, False,
                       u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(33, 34, 1, u'E', 33, None, '10.00', None, False, False,
                       u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(34, 35, 1, u'E', 34, None, '15.00', None, False, False,
                       u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(35, 36, 1, u'E', 35, None, '20.00', None, False, False,
                       u'', u'', u'Kanalisationssteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(36, 37, 1, u'E', 36, None, '26.00', None, False, False,
                       u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(37, 38, 1, u'E', 37, None, '31.00', None, False, False,
                       u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(38, 39, 1, u'E', 38, None, '36.00', None, False, False,
                       u'', u'', u'Immobiliensteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(39, 40, 1, u'E', 39, None, '41.00', None, False, False,
                       u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(40, 41, 1, u'E', 40, None, '47.00', None, False, False,
                       u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(41, 42, 1, u'E', 41, None, '0.00', None, False, False,
                       u'', u'', u'Familienhaftpflicht', '12', '0.00', None))
loader.save(
    create_debts_entry(42, 43, 1, u'E', 42, None, '5.00', None, False, False,
                       u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(43, 44, 1, u'E', 43, None, '10.00', None, False, False,
                       u'', u'', u'Lebensversicherung', '12', '0.00', None))
loader.save(
    create_debts_entry(44, 45, 1, u'E', 44, None, '15.00', None, False, False,
                       u'', u'', u'Andere Versicherungen', '12', '0.00', None))
loader.save(
    create_debts_entry(45, 1, 2, u'I', 1, None, '400.00', 4, False, False, u'',
                       u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(46, 2, 2, u'I', 2, None, '600.00', 4, False, False, u'',
                       u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(47, 3, 2, u'I', 3, None, '800.00', 4, False, False, u'',
                       u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(48, 4, 2, u'I', 4, None, '1000.00', 4, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(49, 5, 2, u'I', 5, None, '1200.00', 4, False, False,
                       u'', u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(50, 6, 2, u'I', 6, None, '1400.00', 4, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(51, 7, 2, u'I', 7, None, '0.00', 4, False, False, u'',
                       u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(52, 8, 2, u'I', 8, None, '200.00', 4, False, False, u'',
                       u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(53, 9, 2, u'I', 9, None, '400.00', 4, False, False, u'',
                       u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(54, 10, 2, u'I', 10, None, '600.00', 4, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(55, 11, 2, u'E', 11, None, '20.00', None, False, False,
                       u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(56, 12, 2, u'E', 12, None, '26.00', None, False, False,
                       u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(57, 13, 2, u'E', 13, None, '31.00', None, False, False,
                       u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(58, 14, 2, u'E', 14, None, '36.00', None, False, False,
                       u'', u'', u'Festnetz-Telefon und Internet', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(59, 15, 2, u'E', 15, None, '41.00', None, False, False,
                       u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(60, 16, 2, u'E', 16, None, '47.00', None, False, False,
                       u'', u'Seminar', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(61, 18, 2, u'E', 17, None, '0.00', None, False, False,
                       u'', u'', u'TEC Busabonnement', '1', '0.00', None))
loader.save(
    create_debts_entry(62, 19, 2, u'E', 18, None, '5.00', None, False, False,
                       u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(63, 20, 2, u'E', 19, None, '10.00', None, False, False,
                       u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(64, 21, 2, u'E', 20, None, '15.00', None, False, False,
                       u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(65, 22, 2, u'E', 21, None, '20.00', None, False, False,
                       u'', u'', u'Tagesmutter & Kleinkindbetreuung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(66, 23, 2, u'E', 22, None, '26.00', None, False, False,
                       u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(67, 24, 2, u'E', 23, None, '31.00', None, False, False,
                       u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(68, 25, 2, u'E', 24, None, '36.00', None, False, False,
                       u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(69, 26, 2, u'E', 25, None, '41.00', None, False, False,
                       u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(70, 27, 2, u'E', 26, None, '47.00', None, False, False,
                       u'', u'', u'Krankenkassenbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(71, 28, 2, u'E', 27, None, '0.00', None, False, False,
                       u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(72, 29, 2, u'E', 28, None, '5.00', None, False, False,
                       u'', u'', u'Unterhaltszahlungen', '1', '0.00', None))
loader.save(
    create_debts_entry(73, 30, 2, u'E', 32, None, '10.00', None, False, False,
                       u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(74, 31, 2, u'E', 29, None, '15.00', None, False, False,
                       u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(75, 32, 2, u'E', 30, None, '20.00', None, False, False,
                       u'', u'Einkaufen', u'Freizeit & Unterhaltung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(76, 33, 2, u'E', 31, None, '26.00', None, False, False,
                       u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(77, 34, 2, u'E', 33, None, '31.00', None, False, False,
                       u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(78, 35, 2, u'E', 34, None, '36.00', None, False, False,
                       u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(79, 36, 2, u'E', 35, None, '41.00', None, False, False,
                       u'', u'', u'Kanalisationssteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(80, 37, 2, u'E', 36, None, '47.00', None, False, False,
                       u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(81, 38, 2, u'E', 37, None, '0.00', None, False, False,
                       u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(82, 39, 2, u'E', 38, None, '5.00', None, False, False,
                       u'', u'', u'Immobiliensteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(83, 40, 2, u'E', 39, None, '10.00', None, False, False,
                       u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(84, 41, 2, u'E', 40, None, '15.00', None, False, False,
                       u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(85, 42, 2, u'E', 41, None, '20.00', None, False, False,
                       u'', u'', u'Familienhaftpflicht', '12', '0.00', None))
loader.save(
    create_debts_entry(86, 43, 2, u'E', 42, None, '26.00', None, False, False,
                       u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(87, 44, 2, u'E', 43, None, '31.00', None, False, False,
                       u'', u'', u'Lebensversicherung', '12', '0.00', None))
loader.save(
    create_debts_entry(88, 45, 2, u'E', 44, None, '36.00', None, False, False,
                       u'', u'', u'Andere Versicherungen', '12', '0.00', None))
loader.save(
    create_debts_entry(89, 1, 3, u'I', 1, None, '800.00', 6, False, False, u'',
                       u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(90, 2, 3, u'I', 2, None, '1000.00', 6, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(91, 3, 3, u'I', 3, None, '1200.00', 6, False, False,
                       u'', u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(92, 4, 3, u'I', 4, None, '1400.00', 6, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(93, 5, 3, u'I', 5, None, '0.00', 6, False, False, u'',
                       u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(94, 6, 3, u'I', 6, None, '200.00', 6, False, False, u'',
                       u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(95, 7, 3, u'I', 7, None, '400.00', 6, False, False, u'',
                       u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(96, 8, 3, u'I', 8, None, '600.00', 6, False, False, u'',
                       u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(97, 9, 3, u'I', 9, None, '800.00', 6, False, False, u'',
                       u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(98, 10, 3, u'I', 10, None, '1000.00', 6, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(99, 11, 3, u'E', 11, None, '41.00', None, False, False,
                       u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(100, 12, 3, u'E', 12, None, '47.00', None, False, False,
                       u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(101, 13, 3, u'E', 13, None, '0.00', None, False, False,
                       u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(102, 14, 3, u'E', 14, None, '5.00', None, False, False,
                       u'', u'', u'Festnetz-Telefon und Internet', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(103, 15, 3, u'E', 15, None, '10.00', None, False, False,
                       u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(104, 16, 3, u'E', 16, None, '15.00', None, False, False,
                       u'', u'Kino', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(105, 18, 3, u'E', 17, None, '20.00', None, False, False,
                       u'', u'', u'TEC Busabonnement', '1', '0.00', None))
loader.save(
    create_debts_entry(106, 19, 3, u'E', 18, None, '26.00', None, False, False,
                       u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(107, 20, 3, u'E', 19, None, '31.00', None, False, False,
                       u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(108, 21, 3, u'E', 20, None, '36.00', None, False, False,
                       u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(109, 22, 3, u'E', 21, None, '41.00', None, False, False,
                       u'', u'', u'Tagesmutter & Kleinkindbetreuung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(110, 23, 3, u'E', 22, None, '47.00', None, False, False,
                       u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(111, 24, 3, u'E', 23, None, '0.00', None, False, False,
                       u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(112, 25, 3, u'E', 24, None, '5.00', None, False, False,
                       u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(113, 26, 3, u'E', 25, None, '10.00', None, False, False,
                       u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(114, 27, 3, u'E', 26, None, '15.00', None, False, False,
                       u'', u'', u'Krankenkassenbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(115, 28, 3, u'E', 27, None, '20.00', None, False, False,
                       u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(116, 29, 3, u'E', 28, None, '26.00', None, False, False,
                       u'', u'', u'Unterhaltszahlungen', '1', '0.00', None))
loader.save(
    create_debts_entry(117, 30, 3, u'E', 32, None, '31.00', None, False, False,
                       u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(118, 31, 3, u'E', 29, None, '36.00', None, False, False,
                       u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(119, 32, 3, u'E', 30, None, '41.00', None, False, False,
                       u'', u'Seminar', u'Freizeit & Unterhaltung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(120, 33, 3, u'E', 31, None, '47.00', None, False, False,
                       u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(121, 34, 3, u'E', 33, None, '0.00', None, False, False,
                       u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(122, 35, 3, u'E', 34, None, '5.00', None, False, False,
                       u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(123, 36, 3, u'E', 35, None, '10.00', None, False, False,
                       u'', u'', u'Kanalisationssteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(124, 37, 3, u'E', 36, None, '15.00', None, False, False,
                       u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(125, 38, 3, u'E', 37, None, '20.00', None, False, False,
                       u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(126, 39, 3, u'E', 38, None, '26.00', None, False, False,
                       u'', u'', u'Immobiliensteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(127, 40, 3, u'E', 39, None, '31.00', None, False, False,
                       u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(128, 41, 3, u'E', 40, None, '36.00', None, False, False,
                       u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(129, 42, 3, u'E', 41, None, '41.00', None, False, False,
                       u'', u'', u'Familienhaftpflicht', '12', '0.00', None))
loader.save(
    create_debts_entry(130, 43, 3, u'E', 42, None, '47.00', None, False, False,
                       u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(131, 44, 3, u'E', 43, None, '0.00', None, False, False,
                       u'', u'', u'Lebensversicherung', '12', '0.00', None))
loader.save(
    create_debts_entry(132, 45, 3, u'E', 44, None, '5.00', None, False, False,
                       u'', u'', u'Andere Versicherungen', '12', '0.00', None))
loader.save(
    create_debts_entry(133, 1, 4, u'I', 1, None, '1200.00', 8, False, False,
                       u'', u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(134, 2, 4, u'I', 2, None, '1400.00', 8, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(135, 3, 4, u'I', 3, None, '0.00', 8, False, False, u'',
                       u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(136, 4, 4, u'I', 4, None, '200.00', 8, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(137, 5, 4, u'I', 5, None, '400.00', 8, False, False,
                       u'', u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(138, 6, 4, u'I', 6, None, '600.00', 8, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(139, 7, 4, u'I', 7, None, '800.00', 8, False, False,
                       u'', u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(140, 8, 4, u'I', 8, None, '1000.00', 8, False, False,
                       u'', u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(141, 9, 4, u'I', 9, None, '1200.00', 8, False, False,
                       u'', u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(142, 10, 4, u'I', 10, None, '1400.00', 8, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(143, 11, 4, u'E', 11, None, '10.00', None, False, False,
                       u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(144, 12, 4, u'E', 12, None, '15.00', None, False, False,
                       u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(145, 13, 4, u'E', 13, None, '20.00', None, False, False,
                       u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(146, 14, 4, u'E', 14, None, '26.00', None, False, False,
                       u'', u'', u'Festnetz-Telefon und Internet', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(147, 15, 4, u'E', 15, None, '31.00', None, False, False,
                       u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(148, 16, 4, u'E', 16, None, '36.00', None, False, False,
                       u'', u'Einkaufen', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(149, 18, 4, u'E', 17, None, '41.00', None, False, False,
                       u'', u'', u'TEC Busabonnement', '1', '0.00', None))
loader.save(
    create_debts_entry(150, 19, 4, u'E', 18, None, '47.00', None, False, False,
                       u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(151, 20, 4, u'E', 19, None, '0.00', None, False, False,
                       u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(152, 21, 4, u'E', 20, None, '5.00', None, False, False,
                       u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(153, 22, 4, u'E', 21, None, '10.00', None, False, False,
                       u'', u'', u'Tagesmutter & Kleinkindbetreuung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(154, 23, 4, u'E', 22, None, '15.00', None, False, False,
                       u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(155, 24, 4, u'E', 23, None, '20.00', None, False, False,
                       u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(156, 25, 4, u'E', 24, None, '26.00', None, False, False,
                       u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(157, 26, 4, u'E', 25, None, '31.00', None, False, False,
                       u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(158, 27, 4, u'E', 26, None, '36.00', None, False, False,
                       u'', u'', u'Krankenkassenbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(159, 28, 4, u'E', 27, None, '41.00', None, False, False,
                       u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(160, 29, 4, u'E', 28, None, '47.00', None, False, False,
                       u'', u'', u'Unterhaltszahlungen', '1', '0.00', None))
loader.save(
    create_debts_entry(161, 30, 4, u'E', 32, None, '0.00', None, False, False,
                       u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(162, 31, 4, u'E', 29, None, '5.00', None, False, False,
                       u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(163, 32, 4, u'E', 30, None, '10.00', None, False, False,
                       u'', u'Kino', u'Freizeit & Unterhaltung', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(164, 33, 4, u'E', 31, None, '15.00', None, False, False,
                       u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(165, 34, 4, u'E', 33, None, '20.00', None, False, False,
                       u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(166, 35, 4, u'E', 34, None, '26.00', None, False, False,
                       u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(167, 36, 4, u'E', 35, None, '31.00', None, False, False,
                       u'', u'', u'Kanalisationssteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(168, 37, 4, u'E', 36, None, '36.00', None, False, False,
                       u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(169, 38, 4, u'E', 37, None, '41.00', None, False, False,
                       u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(170, 39, 4, u'E', 38, None, '47.00', None, False, False,
                       u'', u'', u'Immobiliensteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(171, 40, 4, u'E', 39, None, '0.00', None, False, False,
                       u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(172, 41, 4, u'E', 40, None, '5.00', None, False, False,
                       u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(173, 42, 4, u'E', 41, None, '10.00', None, False, False,
                       u'', u'', u'Familienhaftpflicht', '12', '0.00', None))
loader.save(
    create_debts_entry(174, 43, 4, u'E', 42, None, '15.00', None, False, False,
                       u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(175, 44, 4, u'E', 43, None, '20.00', None, False, False,
                       u'', u'', u'Lebensversicherung', '12', '0.00', None))
loader.save(
    create_debts_entry(176, 45, 4, u'E', 44, None, '26.00', None, False, False,
                       u'', u'', u'Andere Versicherungen', '12', '0.00', None))
loader.save(
    create_debts_entry(177, 1, 5, u'I', 1, None, '0.00', 10, False, False, u'',
                       u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(178, 2, 5, u'I', 2, None, '200.00', 10, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(179, 3, 5, u'I', 3, None, '400.00', 10, False, False,
                       u'', u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(180, 4, 5, u'I', 4, None, '600.00', 10, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(181, 5, 5, u'I', 5, None, '800.00', 10, False, False,
                       u'', u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(182, 6, 5, u'I', 6, None, '1000.00', 10, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(183, 7, 5, u'I', 7, None, '1200.00', 10, False, False,
                       u'', u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(184, 8, 5, u'I', 8, None, '1400.00', 10, False, False,
                       u'', u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(185, 9, 5, u'I', 9, None, '0.00', 10, False, False, u'',
                       u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(186, 10, 5, u'I', 10, None, '200.00', 10, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(187, 11, 5, u'E', 11, None, '31.00', None, False, False,
                       u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(188, 12, 5, u'E', 12, None, '36.00', None, False, False,
                       u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(189, 13, 5, u'E', 13, None, '41.00', None, False, False,
                       u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(190, 14, 5, u'E', 14, None, '47.00', None, False, False,
                       u'', u'', u'Festnetz-Telefon und Internet', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(191, 15, 5, u'E', 15, None, '0.00', None, False, False,
                       u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(192, 16, 5, u'E', 16, None, '5.00', None, False, False,
                       u'', u'Seminar', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(193, 18, 5, u'E', 17, None, '10.00', None, False, False,
                       u'', u'', u'TEC Busabonnement', '1', '0.00', None))
loader.save(
    create_debts_entry(194, 19, 5, u'E', 18, None, '15.00', None, False, False,
                       u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(195, 20, 5, u'E', 19, None, '20.00', None, False, False,
                       u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(196, 21, 5, u'E', 20, None, '26.00', None, False, False,
                       u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(197, 22, 5, u'E', 21, None, '31.00', None, False, False,
                       u'', u'', u'Tagesmutter & Kleinkindbetreuung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(198, 23, 5, u'E', 22, None, '36.00', None, False, False,
                       u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(199, 24, 5, u'E', 23, None, '41.00', None, False, False,
                       u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(200, 25, 5, u'E', 24, None, '47.00', None, False, False,
                       u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(201, 26, 5, u'E', 25, None, '0.00', None, False, False,
                       u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(202, 27, 5, u'E', 26, None, '5.00', None, False, False,
                       u'', u'', u'Krankenkassenbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(203, 28, 5, u'E', 27, None, '10.00', None, False, False,
                       u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(204, 29, 5, u'E', 28, None, '15.00', None, False, False,
                       u'', u'', u'Unterhaltszahlungen', '1', '0.00', None))
loader.save(
    create_debts_entry(205, 30, 5, u'E', 32, None, '20.00', None, False, False,
                       u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(206, 31, 5, u'E', 29, None, '26.00', None, False, False,
                       u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(207, 32, 5, u'E', 30, None, '31.00', None, False, False,
                       u'', u'Einkaufen', u'Freizeit & Unterhaltung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(208, 33, 5, u'E', 31, None, '36.00', None, False, False,
                       u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(209, 34, 5, u'E', 33, None, '41.00', None, False, False,
                       u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(210, 35, 5, u'E', 34, None, '47.00', None, False, False,
                       u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(211, 36, 5, u'E', 35, None, '0.00', None, False, False,
                       u'', u'', u'Kanalisationssteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(212, 37, 5, u'E', 36, None, '5.00', None, False, False,
                       u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(213, 38, 5, u'E', 37, None, '10.00', None, False, False,
                       u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(214, 39, 5, u'E', 38, None, '15.00', None, False, False,
                       u'', u'', u'Immobiliensteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(215, 40, 5, u'E', 39, None, '20.00', None, False, False,
                       u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(216, 41, 5, u'E', 40, None, '26.00', None, False, False,
                       u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(217, 42, 5, u'E', 41, None, '31.00', None, False, False,
                       u'', u'', u'Familienhaftpflicht', '12', '0.00', None))
loader.save(
    create_debts_entry(218, 43, 5, u'E', 42, None, '36.00', None, False, False,
                       u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(219, 44, 5, u'E', 43, None, '41.00', None, False, False,
                       u'', u'', u'Lebensversicherung', '12', '0.00', None))
loader.save(
    create_debts_entry(220, 45, 5, u'E', 44, None, '47.00', None, False, False,
                       u'', u'', u'Andere Versicherungen', '12', '0.00', None))
loader.save(
    create_debts_entry(221, 1, 6, u'I', 1, None, '400.00', 12, False, False,
                       u'', u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(222, 2, 6, u'I', 2, None, '600.00', 12, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(223, 3, 6, u'I', 3, None, '800.00', 12, False, False,
                       u'', u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(224, 4, 6, u'I', 4, None, '1000.00', 12, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(225, 5, 6, u'I', 5, None, '1200.00', 12, False, False,
                       u'', u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(226, 6, 6, u'I', 6, None, '1400.00', 12, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(227, 7, 6, u'I', 7, None, '0.00', 12, False, False, u'',
                       u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(228, 8, 6, u'I', 8, None, '200.00', 12, False, False,
                       u'', u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(229, 9, 6, u'I', 9, None, '400.00', 12, False, False,
                       u'', u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(230, 10, 6, u'I', 10, None, '600.00', 12, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(231, 11, 6, u'E', 11, None, '0.00', None, False, False,
                       u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(232, 12, 6, u'E', 12, None, '5.00', None, False, False,
                       u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(233, 13, 6, u'E', 13, None, '10.00', None, False, False,
                       u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(234, 14, 6, u'E', 14, None, '15.00', None, False, False,
                       u'', u'', u'Festnetz-Telefon und Internet', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(235, 15, 6, u'E', 15, None, '20.00', None, False, False,
                       u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(236, 16, 6, u'E', 16, None, '26.00', None, False, False,
                       u'', u'Kino', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(237, 18, 6, u'E', 17, None, '31.00', None, False, False,
                       u'', u'', u'TEC Busabonnement', '1', '0.00', None))
loader.save(
    create_debts_entry(238, 19, 6, u'E', 18, None, '36.00', None, False, False,
                       u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(239, 20, 6, u'E', 19, None, '41.00', None, False, False,
                       u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(240, 21, 6, u'E', 20, None, '47.00', None, False, False,
                       u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(241, 22, 6, u'E', 21, None, '0.00', None, False, False,
                       u'', u'', u'Tagesmutter & Kleinkindbetreuung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(242, 23, 6, u'E', 22, None, '5.00', None, False, False,
                       u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(243, 24, 6, u'E', 23, None, '10.00', None, False, False,
                       u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(244, 25, 6, u'E', 24, None, '15.00', None, False, False,
                       u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(245, 26, 6, u'E', 25, None, '20.00', None, False, False,
                       u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(246, 27, 6, u'E', 26, None, '26.00', None, False, False,
                       u'', u'', u'Krankenkassenbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(247, 28, 6, u'E', 27, None, '31.00', None, False, False,
                       u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(248, 29, 6, u'E', 28, None, '36.00', None, False, False,
                       u'', u'', u'Unterhaltszahlungen', '1', '0.00', None))
loader.save(
    create_debts_entry(249, 30, 6, u'E', 32, None, '41.00', None, False, False,
                       u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(250, 31, 6, u'E', 29, None, '47.00', None, False, False,
                       u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(251, 32, 6, u'E', 30, None, '0.00', None, False, False,
                       u'', u'Seminar', u'Freizeit & Unterhaltung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(252, 33, 6, u'E', 31, None, '5.00', None, False, False,
                       u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(253, 34, 6, u'E', 33, None, '10.00', None, False, False,
                       u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(254, 35, 6, u'E', 34, None, '15.00', None, False, False,
                       u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(255, 36, 6, u'E', 35, None, '20.00', None, False, False,
                       u'', u'', u'Kanalisationssteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(256, 37, 6, u'E', 36, None, '26.00', None, False, False,
                       u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(257, 38, 6, u'E', 37, None, '31.00', None, False, False,
                       u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(258, 39, 6, u'E', 38, None, '36.00', None, False, False,
                       u'', u'', u'Immobiliensteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(259, 40, 6, u'E', 39, None, '41.00', None, False, False,
                       u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(260, 41, 6, u'E', 40, None, '47.00', None, False, False,
                       u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(261, 42, 6, u'E', 41, None, '0.00', None, False, False,
                       u'', u'', u'Familienhaftpflicht', '12', '0.00', None))
loader.save(
    create_debts_entry(262, 43, 6, u'E', 42, None, '5.00', None, False, False,
                       u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(263, 44, 6, u'E', 43, None, '10.00', None, False, False,
                       u'', u'', u'Lebensversicherung', '12', '0.00', None))
loader.save(
    create_debts_entry(264, 45, 6, u'E', 44, None, '15.00', None, False, False,
                       u'', u'', u'Andere Versicherungen', '12', '0.00', None))
loader.save(
    create_debts_entry(265, 1, 7, u'I', 1, None, '800.00', 14, False, False,
                       u'', u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(266, 2, 7, u'I', 2, None, '1000.00', 14, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(267, 3, 7, u'I', 3, None, '1200.00', 14, False, False,
                       u'', u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(268, 4, 7, u'I', 4, None, '1400.00', 14, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(269, 5, 7, u'I', 5, None, '0.00', 14, False, False, u'',
                       u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(270, 6, 7, u'I', 6, None, '200.00', 14, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(271, 7, 7, u'I', 7, None, '400.00', 14, False, False,
                       u'', u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(272, 8, 7, u'I', 8, None, '600.00', 14, False, False,
                       u'', u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(273, 9, 7, u'I', 9, None, '800.00', 14, False, False,
                       u'', u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(274, 10, 7, u'I', 10, None, '1000.00', 14, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(275, 11, 7, u'E', 11, None, '20.00', None, False, False,
                       u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(276, 12, 7, u'E', 12, None, '26.00', None, False, False,
                       u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(277, 13, 7, u'E', 13, None, '31.00', None, False, False,
                       u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(278, 14, 7, u'E', 14, None, '36.00', None, False, False,
                       u'', u'', u'Festnetz-Telefon und Internet', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(279, 15, 7, u'E', 15, None, '41.00', None, False, False,
                       u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(280, 16, 7, u'E', 16, None, '47.00', None, False, False,
                       u'', u'Einkaufen', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(281, 18, 7, u'E', 17, None, '0.00', None, False, False,
                       u'', u'', u'TEC Busabonnement', '1', '0.00', None))
loader.save(
    create_debts_entry(282, 19, 7, u'E', 18, None, '5.00', None, False, False,
                       u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(283, 20, 7, u'E', 19, None, '10.00', None, False, False,
                       u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(284, 21, 7, u'E', 20, None, '15.00', None, False, False,
                       u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(285, 22, 7, u'E', 21, None, '20.00', None, False, False,
                       u'', u'', u'Tagesmutter & Kleinkindbetreuung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(286, 23, 7, u'E', 22, None, '26.00', None, False, False,
                       u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(287, 24, 7, u'E', 23, None, '31.00', None, False, False,
                       u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(288, 25, 7, u'E', 24, None, '36.00', None, False, False,
                       u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(289, 26, 7, u'E', 25, None, '41.00', None, False, False,
                       u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(290, 27, 7, u'E', 26, None, '47.00', None, False, False,
                       u'', u'', u'Krankenkassenbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(291, 28, 7, u'E', 27, None, '0.00', None, False, False,
                       u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(292, 29, 7, u'E', 28, None, '5.00', None, False, False,
                       u'', u'', u'Unterhaltszahlungen', '1', '0.00', None))
loader.save(
    create_debts_entry(293, 30, 7, u'E', 32, None, '10.00', None, False, False,
                       u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(294, 31, 7, u'E', 29, None, '15.00', None, False, False,
                       u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(295, 32, 7, u'E', 30, None, '20.00', None, False, False,
                       u'', u'Kino', u'Freizeit & Unterhaltung', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(296, 33, 7, u'E', 31, None, '26.00', None, False, False,
                       u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(297, 34, 7, u'E', 33, None, '31.00', None, False, False,
                       u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(298, 35, 7, u'E', 34, None, '36.00', None, False, False,
                       u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(299, 36, 7, u'E', 35, None, '41.00', None, False, False,
                       u'', u'', u'Kanalisationssteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(300, 37, 7, u'E', 36, None, '47.00', None, False, False,
                       u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(301, 38, 7, u'E', 37, None, '0.00', None, False, False,
                       u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(302, 39, 7, u'E', 38, None, '5.00', None, False, False,
                       u'', u'', u'Immobiliensteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(303, 40, 7, u'E', 39, None, '10.00', None, False, False,
                       u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(304, 41, 7, u'E', 40, None, '15.00', None, False, False,
                       u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(305, 42, 7, u'E', 41, None, '20.00', None, False, False,
                       u'', u'', u'Familienhaftpflicht', '12', '0.00', None))
loader.save(
    create_debts_entry(306, 43, 7, u'E', 42, None, '26.00', None, False, False,
                       u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(307, 44, 7, u'E', 43, None, '31.00', None, False, False,
                       u'', u'', u'Lebensversicherung', '12', '0.00', None))
loader.save(
    create_debts_entry(308, 45, 7, u'E', 44, None, '36.00', None, False, False,
                       u'', u'', u'Andere Versicherungen', '12', '0.00', None))
loader.save(
    create_debts_entry(309, 1, 8, u'I', 1, None, '1200.00', 19, False, False,
                       u'', u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(310, 2, 8, u'I', 2, None, '1400.00', 19, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(311, 3, 8, u'I', 3, None, '0.00', 19, False, False, u'',
                       u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(312, 4, 8, u'I', 4, None, '200.00', 19, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(313, 5, 8, u'I', 5, None, '400.00', 19, False, False,
                       u'', u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(314, 6, 8, u'I', 6, None, '600.00', 19, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(315, 7, 8, u'I', 7, None, '800.00', 19, False, False,
                       u'', u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(316, 8, 8, u'I', 8, None, '1000.00', 19, False, False,
                       u'', u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(317, 9, 8, u'I', 9, None, '1200.00', 19, False, False,
                       u'', u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(318, 10, 8, u'I', 10, None, '1400.00', 19, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(319, 11, 8, u'E', 11, None, '41.00', None, False, False,
                       u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(320, 12, 8, u'E', 12, None, '47.00', None, False, False,
                       u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(321, 13, 8, u'E', 13, None, '0.00', None, False, False,
                       u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(322, 14, 8, u'E', 14, None, '5.00', None, False, False,
                       u'', u'', u'Festnetz-Telefon und Internet', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(323, 15, 8, u'E', 15, None, '10.00', None, False, False,
                       u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(324, 16, 8, u'E', 16, None, '15.00', None, False, False,
                       u'', u'Seminar', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(325, 18, 8, u'E', 17, None, '20.00', None, False, False,
                       u'', u'', u'TEC Busabonnement', '1', '0.00', None))
loader.save(
    create_debts_entry(326, 19, 8, u'E', 18, None, '26.00', None, False, False,
                       u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(327, 20, 8, u'E', 19, None, '31.00', None, False, False,
                       u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(328, 21, 8, u'E', 20, None, '36.00', None, False, False,
                       u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(329, 22, 8, u'E', 21, None, '41.00', None, False, False,
                       u'', u'', u'Tagesmutter & Kleinkindbetreuung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(330, 23, 8, u'E', 22, None, '47.00', None, False, False,
                       u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(331, 24, 8, u'E', 23, None, '0.00', None, False, False,
                       u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(332, 25, 8, u'E', 24, None, '5.00', None, False, False,
                       u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(333, 26, 8, u'E', 25, None, '10.00', None, False, False,
                       u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(334, 27, 8, u'E', 26, None, '15.00', None, False, False,
                       u'', u'', u'Krankenkassenbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(335, 28, 8, u'E', 27, None, '20.00', None, False, False,
                       u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(336, 29, 8, u'E', 28, None, '26.00', None, False, False,
                       u'', u'', u'Unterhaltszahlungen', '1', '0.00', None))
loader.save(
    create_debts_entry(337, 30, 8, u'E', 32, None, '31.00', None, False, False,
                       u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(338, 31, 8, u'E', 29, None, '36.00', None, False, False,
                       u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(339, 32, 8, u'E', 30, None, '41.00', None, False, False,
                       u'', u'Einkaufen', u'Freizeit & Unterhaltung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(340, 33, 8, u'E', 31, None, '47.00', None, False, False,
                       u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(341, 34, 8, u'E', 33, None, '0.00', None, False, False,
                       u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(342, 35, 8, u'E', 34, None, '5.00', None, False, False,
                       u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(343, 36, 8, u'E', 35, None, '10.00', None, False, False,
                       u'', u'', u'Kanalisationssteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(344, 37, 8, u'E', 36, None, '15.00', None, False, False,
                       u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(345, 38, 8, u'E', 37, None, '20.00', None, False, False,
                       u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(346, 39, 8, u'E', 38, None, '26.00', None, False, False,
                       u'', u'', u'Immobiliensteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(347, 40, 8, u'E', 39, None, '31.00', None, False, False,
                       u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(348, 41, 8, u'E', 40, None, '36.00', None, False, False,
                       u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(349, 42, 8, u'E', 41, None, '41.00', None, False, False,
                       u'', u'', u'Familienhaftpflicht', '12', '0.00', None))
loader.save(
    create_debts_entry(350, 43, 8, u'E', 42, None, '47.00', None, False, False,
                       u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(351, 44, 8, u'E', 43, None, '0.00', None, False, False,
                       u'', u'', u'Lebensversicherung', '12', '0.00', None))
loader.save(
    create_debts_entry(352, 45, 8, u'E', 44, None, '5.00', None, False, False,
                       u'', u'', u'Andere Versicherungen', '12', '0.00', None))
loader.save(
    create_debts_entry(353, 1, 9, u'I', 1, None, '0.00', 24, False, False, u'',
                       u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(354, 2, 9, u'I', 2, None, '200.00', 24, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(355, 3, 9, u'I', 3, None, '400.00', 24, False, False,
                       u'', u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(356, 4, 9, u'I', 4, None, '600.00', 24, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(357, 5, 9, u'I', 5, None, '800.00', 24, False, False,
                       u'', u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(358, 6, 9, u'I', 6, None, '1000.00', 24, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(359, 7, 9, u'I', 7, None, '1200.00', 24, False, False,
                       u'', u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(360, 8, 9, u'I', 8, None, '1400.00', 24, False, False,
                       u'', u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(361, 9, 9, u'I', 9, None, '0.00', 24, False, False, u'',
                       u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(362, 10, 9, u'I', 10, None, '200.00', 24, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(363, 11, 9, u'E', 11, None, '10.00', None, False, False,
                       u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(364, 12, 9, u'E', 12, None, '15.00', None, False, False,
                       u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(365, 13, 9, u'E', 13, None, '20.00', None, False, False,
                       u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(366, 14, 9, u'E', 14, None, '26.00', None, False, False,
                       u'', u'', u'Festnetz-Telefon und Internet', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(367, 15, 9, u'E', 15, None, '31.00', None, False, False,
                       u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(368, 16, 9, u'E', 16, None, '36.00', None, False, False,
                       u'', u'Kino', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(369, 18, 9, u'E', 17, None, '41.00', None, False, False,
                       u'', u'', u'TEC Busabonnement', '1', '0.00', None))
loader.save(
    create_debts_entry(370, 19, 9, u'E', 18, None, '47.00', None, False, False,
                       u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(371, 20, 9, u'E', 19, None, '0.00', None, False, False,
                       u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(372, 21, 9, u'E', 20, None, '5.00', None, False, False,
                       u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(373, 22, 9, u'E', 21, None, '10.00', None, False, False,
                       u'', u'', u'Tagesmutter & Kleinkindbetreuung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(374, 23, 9, u'E', 22, None, '15.00', None, False, False,
                       u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(375, 24, 9, u'E', 23, None, '20.00', None, False, False,
                       u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(376, 25, 9, u'E', 24, None, '26.00', None, False, False,
                       u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(377, 26, 9, u'E', 25, None, '31.00', None, False, False,
                       u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(378, 27, 9, u'E', 26, None, '36.00', None, False, False,
                       u'', u'', u'Krankenkassenbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(379, 28, 9, u'E', 27, None, '41.00', None, False, False,
                       u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(380, 29, 9, u'E', 28, None, '47.00', None, False, False,
                       u'', u'', u'Unterhaltszahlungen', '1', '0.00', None))
loader.save(
    create_debts_entry(381, 30, 9, u'E', 32, None, '0.00', None, False, False,
                       u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(382, 31, 9, u'E', 29, None, '5.00', None, False, False,
                       u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(383, 32, 9, u'E', 30, None, '10.00', None, False, False,
                       u'', u'Seminar', u'Freizeit & Unterhaltung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(384, 33, 9, u'E', 31, None, '15.00', None, False, False,
                       u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(385, 34, 9, u'E', 33, None, '20.00', None, False, False,
                       u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(386, 35, 9, u'E', 34, None, '26.00', None, False, False,
                       u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(387, 36, 9, u'E', 35, None, '31.00', None, False, False,
                       u'', u'', u'Kanalisationssteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(388, 37, 9, u'E', 36, None, '36.00', None, False, False,
                       u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(389, 38, 9, u'E', 37, None, '41.00', None, False, False,
                       u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(390, 39, 9, u'E', 38, None, '47.00', None, False, False,
                       u'', u'', u'Immobiliensteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(391, 40, 9, u'E', 39, None, '0.00', None, False, False,
                       u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(392, 41, 9, u'E', 40, None, '5.00', None, False, False,
                       u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(393, 42, 9, u'E', 41, None, '10.00', None, False, False,
                       u'', u'', u'Familienhaftpflicht', '12', '0.00', None))
loader.save(
    create_debts_entry(394, 43, 9, u'E', 42, None, '15.00', None, False, False,
                       u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(395, 44, 9, u'E', 43, None, '20.00', None, False, False,
                       u'', u'', u'Lebensversicherung', '12', '0.00', None))
loader.save(
    create_debts_entry(396, 45, 9, u'E', 44, None, '26.00', None, False, False,
                       u'', u'', u'Andere Versicherungen', '12', '0.00', None))
loader.save(
    create_debts_entry(397, 1, 10, u'I', 1, None, '400.00', 28, False, False,
                       u'', u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(398, 2, 10, u'I', 2, None, '600.00', 28, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(399, 3, 10, u'I', 3, None, '800.00', 28, False, False,
                       u'', u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(400, 4, 10, u'I', 4, None, '1000.00', 28, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(401, 5, 10, u'I', 5, None, '1200.00', 28, False, False,
                       u'', u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(402, 6, 10, u'I', 6, None, '1400.00', 28, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(403, 7, 10, u'I', 7, None, '0.00', 28, False, False,
                       u'', u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(404, 8, 10, u'I', 8, None, '200.00', 28, False, False,
                       u'', u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(405, 9, 10, u'I', 9, None, '400.00', 28, False, False,
                       u'', u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(406, 10, 10, u'I', 10, None, '600.00', 28, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(407, 11, 10, u'E', 11, None, '31.00', None, False,
                       False, u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(408, 12, 10, u'E', 12, None, '36.00', None, False,
                       False, u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(409, 13, 10, u'E', 13, None, '41.00', None, False,
                       False, u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(410, 14, 10, u'E', 14, None, '47.00', None, False,
                       False, u'', u'', u'Festnetz-Telefon und Internet', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(411, 15, 10, u'E', 15, None, '0.00', None, False, False,
                       u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(412, 16, 10, u'E', 16, None, '5.00', None, False, False,
                       u'', u'Einkaufen', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(413, 18, 10, u'E', 17, None, '10.00', None, False,
                       False, u'', u'', u'TEC Busabonnement', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(414, 19, 10, u'E', 18, None, '15.00', None, False,
                       False, u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(415, 20, 10, u'E', 19, None, '20.00', None, False,
                       False, u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(416, 21, 10, u'E', 20, None, '26.00', None, False,
                       False, u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(417, 22, 10, u'E', 21, None, '31.00', None, False,
                       False, u'', u'', u'Tagesmutter & Kleinkindbetreuung',
                       '1', '0.00', None))
loader.save(
    create_debts_entry(418, 23, 10, u'E', 22, None, '36.00', None, False,
                       False, u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(419, 24, 10, u'E', 23, None, '41.00', None, False,
                       False, u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(420, 25, 10, u'E', 24, None, '47.00', None, False,
                       False, u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(421, 26, 10, u'E', 25, None, '0.00', None, False, False,
                       u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(422, 27, 10, u'E', 26, None, '5.00', None, False, False,
                       u'', u'', u'Krankenkassenbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(423, 28, 10, u'E', 27, None, '10.00', None, False,
                       False, u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(424, 29, 10, u'E', 28, None, '15.00', None, False,
                       False, u'', u'', u'Unterhaltszahlungen', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(425, 30, 10, u'E', 32, None, '20.00', None, False,
                       False, u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(426, 31, 10, u'E', 29, None, '26.00', None, False,
                       False, u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(427, 32, 10, u'E', 30, None, '31.00', None, False,
                       False, u'', u'Kino', u'Freizeit & Unterhaltung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(428, 33, 10, u'E', 31, None, '36.00', None, False,
                       False, u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(429, 34, 10, u'E', 33, None, '41.00', None, False,
                       False, u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(430, 35, 10, u'E', 34, None, '47.00', None, False,
                       False, u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(431, 36, 10, u'E', 35, None, '0.00', None, False, False,
                       u'', u'', u'Kanalisationssteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(432, 37, 10, u'E', 36, None, '5.00', None, False, False,
                       u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(433, 38, 10, u'E', 37, None, '10.00', None, False,
                       False, u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(434, 39, 10, u'E', 38, None, '15.00', None, False,
                       False, u'', u'', u'Immobiliensteuer', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(435, 40, 10, u'E', 39, None, '20.00', None, False,
                       False, u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(436, 41, 10, u'E', 40, None, '26.00', None, False,
                       False, u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(437, 42, 10, u'E', 41, None, '31.00', None, False,
                       False, u'', u'', u'Familienhaftpflicht', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(438, 43, 10, u'E', 42, None, '36.00', None, False,
                       False, u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(439, 44, 10, u'E', 43, None, '41.00', None, False,
                       False, u'', u'', u'Lebensversicherung', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(440, 45, 10, u'E', 44, None, '47.00', None, False,
                       False, u'', u'', u'Andere Versicherungen', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(441, 1, 11, u'I', 1, None, '800.00', 36, False, False,
                       u'', u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(442, 2, 11, u'I', 2, None, '1000.00', 36, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(443, 3, 11, u'I', 3, None, '1200.00', 36, False, False,
                       u'', u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(444, 4, 11, u'I', 4, None, '1400.00', 36, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(445, 5, 11, u'I', 5, None, '0.00', 36, False, False,
                       u'', u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(446, 6, 11, u'I', 6, None, '200.00', 36, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(447, 7, 11, u'I', 7, None, '400.00', 36, False, False,
                       u'', u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(448, 8, 11, u'I', 8, None, '600.00', 36, False, False,
                       u'', u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(449, 9, 11, u'I', 9, None, '800.00', 36, False, False,
                       u'', u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(450, 10, 11, u'I', 10, None, '1000.00', 36, False,
                       False, u'', u'', u'Gewerkschaftspr\xe4mie', '12',
                       '0.00', None))
loader.save(
    create_debts_entry(451, 11, 11, u'E', 11, None, '0.00', None, False, False,
                       u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(452, 12, 11, u'E', 12, None, '5.00', None, False, False,
                       u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(453, 13, 11, u'E', 13, None, '10.00', None, False,
                       False, u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(454, 14, 11, u'E', 14, None, '15.00', None, False,
                       False, u'', u'', u'Festnetz-Telefon und Internet', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(455, 15, 11, u'E', 15, None, '20.00', None, False,
                       False, u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(456, 16, 11, u'E', 16, None, '26.00', None, False,
                       False, u'', u'Seminar', u'Fahrtkosten', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(457, 18, 11, u'E', 17, None, '31.00', None, False,
                       False, u'', u'', u'TEC Busabonnement', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(458, 19, 11, u'E', 18, None, '36.00', None, False,
                       False, u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(459, 20, 11, u'E', 19, None, '41.00', None, False,
                       False, u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(460, 21, 11, u'E', 20, None, '47.00', None, False,
                       False, u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(461, 22, 11, u'E', 21, None, '0.00', None, False, False,
                       u'', u'', u'Tagesmutter & Kleinkindbetreuung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(462, 23, 11, u'E', 22, None, '5.00', None, False, False,
                       u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(463, 24, 11, u'E', 23, None, '10.00', None, False,
                       False, u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(464, 25, 11, u'E', 24, None, '15.00', None, False,
                       False, u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(465, 26, 11, u'E', 25, None, '20.00', None, False,
                       False, u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(466, 27, 11, u'E', 26, None, '26.00', None, False,
                       False, u'', u'', u'Krankenkassenbeitr\xe4ge', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(467, 28, 11, u'E', 27, None, '31.00', None, False,
                       False, u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(468, 29, 11, u'E', 28, None, '36.00', None, False,
                       False, u'', u'', u'Unterhaltszahlungen', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(469, 30, 11, u'E', 32, None, '41.00', None, False,
                       False, u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(470, 31, 11, u'E', 29, None, '47.00', None, False,
                       False, u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(471, 32, 11, u'E', 30, None, '0.00', None, False, False,
                       u'', u'Einkaufen', u'Freizeit & Unterhaltung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(472, 33, 11, u'E', 31, None, '5.00', None, False, False,
                       u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(473, 34, 11, u'E', 33, None, '10.00', None, False,
                       False, u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(474, 35, 11, u'E', 34, None, '15.00', None, False,
                       False, u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(475, 36, 11, u'E', 35, None, '20.00', None, False,
                       False, u'', u'', u'Kanalisationssteuer', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(476, 37, 11, u'E', 36, None, '26.00', None, False,
                       False, u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(477, 38, 11, u'E', 37, None, '31.00', None, False,
                       False, u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(478, 39, 11, u'E', 38, None, '36.00', None, False,
                       False, u'', u'', u'Immobiliensteuer', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(479, 40, 11, u'E', 39, None, '41.00', None, False,
                       False, u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(480, 41, 11, u'E', 40, None, '47.00', None, False,
                       False, u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(481, 42, 11, u'E', 41, None, '0.00', None, False, False,
                       u'', u'', u'Familienhaftpflicht', '12', '0.00', None))
loader.save(
    create_debts_entry(482, 43, 11, u'E', 42, None, '5.00', None, False, False,
                       u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(483, 44, 11, u'E', 43, None, '10.00', None, False,
                       False, u'', u'', u'Lebensversicherung', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(484, 45, 11, u'E', 44, None, '15.00', None, False,
                       False, u'', u'', u'Andere Versicherungen', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(485, 1, 12, u'I', 1, None, '1200.00', 45, False, False,
                       u'', u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(486, 2, 12, u'I', 2, None, '1400.00', 45, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(487, 3, 12, u'I', 3, None, '0.00', 45, False, False,
                       u'', u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(488, 4, 12, u'I', 4, None, '200.00', 45, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(489, 5, 12, u'I', 5, None, '400.00', 45, False, False,
                       u'', u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(490, 6, 12, u'I', 6, None, '600.00', 45, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(491, 7, 12, u'I', 7, None, '800.00', 45, False, False,
                       u'', u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(492, 8, 12, u'I', 8, None, '1000.00', 45, False, False,
                       u'', u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(493, 9, 12, u'I', 9, None, '1200.00', 45, False, False,
                       u'', u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(494, 10, 12, u'I', 10, None, '1400.00', 45, False,
                       False, u'', u'', u'Gewerkschaftspr\xe4mie', '12',
                       '0.00', None))
loader.save(
    create_debts_entry(495, 11, 12, u'E', 11, None, '20.00', None, False,
                       False, u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(496, 12, 12, u'E', 12, None, '26.00', None, False,
                       False, u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(497, 13, 12, u'E', 13, None, '31.00', None, False,
                       False, u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(498, 14, 12, u'E', 14, None, '36.00', None, False,
                       False, u'', u'', u'Festnetz-Telefon und Internet', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(499, 15, 12, u'E', 15, None, '41.00', None, False,
                       False, u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(500, 16, 12, u'E', 16, None, '47.00', None, False,
                       False, u'', u'Kino', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(501, 18, 12, u'E', 17, None, '0.00', None, False, False,
                       u'', u'', u'TEC Busabonnement', '1', '0.00', None))
loader.save(
    create_debts_entry(502, 19, 12, u'E', 18, None, '5.00', None, False, False,
                       u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(503, 20, 12, u'E', 19, None, '10.00', None, False,
                       False, u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(504, 21, 12, u'E', 20, None, '15.00', None, False,
                       False, u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(505, 22, 12, u'E', 21, None, '20.00', None, False,
                       False, u'', u'', u'Tagesmutter & Kleinkindbetreuung',
                       '1', '0.00', None))
loader.save(
    create_debts_entry(506, 23, 12, u'E', 22, None, '26.00', None, False,
                       False, u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(507, 24, 12, u'E', 23, None, '31.00', None, False,
                       False, u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(508, 25, 12, u'E', 24, None, '36.00', None, False,
                       False, u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(509, 26, 12, u'E', 25, None, '41.00', None, False,
                       False, u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(510, 27, 12, u'E', 26, None, '47.00', None, False,
                       False, u'', u'', u'Krankenkassenbeitr\xe4ge', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(511, 28, 12, u'E', 27, None, '0.00', None, False, False,
                       u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(512, 29, 12, u'E', 28, None, '5.00', None, False, False,
                       u'', u'', u'Unterhaltszahlungen', '1', '0.00', None))
loader.save(
    create_debts_entry(513, 30, 12, u'E', 32, None, '10.00', None, False,
                       False, u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(514, 31, 12, u'E', 29, None, '15.00', None, False,
                       False, u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(515, 32, 12, u'E', 30, None, '20.00', None, False,
                       False, u'', u'Seminar', u'Freizeit & Unterhaltung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(516, 33, 12, u'E', 31, None, '26.00', None, False,
                       False, u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(517, 34, 12, u'E', 33, None, '31.00', None, False,
                       False, u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(518, 35, 12, u'E', 34, None, '36.00', None, False,
                       False, u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(519, 36, 12, u'E', 35, None, '41.00', None, False,
                       False, u'', u'', u'Kanalisationssteuer', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(520, 37, 12, u'E', 36, None, '47.00', None, False,
                       False, u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(521, 38, 12, u'E', 37, None, '0.00', None, False, False,
                       u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(522, 39, 12, u'E', 38, None, '5.00', None, False, False,
                       u'', u'', u'Immobiliensteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(523, 40, 12, u'E', 39, None, '10.00', None, False,
                       False, u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(524, 41, 12, u'E', 40, None, '15.00', None, False,
                       False, u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(525, 42, 12, u'E', 41, None, '20.00', None, False,
                       False, u'', u'', u'Familienhaftpflicht', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(526, 43, 12, u'E', 42, None, '26.00', None, False,
                       False, u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(527, 44, 12, u'E', 43, None, '31.00', None, False,
                       False, u'', u'', u'Lebensversicherung', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(528, 45, 12, u'E', 44, None, '36.00', None, False,
                       False, u'', u'', u'Andere Versicherungen', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(529, 1, 13, u'I', 1, None, '0.00', 54, False, False,
                       u'', u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(530, 2, 13, u'I', 2, None, '200.00', 54, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(531, 3, 13, u'I', 3, None, '400.00', 54, False, False,
                       u'', u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(532, 4, 13, u'I', 4, None, '600.00', 54, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(533, 5, 13, u'I', 5, None, '800.00', 54, False, False,
                       u'', u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(534, 6, 13, u'I', 6, None, '1000.00', 54, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(535, 7, 13, u'I', 7, None, '1200.00', 54, False, False,
                       u'', u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(536, 8, 13, u'I', 8, None, '1400.00', 54, False, False,
                       u'', u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(537, 9, 13, u'I', 9, None, '0.00', 54, False, False,
                       u'', u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(538, 10, 13, u'I', 10, None, '200.00', 54, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(539, 11, 13, u'E', 11, None, '41.00', None, False,
                       False, u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(540, 12, 13, u'E', 12, None, '47.00', None, False,
                       False, u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(541, 13, 13, u'E', 13, None, '0.00', None, False, False,
                       u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(542, 14, 13, u'E', 14, None, '5.00', None, False, False,
                       u'', u'', u'Festnetz-Telefon und Internet', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(543, 15, 13, u'E', 15, None, '10.00', None, False,
                       False, u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(544, 16, 13, u'E', 16, None, '15.00', None, False,
                       False, u'', u'Einkaufen', u'Fahrtkosten', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(545, 18, 13, u'E', 17, None, '20.00', None, False,
                       False, u'', u'', u'TEC Busabonnement', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(546, 19, 13, u'E', 18, None, '26.00', None, False,
                       False, u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(547, 20, 13, u'E', 19, None, '31.00', None, False,
                       False, u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(548, 21, 13, u'E', 20, None, '36.00', None, False,
                       False, u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(549, 22, 13, u'E', 21, None, '41.00', None, False,
                       False, u'', u'', u'Tagesmutter & Kleinkindbetreuung',
                       '1', '0.00', None))
loader.save(
    create_debts_entry(550, 23, 13, u'E', 22, None, '47.00', None, False,
                       False, u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(551, 24, 13, u'E', 23, None, '0.00', None, False, False,
                       u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(552, 25, 13, u'E', 24, None, '5.00', None, False, False,
                       u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(553, 26, 13, u'E', 25, None, '10.00', None, False,
                       False, u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(554, 27, 13, u'E', 26, None, '15.00', None, False,
                       False, u'', u'', u'Krankenkassenbeitr\xe4ge', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(555, 28, 13, u'E', 27, None, '20.00', None, False,
                       False, u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(556, 29, 13, u'E', 28, None, '26.00', None, False,
                       False, u'', u'', u'Unterhaltszahlungen', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(557, 30, 13, u'E', 32, None, '31.00', None, False,
                       False, u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(558, 31, 13, u'E', 29, None, '36.00', None, False,
                       False, u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(559, 32, 13, u'E', 30, None, '41.00', None, False,
                       False, u'', u'Kino', u'Freizeit & Unterhaltung', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(560, 33, 13, u'E', 31, None, '47.00', None, False,
                       False, u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(561, 34, 13, u'E', 33, None, '0.00', None, False, False,
                       u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(562, 35, 13, u'E', 34, None, '5.00', None, False, False,
                       u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(563, 36, 13, u'E', 35, None, '10.00', None, False,
                       False, u'', u'', u'Kanalisationssteuer', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(564, 37, 13, u'E', 36, None, '15.00', None, False,
                       False, u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(565, 38, 13, u'E', 37, None, '20.00', None, False,
                       False, u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(566, 39, 13, u'E', 38, None, '26.00', None, False,
                       False, u'', u'', u'Immobiliensteuer', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(567, 40, 13, u'E', 39, None, '31.00', None, False,
                       False, u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(568, 41, 13, u'E', 40, None, '36.00', None, False,
                       False, u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(569, 42, 13, u'E', 41, None, '41.00', None, False,
                       False, u'', u'', u'Familienhaftpflicht', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(570, 43, 13, u'E', 42, None, '47.00', None, False,
                       False, u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(571, 44, 13, u'E', 43, None, '0.00', None, False, False,
                       u'', u'', u'Lebensversicherung', '12', '0.00', None))
loader.save(
    create_debts_entry(572, 45, 13, u'E', 44, None, '5.00', None, False, False,
                       u'', u'', u'Andere Versicherungen', '12', '0.00', None))
loader.save(
    create_debts_entry(573, 1, 14, u'I', 1, None, '400.00', 63, False, False,
                       u'', u'', u'Geh\xe4lter', '1', '0.00', None))
loader.save(
    create_debts_entry(574, 2, 14, u'I', 2, None, '600.00', 63, False, False,
                       u'', u'', u'Renten', '1', '0.00', None))
loader.save(
    create_debts_entry(575, 3, 14, u'I', 3, None, '800.00', 63, False, False,
                       u'', u'', u'Integrationszulage', '1', '0.00', None))
loader.save(
    create_debts_entry(576, 4, 14, u'I', 4, None, '1000.00', 63, False, False,
                       u'', u'', u'Ersatzeink\xfcnfte', '1', '0.00', None))
loader.save(
    create_debts_entry(577, 5, 14, u'I', 5, None, '1200.00', 63, False, False,
                       u'', u'', u'Alimente', '1', '0.00', None))
loader.save(
    create_debts_entry(578, 6, 14, u'I', 6, None, '1400.00', 63, False, False,
                       u'', u'', u'Essen-Schecks', '1', '0.00', None))
loader.save(
    create_debts_entry(579, 7, 14, u'I', 7, None, '0.00', 63, False, False,
                       u'', u'', u'Andere', '1', '0.00', None))
loader.save(
    create_debts_entry(580, 8, 14, u'I', 8, None, '200.00', 63, False, False,
                       u'', u'', u'Urlaubsgeld', '12', '0.00', None))
loader.save(
    create_debts_entry(581, 9, 14, u'I', 9, None, '400.00', 63, False, False,
                       u'', u'', u'Jahresendzulage', '12', '0.00', None))
loader.save(
    create_debts_entry(582, 10, 14, u'I', 10, None, '600.00', 63, False, False,
                       u'', u'', u'Gewerkschaftspr\xe4mie', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(583, 11, 14, u'E', 11, None, '10.00', None, False,
                       False, u'', u'', u'Miete', '1', '0.00', None))
loader.save(
    create_debts_entry(584, 12, 14, u'E', 12, None, '15.00', None, False,
                       False, u'', u'', u'Wasser', '1', '0.00', None))
loader.save(
    create_debts_entry(585, 13, 14, u'E', 13, None, '20.00', None, False,
                       False, u'', u'', u'Strom', '1', '0.00', None))
loader.save(
    create_debts_entry(586, 14, 14, u'E', 14, None, '26.00', None, False,
                       False, u'', u'', u'Festnetz-Telefon und Internet', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(587, 15, 14, u'E', 15, None, '31.00', None, False,
                       False, u'', u'', u'Handy', '1', '0.00', None))
loader.save(
    create_debts_entry(588, 16, 14, u'E', 16, None, '36.00', None, False,
                       False, u'', u'Seminar', u'Fahrtkosten', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(589, 18, 14, u'E', 17, None, '41.00', None, False,
                       False, u'', u'', u'TEC Busabonnement', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(590, 19, 14, u'E', 18, None, '47.00', None, False,
                       False, u'', u'', u'Benzin', '1', '0.00', None))
loader.save(
    create_debts_entry(591, 20, 14, u'E', 19, None, '0.00', None, False, False,
                       u'', u'', u'Unterhalt Auto', '1', '0.00', None))
loader.save(
    create_debts_entry(592, 21, 14, u'E', 20, None, '5.00', None, False, False,
                       u'', u'', u'Schulkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(593, 22, 14, u'E', 21, None, '10.00', None, False,
                       False, u'', u'', u'Tagesmutter & Kleinkindbetreuung',
                       '1', '0.00', None))
loader.save(
    create_debts_entry(594, 23, 14, u'E', 22, None, '15.00', None, False,
                       False, u'', u'', u'Gesundheit', '1', '0.00', None))
loader.save(
    create_debts_entry(595, 24, 14, u'E', 23, None, '20.00', None, False,
                       False, u'', u'', u'Kleidung', '1', '0.00', None))
loader.save(
    create_debts_entry(596, 25, 14, u'E', 24, None, '26.00', None, False,
                       False, u'', u'', u'Ern\xe4hrung', '1', '0.00', None))
loader.save(
    create_debts_entry(597, 26, 14, u'E', 25, None, '31.00', None, False,
                       False, u'', u'', u'Hygiene', '1', '0.00', None))
loader.save(
    create_debts_entry(598, 27, 14, u'E', 26, None, '36.00', None, False,
                       False, u'', u'', u'Krankenkassenbeitr\xe4ge', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(599, 28, 14, u'E', 27, None, '41.00', None, False,
                       False, u'', u'', u'Gewerkschaftsbeitr\xe4ge', '1',
                       '0.00', None))
loader.save(
    create_debts_entry(600, 29, 14, u'E', 28, None, '47.00', None, False,
                       False, u'', u'', u'Unterhaltszahlungen', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(601, 30, 14, u'E', 32, None, '0.00', None, False, False,
                       u'', u'', u'Pensionssparen', '1', '0.00', None))
loader.save(
    create_debts_entry(602, 31, 14, u'E', 29, None, '5.00', None, False, False,
                       u'', u'', u'Tabak', '1', '0.00', None))
loader.save(
    create_debts_entry(603, 32, 14, u'E', 30, None, '10.00', None, False,
                       False, u'', u'Einkaufen', u'Freizeit & Unterhaltung',
                       '1', '0.00', None))
loader.save(
    create_debts_entry(604, 33, 14, u'E', 31, None, '15.00', None, False,
                       False, u'', u'', u'Haustiere', '1', '0.00', None))
loader.save(
    create_debts_entry(605, 34, 14, u'E', 33, None, '20.00', None, False,
                       False, u'', u'', u'Sonstige', '1', '0.00', None))
loader.save(
    create_debts_entry(606, 35, 14, u'E', 34, None, '26.00', None, False,
                       False, u'', u'', u'Gemeindesteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(607, 36, 14, u'E', 35, None, '31.00', None, False,
                       False, u'', u'', u'Kanalisationssteuer', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(608, 37, 14, u'E', 36, None, '36.00', None, False,
                       False, u'', u'', u'M\xfcllsteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(609, 38, 14, u'E', 37, None, '41.00', None, False,
                       False, u'', u'', u'Autosteuer', '12', '0.00', None))
loader.save(
    create_debts_entry(610, 39, 14, u'E', 38, None, '47.00', None, False,
                       False, u'', u'', u'Immobiliensteuer', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(611, 40, 14, u'E', 39, None, '0.00', None, False, False,
                       u'', u'', u'Andere', '12', '0.00', None))
loader.save(
    create_debts_entry(612, 41, 14, u'E', 40, None, '5.00', None, False, False,
                       u'', u'', u'Feuer', '12', '0.00', None))
loader.save(
    create_debts_entry(613, 42, 14, u'E', 41, None, '10.00', None, False,
                       False, u'', u'', u'Familienhaftpflicht', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(614, 43, 14, u'E', 42, None, '15.00', None, False,
                       False, u'', u'', u'Auto', '12', '0.00', None))
loader.save(
    create_debts_entry(615, 44, 14, u'E', 43, None, '20.00', None, False,
                       False, u'', u'', u'Lebensversicherung', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(616, 45, 14, u'E', 44, None, '26.00', None, False,
                       False, u'', u'', u'Andere Versicherungen', '12', '0.00',
                       None))
loader.save(
    create_debts_entry(617, 45, 1, u'L', 47, 100, '300.00', None, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(618, 46, 1, u'L', 48, 101, '600.00', 1, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(619, 47, 1, u'L', 49, 102, '900.00', 2, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(620, 48, 1, u'L', 50, 103, '1200.00', None, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 208))
loader.save(
    create_debts_entry(621, 45, 2, u'L', 51, 104, '1500.00', None, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 209))
loader.save(
    create_debts_entry(622, 46, 2, u'L', 47, 105, '300.00', 3, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(623, 47, 2, u'L', 48, 106, '600.00', 4, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(624, 48, 2, u'L', 49, 107, '900.00', None, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(625, 49, 2, u'L', 50, 108, '1200.00', 3, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 210))
loader.save(
    create_debts_entry(626, 50, 2, u'L', 51, 109, '1500.00', 4, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 211))
loader.save(
    create_debts_entry(627, 51, 2, u'L', 47, 110, '300.00', None, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(628, 52, 2, u'L', 48, 111, '600.00', 3, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(629, 45, 3, u'L', 49, 112, '900.00', None, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(630, 46, 3, u'L', 50, 187, '1200.00', 5, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 208))
loader.save(
    create_debts_entry(631, 47, 3, u'L', 51, 188, '1500.00', 6, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 209))
loader.save(
    create_debts_entry(632, 48, 3, u'L', 47, 189, '300.00', None, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(633, 49, 3, u'L', 48, 190, '600.00', 5, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(634, 45, 4, u'L', 49, 191, '900.00', None, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(635, 46, 4, u'L', 50, 192, '1200.00', 7, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 210))
loader.save(
    create_debts_entry(636, 47, 4, u'L', 51, 193, '1500.00', 8, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 211))
loader.save(
    create_debts_entry(637, 45, 5, u'L', 47, 194, '300.00', None, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(638, 46, 5, u'L', 48, 195, '600.00', 9, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(639, 47, 5, u'L', 49, 196, '900.00', 10, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(640, 48, 5, u'L', 50, 197, '1200.00', None, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 208))
loader.save(
    create_debts_entry(641, 49, 5, u'L', 51, 198, '1500.00', 9, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 209))
loader.save(
    create_debts_entry(642, 50, 5, u'L', 47, 199, '300.00', 10, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(643, 51, 5, u'L', 48, 200, '600.00', None, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(644, 52, 5, u'L', 49, 201, '900.00', 9, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(645, 53, 5, u'L', 50, 202, '1200.00', 10, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 210))
loader.save(
    create_debts_entry(646, 54, 5, u'L', 51, 203, '1500.00', None, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 211))
loader.save(
    create_debts_entry(647, 55, 5, u'L', 47, 204, '300.00', 9, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(648, 56, 5, u'L', 48, 205, '600.00', 10, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(649, 45, 6, u'L', 49, 206, '900.00', None, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(650, 46, 6, u'L', 50, 207, '1200.00', 11, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 208))
loader.save(
    create_debts_entry(651, 47, 6, u'L', 51, 208, '1500.00', 12, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 209))
loader.save(
    create_debts_entry(652, 48, 6, u'L', 47, 209, '300.00', None, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(653, 49, 6, u'L', 48, 210, '600.00', 11, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(654, 45, 7, u'L', 49, 211, '900.00', None, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(655, 46, 7, u'L', 50, 214, '1200.00', 13, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 210))
loader.save(
    create_debts_entry(656, 47, 7, u'L', 51, 220, '1500.00', 14, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 211))
loader.save(
    create_debts_entry(657, 48, 7, u'L', 47, 221, '300.00', None, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(658, 45, 8, u'L', 48, 222, '600.00', None, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(659, 46, 8, u'L', 49, 223, '900.00', 15, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(660, 47, 8, u'L', 50, 224, '1200.00', 16, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 208))
loader.save(
    create_debts_entry(661, 48, 8, u'L', 51, 225, '1500.00', 17, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 209))
loader.save(
    create_debts_entry(662, 49, 8, u'L', 47, 226, '300.00', 18, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(663, 50, 8, u'L', 48, 227, '600.00', 19, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(664, 51, 8, u'L', 49, 228, '900.00', None, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(665, 52, 8, u'L', 50, 229, '1200.00', 15, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 210))
loader.save(
    create_debts_entry(666, 45, 9, u'L', 51, 230, '1500.00', None, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 211))
loader.save(
    create_debts_entry(667, 46, 9, u'L', 47, 231, '300.00', 20, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(668, 47, 9, u'L', 48, 100, '600.00', 21, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(669, 48, 9, u'L', 49, 101, '900.00', 22, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(670, 49, 9, u'L', 50, 102, '1200.00', 23, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 208))
loader.save(
    create_debts_entry(671, 45, 10, u'L', 51, 103, '1500.00', None, False,
                       True, u'', u'', u'Inkasso-Unternehmen', '1', '0.00',
                       209))
loader.save(
    create_debts_entry(672, 46, 10, u'L', 47, 104, '300.00', 25, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(673, 47, 10, u'L', 48, 105, '600.00', 26, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(674, 45, 11, u'L', 49, 106, '900.00', None, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(675, 46, 11, u'L', 50, 107, '1200.00', 29, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 210))
loader.save(
    create_debts_entry(676, 47, 11, u'L', 51, 108, '1500.00', 30, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 211))
loader.save(
    create_debts_entry(677, 48, 11, u'L', 47, 109, '300.00', 31, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(678, 49, 11, u'L', 48, 110, '600.00', 32, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(679, 50, 11, u'L', 49, 111, '900.00', 33, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(680, 51, 11, u'L', 50, 112, '1200.00', 34, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 208))
loader.save(
    create_debts_entry(681, 52, 11, u'L', 51, 187, '1500.00', 35, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 209))
loader.save(
    create_debts_entry(682, 53, 11, u'L', 47, 188, '300.00', 36, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(683, 54, 11, u'L', 48, 189, '600.00', None, False,
                       False, u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(684, 55, 11, u'L', 49, 190, '900.00', 29, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(685, 56, 11, u'L', 50, 191, '1200.00', 30, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 210))
loader.save(
    create_debts_entry(686, 45, 12, u'L', 51, 192, '1500.00', None, False,
                       True, u'', u'', u'Inkasso-Unternehmen', '1', '0.00',
                       211))
loader.save(
    create_debts_entry(687, 46, 12, u'L', 47, 193, '300.00', 37, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(688, 47, 12, u'L', 48, 194, '600.00', 38, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(689, 48, 12, u'L', 49, 195, '900.00', 39, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(690, 49, 12, u'L', 50, 196, '1200.00', 40, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 208))
loader.save(
    create_debts_entry(691, 45, 13, u'L', 51, 197, '1500.00', None, False,
                       True, u'', u'', u'Inkasso-Unternehmen', '1', '0.00',
                       209))
loader.save(
    create_debts_entry(692, 46, 13, u'L', 47, 198, '300.00', 46, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(693, 47, 13, u'L', 48, 199, '600.00', 47, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(694, 48, 13, u'L', 49, 200, '900.00', 48, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(695, 45, 14, u'L', 50, 201, '1200.00', None, False,
                       True, u'', u'', u'Gerichtsvollzieher', '1', '0.00',
                       210))
loader.save(
    create_debts_entry(696, 46, 14, u'L', 51, 202, '1500.00', 55, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 211))
loader.save(
    create_debts_entry(697, 47, 14, u'L', 47, 203, '300.00', 56, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(698, 48, 14, u'L', 48, 204, '600.00', 57, False, False,
                       u'', u'', u'Schulden', '1', '30.00', None))
loader.save(
    create_debts_entry(699, 49, 14, u'L', 49, 205, '900.00', 58, False, True,
                       u'', u'', u'Zahlungsr\xfcckst\xe4nde', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(700, 50, 14, u'L', 50, 206, '1200.00', 59, False, True,
                       u'', u'', u'Gerichtsvollzieher', '1', '0.00', 208))
loader.save(
    create_debts_entry(701, 51, 14, u'L', 51, 207, '1500.00', 60, False, True,
                       u'', u'', u'Inkasso-Unternehmen', '1', '0.00', 209))
loader.save(
    create_debts_entry(702, 52, 14, u'L', 47, 208, '300.00', 61, False, False,
                       u'', u'', u'Kredite', '1', '15.00', None))
loader.save(
    create_debts_entry(703, 17, 1, u'E', 16, None, '26.00', None, False, False,
                       u'', u'Kino', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(704, 17, 2, u'E', 16, None, '47.00', None, False, False,
                       u'', u'Seminar', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(705, 17, 3, u'E', 16, None, '15.00', None, False, False,
                       u'', u'Einkaufen', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(706, 17, 4, u'E', 16, None, '36.00', None, False, False,
                       u'', u'Kino', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(707, 17, 5, u'E', 16, None, '5.00', None, False, False,
                       u'', u'Seminar', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(708, 17, 6, u'E', 16, None, '26.00', None, False, False,
                       u'', u'Einkaufen', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(709, 17, 7, u'E', 16, None, '47.00', None, False, False,
                       u'', u'Kino', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(710, 17, 8, u'E', 16, None, '15.00', None, False, False,
                       u'', u'Seminar', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(711, 17, 9, u'E', 16, None, '36.00', None, False, False,
                       u'', u'Einkaufen', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(712, 17, 10, u'E', 16, None, '5.00', None, False, False,
                       u'', u'Kino', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(713, 17, 11, u'E', 16, None, '26.00', None, False,
                       False, u'', u'Seminar', u'Fahrtkosten', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(714, 17, 12, u'E', 16, None, '47.00', None, False,
                       False, u'', u'Einkaufen', u'Fahrtkosten', '1', '0.00',
                       None))
loader.save(
    create_debts_entry(715, 17, 13, u'E', 16, None, '15.00', None, False,
                       False, u'', u'Kino', u'Fahrtkosten', '1', '0.00', None))
loader.save(
    create_debts_entry(716, 17, 14, u'E', 16, None, '36.00', None, False,
                       False, u'', u'Seminar', u'Fahrtkosten', '1', '0.00',
                       None))

loader.flush_deferred_objects()

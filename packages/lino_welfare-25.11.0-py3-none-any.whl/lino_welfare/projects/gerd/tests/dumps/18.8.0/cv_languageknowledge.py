# -*- coding: UTF-8 -*-
logger.info("Loading 112 objects to table cv_languageknowledge...")
# fields: id, person, language, spoken, written, spoken_passively, written_passively, native, cef_level
loader.save(
    create_cv_languageknowledge(1, 118, u'ger', u'4', u'4', None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(2, 116, u'ger', u'4', u'4', None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(3, 127, u'ger', u'4', u'2', None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(4, 128, u'ger', u'4', u'0', None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(5, 124, u'ger', u'1', u'2', None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(6, 118, u'fre', u'3', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(7, 116, u'fre', u'3', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(8, 118, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(9, 116, u'eng', u'3', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(10, 124, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(11, 116, u'dut', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(12, 118, u'est', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(13, 124, u'est', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(14, 127, u'est', u'4', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(15, 128, u'est', u'3', u'0', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(16, 117, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(17, 117, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(18, 117, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(19, 120, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(20, 120, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(21, 120, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(22, 121, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(23, 121, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(24, 122, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(25, 122, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(26, 122, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(27, 123, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(28, 123, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(29, 124, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(30, 125, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(31, 125, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(32, 126, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(33, 126, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(34, 126, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(35, 127, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(36, 128, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(37, 128, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(38, 129, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(39, 129, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(40, 130, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(41, 130, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(42, 130, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(43, 131, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(44, 131, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(45, 132, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(46, 132, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(47, 133, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(48, 133, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(49, 134, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(50, 134, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(51, 134, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(52, 135, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(53, 135, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(54, 136, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(55, 136, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(56, 136, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(57, 137, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(58, 137, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(59, 138, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(60, 138, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(61, 138, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(62, 139, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(63, 139, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(64, 140, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(65, 140, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(66, 140, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(67, 141, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(68, 141, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(69, 142, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(70, 142, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(71, 142, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(72, 143, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(73, 143, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(74, 144, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(75, 144, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(76, 144, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(77, 145, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(78, 145, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(79, 146, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(80, 146, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(81, 146, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(82, 147, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(83, 149, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(84, 149, u'ger', None, None, None, None, True,
                                None))
loader.save(
    create_cv_languageknowledge(85, 149, u'fre', u'2', u'2', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(86, 150, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(87, 151, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(88, 152, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(89, 153, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(90, 154, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(91, 155, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(92, 156, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(93, 157, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(94, 158, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(95, 159, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(96, 160, u'eng', u'4', u'4', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(97, 161, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(98, 162, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(99, 165, u'eng', u'3', u'3', None, None, False,
                                None))
loader.save(
    create_cv_languageknowledge(100, 166, u'eng', u'3', u'3', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(101, 167, u'eng', u'4', u'4', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(102, 168, u'eng', u'3', u'3', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(103, 172, u'eng', u'3', u'3', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(104, 173, u'eng', u'4', u'4', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(105, 174, u'eng', u'3', u'3', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(106, 175, u'eng', u'3', u'3', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(107, 176, u'eng', u'4', u'4', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(108, 177, u'eng', u'3', u'3', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(109, 178, u'eng', u'3', u'3', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(110, 179, u'eng', u'4', u'4', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(111, 180, u'eng', u'3', u'3', None, None,
                                False, None))
loader.save(
    create_cv_languageknowledge(112, 181, u'eng', u'3', u'3', None, None,
                                False, None))

loader.flush_deferred_objects()

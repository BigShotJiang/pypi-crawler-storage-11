# -*- coding: UTF-8 -*-
logger.info("Loading 34 objects to table b2c_statement...")
# fields: id, account, statement_number, start_date, end_date, balance_start, balance_end, local_currency
loader.save(
    create_b2c_statement(1, 1, u'2015/0104', date(2015, 9, 4),
                         date(2015, 9, 7), '2378.68', '2308.68', u'EUR'))
loader.save(
    create_b2c_statement(2, 2, u'2015/0087', date(2015, 9, 4),
                         date(2015, 9, 7), '1022.04', '872.04', u'EUR'))
loader.save(
    create_b2c_statement(3, 3, u'2015/0059', date(2015, 9, 4),
                         date(2015, 9, 7), '72.30', '913.45', u'EUR'))
loader.save(
    create_b2c_statement(4, 4, u'2015/0086', date(2015, 9, 4),
                         date(2015, 9, 7), '738.15', '588.15', u'EUR'))
loader.save(
    create_b2c_statement(5, 5, u'2015/0132', date(2015, 9, 4),
                         date(2015, 9, 7), '7156.50', '7006.50', u'EUR'))
loader.save(
    create_b2c_statement(6, 6, u'2015/0037', date(2015, 9, 4),
                         date(2015, 9, 7), '1073.40', '0.00', u'EUR'))
loader.save(
    create_b2c_statement(7, 7, u'2015/0048', date(2015, 9, 4),
                         date(2015, 9, 7), '1142.78', '0.00', u'EUR'))
loader.save(
    create_b2c_statement(8, 8, u'2015/0070', date(2015, 9, 4),
                         date(2015, 9, 7), '356.74', '1332.07', u'EUR'))
loader.save(
    create_b2c_statement(9, 9, u'2015/0022', date(2015, 9, 4),
                         date(2015, 9, 7), '1106.76', '0.00', u'EUR'))
loader.save(
    create_b2c_statement(10, 10, u'2015/0046', date(2015, 9, 4),
                         date(2015, 9, 7), '1110.55', '0.00', u'EUR'))
loader.save(
    create_b2c_statement(11, 11, u'2015/0065', date(2015, 9, 4),
                         date(2015, 9, 7), '555.94', '405.94', u'EUR'))
loader.save(
    create_b2c_statement(12, 12, u'2015/0087', date(2015, 9, 4),
                         date(2015, 9, 7), '580.71', '430.71', u'EUR'))
loader.save(
    create_b2c_statement(13, 13, u'2015/0094', date(2015, 9, 4),
                         date(2015, 9, 7), '3203.51', '3216.51', u'EUR'))
loader.save(
    create_b2c_statement(14, 14, u'2015/0110', date(2015, 9, 4),
                         date(2015, 9, 7), '415.73', '365.73', u'EUR'))
loader.save(
    create_b2c_statement(15, 15, u'2015/0085', date(2015, 9, 4),
                         date(2015, 9, 7), '675.74', '521.00', u'EUR'))
loader.save(
    create_b2c_statement(16, 16, u'2015/0058', date(2015, 9, 4),
                         date(2015, 9, 7), '774.34', '0.00', u'EUR'))
loader.save(
    create_b2c_statement(17, 17, u'2015/0077', date(2015, 9, 4),
                         date(2015, 9, 7), '318.41', '147.52', u'EUR'))
loader.save(
    create_b2c_statement(18, 18, u'2015/0075', date(2015, 9, 4),
                         date(2015, 9, 7), '37.60', '52.60', u'EUR'))
loader.save(
    create_b2c_statement(19, 19, u'2015/0059', date(2015, 9, 4),
                         date(2015, 9, 7), '1132.58', '0.00', u'EUR'))
loader.save(
    create_b2c_statement(20, 20, u'2015/0060', date(2015, 9, 4),
                         date(2015, 9, 7), '791.44', '0.00', u'EUR'))
loader.save(
    create_b2c_statement(21, 21, u'2015/0098', date(2015, 9, 4),
                         date(2015, 9, 7), '657.26', '577.26', u'EUR'))
loader.save(
    create_b2c_statement(22, 22, u'2015/0050', date(2015, 9, 4),
                         date(2015, 9, 7), '1710.28', '1630.28', u'EUR'))
loader.save(
    create_b2c_statement(23, 23, u'2015/0040', date(2015, 8, 31),
                         date(2015, 9, 7), '0.00', '21.50', u'EUR'))
loader.save(
    create_b2c_statement(24, 24, u'2015/0025', date(2015, 9, 4),
                         date(2015, 9, 7), '369.41', '353.36', u'EUR'))
loader.save(
    create_b2c_statement(25, 25, u'2015/0020', date(2015, 9, 4),
                         date(2015, 9, 7), '311.65', '271.65', u'EUR'))
loader.save(
    create_b2c_statement(26, 26, u'2015/0006', date(2015, 8, 6),
                         date(2015, 9, 7), '335.16', '29.59', u'EUR'))
loader.save(
    create_b2c_statement(27, 27, u'2015/0004', date(2015, 8, 6),
                         date(2015, 9, 7), '5970.59', '5970.59', u'EUR'))
loader.save(
    create_b2c_statement(28, 28, u'2015/0010', date(2015, 7, 16),
                         date(2015, 9, 7), '894.66', '394.66', u'EUR'))
loader.save(
    create_b2c_statement(29, 29, u'2015/0015', date(2015, 8, 13),
                         date(2015, 9, 7), '1162.78', '1002.78', u'EUR'))
loader.save(
    create_b2c_statement(30, 30, u'2015/0003', date(2015, 8, 6),
                         date(2015, 9, 7), '654.29', '20.09', u'EUR'))
loader.save(
    create_b2c_statement(31, 31, u'2015/0015', date(2015, 8, 13),
                         date(2015, 9, 7), '780.97', '480.97', u'EUR'))
loader.save(
    create_b2c_statement(32, 32, u'2015/0170', date(2015, 9, 4),
                         date(2015, 9, 7), '232997.14', '20902.40', u'EUR'))
loader.save(
    create_b2c_statement(33, 33, u'2015/0169', date(2015, 9, 4),
                         date(2015, 9, 7), '17616.32', '11625.72', u'EUR'))
loader.save(
    create_b2c_statement(34, 34, u'2015/0104', date(2015, 9, 4),
                         date(2015, 9, 7), '1527.62', '1917.48', u'EUR'))

loader.flush_deferred_objects()

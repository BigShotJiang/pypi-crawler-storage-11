# -*- coding: UTF-8 -*-
logger.info("Loading 29 objects to table ledger_accountingperiod...")
# fields: id, ref, start_date, end_date, state, year, remark
loader.save(
    create_ledger_accountingperiod(7, u'2012-01', date(2012, 1, 1),
                                   date(2012, 1, 31), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(8, u'2012-02', date(2012, 2, 1),
                                   date(2012, 2, 29), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(9, u'2012-03', date(2012, 3, 1),
                                   date(2012, 3, 31), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(10, u'2012-04', date(2012, 4, 1),
                                   date(2012, 4, 30), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(11, u'2012-05', date(2012, 5, 1),
                                   date(2012, 5, 31), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(12, u'2012-06', date(2012, 6, 1),
                                   date(2012, 6, 30), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(13, u'2012-07', date(2012, 7, 1),
                                   date(2012, 7, 31), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(14, u'2012-08', date(2012, 8, 1),
                                   date(2012, 8, 31), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(15, u'2012-09', date(2012, 9, 1),
                                   date(2012, 9, 30), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(16, u'2012-10', date(2012, 10, 1),
                                   date(2012, 10, 31), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(17, u'2012-11', date(2012, 11, 1),
                                   date(2012, 11, 30), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(18, u'2012-12', date(2012, 12, 1),
                                   date(2012, 12, 31), '10', 1, u''))
loader.save(
    create_ledger_accountingperiod(19, u'2013-01', date(2013, 1, 1),
                                   date(2013, 1, 31), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(20, u'2013-02', date(2013, 2, 1),
                                   date(2013, 2, 28), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(21, u'2013-03', date(2013, 3, 1),
                                   date(2013, 3, 31), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(22, u'2013-04', date(2013, 4, 1),
                                   date(2013, 4, 30), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(23, u'2013-05', date(2013, 5, 1),
                                   date(2013, 5, 31), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(24, u'2013-06', date(2013, 6, 1),
                                   date(2013, 6, 30), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(25, u'2013-07', date(2013, 7, 1),
                                   date(2013, 7, 31), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(26, u'2013-08', date(2013, 8, 1),
                                   date(2013, 8, 31), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(27, u'2013-09', date(2013, 9, 1),
                                   date(2013, 9, 30), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(28, u'2013-10', date(2013, 10, 1),
                                   date(2013, 10, 31), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(29, u'2013-11', date(2013, 11, 1),
                                   date(2013, 11, 30), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(6, u'2013-12', date(2013, 12, 1),
                                   date(2013, 12, 31), '10', 2, u''))
loader.save(
    create_ledger_accountingperiod(5, u'2014-01', date(2014, 1, 1),
                                   date(2014, 1, 31), '10', 3, u''))
loader.save(
    create_ledger_accountingperiod(4, u'2014-02', date(2014, 2, 1),
                                   date(2014, 2, 28), '10', 3, u''))
loader.save(
    create_ledger_accountingperiod(3, u'2014-03', date(2014, 3, 1),
                                   date(2014, 3, 31), '10', 3, u''))
loader.save(
    create_ledger_accountingperiod(2, u'2014-04', date(2014, 4, 1),
                                   date(2014, 4, 30), '10', 3, u''))
loader.save(
    create_ledger_accountingperiod(1, u'2014-05', date(2014, 5, 1),
                                   date(2014, 5, 31), '10', 3, u''))

loader.flush_deferred_objects()

# -*- coding: UTF-8 -*-
logger.info("Loading 21 objects to table excerpts_excerpttype...")
# fields: id, name, build_method, template, attach_to_email, email_template, certifying, remark, body_template, content_type, primary, backward_compat, print_recipient, print_directly, shortcut
loader.save(
    create_excerpts_excerpttype(
        1,
        ['Nutzungsbestimmungen', 'Nutzungsbestimmungen', 'Terms & conditions'],
        u'appypdf', u'TermsConditions.odt', False, u'', False, u'', u'',
        contacts_Person, False, False, True, True, None))
loader.save(
    create_excerpts_excerpttype(2, [
        'Einkommensbescheinigung', 'Certificat de revenu',
        'Income confirmation'
    ], None, u'Default.odt', False, u'', True, u'', u'certificate.body.html',
                                aids_IncomeConfirmation, True, False, True,
                                True, None))
loader.save(
    create_excerpts_excerpttype(3, [
        'Kosten\xfcbernahmeschein', 'Kosten\xfcbernahmeschein',
        'Refund confirmation'
    ], None, u'Default.odt', False, u'', True, u'', u'certificate.body.html',
                                aids_RefundConfirmation, True, False, True,
                                True, None))
loader.save(
    create_excerpts_excerpttype(4, [
        'Einfache Bescheinigung', 'Confirmation simple', 'Simple confirmation'
    ], None, u'Default.odt', False, u'', True, u'', u'certificate.body.html',
                                aids_SimpleConfirmation, True, False, True,
                                True, None))
loader.save(
    create_excerpts_excerpttype(5, [
        'Art.61-Konvention', "Mise \xe0 l'emploi art.61",
        'Art61 job supplyment'
    ], None, u'', False, u'', True, u'', u'contract.body.html', art61_Contract,
                                True, False, False, True, None))
loader.save(
    create_excerpts_excerpttype(6, [
        'IdentifyPerson-Anfrage', 'Requ\xeate IdentifyPerson',
        'IdentifyPerson Request'
    ], None, u'', False, u'', True, u'', u'', cbss_IdentifyPersonRequest, True,
                                False, True, True, None))
loader.save(
    create_excerpts_excerpttype(7, [
        'ManageAccess-Anfrage', 'Requ\xeate ManageAccess',
        'ManageAccess Request'
    ], None, u'', False, u'', True, u'', u'', cbss_ManageAccessRequest, True,
                                False, True, True, None))
loader.save(
    create_excerpts_excerpttype(
        8, ['Tx25-Anfrage', 'Requ\xeate Tx25', 'Tx25 Request'], None, u'',
        False, u'', True, u'', u'', cbss_RetrieveTIGroupsRequest, True, False,
        True, True, None))
loader.save(
    create_excerpts_excerpttype(9, [
        'Finanzielle Situation', 'Situation financi\xe8re',
        'Financial situation'
    ], None, u'', False, u'', True, u'', u'', debts_Budget, True, False, True,
                                True, None))
loader.save(
    create_excerpts_excerpttype(
        10, ['Training report', 'Training report', 'Training report'],
        u'weasy2pdf', u'', False, u'', True, u'', u'', esf_ClientSummary, True,
        False, True, True, None))
loader.save(
    create_excerpts_excerpttype(
        11, ['Kontoauszug', 'Kontoauszug', 'Bank Statement'], None, u'', False,
        u'', True, u'', u'', finan_BankStatement, True, False, True, True,
        None))
loader.save(
    create_excerpts_excerpttype(
        12, ['Diverse Buchung', 'Diverse Buchung', 'Journal Entry'], None, u'',
        False, u'', True, u'', u'', finan_JournalEntry, True, False, True,
        True, None))
loader.save(
    create_excerpts_excerpttype(
        13, ['Zahlungsauftrag', 'Zahlungsauftrag', 'Payment Order'], None, u'',
        False, u'', True, u'', u'', finan_PaymentOrder, True, False, True,
        True, None))
loader.save(
    create_excerpts_excerpttype(14, ['VSE', 'PIIS', 'ISIP'], None, u'', False,
                                u'', True, u'', u'', isip_Contract, True, True,
                                True, True, None))
loader.save(
    create_excerpts_excerpttype(15, [
        'Art.60\xa77-Konvention', "Mise \xe0 l'emploi art60\xa77",
        'Art60\xa77 job supplyment'
    ], None, u'', False, u'', True, u'', u'', jobs_Contract, True, True, True,
                                True, None))
loader.save(
    create_excerpts_excerpttype(
        16, ['Zahlungserinnerung', 'Rappel de paiement', 'Payment reminder'],
        u'weasy2pdf', u'payment_reminder.weasy.html', False, u'', False, u'',
        u'', contacts_Partner, False, False, True, True, None))
loader.save(
    create_excerpts_excerpttype(17, [
        'Anwesenheitsbescheinigung', 'Attestation de pr\xe9sence',
        'Presence certificate'
    ], None, u'Default.odt', False, u'Default.eml.html', False, u'',
                                u'presence_certificate.body.html', cal_Guest,
                                True, False, True, True, None))
loader.save(
    create_excerpts_excerpttype(
        18, ['Curriculum vitae', 'Curriculum vitae', 'Curriculum vitae'],
        u'appyrtf', u'cv.odt', False, u'Default.eml.html', False, u'', u'',
        pcsw_Client, False, False, True, True, u'pcsw.Client.cvs_emitted'))
loader.save(
    create_excerpts_excerpttype(19,
                                ['Aktenblatt', 'Fiche client', 'File sheet'],
                                None, u'file_sheet.odt', False,
                                u'Default.eml.html', False, u'', u'',
                                pcsw_Client, True, False, True, True, None))
loader.save(
    create_excerpts_excerpttype(
        20, ['eID-Inhalt', 'Contenu carte eID', 'eID sheet'], None,
        u'eid-content.odt', False, u'Default.eml.html', False, u'', u'',
        pcsw_Client, False, False, True, True, None))
loader.save(
    create_excerpts_excerpttype(
        21, ['Aktionsplan', "Plan d'action", 'Action plan'], None,
        u'Default.odt', False, u'Default.eml.html', False, u'',
        u'pac.body.html', pcsw_Client, False, False, True, True, None))

loader.flush_deferred_objects()

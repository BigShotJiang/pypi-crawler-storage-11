# -*- coding: UTF-8 -*-
logger.info("Loading 51 objects to table debts_account...")
# fields: id, ref, seqno, name, group, type, required_for_household, required_for_person, periods, default_amount
loader.save(
    create_debts_account(1, u'1010', 1,
                         ['Geh\xe4lter', 'Salaires', 'Salaries'], 1, u'I',
                         False, True, '1', None))
loader.save(
    create_debts_account(2, u'1020', 2, ['Renten', 'Pension', 'Pension'], 1,
                         u'I', False, True, '1', None))
loader.save(
    create_debts_account(3, u'1030', 3, [
        'Integrationszulage', "Allocation d'int\xe9gration", 'Integration aid'
    ], 1, u'I', False, True, '1', None))
loader.save(
    create_debts_account(
        4, u'1040', 4,
        ['Ersatzeink\xfcnfte', 'Ersatzeink\xfcnfte', 'Ersatzeink\xfcnfte'], 1,
        u'I', False, True, '1', None))
loader.save(
    create_debts_account(5, u'1050', 5, ['Alimente', 'Aliments', 'Aliments'],
                         1, u'I', False, True, '1', None))
loader.save(
    create_debts_account(
        6, u'1060', 6,
        ['Essen-Schecks', 'Ch\xe8ques-repas', 'Ch\xe8ques-repas'], 1, u'I',
        False, True, '1', None))
loader.save(
    create_debts_account(7, u'1090', 7, ['Andere', 'Andere', 'Andere'], 1,
                         u'I', False, True, '1', None))
loader.save(
    create_debts_account(8, u'2010', 8,
                         ['Urlaubsgeld', 'Cong\xe9 pay\xe9', 'Paid holiday'],
                         2, u'I', False, True, '12', None))
loader.save(
    create_debts_account(
        9, u'2020', 9,
        ['Jahresendzulage', "Prime de fin d'ann\xe9e", 'Year-end prime'], 2,
        u'I', False, True, '12', None))
loader.save(
    create_debts_account(10, u'2030', 10, [
        'Gewerkschaftspr\xe4mie', 'Gewerkschaftspr\xe4mie',
        'Gewerkschaftspr\xe4mie'
    ], 2, u'I', False, True, '12', None))
loader.save(
    create_debts_account(11, u'3010', 11, ['Miete', 'Loyer', 'Rent'], 3, u'E',
                         True, False, '1', None))
loader.save(
    create_debts_account(12, u'3011', 12, ['Wasser', 'Eau', 'Water'], 3, u'E',
                         True, False, '1', None))
loader.save(
    create_debts_account(13, u'3012', 13,
                         ['Strom', 'Electricit\xe9', 'Electricity'], 3, u'E',
                         True, False, '1', None))
loader.save(
    create_debts_account(14, u'3020', 14, [
        'Festnetz-Telefon und Internet', 'T\xe9l\xe9phone fixe et Internet',
        'Telephone & Internet'
    ], 3, u'E', True, False, '1', None))
loader.save(
    create_debts_account(15, u'3021', 15, ['Handy', 'GSM', 'Cell phone'], 3,
                         u'E', True, False, '1', None))
loader.save(
    create_debts_account(
        16, u'3030', 16,
        ['Fahrtkosten', 'Frais de transport', 'Transport costs'], 3, u'E',
        True, False, '1', None))
loader.save(
    create_debts_account(
        17, u'3031', 17,
        ['TEC Busabonnement', 'Abonnement bus', 'Public transport'], 3, u'E',
        True, False, '1', None))
loader.save(
    create_debts_account(18, u'3032', 18, ['Benzin', 'Essence', 'Fuel'], 3,
                         u'E', True, False, '1', None))
loader.save(
    create_debts_account(
        19, u'3033', 19,
        ['Unterhalt Auto', 'Maintenance voiture', 'Car maintenance'], 3, u'E',
        True, False, '1', None))
loader.save(
    create_debts_account(20, u'3040', 20,
                         ['Schulkosten', '\xc9cole', 'School'], 3, u'E', True,
                         False, '1', None))
loader.save(
    create_debts_account(
        21, u'3041', 21,
        ['Tagesmutter & Kleinkindbetreuung', 'Garde enfant', 'Babysitting'], 3,
        u'E', True, False, '1', None))
loader.save(
    create_debts_account(22, u'3050', 22, ['Gesundheit', 'Sant\xe9', 'Health'],
                         3, u'E', True, False, '1', None))
loader.save(
    create_debts_account(23, u'3051', 23,
                         ['Kleidung', 'V\xeatements', 'Clothes'], 3, u'E',
                         True, False, '1', None))
loader.save(
    create_debts_account(24, u'3052', 24,
                         ['Ern\xe4hrung', 'Alimentation', 'Food'], 3, u'E',
                         True, False, '1', None))
loader.save(
    create_debts_account(25, u'3053', 25, ['Hygiene', 'Hygi\xe8ne', 'Hygiene'],
                         3, u'E', True, False, '1', None))
loader.save(
    create_debts_account(
        26, u'3060', 26,
        ['Krankenkassenbeitr\xe4ge', 'Mutuelle', 'Health insurance'], 3, u'E',
        True, False, '1', None))
loader.save(
    create_debts_account(
        27, u'3061', 27,
        ['Gewerkschaftsbeitr\xe4ge', 'Cotisations syndicat', 'Labour fees'], 3,
        u'E', True, False, '1', None))
loader.save(
    create_debts_account(
        28, u'3062', 28,
        ['Unterhaltszahlungen', 'Unterhaltszahlungen', 'Unterhaltszahlungen'],
        3, u'E', True, False, '1', None))
loader.save(
    create_debts_account(
        32, u'3063', 32,
        ['Pensionssparen', '\xc9pargne pension', 'Retirement savings'], 3,
        u'E', True, False, '1', None))
loader.save(
    create_debts_account(29, u'3070', 29, ['Tabak', 'Tabac', 'Tobacco'], 3,
                         u'E', True, False, '1', None))
loader.save(
    create_debts_account(30, u'3071', 30,
                         ['Freizeit & Unterhaltung', 'Loisirs', 'Spare time'],
                         3, u'E', True, False, '1', None))
loader.save(
    create_debts_account(31, u'3072', 31,
                         ['Haustiere', 'Animaux domestiques', 'Pets'], 3, u'E',
                         True, False, '1', None))
loader.save(
    create_debts_account(33, u'3090', 33, ['Sonstige', 'Autres', 'Other'], 3,
                         u'E', True, False, '1', None))
loader.save(
    create_debts_account(34, u'4010', 34,
                         ['Gemeindesteuer', 'Taxe communale', 'Municipal tax'],
                         4, u'E', True, False, '12', None))
loader.save(
    create_debts_account(
        35, u'4020', 35,
        ['Kanalisationssteuer', 'Kanalisationssteuer', 'Kanalisationssteuer'],
        4, u'E', True, False, '12', None))
loader.save(
    create_debts_account(36, u'4030', 36,
                         ['M\xfcllsteuer', 'Taxe d\xe9chets', 'Waste tax'], 4,
                         u'E', True, False, '12', None))
loader.save(
    create_debts_account(37, u'4040', 37,
                         ['Autosteuer', 'Taxe circulation', 'Autosteuer'], 4,
                         u'E', True, False, '12', None))
loader.save(
    create_debts_account(
        38, u'4050', 38,
        ['Immobiliensteuer', 'Taxe immobili\xe8re', 'Immobiliensteuer'], 4,
        u'E', True, False, '12', None))
loader.save(
    create_debts_account(39, u'4090', 39, ['Andere', 'Autres', 'Other'], 4,
                         u'E', True, False, '12', None))
loader.save(
    create_debts_account(40, u'5010', 40, ['Feuer', 'Incendie', 'Fire'], 5,
                         u'E', True, False, '12', None))
loader.save(
    create_debts_account(41, u'5020', 41, [
        'Familienhaftpflicht', 'Responsabilit\xe9 famille',
        'Familienhaftpflicht'
    ], 5, u'E', True, False, '12', None))
loader.save(
    create_debts_account(42, u'5030', 42, ['Auto', 'Voiture', 'Car insurance'],
                         5, u'E', True, False, '12', None))
loader.save(
    create_debts_account(
        43, u'5040', 43,
        ['Lebensversicherung', 'Assurance vie', 'Life insurance'], 5, u'E',
        True, False, '12', None))
loader.save(
    create_debts_account(
        44, u'5090', 44,
        ['Andere Versicherungen', 'Autres assurances', 'Other insurances'], 5,
        u'E', True, False, '12', None))
loader.save(
    create_debts_account(45, u'6010', 45, ['Haus', 'Maison', 'House'], 6, u'A',
                         False, False, '1', None))
loader.save(
    create_debts_account(46, u'6020', 46, ['Auto', 'Voiture', 'Car'], 6, u'A',
                         False, False, '1', None))
loader.save(
    create_debts_account(47, u'7010', 47, ['Kredite', 'Cr\xe9dits', 'Loans'],
                         7, u'L', False, False, '1', None))
loader.save(
    create_debts_account(48, u'7020', 48, ['Schulden', 'Dettes', 'Debts'], 7,
                         u'L', False, False, '1', None))
loader.save(
    create_debts_account(
        49, u'7040', 49,
        ['Zahlungsr\xfcckst\xe4nde', 'Factures \xe0 payer', 'Invoices to pay'],
        7, u'L', False, False, '1', None))
loader.save(
    create_debts_account(50, u'7100', 50,
                         ['Gerichtsvollzieher', 'Huissier', 'Bailiff'], 8,
                         u'L', False, False, '1', None))
loader.save(
    create_debts_account(
        51, u'7110', 51,
        ['Inkasso-Unternehmen', "Agent d'encaissement", 'Cash agency'], 8,
        u'L', False, False, '1', None))

loader.flush_deferred_objects()

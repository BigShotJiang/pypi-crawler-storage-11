# -*- coding: UTF-8 -*-
logger.info("Loading 74 objects to table jobs_candidature...")
# fields: id, sector, function, person, job, date_submitted, remark, state, art60, art61
loader.save(
    create_jobs_candidature(1, None, None, 129, 1, date(2014, 4, 12), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(2, None, None, 130, 5, date(2014, 4, 13), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(3, None, None, 132, 2, date(2014, 4, 14), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(4, None, None, 133, 6, date(2014, 4, 15), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(5, None, None, 137, 3, date(2014, 4, 16), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(6, None, None, 139, 7, date(2014, 4, 17), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(7, None, None, 141, 4, date(2014, 4, 18), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(8, None, None, 142, 8, date(2014, 4, 19), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(9, None, None, 144, 1, date(2014, 4, 20), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(10, None, None, 146, 5, date(2014, 4, 21), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(11, None, None, 147, 2, date(2014, 4, 22), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(12, None, None, 152, 6, date(2014, 4, 23), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(13, None, None, 153, 3, date(2014, 4, 24), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(14, None, None, 155, 7, date(2014, 4, 25), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(15, None, None, 157, 4, date(2014, 4, 26), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(16, None, None, 159, 8, date(2014, 4, 27), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(17, None, None, 161, 1, date(2014, 4, 28), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(18, None, None, 165, 5, date(2014, 4, 29), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(19, None, None, 166, 2, date(2014, 4, 30), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(20, None, None, 168, 6, date(2014, 5, 1), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(21, None, None, 173, 3, date(2014, 5, 2), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(22, None, None, 177, 7, date(2014, 5, 3), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(23, None, None, 178, 4, date(2014, 5, 4), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(24, None, None, 179, 8, date(2014, 5, 5), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(25, None, None, 180, 1, date(2014, 5, 6), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(26, None, None, 181, 5, date(2014, 5, 7), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(27, None, None, 116, 2, date(2014, 5, 8), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(28, None, None, 118, 6, date(2014, 5, 9), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(29, None, None, 124, 3, date(2014, 5, 10), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(30, None, None, 127, 7, date(2014, 5, 11), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(31, None, None, 128, 4, date(2014, 5, 12), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(32, None, None, 129, 8, date(2014, 5, 13), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(33, None, None, 130, 1, date(2014, 5, 14), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(34, None, None, 132, 5, date(2014, 5, 15), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(35, None, None, 133, 2, date(2014, 5, 16), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(36, None, None, 137, 6, date(2014, 5, 17), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(37, None, None, 139, 3, date(2014, 5, 18), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(38, None, None, 141, 7, date(2014, 5, 19), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(39, None, None, 142, 4, date(2014, 5, 20), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(40, None, None, 144, 8, date(2014, 5, 21), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(41, 1, 1, 146, None, date(2014, 5, 2), None, u'30',
                            False, False))
loader.save(
    create_jobs_candidature(42, 2, 2, 147, None, date(2014, 5, 4), None, u'20',
                            False, False))
loader.save(
    create_jobs_candidature(43, 3, 3, 152, None, date(2014, 5, 6), None, u'25',
                            False, False))
loader.save(
    create_jobs_candidature(44, 4, 4, 153, None, date(2014, 5, 8), None, u'27',
                            False, False))
loader.save(
    create_jobs_candidature(45, 5, 1, 155, None, date(2014, 5, 10), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(46, 6, 2, 157, None, date(2014, 5, 12), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(47, 7, 3, 159, None, date(2014, 5, 14), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(48, 8, 4, 161, None, date(2014, 5, 16), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(49, 9, 1, 165, None, date(2014, 5, 18), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(50, 10, 2, 166, None, date(2014, 5, 20), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(51, 11, 3, 168, None, date(2014, 5, 22), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(52, 12, 4, 173, None, date(2014, 5, 24), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(53, 13, 1, 177, None, date(2014, 5, 26), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(54, 14, 2, 178, None, date(2014, 5, 28), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(55, 1, 3, 179, None, date(2014, 5, 30), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(56, 2, 4, 180, None, date(2014, 6, 1), None, u'30',
                            False, False))
loader.save(
    create_jobs_candidature(57, 3, 1, 181, None, date(2014, 6, 3), None, u'20',
                            False, False))
loader.save(
    create_jobs_candidature(58, 4, 2, 116, None, date(2014, 6, 5), None, u'25',
                            False, False))
loader.save(
    create_jobs_candidature(59, 5, 3, 118, None, date(2014, 6, 7), None, u'27',
                            False, False))
loader.save(
    create_jobs_candidature(60, 6, 4, 124, None, date(2014, 6, 9), None, u'30',
                            False, False))
loader.save(
    create_jobs_candidature(61, 7, 1, 127, None, date(2014, 6, 11), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(62, 8, 2, 128, None, date(2014, 6, 13), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(63, 9, 3, 129, None, date(2014, 6, 15), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(64, 10, 4, 130, None, date(2014, 6, 17), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(65, 11, 1, 132, None, date(2014, 6, 19), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(66, 12, 2, 133, None, date(2014, 6, 21), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(67, 13, 3, 137, None, date(2014, 6, 23), None,
                            u'20', False, False))
loader.save(
    create_jobs_candidature(68, 14, 4, 139, None, date(2014, 6, 25), None,
                            u'25', False, False))
loader.save(
    create_jobs_candidature(69, 1, 1, 141, None, date(2014, 6, 27), None,
                            u'27', False, False))
loader.save(
    create_jobs_candidature(70, 2, 2, 142, None, date(2014, 6, 29), None,
                            u'30', False, False))
loader.save(
    create_jobs_candidature(71, 5, 1, 116, None, date(2014, 5, 22), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(72, 5, 2, 117, None, date(2014, 5, 21), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(73, 5, 3, 177, None, date(2014, 5, 20), None,
                            u'10', False, False))
loader.save(
    create_jobs_candidature(74, 5, 4, 120, None, date(2014, 5, 19), None,
                            u'10', False, False))

loader.flush_deferred_objects()

# -*- coding: UTF-8 -*-
logger.info("Loading 106 objects to table cbss_purpose...")
# fields: id, name, sector_code, code
loader.save(
    create_cbss_purpose(1, [
        'INDEMNISATION AUX VICTIMES', 'INDEMNISATION AUX VICTIMES',
        'INDEMNISATION AUX VICTIMES'
    ], 1, 10))
loader.save(
    create_cbss_purpose(2, [
        'RENTES DES AYANTS DROIT', 'RENTES DES AYANTS DROIT',
        'RENTES DES AYANTS DROIT'
    ], 1, 20))
loader.save(
    create_cbss_purpose(3, [
        'PAIEMENTS \xc0 DES TIERS & AUTRES CORRESPONDANTS',
        'PAIEMENTS \xc0 DES TIERS & AUTRES CORRESPONDANTS',
        'PAIEMENTS \xc0 DES TIERS & AUTRES CORRESPONDANTS'
    ], 1, 30))
loader.save(
    create_cbss_purpose(4, [
        'TRAVAILLEURS ASSIMIL\xc9S - CARRI\xc8RE INCOMPL\xc8TE',
        'TRAVAILLEURS ASSIMIL\xc9S - CARRI\xc8RE INCOMPL\xc8TE',
        'TRAVAILLEURS ASSIMIL\xc9S - CARRI\xc8RE INCOMPL\xc8TE'
    ], 1, 40))
loader.save(
    create_cbss_purpose(5, ['D\xe9biteurs', 'D\xe9biteurs', 'D\xe9biteurs'], 1,
                        50))
loader.save(
    create_cbss_purpose(
        6, ['PREMIER CONTACT', 'PREMIER CONTACT', 'PREMIER CONTACT'], 5, 1))
loader.save(
    create_cbss_purpose(
        7, ['DOSSIER ESTIMATION', 'DOSSIER ESTIMATION', 'DOSSIER ESTIMATION'],
        5, 10))
loader.save(
    create_cbss_purpose(
        8,
        ['DOSSIER ATTRIBUTION', 'DOSSIER ATTRIBUTION', 'DOSSIER ATTRIBUTION'],
        5, 20))
loader.save(
    create_cbss_purpose(
        9, ['ATTRIBUTION GRAPA', 'ATTRIBUTION GRAPA', 'ATTRIBUTION GRAPA'], 5,
        30))
loader.save(
    create_cbss_purpose(
        10, ['COHABITANT GRAPA', 'COHABITANT GRAPA', 'COHABITANT GRAPA'], 5,
        31))
loader.save(
    create_cbss_purpose(
        11, ['DOSSIER PAIEMENT', 'DOSSIER PAIEMENT', 'DOSSIER PAIEMENT'], 5,
        100))
loader.save(
    create_cbss_purpose(12, [
        'DOSSIER PAIEMENT RESIDUAIRE', 'DOSSIER PAIEMENT RESIDUAIRE',
        'DOSSIER PAIEMENT RESIDUAIRE'
    ], 5, 110))
loader.save(
    create_cbss_purpose(
        13, ['DOSSIER CADASTRE', 'DOSSIER CADASTRE', 'DOSSIER CADASTRE'], 5,
        150))
loader.save(
    create_cbss_purpose(14, [
        'Dossier \xe9change bilat\xe9ral', 'Dossier \xe9change bilat\xe9ral',
        'Dossier \xe9change bilat\xe9ral'
    ], 5, 500))
loader.save(
    create_cbss_purpose(15, [
        'INDEMNISATION AUX VICTIMES', 'INDEMNISATION AUX VICTIMES',
        'INDEMNISATION AUX VICTIMES'
    ], 6, 10))
loader.save(
    create_cbss_purpose(16, [
        'RENTES DES AYANTS DROIT', 'RENTES DES AYANTS DROIT',
        'RENTES DES AYANTS DROIT'
    ], 6, 20))
loader.save(
    create_cbss_purpose(17, [
        'PAIEMENTS \xc0 DES TIERS & AUTRES CORRESPONDANTS',
        'PAIEMENTS \xc0 DES TIERS & AUTRES CORRESPONDANTS',
        'PAIEMENTS \xc0 DES TIERS & AUTRES CORRESPONDANTS'
    ], 6, 30))
loader.save(
    create_cbss_purpose(18, [
        'TRAVAILLEURS ASSIMIL\xc9S - CARRI\xc8RE INCOMPL\xc8TE',
        'TRAVAILLEURS ASSIMIL\xc9S - CARRI\xc8RE INCOMPL\xc8TE',
        'TRAVAILLEURS ASSIMIL\xc9S - CARRI\xc8RE INCOMPL\xc8TE'
    ], 6, 40))
loader.save(
    create_cbss_purpose(19, [
        'FEMME ENCEINTE ECART2E', 'FEMME ENCEINTE ECART2E',
        'FEMME ENCEINTE ECART2E'
    ], 6, 50))
loader.save(
    create_cbss_purpose(
        20, ['B\xc9N\xc9FICIAIRE', 'B\xc9N\xc9FICIAIRE', 'B\xc9N\xc9FICIAIRE'],
        7, 101))
loader.save(
    create_cbss_purpose(
        21, ['ALLOCATAIRE TYPE 1', 'ALLOCATAIRE TYPE 1', 'ALLOCATAIRE TYPE 1'],
        7, 102))
loader.save(
    create_cbss_purpose(
        22, ['ALLOCATAIRE TYPE 2', 'ALLOCATAIRE TYPE 2', 'ALLOCATAIRE TYPE 2'],
        7, 103))
loader.save(
    create_cbss_purpose(23, [
        'ENFANT B\xc9N\xc9FICIAIRE', 'ENFANT B\xc9N\xc9FICIAIRE',
        'ENFANT B\xc9N\xc9FICIAIRE'
    ], 7, 104))
loader.save(
    create_cbss_purpose(24, [
        'TIERCE PERSONNE TYPE 1', 'TIERCE PERSONNE TYPE 1',
        'TIERCE PERSONNE TYPE 1'
    ], 7, 105))
loader.save(
    create_cbss_purpose(25, [
        'TIERCE PERSONNE TYPE 2', 'TIERCE PERSONNE TYPE 2',
        'TIERCE PERSONNE TYPE 2'
    ], 7, 106))
loader.save(
    create_cbss_purpose(26, [
        'PERSONNE EN RECHERCHE', 'PERSONNE EN RECHERCHE',
        'PERSONNE EN RECHERCHE'
    ], 7, 107))
loader.save(
    create_cbss_purpose(27, [
        'AYANT DROIT \xc0 UNE INTERVENTION MAJOR\xc9E DE L\u2019ASSURANCE SOINS DE SANT\xc9 (TITULAIRE OU B\xc9N\xc9FICIAIRE)',
        'AYANT DROIT \xc0 UNE INTERVENTION MAJOR\xc9E DE L\u2019ASSURANCE SOINS DE SANT\xc9 (TITULAIRE OU B\xc9N\xc9FICIAIRE)',
        'AYANT DROIT \xc0 UNE INTERVENTION MAJOR\xc9E DE L\u2019ASSURANCE SOINS DE SANT\xc9 (TITULAIRE OU B\xc9N\xc9FICIAIRE)'
    ], 9, 2))
loader.save(
    create_cbss_purpose(28, [
        'AYANT DROIT \xc0 UNE INTERVENTION MAJOR\xc9E DE L\u2019ASSURANCE SOINS DE SANT\xc9 (PERSONNE \xc0 CHARGE)',
        'AYANT DROIT \xc0 UNE INTERVENTION MAJOR\xc9E DE L\u2019ASSURANCE SOINS DE SANT\xc9 (PERSONNE \xc0 CHARGE)',
        'AYANT DROIT \xc0 UNE INTERVENTION MAJOR\xc9E DE L\u2019ASSURANCE SOINS DE SANT\xc9 (PERSONNE \xc0 CHARGE)'
    ], 9, 12))
loader.save(create_cbss_purpose(29, ['OUVRIER', 'OUVRIER', 'OUVRIER'], 10, 10))
loader.save(
    create_cbss_purpose(30, [
        'ASSURABILIT\xc9 SOINS DE SANT\xc9',
        'ASSURABILIT\xc9 SOINS DE SANT\xc9',
        'ASSURABILIT\xc9 SOINS DE SANT\xc9'
    ], 11, 1))
loader.save(
    create_cbss_purpose(31, [
        'PERSONNE AVEC DOSSIER INDEMNIT\xc9',
        'PERSONNE AVEC DOSSIER INDEMNIT\xc9',
        'PERSONNE AVEC DOSSIER INDEMNIT\xc9'
    ], 11, 2))
loader.save(
    create_cbss_purpose(
        32,
        ['MEMBRE DU PERSONNEL', 'MEMBRE DU PERSONNEL', 'MEMBRE DU PERSONNEL'],
        12, 2))
loader.save(
    create_cbss_purpose(33, ['SALARI\xc9', 'SALARI\xc9', 'SALARI\xc9'], 12,
                        10))
loader.save(create_cbss_purpose(34, ['DIMONA', 'DIMONA', 'DIMONA'], 12, 30))
loader.save(
    create_cbss_purpose(
        35, ['ENQUETE EMPLOYEUR', 'ENQUETE EMPLOYEUR', 'ENQUETE EMPLOYEUR'],
        12, 40))
loader.save(
    create_cbss_purpose(36, ['TRAVAILLEUR', 'TRAVAILLEUR', 'TRAVAILLEUR'], 13,
                        10))
loader.save(create_cbss_purpose(37, ['DIMONA', 'DIMONA', 'DIMONA'], 13, 30))
loader.save(
    create_cbss_purpose(38, [
        'SALARI\xc9 AVEC TENUE DE COMPTE PENSION',
        'SALARI\xc9 AVEC TENUE DE COMPTE PENSION',
        'SALARI\xc9 AVEC TENUE DE COMPTE PENSION'
    ], 14, 10))
loader.save(
    create_cbss_purpose(39, [
        'SALARI\xc9 SANS TENUE DE COMPTE PENSION',
        'SALARI\xc9 SANS TENUE DE COMPTE PENSION',
        'SALARI\xc9 SANS TENUE DE COMPTE PENSION'
    ], 14, 21))
loader.save(
    create_cbss_purpose(40, [
        'TRAVAILLEUR POUR QUI UNE D\xc9CLARATION DIMONA A \xc9T\xc9 FAITE',
        'TRAVAILLEUR POUR QUI UNE D\xc9CLARATION DIMONA A \xc9T\xc9 FAITE',
        'TRAVAILLEUR POUR QUI UNE D\xc9CLARATION DIMONA A \xc9T\xc9 FAITE'
    ], 14, 30))
loader.save(
    create_cbss_purpose(41, [
        'Carri\xe8re fonctionnaires, employ\xe9es contractuels',
        'Carri\xe8re fonctionnaires, employ\xe9es contractuels',
        'Carri\xe8re fonctionnaires, employ\xe9es contractuels'
    ], 14, 50))
loader.save(
    create_cbss_purpose(
        42, ['DOSSIER EN EXAMEN', 'DOSSIER EN EXAMEN', 'DOSSIER EN EXAMEN'],
        15, 1))
loader.save(
    create_cbss_purpose(43, [
        'STATUT SOCIAL DE TRAVAILLEUR IND\xc9PENDANT',
        'STATUT SOCIAL DE TRAVAILLEUR IND\xc9PENDANT',
        'STATUT SOCIAL DE TRAVAILLEUR IND\xc9PENDANT'
    ], 15, 2))
loader.save(
    create_cbss_purpose(44, [
        'B\xc9N\xc9FICIAIRE DES ALLOCATIONS FAMILIALES SECTEUR IND\xc9PENDANTS',
        'B\xc9N\xc9FICIAIRE DES ALLOCATIONS FAMILIALES SECTEUR IND\xc9PENDANTS',
        'B\xc9N\xc9FICIAIRE DES ALLOCATIONS FAMILIALES SECTEUR IND\xc9PENDANTS'
    ], 15, 3))
loader.save(
    create_cbss_purpose(45, [
        '(EX-)CONJOINT DE L\u2019IND\xc9PENDANT, AYANT DROIT DANS LE STATUT SOCIAL DES IND\xc9PENDANTS',
        '(EX-)CONJOINT DE L\u2019IND\xc9PENDANT, AYANT DROIT DANS LE STATUT SOCIAL DES IND\xc9PENDANTS',
        '(EX-)CONJOINT DE L\u2019IND\xc9PENDANT, AYANT DROIT DANS LE STATUT SOCIAL DES IND\xc9PENDANTS'
    ], 15, 6))
loader.save(
    create_cbss_purpose(46, [
        'ACTEUR QUI PEUT INFLUENCER LA DETERMINATION DU DROIT AUX PRESTATIONS FAMILIALES',
        'ACTEUR QUI PEUT INFLUENCER LA DETERMINATION DU DROIT AUX PRESTATIONS FAMILIALES',
        'ACTEUR QUI PEUT INFLUENCER LA DETERMINATION DU DROIT AUX PRESTATIONS FAMILIALES'
    ], 15, 7))
loader.save(
    create_cbss_purpose(47, [
        'ALLOCATAIRE (PRESTATIONS FAMILIALES)',
        'ALLOCATAIRE (PRESTATIONS FAMILIALES)',
        'ALLOCATAIRE (PRESTATIONS FAMILIALES)'
    ], 15, 8))
loader.save(
    create_cbss_purpose(48, [
        'PERSONNE HANDICAP\xc9E (ALLOCATION)',
        'PERSONNE HANDICAP\xc9E (ALLOCATION)',
        'PERSONNE HANDICAP\xc9E (ALLOCATION)'
    ], 16, 1))
loader.save(
    create_cbss_purpose(
        49,
        ['ENFANT HANDICAP\xc9', 'ENFANT HANDICAP\xc9', 'ENFANT HANDICAP\xc9'],
        16, 2))
loader.save(
    create_cbss_purpose(50, [
        'RECONNAISSANCE MEDICALE', 'RECONNAISSANCE MEDICALE',
        'RECONNAISSANCE MEDICALE'
    ], 16, 3))
loader.save(
    create_cbss_purpose(51, [
        'PERSONNE AVEC LAQUELLE LA PERSONNE HANDICAP\xc9E FORME UN M\xc9NAGE',
        'PERSONNE AVEC LAQUELLE LA PERSONNE HANDICAP\xc9E FORME UN M\xc9NAGE',
        'PERSONNE AVEC LAQUELLE LA PERSONNE HANDICAP\xc9E FORME UN M\xc9NAGE'
    ], 16, 4))
loader.save(
    create_cbss_purpose(52, [
        'DOSSIER BENEFICIAIRE D\u2019UNE ALLOCATION D\u2019INTEGRATION / ALLOCATION DE REMPLACEMENT DE REVENU',
        'DOSSIER BENEFICIAIRE D\u2019UNE ALLOCATION D\u2019INTEGRATION / ALLOCATION DE REMPLACEMENT DE REVENU',
        'DOSSIER BENEFICIAIRE D\u2019UNE ALLOCATION D\u2019INTEGRATION / ALLOCATION DE REMPLACEMENT DE REVENU'
    ], 16, 5))
loader.save(
    create_cbss_purpose(53, [
        'PERSONNE FAISANT PARTIE DU MENAGE D\u2019UNE PERSONNE HANDICAPEE BENEFICIANT D\u2019UNE ALLOCATION D\u2019INTEGRATION / ALLOCATION DE REMPLACEMENT DE REVENU',
        'PERSONNE FAISANT PARTIE DU MENAGE D\u2019UNE PERSONNE HANDICAPEE BENEFICIANT D\u2019UNE ALLOCATION D\u2019INTEGRATION / ALLOCATION DE REMPLACEMENT DE REVENU',
        'PERSONNE FAISANT PARTIE DU MENAGE D\u2019UNE PERSONNE HANDICAPEE BENEFICIANT D\u2019UNE ALLOCATION D\u2019INTEGRATION / ALLOCATION DE REMPLACEMENT DE REVENU'
    ], 16, 6))
loader.save(
    create_cbss_purpose(54, [
        'DOSSIER BENEFICIAIRE D\u2019UNE ALLOCATION D\u2019AIDE AUX PERSONNES AGEES',
        'DOSSIER BENEFICIAIRE D\u2019UNE ALLOCATION D\u2019AIDE AUX PERSONNES AGEES',
        'DOSSIER BENEFICIAIRE D\u2019UNE ALLOCATION D\u2019AIDE AUX PERSONNES AGEES'
    ], 16, 7))
loader.save(
    create_cbss_purpose(55, [
        'PERSONNE FAISANT PARTIE DU MENAGE D\u2019UNE PERSONNE HANDICAPEE BENEFICIANT D\u2019UNE ALLOCATION D\u2019AIDE AUX PERSONNES AGEES',
        'PERSONNE FAISANT PARTIE DU MENAGE D\u2019UNE PERSONNE HANDICAPEE BENEFICIANT D\u2019UNE ALLOCATION D\u2019AIDE AUX PERSONNES AGEES',
        'PERSONNE FAISANT PARTIE DU MENAGE D\u2019UNE PERSONNE HANDICAPEE BENEFICIANT D\u2019UNE ALLOCATION D\u2019AIDE AUX PERSONNES AGEES'
    ], 16, 8))
loader.save(
    create_cbss_purpose(56, [
        'CH\xd4MEUR CONTR\xd4L\xc9', 'CH\xd4MEUR CONTR\xd4L\xc9',
        'CH\xd4MEUR CONTR\xd4L\xc9'
    ], 18, 1))
loader.save(
    create_cbss_purpose(57, [
        'TRAVAILLEUR EN INTERRUPTION DE CARRI\xc8RE',
        'TRAVAILLEUR EN INTERRUPTION DE CARRI\xc8RE',
        'TRAVAILLEUR EN INTERRUPTION DE CARRI\xc8RE'
    ], 18, 2))
loader.save(
    create_cbss_purpose(58, [
        'TRAVAILLEUR VICTIME D\u2019UNE FERMETURE D\u2019ENTREPRISE',
        'TRAVAILLEUR VICTIME D\u2019UNE FERMETURE D\u2019ENTREPRISE',
        'TRAVAILLEUR VICTIME D\u2019UNE FERMETURE D\u2019ENTREPRISE'
    ], 18, 3))
loader.save(
    create_cbss_purpose(59, [
        'DEMANDEUR D\u2019EMPLOI', 'DEMANDEUR D\u2019EMPLOI',
        'DEMANDEUR D\u2019EMPLOI'
    ], 18, 4))
loader.save(
    create_cbss_purpose(60, [
        'MEMBRE DU PERSONNEL ONEM', 'MEMBRE DU PERSONNEL ONEM',
        'MEMBRE DU PERSONNEL ONEM'
    ], 18, 5))
loader.save(
    create_cbss_purpose(61,
                        ['DOSSIER ACTIF', 'DOSSIER ACTIF', 'DOSSIER ACTIF'],
                        19, 1))
loader.save(
    create_cbss_purpose(
        62, ['DOSSIER INACTIF', 'DOSSIER INACTIF', 'DOSSIER INACTIF'], 19, 2))
loader.save(
    create_cbss_purpose(63, ['M\xc9DECIN', 'M\xc9DECIN', 'M\xc9DECIN'], 19,
                        10))
loader.save(
    create_cbss_purpose(64, ['PHARMACIEN', 'PHARMACIEN', 'PHARMACIEN'], 19,
                        20))
loader.save(
    create_cbss_purpose(65, [
        'ASSISTANT-PHARMACEUTICA-TECHNIQUE',
        'ASSISTANT-PHARMACEUTICA-TECHNIQUE',
        'ASSISTANT-PHARMACEUTICA-TECHNIQUE'
    ], 19, 21))
loader.save(
    create_cbss_purpose(66, ['DENTISTE', 'DENTISTE', 'DENTISTE'], 19, 30))
loader.save(
    create_cbss_purpose(67, ['ACCOUCHEUSE', 'ACCOUCHEUSE', 'ACCOUCHEUSE'], 19,
                        40))
loader.save(
    create_cbss_purpose(68, ['INFIRMIER', 'INFIRMIER', 'INFIRMIER'], 19, 41))
loader.save(
    create_cbss_purpose(69,
                        ['AIDE-SOIGNANT', 'AIDE-SOIGNANT', 'AIDE-SOIGNANT'],
                        19, 42))
loader.save(
    create_cbss_purpose(70, [
        'KIN\xc9SITH\xc9RAPEUTE', 'KIN\xc9SITH\xc9RAPEUTE',
        'KIN\xc9SITH\xc9RAPEUTE'
    ], 19, 50))
loader.save(
    create_cbss_purpose(71, ['ORTHESISTE', 'ORTHESISTE', 'ORTHESISTE'], 19,
                        51))
loader.save(
    create_cbss_purpose(72, ['PROTHESISTE', 'PROTHESISTE', 'PROTHESISTE'], 19,
                        54))
loader.save(
    create_cbss_purpose(73, ['AUDIOLOGUE', 'AUDIOLOGUE', 'AUDIOLOGUE'], 19,
                        57))
loader.save(
    create_cbss_purpose(74, ['LOGOP\xc8DES', 'LOGOP\xc8DES', 'LOGOP\xc8DES'],
                        19, 58))
loader.save(
    create_cbss_purpose(75, ['ORTHOPTISTES', 'ORTHOPTISTES', 'ORTHOPTISTES'],
                        19, 59))
loader.save(
    create_cbss_purpose(76, ['PODOLOGUE', 'PODOLOGUE', 'PODOLOGUE'], 19, 60))
loader.save(
    create_cbss_purpose(
        77, ['ORTHOP\xc9DISTES', 'ORTHOP\xc9DISTES', 'ORTHOP\xc9DISTES'], 19,
        61))
loader.save(
    create_cbss_purpose(78, ['BANDAGISTES', 'BANDAGISTES', 'BANDAGISTES'], 19,
                        62))
loader.save(
    create_cbss_purpose(79, [
        'DISPENSATEURS D\u2019IMPLANTS', 'DISPENSATEURS D\u2019IMPLANTS',
        'DISPENSATEURS D\u2019IMPLANTS'
    ], 19, 63))
loader.save(
    create_cbss_purpose(
        80, ['ERGOTH\xc9RAPEUTE', 'ERGOTH\xc9RAPEUTE', 'ERGOTH\xc9RAPEUTE'],
        19, 64))
loader.save(
    create_cbss_purpose(
        81, ['DI\xc9T\xc9TICIEN', 'DI\xc9T\xc9TICIEN', 'DI\xc9T\xc9TICIEN'],
        19, 65))
loader.save(
    create_cbss_purpose(82, ['OPTICIENS', 'OPTICIENS', 'OPTICIENS'], 19, 66))
loader.save(
    create_cbss_purpose(83, ['AUDICIENS', 'AUDICIENS', 'AUDICIENS'], 19, 67))
loader.save(
    create_cbss_purpose(84, [
        'PHARMACIENS BIOLOGISTES', 'PHARMACIENS BIOLOGISTES',
        'PHARMACIENS BIOLOGISTES'
    ], 19, 68))
loader.save(
    create_cbss_purpose(85, [
        'TECHNOLOGUE DE LABORATOIRE', 'TECHNOLOGUE DE LABORATOIRE',
        'TECHNOLOGUE DE LABORATOIRE'
    ], 19, 69))
loader.save(
    create_cbss_purpose(
        86, ['PU\xc9RICULTRICE', 'PU\xc9RICULTRICE', 'PU\xc9RICULTRICE'], 19,
        70))
loader.save(
    create_cbss_purpose(87, [
        'TECHNOLOGUE EN IMAGERIE MEDICALE', 'TECHNOLOGUE EN IMAGERIE MEDICALE',
        'TECHNOLOGUE EN IMAGERIE MEDICALE'
    ], 19, 71))
loader.save(
    create_cbss_purpose(88, [
        'AMBULANCIER (TRANSPORT NON-URGENT DE PATIENT)',
        'AMBULANCIER (TRANSPORT NON-URGENT DE PATIENT)',
        'AMBULANCIER (TRANSPORT NON-URGENT DE PATIENT)'
    ], 19, 80))
loader.save(
    create_cbss_purpose(89, [
        'PROFESSIONNEL DE SANTE POTENTIEL', 'PROFESSIONNEL DE SANTE POTENTIEL',
        'PROFESSIONNEL DE SANTE POTENTIEL'
    ], 19, 99))
loader.save(
    create_cbss_purpose(90, [
        'Provisorische Einschreibung', 'Inscription provisoire',
        'Inscription provisoire'
    ], None, 902))
loader.save(
    create_cbss_purpose(
        91, ['NISS ersetzt', 'NISS remplac\xe9', 'NISS remplac\xe9'], None,
        999))
loader.save(
    create_cbss_purpose(92, [
        'Definitive Einschreibung', 'Inscription d\xe9finitive',
        'Inscription d\xe9finitive'
    ], None, 0))
loader.save(
    create_cbss_purpose(
        93, ['Akte in Untersuchung', 'Dossier en examen', 'Dossier en examen'],
        17, 1))
loader.save(
    create_cbss_purpose(94, [
        'Eingliederungseinkommen', 'Revenu d\u2019int\xe9gration',
        'Revenu d\u2019int\xe9gration'
    ], 17, 2))
loader.save(
    create_cbss_purpose(95, [
        'Gleichgestelltes Eingliederungseinkommen',
        '\xc9quivalent revenu d\u2019int\xe9gration',
        '\xc9quivalent revenu d\u2019int\xe9gration'
    ], 17, 3))
loader.save(
    create_cbss_purpose(96, ['Sonstige Hilfe', 'Autre aide', 'Autre aide'], 17,
                        4))
loader.save(
    create_cbss_purpose(97, ['Mitbewohner', 'Cohabitant', 'Cohabitant'], 17,
                        5))
loader.save(
    create_cbss_purpose(98, [
        'Durch das \xd6SHZ besch\xe4ftigte Person',
        'Personne occup\xe9e par le biais d\u2019un CPAS',
        'Personne occup\xe9e par le biais d\u2019un CPAS'
    ], 17, 6))
loader.save(
    create_cbss_purpose(99, [
        'Schuldnerberatung',
        'M\xe9diation collective de dettes / accompagnement budg\xe9taire',
        'M\xe9diation collective de dettes / accompagnement budg\xe9taire'
    ], 17, 7))
loader.save(
    create_cbss_purpose(
        100, ['Dienstakte', 'Dossiers de service', 'Dossiers de service'], 17,
        8))
loader.save(
    create_cbss_purpose(101, [
        'Sonstige Begleitungsformen', 'Autres formes d\u2019accompagnement',
        'Autres formes d\u2019accompagnement'
    ], 17, 9))
loader.save(
    create_cbss_purpose(102, ['Begleiter', 'Encadrant', 'Encadrant'], 17, 11))
loader.save(
    create_cbss_purpose(103, ['Teilnehmer', 'Participant', 'Participant'], 17,
                        12))
loader.save(
    create_cbss_purpose(104, [
        'Mitarbeiter auf Probe', 'Collaborateur en enqu\xeate',
        'Collaborateur en enqu\xeate'
    ], 17, 20))
loader.save(
    create_cbss_purpose(105, [
        'Mitarbeiter (definitiv)', 'Collaborateur (d\xe9finitif)',
        'Collaborateur (d\xe9finitif)'
    ], 17, 21))
loader.save(
    create_cbss_purpose(106, [
        'Heizkostenbeihilfe',
        'B\xe9n\xe9ficiaire de l\u2019allocation de chauffage',
        'B\xe9n\xe9ficiaire de l\u2019allocation de chauffage'
    ], 17, 40))

loader.flush_deferred_objects()

# -*- coding: UTF-8 -*-
logger.info("Loading 23 objects to table properties_property...")
# fields: id, name, group, type
loader.save(
    create_properties_property(1, ['Gartenarbeit', 'Jardinier', 'Gardener'], 1,
                               1))
loader.save(
    create_properties_property(2, ['Gehorsam', 'Ob\xe9issant', 'Obedient'], 2,
                               2))
loader.save(
    create_properties_property(
        3, ['nur Vollzeit', 'seulement temps plein', 'only full-time'], 3, 1))
loader.save(
    create_properties_property(
        4, ['nur Teilzeit', 'seulement mi-temps', 'only part-time'], 3, 1))
loader.save(
    create_properties_property(5, ['Verk\xe4ufer', 'Vendeur', 'Salesman'], 1,
                               1))
loader.save(
    create_properties_property(6,
                               ['F\xfchrungsf\xe4higkeit', 'Leader', 'Leader'],
                               2, 2))
loader.save(
    create_properties_property(
        7, ['Haushaltshilfe', 'Aide m\xe9nage', 'Household aid'], 1, 1))
loader.save(
    create_properties_property(8, ['B\xe4ckerei', 'P\xe2tisserie', 'Bakery'],
                               1, 1))
loader.save(
    create_properties_property(
        9, ['nicht am Wochenende', 'pas le week-end', 'no work on weekend'], 3,
        1))
loader.save(
    create_properties_property(
        10,
        ['keine Schichtarbeit', 'pas de travail post\xe9', 'no shift work'], 3,
        1))
loader.save(
    create_properties_property(11, ['Kochen', 'Cuisiner', 'Cook'], 1, 1))
loader.save(
    create_properties_property(12, [
        'K\xf6rperliche Einschr\xe4nkung', 'Handicap physique',
        'Physical handicap'
    ], 3, 1))
loader.save(
    create_properties_property(
        13, ['F\xfchrerschein', 'Permis de conduire', 'Driving licence'], 1,
        1))
loader.save(
    create_properties_property(
        14,
        ['Geistige Einschr\xe4nkung', 'Handicap mental', 'Mental handicap'], 3,
        1))
loader.save(
    create_properties_property(15, [
        'Psychische Einschr\xe4nkung', 'Handicap psychique',
        'Psychological handicap'
    ], 3, 1))
loader.save(
    create_properties_property(16, [
        'Gesundheitliche Einschr\xe4nkung', 'Handicap sant\xe9',
        'Health handicap'
    ], 3, 1))
loader.save(
    create_properties_property(17, [
        'Juristische Probleme', 'Probl\xe8me juridiques', 'Juristic problems'
    ], 3, 1))
loader.save(
    create_properties_property(
        18, ['Suchtprobleme', 'Toxicomanie ', 'Addiction problems'], 3, 1))
loader.save(
    create_properties_property(19, [
        'Mangelnde Sozialkompetenz', 'Manque de comp\xe9tence sociale',
        'Lack of social competence'
    ], 3, 1))
loader.save(
    create_properties_property(
        20, ['Motivationsmangel', 'Manque motivation', 'Lack of motivation'],
        3, 1))
loader.save(
    create_properties_property(
        21,
        ['Personen zu Lasten', 'Personnes \xe0 charge', 'Head of a family'], 3,
        1))
loader.save(
    create_properties_property(
        22, ['Kleinkinder', 'Petits enfants \xe0 charge', 'Small children'], 3,
        1))
loader.save(
    create_properties_property(23,
                               ['Analphabet', 'Analphab\xe8te', 'Illiterate'],
                               3, 1))

loader.flush_deferred_objects()

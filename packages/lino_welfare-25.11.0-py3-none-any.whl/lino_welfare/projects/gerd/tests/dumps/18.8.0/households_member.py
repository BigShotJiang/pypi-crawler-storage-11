# -*- coding: UTF-8 -*-
logger.info("Loading 63 objects to table households_member...")
# fields: id, start_date, end_date, title, first_name, middle_name, last_name, gender, birth_date, role, person, household, dependency, primary
loader.save(
    create_households_member(1, None, None, u'', u'Gerd', u'', u'Gerkens',
                             u'M', u'', '01', 212, 232, '02', False))
loader.save(
    create_households_member(2, None, None, u'', u'Tatjana', u'', u'Kasennova',
                             u'F', u'1983-01-15', '03', 213, 232, '02', False))
loader.save(
    create_households_member(3, None, None, u'', u'Hubert', u'', u'Huppertz',
                             u'M', u'', '01', 183, 233, '02', False))
loader.save(
    create_households_member(4, None, None, u'', u'Judith', u'', u'Jousten',
                             u'F', u'', '03', 186, 233, '02', False))
loader.save(
    create_households_member(5, None, date(2002, 3, 4), u'', u'J\xe9r\xf4me',
                             u'', u'Jean\xe9mart', u'M', u'1985-05-14', '01',
                             181, 234, '02', False))
loader.save(
    create_households_member(6, None, None, u'', u'Theresia', u'', u'Thelen',
                             u'F', u'', '03', 185, 234, '02', False))
loader.save(
    create_households_member(7, None, None, u'', u'Denis', u'', u'Denon', u'M',
                             u'1995-08-10', '01', 180, 235, '02', False))
loader.save(
    create_households_member(8, None, None, u'', u'M\xe9lanie', u'',
                             u'M\xe9lard', u'F', u'', '03', 182, 235, '02',
                             False))
loader.save(
    create_households_member(9, None, None, u'', u'Robin', u'', u'Dubois',
                             u'M', u'1993-09-29', '01', 179, 236, '02', False))
loader.save(
    create_households_member(10, None, None, u'', u'Lisa', u'', u'Lahm', u'F',
                             u'1982-02-09', '03', 176, 236, '02', False))
loader.save(
    create_households_member(11, None, None, u'', u'J\xe9r\xf4me', u'',
                             u'Jean\xe9mart', u'M', u'1985-05-14', '01', 181,
                             237, '02', False))
loader.save(
    create_households_member(12, None, None, u'', u'Marie-Louise', u'',
                             u'Vandenmeulenbos', u'F', u'1972-10-19', '03',
                             174, 237, '02', False))
loader.save(
    create_households_member(13, None, None, u'', u'Hubert', u'', u'Frisch',
                             u'M', u'1933-07-21', '01', 238, 254, '02', False))
loader.save(
    create_households_member(14, None, None, u'', u'Gaby', u'', u'Frogemuth',
                             u'F', u'1934-08-04', '03', 239, 254, '02', False))
loader.save(
    create_households_member(15, None, None, u'', u'Paul', u'', u'Frisch',
                             u'M', u'1967-06-19', '01', 240, 255, '02', False))
loader.save(
    create_households_member(16, None, None, u'', u'Paula', u'', u'Einzig',
                             u'F', u'1968-12-19', '03', 244, 255, '02', False))
loader.save(
    create_households_member(17, None, None, u'', u'Philippe', u'', u'Frisch',
                             u'M', u'1997-06-19', '05', 247, 255, '01', False))
loader.save(
    create_households_member(18, None, None, u'', u'Clara', u'', u'Frisch',
                             u'F', u'1999-06-19', '05', 248, 255, '01', False))
loader.save(
    create_households_member(19, None, None, u'', u'Dennis', u'', u'Frisch',
                             u'M', u'2001-06-19', '05', 250, 255, '01', False))
loader.save(
    create_households_member(20, None, None, u'', u'Paul', u'', u'Frisch',
                             u'M', u'1967-06-19', '01', 240, 256, '02', True))
loader.save(
    create_households_member(21, None, None, u'', u'Petra', u'', u'Zweith',
                             u'F', u'1968-12-19', '03', 246, 256, '02', True))
loader.save(
    create_households_member(22, None, None, u'', u'Philippe', u'', u'Frisch',
                             u'M', u'1997-06-19', '05', 247, 256, '01', False))
loader.save(
    create_households_member(23, None, None, u'', u'Clara', u'', u'Frisch',
                             u'F', u'1999-06-19', '05', 248, 256, '01', False))
loader.save(
    create_households_member(24, None, None, u'', u'Dennis', u'', u'Frisch',
                             u'M', u'2001-06-19', '05', 250, 256, '01', False))
loader.save(
    create_households_member(25, None, None, u'', u'Ludwig', u'', u'Frisch',
                             u'M', u'1968-06-01', '01', 241, 257, '02', False))
loader.save(
    create_households_member(26, None, None, u'', u'Laura', u'', u'Loslever',
                             u'F', u'1968-04-27', '03', 251, 257, '02', False))
loader.save(
    create_households_member(27, None, None, u'', u'Melba', u'', u'Frisch',
                             u'F', u'2002-04-05', '05', 252, 257, '01', False))
loader.save(
    create_households_member(28, None, None, u'', u'Irma', u'', u'Frisch',
                             u'F', u'2008-03-24', '05', 253, 257, '01', False))
loader.save(
    create_households_member(29, None, None, u'', u'Albert', u'', u'Adam',
                             u'M', u'1973-07-21', '01', 258, 270, '02', False))
loader.save(
    create_households_member(30, None, None, u'', u'Eveline', u'', u'Evrard',
                             u'F', u'1974-08-21', '03', 260, 270, '02', False))
loader.save(
    create_households_member(31, None, None, u'', u'No\xe9mie', u'', u'Adam',
                             u'F', u'2002-08-22', '05', 267, 270, '01', False))
loader.save(
    create_households_member(32, None, None, u'', u'Odette', u'', u'Adam',
                             u'F', u'2004-08-22', '05', 268, 270, '01', False))
loader.save(
    create_households_member(33, None, None, u'', u'Pascale', u'', u'Adam',
                             u'F', u'2004-08-22', '05', 269, 270, '01', False))
loader.save(
    create_households_member(34, None, None, u'', u'Jan', u'', u'Braun', u'M',
                             u'1996-08-22', '05', 263, 270, '01', False))
loader.save(
    create_households_member(35, None, None, u'', u'Kevin', u'', u'Braun',
                             u'M', u'1998-08-22', '05', 264, 270, '01', False))
loader.save(
    create_households_member(36, None, None, u'', u'Lars', u'', u'Braun', u'M',
                             u'1998-08-22', '05', 265, 270, '01', False))
loader.save(
    create_households_member(37, None, None, u'', u'Albert', u'', u'Adam',
                             u'M', u'1973-07-21', '01', 258, 271, '02', False))
loader.save(
    create_households_member(38, None, None, u'', u'Fran\xe7oise', u'',
                             u'Freisen', u'F', u'1974-08-22', '03', 261, 271,
                             '02', False))
loader.save(
    create_households_member(39, None, None, u'', u'No\xe9mie', u'', u'Adam',
                             u'F', u'2002-08-22', '05', 267, 271, '01', False))
loader.save(
    create_households_member(40, None, None, u'', u'Odette', u'', u'Adam',
                             u'F', u'2004-08-22', '05', 268, 271, '01', False))
loader.save(
    create_households_member(41, None, None, u'', u'Pascale', u'', u'Adam',
                             u'F', u'2004-08-22', '05', 269, 271, '01', False))
loader.save(
    create_households_member(42, None, None, u'', u'Jan', u'', u'Braun', u'M',
                             u'1996-08-22', '05', 263, 271, '01', False))
loader.save(
    create_households_member(43, None, None, u'', u'Kevin', u'', u'Braun',
                             u'M', u'1998-08-22', '05', 264, 271, '01', False))
loader.save(
    create_households_member(44, None, None, u'', u'Lars', u'', u'Braun', u'M',
                             u'1998-08-22', '05', 265, 271, '01', False))
loader.save(
    create_households_member(45, None, None, u'', u'Monique', u'', u'Braun',
                             u'F', u'2000-08-22', '05', 266, 271, '01', False))
loader.save(
    create_households_member(46, None, None, u'', u'Bruno', u'', u'Braun',
                             u'M', u'1973-07-22', '01', 259, 272, '02', False))
loader.save(
    create_households_member(47, None, None, u'', u'Eveline', u'', u'Evrard',
                             u'F', u'1974-08-21', '03', 260, 272, '02', False))
loader.save(
    create_households_member(48, None, None, u'', u'Jan', u'', u'Braun', u'M',
                             u'1996-08-22', '05', 263, 272, '01', False))
loader.save(
    create_households_member(49, None, None, u'', u'Kevin', u'', u'Braun',
                             u'M', u'1998-08-22', '05', 264, 272, '01', False))
loader.save(
    create_households_member(50, None, None, u'', u'Lars', u'', u'Braun', u'M',
                             u'1998-08-22', '05', 265, 272, '01', False))
loader.save(
    create_households_member(51, None, None, u'', u'Monique', u'', u'Braun',
                             u'F', u'2000-08-22', '05', 266, 272, '01', False))
loader.save(
    create_households_member(52, None, None, u'', u'No\xe9mie', u'', u'Adam',
                             u'F', u'2002-08-22', '05', 267, 272, '01', False))
loader.save(
    create_households_member(53, None, None, u'', u'Odette', u'', u'Adam',
                             u'F', u'2004-08-22', '05', 268, 272, '01', False))
loader.save(
    create_households_member(54, None, None, u'', u'Pascale', u'', u'Adam',
                             u'F', u'2004-08-22', '05', 269, 272, '01', False))
loader.save(
    create_households_member(55, None, None, u'', u'Bruno', u'', u'Braun',
                             u'M', u'1973-07-22', '01', 259, 273, '02', False))
loader.save(
    create_households_member(56, None, None, u'', u'Fran\xe7oise', u'',
                             u'Freisen', u'F', u'1974-08-22', '03', 261, 273,
                             '02', False))
loader.save(
    create_households_member(57, None, None, u'', u'Jan', u'', u'Braun', u'M',
                             u'1996-08-22', '05', 263, 273, '01', False))
loader.save(
    create_households_member(58, None, None, u'', u'Kevin', u'', u'Braun',
                             u'M', u'1998-08-22', '05', 264, 273, '01', False))
loader.save(
    create_households_member(59, None, None, u'', u'Lars', u'', u'Braun', u'M',
                             u'1998-08-22', '05', 265, 273, '01', False))
loader.save(
    create_households_member(60, None, None, u'', u'Monique', u'', u'Braun',
                             u'F', u'2000-08-22', '05', 266, 273, '01', False))
loader.save(
    create_households_member(61, None, None, u'', u'No\xe9mie', u'', u'Adam',
                             u'F', u'2002-08-22', '05', 267, 273, '01', False))
loader.save(
    create_households_member(62, None, None, u'', u'Odette', u'', u'Adam',
                             u'F', u'2004-08-22', '05', 268, 273, '01', False))
loader.save(
    create_households_member(63, None, None, u'', u'Pascale', u'', u'Adam',
                             u'F', u'2004-08-22', '05', 269, 273, '01', False))

loader.flush_deferred_objects()

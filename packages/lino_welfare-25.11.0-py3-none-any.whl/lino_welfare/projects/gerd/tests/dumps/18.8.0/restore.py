#!/usr/bin/env python
# -*- coding: UTF-8 -*-

# This is a Python dump created using dump2py.
# DJANGO_SETTINGS_MODULE was 'lino_welfare.projects.gerd.settings.demo', TIME_ZONE was None.

from lino import logger

SOURCE_VERSION = '18.11.0'

import os
import six
from decimal import Decimal
from datetime import datetime
from datetime import time, date
from django.conf import settings
from django.utils.timezone import make_aware, utc
from django.core.management import call_command
# from django.contrib.contenttypes.models import ContentType
from lino.utils.dpy import create_mti_child
from lino.utils.dpy import DpyLoader
from lino.core.utils import resolve_model

if settings.USE_TZ:

    def dt(*args):
        return make_aware(datetime(*args), timezone=utc)
else:

    def dt(*args):
        return datetime(*args)


def new_content_type_id(m):
    if m is None: return m
    ct = settings.SITE.models.contenttypes.ContentType.objects.get_for_model(m)
    if ct is None: return None
    return ct.pk


def pmem():
    # Thanks to https://stackoverflow.com/questions/938733/total-memory-used-by-python-process
    process = psutil.Process(os.getpid())
    print(process.memory_info().rss)


def execfile(fn, *args):
    logger.info("Execute file %s ...", fn)
    six.exec_(compile(open(fn, "rb").read(), fn, 'exec'), *args)
    # pmem()  # requires pip install psutil


def bv2kw(fieldname, values):
    """
    Needed if `Site.languages` changed between dumpdata and loaddata
    """
    return settings.SITE.babelkw(fieldname,
                                 de=values[0],
                                 fr=values[1],
                                 en=values[2])


addresses_Address = resolve_model("addresses.Address")
aids_AidType = resolve_model("aids.AidType")
aids_Category = resolve_model("aids.Category")
aids_Granting = resolve_model("aids.Granting")
aids_IncomeConfirmation = resolve_model("aids.IncomeConfirmation")
aids_RefundConfirmation = resolve_model("aids.RefundConfirmation")
aids_SimpleConfirmation = resolve_model("aids.SimpleConfirmation")
art61_Contract = resolve_model("art61.Contract")
art61_ContractType = resolve_model("art61.ContractType")
b2c_Account = resolve_model("b2c.Account")
b2c_Statement = resolve_model("b2c.Statement")
b2c_Transaction = resolve_model("b2c.Transaction")
boards_Board = resolve_model("boards.Board")
boards_Member = resolve_model("boards.Member")
cal_Calendar = resolve_model("cal.Calendar")
cal_DailyPlannerRow = resolve_model("cal.DailyPlannerRow")
cal_Event = resolve_model("cal.Event")
cal_EventPolicy = resolve_model("cal.EventPolicy")
cal_EventType = resolve_model("cal.EventType")
cal_Guest = resolve_model("cal.Guest")
cal_GuestRole = resolve_model("cal.GuestRole")
cal_RecurrentEvent = resolve_model("cal.RecurrentEvent")
cal_RemoteCalendar = resolve_model("cal.RemoteCalendar")
cal_Room = resolve_model("cal.Room")
cal_Subscription = resolve_model("cal.Subscription")
cal_Task = resolve_model("cal.Task")
cbss_IdentifyPersonRequest = resolve_model("cbss.IdentifyPersonRequest")
cbss_ManageAccessRequest = resolve_model("cbss.ManageAccessRequest")
cbss_Purpose = resolve_model("cbss.Purpose")
cbss_RetrieveTIGroupsRequest = resolve_model("cbss.RetrieveTIGroupsRequest")
cbss_Sector = resolve_model("cbss.Sector")
changes_Change = resolve_model("changes.Change")
checkdata_Problem = resolve_model("checkdata.Problem")
clients_ClientContact = resolve_model("clients.ClientContact")
clients_ClientContactType = resolve_model("clients.ClientContactType")
coachings_Coaching = resolve_model("coachings.Coaching")
coachings_CoachingEnding = resolve_model("coachings.CoachingEnding")
coachings_CoachingType = resolve_model("coachings.CoachingType")
contacts_Company = resolve_model("contacts.Company")
contacts_CompanyType = resolve_model("contacts.CompanyType")
contacts_Partner = resolve_model("contacts.Partner")
contacts_Person = resolve_model("contacts.Person")
contacts_Role = resolve_model("contacts.Role")
contacts_RoleType = resolve_model("contacts.RoleType")
countries_Country = resolve_model("countries.Country")
countries_Place = resolve_model("countries.Place")
cv_Duration = resolve_model("cv.Duration")
cv_EducationLevel = resolve_model("cv.EducationLevel")
cv_Experience = resolve_model("cv.Experience")
cv_Function = resolve_model("cv.Function")
cv_LanguageKnowledge = resolve_model("cv.LanguageKnowledge")
cv_Regime = resolve_model("cv.Regime")
cv_Sector = resolve_model("cv.Sector")
cv_Status = resolve_model("cv.Status")
cv_Study = resolve_model("cv.Study")
cv_StudyType = resolve_model("cv.StudyType")
cv_Training = resolve_model("cv.Training")
dashboard_Widget = resolve_model("dashboard.Widget")
debts_Account = resolve_model("debts.Account")
debts_Actor = resolve_model("debts.Actor")
debts_Budget = resolve_model("debts.Budget")
debts_Entry = resolve_model("debts.Entry")
debts_Group = resolve_model("debts.Group")
dupable_clients_Word = resolve_model("dupable_clients.Word")
esf_ClientSummary = resolve_model("esf.ClientSummary")
excerpts_Excerpt = resolve_model("excerpts.Excerpt")
excerpts_ExcerptType = resolve_model("excerpts.ExcerptType")
finan_BankStatement = resolve_model("finan.BankStatement")
finan_BankStatementItem = resolve_model("finan.BankStatementItem")
finan_JournalEntry = resolve_model("finan.JournalEntry")
finan_JournalEntryItem = resolve_model("finan.JournalEntryItem")
finan_PaymentOrder = resolve_model("finan.PaymentOrder")
finan_PaymentOrderItem = resolve_model("finan.PaymentOrderItem")
gfks_HelpText = resolve_model("gfks.HelpText")
households_Household = resolve_model("households.Household")
households_Member = resolve_model("households.Member")
households_Type = resolve_model("households.Type")
humanlinks_Link = resolve_model("humanlinks.Link")
isip_Contract = resolve_model("isip.Contract")
isip_ContractEnding = resolve_model("isip.ContractEnding")
isip_ContractPartner = resolve_model("isip.ContractPartner")
isip_ContractType = resolve_model("isip.ContractType")
isip_ExamPolicy = resolve_model("isip.ExamPolicy")
jobs_Candidature = resolve_model("jobs.Candidature")
jobs_Contract = resolve_model("jobs.Contract")
jobs_ContractType = resolve_model("jobs.ContractType")
jobs_Job = resolve_model("jobs.Job")
jobs_JobProvider = resolve_model("jobs.JobProvider")
jobs_JobType = resolve_model("jobs.JobType")
jobs_Offer = resolve_model("jobs.Offer")
jobs_Schedule = resolve_model("jobs.Schedule")
languages_Language = resolve_model("languages.Language")
ledger_Account = resolve_model("accounting.Account")
ledger_AccountingPeriod = resolve_model("accounting.AccountingPeriod")
ledger_FiscalYear = resolve_model("accounting.FiscalYear")
ledger_Journal = resolve_model("accounting.Journal")
ledger_LedgerInfo = resolve_model("accounting.LedgerInfo")
ledger_MatchRule = resolve_model("accounting.MatchRule")
ledger_Movement = resolve_model("accounting.Movement")
ledger_PaymentTerm = resolve_model("accounting.PaymentTerm")
ledger_Voucher = resolve_model("accounting.Voucher")
newcomers_Broker = resolve_model("newcomers.Broker")
newcomers_Competence = resolve_model("newcomers.Competence")
newcomers_Faculty = resolve_model("newcomers.Faculty")
notes_EventType = resolve_model("notes.EventType")
notes_Note = resolve_model("notes.Note")
notes_NoteType = resolve_model("notes.NoteType")
notify_Message = resolve_model("notify.Message")
outbox_Attachment = resolve_model("outbox.Attachment")
outbox_Mail = resolve_model("outbox.Mail")
outbox_Recipient = resolve_model("outbox.Recipient")
pcsw_Activity = resolve_model("pcsw.Activity")
pcsw_AidType = resolve_model("pcsw.AidType")
pcsw_Client = resolve_model("pcsw.Client")
pcsw_Conviction = resolve_model("pcsw.Conviction")
pcsw_Dispense = resolve_model("pcsw.Dispense")
pcsw_DispenseReason = resolve_model("pcsw.DispenseReason")
pcsw_Exclusion = resolve_model("pcsw.Exclusion")
pcsw_ExclusionType = resolve_model("pcsw.ExclusionType")
pcsw_PersonGroup = resolve_model("pcsw.PersonGroup")
properties_PersonProperty = resolve_model("properties.PersonProperty")
properties_PropChoice = resolve_model("properties.PropChoice")
properties_PropGroup = resolve_model("properties.PropGroup")
properties_PropType = resolve_model("properties.PropType")
properties_Property = resolve_model("properties.Property")
sepa_Account = resolve_model("sepa.Account")
system_SiteConfig = resolve_model("system.SiteConfig")
tinymce_TextFieldTemplate = resolve_model("tinymce.TextFieldTemplate")
uploads_Upload = resolve_model("uploads.Upload")
uploads_UploadType = resolve_model("uploads.UploadType")
users_Authority = resolve_model("users.Authority")
users_User = resolve_model("users.User")
vatless_AccountInvoice = resolve_model("vatless.AccountInvoice")
vatless_InvoiceItem = resolve_model("vatless.InvoiceItem")
xcourses_Course = resolve_model("xcourses.Course")
xcourses_CourseContent = resolve_model("xcourses.CourseContent")
xcourses_CourseOffer = resolve_model("xcourses.CourseOffer")
xcourses_CourseProvider = resolve_model("xcourses.CourseProvider")
xcourses_CourseRequest = resolve_model("xcourses.CourseRequest")


def create_aids_category(id, name):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    return aids_Category(**kw)


def create_b2c_account(id, iban, bic, account_name, owner_name,
                       last_transaction):
    kw = dict()
    kw.update(id=id)
    kw.update(iban=iban)
    kw.update(bic=bic)
    kw.update(account_name=account_name)
    kw.update(owner_name=owner_name)
    kw.update(last_transaction=last_transaction)
    return b2c_Account(**kw)


def create_b2c_statement(id, account_id, statement_number, start_date,
                         end_date, balance_start, balance_end, local_currency):
    if balance_start is not None: balance_start = Decimal(balance_start)
    if balance_end is not None: balance_end = Decimal(balance_end)
    kw = dict()
    kw.update(id=id)
    kw.update(account_id=account_id)
    kw.update(statement_number=statement_number)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(balance_start=balance_start)
    kw.update(balance_end=balance_end)
    kw.update(local_currency=local_currency)
    return b2c_Statement(**kw)


def create_b2c_transaction(id, statement_id, seqno, amount, remote_account,
                           remote_bic, message, eref, remote_owner,
                           remote_owner_address, remote_owner_city,
                           remote_owner_postalcode, remote_owner_country_code,
                           txcd, txcd_issuer, booking_date, value_date):
    if amount is not None: amount = Decimal(amount)
    kw = dict()
    kw.update(id=id)
    kw.update(statement_id=statement_id)
    kw.update(seqno=seqno)
    kw.update(amount=amount)
    kw.update(remote_account=remote_account)
    kw.update(remote_bic=remote_bic)
    kw.update(message=message)
    kw.update(eref=eref)
    kw.update(remote_owner=remote_owner)
    kw.update(remote_owner_address=remote_owner_address)
    kw.update(remote_owner_city=remote_owner_city)
    kw.update(remote_owner_postalcode=remote_owner_postalcode)
    kw.update(remote_owner_country_code=remote_owner_country_code)
    kw.update(txcd=txcd)
    kw.update(txcd_issuer=txcd_issuer)
    kw.update(booking_date=booking_date)
    kw.update(value_date=value_date)
    return b2c_Transaction(**kw)


def create_boards_board(id, start_date, end_date, name):
    kw = dict()
    kw.update(id=id)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    if name is not None: kw.update(bv2kw('name', name))
    return boards_Board(**kw)


def create_cal_calendar(id, name, description, color):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(description=description)
    kw.update(color=color)
    return cal_Calendar(**kw)


def create_cal_dailyplannerrow(id, seqno, designation, start_time, end_time):
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    if designation is not None: kw.update(bv2kw('designation', designation))
    kw.update(start_time=start_time)
    kw.update(end_time=end_time)
    return cal_DailyPlannerRow(**kw)


def create_cal_eventtype(id, ref, seqno, name, attach_to_email, email_template,
                         description, is_appointment, all_rooms, locks_user,
                         force_guest_states, start_date, event_label,
                         max_conflicting, max_days, transparent,
                         planner_column, invite_client, esf_field):
    #    if planner_column: planner_column = settings.SITE.models.cal.PlannerColumns.get_by_value(planner_column)
    #    if esf_field: esf_field = settings.SITE.models.esf.StatisticalFields.get_by_value(esf_field)
    kw = dict()
    kw.update(id=id)
    kw.update(ref=ref)
    kw.update(seqno=seqno)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(attach_to_email=attach_to_email)
    kw.update(email_template=email_template)
    kw.update(description=description)
    kw.update(is_appointment=is_appointment)
    kw.update(all_rooms=all_rooms)
    kw.update(locks_user=locks_user)
    kw.update(force_guest_states=force_guest_states)
    kw.update(start_date=start_date)
    if event_label is not None: kw.update(bv2kw('event_label', event_label))
    kw.update(max_conflicting=max_conflicting)
    kw.update(max_days=max_days)
    kw.update(transparent=transparent)
    kw.update(planner_column=planner_column)
    kw.update(invite_client=invite_client)
    kw.update(esf_field=esf_field)
    return cal_EventType(**kw)


def create_cal_eventpolicy(id, start_date, start_time, end_date, end_time,
                           name, every_unit, every, monday, tuesday, wednesday,
                           thursday, friday, saturday, sunday, max_events,
                           event_type_id):
    #    if every_unit: every_unit = settings.SITE.models.cal.Recurrences.get_by_value(every_unit)
    kw = dict()
    kw.update(id=id)
    kw.update(start_date=start_date)
    kw.update(start_time=start_time)
    kw.update(end_date=end_date)
    kw.update(end_time=end_time)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(every_unit=every_unit)
    kw.update(every=every)
    kw.update(monday=monday)
    kw.update(tuesday=tuesday)
    kw.update(wednesday=wednesday)
    kw.update(thursday=thursday)
    kw.update(friday=friday)
    kw.update(saturday=saturday)
    kw.update(sunday=sunday)
    kw.update(max_events=max_events)
    kw.update(event_type_id=event_type_id)
    return cal_EventPolicy(**kw)


def create_cal_guestrole(id, ref, name):
    kw = dict()
    kw.update(id=id)
    kw.update(ref=ref)
    if name is not None: kw.update(bv2kw('name', name))
    return cal_GuestRole(**kw)


def create_cal_remotecalendar(id, seqno, type, url_template, username,
                              password, readonly):
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    kw.update(type=type)
    kw.update(url_template=url_template)
    kw.update(username=username)
    kw.update(password=password)
    kw.update(readonly=readonly)
    return cal_RemoteCalendar(**kw)


def create_cbss_purpose(id, name, sector_code, code):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(sector_code=sector_code)
    kw.update(code=code)
    return cbss_Purpose(**kw)


def create_cbss_sector(id, name, code, subcode, abbr):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(code=code)
    kw.update(subcode=subcode)
    if abbr is not None: kw.update(bv2kw('abbr', abbr))
    return cbss_Sector(**kw)


def create_clients_clientcontacttype(id, name, known_contact_type, is_bailiff,
                                     can_refund):
    #    if known_contact_type: known_contact_type = settings.SITE.models.clients.KnownContactTypes.get_by_value(known_contact_type)
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(known_contact_type=known_contact_type)
    kw.update(is_bailiff=is_bailiff)
    kw.update(can_refund=can_refund)
    return clients_ClientContactType(**kw)


def create_coachings_coachingtype(id, name, does_integ, does_gss,
                                  eval_guestrole_id):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(does_integ=does_integ)
    kw.update(does_gss=does_gss)
    kw.update(eval_guestrole_id=eval_guestrole_id)
    return coachings_CoachingType(**kw)


def create_coachings_coachingending(id, seqno, name, type_id):
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(type_id=type_id)
    return coachings_CoachingEnding(**kw)


def create_contacts_companytype(id, name, abbr):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    if abbr is not None: kw.update(bv2kw('abbr', abbr))
    return contacts_CompanyType(**kw)


def create_contacts_roletype(id, name, use_in_contracts):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(use_in_contracts=use_in_contracts)
    return contacts_RoleType(**kw)


def create_countries_country(name, isocode, short_code, iso3, inscode,
                             actual_country_id):
    kw = dict()
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(isocode=isocode)
    kw.update(short_code=short_code)
    kw.update(iso3=iso3)
    kw.update(inscode=inscode)
    kw.update(actual_country_id=actual_country_id)
    return countries_Country(**kw)


def create_countries_place(id, parent_id, name, country_id, zip_code, type,
                           show_type, inscode):
    #    if type: type = settings.SITE.models.countries.PlaceTypes.get_by_value(type)
    kw = dict()
    kw.update(id=id)
    kw.update(parent_id=parent_id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(country_id=country_id)
    kw.update(zip_code=zip_code)
    kw.update(type=type)
    kw.update(show_type=show_type)
    kw.update(inscode=inscode)
    return countries_Place(**kw)


def create_cv_duration(id, name):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    return cv_Duration(**kw)


def create_cv_educationlevel(id, seqno, name, is_study, is_training):
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(is_study=is_study)
    kw.update(is_training=is_training)
    return cv_EducationLevel(**kw)


def create_cv_regime(id, name):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    return cv_Regime(**kw)


def create_cv_sector(id, name, remark):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(remark=remark)
    return cv_Sector(**kw)


def create_cv_function(id, name, remark, sector_id):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(remark=remark)
    kw.update(sector_id=sector_id)
    return cv_Function(**kw)


def create_cv_status(id, name):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    return cv_Status(**kw)


def create_cv_studytype(id, name, is_study, is_training, education_level_id):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(is_study=is_study)
    kw.update(is_training=is_training)
    kw.update(education_level_id=education_level_id)
    return cv_StudyType(**kw)


def create_debts_group(id, name, ref, account_type, entries_layout):
    #    if account_type: account_type = settings.SITE.models.debts.AccountTypes.get_by_value(account_type)
    #    if entries_layout: entries_layout = settings.SITE.models.debts.EntriesLayouts.get_by_value(entries_layout)
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(ref=ref)
    kw.update(account_type=account_type)
    kw.update(entries_layout=entries_layout)
    return debts_Group(**kw)


def create_debts_account(id, ref, seqno, name, group_id, type,
                         required_for_household, required_for_person, periods,
                         default_amount):
    #    if type: type = settings.SITE.models.debts.AccountTypes.get_by_value(type)
    if periods is not None: periods = Decimal(periods)
    if default_amount is not None: default_amount = Decimal(default_amount)
    kw = dict()
    kw.update(id=id)
    kw.update(ref=ref)
    kw.update(seqno=seqno)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(group_id=group_id)
    kw.update(type=type)
    kw.update(required_for_household=required_for_household)
    kw.update(required_for_person=required_for_person)
    kw.update(periods=periods)
    kw.update(default_amount=default_amount)
    return debts_Account(**kw)


def create_excerpts_excerpttype(id, name, build_method, template,
                                attach_to_email, email_template, certifying,
                                remark, body_template, content_type_id,
                                primary, backward_compat, print_recipient,
                                print_directly, shortcut):
    #    if build_method: build_method = settings.SITE.models.printing.BuildMethods.get_by_value(build_method)
    content_type_id = new_content_type_id(content_type_id)
    #    if shortcut: shortcut = settings.SITE.models.excerpts.Shortcuts.get_by_value(shortcut)
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(build_method=build_method)
    kw.update(template=template)
    kw.update(attach_to_email=attach_to_email)
    kw.update(email_template=email_template)
    kw.update(certifying=certifying)
    kw.update(remark=remark)
    kw.update(body_template=body_template)
    kw.update(content_type_id=content_type_id)
    kw.update(primary=primary)
    kw.update(backward_compat=backward_compat)
    kw.update(print_recipient=print_recipient)
    kw.update(print_directly=print_directly)
    kw.update(shortcut=shortcut)
    return excerpts_ExcerptType(**kw)


def create_gfks_helptext(id, content_type_id, field, help_text):
    content_type_id = new_content_type_id(content_type_id)
    kw = dict()
    kw.update(id=id)
    kw.update(content_type_id=content_type_id)
    kw.update(field=field)
    kw.update(help_text=help_text)
    return gfks_HelpText(**kw)


def create_households_type(id, name):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    return households_Type(**kw)


def create_isip_contractending(id, name, use_in_isip, use_in_jobs, is_success,
                               needs_date_ended):
    kw = dict()
    kw.update(id=id)
    kw.update(name=name)
    kw.update(use_in_isip=use_in_isip)
    kw.update(use_in_jobs=use_in_jobs)
    kw.update(is_success=is_success)
    kw.update(needs_date_ended=needs_date_ended)
    return isip_ContractEnding(**kw)


def create_isip_exampolicy(id, start_date, start_time, end_date, end_time,
                           name, every_unit, every, monday, tuesday, wednesday,
                           thursday, friday, saturday, sunday, max_events,
                           event_type_id):
    #    if every_unit: every_unit = settings.SITE.models.cal.Recurrences.get_by_value(every_unit)
    kw = dict()
    kw.update(id=id)
    kw.update(start_date=start_date)
    kw.update(start_time=start_time)
    kw.update(end_date=end_date)
    kw.update(end_time=end_time)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(every_unit=every_unit)
    kw.update(every=every)
    kw.update(monday=monday)
    kw.update(tuesday=tuesday)
    kw.update(wednesday=wednesday)
    kw.update(thursday=thursday)
    kw.update(friday=friday)
    kw.update(saturday=saturday)
    kw.update(sunday=sunday)
    kw.update(max_events=max_events)
    kw.update(event_type_id=event_type_id)
    return isip_ExamPolicy(**kw)


def create_art61_contracttype(id, ref, name, full_name, exam_policy_id,
                              overlap_group, template):
    #    if overlap_group: overlap_group = settings.SITE.models.isip.OverlapGroups.get_by_value(overlap_group)
    kw = dict()
    kw.update(id=id)
    kw.update(ref=ref)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(full_name=full_name)
    kw.update(exam_policy_id=exam_policy_id)
    kw.update(overlap_group=overlap_group)
    kw.update(template=template)
    return art61_ContractType(**kw)


def create_isip_contracttype(id, name, full_name, exam_policy_id,
                             overlap_group, template, ref, needs_study_type):
    #    if overlap_group: overlap_group = settings.SITE.models.isip.OverlapGroups.get_by_value(overlap_group)
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(full_name=full_name)
    kw.update(exam_policy_id=exam_policy_id)
    kw.update(overlap_group=overlap_group)
    kw.update(template=template)
    kw.update(ref=ref)
    kw.update(needs_study_type=needs_study_type)
    return isip_ContractType(**kw)


def create_jobs_contracttype(id, ref, name, full_name, exam_policy_id,
                             overlap_group, template):
    #    if overlap_group: overlap_group = settings.SITE.models.isip.OverlapGroups.get_by_value(overlap_group)
    kw = dict()
    kw.update(id=id)
    kw.update(ref=ref)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(full_name=full_name)
    kw.update(exam_policy_id=exam_policy_id)
    kw.update(overlap_group=overlap_group)
    kw.update(template=template)
    return jobs_ContractType(**kw)


def create_jobs_jobtype(id, seqno, name, remark, is_social):
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    kw.update(name=name)
    kw.update(remark=remark)
    kw.update(is_social=is_social)
    return jobs_JobType(**kw)


def create_jobs_schedule(id, name):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    return jobs_Schedule(**kw)


def create_languages_language(name, id, iso2):
    kw = dict()
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(id=id)
    kw.update(iso2=iso2)
    return languages_Language(**kw)


def create_ledger_account(id, ref, seqno, name, common_account, needs_partner,
                          clearable, default_amount, sales_allowed,
                          purchases_allowed, wages_allowed, taxes_allowed,
                          clearings_allowed, bank_po_allowed):
    #    if common_account: common_account = settings.SITE.models.accounting.CommonAccounts.get_by_value(common_account)
    if default_amount is not None: default_amount = Decimal(default_amount)
    kw = dict()
    kw.update(id=id)
    kw.update(ref=ref)
    kw.update(seqno=seqno)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(common_account=common_account)
    kw.update(needs_partner=needs_partner)
    kw.update(clearable=clearable)
    kw.update(default_amount=default_amount)
    kw.update(sales_allowed=sales_allowed)
    kw.update(purchases_allowed=purchases_allowed)
    kw.update(wages_allowed=wages_allowed)
    kw.update(taxes_allowed=taxes_allowed)
    kw.update(clearings_allowed=clearings_allowed)
    kw.update(bank_po_allowed=bank_po_allowed)
    return ledger_Account(**kw)


def create_ledger_fiscalyear(id, ref, start_date, end_date, state):
    #    if state: state = settings.SITE.models.accounting.PeriodStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(ref=ref)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(state=state)
    return ledger_FiscalYear(**kw)


def create_ledger_accountingperiod(id, ref, start_date, end_date, state,
                                   year_id, remark):
    #    if state: state = settings.SITE.models.accounting.PeriodStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(ref=ref)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(state=state)
    kw.update(year_id=year_id)
    kw.update(remark=remark)
    return ledger_AccountingPeriod(**kw)


def create_ledger_paymentterm(id, ref, name, days, months, end_of_month,
                              printed_text):
    kw = dict()
    kw.update(id=id)
    kw.update(ref=ref)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(days=days)
    kw.update(months=months)
    kw.update(end_of_month=end_of_month)
    if printed_text is not None: kw.update(bv2kw('printed_text', printed_text))
    return ledger_PaymentTerm(**kw)


def create_newcomers_broker(id, name):
    kw = dict()
    kw.update(id=id)
    kw.update(name=name)
    return newcomers_Broker(**kw)


def create_newcomers_faculty(id, name, weight):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(weight=weight)
    return newcomers_Faculty(**kw)


def create_notes_eventtype(id, name, remark, body):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(remark=remark)
    if body is not None: kw.update(bv2kw('body', body))
    return notes_EventType(**kw)


def create_notes_notetype(id, name, build_method, template, attach_to_email,
                          email_template, important, remark, special_type):
    #    if build_method: build_method = settings.SITE.models.printing.BuildMethods.get_by_value(build_method)
    #    if special_type: special_type = settings.SITE.models.notes.SpecialTypes.get_by_value(special_type)
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(build_method=build_method)
    kw.update(template=template)
    kw.update(attach_to_email=attach_to_email)
    kw.update(email_template=email_template)
    kw.update(important=important)
    kw.update(remark=remark)
    kw.update(special_type=special_type)
    return notes_NoteType(**kw)


def create_pcsw_activity(id, name, lst104):
    kw = dict()
    kw.update(id=id)
    kw.update(name=name)
    kw.update(lst104=lst104)
    return pcsw_Activity(**kw)


def create_contacts_partner(id, email, language, url, phone, gsm, fax,
                            modified, created, country_id, city_id, zip_code,
                            region_id, addr1, street_prefix, street, street_no,
                            street_box, addr2, prefix, name, remarks,
                            is_obsolete, activity_id, client_contact_type_id,
                            payment_term_id):
    kw = dict()
    kw.update(id=id)
    kw.update(email=email)
    kw.update(language=language)
    kw.update(url=url)
    kw.update(phone=phone)
    kw.update(gsm=gsm)
    kw.update(fax=fax)
    kw.update(modified=modified)
    kw.update(created=created)
    kw.update(country_id=country_id)
    kw.update(city_id=city_id)
    kw.update(zip_code=zip_code)
    kw.update(region_id=region_id)
    kw.update(addr1=addr1)
    kw.update(street_prefix=street_prefix)
    kw.update(street=street)
    kw.update(street_no=street_no)
    kw.update(street_box=street_box)
    kw.update(addr2=addr2)
    kw.update(prefix=prefix)
    kw.update(name=name)
    kw.update(remarks=remarks)
    kw.update(is_obsolete=is_obsolete)
    kw.update(activity_id=activity_id)
    kw.update(client_contact_type_id=client_contact_type_id)
    kw.update(payment_term_id=payment_term_id)
    return contacts_Partner(**kw)


def create_addresses_address(id, country_id, city_id, zip_code, region_id,
                             addr1, street_prefix, street, street_no,
                             street_box, addr2, data_source, address_type,
                             partner_id, remark, primary):
    #    if data_source: data_source = settings.SITE.models.addresses.DataSources.get_by_value(data_source)
    #    if address_type: address_type = settings.SITE.models.addresses.AddressTypes.get_by_value(address_type)
    kw = dict()
    kw.update(id=id)
    kw.update(country_id=country_id)
    kw.update(city_id=city_id)
    kw.update(zip_code=zip_code)
    kw.update(region_id=region_id)
    kw.update(addr1=addr1)
    kw.update(street_prefix=street_prefix)
    kw.update(street=street)
    kw.update(street_no=street_no)
    kw.update(street_box=street_box)
    kw.update(addr2=addr2)
    kw.update(data_source=data_source)
    kw.update(address_type=address_type)
    kw.update(partner_id=partner_id)
    kw.update(remark=remark)
    kw.update(primary=primary)
    return addresses_Address(**kw)


def create_contacts_company(partner_ptr_id, type_id, vat_id):
    kw = dict()
    kw.update(type_id=type_id)
    kw.update(vat_id=vat_id)
    return create_mti_child(contacts_Partner, partner_ptr_id, contacts_Company,
                            **kw)


def create_contacts_person(partner_ptr_id, title, first_name, middle_name,
                           last_name, gender, birth_date):
    #    if gender: gender = settings.SITE.models.system.Genders.get_by_value(gender)
    kw = dict()
    kw.update(title=title)
    kw.update(first_name=first_name)
    kw.update(middle_name=middle_name)
    kw.update(last_name=last_name)
    kw.update(gender=gender)
    kw.update(birth_date=birth_date)
    return create_mti_child(contacts_Partner, partner_ptr_id, contacts_Person,
                            **kw)


def create_aids_aidtype(id, name, company_id, contact_person_id,
                        contact_role_id, excerpt_title, aid_regime,
                        confirmation_type, short_name, board_id,
                        print_directly, is_integ_duty, is_urgent,
                        confirmed_by_primary_coach, pharmacy_type_id,
                        address_type, body_template):
    #    if aid_regime: aid_regime = settings.SITE.models.aids.AidRegimes.get_by_value(aid_regime)
    #    if confirmation_type: confirmation_type = settings.SITE.models.aids.ConfirmationTypes.get_by_value(confirmation_type)
    #    if address_type: address_type = settings.SITE.models.addresses.AddressTypes.get_by_value(address_type)
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    if excerpt_title is not None:
        kw.update(bv2kw('excerpt_title', excerpt_title))
    kw.update(aid_regime=aid_regime)
    kw.update(confirmation_type=confirmation_type)
    kw.update(short_name=short_name)
    kw.update(board_id=board_id)
    kw.update(print_directly=print_directly)
    kw.update(is_integ_duty=is_integ_duty)
    kw.update(is_urgent=is_urgent)
    kw.update(confirmed_by_primary_coach=confirmed_by_primary_coach)
    kw.update(pharmacy_type_id=pharmacy_type_id)
    kw.update(address_type=address_type)
    kw.update(body_template=body_template)
    return aids_AidType(**kw)


def create_boards_member(id, board_id, person_id, role_id):
    kw = dict()
    kw.update(id=id)
    kw.update(board_id=board_id)
    kw.update(person_id=person_id)
    kw.update(role_id=role_id)
    return boards_Member(**kw)


def create_cal_room(id, name, company_id, contact_person_id, contact_role_id,
                    description):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    kw.update(description=description)
    return cal_Room(**kw)


def create_contacts_role(id, type_id, person_id, company_id):
    kw = dict()
    kw.update(id=id)
    kw.update(type_id=type_id)
    kw.update(person_id=person_id)
    kw.update(company_id=company_id)
    return contacts_Role(**kw)


def create_households_household(partner_ptr_id, type_id):
    kw = dict()
    kw.update(type_id=type_id)
    return create_mti_child(contacts_Partner, partner_ptr_id,
                            households_Household, **kw)


def create_households_member(id, start_date, end_date, title, first_name,
                             middle_name, last_name, gender, birth_date, role,
                             person_id, household_id, dependency, primary):
    #    if gender: gender = settings.SITE.models.system.Genders.get_by_value(gender)
    #    if role: role = settings.SITE.models.households.MemberRoles.get_by_value(role)
    #    if dependency: dependency = settings.SITE.models.households.MemberDependencies.get_by_value(dependency)
    kw = dict()
    kw.update(id=id)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(title=title)
    kw.update(first_name=first_name)
    kw.update(middle_name=middle_name)
    kw.update(last_name=last_name)
    kw.update(gender=gender)
    kw.update(birth_date=birth_date)
    kw.update(role=role)
    kw.update(person_id=person_id)
    kw.update(household_id=household_id)
    kw.update(dependency=dependency)
    kw.update(primary=primary)
    return households_Member(**kw)


def create_humanlinks_link(id, type, parent_id, child_id):
    #    if type: type = settings.SITE.models.humanlinks.LinkTypes.get_by_value(type)
    kw = dict()
    kw.update(id=id)
    kw.update(type=type)
    kw.update(parent_id=parent_id)
    kw.update(child_id=child_id)
    return humanlinks_Link(**kw)


def create_jobs_jobprovider(company_ptr_id):
    kw = dict()
    return create_mti_child(contacts_Company, company_ptr_id, jobs_JobProvider,
                            **kw)


def create_jobs_job(id, sector_id, function_id, name, type_id, provider_id,
                    contract_type_id, hourly_rate, capacity, remark):
    if hourly_rate is not None: hourly_rate = Decimal(hourly_rate)
    kw = dict()
    kw.update(id=id)
    kw.update(sector_id=sector_id)
    kw.update(function_id=function_id)
    kw.update(name=name)
    kw.update(type_id=type_id)
    kw.update(provider_id=provider_id)
    kw.update(contract_type_id=contract_type_id)
    kw.update(hourly_rate=hourly_rate)
    kw.update(capacity=capacity)
    kw.update(remark=remark)
    return jobs_Job(**kw)


def create_jobs_offer(id, sector_id, function_id, name, provider_id,
                      selection_from, selection_until, start_date, remark):
    kw = dict()
    kw.update(id=id)
    kw.update(sector_id=sector_id)
    kw.update(function_id=function_id)
    kw.update(name=name)
    kw.update(provider_id=provider_id)
    kw.update(selection_from=selection_from)
    kw.update(selection_until=selection_until)
    kw.update(start_date=start_date)
    kw.update(remark=remark)
    return jobs_Offer(**kw)


def create_pcsw_aidtype(id, name):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    return pcsw_AidType(**kw)


def create_pcsw_dispensereason(id, seqno, name):
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    if name is not None: kw.update(bv2kw('name', name))
    return pcsw_DispenseReason(**kw)


def create_pcsw_exclusiontype(id, name):
    kw = dict()
    kw.update(id=id)
    kw.update(name=name)
    return pcsw_ExclusionType(**kw)


def create_pcsw_persongroup(id, name, ref_name, active):
    kw = dict()
    kw.update(id=id)
    kw.update(name=name)
    kw.update(ref_name=ref_name)
    kw.update(active=active)
    return pcsw_PersonGroup(**kw)


def create_pcsw_client(
        person_ptr_id, national_id, birth_country_id, birth_place,
        nationality_id, card_number, card_valid_from, card_valid_until,
        card_type, card_issuer, noble_condition, client_state, group_id,
        civil_state, residence_type, in_belgium_since, residence_until,
        unemployed_since, seeking_since, needs_residence_permit,
        needs_work_permit, work_permit_suspended_until, aid_type_id,
        declared_name, is_seeking, unavailable_until, unavailable_why,
        obstacles, skills, job_office_contact_id, refusal_reason, remarks2,
        gesdos_id, tim_id, is_cpas, is_senior, health_insurance_id,
        pharmacy_id, income_ag, income_wg, income_kg, income_rente,
        income_misc, job_agents, broker_id, faculty_id, has_esf):
    #    if card_type: card_type = settings.SITE.models.beid.BeIdCardTypes.get_by_value(card_type)
    #    if client_state: client_state = settings.SITE.models.clients.ClientStates.get_by_value(client_state)
    #    if civil_state: civil_state = settings.SITE.models.contacts.CivilStates.get_by_value(civil_state)
    #    if residence_type: residence_type = settings.SITE.models.beid.ResidenceTypes.get_by_value(residence_type)
    #    if refusal_reason: refusal_reason = settings.SITE.models.pcsw.RefusalReasons.get_by_value(refusal_reason)
    kw = dict()
    kw.update(national_id=national_id)
    kw.update(birth_country_id=birth_country_id)
    kw.update(birth_place=birth_place)
    kw.update(nationality_id=nationality_id)
    kw.update(card_number=card_number)
    kw.update(card_valid_from=card_valid_from)
    kw.update(card_valid_until=card_valid_until)
    kw.update(card_type=card_type)
    kw.update(card_issuer=card_issuer)
    kw.update(noble_condition=noble_condition)
    kw.update(client_state=client_state)
    kw.update(group_id=group_id)
    kw.update(civil_state=civil_state)
    kw.update(residence_type=residence_type)
    kw.update(in_belgium_since=in_belgium_since)
    kw.update(residence_until=residence_until)
    kw.update(unemployed_since=unemployed_since)
    kw.update(seeking_since=seeking_since)
    kw.update(needs_residence_permit=needs_residence_permit)
    kw.update(needs_work_permit=needs_work_permit)
    kw.update(work_permit_suspended_until=work_permit_suspended_until)
    kw.update(aid_type_id=aid_type_id)
    kw.update(declared_name=declared_name)
    kw.update(is_seeking=is_seeking)
    kw.update(unavailable_until=unavailable_until)
    kw.update(unavailable_why=unavailable_why)
    kw.update(obstacles=obstacles)
    kw.update(skills=skills)
    kw.update(job_office_contact_id=job_office_contact_id)
    kw.update(refusal_reason=refusal_reason)
    kw.update(remarks2=remarks2)
    kw.update(gesdos_id=gesdos_id)
    kw.update(tim_id=tim_id)
    kw.update(is_cpas=is_cpas)
    kw.update(is_senior=is_senior)
    kw.update(health_insurance_id=health_insurance_id)
    kw.update(pharmacy_id=pharmacy_id)
    kw.update(income_ag=income_ag)
    kw.update(income_wg=income_wg)
    kw.update(income_kg=income_kg)
    kw.update(income_rente=income_rente)
    kw.update(income_misc=income_misc)
    kw.update(job_agents=job_agents)
    kw.update(broker_id=broker_id)
    kw.update(faculty_id=faculty_id)
    kw.update(has_esf=has_esf)
    return create_mti_child(contacts_Person, person_ptr_id, pcsw_Client, **kw)


def create_clients_clientcontact(id, company_id, contact_person_id,
                                 contact_role_id, type_id, client_id, remark):
    kw = dict()
    kw.update(id=id)
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    kw.update(type_id=type_id)
    kw.update(client_id=client_id)
    kw.update(remark=remark)
    return clients_ClientContact(**kw)


def create_cv_experience(id, start_date, end_date, country_id, city_id,
                         zip_code, sector_id, function_id, person_id,
                         duration_text, company, title, status_id, duration_id,
                         regime_id, is_training, remarks, termination_reason):
    kw = dict()
    kw.update(id=id)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(country_id=country_id)
    kw.update(city_id=city_id)
    kw.update(zip_code=zip_code)
    kw.update(sector_id=sector_id)
    kw.update(function_id=function_id)
    kw.update(person_id=person_id)
    kw.update(duration_text=duration_text)
    kw.update(company=company)
    kw.update(title=title)
    kw.update(status_id=status_id)
    kw.update(duration_id=duration_id)
    kw.update(regime_id=regime_id)
    kw.update(is_training=is_training)
    kw.update(remarks=remarks)
    kw.update(termination_reason=termination_reason)
    return cv_Experience(**kw)


def create_cv_languageknowledge(id, person_id, language_id, spoken, written,
                                spoken_passively, written_passively, native,
                                cef_level):
    #    if spoken: spoken = settings.SITE.models.cv.HowWell.get_by_value(spoken)
    #    if written: written = settings.SITE.models.cv.HowWell.get_by_value(written)
    #    if spoken_passively: spoken_passively = settings.SITE.models.cv.HowWell.get_by_value(spoken_passively)
    #    if written_passively: written_passively = settings.SITE.models.cv.HowWell.get_by_value(written_passively)
    #    if cef_level: cef_level = settings.SITE.models.cv.CefLevel.get_by_value(cef_level)
    kw = dict()
    kw.update(id=id)
    kw.update(person_id=person_id)
    kw.update(language_id=language_id)
    kw.update(spoken=spoken)
    kw.update(written=written)
    kw.update(spoken_passively=spoken_passively)
    kw.update(written_passively=written_passively)
    kw.update(native=native)
    kw.update(cef_level=cef_level)
    return cv_LanguageKnowledge(**kw)


def create_cv_study(id, start_date, end_date, country_id, city_id, zip_code,
                    person_id, duration_text, language_id, school, state,
                    remarks, type_id, education_level_id, content):
    #    if state: state = settings.SITE.models.cv.EducationEntryStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(country_id=country_id)
    kw.update(city_id=city_id)
    kw.update(zip_code=zip_code)
    kw.update(person_id=person_id)
    kw.update(duration_text=duration_text)
    kw.update(language_id=language_id)
    kw.update(school=school)
    kw.update(state=state)
    kw.update(remarks=remarks)
    kw.update(type_id=type_id)
    kw.update(education_level_id=education_level_id)
    kw.update(content=content)
    return cv_Study(**kw)


def create_cv_training(id, start_date, end_date, country_id, city_id, zip_code,
                       sector_id, function_id, person_id, duration_text,
                       language_id, school, state, remarks, type_id, content,
                       certificates):
    #    if state: state = settings.SITE.models.cv.EducationEntryStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(country_id=country_id)
    kw.update(city_id=city_id)
    kw.update(zip_code=zip_code)
    kw.update(sector_id=sector_id)
    kw.update(function_id=function_id)
    kw.update(person_id=person_id)
    kw.update(duration_text=duration_text)
    kw.update(language_id=language_id)
    kw.update(school=school)
    kw.update(state=state)
    kw.update(remarks=remarks)
    kw.update(type_id=type_id)
    kw.update(content=content)
    kw.update(certificates=certificates)
    return cv_Training(**kw)


def create_dupable_clients_word(id, word, owner_id):
    kw = dict()
    kw.update(id=id)
    kw.update(word=word)
    kw.update(owner_id=owner_id)
    return dupable_clients_Word(**kw)


def create_jobs_candidature(id, sector_id, function_id, person_id, job_id,
                            date_submitted, remark, state, art60, art61):
    #    if state: state = settings.SITE.models.jobs.CandidatureStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(sector_id=sector_id)
    kw.update(function_id=function_id)
    kw.update(person_id=person_id)
    kw.update(job_id=job_id)
    kw.update(date_submitted=date_submitted)
    kw.update(remark=remark)
    kw.update(state=state)
    kw.update(art60=art60)
    kw.update(art61=art61)
    return jobs_Candidature(**kw)


def create_pcsw_conviction(id, client_id, date, prejudicial, designation):
    kw = dict()
    kw.update(id=id)
    kw.update(client_id=client_id)
    kw.update(date=date)
    kw.update(prejudicial=prejudicial)
    kw.update(designation=designation)
    return pcsw_Conviction(**kw)


def create_pcsw_dispense(id, client_id, reason_id, remarks, start_date,
                         end_date):
    kw = dict()
    kw.update(id=id)
    kw.update(client_id=client_id)
    kw.update(reason_id=reason_id)
    kw.update(remarks=remarks)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    return pcsw_Dispense(**kw)


def create_pcsw_exclusion(id, person_id, type_id, excluded_from,
                          excluded_until, remark):
    kw = dict()
    kw.update(id=id)
    kw.update(person_id=person_id)
    kw.update(type_id=type_id)
    kw.update(excluded_from=excluded_from)
    kw.update(excluded_until=excluded_until)
    kw.update(remark=remark)
    return pcsw_Exclusion(**kw)


def create_properties_propgroup(id, name):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    return properties_PropGroup(**kw)


def create_properties_proptype(id, name, choicelist, default_value,
                               limit_to_choices, multiple_choices):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(choicelist=choicelist)
    kw.update(default_value=default_value)
    kw.update(limit_to_choices=limit_to_choices)
    kw.update(multiple_choices=multiple_choices)
    return properties_PropType(**kw)


def create_properties_propchoice(id, type_id, value, text):
    kw = dict()
    kw.update(id=id)
    kw.update(type_id=type_id)
    kw.update(value=value)
    if text is not None: kw.update(bv2kw('text', text))
    return properties_PropChoice(**kw)


def create_properties_property(id, name, group_id, type_id):
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(group_id=group_id)
    kw.update(type_id=type_id)
    return properties_Property(**kw)


def create_properties_personproperty(id, group_id, property_id, value,
                                     person_id, remark):
    kw = dict()
    kw.update(id=id)
    kw.update(group_id=group_id)
    kw.update(property_id=property_id)
    kw.update(value=value)
    kw.update(person_id=person_id)
    kw.update(remark=remark)
    return properties_PersonProperty(**kw)


def create_sepa_account(id, partner_id, iban, bic, remark, primary,
                        account_type, managed):
    #    if account_type: account_type = settings.SITE.models.sepa.AccountTypes.get_by_value(account_type)
    kw = dict()
    kw.update(id=id)
    kw.update(partner_id=partner_id)
    kw.update(iban=iban)
    kw.update(bic=bic)
    kw.update(remark=remark)
    kw.update(primary=primary)
    kw.update(account_type=account_type)
    kw.update(managed=managed)
    return sepa_Account(**kw)


def create_ledger_journal(id, ref, seqno, name, build_method, template,
                          trade_type, voucher_type, journal_group,
                          auto_check_clearings, auto_fill_suggestions,
                          force_sequence, account_id, partner_id, printed_name,
                          dc, yearly_numbering, must_declare, sepa_account_id):
    #    if build_method: build_method = settings.SITE.models.printing.BuildMethods.get_by_value(build_method)
    #    if trade_type: trade_type = settings.SITE.models.accounting.TradeTypes.get_by_value(trade_type)
    #    if voucher_type: voucher_type = settings.SITE.models.accounting.VoucherTypes.get_by_value(voucher_type)
    #    if journal_group: journal_group = settings.SITE.models.accounting.JournalGroups.get_by_value(journal_group)
    kw = dict()
    kw.update(id=id)
    kw.update(ref=ref)
    kw.update(seqno=seqno)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(build_method=build_method)
    kw.update(template=template)
    kw.update(trade_type=trade_type)
    kw.update(voucher_type=voucher_type)
    kw.update(journal_group=journal_group)
    kw.update(auto_check_clearings=auto_check_clearings)
    kw.update(auto_fill_suggestions=auto_fill_suggestions)
    kw.update(force_sequence=force_sequence)
    kw.update(account_id=account_id)
    kw.update(partner_id=partner_id)
    if printed_name is not None: kw.update(bv2kw('printed_name', printed_name))
    kw.update(dc=dc)
    kw.update(yearly_numbering=yearly_numbering)
    kw.update(must_declare=must_declare)
    kw.update(sepa_account_id=sepa_account_id)
    return ledger_Journal(**kw)


def create_ledger_matchrule(id, account_id, journal_id):
    kw = dict()
    kw.update(id=id)
    kw.update(account_id=account_id)
    kw.update(journal_id=journal_id)
    return ledger_MatchRule(**kw)


def create_uploads_uploadtype(id, name, upload_area, max_number, wanted,
                              shortcut, warn_expiry_unit, warn_expiry_value):
    #    if upload_area: upload_area = settings.SITE.models.uploads.UploadAreas.get_by_value(upload_area)
    #    if shortcut: shortcut = settings.SITE.models.uploads.Shortcuts.get_by_value(shortcut)
    #    if warn_expiry_unit: warn_expiry_unit = settings.SITE.models.cal.Recurrences.get_by_value(warn_expiry_unit)
    kw = dict()
    kw.update(id=id)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(upload_area=upload_area)
    kw.update(max_number=max_number)
    kw.update(wanted=wanted)
    kw.update(shortcut=shortcut)
    kw.update(warn_expiry_unit=warn_expiry_unit)
    kw.update(warn_expiry_value=warn_expiry_value)
    return uploads_UploadType(**kw)


def create_users_user(id, email, language, modified, created, start_date,
                      end_date, password, last_login, username, user_type,
                      initials, first_name, last_name, remarks,
                      newcomer_consultations, newcomer_appointments,
                      notify_myself, mail_mode, access_class, event_type_id,
                      calendar_id, coaching_type_id, coaching_supervisor,
                      newcomer_quota, partner_id):
    #    if user_type: user_type = settings.SITE.models.users.UserTypes.get_by_value(user_type)
    #    if mail_mode: mail_mode = settings.SITE.models.notify.MailModes.get_by_value(mail_mode)
    #    if access_class: access_class = settings.SITE.models.cal.AccessClasses.get_by_value(access_class)
    kw = dict()
    kw.update(id=id)
    kw.update(email=email)
    kw.update(language=language)
    kw.update(modified=modified)
    kw.update(created=created)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(password=password)
    kw.update(last_login=last_login)
    kw.update(username=username)
    kw.update(user_type=user_type)
    kw.update(initials=initials)
    kw.update(first_name=first_name)
    kw.update(last_name=last_name)
    kw.update(remarks=remarks)
    kw.update(newcomer_consultations=newcomer_consultations)
    kw.update(newcomer_appointments=newcomer_appointments)
    kw.update(notify_myself=notify_myself)
    kw.update(mail_mode=mail_mode)
    kw.update(access_class=access_class)
    kw.update(event_type_id=event_type_id)
    kw.update(calendar_id=calendar_id)
    kw.update(coaching_type_id=coaching_type_id)
    kw.update(coaching_supervisor=coaching_supervisor)
    kw.update(newcomer_quota=newcomer_quota)
    kw.update(partner_id=partner_id)
    return users_User(**kw)


def create_aids_granting(id, start_date, end_date, user_id, decision_date,
                         board_id, signer_id, state, client_id, aid_type_id,
                         category_id, request_date):
    #    if state: state = settings.SITE.models.aids.ConfirmationStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(user_id=user_id)
    kw.update(decision_date=decision_date)
    kw.update(board_id=board_id)
    kw.update(signer_id=signer_id)
    kw.update(state=state)
    kw.update(client_id=client_id)
    kw.update(aid_type_id=aid_type_id)
    kw.update(category_id=category_id)
    kw.update(request_date=request_date)
    return aids_Granting(**kw)


def create_cal_event(id, modified, created, project_id, start_date, start_time,
                     end_date, end_time, build_time, build_method, user_id,
                     assigned_to_id, owner_type_id, owner_id, summary,
                     description, access_class, sequence, auto_type, priority,
                     event_type_id, transparent, room_id, state):
    #    if build_method: build_method = settings.SITE.models.printing.BuildMethods.get_by_value(build_method)
    owner_type_id = new_content_type_id(owner_type_id)
    #    if access_class: access_class = settings.SITE.models.cal.AccessClasses.get_by_value(access_class)
    #    if priority: priority = settings.SITE.models.xl.Priorities.get_by_value(priority)
    #    if state: state = settings.SITE.models.cal.EntryStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(modified=modified)
    kw.update(created=created)
    kw.update(project_id=project_id)
    kw.update(start_date=start_date)
    kw.update(start_time=start_time)
    kw.update(end_date=end_date)
    kw.update(end_time=end_time)
    kw.update(build_time=build_time)
    kw.update(build_method=build_method)
    kw.update(user_id=user_id)
    kw.update(assigned_to_id=assigned_to_id)
    kw.update(owner_type_id=owner_type_id)
    kw.update(owner_id=owner_id)
    kw.update(summary=summary)
    kw.update(description=description)
    kw.update(access_class=access_class)
    kw.update(sequence=sequence)
    kw.update(auto_type=auto_type)
    kw.update(priority=priority)
    kw.update(event_type_id=event_type_id)
    kw.update(transparent=transparent)
    kw.update(room_id=room_id)
    kw.update(state=state)
    return cal_Event(**kw)


def create_cal_guest(id, event_id, partner_id, role_id, state, remark,
                     waiting_since, busy_since, gone_since):
    #    if state: state = settings.SITE.models.cal.GuestStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(event_id=event_id)
    kw.update(partner_id=partner_id)
    kw.update(role_id=role_id)
    kw.update(state=state)
    kw.update(remark=remark)
    kw.update(waiting_since=waiting_since)
    kw.update(busy_since=busy_since)
    kw.update(gone_since=gone_since)
    return cal_Guest(**kw)


def create_cal_recurrentevent(id, start_date, start_time, end_date, end_time,
                              name, user_id, every_unit, every, monday,
                              tuesday, wednesday, thursday, friday, saturday,
                              sunday, max_events, event_type_id, description):
    #    if every_unit: every_unit = settings.SITE.models.cal.Recurrences.get_by_value(every_unit)
    kw = dict()
    kw.update(id=id)
    kw.update(start_date=start_date)
    kw.update(start_time=start_time)
    kw.update(end_date=end_date)
    kw.update(end_time=end_time)
    if name is not None: kw.update(bv2kw('name', name))
    kw.update(user_id=user_id)
    kw.update(every_unit=every_unit)
    kw.update(every=every)
    kw.update(monday=monday)
    kw.update(tuesday=tuesday)
    kw.update(wednesday=wednesday)
    kw.update(thursday=thursday)
    kw.update(friday=friday)
    kw.update(saturday=saturday)
    kw.update(sunday=sunday)
    kw.update(max_events=max_events)
    kw.update(event_type_id=event_type_id)
    kw.update(description=description)
    return cal_RecurrentEvent(**kw)


def create_cal_subscription(id, user_id, calendar_id, is_hidden):
    kw = dict()
    kw.update(id=id)
    kw.update(user_id=user_id)
    kw.update(calendar_id=calendar_id)
    kw.update(is_hidden=is_hidden)
    return cal_Subscription(**kw)


def create_cal_task(id, modified, created, project_id, start_date, start_time,
                    user_id, owner_type_id, owner_id, summary, description,
                    access_class, sequence, auto_type, priority, due_date,
                    due_time, percent, state, delegated):
    owner_type_id = new_content_type_id(owner_type_id)
    #    if access_class: access_class = settings.SITE.models.cal.AccessClasses.get_by_value(access_class)
    #    if priority: priority = settings.SITE.models.xl.Priorities.get_by_value(priority)
    #    if state: state = settings.SITE.models.cal.TaskStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(modified=modified)
    kw.update(created=created)
    kw.update(project_id=project_id)
    kw.update(start_date=start_date)
    kw.update(start_time=start_time)
    kw.update(user_id=user_id)
    kw.update(owner_type_id=owner_type_id)
    kw.update(owner_id=owner_id)
    kw.update(summary=summary)
    kw.update(description=description)
    kw.update(access_class=access_class)
    kw.update(sequence=sequence)
    kw.update(auto_type=auto_type)
    kw.update(priority=priority)
    kw.update(due_date=due_date)
    kw.update(due_time=due_time)
    kw.update(percent=percent)
    kw.update(state=state)
    kw.update(delegated=delegated)
    return cal_Task(**kw)


def create_changes_change(id, time, type, user_id, object_type_id, object_id,
                          master_type_id, master_id, diff, changed_fields):
    #    if type: type = settings.SITE.models.changes.ChangeTypes.get_by_value(type)
    object_type_id = new_content_type_id(object_type_id)
    master_type_id = new_content_type_id(master_type_id)
    kw = dict()
    kw.update(id=id)
    kw.update(time=time)
    kw.update(type=type)
    kw.update(user_id=user_id)
    kw.update(object_type_id=object_type_id)
    kw.update(object_id=object_id)
    kw.update(master_type_id=master_type_id)
    kw.update(master_id=master_id)
    kw.update(diff=diff)
    kw.update(changed_fields=changed_fields)
    return changes_Change(**kw)


def create_checkdata_problem(id, user_id, owner_type_id, owner_id, checker,
                             message):
    owner_type_id = new_content_type_id(owner_type_id)
    #    if checker: checker = settings.SITE.models.checkdata.Checkers.get_by_value(checker)
    kw = dict()
    kw.update(id=id)
    kw.update(user_id=user_id)
    kw.update(owner_type_id=owner_type_id)
    kw.update(owner_id=owner_id)
    kw.update(checker=checker)
    kw.update(message=message)
    return checkdata_Problem(**kw)


def create_coachings_coaching(id, start_date, end_date, user_id, client_id,
                              type_id, primary, ending_id):
    kw = dict()
    kw.update(id=id)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(user_id=user_id)
    kw.update(client_id=client_id)
    kw.update(type_id=type_id)
    kw.update(primary=primary)
    kw.update(ending_id=ending_id)
    return coachings_Coaching(**kw)


def create_dashboard_widget(id, seqno, user_id, item_name, visible):
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    kw.update(user_id=user_id)
    kw.update(item_name=item_name)
    kw.update(visible=visible)
    return dashboard_Widget(**kw)


def create_excerpts_excerpt(id, project_id, build_time, build_method, user_id,
                            owner_type_id, owner_id, company_id,
                            contact_person_id, contact_role_id,
                            excerpt_type_id, language):
    #    if build_method: build_method = settings.SITE.models.printing.BuildMethods.get_by_value(build_method)
    owner_type_id = new_content_type_id(owner_type_id)
    kw = dict()
    kw.update(id=id)
    kw.update(project_id=project_id)
    kw.update(build_time=build_time)
    kw.update(build_method=build_method)
    kw.update(user_id=user_id)
    kw.update(owner_type_id=owner_type_id)
    kw.update(owner_id=owner_id)
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    kw.update(excerpt_type_id=excerpt_type_id)
    kw.update(language=language)
    return excerpts_Excerpt(**kw)


def create_aids_incomeconfirmation(id, created, start_date, end_date, user_id,
                                   company_id, contact_person_id,
                                   contact_role_id, printed_by_id, signer_id,
                                   state, client_id, granting_id, remark,
                                   language, category_id, amount):
    #    if state: state = settings.SITE.models.aids.ConfirmationStates.get_by_value(state)
    if amount is not None: amount = Decimal(amount)
    kw = dict()
    kw.update(id=id)
    kw.update(created=created)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(user_id=user_id)
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    kw.update(printed_by_id=printed_by_id)
    kw.update(signer_id=signer_id)
    kw.update(state=state)
    kw.update(client_id=client_id)
    kw.update(granting_id=granting_id)
    kw.update(remark=remark)
    kw.update(language=language)
    kw.update(category_id=category_id)
    kw.update(amount=amount)
    return aids_IncomeConfirmation(**kw)


def create_aids_refundconfirmation(id, created, start_date, end_date, user_id,
                                   company_id, contact_person_id,
                                   contact_role_id, printed_by_id, signer_id,
                                   state, client_id, granting_id, remark,
                                   language, doctor_type_id, doctor_id,
                                   pharmacy_id):
    #    if state: state = settings.SITE.models.aids.ConfirmationStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(created=created)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(user_id=user_id)
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    kw.update(printed_by_id=printed_by_id)
    kw.update(signer_id=signer_id)
    kw.update(state=state)
    kw.update(client_id=client_id)
    kw.update(granting_id=granting_id)
    kw.update(remark=remark)
    kw.update(language=language)
    kw.update(doctor_type_id=doctor_type_id)
    kw.update(doctor_id=doctor_id)
    kw.update(pharmacy_id=pharmacy_id)
    return aids_RefundConfirmation(**kw)


def create_aids_simpleconfirmation(id, created, start_date, end_date, user_id,
                                   company_id, contact_person_id,
                                   contact_role_id, printed_by_id, signer_id,
                                   state, client_id, granting_id, remark,
                                   language):
    #    if state: state = settings.SITE.models.aids.ConfirmationStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(created=created)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(user_id=user_id)
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    kw.update(printed_by_id=printed_by_id)
    kw.update(signer_id=signer_id)
    kw.update(state=state)
    kw.update(client_id=client_id)
    kw.update(granting_id=granting_id)
    kw.update(remark=remark)
    kw.update(language=language)
    return aids_SimpleConfirmation(**kw)


def create_art61_contract(
        id, signer1_id, signer2_id, user_id, company_id, contact_person_id,
        contact_role_id, printed_by_id, client_id, language, applies_from,
        applies_until, date_decided, date_issued, user_asd_id, exam_policy_id,
        ending_id, date_ended, duration, reference_person, responsibilities,
        remark, type_id, job_title, status_id, cv_duration_id, regime_id,
        subsidize_10, subsidize_20, subsidize_30, subsidize_40, subsidize_50):
    kw = dict()
    kw.update(id=id)
    kw.update(signer1_id=signer1_id)
    kw.update(signer2_id=signer2_id)
    kw.update(user_id=user_id)
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    kw.update(printed_by_id=printed_by_id)
    kw.update(client_id=client_id)
    kw.update(language=language)
    kw.update(applies_from=applies_from)
    kw.update(applies_until=applies_until)
    kw.update(date_decided=date_decided)
    kw.update(date_issued=date_issued)
    kw.update(user_asd_id=user_asd_id)
    kw.update(exam_policy_id=exam_policy_id)
    kw.update(ending_id=ending_id)
    kw.update(date_ended=date_ended)
    kw.update(duration=duration)
    kw.update(reference_person=reference_person)
    kw.update(responsibilities=responsibilities)
    kw.update(remark=remark)
    kw.update(type_id=type_id)
    kw.update(job_title=job_title)
    kw.update(status_id=status_id)
    kw.update(cv_duration_id=cv_duration_id)
    kw.update(regime_id=regime_id)
    kw.update(subsidize_10=subsidize_10)
    kw.update(subsidize_20=subsidize_20)
    kw.update(subsidize_30=subsidize_30)
    kw.update(subsidize_40=subsidize_40)
    kw.update(subsidize_50=subsidize_50)
    return art61_Contract(**kw)


def create_cbss_identifypersonrequest(
        id, user_id, printed_by_id, person_id, sent, status, environment,
        ticket, request_xml, response_xml, debug_messages, info_messages,
        national_id, birth_date, sis_card_no, id_card_no, first_name,
        last_name, middle_name, gender, tolerance):
    #    if status: status = settings.SITE.models.cbss.RequestStates.get_by_value(status)
    #    if gender: gender = settings.SITE.models.system.Genders.get_by_value(gender)
    kw = dict()
    kw.update(id=id)
    kw.update(user_id=user_id)
    kw.update(printed_by_id=printed_by_id)
    kw.update(person_id=person_id)
    kw.update(sent=sent)
    kw.update(status=status)
    kw.update(environment=environment)
    kw.update(ticket=ticket)
    kw.update(request_xml=request_xml)
    kw.update(response_xml=response_xml)
    kw.update(debug_messages=debug_messages)
    kw.update(info_messages=info_messages)
    kw.update(national_id=national_id)
    kw.update(birth_date=birth_date)
    kw.update(sis_card_no=sis_card_no)
    kw.update(id_card_no=id_card_no)
    kw.update(first_name=first_name)
    kw.update(last_name=last_name)
    kw.update(middle_name=middle_name)
    kw.update(gender=gender)
    kw.update(tolerance=tolerance)
    return cbss_IdentifyPersonRequest(**kw)


def create_cbss_manageaccessrequest(
        id, user_id, printed_by_id, person_id, sent, status, environment,
        ticket, request_xml, response_xml, debug_messages, info_messages,
        national_id, birth_date, sis_card_no, id_card_no, first_name,
        last_name, sector_id, purpose_id, start_date, end_date, action,
        query_register):
    #    if status: status = settings.SITE.models.cbss.RequestStates.get_by_value(status)
    #    if action: action = settings.SITE.models.cbss.ManageActions.get_by_value(action)
    #    if query_register: query_register = settings.SITE.models.cbss.QueryRegisters.get_by_value(query_register)
    kw = dict()
    kw.update(id=id)
    kw.update(user_id=user_id)
    kw.update(printed_by_id=printed_by_id)
    kw.update(person_id=person_id)
    kw.update(sent=sent)
    kw.update(status=status)
    kw.update(environment=environment)
    kw.update(ticket=ticket)
    kw.update(request_xml=request_xml)
    kw.update(response_xml=response_xml)
    kw.update(debug_messages=debug_messages)
    kw.update(info_messages=info_messages)
    kw.update(national_id=national_id)
    kw.update(birth_date=birth_date)
    kw.update(sis_card_no=sis_card_no)
    kw.update(id_card_no=id_card_no)
    kw.update(first_name=first_name)
    kw.update(last_name=last_name)
    kw.update(sector_id=sector_id)
    kw.update(purpose_id=purpose_id)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(action=action)
    kw.update(query_register=query_register)
    return cbss_ManageAccessRequest(**kw)


def create_cbss_retrievetigroupsrequest(id, user_id, printed_by_id, person_id,
                                        sent, status, environment, ticket,
                                        request_xml, response_xml,
                                        debug_messages, info_messages,
                                        national_id, language, history):
    #    if status: status = settings.SITE.models.cbss.RequestStates.get_by_value(status)
    #    if language: language = settings.SITE.models.cbss.RequestLanguages.get_by_value(language)
    kw = dict()
    kw.update(id=id)
    kw.update(user_id=user_id)
    kw.update(printed_by_id=printed_by_id)
    kw.update(person_id=person_id)
    kw.update(sent=sent)
    kw.update(status=status)
    kw.update(environment=environment)
    kw.update(ticket=ticket)
    kw.update(request_xml=request_xml)
    kw.update(response_xml=response_xml)
    kw.update(debug_messages=debug_messages)
    kw.update(info_messages=info_messages)
    kw.update(national_id=national_id)
    kw.update(language=language)
    kw.update(history=history)
    return cbss_RetrieveTIGroupsRequest(**kw)


def create_debts_budget(id, user_id, printed_by_id, date, partner_id,
                        print_todos, print_empty_rows, include_yearly_incomes,
                        intro, conclusion, dist_amount):
    if dist_amount is not None: dist_amount = Decimal(dist_amount)
    kw = dict()
    kw.update(id=id)
    kw.update(user_id=user_id)
    kw.update(printed_by_id=printed_by_id)
    kw.update(date=date)
    kw.update(partner_id=partner_id)
    kw.update(print_todos=print_todos)
    kw.update(print_empty_rows=print_empty_rows)
    kw.update(include_yearly_incomes=include_yearly_incomes)
    kw.update(intro=intro)
    kw.update(conclusion=conclusion)
    kw.update(dist_amount=dist_amount)
    return debts_Budget(**kw)


def create_debts_actor(id, seqno, budget_id, partner_id, header, remark):
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    kw.update(budget_id=budget_id)
    kw.update(partner_id=partner_id)
    kw.update(header=header)
    kw.update(remark=remark)
    return debts_Actor(**kw)


def create_debts_entry(id, seqno, budget_id, account_type, account_id,
                       partner_id, amount, actor_id, circa, distribute, todo,
                       remark, description, periods, monthly_rate, bailiff_id):
    #    if account_type: account_type = settings.SITE.models.debts.AccountTypes.get_by_value(account_type)
    if amount is not None: amount = Decimal(amount)
    if periods is not None: periods = Decimal(periods)
    if monthly_rate is not None: monthly_rate = Decimal(monthly_rate)
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    kw.update(budget_id=budget_id)
    kw.update(account_type=account_type)
    kw.update(account_id=account_id)
    kw.update(partner_id=partner_id)
    kw.update(amount=amount)
    kw.update(actor_id=actor_id)
    kw.update(circa=circa)
    kw.update(distribute=distribute)
    kw.update(todo=todo)
    kw.update(remark=remark)
    kw.update(description=description)
    kw.update(periods=periods)
    kw.update(monthly_rate=monthly_rate)
    kw.update(bailiff_id=bailiff_id)
    return debts_Entry(**kw)


def create_esf_clientsummary(id, printed_by_id, year, month, esf10, esf20,
                             esf21, esf30, esf40, esf41, esf42, esf43, esf44,
                             esf50, esf60, esf70, master_id,
                             education_level_id, children_at_charge,
                             certified_handicap, other_difficulty, result,
                             remark):
    #    if result: result = settings.SITE.models.esf.ParticipationCertificates.get_by_value(result)
    kw = dict()
    kw.update(id=id)
    kw.update(printed_by_id=printed_by_id)
    kw.update(year=year)
    kw.update(month=month)
    kw.update(esf10=esf10)
    kw.update(esf20=esf20)
    kw.update(esf21=esf21)
    kw.update(esf30=esf30)
    kw.update(esf40=esf40)
    kw.update(esf41=esf41)
    kw.update(esf42=esf42)
    kw.update(esf43=esf43)
    kw.update(esf44=esf44)
    kw.update(esf50=esf50)
    kw.update(esf60=esf60)
    kw.update(esf70=esf70)
    kw.update(master_id=master_id)
    kw.update(education_level_id=education_level_id)
    kw.update(children_at_charge=children_at_charge)
    kw.update(certified_handicap=certified_handicap)
    kw.update(other_difficulty=other_difficulty)
    kw.update(result=result)
    kw.update(remark=remark)
    return esf_ClientSummary(**kw)


def create_isip_contract(id, signer1_id, signer2_id, user_id, printed_by_id,
                         client_id, language, applies_from, applies_until,
                         date_decided, date_issued, user_asd_id,
                         exam_policy_id, ending_id, date_ended, type_id,
                         study_type_id, stages, goals, duties_asd, duties_dsbe,
                         duties_pcsw, duties_person, user_dsbe_id):
    kw = dict()
    kw.update(id=id)
    kw.update(signer1_id=signer1_id)
    kw.update(signer2_id=signer2_id)
    kw.update(user_id=user_id)
    kw.update(printed_by_id=printed_by_id)
    kw.update(client_id=client_id)
    kw.update(language=language)
    kw.update(applies_from=applies_from)
    kw.update(applies_until=applies_until)
    kw.update(date_decided=date_decided)
    kw.update(date_issued=date_issued)
    kw.update(user_asd_id=user_asd_id)
    kw.update(exam_policy_id=exam_policy_id)
    kw.update(ending_id=ending_id)
    kw.update(date_ended=date_ended)
    kw.update(type_id=type_id)
    kw.update(study_type_id=study_type_id)
    kw.update(stages=stages)
    kw.update(goals=goals)
    kw.update(duties_asd=duties_asd)
    kw.update(duties_dsbe=duties_dsbe)
    kw.update(duties_pcsw=duties_pcsw)
    kw.update(duties_person=duties_person)
    kw.update(user_dsbe_id=user_dsbe_id)
    return isip_Contract(**kw)


def create_isip_contractpartner(id, company_id, contact_person_id,
                                contact_role_id, contract_id, duties_company):
    kw = dict()
    kw.update(id=id)
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    kw.update(contract_id=contract_id)
    kw.update(duties_company=duties_company)
    return isip_ContractPartner(**kw)


def create_jobs_contract(id, signer1_id, signer2_id, user_id, company_id,
                         contact_person_id, contact_role_id, printed_by_id,
                         client_id, language, applies_from, applies_until,
                         date_decided, date_issued, user_asd_id,
                         exam_policy_id, ending_id, date_ended, duration,
                         reference_person, responsibilities, remark, type_id,
                         job_id, regime_id, schedule_id, hourly_rate,
                         refund_rate):
    if hourly_rate is not None: hourly_rate = Decimal(hourly_rate)
    kw = dict()
    kw.update(id=id)
    kw.update(signer1_id=signer1_id)
    kw.update(signer2_id=signer2_id)
    kw.update(user_id=user_id)
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    kw.update(printed_by_id=printed_by_id)
    kw.update(client_id=client_id)
    kw.update(language=language)
    kw.update(applies_from=applies_from)
    kw.update(applies_until=applies_until)
    kw.update(date_decided=date_decided)
    kw.update(date_issued=date_issued)
    kw.update(user_asd_id=user_asd_id)
    kw.update(exam_policy_id=exam_policy_id)
    kw.update(ending_id=ending_id)
    kw.update(date_ended=date_ended)
    kw.update(duration=duration)
    kw.update(reference_person=reference_person)
    kw.update(responsibilities=responsibilities)
    kw.update(remark=remark)
    kw.update(type_id=type_id)
    kw.update(job_id=job_id)
    kw.update(regime_id=regime_id)
    kw.update(schedule_id=schedule_id)
    kw.update(hourly_rate=hourly_rate)
    kw.update(refund_rate=refund_rate)
    return jobs_Contract(**kw)


def create_ledger_ledgerinfo(user_id, entry_date):
    kw = dict()
    kw.update(user_id=user_id)
    kw.update(entry_date=entry_date)
    return ledger_LedgerInfo(**kw)


def create_ledger_voucher(id, user_id, journal_id, entry_date, voucher_date,
                          accounting_period_id, number, narration, state):
    #    if state: state = settings.SITE.models.accounting.VoucherStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(user_id=user_id)
    kw.update(journal_id=journal_id)
    kw.update(entry_date=entry_date)
    kw.update(voucher_date=voucher_date)
    kw.update(accounting_period_id=accounting_period_id)
    kw.update(number=number)
    kw.update(narration=narration)
    kw.update(state=state)
    return ledger_Voucher(**kw)


def create_finan_bankstatement(voucher_ptr_id, printed_by_id, item_account_id,
                               item_remark, last_item_date, balance1,
                               balance2):
    if balance1 is not None: balance1 = Decimal(balance1)
    if balance2 is not None: balance2 = Decimal(balance2)
    kw = dict()
    kw.update(printed_by_id=printed_by_id)
    kw.update(item_account_id=item_account_id)
    kw.update(item_remark=item_remark)
    kw.update(last_item_date=last_item_date)
    kw.update(balance1=balance1)
    kw.update(balance2=balance2)
    return create_mti_child(ledger_Voucher, voucher_ptr_id,
                            finan_BankStatement, **kw)


def create_finan_bankstatementitem(id, seqno, project_id, match, amount, dc,
                                   remark, account_id, partner_id, date,
                                   voucher_id):
    if amount is not None: amount = Decimal(amount)
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    kw.update(project_id=project_id)
    kw.update(match=match)
    kw.update(amount=amount)
    kw.update(dc=dc)
    kw.update(remark=remark)
    kw.update(account_id=account_id)
    kw.update(partner_id=partner_id)
    kw.update(date=date)
    kw.update(voucher_id=voucher_id)
    return finan_BankStatementItem(**kw)


def create_finan_journalentry(voucher_ptr_id, printed_by_id, project_id,
                              item_account_id, item_remark, last_item_date):
    kw = dict()
    kw.update(printed_by_id=printed_by_id)
    kw.update(project_id=project_id)
    kw.update(item_account_id=item_account_id)
    kw.update(item_remark=item_remark)
    kw.update(last_item_date=last_item_date)
    return create_mti_child(ledger_Voucher, voucher_ptr_id, finan_JournalEntry,
                            **kw)


def create_finan_journalentryitem(id, seqno, project_id, match, amount, dc,
                                  remark, account_id, partner_id, date,
                                  voucher_id):
    if amount is not None: amount = Decimal(amount)
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    kw.update(project_id=project_id)
    kw.update(match=match)
    kw.update(amount=amount)
    kw.update(dc=dc)
    kw.update(remark=remark)
    kw.update(account_id=account_id)
    kw.update(partner_id=partner_id)
    kw.update(date=date)
    kw.update(voucher_id=voucher_id)
    return finan_JournalEntryItem(**kw)


def create_finan_paymentorder(voucher_ptr_id, printed_by_id, item_account_id,
                              item_remark, total, execution_date):
    if total is not None: total = Decimal(total)
    kw = dict()
    kw.update(printed_by_id=printed_by_id)
    kw.update(item_account_id=item_account_id)
    kw.update(item_remark=item_remark)
    kw.update(total=total)
    kw.update(execution_date=execution_date)
    return create_mti_child(ledger_Voucher, voucher_ptr_id, finan_PaymentOrder,
                            **kw)


def create_finan_paymentorderitem(id, seqno, project_id, match, amount, dc,
                                  remark, account_id, partner_id,
                                  bank_account_id, voucher_id):
    if amount is not None: amount = Decimal(amount)
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    kw.update(project_id=project_id)
    kw.update(match=match)
    kw.update(amount=amount)
    kw.update(dc=dc)
    kw.update(remark=remark)
    kw.update(account_id=account_id)
    kw.update(partner_id=partner_id)
    kw.update(bank_account_id=bank_account_id)
    kw.update(voucher_id=voucher_id)
    return finan_PaymentOrderItem(**kw)


def create_ledger_movement(id, project_id, voucher_id, partner_id, seqno,
                           account_id, amount, dc, match, cleared, value_date):
    if amount is not None: amount = Decimal(amount)
    kw = dict()
    kw.update(id=id)
    kw.update(project_id=project_id)
    kw.update(voucher_id=voucher_id)
    kw.update(partner_id=partner_id)
    kw.update(seqno=seqno)
    kw.update(account_id=account_id)
    kw.update(amount=amount)
    kw.update(dc=dc)
    kw.update(match=match)
    kw.update(cleared=cleared)
    kw.update(value_date=value_date)
    return ledger_Movement(**kw)


def create_newcomers_competence(id, seqno, user_id, faculty_id, weight):
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    kw.update(user_id=user_id)
    kw.update(faculty_id=faculty_id)
    kw.update(weight=weight)
    return newcomers_Competence(**kw)


def create_notes_note(id, project_id, build_time, build_method, user_id,
                      owner_type_id, owner_id, company_id, contact_person_id,
                      contact_role_id, date, time, type_id, event_type_id,
                      subject, body, language, important):
    #    if build_method: build_method = settings.SITE.models.printing.BuildMethods.get_by_value(build_method)
    owner_type_id = new_content_type_id(owner_type_id)
    kw = dict()
    kw.update(id=id)
    kw.update(project_id=project_id)
    kw.update(build_time=build_time)
    kw.update(build_method=build_method)
    kw.update(user_id=user_id)
    kw.update(owner_type_id=owner_type_id)
    kw.update(owner_id=owner_id)
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    kw.update(date=date)
    kw.update(time=time)
    kw.update(type_id=type_id)
    kw.update(event_type_id=event_type_id)
    kw.update(subject=subject)
    kw.update(body=body)
    kw.update(language=language)
    kw.update(important=important)
    return notes_Note(**kw)


def create_notify_message(id, created, user_id, owner_type_id, owner_id,
                          message_type, seen, sent, body, mail_mode, subject):
    owner_type_id = new_content_type_id(owner_type_id)
    #    if message_type: message_type = settings.SITE.models.notify.MessageTypes.get_by_value(message_type)
    #    if mail_mode: mail_mode = settings.SITE.models.notify.MailModes.get_by_value(mail_mode)
    kw = dict()
    kw.update(id=id)
    kw.update(created=created)
    kw.update(user_id=user_id)
    kw.update(owner_type_id=owner_type_id)
    kw.update(owner_id=owner_id)
    kw.update(message_type=message_type)
    kw.update(seen=seen)
    kw.update(sent=sent)
    kw.update(body=body)
    kw.update(mail_mode=mail_mode)
    kw.update(subject=subject)
    return notify_Message(**kw)


def create_outbox_mail(id, project_id, user_id, owner_type_id, owner_id, date,
                       subject, body, sent):
    owner_type_id = new_content_type_id(owner_type_id)
    kw = dict()
    kw.update(id=id)
    kw.update(project_id=project_id)
    kw.update(user_id=user_id)
    kw.update(owner_type_id=owner_type_id)
    kw.update(owner_id=owner_id)
    kw.update(date=date)
    kw.update(subject=subject)
    kw.update(body=body)
    kw.update(sent=sent)
    return outbox_Mail(**kw)


def create_outbox_attachment(id, owner_type_id, owner_id, mail_id):
    owner_type_id = new_content_type_id(owner_type_id)
    kw = dict()
    kw.update(id=id)
    kw.update(owner_type_id=owner_type_id)
    kw.update(owner_id=owner_id)
    kw.update(mail_id=mail_id)
    return outbox_Attachment(**kw)


def create_outbox_recipient(id, mail_id, partner_id, type, address, name):
    #    if type: type = settings.SITE.models.outbox.RecipientTypes.get_by_value(type)
    kw = dict()
    kw.update(id=id)
    kw.update(mail_id=mail_id)
    kw.update(partner_id=partner_id)
    kw.update(type=type)
    kw.update(address=address)
    kw.update(name=name)
    return outbox_Recipient(**kw)


def create_system_siteconfig(
        id, default_build_method, simulate_today, site_company_id, signer1_id,
        signer2_id, signer1_function_id, signer2_function_id, next_partner_id,
        default_event_type_id, site_calendar_id, max_auto_events,
        hide_events_before, client_calendar_id, client_guestrole_id,
        team_guestrole_id, prompt_calendar_id, propgroup_skills_id,
        propgroup_softskills_id, propgroup_obstacles_id, master_budget_id,
        system_note_type_id, job_office_id, residence_permit_upload_type_id,
        work_permit_upload_type_id, driving_licence_upload_type_id, sector_id,
        cbss_org_unit, ssdn_user_id, ssdn_email, cbss_http_username,
        cbss_http_password):
    #    if default_build_method: default_build_method = settings.SITE.models.printing.BuildMethods.get_by_value(default_build_method)
    kw = dict()
    kw.update(id=id)
    kw.update(default_build_method=default_build_method)
    kw.update(simulate_today=simulate_today)
    kw.update(site_company_id=site_company_id)
    kw.update(signer1_id=signer1_id)
    kw.update(signer2_id=signer2_id)
    kw.update(signer1_function_id=signer1_function_id)
    kw.update(signer2_function_id=signer2_function_id)
    kw.update(next_partner_id=next_partner_id)
    kw.update(default_event_type_id=default_event_type_id)
    kw.update(site_calendar_id=site_calendar_id)
    kw.update(max_auto_events=max_auto_events)
    kw.update(hide_events_before=hide_events_before)
    kw.update(client_calendar_id=client_calendar_id)
    kw.update(client_guestrole_id=client_guestrole_id)
    kw.update(team_guestrole_id=team_guestrole_id)
    kw.update(prompt_calendar_id=prompt_calendar_id)
    kw.update(propgroup_skills_id=propgroup_skills_id)
    kw.update(propgroup_softskills_id=propgroup_softskills_id)
    kw.update(propgroup_obstacles_id=propgroup_obstacles_id)
    kw.update(master_budget_id=master_budget_id)
    kw.update(system_note_type_id=system_note_type_id)
    kw.update(job_office_id=job_office_id)
    kw.update(residence_permit_upload_type_id=residence_permit_upload_type_id)
    kw.update(work_permit_upload_type_id=work_permit_upload_type_id)
    kw.update(driving_licence_upload_type_id=driving_licence_upload_type_id)
    kw.update(sector_id=sector_id)
    kw.update(cbss_org_unit=cbss_org_unit)
    kw.update(ssdn_user_id=ssdn_user_id)
    kw.update(ssdn_email=ssdn_email)
    kw.update(cbss_http_username=cbss_http_username)
    kw.update(cbss_http_password=cbss_http_password)
    return system_SiteConfig(**kw)


def create_tinymce_textfieldtemplate(id, user_id, name, description, text):
    kw = dict()
    kw.update(id=id)
    kw.update(user_id=user_id)
    kw.update(name=name)
    kw.update(description=description)
    kw.update(text=text)
    return tinymce_TextFieldTemplate(**kw)


def create_uploads_upload(id, project_id, start_date, end_date, file, mimetype,
                          user_id, owner_type_id, owner_id, company_id,
                          contact_person_id, contact_role_id, upload_area,
                          type_id, description, remark, needed):
    owner_type_id = new_content_type_id(owner_type_id)
    #    if upload_area: upload_area = settings.SITE.models.uploads.UploadAreas.get_by_value(upload_area)
    kw = dict()
    kw.update(id=id)
    kw.update(project_id=project_id)
    kw.update(start_date=start_date)
    kw.update(end_date=end_date)
    kw.update(file=file)
    kw.update(mimetype=mimetype)
    kw.update(user_id=user_id)
    kw.update(owner_type_id=owner_type_id)
    kw.update(owner_id=owner_id)
    kw.update(company_id=company_id)
    kw.update(contact_person_id=contact_person_id)
    kw.update(contact_role_id=contact_role_id)
    kw.update(upload_area=upload_area)
    kw.update(type_id=type_id)
    kw.update(description=description)
    kw.update(remark=remark)
    kw.update(needed=needed)
    return uploads_Upload(**kw)


def create_users_authority(id, user_id, authorized_id):
    kw = dict()
    kw.update(id=id)
    kw.update(user_id=user_id)
    kw.update(authorized_id=authorized_id)
    return users_Authority(**kw)


def create_vatless_accountinvoice(voucher_ptr_id, project_id, partner_id,
                                  payment_term_id, match, bank_account_id,
                                  your_ref, due_date, amount):
    if amount is not None: amount = Decimal(amount)
    kw = dict()
    kw.update(project_id=project_id)
    kw.update(partner_id=partner_id)
    kw.update(payment_term_id=payment_term_id)
    kw.update(match=match)
    kw.update(bank_account_id=bank_account_id)
    kw.update(your_ref=your_ref)
    kw.update(due_date=due_date)
    kw.update(amount=amount)
    return create_mti_child(ledger_Voucher, voucher_ptr_id,
                            vatless_AccountInvoice, **kw)


def create_vatless_invoiceitem(id, seqno, project_id, account_id, voucher_id,
                               title, amount):
    if amount is not None: amount = Decimal(amount)
    kw = dict()
    kw.update(id=id)
    kw.update(seqno=seqno)
    kw.update(project_id=project_id)
    kw.update(account_id=account_id)
    kw.update(voucher_id=voucher_id)
    kw.update(title=title)
    kw.update(amount=amount)
    return vatless_InvoiceItem(**kw)


def create_xcourses_coursecontent(id, name):
    kw = dict()
    kw.update(id=id)
    kw.update(name=name)
    return xcourses_CourseContent(**kw)


def create_xcourses_courseprovider(company_ptr_id):
    kw = dict()
    return create_mti_child(contacts_Company, company_ptr_id,
                            xcourses_CourseProvider, **kw)


def create_xcourses_courseoffer(id, title, guest_role_id, content_id,
                                provider_id, description):
    kw = dict()
    kw.update(id=id)
    kw.update(title=title)
    kw.update(guest_role_id=guest_role_id)
    kw.update(content_id=content_id)
    kw.update(provider_id=provider_id)
    kw.update(description=description)
    return xcourses_CourseOffer(**kw)


def create_xcourses_course(id, offer_id, title, start_date, remark):
    kw = dict()
    kw.update(id=id)
    kw.update(offer_id=offer_id)
    kw.update(title=title)
    kw.update(start_date=start_date)
    kw.update(remark=remark)
    return xcourses_Course(**kw)


def create_xcourses_courserequest(id, person_id, offer_id, content_id,
                                  date_submitted, urgent, state, course_id,
                                  remark, date_ended):
    #    if state: state = settings.SITE.models.xcourses.CourseRequestStates.get_by_value(state)
    kw = dict()
    kw.update(id=id)
    kw.update(person_id=person_id)
    kw.update(offer_id=offer_id)
    kw.update(content_id=content_id)
    kw.update(date_submitted=date_submitted)
    kw.update(urgent=urgent)
    kw.update(state=state)
    kw.update(course_id=course_id)
    kw.update(remark=remark)
    kw.update(date_ended=date_ended)
    return xcourses_CourseRequest(**kw)


def main(args):
    loader = DpyLoader(globals(), quick=args.quick)
    from django.core.management import call_command
    call_command('initdb', interactive=args.interactive)
    os.chdir(os.path.dirname(__file__))
    loader.initialize()
    args = (globals(), locals())

    execfile("aids_category.py", *args)
    execfile("b2c_account.py", *args)
    execfile("b2c_statement.py", *args)
    execfile("b2c_transaction.py", *args)
    execfile("boards_board.py", *args)
    execfile("cal_calendar.py", *args)
    execfile("cal_dailyplannerrow.py", *args)
    execfile("cal_eventtype.py", *args)
    execfile("cal_eventpolicy.py", *args)
    execfile("cal_guestrole.py", *args)
    execfile("cal_remotecalendar.py", *args)
    execfile("cbss_purpose.py", *args)
    execfile("cbss_sector.py", *args)
    execfile("clients_clientcontacttype.py", *args)
    execfile("coachings_coachingtype.py", *args)
    execfile("coachings_coachingending.py", *args)
    execfile("contacts_companytype.py", *args)
    execfile("contacts_roletype.py", *args)
    execfile("countries_country.py", *args)
    execfile("countries_place.py", *args)
    execfile("cv_duration.py", *args)
    execfile("cv_educationlevel.py", *args)
    execfile("cv_regime.py", *args)
    execfile("cv_sector.py", *args)
    execfile("cv_function.py", *args)
    execfile("cv_status.py", *args)
    execfile("cv_studytype.py", *args)
    execfile("debts_group.py", *args)
    execfile("debts_account.py", *args)
    execfile("excerpts_excerpttype.py", *args)
    execfile("gfks_helptext.py", *args)
    execfile("households_type.py", *args)
    execfile("isip_contractending.py", *args)
    execfile("isip_exampolicy.py", *args)
    execfile("art61_contracttype.py", *args)
    execfile("isip_contracttype.py", *args)
    execfile("jobs_contracttype.py", *args)
    execfile("jobs_jobtype.py", *args)
    execfile("jobs_schedule.py", *args)
    execfile("languages_language.py", *args)
    execfile("ledger_account.py", *args)
    execfile("ledger_fiscalyear.py", *args)
    execfile("ledger_accountingperiod.py", *args)
    execfile("ledger_paymentterm.py", *args)
    execfile("newcomers_broker.py", *args)
    execfile("newcomers_faculty.py", *args)
    execfile("notes_eventtype.py", *args)
    execfile("notes_notetype.py", *args)
    execfile("pcsw_activity.py", *args)
    execfile("contacts_partner.py", *args)
    execfile("addresses_address.py", *args)
    execfile("contacts_company.py", *args)
    execfile("contacts_person.py", *args)
    execfile("aids_aidtype.py", *args)
    execfile("boards_member.py", *args)
    execfile("cal_room.py", *args)
    execfile("contacts_role.py", *args)
    execfile("households_household.py", *args)
    execfile("households_member.py", *args)
    execfile("humanlinks_link.py", *args)
    execfile("jobs_jobprovider.py", *args)
    execfile("jobs_job.py", *args)
    execfile("jobs_offer.py", *args)
    execfile("pcsw_aidtype.py", *args)
    execfile("pcsw_dispensereason.py", *args)
    execfile("pcsw_exclusiontype.py", *args)
    execfile("pcsw_persongroup.py", *args)
    execfile("pcsw_client.py", *args)
    execfile("clients_clientcontact.py", *args)
    execfile("cv_experience.py", *args)
    execfile("cv_languageknowledge.py", *args)
    execfile("cv_study.py", *args)
    execfile("cv_training.py", *args)
    execfile("dupable_clients_word.py", *args)
    execfile("jobs_candidature.py", *args)
    execfile("pcsw_conviction.py", *args)
    execfile("pcsw_dispense.py", *args)
    execfile("pcsw_exclusion.py", *args)
    execfile("properties_propgroup.py", *args)
    execfile("properties_proptype.py", *args)
    execfile("properties_propchoice.py", *args)
    execfile("properties_property.py", *args)
    execfile("properties_personproperty.py", *args)
    execfile("sepa_account.py", *args)
    execfile("ledger_journal.py", *args)
    execfile("ledger_matchrule.py", *args)
    execfile("uploads_uploadtype.py", *args)
    execfile("users_user.py", *args)
    execfile("aids_granting.py", *args)
    execfile("cal_event.py", *args)
    execfile("cal_guest.py", *args)
    execfile("cal_recurrentevent.py", *args)
    execfile("cal_subscription.py", *args)
    execfile("cal_task.py", *args)
    execfile("changes_change.py", *args)
    execfile("checkdata_problem.py", *args)
    execfile("coachings_coaching.py", *args)
    execfile("dashboard_widget.py", *args)
    execfile("excerpts_excerpt.py", *args)
    execfile("aids_incomeconfirmation.py", *args)
    execfile("aids_refundconfirmation.py", *args)
    execfile("aids_simpleconfirmation.py", *args)
    execfile("art61_contract.py", *args)
    execfile("cbss_identifypersonrequest.py", *args)
    execfile("cbss_manageaccessrequest.py", *args)
    execfile("cbss_retrievetigroupsrequest.py", *args)
    execfile("debts_budget.py", *args)
    execfile("debts_actor.py", *args)
    execfile("debts_entry.py", *args)
    execfile("esf_clientsummary.py", *args)
    execfile("isip_contract.py", *args)
    execfile("isip_contractpartner.py", *args)
    execfile("jobs_contract.py", *args)
    execfile("ledger_ledgerinfo.py", *args)
    execfile("ledger_voucher.py", *args)
    execfile("finan_bankstatement.py", *args)
    execfile("finan_bankstatementitem.py", *args)
    execfile("finan_journalentry.py", *args)
    execfile("finan_journalentryitem.py", *args)
    execfile("finan_paymentorder.py", *args)
    execfile("finan_paymentorderitem.py", *args)
    execfile("ledger_movement.py", *args)
    execfile("newcomers_competence.py", *args)
    execfile("notes_note.py", *args)
    execfile("notify_message.py", *args)
    execfile("outbox_mail.py", *args)
    execfile("outbox_attachment.py", *args)
    execfile("outbox_recipient.py", *args)
    execfile("system_siteconfig.py", *args)
    execfile("tinymce_textfieldtemplate.py", *args)
    execfile("uploads_upload.py", *args)
    execfile("users_authority.py", *args)
    execfile("vatless_accountinvoice.py", *args)
    execfile("vatless_invoiceitem.py", *args)
    execfile("xcourses_coursecontent.py", *args)
    execfile("xcourses_courseprovider.py", *args)
    execfile("xcourses_courseoffer.py", *args)
    execfile("xcourses_course.py", *args)
    execfile("xcourses_courserequest.py", *args)
    loader.finalize()
    logger.info("Loaded %d objects", loader.count_objects)
    call_command('resetsequences')


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Restore the data.')
    parser.add_argument(
        '--noinput',
        dest='interactive',
        action='store_false',
        default=True,
        help="Don't ask for confirmation before flushing the database.")
    parser.add_argument('--quick',
                        dest='quick',
                        action='store_true',
                        default=False,
                        help='Do not call full_clean() on restored instances.')

    args = parser.parse_args()
    main(args)

# -*- coding: UTF-8 -*-
logger.info("Loading 189 objects to table esf_clientsummary...")
# fields: id, printed_by, year, month, esf10, esf20, esf21, esf30, esf40, esf41, esf42, esf43, esf44, esf50, esf60, esf70, master, education_level, children_at_charge, certified_handicap, other_difficulty, result, remark
loader.save(
    create_esf_clientsummary(1, None, 2012, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 116, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(2, None, 2013, None, '0:00', '11:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 116, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(3, None, 2014, None, '2:00', '11:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 116, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(4, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 117, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(5, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 117, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(6, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 117, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(7, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '478:48', 118, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(8, None, 2013, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 118, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(9, None, 2014, None, '0:00', '0:00', '1:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 118, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(10, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 120, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(11, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 120, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(12, None, 2014, None, '0:00', '0:00', '0:00',
                             '1:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 120, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(13, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 121, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(14, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 121, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(15, None, 2014, None, '2:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 121, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(16, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 122, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(17, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 122, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(18, None, 2014, None, '0:00', '1:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 122, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(19, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 123, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(20, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 123, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(21, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 123, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(22, None, 2012, None, '0:00', '2:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 124, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(23, None, 2013, None, '0:00', '8:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 124, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(24, None, 2014, None, '0:00', '0:00', '0:00',
                             '1:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 124, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(25, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 125, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(26, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 125, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(27, None, 2014, None, '2:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 125, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(28, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '425:36', 126, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(29, None, 2013, None, '0:00', '4:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 126, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(30, None, 2014, None, '0:00', '2:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 126, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(31, None, 2012, None, '0:00', '2:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 127, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(32, None, 2013, None, '0:00', '12:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 127, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(33, None, 2014, None, '0:00', '11:00', '1:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 127, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(34, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 128, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(35, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 128, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(36, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 128, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(37, None, 2012, None, '0:00', '2:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 129, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(38, None, 2013, None, '0:00', '11:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 129, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(39, None, 2014, None, '2:00', '11:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 129, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(40, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '311:36', 130, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(41, None, 2013, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '319:12', 130, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(42, None, 2014, None, '0:00', '4:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 130, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(43, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 131, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(44, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 131, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(45, None, 2014, None, '0:00', '0:00', '1:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 131, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(46, None, 2012, None, '0:00', '1:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 132, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(47, None, 2013, None, '0:00', '12:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 132, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(48, None, 2014, None, '0:00', '2:00', '0:00',
                             '1:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 132, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(49, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '266:00', 133, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(50, None, 2013, None, '0:00', '4:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 133, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(51, None, 2014, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 133, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(52, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 134, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(53, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 134, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(54, None, 2014, None, '0:00', '1:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 134, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(55, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 135, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(56, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 135, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(57, None, 2014, None, '0:00', '0:00', '1:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 135, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(58, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 136, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(59, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 136, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(60, None, 2014, None, '0:00', '0:00', '0:00',
                             '1:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 136, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(61, None, 2012, None, '0:00', '1:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 137, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(62, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 137, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(63, None, 2014, None, '2:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 137, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(64, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 138, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(65, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 138, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(66, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 138, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(67, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 139, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(68, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 139, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(69, None, 2014, None, '0:00', '0:00', '1:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 139, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(70, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 140, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(71, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 140, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(72, None, 2014, None, '0:00', '0:00', '0:00',
                             '1:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 140, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(73, None, 2012, None, '0:00', '1:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 141, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(74, None, 2013, None, '0:00', '9:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 141, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(75, None, 2014, None, '2:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 141, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(76, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '159:36', 142, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(77, None, 2013, None, '0:00', '4:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 142, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(78, None, 2014, None, '0:00', '4:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 142, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(79, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 143, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(80, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 143, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(81, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 143, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(82, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 144, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(83, None, 2013, None, '0:00', '12:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 144, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(84, None, 2014, None, '0:00', '11:00', '0:00',
                             '1:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 144, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(85, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 145, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(86, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 145, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(87, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 145, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(88, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '98:48', 146, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(89, None, 2013, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '98:48', 146, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(90, None, 2014, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 146, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(91, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 147, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(92, None, 2013, None, '0:00', '12:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 147, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(93, None, 2014, None, '0:00', '11:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 147, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(94, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 149, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(95, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 149, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(96, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 149, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(97, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 150, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(98, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 150, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(99, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 150, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(100, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 151, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(101, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 151, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(102, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 151, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(103, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 152, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(104, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 152, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(105, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 152, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(106, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 153, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(107, None, 2013, None, '0:00', '11:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 153, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(108, None, 2014, None, '0:00', '4:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 153, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(109, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 154, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(110, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 154, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(111, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 154, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(112, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 155, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(113, None, 2013, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '1976:00', 155, None, False,
                             False, False, None, u''))
loader.save(
    create_esf_clientsummary(114, None, 2014, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '1976:00', 155, None, False,
                             False, False, None, u''))
loader.save(
    create_esf_clientsummary(115, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 156, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(116, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 156, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(117, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 156, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(118, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 157, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(119, None, 2013, None, '0:00', '10:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 157, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(120, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 157, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(121, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 158, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(122, None, 2013, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '1915:12', 158, None, False,
                             False, False, None, u''))
loader.save(
    create_esf_clientsummary(123, None, 2014, None, '0:00', '4:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 158, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(124, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 159, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(125, None, 2013, None, '0:00', '11:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 159, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(126, None, 2014, None, '0:00', '10:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 159, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(127, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 160, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(128, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 160, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(129, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 160, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(130, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 161, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(131, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 161, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(132, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 161, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(133, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 162, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(134, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 162, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(135, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 162, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(136, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 164, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(137, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 164, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(138, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 164, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(139, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 165, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(140, None, 2013, None, '0:00', '10:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 165, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(141, None, 2014, None, '0:00', '12:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 165, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(142, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 166, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(143, None, 2013, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '1808:48', 166, None, False,
                             False, False, None, u''))
loader.save(
    create_esf_clientsummary(144, None, 2014, None, '0:00', '4:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 166, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(145, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 167, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(146, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 167, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(147, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 167, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(148, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 168, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(149, None, 2013, None, '0:00', '10:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 168, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(150, None, 2014, None, '0:00', '11:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 168, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(151, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 172, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(152, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 172, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(153, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 172, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(154, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 173, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(155, None, 2013, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '1763:12', 173, None, False,
                             False, False, None, u''))
loader.save(
    create_esf_clientsummary(156, None, 2014, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '1763:12', 173, None, False,
                             False, False, None, u''))
loader.save(
    create_esf_clientsummary(157, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 174, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(158, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 174, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(159, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 174, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(160, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 175, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(161, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 175, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(162, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 175, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(163, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 176, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(164, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 176, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(165, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 176, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(166, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 177, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(167, None, 2013, None, '0:00', '10:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 177, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(168, None, 2014, None, '0:00', '11:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 177, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(169, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 178, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(170, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 178, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(171, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 178, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(172, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 179, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(173, None, 2013, None, '0:00', '9:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 179, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(174, None, 2014, None, '0:00', '12:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 179, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(175, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 180, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(176, None, 2013, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '1649:12', 180, None, False,
                             False, False, None, u''))
loader.save(
    create_esf_clientsummary(177, None, 2014, None, '0:00', '3:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '1656:48', 180, None, False,
                             False, False, None, u''))
loader.save(
    create_esf_clientsummary(178, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 181, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(179, None, 2013, None, '0:00', '9:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 181, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(180, None, 2014, None, '0:00', '11:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 181, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(181, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 213, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(182, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 213, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(183, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 213, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(184, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 240, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(185, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 240, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(186, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 240, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(187, None, 2012, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 259, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(188, None, 2013, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 259, None, False, False,
                             False, None, u''))
loader.save(
    create_esf_clientsummary(189, None, 2014, None, '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', '0:00', '0:00', '0:00',
                             '0:00', '0:00', '0:00', 259, None, False, False,
                             False, None, u''))

loader.flush_deferred_objects()

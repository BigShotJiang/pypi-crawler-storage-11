# -*- coding: UTF-8 -*-
logger.info("Loading 90 objects to table coachings_coaching...")
# fields: id, start_date, end_date, user, client, type, primary, ending
loader.save(
    create_coachings_coaching(1, date(2012, 3, 3), None, 6, 116, 1, False,
                              None))
loader.save(
    create_coachings_coaching(2, date(2012, 3, 13), date(2013, 3, 8), 5, 116,
                              2, False, 1))
loader.save(
    create_coachings_coaching(3, date(2013, 3, 8), date(2013, 10, 24), 4, 116,
                              2, False, 2))
loader.save(
    create_coachings_coaching(4, date(2013, 10, 24), None, 9, 116, 2, True,
                              None))
loader.save(
    create_coachings_coaching(5, date(2013, 10, 11), None, 5, 118, 1, True,
                              None))
loader.save(
    create_coachings_coaching(6, date(2013, 10, 14), None, 4, 118, 2, False,
                              None))
loader.save(
    create_coachings_coaching(7, date(2011, 8, 26), date(2013, 1, 7), 5, 123,
                              1, True, 3))
loader.save(
    create_coachings_coaching(8, date(2014, 5, 12), None, 4, 124, 2, True,
                              None))
loader.save(
    create_coachings_coaching(9, None, date(2014, 3, 23), 6, 126, 2, True, 4))
loader.save(
    create_coachings_coaching(10, date(2012, 3, 3), None, 5, 127, 1, True,
                              None))
loader.save(
    create_coachings_coaching(11, date(2013, 3, 8), date(2013, 10, 4), 4, 127,
                              3, False, 1))
loader.save(
    create_coachings_coaching(12, date(2013, 10, 4), None, 9, 127, 2, False,
                              None))
loader.save(
    create_coachings_coaching(13, date(2013, 10, 24), None, 5, 128, 1, True,
                              None))
loader.save(
    create_coachings_coaching(14, date(2013, 12, 13), None, 4, 128, 2, False,
                              None))
loader.save(
    create_coachings_coaching(15, date(2014, 4, 2), None, 5, 128, 3, False,
                              None))
loader.save(
    create_coachings_coaching(16, date(2012, 3, 3), None, 4, 129, 1, False,
                              None))
loader.save(
    create_coachings_coaching(17, date(2012, 3, 13), date(2013, 3, 8), 6, 129,
                              2, False, 2))
loader.save(
    create_coachings_coaching(18, date(2013, 3, 8), date(2013, 10, 24), 5, 129,
                              2, False, 3))
loader.save(
    create_coachings_coaching(19, date(2013, 10, 24), None, 4, 129, 2, True,
                              None))
loader.save(
    create_coachings_coaching(20, date(2013, 10, 11), None, 9, 130, 1, True,
                              None))
loader.save(
    create_coachings_coaching(21, date(2013, 10, 14), None, 5, 130, 2, False,
                              None))
loader.save(
    create_coachings_coaching(22, date(2014, 5, 12), None, 4, 132, 2, True,
                              None))
loader.save(
    create_coachings_coaching(23, date(2012, 3, 3), None, 5, 133, 1, True,
                              None))
loader.save(
    create_coachings_coaching(24, date(2013, 3, 8), date(2013, 10, 4), 4, 133,
                              3, False, 4))
loader.save(
    create_coachings_coaching(25, date(2013, 10, 4), None, 6, 133, 2, False,
                              None))
loader.save(
    create_coachings_coaching(26, date(2013, 10, 24), None, 5, 137, 1, True,
                              None))
loader.save(
    create_coachings_coaching(27, date(2013, 12, 13), None, 4, 137, 2, False,
                              None))
loader.save(
    create_coachings_coaching(28, date(2014, 4, 2), None, 9, 137, 3, False,
                              None))
loader.save(
    create_coachings_coaching(29, date(2011, 12, 4), date(2013, 3, 18), 5, 138,
                              1, False, 1))
loader.save(
    create_coachings_coaching(30, date(2013, 3, 18), date(2013, 11, 3), 4, 138,
                              1, True, 2))
loader.save(
    create_coachings_coaching(31, date(2012, 3, 3), None, 5, 139, 1, False,
                              None))
loader.save(
    create_coachings_coaching(32, date(2012, 3, 13), date(2013, 3, 8), 4, 139,
                              2, False, 3))
loader.save(
    create_coachings_coaching(33, date(2013, 3, 8), date(2013, 10, 24), 6, 139,
                              2, False, 4))
loader.save(
    create_coachings_coaching(34, date(2013, 10, 24), None, 5, 139, 2, True,
                              None))
loader.save(
    create_coachings_coaching(35, date(2013, 10, 11), None, 4, 141, 1, True,
                              None))
loader.save(
    create_coachings_coaching(36, date(2013, 10, 14), None, 9, 141, 2, False,
                              None))
loader.save(
    create_coachings_coaching(37, date(2014, 5, 12), None, 5, 142, 2, True,
                              None))
loader.save(
    create_coachings_coaching(38, date(2012, 3, 3), None, 4, 144, 1, True,
                              None))
loader.save(
    create_coachings_coaching(39, date(2013, 3, 8), date(2013, 10, 4), 5, 144,
                              3, False, 1))
loader.save(
    create_coachings_coaching(40, date(2013, 10, 4), None, 4, 144, 2, False,
                              None))
loader.save(
    create_coachings_coaching(41, date(2011, 8, 26), date(2013, 1, 7), 6, 145,
                              1, True, 2))
loader.save(
    create_coachings_coaching(42, date(2013, 10, 24), None, 5, 146, 1, True,
                              None))
loader.save(
    create_coachings_coaching(43, date(2013, 12, 13), None, 4, 146, 2, False,
                              None))
loader.save(
    create_coachings_coaching(44, date(2014, 4, 2), None, 9, 146, 3, False,
                              None))
loader.save(
    create_coachings_coaching(45, date(2012, 3, 3), None, 5, 147, 1, False,
                              None))
loader.save(
    create_coachings_coaching(46, date(2012, 3, 13), date(2013, 3, 8), 4, 147,
                              2, False, 3))
loader.save(
    create_coachings_coaching(47, date(2013, 3, 8), date(2013, 10, 24), 5, 147,
                              2, False, 4))
loader.save(
    create_coachings_coaching(48, date(2013, 10, 24), None, 4, 147, 2, True,
                              None))
loader.save(
    create_coachings_coaching(49, date(2013, 10, 11), None, 6, 152, 1, True,
                              None))
loader.save(
    create_coachings_coaching(50, date(2013, 10, 14), None, 5, 152, 2, False,
                              None))
loader.save(
    create_coachings_coaching(51, date(2014, 5, 12), None, 4, 153, 2, True,
                              None))
loader.save(
    create_coachings_coaching(52, date(2012, 3, 3), None, 9, 155, 1, True,
                              None))
loader.save(
    create_coachings_coaching(53, date(2013, 3, 8), date(2013, 10, 4), 5, 155,
                              3, False, 1))
loader.save(
    create_coachings_coaching(54, date(2013, 10, 4), None, 4, 155, 2, False,
                              None))
loader.save(
    create_coachings_coaching(55, date(2013, 10, 24), None, 5, 157, 1, True,
                              None))
loader.save(
    create_coachings_coaching(56, date(2013, 12, 13), None, 4, 157, 2, False,
                              None))
loader.save(
    create_coachings_coaching(57, date(2014, 4, 2), None, 6, 157, 3, False,
                              None))
loader.save(
    create_coachings_coaching(58, None, date(2014, 3, 23), 5, 158, 2, True, 2))
loader.save(
    create_coachings_coaching(59, date(2012, 3, 3), None, 4, 159, 1, False,
                              None))
loader.save(
    create_coachings_coaching(60, date(2012, 3, 13), date(2013, 3, 8), 9, 159,
                              2, False, 3))
loader.save(
    create_coachings_coaching(61, date(2013, 3, 8), date(2013, 10, 24), 5, 159,
                              2, False, 4))
loader.save(
    create_coachings_coaching(62, date(2013, 10, 24), None, 4, 159, 2, True,
                              None))
loader.save(
    create_coachings_coaching(63, date(2013, 10, 11), None, 5, 161, 1, True,
                              None))
loader.save(
    create_coachings_coaching(64, date(2013, 10, 14), None, 4, 161, 2, False,
                              None))
loader.save(
    create_coachings_coaching(65, date(2014, 5, 12), None, 6, 165, 2, True,
                              None))
loader.save(
    create_coachings_coaching(66, date(2012, 3, 3), None, 5, 166, 1, True,
                              None))
loader.save(
    create_coachings_coaching(67, date(2013, 3, 8), date(2013, 10, 4), 4, 166,
                              3, False, 1))
loader.save(
    create_coachings_coaching(68, date(2013, 10, 4), None, 9, 166, 2, False,
                              None))
loader.save(
    create_coachings_coaching(69, date(2011, 12, 4), date(2013, 3, 18), 5, 167,
                              1, False, 2))
loader.save(
    create_coachings_coaching(70, date(2013, 3, 18), date(2013, 11, 3), 4, 167,
                              1, True, 3))
loader.save(
    create_coachings_coaching(71, date(2013, 10, 24), None, 5, 168, 1, True,
                              None))
loader.save(
    create_coachings_coaching(72, date(2013, 12, 13), None, 4, 168, 2, False,
                              None))
loader.save(
    create_coachings_coaching(73, date(2014, 4, 2), None, 6, 168, 3, False,
                              None))
loader.save(
    create_coachings_coaching(74, date(2012, 3, 3), None, 5, 173, 1, False,
                              None))
loader.save(
    create_coachings_coaching(75, date(2012, 3, 13), date(2013, 3, 8), 4, 173,
                              2, False, 4))
loader.save(
    create_coachings_coaching(76, date(2013, 3, 8), date(2013, 10, 24), 9, 173,
                              2, False, 1))
loader.save(
    create_coachings_coaching(77, date(2013, 10, 24), None, 5, 173, 2, True,
                              None))
loader.save(
    create_coachings_coaching(78, date(2013, 10, 11), None, 4, 177, 1, True,
                              None))
loader.save(
    create_coachings_coaching(79, date(2013, 10, 14), None, 5, 177, 2, False,
                              None))
loader.save(
    create_coachings_coaching(80, date(2014, 5, 12), None, 4, 178, 2, True,
                              None))
loader.save(
    create_coachings_coaching(81, date(2012, 3, 3), None, 6, 179, 1, True,
                              None))
loader.save(
    create_coachings_coaching(82, date(2013, 3, 8), date(2013, 10, 4), 5, 179,
                              3, False, 2))
loader.save(
    create_coachings_coaching(83, date(2013, 10, 4), None, 4, 179, 2, False,
                              None))
loader.save(
    create_coachings_coaching(84, date(2013, 10, 24), None, 9, 180, 1, True,
                              None))
loader.save(
    create_coachings_coaching(85, date(2013, 12, 13), None, 5, 180, 2, False,
                              None))
loader.save(
    create_coachings_coaching(86, date(2014, 4, 2), None, 4, 180, 3, False,
                              None))
loader.save(
    create_coachings_coaching(87, date(2012, 3, 3), None, 5, 181, 1, False,
                              None))
loader.save(
    create_coachings_coaching(88, date(2012, 3, 13), date(2013, 3, 8), 4, 181,
                              2, False, 3))
loader.save(
    create_coachings_coaching(89, date(2013, 3, 8), date(2013, 10, 24), 6, 181,
                              2, False, 4))
loader.save(
    create_coachings_coaching(90, date(2013, 10, 24), None, 5, 181, 2, True,
                              None))

loader.flush_deferred_objects()

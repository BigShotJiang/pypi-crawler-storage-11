# -*- coding: UTF-8 -*-
logger.info("Loading 109 objects to table contacts_person...")
# fields: partner_ptr, title, first_name, middle_name, last_name, gender, birth_date
loader.save(
    create_contacts_person(258, u'', u'Albert', u'', u'Adam', u'M',
                           u'1973-07-21'))
loader.save(
    create_contacts_person(262, u'', u'Ilja', u'', u'Adam', u'M',
                           u'1994-08-22'))
loader.save(
    create_contacts_person(267, u'', u'No\xe9mie', u'', u'Adam', u'F',
                           u'2002-08-22'))
loader.save(
    create_contacts_person(268, u'', u'Odette', u'', u'Adam', u'F',
                           u'2004-08-22'))
loader.save(
    create_contacts_person(269, u'', u'Pascale', u'', u'Adam', u'F',
                           u'2004-08-22'))
loader.save(
    create_contacts_person(184, u'', u'Alicia', u'', u'Allmanns', None, u''))
loader.save(
    create_contacts_person(115, u'', u'Hans', u'', u'Altenberg', u'M', u''))
loader.save(
    create_contacts_person(113, u'', u'Andreas', u'', u'Arens', u'M', u''))
loader.save(
    create_contacts_person(114, u'', u'Annette', u'', u'Arens', u'F', u''))
loader.save(
    create_contacts_person(116, u'', u'Alfons', u'', u'Ausdemwald', u'M',
                           u'1998-05-26'))
loader.save(
    create_contacts_person(117, u'', u'Laurent', u'', u'Bastiaensen', u'M',
                           u'1997-12-07'))
loader.save(
    create_contacts_person(170, u'Dr.', u'Bernard', u'', u'Bodard', None, u''))
loader.save(
    create_contacts_person(259, u'', u'Bruno', u'', u'Braun', u'M',
                           u'1973-07-22'))
loader.save(
    create_contacts_person(263, u'', u'Jan', u'', u'Braun', u'M',
                           u'1996-08-22'))
loader.save(
    create_contacts_person(264, u'', u'Kevin', u'', u'Braun', u'M',
                           u'1998-08-22'))
loader.save(
    create_contacts_person(265, u'', u'Lars', u'', u'Braun', u'M',
                           u'1998-08-22'))
loader.save(
    create_contacts_person(266, u'', u'Monique', u'', u'Braun', u'F',
                           u'2000-08-22'))
loader.save(
    create_contacts_person(177, u'', u'Bernd', u'', u'Brecht', u'M',
                           u'1997-06-20'))
loader.save(
    create_contacts_person(217, u'Dr.', u'Carmen', u'', u'Castou', None, u''))
loader.save(
    create_contacts_person(120, u'', u'Marc', u'', u'Chantraine', u'M',
                           u'1997-01-01'))
loader.save(
    create_contacts_person(119, u'', u'Ulrike', u'', u'Charlier', u'F', u''))
loader.save(
    create_contacts_person(118, u'', u'Charlotte', u'', u'Collard', u'F',
                           u'1996-07-15'))
loader.save(
    create_contacts_person(122, u'', u'Doroth\xe9e', u'', u'Demeulenaere',
                           u'F', u''))
loader.save(
    create_contacts_person(180, u'', u'Denis', u'', u'Denon', u'M',
                           u'1995-08-10'))
loader.save(
    create_contacts_person(121, u'', u'Daniel', u'', u'Dericum', u'M',
                           u'1995-02-21'))
loader.save(
    create_contacts_person(124, u'', u'Doroth\xe9e', u'', u'Dobbelstein', u'F',
                           u''))
loader.save(
    create_contacts_person(123, u'', u'Doroth\xe9e', u'',
                           u'Dobbelstein-Demeulenaere', u'F', u''))
loader.save(
    create_contacts_person(249, u'', u'Dora', u'', u'Drosson', u'F',
                           u'1971-12-19'))
loader.save(
    create_contacts_person(179, u'', u'Robin', u'', u'Dubois', u'M',
                           u'1993-09-29'))
loader.save(
    create_contacts_person(171, u'', u'Jean', u'', u'Dupont', None, u''))
loader.save(
    create_contacts_person(175, u'', u'Emil', u'', u'Eierschal', u'M',
                           u'1993-04-12'))
loader.save(
    create_contacts_person(244, u'', u'Paula', u'', u'Einzig', u'F',
                           u'1968-12-19'))
loader.save(
    create_contacts_person(128, u'', u'Daniel', u'', u'Emonts', u'M',
                           u'1992-10-24'))
loader.save(
    create_contacts_person(150, u'', u'Erich', u'', u'Emonts', u'M',
                           u'1992-05-07'))
loader.save(
    create_contacts_person(152, u'', u'Erna', u'', u'Emonts-Gast', u'F',
                           u'1991-11-19'))
loader.save(
    create_contacts_person(151, u'', u'Erwin', u'', u'Emontspool', u'M',
                           u'1991-06-02'))
loader.save(
    create_contacts_person(129, u'', u'Edgar', u'', u'Engels', u'M',
                           u'1990-12-14'))
loader.save(
    create_contacts_person(125, u'', u'Berta', u'', u'Ernst', u'F',
                           u'1990-06-27'))
loader.save(
    create_contacts_person(127, u'', u'Eberhart', u'', u'Evers', u'M',
                           u'1990-01-08'))
loader.save(
    create_contacts_person(126, u'', u'Bernd', u'', u'Evertz', u'M',
                           u'1989-07-22'))
loader.save(
    create_contacts_person(260, u'', u'Eveline', u'', u'Evrard', u'F',
                           u'1974-08-21'))
loader.save(
    create_contacts_person(130, u'', u'Luc', u'', u'Faymonville', u'M',
                           u'1989-02-02'))
loader.save(
    create_contacts_person(261, u'', u'Fran\xe7oise', u'', u'Freisen', u'F',
                           u'1974-08-22'))
loader.save(
    create_contacts_person(242, u'', u'Alice', u'', u'Frisch', u'F',
                           u'1969-12-19'))
loader.save(
    create_contacts_person(243, u'', u'Bernd', u'', u'Frisch', u'M',
                           u'1971-09-10'))
loader.save(
    create_contacts_person(248, u'', u'Clara', u'', u'Frisch', u'F',
                           u'1999-06-19'))
loader.save(
    create_contacts_person(250, u'', u'Dennis', u'', u'Frisch', u'M',
                           u'2001-06-19'))
loader.save(
    create_contacts_person(238, u'', u'Hubert', u'', u'Frisch', u'M',
                           u'1933-07-21'))
loader.save(
    create_contacts_person(253, u'', u'Irma', u'', u'Frisch', u'F',
                           u'2008-03-24'))
loader.save(
    create_contacts_person(241, u'', u'Ludwig', u'', u'Frisch', u'M',
                           u'1968-06-01'))
loader.save(
    create_contacts_person(252, u'', u'Melba', u'', u'Frisch', u'F',
                           u'2002-04-05'))
loader.save(
    create_contacts_person(240, u'', u'Paul', u'', u'Frisch', u'M',
                           u'1967-06-19'))
loader.save(
    create_contacts_person(245, u'', u'Peter', u'', u'Frisch', u'M',
                           u'1987-06-19'))
loader.save(
    create_contacts_person(247, u'', u'Philippe', u'', u'Frisch', u'M',
                           u'1997-06-19'))
loader.save(
    create_contacts_person(239, u'', u'Gaby', u'', u'Frogemuth', u'F',
                           u'1934-08-04'))
loader.save(
    create_contacts_person(212, u'', u'Gerd', u'', u'Gerkens', u'M', u''))
loader.save(
    create_contacts_person(131, u'', u'Germaine', u'', u'Gernegro\xdf', u'F',
                           u'1988-08-16'))
loader.save(
    create_contacts_person(132, u'', u'Gregory', u'', u'Groteclaes', u'M',
                           u'1988-02-28'))
loader.save(
    create_contacts_person(134, u'', u'Henri', u'', u'Hilgers', u'M',
                           u'1987-09-11'))
loader.save(
    create_contacts_person(133, u'', u'Hildegard', u'', u'Hilgers', u'F',
                           u'1987-03-25'))
loader.save(
    create_contacts_person(183, u'', u'Hubert', u'', u'Huppertz', u'M', u''))
loader.save(
    create_contacts_person(135, u'', u'Irene', u'', u'Ingels', u'F',
                           u'1986-10-06'))
loader.save(
    create_contacts_person(137, u'', u'Jacqueline', u'', u'Jacobs', u'F',
                           u'1986-04-19'))
loader.save(
    create_contacts_person(136, u'', u'J\xe9r\xe9my', u'', u'Jansen', u'M',
                           u'1985-10-31'))
loader.save(
    create_contacts_person(181, u'', u'J\xe9r\xf4me', u'', u'Jean\xe9mart',
                           u'M', u'1985-05-14'))
loader.save(
    create_contacts_person(138, u'', u'Johann', u'', u'Johnen', u'M',
                           u'1984-11-25'))
loader.save(
    create_contacts_person(139, u'', u'Josef', u'', u'Jonas', u'M',
                           u'1984-06-08'))
loader.save(
    create_contacts_person(140, u'', u'Jan', u'', u'Jousten', u'M',
                           u'1983-12-21'))
loader.save(
    create_contacts_person(186, u'', u'Judith', u'', u'Jousten', u'F', u''))
loader.save(
    create_contacts_person(141, u'', u'Karl', u'', u'Kaivers', u'M',
                           u'1983-07-04'))
loader.save(
    create_contacts_person(213, u'', u'Tatjana', u'', u'Kasennova', u'F',
                           u'1983-01-15'))
loader.save(
    create_contacts_person(178, u'', u'Karl', u'', u'Keller', u'M',
                           u'1982-07-29'))
loader.save(
    create_contacts_person(219, u'Dr.', u'Killian', u'', u'Kimmel', None, u''))
loader.save(
    create_contacts_person(176, u'', u'Lisa', u'', u'Lahm', u'F',
                           u'1982-02-09'))
loader.save(
    create_contacts_person(142, u'', u'Guido', u'', u'Lambertz', u'M',
                           u'1981-08-23'))
loader.save(
    create_contacts_person(143, u'', u'Laura', u'', u'Laschet', u'F',
                           u'1981-03-06'))
loader.save(
    create_contacts_person(144, u'', u'Line', u'', u'Lazarus', u'F',
                           u'1980-09-17'))
loader.save(
    create_contacts_person(145, u'', u'Josefine', u'', u'Leffin', u'F',
                           u'1980-03-31'))
loader.save(
    create_contacts_person(251, u'', u'Laura', u'', u'Loslever', u'F',
                           u'1968-04-27'))
loader.save(
    create_contacts_person(146, u'', u'Marc', u'', u'Malmendier', u'M',
                           u'1979-10-13'))
loader.save(
    create_contacts_person(172, u'', u'Mark', u'', u'Martelaer', u'M',
                           u'1979-04-26'))
loader.save(
    create_contacts_person(147, u'', u'Melissa', u'', u'Meessen', u'F',
                           u'1978-11-07'))
loader.save(
    create_contacts_person(149, u'', u'Marie-Louise', u'', u'Meier', u'F',
                           u'1978-05-21'))
loader.save(
    create_contacts_person(148, u'', u'Michael', u'', u'Mie\xdfen', u'M', u''))
loader.save(
    create_contacts_person(182, u'', u'M\xe9lanie', u'', u'M\xe9lard', u'F',
                           u''))
loader.save(
    create_contacts_person(153, u'', u'Alfons', u'', u'Radermacher', u'M',
                           u'1977-12-02'))
loader.save(
    create_contacts_person(154, u'', u'Berta', u'', u'Radermacher', u'F',
                           u'1977-06-15'))
loader.save(
    create_contacts_person(155, u'', u'Christian', u'', u'Radermacher', u'M',
                           u'1976-12-27'))
loader.save(
    create_contacts_person(156, u'', u'Daniela', u'', u'Radermacher', u'F',
                           u'1976-07-10'))
loader.save(
    create_contacts_person(157, u'', u'Edgard', u'', u'Radermacher', u'M',
                           u'1976-01-22'))
loader.save(
    create_contacts_person(158, u'', u'Fritz', u'', u'Radermacher', u'M',
                           u'1975-08-05'))
loader.save(
    create_contacts_person(159, u'', u'Guido', u'', u'Radermacher', u'M',
                           u'1975-02-16'))
loader.save(
    create_contacts_person(160, u'', u'Hans', u'', u'Radermacher', u'M',
                           u'1974-08-30'))
loader.save(
    create_contacts_person(161, u'', u'Hedi', u'', u'Radermacher', u'F',
                           u'1974-03-13'))
loader.save(
    create_contacts_person(162, u'', u'Inge', u'', u'Radermacher', u'F',
                           u'1973-09-24'))
loader.save(
    create_contacts_person(163, u'', u'Jean', u'', u'Radermacher', u'M', u''))
loader.save(
    create_contacts_person(173, u'', u'Rik', u'', u'Radermecker', u'M',
                           u'1973-04-07'))
loader.save(
    create_contacts_person(185, u'', u'Theresia', u'', u'Thelen', u'F', u''))
loader.save(
    create_contacts_person(174, u'', u'Marie-Louise', u'', u'Vandenmeulenbos',
                           u'F', u'1972-10-19'))
loader.save(
    create_contacts_person(218, u'Dr.', u'Walter', u'', u'Waldmann', None,
                           u''))
loader.save(
    create_contacts_person(215, u'', u'Waltraud', u'', u'Waldmann', None, u''))
loader.save(
    create_contacts_person(216, u'', u'Werner', u'', u'Wehnicht', None, u''))
loader.save(
    create_contacts_person(246, u'', u'Petra', u'', u'Zweith', u'F',
                           u'1968-12-19'))
loader.save(
    create_contacts_person(165, u'', u'David', u'', u'da Vinci', u'M',
                           u'1972-05-02'))
loader.save(
    create_contacts_person(164, u'', u'Didier', u'', u'di Rupo', u'M',
                           u'1971-11-14'))
loader.save(
    create_contacts_person(166, u'', u'Vincent', u'', u'van Veen', u'M',
                           u'1971-05-28'))
loader.save(
    create_contacts_person(169, u'', u'Erna', u'', u'\xc4rgerlich', u'F', u''))
loader.save(
    create_contacts_person(167, u'', u'\xd5ie', u'', u'\xd5unapuu', u'F',
                           u'1970-12-09'))
loader.save(
    create_contacts_person(168, u'', u'Otto', u'', u'\xd6stges', u'M',
                           u'1970-06-22'))

loader.flush_deferred_objects()

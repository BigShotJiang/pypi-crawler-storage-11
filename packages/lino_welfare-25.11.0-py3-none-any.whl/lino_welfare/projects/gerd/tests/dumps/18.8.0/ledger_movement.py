# -*- coding: UTF-8 -*-
logger.info("Loading 602 objects to table ledger_movement...")
# fields: id, project, voucher, partner, seqno, account, amount, dc, match, cleared, value_date
loader.save(
    create_ledger_movement(1, 116, 1, None, 1, 37, '10.00', False, u'', True,
                           date(2014, 5, 22)))
loader.save(
    create_ledger_movement(2, 116, 1, 220, 2, 4, '10.00', True, u'REG 1/2014',
                           False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(3, 124, 2, None, 1, 38, '12.50', False, u'', True,
                           date(2014, 5, 17)))
loader.save(
    create_ledger_movement(4, 127, 2, None, 2, 38, '25.00', False, u'', True,
                           date(2014, 5, 17)))
loader.save(
    create_ledger_movement(5, 128, 2, None, 3, 38, '29.95', False, u'', True,
                           date(2014, 5, 17)))
loader.save(
    create_ledger_movement(6, 116, 2, None, 4, 38, '120.00', False, u'', True,
                           date(2014, 5, 17)))
loader.save(
    create_ledger_movement(7, 118, 2, None, 5, 38, '5.33', False, u'', True,
                           date(2014, 5, 17)))
loader.save(
    create_ledger_movement(8, 124, 2, 221, 6, 4, '12.50', True, u'SREG 1/2014',
                           False, date(2014, 5, 17)))
loader.save(
    create_ledger_movement(9, 127, 2, 221, 7, 4, '25.00', True, u'SREG 1/2014',
                           False, date(2014, 5, 17)))
loader.save(
    create_ledger_movement(10, 128, 2, 221, 8, 4, '29.95', True,
                           u'SREG 1/2014', False, date(2014, 5, 17)))
loader.save(
    create_ledger_movement(11, 116, 2, 221, 9, 4, '120.00', True,
                           u'SREG 1/2014', False, date(2014, 5, 17)))
loader.save(
    create_ledger_movement(12, 118, 2, 221, 10, 4, '5.33', True,
                           u'SREG 1/2014', False, date(2014, 5, 17)))
loader.save(
    create_ledger_movement(13, 127, 3, None, 1, 39, '10.00', False, u'', True,
                           date(2014, 5, 12)))
loader.save(
    create_ledger_movement(14, 127, 3, 222, 2, 4, '10.00', True, u'REG 2/2014',
                           False, date(2014, 5, 12)))
loader.save(
    create_ledger_movement(15, 116, 4, None, 1, 40, '12.50', False, u'', True,
                           date(2014, 5, 7)))
loader.save(
    create_ledger_movement(16, 116, 4, 223, 2, 4, '12.50', True, u'REG 3/2014',
                           False, date(2014, 5, 7)))
loader.save(
    create_ledger_movement(17, 124, 5, None, 1, 41, '37.50', False, u'', True,
                           date(2014, 5, 2)))
loader.save(
    create_ledger_movement(18, 127, 5, None, 2, 41, '54.95', False, u'', True,
                           date(2014, 5, 2)))
loader.save(
    create_ledger_movement(19, 128, 5, None, 3, 41, '120.00', False, u'', True,
                           date(2014, 5, 2)))
loader.save(
    create_ledger_movement(20, 116, 5, None, 4, 41, '5.33', False, u'', True,
                           date(2014, 5, 2)))
loader.save(
    create_ledger_movement(21, 118, 5, None, 5, 41, '10.00', False, u'', True,
                           date(2014, 5, 2)))
loader.save(
    create_ledger_movement(22, 124, 5, 224, 6, 4, '37.50', True,
                           u'SREG 2/2014', False, date(2014, 5, 2)))
loader.save(
    create_ledger_movement(23, 127, 5, 224, 7, 4, '54.95', True,
                           u'SREG 2/2014', False, date(2014, 5, 2)))
loader.save(
    create_ledger_movement(24, 128, 5, 224, 8, 4, '120.00', True,
                           u'SREG 2/2014', False, date(2014, 5, 2)))
loader.save(
    create_ledger_movement(25, 116, 5, 224, 9, 4, '5.33', True, u'SREG 2/2014',
                           False, date(2014, 5, 2)))
loader.save(
    create_ledger_movement(26, 118, 5, 224, 10, 4, '10.00', True,
                           u'SREG 2/2014', False, date(2014, 5, 2)))
loader.save(
    create_ledger_movement(27, 116, 6, None, 1, 42, '29.95', False, u'', True,
                           date(2014, 4, 27)))
loader.save(
    create_ledger_movement(28, 116, 6, 225, 2, 4, '29.95', True, u'REG 4/2014',
                           False, date(2014, 4, 27)))
loader.save(
    create_ledger_movement(29, 124, 7, None, 1, 43, '120.00', False, u'', True,
                           date(2014, 4, 22)))
loader.save(
    create_ledger_movement(30, 124, 7, 226, 2, 4, '120.00', True,
                           u'REG 5/2014', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(31, 128, 8, None, 1, 30, '5.33', False, u'', True,
                           date(2014, 4, 17)))
loader.save(
    create_ledger_movement(32, 116, 8, None, 2, 30, '10.00', False, u'', True,
                           date(2014, 4, 17)))
loader.save(
    create_ledger_movement(33, 118, 8, None, 3, 30, '12.50', False, u'', True,
                           date(2014, 4, 17)))
loader.save(
    create_ledger_movement(34, 124, 8, None, 4, 30, '25.00', False, u'', True,
                           date(2014, 4, 17)))
loader.save(
    create_ledger_movement(35, 127, 8, None, 5, 30, '29.95', False, u'', True,
                           date(2014, 4, 17)))
loader.save(
    create_ledger_movement(36, 128, 8, 227, 6, 4, '5.33', True, u'SREG 3/2014',
                           False, date(2014, 4, 17)))
loader.save(
    create_ledger_movement(37, 116, 8, 227, 7, 4, '10.00', True,
                           u'SREG 3/2014', False, date(2014, 4, 17)))
loader.save(
    create_ledger_movement(38, 118, 8, 227, 8, 4, '12.50', True,
                           u'SREG 3/2014', False, date(2014, 4, 17)))
loader.save(
    create_ledger_movement(39, 124, 8, 227, 9, 4, '25.00', True,
                           u'SREG 3/2014', False, date(2014, 4, 17)))
loader.save(
    create_ledger_movement(40, 127, 8, 227, 10, 4, '29.95', True,
                           u'SREG 3/2014', False, date(2014, 4, 17)))
loader.save(
    create_ledger_movement(41, 116, 9, None, 1, 47, '120.00', False, u'', True,
                           date(2014, 4, 12)))
loader.save(
    create_ledger_movement(42, 116, 9, 228, 2, 4, '120.00', True,
                           u'REG 6/2014', False, date(2014, 4, 12)))
loader.save(
    create_ledger_movement(43, 124, 10, None, 1, 32, '5.33', False, u'', True,
                           date(2014, 4, 7)))
loader.save(
    create_ledger_movement(44, 124, 10, 229, 2, 4, '5.33', True, u'REG 7/2014',
                           False, date(2014, 4, 7)))
loader.save(
    create_ledger_movement(45, 128, 11, None, 1, 31, '15.33', False, u'', True,
                           date(2014, 4, 2)))
loader.save(
    create_ledger_movement(46, 116, 11, None, 2, 31, '22.50', False, u'', True,
                           date(2014, 4, 2)))
loader.save(
    create_ledger_movement(47, 118, 11, None, 3, 31, '25.00', False, u'', True,
                           date(2014, 4, 2)))
loader.save(
    create_ledger_movement(48, 124, 11, None, 4, 31, '29.95', False, u'', True,
                           date(2014, 4, 2)))
loader.save(
    create_ledger_movement(49, 127, 11, None, 5, 31, '120.00', False, u'',
                           True, date(2014, 4, 2)))
loader.save(
    create_ledger_movement(50, 128, 11, 220, 6, 4, '15.33', True,
                           u'SREG 4/2014', True, date(2014, 4, 2)))
loader.save(
    create_ledger_movement(51, 116, 11, 220, 7, 4, '22.50', True,
                           u'SREG 4/2014', True, date(2014, 4, 2)))
loader.save(
    create_ledger_movement(52, 118, 11, 220, 8, 4, '25.00', True,
                           u'SREG 4/2014', True, date(2014, 4, 2)))
loader.save(
    create_ledger_movement(53, 124, 11, 220, 9, 4, '29.95', True,
                           u'SREG 4/2014', True, date(2014, 4, 2)))
loader.save(
    create_ledger_movement(54, 127, 11, 220, 10, 4, '120.00', True,
                           u'SREG 4/2014', True, date(2014, 4, 2)))
loader.save(
    create_ledger_movement(55, 124, 12, None, 1, 36, '12.50', False, u'', True,
                           date(2014, 3, 28)))
loader.save(
    create_ledger_movement(56, 124, 12, 221, 2, 4, '12.50', True,
                           u'REG 8/2014', False, date(2014, 3, 28)))
loader.save(
    create_ledger_movement(57, 128, 13, None, 1, 35, '25.00', False, u'', True,
                           date(2014, 3, 23)))
loader.save(
    create_ledger_movement(58, 128, 13, 222, 2, 4, '25.00', True,
                           u'REG 9/2014', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(59, 118, 14, None, 1, 29, '29.95', False, u'', True,
                           date(2014, 3, 18)))
loader.save(
    create_ledger_movement(60, 124, 14, None, 2, 29, '120.00', False, u'',
                           True, date(2014, 3, 18)))
loader.save(
    create_ledger_movement(61, 127, 14, None, 3, 29, '5.33', False, u'', True,
                           date(2014, 3, 18)))
loader.save(
    create_ledger_movement(62, 128, 14, None, 4, 29, '10.00', False, u'', True,
                           date(2014, 3, 18)))
loader.save(
    create_ledger_movement(63, 116, 14, None, 5, 29, '12.50', False, u'', True,
                           date(2014, 3, 18)))
loader.save(
    create_ledger_movement(64, 118, 14, 223, 6, 4, '29.95', True,
                           u'SREG 5/2014', True, date(2014, 3, 18)))
loader.save(
    create_ledger_movement(65, 124, 14, 223, 7, 4, '120.00', True,
                           u'SREG 5/2014', True, date(2014, 3, 18)))
loader.save(
    create_ledger_movement(66, 127, 14, 223, 8, 4, '5.33', True,
                           u'SREG 5/2014', True, date(2014, 3, 18)))
loader.save(
    create_ledger_movement(67, 128, 14, 223, 9, 4, '10.00', True,
                           u'SREG 5/2014', True, date(2014, 3, 18)))
loader.save(
    create_ledger_movement(68, 116, 14, 223, 10, 4, '12.50', True,
                           u'SREG 5/2014', True, date(2014, 3, 18)))
loader.save(
    create_ledger_movement(69, 124, 15, None, 1, 34, '25.00', False, u'', True,
                           date(2014, 3, 13)))
loader.save(
    create_ledger_movement(70, 124, 15, 224, 2, 4, '25.00', True,
                           u'REG 10/2014', False, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(71, 128, 16, None, 1, 33, '29.95', False, u'', True,
                           date(2014, 3, 8)))
loader.save(
    create_ledger_movement(72, 128, 16, 225, 2, 4, '29.95', True,
                           u'REG 11/2014', False, date(2014, 3, 8)))
loader.save(
    create_ledger_movement(73, 118, 17, None, 1, 37, '149.95', False, u'',
                           True, date(2014, 3, 3)))
loader.save(
    create_ledger_movement(74, 124, 17, None, 2, 37, '125.33', False, u'',
                           True, date(2014, 3, 3)))
loader.save(
    create_ledger_movement(75, 127, 17, None, 3, 37, '10.00', False, u'', True,
                           date(2014, 3, 3)))
loader.save(
    create_ledger_movement(76, 128, 17, None, 4, 37, '12.50', False, u'', True,
                           date(2014, 3, 3)))
loader.save(
    create_ledger_movement(77, 116, 17, None, 5, 37, '25.00', False, u'', True,
                           date(2014, 3, 3)))
loader.save(
    create_ledger_movement(78, 118, 17, 226, 6, 4, '149.95', True,
                           u'SREG 6/2014', True, date(2014, 3, 3)))
loader.save(
    create_ledger_movement(79, 124, 17, 226, 7, 4, '125.33', True,
                           u'SREG 6/2014', True, date(2014, 3, 3)))
loader.save(
    create_ledger_movement(80, 127, 17, 226, 8, 4, '10.00', True,
                           u'SREG 6/2014', True, date(2014, 3, 3)))
loader.save(
    create_ledger_movement(81, 128, 17, 226, 9, 4, '12.50', True,
                           u'SREG 6/2014', True, date(2014, 3, 3)))
loader.save(
    create_ledger_movement(82, 116, 17, 226, 10, 4, '25.00', True,
                           u'SREG 6/2014', True, date(2014, 3, 3)))
loader.save(
    create_ledger_movement(83, 128, 18, None, 1, 38, '5.33', False, u'', True,
                           date(2014, 2, 26)))
loader.save(
    create_ledger_movement(84, 128, 18, 227, 2, 4, '5.33', True,
                           u'REG 12/2014', False, date(2014, 2, 26)))
loader.save(
    create_ledger_movement(85, 118, 19, None, 1, 39, '10.00', False, u'', True,
                           date(2014, 2, 21)))
loader.save(
    create_ledger_movement(86, 118, 19, 228, 2, 4, '10.00', True,
                           u'REG 13/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(87, 127, 20, None, 1, 40, '12.50', False, u'', True,
                           date(2014, 2, 16)))
loader.save(
    create_ledger_movement(88, 128, 20, None, 2, 40, '25.00', False, u'', True,
                           date(2014, 2, 16)))
loader.save(
    create_ledger_movement(89, 116, 20, None, 3, 40, '29.95', False, u'', True,
                           date(2014, 2, 16)))
loader.save(
    create_ledger_movement(90, 118, 20, None, 4, 40, '120.00', False, u'',
                           True, date(2014, 2, 16)))
loader.save(
    create_ledger_movement(91, 124, 20, None, 5, 40, '5.33', False, u'', True,
                           date(2014, 2, 16)))
loader.save(
    create_ledger_movement(92, 127, 20, 229, 6, 4, '12.50', True,
                           u'SREG 7/2014', True, date(2014, 2, 16)))
loader.save(
    create_ledger_movement(93, 128, 20, 229, 7, 4, '25.00', True,
                           u'SREG 7/2014', True, date(2014, 2, 16)))
loader.save(
    create_ledger_movement(94, 116, 20, 229, 8, 4, '29.95', True,
                           u'SREG 7/2014', True, date(2014, 2, 16)))
loader.save(
    create_ledger_movement(95, 118, 20, 229, 9, 4, '120.00', True,
                           u'SREG 7/2014', True, date(2014, 2, 16)))
loader.save(
    create_ledger_movement(96, 124, 20, 229, 10, 4, '5.33', True,
                           u'SREG 7/2014', True, date(2014, 2, 16)))
loader.save(
    create_ledger_movement(97, 128, 21, None, 1, 41, '10.00', False, u'', True,
                           date(2014, 2, 11)))
loader.save(
    create_ledger_movement(98, 128, 21, 220, 2, 4, '10.00', True,
                           u'REG 14/2014', False, date(2014, 2, 11)))
loader.save(
    create_ledger_movement(99, 118, 22, None, 1, 42, '12.50', False, u'', True,
                           date(2014, 2, 6)))
loader.save(
    create_ledger_movement(100, 118, 22, 221, 2, 4, '12.50', True,
                           u'REG 15/2014', False, date(2014, 2, 6)))
loader.save(
    create_ledger_movement(101, 127, 23, None, 1, 43, '37.50', False, u'',
                           True, date(2014, 2, 1)))
loader.save(
    create_ledger_movement(102, 128, 23, None, 2, 43, '54.95', False, u'',
                           True, date(2014, 2, 1)))
loader.save(
    create_ledger_movement(103, 116, 23, None, 3, 43, '120.00', False, u'',
                           True, date(2014, 2, 1)))
loader.save(
    create_ledger_movement(104, 118, 23, None, 4, 43, '5.33', False, u'', True,
                           date(2014, 2, 1)))
loader.save(
    create_ledger_movement(105, 124, 23, None, 5, 43, '10.00', False, u'',
                           True, date(2014, 2, 1)))
loader.save(
    create_ledger_movement(106, 127, 23, 222, 6, 4, '37.50', True,
                           u'SREG 8/2014', True, date(2014, 2, 1)))
loader.save(
    create_ledger_movement(107, 128, 23, 222, 7, 4, '54.95', True,
                           u'SREG 8/2014', True, date(2014, 2, 1)))
loader.save(
    create_ledger_movement(108, 116, 23, 222, 8, 4, '120.00', True,
                           u'SREG 8/2014', True, date(2014, 2, 1)))
loader.save(
    create_ledger_movement(109, 118, 23, 222, 9, 4, '5.33', True,
                           u'SREG 8/2014', True, date(2014, 2, 1)))
loader.save(
    create_ledger_movement(110, 124, 23, 222, 10, 4, '10.00', True,
                           u'SREG 8/2014', True, date(2014, 2, 1)))
loader.save(
    create_ledger_movement(111, 118, 24, None, 1, 30, '29.95', False, u'',
                           True, date(2014, 1, 27)))
loader.save(
    create_ledger_movement(112, 118, 24, 223, 2, 4, '29.95', True,
                           u'REG 16/2014', False, date(2014, 1, 27)))
loader.save(
    create_ledger_movement(113, 127, 25, None, 1, 47, '120.00', False, u'',
                           True, date(2014, 1, 22)))
loader.save(
    create_ledger_movement(114, 127, 25, 224, 2, 4, '120.00', True,
                           u'REG 17/2014', False, date(2014, 1, 22)))
loader.save(
    create_ledger_movement(115, 116, 26, None, 1, 32, '5.33', False, u'', True,
                           date(2014, 1, 17)))
loader.save(
    create_ledger_movement(116, 118, 26, None, 2, 32, '10.00', False, u'',
                           True, date(2014, 1, 17)))
loader.save(
    create_ledger_movement(117, 124, 26, None, 3, 32, '12.50', False, u'',
                           True, date(2014, 1, 17)))
loader.save(
    create_ledger_movement(118, 127, 26, None, 4, 32, '25.00', False, u'',
                           True, date(2014, 1, 17)))
loader.save(
    create_ledger_movement(119, 128, 26, None, 5, 32, '29.95', False, u'',
                           True, date(2014, 1, 17)))
loader.save(
    create_ledger_movement(120, 116, 26, 225, 6, 4, '5.33', True,
                           u'SREG 9/2014', True, date(2014, 1, 17)))
loader.save(
    create_ledger_movement(121, 118, 26, 225, 7, 4, '10.00', True,
                           u'SREG 9/2014', True, date(2014, 1, 17)))
loader.save(
    create_ledger_movement(122, 124, 26, 225, 8, 4, '12.50', True,
                           u'SREG 9/2014', True, date(2014, 1, 17)))
loader.save(
    create_ledger_movement(123, 127, 26, 225, 9, 4, '25.00', True,
                           u'SREG 9/2014', True, date(2014, 1, 17)))
loader.save(
    create_ledger_movement(124, 128, 26, 225, 10, 4, '29.95', True,
                           u'SREG 9/2014', True, date(2014, 1, 17)))
loader.save(
    create_ledger_movement(125, 118, 27, None, 1, 31, '120.00', False, u'',
                           True, date(2014, 1, 12)))
loader.save(
    create_ledger_movement(126, 118, 27, 226, 2, 4, '120.00', True,
                           u'REG 18/2014', False, date(2014, 1, 12)))
loader.save(
    create_ledger_movement(127, 127, 28, None, 1, 36, '5.33', False, u'', True,
                           date(2014, 1, 7)))
loader.save(
    create_ledger_movement(128, 127, 28, 227, 2, 4, '5.33', True,
                           u'REG 19/2014', False, date(2014, 1, 7)))
loader.save(
    create_ledger_movement(129, 116, 29, None, 1, 35, '15.33', False, u'',
                           True, date(2014, 1, 2)))
loader.save(
    create_ledger_movement(130, 118, 29, None, 2, 35, '22.50', False, u'',
                           True, date(2014, 1, 2)))
loader.save(
    create_ledger_movement(131, 124, 29, None, 3, 35, '25.00', False, u'',
                           True, date(2014, 1, 2)))
loader.save(
    create_ledger_movement(132, 127, 29, None, 4, 35, '29.95', False, u'',
                           True, date(2014, 1, 2)))
loader.save(
    create_ledger_movement(133, 128, 29, None, 5, 35, '120.00', False, u'',
                           True, date(2014, 1, 2)))
loader.save(
    create_ledger_movement(134, 116, 29, 228, 6, 4, '15.33', True,
                           u'SREG 10/2014', True, date(2014, 1, 2)))
loader.save(
    create_ledger_movement(135, 118, 29, 228, 7, 4, '22.50', True,
                           u'SREG 10/2014', True, date(2014, 1, 2)))
loader.save(
    create_ledger_movement(136, 124, 29, 228, 8, 4, '25.00', True,
                           u'SREG 10/2014', True, date(2014, 1, 2)))
loader.save(
    create_ledger_movement(137, 127, 29, 228, 9, 4, '29.95', True,
                           u'SREG 10/2014', True, date(2014, 1, 2)))
loader.save(
    create_ledger_movement(138, 128, 29, 228, 10, 4, '120.00', True,
                           u'SREG 10/2014', True, date(2014, 1, 2)))
loader.save(
    create_ledger_movement(139, 127, 30, None, 1, 29, '12.50', False, u'',
                           True, date(2013, 12, 28)))
loader.save(
    create_ledger_movement(140, 127, 30, 229, 2, 4, '12.50', True,
                           u'REG 1/2013', False, date(2013, 12, 28)))
loader.save(
    create_ledger_movement(141, 116, 31, 116, 1, 30, '648.91', True,
                           u'AAW 1:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(142, 116, 31, 116, 2, 21, '648.91', False,
                           u'AAW 1:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(143, 118, 31, 118, 3, 30, '817.36', True,
                           u'AAW 1:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(144, 118, 31, 118, 4, 21, '817.36', False,
                           u'AAW 1:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(145, 124, 31, 124, 5, 30, '544.91', True,
                           u'AAW 1:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(146, 124, 31, 124, 6, 21, '544.91', False,
                           u'AAW 1:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(147, 127, 31, 127, 7, 30, '800.08', True,
                           u'AAW 1:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(148, 127, 31, 127, 8, 21, '800.08', False,
                           u'AAW 1:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(149, 128, 31, 128, 9, 30, '648.91', True,
                           u'AAW 1:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(150, 128, 31, 128, 10, 21, '648.91', False,
                           u'AAW 1:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(151, 116, 32, 116, 1, 32, '817.36', True,
                           u'AAW 2:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(152, 116, 32, 116, 2, 21, '817.36', False,
                           u'AAW 2:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(153, 118, 32, 118, 3, 32, '544.91', True,
                           u'AAW 2:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(154, 118, 32, 118, 4, 21, '544.91', False,
                           u'AAW 2:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(155, 124, 32, 124, 5, 32, '800.08', True,
                           u'AAW 2:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(156, 124, 32, 124, 6, 21, '800.08', False,
                           u'AAW 2:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(157, 127, 32, 127, 7, 32, '648.91', True,
                           u'AAW 2:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(158, 127, 32, 127, 8, 21, '648.91', False,
                           u'AAW 2:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(159, 128, 32, 128, 9, 32, '817.36', True,
                           u'AAW 2:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(160, 128, 32, 128, 10, 21, '817.36', False,
                           u'AAW 2:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(161, 116, 33, 116, 1, 31, '544.91', True,
                           u'AAW 3:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(162, 116, 33, 116, 2, 21, '544.91', False,
                           u'AAW 3:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(163, 118, 33, 118, 3, 31, '800.08', True,
                           u'AAW 3:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(164, 118, 33, 118, 4, 21, '800.08', False,
                           u'AAW 3:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(165, 124, 33, 124, 5, 31, '648.91', True,
                           u'AAW 3:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(166, 124, 33, 124, 6, 21, '648.91', False,
                           u'AAW 3:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(167, 127, 33, 127, 7, 31, '817.36', True,
                           u'AAW 3:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(168, 127, 33, 127, 8, 21, '817.36', False,
                           u'AAW 3:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(169, 128, 33, 128, 9, 31, '544.91', True,
                           u'AAW 3:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(170, 128, 33, 128, 10, 21, '544.91', False,
                           u'AAW 3:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(171, 116, 34, 116, 1, 29, '800.08', True,
                           u'AAW 4:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(172, 116, 34, 116, 2, 21, '800.08', False,
                           u'AAW 4:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(173, 118, 34, 118, 3, 29, '648.91', True,
                           u'AAW 4:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(174, 118, 34, 118, 4, 21, '648.91', False,
                           u'AAW 4:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(175, 124, 34, 124, 5, 29, '817.36', True,
                           u'AAW 4:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(176, 124, 34, 124, 6, 21, '817.36', False,
                           u'AAW 4:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(177, 127, 34, 127, 7, 29, '544.91', True,
                           u'AAW 4:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(178, 127, 34, 127, 8, 21, '544.91', False,
                           u'AAW 4:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(179, 128, 34, 128, 9, 29, '800.08', True,
                           u'AAW 4:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(180, 128, 34, 128, 10, 21, '800.08', False,
                           u'AAW 4:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(181, 116, 35, 116, 1, 34, '648.91', True,
                           u'AAW 5:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(182, 116, 35, 116, 2, 21, '648.91', False,
                           u'AAW 5:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(183, 118, 35, 118, 3, 34, '817.36', True,
                           u'AAW 5:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(184, 118, 35, 118, 4, 21, '817.36', False,
                           u'AAW 5:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(185, 124, 35, 124, 5, 34, '544.91', True,
                           u'AAW 5:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(186, 124, 35, 124, 6, 21, '544.91', False,
                           u'AAW 5:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(187, 127, 35, 127, 7, 34, '800.08', True,
                           u'AAW 5:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(188, 127, 35, 127, 8, 21, '800.08', False,
                           u'AAW 5:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(189, 128, 35, 128, 9, 34, '648.91', True,
                           u'AAW 5:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(190, 128, 35, 128, 10, 21, '648.91', False,
                           u'AAW 5:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(191, 116, 36, 116, 1, 33, '817.36', True,
                           u'AAW 6:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(192, 116, 36, 116, 2, 21, '817.36', False,
                           u'AAW 6:1', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(193, 118, 36, 118, 3, 33, '544.91', True,
                           u'AAW 6:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(194, 118, 36, 118, 4, 21, '544.91', False,
                           u'AAW 6:2', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(195, 124, 36, 124, 5, 33, '800.08', True,
                           u'AAW 6:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(196, 124, 36, 124, 6, 21, '800.08', False,
                           u'AAW 6:3', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(197, 127, 36, 127, 7, 33, '648.91', True,
                           u'AAW 6:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(198, 127, 36, 127, 8, 21, '648.91', False,
                           u'AAW 6:4', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(199, 128, 36, 128, 9, 33, '817.36', True,
                           u'AAW 6:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(200, 128, 36, 128, 10, 21, '817.36', False,
                           u'AAW 6:5', False, date(2014, 5, 22)))
loader.save(
    create_ledger_movement(201, 116, 37, 116, 1, 30, '544.91', True,
                           u'AAW 7:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(202, 116, 37, 116, 2, 21, '544.91', False,
                           u'AAW 7:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(203, 118, 37, 118, 3, 30, '800.08', True,
                           u'AAW 7:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(204, 118, 37, 118, 4, 21, '800.08', False,
                           u'AAW 7:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(205, 124, 37, 124, 5, 30, '648.91', True,
                           u'AAW 7:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(206, 124, 37, 124, 6, 21, '648.91', False,
                           u'AAW 7:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(207, 127, 37, 127, 7, 30, '817.36', True,
                           u'AAW 7:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(208, 127, 37, 127, 8, 21, '817.36', False,
                           u'AAW 7:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(209, 128, 37, 128, 9, 30, '544.91', True,
                           u'AAW 7:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(210, 128, 37, 128, 10, 21, '544.91', False,
                           u'AAW 7:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(211, 116, 38, 116, 1, 32, '800.08', True,
                           u'AAW 8:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(212, 116, 38, 116, 2, 21, '800.08', False,
                           u'AAW 8:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(213, 118, 38, 118, 3, 32, '648.91', True,
                           u'AAW 8:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(214, 118, 38, 118, 4, 21, '648.91', False,
                           u'AAW 8:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(215, 124, 38, 124, 5, 32, '817.36', True,
                           u'AAW 8:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(216, 124, 38, 124, 6, 21, '817.36', False,
                           u'AAW 8:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(217, 127, 38, 127, 7, 32, '544.91', True,
                           u'AAW 8:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(218, 127, 38, 127, 8, 21, '544.91', False,
                           u'AAW 8:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(219, 128, 38, 128, 9, 32, '800.08', True,
                           u'AAW 8:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(220, 128, 38, 128, 10, 21, '800.08', False,
                           u'AAW 8:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(221, 116, 39, 116, 1, 31, '648.91', True,
                           u'AAW 9:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(222, 116, 39, 116, 2, 21, '648.91', False,
                           u'AAW 9:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(223, 118, 39, 118, 3, 31, '817.36', True,
                           u'AAW 9:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(224, 118, 39, 118, 4, 21, '817.36', False,
                           u'AAW 9:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(225, 124, 39, 124, 5, 31, '544.91', True,
                           u'AAW 9:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(226, 124, 39, 124, 6, 21, '544.91', False,
                           u'AAW 9:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(227, 127, 39, 127, 7, 31, '800.08', True,
                           u'AAW 9:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(228, 127, 39, 127, 8, 21, '800.08', False,
                           u'AAW 9:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(229, 128, 39, 128, 9, 31, '648.91', True,
                           u'AAW 9:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(230, 128, 39, 128, 10, 21, '648.91', False,
                           u'AAW 9:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(231, 116, 40, 116, 1, 29, '817.36', True,
                           u'AAW 10:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(232, 116, 40, 116, 2, 21, '817.36', False,
                           u'AAW 10:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(233, 118, 40, 118, 3, 29, '544.91', True,
                           u'AAW 10:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(234, 118, 40, 118, 4, 21, '544.91', False,
                           u'AAW 10:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(235, 124, 40, 124, 5, 29, '800.08', True,
                           u'AAW 10:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(236, 124, 40, 124, 6, 21, '800.08', False,
                           u'AAW 10:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(237, 127, 40, 127, 7, 29, '648.91', True,
                           u'AAW 10:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(238, 127, 40, 127, 8, 21, '648.91', False,
                           u'AAW 10:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(239, 128, 40, 128, 9, 29, '817.36', True,
                           u'AAW 10:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(240, 128, 40, 128, 10, 21, '817.36', False,
                           u'AAW 10:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(241, 116, 41, 116, 1, 34, '544.91', True,
                           u'AAW 11:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(242, 116, 41, 116, 2, 21, '544.91', False,
                           u'AAW 11:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(243, 118, 41, 118, 3, 34, '800.08', True,
                           u'AAW 11:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(244, 118, 41, 118, 4, 21, '800.08', False,
                           u'AAW 11:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(245, 124, 41, 124, 5, 34, '648.91', True,
                           u'AAW 11:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(246, 124, 41, 124, 6, 21, '648.91', False,
                           u'AAW 11:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(247, 127, 41, 127, 7, 34, '817.36', True,
                           u'AAW 11:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(248, 127, 41, 127, 8, 21, '817.36', False,
                           u'AAW 11:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(249, 128, 41, 128, 9, 34, '544.91', True,
                           u'AAW 11:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(250, 128, 41, 128, 10, 21, '544.91', False,
                           u'AAW 11:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(251, 116, 42, 116, 1, 33, '800.08', True,
                           u'AAW 12:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(252, 116, 42, 116, 2, 21, '800.08', False,
                           u'AAW 12:1', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(253, 118, 42, 118, 3, 33, '648.91', True,
                           u'AAW 12:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(254, 118, 42, 118, 4, 21, '648.91', False,
                           u'AAW 12:2', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(255, 124, 42, 124, 5, 33, '817.36', True,
                           u'AAW 12:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(256, 124, 42, 124, 6, 21, '817.36', False,
                           u'AAW 12:3', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(257, 127, 42, 127, 7, 33, '544.91', True,
                           u'AAW 12:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(258, 127, 42, 127, 8, 21, '544.91', False,
                           u'AAW 12:4', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(259, 128, 42, 128, 9, 33, '800.08', True,
                           u'AAW 12:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(260, 128, 42, 128, 10, 21, '800.08', False,
                           u'AAW 12:5', False, date(2014, 4, 22)))
loader.save(
    create_ledger_movement(261, 116, 43, 116, 1, 30, '648.91', True,
                           u'AAW 13:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(262, 116, 43, 116, 2, 21, '648.91', False,
                           u'AAW 13:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(263, 118, 43, 118, 3, 30, '817.36', True,
                           u'AAW 13:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(264, 118, 43, 118, 4, 21, '817.36', False,
                           u'AAW 13:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(265, 124, 43, 124, 5, 30, '544.91', True,
                           u'AAW 13:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(266, 124, 43, 124, 6, 21, '544.91', False,
                           u'AAW 13:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(267, 127, 43, 127, 7, 30, '800.08', True,
                           u'AAW 13:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(268, 127, 43, 127, 8, 21, '800.08', False,
                           u'AAW 13:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(269, 128, 43, 128, 9, 30, '648.91', True,
                           u'AAW 13:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(270, 128, 43, 128, 10, 21, '648.91', False,
                           u'AAW 13:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(271, 116, 44, 116, 1, 32, '817.36', True,
                           u'AAW 14:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(272, 116, 44, 116, 2, 21, '817.36', False,
                           u'AAW 14:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(273, 118, 44, 118, 3, 32, '544.91', True,
                           u'AAW 14:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(274, 118, 44, 118, 4, 21, '544.91', False,
                           u'AAW 14:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(275, 124, 44, 124, 5, 32, '800.08', True,
                           u'AAW 14:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(276, 124, 44, 124, 6, 21, '800.08', False,
                           u'AAW 14:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(277, 127, 44, 127, 7, 32, '648.91', True,
                           u'AAW 14:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(278, 127, 44, 127, 8, 21, '648.91', False,
                           u'AAW 14:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(279, 128, 44, 128, 9, 32, '817.36', True,
                           u'AAW 14:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(280, 128, 44, 128, 10, 21, '817.36', False,
                           u'AAW 14:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(281, 116, 45, 116, 1, 31, '544.91', True,
                           u'AAW 15:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(282, 116, 45, 116, 2, 21, '544.91', False,
                           u'AAW 15:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(283, 118, 45, 118, 3, 31, '800.08', True,
                           u'AAW 15:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(284, 118, 45, 118, 4, 21, '800.08', False,
                           u'AAW 15:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(285, 124, 45, 124, 5, 31, '648.91', True,
                           u'AAW 15:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(286, 124, 45, 124, 6, 21, '648.91', False,
                           u'AAW 15:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(287, 127, 45, 127, 7, 31, '817.36', True,
                           u'AAW 15:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(288, 127, 45, 127, 8, 21, '817.36', False,
                           u'AAW 15:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(289, 128, 45, 128, 9, 31, '544.91', True,
                           u'AAW 15:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(290, 128, 45, 128, 10, 21, '544.91', False,
                           u'AAW 15:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(291, 116, 46, 116, 1, 29, '800.08', True,
                           u'AAW 16:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(292, 116, 46, 116, 2, 21, '800.08', False,
                           u'AAW 16:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(293, 118, 46, 118, 3, 29, '648.91', True,
                           u'AAW 16:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(294, 118, 46, 118, 4, 21, '648.91', False,
                           u'AAW 16:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(295, 124, 46, 124, 5, 29, '817.36', True,
                           u'AAW 16:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(296, 124, 46, 124, 6, 21, '817.36', False,
                           u'AAW 16:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(297, 127, 46, 127, 7, 29, '544.91', True,
                           u'AAW 16:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(298, 127, 46, 127, 8, 21, '544.91', False,
                           u'AAW 16:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(299, 128, 46, 128, 9, 29, '800.08', True,
                           u'AAW 16:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(300, 128, 46, 128, 10, 21, '800.08', False,
                           u'AAW 16:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(301, 116, 47, 116, 1, 34, '648.91', True,
                           u'AAW 17:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(302, 116, 47, 116, 2, 21, '648.91', False,
                           u'AAW 17:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(303, 118, 47, 118, 3, 34, '817.36', True,
                           u'AAW 17:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(304, 118, 47, 118, 4, 21, '817.36', False,
                           u'AAW 17:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(305, 124, 47, 124, 5, 34, '544.91', True,
                           u'AAW 17:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(306, 124, 47, 124, 6, 21, '544.91', False,
                           u'AAW 17:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(307, 127, 47, 127, 7, 34, '800.08', True,
                           u'AAW 17:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(308, 127, 47, 127, 8, 21, '800.08', False,
                           u'AAW 17:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(309, 128, 47, 128, 9, 34, '648.91', True,
                           u'AAW 17:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(310, 128, 47, 128, 10, 21, '648.91', False,
                           u'AAW 17:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(311, 116, 48, 116, 1, 33, '817.36', True,
                           u'AAW 18:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(312, 116, 48, 116, 2, 21, '817.36', False,
                           u'AAW 18:1', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(313, 118, 48, 118, 3, 33, '544.91', True,
                           u'AAW 18:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(314, 118, 48, 118, 4, 21, '544.91', False,
                           u'AAW 18:2', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(315, 124, 48, 124, 5, 33, '800.08', True,
                           u'AAW 18:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(316, 124, 48, 124, 6, 21, '800.08', False,
                           u'AAW 18:3', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(317, 127, 48, 127, 7, 33, '648.91', True,
                           u'AAW 18:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(318, 127, 48, 127, 8, 21, '648.91', False,
                           u'AAW 18:4', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(319, 128, 48, 128, 9, 33, '817.36', True,
                           u'AAW 18:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(320, 128, 48, 128, 10, 21, '817.36', False,
                           u'AAW 18:5', False, date(2014, 3, 23)))
loader.save(
    create_ledger_movement(321, 127, 73, 229, 1, 4, '12.50', False,
                           u'REG 1/2013', False, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(322, 127, 73, 229, 2, 21, '12.50', True,
                           u'REG 1/2013', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(323, 116, 73, 228, 3, 4, '15.33', False,
                           u'SREG 10/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(324, 116, 73, 228, 4, 21, '15.33', True,
                           u'SREG 10/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(325, 118, 73, 228, 5, 4, '22.50', False,
                           u'SREG 10/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(326, 118, 73, 228, 6, 21, '22.50', True,
                           u'SREG 10/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(327, 124, 73, 228, 7, 4, '25.00', False,
                           u'SREG 10/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(328, 124, 73, 228, 8, 21, '25.00', True,
                           u'SREG 10/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(329, 127, 73, 228, 9, 4, '29.95', False,
                           u'SREG 10/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(330, 127, 73, 228, 10, 21, '29.95', True,
                           u'SREG 10/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(331, 128, 73, 228, 11, 4, '120.00', False,
                           u'SREG 10/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(332, 128, 73, 228, 12, 21, '120.00', True,
                           u'SREG 10/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(333, 127, 73, 227, 13, 4, '5.33', False,
                           u'REG 19/2014', False, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(334, 127, 73, 227, 14, 21, '5.33', True,
                           u'REG 19/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(335, 118, 73, 226, 15, 4, '120.00', False,
                           u'REG 18/2014', False, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(336, 118, 73, 226, 16, 21, '120.00', True,
                           u'REG 18/2014', True, date(2014, 1, 13)))
loader.save(
    create_ledger_movement(337, 116, 74, 225, 1, 4, '5.33', False,
                           u'SREG 9/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(338, 116, 74, 225, 2, 21, '5.33', True,
                           u'SREG 9/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(339, 118, 74, 225, 3, 4, '10.00', False,
                           u'SREG 9/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(340, 118, 74, 225, 4, 21, '10.00', True,
                           u'SREG 9/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(341, 124, 74, 225, 5, 4, '12.50', False,
                           u'SREG 9/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(342, 124, 74, 225, 6, 21, '12.50', True,
                           u'SREG 9/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(343, 127, 74, 225, 7, 4, '25.00', False,
                           u'SREG 9/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(344, 127, 74, 225, 8, 21, '25.00', True,
                           u'SREG 9/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(345, 128, 74, 225, 9, 4, '29.95', False,
                           u'SREG 9/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(346, 128, 74, 225, 10, 21, '29.95', True,
                           u'SREG 9/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(347, 127, 74, 224, 11, 4, '120.00', False,
                           u'REG 17/2014', False, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(348, 127, 74, 224, 12, 21, '120.00', True,
                           u'REG 17/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(349, 118, 74, 223, 13, 4, '29.95', False,
                           u'REG 16/2014', False, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(350, 118, 74, 223, 14, 21, '29.95', True,
                           u'REG 16/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(351, 116, 74, 222, 15, 4, '120.00', False,
                           u'SREG 8/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(352, 116, 74, 222, 16, 21, '120.00', True,
                           u'SREG 8/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(353, 118, 74, 222, 17, 4, '5.33', False,
                           u'SREG 8/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(354, 118, 74, 222, 18, 21, '5.33', True,
                           u'SREG 8/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(355, 124, 74, 222, 19, 4, '10.00', False,
                           u'SREG 8/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(356, 124, 74, 222, 20, 21, '10.00', True,
                           u'SREG 8/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(357, 127, 74, 222, 21, 4, '37.50', False,
                           u'SREG 8/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(358, 127, 74, 222, 22, 21, '37.50', True,
                           u'SREG 8/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(359, 128, 74, 222, 23, 4, '54.95', False,
                           u'SREG 8/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(360, 128, 74, 222, 24, 21, '54.95', True,
                           u'SREG 8/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(361, 118, 74, 221, 25, 4, '12.50', False,
                           u'REG 15/2014', False, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(362, 118, 74, 221, 26, 21, '12.50', True,
                           u'REG 15/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(363, 128, 74, 220, 27, 4, '10.00', False,
                           u'REG 14/2014', False, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(364, 128, 74, 220, 28, 21, '10.00', True,
                           u'REG 14/2014', True, date(2014, 2, 13)))
loader.save(
    create_ledger_movement(365, 116, 75, 229, 1, 4, '29.95', False,
                           u'SREG 7/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(366, 116, 75, 229, 2, 21, '29.95', True,
                           u'SREG 7/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(367, 118, 75, 229, 3, 4, '120.00', False,
                           u'SREG 7/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(368, 118, 75, 229, 4, 21, '120.00', True,
                           u'SREG 7/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(369, 124, 75, 229, 5, 4, '5.33', False,
                           u'SREG 7/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(370, 124, 75, 229, 6, 21, '5.33', True,
                           u'SREG 7/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(371, 127, 75, 229, 7, 4, '12.50', False,
                           u'SREG 7/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(372, 127, 75, 229, 8, 21, '12.50', True,
                           u'SREG 7/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(373, 128, 75, 229, 9, 4, '25.00', False,
                           u'SREG 7/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(374, 128, 75, 229, 10, 21, '25.00', True,
                           u'SREG 7/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(375, 118, 75, 228, 11, 4, '10.00', False,
                           u'REG 13/2014', False, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(376, 118, 75, 228, 12, 21, '10.00', True,
                           u'REG 13/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(377, 128, 75, 227, 13, 4, '5.33', False,
                           u'REG 12/2014', False, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(378, 128, 75, 227, 14, 21, '5.33', True,
                           u'REG 12/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(379, 116, 75, 226, 15, 4, '25.00', False,
                           u'SREG 6/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(380, 116, 75, 226, 16, 21, '25.00', True,
                           u'SREG 6/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(381, 118, 75, 226, 17, 4, '149.95', False,
                           u'SREG 6/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(382, 118, 75, 226, 18, 21, '149.95', True,
                           u'SREG 6/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(383, 124, 75, 226, 19, 4, '125.33', False,
                           u'SREG 6/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(384, 124, 75, 226, 20, 21, '125.33', True,
                           u'SREG 6/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(385, 127, 75, 226, 21, 4, '10.00', False,
                           u'SREG 6/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(386, 127, 75, 226, 22, 21, '10.00', True,
                           u'SREG 6/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(387, 128, 75, 226, 23, 4, '12.50', False,
                           u'SREG 6/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(388, 128, 75, 226, 24, 21, '12.50', True,
                           u'SREG 6/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(389, 128, 75, 225, 25, 4, '29.95', False,
                           u'REG 11/2014', False, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(390, 128, 75, 225, 26, 21, '29.95', True,
                           u'REG 11/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(391, 124, 75, 224, 27, 4, '25.00', False,
                           u'REG 10/2014', False, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(392, 124, 75, 224, 28, 21, '25.00', True,
                           u'REG 10/2014', True, date(2014, 3, 13)))
loader.save(
    create_ledger_movement(393, 116, 76, 223, 1, 4, '12.50', False,
                           u'SREG 5/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(394, 116, 76, 223, 2, 21, '12.50', True,
                           u'SREG 5/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(395, 118, 76, 223, 3, 4, '29.95', False,
                           u'SREG 5/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(396, 118, 76, 223, 4, 21, '29.95', True,
                           u'SREG 5/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(397, 124, 76, 223, 5, 4, '120.00', False,
                           u'SREG 5/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(398, 124, 76, 223, 6, 21, '120.00', True,
                           u'SREG 5/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(399, 127, 76, 223, 7, 4, '5.33', False,
                           u'SREG 5/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(400, 127, 76, 223, 8, 21, '5.33', True,
                           u'SREG 5/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(401, 128, 76, 223, 9, 4, '10.00', False,
                           u'SREG 5/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(402, 128, 76, 223, 10, 21, '10.00', True,
                           u'SREG 5/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(403, 128, 76, 222, 11, 4, '25.00', False,
                           u'REG 9/2014', False, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(404, 128, 76, 222, 12, 21, '25.00', True,
                           u'REG 9/2014', False, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(405, 124, 76, 221, 13, 4, '12.50', False,
                           u'REG 8/2014', False, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(406, 124, 76, 221, 14, 21, '12.50', True,
                           u'REG 8/2014', False, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(407, 116, 76, 220, 15, 4, '22.50', False,
                           u'SREG 4/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(408, 116, 76, 220, 16, 21, '22.50', True,
                           u'SREG 4/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(409, 118, 76, 220, 17, 4, '25.00', False,
                           u'SREG 4/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(410, 118, 76, 220, 18, 21, '25.00', True,
                           u'SREG 4/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(411, 124, 76, 220, 19, 4, '29.95', False,
                           u'SREG 4/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(412, 124, 76, 220, 20, 21, '29.95', True,
                           u'SREG 4/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(413, 127, 76, 220, 21, 4, '120.00', False,
                           u'SREG 4/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(414, 127, 76, 220, 22, 21, '120.00', True,
                           u'SREG 4/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(415, 128, 76, 220, 23, 4, '15.33', False,
                           u'SREG 4/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(416, 128, 76, 220, 24, 21, '15.33', True,
                           u'SREG 4/2014', True, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(417, 124, 76, 229, 25, 4, '5.33', False,
                           u'REG 7/2014', False, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(418, 124, 76, 229, 26, 21, '5.33', True,
                           u'REG 7/2014', False, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(419, 116, 76, 228, 27, 4, '120.00', False,
                           u'REG 6/2014', False, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(420, 116, 76, 228, 28, 21, '120.00', True,
                           u'REG 6/2014', False, date(2014, 4, 13)))
loader.save(
    create_ledger_movement(421, 118, 101, 226, 1, 4, '120.00', False,
                           u'REG 18/2014', False, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(422, 118, 101, 226, 2, 3, '120.00', True,
                           u'REG 18/2014', False, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(423, 127, 101, 227, 3, 4, '5.33', False,
                           u'REG 19/2014', False, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(424, 127, 101, 227, 4, 3, '5.33', True,
                           u'REG 19/2014', False, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(425, 116, 101, 228, 5, 21, '15.33', False,
                           u'SREG 10/2014', True, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(426, 116, 101, 228, 6, 3, '15.33', True,
                           u'SREG 10/2014', False, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(427, 118, 101, 228, 7, 21, '22.50', False,
                           u'SREG 10/2014', True, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(428, 118, 101, 228, 8, 3, '22.50', True,
                           u'SREG 10/2014', False, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(429, 124, 101, 228, 9, 21, '25.00', False,
                           u'SREG 10/2014', True, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(430, 124, 101, 228, 10, 3, '25.00', True,
                           u'SREG 10/2014', False, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(431, 127, 101, 228, 11, 21, '29.95', False,
                           u'SREG 10/2014', True, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(432, 127, 101, 228, 12, 3, '29.95', True,
                           u'SREG 10/2014', False, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(433, 128, 101, 228, 13, 21, '120.00', False,
                           u'SREG 10/2014', True, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(434, 128, 101, 228, 14, 3, '120.00', True,
                           u'SREG 10/2014', False, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(435, 127, 101, 229, 15, 4, '12.50', False,
                           u'REG 1/2013', False, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(436, 127, 101, 229, 16, 3, '12.50', True,
                           u'REG 1/2013', False, date(2014, 1, 21)))
loader.save(
    create_ledger_movement(437, 118, 102, 226, 1, 21, '120.00', False,
                           u'REG 18/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(438, 118, 102, 226, 2, 3, '120.00', True,
                           u'REG 18/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(439, 127, 102, 227, 3, 21, '5.33', False,
                           u'REG 19/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(440, 127, 102, 227, 4, 3, '5.33', True,
                           u'REG 19/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(441, 127, 102, 229, 5, 21, '12.50', False,
                           u'REG 1/2013', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(442, 127, 102, 229, 6, 3, '12.50', True,
                           u'REG 1/2013', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(443, 128, 102, 220, 7, 4, '10.00', False,
                           u'REG 14/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(444, 128, 102, 220, 8, 3, '10.00', True,
                           u'REG 14/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(445, 118, 102, 221, 9, 4, '12.50', False,
                           u'REG 15/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(446, 118, 102, 221, 10, 3, '12.50', True,
                           u'REG 15/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(447, 116, 102, 222, 11, 21, '120.00', False,
                           u'SREG 8/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(448, 116, 102, 222, 12, 3, '120.00', True,
                           u'SREG 8/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(449, 118, 102, 222, 13, 21, '5.33', False,
                           u'SREG 8/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(450, 118, 102, 222, 14, 3, '5.33', True,
                           u'SREG 8/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(451, 124, 102, 222, 15, 21, '10.00', False,
                           u'SREG 8/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(452, 124, 102, 222, 16, 3, '10.00', True,
                           u'SREG 8/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(453, 127, 102, 222, 17, 21, '37.50', False,
                           u'SREG 8/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(454, 127, 102, 222, 18, 3, '37.50', True,
                           u'SREG 8/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(455, 128, 102, 222, 19, 21, '54.95', False,
                           u'SREG 8/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(456, 128, 102, 222, 20, 3, '54.95', True,
                           u'SREG 8/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(457, 118, 102, 223, 21, 4, '29.95', False,
                           u'REG 16/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(458, 118, 102, 223, 22, 3, '29.95', True,
                           u'REG 16/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(459, 127, 102, 224, 23, 4, '120.00', False,
                           u'REG 17/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(460, 127, 102, 224, 24, 3, '120.00', True,
                           u'REG 17/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(461, 116, 102, 225, 25, 21, '5.33', False,
                           u'SREG 9/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(462, 116, 102, 225, 26, 3, '5.33', True,
                           u'SREG 9/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(463, 118, 102, 225, 27, 21, '10.00', False,
                           u'SREG 9/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(464, 118, 102, 225, 28, 3, '10.00', True,
                           u'SREG 9/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(465, 124, 102, 225, 29, 21, '12.50', False,
                           u'SREG 9/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(466, 124, 102, 225, 30, 3, '12.50', True,
                           u'SREG 9/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(467, 127, 102, 225, 31, 21, '25.00', False,
                           u'SREG 9/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(468, 127, 102, 225, 32, 3, '25.00', True,
                           u'SREG 9/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(469, 128, 102, 225, 33, 21, '29.95', False,
                           u'SREG 9/2014', True, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(470, 128, 102, 225, 34, 3, '29.95', True,
                           u'SREG 9/2014', False, date(2014, 2, 21)))
loader.save(
    create_ledger_movement(471, 128, 103, 220, 1, 21, '10.00', False,
                           u'REG 14/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(472, 128, 103, 220, 2, 3, '10.00', True,
                           u'REG 14/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(473, 118, 103, 221, 3, 21, '12.50', False,
                           u'REG 15/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(474, 118, 103, 221, 4, 3, '12.50', True,
                           u'REG 15/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(475, 118, 103, 223, 5, 21, '29.95', False,
                           u'REG 16/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(476, 118, 103, 223, 6, 3, '29.95', True,
                           u'REG 16/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(477, 127, 103, 224, 7, 21, '120.00', False,
                           u'REG 17/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(478, 127, 103, 224, 8, 3, '120.00', True,
                           u'REG 17/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(479, 124, 103, 224, 9, 4, '25.00', False,
                           u'REG 10/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(480, 124, 103, 224, 10, 3, '25.00', True,
                           u'REG 10/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(481, 128, 103, 225, 11, 4, '29.95', False,
                           u'REG 11/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(482, 128, 103, 225, 12, 3, '29.95', True,
                           u'REG 11/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(483, 116, 103, 226, 13, 21, '25.00', False,
                           u'SREG 6/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(484, 116, 103, 226, 14, 3, '25.00', True,
                           u'SREG 6/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(485, 118, 103, 226, 15, 21, '149.95', False,
                           u'SREG 6/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(486, 118, 103, 226, 16, 3, '149.95', True,
                           u'SREG 6/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(487, 124, 103, 226, 17, 21, '125.33', False,
                           u'SREG 6/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(488, 124, 103, 226, 18, 3, '125.33', True,
                           u'SREG 6/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(489, 127, 103, 226, 19, 21, '10.00', False,
                           u'SREG 6/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(490, 127, 103, 226, 20, 3, '10.00', True,
                           u'SREG 6/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(491, 128, 103, 226, 21, 21, '12.50', False,
                           u'SREG 6/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(492, 128, 103, 226, 22, 3, '12.50', True,
                           u'SREG 6/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(493, 128, 103, 227, 23, 4, '5.33', False,
                           u'REG 12/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(494, 128, 103, 227, 24, 3, '5.33', True,
                           u'REG 12/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(495, 118, 103, 228, 25, 4, '10.00', False,
                           u'REG 13/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(496, 118, 103, 228, 26, 3, '10.00', True,
                           u'REG 13/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(497, 116, 103, 229, 27, 21, '29.95', False,
                           u'SREG 7/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(498, 116, 103, 229, 28, 3, '29.95', True,
                           u'SREG 7/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(499, 118, 103, 229, 29, 21, '120.00', False,
                           u'SREG 7/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(500, 118, 103, 229, 30, 3, '120.00', True,
                           u'SREG 7/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(501, 124, 103, 229, 31, 21, '5.33', False,
                           u'SREG 7/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(502, 124, 103, 229, 32, 3, '5.33', True,
                           u'SREG 7/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(503, 127, 103, 229, 33, 21, '12.50', False,
                           u'SREG 7/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(504, 127, 103, 229, 34, 3, '12.50', True,
                           u'SREG 7/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(505, 128, 103, 229, 35, 21, '25.00', False,
                           u'SREG 7/2014', True, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(506, 128, 103, 229, 36, 3, '25.00', True,
                           u'SREG 7/2014', False, date(2014, 3, 21)))
loader.save(
    create_ledger_movement(507, 124, 104, 224, 1, 21, '25.00', False,
                           u'REG 10/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(508, 124, 104, 224, 2, 3, '25.00', True,
                           u'REG 10/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(509, 128, 104, 225, 3, 21, '29.95', False,
                           u'REG 11/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(510, 128, 104, 225, 4, 3, '29.95', True,
                           u'REG 11/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(511, 128, 104, 227, 5, 21, '5.33', False,
                           u'REG 12/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(512, 128, 104, 227, 6, 3, '5.33', True,
                           u'REG 12/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(513, 118, 104, 228, 7, 21, '10.00', False,
                           u'REG 13/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(514, 118, 104, 228, 8, 3, '10.00', True,
                           u'REG 13/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(515, 116, 104, 116, 9, 4, '648.91', True,
                           u'AAW 13:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(516, 116, 104, 116, 10, 3, '648.91', False,
                           u'AAW 13:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(517, 116, 104, 116, 11, 4, '817.36', True,
                           u'AAW 14:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(518, 116, 104, 116, 12, 3, '817.36', False,
                           u'AAW 14:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(519, 116, 104, 116, 13, 4, '544.91', True,
                           u'AAW 15:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(520, 116, 104, 116, 14, 3, '544.91', False,
                           u'AAW 15:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(521, 116, 104, 116, 15, 4, '800.08', True,
                           u'AAW 16:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(522, 116, 104, 116, 16, 3, '800.08', False,
                           u'AAW 16:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(523, 116, 104, 116, 17, 4, '648.91', True,
                           u'AAW 17:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(524, 116, 104, 116, 18, 3, '648.91', False,
                           u'AAW 17:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(525, 116, 104, 116, 19, 4, '817.36', True,
                           u'AAW 18:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(526, 116, 104, 116, 20, 3, '817.36', False,
                           u'AAW 18:1', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(527, 118, 104, 118, 21, 4, '817.36', True,
                           u'AAW 13:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(528, 118, 104, 118, 22, 3, '817.36', False,
                           u'AAW 13:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(529, 118, 104, 118, 23, 4, '544.91', True,
                           u'AAW 14:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(530, 118, 104, 118, 24, 3, '544.91', False,
                           u'AAW 14:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(531, 118, 104, 118, 25, 4, '800.08', True,
                           u'AAW 15:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(532, 118, 104, 118, 26, 3, '800.08', False,
                           u'AAW 15:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(533, 118, 104, 118, 27, 4, '648.91', True,
                           u'AAW 16:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(534, 118, 104, 118, 28, 3, '648.91', False,
                           u'AAW 16:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(535, 118, 104, 118, 29, 4, '817.36', True,
                           u'AAW 17:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(536, 118, 104, 118, 30, 3, '817.36', False,
                           u'AAW 17:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(537, 118, 104, 118, 31, 4, '544.91', True,
                           u'AAW 18:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(538, 118, 104, 118, 32, 3, '544.91', False,
                           u'AAW 18:2', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(539, 124, 104, 124, 33, 4, '544.91', True,
                           u'AAW 13:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(540, 124, 104, 124, 34, 3, '544.91', False,
                           u'AAW 13:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(541, 124, 104, 124, 35, 4, '800.08', True,
                           u'AAW 14:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(542, 124, 104, 124, 36, 3, '800.08', False,
                           u'AAW 14:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(543, 124, 104, 124, 37, 4, '648.91', True,
                           u'AAW 15:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(544, 124, 104, 124, 38, 3, '648.91', False,
                           u'AAW 15:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(545, 124, 104, 124, 39, 4, '817.36', True,
                           u'AAW 16:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(546, 124, 104, 124, 40, 3, '817.36', False,
                           u'AAW 16:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(547, 124, 104, 124, 41, 4, '544.91', True,
                           u'AAW 17:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(548, 124, 104, 124, 42, 3, '544.91', False,
                           u'AAW 17:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(549, 124, 104, 124, 43, 4, '800.08', True,
                           u'AAW 18:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(550, 124, 104, 124, 44, 3, '800.08', False,
                           u'AAW 18:3', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(551, 127, 104, 127, 45, 4, '800.08', True,
                           u'AAW 13:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(552, 127, 104, 127, 46, 3, '800.08', False,
                           u'AAW 13:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(553, 127, 104, 127, 47, 4, '648.91', True,
                           u'AAW 14:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(554, 127, 104, 127, 48, 3, '648.91', False,
                           u'AAW 14:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(555, 127, 104, 127, 49, 4, '817.36', True,
                           u'AAW 15:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(556, 127, 104, 127, 50, 3, '817.36', False,
                           u'AAW 15:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(557, 127, 104, 127, 51, 4, '544.91', True,
                           u'AAW 16:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(558, 127, 104, 127, 52, 3, '544.91', False,
                           u'AAW 16:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(559, 127, 104, 127, 53, 4, '800.08', True,
                           u'AAW 17:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(560, 127, 104, 127, 54, 3, '800.08', False,
                           u'AAW 17:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(561, 127, 104, 127, 55, 4, '648.91', True,
                           u'AAW 18:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(562, 127, 104, 127, 56, 3, '648.91', False,
                           u'AAW 18:4', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(563, 128, 104, 128, 57, 4, '648.91', True,
                           u'AAW 13:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(564, 128, 104, 128, 58, 3, '648.91', False,
                           u'AAW 13:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(565, 128, 104, 128, 59, 4, '817.36', True,
                           u'AAW 14:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(566, 128, 104, 128, 60, 3, '817.36', False,
                           u'AAW 14:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(567, 128, 104, 128, 61, 4, '544.91', True,
                           u'AAW 15:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(568, 128, 104, 128, 62, 3, '544.91', False,
                           u'AAW 15:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(569, 128, 104, 128, 63, 4, '800.08', True,
                           u'AAW 16:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(570, 128, 104, 128, 64, 3, '800.08', False,
                           u'AAW 16:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(571, 128, 104, 128, 65, 4, '648.91', True,
                           u'AAW 17:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(572, 128, 104, 128, 66, 3, '648.91', False,
                           u'AAW 17:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(573, 128, 104, 128, 67, 4, '817.36', True,
                           u'AAW 18:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(574, 128, 104, 128, 68, 3, '817.36', False,
                           u'AAW 18:5', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(575, 116, 104, 220, 69, 21, '22.50', False,
                           u'SREG 4/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(576, 116, 104, 220, 70, 3, '22.50', True,
                           u'SREG 4/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(577, 118, 104, 220, 71, 21, '25.00', False,
                           u'SREG 4/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(578, 118, 104, 220, 72, 3, '25.00', True,
                           u'SREG 4/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(579, 124, 104, 220, 73, 21, '29.95', False,
                           u'SREG 4/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(580, 124, 104, 220, 74, 3, '29.95', True,
                           u'SREG 4/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(581, 127, 104, 220, 75, 21, '120.00', False,
                           u'SREG 4/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(582, 127, 104, 220, 76, 3, '120.00', True,
                           u'SREG 4/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(583, 128, 104, 220, 77, 21, '15.33', False,
                           u'SREG 4/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(584, 128, 104, 220, 78, 3, '15.33', True,
                           u'SREG 4/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(585, 124, 104, 221, 79, 4, '12.50', False,
                           u'REG 8/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(586, 124, 104, 221, 80, 3, '12.50', True,
                           u'REG 8/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(587, 128, 104, 222, 81, 4, '25.00', False,
                           u'REG 9/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(588, 128, 104, 222, 82, 3, '25.00', True,
                           u'REG 9/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(589, 116, 104, 223, 83, 21, '12.50', False,
                           u'SREG 5/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(590, 116, 104, 223, 84, 3, '12.50', True,
                           u'SREG 5/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(591, 118, 104, 223, 85, 21, '29.95', False,
                           u'SREG 5/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(592, 118, 104, 223, 86, 3, '29.95', True,
                           u'SREG 5/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(593, 124, 104, 223, 87, 21, '120.00', False,
                           u'SREG 5/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(594, 124, 104, 223, 88, 3, '120.00', True,
                           u'SREG 5/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(595, 127, 104, 223, 89, 21, '5.33', False,
                           u'SREG 5/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(596, 127, 104, 223, 90, 3, '5.33', True,
                           u'SREG 5/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(597, 128, 104, 223, 91, 21, '10.00', False,
                           u'SREG 5/2014', True, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(598, 128, 104, 223, 92, 3, '10.00', True,
                           u'SREG 5/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(599, 116, 104, 228, 93, 4, '120.00', False,
                           u'REG 6/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(600, 116, 104, 228, 94, 3, '120.00', True,
                           u'REG 6/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(601, 124, 104, 229, 95, 4, '5.33', False,
                           u'REG 7/2014', False, date(2014, 4, 21)))
loader.save(
    create_ledger_movement(602, 124, 104, 229, 96, 3, '5.33', True,
                           u'REG 7/2014', False, date(2014, 4, 21)))

loader.flush_deferred_objects()

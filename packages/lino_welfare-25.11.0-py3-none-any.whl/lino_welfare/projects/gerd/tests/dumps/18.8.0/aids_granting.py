# -*- coding: UTF-8 -*-
logger.info("Loading 58 objects to table aids_granting...")
# fields: id, start_date, end_date, user, decision_date, board, signer, state, client, aid_type, category, request_date
loader.save(
    create_aids_granting(1, date(2012, 9, 29), None, None, None, None, 9,
                         u'01', 116, 1, None, None))
loader.save(
    create_aids_granting(2, date(2013, 8, 8), None, None, None, None, 9, u'01',
                         116, 2, None, None))
loader.save(
    create_aids_granting(3, date(2012, 10, 9), None, None, None, None, 4,
                         u'01', 124, 1, None, None))
loader.save(
    create_aids_granting(4, date(2012, 10, 19), None, None, None, None, 5,
                         u'01', 127, 2, None, None))
loader.save(
    create_aids_granting(5, date(2014, 2, 12), None, None, None, None, 5,
                         u'01', 127, 1, None, None))
loader.save(
    create_aids_granting(6, date(2014, 3, 15), None, None, None, None, 5,
                         u'01', 127, 2, None, None))
loader.save(
    create_aids_granting(7, date(2012, 10, 29), None, None, None, None, 4,
                         u'01', 129, 1, None, None))
loader.save(
    create_aids_granting(8, date(2014, 2, 22), None, None, None, None, 4,
                         u'01', 129, 2, None, None))
loader.save(
    create_aids_granting(9, date(2012, 11, 8), None, None, None, None, 4,
                         u'01', 132, 1, None, None))
loader.save(
    create_aids_granting(10, date(2012, 11, 18), None, None, None, None, 5,
                         u'01', 137, 2, None, None))
loader.save(
    create_aids_granting(11, date(2012, 11, 28), None, None, None, None, 4,
                         u'01', 141, 1, None, None))
loader.save(
    create_aids_granting(12, date(2012, 12, 8), None, None, None, None, 4,
                         u'01', 144, 2, None, None))
loader.save(
    create_aids_granting(13, date(2014, 4, 3), None, None, None, None, 4,
                         u'01', 144, 1, None, None))
loader.save(
    create_aids_granting(14, date(2012, 12, 18), None, None, None, None, 4,
                         u'01', 147, 2, None, None))
loader.save(
    create_aids_granting(15, date(2014, 4, 13), None, None, None, None, 4,
                         u'01', 147, 1, None, None))
loader.save(
    create_aids_granting(16, date(2014, 5, 14), None, None, None, None, 4,
                         u'01', 147, 2, None, None))
loader.save(
    create_aids_granting(17, date(2012, 12, 28), None, None, None, None, 4,
                         u'01', 153, 1, None, None))
loader.save(
    create_aids_granting(18, date(2013, 1, 7), None, None, None, None, 5,
                         u'01', 157, 2, None, None))
loader.save(
    create_aids_granting(19, date(2013, 1, 17), None, None, None, None, 4,
                         u'01', 159, 1, None, None))
loader.save(
    create_aids_granting(20, date(2014, 5, 13), None, None, None, None, 4,
                         u'01', 159, 2, None, None))
loader.save(
    create_aids_granting(21, date(2014, 6, 13), None, None, None, None, 4,
                         u'01', 159, 1, None, None))
loader.save(
    create_aids_granting(22, date(2013, 1, 27), None, None, None, None, 6,
                         u'01', 165, 2, None, None))
loader.save(
    create_aids_granting(23, date(2014, 5, 23), None, None, None, None, 6,
                         u'01', 165, 1, None, None))
loader.save(
    create_aids_granting(24, date(2013, 2, 6), None, None, None, None, 5,
                         u'01', 168, 2, None, None))
loader.save(
    create_aids_granting(25, date(2014, 6, 2), None, None, None, None, 5,
                         u'01', 168, 1, None, None))
loader.save(
    create_aids_granting(26, date(2014, 7, 3), None, None, None, None, 5,
                         u'01', 168, 2, None, None))
loader.save(
    create_aids_granting(27, date(2013, 2, 16), None, None, None, None, 4,
                         u'01', 177, 1, None, None))
loader.save(
    create_aids_granting(28, date(2014, 6, 12), None, None, None, None, 4,
                         u'01', 177, 2, None, None))
loader.save(
    create_aids_granting(29, date(2013, 2, 26), None, None, None, None, 6,
                         u'01', 179, 1, None, None))
loader.save(
    create_aids_granting(30, date(2014, 6, 22), None, None, None, None, 6,
                         u'01', 179, 2, None, None))
loader.save(
    create_aids_granting(31, date(2014, 7, 23), None, None, None, None, 6,
                         u'01', 179, 1, None, None))
loader.save(
    create_aids_granting(32, date(2013, 3, 8), None, None, None, None, 5,
                         u'01', 181, 2, None, None))
loader.save(
    create_aids_granting(33, date(2014, 7, 2), None, None, None, None, 5,
                         u'01', 181, 1, None, None))
loader.save(
    create_aids_granting(34, date(2014, 5, 22), None, None, date(2014, 5, 21),
                         1, 9, u'01', 116, 1, None, None))
loader.save(
    create_aids_granting(35, date(2014, 5, 22), date(2014, 5, 23), None,
                         date(2014, 5, 21), 2, 5, u'02', 118, 1, None, None))
loader.save(
    create_aids_granting(36, date(2014, 5, 23), date(2014, 5, 24), None,
                         date(2014, 5, 22), 3, 4, u'01', 124, 2, None, None))
loader.save(
    create_aids_granting(37, date(2014, 5, 23), date(2014, 6, 22), None,
                         date(2014, 5, 22), 1, 5, u'02', 127, 2, None, None))
loader.save(
    create_aids_granting(38, date(2014, 5, 24), date(2014, 5, 24), None,
                         date(2014, 5, 23), 2, 5, u'01', 128, 3, None, None))
loader.save(
    create_aids_granting(39, date(2014, 5, 24), None, None, date(2014, 5, 23),
                         3, 4, u'02', 129, 3, None, None))
loader.save(
    create_aids_granting(40, date(2014, 5, 25), date(2015, 5, 25), None,
                         date(2014, 5, 24), 1, 9, u'01', 130, 4, None, None))
loader.save(
    create_aids_granting(41, date(2014, 5, 25), None, None, date(2014, 5, 24),
                         2, 4, u'02', 132, 4, None, None))
loader.save(
    create_aids_granting(42, date(2014, 5, 26), date(2014, 5, 27), None,
                         date(2014, 5, 25), 3, 5, u'01', 133, 5, None, None))
loader.save(
    create_aids_granting(43, date(2014, 5, 26), date(2014, 5, 27), None,
                         date(2014, 5, 25), 1, 5, u'02', 137, 5, None, None))
loader.save(
    create_aids_granting(44, date(2014, 5, 27), date(2014, 6, 26), None,
                         date(2014, 5, 26), 2, 5, u'01', 139, 6, None, None))
loader.save(
    create_aids_granting(45, date(2014, 5, 27), date(2014, 5, 27), None,
                         date(2014, 5, 26), 3, 4, u'02', 141, 6, None, None))
loader.save(
    create_aids_granting(46, date(2014, 5, 28), None, None, date(2014, 5, 27),
                         1, 5, u'01', 142, 7, None, None))
loader.save(
    create_aids_granting(47, date(2014, 5, 28), date(2015, 5, 28), None,
                         date(2014, 5, 27), 2, 4, u'02', 144, 7, None, None))
loader.save(
    create_aids_granting(48, date(2014, 5, 29), None, None, date(2014, 5, 28),
                         3, 5, u'01', 146, 8, None, None))
loader.save(
    create_aids_granting(49, date(2014, 5, 29), date(2014, 5, 30), None,
                         date(2014, 5, 28), 1, 4, u'02', 147, 8, None, None))
loader.save(
    create_aids_granting(50, date(2014, 5, 30), date(2014, 5, 31), None,
                         date(2014, 5, 29), 2, 6, u'01', 152, 9, None, None))
loader.save(
    create_aids_granting(51, date(2014, 5, 30), date(2014, 6, 29), None,
                         date(2014, 5, 29), 3, 4, u'02', 153, 9, None, None))
loader.save(
    create_aids_granting(52, date(2014, 5, 31), date(2014, 5, 31), None,
                         date(2014, 5, 30), 1, None, u'01', 155, 10, None,
                         None))
loader.save(
    create_aids_granting(53, date(2014, 5, 31), None, None, date(2014, 5, 30),
                         2, None, u'01', 157, 10, None, None))
loader.save(
    create_aids_granting(54, date(2014, 6, 1), date(2015, 6, 1), None,
                         date(2014, 5, 31), 3, 4, u'01', 159, 11, None, None))
loader.save(
    create_aids_granting(55, date(2014, 6, 1), None, None, date(2014, 5, 31),
                         1, 5, u'02', 161, 11, None, None))
loader.save(
    create_aids_granting(56, date(2014, 5, 27), date(2014, 6, 26), None, None,
                         None, 5, u'01', 139, 7, None, None))
loader.save(
    create_aids_granting(57, date(2014, 5, 27), date(2014, 5, 27), None, None,
                         None, 4, u'01', 141, 7, None, None))
loader.save(
    create_aids_granting(58, date(2014, 5, 22), None, None, None, None, None,
                         u'01', 240, 11, None, None))

loader.flush_deferred_objects()

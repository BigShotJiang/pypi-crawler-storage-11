# -*- coding: UTF-8 -*-
logger.info("Loading 111 objects to table notes_note...")
# fields: id, project, build_time, build_method, user, owner_type, owner_id, company, contact_person, contact_role, date, time, type, event_type, subject, body, language, important
loader.save(
    create_notes_note(1, None, None, u'appypdf', 8,
                      None, None, None, None, None, date(2014, 5, 22),
                      time(8, 7, 36), None, None, u'', u'', u'', False))
loader.save(
    create_notes_note(2, None, None, u'appypdf', 6,
                      None, None, None, None, None, date(2014, 5, 23),
                      time(8, 7, 36), None, None, u'    Erstgespr\xe4ch', u'',
                      u'', False))
loader.save(
    create_notes_note(3, None, None, u'appypdf', 9,
                      None, None, None, None, None, date(2014, 5, 24),
                      time(8, 7, 36), None, None, u'    Versammlung beim AG',
                      u'', u'', False))
loader.save(
    create_notes_note(4, None, None, u'appypdf', 5,
                      None, None, None, None, None, date(2014, 5, 25),
                      time(8, 7, 36), None, None, u'    Zwischenbericht', u'',
                      u'', False))
loader.save(
    create_notes_note(5, None, None, u'appypdf', 10,
                      None, None, None, None, None, date(2014, 5, 26),
                      time(8, 7, 36), None, None, u'    Krisensitzung', u'',
                      u'', False))
loader.save(
    create_notes_note(6, None, None, u'appypdf', 4,
                      None, None, None, None, None, date(2014, 5, 27),
                      time(8, 7, 36), None, None, u'    ', u'', u'', False))
loader.save(
    create_notes_note(7, None, None, u'appypdf', 11,
                      None, None, None, None, None, date(2014, 5, 28),
                      time(8, 7, 36), None, None, u'', u'', u'', False))
loader.save(
    create_notes_note(8, None, None, u'appypdf', 2,
                      None, None, None, None, None, date(2014, 5, 29),
                      time(8, 7, 36), None, None, u'    Erstgespr\xe4ch', u'',
                      u'', False))
loader.save(
    create_notes_note(9, None, None, u'appypdf', 1,
                      None, None, None, None, None, date(2014, 5, 30),
                      time(8, 7, 36), None, None, u'    Versammlung beim AG',
                      u'', u'', False))
loader.save(
    create_notes_note(10, None, None, u'appypdf', 3,
                      None, None, None, None, None, date(2014, 5, 31),
                      time(8, 7, 36), None, None, u'    Zwischenbericht', u'',
                      u'', False))
loader.save(
    create_notes_note(11, 116, None, u'appypdf', 8,
                      None, None, None, None, None, date(2013, 4, 17),
                      time(8, 8,
                           8), 1, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(12, 117, None, u'appypdf', 6,
                      None, None, None, None, None, date(2013, 4, 18),
                      time(8, 8, 8), 2, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(13, 118, None, u'appypdf', 9, None, None, None, None,
                      None, date(2013, 4, 19), time(8, 8, 8), 3, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(14, 120, None, u'appypdf', 5,
                      None, None, None, None, None, date(2013, 4, 20),
                      time(8, 8, 8), 4, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(15, 121, None, u'appypdf', 10,
                      None, None, None, None, None, date(2013, 4, 21),
                      time(8, 8,
                           8), 5, None, u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(16, 122, None, u'appypdf', 13,
                      None, None, None, None, None, date(2013, 4, 22),
                      time(8, 8, 8), 6, None, u'Appointment with RCycle', u'',
                      u'', False))
loader.save(
    create_notes_note(17, 123, None, u'appypdf', 4,
                      None, None, None, None, None, date(2013, 4, 23),
                      time(8, 8, 8), 7, None, u'Storniert', u'', u'', False))
loader.save(
    create_notes_note(18, 124, None, u'rtf', 11, None, None, None, None, None,
                      date(2013, 4, 24), time(8, 8, 8), 8, None,
                      u'Apologized via SMS', u'', u'', False))
loader.save(
    create_notes_note(19, 125, None, u'appypdf', 2,
                      None, None, None, None, None, date(2013, 4, 25),
                      time(8, 8,
                           8), 9, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(20, 126, None, u'appyrtf', 1,
                      None, None, None, None, None, date(2013, 4, 26),
                      time(8, 8, 8), 10, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(21, 116, None, u'appypdf', 3, None, None, None, None,
                      None, date(2013, 4, 27), time(8, 8, 8), 11, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(22, 117, None, u'appypdf', 7,
                      None, None, None, None, None, date(2013, 4, 28),
                      time(8, 8, 8), 1, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(23, 118, None, u'appypdf', 12,
                      None, None, None, None, None, date(2013, 4, 29),
                      time(8, 8,
                           8), 2, None, u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(24, 120, None, u'appypdf', 8,
                      None, None, None, None, None, date(2013, 4, 30),
                      time(8, 8, 8), 3, None, u'Appointment with RCycle', u'',
                      u'', False))
loader.save(
    create_notes_note(25, 121, None, u'appypdf', 6,
                      None, None, None, None, None, date(2013, 5, 1),
                      time(8, 8, 8), 4, None, u'Storniert', u'', u'', False))
loader.save(
    create_notes_note(26, 122, None, u'appypdf', 9,
                      None, None, None, None, None, date(2013, 5, 2),
                      time(8, 8, 8), 5, None, u'Apologized via SMS', u'', u'',
                      False))
loader.save(
    create_notes_note(27, 123, None, u'appypdf', 5,
                      None, None, None, None, None, date(2013, 5, 3),
                      time(8, 8,
                           8), 6, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(28, 124, None, u'appypdf', 10,
                      None, None, None, None, None, date(2013, 5, 4),
                      time(8, 8, 8), 7, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(29, 125, None, u'rtf', 13, None, None, None, None, None,
                      date(2013, 5, 5), time(8, 8, 8), 8, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(30, 126, None, u'appypdf', 4,
                      None, None, None, None, None, date(2013, 5, 6),
                      time(8, 8, 8), 9, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(31, 116, None, u'appyrtf', 11,
                      None, None, None, None, None, date(2013, 5, 7),
                      time(8, 8,
                           8), 10, None, u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(32, 117, None, u'appypdf', 2,
                      None, None, None, None, None, date(2013, 5, 8),
                      time(8, 8, 8), 11, None, u'Appointment with RCycle', u'',
                      u'', False))
loader.save(
    create_notes_note(33, 118, None, u'appypdf', 1,
                      None, None, None, None, None, date(2013, 5, 9),
                      time(8, 8, 8), 1, None, u'Storniert', u'', u'', False))
loader.save(
    create_notes_note(34, 120, None, u'appypdf', 3,
                      None, None, None, None, None, date(2013, 5, 10),
                      time(8, 8, 8), 2, None, u'Apologized via SMS', u'', u'',
                      False))
loader.save(
    create_notes_note(35, 121, None, u'appypdf', 7,
                      None, None, None, None, None, date(2013, 5, 11),
                      time(8, 8,
                           8), 3, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(36, 122, None, u'appypdf', 12,
                      None, None, None, None, None, date(2013, 5, 12),
                      time(8, 8, 8), 4, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(37, 123, None, u'appypdf', 8, None, None, None, None,
                      None, date(2013, 5, 13), time(8, 8, 8), 5, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(38, 124, None, u'appypdf', 6,
                      None, None, None, None, None, date(2013, 5, 14),
                      time(8, 8, 8), 6, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(39, 125, None, u'appypdf', 9,
                      None, None, None, None, None, date(2013, 5, 15),
                      time(8, 8,
                           8), 7, None, u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(40, 126, None, u'rtf', 5, None, None, None, None, None,
                      date(2013, 5, 16), time(8, 8, 8), 8, None,
                      u'Appointment with RCycle', u'', u'', False))
loader.save(
    create_notes_note(41, 116, None, u'appypdf', 10,
                      None, None, None, None, None, date(2013, 5, 17),
                      time(8, 8, 8), 9, None, u'Storniert', u'', u'', False))
loader.save(
    create_notes_note(42, 117, None, u'appyrtf', 13,
                      None, None, None, None, None, date(2013, 5, 18),
                      time(8, 8, 8), 10, None, u'Apologized via SMS', u'', u'',
                      False))
loader.save(
    create_notes_note(43, 118, None, u'appypdf', 4,
                      None, None, None, None, None, date(2013, 5, 19),
                      time(8, 8,
                           8), 11, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(44, 120, None, u'appypdf', 11,
                      None, None, None, None, None, date(2013, 5, 20),
                      time(8, 8, 8), 1, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(45, 121, None, u'appypdf', 2, None, None, None, None,
                      None, date(2013, 5, 21), time(8, 8, 8), 2, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(46, 122, None, u'appypdf', 1,
                      None, None, None, None, None, date(2013, 5, 22),
                      time(8, 8, 8), 3, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(47, 123, None, u'appypdf', 3,
                      None, None, None, None, None, date(2013, 5, 23),
                      time(8, 8,
                           8), 4, None, u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(48, 124, None, u'appypdf', 7,
                      None, None, None, None, None, date(2013, 5, 24),
                      time(8, 8, 8), 5, None, u'Appointment with RCycle', u'',
                      u'', False))
loader.save(
    create_notes_note(49, 125, None, u'appypdf', 12,
                      None, None, None, None, None, date(2013, 5, 25),
                      time(8, 8, 8), 6, None, u'Storniert', u'', u'', False))
loader.save(
    create_notes_note(50, 126, None, u'appypdf', 8,
                      None, None, None, None, None, date(2013, 5, 26),
                      time(8, 8, 8), 7, None, u'Apologized via SMS', u'', u'',
                      False))
loader.save(
    create_notes_note(51, 116, None, u'rtf', 6, None, None, None, None, None,
                      date(2013, 5, 27), time(8, 8, 8), 8, None,
                      u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(52, 117, None, u'appypdf', 9,
                      None, None, None, None, None, date(2013, 5, 28),
                      time(8, 8, 8), 9, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(53, 118, None, u'appyrtf', 5, None, None, None, None,
                      None, date(2013, 5, 29), time(8, 8, 8), 10, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(54, 120, None, u'appypdf', 10,
                      None, None, None, None, None, date(2013, 5, 30),
                      time(8, 8, 8), 11, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(55, 121, None, u'appypdf', 13,
                      None, None, None, None, None, date(2013, 5, 31),
                      time(8, 8,
                           8), 1, None, u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(56, 122, None, u'appypdf', 4,
                      None, None, None, None, None, date(2013, 6, 1),
                      time(8, 8, 8), 2, None, u'Appointment with RCycle', u'',
                      u'', False))
loader.save(
    create_notes_note(57, 123, None, u'appypdf', 11,
                      None, None, None, None, None, date(2013, 6, 2),
                      time(8, 8, 8), 3, None, u'Storniert', u'', u'', False))
loader.save(
    create_notes_note(58, 124, None, u'appypdf', 2,
                      None, None, None, None, None, date(2013, 6, 3),
                      time(8, 8, 8), 4, None, u'Apologized via SMS', u'', u'',
                      False))
loader.save(
    create_notes_note(59, 125, None, u'appypdf', 1,
                      None, None, None, None, None, date(2013, 6, 4),
                      time(8, 8,
                           8), 5, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(60, 126, None, u'appypdf', 3,
                      None, None, None, None, None, date(2013, 6, 5),
                      time(8, 8, 8), 6, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(61, 116, None, u'appypdf', 7, None, None, None, None,
                      None, date(2013, 6, 6), time(8, 8, 8), 7, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(62, 117, None, u'rtf', 12, None, None, None, None, None,
                      date(2013, 6, 7), time(8, 8, 8), 8, None, u'More ideas',
                      u'', u'', False))
loader.save(
    create_notes_note(63, 118, None, u'appypdf', 8,
                      None, None, None, None, None, date(2013, 6, 8),
                      time(8, 8,
                           8), 9, None, u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(64, 120, None, u'appyrtf', 6,
                      None, None, None, None, None, date(2013, 6, 9),
                      time(8, 8, 8), 10, None, u'Appointment with RCycle', u'',
                      u'', False))
loader.save(
    create_notes_note(65, 121, None, u'appypdf', 9,
                      None, None, None, None, None, date(2013, 6, 10),
                      time(8, 8, 8), 11, None, u'Storniert', u'', u'', False))
loader.save(
    create_notes_note(66, 122, None, u'appypdf', 5,
                      None, None, None, None, None, date(2013, 6, 11),
                      time(8, 8, 8), 1, None, u'Apologized via SMS', u'', u'',
                      False))
loader.save(
    create_notes_note(67, 123, None, u'appypdf', 10,
                      None, None, None, None, None, date(2013, 6, 12),
                      time(8, 8,
                           8), 2, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(68, 124, None, u'appypdf', 13,
                      None, None, None, None, None, date(2013, 6, 13),
                      time(8, 8, 8), 3, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(69, 125, None, u'appypdf', 4, None, None, None, None,
                      None, date(2013, 6, 14), time(8, 8, 8), 4, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(70, 126, None, u'appypdf', 11,
                      None, None, None, None, None, date(2013, 6, 15),
                      time(8, 8, 8), 5, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(71, 116, None, u'appypdf', 2,
                      None, None, None, None, None, date(2013, 6, 16),
                      time(8, 8,
                           8), 6, None, u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(72, 117, None, u'appypdf', 1,
                      None, None, None, None, None, date(2013, 6, 17),
                      time(8, 8, 8), 7, None, u'Appointment with RCycle', u'',
                      u'', False))
loader.save(
    create_notes_note(73, 118, None, u'rtf', 3, None, None, None, None, None,
                      date(2013, 6, 18), time(8, 8, 8), 8, None, u'Storniert',
                      u'', u'', False))
loader.save(
    create_notes_note(74, 120, None, u'appypdf', 7,
                      None, None, None, None, None, date(2013, 6, 19),
                      time(8, 8, 8), 9, None, u'Apologized via SMS', u'', u'',
                      False))
loader.save(
    create_notes_note(75, 121, None, u'appyrtf', 12,
                      None, None, None, None, None, date(2013, 6, 20),
                      time(8, 8,
                           8), 10, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(76, 122, None, u'appypdf', 8,
                      None, None, None, None, None, date(2013, 6, 21),
                      time(8, 8, 8), 11, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(77, 123, None, u'appypdf', 6, None, None, None, None,
                      None, date(2013, 6, 22), time(8, 8, 8), 1, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(78, 124, None, u'appypdf', 9,
                      None, None, None, None, None, date(2013, 6, 23),
                      time(8, 8, 8), 2, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(79, 125, None, u'appypdf', 5,
                      None, None, None, None, None, date(2013, 6, 24),
                      time(8, 8,
                           8), 3, None, u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(80, 126, None, u'appypdf', 10,
                      None, None, None, None, None, date(2013, 6, 25),
                      time(8, 8, 8), 4, None, u'Appointment with RCycle', u'',
                      u'', False))
loader.save(
    create_notes_note(81, 116, None, u'appypdf', 13,
                      None, None, None, None, None, date(2013, 6, 26),
                      time(8, 8, 8), 5, None, u'Storniert', u'', u'', False))
loader.save(
    create_notes_note(82, 117, None, u'appypdf', 4,
                      None, None, None, None, None, date(2013, 6, 27),
                      time(8, 8, 8), 6, None, u'Apologized via SMS', u'', u'',
                      False))
loader.save(
    create_notes_note(83, 118, None, u'appypdf', 11,
                      None, None, None, None, None, date(2013, 6, 28),
                      time(8, 8,
                           8), 7, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(84, 120, None, u'rtf', 2, None, None, None, None, None,
                      date(2013, 6, 29), time(8, 8, 8), 8, None, u'Ideas', u'',
                      u'', False))
loader.save(
    create_notes_note(85, 121, None, u'appypdf', 1, None, None, None, None,
                      None, date(2013, 6, 30), time(8, 8, 8), 9, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(86, 122, None, u'appyrtf', 3,
                      None, None, None, None, None, date(2013, 7, 1),
                      time(8, 8, 8), 10, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(87, 123, None, u'appypdf', 7,
                      None, None, None, None, None, date(2013, 7, 2),
                      time(8, 8,
                           8), 11, None, u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(88, 124, None, u'appypdf', 12,
                      None, None, None, None, None, date(2013, 7, 3),
                      time(8, 8, 8), 1, None, u'Appointment with RCycle', u'',
                      u'', False))
loader.save(
    create_notes_note(89, 125, None, u'appypdf', 8,
                      None, None, None, None, None, date(2013, 7, 4),
                      time(8, 8, 8), 2, None, u'Storniert', u'', u'', False))
loader.save(
    create_notes_note(90, 126, None, u'appypdf', 6,
                      None, None, None, None, None, date(2013, 7, 5),
                      time(8, 8, 8), 3, None, u'Apologized via SMS', u'', u'',
                      False))
loader.save(
    create_notes_note(91, 116, None, u'appypdf', 9,
                      None, None, None, None, None, date(2013, 7, 6),
                      time(8, 8,
                           8), 4, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(92, 117, None, u'appypdf', 5,
                      None, None, None, None, None, date(2013, 7, 7),
                      time(8, 8, 8), 5, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(93, 118, None, u'appypdf', 10, None, None, None, None,
                      None, date(2013, 7, 8), time(8, 8, 8), 6, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(94, 120, None, u'appypdf', 13,
                      None, None, None, None, None, date(2013, 7, 9),
                      time(8, 8, 8), 7, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(95, 121, None, u'rtf', 4, None, None, None, None, None,
                      date(2013, 7, 10), time(8, 8, 8), 8, None,
                      u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(96, 122, None, u'appypdf', 11,
                      None, None, None, None, None, date(2013, 7, 11),
                      time(8, 8, 8), 9, None, u'Appointment with RCycle', u'',
                      u'', False))
loader.save(
    create_notes_note(97, 123, None, u'appyrtf', 2,
                      None, None, None, None, None, date(2013, 7, 12),
                      time(8, 8, 9), 10, None, u'Storniert', u'', u'', False))
loader.save(
    create_notes_note(98, 124, None, u'appypdf', 1,
                      None, None, None, None, None, date(2013, 7, 13),
                      time(8, 8, 9), 11, None, u'Apologized via SMS', u'', u'',
                      False))
loader.save(
    create_notes_note(99, 125, None, u'appypdf', 3,
                      None, None, None, None, None, date(2013, 7, 14),
                      time(8, 8,
                           9), 1, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(100, 126, None, u'appypdf', 7,
                      None, None, None, None, None, date(2013, 7, 15),
                      time(8, 8, 9), 2, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(101, 116, None, u'appypdf', 12, None, None, None, None,
                      None, date(2013, 7, 16), time(8, 8, 9), 3, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(102, 117, None, u'appypdf', 8,
                      None, None, None, None, None, date(2013, 7, 17),
                      time(8, 8, 9), 4, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(103, 118, None, u'appypdf', 6,
                      None, None, None, None, None, date(2013, 7, 18),
                      time(8, 8,
                           9), 5, None, u'Tried to explain', u'', u'', False))
loader.save(
    create_notes_note(104, 120, None, u'appypdf', 9,
                      None, None, None, None, None, date(2013, 7, 19),
                      time(8, 8, 9), 6, None, u'Appointment with RCycle', u'',
                      u'', False))
loader.save(
    create_notes_note(105, 121, None, u'appypdf', 5,
                      None, None, None, None, None, date(2013, 7, 20),
                      time(8, 8, 9), 7, None, u'Storniert', u'', u'', False))
loader.save(
    create_notes_note(106, 122, None, u'rtf', 10, None, None, None, None, None,
                      date(2013, 7, 21), time(8, 8, 9), 8, None,
                      u'Apologized via SMS', u'', u'', False))
loader.save(
    create_notes_note(107, 123, None, u'appypdf', 13,
                      None, None, None, None, None, date(2013, 7, 22),
                      time(8, 8,
                           9), 9, None, u'Get acquaintaned', u'', u'', False))
loader.save(
    create_notes_note(108, 124, None, u'appyrtf', 4,
                      None, None, None, None, None, date(2013, 7, 23),
                      time(8, 8, 9), 10, None, u'Ideas', u'', u'', False))
loader.save(
    create_notes_note(109, 125, None, u'appypdf', 11, None, None, None, None,
                      None, date(2013, 7, 24), time(8, 8, 9), 11, None,
                      u'Feedback after first working day', u'', u'', False))
loader.save(
    create_notes_note(110, 126, None, u'appypdf', 2,
                      None, None, None, None, None, date(2013, 7, 25),
                      time(8, 8, 9), 1, None, u'More ideas', u'', u'', False))
loader.save(
    create_notes_note(111, 116, None, u'appypdf', 8,
                      None, None, None, None, None, date(2014, 5, 2),
                      time(8, 8, 9), 1, None, u'Keinen Kaffee anbieten', u'',
                      u'', True))

loader.flush_deferred_objects()

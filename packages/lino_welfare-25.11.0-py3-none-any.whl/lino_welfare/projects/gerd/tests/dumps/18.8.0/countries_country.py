# -*- coding: UTF-8 -*-
logger.info("Loading 270 objects to table countries_country...")
# fields: name, isocode, short_code, iso3, inscode, actual_country
loader.save(
    create_countries_country(['Andorra', 'Andorre', 'Andorra'], u'AD', u'',
                             u'AND', u'102', None))
loader.save(
    create_countries_country([
        'Vereinigte Arabische Emirate', '\xc9mirats Arabes Unis',
        'United Arab Emirates'
    ], u'AE', u'', u'ARE', u'260', None))
loader.save(
    create_countries_country(['Afghanistan', 'Afghanistan', 'Afghanistan'],
                             u'AF', u'', u'AFG', u'251', None))
loader.save(
    create_countries_country(
        ['Antigua und Barbuda', 'Antigua-et-Barbuda', 'Antigua and Barbuda'],
        u'AG', u'', u'ATG', u'', None))
loader.save(
    create_countries_country(['Anguilla', 'Anguilla', 'Anguilla'], u'AI', u'',
                             u'AIA', u'', None))
loader.save(
    create_countries_country(['French Afars and Issas', '', ''], u'AIDJ', u'',
                             u'', u'', None))
loader.save(
    create_countries_country(['Albanien', 'Albanie', 'Albania'], u'AL', u'',
                             u'ALB', u'101', None))
loader.save(
    create_countries_country(['Armenien', 'Arm\xe9nie', 'Armenia'], u'AM', u'',
                             u'ARM', u'249', None))
loader.save(
    create_countries_country([
        'Niederl\xe4ndische Antillen', 'Antilles N\xe9erlandaises',
        'Netherlands Antilles'
    ], u'AN', u'', u'ANT', u'482', None))
loader.save(
    create_countries_country(['Angola', 'Angola', 'Angola'], u'AO', u'',
                             u'AGO', u'381', None))
loader.save(
    create_countries_country(['Antarktis', 'Antarctique', 'Antarctica'], u'AQ',
                             u'', u'ATA', u'', None))
loader.save(
    create_countries_country(['Argentinien', 'Argentine', 'Argentina'], u'AR',
                             u'', u'ARG', u'511', None))
loader.save(
    create_countries_country(
        ['Amerikanisch-Samoa', 'Samoa Am\xe9ricaines', 'American Samoa'],
        u'AS', u'', u'ASM', u'', None))
loader.save(
    create_countries_country(['\xd6sterreich', 'Autriche', 'Austria'], u'AT',
                             u'', u'AUT', u'105', None))
loader.save(
    create_countries_country(['Australien', 'Australie', 'Australia'], u'AU',
                             u'', u'AUS', u'611', None))
loader.save(
    create_countries_country(['Aruba', 'Aruba', 'Aruba'], u'AW', u'', u'ABW',
                             u'', None))
loader.save(
    create_countries_country(
        ['\xc5land-Inseln', '\xceles \xc5land', '\xc5land Islands'], u'AX',
        u'', u'ALA', u'', None))
loader.save(
    create_countries_country(['Aserbaidschan', 'Azerba\xefdjan', 'Azerbaijan'],
                             u'AZ', u'', u'AZE', u'250', None))
loader.save(
    create_countries_country([
        'Bosnien und Herzegowina', 'Bosnie-Herz\xe9govine',
        'Bosnia and Herzegovina'
    ], u'BA', u'', u'BIH', u'149', None))
loader.save(
    create_countries_country(['Barbados', 'Barbade', 'Barbados'], u'BB', u'',
                             u'BRB', u'423', None))
loader.save(
    create_countries_country(['Bangladesch', 'Bangladesh', 'Bangladesh'],
                             u'BD', u'', u'BGD', u'237', None))
loader.save(
    create_countries_country(['Belgien', 'Belgique', 'Belgium'], u'BE', u'B',
                             u'BEL', u'150', None))
loader.save(
    create_countries_country(['Burkina Faso', 'Burkina Faso', 'Burkina Faso'],
                             u'BF', u'', u'BFA', u'308', None))
loader.save(
    create_countries_country(['Bulgarien', 'Bulgarie', 'Bulgaria'], u'BG', u'',
                             u'BGR', u'106', None))
loader.save(
    create_countries_country(['Bahrain', 'Bahre\xefn', 'Bahrain'], u'BH', u'',
                             u'BHR', u'268', None))
loader.save(
    create_countries_country(['Burundi', 'Burundi', 'Burundi'], u'BI', u'',
                             u'BDI', u'303', None))
loader.save(
    create_countries_country(['Benin', 'B\xe9nin', 'Benin'], u'BJ', u'',
                             u'BEN', u'310', None))
loader.save(
    create_countries_country(['Bermuda', 'Bermudes', 'Bermuda'], u'BM', u'',
                             u'BMU', u'', None))
loader.save(
    create_countries_country(
        ['Brunei Darussalam', 'Brun\xe9i Darussalam', 'Brunei Darussalam'],
        u'BN', u'', u'BRN', u'224', None))
loader.save(
    create_countries_country(['Bolivien', 'Bolivie', 'Bolivia'], u'BO', u'',
                             u'BOL', u'512', None))
loader.save(
    create_countries_country(['British Antarctic Territory', '', ''], u'BQAQ',
                             u'', u'', u'', None))
loader.save(
    create_countries_country(['Brasilien', 'Br\xe9sil', 'Brazil'], u'BR', u'',
                             u'BRA', u'513', None))
loader.save(
    create_countries_country(['Bahamas', 'Bahamas', 'Bahamas'], u'BS', u'',
                             u'BHS', u'484', None))
loader.save(
    create_countries_country(['Bhutan', 'Bhoutan', 'Bhutan'], u'BT', u'',
                             u'BTN', u'223', None))
loader.save(
    create_countries_country(
        ['Burma, Socialist Republic of the Union of', '', ''], u'BUMM', u'',
        u'', u'', None))
loader.save(
    create_countries_country(['Bouvetinsel', '\xcele Bouvet', 'Bouvet Island'],
                             u'BV', u'', u'BVT', u'', None))
loader.save(
    create_countries_country(['Botswana', 'Botswana', 'Botswana'], u'BW', u'',
                             u'BWA', u'302', None))
loader.save(
    create_countries_country(['Belarus', 'B\xe9larus', 'Belarus'], u'BY', u'',
                             u'BLR', u'142', None))
loader.save(
    create_countries_country(
        ['Byelorussian SSR Soviet Socialist Republic', '', ''], u'BYAA', u'',
        u'', u'', u'BY'))
loader.save(
    create_countries_country(['Belize', 'Belize', 'Belize'], u'BZ', u'',
                             u'BLZ', u'430', None))
loader.save(
    create_countries_country(['Kanada', 'Canada', 'Canada'], u'CA', u'',
                             u'CAN', u'401', None))
loader.save(
    create_countries_country(
        ['Kokosinseln', '\xceles Cocos (Keeling)', 'Cocos (Keeling) Islands'],
        u'CC', u'', u'CCK', u'', None))
loader.save(
    create_countries_country([
        'Demokratische Republik Kongo',
        'R\xe9publique D\xe9mocratique du Congo',
        'The Democratic Republic Of The Congo'
    ], u'CD', u'', u'COD', u'', None))
loader.save(
    create_countries_country([
        'Zentralafrikanische Republik', 'R\xe9publique Centrafricaine',
        'Central African'
    ], u'CF', u'', u'CAF', u'305', None))
loader.save(
    create_countries_country(
        ['Republik Kongo', 'R\xe9publique du Congo', 'Republic of the Congo'],
        u'CG', u'', u'COG', u'', None))
loader.save(
    create_countries_country(['Schweiz', 'Suisse', 'Switzerland'], u'CH', u'',
                             u'CHE', u'127', None))
loader.save(
    create_countries_country(
        ["C\xf4te d'Ivoire", "C\xf4te d'Ivoire", "C\xf4te d'Ivoire"], u'CI',
        u'', u'CIV', u'309', None))
loader.save(
    create_countries_country(['Cookinseln', '\xceles Cook', 'Cook Islands'],
                             u'CK', u'', u'COK', u'', None))
loader.save(
    create_countries_country(['Chile', 'Chili', 'Chile'], u'CL', u'', u'CHL',
                             u'514', None))
loader.save(
    create_countries_country(['Kamerun', 'Cameroun', 'Cameroon'], u'CM', u'',
                             u'CMR', u'304', None))
loader.save(
    create_countries_country(['China', 'Chine', 'China'], u'CN', u'', u'CHN',
                             u'218', None))
loader.save(
    create_countries_country(['Kolumbien', 'Colombie', 'Colombia'], u'CO', u'',
                             u'COL', u'515', None))
loader.save(
    create_countries_country(['Costa Rica', 'Costa Rica', 'Costa Rica'], u'CR',
                             u'', u'CRI', u'411', None))
loader.save(
    create_countries_country([
        'Serbien und Montenegro', 'Serbie-et-Mont\xe9n\xe9gro',
        'Serbia and Montenegro'
    ], u'CS', u'', u'SCG', u'132', None))
loader.save(
    create_countries_country(
        ['Czechoslovakia, Czechoslovak Socialist Republic', '', ''], u'CSHH',
        u'', u'', u'', None))
loader.save(
    create_countries_country(['Canton & Enderbury Islands', '', ''], u'CTKI',
                             u'', u'', u'', None))
loader.save(
    create_countries_country(['Kuba', 'Cuba', 'Cuba'], u'CU', u'', u'CUB',
                             u'412', None))
loader.save(
    create_countries_country(['Kap Verde', 'Cap-vert', 'Cape Verde'], u'CV',
                             u'', u'CPV', u'', None))
loader.save(
    create_countries_country(
        ['Weihnachtsinsel', '\xcele Christmas', 'Christmas Island'], u'CX',
        u'', u'CXR', u'', None))
loader.save(
    create_countries_country(['Zypern', 'Chypre', 'Cyprus'], u'CY', u'',
                             u'CYP', u'107', None))
loader.save(
    create_countries_country([
        'Tschechische Republik', 'R\xe9publique Tch\xe8que', 'Czech Republic'
    ], u'CZ', u'', u'CZE', u'140', None))
loader.save(
    create_countries_country(['German Democratic Republic', '', ''], u'DDDE',
                             u'', u'', u'170', u'DE'))
loader.save(
    create_countries_country(['Deutschland', 'Allemagne', 'Germany'], u'DE',
                             u'D', u'DEU', u'173', None))
loader.save(
    create_countries_country(['German Federal Republic', '', ''], u'DEDE', u'',
                             u'', u'103', u'DE'))
loader.save(
    create_countries_country(['Dschibuti', 'Djibouti', 'Djibouti'], u'DJ', u'',
                             u'DJI', u'', None))
loader.save(
    create_countries_country(['D\xe4nemark', 'Danemark', 'Denmark'], u'DK',
                             u'', u'DNK', u'108', None))
loader.save(
    create_countries_country(['Dominica', 'Dominique', 'Dominica'], u'DM', u'',
                             u'DMA', u'', None))
loader.save(
    create_countries_country([
        'Dominikanische Republik', 'R\xe9publique Dominicaine',
        'Dominican Republic'
    ], u'DO', u'', u'DOM', u'420', None))
loader.save(
    create_countries_country(['Dahomey', '', ''], u'DYBJ', u'', u'', u'',
                             None))
loader.save(
    create_countries_country(['Algerien', 'Alg\xe9rie', 'Algeria'], u'DZ', u'',
                             u'DZA', u'351', None))
loader.save(
    create_countries_country(['Ecuador', '\xc9quateur', 'Ecuador'], u'EC', u'',
                             u'ECU', u'516', None))
loader.save(
    create_countries_country(['Estland', 'Estonie', 'Estonia'], u'EE', u'',
                             u'EST', u'136', None))
loader.save(
    create_countries_country(['\xc4gypten', '\xc9gypte', 'Egypt'], u'EG', u'',
                             u'EGY', u'352', None))
loader.save(
    create_countries_country(
        ['Westsahara', 'Sahara Occidental', 'Western Sahara'], u'EH', u'',
        u'ESH', u'388', None))
loader.save(
    create_countries_country(['Eritrea', '\xc9rythr\xe9e', 'Eritrea'], u'ER',
                             u'', u'ERI', u'349', None))
loader.save(
    create_countries_country(['Spanien', 'Espagne', 'Spain'], u'ES', u'',
                             u'ESP', u'109', None))
loader.save(
    create_countries_country(['\xc4thiopien', '\xc9thiopie', 'Ethiopia'],
                             u'ET', u'', u'ETH', u'311', None))
loader.save(
    create_countries_country(['Finnland', 'Finlande', 'Finland'], u'FI', u'',
                             u'FIN', u'110', None))
loader.save(
    create_countries_country(['Fidschi', 'Fidji', 'Fiji'], u'FJ', u'', u'FJI',
                             u'617', None))
loader.save(
    create_countries_country(
        ['Falklandinseln', '\xceles (malvinas) Falkland', 'Falkland Islands'],
        u'FK', u'', u'FLK', u'', None))
loader.save(
    create_countries_country([
        'Mikronesien', '\xc9tats F\xe9d\xe9r\xe9s de Micron\xe9sie',
        'Federated States of Micronesia'
    ], u'FM', u'', u'FSM', u'', None))
loader.save(
    create_countries_country(
        ['F\xe4r\xf6er', '\xceles F\xe9ro\xe9', 'Faroe Islands'], u'FO', u'',
        u'FRO', u'', None))
loader.save(
    create_countries_country([
        'French Southern and Antarctic Territories (now split between AQ and TF)',
        '', ''
    ], u'FQHH', u'', u'', u'', None))
loader.save(
    create_countries_country(['Frankreich', 'France', 'France'], u'FR', u'F',
                             u'FRA', u'111', None))
loader.save(
    create_countries_country(['Gabun', 'Gabon', 'Gabon'], u'GA', u'', u'GAB',
                             u'312', None))
loader.save(
    create_countries_country([
        'Vereinigtes K\xf6nigreich von Gro\xdfbritannien und Nordirland',
        'Royaume-Uni', 'United Kingdom'
    ], u'GB', u'', u'GBR', u'112', None))
loader.save(
    create_countries_country(['Grenada', 'Grenade', 'Grenada'], u'GD', u'',
                             u'GRD', u'426', None))
loader.save(
    create_countries_country(['Georgien', 'G\xe9orgie', 'Georgia'], u'GE', u'',
                             u'GEO', u'253', None))
loader.save(
    create_countries_country([
        'Gilbert & Ellice Islands (now split into Kiribati and Tuvalu)', '', ''
    ], u'GEHH', u'', u'', u'', None))
loader.save(
    create_countries_country(
        ['Franz\xf6sisch-Guayana', 'Guyane Fran\xe7aise', 'French Guiana'],
        u'GF', u'', u'GUF', u'', None))
loader.save(
    create_countries_country(['Ghana', 'Ghana', 'Ghana'], u'GH', u'', u'GHA',
                             u'314', None))
loader.save(
    create_countries_country(['Gibraltar', 'Gibraltar', 'Gibraltar'], u'GI',
                             u'', u'GIB', u'', None))
loader.save(
    create_countries_country(['Gr\xf6nland', 'Groenland', 'Greenland'], u'GL',
                             u'', u'GRL', u'', None))
loader.save(
    create_countries_country(['Gambia', 'Gambie', 'Gambia'], u'GM', u'',
                             u'GMB', u'313', None))
loader.save(
    create_countries_country(['Guinea', 'Guin\xe9e', 'Guinea'], u'GN', u'',
                             u'GIN', u'315', None))
loader.save(
    create_countries_country(['Guadeloupe', 'Guadeloupe', 'Guadeloupe'], u'GP',
                             u'', u'GLP', u'', None))
loader.save(
    create_countries_country([
        '\xc4quatorialguinea', 'Guin\xe9e \xc9quatoriale', 'Equatorial Guinea'
    ], u'GQ', u'', u'GNQ', u'337', None))
loader.save(
    create_countries_country(['Griechenland', 'Gr\xe8ce', 'Greece'], u'GR',
                             u'', u'GRC', u'114', None))
loader.save(
    create_countries_country([
        'S\xfcdgeorgien und die S\xfcdlichen Sandwichinseln',
        'G\xe9orgie du Sud et les \xceles Sandwich du Sud',
        'South Georgia and the South Sandwich Islands'
    ], u'GS', u'', u'SGS', u'', None))
loader.save(
    create_countries_country(['Guatemala', 'Guatemala', 'Guatemala'], u'GT',
                             u'', u'GTM', u'413', None))
loader.save(
    create_countries_country(['Guam', 'Guam', 'Guam'], u'GU', u'', u'GUM', u'',
                             None))
loader.save(
    create_countries_country(
        ['Guinea-Bissau', 'Guin\xe9e-Bissau', 'Guinea-Bissau'], u'GW', u'',
        u'GNB', u'338', None))
loader.save(
    create_countries_country(['Guyana', 'Guyana', 'Guyana'], u'GY', u'',
                             u'GUY', u'521', None))
loader.save(
    create_countries_country(['Hongkong', 'Hong-Kong', 'Hong Kong'], u'HK',
                             u'', u'HKG', u'234', None))
loader.save(
    create_countries_country([
        'Heard und McDonaldinseln', '\xceles Heard et Mcdonald',
        'Heard Island and McDonald Islands'
    ], u'HM', u'', u'HMD', u'', None))
loader.save(
    create_countries_country(['Honduras', 'Honduras', 'Honduras'], u'HN', u'',
                             u'HND', u'414', None))
loader.save(
    create_countries_country(['Kroatien', 'Croatie', 'Croatia'], u'HR', u'',
                             u'HRV', u'146', None))
loader.save(
    create_countries_country(['Haiti', 'Ha\xefti', 'Haiti'], u'HT', u'',
                             u'HTI', u'419', None))
loader.save(
    create_countries_country(['Ungarn', 'Hongrie', 'Hungary'], u'HU', u'',
                             u'HUN', u'138', None))
loader.save(
    create_countries_country(['Upper Volta, Republic of', '', ''], u'HVBF',
                             u'', u'', u'', None))
loader.save(
    create_countries_country(['Indonesien', 'Indon\xe9sie', 'Indonesia'],
                             u'ID', u'', u'IDN', u'208', None))
loader.save(
    create_countries_country(['Irland', 'Irlande', 'Ireland'], u'IE', u'',
                             u'IRL', u'116', None))
loader.save(
    create_countries_country(['Israel', 'Isra\xebl', 'Israel'], u'IL', u'',
                             u'ISR', u'256', None))
loader.save(
    create_countries_country(['Insel Man', '\xcele de Man', 'Isle of Man'],
                             u'IM', u'', u'IMN', u'', None))
loader.save(
    create_countries_country(['Indien', 'Inde', 'India'], u'IN', u'', u'IND',
                             u'207', None))
loader.save(
    create_countries_country([
        'Britisches Territorium im Indischen Ozean',
        "Territoire Britannique de l'Oc\xe9an Indien",
        'British Indian Ocean Territory'
    ], u'IO', u'', u'IOT', u'', None))
loader.save(
    create_countries_country(['Irak', 'Iraq', 'Iraq'], u'IQ', u'', u'IRQ',
                             u'254', None))
loader.save(
    create_countries_country([
        'Islamische Republik Iran', "R\xe9publique Islamique d'Iran",
        'Islamic Republic of Iran'
    ], u'IR', u'', u'IRN', u'', None))
loader.save(
    create_countries_country(['Island', 'Islande', 'Iceland'], u'IS', u'',
                             u'ISL', u'117', None))
loader.save(
    create_countries_country(['Italien', 'Italie', 'Italy'], u'IT', u'',
                             u'ITA', u'128', None))
loader.save(
    create_countries_country(['Jamaika', 'Jama\xefque', 'Jamaica'], u'JM', u'',
                             u'JAM', u'415', None))
loader.save(
    create_countries_country(['Jordanien', 'Jordanie', 'Jordan'], u'JO', u'',
                             u'JOR', u'257', None))
loader.save(
    create_countries_country(['Japan', 'Japon', 'Japan'], u'JP', u'', u'JPN',
                             u'209', None))
loader.save(
    create_countries_country(['Johnston Island', '', ''], u'JTUM', u'', u'',
                             u'', None))
loader.save(
    create_countries_country(['Kenia', 'Kenya', 'Kenya'], u'KE', u'', u'KEN',
                             u'336', None))
loader.save(
    create_countries_country(['Kirgisistan', 'Kirghizistan', 'Kyrgyzstan'],
                             u'KG', u'', u'KGZ', u'226', None))
loader.save(
    create_countries_country(['Kambodscha', 'Cambodge', 'Cambodia'], u'KH',
                             u'', u'KHM', u'211', None))
loader.save(
    create_countries_country(['Kiribati', 'Kiribati', 'Kiribati'], u'KI', u'',
                             u'KIR', u'', None))
loader.save(
    create_countries_country(['Komoren', 'Comores', 'Comoros'], u'KM', u'',
                             u'COM', u'', None))
loader.save(
    create_countries_country([
        'St. Kitts und Nevis', 'Saint-Kitts-et-Nevis', 'Saint Kitts and Nevis'
    ], u'KN', u'', u'KNA', u'', None))
loader.save(
    create_countries_country([
        'Demokratische Volksrepublik Korea',
        'R\xe9publique Populaire D\xe9mocratique de Cor\xe9e',
        "Democratic People's Republic of Korea"
    ], u'KP', u'', u'PRK', u'', None))
loader.save(
    create_countries_country(
        ['Republik Korea', 'R\xe9publique de Cor\xe9e', 'Republic of Korea'],
        u'KR', u'', u'KOR', u'', None))
loader.save(
    create_countries_country(['Kuwait', 'Kowe\xeft', 'Kuwait'], u'KW', u'',
                             u'KWT', u'264', None))
loader.save(
    create_countries_country(
        ['Kaimaninseln', '\xceles Ca\xefmanes', 'Cayman Islands'], u'KY', u'',
        u'CYM', u'', None))
loader.save(
    create_countries_country(['Kasachstan', 'Kazakhstan', 'Kazakhstan'], u'KZ',
                             u'', u'KAZ', u'225', None))
loader.save(
    create_countries_country([
        'Demokratische Volksrepublik Laos',
        'R\xe9publique D\xe9mocratique Populaire Lao',
        "Lao People's Democratic Republic"
    ], u'LA', u'', u'LAO', u'', None))
loader.save(
    create_countries_country(['Libanon', 'Liban', 'Lebanon'], u'LB', u'',
                             u'LBN', u'258', None))
loader.save(
    create_countries_country(['St. Lucia', 'Sainte-Lucie', 'Saint Lucia'],
                             u'LC', u'', u'LCA', u'', None))
loader.save(
    create_countries_country(
        ['Liechtenstein', 'Liechtenstein', 'Liechtenstein'], u'LI', u'',
        u'LIE', u'118', None))
loader.save(
    create_countries_country(['Sri Lanka', 'Sri Lanka', 'Sri Lanka'], u'LK',
                             u'', u'LKA', u'203', None))
loader.save(
    create_countries_country(['Liberia', 'Lib\xe9ria', 'Liberia'], u'LR', u'',
                             u'LBR', u'318', None))
loader.save(
    create_countries_country(['Lesotho', 'Lesotho', 'Lesotho'], u'LS', u'',
                             u'LSO', u'301', None))
loader.save(
    create_countries_country(['Litauen', 'Lituanie', 'Lithuania'], u'LT', u'',
                             u'LTU', u'137', None))
loader.save(
    create_countries_country(['Luxemburg', 'Luxembourg', 'Luxembourg'], u'LU',
                             u'', u'LUX', u'113', None))
loader.save(
    create_countries_country(['Lettland', 'Lettonie', 'Latvia'], u'LV', u'',
                             u'LVA', u'135', None))
loader.save(
    create_countries_country([
        'Libysch-Arabische Dschamahirija', 'Jamahiriya Arabe Libyenne',
        'Libyan Arab Jamahiriya'
    ], u'LY', u'', u'LBY', u'', None))
loader.save(
    create_countries_country(['Marokko', 'Maroc', 'Morocco'], u'MA', u'',
                             u'MAR', u'354', None))
loader.save(
    create_countries_country(['Monaco', 'Monaco', 'Monaco'], u'MC', u'',
                             u'MCO', u'120', None))
loader.save(
    create_countries_country(
        ['Moldawien', 'R\xe9publique de Moldova', 'Republic of Moldova'],
        u'MD', u'', u'MDA', u'', None))
loader.save(
    create_countries_country(['Madagaskar', 'Madagascar', 'Madagascar'], u'MG',
                             u'', u'MDG', u'324', None))
loader.save(
    create_countries_country(
        ['Marshallinseln', '\xceles Marshall', 'Marshall Islands'], u'MH', u'',
        u'MHL', u'', None))
loader.save(
    create_countries_country(['Midway Islands', '', ''], u'MIUM', u'', u'',
                             u'', None))
loader.save(
    create_countries_country([
        'Ehem. jugoslawische Republik Mazedonien',
        "L'ex-R\xe9publique Yougoslave de Mac\xe9doine",
        'The Former Yugoslav Republic of Macedonia'
    ], u'MK', u'', u'MKD', u'', None))
loader.save(
    create_countries_country(['Mali', 'Mali', 'Mali'], u'ML', u'', u'MLI',
                             u'319', None))
loader.save(
    create_countries_country(['Myanmar', 'Myanmar', 'Myanmar'], u'MM', u'',
                             u'MMR', u'', None))
loader.save(
    create_countries_country(['Mongolei', 'Mongolie', 'Mongolia'], u'MN', u'',
                             u'MNG', u'221', None))
loader.save(
    create_countries_country(['Macao', 'Macao', 'Macao'], u'MO', u'', u'MAC',
                             u'', None))
loader.save(
    create_countries_country([
        'N\xf6rdliche Marianen', '\xceles Mariannes du Nord',
        'Northern Mariana Islands'
    ], u'MP', u'', u'MNP', u'', None))
loader.save(
    create_countries_country(['Martinique', 'Martinique', 'Martinique'], u'MQ',
                             u'', u'MTQ', u'', None))
loader.save(
    create_countries_country(['Mauretanien', 'Mauritanie', 'Mauritania'],
                             u'MR', u'', u'MRT', u'355', None))
loader.save(
    create_countries_country(['Montserrat', 'Montserrat', 'Montserrat'], u'MS',
                             u'', u'MSR', u'', None))
loader.save(
    create_countries_country(['Malta', 'Malte', 'Malta'], u'MT', u'', u'MLT',
                             u'119', None))
loader.save(
    create_countries_country(['Mauritius', 'Maurice', 'Mauritius'], u'MU', u'',
                             u'MUS', u'317', None))
loader.save(
    create_countries_country(['Malediven', 'Maldives', 'Maldives'], u'MV', u'',
                             u'MDV', u'222', None))
loader.save(
    create_countries_country(['Malawi', 'Malawi', 'Malawi'], u'MW', u'',
                             u'MWI', u'358', None))
loader.save(
    create_countries_country(['Mexiko', 'Mexique', 'Mexico'], u'MX', u'',
                             u'MEX', u'416', None))
loader.save(
    create_countries_country(['Malaysia', 'Malaisie', 'Malaysia'], u'MY', u'',
                             u'MYS', u'212', None))
loader.save(
    create_countries_country(['Mosambik', 'Mozambique', 'Mozambique'], u'MZ',
                             u'', u'MOZ', u'383', None))
loader.save(
    create_countries_country(['Namibia', 'Namibie', 'Namibia'], u'NA', u'',
                             u'NAM', u'384', None))
loader.save(
    create_countries_country(
        ['Neukaledonien', 'Nouvelle-Cal\xe9donie', 'New Caledonia'], u'NC',
        u'', u'NCL', u'', None))
loader.save(
    create_countries_country(['Niger', 'Niger', 'Niger'], u'NE', u'', u'NER',
                             u'321', None))
loader.save(
    create_countries_country(
        ['Norfolkinsel', '\xcele Norfolk', 'Norfolk Island'], u'NF', u'',
        u'NFK', u'', None))
loader.save(
    create_countries_country(['Nigeria', 'Nig\xe9ria', 'Nigeria'], u'NG', u'',
                             u'NGA', u'322', None))
loader.save(
    create_countries_country(['New Hebrides', '', ''], u'NHVU', u'', u'', u'',
                             None))
loader.save(
    create_countries_country(['Nicaragua', 'Nicaragua', 'Nicaragua'], u'NI',
                             u'', u'NIC', u'417', None))
loader.save(
    create_countries_country(['Niederlande', 'Pays-Bas', 'Netherlands'], u'NL',
                             u'', u'NLD', u'129', None))
loader.save(
    create_countries_country(['Norwegen', 'Norv\xe8ge', 'Norway'], u'NO', u'',
                             u'NOR', u'121', None))
loader.save(
    create_countries_country(['Nepal', 'N\xe9pal', 'Nepal'], u'NP', u'',
                             u'NPL', u'213', None))
loader.save(
    create_countries_country(['Dronning Maud Land', '', ''], u'NQAQ', u'', u'',
                             u'', None))
loader.save(
    create_countries_country(['Nauru', 'Nauru', 'Nauru'], u'NR', u'', u'NRU',
                             u'615', None))
loader.save(
    create_countries_country(
        ['Neutral Zone (formerly between Saudi Arabia & Iraq)', '', ''],
        u'NTHH', u'', u'', u'', None))
loader.save(
    create_countries_country(['Niue', 'Niu\xe9', 'Niue'], u'NU', u'', u'NIU',
                             u'', None))
loader.save(
    create_countries_country(
        ['Neuseeland', 'Nouvelle-Z\xe9lande', 'New Zealand'], u'NZ', u'',
        u'NZL', u'613', None))
loader.save(
    create_countries_country(['Oman', 'Oman', 'Oman'], u'OM', u'', u'OMN',
                             u'266', None))
loader.save(
    create_countries_country(['Panama', 'Panama', 'Panama'], u'PA', u'',
                             u'PAN', u'418', None))
loader.save(
    create_countries_country([
        'Pacific Islands (trust territory) (divided into FM, MH, MP, and PW)',
        '', ''
    ], u'PCHH', u'', u'', u'', None))
loader.save(
    create_countries_country(['Peru', 'P\xe9rou', 'Peru'], u'PE', u'', u'PER',
                             u'518', None))
loader.save(
    create_countries_country([
        'Franz\xf6sisch-Polynesien', 'Polyn\xe9sie Fran\xe7aise',
        'French Polynesia'
    ], u'PF', u'', u'PYF', u'', None))
loader.save(
    create_countries_country([
        'Papua-Neuguinea', 'Papouasie-Nouvelle-Guin\xe9e', 'Papua New Guinea'
    ], u'PG', u'', u'PNG', u'619', None))
loader.save(
    create_countries_country(['Philippinen', 'Philippines', 'Philippines'],
                             u'PH', u'', u'PHL', u'214', None))
loader.save(
    create_countries_country(['Pakistan', 'Pakistan', 'Pakistan'], u'PK', u'',
                             u'PAK', u'259', None))
loader.save(
    create_countries_country(['Polen', 'Pologne', 'Poland'], u'PL', u'',
                             u'POL', u'139', None))
loader.save(
    create_countries_country([
        'St. Pierre und Miquelon', 'Saint-Pierre-et-Miquelon',
        'Saint-Pierre and Miquelon'
    ], u'PM', u'', u'SPM', u'', None))
loader.save(
    create_countries_country(['Pitcairninseln', 'Pitcairn', 'Pitcairn'], u'PN',
                             u'', u'PCN', u'', None))
loader.save(
    create_countries_country(['Puerto Rico', 'Porto Rico', 'Puerto Rico'],
                             u'PR', u'', u'PRI', u'', None))
loader.save(
    create_countries_country([
        'Pal\xe4stinensische Autonomiegebiete',
        'Territoire Palestinien Occup\xe9', 'Occupied Palestinian Territory'
    ], u'PS', u'', u'PSE', u'', None))
loader.save(
    create_countries_country(['Portugal', 'Portugal', 'Portugal'], u'PT', u'',
                             u'PRT', u'123', None))
loader.save(
    create_countries_country(['US Miscellaneous Pacific Islands', '', ''],
                             u'PUUM', u'', u'', u'', None))
loader.save(
    create_countries_country(['Palau', 'Palaos', 'Palau'], u'PW', u'', u'PLW',
                             u'', None))
loader.save(
    create_countries_country(['Paraguay', 'Paraguay', 'Paraguay'], u'PY', u'',
                             u'PRY', u'517', None))
loader.save(
    create_countries_country(['Panama Canal Zone', '', ''], u'PZPA', u'', u'',
                             u'', None))
loader.save(
    create_countries_country(['Katar', 'Qatar', 'Qatar'], u'QA', u'', u'QAT',
                             u'267', None))
loader.save(
    create_countries_country(['R\xe9union', 'R\xe9union', 'R\xe9union'], u'RE',
                             u'', u'REU', u'', None))
loader.save(
    create_countries_country(['Southern Rhodesia', '', ''], u'RHZW', u'', u'',
                             u'', None))
loader.save(
    create_countries_country(['Rum\xe4nien', 'Roumanie', 'Romania'], u'RO',
                             u'', u'ROU', u'124', None))
loader.save(
    create_countries_country([
        'Russische F\xf6deration', 'F\xe9d\xe9ration de Russie',
        'Russian Federation'
    ], u'RU', u'', u'RUS', u'145', None))
loader.save(
    create_countries_country(['Ruanda', 'Rwanda', 'Rwanda'], u'RW', u'',
                             u'RWA', u'', None))
loader.save(
    create_countries_country(
        ['Saudi-Arabien', 'Arabie Saoudite', 'Saudi Arabia'], u'SA', u'',
        u'SAU', u'252', None))
loader.save(
    create_countries_country(
        ['Salomonen', '\xceles Salomon', 'Solomon Islands'], u'SB', u'',
        u'SLB', u'', None))
loader.save(
    create_countries_country(['Seychellen', 'Seychelles', 'Seychelles'], u'SC',
                             u'', u'SYC', u'', None))
loader.save(
    create_countries_country(['Sudan', 'Soudan', 'Sudan'], u'SD', u'', u'SDN',
                             u'356', None))
loader.save(
    create_countries_country(['Schweden', 'Su\xe8de', 'Sweden'], u'SE', u'',
                             u'SWE', u'126', None))
loader.save(
    create_countries_country(['Singapur', 'Singapour', 'Singapore'], u'SG',
                             u'', u'SGP', u'205', None))
loader.save(
    create_countries_country(
        ['St. Helena', 'Sainte-H\xe9l\xe8ne', 'Saint Helena'], u'SH', u'',
        u'SHN', u'', None))
loader.save(
    create_countries_country(['Slowenien', 'Slov\xe9nie', 'Slovenia'], u'SI',
                             u'', u'SVN', u'147', None))
loader.save(
    create_countries_country([
        'Svalbard and Jan Mayen', 'Svalbard et \xcele Jan Mayen',
        'Svalbard and Jan Mayen'
    ], u'SJ', u'', u'SJM', u'', None))
loader.save(
    create_countries_country(['Slowakei', 'Slovaquie', 'Slovakia'], u'SK', u'',
                             u'SVK', u'141', None))
loader.save(
    create_countries_country(['Sikkim', '', ''], u'SKIN', u'', u'', u'', None))
loader.save(
    create_countries_country(['Sierra Leone', 'Sierra Leone', 'Sierra Leone'],
                             u'SL', u'', u'SLE', u'328', None))
loader.save(
    create_countries_country(['San Marino', 'Saint-Marin', 'San Marino'],
                             u'SM', u'', u'SMR', u'125', None))
loader.save(
    create_countries_country(['Senegal', 'S\xe9n\xe9gal', 'Senegal'], u'SN',
                             u'', u'SEN', u'320', None))
loader.save(
    create_countries_country(['Somalia', 'Somalie', 'Somalia'], u'SO', u'',
                             u'SOM', u'329', None))
loader.save(
    create_countries_country(['Suriname', 'Suriname', 'Suriname'], u'SR', u'',
                             u'SUR', u'', None))
loader.save(
    create_countries_country([
        'S\xe3o Tom\xe9 und Pr\xedncipe', 'Sao Tom\xe9-et-Principe',
        'Sao Tome and Principe'
    ], u'ST', u'', u'STP', u'', None))
loader.save(
    create_countries_country(
        ['USSR, Union of Soviet Socialist Republics', '', ''], u'SUHH', u'',
        u'', u'', u'RU'))
loader.save(
    create_countries_country(['El Salvador', 'El Salvador', 'El Salvador'],
                             u'SV', u'', u'SLV', u'421', None))
loader.save(
    create_countries_country([
        'Arabische Republik Syrien', 'R\xe9publique Arabe Syrienne',
        'Syrian Arab Republic'
    ], u'SY', u'', u'SYR', u'', None))
loader.save(
    create_countries_country(['Swasiland', 'Swaziland', 'Swaziland'], u'SZ',
                             u'', u'SWZ', u'395', None))
loader.save(
    create_countries_country([
        'Turks- und Caicosinseln', '\xceles Turks et Ca\xefques',
        'Turks and Caicos Islands'
    ], u'TC', u'', u'TCA', u'', None))
loader.save(
    create_countries_country(['Tschad', 'Tchad', 'Chad'], u'TD', u'', u'TCD',
                             u'333', None))
loader.save(
    create_countries_country([
        'Franz\xf6sische S\xfcd- und Antarktisgebiete',
        'Terres Australes Fran\xe7aises', 'French Southern Territories'
    ], u'TF', u'', u'ATF', u'', None))
loader.save(
    create_countries_country(['Togo', 'Togo', 'Togo'], u'TG', u'', u'TGO',
                             u'334', None))
loader.save(
    create_countries_country(['Thailand', 'Tha\xeflande', 'Thailand'], u'TH',
                             u'', u'THA', u'235', None))
loader.save(
    create_countries_country(['Tadschikistan', 'Tadjikistan', 'Tajikistan'],
                             u'TJ', u'', u'TJK', u'228', None))
loader.save(
    create_countries_country(['Tokelau', 'Tokelau', 'Tokelau'], u'TK', u'',
                             u'TKL', u'', None))
loader.save(
    create_countries_country(['Timor-Leste', 'Timor-Leste', 'Timor-Leste'],
                             u'TL', u'', u'TLS', u'', None))
loader.save(
    create_countries_country(
        ['Turkmenistan', 'Turkm\xe9nistan', 'Turkmenistan'], u'TM', u'',
        u'TKM', u'229', None))
loader.save(
    create_countries_country(['Tunesien', 'Tunisie', 'Tunisia'], u'TN', u'',
                             u'TUN', u'357', None))
loader.save(
    create_countries_country(['Tonga', 'Tonga', 'Tonga'], u'TO', u'', u'TON',
                             u'616', None))
loader.save(
    create_countries_country(['East Timor (was Portuguese Timor)', '', ''],
                             u'TPTL', u'', u'', u'', None))
loader.save(
    create_countries_country(['T\xfcrkei', 'Turquie', 'Turkey'], u'TR', u'',
                             u'TUR', u'262', None))
loader.save(
    create_countries_country(
        ['Trinidad und Tobago', 'Trinit\xe9-et-Tobago', 'Trinidad and Tobago'],
        u'TT', u'', u'TTO', u'422', None))
loader.save(
    create_countries_country(['Tuvalu', 'Tuvalu', 'Tuvalu'], u'TV', u'',
                             u'TUV', u'621', None))
loader.save(
    create_countries_country(['Taiwan', 'Ta\xefwan', 'Taiwan'], u'TW', u'',
                             u'TWN', u'204', None))
loader.save(
    create_countries_country([
        'Vereinigte Republik Tansania', 'R\xe9publique-Unie de Tanzanie',
        'United Republic Of Tanzania'
    ], u'TZ', u'', u'TZA', u'', None))
loader.save(
    create_countries_country(['Ukraine', 'Ukraine', 'Ukraine'], u'UA', u'',
                             u'UKR', u'143', None))
loader.save(
    create_countries_country(['Uganda', 'Ouganda', 'Uganda'], u'UG', u'',
                             u'UGA', u'323', None))
loader.save(
    create_countries_country([
        'Amerikanisch-Ozeanien',
        '\xceles Mineures \xc9loign\xe9es des \xc9tats-Unis',
        'United States Minor Outlying Islands'
    ], u'UM', u'', u'UMI', u'', None))
loader.save(
    create_countries_country(
        ['Vereinigte Staaten von Amerika', '\xc9tats-Unis', 'United States'],
        u'US', u'', u'USA', u'', None))
loader.save(
    create_countries_country(['Uruguay', 'Uruguay', 'Uruguay'], u'UY', u'',
                             u'URY', u'519', None))
loader.save(
    create_countries_country(['Usbekistan', 'Ouzb\xe9kistan', 'Uzbekistan'],
                             u'UZ', u'', u'UZB', u'227', None))
loader.save(
    create_countries_country([
        'Vatikanstadt', 'Saint-Si\xe8ge (\xe9tat de la Cit\xe9 du Vatican)',
        'Vatican City State'
    ], u'VA', u'', u'VAT', u'133', None))
loader.save(
    create_countries_country([
        'St. Vincent und die Grenadinen', 'Saint-Vincent-et-les Grenadines',
        'Saint Vincent and the Grenadines'
    ], u'VC', u'', u'VCT', u'', None))
loader.save(
    create_countries_country(['Viet-Nam, Democratic Republic of', '', ''],
                             u'VDVN', u'', u'', u'', None))
loader.save(
    create_countries_country(['Venezuela', 'Venezuela', 'Venezuela'], u'VE',
                             u'', u'VEN', u'520', None))
loader.save(
    create_countries_country([
        'Britische Jungferninseln', '\xceles Vierges Britanniques',
        'British Virgin Islands'
    ], u'VG', u'', u'VGB', u'', None))
loader.save(
    create_countries_country([
        'Amerikanische Jungferninseln', '\xceles Vierges des \xc9tats-Unis',
        'U.S. Virgin Islands'
    ], u'VI', u'', u'VIR', u'', None))
loader.save(
    create_countries_country(['Vietnam', 'Viet Nam', 'Vietnam'], u'VN', u'',
                             u'VNM', u'', None))
loader.save(
    create_countries_country(['Vanuatu', 'Vanuatu', 'Vanuatu'], u'VU', u'',
                             u'VUT', u'624', None))
loader.save(
    create_countries_country(
        ['Wallis und Futuna', 'Wallis et Futuna', 'Wallis and Futuna'], u'WF',
        u'', u'WLF', u'', None))
loader.save(
    create_countries_country(['Wake Island', '', ''], u'WKUM', u'', u'', u'',
                             None))
loader.save(
    create_countries_country(['Samoa', 'Samoa', 'Samoa'], u'WS', u'', u'WSM',
                             u'', None))
loader.save(
    create_countries_country(
        ["Yemen, Democratic, People's Democratic Republic of", '', ''],
        u'YDYE', u'', u'', u'', None))
loader.save(
    create_countries_country(['Jemen', 'Y\xe9men', 'Yemen'], u'YE', u'',
                             u'YEM', u'', None))
loader.save(
    create_countries_country(['Mayotte', 'Mayotte', 'Mayotte'], u'YT', u'',
                             u'MYT', u'', None))
loader.save(
    create_countries_country(['Yugoslavia, Federal Republic of', '', ''],
                             u'YUCS', u'', u'', u'', None))
loader.save(
    create_countries_country(
        ['S\xfcdafrika', 'Afrique du Sud', 'South Africa'], u'ZA', u'', u'ZAF',
        u'325', None))
loader.save(
    create_countries_country(['Sambia', 'Zambie', 'Zambia'], u'ZM', u'',
                             u'ZMB', u'335', None))
loader.save(
    create_countries_country(['Zaire, Republic of', '', ''], u'ZRCD', u'', u'',
                             u'', None))
loader.save(
    create_countries_country(['Simbabwe', 'Zimbabwe', 'Zimbabwe'], u'ZW', u'',
                             u'ZWE', u'344', None))

loader.flush_deferred_objects()

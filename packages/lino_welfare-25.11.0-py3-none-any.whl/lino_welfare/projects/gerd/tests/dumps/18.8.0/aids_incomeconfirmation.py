# -*- coding: UTF-8 -*-
logger.info("Loading 58 objects to table aids_incomeconfirmation...")
# fields: id, created, start_date, end_date, user, company, contact_person, contact_role, printed_by, signer, state, client, granting, remark, language, category, amount
loader.save(
    create_aids_incomeconfirmation(1, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 9,
                                        29), None, 6, None, None, None, 3, 9,
                                   u'01', 116, 1, u'', u'de', 1, '123.00'))
loader.save(
    create_aids_incomeconfirmation(2, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 8,
                                        8), None, 9, None, None, None, None, 9,
                                   u'02', 116, 2, u'', u'de', 2, '234.00'))
loader.save(
    create_aids_incomeconfirmation(3, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 8,
                                        8), None, 5, None, None, None, None, 9,
                                   u'01', 116, 2, u'', u'de', 3, '345.00'))
loader.save(
    create_aids_incomeconfirmation(4, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 10,
                                        9), None, 10, None, None, None, None,
                                   4, u'02', 124, 3, u'', u'fr', 1, '456.00'))
loader.save(
    create_aids_incomeconfirmation(5, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 10,
                                        19), None, 4, None, None, None, None,
                                   5, u'01', 127, 4, u'', u'en', 2, '678.00'))
loader.save(
    create_aids_incomeconfirmation(6, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 10,
                                        19), None, 6, None, None, None, None,
                                   5, u'02', 127, 4, u'', u'en', 3, '123.00'))
loader.save(
    create_aids_incomeconfirmation(7, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 2,
                                        12), None, 9, None, None, None, None,
                                   5, u'01', 127, 5, u'', u'en', 1, '234.00'))
loader.save(
    create_aids_incomeconfirmation(8, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 3,
                                        15), None, 5, None, None, None, None,
                                   5, u'02', 127, 6, u'', u'en', 2, '345.00'))
loader.save(
    create_aids_incomeconfirmation(9, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 3,
                                        15), None, 10, None, None, None, None,
                                   5, u'01', 127, 6, u'', u'en', 3, '456.00'))
loader.save(
    create_aids_incomeconfirmation(10, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 10,
                                        29), None, 4, None, None, None, None,
                                   4, u'02', 129, 7, u'', u'de', 1, '678.00'))
loader.save(
    create_aids_incomeconfirmation(11, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 2,
                                        22), None, 6, None, None, None, None,
                                   4, u'01', 129, 8, u'', u'de', 2, '123.00'))
loader.save(
    create_aids_incomeconfirmation(12, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 2,
                                        22), None, 9, None, None, None, None,
                                   4, u'02', 129, 8, u'', u'de', 3, '234.00'))
loader.save(
    create_aids_incomeconfirmation(13, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 11,
                                        8), None, 5, None, None, None, None, 4,
                                   u'01', 132, 9, u'', u'de', 1, '345.00'))
loader.save(
    create_aids_incomeconfirmation(14, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 11,
                                        18), None, 10, None, None, None, None,
                                   5, u'02', 137, 10, u'', u'de', 2, '456.00'))
loader.save(
    create_aids_incomeconfirmation(15, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 11,
                                        18), None, 4, None, None, None, None,
                                   5, u'01', 137, 10, u'', u'de', 3, '678.00'))
loader.save(
    create_aids_incomeconfirmation(16, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 11,
                                        28), None, 6, None, None, None, None,
                                   4, u'02', 141, 11, u'', u'en', 1, '123.00'))
loader.save(
    create_aids_incomeconfirmation(17, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 12,
                                        8), None, 9, None, None, None, None, 4,
                                   u'01', 144, 12, u'', u'de', 2, '234.00'))
loader.save(
    create_aids_incomeconfirmation(18, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 12,
                                        8), None, 5, None, None, None, None, 4,
                                   u'02', 144, 12, u'', u'de', 3, '345.00'))
loader.save(
    create_aids_incomeconfirmation(19, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 4,
                                        3), None, 10, None, None, None, None,
                                   4, u'01', 144, 13, u'', u'de', 1, '456.00'))
loader.save(
    create_aids_incomeconfirmation(20, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 12,
                                        18), None, 4, None, None, None, None,
                                   4, u'02', 147, 14, u'', u'de', 2, '678.00'))
loader.save(
    create_aids_incomeconfirmation(21, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 12,
                                        18), None, 6, None, None, None, None,
                                   4, u'01', 147, 14, u'', u'de', 3, '123.00'))
loader.save(
    create_aids_incomeconfirmation(22, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 4,
                                        13), None, 9, None, None, None, None,
                                   4, u'02', 147, 15, u'', u'de', 1, '234.00'))
loader.save(
    create_aids_incomeconfirmation(23, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5,
                                        14), None, 5, None, None, None, None,
                                   4, u'01', 147, 16, u'', u'de', 2, '345.00'))
loader.save(
    create_aids_incomeconfirmation(24, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5,
                                        14), None, 10, None, None, None, None,
                                   4, u'02', 147, 16, u'', u'de', 3, '456.00'))
loader.save(
    create_aids_incomeconfirmation(25, dt(2018, 12, 16, 8, 8, 9),
                                   date(2012, 12,
                                        28), None, 4, None, None, None, None,
                                   4, u'01', 153, 17, u'', u'fr', 1, '678.00'))
loader.save(
    create_aids_incomeconfirmation(26, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 1,
                                        7), None, 6, None, None, None, None, 5,
                                   u'02', 157, 18, u'', u'de', 2, '123.00'))
loader.save(
    create_aids_incomeconfirmation(27, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 1,
                                        7), None, 9, None, None, None, None, 5,
                                   u'01', 157, 18, u'', u'de', 3, '234.00'))
loader.save(
    create_aids_incomeconfirmation(28, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 1,
                                        17), None, 5, None, None, None, None,
                                   4, u'02', 159, 19, u'', u'de', 1, '345.00'))
loader.save(
    create_aids_incomeconfirmation(29, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5,
                                        13), None, 10, None, None, None, None,
                                   4, u'01', 159, 20, u'', u'de', 2, '456.00'))
loader.save(
    create_aids_incomeconfirmation(30, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5,
                                        13), None, 4, None, None, None, None,
                                   4, u'02', 159, 20, u'', u'de', 3, '678.00'))
loader.save(
    create_aids_incomeconfirmation(31, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 6,
                                        13), None, 6, None, None, None, None,
                                   4, u'01', 159, 21, u'', u'de', 1, '123.00'))
loader.save(
    create_aids_incomeconfirmation(32, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 1,
                                        27), None, 9, None, None, None, None,
                                   6, u'02', 165, 22, u'', u'de', 2, '234.00'))
loader.save(
    create_aids_incomeconfirmation(33, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 1,
                                        27), None, 5, None, None, None, None,
                                   6, u'01', 165, 22, u'', u'de', 3, '345.00'))
loader.save(
    create_aids_incomeconfirmation(34, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5,
                                        23), None, 10, None, None, None, None,
                                   6, u'02', 165, 23, u'', u'de', 1, '456.00'))
loader.save(
    create_aids_incomeconfirmation(35, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 2,
                                        6), None, 4, None, None, None, None, 5,
                                   u'01', 168, 24, u'', u'fr', 2, '678.00'))
loader.save(
    create_aids_incomeconfirmation(36, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 2,
                                        6), None, 6, None, None, None, None, 5,
                                   u'02', 168, 24, u'', u'fr', 3, '123.00'))
loader.save(
    create_aids_incomeconfirmation(37, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 6,
                                        2), None, 9, None, None, None, None, 5,
                                   u'01', 168, 25, u'', u'fr', 1, '234.00'))
loader.save(
    create_aids_incomeconfirmation(38, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 7,
                                        3), None, 5, None, None, None, None, 5,
                                   u'02', 168, 26, u'', u'fr', 2, '345.00'))
loader.save(
    create_aids_incomeconfirmation(39, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 7,
                                        3), None, 10, None, None, None, None,
                                   5, u'01', 168, 26, u'', u'fr', 3, '456.00'))
loader.save(
    create_aids_incomeconfirmation(40, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 2,
                                        16), None, 4, None, None, None, None,
                                   4, u'02', 177, 27, u'', u'de', 1, '678.00'))
loader.save(
    create_aids_incomeconfirmation(41, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 6,
                                        12), None, 6, None, None, None, None,
                                   4, u'01', 177, 28, u'', u'de', 2, '123.00'))
loader.save(
    create_aids_incomeconfirmation(42, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 6,
                                        12), None, 9, None, None, None, None,
                                   4, u'02', 177, 28, u'', u'de', 3, '234.00'))
loader.save(
    create_aids_incomeconfirmation(43, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 2,
                                        26), None, 5, None, None, None, None,
                                   6, u'01', 179, 29, u'', u'de', 1, '345.00'))
loader.save(
    create_aids_incomeconfirmation(44, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 6,
                                        22), None, 10, None, None, None, None,
                                   6, u'02', 179, 30, u'', u'de', 2, '456.00'))
loader.save(
    create_aids_incomeconfirmation(45, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 6,
                                        22), None, 4, None, None, None, None,
                                   6, u'01', 179, 30, u'', u'de', 3, '678.00'))
loader.save(
    create_aids_incomeconfirmation(46, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 7,
                                        23), None, 6, None, None, None, None,
                                   6, u'02', 179, 31, u'', u'de', 1, '123.00'))
loader.save(
    create_aids_incomeconfirmation(47, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 3,
                                        8), None, 9, None, None, None, None, 5,
                                   u'01', 181, 32, u'', u'fr', 2, '234.00'))
loader.save(
    create_aids_incomeconfirmation(48, dt(2018, 12, 16, 8, 8, 9),
                                   date(2013, 3,
                                        8), None, 5, None, None, None, None, 5,
                                   u'02', 181, 32, u'', u'fr', 3, '345.00'))
loader.save(
    create_aids_incomeconfirmation(49, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 7,
                                        2), None, 10, None, None, None, None,
                                   5, u'01', 181, 33, u'', u'fr', 1, '456.00'))
loader.save(
    create_aids_incomeconfirmation(50, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5,
                                        22), None, 4, None, None, None, None,
                                   9, u'02', 116, 34, u'', u'de', 2, '678.00'))
loader.save(
    create_aids_incomeconfirmation(51, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5,
                                        22), None, 6, None, None, None, None,
                                   9, u'01', 116, 34, u'', u'de', 3, '123.00'))
loader.save(
    create_aids_incomeconfirmation(52, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5, 22), date(2014, 5, 23), 9,
                                   None, None, None, None, 5, u'02', 118, 35,
                                   u'', u'de', 1, '234.00'))
loader.save(
    create_aids_incomeconfirmation(53, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5, 23), date(2014, 5, 24), 5,
                                   None, None, None, None, 4, u'01', 124, 36,
                                   u'', u'fr', 2, '345.00'))
loader.save(
    create_aids_incomeconfirmation(54, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5, 23), date(2014, 5, 24), 10,
                                   None, None, None, None, 4, u'02', 124, 36,
                                   u'', u'fr', 3, '456.00'))
loader.save(
    create_aids_incomeconfirmation(55, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5, 23), date(2014, 6, 22), 4,
                                   None, None, None, None, 5, u'01', 127, 37,
                                   u'', u'en', 1, '678.00'))
loader.save(
    create_aids_incomeconfirmation(56, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5, 24), date(2014, 5, 24), 6,
                                   None, None, None, None, 5, u'02', 128, 38,
                                   u'', u'de', 2, '123.00'))
loader.save(
    create_aids_incomeconfirmation(57, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5, 24), date(2014, 5, 24), 9,
                                   None, None, None, None, 5, u'01', 128, 38,
                                   u'', u'de', 3, '234.00'))
loader.save(
    create_aids_incomeconfirmation(58, dt(2018, 12, 16, 8, 8, 9),
                                   date(2014, 5,
                                        24), None, 5, None, None, None, None,
                                   4, u'02', 129, 39, u'', u'de', 1, '345.00'))

loader.flush_deferred_objects()

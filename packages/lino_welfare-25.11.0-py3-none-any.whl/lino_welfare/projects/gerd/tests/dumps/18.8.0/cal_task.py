# -*- coding: UTF-8 -*-
logger.info("Loading 35 objects to table cal_task...")
# fields: id, modified, created, project, start_date, start_time, user, owner_type, owner_id, summary, description, access_class, sequence, auto_type, priority, due_date, due_time, percent, state, delegated
loader.save(
    create_cal_task(1, dt(2018, 12, 16, 8, 7, 48), dt(2018, 12, 16, 8, 7,
                                                      48), 116,
                    date(2014, 11, 1), None, 4, isip_Contract, 2,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(2, dt(2018, 12, 16, 8, 7, 49), dt(2018, 12, 16, 8, 7,
                                                      49), 127,
                    date(2014, 12, 21), None, 9, isip_Contract, 6,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(3, dt(2018, 12, 16, 8, 7, 49), dt(2018, 12, 16, 8, 7,
                                                      49), 128,
                    date(2014, 9, 23), None, 6, art61_Contract, 1,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(4, dt(2018, 12, 16, 8, 7, 50), dt(2018, 12, 16, 8, 7,
                                                      50), 129,
                    date(2014, 11, 30), None, 4, isip_Contract, 8,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(5, dt(2018, 12, 16, 8, 7, 50), dt(2018, 12, 16, 8, 7,
                                                      50), 130,
                    date(2014, 10, 3), None, 5, jobs_Contract, 4,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(6, dt(2018, 12, 16, 8, 7, 51), dt(2018, 12, 16, 8, 7,
                                                      51), 133,
                    date(2014, 10, 12), None, 6, jobs_Contract, 5,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(7, dt(2018, 12, 16, 8, 7, 51), dt(2018, 12, 16, 8, 7,
                                                      51), 139,
                    date(2014, 10, 23), None, 5, art61_Contract, 3,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(8, dt(2018, 12, 16, 8, 7, 52), dt(2018, 12, 16, 8, 7,
                                                      52), 142,
                    date(2014, 11, 2), None, 6, jobs_Contract, 6,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(9, dt(2018, 12, 16, 8, 7, 53), dt(2018, 12, 16, 8,
                                                      7, 52), 144,
                    date(2015, 1, 9), None, 4, isip_Contract, 13,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(10, dt(2018, 12, 16, 8, 7, 53), dt(2018, 12, 16, 8, 7,
                                                       53), 146,
                    date(2014, 11, 13), None, 4, jobs_Contract, 8,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(11, dt(2018, 12, 16, 8, 7, 54), dt(2018, 12, 16, 8, 7,
                                                       54), 147,
                    date(2015, 2, 22), None, 4, isip_Contract, 16,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(12, dt(2018, 12, 16, 8, 7, 54), dt(2018, 12, 16, 8, 7,
                                                       54), 152,
                    date(2014, 11, 22), None, 6, art61_Contract, 4,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(13, dt(2018, 12, 16, 8, 7, 54), dt(2018, 12, 16, 8, 7,
                                                       54), 155,
                    date(2014, 12, 2), None, 4, jobs_Contract, 10,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(14, dt(2018, 12, 16, 8, 7, 55), dt(2018, 12, 16, 8, 7,
                                                       55), 158,
                    date(2014, 12, 11), None, 6, jobs_Contract, 11,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(15, dt(2018, 12, 16, 8, 7, 56), dt(2018, 12, 16, 8, 7,
                                                       56), 159,
                    date(2015, 3, 21), None, 4, isip_Contract, 21,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(16, dt(2018, 12, 16, 8, 7, 56), dt(2018, 12, 16, 8, 7,
                                                       56), 161,
                    date(2014, 12, 22), None, 4, art61_Contract, 6,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(17, dt(2018, 12, 16, 8, 7, 57), dt(2018, 12, 16, 8, 7,
                                                       56), 165,
                    date(2015, 2, 28), None, 6, isip_Contract, 23,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(18, dt(2018, 12, 16, 8, 7, 57), dt(2018, 12, 16, 8, 7,
                                                       57), 166,
                    date(2014, 12, 31), None, 6, jobs_Contract, 12,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(19, dt(2018, 12, 16, 8, 7, 57), dt(2018, 12, 16, 8, 7,
                                                       57), 168,
                    date(2014, 6, 2), None, 4, isip_Contract, 25,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(20, dt(2018, 12, 16, 8, 7, 58), dt(2018, 12, 16, 8, 7,
                                                       58), 168,
                    date(2015, 4, 11), None, 4, isip_Contract, 26,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(21, dt(2018, 12, 16, 8, 7, 58), dt(2018, 12, 16, 8, 7,
                                                       58), 173,
                    date(2015, 1, 11), None, 5, jobs_Contract, 14,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(22, dt(2018, 12, 16, 8, 7, 59), dt(2018, 12, 16, 8, 7,
                                                       59), 177,
                    date(2015, 3, 20), None, 5, isip_Contract, 28,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(23, dt(2018, 12, 16, 8, 7, 59), dt(2018, 12, 16, 8, 7,
                                                       59), 178,
                    date(2015, 1, 20), None, 6, art61_Contract, 7,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(24, dt(2018, 12, 16, 8, 7, 59), dt(2018, 12, 16, 8, 7,
                                                       59), 179,
                    date(2014, 5, 21), None, 6, isip_Contract, 29,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(25, dt(2018, 12, 16, 8, 7, 59), dt(2018, 12, 16, 8, 7,
                                                       59), 179,
                    date(2014, 6, 22), None, 4, isip_Contract, 30,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(26, dt(2018, 12, 16, 8, 8, 0), dt(2018, 12, 16, 8,
                                                      8, 0), 179,
                    date(2015, 4, 30), None, 4, isip_Contract, 31,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(27, dt(2018, 12, 16, 8, 8, 0), dt(2018, 12, 16, 8,
                                                      8, 0), 180,
                    date(2015, 2, 3), None, 5, jobs_Contract, 16,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(28, dt(2018, 12, 16, 8, 8, 1), dt(2018, 12, 16, 8,
                                                      8, 0), 181,
                    date(2014, 6, 1), None, 4, isip_Contract, 32,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(29, dt(2018, 12, 16, 8, 8, 1), dt(2018, 12, 16, 8,
                                                      8, 1), 181,
                    date(2015, 4, 10), None, 5, isip_Contract, 33,
                    u'Vertrag endet in einem Monat', u'', u'30', 0, 1, u'30',
                    None, None, None, u'10', False))
loader.save(
    create_cal_task(30, dt(2018, 12, 16, 8, 9, 1), dt(2018, 12, 16, 8,
                                                      9, 1), 116,
                    date(2015, 3, 17), None, 5, uploads_Upload, 1,
                    u'Aufenthaltserlaubnis wird ung\xfcltig', u'', u'30', 0, 1,
                    u'30', None, None, None, u'10', False))
loader.save(
    create_cal_task(31, dt(2018, 12, 16, 8, 9, 1), dt(2018, 12, 16, 8,
                                                      9, 1), 116,
                    date(2015, 3, 17), None, 5, uploads_Upload, 2,
                    u'Arbeitserlaubnis wird ung\xfcltig', u'', u'30', 0, 1,
                    u'30', None, None, None, u'10', False))
loader.save(
    create_cal_task(32, dt(2018, 12, 16, 8, 9, 1), dt(2018, 12, 16, 8,
                                                      9, 1), 177,
                    date(2015, 4, 27), None, 5, uploads_Upload, 3,
                    u'F\xfchrerschein wird ung\xfcltig', u'', u'30', 0, 1,
                    u'30', None, None, None, u'10', False))
loader.save(
    create_cal_task(33, dt(2018, 12, 16, 8, 9, 1), dt(2018, 12, 16, 8,
                                                      9, 1), 177,
                    date(2015, 4, 27), None, 5, uploads_Upload, 4,
                    u'Identifizierendes Dokument wird ung\xfcltig', u'', u'30',
                    0, 1, u'30', None, None, None, u'10', False))
loader.save(
    create_cal_task(34, dt(2018, 12, 16, 8, 9, 2), dt(2018, 12, 16, 8,
                                                      9, 2), 124,
                    date(2015, 1, 18), None, 7, uploads_Upload, 9,
                    u'Aufenthaltserlaubnis wird ung\xfcltig', u'', u'30', 0, 1,
                    u'30', None, None, None, u'10', False))
loader.save(
    create_cal_task(35, dt(2018, 12, 16, 8, 9, 2), dt(2018, 12, 16, 8,
                                                      9, 2), 124,
                    date(2014, 6, 30), None, 6, uploads_Upload, 10,
                    u'Arbeitserlaubnis wird ung\xfcltig', u'', u'30', 0, 1,
                    u'30', None, None, None, u'10', False))

loader.flush_deferred_objects()

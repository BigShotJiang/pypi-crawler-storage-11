# -*- coding: UTF-8 -*-
logger.info("Loading 30 objects to table vatless_accountinvoice...")
# fields: voucher_ptr, project, partner, payment_term, match, bank_account, your_ref, due_date, amount
loader.save(
    create_vatless_accountinvoice(1, 116, 220, None, u'', 1, u'',
                                  date(2014, 6, 21), '10.00'))
loader.save(
    create_vatless_accountinvoice(2, None, 221, None, u'', 2, u'',
                                  date(2014, 6, 16), '192.78'))
loader.save(
    create_vatless_accountinvoice(3, 127, 222, None, u'', 3, u'',
                                  date(2014, 6, 11), '10.00'))
loader.save(
    create_vatless_accountinvoice(4, 116, 223, None, u'', 8, u'',
                                  date(2014, 6, 6), '12.50'))
loader.save(
    create_vatless_accountinvoice(5, None, 224, None, u'', 9, u'',
                                  date(2014, 6, 1), '227.78'))
loader.save(
    create_vatless_accountinvoice(6, 116, 225, None, u'', 10, u'',
                                  date(2014, 5, 27), '29.95'))
loader.save(
    create_vatless_accountinvoice(7, 124, 226, None, u'', 13, u'',
                                  date(2014, 5, 22), '120.00'))
loader.save(
    create_vatless_accountinvoice(8, None, 227, None, u'', 15, u'',
                                  date(2014, 5, 17), '82.78'))
loader.save(
    create_vatless_accountinvoice(9, 116, 228, None, u'', 16, u'',
                                  date(2014, 5, 12), '120.00'))
loader.save(
    create_vatless_accountinvoice(10, 124, 229, None, u'', 17, u'',
                                  date(2014, 5, 7), '5.33'))
loader.save(
    create_vatless_accountinvoice(11, None, 220, None, u'', 1, u'',
                                  date(2014, 5, 2), '212.78'))
loader.save(
    create_vatless_accountinvoice(12, 124, 221, None, u'', 2, u'',
                                  date(2014, 4, 27), '12.50'))
loader.save(
    create_vatless_accountinvoice(13, 128, 222, None, u'', 3, u'',
                                  date(2014, 4, 22), '25.00'))
loader.save(
    create_vatless_accountinvoice(14, None, 223, None, u'', 8, u'',
                                  date(2014, 4, 17), '177.78'))
loader.save(
    create_vatless_accountinvoice(15, 124, 224, None, u'', 9, u'',
                                  date(2014, 4, 12), '25.00'))
loader.save(
    create_vatless_accountinvoice(16, 128, 225, None, u'', 10, u'',
                                  date(2014, 4, 7), '29.95'))
loader.save(
    create_vatless_accountinvoice(17, None, 226, None, u'', 13, u'',
                                  date(2014, 4, 2), '322.78'))
loader.save(
    create_vatless_accountinvoice(18, 128, 227, None, u'', 15, u'',
                                  date(2014, 3, 28), '5.33'))
loader.save(
    create_vatless_accountinvoice(19, 118, 228, None, u'', 16, u'',
                                  date(2014, 3, 23), '10.00'))
loader.save(
    create_vatless_accountinvoice(20, None, 229, None, u'', 17, u'',
                                  date(2014, 3, 18), '192.78'))
loader.save(
    create_vatless_accountinvoice(21, 128, 220, None, u'', 1, u'',
                                  date(2014, 3, 13), '10.00'))
loader.save(
    create_vatless_accountinvoice(22, 118, 221, None, u'', 2, u'',
                                  date(2014, 3, 8), '12.50'))
loader.save(
    create_vatless_accountinvoice(23, None, 222, None, u'', 3, u'',
                                  date(2014, 3, 3), '227.78'))
loader.save(
    create_vatless_accountinvoice(24, 118, 223, None, u'', 8, u'',
                                  date(2014, 2, 26), '29.95'))
loader.save(
    create_vatless_accountinvoice(25, 127, 224, None, u'', 9, u'',
                                  date(2014, 2, 21), '120.00'))
loader.save(
    create_vatless_accountinvoice(26, None, 225, None, u'', 10, u'',
                                  date(2014, 2, 16), '82.78'))
loader.save(
    create_vatless_accountinvoice(27, 118, 226, None, u'', 13, u'',
                                  date(2014, 2, 11), '120.00'))
loader.save(
    create_vatless_accountinvoice(28, 127, 227, None, u'', 15, u'',
                                  date(2014, 2, 6), '5.33'))
loader.save(
    create_vatless_accountinvoice(29, None, 228, None, u'', 16, u'',
                                  date(2014, 2, 1), '212.78'))
loader.save(
    create_vatless_accountinvoice(30, 127, 229, None, u'', 17, u'',
                                  date(2014, 1, 27), '12.50'))

loader.flush_deferred_objects()

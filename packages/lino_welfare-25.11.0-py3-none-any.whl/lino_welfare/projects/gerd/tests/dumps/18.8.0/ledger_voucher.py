# -*- coding: UTF-8 -*-
logger.info("Loading 56 objects to table ledger_voucher...")
# fields: id, user, journal, entry_date, voucher_date, accounting_period, number, narration, state
loader.save(
    create_ledger_voucher(1, 12, 1, date(2014, 5, 22), date(2014, 5, 21), 1, 1,
                          u'', '20'))
loader.save(
    create_ledger_voucher(2, 12, 2, date(2014, 5, 17), date(2014, 5, 16), 1, 1,
                          u'', '20'))
loader.save(
    create_ledger_voucher(3, 12, 1, date(2014, 5, 12), date(2014, 5, 11), 1, 2,
                          u'', '20'))
loader.save(
    create_ledger_voucher(4, 12, 1, date(2014, 5, 7), date(2014, 5, 6), 1, 3,
                          u'', '20'))
loader.save(
    create_ledger_voucher(5, 12, 2, date(2014, 5, 2), date(2014, 5, 1), 1, 2,
                          u'', '20'))
loader.save(
    create_ledger_voucher(6, 12, 1, date(2014, 4, 27), date(2014, 4, 26), 2, 4,
                          u'', '20'))
loader.save(
    create_ledger_voucher(7, 12, 1, date(2014, 4, 22), date(2014, 4, 21), 2, 5,
                          u'', '20'))
loader.save(
    create_ledger_voucher(8, 12, 2, date(2014, 4, 17), date(2014, 4, 16), 2, 3,
                          u'', '20'))
loader.save(
    create_ledger_voucher(9, 12, 1, date(2014, 4, 12), date(2014, 4, 11), 2, 6,
                          u'', '20'))
loader.save(
    create_ledger_voucher(10, 12, 1, date(2014, 4, 7), date(2014, 4, 6), 2, 7,
                          u'', '20'))
loader.save(
    create_ledger_voucher(11, 12, 2, date(2014, 4, 2), date(2014, 4, 1), 2, 4,
                          u'', '20'))
loader.save(
    create_ledger_voucher(12, 12, 1, date(2014, 3, 28), date(2014, 3, 27), 3,
                          8, u'', '20'))
loader.save(
    create_ledger_voucher(13, 12, 1, date(2014, 3, 23), date(2014, 3, 22), 3,
                          9, u'', '20'))
loader.save(
    create_ledger_voucher(14, 12, 2, date(2014, 3, 18), date(2014, 3, 17), 3,
                          5, u'', '20'))
loader.save(
    create_ledger_voucher(15, 12, 1, date(2014, 3, 13), date(2014, 3, 12), 3,
                          10, u'', '20'))
loader.save(
    create_ledger_voucher(16, 12, 1, date(2014, 3, 8), date(2014, 3, 7), 3, 11,
                          u'', '20'))
loader.save(
    create_ledger_voucher(17, 12, 2, date(2014, 3, 3), date(2014, 3, 2), 3, 6,
                          u'', '20'))
loader.save(
    create_ledger_voucher(18, 12, 1, date(2014, 2, 26), date(2014, 2, 25), 4,
                          12, u'', '20'))
loader.save(
    create_ledger_voucher(19, 12, 1, date(2014, 2, 21), date(2014, 2, 20), 4,
                          13, u'', '20'))
loader.save(
    create_ledger_voucher(20, 12, 2, date(2014, 2, 16), date(2014, 2, 15), 4,
                          7, u'', '20'))
loader.save(
    create_ledger_voucher(21, 12, 1, date(2014, 2, 11), date(2014, 2, 10), 4,
                          14, u'', '20'))
loader.save(
    create_ledger_voucher(22, 12, 1, date(2014, 2, 6), date(2014, 2, 5), 4, 15,
                          u'', '20'))
loader.save(
    create_ledger_voucher(23, 12, 2, date(2014, 2, 1), date(2014, 1, 31), 4, 8,
                          u'', '20'))
loader.save(
    create_ledger_voucher(24, 12, 1, date(2014, 1, 27), date(2014, 1, 26), 5,
                          16, u'', '20'))
loader.save(
    create_ledger_voucher(25, 12, 1, date(2014, 1, 22), date(2014, 1, 21), 5,
                          17, u'', '20'))
loader.save(
    create_ledger_voucher(26, 12, 2, date(2014, 1, 17), date(2014, 1, 16), 5,
                          9, u'', '20'))
loader.save(
    create_ledger_voucher(27, 12, 1, date(2014, 1, 12), date(2014, 1, 11), 5,
                          18, u'', '20'))
loader.save(
    create_ledger_voucher(28, 12, 1, date(2014, 1, 7), date(2014, 1, 6), 5, 19,
                          u'', '20'))
loader.save(
    create_ledger_voucher(29, 12, 2, date(2014, 1, 2), date(2014, 1, 1), 5, 10,
                          u'', '20'))
loader.save(
    create_ledger_voucher(30, 12, 1, date(2013, 12, 28), date(2013, 12, 27), 6,
                          1, u'', '20'))
loader.save(
    create_ledger_voucher(31, 12, 3, date(2014, 5, 22), date(2014, 5, 22), 1,
                          1, u'Allgemeine Beihilfen', '20'))
loader.save(
    create_ledger_voucher(32, 12, 3, date(2014, 5, 22), date(2014, 5, 22), 1,
                          2, u'Heizkosten- u. Energiebeihilfe', '20'))
loader.save(
    create_ledger_voucher(33, 12, 3, date(2014, 5, 22), date(2014, 5, 22), 1,
                          3, u'Fonds Gas und Elektrizit\xe4t', '20'))
loader.save(
    create_ledger_voucher(34, 12, 3, date(2014, 5, 22), date(2014, 5, 22), 1,
                          4, u'Eingliederungseinkommen', '20'))
loader.save(
    create_ledger_voucher(35, 12, 3, date(2014, 5, 22), date(2014, 5, 22), 1,
                          5, u'Sozialhilfe', '20'))
loader.save(
    create_ledger_voucher(36, 12, 3, date(2014, 5, 22), date(2014, 5, 22), 1,
                          6, u'Beihilfe f\xfcr Ausl\xe4nder', '20'))
loader.save(
    create_ledger_voucher(37, 12, 3, date(2014, 4, 22), date(2014, 4, 22), 2,
                          7, u'Allgemeine Beihilfen', '20'))
loader.save(
    create_ledger_voucher(38, 12, 3, date(2014, 4, 22), date(2014, 4, 22), 2,
                          8, u'Heizkosten- u. Energiebeihilfe', '20'))
loader.save(
    create_ledger_voucher(39, 12, 3, date(2014, 4, 22), date(2014, 4, 22), 2,
                          9, u'Fonds Gas und Elektrizit\xe4t', '20'))
loader.save(
    create_ledger_voucher(40, 12, 3, date(2014, 4, 22), date(2014, 4, 22), 2,
                          10, u'Eingliederungseinkommen', '20'))
loader.save(
    create_ledger_voucher(41, 12, 3, date(2014, 4, 22), date(2014, 4, 22), 2,
                          11, u'Sozialhilfe', '20'))
loader.save(
    create_ledger_voucher(42, 12, 3, date(2014, 4, 22), date(2014, 4, 22), 2,
                          12, u'Beihilfe f\xfcr Ausl\xe4nder', '20'))
loader.save(
    create_ledger_voucher(43, 12, 3, date(2014, 3, 23), date(2014, 3, 23), 3,
                          13, u'Allgemeine Beihilfen', '20'))
loader.save(
    create_ledger_voucher(44, 12, 3, date(2014, 3, 23), date(2014, 3, 23), 3,
                          14, u'Heizkosten- u. Energiebeihilfe', '20'))
loader.save(
    create_ledger_voucher(45, 12, 3, date(2014, 3, 23), date(2014, 3, 23), 3,
                          15, u'Fonds Gas und Elektrizit\xe4t', '20'))
loader.save(
    create_ledger_voucher(46, 12, 3, date(2014, 3, 23), date(2014, 3, 23), 3,
                          16, u'Eingliederungseinkommen', '20'))
loader.save(
    create_ledger_voucher(47, 12, 3, date(2014, 3, 23), date(2014, 3, 23), 3,
                          17, u'Sozialhilfe', '20'))
loader.save(
    create_ledger_voucher(48, 12, 3, date(2014, 3, 23), date(2014, 3, 23), 3,
                          18, u'Beihilfe f\xfcr Ausl\xe4nder', '20'))
loader.save(
    create_ledger_voucher(73, 7, 3, date(2014, 1, 13), date(2014, 1, 13), 5,
                          19, u'', '20'))
loader.save(
    create_ledger_voucher(74, 12, 3, date(2014, 2, 13), date(2014, 2, 13), 4,
                          20, u'', '20'))
loader.save(
    create_ledger_voucher(75, 8, 3, date(2014, 3, 13), date(2014, 3, 13), 3,
                          21, u'', '20'))
loader.save(
    create_ledger_voucher(76, 6, 3, date(2014, 4, 13), date(2014, 4, 13), 2,
                          22, u'', '20'))
loader.save(
    create_ledger_voucher(101, 8, 4, date(2014, 1, 21), date(2014, 1, 21), 5,
                          1, u'', '20'))
loader.save(
    create_ledger_voucher(102, 6, 4, date(2014, 2, 21), date(2014, 2, 21), 4,
                          2, u'', '20'))
loader.save(
    create_ledger_voucher(103, 9, 4, date(2014, 3, 21), date(2014, 3, 21), 3,
                          3, u'', '20'))
loader.save(
    create_ledger_voucher(104, 5, 4, date(2014, 4, 21), date(2014, 4, 21), 2,
                          4, u'', '20'))

loader.flush_deferred_objects()

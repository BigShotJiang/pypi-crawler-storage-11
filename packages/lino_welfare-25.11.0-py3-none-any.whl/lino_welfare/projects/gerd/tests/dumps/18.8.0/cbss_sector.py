# -*- coding: UTF-8 -*-
logger.info("Loading 209 objects to table cbss_sector...")
# fields: id, name, code, subcode, abbr
loader.save(
    create_cbss_sector(
        1, ['Registre national', 'Registre national', 'Registre national'], 0,
        0, ['RN', 'RN', 'RN']))
loader.save(
    create_cbss_sector(2, [
        'Fonds des accidents du travail', 'Fonds des accidents du travail',
        'Fonds des accidents du travail'
    ], 1, 0, ['FAT', 'FAT', 'FAT']))
loader.save(
    create_cbss_sector(3, [
        'Fonds des accidents du travail', 'Fonds des accidents du travail',
        'Fonds des accidents du travail'
    ], 1, 1, ['FAT', 'FAT', 'FAT']))
loader.save(
    create_cbss_sector(4, [
        'Fonds national de retraite pour ouvriers mineurs',
        'Fonds national de retraite pour ouvriers mineurs',
        'Fonds national de retraite pour ouvriers mineurs'
    ], 2, 0, ['FNROM', 'FNROM', 'FNROM']))
loader.save(
    create_cbss_sector(5, ['INAMI_SAM ', 'INAMI_SAM ', 'INAMI_SAM '], 3, 1,
                       ['INAMI_SAM', 'INAMI_SAM', 'INAMI_SAM']))
loader.save(
    create_cbss_sector(6, [
        'Office national des pensions', 'Office national des pensions',
        'Office national des pensions'
    ], 5, 0, ['ONP', 'ONP', 'ONP']))
loader.save(
    create_cbss_sector(7, [
        'Fonds des maladies professionnelles ',
        'Fonds des maladies professionnelles ',
        'Fonds des maladies professionnelles '
    ], 6, 0, ['FMP', 'FMP', 'FMP']))
loader.save(
    create_cbss_sector(8, [
        "Office national d'allocations familiales pour travailleurs salari\xe9s",
        "Office national d'allocations familiales pour travailleurs salari\xe9s",
        "Office national d'allocations familiales pour travailleurs salari\xe9s"
    ], 7, 0, ['ONAFTS', 'ONAFTS', 'ONAFTS']))
loader.save(
    create_cbss_sector(9, [
        "Caisses d'allocations familiales", "Caisses d'allocations familiales",
        "Caisses d'allocations familiales"
    ], 7, 1, ['ONAFTS', 'ONAFTS', 'ONAFTS']))
loader.save(
    create_cbss_sector(10, [
        "Institut national d'assurance maladie-invalidit\xe9 - VIPO",
        "Institut national d'assurance maladie-invalidit\xe9 - VIPO",
        "Institut national d'assurance maladie-invalidit\xe9 - VIPO"
    ], 8, 0, ['INAMI-W', 'INAMI-W', 'INAMI-W']))
loader.save(
    create_cbss_sector(11, [
        'Caisse de secours et de pr\xe9voyance en faveur des marins',
        'Caisse de secours et de pr\xe9voyance en faveur des marins',
        'Caisse de secours et de pr\xe9voyance en faveur des marins'
    ], 9, 0, ['CSPM', 'CSPM', 'CSPM']))
loader.save(
    create_cbss_sector(12, [
        'Office national de vacances annuelles',
        'Office national de vacances annuelles',
        'Office national de vacances annuelles'
    ], 10, 0, ['ONVA', 'ONVA', 'ONVA']))
loader.save(
    create_cbss_sector(
        13,
        ['Caisses de vacances', 'Caisses de vacances', 'Caisses de vacances'],
        10, 1, ['ONVA', 'ONVA', 'ONVA']))
loader.save(
    create_cbss_sector(14, [
        'Coll\xe8ge intermutualiste national',
        'Coll\xe8ge intermutualiste national',
        'Coll\xe8ge intermutualiste national'
    ], 11, 0, ['CIN', 'CIN', 'CIN']))
loader.save(
    create_cbss_sector(15, [
        'Coll\xe8ge intermutualiste national',
        'Coll\xe8ge intermutualiste national',
        'Coll\xe8ge intermutualiste national'
    ], 11, 1, ['CIN', 'CIN', 'CIN']))
loader.save(
    create_cbss_sector(16, [
        "Caisse auxiliaire d'assurance maladie et invalidit\xe9 (CAAMI)",
        "Caisse auxiliaire d'assurance maladie et invalidit\xe9 (CAAMI)",
        "Caisse auxiliaire d'assurance maladie et invalidit\xe9 (CAAMI)"
    ], 11, 2, ['CIN', 'CIN', 'CIN']))
loader.save(
    create_cbss_sector(17, ['INAMI ', 'INAMI ', 'INAMI '], 11, 3,
                       ['CIN', 'CIN', 'CIN']))
loader.save(
    create_cbss_sector(18, ['INAMI', 'INAMI', 'INAMI'], 11, 4,
                       ['CIN', 'CIN', 'CIN']))
loader.save(
    create_cbss_sector(19, [
        'Feuille de renseignement', 'Feuille de renseignement',
        'Feuille de renseignement'
    ], 11, 5, ['CIN', 'CIN', 'CIN']))
loader.save(
    create_cbss_sector(20, [
        'Office national de s\xe9curit\xe9 sociale',
        'Office national de s\xe9curit\xe9 sociale',
        'Office national de s\xe9curit\xe9 sociale'
    ], 12, 0, ['ONSS', 'ONSS', 'ONSS']))
loader.save(
    create_cbss_sector(21, [
        'Office national de s\xe9curit\xe9 sociale  ',
        'Office national de s\xe9curit\xe9 sociale  ',
        'Office national de s\xe9curit\xe9 sociale  '
    ], 12, 1, ['ONSS', 'ONSS', 'ONSS']))
loader.save(
    create_cbss_sector(22, [
        'Office national de s\xe9curit\xe9 sociale - Human Resources',
        'Office national de s\xe9curit\xe9 sociale - Human Resources',
        'Office national de s\xe9curit\xe9 sociale - Human Resources'
    ], 12, 2, ['ONSS', 'ONSS', 'ONSS']))
loader.save(
    create_cbss_sector(23, [
        'Office national de s\xe9curit\xe9 sociale  ',
        'Office national de s\xe9curit\xe9 sociale  ',
        'Office national de s\xe9curit\xe9 sociale  '
    ], 12, 10, ['ONSS', 'ONSS', 'ONSS']))
loader.save(
    create_cbss_sector(24, [
        'Office national de s\xe9curit\xe9 sociale  - statistiques',
        'Office national de s\xe9curit\xe9 sociale  - statistiques',
        'Office national de s\xe9curit\xe9 sociale  - statistiques'
    ], 12, 11, ['ONSS', 'ONSS', 'ONSS']))
loader.save(
    create_cbss_sector(25, [
        'Office national de s\xe9curit\xe9 sociale des administrations provinciales et locales',
        'Office national de s\xe9curit\xe9 sociale des administrations provinciales et locales',
        'Office national de s\xe9curit\xe9 sociale des administrations provinciales et locales'
    ], 13, 0, ['ONSSAPL', 'ONSSAPL', 'ONSSAPL']))
loader.save(
    create_cbss_sector(26, [
        'Office national de s\xe9curit\xe9 sociale des administrations provinciales et locales',
        'Office national de s\xe9curit\xe9 sociale des administrations provinciales et locales',
        'Office national de s\xe9curit\xe9 sociale des administrations provinciales et locales'
    ], 13, 2, ['ONSSAPL', 'ONSSAPL', 'ONSSAPL']))
loader.save(
    create_cbss_sector(27, [
        'retenue de solidarit\xe9', 'retenue de solidarit\xe9',
        'retenue de solidarit\xe9'
    ], 13, 3, ['ONSSAPL', 'ONSSAPL', 'ONSSAPL']))
loader.save(
    create_cbss_sector(28, [
        'Office national de s\xe9curit\xe9 sociale des administrations provinciales et locales',
        'Office national de s\xe9curit\xe9 sociale des administrations provinciales et locales',
        'Office national de s\xe9curit\xe9 sociale des administrations provinciales et locales'
    ], 13, 10, ['ONSSAPL', 'ONSSAPL', 'ONSSAPL']))
loader.save(
    create_cbss_sector(29, [
        'ONSSAPL-statistiques', 'ONSSAPL-statistiques', 'ONSSAPL-statistiques'
    ], 13, 11, ['ONSSAPL', 'ONSSAPL', 'ONSSAPL']))
loader.save(
    create_cbss_sector(30, ['SIGeDIS', 'SIGeDIS', 'SIGeDIS'], 14, 0,
                       ['SIGeDIS', 'SIGeDIS', 'SIGeDIS']))
loader.save(
    create_cbss_sector(31, ['Argo', 'Argo', 'Argo'], 14, 3,
                       ['SIGeDIS', 'SIGeDIS', 'SIGeDIS']))
loader.save(
    create_cbss_sector(32, ['Capelo', 'Capelo', 'Capelo'], 14, 4,
                       ['SIGeDIS', 'SIGeDIS', 'SIGeDIS']))
loader.save(
    create_cbss_sector(33, [
        "Institut national d'assurances sociales pour travailleurs ind\xe9pendants",
        "Institut national d'assurances sociales pour travailleurs ind\xe9pendants",
        "Institut national d'assurances sociales pour travailleurs ind\xe9pendants"
    ], 15, 0, ['INASTI', 'INASTI', 'INASTI']))
loader.save(
    create_cbss_sector(34, [
        "Caisses d'assurances sociales", "Caisses d'assurances sociales",
        "Caisses d'assurances sociales"
    ], 15, 1, ['INASTI', 'INASTI', 'INASTI']))
loader.save(
    create_cbss_sector(35, [
        'SPF S\xe9curit\xe9 sociale - DG Ind\xe9pendants',
        'SPF S\xe9curit\xe9 sociale - DG Ind\xe9pendants',
        'SPF S\xe9curit\xe9 sociale - DG Ind\xe9pendants'
    ], 15, 2, ['SPF SS', 'SPF SS', 'SPF SS']))
loader.save(
    create_cbss_sector(
        36,
        ['Service de pensions', 'Service de pensions', 'Service de pensions'],
        15, 4, ['INASTI', 'INASTI', 'INASTI']))
loader.save(
    create_cbss_sector(37, [
        'Direction g\xe9n\xe9rale personnes handicap\xe9es',
        'Direction g\xe9n\xe9rale personnes handicap\xe9es',
        'Direction g\xe9n\xe9rale personnes handicap\xe9es'
    ], 16, 0, ['SPF SS', 'SPF SS', 'SPF SS']))
loader.save(
    create_cbss_sector(38, [
        'SPF S\xe9curit\xe9 sociale - Inspection Sociale',
        'SPF S\xe9curit\xe9 sociale - Inspection Sociale',
        'SPF S\xe9curit\xe9 sociale - Inspection Sociale'
    ], 16, 1, ['SPF SS', 'SPF SS', 'SPF SS']))
loader.save(
    create_cbss_sector(39, [
        'SPF S\xe9curit\xe9 sociale - SPP Int\xe9gration Sociale',
        'SPF S\xe9curit\xe9 sociale - SPP Int\xe9gration Sociale',
        'SPF S\xe9curit\xe9 sociale - SPP Int\xe9gration Sociale'
    ], 16, 2, ['SPF SS', 'SPF SS', 'SPF SS']))
loader.save(
    create_cbss_sector(40, ['e-community', 'e-community', 'e-community'], 16,
                       3, ['SPF SS', 'SPF SS', 'SPF SS']))
loader.save(
    create_cbss_sector(41, [
        'commission dispensions ind\xe9pendants',
        'commission dispensions ind\xe9pendants',
        'commission dispensions ind\xe9pendants'
    ], 16, 4, ['SPF SS', 'SPF SS', 'SPF SS']))
loader.save(
    create_cbss_sector(42, [
        'Direction G\xe9n\xe9rale Politique Sociale',
        'Direction G\xe9n\xe9rale Politique Sociale',
        'Direction G\xe9n\xe9rale Politique Sociale'
    ], 16, 5, ['SPF SS', 'SPF SS', 'SPF SS']))
loader.save(
    create_cbss_sector(43, [
        'Direction G\xe9n\xe9rale Victimes de la guerre',
        'Direction G\xe9n\xe9rale Victimes de la guerre',
        'Direction G\xe9n\xe9rale Victimes de la guerre'
    ], 16, 6, ['SPF SS', 'SPF SS', 'SPF SS']))
loader.save(
    create_cbss_sector(44, [' CPAS', ' CPAS', ' CPAS'], 17, 0,
                       ['CPAS', 'CPAS', 'CPAS']))
loader.save(
    create_cbss_sector(45, [
        '\xd6ffentliche Sozialhilfezentren',
        "Centres publics d'action sociale", "Centres publics d'action sociale"
    ], 17, 1, ['\xd6SHZ', 'CPAS', 'CPAS']))
loader.save(
    create_cbss_sector(46, [
        'FSE chapitre 12 uniquement compos\xe9s de CPAS',
        'FSE chapitre 12 uniquement compos\xe9s de CPAS',
        'FSE chapitre 12 uniquement compos\xe9s de CPAS'
    ], 17, 3, ['CPAS', 'CPAS', 'CPAS']))
loader.save(
    create_cbss_sector(47, [
        "Office national de l'emploi", "Office national de l'emploi",
        "Office national de l'emploi"
    ], 18, 0, ['ONEM', 'ONEM', 'ONEM']))
loader.save(
    create_cbss_sector(48, [
        "Office national de l'emploi - organismes de paiement",
        "Office national de l'emploi - organismes de paiement",
        "Office national de l'emploi - organismes de paiement"
    ], 18, 1, ['ONEM', 'ONEM', 'ONEM']))
loader.save(
    create_cbss_sector(49, [
        "Office national de l'emploi - inspection sociale",
        "Office national de l'emploi - inspection sociale",
        "Office national de l'emploi - inspection sociale"
    ], 18, 2, ['ONEM', 'ONEM', 'ONEM']))
loader.save(
    create_cbss_sector(50, [
        'Fonds de fermeture des entreprises',
        'Fonds de fermeture des entreprises',
        'Fonds de fermeture des entreprises'
    ], 18, 3, ['FFE', 'FFE', 'FFE']))
loader.save(
    create_cbss_sector(51, [
        "Office national de l'emploi - HRM",
        "Office national de l'emploi - HRM",
        "Office national de l'emploi - HRM"
    ], 18, 5, ['ONEM', 'ONEM', 'ONEM']))
loader.save(
    create_cbss_sector(52, ['INTER-OP', 'INTER-OP', 'INTER-OP'], 18, 6,
                       ['INTEROP', 'INTEROP', 'INTEROP']))
loader.save(
    create_cbss_sector(53, [
        'SPF Sant\xe9 publique', 'SPF Sant\xe9 publique',
        'SPF Sant\xe9 publique'
    ], 19, 0, [
        'SPF Sant\xe9 publique', 'SPF Sant\xe9 publique',
        'SPF Sant\xe9 publique'
    ]))
loader.save(
    create_cbss_sector(54, [
        'Dispensataires de soins', 'Dispensataires de soins',
        'Dispensataires de soins'
    ], 19, 1, [
        'SPF Sant\xe9 publique', 'SPF Sant\xe9 publique',
        'SPF Sant\xe9 publique'
    ]))
loader.save(
    create_cbss_sector(55, ['Medex', 'Medex', 'Medex'], 19, 2, [
        'SPF Sant\xe9 publique', 'SPF Sant\xe9 publique',
        'SPF Sant\xe9 publique'
    ]))
loader.save(
    create_cbss_sector(56, ['Euthanasie', 'Euthanasie', 'Euthanasie'], 19, 3, [
        'SPF Sant\xe9 publique', 'SPF Sant\xe9 publique',
        'SPF Sant\xe9 publique'
    ]))
loader.save(
    create_cbss_sector(57, [
        "Office national de s\xe9curit\xe9 sociale d'outre-mer",
        "Office national de s\xe9curit\xe9 sociale d'outre-mer",
        "Office national de s\xe9curit\xe9 sociale d'outre-mer"
    ], 20, 0, ['OSSOM', 'OSSOM', 'OSSOM']))
loader.save(
    create_cbss_sector(58, [
        "Institut national d'assurance maladie-invalidit\xe9  ",
        "Institut national d'assurance maladie-invalidit\xe9  ",
        "Institut national d'assurance maladie-invalidit\xe9  "
    ], 21, 0, ['INAMI', 'INAMI', 'INAMI']))
loader.save(
    create_cbss_sector(
        59,
        ['Services Inspection', 'Services Inspection', 'Services Inspection'],
        21, 1, ['INAMI', 'INAMI', 'INAMI']))
loader.save(
    create_cbss_sector(60, [
        'Cadastre des pensions', 'Cadastre des pensions',
        'Cadastre des pensions'
    ], 22, 0, ['INAMI-P', 'INAMI-P', 'INAMI-P']))
loader.save(
    create_cbss_sector(61, [
        'Ethias dans le cadre du flux sur les pensions avec le FAT',
        'Ethias dans le cadre du flux sur les pensions avec le FAT',
        'Ethias dans le cadre du flux sur les pensions avec le FAT'
    ], 22, 10, ['Ethias', 'Ethias', 'Ethias']))
loader.save(
    create_cbss_sector(62, [
        'Service des Pensions du Secteur Public',
        'Service des Pensions du Secteur Public',
        'Service des Pensions du Secteur Public'
    ], 23, 0, ['SdPSP', 'SdPSP', 'SdPSP']))
loader.save(
    create_cbss_sector(63, [
        'Service des Pensions du Secteur Public',
        'Service des Pensions du Secteur Public',
        'Service des Pensions du Secteur Public'
    ], 23, 1, ['SdPSP', 'SdPSP', 'SdPSP']))
loader.save(
    create_cbss_sector(64, [
        'Service des Pensions du Secteur Public',
        'Service des Pensions du Secteur Public',
        'Service des Pensions du Secteur Public'
    ], 23, 2, ['SdPSP', 'SdPSP', 'SdPSP']))
loader.save(
    create_cbss_sector(65, ['OASIS', 'OASIS', 'OASIS'], 24, 0,
                       ['OASIS', 'OASIS', 'OASIS']))
loader.save(
    create_cbss_sector(66, [
        'Banque Carrefour de la s\xe9curit\xe9 sociale',
        'Banque Carrefour de la s\xe9curit\xe9 sociale',
        'Banque Carrefour de la s\xe9curit\xe9 sociale'
    ], 25, 0, ['BCSS', 'BCSS', 'BCSS']))
loader.save(
    create_cbss_sector(67, [
        'Service public f\xe9d\xe9ral Emploi, Travail et Concertation sociale',
        'Service public f\xe9d\xe9ral Emploi, Travail et Concertation sociale',
        'Service public f\xe9d\xe9ral Emploi, Travail et Concertation sociale'
    ], 26, 0, ['SPF ETCS', 'SPF ETCS', 'SPF ETCS']))
loader.save(
    create_cbss_sector(68, [
        'SPF ETCS - inspection sociale', 'SPF ETCS - inspection sociale',
        'SPF ETCS - inspection sociale'
    ], 26, 1, ['SPF ETCS', 'SPF ETCS', 'SPF ETCS']))
loader.save(
    create_cbss_sector(69, [
        'SPF ETCS - inspection technique', 'SPF ETCS - inspection technique',
        'SPF ETCS - inspection technique'
    ], 26, 2, ['SPF ETCS', 'SPF ETCS', 'SPF ETCS']))
loader.save(
    create_cbss_sector(70, [
        'SPF ETCS - inspection m\xe9dicale',
        'SPF ETCS - inspection m\xe9dicale',
        'SPF ETCS - inspection m\xe9dicale'
    ], 26, 3, ['SPF ETCS', 'SPF ETCS', 'SPF ETCS']))
loader.save(
    create_cbss_sector(71, [
        'SPF ETCS - Fonds Social Europ\xe9en',
        'SPF ETCS - Fonds Social Europ\xe9en',
        'SPF ETCS - Fonds Social Europ\xe9en'
    ], 26, 4, ['SPF ETCS', 'SPF ETCS', 'SPF ETCS']))
loader.save(
    create_cbss_sector(
        72, ['SPF ETCS - e-pv', 'SPF ETCS - e-pv', 'SPF ETCS - e-pv'], 26, 5,
        ['SPF ETCS', 'SPF ETCS', 'SPF ETCS']))
loader.save(
    create_cbss_sector(73, [
        "Institut national d'assurance maladie-invalidit\xe9 (bon de cotisation)",
        "Institut national d'assurance maladie-invalidit\xe9 (bon de cotisation)",
        "Institut national d'assurance maladie-invalidit\xe9 (bon de cotisation)"
    ], 27, 0, ['INAMI-B', 'INAMI-B', 'INAMI-B']))
loader.save(
    create_cbss_sector(74, [
        "Institut national d'assurance maladie-invalidit\xe9 (VIPO)",
        "Institut national d'assurance maladie-invalidit\xe9 (VIPO)",
        "Institut national d'assurance maladie-invalidit\xe9 (VIPO)"
    ], 28, 0, ['INAMI-W', 'INAMI-W', 'INAMI-W']))
loader.save(
    create_cbss_sector(75, [
        'Service du contr\xf4le administratif',
        'Service du contr\xf4le administratif',
        'Service du contr\xf4le administratif'
    ], 28, 2, ['INAMI-W', 'INAMI-W', 'INAMI-W']))
loader.save(
    create_cbss_sector(76, ['Gestion omnio', 'Gestion omnio', 'Gestion omnio'],
                       28, 3, ['INAMI-W', 'INAMI-W', 'INAMI-W']))
loader.save(
    create_cbss_sector(
        77, ['VIPO - communes', 'VIPO - communes', 'VIPO - communes'], 29, 0,
        ['VIPO-C', 'VIPO-C', 'VIPO-C']))
loader.save(
    create_cbss_sector(
        78, ['VIPO - provinces', 'VIPO - provinces', 'VIPO - provinces'], 30,
        0, ['VIPO-P', 'VIPO-P', 'VIPO-P']))
loader.save(
    create_cbss_sector(79, [
        "Association d'institutions sectorielles",
        "Association d'institutions sectorielles",
        "Association d'institutions sectorielles"
    ], 31, 0, ['AIS', 'AIS', 'AIS']))
loader.save(
    create_cbss_sector(80, [
        "Fonds de s\xe9curit\xe9 d'existence",
        "Fonds de s\xe9curit\xe9 d'existence",
        "Fonds de s\xe9curit\xe9 d'existence"
    ], 31, 1, ['FSE', 'FSE', 'FSE']))
loader.save(
    create_cbss_sector(
        81, [
            'Fonds de la construction', 'Fonds de la construction',
            'Fonds de la construction'
        ], 31, 2,
        ['Fonds construction', 'Fonds construction', 'Fonds construction']))
loader.save(
    create_cbss_sector(82, ['Fonds horeca', 'Fonds horeca', 'Fonds horeca'],
                       31, 3,
                       ['Fonds horeca', 'Fonds horeca', 'Fonds horeca']))
loader.save(
    create_cbss_sector(83, [
        'SPF Mobilit\xe9 et Transports', 'SPF Mobilit\xe9 et Transports',
        'SPF Mobilit\xe9 et Transports'
    ], 34, 0, [
        'SPF Mobilit\xe9 Transports', 'SPF Mobilit\xe9 Transports',
        'SPF Mobilit\xe9 Transports'
    ]))
loader.save(
    create_cbss_sector(84, [
        'Association des services externes de pr\xe9vention et de protection au travail ',
        'Association des services externes de pr\xe9vention et de protection au travail ',
        'Association des services externes de pr\xe9vention et de protection au travail '
    ], 35, 0, ['ASEPP', 'ASEPP', 'ASEPP']))
loader.save(
    create_cbss_sector(
        85, ['SPF Int\xe9rieur', 'SPF Int\xe9rieur', 'SPF Int\xe9rieur'], 36,
        0, ['SPF Int\xe9rieur', 'SPF Int\xe9rieur', 'SPF Int\xe9rieur']))
loader.save(
    create_cbss_sector(86, [
        'SPF Int\xe9rieur - Office des \xe9trangers',
        'SPF Int\xe9rieur - Office des \xe9trangers',
        'SPF Int\xe9rieur - Office des \xe9trangers'
    ], 36, 1, ['SPF Int\xe9rieur', 'SPF Int\xe9rieur', 'SPF Int\xe9rieur']))
loader.save(
    create_cbss_sector(87, [
        'ePlatform R\xe9gion Bruxelles Capitale',
        'ePlatform R\xe9gion Bruxelles Capitale',
        'ePlatform R\xe9gion Bruxelles Capitale'
    ], 37, 0, ['e-RBC', 'e-RBC', 'e-RBC']))
loader.save(
    create_cbss_sector(88, ['Emploi', 'Emploi', 'Emploi'], 37, 1,
                       ['e-RBC', 'e-RBC', 'e-RBC']))
loader.save(
    create_cbss_sector(89, [
        "Inspection de l'Emploi", "Inspection de l'Emploi",
        "Inspection de l'Emploi"
    ], 37, 2, ['e-RBC', 'e-RBC', 'e-RBC']))
loader.save(
    create_cbss_sector(90, [
        'Direction des Taxis et des Transports r\xe9guliers sp\xe9cialis\xe9s',
        'Direction des Taxis et des Transports r\xe9guliers sp\xe9cialis\xe9s',
        'Direction des Taxis et des Transports r\xe9guliers sp\xe9cialis\xe9s'
    ], 37, 3, ['e-RBC', 'e-RBC', 'e-RBC']))
loader.save(
    create_cbss_sector(91, [
        "Fonds sociaux de s\xe9curit\xe9 d'existence",
        "Fonds sociaux de s\xe9curit\xe9 d'existence",
        "Fonds sociaux de s\xe9curit\xe9 d'existence"
    ], 38, 0, ['FSSE', 'FSSE', 'FSSE']))
loader.save(
    create_cbss_sector(92, [
        'Fonds de la construction', 'Fonds de la construction',
        'Fonds de la construction'
    ], 38, 5, ['FSSE', 'FSSE', 'FSSE']))
loader.save(
    create_cbss_sector(93, ['Eandis', 'Eandis', 'Eandis'], 39, 0,
                       ['Eandis', 'Eandis', 'Eandis']))
loader.save(
    create_cbss_sector(94, [
        'Vlaamse Overheid - Vlaams Integratie Platform',
        'Vlaamse Overheid - Vlaams Integratie Platform',
        'Vlaamse Overheid - Vlaams Integratie Platform'
    ], 40, 0, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(95, [
        'Vlaamse Overheid - Welzijn Volksgezondheid en Gezin',
        'Vlaamse Overheid - Welzijn Volksgezondheid en Gezin',
        'Vlaamse Overheid - Welzijn Volksgezondheid en Gezin'
    ], 40, 1, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(96, [
        'Vlaamse Overheid - Studietoelagen',
        'Vlaamse Overheid - Studietoelagen',
        'Vlaamse Overheid - Studietoelagen'
    ], 40, 2, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(97, [
        'Vlaamse Overheid - Onderwijs', 'Vlaamse Overheid - Onderwijs',
        'Vlaamse Overheid - Onderwijs'
    ], 40, 3, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(98, [
        'Vlaamse Overheid - De Lijn', 'Vlaamse Overheid - De Lijn',
        'Vlaamse Overheid - De Lijn'
    ], 40, 4, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(99, [
        'Vlaamse Overheid - Cultuur, Jeugd, Sport en Media',
        'Vlaamse Overheid - Cultuur, Jeugd, Sport en Media',
        'Vlaamse Overheid - Cultuur, Jeugd, Sport en Media'
    ], 40, 5, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(100, [
        'Vlaamse Overheid - Werk en Sociale Economie',
        'Vlaamse Overheid - Werk en Sociale Economie',
        'Vlaamse Overheid - Werk en Sociale Economie'
    ], 40, 6, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(
        101, ['Syntra Vlaanderen', 'Syntra Vlaanderen', 'Syntra Vlaanderen'],
        40, 7, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(102, [
        'Vlaams Agentschap voor Landbouw en Visserij',
        'Vlaams Agentschap voor Landbouw en Visserij',
        'Vlaams Agentschap voor Landbouw en Visserij'
    ], 40, 8, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(103, [
        'IVA Wonen Vlaanderen', 'IVA Wonen Vlaanderen', 'IVA Wonen Vlaanderen'
    ], 40, 9, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(104, ['KBI Wooncode', 'KBI Wooncode', 'KBI Wooncode'],
                       40, 10, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(105, [
        'Agentschap voor Onderwijsdiensten - onderwijzend personeel',
        'Agentschap voor Onderwijsdiensten - onderwijzend personeel',
        'Agentschap voor Onderwijsdiensten - onderwijzend personeel'
    ], 40, 11, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(106, [
        'Orafin (Centrale Accounting)', 'Orafin (Centrale Accounting)',
        'Orafin (Centrale Accounting)'
    ], 40, 12, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(107, [
        'VEA - Departement Leefmilieu, Natuur en Energie',
        'VEA - Departement Leefmilieu, Natuur en Energie',
        'VEA - Departement Leefmilieu, Natuur en Energie'
    ], 40, 13, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(108, [
        'WSE Inspectiediensten', 'WSE Inspectiediensten',
        'WSE Inspectiediensten'
    ], 40, 14, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(109, [
        'Agentschap Ondernemen', 'Agentschap Ondernemen',
        'Agentschap Ondernemen'
    ], 40, 15, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(110, [
        'AKOV : Agentschap Kwaliteitszorg in Onderwijs en Vorming',
        'AKOV : Agentschap Kwaliteitszorg in Onderwijs en Vorming',
        'AKOV : Agentschap Kwaliteitszorg in Onderwijs en Vorming'
    ], 40, 16, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(111, [
        'Bestuurszaken eGov en ICT Beheer', 'Bestuurszaken eGov en ICT Beheer',
        'Bestuurszaken eGov en ICT Beheer'
    ], 40, 17, ['VO', 'VO', 'VO']))
loader.save(
    create_cbss_sector(112, ['GOTOT', 'GOTOT', 'GOTOT'], 41, 0,
                       ['GOTOT', 'GOTOT', 'GOTOT']))
loader.save(
    create_cbss_sector(113, ['Limosa', 'Limosa', 'Limosa'], 42, 0,
                       ['Limosa', 'Limosa', 'Limosa']))
loader.save(
    create_cbss_sector(114, [
        'Samenwerking Vlaams Water', 'Samenwerking Vlaams Water',
        'Samenwerking Vlaams Water'
    ], 43, 0, ['SVW', 'SVW', 'SVW']))
loader.save(
    create_cbss_sector(115, [
        'Institut belge des services postaux et des t\xe9l\xe9communications\nBelgisch Instituut voor postdiensten en telecommunicatie\nBelgian Institute for Postal services and Telecommunications',
        'Institut belge des services postaux et des t\xe9l\xe9communications\nBelgisch Instituut voor postdiensten en telecommunicatie\nBelgian Institute for Postal services and Telecommunications',
        'Institut belge des services postaux et des t\xe9l\xe9communications\nBelgisch Instituut voor postdiensten en telecommunicatie\nBelgian Institute for Postal services and Telecommunications'
    ], 44, 0, ['IBPT/BIPT', 'IBPT/BIPT', 'IBPT/BIPT']))
loader.save(
    create_cbss_sector(116, [
        'Communaut\xe9 germanophone', 'Communaut\xe9 germanophone',
        'Communaut\xe9 germanophone'
    ], 45, 0, ['Comm. german.', 'Comm. german.', 'Comm. german.']))
loader.save(
    create_cbss_sector(117, [
        'Communaut\xe9 germanophone d\xe9pistage cancer',
        'Communaut\xe9 germanophone d\xe9pistage cancer',
        'Communaut\xe9 germanophone d\xe9pistage cancer'
    ], 45, 1, ['Comm. german.', 'Comm. german.', 'Comm. german.']))
loader.save(
    create_cbss_sector(118, ['4e voie', '4e voie', '4e voie'], 46, 0,
                       ['4e voie', '4e voie', '4e voie']))
loader.save(
    create_cbss_sector(119, [
        'la Soci\xe9t\xe9 Wallonne du Logement',
        'la Soci\xe9t\xe9 Wallonne du Logement',
        'la Soci\xe9t\xe9 Wallonne du Logement'
    ], 47, 0, ['SWL ', 'SWL ', 'SWL ']))
loader.save(
    create_cbss_sector(120, [
        'Soci\xe9t\xe9 du Logement de la R\xe9gion de Bruxelles-Capitale',
        'Soci\xe9t\xe9 du Logement de la R\xe9gion de Bruxelles-Capitale',
        'Soci\xe9t\xe9 du Logement de la R\xe9gion de Bruxelles-Capitale'
    ], 48, 0, ['SLRB', 'SLRB', 'SLRB']))
loader.save(
    create_cbss_sector(121, [
        'Vlaamse Maatschappij voor Sociaal Wonen',
        'Vlaamse Maatschappij voor Sociaal Wonen',
        'Vlaamse Maatschappij voor Sociaal Wonen'
    ], 49, 0, ['VMSW', 'VMSW', 'VMSW']))
loader.save(
    create_cbss_sector(122, ['SPF Finances', 'SPF Finances', 'SPF Finances'],
                       50, 0,
                       ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(123, [
        'Administration des Contributions Directes',
        'Administration des Contributions Directes',
        'Administration des Contributions Directes'
    ], 50, 1, ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(124, [
        'Documentation patrimoine', 'Documentation patrimoine',
        'Documentation patrimoine'
    ], 50, 2, ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(125, [
        'Paiements anticip\xe9s', 'Paiements anticip\xe9s',
        'Paiements anticip\xe9s'
    ], 50, 3, ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(126, [
        'Pr\xe9compte immobilier', 'Pr\xe9compte immobilier',
        'Pr\xe9compte immobilier'
    ], 50, 4, ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(127, [
        'Taxe sur la valeur ajout\xe9e', 'Taxe sur la valeur ajout\xe9e',
        'Taxe sur la valeur ajout\xe9e'
    ], 50, 5, ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(128, [
        'Service des cr\xe9ances alimentaires',
        'Service des cr\xe9ances alimentaires',
        'Service des cr\xe9ances alimentaires'
    ], 50, 6, ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(129,
                       ['Datawarehouse', 'Datawarehouse', 'Datawarehouse'], 50,
                       7, ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(130, [
        'Taxes de circulation', 'Taxes de circulation', 'Taxes de circulation'
    ], 50, 8, ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(131, [
        'Administration des Contributions Directes (MAF revenus)',
        'Administration des Contributions Directes (MAF revenus)',
        'Administration des Contributions Directes (MAF revenus)'
    ], 50, 9, ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(132, [
        "Administration des Contributions Directes (mise \xe0 jour des cr\xe9ances pour l'ONVA)",
        "Administration des Contributions Directes (mise \xe0 jour des cr\xe9ances pour l'ONVA)",
        "Administration des Contributions Directes (mise \xe0 jour des cr\xe9ances pour l'ONVA)"
    ], 50, 10, ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(133, [
        'Tr\xe9sorerie Victimes de guerre', 'Tr\xe9sorerie Victimes de guerre',
        'Tr\xe9sorerie Victimes de guerre'
    ], 50, 11, ['SPF Finances', 'SPF Finances', 'SPF Finances']))
loader.save(
    create_cbss_sector(134, [
        "Institutions hors r\xe9seau qui payent des pensions l\xe9gales et qui sont habilit\xe9es \xe0 op\xe9rer des retenues sur les pensions \xe0 payer dans le cadre de la 'cotisation de solidarit\xe9'",
        "Institutions hors r\xe9seau qui payent des pensions l\xe9gales et qui sont habilit\xe9es \xe0 op\xe9rer des retenues sur les pensions \xe0 payer dans le cadre de la 'cotisation de solidarit\xe9'",
        "Institutions hors r\xe9seau qui payent des pensions l\xe9gales et qui sont habilit\xe9es \xe0 op\xe9rer des retenues sur les pensions \xe0 payer dans le cadre de la 'cotisation de solidarit\xe9'"
    ], 51, 0, ['', '', '']))
loader.save(
    create_cbss_sector(135, [
        'Soci\xe9t\xe9 nationale des chemins de fer belges',
        'Soci\xe9t\xe9 nationale des chemins de fer belges',
        'Soci\xe9t\xe9 nationale des chemins de fer belges'
    ], 51, 1, ['SNCB', 'SNCB', 'SNCB']))
loader.save(
    create_cbss_sector(136, [
        'Radio T\xe9l\xe9vision Belge Francophone',
        'Radio T\xe9l\xe9vision Belge Francophone',
        'Radio T\xe9l\xe9vision Belge Francophone'
    ], 51, 2, ['RTBF', 'RTBF', 'RTBF']))
loader.save(
    create_cbss_sector(137, [
        'Office de navigation', 'Office de navigation', 'Office de navigation'
    ], 51, 3, ['OFN', 'OFN', 'OFN']))
loader.save(
    create_cbss_sector(138, [
        'Dienst voor Scheepvaart', 'Dienst voor Scheepvaart',
        'Dienst voor Scheepvaart'
    ], 51, 4, ['DSV', 'DSV', 'DSV']))
loader.save(
    create_cbss_sector(139, [
        'Vlaamse Radio en Televisie', 'Vlaamse Radio en Televisie',
        'Vlaamse Radio en Televisie'
    ], 51, 5, ['VRT', 'VRT', 'VRT']))
loader.save(
    create_cbss_sector(140, [
        'Regie der Luchtwegen', 'Regie der Luchtwegen', 'Regie der Luchtwegen'
    ], 51, 6, ['RLW', 'RLW', 'RLW']))
loader.save(
    create_cbss_sector(141, [
        'Societ\xe9 wallonne des  eaux', 'Societ\xe9 wallonne des  eaux',
        'Societ\xe9 wallonne des  eaux'
    ], 51, 7, ['SWDE', 'SWDE', 'SWDE']))
loader.save(
    create_cbss_sector(142, ['Belgacom', 'Belgacom', 'Belgacom'], 51, 8,
                       ['BELGACOM', 'BELGACOM', 'BELGACOM']))
loader.save(
    create_cbss_sector(143, [
        'Caisse de retraite des s\xe9nateurs',
        'Caisse de retraite des s\xe9nateurs',
        'Caisse de retraite des s\xe9nateurs'
    ], 51, 9, ['CRS', 'CRS', 'CRS']))
loader.save(
    create_cbss_sector(144, [
        'Kamer van Volksvertegenwoordigers',
        'Kamer van Volksvertegenwoordigers',
        'Kamer van Volksvertegenwoordigers'
    ], 51, 10, ['KVV', 'KVV', 'KVV']))
loader.save(
    create_cbss_sector(145, [
        'Pensioenkas voor Volksvertegenwoordigers',
        'Pensioenkas voor Volksvertegenwoordigers',
        'Pensioenkas voor Volksvertegenwoordigers'
    ], 51, 11, ['PVV', 'PVV', 'PVV']))
loader.save(
    create_cbss_sector(146, [
        'Vlaamse Maatschappij voor Watervoorziening',
        'Vlaamse Maatschappij voor Watervoorziening',
        'Vlaamse Maatschappij voor Watervoorziening'
    ], 51, 12, ['VMWV', 'VMWV', 'VMWV']))
loader.save(
    create_cbss_sector(147, [
        'Belgischer Rundfunk und Fernsehzentrum',
        'Belgischer Rundfunk und Fernsehzentrum',
        'Belgischer Rundfunk und Fernsehzentrum'
    ], 51, 13, ['BRF', 'BRF', 'BRF']))
loader.save(
    create_cbss_sector(148, [
        'Pensioenkas van de Brusselse Hoofdstedelijke Raad',
        'Pensioenkas van de Brusselse Hoofdstedelijke Raad',
        'Pensioenkas van de Brusselse Hoofdstedelijke Raad'
    ], 51, 14, ['PBHR', 'PBHR', 'PBHR']))
loader.save(
    create_cbss_sector(149, [
        'Caisse de pension des deput\xe9s wallons',
        'Caisse de pension des deput\xe9s wallons',
        'Caisse de pension des deput\xe9s wallons'
    ], 51, 15, ['CPDW', 'CPDW', 'CPDW']))
loader.save(
    create_cbss_sector(150, [
        'Pensioenfonds van het Vlaams Parlement',
        'Pensioenfonds van het Vlaams Parlement',
        'Pensioenfonds van het Vlaams Parlement'
    ], 51, 16, ['PVLPAR', 'PVLPAR', 'PVLPAR']))
loader.save(
    create_cbss_sector(151, ['Belgacom', 'Belgacom', 'Belgacom'], 51, 17,
                       ['BELGACOM', 'BELGACOM', 'BELGACOM']))
loader.save(
    create_cbss_sector(152, [
        'Vlaamse Dienst voor Arbeidsbemiddeling en Beroepsopleiding',
        'Vlaamse Dienst voor Arbeidsbemiddeling en Beroepsopleiding',
        'Vlaamse Dienst voor Arbeidsbemiddeling en Beroepsopleiding'
    ], 53, 0, ['VDAB', 'VDAB', 'VDAB']))
loader.save(
    create_cbss_sector(153, ['Actiris', 'Actiris', 'Actiris'], 54, 0,
                       ['Actiris', 'Actiris', 'Actiris']))
loader.save(
    create_cbss_sector(154, [
        "Office communautaire et r\xe9gional de la Formation professionnelle et de l'Emploi",
        "Office communautaire et r\xe9gional de la Formation professionnelle et de l'Emploi",
        "Office communautaire et r\xe9gional de la Formation professionnelle et de l'Emploi"
    ], 55, 0, ['FOREM', 'FOREM', 'FOREM']))
loader.save(
    create_cbss_sector(155, [
        'Arbeitsamt der deutschsprachigen Gemeinschaft',
        'Arbeitsamt der deutschsprachigen Gemeinschaft',
        'Arbeitsamt der deutschsprachigen Gemeinschaft'
    ], 56, 0, ['ADG', 'ADG', 'ADG']))
loader.save(
    create_cbss_sector(156, ['AGORA', 'AGORA', 'AGORA'], 57, 0,
                       ['AGORA', 'AGORA', 'AGORA']))
loader.save(
    create_cbss_sector(157, ['AGORA', 'AGORA', 'AGORA'], 57, 2,
                       ['AGORA-BCSS', 'AGORA-BCSS', 'AGORA-BCSS']))
loader.save(
    create_cbss_sector(158, [
        'Institut national de statistique', 'Institut national de statistique',
        'Institut national de statistique'
    ], 58, 0, ['INS', 'INS', 'INS']))
loader.save(
    create_cbss_sector(159, ["L'Italie", "L'Italie", "L'Italie"], 59, 28,
                       ['Europe', 'Europe', 'Europe']))
loader.save(
    create_cbss_sector(160, [
        'Bijzondere Jeugdbijstand (allocations familiales)',
        'Bijzondere Jeugdbijstand (allocations familiales)',
        'Bijzondere Jeugdbijstand (allocations familiales)'
    ], 60, 0, ['BJB', 'BJB', 'BJB']))
loader.save(
    create_cbss_sector(161, [
        'Vlaamse Belastingsdienst', 'Vlaamse Belastingsdienst',
        'Vlaamse Belastingsdienst'
    ], 61, 0, ['VLABEL', 'VLABEL', 'VLABEL']))
loader.save(
    create_cbss_sector(162, [
        'Vlaams Agentschap voor Personen met een Handicap',
        'Vlaams Agentschap voor Personen met een Handicap',
        'Vlaams Agentschap voor Personen met een Handicap'
    ], 62, 0, ['VAPH', 'VAPH', 'VAPH']))
loader.save(
    create_cbss_sector(163, [
        'Vlaamse Milieumaatschappij', 'Vlaamse Milieumaatschappij',
        'Vlaamse Milieumaatschappij'
    ], 63, 0, ['VMM', 'VMM', 'VMM']))
loader.save(
    create_cbss_sector(164, [
        'Openbare vervoersmaatschappij De Lijn ',
        'Openbare vervoersmaatschappij De Lijn ',
        'Openbare vervoersmaatschappij De Lijn '
    ], 64, 0, ['De Lijn', 'De Lijn', 'De Lijn']))
loader.save(
    create_cbss_sector(165, [
        'R\xe9gion de Bruxelles-Capitale', 'R\xe9gion de Bruxelles-Capitale',
        'R\xe9gion de Bruxelles-Capitale'
    ], 65, 0, ['RBC', 'RBC', 'RBC']))
loader.save(
    create_cbss_sector(166, [
        'd\xe9pistage du cancer colorectal',
        'd\xe9pistage du cancer colorectal',
        'd\xe9pistage du cancer colorectal'
    ], 65, 3, ['RBC', 'RBC', 'RBC']))
loader.save(
    create_cbss_sector(167, [
        'Service de perception de la redevance radio et t\xe9l\xe9vision de la Communaut\xe9 fran\xe7aise',
        'Service de perception de la redevance radio et t\xe9l\xe9vision de la Communaut\xe9 fran\xe7aise',
        'Service de perception de la redevance radio et t\xe9l\xe9vision de la Communaut\xe9 fran\xe7aise'
    ], 66, 0, ['FISC-W', 'FISC-W', 'FISC-W']))
loader.save(
    create_cbss_sector(
        168, ['Easi-Wal', 'Easi-Wal', 'Easi-Wal'], 69, 0,
        ['R\xe9gion Wallonne', 'R\xe9gion Wallonne', 'R\xe9gion Wallonne']))
loader.save(
    create_cbss_sector(
        169, ['AWIPH', 'AWIPH', 'AWIPH'], 69, 1,
        ['R\xe9gion Wallonne', 'R\xe9gion Wallonne', 'R\xe9gion Wallonne']))
loader.save(
    create_cbss_sector(
        170, [
            'Franstalige Gemeenschap - d\xe9pistage cancer',
            'Franstalige Gemeenschap - d\xe9pistage cancer',
            'Franstalige Gemeenschap - d\xe9pistage cancer'
        ], 69, 2,
        ['R\xe9gion Wallonne', 'R\xe9gion Wallonne', 'R\xe9gion Wallonne']))
loader.save(
    create_cbss_sector(
        171, [
            'Direction G\xe9n\xe9rale Action Sociale et Sant\xe9',
            'Direction G\xe9n\xe9rale Action Sociale et Sant\xe9',
            'Direction G\xe9n\xe9rale Action Sociale et Sant\xe9'
        ], 69, 3,
        ['R\xe9gion Wallonne', 'R\xe9gion Wallonne', 'R\xe9gion Wallonne']))
loader.save(
    create_cbss_sector(
        172, [
            'Direction G\xe9n\xe9rale Agriculture',
            'Direction G\xe9n\xe9rale Agriculture',
            'Direction G\xe9n\xe9rale Agriculture'
        ], 69, 4,
        ['R\xe9gion Wallonne', 'R\xe9gion Wallonne', 'R\xe9gion Wallonne']))
loader.save(
    create_cbss_sector(
        173, [
            "Direction G\xe9n\xe9rale de l'Economie et de l'Emploi",
            "Direction G\xe9n\xe9rale de l'Economie et de l'Emploi",
            "Direction G\xe9n\xe9rale de l'Economie et de l'Emploi"
        ], 69, 5,
        ['R\xe9gion Wallonne', 'R\xe9gion Wallonne', 'R\xe9gion Wallonne']))
loader.save(
    create_cbss_sector(
        174, [
            "Minist\xe8re de l'Equipement et de Transport ",
            "Minist\xe8re de l'Equipement et de Transport ",
            "Minist\xe8re de l'Equipement et de Transport "
        ], 69, 6,
        ['R\xe9gion Wallonne', 'R\xe9gion Wallonne', 'R\xe9gion Wallonne']))
loader.save(
    create_cbss_sector(
        175, [
            'Soci\xe9t\xe9 Wallonne du Logement',
            'Soci\xe9t\xe9 Wallonne du Logement',
            'Soci\xe9t\xe9 Wallonne du Logement'
        ], 69, 7,
        ['R\xe9gion Wallonne', 'R\xe9gion Wallonne', 'R\xe9gion Wallonne']))
loader.save(
    create_cbss_sector(176, [
        'SPF Economie, Classes moyennes et Energie',
        'SPF Economie, Classes moyennes et Energie',
        'SPF Economie, Classes moyennes et Energie'
    ], 70, 0, ['SPF Economie', 'SPF Economie', 'SPF Economie']))
loader.save(
    create_cbss_sector(177, ['BCE', 'BCE', 'BCE'], 70, 1,
                       ['SPF Economie', 'SPF Economie', 'SPF Economie']))
loader.save(
    create_cbss_sector(178, [
        'Direction g\xe9n\xe9rale Politique des Petites et Moyennes Entreprises',
        'Direction g\xe9n\xe9rale Politique des Petites et Moyennes Entreprises',
        'Direction g\xe9n\xe9rale Politique des Petites et Moyennes Entreprises'
    ], 70, 2, ['SPF Economie', 'SPF Economie', 'SPF Economie']))
loader.save(
    create_cbss_sector(179, [
        'Avantage forfaitaire gaz et \xe9lectricit\xe9',
        'Avantage forfaitaire gaz et \xe9lectricit\xe9',
        'Avantage forfaitaire gaz et \xe9lectricit\xe9'
    ], 70, 3, ['SPF Economie', 'SPF Economie', 'SPF Economie']))
loader.save(
    create_cbss_sector(180, ['E-notariat', 'E-notariat', 'E-notariat'], 74, 0,
                       ['E-notariat', 'E-notariat', 'E-notariat']))
loader.save(
    create_cbss_sector(181, ['SPF Justice', 'SPF Justice', 'SPF Justice'], 75,
                       0, ['SPF Justice', 'SPF Justice', 'SPF Justice']))
loader.save(
    create_cbss_sector(182,
                       ['eDepot (FRNB)', 'eDepot (FRNB)', 'eDepot (FRNB)'], 76,
                       0, ['eDepot', 'eDepot', 'eDepot']))
loader.save(
    create_cbss_sector(183,
                       ['FPHP Version 3', 'FPHP Version 3', 'FPHP Version 3'],
                       76, 1, ['eDepot', 'eDepot', 'eDepot']))
loader.save(
    create_cbss_sector(184, [
        'secteur des pensions - deuxi\xe8me pilier',
        'secteur des pensions - deuxi\xe8me pilier',
        'secteur des pensions - deuxi\xe8me pilier'
    ], 77, 0, ['WAP', 'WAP', 'WAP']))
loader.save(
    create_cbss_sector(185, [
        'secteur des pensions - deuxi\xe8me pilier - r\xe9seau secondaire',
        'secteur des pensions - deuxi\xe8me pilier - r\xe9seau secondaire',
        'secteur des pensions - deuxi\xe8me pilier - r\xe9seau secondaire'
    ], 77, 1, ['WAP', 'WAP', 'WAP']))
loader.save(
    create_cbss_sector(186, [
        'Fedict - Guichet de Police virtuel',
        'Fedict - Guichet de Police virtuel',
        'Fedict - Guichet de Police virtuel'
    ], 78, 0, ['e-Police', 'e-Police', 'e-Police']))
loader.save(
    create_cbss_sector(
        187,
        ['Front Office Emploi', 'Front Office Emploi', 'Front Office Emploi'],
        79, 0, ['FO Emploi', 'FO Emploi', 'FO Emploi']))
loader.save(
    create_cbss_sector(188, [
        'ePlatform - Deutschsprachigen Gemeinschaft - r\xe9seau primaire',
        'ePlatform - Deutschsprachigen Gemeinschaft - r\xe9seau primaire',
        'ePlatform - Deutschsprachigen Gemeinschaft - r\xe9seau primaire'
    ], 80, 0, ['e-DG', 'e-DG', 'e-DG']))
loader.save(
    create_cbss_sector(189, [
        'ePlatform - Deutschsprachigen Gemeinschaft - Emploi',
        'ePlatform - Deutschsprachigen Gemeinschaft - Emploi',
        'ePlatform - Deutschsprachigen Gemeinschaft - Emploi'
    ], 80, 1, ['e-DG', 'e-DG', 'e-DG']))
loader.save(
    create_cbss_sector(190, [
        'Office des Etrangers', 'Office des Etrangers', 'Office des Etrangers'
    ], 81, 1, ['SPF Int\xe9rieur', 'SPF Int\xe9rieur', 'SPF Int\xe9rieur']))
loader.save(
    create_cbss_sector(191, [
        'Direction S\xe9curit\xe9 Priv\xe9e',
        'Direction S\xe9curit\xe9 Priv\xe9e',
        'Direction S\xe9curit\xe9 Priv\xe9e'
    ], 81, 2, ['SPF Int\xe9rieur', 'SPF Int\xe9rieur', 'SPF Int\xe9rieur']))
loader.save(
    create_cbss_sector(
        192, ['DSP Contr\xf4le', 'DSP Contr\xf4le', 'DSP Contr\xf4le'], 81, 3,
        ['SPF Int\xe9rieur', 'SPF Int\xe9rieur', 'SPF Int\xe9rieur']))
loader.save(
    create_cbss_sector(193, [
        'Chambre National des Huissiers de Justice',
        'Chambre National des Huissiers de Justice',
        'Chambre National des Huissiers de Justice'
    ], 82, 0, ['CNHJ', 'CNHJ', 'CNHJ']))
loader.save(
    create_cbss_sector(194, [
        'Direction g\xe9n\xe9rale', 'Direction g\xe9n\xe9rale',
        'Direction g\xe9n\xe9rale'
    ], 83, 0, [
        'Communaut\xe9 Fran\xe7aise', 'Communaut\xe9 Fran\xe7aise',
        'Communaut\xe9 Fran\xe7aise'
    ]))
loader.save(
    create_cbss_sector(195, [
        'Service de la recherche', 'Service de la recherche',
        'Service de la recherche'
    ], 83, 1, [
        'Communaut\xe9 Fran\xe7aise', 'Communaut\xe9 Fran\xe7aise',
        'Communaut\xe9 Fran\xe7aise'
    ]))
loader.save(
    create_cbss_sector(196, [
        'ASBL dans le cadre du project FSE',
        'ASBL dans le cadre du project FSE',
        'ASBL dans le cadre du project FSE'
    ], 84, 0, ['ASBLFSE', 'ASBLFSE', 'ASBLFSE']))
loader.save(
    create_cbss_sector(197, ['SNCB', 'SNCB', 'SNCB'], 85, 0,
                       ['SNCB', 'SNCB', 'SNCB']))
loader.save(
    create_cbss_sector(198, [
        'Fonds du logement de la R\xe9gion de Bruxelles-Capitale',
        'Fonds du logement de la R\xe9gion de Bruxelles-Capitale',
        'Fonds du logement de la R\xe9gion de Bruxelles-Capitale'
    ], 86, 0, [
        'F. du logement de la R\xe9gion de Bxl-Cap.',
        'F. du logement de la R\xe9gion de Bxl-Cap.',
        'F. du logement de la R\xe9gion de Bxl-Cap.'
    ]))
loader.save(
    create_cbss_sector(
        199,
        ['Vlaams Woningfonds', 'Vlaams Woningfonds', 'Vlaams Woningfonds'], 87,
        0, ['Vlaams Woningfonds', 'Vlaams Woningfonds', 'Vlaams Woningfonds']))
loader.save(
    create_cbss_sector(200, [
        'Vlaams Agentschap Zorg en Gezondheid',
        'Vlaams Agentschap Zorg en Gezondheid',
        'Vlaams Agentschap Zorg en Gezondheid'
    ], 89, 0, ['VESTA', 'VESTA', 'VESTA']))
loader.save(
    create_cbss_sector(201, [
        'Vlaams Agentschap Zorg en Gezondheid - services priv\xe9s',
        'Vlaams Agentschap Zorg en Gezondheid - services priv\xe9s',
        'Vlaams Agentschap Zorg en Gezondheid - services priv\xe9s'
    ], 89, 1, ['VESTA', 'VESTA', 'VESTA']))
loader.save(
    create_cbss_sector(202, [
        'Belgian Cancer Registry', 'Belgian Cancer Registry',
        'Belgian Cancer Registry'
    ], 90, 0, [
        'Belgian Cancer Registry', 'Belgian Cancer Registry',
        'Belgian Cancer Registry'
    ]))
loader.save(
    create_cbss_sector(203, ['eHealth', 'eHealth', 'eHealth'], 91, 0,
                       ['eHealth', 'eHealth', 'eHealth']))
loader.save(
    create_cbss_sector(204, ['Identifin', 'Identifin', 'Identifin'], 92, 0,
                       ['Identifin', 'Identifin', 'Identifin']))
loader.save(
    create_cbss_sector(205, [
        'Fedict - FSB Testing', 'Fedict - FSB Testing', 'Fedict - FSB Testing'
    ], 93, 0, ['Fedict', 'Fedict', 'Fedict']))
loader.save(
    create_cbss_sector(
        206, ['Fedict - eBirth', 'Fedict - eBirth', 'Fedict - eBirth'], 93, 1,
        ['Fedict', 'Fedict', 'Fedict']))
loader.save(
    create_cbss_sector(207, [
        'Fedict - FRNB (F\xe9d\xe9ration Royale du Notariat Belge)',
        'Fedict - FRNB (F\xe9d\xe9ration Royale du Notariat Belge)',
        'Fedict - FRNB (F\xe9d\xe9ration Royale du Notariat Belge)'
    ], 93, 2, ['Fedict', 'Fedict', 'Fedict']))
loader.save(
    create_cbss_sector(
        208,
        ['FEDIAM SPF Finances', 'FEDIAM SPF Finances', 'FEDIAM SPF Finances'],
        93, 3, ['Fedict', 'Fedict', 'Fedict']))
loader.save(
    create_cbss_sector(209, ['STIB', 'STIB', 'STIB'], 94, 0,
                       ['STIB', 'STIB', 'STIB']))

loader.flush_deferred_objects()

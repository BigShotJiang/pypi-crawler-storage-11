# -*- coding: UTF-8 -*-
logger.info("Loading 13 objects to table users_user...")
# fields: id, email, language, modified, created, start_date, end_date, password, last_login, username, user_type, initials, first_name, last_name, remarks, newcomer_consultations, newcomer_appointments, notify_myself, mail_mode, access_class, event_type, calendar, coaching_type, coaching_supervisor, newcomer_quota, partner
loader.save(
    create_users_user(8, u'', u'de', dt(2018, 12, 16, 8, 7, 38),
                      dt(2018, 12, 16, 8, 7, 34), None, None,
                      u'!udqAMDgTPxcpGvSJZvQhkOXgIlSYcXPix4MPjXLk', None,
                      u'nicolas', None, u'', u'', u'', u'', False, False,
                      False, u'often', u'30', None, 2, None, False, 0, None))
loader.save(
    create_users_user(
        6, u'demo@example.com', u'fr', dt(2018, 12, 16, 8, 8, 20),
        dt(2018, 12, 16, 8, 7, 34), None, None,
        u'pbkdf2_sha256$36000$v20lkVNfUMOv$iGQvgbNIDM3knISsh+vbk2CT1JYR+t3GgNnBzt10EVo=',
        None, u'alicia', '100', u'', u'Alicia', u'Allmanns', u'', True, True,
        False, u'often', u'30', None, 3, 2, False, 100, 184))
loader.save(
    create_users_user(
        9, u'', u'de', dt(2018, 12, 16, 8, 8, 20), dt(2018, 12, 16, 8, 7,
                                                      34), None, None,
        u'pbkdf2_sha256$36000$DtBmRIhS8Fwa$KsOiSBS4erSG5jI9N7ro5EWJB56eVFj07rH00WRM1+0=',
        None, u'caroline', '200', u'', u'Caroline', u'Carnol', u'', True, True,
        False, u'often', u'30', None, 4, 1, False, 0, None))
loader.save(
    create_users_user(
        5, u'demo@example.com', u'de', dt(2018, 12, 16, 8, 8, 20),
        dt(2018, 12, 16, 8, 7, 34), None, None,
        u'pbkdf2_sha256$36000$DvJD4sAefGvf$uFuj9gAySGAoOQBgRxnl65gOPMcekhdhEMkcAzwkA28=',
        None, u'hubert', '100', u'', u'Hubert', u'Huppertz', u'', True, False,
        False, u'often', u'30', None, 5, 2, False, 60, 183))
loader.save(
    create_users_user(
        10, u'demo@example.com', u'de', dt(2018, 12, 16, 8, 8, 20),
        dt(2018, 12, 16, 8, 7, 34), None, None,
        u'pbkdf2_sha256$36000$CTGNGRQuu59O$J+wZ1XKvdDCXdkY2oM5H/fdVXFVmta+EP+nLiuEx1cU=',
        None, u'judith', '400', u'', u'Judith', u'Jousten', u'', True, True,
        False, u'often', u'30', None, 6, 1, False, 0, 186))
loader.save(
    create_users_user(
        13, u'', u'de', dt(2018, 12, 16, 8, 8, 21), dt(2018, 12, 16, 8, 8,
                                                       4), None, None,
        u'pbkdf2_sha256$36000$yqB4KoqO0Fc0$NXthot/dgZ+XUr6M0vOnm55Wn3YjTwkWtFk5F5iEwLg=',
        None, u'kerstin', '300', u'', u'Kerstin', u'Kerres', u'', False, False,
        False, u'often', u'30', None, None, None, False, 0, None))
loader.save(
    create_users_user(
        4, u'demo@example.com', u'fr', dt(2018, 12, 16, 8, 8, 21),
        dt(2018, 12, 16, 8, 7, 34), None, None,
        u'pbkdf2_sha256$36000$7tF0n3uUEkeW$2tOrT8v4mKUaNgxQwh6jkrDiDl41vhCIDosKAiYMi4U=',
        None, u'melanie', '110', u'', u'M\xe9lanie', u'M\xe9lard', u'', False,
        False, False, u'often', u'30', None, 7, 2, False, 50, 182))
loader.save(
    create_users_user(
        11, u'demo@example.com', u'de', dt(2018, 12, 16, 8, 8, 21),
        dt(2018, 12, 16, 8, 7, 34), None, None,
        u'pbkdf2_sha256$36000$jY61kNHU36m9$6zUUK34/loq03qP51B74BTvWuYzso6xOiLwnk0KX+8w=',
        None, u'patrick', '910', u'', u'Patrick', u'Paraneau', u'', False,
        False, False, u'often', u'30', None, 8, None, False, 0, None))
loader.save(
    create_users_user(
        2, u'demo@example.com', u'fr', dt(2018, 12, 16, 8, 8, 21),
        dt(2018, 12, 16, 8, 7, 34), None, None,
        u'pbkdf2_sha256$36000$Qj0TykhnM6Dp$gNwlYI4RiJcjPqy3L3BDSxLSq8JF05qxO4c/oha06Kk=',
        None, u'romain', '900', u'', u'Romain', u'Raffault', u'', False, False,
        False, u'often', u'30', None, 9, None, False, 0, None))
loader.save(
    create_users_user(
        1, u'demo@example.com', u'de', dt(2018, 12, 16, 8, 8, 21),
        dt(2018, 12, 16, 8, 7, 34), None, None,
        u'pbkdf2_sha256$36000$ZOt6vuzleppp$t3pox0Zu4MDAAk13RSecobWT/Lxq/1VU1DQqWxmXbDo=',
        None, u'rolf', '900', u'', u'Rolf', u'Rompen', u'', False, False,
        False, u'often', u'30', None, 10, None, False, 0, None))
loader.save(
    create_users_user(
        3, u'demo@example.com', u'en', dt(2018, 12, 16, 8, 8, 21),
        dt(2018, 12, 16, 8, 7, 34), None, None,
        u'pbkdf2_sha256$36000$pJtvgRkDJfAv$3pLuTOFS3mB4mzbzhE+A8boPr4xrt97q/XVtTfoPgm4=',
        None, u'robin', '900', u'', u'Robin', u'Rood', u'', False, False,
        False, u'often', u'30', None, 11, None, False, 0, None))
loader.save(
    create_users_user(
        7, u'demo@example.com', u'de', dt(2018, 12, 16, 8, 8, 21),
        dt(2018, 12, 16, 8, 7, 34), None, None,
        u'pbkdf2_sha256$36000$BBbItwvEQ3JR$Xn1N6I/15HnwS9Luzn77AIWPYES2AWQnAgRPAPGZK9k=',
        None, u'theresia', '210', u'', u'Theresia', u'Thelen', u'', False,
        False, False, u'often', u'30', None, 12, None, False, 0, 185))
loader.save(
    create_users_user(
        12, u'', u'de', dt(2018, 12, 16, 8, 8, 21), dt(2018, 12, 16, 8, 7,
                                                       38), None, None,
        u'pbkdf2_sha256$36000$V0fXI07GHRSn$jgg+yj+1tPG4QSp6fpPWAUWTPpT07tofcaIXbLOTOW8=',
        None, u'wilfried', '500', u'', u'Wilfried', u'Willems', u'', False,
        False, False, u'often', u'30', None, None, None, False, 0, None))

loader.flush_deferred_objects()

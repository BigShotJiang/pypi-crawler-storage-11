# -*- coding: UTF-8 -*-
logger.info("Loading 20 objects to table xcourses_courserequest...")
# fields: id, person, offer, content, date_submitted, urgent, state, course, remark, date_ended
loader.save(
    create_xcourses_courserequest(1, 116, None, 1, date(2014, 5, 22), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(2, 118, None, 2, date(2014, 5, 20), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(3, 124, None, 1, date(2014, 5, 18), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(4, 127, None, 2, date(2014, 5, 16), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(5, 128, None, 1, date(2014, 5, 14), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(6, 129, None, 2, date(2014, 5, 12), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(7, 130, None, 1, date(2014, 5, 10), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(8, 132, None, 2, date(2014, 5, 8), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(9, 133, None, 1, date(2014, 5, 6), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(10, 137, None, 2, date(2014, 5, 4), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(11, 139, None, 1, date(2014, 5, 2), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(12, 141, None, 2, date(2014, 4, 30), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(13, 142, None, 1, date(2014, 4, 28), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(14, 144, None, 2, date(2014, 4, 26), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(15, 146, None, 1, date(2014, 4, 24), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(16, 147, None, 2, date(2014, 4, 22), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(17, 152, None, 1, date(2014, 4, 20), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(18, 153, None, 2, date(2014, 4, 18), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(19, 155, None, 1, date(2014, 4, 16), False,
                                  u'10', None, None, None))
loader.save(
    create_xcourses_courserequest(20, 157, None, 2, date(2014, 4, 14), False,
                                  u'10', None, None, None))

loader.flush_deferred_objects()

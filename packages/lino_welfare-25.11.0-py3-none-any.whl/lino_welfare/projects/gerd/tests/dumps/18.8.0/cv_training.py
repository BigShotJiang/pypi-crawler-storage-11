# -*- coding: UTF-8 -*-
logger.info("Loading 20 objects to table cv_training...")
# fields: id, start_date, end_date, country, city, zip_code, sector, function, person, duration_text, language, school, state, remarks, type, content, certificates
loader.save(
    create_cv_training(1, date(2011, 2, 7), date(2011, 3,
                                                 7), u'BQAQ', None, u'', 3, 3,
                       142, u'', None, u'', u'0', None, 9, u'', u''))
loader.save(
    create_cv_training(2, date(2011, 2, 9), date(2011, 4, 9), u'BR', None, u'',
                       4, 4, 144, u'', None, u'Darul Uloom Leicester', u'1',
                       None, 10, u'', u''))
loader.save(
    create_cv_training(3, date(2011, 2, 11), date(2011, 5,
                                                  11), u'BS', None, u'', 5, 1,
                       146, u'', None, u'Emmanuel Christian School, Leicester',
                       u'2', None, 11, u'', u''))
loader.save(
    create_cv_training(4, date(2011, 2, 13), date(2011, 8,
                                                  13), u'BT', None, u'', 6, 2,
                       147, u'', None, u'Leicester High School for Girls',
                       u'0', None, 9, u'', u''))
loader.save(
    create_cv_training(5, date(2011, 2, 15), date(2011, 8, 15), u'BUMM', None,
                       u'', 7, 3, 152, u'', None, u'Leicester Grammar School',
                       u'1', None, 10, u'', u''))
loader.save(
    create_cv_training(6, date(2011, 2, 17), date(2011, 11, 17), u'BV', None,
                       u'', 8, 4, 153, u'', None, u'Leicester Islamic Academy',
                       u'2', None, 11, u'', u''))
loader.save(
    create_cv_training(7, date(2011, 2, 19), date(2012, 2,
                                                  19), u'BW', None, u'', 9, 1,
                       155, u'', None, u'Leicester Montessori School', u'0',
                       None, 9, u'', u''))
loader.save(
    create_cv_training(8, date(2011, 2, 21), date(2012, 2, 21), u'BY', None,
                       u'', 10, 2, 157, u'', None, u'Sathya Sai School', u'1',
                       None, 10, u'', u''))
loader.save(
    create_cv_training(9, date(2011, 2, 23), date(2013, 2, 23), u'BYAA', None,
                       u'', 11, 3, 159, u'', None, u'Stoneygate School', u'2',
                       None, 11, u'', u''))
loader.save(
    create_cv_training(10, date(2011, 2, 25), date(2013, 2, 25), u'BZ', None,
                       u'', 12, 4, 161, u'', None, u"St Crispin's School",
                       u'0', None, 9, u'', u''))
loader.save(
    create_cv_training(11, date(2011, 2, 27), date(2011, 3,
                                                   27), u'CA', None, u'', 13,
                       1, 165, u'', None, u'', u'1', None, 10, u'', u''))
loader.save(
    create_cv_training(12, date(2011, 3, 1), date(2011, 5, 1), u'CC', None,
                       u'', 14, 2, 166, u'', None, u'Leicester College', u'2',
                       None, 11, u'', u''))
loader.save(
    create_cv_training(13, date(2011, 3, 3), date(2011, 6, 3), u'CD', None,
                       u'', 1, 3, 168, u'', None, u'Gateway College', u'0',
                       None, 9, u'', u''))
loader.save(
    create_cv_training(14, date(2011, 3, 5), date(2011, 9, 5), u'CF', None,
                       u'', 2, 4, 173, u'', None, u'Regent College, Leicester',
                       u'1', None, 10, u'', u''))
loader.save(
    create_cv_training(15, date(2011, 3,
                                7), date(2011, 9,
                                         7), u'CG', None, u'', 3, 1, 177, u'',
                       None, u'Wyggeston and Queen Elizabeth I College', u'2',
                       None, 11, u'', u''))
loader.save(
    create_cv_training(16, date(2011, 3, 9), date(2011, 12,
                                                  9), u'CH', None, u'', 4, 2,
                       178, u'', None, u'', u'0', None, 9, u'', u''))
loader.save(
    create_cv_training(17, date(2011, 3, 11), date(2012, 3, 11), u'CI', None,
                       u'', 5, 3, 179, u'', None, u'Darul Uloom Leicester',
                       u'1', None, 10, u'', u''))
loader.save(
    create_cv_training(18, date(2011, 3, 13), date(2012, 3,
                                                   13), u'CK', None, u'', 6, 4,
                       180, u'', None, u'Emmanuel Christian School, Leicester',
                       u'2', None, 11, u'', u''))
loader.save(
    create_cv_training(19, date(2011, 3, 15), date(2013, 3,
                                                   15), u'CL', None, u'', 7, 1,
                       181, u'', None, u'Leicester High School for Girls',
                       u'0', None, 9, u'', u''))
loader.save(
    create_cv_training(20, date(2011, 3, 17), date(2013, 3, 17), u'CM', None,
                       u'', 8, 2, 116, u'', None, u'Leicester Grammar School',
                       u'1', None, 10, u'', u''))

loader.flush_deferred_objects()

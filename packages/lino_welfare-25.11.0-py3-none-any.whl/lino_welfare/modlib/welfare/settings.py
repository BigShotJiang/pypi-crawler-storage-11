# -*- coding: UTF-8 -*-
# Copyright 2009-2021 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""Default settings of a :ref:`welfare` project.

"""

from lino.projects.std.settings import *


class Site(Site):
    """
    The base class for all Lino Welfare applications.
    """

    demo_fixtures = """std std2 few_languages demo
    demo2 demo3 cbss checkdata""".split()

    # languages = 'en fr de nl'
    # hidden_languages = 'nl'

    migration_class = 'lino_welfare.migrate.Migrator'
    project_model = 'pcsw.Client'
    userdocs_prefix = 'welfare.'
    auto_configure_logger_names = 'lino lino_xl lino_welfare'
    # verbose_client_info_message = True

    # default_ui = "lino_react.react" # does not yet work because "Tried to get
    # static handle for debts.PrintEntriesByBudget"

    # default_build_method = "appyodt"
    default_build_method = "appypdf"
    uppercase_last_name = True

    user_types_module = 'lino_welfare.modlib.welfare.user_types'
    workflows_module = 'lino_welfare.modlib.welfare.workflows'

    def get_plugin_configs(self):
        yield super().get_plugin_configs()
        yield ('clients', 'client_model', 'pcsw.Client')
        yield ('clients', 'demo_coach', 'hubert')
        yield ('addresses', 'partner_model', 'contacts.Partner')
        yield ('excerpts', 'responsible_user', 'melanie')
        # if 'accounting' in self.plugins:
        yield ('accounting', 'ref_length', 16)
        yield ('accounting', 'project_model', 'pcsw.Client')
        yield ('cal', 'mytasks_start_date', -30)
        # yield ('help', 'interproject_specs', 'lino_welfare')
        yield ('contacts', 'show_birthdays', False)
        if self.default_ui == "lino.modlib.extjs":
            yield ('calview', 'hidden', True)

    def setup_quicklinks(self, user, tb):
        # tb.add_action(self.modules.pcsw.Clients.detail_action)
        super().setup_quicklinks(user, tb)
        tb.add_action("pcsw.Clients.find_by_beid")
        tb.add_action(self.modules.integ.Clients)
        tb.add_action(self.modules.isip.MyContracts)
        # if self.is_installed("art60"):
        #     tb.add_action(self.modules.art60.MyContracts)
        # else:
        #     tb.add_action(self.modules.jobs.MyContracts)
        tb.add_action(self.modules.cal.EntriesByDay)

    def get_installed_plugins(self):
        yield 'lino_welfare.modlib.system'
        # our custom system plugin must come before super() to avoid having
        # lino.modlib.system loaded
        yield super().get_installed_plugins()
        yield 'lino.modlib.help'
        yield 'lino_xl.lib.statbel.countries'
        yield 'lino_welfare.modlib.contacts'

        # yield 'lino.modlib.gfks'
        yield 'lino_xl.lib.appypod'
        yield 'django.contrib.humanize'  # translations for
        yield 'lino_welfare.modlib.users'
        yield 'lino.modlib.notify'
        yield 'lino.modlib.changes'

        yield 'lino_xl.lib.properties'
        yield 'lino_xl.lib.addresses'

        yield 'lino_xl.lib.excerpts'

        yield 'lino_xl.lib.uploads'
        yield 'lino_xl.lib.outbox'

        yield 'lino_xl.lib.extensible'
        yield 'lino_welfare.modlib.cal'

        yield 'lino_xl.lib.calview'

        yield 'lino_welfare.modlib.reception'
        yield 'lino_welfare.modlib.badges'
        yield 'lino_xl.lib.boards'

        yield 'lino_welfare.modlib.pcsw'
        # yield 'lino_xl.lib.clients'
        # yield 'lino_xl.lib.coachings'
        yield 'lino_welfare.modlib.welfare'

        # NOTE: ordering influences (1) main menu (2) fixtures loading
        # e.g. pcsw.demo creates clients needed by cbss.demo
        # yield 'lino_welfare.modlib.trading'
        # yield 'lino_welfare.modlib.pcsw'
        yield 'lino_welfare.modlib.accounting'
        yield 'lino_welfare.modlib.sepa'
        yield 'lino_xl.lib.b2c'
        yield 'lino_welfare.modlib.finan'
        # yield 'lino_xl.lib.bevats'

        # yield 'lino_xl.lib.accounting'
        yield 'lino_xl.lib.vatless'
        if False:  # not sure whether they make sense
            yield 'lino_welfare.modlib.client_vouchers'
        # yield 'lino_xl.lib.finan'

        yield 'lino_welcht.lib.cv'
        yield 'lino_welfare.modlib.integ'
        yield 'lino_welfare.modlib.isip'
        yield 'lino_welfare.modlib.jobs'
        yield 'lino_welfare.modlib.art61'
        yield 'lino_welfare.modlib.immersion'
        yield 'lino_welfare.modlib.active_job_search'
        yield 'lino_welcht.lib.courses'
        yield 'lino_welfare.modlib.xcourses'
        yield 'lino_welfare.modlib.newcomers'
        yield 'lino_welfare.modlib.cbss'  # must come after pcsw
        yield 'lino_welfare.modlib.households'  # must come after pcsw
        yield 'lino_xl.lib.humanlinks'  # must come after households
        yield 'lino_welfare.modlib.debts'  # must come after households
        # The `notes` demo fixture creates Notes for Clients.
        yield 'lino_welfare.modlib.notes'
        yield 'lino_welfare.modlib.aids'
        # yield 'lino_welfare.modlib.projects'
        yield 'lino_welfare.modlib.polls'
        yield 'lino_welfare.modlib.esf'

        yield 'lino_xl.lib.beid'
        # yield 'lino.modlib.davlink'
        yield 'lino.modlib.dashboard'

        yield 'lino.modlib.export_excel'
        yield 'lino_welfare.modlib.dupable_clients'
        yield 'lino.modlib.checkdata'
        if self.default_ui == "lino.modlib.extjs":
            yield 'lino.modlib.tinymce'

    def get_dashboard_items(self, user):
        """Returns the items of the admin index page:

        - :class:`lino_welfare.modlib.integ.models.UsersWithClients`
        - :class:`lino_welfare.modlib.reception.models.MyWaitingVisitors`
        - :class:`lino_xl.lib.cal.MyEntries`
        - :class:`lino_xl.lib.cal.MyTasks`
        - ...


        """
        if user.is_authenticated:
            yield self.modules.integ.UsersWithClients
            yield self.modules.reception.MyWaitingVisitors
            yield self.modules.reception.WaitingVisitors
            yield self.modules.cal.MyEntries
            yield self.modules.cal.MyTasks
            yield self.models.cal.MyOverdueAppointments
            # ~ yield self.modules.reception.ReceivedVisitors
            yield self.models.notify.MyMessages

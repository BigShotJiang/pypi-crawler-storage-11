def hello():
    print("hello")
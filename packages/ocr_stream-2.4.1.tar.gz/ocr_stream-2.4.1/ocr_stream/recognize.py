#!/usr/bin/env python3
from __future__ import annotations
from convert_stream import DocumentPdf, PageDocumentPdf
from convert_stream.pdf import ConvertPdfToImages
from convert_stream.image import ImageObject
from ocr_stream.bin_tess import BinTesseract
from ocr_stream.modules import LibOcr, DEFAULT_LIB_OCR
from ocr_stream.ocr import TesseractOcr, TextRecognized
from pandas import DataFrame
import soup_files as sp


class VoidPbar(sp.ABCProgressBar):

    def __init__(self):
        super().__init__()

    def set_percent(self, percent: float):
        pass

    def set_text(self, text: str):
        pass


class ProgressVoid(sp.ProgressBarAdapter):

    def __init__(self, progress_bar: sp.ABCProgressBar = VoidPbar()):
        super().__init__(progress_bar)

    def update(self, percent: float, status: str = "-"):
        pass

    def update_percent(self, percent: float = 0):
        pass

    def update_text(self, text: str = "-"):
        pass


class RecognizeImage(object):
    """
        Reconhecer textos em imagens com pytesseract|pyocr usando o tesseract
    """

    def __init__(
                self,
                bin_tess: BinTesseract = BinTesseract(), *,
                lib_ocr: LibOcr = DEFAULT_LIB_OCR
            ):
        super().__init__()
        self.module_ocr: TesseractOcr = TesseractOcr.create(
            bin_tess,
            lib_ocr=lib_ocr,
            lang=bin_tess.get_lang(),
            tess_data_dir=bin_tess.get_tessdata_dir(),
        )

    @property
    def bin_tesseract(self) -> BinTesseract:
        return self.module_ocr.mod_ocr.bin_tess

    def image_content_data(self, img: ImageObject | sp.File) -> DataFrame:
        """
        Retorna uma tabela estruturada com os dados reconhecidos da imagem.

        Este método extrai as informações contidas em uma imagem e as organiza em
        um DataFrame com colunas como o texto detectado, coordenadas da caixa delimitadora,
        nível do OCR e confiabilidade, entre outras.

        Parâmetros:
        img (ImageObject | sp.File): A imagem a ser processada, podendo ser um objeto
        `ImageObject` ou um arquivo `sp.File`.

        Retorna:
        DataFrame: Uma tabela contendo os dados reconhecidos na imagem.

        Lança:
        ValueError: Se o tipo do parâmetro `img` não for `ImageObject` ou `sp.File`.

        @param img: Imagem a ser processada, podendo ser uma instância de `ImageObject`
            ou um arquivo `sp.File`.
        @type img: ImageObject | sp.File

        @rtype: pandas.DataFrame
        @return: Um DataFrame com os dados reconhecidos na imagem.

        @raise ValueError: Caso o tipo de `img` não seja `ImageObject` nem `sp.File`.
        """
        return self.image_recognize(img).to_dataframe()

    def image_recognize(self, img: ImageObject | sp.File, *, land_scape: bool = False) -> TextRecognized:
        if isinstance(img, sp.File):
            img = ImageObject(img)
        if land_scape:
            img.set_landscape()
        rec: TextRecognized = self.module_ocr.to_reconize(img)
        return rec

    def image_to_string(self, img: ImageObject | sp.File) -> str:
        return self.module_ocr.to_string(img)


class RecognizePdf(object):

    def __init__(
                self,
                bin_tess: BinTesseract = BinTesseract(), *,
                lib_ocr: LibOcr = DEFAULT_LIB_OCR,
            ):
        self.recognize_image: RecognizeImage = RecognizeImage(bin_tess, lib_ocr=lib_ocr)
        self.pbar: sp.ProgressBarAdapter = sp.CreatePbar().get()

    def set_pbar(self, p: sp.ProgressBarAdapter):
        self.pbar = p

    def recognize_page_pdf(self, page: PageDocumentPdf, *, dpi: int = 300) -> DocumentPdf:
        """
            Converte a página em Imagem, reconhece o texto com OCR e
        retorna uma nova página com o texto reconhecido.
        """
        _doc = DocumentPdf.create_from_pages([page])
        _conv = ConvertPdfToImages.create(_doc)
        _conv.set_pbar(self.pbar)
        img: ImageObject = _conv.to_images(dpi=dpi)[0]
        text_recognized: TextRecognized = self.recognize_image.image_recognize(img)
        del _doc
        del _conv
        del img
        text_recognized.metadata.file_path = page.metadata.file_path
        text_recognized.metadata.dir_path = page.metadata.dir_path
        return text_recognized.to_document()

    def recognize_document(self, doc: DocumentPdf, *, dpi: int = 300) -> DocumentPdf:
        _pages: list[PageDocumentPdf] = []
        _pages.clear()
        _conv = ConvertPdfToImages.create(doc)
        _conv.set_pbar(self.pbar)
        images: list[ImageObject] = _conv.to_images(dpi=dpi)
        max_num: int = len(images)
        for num, img in enumerate(images):
            self.pbar.update(
                ((num + 1) / max_num) * 100,
                f'OCR Documento [{num+1} de {max_num}]'
            )
            text_recognized = self.recognize_image.image_recognize(img)
            _pages.append(text_recognized.to_page_pdf())
        print()
        self.pbar.stop()
        new_doc = DocumentPdf.create_from_pages(_pages)
        new_doc.metadata = doc.metadata
        return new_doc

    def recognize_file_pdf(self, file: sp.File, *, dpi: int = 300) -> DocumentPdf:
        file_doc = DocumentPdf.create_from_file(file)
        recognized_doc = self.recognize_document(file_doc, dpi=dpi)
        del file_doc
        return recognized_doc

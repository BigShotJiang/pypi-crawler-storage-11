#!/usr/bin/env python3
from __future__ import annotations
from io import BytesIO
from ocr_stream.modules import *
from ocr_stream.bin_tess import BinTesseract, get_path_tesseract_sys
from ocr_stream.ocr import TesseractOcr, TextRecognized
from ocr_stream.recognize import (
    RecognizeImage, RecognizePdf, VoidPbar, ProgressVoid
)
import convert_stream as cs
import pandas as pd
import soup_files as sp

__version__ = '2.4'


def read_image(img: cs.ImageObject, rec: RecognizeImage = RecognizeImage()) -> TextRecognized:
    _txt = rec.image_recognize(img)
    _txt.metadata = img.metadata
    return _txt


def read_images(
            images: list[cs.ImageObject], *,
            rec: RecognizeImage = RecognizeImage(),
            pbar: sp.ProgressBarAdapter = sp.CreatePbar().get()
        ) -> cs.DocumentPdf:
    pbar.start()
    print()
    max_num = len(images)
    pages = []

    for idx, image in enumerate(images):
        pbar.update(
            ((idx + 1) / max_num) * 100,
            f'[OCR IMAGENS] {idx + 1} / {max_num}',
        )
        out = read_image(image, rec=rec).to_page_pdf()
        pages.append(out)
    tmp_doc = cs.DocumentPdf.create_from_pages(pages)
    print()
    pbar.stop()
    return tmp_doc


def read_document(
            document: cs.DocumentPdf, *,
            dpi: int = 300,
            pbar: sp.ProgressBarAdapter = sp.CreatePbar().get()
        ) -> cs.DocumentPdf:
    pbar.start()
    print()
    _metadata: cs.MetaDataFile = document.metadata
    recognized_items: list[TextRecognized] = []
    pages_pdf: list[cs.PageDocumentPdf] = document.to_pages()
    total = len(pages_pdf)
    void_pbar = ProgressVoid()
    for num, page in enumerate(pages_pdf):
        pbar.update(
            ((num + 1) / total) * 100,
            f'[OCR PDF] {num + 1}/{total} {page.metadata.name}',
        )
        convert: cs.ConvertPdfToImages = cs.ConvertPdfToImages(cs.DocumentPdf.create_from_pages([page]))
        convert.set_pbar(void_pbar)
        images: list[cs.ImageObject] = convert.to_images(dpi=dpi)
        for im in images:
            recognized_items.append(read_image(im))
    print()
    final_pages: list[cs.PageDocumentPdf] = [x.to_page_pdf() for x in recognized_items]
    final_doc: cs.DocumentPdf = cs.DocumentPdf.create_from_pages(final_pages)
    final_doc.metadata = _metadata
    return final_doc


class SearchableTextImage(object):
    """

    return {
            cs.ColumnsTable.KEY.value: cs.ColumnBody(cs.ColumnsTable.KEY.value, ListString([])),
            cs.ColumnsTable.NUM_PAGE.value: cs.ColumnBody(cs.ColumnsTable.NUM_PAGE.value, ListString([])),
            cs.ColumnsTable.NUM_LINE.value: cs.ColumnBody(cs.ColumnsTable.NUM_LINE.value, ListString([])),
            cs.ColumnsTable.TEXT.value: cs.ColumnBody(cs.ColumnsTable.TEXT.value, ListString([])),
            cs.ColumnsTable.FILE_NAME.value: cs.ColumnBody(cs.ColumnsTable.FILE_NAME.value, ListString([])),
            cs.ColumnsTable.FILETYPE.value: cs.ColumnBody(cs.ColumnsTable.FILETYPE.value, ListString([])),
            cs.ColumnsTable.FILE_PATH.value: cs.ColumnBody(cs.ColumnsTable.FILE_PATH.value, ListString([])),
            cs.ColumnsTable.DIR.value: cs.ColumnBody(cs.ColumnsTable.DIR.value, ListString([])),
        }
    """
    def __init__(self, silent: bool = False):
        self.silent = silent
        self.elements: cs.DictTextTable = cs.DictTextTable.create_void_dict()

    def __repr__(self):
        return f'SearchableTextPdf: {self.elements}'

    @property
    def length(self) -> int:
        return len(self.elements[cs.ColumnsTable.TEXT.value])

    def is_empty(self) -> bool:
        return len(self.elements[cs.ColumnsTable.TEXT.value]) == 0

    @property
    def columns(self) -> cs.HeadValues:
        return cs.HeadValues([cs.HeadCell(x) for x in list(self.elements.keys())])

    @property
    def first(self) -> dict[str, str]:
        if self.is_empty():
            return {}
        cols = self.columns
        _first = {}
        for c in cols:
            _first[c] = self.elements[c][0]
        return _first

    @property
    def last(self) -> dict[str, str]:
        if self.is_empty():
            return {}
        if self.is_empty():
            return {}
        cols = self.columns
        _last = {}
        for c in cols:
            _last[c] = self.elements[c][-1]
        return _last

    def get_item(self, idx: int) -> dict[str, str]:
        _current_item = {}
        cols = self.columns
        try:
            for col in cols:
                _current_item[col] = self.elements[col][idx]
        except Exception as err:
            if not self.silent:
                print(err)
            return _current_item
        else:
            return _current_item

    def add_line(self, line: dict[str, str]) -> None:
        cols: cs.HeadValues = self.columns
        cols_line: cs.HeadValues = cs.HeadValues([cs.HeadCell(y) for y in list(line.keys())])
        for col in cols:
            if cols_line.contains(col, case=True, iqual=True):
                self.elements[col].append(line[col])

    def clear(self) -> None:
        for _k in self.elements.keys():
            self.elements[_k].clear()

    def to_string(self) -> str:
        """
            Retorna o texto da coluna TEXT em formato de string
        ou 'nas' em caso de erro nas = Not a String
        """
        try:
            return ' '.join(self.elements[cs.ColumnsTable.TEXT.value])
        except Exception as e:
            print(e)
            return 'nas'

    def to_data_frame(self) -> pd.DataFrame:
        return pd.DataFrame.from_dict(self.elements)

    def to_file_json(self, file: sp.File):
        """Exporta os dados da busca para um arquivo JSON"""
        dt = sp.JsonConvert.from_dict(self.elements).to_json_data()
        dt.to_file(file)

    def to_file_excel(self, file: sp.File):
        """Exporta os dados da busca para um arquivo .XLSX"""
        self.to_data_frame().to_excel(file.absolute(), index=False)


class ImageFinder(object):
    """
        Classe para Filtrar texto em Imagens
    """

    def __init__(self):
        self.docs_collection: dict[str, cs.ImageObject] = {}
        self.recognize: RecognizeImage = RecognizeImage()
        self.pbar: sp.ProgressBarAdapter = sp.ProgressBarAdapter()

    def is_empty(self) -> bool:
        return len(self.docs_collection) == 0

    def clear(self) -> None:
        self.docs_collection.clear()

    def add_image(self, img: sp.File | bytes | BytesIO | str | cs.ImageObject) -> None:
        if isinstance(img, sp.File):
            img = cs.ImageObject(img)
        elif isinstance(img, cs.ImageObject):
            pass
        elif isinstance(img, bytes):
            img = cs.ImageObject(img)
        elif isinstance(img, str):
            img = cs.ImageObject(img)
        elif isinstance(img, BytesIO):
            img = cs.ImageObject(img)

        if not img.metadata.file_path.is_empty:
            self.docs_collection[img.metadata.file_path] = img
        else:
            self.docs_collection[img.metadata.name] = img

    def add_images(self, images: list[sp.File] | list[cs.ImageObject] | list[bytes] | list[BytesIO]) -> None:
        for f in images:
            self.add_image(f)

    def add_directory_images(self, dir_pdf: sp.Directory) -> None:
        files = sp.InputFiles(dir_pdf).get_files(file_type=sp.LibraryDocs.IMAGE)
        if len(files) > 0:
            self.add_images(files)

    def find(
            self, text: str,
            separator: str = '\n',
            iqual: bool = False,
            case: bool = False,
            silent: bool = False,
            ) -> SearchableTextImage:
        """
            Filtrar texto retornando a primeira ocorrência do Documento PDF.
        """
        _searchable = SearchableTextImage(silent)
        if self.is_empty():
            return _searchable

        total_num: int = len(self.docs_collection.keys())
        for n, file_key in enumerate(self.docs_collection.keys()):
            self.pbar.update(
                ((n + 1) / total_num) * 100,
                f'[PESQUISANDO]: {n+1}/{total_num}',
            )

            current_img: cs.ImageObject = self.docs_collection[file_key]
            txt_in_img = self.recognize.image_to_string(current_img)
            if (txt_in_img == '') or (txt_in_img is None):
                self.pbar.update_text(f'ERRO: {n+1} {current_img.metadata.name}')
                continue
            try:
                fd = cs.text.FindText(txt_in_img, separator=separator)
                idx = fd.find_index(text, iqual=iqual, case=case)
                if idx is None:
                    continue
                math_text: str | None = fd.get_index(idx)
            except Exception as err:
                print(f'{__class__.__name__} {err}')
            else:
                new_line: dict[str, str] = {
                    cs.ColumnsTable.KEY.value: f'{idx}',
                    cs.ColumnsTable.NUM_PAGE.value: 'nan',
                    cs.ColumnsTable.NUM_LINE.value: f'{idx + 1}',
                    cs.ColumnsTable.TEXT.value: math_text,
                    cs.ColumnsTable.FILE_NAME.value: current_img.metadata.file_path,
                    cs.ColumnsTable.FILETYPE.value: current_img.metadata.extension,
                    cs.ColumnsTable.FILE_PATH.value: current_img.metadata.dir_path,
                    cs.ColumnsTable.DIR.value: current_img.metadata.dir_path,
                }
                _searchable.add_line(new_line)
                return _searchable
        return _searchable

    def find_all(
                self, text: str,
                separator: str = '\n',
                iqual: bool = False,
                case: bool = False,
                silent: bool = False,
            ) -> SearchableTextImage:
        """
            Filtrar texto em documento PDF e retorna todas as ocorrências do texto
        encontradas no documento, incluindo o número da linha, página e nome do arquivo
        em cada ocorrência.
        """
        _searchable = SearchableTextImage(silent)
        if self.is_empty():
            return _searchable

        total_num: int = len(self.docs_collection.keys())
        for n, file_key in enumerate(self.docs_collection.keys()):
            self.pbar.update(
                ((n + 1) / total_num) * 100,
                f'[PESQUISANDO]: {n + 1}/{total_num}',
            )

            current_img: cs.ImageObject = self.docs_collection[file_key]
            txt_in_img = self.recognize.image_to_string(current_img)
            if (txt_in_img == '') or (txt_in_img is None):
                self.pbar.update_text(f'ERRO: {n + 1} {current_img.metadata.name}')
                continue
            try:
                fd = cs.text.FindText(txt_in_img, separator=separator)
                idx = fd.find_index(text, iqual=iqual, case=case)
                if idx is None:
                    continue
                math_text: str | None = fd.get_index(idx)
            except Exception as err:
                print(f'{__class__.__name__} {err}')
            else:
                new_line: dict[str, str] = {
                    cs.ColumnsTable.KEY.value: f'{idx}',
                    cs.ColumnsTable.NUM_PAGE.value: 'nan',
                    cs.ColumnsTable.NUM_LINE.value: f'{idx + 1}',
                    cs.ColumnsTable.TEXT.value: math_text,
                    cs.ColumnsTable.FILE_NAME.value: current_img.metadata.file_path,
                    cs.ColumnsTable.FILETYPE.value: current_img.metadata.extension,
                    cs.ColumnsTable.FILE_PATH.value: current_img.metadata.dir_path,
                    cs.ColumnsTable.DIR.value: current_img.metadata.dir_path,
                }
                _searchable.add_line(new_line)
        return _searchable


__all__ = [
    'ImageFinder', 'SearchableTextImage', 'read_images',
    'read_document', 'RecognizeImage', 'RecognizePdf', 'VoidPbar', 'ProgressVoid'
]

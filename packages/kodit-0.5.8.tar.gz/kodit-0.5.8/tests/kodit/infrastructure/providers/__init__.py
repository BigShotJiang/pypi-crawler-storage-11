"""Tests for infrastructure providers."""

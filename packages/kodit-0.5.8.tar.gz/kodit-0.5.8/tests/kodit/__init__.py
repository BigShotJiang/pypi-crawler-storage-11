"""Test package for kodit."""

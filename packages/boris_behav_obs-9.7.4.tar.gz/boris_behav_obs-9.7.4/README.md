BORIS (Behavioral Observation Research Interactive Software)
===============================================================


![BORIS logo](https://github.com/olivierfriard/BORIS/blob/master/boris/icons/logo_boris.png?raw=true)

BORIS is an easy-to-use event logging software for video/audio coding or live observations.

BORIS is a free and open-source software available for GNU/Linux, Windows and macOS.

It provides also some analysis tools like time budget and some plotting functions.

<!-- The BO-RIS paper has more than [![BORIS citations counter](https://penelope.unito.it/friard/boris_scopus_citations.png) citations](https://www.boris.unito.it/citations) in peer-reviewed scientific publications. -->


The BORIS paper has more than 2423 citations in peer-reviewed scientific publications.




See the official [BORIS web site](https://www.boris.unito.it).

<a href="https://www.boris.unito.it" target="_blank"><img alt="Website" src="https://img.shields.io/website?url=https%3A%2F%2Fwww.boris.unito.it"></a>
<a href="https://www.boris.unito.it/user_guide/" target="_blank"><img alt="User guide" src="https://img.shields.io/badge/Documentation-orange"></a>
[![Python web site](https://img.shields.io/badge/Made%20with-Python-1f425f.svg)](https://www.python.org)
![Python versions](https://img.shields.io/pypi/pyversions/boris-behav-obs)
![BORIS license](https://img.shields.io/pypi/l/boris-behav-obs)
[![PyPI version](https://img.shields.io/pypi/v/boris-behav-obs.svg)](https://pypi.org/project/boris-behav-obs/)

[![Number of downloads](https://static.pepy.tech/personalized-badge/boris-behav-obs?period=total&units=international_system&left_color=black&right_color=orange&left_text=Downloads)](https://pepy.tech/project/boris-behav-obs)
![commit-activity](https://img.shields.io/github/commit-activity/m/olivierfriard/BORIS)
![GitHub last commit](https://img.shields.io/github/last-commit/olivierfriard/BORIS)

![BORIS scopus citations badge](https://penelope.unito.it/friard/boris_scopus_citations.svg)


![GitHub Repo stars](https://img.shields.io/github/stars/olivierfriard/BORIS?style=flat&label=Stars)
[![Please Star](https://img.shields.io/badge/⭐-Star%20this%20repo-blue?style=flat-square)](https://github.com/olivierfriard/BORIS/stargazers)

# Documentation



The [user guide](https://www.boris.unito.it/user_guide/) provides a good starting point for learning how to use BORIS.

Some [video tutorials](https://www.boris.unito.it/video_tutorials/) are available.





# Bug reports and feature requests


To search for bugs, report them or request a feature, please use the [GitHub issues tracker](https://github.com/olivierfriard/BORIS/issues)





# Citing BORIS


Please acknowledge and cite the use of this software and its authors when
results are used in publications or published elsewhere. You can use the
following BibTex entry

```
@article {MEE3:MEE312584,
    author = {Friard, Olivier and Gamba, Marco},
   title = {BORIS: a free, versatile open-source event-logging software for video/audio coding and live observations},
   journal = {Methods in Ecology and Evolution},
   issn = {2041-210X},
   url = {http://dx.doi.org/10.1111/2041-210X.12584},
   doi = {10.1111/2041-210X.12584},
   pages = {1324--1330},
    year = {2016},
}
```

You can also send us a nice postcard! See the [user testimonials](https://www.boris.unito.it/postcards).








# Licence


This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.


Distributed with a [GPL v.3 license](LICENSE.TXT).

Copyright (C) 2012-2025 Olivier Friard

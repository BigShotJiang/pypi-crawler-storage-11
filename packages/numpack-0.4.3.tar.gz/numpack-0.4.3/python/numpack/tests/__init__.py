"""
NumPack tests package
""" 
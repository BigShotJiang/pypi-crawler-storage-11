---
page_title: "Function: format"
description: |-
  Format a template string with positional arguments.
---

# format (Function)

Substitute `{}` placeholders in a template with values. Inputs are coerced to strings, letting you mix strings, numbers, and booleans safely.

## Example Usage

{{ example('format') }}

## Signature

`format(template: string, values: list[any]) -> string`

## Parameters

- `template` (string, required) — String containing `{}` placeholders. Returns `null` when the template is `null`.
- `values` (list[any], required) — Positional values inserted into the template. A `null` list is treated as empty.

## Returns

A formatted string or `null` when the template is `null`.

## Notes

- An error is raised if the number of values does not match the number of placeholders.

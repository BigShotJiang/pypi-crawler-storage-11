"""Core Domain Classes."""

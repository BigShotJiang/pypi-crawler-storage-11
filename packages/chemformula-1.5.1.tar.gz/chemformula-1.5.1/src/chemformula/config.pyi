AllowHydrogenIsotopes: bool

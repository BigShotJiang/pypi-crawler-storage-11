"""Tests for theme module."""

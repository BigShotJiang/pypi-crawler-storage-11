import torch


def norm(a):
    """Computes the L2 norm i.e. root sum of squares"""
    return torch.linalg.vector_norm(a, dim=(-1, -2), keepdim=True)


def cal_psnr(
    a: torch.Tensor,
    b: torch.Tensor,
    max_pixel: float = 1.0,
    min_pixel: float = 0.0,
):
    r"""
    Computes the peak signal-to-noise ratio (PSNR).

    :param torch.Tensor a: tensor estimate
    :param torch.Tensor b: tensor reference
    :param float max_pixel: maximum pixel value
    :param float min_pixel: minimum pixel value
    """
    with torch.no_grad():
        psnr = -10.0 * torch.log10(cal_mse(a, b) / (max_pixel - min_pixel) ** 2 + 1e-8)
    return psnr


def cal_mse(a, b):
    """Computes the mean squared error (MSE)"""
    return (a - b).abs().pow(2).mean(dim=tuple(range(1, a.ndim)), keepdim=False)


def cal_mae(a, b):
    """Computes the mean absolute error (MAE)"""
    return (a - b).abs().mean(dim=tuple(range(1, a.ndim)), keepdim=False)

import deepinv
import torch
import pytest
from deepinv.utils.decorators import _deprecated_alias
from deepinv.utils.compat import zip_strict
import warnings
import numpy as np
import contextlib
from contextlib import nullcontext
import random
import unittest.mock as mock
from unittest.mock import patch
import subprocess
import os
import inspect
import pathlib
import requests
import torchvision.transforms as transforms
import PIL
import io
import copy
import math
import sys

# NOTE: It's used as a fixture.
from conftest import non_blocking_plots  # noqa: F401

from deepinv.tests.test_datasets import check_dataset_format


@pytest.fixture
def tensorlist():
    x = torch.ones((1, 1, 2, 2))
    y = torch.ones((1, 1, 2, 2))
    x = deepinv.utils.TensorList([x, x])
    y = deepinv.utils.TensorList([y, y])
    return x, y


@pytest.fixture
def model():
    physics = deepinv.physics.Denoising()
    model = deepinv.optim.optimizers.optim_builder(
        iteration="PGD",
        prior=deepinv.optim.prior.TVPrior(n_it_max=20),
        data_fidelity=deepinv.optim.data_fidelity.L2(),
        early_stop=True,
        max_iter=10,
        verbose=False,
        params_algo={"stepsize": 1.0, "lambda": 1e-2},
    )
    x = torch.randn(1, 1, 64, 64, generator=torch.Generator().manual_seed(0))
    # NOTE: It is needed for attribute params_algo to be initialized.
    _ = model(x, physics=physics)
    yield model


def test_tensordict_sum(tensorlist):
    x, y = tensorlist
    z = torch.ones((1, 1, 2, 2)) * 2
    z1 = deepinv.utils.TensorList([z, z])
    z = x + y
    assert (z1[0] == z[0]).all() and (z1[1] == z[1]).all()
    z = y + x
    assert (z1[0] == z[0]).all() and (z1[1] == z[1]).all()


def test_tensordict_mul(tensorlist):
    x, y = tensorlist
    alpha = 1.0
    z = torch.ones((1, 1, 2, 2))
    z1 = deepinv.utils.TensorList([z, z])
    z = x * alpha
    assert (z1[0] == z[0]).all() and (z1[1] == z[1]).all()
    z = alpha * x
    assert (z1[0] == z[0]).all() and (z1[1] == z[1]).all()


def test_tensordict_scalar_mul(tensorlist):
    x, y = tensorlist
    z = torch.ones((1, 1, 2, 2))
    z1 = deepinv.utils.TensorList([z, z])
    z = x * y
    assert (z1[0] == z[0]).all() and (z1[1] == z[1]).all()


def test_tensordict_div(tensorlist):
    x, y = tensorlist
    z = torch.ones((1, 1, 2, 2))
    z1 = deepinv.utils.TensorList([z, z])
    z = x / y
    assert (z1[0] == z[0]).all() and (z1[1] == z[1]).all()


def test_tensordict_sub(tensorlist):
    x, y = tensorlist
    z = torch.zeros((1, 1, 2, 2))
    z1 = deepinv.utils.TensorList([z, z])
    z = x - y
    assert (z1[0] == z[0]).all() and (z1[1] == z[1]).all()


def test_tensordict_neg(tensorlist):
    x, y = tensorlist
    z = -torch.ones((1, 1, 2, 2))
    z1 = deepinv.utils.TensorList([z, z])
    z = -x
    assert (z1[0] == z[0]).all() and (z1[1] == z[1]).all()


def test_tensordict_append(tensorlist):
    x, y = tensorlist
    z = torch.ones((1, 1, 2, 2))
    z1 = deepinv.utils.TensorList([z, z, z, z])
    z = x.append(y)
    assert (z1[0] == z[0]).all() and (z1[-1] == z[-1]).all()


def test_tensorlist_any_all_isnan():
    x = torch.zeros(1, 3)
    x_nan = torch.nan * x
    tl = deepinv.utils.TensorList([x, x])
    tl_mixed = deepinv.utils.TensorList([x, x_nan])
    tl_nan = deepinv.utils.TensorList([x_nan, x_nan])

    assert x_nan.isnan().all()
    assert not tl.isnan().any()
    assert not tl.isnan().all()
    assert tl_mixed.isnan().any()
    assert not tl_mixed.isnan().all()
    assert tl_nan.isnan().all()


# The class TensorList features many utility methods that we do not test in
# depth but verify that they do not raise any exception when called. To do
# that, we get a tensor list instance, we iterate over its methods and try to call
# them filling in the required parameters in the process. We use the name of
# the parameter to determine what to pass in, e.g., if the parameter is named
# shape we use the input tensor list shape as the value for that parameter. By
# default we use the tensor list itself for every optional parameter.
def test_tensorlist_methods(tensorlist):
    x, y = tensorlist
    parameter_map = {
        "shape": x.shape,
        "dim": 0,
        "device": x[0].device,
        "dtype": x[0].dtype,
    }

    for method_name, method in inspect.getmembers(x, predicate=inspect.ismethod):
        # Ignore dunder methods
        if method_name.startswith("__") and method_name.endswith("__"):
            continue

        # Ignore methods that assume a GPU is available if there is none
        if method_name == "cuda" and not torch.cuda.is_available():
            continue

        sig = inspect.signature(method)

        # Use the tensor list itself for every required argument
        args = [
            parameter_map[p.name] if p.name in parameter_map else x
            for p in sig.parameters.values()
            # Both conditions are needed to deal with *args and **kwargs
            # but also not to include parameters that are not required
            if p.default is p.empty
            and p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
        ]

        # Test that the method does not raise any exception
        # NOTE: We run the method on a copy of the object to avoid side effects
        x_copy = copy.deepcopy(x)
        _ = getattr(x_copy, method_name)(*args)


@pytest.mark.parametrize("shape", [(1, 1, 3, 3), (1, 1, 5, 5)])
@pytest.mark.parametrize("length", [1, 2, 3, 4, 5])
def test_dirac_like(shape, length, device):
    rng = torch.Generator(device=device).manual_seed(0)
    x = [torch.randn(shape, generator=rng, device=device) for _ in range(length)]
    h = deepinv.utils.dirac_like(x)

    assert h.device == x[0].device

    y = deepinv.utils.TensorList(
        [
            deepinv.physics.functional.conv2d(xi, hi, padding="circular")
            for hi, xi in zip_strict(h, x)
        ]
    )

    for xi, hi, yi in zip_strict(x, h, y):
        assert (
            hi.shape == xi.shape
        ), "Dirac delta should have the same shape as the input tensor."

        if hi.shape[-2] % 2 == 1 and hi.shape[-1] % 2 == 1:
            assert torch.allclose(
                xi, yi
            ), "Convolution with Dirac delta should return the original tensor."


@pytest.mark.parametrize("C", [1, 3])
@pytest.mark.parametrize("n_images", range(1, 3))
@pytest.mark.parametrize("save_plot", [False, True])
@pytest.mark.parametrize("cbar", [False, True])
@pytest.mark.parametrize("with_titles", [False, True])
@pytest.mark.parametrize("dict_img_list", [False, True])
@pytest.mark.parametrize("suptitle", [None, "dummy_title"])
@pytest.mark.parametrize("with_subtitles", [False, True])
@pytest.mark.parametrize("batched", [False, True])
@pytest.mark.parametrize("return_axs", [False, True])
def test_plot(
    tmp_path,
    C,
    n_images,
    save_plot,
    cbar,
    with_titles,
    dict_img_list,
    suptitle,
    with_subtitles,
    batched,
    return_axs,
):
    if batched:
        shape = (1, C, 2, 2)
    else:
        shape = (C, 2, 2)
    img_list = torch.ones(shape)
    img_list = [img_list] * n_images if isinstance(img_list, torch.Tensor) else img_list
    titles = "0" if n_images == 1 else [str(i) for i in range(n_images)]
    subtitles = ["subtitle"] * n_images
    img_list = {k: v for k, v in zip_strict(titles, img_list)}
    if not with_titles:
        titles = None
    if not with_subtitles:
        subtitles = None
    if not dict_img_list:
        img_list = list(img_list.values())
    else:
        titles = None
    save_dir = tmp_path if save_plot else None
    with (
        pytest.raises(AssertionError)
        if titles is not None and isinstance(img_list, dict)
        else nullcontext()
    ):
        axs = deepinv.utils.plot(
            img_list,
            titles=titles,
            save_dir=save_dir,
            cbar=cbar,
            suptitle=suptitle,
            subtitles=subtitles,
            return_axs=return_axs,
        )
        if return_axs:
            assert axs is not None
        else:
            assert axs is None


@pytest.mark.parametrize("n_plots", [1, 2, 3])
@pytest.mark.parametrize("titles", [None, "Dummy plot"])
@pytest.mark.parametrize("save_plot", [False, True])
@pytest.mark.parametrize("show", [False, True])
@pytest.mark.parametrize("suptitle", [None, "dummy_title"])
@pytest.mark.parametrize("with_subtitles", [False, True])
def test_scatter_plot(
    tmp_path, n_plots, titles, save_plot, show, suptitle, with_subtitles
):
    xy_list = torch.randn(100, 2, generator=torch.Generator().manual_seed(0))
    xy_list = [xy_list] * n_plots if n_plots > 1 else xy_list
    if titles is not None:
        titles = [titles] * n_plots if n_plots > 1 else titles
    subtitles = ["subtitle"] * n_plots if with_subtitles else None
    save_dir = tmp_path if save_plot else None
    deepinv.utils.scatter_plot(
        xy_list,
        titles=titles,
        suptitle=suptitle,
        save_dir=save_dir,
        show=show,
        subtitles=subtitles,
    )


@pytest.mark.parametrize("seed", [0])
@pytest.mark.parametrize("n_metrics", [1, 2])
@pytest.mark.parametrize("n_batches", [1, 2])
@pytest.mark.parametrize("n_iterations", [1, 2])
@pytest.mark.parametrize("save_plot", [False, True])
@pytest.mark.parametrize("show", [False, True])
def test_plot_curves(
    tmp_path, seed, n_metrics, n_batches, n_iterations, save_plot, show
):
    rng = random.Random(seed)
    metrics = {
        str(k): [[rng.random() for _ in range(n_iterations)] for _ in range(n_batches)]
        for k in range(n_metrics)
    }
    save_dir = tmp_path if save_plot else None
    deepinv.utils.plot_curves(metrics, save_dir=save_dir, show=show)


@pytest.mark.parametrize("init_params", [None])
@pytest.mark.parametrize("save_plot", [False, True])
@pytest.mark.parametrize("show", [False, True])
def test_plot_parameters(tmp_path, model, init_params, save_plot, show):
    save_dir = tmp_path if save_plot else None
    deepinv.utils.plot_parameters(model, init_params, save_dir=save_dir, show=show)


def test_plot_inset():
    # Plots a batch of images with a checkboard pattern, with different inset locations
    x = torch.ones(2, 1, 100, 100)

    for i in range(0, 100, 10):
        x[:, :, :, i : i + 5] = 0
        x[:, :, i : i + 5, :] = 0

    deepinv.utils.plot_inset(
        [x],
        titles=["a"],
        labels=["a"],
        inset_loc=((0, 0.5), (0.5, 0.5)),
        show=False,
        save_fn="temp.png",
    )


def test_plot_videos():
    x = torch.rand((1, 3, 5, 8, 8))  # B,C,T,H,W image sequence
    y = torch.rand((1, 3, 5, 16, 16))
    deepinv.utils.plot_videos(
        [x, y], display=True
    )  # this should generate warning without IPython installed
    deepinv.utils.plot_videos([x, y], save_fn="vid.gif")


def test_save_videos():
    x = torch.rand((1, 3, 5, 8, 8))  # B,C,T,H,W image sequence
    y = torch.rand((1, 3, 5, 16, 16))
    deepinv.utils.save_videos([x, y], time_dim=2, save_fn="vid.gif")


def test_plot_ortho3D():
    for c in range(1, 5):
        x = torch.ones((1, c, 2, 2, 2))
        imgs = [x, x]
        deepinv.utils.plot_ortho3D(imgs, titles=["a", "b"], show=False)
        deepinv.utils.plot_ortho3D(x, titles="a", show=False)
        deepinv.utils.plot_ortho3D(imgs, show=False)


# -------------- Test deprecated_alias --------------
class DummyModule(torch.nn.Module):
    @_deprecated_alias(old_lr="lr")
    def __init__(self, lr=0.1):
        super().__init__()
        self.lr = lr


@_deprecated_alias(old_arg="new_arg")
def dummy_function(new_arg=0.1):
    return new_arg**2


def test_deprecated_alias():
    # --- Class (torch.nn.Module) tests ---
    with pytest.warns(DeprecationWarning, match="old_lr.*deprecated"):
        m1 = DummyModule(old_lr=0.01)
        assert m1.lr == 0.01

    m2 = DummyModule(lr=0.02)
    assert m2.lr == 0.02

    with pytest.raises(TypeError, match="Cannot specify both 'old_lr' and 'lr'"):
        DummyModule(old_lr=0.01, lr=0.02)

    # Test no warning with correct parameter
    with warnings.catch_warnings(record=True) as record:
        warnings.simplefilter("always")
        DummyModule(lr=0.3)
        assert len(record) == 0

    # --- Function tests ---
    with pytest.warns(DeprecationWarning, match="old_arg.*deprecated"):
        result1 = dummy_function(old_arg=0.1)
        assert result1 == 0.1**2

    result2 = dummy_function(new_arg=0.2)
    assert result2 == 0.2**2
    with pytest.raises(TypeError, match="Cannot specify both 'old_arg' and 'new_arg'"):
        dummy_function(old_arg=0.1, new_arg=0.2)
    # Test no warning with correct parameter
    with warnings.catch_warnings(record=True) as record:
        warnings.simplefilter("always")
        dummy_function(new_arg=0.3)
        assert len(record) == 0


@pytest.mark.parametrize("size", [64, 128])
@pytest.mark.parametrize("n_data", [1, 2, 3])
@pytest.mark.parametrize("transform", [None, lambda x: x])
@pytest.mark.parametrize("length", [1, 10])
@pytest.mark.parametrize("dataset_name", ["random", "shepplogan"])
def test_phantom_datasets(size, n_data, transform, length, dataset_name):
    if dataset_name == "random":
        dataset = deepinv.utils.RandomPhantomDataset(
            size=size, n_data=n_data, transform=transform, length=length
        )
    elif dataset_name == "shepplogan":
        dataset = deepinv.utils.SheppLoganDataset(
            size=size, n_data=n_data, transform=transform
        )
    check_dataset_format(
        dataset,
        length=length if dataset_name != "shepplogan" else 1,
        dtype=torch.Tensor,
        shape=(n_data, size, size),
    )


@pytest.mark.parametrize("input_shape", [(1, 3, 32, 64)])
@pytest.mark.parametrize("size", [32, 128, 129])
def test_resize_pad_square_tensor(input_shape, size):
    tensor = torch.rand(input_shape, generator=torch.Generator().manual_seed(0))
    output = deepinv.utils.resize_pad_square_tensor(tensor, size)

    assert isinstance(output, torch.Tensor), "Output should be a tensor."
    assert output.dim() == 4, "Output tensor should be 4D."
    assert output.shape[-2] == output.shape[-1], "Output tensor should be square."
    assert output.shape[-2] == size, "Output tensor should have the specified size."

    # The frequency of black pixels should increase as long as the input tensor is not square
    def black_pixels_frequency(im, bin_size=10 / 255):
        return torch.sum(2 * im.abs() < bin_size) / im.numel()

    if input_shape[-2] != input_shape[-1]:
        assert black_pixels_frequency(output) > black_pixels_frequency(
            tensor
        ), "Black pixels frequency should increase after resizing and padding."


@pytest.mark.parametrize("input_shape", [(4, 3, 32, 32), (4, 2, 32, 32)])
def test_torch2cpu(input_shape):
    tensor = torch.randn(input_shape, generator=torch.Generator().manual_seed(0))
    output = deepinv.utils.torch2cpu(tensor)

    assert isinstance(output, np.ndarray), "Output should be a numpy array."

    # Grayscale, complex and color images are treated differently:
    # (B, C, H, W) -> (H, W, C) if C is not in { 1, 2 }
    #              -> (H, W)    otherwise
    assert output.shape[0] == tensor.shape[2]
    assert output.shape[1] == tensor.shape[3]
    if input_shape[1] not in [1, 2]:
        assert output.ndim == 3, "Output should be 3D for color images."
        assert output.shape[2] == (tensor.shape[1] if input_shape[1] != 2 else 1)
    else:
        assert output.ndim == 2, "Output should be 2D for grayscale or complex images."

    # Values clamped to [0, 1]
    assert np.all(output >= 0) and np.all(
        output <= 1
    ), "Output values should be in the range [0, 1]."


# A list of tuples: (command_runs, n_gpus, freer_gpu_index)
@pytest.mark.parametrize(
    "test_case",
    [
        # Case 1: The nvidia-smi command succeeds.
        (True, 2, 1),
        # Case 2: The command fails and torch.cuda.device_count() is zero.
        (False, 0, None),
        # Case 3: The command fails and torch.cuda.device_count() is positive.
        (False, 2, 1),
    ],
)
# NOTE: The nvidia-smi command is executed differently depending on the OS, we
# make sure that the logic is right.
@pytest.mark.parametrize("os_name", ["posix", "nt"])
@pytest.mark.parametrize("verbose", [False, True])
@pytest.mark.parametrize("use_torch_api", [False, True])
@pytest.mark.parametrize("hide_warnings", [False, True])
def test_get_freer_gpu(test_case, os_name, verbose, use_torch_api, hide_warnings):
    # The function get_freer_gpu is meant to return the torch.device associated
    # to the available GPU with the most free memory if there is one and
    # torch.device("cuda") as a fallback.
    # It works by first trying to run a `nvidia-smi` command and if it fails
    # it falls back to using the functions `torch.cuda.device_count` and
    # `torch.cuda.mem_get_info`. We mock the three components to control the
    # expected return value. In this scenario, we consider is a machine with n
    # GPUs, all of which have 1 MiB of total memory, and all of which have 0
    # MiB of free memory except for a single GPU (the freer GPU). We also
    # consider that the command
    # nvidia-smi might or might not be present in the system, resulting in
    # a failure of the function `subprocess.run` used in the implementation.
    command_runs, n_gpus, freer_gpu_index = test_case

    if freer_gpu_index is not None:
        assert (
            0 <= freer_gpu_index and freer_gpu_index < n_gpus
        ), "freer_gpu_index should be a valid index within the range of available GPUs."
    else:
        assert n_gpus == 0, "freer_gpu_index should be None only when n_gpus is 0."

    with (
        patch.object(subprocess, "run") as mock_subprocess_run,
        patch.object(torch.cuda, "device_count") as mock_device_count,
        patch.object(torch.cuda, "mem_get_info") as mock_mem_get_info,
        patch.object(os, "name", os_name),
    ):
        if command_runs:
            # Mock the standard output reported by subprocess.run by simulating
            # the output of the command used in the implementation:
            # nvidia-smi -q -d Memory | grep -A5 GPU | grep Free
            mock_subprocess_run.return_value.stdout = "\n".join(
                [
                    f"Free : 1 MiB" if idx == freer_gpu_index else "Free : 0 MiB"
                    for idx in range(n_gpus)
                ]
            )
        else:
            mock_subprocess_run.side_effect = FileNotFoundError
        mock_device_count.return_value = n_gpus

        def mem_info_mock(idx):
            total_mem = 1048576  # 1 MiB
            if idx == freer_gpu_index:
                free_mem = total_mem
            elif idx < n_gpus:
                free_mem = 0
            else:
                raise ValueError("Invalid GPU index")
            return (free_mem, total_mem)

        mock_mem_get_info.side_effect = mem_info_mock

        device = deepinv.utils.get_freer_gpu(
            verbose=verbose, use_torch_api=use_torch_api, hide_warnings=hide_warnings
        )
        if n_gpus == 0:
            assert device is None, "The output should be None when no GPU is available."
        else:
            assert isinstance(device, torch.device), "Device should be a torch device."
            assert device.type == "cuda", "Device should be a CUDA device."
            assert (
                device.index == freer_gpu_index
            ), f"Selected GPU index should be {freer_gpu_index}."


@pytest.mark.parametrize("fn_name", ["norm", "cal_angle", "cal_mse", "norm_psnr"])
def test_deprecated_metric_functions(fn_name):
    f = getattr(deepinv.utils.metric, fn_name)
    with pytest.raises(NotImplementedError, match="deprecated"):
        # The functions take a variable number of required arguments so we
        # use reflection to get their number and pass in None for each of them.
        sig = inspect.signature(f)
        args = [
            None
            for p in sig.parameters.values()
            if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
        ]
        f(*args)


@pytest.mark.parametrize("with_data_dir", [False, True])
@pytest.mark.parametrize("data_dir_type", [str, pathlib.Path])
@pytest.mark.parametrize("name", ["Levin09.npy"])
@pytest.mark.parametrize("index", [1])
@pytest.mark.parametrize("download", [False, True])
def test_load_degradation(
    tmp_path, with_data_dir, data_dir_type, name, index, download
):
    if with_data_dir:
        assert data_dir_type in [
            str,
            pathlib.Path,
        ], "data_dir_type should be str or pathlib.Path."
        data_dir = data_dir_type(tmp_path)
    else:
        data_dir = None

    args = [name, data_dir]
    kwargs = {"index": index}

    # We make sure the degradation is present on disk if download is False.
    if not download:
        _ = deepinv.utils.load_degradation(*args, **kwargs, download=True)

    kernel_torch = deepinv.utils.load_degradation(*args, **kwargs, download=download)
    assert isinstance(kernel_torch, torch.Tensor), "Kernel should be a torch tensor."


@pytest.mark.parametrize("n_retrievals", [1, 2])
@pytest.mark.parametrize("dataset_name", ["set3c"])
@pytest.mark.parametrize(
    "transform",
    [None, transforms.Compose([transforms.CenterCrop(64), transforms.ToTensor()])],
)
def test_load_dataset(n_retrievals, dataset_name, transform):
    # If a transform function is provided, mock it for further testing
    if transform is not None:
        transform = mock.Mock(wraps=transform)

    dataset = deepinv.utils.load_dataset(dataset_name, transform=transform)
    assert isinstance(dataset, deepinv.datasets.ImageFolder)

    for k in range(n_retrievals):
        x = dataset[k]
        if transform is not None:
            assert isinstance(x, torch.Tensor), "Dataset image should be a tensor."
        else:
            assert isinstance(
                x, PIL.Image.Image
            ), "Dataset image should be a PIL Image."

    if transform is not None:
        assert (
            transform.call_count == n_retrievals
        ), "Transform should be called once for each dataset item."


@pytest.mark.parametrize(
    "name",
    [
        "butterfly.png",
        "CT100_256x256_0.pt",
        "brainweb_t1_ICBM_1mm_subject_0_slice_0.npy",
    ],
)
def test_load_example(name):
    x = deepinv.utils.load_example(name, img_size=(64, 64))
    assert isinstance(x, torch.Tensor)
    if name.split(".")[-1] == "png":
        assert x.shape[-2:] == (64, 64)


@pytest.mark.parametrize(
    "operation", ["super-resolution", "deblur", "inpaint", "dummy"]
)
@pytest.mark.parametrize("noise_level_img", [0, 0.03])
def test_get_GSPnP_params(operation, noise_level_img):
    supported_operations = ["super-resolution", "deblur", "inpaint"]
    with (
        pytest.raises(ValueError)
        if operation not in supported_operations
        else nullcontext()
    ):
        lamb, sigma_denoiser, stepsize, max_iter = deepinv.utils.get_GSPnP_params(
            operation, noise_level_img
        )
        assert isinstance(lamb, float), "Lambda should be a float."
        assert lamb > 0, "Lambda should be positive."
        assert isinstance(sigma_denoiser, float), "Sigma denoiser should be a float."
        assert sigma_denoiser >= 0, "Sigma denoiser should be non-negative."
        assert isinstance(stepsize, float), "Stepsize should be a float."
        assert stepsize > 0, "Stepsize should be positive."
        assert isinstance(max_iter, int), "Max iterations should be an integer."
        assert max_iter > 0, "Max iterations should be positive."


@pytest.mark.parametrize("to_float", [float, np.float32, np.float64])
def test_AverageMeter(to_float):
    rng = torch.Generator().manual_seed(0)
    vals = torch.randn(10, generator=rng)

    meter = deepinv.utils.AverageMeter("DummyValue", fmt=":f")
    for val in vals:
        meter.update(to_float(val.item()))

    # Check that the aggregates are correct
    assert math.isclose(meter.val, vals[-1].item()), "Current value is incorrect."
    assert math.isclose(
        meter.avg, vals.mean().item(), rel_tol=1e-5
    ), "Average value is incorrect."
    assert math.isclose(
        meter.sum, vals.sum().item(), rel_tol=1e-5
    ), "Sum value is incorrect."
    assert meter.count == len(vals), "Count value is incorrect."
    assert math.isclose(
        meter.std, vals.std(correction=0).item(), rel_tol=1e-5
    ), "Std value is incorrect."
    assert math.isclose(
        meter.sum2, (vals**2).sum().item(), rel_tol=1e-5
    ), "Sum2 value is incorrect."
    assert all(
        math.isclose(a, b, rel_tol=1e-10)
        for a, b in zip_strict(meter.vals, vals.tolist())
    ), "Retained values are incorrect."

    # Scalar aggregates should be instances of the builtin float type
    scalar_attr_names = [
        "val",
        "avg",
        "sum",
        "count",
        "std",
        "sum2",
    ]
    for attr_name in scalar_attr_names:
        attr_val = getattr(meter, attr_name)
        assert (
            type(attr_val) == float
        ), f"Attribute {attr_name} should be exactly a float, and not a subclass of a float (numpy, PyTorch). Got {type(attr_val)} instead."

    # The list of retained values should only contain (exact) float instances
    for val in meter.vals:
        assert (
            type(val) == float
        ), f"Entries of vals should be exactly a float, and not a subclass of a float (numpy, PyTorch). Got {type(val)} instead."


@pytest.mark.parametrize("rng", [random.Random(0)])
@pytest.mark.parametrize("n_meters", [1, 2])
@pytest.mark.parametrize("n_updates", [10])
@pytest.mark.parametrize("fmt", ["f"])
@pytest.mark.parametrize(
    "epoch, num_epochs",
    [
        (0, 5),
        (5, 5),
        (5, 10),
        (10, 15),
        (37, 100),
        (150, 150),
    ],
)
@pytest.mark.parametrize("surfix", ["", "dummy_suffix"])
@pytest.mark.parametrize("prefix", ["", "dummy_prefix"])
def test_ProgressMeter(
    rng, n_meters, n_updates, fmt, epoch, num_epochs, surfix, prefix
):
    meters = [
        deepinv.utils.AverageMeter(f"dummy_meter{i + 1}", fmt=f":{fmt}")
        for i in range(n_meters)
    ]

    for meter in meters:
        for _ in range(n_updates):
            meter.update(rng.random())

    progress = deepinv.utils.ProgressMeter(
        num_epochs, meters, surfix=surfix, prefix=prefix
    )

    stdout_buf = io.StringIO()
    with contextlib.redirect_stdout(stdout_buf):
        progress.display(epoch)

    stdout = stdout_buf.getvalue()
    stdout = stdout.strip()
    # NOTE: For some reason prefix is appended at the end and surfix at the
    # beginning. Is it a bug?
    assert stdout.endswith(prefix), "Prefix should be at the end of the output."
    assert stdout.startswith(surfix), "Surfix should be at the beginning of the output."

    assert str(epoch) in stdout, "Epoch number should be in the output."
    assert str(num_epochs) in stdout, "Number of epochs should be in the output."

    for meter in meters:
        assert (
            meter.name in stdout
        ), f"Meter name '{meter.name}' should be in the output."
        assert (
            f"{meter.avg:{fmt}}" in stdout
        ), f"Meter average '{meter.avg}' should be in the output."


@pytest.mark.parametrize("original_size", [(16, 16), (32, 32), (64, 64)])
@pytest.mark.parametrize("grayscale", [False, True])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
@pytest.mark.parametrize("img_size", [None, 32, (32, 32)])
@pytest.mark.parametrize("resize_mode", ["crop", "resize"])
def test_load_image(
    tmp_path, device, original_size, grayscale, dtype, img_size, resize_mode
):
    # We use a mocked PIL image to test the load_image function.
    im = PIL.Image.new("RGB", original_size, color=(0, 0, 0))
    buffer = io.BytesIO()
    im.save(buffer, format="PNG")
    buffer.seek(0)
    im = PIL.PngImagePlugin.PngImageFile(buffer)

    with patch.object(PIL.Image, "open", return_value=im):
        x = deepinv.utils.load_image(
            f"{tmp_path}/im.png",
            grayscale=grayscale,
            device=device,
            dtype=dtype,
            img_size=img_size,
            resize_mode=resize_mode,
        )
        assert isinstance(x, torch.Tensor), "Loaded image should be a tensor."
        if img_size is not None:
            img_size = (img_size, img_size) if isinstance(img_size, int) else img_size
            assert (
                x.shape[-2:] == img_size
            ), f"Image shape should be {img_size}, got {x.shape[-2:]}"


@pytest.mark.parametrize("batch_size", [1, 2])
@pytest.mark.parametrize(
    "signal_shape",
    [(3, 16, 16), (1, 16, 16), (1, 16), (1, 16, 16, 16), (1, 16, 8), (16, 16), (16,)],
)
@pytest.mark.parametrize("mode", ["min_max", "clip"])
@pytest.mark.parametrize("seed", [0])
def test_normalize_signals(batch_size, signal_shape, mode, seed):
    shape = (batch_size, *signal_shape)
    rng = torch.Generator().manual_seed(seed)

    # Generate a batch of random signals, half constant and half not
    # NOTE: Constant signals are the main edge case to test.
    inp = torch.empty(shape, device="cpu", dtype=torch.float32)
    indices = torch.randperm(batch_size, generator=rng)
    N_const_idx = math.ceil(batch_size / 2)
    const_idx, var_idx = indices[:N_const_idx], indices[N_const_idx:]
    const_values = torch.randn(
        N_const_idx, generator=rng, device=inp.device, dtype=inp.dtype
    )
    inp[const_idx] = const_values.view((-1,) + ((1,) * len(signal_shape)))
    if var_idx.numel() != 0:
        inp[var_idx] = torch.randn(
            inp[const_idx].shape, generator=rng, device=inp.device, dtype=inp.dtype
        )

    # Sanity check
    assert inp.shape == shape, "Input tensor should have the specified shape."

    # Apply the tested function
    out = deepinv.utils.normalize_signal(inp, mode=mode)

    # Check the tensor attributes
    assert out.dtype == inp.dtype, "Output dtype should match input dtype."
    assert out.device == inp.device, "Output device should match input device."
    assert out.shape == inp.shape, "Output shape should match input shape."

    # Check that the output entries are between zero and one
    assert torch.all(0 <= out) and torch.all(
        out <= 1
    ), "Output entries should be in [0, 1]."

    # Tests specific to min-max normalization
    if mode == "min_max":
        # Test the edge case of constant signals
        for inp_s, out_s in zip_strict(inp, out):
            inp_unique = torch.unique(inp_s)
            is_inp_constant = inp_unique.numel() == 1
            if is_inp_constant:
                # Verify that constant signals remain constant after normalization
                out_unique = torch.unique(out_s)
                is_out_constant = out_unique.numel() == 1
                assert (
                    is_out_constant
                ), "Output should be constant if input is constant."

                # Input and output constant values
                inp_c = inp_unique.item()
                out_c = out_unique.item()

                # Verify that the rescaling is the smallest possible
                target_c = max(0, min(1, inp_c))
                assert (
                    out_c == target_c
                ), "The distance between the input and ouput constants is not minimal."
    elif mode == "clip":
        # Check that the input is clipped between zero and one
        assert torch.all(
            out == torch.clamp(inp, 0, 1)
        ), "Output should be clipped between 0 and 1."
    else:
        raise ValueError(
            f"Unknown mode '{mode}'. Supported modes are 'min_max' and 'clip'."
        )


@pytest.mark.parametrize("x", [None, torch.randn(2, 3, 32, 32)])
@pytest.mark.parametrize("y", [None, torch.randn(2, 3, 32, 32)])
@pytest.mark.parametrize("x_net", [None, torch.randn(2, 3, 32, 32)])
@pytest.mark.parametrize("x_nl", [None, torch.randn(2, 3, 32, 32)])
@pytest.mark.parametrize("rescale_mode", ["min_max", "clip"])
def test_prepare_images(x, y, x_net, x_nl, rescale_mode):
    imgs, titles, grid_image, caption = deepinv.utils.plotting.prepare_images(
        x, y, x_net, x_nl, rescale_mode=rescale_mode
    )

    # Checks for empty inputs
    if all(v is None for v in [x, y, x_net, x_nl]):
        assert imgs == [], "Images list should be empty when all inputs are None."
        assert titles == [], "Titles list should be empty when all inputs are None."
        assert (
            grid_image == None
        ), "Grid image list should be empty when all inputs are None."

    else:
        assert all(
            isinstance(img, torch.Tensor) for img in imgs
        ), "All images should be torch tensors."
        assert all(
            isinstance(title, str) for title in titles
        ), "All titles should be strings."
        assert len(imgs) == len(
            titles
        ), "Number of images should match number of titles."
        conditions = [
            x is not None,
            x_net is not None,
            x_nl is not None,
            y is not None and x is not None and y.shape == x.shape,
        ]
        assert len(imgs) == sum(
            conditions
        ), f"Expected {sum(conditions)} images but got {len(imgs)}"


@pytest.mark.parametrize("seed", [0])
def test_prepare_images_shapes(seed):
    rng = torch.Generator().manual_seed(seed)
    x = torch.randn(32, 1, 10, 10, generator=rng)

    imgs, titles, grid_image, caption = deepinv.utils.plotting.prepare_images(
        x, y=x, x_net=x, x_nl=x, rescale_mode="min_max"
    )

    # Check that the grid image has the correct shape (4 below = number of non None inputs)
    num_inputs = 4  # x, y, x_net, x_nl
    assert grid_image.shape == torch.Size(
        [3, num_inputs * (x.shape[-1] + 2) + 2, x.shape[0] * (x.shape[-2] + 2) + 2]
    )


# Module-level fixtures
pytestmark = [pytest.mark.usefixtures("non_blocking_plots")]


@pytest.mark.parametrize("force_polyfill", [False, True])
def test_zip_strict_behavior(force_polyfill):
    # Test correct pairing
    a = [1, 2, 3]
    b = ["x", object(), "z"]
    c = [True, False, object()]

    result = list(zip_strict(a, b, c, force_polyfill=force_polyfill))

    # If Python >= 3.10, compare with zip(strict=True)
    if sys.version_info >= (3, 10):
        expected = list(zip(a, b, c, strict=True))  # novermin
        assert result == expected

    # Test ValueError for different lengths
    d = [1, 2]
    with pytest.raises(ValueError):
        list(zip_strict(a, d, force_polyfill=force_polyfill))

    # If Python >= 3.10, confirm zip(strict=True) also raises
    if sys.version_info >= (3, 10):
        with pytest.raises(ValueError):
            list(zip(a, d, strict=True))  # novermin

    # Test consumption behavior
    def spy(iterable):
        it = iter(iterable)
        for x in it:
            yield x

    a = spy([1, 2, 3])
    b = spy([10, 20, 30, 40])
    c = spy([100, 200, 300, 400])

    try:
        _ = list(zip_strict(a, b, c, force_polyfill=force_polyfill))
    except ValueError:
        pass

    assert next(a, None) is None, "Iterator a should be fully consumed."
    assert next(b, None) is None, "Iterator b should be fully consumed."
    assert next(c, None) == 400, "Iterator c should have one item left."

    # Test empty input
    assert (
        list(zip_strict(force_polyfill=force_polyfill)) == []
    ), "Empty input should yield empty output."


@pytest.mark.parametrize("latex_exists", [True, False])
def test_default_tex(latex_exists, monkeypatch):
    import matplotlib.pyplot as plt
    import shutil

    monkeypatch.setattr(
        "shutil.which", lambda cmd: ("/usr/bin/latex" if latex_exists else None)
    )

    # Test default
    assert deepinv.utils.plotting.get_enable_tex()

    # Check latex only called when latex installed
    if shutil.which("latex"):
        deepinv.utils.plotting.set_checked_tex(False)
        deepinv.utils.enable_tex()
        with patch(
            "matplotlib.texmanager.TexManager.get_text_width_height_descent"
        ) as mock_func:
            # Test the tex checking allows other non-latex errors through
            mock_func.side_effect = RuntimeError("something non-latex related")
            with pytest.raises(RuntimeError, match="something non-latex related"):
                deepinv.utils.plotting.config_matplotlib()
            mock_func.assert_called_once()
            assert not deepinv.utils.plotting.get_checked_tex()  # not checked
            assert deepinv.utils.plotting.get_enable_tex()  # still enabled

            # Test the tex checking happens
            mock_func.reset_mock()
            mock_func.side_effect = RuntimeError("latex was not able to process")
            deepinv.utils.plotting.config_matplotlib()
            mock_func.assert_called_once()
            # The check should now have disabled tex
            assert not deepinv.utils.plotting.get_enable_tex()
            assert deepinv.utils.plotting.get_checked_tex()  # and also checked now

            # Test that the check no longer happens
            mock_func.reset_mock()
            deepinv.utils.plotting.config_matplotlib()
            mock_func.assert_not_called()

    # Test disabling works
    deepinv.utils.disable_tex()
    assert not deepinv.utils.plotting.get_enable_tex()
    assert not plt.rcParams["text.usetex"]

    # Test enabling works, even with plotting
    deepinv.utils.enable_tex()
    deepinv.utils.plot(torch.randn(1, 1, 4, 4))
    assert deepinv.utils.plotting.get_enable_tex()
    assert plt.rcParams["text.usetex"] == bool(shutil.which("latex"))

    # Test plot has no side effect
    deepinv.utils.disable_tex()
    deepinv.utils.plot(torch.randn(1, 1, 4, 4))
    assert not deepinv.utils.plotting.get_enable_tex()
    assert not plt.rcParams["text.usetex"]

    # Finish test by resetting to default values
    deepinv.utils.plotting.set_checked_tex(False)
    deepinv.utils.plotting.enable_tex()


@pytest.mark.parametrize("apply_rescale", [True, False])
@pytest.mark.parametrize("as_tensor", [True, False])
def test_io_dicom(apply_rescale, as_tensor):
    pytest.importorskip(
        "pydicom",
        reason="This test requires pydicom. It should be "
        "installed with `pip install pydicom`",
    )
    file = deepinv.io.load_url(
        "https://github.com/robyoung/dicom-test-files/raw/refs/heads/master/data/pydicom/693_J2KI.dcm"
    )
    x = deepinv.io.load_dicom(file, as_tensor=as_tensor, apply_rescale=apply_rescale)
    assert x.shape == (1, 512, 512) if as_tensor else (512, 512)
    assert isinstance(x, torch.Tensor) if as_tensor else np.ndarray


def test_io_nifti(tmp_path):
    pytest.importorskip(
        "nibabel",
        reason="This test requires nibabel. It should be "
        "installed with `pip install nibabel`",
    )
    with open(tmp_path / "tmp.nii.gz", "wb") as f:
        f.write(
            requests.get(
                "https://github.com/neurolabusc/niivue-images/raw/refs/heads/main/Iguana.nii.gz"
            ).content
        )

    assert deepinv.io.load_nifti(tmp_path / "tmp.nii.gz").shape == (
        210,
        256,
        179,
    )  # 3D volume


def test_io_ismrmd():
    file = deepinv.io.load_url(
        deepinv.utils.demo.get_image_url("demo_fastmri_brain_multicoil.h5")
    )
    assert deepinv.io.load_ismrmd(file, data_name="kspace", data_slice=0).shape == (
        2,
        4,
        512,
        213,
    )  # CNHW, 4 coils
    assert deepinv.io.load_ismrmd(
        file, data_name="kspace", data_slice=(0, slice(0, 2))
    ).shape == (
        2,
        2,
        512,
        213,
    )  # CNHW, 2 coils
    assert deepinv.io.load_ismrmd(file, data_name="kspace").shape == (
        2,
        16,
        4,
        512,
        213,
    )  # CXNHW (X is slice dim, note this is unusual usage)


def test_io_torch():
    assert deepinv.io.load_torch(
        deepinv.utils.load_url(deepinv.utils.demo.get_image_url("CT100_256x256_0.pt"))
    ).shape == (1, 1, 256, 256)


def test_io_np():
    assert deepinv.io.load_np(
        deepinv.utils.load_url(
            deepinv.utils.demo.get_image_url(
                "brainweb_t1_ICBM_1mm_subject_0_slice_0.npy"
            )
        )
    ).shape == (217, 181)
    assert deepinv.utils.demo.load_example(
        "brainweb_t1_ICBM_1mm_subject_0_slice_0.npy"
    ).shape == (217, 181)


def test_io_raster():
    pytest.importorskip(
        "rasterio",
        reason="This test requires rasterio. It should be "
        "installed with `pip install rasterio`",
    )
    file = deepinv.io.load_url(
        "https://download.osgeo.org/geotiff/samples/spot/chicago/SP27GTIF.TIF"
    )
    assert deepinv.io.load_raster(file, patch=False).shape == (1, 929, 699)

    x = deepinv.io.load_raster(file, patch=True)
    assert next(x).shape == (1, 11, 699)
    assert len(list(x)) == 929 // 11

    # Test patches are patched correctly
    assert next(deepinv.io.load_raster(file, patch=(2, 5))).shape == (1, 2, 5)
    assert next(deepinv.io.load_raster(file, patch=5)).shape == (1, 5, 5)

    assert len(list(deepinv.io.load_raster(file, patch=(3, 699)))) == 310
    assert len(list(deepinv.io.load_raster(file, patch=(929, 3)))) == 233

    # Test patch start
    assert (
        len(list(deepinv.io.load_raster(file, patch=(3, 699), patch_start=(920, 0))))
        == 3
    )

    # Test transform
    assert deepinv.io.load_raster(file, patch=True, transform=lambda x: x)


def test_io_blosc2():
    pytest.importorskip(
        "blosc2",
        reason="This test requires blosc2. It should be "
        "installed with `pip install blosc2`",
    )
    fake_array = np.random.rand(2, 2).astype(np.float32)

    with patch("blosc2.open") as mock_open, patch("importlib.import_module"):
        mock_arr = mock.MagicMock()
        mock_arr.__getitem__.return_value = fake_array
        mock_open.return_value = mock_arr

        out = deepinv.io.load_blosc2(pathlib.Path("fake.b2"))
        assert torch.is_tensor(out)
        assert out.shape == torch.from_numpy(fake_array).shape

        out_memmap = deepinv.io.load_blosc2(pathlib.Path("fake.b2"), as_memmap=True)
        assert out_memmap is mock_arr

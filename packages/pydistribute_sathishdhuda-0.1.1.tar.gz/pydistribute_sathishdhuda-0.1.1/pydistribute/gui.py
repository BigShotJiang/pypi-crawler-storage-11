import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import subprocess
import os
import sys
import tempfile
import shutil
import ast
import threading
import time
import re

# ---------------------------
# Amazon-inspired color theme
# ---------------------------
AMAZON_ORANGE = "#FF9900"
AMAZON_DEEP = "#232F3E"
AMAZON_LIGHT = "#F6F7F8"
CARD_BG = "#FFFFFF"
MUTED_TEXT = "#4A5564"
SUCCESS_GREEN = "#2E7D32"
DANGER_RED = "#D32F2F"
CONSOLE_BLACK = "#000000"
CONSOLE_GREEN = "#00FF00"
CONSOLE_RED = "#FF0000"
CONSOLE_BLUE = "#0000FF"
CONSOLE_YELLOW = "#FFFF00"
CONSOLE_MAGENTA = "#FF00FF"
CONSOLE_CYAN = "#00FFFF"
CONSOLE_WHITE = "#FFFFFF"

class StylishButton(ttk.Button):
    """Button with hover effect using bindings"""
    def __init__(self, master=None, **kwargs):
        ttk.Button.__init__(self, master, **kwargs)
        self.default_bg = kwargs.get('style', '')
        self.bind("<Enter>", self.on_enter)
        self.bind("<Leave>", self.on_leave)
    def on_enter(self, e):
        self.state(['active'])
    def on_leave(self, e):
        self.state(['!active'])

class PyPIPublisherGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("PyDistribute")
        self.root.geometry("1100x760")
        self.root.configure(bg=AMAZON_LIGHT)
        self.root.minsize(1000, 640)

        # Variables
        self.module_name = tk.StringVar()
        self.version = tk.StringVar(value="0.1.0")
        self.author = tk.StringVar()
        self.author_email = tk.StringVar()
        self.description = tk.StringVar()
        self.pypi_token = tk.StringVar()
        self.status_text = tk.StringVar(value="Ready")

        # Setup ttk style
        self.setup_styles()
        self.create_layout()
        self.insert_example_code()

    def setup_styles(self):
        style = ttk.Style(self.root)
        style.theme_use('clam')  # better baseline for styling

        # Fonts & general
        self.header_font = ("Segoe UI", 16, "bold")
        self.sub_font = ("Segoe UI", 10)
        self.mono_font = ("Consolas", 10)
        self.console_font = ("Consolas", 9)

        # Header frame
        style.configure("Header.TFrame", background=AMAZON_DEEP)
        style.configure("Header.TLabel", background=AMAZON_DEEP, foreground="white", font=self.header_font)

        # Card frames
        style.configure("Card.TFrame", background=CARD_BG, relief="flat")
        style.configure("Card.TLabel", background=CARD_BG, foreground=MUTED_TEXT, font=self.sub_font)

        # Field labels and entries
        style.configure("Field.TLabel", background=CARD_BG, foreground=MUTED_TEXT, font=self.sub_font)
        style.configure("TEntry", fieldbackground="white", background="white", foreground=MUTED_TEXT, relief="flat", padding=6)

        # Primary button (orange)
        style.configure("Primary.TButton",
                        background=AMAZON_ORANGE,
                        foreground="white",
                        font=("Segoe UI", 10, "bold"),
                        padding=8,
                        relief="flat")
        style.map("Primary.TButton",
                  background=[('active', '#e67e00'), ('disabled', '#f2b76b')])

        # Secondary button (subtle)
        style.configure("Secondary.TButton",
                        background="#fff",
                        foreground=AMAZON_DEEP,
                        font=("Segoe UI", 10),
                        padding=6,
                        relief="flat")
        style.map("Secondary.TButton",
                  background=[('active', '#efefef')])

        # Log text
        style.configure("Log.TFrame", background=AMAZON_LIGHT)

        # Notebook style
        style.configure("TNotebook", background=AMAZON_LIGHT, tabposition='n')
        style.configure("TNotebook.Tab", font=("Segoe UI", 10), padding=[12, 8])

    def create_layout(self):
        # ---------- Header ----------
        header = ttk.Frame(self.root, style="Header.TFrame")
        header.pack(side=tk.TOP, fill=tk.X)
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text="PyDistribute - Python Package Publisher", style="Header.TLabel").grid(row=0, column=0, sticky=tk.W, padx=20, pady=14)
        ttk.Label(header, text="Streamline your package distribution with PyDistribute", style="Header.TLabel").grid(row=0, column=1, sticky=tk.E, padx=20, pady=14)

        # ---------- Toolbar / Quick actions ----------
        toolbar = ttk.Frame(self.root, padding=(20, 12), style="Card.TFrame", relief="flat")
        toolbar.pack(fill=tk.X, padx=20, pady=(10, 0))

        # Buttons in toolbar
        btn_new = ttk.Button(toolbar, text="New Module", style="Secondary.TButton", command=self.new_module)
        btn_new.pack(side=tk.LEFT, padx=(0,8))
        btn_generate = ttk.Button(toolbar, text="Generate Setup", style="Secondary.TButton", command=self.generate_setup)
        btn_generate.pack(side=tk.LEFT, padx=8)
        btn_build = ttk.Button(toolbar, text="Build Package", style="Secondary.TButton", command=self.build_package)
        btn_build.pack(side=tk.LEFT, padx=8)
        btn_publish = ttk.Button(toolbar, text="Publish to PyPI", style="Primary.TButton", command=self.publish_package)
        btn_publish.pack(side=tk.LEFT, padx=8)

        # Spacer
        spacer = ttk.Frame(toolbar)
        spacer.pack(side=tk.LEFT, expand=True)

        # Small help / about
        about_btn = ttk.Button(toolbar, text="About", style="Secondary.TButton", command=self.show_about)
        about_btn.pack(side=tk.RIGHT, padx=(8,0))

        # ---------- Main Content Area (left form + right editor) ----------
        main_frame = ttk.Frame(self.root, padding=20, style="Card.TFrame")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=12)

        # left panel - module info and actions
        left_panel = ttk.Frame(main_frame, width=360, style="Card.TFrame")
        left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0,12), pady=4)
        left_panel.pack_propagate(False)

        # Card: Module Info
        card_info = ttk.Frame(left_panel, style="Card.TFrame", padding=12)
        card_info.pack(fill=tk.X, pady=(0,12))
        ttk.Label(card_info, text="Module Information", style="Card.TLabel", font=("Segoe UI", 12, "bold")).pack(anchor=tk.W, pady=(0,8))

        form = ttk.Frame(card_info, style="Card.TFrame")
        form.pack(fill=tk.X, pady=(4,0))

        # fields
        fields = [
            ("Module Name", self.module_name),
            ("Version", self.version),
            ("Author", self.author),
            ("Author Email", self.author_email),
            ("Description", self.description),
            ("PyPI API Token", self.pypi_token)
        ]

        for i, (label_text, var) in enumerate(fields):
            lbl = ttk.Label(form, text=label_text, style="Field.TLabel")
            lbl.grid(row=i, column=0, sticky=tk.W, pady=8)
            ent = ttk.Entry(form, textvariable=var, width=30, style="TEntry")
            if "Token" in label_text:
                ent.configure(show="*")
            ent.grid(row=i, column=1, sticky=tk.W, padx=(8,0), pady=8)

        # Quick actions lower in left panel
        card_actions = ttk.Frame(left_panel, style="Card.TFrame", padding=12)
        card_actions.pack(fill=tk.X)
        ttk.Label(card_actions, text="Quick Actions", style="Card.TLabel", font=("Segoe UI", 11, "bold")).pack(anchor=tk.W, pady=(0,8))

        ttk.Button(card_actions, text="Open Existing Project Folder", style="Secondary.TButton", command=self.open_folder).pack(fill=tk.X, pady=6)
        ttk.Button(card_actions, text="Save Code to .py", style="Secondary.TButton", command=self.save_code_to_file).pack(fill=tk.X, pady=6)

        # ---------- right panel - notebook with tabs ----------
        right_panel = ttk.Frame(main_frame, style="Card.TFrame")
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        notebook = ttk.Notebook(right_panel)
        notebook.pack(fill=tk.BOTH, expand=True)

        # Code editor tab
        code_tab = ttk.Frame(notebook)
        notebook.add(code_tab, text="Code Editor")

        ttk.Label(code_tab, text="Module Code", style="Card.TLabel").pack(anchor=tk.W, padx=12, pady=(12,0))
        self.code_text = scrolledtext.ScrolledText(code_tab, height=22, font=self.mono_font)
        self.code_text.pack(fill=tk.BOTH, expand=True, padx=12, pady=8)

        # Usage guide tab
        usage_tab = ttk.Frame(notebook)
        notebook.add(usage_tab, text="Usage Guide")
        ttk.Label(usage_tab, text="Usage Instructions", style="Card.TLabel").pack(anchor=tk.W, padx=12, pady=(12,0))
        self.usage_text = scrolledtext.ScrolledText(usage_tab, height=22, font=self.mono_font,background=CONSOLE_BLACK, foreground=CONSOLE_WHITE)
        self.usage_text.pack(fill=tk.BOTH, expand=True, padx=12, pady=8)
        self.usage_text.insert(tk.END, self.default_usage_text())

        # Console log tab
        console_tab = ttk.Frame(notebook)
        notebook.add(console_tab, text="Console Log")
        ttk.Label(console_tab, text="Console Output", style="Card.TLabel").pack(anchor=tk.W, padx=12, pady=(12,0))
        self.log_text = scrolledtext.ScrolledText(console_tab, height=22, font=self.console_font, background=CONSOLE_BLACK, foreground=CONSOLE_WHITE)
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=12, pady=8)

        # ---------- Status bar at bottom ----------
        bottom = ttk.Frame(self.root, padding=(20, 8), style="Log.TFrame")
        bottom.pack(side=tk.BOTTOM, fill=tk.X)
        # status and buttons
        status_frame = ttk.Frame(bottom, style="Log.TFrame")
        status_frame.pack(fill=tk.X)

        self.status_label = ttk.Label(status_frame, textvariable=self.status_text, background=AMAZON_LIGHT, foreground=MUTED_TEXT)
        self.status_label.pack(side=tk.LEFT)

        self.progress = ttk.Progressbar(status_frame, mode="determinate", maximum=100, length=360)
        self.progress.pack(side=tk.RIGHT, padx=6)

    def default_usage_text(self):
        return '''# Usage Guide

After publishing your module to PyPI, users can install it using pip:

$ pip install your_module_name

Then they can use it in their Python code:

>>> import your_module_name
>>> # Use the functions/classes you defined
'''

    def insert_example_code(self):
        example_code = '''"""
Example Module
"""

__version__ = "0.1.0"

def hello_world():
    """Return a greeting message."""
    return "Hello, World!"

def add_numbers(a, b):
    """Add two numbers and return the result."""
    return a + b
'''
        self.code_text.delete(1.0, tk.END)
        self.code_text.insert(tk.END, example_code)

    # -----------------------------
    # Utility & core functionality
    # -----------------------------
    def new_module(self):
        self.module_name.set("")
        self.version.set("0.1.0")
        self.author.set("")
        self.author_email.set("")
        self.description.set("")
        self.pypi_token.set("")
        self.code_text.delete(1.0, tk.END)
        self.usage_text.delete(1.0, tk.END)
        self.usage_text.insert(tk.END, self.default_usage_text())
        self.log_info("Cleared fields for new module.")
        self.set_status("Ready")

    def show_about(self):
        messagebox.showinfo("About", "PyPI Module Publisher — Amazon Style\nVersion 1.0\nDesigned to be modern & simple.")

    def log_message(self, message, tag="info"):
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] ", "timestamp")
        self.log_text.insert(tk.END, f"{message}\n", tag)
        self.log_text.see(tk.END)
        self.root.update_idletasks()

    def log_info(self, message):
        self.log_message(message, "info")

    def log_command(self, message):
        """Log command messages in green"""
        self.log_message(message, "command")

    def log_error(self, message):
        """Log error messages in red"""
        self.log_message(message, "error")

    def log_success(self, message):
        """Log success messages in green"""
        self.log_message(message, "success")

    def log_warning(self, message):
        """Log warning messages in yellow"""
        self.log_message(message, "warning")

    def log_debug(self, message):
        """Log debug messages in cyan"""
        self.log_message(message, "debug")

    def set_status(self, text):
        self.status_text.set(text)
        self.root.update_idletasks()

    def simulate_progress(self, max_value=100, interval=0.05):
        """Simulate progress for visual feedback"""
        for i in range(max_value + 1):
            self.progress['value'] = i
            self.root.update_idletasks()
            time.sleep(interval)

    def run_command(self, command, cwd=None, env=None):
        """Run command and stream outputs to log text. Returns True if exit code 0."""
        self.log_command(f"$ {' '.join(command)}")
        try:
            # Use subprocess.Popen for real-time output
            proc = subprocess.Popen(
                command, 
                cwd=cwd, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.STDOUT, 
                text=True, 
                env=env or dict(os.environ, PYTHONPATH=''),
                bufsize=1,
                universal_newlines=True
            )
            
            # Stream output in real-time
            while True:
                if proc.stdout is not None:
                    output = proc.stdout.readline()
                    if output == '' and proc.poll() is not None:
                        break
                    if output:
                        line = output.strip()
                        # Colorize based on content
                        if re.search(r'(ERROR|Failed|Exception|Traceback)', line, re.IGNORECASE):
                            self.log_error(line)
                        elif re.search(r'(SUCCESS|Completed|Finished|Done)', line, re.IGNORECASE):
                            self.log_success(line)
                        elif re.search(r'(WARN|Warning)', line, re.IGNORECASE):
                            self.log_warning(line)
                        elif re.search(r'(DEBUG|Debug)', line, re.IGNORECASE):
                            self.log_debug(line)
                        elif re.search(r'(Installing|Downloading|Collecting)', line, re.IGNORECASE):
                            self.log_info(line)
                        else:
                            self.log_info(line)
            
            proc.wait()
            if proc.returncode != 0:
                self.log_error(f"Command failed with exit code {proc.returncode}")
                return False
            else:
                self.log_success("Command completed successfully")
                return True
        except Exception as e:
            self.log_error(f"Exception running command: {e}")
            return False

    def generate_setup(self):
        module_name = self.module_name.get().strip()
        if not module_name:
            messagebox.showerror("Error", "Please enter a module name")
            return

        # Create temp dir
        temp_dir = tempfile.mkdtemp(prefix="pypi_module_")
        module_dir = os.path.join(temp_dir, module_name)
        try:
            os.makedirs(module_dir, exist_ok=True)
            init_path = os.path.join(module_dir, "__init__.py")
            with open(init_path, "w", encoding="utf-8") as f:
                f.write(self.code_text.get(1.0, tk.END))
            self.log_success(f"Created {init_path}")

            # setup.py
            setup_content = f'''from setuptools import setup, find_packages

setup(
    name="{module_name}",
    version="{self.version.get()}",
    author="{self.author.get()}",
    author_email="{self.author_email.get()}",
    description="{self.description.get()}",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
'''
            setup_path = os.path.join(temp_dir, "setup.py")
            with open(setup_path, "w", encoding="utf-8") as f:
                f.write(setup_content)
            self.log_success(f"Created {setup_path}")

            # pyproject.toml
            pyproject_content = '''[build-system]
requires = ["setuptools>=45", "wheel"]
build-backend = "setuptools.build_meta"
'''
            pyproject_path = os.path.join(temp_dir, "pyproject.toml")
            with open(pyproject_path, "w", encoding="utf-8") as f:
                f.write(pyproject_content)
            self.log_success(f"Created {pyproject_path}")

            # README.md
            readme_content = f"# {module_name}\n\n{self.description.get()}\n"
            readme_path = os.path.join(temp_dir, "README.md")
            with open(readme_path, "w", encoding="utf-8") as f:
                f.write(readme_content)
            self.log_success(f"Created {readme_path}")

            self.temp_dir = temp_dir
            self.log_success(f"Setup files created in {temp_dir}")
            messagebox.showinfo("Success", f"Setup files created in:\n{temp_dir}")
            self.set_status("Setup generated")
        except Exception as e:
            self.log_error(f"Error generating setup: {e}")
            messagebox.showerror("Error", f"Error generating setup: {e}")
            self.set_status("Error")

    def build_package(self):
        if not hasattr(self, "temp_dir") or not os.path.exists(self.temp_dir):
            messagebox.showerror("Error", "Please generate setup files first")
            return

        def worker():
            self.set_status("Installing build tools...")
            self.progress.start(10)
            self.log_info("Installing required build tools...")
            ok = self.run_command([sys.executable, "-m", "pip", "install", "--upgrade", "build", "twine"])
            if not ok:
                self.progress.stop()
                self.set_status("Failed to install build tools")
                self.log_error("Failed to install build tools")
                return
            self.log_success("Build tools installed successfully")
            
            # Clean dist
            dist_path = os.path.join(self.temp_dir, "dist")
            if os.path.exists(dist_path):
                shutil.rmtree(dist_path)
                self.log_info("Cleaned previous builds")
                time.sleep(0.5)  # Small delay for visual feedback

            self.set_status("Building package...")
            self.log_info("Building package...")
            ok = self.run_command([sys.executable, "-m", "build"], cwd=self.temp_dir)
            self.progress.stop()
            if ok:
                self.set_status("Build successful")
                self.log_success("Package built successfully!")
                messagebox.showinfo("Success", "Package built successfully!")
            else:
                self.set_status("Build failed")
                self.log_error("Failed to build package. Check log.")
                messagebox.showerror("Error", "Failed to build package. Check log.")

        t = threading.Thread(target=worker, daemon=True)
        t.start()

    def publish_package(self):
        if not hasattr(self, "temp_dir") or not os.path.exists(self.temp_dir):
            messagebox.showerror("Error", "Please generate setup files first")
            return

        token = self.pypi_token.get().strip()
        if not token:
            messagebox.showerror("Error", "Please enter your PyPI API token")
            return

        dist_path = os.path.join(self.temp_dir, "dist")
        if not os.path.exists(dist_path) or not os.listdir(dist_path):
            messagebox.showerror("Error", "No built package found. Please build the package first.")
            return

        def worker():
            self.set_status("Publishing package to PyPI...")
            self.progress.start(8)
            self.log_info("Publishing package to PyPI...")
            
            # Use environment variable for token authentication
            env = os.environ.copy()
            env['TWINE_USERNAME'] = '__token__'
            env['TWINE_PASSWORD'] = token
            
            twine_cmd = [
                sys.executable, "-m", "twine", "upload",
                os.path.join(dist_path, "*")
            ]
            ok = self.run_command(twine_cmd, env=env)
            self.progress.stop()
            if ok:
                self.set_status("Published successfully")
                self.log_success("Published to PyPI.")
                self.generate_usage_guide()
                messagebox.showinfo("Success", "Package published successfully!")
            else:
                self.set_status("Publish failed")
                self.log_error("Publish failed. Check log for details.")
                messagebox.showerror("Error", "Publish failed. Check log for details.")

        t = threading.Thread(target=worker, daemon=True)
        t.start()

    def generate_usage_guide(self):
        """Generate usage guide based on the module code with parameter information"""
        module_name = self.module_name.get().strip() or "your_module"
        code = self.code_text.get(1.0, tk.END)
        
        try:
            # Parse the code to extract functions and classes
            tree = ast.parse(code)
            
            functions = []
            classes = []
            
            # Extract functions with parameter information
            for node in ast.iter_child_nodes(tree):
                if isinstance(node, ast.FunctionDef):
                    # Get function name and parameters
                    func_name = node.name
                    args = []
                    if node.args.args:
                        for arg in node.args.args:
                            args.append(arg.arg)
                    functions.append((func_name, args))
                elif isinstance(node, ast.ClassDef):
                    classes.append(node.name)
            
            # Generate usage guide in the desired format
            usage = f"# Usage Guide for {module_name}\n\n## Installation\n\n```\npip install {module_name}\n```\n\n## Usage Examples\n\n```python\nimport {module_name}\n"
            
            # Add function examples with parameters
            if functions:
                usage += "\n# Functions\n"
                for fname, args in functions:
                    usage += f"\n# Using {fname}\n"
                    if args:
                        # skip self
                        arglist = [a for a in args if a != "self"]
                        param_str = ", ".join([f"{a}={self._example_for_arg(a)}" for a in arglist])
                        usage += f"result = {module_name}.{fname}({param_str})\n"
                    else:
                        usage += f"result = {module_name}.{fname}()\n"
            
            # Add class examples
            if classes:
                usage += "\n# Classes\n"
                for cname in classes:
                    usage += f"\nobj = {module_name}.{cname}()\n"
            usage += "```\n\n## API Reference\n\n(Automatically generated examples)"
            
            # Update the usage text
            self.usage_text.delete(1.0, tk.END)
            self.usage_text.insert(tk.END, usage)
            self.log_success("Usage guide generated.")
        except Exception as e:
            self.log_error(f"Error generating usage guide: {e}")

    def _example_for_arg(self, argname):
        # small heuristic to pick example values
        low = argname.lower()
        if "name" in low or "str" in low:
            return "'example'"
        if "count" in low or "num" in low or "n" == low:
            return "1"
        if "path" in low or "file" in low:
            return "'/path/to/file'"
        if "flag" in low or "enabled" in low or "bool" in low:
            return "True"
        return "value"

    # -----------------------------
    # Extra helpers
    # -----------------------------
    def open_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.log_info(f"Selected folder: {folder}")

    def save_code_to_file(self):
        module_name = self.module_name.get().strip() or "module"
        fname = filedialog.asksaveasfilename(defaultextension=".py", initialfile=f"{module_name}.py",
                                             filetypes=[("Python", "*.py"), ("All files", "*.*")])
        if fname:
            try:
                with open(fname, "w", encoding="utf-8") as f:
                    f.write(self.code_text.get(1.0, tk.END))
                self.log_success(f"Saved code to {fname}")
                messagebox.showinfo("Saved", f"Code saved to {fname}")
            except Exception as e:
                self.log_error(f"Failed to save file: {e}")
                messagebox.showerror("Error", f"Failed to save file: {e}")

def main():
    root = tk.Tk()
    app = PyPIPublisherGUI(root)
    
    # Configure text tags for colored log output
    log_text = app.log_text
    log_text.tag_configure("timestamp", foreground="#888888")
    log_text.tag_configure("info", foreground=CONSOLE_WHITE)
    log_text.tag_configure("command", foreground=CONSOLE_GREEN, font=("Consolas", 9, "bold"))
    log_text.tag_configure("error", foreground=CONSOLE_RED)
    log_text.tag_configure("success", foreground=CONSOLE_GREEN)
    log_text.tag_configure("warning", foreground=CONSOLE_YELLOW)
    log_text.tag_configure("debug", foreground=CONSOLE_CYAN)
    
    # Set background color for the log text widget
    log_text.configure(background=CONSOLE_BLACK)
    
    root.mainloop()

if __name__ == "__main__":
    main()
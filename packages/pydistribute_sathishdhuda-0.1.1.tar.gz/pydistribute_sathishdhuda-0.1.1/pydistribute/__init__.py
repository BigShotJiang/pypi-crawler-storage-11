"""
PyDistribute - A GUI tool for creating and publishing Python modules to PyPI
"""

__version__ = "0.1.0"

def run():
    """Run the PyPI Publisher GUI"""
    from .gui import main
    main()

if __name__ == "__main__":
    run()
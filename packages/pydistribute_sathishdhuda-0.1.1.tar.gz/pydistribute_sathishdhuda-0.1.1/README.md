# NLTKK - Natural Language Toolkit Kit

A comprehensive NLP toolkit with functions for text processing, analysis, and more.

## Features

- Plural word detection
- Text splitting
- Stemming and lemmatization
- Stop word removal
- Sentence tokenization
- Edit distance calculation
- N-gram models
- Bigram probability calculation
- Kneser-Ney smoothing
- Sentiment analysis
- Text chunking
- POS tagging
- HMM POS tagging
- Named Entity Recognition
- Markov Chains
- Thematic Role Labeling
- PropBank lookup
- FrameNet lookup
- Relation extraction
- Relation classification

## Installation

```bash
pip install nlltk
```

## Usage

```python
import nltkk

# Example usage
text = "Hello! How's everything going? Let's meet at 5:00 pm. #excited"
words = nltkk.split(text)
print(words)
```

## Simple Module Manager

This package also includes a GUI application for creating and publishing your own Python modules:

### Features
- Create Python modules by entering module name and code
- Build distribution packages (wheel and source distributions)
- Publish to PyPI or TestPyPI for public access
- Simple and intuitive interface

### Running the Module Manager

```bash
simple-module-manager
```

Or run directly:

```bash
python simple_module_manager.py
```

### How to Publish Your Module

1. Run the Simple Module Manager
2. Enter a unique module name
3. Write or paste your Python code
4. Click "Create Module"
5. Click "Build Module"
6. Enter your PyPI API token
7. Click "Publish Module"

### Getting PyPI API Tokens

1. Go to https://pypi.org/manage/account/
2. Scroll down to "API tokens"
3. Click "Add API token"
4. Give it a name and select scope
5. Copy the token and paste it in the application

### Making Your Module Publicly Accessible

When you publish to PyPI:
1. Your module becomes publicly available
2. Anyone can install it with `pip install your-module-name`
3. They can import and use your functions and classes in their projects

This makes your code accessible to the entire Python community!

# PyDistribute

A GUI tool for creating and publishing Python modules to PyPI.

## Features

- Simple graphical interface for package creation
- Automatic generation of setup files
- One-click package building and publishing
- Usage guide generation
- Real-time console output with colored logging

## Installation

```bash
pip install pydistribute
```

## Usage

After installation, you can run PyDistribute in several ways:

1. From the command line:
   ```bash
   pydistribute
   ```

2. From Python:
   ```python
   import pydistribute
   pydistribute.run()
   ```

3. Using the batch file (Windows):
   ```bash
   run_pydistribute.bat
   ```

## Publishing Your Package

1. Enter your module information (name, version, author, etc.)
2. Paste your Python code in the editor
3. Click "Generate Setup" to create all necessary packaging files
4. Click "Build Package" to create the distributable files
5. Enter your PyPI API token
6. Click "Publish to PyPI"

## Getting a PyPI API Token

1. Go to https://pypi.org/ and log in to your account
2. Navigate to Account Settings → API tokens
3. Click "Add API token"
4. Give it a name and select scope (entire account or specific project)
5. Copy the token and use it in the GUI

## Requirements

- Python 3.6 or higher
- pip
- A PyPI account and API token

## Security Notes

- Your PyPI API token is stored only in memory and is not saved to disk
- Never share your API token with others
- For added security, use a token with limited scope

## License

This project is licensed under the MIT License.

## Troubleshooting

**Error: 403 Forbidden when publishing**
- Make sure your API token is correct and has the necessary permissions
- Ensure you're using a valid token from https://pypi.org/manage/account/
- Try creating a new token if the current one isn't working

**Error: No built package found**
- Make sure you clicked "Build Package" before trying to publish

**Error: Failed to install build tools**
- Make sure you have internet connection
- Try running `pip install build twine` manually

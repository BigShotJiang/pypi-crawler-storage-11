# setup.py
from setuptools import setup, find_packages

setup(
    name='rocket_HAFA',  # Replace with your package name
    version="0.1.1",
 # Replace with your package version
    author='nouar hafnaoui',  # Replace with your name
    author_email='mh.nouar@esi-sba.dz',  # Replace with your email
    description='A package for simulating rockets and shuttles',
    packages=find_packages(),  # Automatically find packages in the directory
    license='MIT',  # License type
    url='https://github.com/hafa',  # Replace with your repo URL if applicable
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)

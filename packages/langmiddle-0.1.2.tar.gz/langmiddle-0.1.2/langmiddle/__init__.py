"""Middlewares for LangChain / LangGraph

This package provides middleware components for LangChain and LangGraph applications,
enabling enhanced functionality and streamlined development workflows.
"""

__version__ = "0.1.2"
__author__ = "Alpha x1"
__email__ = "alpha.xone@outlook.com"

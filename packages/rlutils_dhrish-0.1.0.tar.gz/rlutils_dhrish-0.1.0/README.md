# RLUtils Dhrish

A lightweight Python package for core Reinforcement Learning utilities — ideal for students, researchers, and practitioners.

## 🚀 Features
- **n_step_return:** Compute n-step bootstrapped returns.
- **discount_rewards:** Compute discounted cumulative rewards.
- **moving_average_rewards:** Smooth episodic returns over time.

## 📦 Installation
```bash
pip install rlutils-dhrish

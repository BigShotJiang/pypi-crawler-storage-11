"""
RLUtils Dhrish: A lightweight reinforcement learning utility package.

Includes:
- n_step_return: Compute n-step bootstrapped returns.
- discount_rewards: Compute discounted cumulative rewards.
- moving_average_rewards: Smooth episodic rewards.

Author: Dhrish Shah
"""

from .n_step_return import n_step_return
from .discount_rewards import discount_rewards
from .moving_average import moving_average_rewards

__all__ = ["n_step_return", "discount_rewards", "moving_average_rewards"]

import numpy as np

def discount_rewards(rewards, gamma=0.99, normalize=True):
    """
    Computes discounted cumulative rewards for a full episode.

    Parameters
    ----------
    rewards : list or np.ndarray
        Sequence of rewards obtained in an episode.
    gamma : float, optional (default=0.99)
        Discount factor (0 <= gamma <= 1).
    normalize : bool, optional (default=True)
        Whether to normalize the result to zero mean and unit variance.

    Returns
    -------
    np.ndarray
        Discounted reward-to-go for each timestep.

    Example
    -------
    >>> rewards = [1, 1, 1]
    >>> discount_rewards(rewards, gamma=0.9)
    array([2.71, 1.9, 1. ])
    """
    if not isinstance(rewards, (list, np.ndarray)):
        raise TypeError("rewards must be a list or numpy array")

    if not 0 <= gamma <= 1:
        raise ValueError("gamma must be between 0 and 1")

    rewards = np.array(rewards, dtype=float)
    discounted = np.zeros_like(rewards)
    running_add = 0.0

    for t in reversed(range(len(rewards))):
        running_add = rewards[t] + gamma * running_add
        discounted[t] = running_add

    if normalize:
        discounted = (discounted - np.mean(discounted)) / (np.std(discounted) + 1e-8)

    return discounted


if __name__ == "__main__":
    # Demo example
    rewards = [1, 1, 1]
    print("Discounted rewards:", discount_rewards(rewards, gamma=0.9, normalize=False))

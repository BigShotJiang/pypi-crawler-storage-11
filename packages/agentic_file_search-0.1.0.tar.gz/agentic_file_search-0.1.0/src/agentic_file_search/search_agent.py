import json
import subprocess
import os
import time
from pathlib import Path

from .conversation import Conversation


DESCRIPTION = "Agentic search agent that explores folders using Windows CMD commands and answers user queries"

INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "message": {"type": "string", "description": "User query about what to find or explore"},
        "folder_path": {"type": "string", "description": "Path to folder to explore"},
        "max_iterations": {"type": "integer", "description": "Maximum exploration iterations (default: 20)"},
        "thinking": {"type": "boolean", "description": "Whether to enable extended thinking"},
        "thinking_budget": {"type": "integer", "description": "Token budget for thinking"},
        "model": {"type": "string", "description": "Claude model to use"}
    },
    "required": ["message", "folder_path"]
}

OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "success": {"type": "boolean", "description": "Whether exploration completed successfully"},
        "summary": {"type": "string", "description": "Summary of exploration and findings"},
        "iterations": {"type": "integer", "description": "Number of iterations used"},
        "time_taken": {"type": "number", "description": "Time taken in seconds"},
        "commands_executed": {
            "type": "object",
            "description": "Count of each command type executed"
        },
        "key_findings": {
            "type": "array",
            "description": "Key findings from exploration",
            "items": {
                "type": "object",
                "properties": {
                    "command": {"type": "string"},
                    "result_preview": {"type": "string"}
                }
            }
        }
    },
    "required": ["success", "summary", "iterations", "time_taken"]
}

SYSTEM_PROMPT_TEMPLATE = """You are an autonomous folder exploration agent. Your task is to explore a directory structure using Windows CMD commands to help answer the user's question.

AVAILABLE COMMANDS:
- dir [path]: List directory contents
- tree /F /A [path]: Show full directory tree structure with files
- tree /A [path]: Show directory tree without files (faster for deep folders)
- type <file>: Display file contents
- findstr /S /I "pattern" *.ext: Search for text patterns in files
- where <file>: Locate files by name
- cd <path>: Change to relative subdirectory{rga_command}

TIPS:
- Always check folder size first using 'dir' or 'tree /A'{rga_tip_suffix}
- If tree output is massive (truncated), use 'dir' on specific subdirectories instead{additional_tips}

INSTRUCTIONS:
1. Analyze the current state and decide what to do next
2. Choose ONE action: execute a command OR conclude
3. When you have gathered enough information, provide a conclusion

OUTPUT FORMAT (output ONLY ONE of these per response):
<command>The command to execute{rga_output_hint}</command>

OR when ready to conclude:
<conclude>Summary of what was found and answer to user's query</conclude>

IMPORTANT: Output ONLY ONE action tag per response. Do not output multiple commands or mix commands with other content."""

INITIAL_USER_PROMPT = """USER QUERY: {user_query}
STARTING DIRECTORY: {current_dir}

Begin exploration."""

CONTINUE_PROMPT = """Last command: {command}
Result: {result}

Continue exploration."""

EXCLUDED_DIR_PATTERNS = {
    "__pycache__", "node_modules", ".git", "dist", "build", ".venv", "venv",
    ".pytest_cache", ".ruff_cache", ".nuxt", ".next", "coverage", "htmlcov",
    "docs", "documentation", "examples", "tests", ".idea", ".vscode", ".vs",
    ".mypy_cache", ".tox", ".coverage", ".cache", "__MACOSX"
}

SAFE_COMMANDS = {"dir", "tree", "type", "findstr", "where", "cd", "echo"}
DANGEROUS_PATTERNS = ["del", "rmdir", "rd", "erase", "move", "copy", "xcopy", "ren", "rename",
                      "format", "diskpart", "reg", "sc", "net", "taskkill", "shutdown",
                      ">", ">>", "|", "&", "&&", "||", "^", "<"]

MAX_OUTPUT_SIZE = 500000
MAX_FILE_SIZE = 1000000
COMMAND_TIMEOUT = 10


class SearchAgent:
    """Autonomous agent for exploring and searching folder structures using CMD commands."""

    # ============================================================================
    # INITIALIZATION
    # ============================================================================

    def __init__(
        self,
        model="claude-haiku-4-5",
        log_file=None,
        hide_long_user_messages=True,
        max_logged_user_chars=2000,
        use_rga=True,
    ):
        self.model = model
        self.use_rga = use_rga
        self.rga_available = self.check_rga_available() if use_rga else False
        self.tools = {
            "web_search": {
                "type": "web_search_20250305",
                "name": "web_search",
            }
        }

        self.conversation = Conversation(
            system=self.get_system_prompt(),
            model=model,
            log_file=log_file,
            tools=self.tools,
            hide_long_user_messages=hide_long_user_messages,
            max_logged_user_chars=max_logged_user_chars,
        )

    def check_rga_available(self):
        """Check if rga (ripgrep-all) is available on the system."""
        try:
            result = subprocess.run(
                ["rga", "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    # ============================================================================
    # PROMPT GENERATION
    # ============================================================================

    def get_system_prompt(self):
        """Get the appropriate system prompt based on rga availability."""
        if self.rga_available:
            return SYSTEM_PROMPT_TEMPLATE.format(
                rga_command="\n- rga <search_query> <folder>: Use ripgrep-all for comprehensive search across all files",
                rga_tip_suffix=" before using RGA",
                additional_tips="\n- For small to medium folders, use RGA to scan everything at once (very efficient)\n- For large folders, narrow down to specific subdirectories before using RGA\n- RGA searches through code, documents, PDFs, and more - but can be slow on large folders",
                rga_output_hint=' (or "RGA: <query> <folder>" for ripgrep-all)'
            )
        else:
            return SYSTEM_PROMPT_TEMPLATE.format(
                rga_command="",
                rga_tip_suffix=" to understand the structure",
                additional_tips="\n- Use 'findstr /S /I \"pattern\" *.ext' to search for text patterns across files\n- Use 'where' to locate files by name\n- For targeted content search, use 'type' to read specific files\n- Combine commands strategically: use tree/dir to find files, then type to read them",
                rga_output_hint=""
            )

    def create_agent_prompt(self, user_query, current_dir, is_first_iteration, last_command="", last_result="", max_result_len=50000):
        """Build the prompt for the agent's next iteration, including previous command results if available."""
        if is_first_iteration:
            return INITIAL_USER_PROMPT.format(user_query=user_query, current_dir=current_dir)

        truncated_result = last_result[:max_result_len]
        if len(last_result) > max_result_len:
            truncated_result += (
                "\n\n[!!! OUTPUT TRUNCATED !!!]\n"
                f"Original size: {len(last_result)} chars, showing first {max_result_len} chars.\n"
                "WARNING: Critical information may be hidden. Consider using a more targeted command."
            )
        return CONTINUE_PROMPT.format(command=last_command, result=truncated_result)

    # ============================================================================
    # AGENT DECISION PARSING
    # ============================================================================

    def parse_extracted_decision(self, extracted):
        """Parse the extracted tags to determine the agent's action."""
        # Check which tag was provided (one should be present, the other None)
        if extracted.get("conclude") is not None:
            return {
                "action": "conclude",
                "conclusion": extracted["conclude"]
            }
        
        if extracted.get("command") is not None:
            command = extracted["command"]
            
            # Check if it's an RGA command
            if command.upper().startswith("RGA:"):
                rga_parts = command[4:].strip().split(maxsplit=1)
                if len(rga_parts) == 2:
                    return {
                        "action": "rga",
                        "query": rga_parts[0],
                        "folder": rga_parts[1]
                    }
                return {
                    "action": "rga",
                    "query": rga_parts[0] if rga_parts else "",
                    "folder": "."
                }
            
            return {
                "action": "command",
                "command": command
            }
        
        # This should not happen due to answer_with_tags validation
        return {
            "action": "error",
            "error": "No valid tags extracted"
        }

    # ============================================================================
    # COMMAND EXECUTION
    # ============================================================================

    def execute_safe_command(self, command_str, base_folder, timeout=COMMAND_TIMEOUT):
        """Execute a whitelisted command in the target folder with security checks and output size limits."""
        command_str = command_str.strip()

        if not command_str:
            return {"success": False, "error": "Empty command", "stdout": "", "stderr": ""}

        parts = command_str.split()
        if not parts:
            return {"success": False, "error": "Invalid command", "stdout": "", "stderr": ""}

        cmd_name = parts[0].lower()

        if cmd_name not in SAFE_COMMANDS:
            return {"success": False, "error": f"Command '{cmd_name}' not in whitelist: {SAFE_COMMANDS}", "stdout": "", "stderr": ""}

        for pattern in DANGEROUS_PATTERNS:
            if pattern in command_str.lower():
                return {"success": False, "error": f"Dangerous pattern '{pattern}' detected", "stdout": "", "stderr": ""}

        if cmd_name == "type" and len(parts) > 1:
            file_path = " ".join(parts[1:])
            full_path = os.path.join(base_folder, file_path) if not os.path.isabs(file_path) else file_path

            if not full_path.startswith(os.path.abspath(base_folder)):
                return {"success": False, "error": "Path traversal attempt detected", "stdout": "", "stderr": ""}

            if os.path.exists(full_path) and os.path.isfile(full_path):
                file_size = os.path.getsize(full_path)
                if file_size > MAX_FILE_SIZE:
                    return {"success": False, "error": f"File too large ({file_size} bytes > {MAX_FILE_SIZE} bytes)", "stdout": "", "stderr": ""}

        result = subprocess.run(
            command_str,
            shell=True,
            capture_output=True,
            text=True,
            cwd=base_folder,
            timeout=timeout,
            encoding="utf-8",
            errors="ignore"
        )

        stdout = result.stdout[:MAX_OUTPUT_SIZE] if result.stdout else ""
        stderr = result.stderr[:MAX_OUTPUT_SIZE] if result.stderr else ""

        if len(result.stdout or "") > MAX_OUTPUT_SIZE:
            stdout += (
                "\n\n[!!! OUTPUT TRUNCATED !!!]\n"
                f"Original size: {len(result.stdout)} chars, showing first {MAX_OUTPUT_SIZE} chars.\n"
                "WARNING: Critical information may be hidden. Consider using a more targeted command (e.g., filter results, search specific subdirectory)."
            )

        return {
            "success": result.returncode == 0,
            "stdout": stdout,
            "stderr": stderr,
            "returncode": result.returncode
        }

    # ============================================================================
    # MAIN EXPLORATION LOOP
    # ============================================================================

    def explore(self, user_query, folder_path, max_iterations=20, **kwargs):
        """Run an autonomous exploration loop to answer the user's query about a folder."""
        start_time = time.time()

        folder_path = os.path.abspath(folder_path)
        if not os.path.isdir(folder_path):
            return {
                "success": False,
                "error": f"Folder does not exist: {folder_path}",
                "summary": "",
                "iterations": 0,
                "time_taken": 0
            }

        history = []
        current_dir = folder_path

        print(f"[EXPLORATION] Starting exploration of: {folder_path}")
        print(f"[EXPLORATION] User query: {user_query}")

        last_command = ""
        last_result = ""

        for iteration in range(1, max_iterations + 1):
            print(f"\n[ITERATION {iteration}/{max_iterations}]")

            prompt = self.create_agent_prompt(user_query, current_dir, is_first_iteration=(iteration == 1),
                                        last_command=last_command, last_result=last_result)

            # Extract tags using answer_with_tags (one of conclude or command must be present)
            extracted = self.conversation.answer_with_tags(
                prompt, 
                required_tags=["conclude", "command"],
                allow_none=True,
                additional_error_message="You must provide EXACTLY ONE of these tags: <conclude> for conclusions or <command> for commands.",
                **kwargs
            )
            
            decision = self.parse_extracted_decision(extracted)

            if decision["action"] == "conclude":
                print("[CONCLUDE] Agent has concluded exploration")
                elapsed = time.time() - start_time
                return {
                    "success": True,
                    "summary": decision["conclusion"],
                    "iterations": iteration,
                    "time_taken": round(elapsed, 2),
                    "history": history
                }

            if decision["action"] == "command":
                command = decision["command"]
                print(f"[COMMAND] {command}")

                result = self.execute_safe_command(command, current_dir)

                if result["success"]:
                    output = result["stdout"] if result["stdout"] else result["stderr"]
                    print(f"[OUTPUT] {len(output)} chars")
                    history.append({"command": command, "result": output})
                    last_command = command
                    last_result = output
                else:
                    error = result.get("error", result.get("stderr", "Unknown error"))
                    print(f"[ERROR] {error}")
                    error_msg = f"ERROR: {error}"
                    history.append({"command": command, "result": error_msg})
                    last_command = command
                    last_result = error_msg
                continue

            if decision["action"] == "rga":
                query = decision["query"]
                folder = decision.get("folder", ".")
                target_folder = os.path.join(current_dir, folder) if folder != "." else current_dir
                print(f"[RGA] Query: {query}, Folder: {folder}")

                if not self.rga_available:
                    error_msg = "ERROR: rga is not available. Please use findstr, where, or type commands instead."
                    print(f"[ERROR] {error_msg}")
                    rga_cmd = f"rga {query} {folder}"
                    history.append({"command": rga_cmd, "result": error_msg})
                    last_command = rga_cmd
                    last_result = error_msg
                    continue

                rga_results = self.run_rga(query, target_folder)

                result_summary = f"Found {len(rga_results)} matches"
                if rga_results:
                    files = {result_item["file"] for result_item in rga_results}
                    result_summary += f" in {len(files)} files"
                    all_results = "\n".join([
                        f"- {result_item['file']}:{result_item['line']} {result_item['match'][:80]}"
                        for result_item in rga_results
                    ])
                    result_summary += f"\nAll results:\n{all_results}"

                print(f"[RGA RESULT] {result_summary[:200]}...")
                rga_cmd = f"rga {query} {folder}"
                history.append({"command": rga_cmd, "result": result_summary})
                last_command = rga_cmd
                last_result = result_summary
                continue

            if decision["action"] == "error":
                print(f"[PARSE ERROR] {decision.get('error')}")
                history.append({"command": "(parse error)", "result": decision.get('error', 'Unknown error')})

        print("\n[EXPLORATION] Max iterations reached")
        elapsed = time.time() - start_time

        return {
            "success": False,
            "error": "Max iterations reached without conclusion",
            "summary": "Exploration incomplete - max iterations reached",
            "iterations": max_iterations,
            "time_taken": round(elapsed, 2),
            "history": history
        }

    # ============================================================================
    # RGA SEARCH METHODS
    # ============================================================================

    def calculate_line_from_offset(self, file_path, absolute_offset):
        """Calculate the line number from a byte offset in a file."""
        if not os.path.isfile(file_path):
            return 0

        with open(file_path, "rb") as file_handle:
            content = file_handle.read(absolute_offset)

        return content.count(b"\n") + 1

    def get_context_lines(self, file_path, line_number, context_lines=2):
        """Extract context lines before and after a specific line in a file."""
        context_before = ""
        context_after = ""

        if not os.path.isfile(file_path) or not line_number or line_number <= 0:
            return context_before, context_after

        with open(file_path, "r", encoding="utf-8", errors="ignore") as file_handle:
            all_lines = file_handle.readlines()

        start = max(0, line_number - context_lines - 1)
        end = min(len(all_lines), line_number + context_lines)

        before_lines = all_lines[start:line_number - 1] if line_number > 1 else []
        after_lines = all_lines[line_number:end] if line_number <= len(all_lines) else []

        context_before = "".join(before_lines).strip()
        context_after = "".join(after_lines).strip()

        return context_before, context_after

    def run_rga(self, query, folder_path):
        """Run ripgrep-all to search for text across all file types in a folder."""
        cmd = ["rga", "--json", query, folder_path]
        for pattern in EXCLUDED_DIR_PATTERNS:
            cmd.extend(["--glob", f"!**/{pattern}/**"])

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=60
        )

        if result.returncode != 0:
            stderr = result.stderr or ""
            if "command not found" in stderr.lower() or "not recognized" in stderr.lower():
                raise FileNotFoundError("rga (ripgrep-all) is not installed. Install it first: https://github.com/phiresky/ripgrep-all")

            stdout = result.stdout or ""
            if stdout.strip():
                try:
                    lines = stdout.strip().split("\n")
                    for line in reversed(lines):
                        if line.strip():
                            summary = json.loads(line)
                            if summary.get("type") == "summary":
                                return []
                except (json.JSONDecodeError, KeyError):
                    pass

            error_msg = stderr if stderr else stdout if stdout else "Unknown error"
            raise RuntimeError(f"rga command failed (code {result.returncode}): {error_msg}")

        stdout = result.stdout or ""
        if not stdout.strip():
            return []

        lines = stdout.strip().split("\n")
        results = []
        for line_idx, line in enumerate(lines, 1):
            if not line.strip():
                continue

            try:
                match_data = json.loads(line)
            except json.JSONDecodeError as error:
                print(f"Warning: Failed to parse JSON at line {line_idx}: {error}")
                print(f"Content: {line[:100]}...")
                continue

            if match_data.get("type") == "match":
                data = match_data.get("data", {})
                path = data.get("path", {}).get("text", "")
                line_number = data.get("line_number")
                absolute_offset = data.get("absolute_offset", 0)
                lines_obj = data.get("lines", {})
                full_line_text = lines_obj.get("text", "").strip()

                submatches = data.get("submatches", [])
                if submatches and len(submatches) > 0:
                    submatch = submatches[0]
                    start = submatch.get("start", 0)
                    end = submatch.get("end", 0)
                    match_text = full_line_text[start:end] if full_line_text else ""
                else:
                    match_text = full_line_text

                if line_number is None and absolute_offset is not None:
                    line_number = self.calculate_line_from_offset(path, absolute_offset)

                line_number = line_number if line_number else 0
                context_before, context_after = self.get_context_lines(path, line_number)

                result_item = {
                    "file": Path(path).as_posix(),
                    "line": line_number,
                    "match": match_text,
                    "context_before": context_before,
                    "context_after": context_after
                }
                results.append(result_item)

        return results

    # ============================================================================
    # RESULT FORMATTING
    # ============================================================================

    def format_exploration_summary(self, exploration_result):
        """Format exploration results into a structured summary with command counts and key findings."""
        summary = exploration_result.get("summary", "No summary available")
        iterations = exploration_result.get("iterations", 0)
        time_taken = exploration_result.get("time_taken", 0)
        history = exploration_result.get("history", [])

        command_counts = {}
        for history_item in history:
            cmd = history_item["command"].split()[0] if history_item["command"] else "unknown"
            command_counts[cmd] = command_counts.get(cmd, 0) + 1

        findings = []
        for history_item in history:
            if "ERROR" not in history_item["result"]:
                findings.append({
                    "command": history_item["command"],
                    "result_preview": history_item["result"][:200]
                })

        return {
            "summary": summary,
            "iterations": iterations,
            "time_taken": time_taken,
            "commands_executed": command_counts,
            "key_findings": findings[:10],
            "success": exploration_result.get("success", False)
        }


# ============================================================================
# MODULE-LEVEL FUNCTIONS
# ============================================================================

def main(*, message: str, folder_path: str, max_iterations: int = 100, model: str = "claude-haiku-4-5", use_rga: bool = True, **kwargs) -> dict:
    """Main entry point for running a folder exploration with the SearchAgent."""
    agent = SearchAgent(model=model, use_rga=use_rga)
    exploration_result = agent.explore(message, folder_path, max_iterations=max_iterations, **kwargs)
    formatted_result = agent.format_exploration_summary(exploration_result)
    return formatted_result


def test():
    """Run basic tests to verify SearchAgent functionality."""
    from jsonschema import validate

    print("Test 1: Basic exploration")
    result = main(message="What Python files are in this folder?", folder_path=".", max_iterations=5, model="claude-haiku-4-5")
    validate(instance=result, schema=OUTPUT_SCHEMA)

    assert "success" in result
    assert "summary" in result
    assert "iterations" in result

    print(f"Success: {result['success']}")
    print(f"Summary: {result['summary'][:200]}...")
    print(f"Iterations: {result['iterations']}")
    print(f"Time taken: {result['time_taken']}s")
    print(f"Commands: {result['commands_executed']}")

    print("\nTest 2: Find specific files")
    result2 = main(message="Find all agent-related files", folder_path=".", max_iterations=5, model="claude-haiku-4-5")
    validate(instance=result2, schema=OUTPUT_SCHEMA)
    print(f"Success: {result2['success']}")
    print(f"Summary: {result2['summary'][:200]}...")
    print(f"Time taken: {result2['time_taken']}s")

    print("\nAll tests passed!")


if __name__ == "__main__":
    test()

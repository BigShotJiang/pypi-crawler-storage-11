"""Command-line interface for agentic_search package."""

import argparse
import sys
import json
from pathlib import Path
from .search_agent import main


def create_parser():
    """Create and configure the argument parser."""
    parser = argparse.ArgumentParser(
        prog="agentic_file_search",
        description="Agentic search tool that explores folders using Windows CMD commands and answers queries",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m agentic_file_search "find all Python files" .
  python -m agentic_file_search "find classes that inherit from Agent" ./src --max-iterations 20
  python -m agentic_file_search "find configuration files" C:/Projects --model claude-sonnet-4-5
  python -m agentic_file_search "find receipts" ~/Downloads --no-rga --output results.json
        """
    )
    
    # Required arguments
    parser.add_argument(
        "message",
        type=str,
        help="Query or question about what to find or explore in the folder"
    )
    
    parser.add_argument(
        "folder_path",
        type=str,
        help="Path to the folder to explore"
    )
    
    # Optional arguments
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=100,
        metavar="N",
        help="Maximum number of exploration iterations (default: 100)"
    )
    
    parser.add_argument(
        "--model",
        type=str,
        default="claude-haiku-4-5",
        choices=["claude-haiku-4-5", "claude-sonnet-4-5", "claude-opus-4"],
        help="Claude model to use (default: claude-haiku-4-5)"
    )
    
    parser.add_argument(
        "--no-rga",
        action="store_true",
        help="Disable ripgrep-all (rga) command usage"
    )
    
    parser.add_argument(
        "--output",
        "-o",
        type=str,
        metavar="FILE",
        help="Save results to a JSON file"
    )
    
    parser.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Suppress progress output, only show final summary"
    )
    
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON to stdout"
    )
    
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0"
    )
    
    return parser


def format_output(result: dict, as_json: bool = False) -> str:
    """Format the exploration result for display."""
    if as_json:
        return json.dumps(result, indent=2)
    
    output = []
    output.append("=" * 80)
    output.append("EXPLORATION COMPLETE")
    output.append("=" * 80)
    output.append(f"Status: {'SUCCESS' if result['success'] else 'FAILED'}")
    output.append(f"Iterations: {result['iterations']}")
    output.append(f"Time taken: {result['time_taken']:.2f}s")
    output.append("")
    
    if result.get('commands_executed'):
        output.append("Commands executed:")
        for cmd, count in result['commands_executed'].items():
            output.append(f"  - {cmd}: {count}")
        output.append("")
    
    output.append("Summary:")
    output.append("-" * 80)
    output.append(result['summary'])
    output.append("-" * 80)
    
    if result.get('key_findings'):
        output.append("")
        output.append("Key findings:")
        for i, finding in enumerate(result['key_findings'], 1):
            output.append(f"{i}. Command: {finding.get('command', 'N/A')}")
            preview = finding.get('result_preview', '')
            if preview:
                # Truncate long previews
                preview = preview[:200] + "..." if len(preview) > 200 else preview
                output.append(f"   Result: {preview}")
    
    output.append("=" * 80)
    return "\n".join(output)


def main_cli():
    """Main CLI entry point."""
    parser = create_parser()
    args = parser.parse_args()
    
    # Validate folder path
    folder_path = Path(args.folder_path)
    if not folder_path.exists():
        print(f"Error: Folder path does not exist: {args.folder_path}", file=sys.stderr)
        sys.exit(1)
    
    if not folder_path.is_dir():
        print(f"Error: Path is not a directory: {args.folder_path}", file=sys.stderr)
        sys.exit(1)
    
    # Convert folder path to string for the agent
    folder_path_str = str(folder_path.resolve())
    
    # Show initial message unless quiet mode
    if not args.quiet:
        print(f"Starting agentic search...")
        print(f"Query: {args.message}")
        print(f"Folder: {folder_path_str}")
        print(f"Model: {args.model}")
        print(f"Max iterations: {args.max_iterations}")
        print("")
    
    try:
        # Run the search agent
        result = main(
            message=args.message,
            folder_path=folder_path_str,
            max_iterations=args.max_iterations,
            model=args.model,
            use_rga=not args.no_rga
        )
        
        # Save to file if requested
        if args.output:
            output_path = Path(args.output)
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(result, f, indent=2)
            if not args.quiet and not args.json:
                print(f"\nResults saved to: {output_path}")
        
        # Display results
        if args.json:
            print(format_output(result, as_json=True))
        elif not args.quiet:
            print(format_output(result, as_json=False))
        
        # Exit with appropriate code
        sys.exit(0 if result['success'] else 1)
        
    except KeyboardInterrupt:
        print("\n\nSearch interrupted by user.", file=sys.stderr)
        sys.exit(130)
    except Exception as e:
        print(f"\nError during search: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main_cli()


import anthropic
import os
from dotenv import load_dotenv

load_dotenv()
client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))


def prompt(conversation=None, system="", stop_sequences=None, stream=False, model="claude-sonnet-4-5", tools=None, thinking=None):
    if conversation is None:
        conversation = []
    if stop_sequences is None:
        stop_sequences = []

    # Format system with cache_control
    system_blocks = [
        {
            "type": "text",
            "text": system,
            "cache_control": {"type": "ephemeral"}
        }
    ] if system else []

    # Add cache_control to last tool
    tools_list = tools or []
    if tools_list:
        tools_list = [t.copy() for t in tools_list]
        tools_list[-1]["cache_control"] = {"type": "ephemeral"}

    # Build thinking parameter if provided
    thinking_param = None
    max_tokens = 4096  # Default max_tokens

    if thinking:
        thinking_budget = thinking.get("budget_tokens", 10000)
        thinking_param = {
            "type": "enabled",
            "budget_tokens": thinking_budget
        }
        # Ensure max_tokens is greater than thinking budget
        max_tokens = max(4096, thinking_budget + 1000)

    # Build the API call parameters
    api_params = {
        "model": model,
        "system": system_blocks,
        "messages": conversation,
        "max_tokens": max_tokens,
        "stop_sequences": stop_sequences,
        "tools": tools_list,
    }

    # Only add thinking parameter if it's not None
    if thinking_param is not None:
        api_params["thinking"] = thinking_param

    if stream:
        return client.messages.stream(**api_params)
    return client.messages.create(**api_params)


def list_models():
    models = client.models.list()
    for model in models.data:
        print(f"- {model.id}")


if __name__ == "__main__":
    prompt([{"role": "user", "content": "What is the weather in Zürich?"}], stream=True)


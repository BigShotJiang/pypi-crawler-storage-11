"""Agentic search package exposing the SearchAgent entry points."""

from .search_agent import SearchAgent, main

__version__ = "0.1.0"
__all__ = ["SearchAgent", "main"]


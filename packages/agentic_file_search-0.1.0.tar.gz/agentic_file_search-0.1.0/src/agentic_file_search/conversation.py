from .claude import prompt

class Conversation:
    def __init__(
        self,
        system="",
        tools=None,
        model="claude-sonnet-4-5",
        log_file=None,
        hide_long_user_messages=True,
        max_logged_user_chars=2000,
    ):
        self.history = []
        self.system = system
        self.tools = tools or {}
        self.model = model
        self.log_file = log_file
        self.hide_long_user_messages = hide_long_user_messages
        self.max_logged_user_chars = max_logged_user_chars
        # ANSI color codes
        self.colors = {
            "user": "\033[94m",  # Blue
            "assistant": "\033[92m",  # Green
            "system": "\033[93m",  # Yellow
            "reset": "\033[0m",  # Reset color
        }
        # Initialize the log file if provided
        if log_file is not None:
            with open(log_file, "w", encoding="utf-8") as f:
                f.write("# Conversation Log\n\n")

    @staticmethod
    def extract_text_from_message(message):
        """Extract text content from a message object with content blocks."""
        text_blocks = [block.text for block in message.content if hasattr(block, "text")]
        if not text_blocks:
            raise ValueError("No text block found in message content")
        return "\n".join(text_blocks)

    @staticmethod
    def extract_xml_tags(text, tags, allow_none=False):
        """
        Extract content from XML-like tags in text.

        Args:
            text: String containing XML-like tags
            tags: Tag name (str) or list of tag names (without angle brackets)
            allow_none: If True, return None for missing tags instead of raising error

        Returns:
            If tags is a string: Returns the extracted content directly (str or None)
            If tags is a list: Returns dict mapping tag names to their extracted content (or None)

        Raises:
            ValueError: If any required tag is missing and allow_none is False
        """
        single_tag = isinstance(tags, str)
        if single_tag:
            tags = [tags]

        result = {}
        missing_tags = []

        for tag in tags:
            open_tag = f"<{tag}>"
            close_tag = f"</{tag}>"

            if open_tag not in text or close_tag not in text:
                if allow_none:
                    result[tag] = None
                else:
                    missing_tags.append(tag)
            else:
                content = text.split(open_tag)[1].split(close_tag)[0].strip()
                result[tag] = content

        if missing_tags:
            tag_list = ", ".join([f"<{tag}>" for tag in missing_tags])
            raise ValueError(f"Missing tags: {tag_list}")

        return result[tags[0]] if single_tag else result

    @property
    def tools_declaration(self):
        """Extract tool declarations for LLM API (exclude function callables)"""
        return [
            {k: v for k, v in tool.items() if k != "function"}
            for tool in self.tools.values()
        ]

    def add_message(self, role, content, print_message=True):
        """Add a message to the conversation history and log it.

        Args:
            role (str): The role of the message sender ('user', 'assistant', etc.)
            content (str or stream): The content of the message or a stream object

        Returns:
            Message object for streams (with stop_reason, content, etc.), None otherwise
        """
        color = self.colors.get(role, self.colors["reset"])
        message_object = None
        display_content = content

        if print_message:
            print(f"{color}## {role.capitalize()} ({self._get_timestamp()}){self.colors['reset']}\n")

        # Handle stream objects
        if hasattr(content, "__enter__"):
            with content as stream:
                if print_message:
                    message_object, streamed = self._handle_stream_events(stream, role)
                else:
                    message_object = stream.get_final_message()
                    streamed = False

                content = message_object.content
                display_content = self._get_display_content(role, content)
                if print_message and not streamed and content:
                    self._print_content_blocks(display_content, color)
                    print()
        else:
            display_content = self._get_display_content(role, content)
            if print_message:
                self._print_content_blocks(display_content, color)
                print()

        self.history.append({"role": role, "content": content})

        # Write to log file if provided
        if self.log_file is not None:
            timestamp = self._get_timestamp()
            if display_content is content:
                display_content = self._get_display_content(role, content)
            formatted_message = self._format_log_message(role, display_content, timestamp)
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(formatted_message)

        return message_object

    def _safe_print(self, text, color="", end="", flush=False):
        """Print text with Unicode error handling."""
        try:
            print(f"{color}{text}{self.colors['reset']}", end=end, flush=flush)
        except UnicodeEncodeError:
            safe_text = text.encode("ascii", "replace").decode("ascii")
            print(f"{color}{safe_text}{self.colors['reset']}", end=end, flush=flush)

    def _print_block_header(self, label):
        """Print a formatted block header like [THINKING] or [TOOL USE]."""
        print(f"{self.colors['system']}[{label}]{self.colors['reset']}", end="", flush=True)

    def _print_content_blocks(self, content, color):
        """Print content blocks (thinking, text, etc.) with proper formatting."""
        if not (hasattr(content, "__iter__") and not isinstance(content, str)):
            self._safe_print(content, color)
            return

        for block in content:
            if hasattr(block, "type"):
                if block.type == "thinking":
                    self._print_block_header("THINKING")
                    print()
                    self._safe_print(block.thinking, self.colors["system"])
                    print()
                elif block.type == "text":
                    self._safe_print(block.text, color)

    def _handle_tool_block(self, content_block, thinking_started, tool_use_started):
        """Handle tool_use and server_tool_use blocks (shared logic)."""
        if not tool_use_started:
            if thinking_started:
                print(f"\n{self.colors['reset']}")
                thinking_started = False
            self._print_block_header("TOOL USE")
            tool_use_started = True

        if hasattr(content_block, "name"):
            self._safe_print(f" {content_block.name}", self.colors["system"], flush=True)
        if hasattr(content_block, "input"):
            self._safe_print(f" with input: {content_block.input}", self.colors["system"], flush=True)
        print()

        return thinking_started, tool_use_started, True

    def _handle_stream_events(self, stream, role):
        """Process all stream events and return message object."""
        color = self.colors.get(role, self.colors["reset"])
        state = {"thinking": False, "tool_use": False, "streamed": False}

        for event in stream:
            if not hasattr(event, "type"):
                continue

            if event.type == "thinking" and hasattr(event, "thinking"):
                if not state["thinking"]:
                    self._print_block_header("THINKING")
                    state["thinking"] = True
                self._safe_print(event.thinking, self.colors["system"], flush=True)
                state["streamed"] = True

            elif event.type == "content_block_start" and hasattr(event, "content_block"):
                cb = event.content_block
                if hasattr(cb, "type"):
                    if cb.type in ("tool_use", "server_tool_use"):
                        state["thinking"], state["tool_use"], state["streamed"] = \
                            self._handle_tool_block(cb, state["thinking"], state["tool_use"])
                    elif cb.type == "web_search_tool_result":
                        if not state["tool_use"]:
                            if state["thinking"]:
                                print(f"\n{self.colors['reset']}")
                                state["thinking"] = False
                            self._print_block_header("TOOL RESULT")
                            state["tool_use"] = True
                        if hasattr(cb, "content"):
                            if hasattr(cb.content, "__len__"):
                                print(f" - {len(cb.content)} results", end="", flush=True)
                            else:
                                print(" - error", end="", flush=True)
                        print(f"\n{self.colors['reset']}", end="", flush=True)
                        state["streamed"] = True

            elif event.type == "content_block_delta" and hasattr(event, "delta") and hasattr(event.delta, "text"):
                if state["thinking"]:
                    print(f"\n{self.colors['reset']}")
                    state["thinking"] = False
                elif state["tool_use"]:
                    print(f"\n{self.colors['reset']}")
                    state["tool_use"] = False
                self._safe_print(event.delta.text, color, flush=True)
                state["streamed"] = True

        if state["streamed"]:
            print()

        return stream.get_final_message(), state["streamed"]

    def _format_log_message(self, role, content, timestamp):
        """Format a message for the log file."""
        if role == "assistant" and hasattr(content, "__iter__") and not isinstance(content, str):
            formatted_content = ""
            for block in content:
                if hasattr(block, "type"):
                    if block.type == "thinking":
                        formatted_content += f"**Thinking:**\n```\n{block.thinking}\n```\n\n"
                    elif block.type == "text":
                        formatted_content += f"{block.text}\n"
            return f"## Assistant ({timestamp})\n\n{formatted_content}\n"
        elif role == "user":
            return f"## User ({timestamp})\n\n{content}\n"
        elif role == "assistant":
            return f"## Assistant ({timestamp})\n\n{content}\n"
        else:
            return f"## {role.capitalize()} ({timestamp})\n\n{content}\n"

    def _get_display_content(self, role, content):
        """Return content for printing/logging, optionally truncating long user messages."""
        if (
            role == "user"
            and self.hide_long_user_messages
            and isinstance(content, str)
            and len(content) > self.max_logged_user_chars
        ):
            truncated = content[:self.max_logged_user_chars]
            return (
                f"{truncated}\n\n"
                f"[... truncated {len(content) - self.max_logged_user_chars} more chars, "
                f"{len(content)} total]"
            )
        return content

    def _get_timestamp(self):
        """Get current timestamp in a readable format."""
        from datetime import datetime

        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _get_cached_history(self):
        """Get conversation history with cache_control on last user message."""
        if not self.history:
            return []

        result = []
        for i, turn in enumerate(self.history):
            if i == len(self.history) - 1 and turn["role"] == "user":
                # Add cache_control to last user message
                if isinstance(turn["content"], str):
                    result.append({
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": turn["content"],
                                "cache_control": {"type": "ephemeral"}
                            }
                        ]
                    })
                else:
                    result.append(turn)
            else:
                result.append(turn)

        return result

    def send(self, message, model=None, stream=True, **kwargs):
        """Send a message and handle the full conversation loop with tool use.

        Args:
            message: User message (str or list for tool results)
            model: Model to use (defaults to instance model)
            stream: Whether to stream the response
            **kwargs: Additional parameters (thinking, thinking_budget, etc.)

        Returns:
            Final assistant message object
        """

        self.add_message("user", message)
        model = model or self.model
        thinking = kwargs.get("thinking", True)
        thinking_budget = kwargs.get("thinking_budget", 10000)
        thinking_config = {"budget_tokens": thinking_budget} if thinking else None
        stream_response = prompt(
            system=self.system,
            conversation=self._get_cached_history(),
            tools=self.tools_declaration,
            model=model,
            stream=stream,
            thinking=thinking_config,
        )

        while True:
            message_obj = self.add_message("assistant", stream_response)

            if message_obj.stop_reason != "tool_use":
                break

            # Show tool use information
            print(f"{self.colors['system']}[TOOL USE]{self.colors['reset']}")
            tool_calls = []

            if not message_obj.content:
                raise ValueError("Message has stop_reason='tool_use' but content is empty")

            if not hasattr(message_obj.content, "__iter__") or isinstance(message_obj.content, str):
                raise ValueError(f"Message has stop_reason='tool_use' but content is not iterable: {type(message_obj.content)}")

            for block in message_obj.content:
                if hasattr(block, "type") and block.type in ("tool_use", "server_tool_use"):
                    if not hasattr(block, "name"):
                        continue
                    if block.name not in self.tools:
                        print(f"{self.colors['system']}Warning: Tool '{block.name}' not found in available tools{self.colors['reset']}")
                        continue
                    tool_def = self.tools[block.name]
                    if "function" not in tool_def:
                        print(f"{self.colors['system']}Skipping built-in tool '{block.name}' (handled by API){self.colors['reset']}")
                        continue
                    print(f"{self.colors['system']}Using tool: {block.name}{self.colors['reset']}")
                    tool_calls.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": str(tool_def["function"](**block.input)),
                        }
                    )

            if not tool_calls:
                content_types = [getattr(block, "type", "unknown") for block in message_obj.content] if message_obj.content else []
                print(f"{self.colors['system']}Warning: stop_reason='tool_use' but no executable tool calls found.{self.colors['reset']}")
                print(f"{self.colors['system']}Content blocks: {content_types}. Treating as normal completion.{self.colors['reset']}")
                break

            # Display tool results
            print(f"\n{self.colors['system']}[TOOL RESULT]{self.colors['reset']}")
            for tool_call in tool_calls:
                content = tool_call["content"]
                max_length = 500
                if len(content) > max_length:
                    content = content[:max_length] + f"... [truncated, {len(tool_call['content'])} total chars]"
                self._safe_print(content, self.colors['system'])
                print()

            self.add_message("user", tool_calls, print_message=False)
            stream_response = prompt(
                conversation=self._get_cached_history(), tools=self.tools_declaration, model=model, stream=stream, thinking=thinking_config
            )

        return message_obj

    def answer_with_tags(self, message, required_tags, max_attempts=3, additional_error_message="", allow_none=False, **kwargs):
        """Send a message and extract required XML tags with retry logic.

        Args:
            message: User message to send
            required_tags: Tag name (str) or list of tag names to extract
            max_attempts: Maximum number of retry attempts
            additional_error_message: Additional context for error messages
            allow_none: If True, requires at least one tag; if False, requires all tags
            **kwargs: Additional parameters passed to send() (model, stream, etc.)

        Returns:
            Extracted tag content (str if single tag, dict if multiple tags)

        Raises:
            ValueError: If tags cannot be extracted after max_attempts
        """
        for attempt in range(1, max_attempts + 1):
            response = self.send(message, **kwargs)
            try:
                text_content = self.extract_text_from_message(response)
                extracted = self.extract_xml_tags(text_content, required_tags, allow_none=allow_none)

                if allow_none:
                    tag_list = required_tags if isinstance(required_tags, list) else [required_tags]
                    if isinstance(extracted, dict) and all(v is None for v in extracted.values()):
                        raise ValueError(f"At least one tag must be provided: {', '.join([f'<{tag}>' for tag in tag_list])}")
                    elif extracted is None:
                        raise ValueError(f"Tag <{required_tags}> must be provided")

                return extracted
            except ValueError as e:
                if attempt == max_attempts:
                    raise ValueError(f"Failed to extract tags after {max_attempts} attempts: {e}")

                tag_list = required_tags if isinstance(required_tags, list) else [required_tags]
                tags_str = ", ".join([f"<{tag}>...</{tag}>" for tag in tag_list])
                requirement = "at least one of these tags" if allow_none else "all required tags"
                error_msg = f"[ERROR] Extraction failed: {e}\n\nYou MUST provide {requirement}:\n{tags_str}"
                if additional_error_message:
                    error_msg += f"\n\n{additional_error_message}"
                message = error_msg


import argparse
from .recognizer import SimpleFaceRecognizer
from .add_faces import add_faces_from_folder
from .recognizer import SimpleFaceRecognizer
from .remove_faces import remove_face_database
import os

def main():
    parser = argparse.ArgumentParser(description="SimpleFace CLI Tool")
    parser.add_argument("image", help="Path to input image")
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.3,
        help="Cosine similarity threshold for recognition (default: 0.5)",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    # Subcommand: add_faces
    subparsers.add_parser("add_faces", help="Add all faces from the current folder to the database")

    # Subcommand: recognize
    parser_rec = subparsers.add_parser("recognize", help="Recognize faces from an image")
    parser_rec.add_argument("image_path", help="Path to image")

    # Subcommand: remove_faces
    subparsers.add_parser("remove_faces", help="Remove the face database file")
    args = parser.parse_args()

    if args.command == "add_faces":
        folder = os.getcwd()
        add_faces_from_folder(folder)

    elif args.command == "recognize":
        recognizer = SimpleFaceRecognizer()
        recognizer.recognize_file(args.image_path)

    elif args.command == "remove_faces":
        remove_face_database()
if __name__ == "__main__":
    main()

# facial_recognition
<b>facial_recognition</b> aims to be the most effective face recognition for library for python that you can install with a single command
```
pip install facial_recognition
```
After that you need to download and setup the model file used for recognition by running the following command (Even if you dont do this now the model file will be downloaded the first time you run this library)

```
facial_recognition-setup
```

# Adding Known faces to the database
Just copy a preferably high definition front camera facing and face clearly visible single photo of each person you want recognized to a folder and rename it with the name of that person. Afte you have copied and renamed all known faces in this manner.Run the following command from inside the folder (open the folder and then right click shell/terminal)

```
facial_recognition add_faces
```
Then inorder to recognise the faces in a image lets say sample.jpg, Copy the file to the tests folder and 
Just run

```
facial_recognition recognize test.jpg
```

To remove all stored known faces and start again

```
facial_recognition remove_faces
```

**Please note in case of any bugs that this library will be updated frequently**

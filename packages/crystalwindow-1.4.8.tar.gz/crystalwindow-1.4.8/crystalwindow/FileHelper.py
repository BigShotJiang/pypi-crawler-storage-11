import os
import json
import pickle
import tkinter as tk
from tkinter import filedialog


class FileHelper:
    """CrystalWindow integrated file helper with default folders & Tk dialogs."""

    def __init__(self, default_save_folder="saves"):
        # auto-make folder if not found
        self.default_save_folder = default_save_folder
        os.makedirs(self.default_save_folder, exist_ok=True)

    # ---- TK FILE DIALOGS ----
    def ask_save_file(self, default_name="save.json",
                      filetypes=[("JSON files", "*.json"), ("All files", "*.*")]):
        """Open a Tkinter Save dialog inside default folder."""
        root = tk.Tk()
        root.withdraw()
        path = filedialog.asksaveasfilename(
            initialdir=self.default_save_folder,
            initialfile=default_name,
            filetypes=filetypes,
            defaultextension=filetypes[0][1]
        )
        root.destroy()
        return path

    def ask_open_file(self,
                      filetypes=[("JSON files", "*.json"), ("All files", "*.*")]):
        """Open a Tkinter Open dialog inside default folder."""
        root = tk.Tk()
        root.withdraw()
        path = filedialog.askopenfilename(
            initialdir=self.default_save_folder,
            filetypes=filetypes
        )
        root.destroy()
        return path

    # ---- TEXT ----
    def save_text(self, filename, content):
        """Save plain text data to file."""
        path = os.path.join(self.default_save_folder, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return path

    def load_text(self, filename):
        """Load plain text data from file."""
        path = os.path.join(self.default_save_folder, filename)
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        print(f"[WARN] Text file not found: {filename}")
        return None

    # ---- JSON ----
    def save_json(self, filename, data):
        """Save JSON serializable data."""
        path = os.path.join(self.default_save_folder, filename)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
        return path

    def load_json(self, filename):
        """Load JSON file."""
        path = os.path.join(self.default_save_folder, filename)
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        print(f"[WARN] JSON file not found: {filename}")
        return None

    # ---- PICKLE ----
    def save_pickle(self, filename, obj):
        """Save object using pickle (binary)."""
        path = os.path.join(self.default_save_folder, filename)
        with open(path, "wb") as f:
            pickle.dump(obj, f)
        return path

    def load_pickle(self, filename):
        """Load pickle file (binary)."""
        path = os.path.join(self.default_save_folder, filename)
        if os.path.exists(path):
            with open(path, "rb") as f:
                return pickle.load(f)
        print(f"[WARN] Pickle file not found: {filename}")
        return None

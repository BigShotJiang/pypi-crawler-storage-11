from setuptools import setup, find_packages

setup(
    name="crystalwindow",        # this is the name ppl will pip install
    version="1.4.8",                # update when u change stuff
    packages=find_packages(),     # auto-find all ur modules
    install_requires=["pygame>=2.3.0"],  # cuz ur lib uses pygame
    author="CrystalBallyHereXD",
    description="pygame but remade, easy window/player/tile handling",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires='>=3.8',
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)

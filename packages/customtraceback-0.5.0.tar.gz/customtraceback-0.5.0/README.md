# customTraceback

## A quick and easy way to customize your Python tracebacks

```py
import customTraceback

def myTraceback(name, value, tb):
    print(f"🔥 Exception: {name}")
    print(f"💬 {value}")
    print(f"📜 Trace: {tb}")

customTraceback.setTraceBack(myTraceback)

1 / 0
```
### This replaces the division by 0 error with a custom traceback
**This is a basic example this package is a fun package to make cool tracebacks**
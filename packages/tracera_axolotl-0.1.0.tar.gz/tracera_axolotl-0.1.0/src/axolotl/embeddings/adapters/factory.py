"""Factory for creating embedding adapters."""

from collections.abc import Callable
from typing import Protocol, runtime_checkable

from ..domain import BedrockConfig
from ..exceptions import EmbeddingError
from ..ports import EmbeddingsPort


@runtime_checkable
class EmbeddingConfigProtocol(Protocol):
    """Protocol defining the interface that all embedding configs must implement."""

    provider: str
    framework: str
    model_name: str


def register_embedding_adapter(
    provider: str, framework: str
) -> Callable[[type[EmbeddingsPort]], type[EmbeddingsPort]]:
    """Decorator to register an embedding adapter with the factory.

    Args:
        provider: Name of the provider (e.g., "bedrock")
        framework: Name of the framework (e.g., "llamaindex")
    """

    def decorator(adapter_class: type[EmbeddingsPort]) -> type[EmbeddingsPort]:
        adapter_key = f"{provider.lower()}:{framework.lower()}"
        EmbeddingAdapterFactory._ADAPTERS[adapter_key] = adapter_class
        return adapter_class

    return decorator


class EmbeddingAdapterFactory:
    """Factory for creating embedding adapters based on configuration."""

    # Registry of supported provider-framework combinations and their adapter classes
    # Key format: "provider:framework"
    # This is populated automatically by the @register_embedding_adapter decorator
    _ADAPTERS: dict[str, type[EmbeddingsPort]] = {}

    @classmethod
    def create_adapter(cls, config: EmbeddingConfigProtocol) -> EmbeddingsPort:
        """Create an embedding adapter based on the configuration.

        Args:
            config: Configuration for the embedding adapter

        Returns:
            An instance of EmbeddingsPort for the specified provider and framework

        Raises:
            EmbeddingError: If the provider-framework combination is not supported or adapter creation fails
        """
        provider = config.provider.lower()
        framework = config.framework.lower()
        adapter_key = f"{provider}:{framework}"

        if adapter_key not in cls._ADAPTERS:
            supported_combinations = ", ".join(cls._ADAPTERS.keys())
            raise EmbeddingError(
                f"Unsupported provider-framework combination: '{adapter_key}'. "
                f"Supported combinations: {supported_combinations}",
                details={
                    "provider": provider,
                    "framework": framework,
                    "adapter_key": adapter_key,
                    "supported_combinations": list(cls._ADAPTERS.keys()),
                },
            )

        adapter_class = cls._ADAPTERS[adapter_key]

        try:
            # For now, we only have Bedrock-specific logic, but this can be extended
            if provider == "bedrock":
                # Ensure we have the right config type for Bedrock
                if not isinstance(config, BedrockConfig):
                    raise EmbeddingError(
                        f"BedrockConfig required for provider '{provider}', got {type(config).__name__}",
                        details={
                            "provider": provider,
                            "config_type": type(config).__name__,
                        },
                    )
                return adapter_class(config)  # type: ignore[call-arg]
            else:
                # For future providers, add similar type checking
                return adapter_class(config)  # type: ignore[call-arg]

        except EmbeddingError:
            # Re-raise EmbeddingError as-is to preserve original details
            raise
        except Exception as e:
            error_msg = f"Failed to create adapter for {adapter_key}: {str(e)}"
            raise EmbeddingError(
                error_msg,
                details={
                    "provider": provider,
                    "framework": framework,
                    "model_name": config.model_name,
                    "adapter_class": getattr(
                        adapter_class, "__name__", str(adapter_class)
                    ),
                },
            ) from e

    @classmethod
    def get_supported_providers(cls) -> list[str]:
        """Get list of supported embedding providers.

        Returns:
            List of unique provider names
        """
        providers = set()
        for key in cls._ADAPTERS.keys():
            provider, _ = key.split(":", 1)
            providers.add(provider)
        return list(providers)

    @classmethod
    def get_supported_frameworks(cls) -> list[str]:
        """Get list of supported frameworks.

        Returns:
            List of unique framework names
        """
        frameworks = set()
        for key in cls._ADAPTERS.keys():
            _, framework = key.split(":", 1)
            frameworks.add(framework)
        return list(frameworks)

    @classmethod
    def get_supported_combinations(cls) -> list[str]:
        """Get list of supported provider-framework combinations.

        Returns:
            List of supported combinations in format "provider:framework"
        """
        return list(cls._ADAPTERS.keys())

    @classmethod
    def register_adapter(
        cls, provider: str, framework: str, adapter_class: type[EmbeddingsPort]
    ) -> None:
        """Register a new adapter for a provider-framework combination.

        Args:
            provider: Name of the provider
            framework: Name of the framework
            adapter_class: Adapter class that implements EmbeddingsPort

        Raises:
            EmbeddingError: If the adapter class doesn't implement EmbeddingsPort
        """
        if not issubclass(adapter_class, EmbeddingsPort):
            raise EmbeddingError(
                "Adapter class must implement EmbeddingsPort interface",
                details={
                    "provider": provider,
                    "framework": framework,
                    "adapter_class": adapter_class.__name__,
                },
            )

        adapter_key = f"{provider.lower()}:{framework.lower()}"
        cls._ADAPTERS[adapter_key] = adapter_class

    @classmethod
    def is_provider_supported(cls, provider: str) -> bool:
        """Check if a provider is supported.

        Args:
            provider: Name of the provider to check

        Returns:
            True if provider is supported, False otherwise
        """
        return provider.lower() in cls.get_supported_providers()

    @classmethod
    def is_combination_supported(cls, provider: str, framework: str) -> bool:
        """Check if a provider-framework combination is supported.

        Args:
            provider: Name of the provider to check
            framework: Name of the framework to check

        Returns:
            True if combination is supported, False otherwise
        """
        adapter_key = f"{provider.lower()}:{framework.lower()}"
        return adapter_key in cls._ADAPTERS

    @classmethod
    def get_supported_models(
        cls, provider: str, framework: str = "llamaindex"
    ) -> list[str]:
        """Get list of supported models for a specific provider-framework combination.

        Args:
            provider: Name of the provider
            framework: Name of the framework (defaults to "llamaindex")

        Returns:
            List of supported model names for the provider-framework combination

        Raises:
            EmbeddingError: If provider-framework combination is not supported or models cannot be retrieved
        """
        provider = provider.lower()
        framework = framework.lower()
        adapter_key = f"{provider}:{framework}"

        if adapter_key not in cls._ADAPTERS:
            supported_combinations = ", ".join(cls._ADAPTERS.keys())
            raise EmbeddingError(
                f"Unsupported provider-framework combination: '{adapter_key}'. "
                f"Supported combinations: {supported_combinations}",
                details={
                    "provider": provider,
                    "framework": framework,
                    "adapter_key": adapter_key,
                    "supported_combinations": list(cls._ADAPTERS.keys()),
                },
            )

        try:
            adapter_class = cls._ADAPTERS[adapter_key]

            # Check if the adapter class has a get_supported_models method
            if hasattr(adapter_class, "get_supported_models"):
                return adapter_class.get_supported_models()
            else:
                raise EmbeddingError(
                    f"Model listing not implemented for combination: '{adapter_key}'",
                    details={"provider": provider, "framework": framework},
                )
        except Exception as e:
            error_msg = f"Failed to get supported models for {adapter_key}: {str(e)}"
            raise EmbeddingError(
                error_msg, details={"provider": provider, "framework": framework}
            ) from e


# Module-level discovery - happens once when the module is imported
def _discover_adapters() -> None:
    """Discover and register all adapters by importing adapter modules."""
    # Import all adapter modules to trigger registration
    from . import llamaindex  # noqa: F401
    # Add more adapter modules here as they are created


# Run discovery immediately when this module is imported
_discover_adapters()

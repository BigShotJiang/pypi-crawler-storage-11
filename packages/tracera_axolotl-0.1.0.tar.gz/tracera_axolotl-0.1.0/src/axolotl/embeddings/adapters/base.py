"""Base adapter for embedding implementations."""

import logging
from abc import ABC, abstractmethod
from typing import Any, Optional

from ..exceptions import EmbeddingError
from ..ports import EmbeddingsPort


class BaseEmbeddingAdapter(EmbeddingsPort, ABC):
    """Base class for all embedding adapters with common functionality."""

    def __init__(self, model_name: str, **kwargs: Any) -> None:
        """Initialize the base adapter.

        Args:
            model_name: Name of the embedding model
            **kwargs: Additional configuration parameters
        """
        self.model_name = model_name
        self.logger = logging.getLogger(self.__class__.__name__)
        self._dimension: Optional[int] = None

    def embed_text(self, text: str) -> list[float]:
        """Convert text to vector embedding with error handling.

        Args:
            text: Text to convert to embedding

        Returns:
            Vector embedding as list of floats

        Raises:
            EmbeddingError: If embedding generation fails
        """
        if not text or not text.strip():
            raise EmbeddingError("Text cannot be empty or whitespace only")

        try:
            self.logger.debug(f"Generating embedding for text of length {len(text)}")
            result = self._embed_single_text(text)
            self.logger.debug(
                f"Successfully generated embedding with dimension {len(result)}"
            )
            return result
        except Exception as e:
            error_msg = f"Failed to generate embedding for text: {str(e)}"
            self.logger.error(error_msg)
            raise EmbeddingError(
                error_msg, details={"model": self.model_name, "text_length": len(text)}
            ) from e

    def embed_texts(self, texts: list[str]) -> list[list[float]]:
        """Convert multiple texts to vector embeddings with error handling.

        Args:
            texts: List of texts to convert to embeddings

        Returns:
            List of vector embeddings

        Raises:
            EmbeddingError: If embedding generation fails
        """
        if not texts:
            raise EmbeddingError("Texts list cannot be empty")

        # Validate all texts
        for i, text in enumerate(texts):
            if not text or not text.strip():
                raise EmbeddingError(
                    f"Text at index {i} cannot be empty or whitespace only"
                )

        try:
            self.logger.debug(f"Generating embeddings for {len(texts)} texts")
            results = self._embed_multiple_texts(texts)
            self.logger.debug(f"Successfully generated {len(results)} embeddings")

            if results and len({len(result) for result in results}) > 1:
                raise EmbeddingError(
                    "Inconsistent embedding dimensions in batch results"
                )

            return results
        except Exception as e:
            error_msg = (
                f"Failed to generate embeddings for {len(texts)} texts: {str(e)}"
            )
            self.logger.error(error_msg)
            raise EmbeddingError(
                error_msg, details={"model": self.model_name, "batch_size": len(texts)}
            ) from e

    @property
    def dimension(self) -> int:
        """Get the dimension of the embeddings with caching.

        Returns:
            Number of dimensions in the embedding vectors

        Raises:
            EmbeddingError: If dimension cannot be determined
        """
        if self._dimension is None:
            try:
                self._dimension = self._get_dimension()
                self.logger.debug(f"Cached embedding dimension: {self._dimension}")
            except Exception as e:
                error_msg = f"Failed to get embedding dimension: {str(e)}"
                self.logger.error(error_msg)
                raise EmbeddingError(
                    error_msg, details={"model": self.model_name}
                ) from e

        return self._dimension

    @abstractmethod
    def _embed_single_text(self, text: str) -> list[float]:
        """Implementation-specific method for embedding single text.

        Args:
            text: Text to embed

        Returns:
            Vector embedding as list of floats
        """
        pass

    @abstractmethod
    def _embed_multiple_texts(self, texts: list[str]) -> list[list[float]]:
        """Implementation-specific method for embedding multiple texts.

        Args:
            texts: List of texts to embed

        Returns:
            List of vector embeddings
        """
        pass

    @abstractmethod
    def _get_dimension(self) -> int:
        """Implementation-specific method for getting embedding dimension.

        Returns:
            Number of dimensions in the embedding vectors
        """
        pass

"""Adapters for different embedding providers."""

from .base import BaseEmbeddingAdapter
from .factory import EmbeddingAdapterFactory
from .llamaindex import (
    LlamaindexBedrockEmbeddingAdapter,
)

__all__ = [
    "BaseEmbeddingAdapter",
    "EmbeddingAdapterFactory",
    "LlamaindexBedrockEmbeddingAdapter",
]

"""LlamaIndex-based embedding adapters."""

from .bedrock import LlamaindexBedrockEmbeddingAdapter

__all__ = [
    "LlamaindexBedrockEmbeddingAdapter",
]

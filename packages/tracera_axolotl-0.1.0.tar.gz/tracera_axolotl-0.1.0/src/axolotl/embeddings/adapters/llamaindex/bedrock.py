"""AWS Bedrock embedding adapter using LlamaIndex."""

import logging
from typing import Any

from llama_index.embeddings.bedrock import BedrockEmbedding

from ...domain import BedrockConfig
from ...exceptions import EmbeddingError
from ..base import BaseEmbeddingAdapter
from ..factory import register_embedding_adapter


@register_embedding_adapter("bedrock", "llamaindex")
class LlamaindexBedrockEmbeddingAdapter(BaseEmbeddingAdapter):
    """AWS Bedrock embedding adapter using LlamaIndex framework."""

    def __init__(self, config: BedrockConfig) -> None:
        """Initialize the Bedrock embedding adapter.

        Args:
            config: Bedrock configuration settings

        Raises:
            EmbeddingError: If adapter initialization fails
        """
        super().__init__(config.model_name)
        self.config = config
        self.logger = logging.getLogger(self.__class__.__name__)

        try:
            # Build kwargs for BedrockEmbedding
            bedrock_kwargs: dict[str, Any] = {
                "model_name": config.model_name,
                "region_name": config.region,
            }

            # Add optional AWS credentials if provided
            if config.access_key_id:
                bedrock_kwargs["aws_access_key_id"] = config.access_key_id
            if config.secret_access_key:
                bedrock_kwargs["aws_secret_access_key"] = config.secret_access_key
            if config.session_token:
                bedrock_kwargs["aws_session_token"] = config.session_token
            if config.profile_name:
                bedrock_kwargs["profile_name"] = config.profile_name

            # Add any additional kwargs
            bedrock_kwargs.update(config.additional_kwargs)

            self.logger.debug(
                f"Initializing BedrockEmbedding with model: {config.model_name}, region: {config.region}"
            )
            self._embedding_model = BedrockEmbedding(**bedrock_kwargs)

            # Optionally validate model name now that we have credentials and BedrockEmbedding instance
            try:
                self._validate_model_name()
            except Exception as e:
                self.logger.debug(
                    f"Could not validate model during initialization: {str(e)}"
                )

            self.logger.info(
                f"Successfully initialized Bedrock embedding adapter for model: {config.model_name}"
            )

        except Exception as e:
            error_msg = f"Failed to initialize Bedrock embedding adapter: {str(e)}"
            self.logger.error(error_msg)
            raise EmbeddingError(
                error_msg,
                details={
                    "model_name": config.model_name,
                    "region": config.region,
                    "provider": "bedrock",
                },
            ) from e

    def _embed_single_text(self, text: str) -> list[float]:
        """Embed a single text using Bedrock.

        Args:
            text: Text to embed

        Returns:
            Vector embedding as list of floats
        """
        try:
            # LlamaIndex BedrockEmbedding.get_text_embedding returns List[float]
            embedding: list[float] = self._embedding_model.get_text_embedding(text)
            return embedding
        except Exception as e:
            error_msg = f"Bedrock embedding failed for single text: {str(e)}"
            self.logger.error(error_msg)
            raise EmbeddingError(
                error_msg,
                details={
                    "model_name": self.config.model_name,
                    "text_length": len(text),
                    "provider": "bedrock",
                },
            ) from e

    def _embed_multiple_texts(self, texts: list[str]) -> list[list[float]]:
        """Embed multiple texts using Bedrock.

        Args:
            texts: List of texts to embed

        Returns:
            List of vector embeddings
        """
        try:
            # LlamaIndex BedrockEmbedding.get_text_embedding_batch returns List[List[float]]
            embeddings: list[list[float]] = (
                self._embedding_model.get_text_embedding_batch(texts)
            )
            return embeddings
        except Exception as e:
            error_msg = (
                f"Bedrock batch embedding failed for {len(texts)} texts: {str(e)}"
            )
            self.logger.error(error_msg)
            raise EmbeddingError(
                error_msg,
                details={
                    "model_name": self.config.model_name,
                    "batch_size": len(texts),
                    "provider": "bedrock",
                },
            ) from e

    def _get_dimension(self) -> int:
        """Get the dimension of Bedrock embeddings.

        Returns:
            Number of dimensions in the embedding vectors
        """
        try:
            # Get dimension by embedding a test string
            test_embedding = self._embed_single_text("test")
            dimension = len(test_embedding)

            self.logger.debug(
                f"Bedrock model {self.config.model_name} has dimension: {dimension}"
            )
            return dimension

        except Exception as e:
            error_msg = f"Failed to determine Bedrock embedding dimension: {str(e)}"
            self.logger.error(error_msg)
            raise EmbeddingError(
                error_msg,
                details={"model_name": self.config.model_name, "provider": "bedrock"},
            ) from e

    def _validate_model_name(self) -> bool:
        """Validate that the configured model is supported by Bedrock.

        Returns:
            True if model is supported or validation cannot be performed
        """
        try:
            supported_models = self.get_supported_models()

            all_model_names = []
            for _, models in supported_models.items():
                all_model_names.extend(models)

            if self.config.model_name not in all_model_names:
                self.logger.warning(
                    f"Model '{self.config.model_name}' is not in LlamaIndex's supported Bedrock models list. "
                    f"Supported models: {', '.join(all_model_names)}"
                )
                return False

            self.logger.debug(
                f"Model '{self.config.model_name}' is supported by Bedrock"
            )
            return True

        except Exception as e:
            # If we can't get the supported models list, log and return True (assume valid)
            self.logger.debug(f"Could not validate Bedrock model list: {str(e)}")
            return True

    @classmethod
    def get_supported_models(cls) -> dict[str, list[str]]:
        """Get list of supported Bedrock embedding models.

        Note: This method requires AWS credentials to be configured.

        Returns:
            List of supported model names

        Raises:
            Exception: If AWS authentication fails or Bedrock is not accessible
        """
        try:
            return BedrockEmbedding.list_supported_models()
        except Exception as e:
            raise Exception(
                f"Failed to retrieve Bedrock models. This usually indicates AWS authentication issues. "
                f"Ensure AWS credentials are configured. Original error: {str(e)}"
            ) from e

    def __repr__(self) -> str:
        """String representation of the adapter."""
        return f"LlamaindexBedrockEmbeddingAdapter(model={self.config.model_name}, region={self.config.region})"

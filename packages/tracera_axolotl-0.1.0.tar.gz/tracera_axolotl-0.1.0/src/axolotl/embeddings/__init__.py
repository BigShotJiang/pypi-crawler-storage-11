"""Embeddings module for text-to-vector conversion operations."""

from .adapters import (
    EmbeddingAdapterFactory,
    LlamaindexBedrockEmbeddingAdapter,
)
from .domain import BedrockConfig
from .exceptions import EmbeddingError
from .ports import EmbeddingsPort

__all__ = [
    "EmbeddingsPort",
    "EmbeddingError",
    "EmbeddingAdapterFactory",
    "LlamaindexBedrockEmbeddingAdapter",
    "BedrockConfig",
]

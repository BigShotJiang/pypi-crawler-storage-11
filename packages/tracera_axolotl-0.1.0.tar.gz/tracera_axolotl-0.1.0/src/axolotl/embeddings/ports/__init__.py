"""Ports (abstract interfaces) for embeddings operations."""

from .embeddings import EmbeddingsPort

__all__ = [
    "EmbeddingsPort",
]

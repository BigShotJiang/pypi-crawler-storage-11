"""Embeddings port interface."""

from abc import ABC, abstractmethod


class EmbeddingsPort(ABC):
    """Abstract interface for text-to-vector embedding operations."""

    @abstractmethod
    def embed_text(self, text: str) -> list[float]:
        """Convert text to vector embedding.

        Args:
            text: Text to convert to embedding

        Returns:
            Vector embedding as list of floats
        """
        pass

    @abstractmethod
    def embed_texts(self, texts: list[str]) -> list[list[float]]:
        """Convert multiple texts to vector embeddings.

        Args:
            texts: list of texts to convert to embeddings

        Returns:
            list of vector embeddings
        """
        pass

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Get the dimension of the embeddings.

        Returns:
            Number of dimensions in the embedding vectors
        """
        pass

"""Configuration models for embedding adapters."""

import os
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class BedrockConfig(BaseModel):
    """Configuration for AWS Bedrock embedding models.

    Supports loading from environment variables:
    - AWS_REGION or AWS_DEFAULT_REGION
    - AWS_ACCESS_KEY_ID
    - AWS_SECRET_ACCESS_KEY
    - AWS_SESSION_TOKEN
    - AWS_PROFILE
    """

    provider: str = Field(default="bedrock", description="The embedding provider")
    framework: str = Field(default="llamaindex", description="The framework to use")
    model_name: str = Field(..., description="The name of the embedding model")

    # AWS Bedrock specific fields with environment variable fallbacks
    region: str = Field(
        default_factory=lambda: os.getenv("AWS_REGION")
        or os.getenv("AWS_DEFAULT_REGION")
        or "us-east-1",
        description="AWS region for Bedrock service",
    )
    access_key_id: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_ACCESS_KEY_ID"),
        description="AWS access key ID (optional if using IAM roles)",
    )
    secret_access_key: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_SECRET_ACCESS_KEY"),
        description="AWS secret access key (optional if using IAM roles)",
    )
    session_token: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_SESSION_TOKEN"),
        description="AWS session token (optional)",
    )
    profile_name: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_PROFILE"),
        description="AWS profile name (optional)",
    )
    additional_kwargs: dict[str, Any] = Field(
        default_factory=dict, description="Additional keyword arguments for the model"
    )

    model_config = ConfigDict(extra="forbid")

    @field_validator(
        "access_key_id",
        "secret_access_key",
        "session_token",
        "profile_name",
        mode="before",
    )
    @classmethod
    def empty_str_to_none(cls, v: Optional[str]) -> Optional[str]:
        """Convert empty strings to None for optional AWS credential fields."""
        return None if v == "" else v

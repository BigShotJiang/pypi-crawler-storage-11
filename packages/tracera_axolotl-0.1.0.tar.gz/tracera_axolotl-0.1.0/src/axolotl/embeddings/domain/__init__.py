"""Domain models for embeddings operations."""

from .config import BedrockConfig

__all__ = [
    "BedrockConfig",
]

# Embeddings Module

A modular, extensible text-to-vector embedding system with initial AWS Bedrock support and designed for easy expansion to other embedding providers.

## Overview

This module provides a unified interface for text-to-vector embedding operations across different providers and frameworks. It follows the ports and adapters pattern to ensure clean separation of concerns and easy extensibility.

### Key Features

- **Unified Interface**: Common API across all embedding providers
- **Extensible Architecture**: Easy to add new embedding providers
- **Configuration-Driven**: Simple configuration-based adapter creation
- **Type Safety**: Full type hints and Pydantic models
- **Error Handling**: Comprehensive error handling with detailed context
- **Framework Agnostic**: Supports multiple underlying frameworks (LlamaIndex, etc.)

### Supported Providers

- ✅ **AWS Bedrock** (via LlamaIndex, provider: "bedrock")

## Quick Start

```python
from axolotl.embeddings import (
    EmbeddingAdapterFactory,
    BedrockConfig,
    EmbeddingsPort
)

# Configure Bedrock
config = BedrockConfig(
    model_name="amazon.titan-embed-text-v1",
    region="us-east-1"
)

# Create adapter
embeddings = EmbeddingAdapterFactory.create_adapter(config)

# Generate embeddings
text = "Hello, world!"
vector = embeddings.embed_text(text)
print(f"Embedding dimension: {embeddings.dimension}")
```

## Architecture

### Domain Layer (`domain/`)

Pure data models and business logic:

- **BedrockConfig**: AWS Bedrock-specific configuration
- **Future**: OpenAIConfig, CohereConfig, etc.

### Ports Layer (`ports/`)

Abstract interfaces defining contracts:

- **EmbeddingsPort**: Text-to-vector operations (embed_text, embed_texts, dimension)

### Adapters Layer (`adapters/`)

Concrete implementations for specific providers:

- **BaseEmbeddingAdapter**: Common functionality and error handling
- **LlamaindexBedrockEmbeddingAdapter**: Bedrock implementation via LlamaIndex
- **EmbeddingAdapterFactory**: Configuration-driven adapter creation

### Examples Layer (`examples/`)

Usage examples and demonstrations:

- **bedrock_usage.py**: Comprehensive Bedrock examples
- **list_models.py**: List available Bedrock models
- **environment_config_example.py**: Configuration examples
- **future_configs_example.py**: Extensibility demonstration

## Configuration

### AWS Bedrock Configuration

```python
from axolotl.embeddings import BedrockConfig

config = BedrockConfig(
    # Model settings
    model_name="amazon.titan-embed-text-v1",

    # AWS settings
    region="us-east-1",
    access_key_id="your-key",
    secret_access_key="your-secret", # pragma: allowlist secret

    # Optional settings
    profile_name="default",
    additional_kwargs={}
)
```

### Environment Variables

```bash
# AWS Configuration
export AWS_REGION="us-east-1"
export AWS_ACCESS_KEY_ID="your-key"
export AWS_SECRET_ACCESS_KEY="your-secret" # pragma: allowlist secret
export AWS_PROFILE="default"

# Optional
export AWS_SESSION_TOKEN="your-session-token"
```

## Usage Examples

### Basic Operations

```python
from axolotl.embeddings import EmbeddingAdapterFactory, BedrockConfig

# Create configuration
config = BedrockConfig(
    model_name="amazon.titan-embed-text-v1",
    region="us-east-1"
)

# Create adapter
embeddings = EmbeddingAdapterFactory.create_adapter(config)

# Single text embedding
text = "Machine learning is fascinating"
vector = embeddings.embed_text(text)
print(f"Vector dimension: {len(vector)}")

# Multiple texts embedding
texts = [
    "Artificial intelligence",
    "Machine learning",
    "Deep learning"
]
vectors = embeddings.embed_texts(texts)
print(f"Generated {len(vectors)} embeddings")

# Get embedding dimension
print(f"Embedding dimension: {embeddings.dimension}")
```

### Advanced Usage

```python
# Using with custom AWS profile
config = BedrockConfig(
    model_name="amazon.titan-embed-text-v1",
    region="us-west-2",
    profile_name="production"
)

# Using with additional model parameters
config = BedrockConfig(
    model_name="amazon.titan-embed-text-v1",
    region="us-east-1",
    additional_kwargs={
        "max_tokens": 512,
        "temperature": 0.1
    }
)

embeddings = EmbeddingAdapterFactory.create_adapter(config)
```

## Available Models

### AWS Bedrock Models

The following embedding model is supported via AWS Bedrock:

- **amazon.titan-embed-text-v1**: General-purpose text embeddings (1536 dimensions)

### Model Selection

```python
# Titan v1 (1536 dimensions)
config = BedrockConfig(model_name="amazon.titan-embed-text-v1")
```

### Dimension Considerations

The Titan v1 model produces 1536-dimensional embeddings:

```python
# Check embedding dimension
embeddings = EmbeddingAdapterFactory.create_adapter(config)
print(f"Embedding dimension: {embeddings.dimension}")  # Will be 1536

# Use with vector stores
vector_config = OpenSearchConfig(
    endpoint="http://localhost:9200",
    dimension=embeddings.dimension,  # Will be 1536
    embedding_config={"provider": "bedrock", "framework": "llamaindex"}
)
```

## Performance Considerations

### Batch Processing

For multiple texts, use `embed_texts()` for better performance:

```python
# Efficient batch processing
texts = ["text1", "text2", "text3", "text4"]
vectors = embeddings.embed_texts(texts)  # Single API call

# Less efficient individual processing
vectors = [embeddings.embed_text(text) for text in texts]  # Multiple API calls
```

### Caching

Consider implementing caching for repeated embeddings:

```python
from functools import lru_cache

@lru_cache(maxsize=1000)
def cached_embed_text(text: str) -> tuple:
    """Cache embeddings for repeated texts."""
    vector = embeddings.embed_text(text)
    return tuple(vector)  # Convert to tuple for hashability
```

### Rate Limiting

AWS Bedrock has rate limits. Consider implementing retry logic:

```python
import time
from axolotl.embeddings.exceptions import EmbeddingError

def embed_with_retry(text: str, max_retries: int = 3) -> list[float]:
    """Embed text with retry logic for rate limiting."""
    for attempt in range(max_retries):
        try:
            return embeddings.embed_text(text)
        except EmbeddingError as e:
            if "rate" in str(e).lower() and attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
                continue
            raise
    raise EmbeddingError("Max retries exceeded")
```

## Error Handling

The system provides comprehensive error handling:

```python
from axolotl.embeddings.exceptions import EmbeddingError

try:
    vector = embeddings.embed_text("Hello, world!")
except EmbeddingError as e:
    print(f"Error: {e}")
    print(f"Details: {e.details}")
```

### Exception Hierarchy

- **EmbeddingError**: Base exception for all embedding operations

## Development

### Running Examples

```bash
# Basic Bedrock usage
uv run python -m axolotl.embeddings.examples.bedrock_usage

# List available models
uv run python -m axolotl.embeddings.examples.list_models

# Environment configuration
uv run python -m axolotl.embeddings.examples.environment_config_example

# Future configurations
uv run python -m axolotl.embeddings.examples.future_configs_example
```

### Prerequisites

- AWS Bedrock access (for Bedrock examples)
- Python 3.12+
- Required dependencies (see pyproject.toml)

### Testing

```bash
# Run tests
uv run pytest axolotl/tests/embeddings/

# Run with coverage
uv run pytest axolotl/tests/embeddings/ --cov=axolotl.embeddings
```

## Dependencies

### Core Dependencies

- **pydantic**: Data validation and configuration

### Optional Dependencies

- **llama-index**: LlamaIndex framework (for llamaindex adapters)
- **llama-index-embeddings-bedrock**: Bedrock integration via LlamaIndex

### Development Dependencies

- **pytest**: Testing framework
- **pytest-cov**: Coverage reporting

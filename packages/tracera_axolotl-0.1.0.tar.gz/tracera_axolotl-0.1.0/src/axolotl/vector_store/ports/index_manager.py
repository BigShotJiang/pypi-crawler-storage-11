"""Index manager port interface."""

from abc import ABC, abstractmethod
from typing import Any


class IndexManagerPort(ABC):
    """Abstract interface for index management operations."""

    @abstractmethod
    def create_index(self, index_name: str, **index_config: Any) -> bool:
        """Create a new vector index with store-specific configuration.

        Args:
            index_name: Name of the index to create
            **index_config: Store-specific index configuration parameters

        Returns:
            True if index was created successfully
        """
        pass

    @abstractmethod
    def delete_index(self, index_name: str) -> bool:
        """Delete an existing index.

        Args:
            index_name: Name of the index to delete

        Returns:
            True if index was deleted successfully
        """
        pass

    @abstractmethod
    def index_exists(self, index_name: str) -> bool:
        """Check if an index exists.

        Args:
            index_name: Name of the index to check

        Returns:
            True if index exists
        """
        pass

    @abstractmethod
    def list_indices(self) -> list[str]:
        """list all available indices.

        Returns:
            list of index names
        """
        pass

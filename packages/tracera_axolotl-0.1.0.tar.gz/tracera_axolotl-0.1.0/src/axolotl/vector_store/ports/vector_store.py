"""Vector store port interface."""

from abc import ABC, abstractmethod
from typing import Any

from ..domain import DocumentChunk, ScoredDocumentChunk, TextQuery


class VectorStorePort(ABC):
    """Abstract interface for vector store operations."""

    @abstractmethod
    def add_documents(
        self, documents: list[DocumentChunk], index_name: str
    ) -> list[str]:
        """Add document chunks to the vector store.

        Args:
            documents: list of document chunks to add
            index_name: Name of the index to add documents to

        Returns:
            list of document IDs that were added
        """
        pass

    @abstractmethod
    def search(self, query: TextQuery, index_name: str) -> list[ScoredDocumentChunk]:
        """Perform semantic search using text query.

        Args:
            query: Text query for semantic search (text will be converted to embeddings)
            index_name: Name of the index to search

        Returns:
            list of scored document chunks matching the query
        """
        pass

    @abstractmethod
    def get_document(self, document_id: str, index_name: str) -> dict[str, Any]:
        """Get a document by ID.

        Args:
            document_id: ID of the document to retrieve
            index_name: Name of the index containing the document

        Returns:
            Dictionary containing the document data
        """
        pass

    @abstractmethod
    def delete_documents(self, document_ids: list[str], index_name: str) -> bool:
        """Delete documents from the vector store.

        Args:
            document_ids: list of document IDs to delete
            index_name: Name of the index to delete from

        Returns:
            True if deletion was successful
        """
        pass

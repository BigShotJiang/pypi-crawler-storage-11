"""Domain-specific exceptions for vector store operations."""

from typing import Any, Optional


class VectorStoreError(Exception):
    """Base exception for all vector store operations."""

    def __init__(self, message: str, details: Optional[Any] = None) -> None:
        self.message = message
        self.details = details
        super().__init__(message)

    def __str__(self) -> str:
        if self.details:
            return f"{self.message} (Details: {self.details})"
        return self.message


class DocumentError(VectorStoreError):
    """Exception raised for document-related errors."""

    pass


class IndexError(VectorStoreError):
    """Exception raised for index-related errors."""

    pass


class QueryError(VectorStoreError):
    """Exception raised for query-related errors."""

    pass


class EmbeddingError(VectorStoreError):
    """Exception raised for embedding-related errors."""

    pass


# Specific document errors
class DocumentNotFoundError(DocumentError):
    """Exception raised when a document is not found."""

    def __init__(self, document_id: str, index_name: Optional[str] = None) -> None:
        message = f"Document '{document_id}' not found"
        if index_name:
            message += f" in index '{index_name}'"
        super().__init__(
            message, {"document_id": document_id, "index_name": index_name}
        )


class DocumentValidationError(DocumentError):
    """Exception raised when document validation fails."""

    pass


class DuplicateDocumentError(DocumentError):
    """Exception raised when attempting to create a document that already exists."""

    def __init__(self, document_id: str, index_name: Optional[str] = None) -> None:
        message = f"Document '{document_id}' already exists"
        if index_name:
            message += f" in index '{index_name}'"
        super().__init__(
            message, {"document_id": document_id, "index_name": index_name}
        )


# Specific index errors
class IndexNotFoundError(IndexError):
    """Exception raised when an index is not found."""

    def __init__(self, index_name: str) -> None:
        message = f"Index '{index_name}' not found"
        super().__init__(message, {"index_name": index_name})


class IndexAlreadyExistsError(IndexError):
    """Exception raised when attempting to create an index that already exists."""

    def __init__(self, index_name: str) -> None:
        message = f"Index '{index_name}' already exists"
        super().__init__(message, {"index_name": index_name})


class IndexConfigurationError(IndexError):
    """Exception raised for index configuration errors."""

    pass


# Specific query errors
class InvalidQueryError(QueryError):
    """Exception raised for invalid query parameters."""

    pass


class QueryTimeoutError(QueryError):
    """Exception raised when a query times out."""

    def __init__(
        self, timeout_seconds: float, query_type: Optional[str] = None
    ) -> None:
        message = f"Query timed out after {timeout_seconds} seconds"
        if query_type:
            message = f"{query_type} query timed out after {timeout_seconds} seconds"
        super().__init__(
            message, {"timeout_seconds": timeout_seconds, "query_type": query_type}
        )


class QueryExecutionError(QueryError):
    """Exception raised when query execution fails."""

    pass


# Specific embedding errors
class EmbeddingDimensionMismatchError(EmbeddingError):
    """Exception raised when embedding dimensions don't match expected values."""

    def __init__(self, expected_dim: int, actual_dim: int) -> None:
        message = (
            f"Embedding dimension mismatch: expected {expected_dim}, got {actual_dim}"
        )
        super().__init__(
            message,
            {"expected_dimension": expected_dim, "actual_dimension": actual_dim},
        )


class EmbeddingGenerationError(EmbeddingError):
    """Exception raised when embedding generation fails."""

    pass


class MissingEmbeddingError(EmbeddingError):
    """Exception raised when an embedding is required but missing."""

    def __init__(self, document_id: Optional[str] = None) -> None:
        message = "Document is missing required embedding"
        if document_id:
            message = f"Document '{document_id}' is missing required embedding"
        super().__init__(message, {"document_id": document_id})


# Connection and infrastructure errors
class ConnectionError(VectorStoreError):
    """Exception raised for connection-related errors."""

    pass


class AuthenticationError(VectorStoreError):
    """Exception raised for authentication-related errors."""

    pass


class PermissionError(VectorStoreError):
    """Exception raised for permission-related errors."""

    pass

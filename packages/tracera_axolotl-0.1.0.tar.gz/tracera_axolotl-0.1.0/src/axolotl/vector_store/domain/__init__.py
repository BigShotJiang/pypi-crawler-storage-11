"""Domain models and types for vector store operations.

The domain layer contains pure data models and business logic types.
Store-specific configurations are defined in their respective modules.
"""

from .document import DocumentChunk, ScoredDocumentChunk
from .opensearch_config import OpenSearchConfig, VectorSearchMethod
from .query import TextQuery

__all__ = [
    # Document models
    "DocumentChunk",
    "ScoredDocumentChunk",
    # Query models
    "TextQuery",
    # Configuration models
    "OpenSearchConfig",
    "VectorSearchMethod",
]

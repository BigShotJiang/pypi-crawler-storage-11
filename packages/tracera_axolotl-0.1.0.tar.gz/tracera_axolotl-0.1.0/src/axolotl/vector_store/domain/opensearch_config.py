"""OpenSearch-specific configuration models."""

from typing import Any, Optional

from pydantic import BaseModel, Field, ConfigDict


class VectorSearchMethod(BaseModel):
    """Method for vector search."""

    name: str = Field(default="hnsw", description="Name of the method")
    engine: str = Field(default="faiss", description="Engine of the method")
    space_type: str = Field(default="l2", description="Space type of the method")
    parameters: dict[str, Any] = Field(
        default={
            "m": 48,
            "ef_construction": 256,
        },
        description="Parameters of the method",
    )

    model_config = ConfigDict(extra="allow")


class OpenSearchConfig(BaseModel):
    """Configuration for OpenSearch vector store."""

    provider: str = Field(default="aws", description="Provider name")
    framework: str = Field(default="llamaindex", description="Framework name")

    # Connection settings
    endpoint: str = Field(..., description="OpenSearch endpoint URL")

    # Index settings
    index: Optional[str] = Field(default=None, description="Index name to use")
    text_field: str = Field(
        default="content", description="Field name for storing text content"
    )
    embedding_field: str = Field(
        default="embedding", description="Field name for storing embeddings"
    )

    # Vector settings
    dimension: int = Field(..., ge=1, description="Embedding dimension")
    method: VectorSearchMethod = Field(
        default=VectorSearchMethod(), description="Method for vector search"
    )

    # Connection options
    verify_certs: bool = Field(
        default=True, description="Whether to verify SSL certificates"
    )
    use_ssl: bool = Field(default=True, description="Whether to use SSL")

    # Additional client options
    client_options: dict[str, Any] = Field(
        default_factory=dict, description="Additional OpenSearch client options"
    )

    # Embedding configuration
    embedding_config: dict[str, Any] = Field(
        default={}, description="Configuration for embedding model"
    )

    def __str__(self) -> str:
        # Mask password in client_options if it's in http_auth format
        masked_client_options = self.client_options.copy()
        if "http_auth" in masked_client_options:
            http_auth = masked_client_options["http_auth"]
            if isinstance(http_auth, (list, tuple)) and len(http_auth) == 2:
                # Format: ("username", "password") -> ("username", "***")
                masked_client_options["http_auth"] = (http_auth[0], "***")

        return (
            f"OpenSearch Configuration:\n"
            f"  Provider: {self.provider}\n"
            f"  Framework: {self.framework}\n"
            f"  Endpoint: {self.endpoint}\n"
            f"  Index: {self.index}\n"
            f"  Text Field: {self.text_field}\n"
            f"  Embedding Field: {self.embedding_field}\n"
            f"  VectorSearchMethod: {self.method}\n"
            f"  Dimension: {self.dimension}\n"
            f"  Verify Certs: {self.verify_certs}\n"
            f"  Use SSL: {self.use_ssl}\n"
            f"  Client Options: {masked_client_options}\n"
            f"  Embedding Config: {self.embedding_config}\n"
        )

    def get_index_config(self, **overrides: Any) -> dict[str, Any]:
        """Get OpenSearch index configuration with optional overrides.

        Args:
            **overrides: Override any default configuration values

        Returns:
            Dictionary with OpenSearch index configuration
        """
        config = {
            "dimension": self.dimension,
            "text_field": self.text_field,
            "embedding_field": self.embedding_field,
            "method": self.method,
        }
        config.update(overrides)
        return config

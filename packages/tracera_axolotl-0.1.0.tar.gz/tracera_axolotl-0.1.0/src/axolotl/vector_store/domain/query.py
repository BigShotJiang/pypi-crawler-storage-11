"""Query models for vector store operations."""

import json
from typing import Any, Optional

from pydantic import BaseModel, Field


class TextQuery(BaseModel):
    """Query using text for semantic search (text will be converted to embeddings)."""

    text: str = Field(
        ..., min_length=1, description="The query text for semantic search"
    )
    limit: int = Field(
        default=10, ge=1, le=1000, description="Maximum number of results to return"
    )
    filters: Optional[dict[str, Any]] = Field(
        default=None, description="Metadata filters to apply"
    )
    min_score: Optional[float] = Field(
        default=None, ge=0.0, le=1.0, description="Minimum similarity score threshold"
    )
    include_metadata: bool = Field(
        default=True, description="Whether to include document metadata in results"
    )
    include_content: bool = Field(
        default=True, description="Whether to include document content in results"
    )
    embedding: Optional[list[float]] = Field(
        default=None, description="Embedding vector to use for search"
    )

    def __str__(self) -> str:
        text_preview = self.text[:100] + "..." if len(self.text) > 100 else self.text
        filters_info = (
            f"\n  Filters: {json.dumps(self.filters, indent=2)}"
            if self.filters
            else "\n  Filters: None"
        )
        min_score_info = (
            f"\n  Minimum Score: {self.min_score}"
            if self.min_score is not None
            else "\n  Minimum Score: None"
        )
        return f"Semantic Search Query:\n  Query Text: '{text_preview}'\n  Text Length: {len(self.text)} characters\n  Result Limit: {self.limit}{filters_info}{min_score_info}\n  Include Metadata: {self.include_metadata}\n  Include Content: {self.include_content}"

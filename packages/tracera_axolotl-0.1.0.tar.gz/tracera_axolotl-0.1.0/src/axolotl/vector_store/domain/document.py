"""Document chunk models for vector store operations."""

import json
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field


class DocumentChunk(BaseModel):
    """Core document chunk model for vector store operations."""

    id: str = Field(..., description="The unique identifier of the document chunk")
    content: str = Field(
        ..., min_length=1, description="The textual content of the document chunk"
    )
    normalized_content: Optional[str] = Field(
        None,
        min_length=1,
        description="The normalized textual content of the document chunk",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata associated with the document chunk",
    )
    type: Literal["DocumentChunk"] = Field(
        default="DocumentChunk", description="The type of the document chunk"
    )

    def __str__(self) -> str:
        return f"Document ID: {self.id}\nContent: {self.content}\nMetadata: {json.dumps(self.metadata, indent=2)}\nType: {self.type}"

    def __repr__(self) -> str:
        return f"Document(id={self.id}, content={self.content}, metadata={self.metadata}, type={self.type})"


class ScoredDocumentChunk(BaseModel):
    """A document chunk with an associated relevance score."""

    document_chunk: DocumentChunk = Field(..., description="The document chunk")
    score: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="The relevance score of the document chunk (0.0 to 1.0)",
    )
    type: Literal["ScoredDocumentChunk"] = Field(
        default="ScoredDocumentChunk", description="The type of the document chunk"
    )

    @property
    def document_id(self) -> str:
        """Get the document chunk ID."""
        return self.document_chunk.id

    @property
    def content(self) -> str:
        """Get the document chunk content."""
        return self.document_chunk.content

    @property
    def metadata(self) -> dict[str, Any]:
        """Get the document chunk metadata."""
        return self.document_chunk.metadata

    def __str__(self) -> str:
        return f"Document ID: {self.document_id}\nContent: {self.content}\nMetadata: {json.dumps(self.metadata, indent=2)}\nType: {self.document_chunk.type}\nScore: {self.score}"

    def __repr__(self) -> str:
        return f"ScoredDocument(document={self.document_chunk}, score={self.score})"

"""Factory for creating vector store adapters."""

from collections.abc import Callable
from typing import Protocol, runtime_checkable

from ..exceptions import VectorStoreError
from ..ports import VectorStorePort


@runtime_checkable
class VectorStoreConfigProtocol(Protocol):
    """Protocol defining the interface that all vector store configs must implement."""

    provider: str
    framework: str


def register_vector_store_adapter(
    provider: str, framework: str
) -> Callable[[type[VectorStorePort]], type[VectorStorePort]]:
    """Decorator to register a vector store adapter with the factory.

    Args:
        provider: Name of the provider (e.g., "opensearch", "pinecone", "chroma")
        framework: Name of the framework (e.g., "llamaindex")
    """

    def decorator(adapter_class: type[VectorStorePort]) -> type[VectorStorePort]:
        adapter_key = f"{provider.lower()}:{framework.lower()}"
        VectorStoreAdapterFactory._ADAPTERS[adapter_key] = adapter_class
        return adapter_class

    return decorator


class VectorStoreAdapterFactory:
    """Factory for creating vector store adapters based on configuration."""

    # Registry of supported provider-framework combinations and their adapter classes
    # Key format: "provider:framework"
    # This is populated automatically by the @register_vector_store_adapter decorator
    _ADAPTERS: dict[str, type[VectorStorePort]] = {}

    @classmethod
    def create_adapter(cls, config: VectorStoreConfigProtocol) -> VectorStorePort:
        """Create a vector store adapter based on the configuration.

        Args:
            config: Configuration for the vector store adapter

        Returns:
            An instance of VectorStorePort for the specified provider and framework

        Raises:
            VectorStoreError: If the provider-framework combination is not supported or adapter creation fails
        """
        provider = config.provider.lower()
        framework = config.framework.lower()
        adapter_key = f"{provider}:{framework}"

        if adapter_key not in cls._ADAPTERS:
            supported_combinations = ", ".join(cls._ADAPTERS.keys())
            raise VectorStoreError(
                f"Unsupported provider-framework combination: '{adapter_key}'. "
                f"Supported combinations: {supported_combinations}",
                details={
                    "provider": provider,
                    "framework": framework,
                    "adapter_key": adapter_key,
                    "supported_combinations": list(cls._ADAPTERS.keys()),
                },
            )

        adapter_class = cls._ADAPTERS[adapter_key]

        try:
            return adapter_class(config)  # type: ignore[call-arg]
        except VectorStoreError:
            # Re-raise VectorStoreError as-is to preserve original details
            raise
        except Exception as e:
            error_msg = f"Failed to create adapter for {adapter_key}: {str(e)}"
            raise VectorStoreError(
                error_msg,
                details={
                    "provider": provider,
                    "framework": framework,
                    "adapter_class": getattr(
                        adapter_class, "__name__", str(adapter_class)
                    ),
                },
            ) from e

    @classmethod
    def get_supported_providers(cls) -> list[str]:
        """Get list of supported vector store providers.

        Returns:
            List of unique provider names
        """
        providers = set()
        for key in cls._ADAPTERS.keys():
            provider, _ = key.split(":", 1)
            providers.add(provider)
        return list(providers)

    @classmethod
    def get_supported_frameworks(cls) -> list[str]:
        """Get list of supported frameworks.

        Returns:
            List of unique framework names
        """
        frameworks = set()
        for key in cls._ADAPTERS.keys():
            _, framework = key.split(":", 1)
            frameworks.add(framework)
        return list(frameworks)

    @classmethod
    def get_supported_combinations(cls) -> list[str]:
        """Get list of supported provider-framework combinations.

        Returns:
            List of supported combinations in format "provider:framework"
        """
        return list(cls._ADAPTERS.keys())

    @classmethod
    def register_adapter(
        cls, provider: str, framework: str, adapter_class: type[VectorStorePort]
    ) -> None:
        """Register a new adapter for a provider-framework combination.

        Args:
            provider: Name of the provider
            framework: Name of the framework
            adapter_class: Adapter class that implements VectorStorePort

        Raises:
            VectorStoreError: If the adapter class doesn't implement VectorStorePort
        """
        if not issubclass(adapter_class, VectorStorePort):
            raise VectorStoreError(
                "Adapter class must implement VectorStorePort interface",
                details={
                    "provider": provider,
                    "framework": framework,
                    "adapter_class": adapter_class.__name__,
                },
            )

        adapter_key = f"{provider.lower()}:{framework.lower()}"
        cls._ADAPTERS[adapter_key] = adapter_class

    @classmethod
    def is_provider_supported(cls, provider: str) -> bool:
        """Check if a provider is supported.

        Args:
            provider: Name of the provider to check

        Returns:
            True if provider is supported, False otherwise
        """
        return provider.lower() in cls.get_supported_providers()

    @classmethod
    def is_combination_supported(cls, provider: str, framework: str) -> bool:
        """Check if a provider-framework combination is supported.

        Args:
            provider: Name of the provider to check
            framework: Name of the framework to check

        Returns:
            True if combination is supported, False otherwise
        """
        adapter_key = f"{provider.lower()}:{framework.lower()}"
        return adapter_key in cls._ADAPTERS


# Module-level discovery - happens once when the module is imported
def _discover_adapters() -> None:
    """Discover and register all adapters by importing adapter modules."""
    # Import all adapter modules to trigger registration
    from . import llamaindex  # noqa: F401
    # Add more adapter modules here as they are created


# Run discovery immediately when this module is imported
_discover_adapters()

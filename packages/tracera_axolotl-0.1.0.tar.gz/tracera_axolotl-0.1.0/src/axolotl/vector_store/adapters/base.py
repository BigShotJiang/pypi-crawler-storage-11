"""Base adapter for vector store implementations."""

import logging
from abc import ABC, abstractmethod
from typing import Any

from ..domain import DocumentChunk, ScoredDocumentChunk, TextQuery
from ..exceptions import VectorStoreError
from ..ports import IndexManagerPort, VectorStorePort


class BaseVectorStoreAdapter(VectorStorePort, IndexManagerPort, ABC):
    """Base class for all vector store adapters with common functionality."""

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the base adapter.

        Args:
            **kwargs: Additional configuration parameters
        """
        self.logger = logging.getLogger(self.__class__.__name__)
        self._client: Any = None

    def add_documents(
        self, documents: list[DocumentChunk], index_name: str
    ) -> list[str]:
        """Add document chunks to the vector store with error handling.

        Args:
            documents: List of document chunks to add
            index_name: Name of the index to add documents to

        Returns:
            List of document IDs that were added

        Raises:
            VectorStoreError: If document addition fails
        """
        if not documents:
            raise VectorStoreError("Documents list cannot be empty")

        if not index_name or not index_name.strip():
            raise VectorStoreError("Index name cannot be empty or whitespace only")

        # Validate all documents
        for i, doc in enumerate(documents):
            if not doc.content or not doc.content.strip():
                raise VectorStoreError(
                    f"Document at index {i} cannot have empty content"
                )

        try:
            self.logger.debug(
                f"Adding {len(documents)} documents to index '{index_name}'"
            )
            result = self._add_documents_impl(documents, index_name)
            self.logger.debug(f"Successfully added {len(result)} documents")
            return result
        except Exception as e:
            error_msg = f"Failed to add documents to index '{index_name}': {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(
                error_msg,
                details={"index_name": index_name, "document_count": len(documents)},
            ) from e

    def search(self, query: TextQuery, index_name: str) -> list[ScoredDocumentChunk]:
        """Perform semantic search with error handling.

        Args:
            query: Text query for semantic search
            index_name: Name of the index to search

        Returns:
            List of scored document chunks matching the query

        Raises:
            VectorStoreError: If search fails
        """
        if not query.text or not query.text.strip():
            raise VectorStoreError("Query text cannot be empty or whitespace only")

        if not index_name or not index_name.strip():
            raise VectorStoreError("Index name cannot be empty or whitespace only")

        try:
            self.logger.debug(
                f"Searching index '{index_name}' with query length {len(query.text)}"
            )
            results = self._search_impl(query, index_name)
            self.logger.debug(f"Search returned {len(results)} results")
            return results
        except Exception as e:
            error_msg = f"Failed to search index '{index_name}': {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(
                error_msg,
                details={
                    "index_name": index_name,
                    "query_text_length": len(query.text),
                    "query_limit": query.limit,
                },
            ) from e

    def get_document(self, document_id: str, index_name: str) -> dict[str, Any]:
        """Get a document by ID with error handling.

        Args:
            document_id: ID of the document to retrieve
            index_name: Name of the index containing the document

        Returns:
            The document chunk

        Raises:
            VectorStoreError: If document retrieval fails
        """
        if not document_id or not document_id.strip():
            raise VectorStoreError("Document ID cannot be empty or whitespace only")

        if not index_name or not index_name.strip():
            raise VectorStoreError("Index name cannot be empty or whitespace only")

        try:
            self.logger.debug(
                f"Retrieving document '{document_id}' from index '{index_name}'"
            )
            result = self._get_document_impl(document_id, index_name)
            self.logger.debug(f"Successfully retrieved document '{document_id}'")
            return result
        except Exception as e:
            error_msg = f"Failed to get document '{document_id}' from index '{index_name}': {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(
                error_msg,
                details={"document_id": document_id, "index_name": index_name},
            ) from e

    def delete_documents(self, document_ids: list[str], index_name: str) -> bool:
        """Delete documents with error handling.

        Args:
            document_ids: List of document IDs to delete
            index_name: Name of the index to delete from

        Returns:
            True if deletion was successful

        Raises:
            VectorStoreError: If document deletion fails
        """
        if not document_ids:
            raise VectorStoreError("Document IDs list cannot be empty")

        if not index_name or not index_name.strip():
            raise VectorStoreError("Index name cannot be empty or whitespace only")

        # Validate all document IDs
        for i, doc_id in enumerate(document_ids):
            if not doc_id or not doc_id.strip():
                raise VectorStoreError(
                    f"Document ID at index {i} cannot be empty or whitespace only"
                )

        try:
            self.logger.debug(
                f"Deleting {len(document_ids)} documents from index '{index_name}'"
            )
            result = self._delete_documents_impl(document_ids, index_name)
            self.logger.debug(
                f"Successfully deleted documents from index '{index_name}'"
            )
            return result
        except Exception as e:
            error_msg = (
                f"Failed to delete documents from index '{index_name}': {str(e)}"
            )
            self.logger.error(error_msg)
            raise VectorStoreError(
                error_msg,
                details={"index_name": index_name, "document_count": len(document_ids)},
            ) from e

    def create_index(self, index_name: str, **index_config: Any) -> bool:
        """Create a new vector index with store-specific configuration.

        Args:
            index_name: Name of the index to create
            **index_config: Store-specific index configuration parameters

        Returns:
            True if index was created successfully

        Raises:
            VectorStoreError: If index creation fails
        """
        if not index_name or not index_name.strip():
            raise VectorStoreError("Index name cannot be empty or whitespace only")

        try:
            self.logger.debug(f"Creating index '{index_name}'")
            result = self._create_index_impl(index_name, **index_config)
            self.logger.debug(f"Successfully created index '{index_name}'")
            return result
        except Exception as e:
            error_msg = f"Failed to create index '{index_name}': {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(
                error_msg,
                details={
                    "index_name": index_name,
                    "config_keys": list(index_config.keys()),
                },
            ) from e

    def delete_index(self, index_name: str) -> bool:
        """Delete an existing index with error handling.

        Args:
            index_name: Name of the index to delete

        Returns:
            True if index was deleted successfully

        Raises:
            VectorStoreError: If index deletion fails
        """
        if not index_name or not index_name.strip():
            raise VectorStoreError("Index name cannot be empty or whitespace only")

        try:
            self.logger.debug(f"Deleting index '{index_name}'")
            result = self._delete_index_impl(index_name)
            self.logger.debug(f"Successfully deleted index '{index_name}'")
            return result
        except Exception as e:
            error_msg = f"Failed to delete index '{index_name}': {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(error_msg, details={"index_name": index_name}) from e

    def index_exists(self, index_name: str) -> bool:
        """Check if an index exists with error handling.

        Args:
            index_name: Name of the index to check

        Returns:
            True if index exists

        Raises:
            VectorStoreError: If index existence check fails
        """
        if not index_name or not index_name.strip():
            raise VectorStoreError("Index name cannot be empty or whitespace only")

        try:
            self.logger.debug(f"Checking if index '{index_name}' exists")
            result = self._index_exists_impl(index_name)
            self.logger.debug(f"Index '{index_name}' exists: {result}")
            return result
        except Exception as e:
            error_msg = f"Failed to check if index '{index_name}' exists: {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(error_msg, details={"index_name": index_name}) from e

    def list_indices(self) -> list[str]:
        """List all available indices with error handling.

        Returns:
            List of index names

        Raises:
            VectorStoreError: If listing indices fails
        """
        try:
            self.logger.debug("Listing all indices")
            results = self._list_indices_impl()
            self.logger.debug(f"Found {len(results)} indices")
            return results
        except Exception as e:
            error_msg = f"Failed to list indices: {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(error_msg) from e

    @property
    def client(self) -> Any:
        """Get the underlying client for advanced operations.

        Returns:
            The underlying vector store client
        """
        return self._client

    # Abstract methods for implementation-specific logic

    @abstractmethod
    def _add_documents_impl(
        self, documents: list[DocumentChunk], index_name: str
    ) -> list[str]:
        """Implementation-specific method for adding documents.

        Args:
            documents: List of document chunks to add
            index_name: Name of the index to add documents to

        Returns:
            List of document IDs that were added
        """
        pass

    @abstractmethod
    def _search_impl(
        self, query: TextQuery, index_name: str
    ) -> list[ScoredDocumentChunk]:
        """Implementation-specific method for searching.

        Args:
            query: Text query for semantic search
            index_name: Name of the index to search

        Returns:
            List of scored document chunks matching the query
        """
        pass

    @abstractmethod
    def _get_document_impl(self, document_id: str, index_name: str) -> dict[str, Any]:
        """Implementation-specific method for getting a document by ID.

        Args:
            document_id: ID of the document to retrieve
            index_name: Name of the index containing the document

        Returns:
            Dictionary containing the document data
        """
        pass

    @abstractmethod
    def _delete_documents_impl(self, document_ids: list[str], index_name: str) -> bool:
        """Implementation-specific method for deleting documents.

        Args:
            document_ids: List of document IDs to delete
            index_name: Name of the index to delete from

        Returns:
            True if deletion was successful
        """
        pass

    @abstractmethod
    def _create_index_impl(self, index_name: str, **index_config: Any) -> bool:
        """Implementation-specific method for creating an index.

        Args:
            index_name: Name of the index to create
            **index_config: Store-specific index configuration parameters

        Returns:
            True if index was created successfully
        """
        pass

    @abstractmethod
    def _delete_index_impl(self, index_name: str) -> bool:
        """Implementation-specific method for deleting an index.

        Args:
            index_name: Name of the index to delete

        Returns:
            True if index was deleted successfully
        """
        pass

    @abstractmethod
    def _index_exists_impl(self, index_name: str) -> bool:
        """Implementation-specific method for checking if an index exists.

        Args:
            index_name: Name of the index to check

        Returns:
            True if index exists
        """
        pass

    @abstractmethod
    def _list_indices_impl(self) -> list[str]:
        """Implementation-specific method for listing indices.

        Returns:
            List of index names
        """
        pass

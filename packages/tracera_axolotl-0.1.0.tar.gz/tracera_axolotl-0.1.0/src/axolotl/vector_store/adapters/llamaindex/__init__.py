"""LlamaIndex-based vector store adapters."""

from .opensearch import LlamaIndexOpenSearchAdapter

__all__ = [
    "LlamaIndexOpenSearchAdapter",
]

"""OpenSearch adapter using LlamaIndex."""

from typing import Any

from llama_index.core.schema import Document
from llama_index.core.vector_stores.types import VectorStoreQuery, VectorStoreQueryMode
from llama_index.vector_stores.opensearch import (
    OpensearchVectorClient,
    OpensearchVectorStore,
)
from llama_index.core.vector_stores import (
    MetadataFilter,
    MetadataFilters,
    FilterOperator,
)

from ....embeddings import EmbeddingAdapterFactory
from ...domain import DocumentChunk, OpenSearchConfig, ScoredDocumentChunk, TextQuery
from ...exceptions import VectorStoreError
from ..base import BaseVectorStoreAdapter
from ..factory import register_vector_store_adapter

import logging

logger = logging.getLogger(__name__)


@register_vector_store_adapter("aws", "llamaindex")
class LlamaIndexOpenSearchAdapter(BaseVectorStoreAdapter):
    """OpenSearch vector store adapter using LlamaIndex."""

    def __init__(self, config: OpenSearchConfig) -> None:
        """Initialize the OpenSearch adapter.

        Args:
            config: OpenSearch configuration

        Raises:
            VectorStoreError: If initialization fails
        """
        super().__init__()
        self.config = config

        try:
            # Create OpenSearch vector client
            self._client = OpensearchVectorClient(
                endpoint=config.endpoint,
                index=config.index,
                dim=config.dimension,
                embedding_field=config.embedding_field,
                text_field=config.text_field,
                method=config.method.model_dump(),
                verify_certs=config.verify_certs,
                use_ssl=config.use_ssl,
                **config.client_options,
            )

            # Create the vector store
            self._vector_store = OpensearchVectorStore(self._client)
            self.logger.info(
                f"Initialized OpenSearch adapter for endpoint: {config.endpoint}"
            )

            # Initialize embedding service if configuration is provided
            if not config.embedding_config:
                raise VectorStoreError(
                    "Embedding configuration is required",
                    details={
                        "endpoint": config.endpoint,
                        "dimension": config.dimension,
                        "index": config.index,
                    },
                )

            self._initialize_embedding_service(config.embedding_config)

        except Exception as e:
            error_msg = f"Failed to initialize OpenSearch adapter: {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(
                error_msg,
                details={
                    "endpoint": config.endpoint,
                    "dimension": config.dimension,
                    "index": config.index,
                },
            ) from e

    def _initialize_embedding_service(self, embedding_config: dict[str, Any]) -> None:
        """Initialize the embedding service from configuration.

        Args:
            embedding_config: Configuration dictionary for embedding service

        Raises:
            VectorStoreError: If embedding service initialization fails
        """
        try:
            # Convert dictionary to proper config object based on provider
            provider = embedding_config.get("provider", "").lower()
            _framework = embedding_config.get("framework", "llamaindex").lower()

            if provider == "bedrock":
                from ....embeddings import BedrockConfig

                config_obj = BedrockConfig(**embedding_config)
            else:
                raise VectorStoreError(
                    f"Unsupported embedding provider: {provider}",
                    details={
                        "provider": provider,
                        "supported": ["bedrock"],
                    },
                )

            # Create embedding adapter from configuration
            self._embedding_service = EmbeddingAdapterFactory.create_adapter(config_obj)

            self.logger.info(
                f"Initialized embedding service: {self._embedding_service}"
            )

        except Exception as e:
            error_msg = f"Failed to initialize embedding service: {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(error_msg) from e

    def _add_documents_impl(
        self, documents: list[DocumentChunk], index_name: str
    ) -> list[str]:
        """Add documents to OpenSearch index.

        Args:
            documents: List of document chunks to add
            index_name: Name of the index to add documents to

        Returns:
            List of document IDs that were added
        """

        # Convert DocumentChunk objects to LlamaIndex Document objects
        nodes = []

        # Use real embedding service
        if self._embedding_service is None:
            raise VectorStoreError(
                "Embedding service not initialized",
                details={"operation": "add_documents"},
            )

        texts = [
            doc.normalized_content
            if doc.normalized_content is not None
            else doc.content
            for doc in documents
        ]
        embeddings = self._embedding_service.embed_texts(texts)

        for doc, embedding in zip(documents, embeddings, strict=False):
            node = Document(
                doc_id=doc.id,
                text=doc.content,
                metadata=doc.metadata,
                embedding=embedding,
            )
            nodes.append(node)

        # Add nodes to the vector store
        self._vector_store.add(nodes)

        return [doc.id for doc in documents]

    def _search_impl(
        self, query: TextQuery, index_name: str
    ) -> list[ScoredDocumentChunk]:
        """Search for similar documents.

        Args:
            query: Text query for semantic search
            index_name: Name of the index to search

        Returns:
            List of scored document chunks matching the query
        """

        # Generate query embedding
        if self._embedding_service is None:
            raise VectorStoreError(
                "Embedding service not initialized", details={"operation": "query"}
            )

        query_embedding = (
            query.embedding
            if query.embedding is not None
            else self._embedding_service.embed_text(query.text)
        )

        # Convert filters to LlamaIndex MetadataFilters format
        filters = None
        if query.filters:
            metadata_filters = []
            for key, value in query.filters.items():
                metadata_filters.append(
                    MetadataFilter(key=key, value=value, operator=FilterOperator.EQ)
                )
            filters = MetadataFilters(filters=metadata_filters)

        # Create vector store query
        vector_query = VectorStoreQuery(
            query_str=query.text,
            query_embedding=query_embedding,
            similarity_top_k=query.limit,
            mode=VectorStoreQueryMode.DEFAULT,
            filters=filters,
        )

        # Perform the search
        result = self._vector_store.query(vector_query)

        # Convert results to ScoredDocumentChunk objects
        scored_docs = []
        for i, node in enumerate(result.nodes or []):
            # Apply minimum score filter if specified
            if (
                query.min_score is not None
                and query.min_score > 0.0
                and result.similarities[i] < query.min_score
            ):
                continue

            # Get the score (similarity) - higher scores mean more similar
            score = (
                result.similarities[i]
                if result.similarities and i < len(result.similarities)
                else 0.0
            )

            # Convert back to DocumentChunk
            doc_chunk = DocumentChunk(
                id=node.node_id,
                content=node.get_content()
                if hasattr(node, "get_content")
                else node.text,
                metadata=node.metadata or {},
            )

            # Create scored document
            scored_doc = ScoredDocumentChunk(
                document_chunk=doc_chunk, score=float(score)
            )
            scored_docs.append(scored_doc)

        # Sort by score (highest first)
        scored_docs.sort(key=lambda x: x.score, reverse=True)
        logger.info(f"Length of scored docs: {len(scored_docs)}")

        return scored_docs

    def _get_document_impl(self, document_id: str, index_name: str) -> dict[str, Any]:
        """Get a document by ID.

        Args:
            document_id: ID of the document to retrieve
            index_name: Name of the index containing the document

        Returns:
            Dictionary containing the document data

        Raises:
            VectorStoreError: If document is not found
        """

        try:
            response = self._client._os_client.get(index=index_name, id=document_id)
            if not response.get("found", False):
                raise VectorStoreError(
                    f"Document '{document_id}' not found in index '{index_name}'"
                )
            return response
        except Exception as e:
            if "not found" in str(e).lower():
                raise VectorStoreError(
                    f"Document '{document_id}' not found in index '{index_name}'"
                ) from e
            raise VectorStoreError(
                f"Error getting document '{document_id}' from index '{index_name}': {str(e)}"
            ) from e

    def _delete_documents_impl(self, document_ids: list[str], index_name: str) -> bool:
        """Delete documents from the index.

        Args:
            document_ids: List of document IDs to delete
            index_name: Name of the index to delete from

        Returns:
            True if deletion was successful
        """

        # Delete documents using the vector store
        self._vector_store.delete_nodes(node_ids=document_ids)

        return True

    def _create_index_impl(self, index_name: str, **index_config: Any) -> bool:
        """Create a new OpenSearch index.

        Note:
            The index is automatically created by the LlamaIndex OpenSearch client during initialization.
            No action is required here.

        Args:
            index_name: Name of the index to create
            **index_config: OpenSearch-specific configuration parameters

        Returns:
            True (index is assumed to be created automatically)
        """

        # Check if index exists
        if not self._index_exists_impl(index_name):
            raise VectorStoreError(f"Index '{index_name}' does not exist")

        self.logger.info(
            f"Index '{index_name}' is automatically created by the LlamaIndex OpenSearch client; no action taken."
        )
        return True

    def _delete_index_impl(self, index_name: str) -> bool:
        """Delete an existing index.

        Args:
            index_name: Name of the index to delete

        Returns:
            True if index was deleted successfully
        """
        try:
            # Use the underlying OpenSearch client to delete the index
            self._client._os_client.indices.delete(index=index_name)
            self.logger.info(f"Deleted index '{index_name}'")
            return True

        except Exception as e:
            error_msg = f"Failed to delete index '{index_name}': {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(error_msg) from e

    def _index_exists_impl(self, index_name: str) -> bool:
        """Check if an index exists.

        Args:
            index_name: Name of the index to check

        Returns:
            True if index exists
        """
        try:
            # Use the underlying OpenSearch client to check if index exists
            return self._client._os_client.indices.exists(index=index_name)
        except Exception as e:
            error_msg = f"Failed to check if index '{index_name}' exists: {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(error_msg) from e

    def _list_indices_impl(self) -> list[str]:
        """List all available indices.

        Returns:
            List of index names
        """
        try:
            # Use the underlying OpenSearch client to list indices
            response = self._client._os_client.indices.get_alias(index="*")
            return list(response.keys())
        except Exception as e:
            error_msg = f"Failed to list indices: {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(error_msg) from e

    def clear_index(self, index_name: str) -> bool:
        """Clear all documents from an index.

        Args:
            index_name: Name of the index to clear

        Returns:
            True if clearing was successful
        """
        try:
            # Clear the vector store
            self._vector_store.clear()

            self.logger.info(f"Cleared index '{index_name}'")
            return True

        except Exception as e:
            error_msg = f"Failed to clear index '{index_name}': {str(e)}"
            self.logger.error(error_msg)
            raise VectorStoreError(error_msg) from e

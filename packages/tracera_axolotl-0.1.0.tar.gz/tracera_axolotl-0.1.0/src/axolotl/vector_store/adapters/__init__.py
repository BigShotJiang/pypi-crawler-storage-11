"""Vector store adapters package."""

from .base import BaseVectorStoreAdapter
from .factory import (
    VectorStoreAdapterFactory,
    VectorStoreConfigProtocol,
    register_vector_store_adapter,
)

__all__ = [
    "BaseVectorStoreAdapter",
    "VectorStoreAdapterFactory",
    "register_vector_store_adapter",
    "VectorStoreConfigProtocol",
]

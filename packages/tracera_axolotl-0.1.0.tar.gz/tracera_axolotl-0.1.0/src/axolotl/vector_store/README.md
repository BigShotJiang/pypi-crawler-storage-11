# Vector Store Module

A modular, extensible vector store system with initial OpenSearch support and designed for easy expansion to other vector databases.

## Overview

This module provides a unified interface for vector store operations across different backends. It follows the ports and adapters pattern to ensure clean separation of concerns and easy extensibility.

### Key Features

- **Unified Interface**: Common API across all vector store backends
- **Extensible Architecture**: Easy to add new vector store providers
- **Configuration-Driven**: Simple configuration-based adapter creation
- **Type Safety**: Full type hints and Pydantic models
- **Error Handling**: Comprehensive error handling with detailed context
- **Framework Agnostic**: Supports multiple underlying frameworks (LlamaIndex, etc.)

### Supported Backends

- ✅ **OpenSearch** (via LlamaIndex, provider: "aws")

## Quick Start

```python
from axolotl.vector_store import (
    VectorStoreAdapterFactory,
    OpenSearchConfig,
    DocumentChunk,
    TextQuery
)

# Configure OpenSearch
config = OpenSearchConfig(
    endpoint="http://localhost:9200",
    dimension=384,
    index="documents",
    embedding_config={
        "provider": "bedrock",
        "framework": "llamaindex",
        "model_id": "amazon.titan-embed-text-v1"
    }
)

# Create adapter
adapter = VectorStoreAdapterFactory.create_adapter(config)

# Add documents
documents = [
    DocumentChunk(
        id="doc1",
        content="Example document content",
        metadata={"category": "example"}
    )
]
adapter.add_documents(documents, "my_index")

# Search
query = TextQuery(text="example query", limit=5)
results = adapter.search(query, "my_index")
```

## Architecture

### Domain Layer (`domain/`)

Pure data models and business logic:

- **DocumentChunk**: Core document model
- **ScoredDocumentChunk**: Document with relevance score
- **TextQuery**: Search query configuration
- **OpenSearchConfig**: OpenSearch-specific configuration

### Ports Layer (`ports/`)

Abstract interfaces defining contracts:

- **VectorStorePort**: Document operations (add, search, get, delete)
- **IndexManagerPort**: Index management (create, delete, list, exists)

### Adapters Layer (`adapters/`)

Concrete implementations for specific backends:

- **BaseVectorStoreAdapter**: Common functionality and error handling
- **LlamaIndexOpenSearchAdapter**: OpenSearch implementation via LlamaIndex
- **VectorStoreAdapterFactory**: Configuration-driven adapter creation

### Examples Layer (`examples/`)

Usage examples and demonstrations:

- **opensearch_cli.py**: Comprehensive OpenSearch CLI example

## Configuration

### OpenSearch Configuration

**Note**: The `embedding_config` parameter is functionally required - the adapter will raise an error if it's empty or missing.

```python
from axolotl.vector_store import OpenSearchConfig

config = OpenSearchConfig(
    # Connection
    endpoint="http://localhost:9200",
    username="admin",
    password="admin", # pragma: allowlist secret

    # Vector settings
    dimension=384,

    # Index settings
    index="documents",
    text_field="content",
    embedding_field="embedding",

    # Connection options
    verify_certs=True,
    use_ssl=True,

    # Embedding configuration (required)
    embedding_config={
        "provider": "bedrock",
        "framework": "llamaindex",
        "model_id": "amazon.titan-embed-text-v1"
    }
)
```

### Embedding Configuration Options

The `embedding_config` supports different providers:

```python
# AWS Bedrock (recommended)
embedding_config={
    "provider": "bedrock",
    "framework": "llamaindex",
    "model_id": "amazon.titan-embed-text-v1"
}

# Add more providers as they become available
```

### Environment Variables

```bash
# Connection
export OPENSEARCH_ENDPOINT="http://localhost:9200"
export OPENSEARCH_USERNAME="admin"
export OPENSEARCH_PASSWORD="admin" # pragma: allowlist secret

# SSL/TLS
export OPENSEARCH_VERIFY_CERTS="true"
export OPENSEARCH_USE_SSL="true"
```

## Usage Examples

### Basic Operations

```python
# Note: Indexes are automatically created by the OpenSearch client when needed
# No explicit index creation is required

# Add documents
documents = [
    DocumentChunk(
        id="doc1",
        content="Document content here",
        metadata={"category": "tech"}
    )
]
adapter.add_documents(documents, "my_index")

# Search with filters
query = TextQuery(
    text="search query",
    limit=10,
    filters={"category": "tech"},
    min_score=0.7
)
results = adapter.search(query, "my_index")

# Get specific document
doc = adapter.get_document("doc1", "my_index")

# Delete documents
adapter.delete_documents(["doc1"], "my_index")

# Index management
indices = adapter.list_indices()
exists = adapter.index_exists("my_index")

adapter.delete_index("my_index")
```

### Advanced Search

```python
# Complex metadata filtering
query = TextQuery(
    text="machine learning",
    limit=20,
    filters={
        "category": "ai",
        "date": {"gte": "2024-01-01"},
        "tags": ["ml", "nlp"]
    },
    min_score=0.8,
    include_metadata=True,
    include_content=True
)

results = adapter.search(query, "research_index")
```

## Index Management

**Important**: The OpenSearch adapter uses automatic index creation. Indexes are created automatically when you first add documents to them. You don't need to explicitly call `create_index()` - it's handled by the underlying LlamaIndex OpenSearch client.

```python
# Indexes are created automatically when needed
adapter.add_documents(documents, "new_index")  # This will create "new_index" if it doesn't exist

# You can still check if an index exists
if adapter.index_exists("my_index"):
    print("Index exists")

# List all indices
indices = adapter.list_indices()

# Delete an index if needed
adapter.delete_index("old_index")
```

## Vector Search Capabilities

### Similarity Search

The vector store supports various similarity search methods:

```python
# Basic similarity search
query = TextQuery(text="machine learning", limit=10)
results = adapter.search(query, "my_index")

# Search with minimum score threshold
query = TextQuery(
    text="artificial intelligence",
    limit=5,
    min_score=0.8  # Only return results with 80%+ similarity
)
results = adapter.search(query, "my_index")
```

### Metadata Filtering

Filter search results using document metadata:

```python
# Simple metadata filtering
query = TextQuery(
    text="python programming",
    filters={"category": "programming", "language": "python"}
)
```

**Note**: The current implementation passes filters as a dictionary directly to LlamaIndex. For more complex filtering requirements, you may need to use LlamaIndex's `MetadataFilters` objects directly.

### Result Processing

Process search results with content and metadata:

```python
# Search with content and metadata inclusion
query = TextQuery(
    text="neural networks",
    include_content=True,
    include_metadata=True
)
results = adapter.search(query, "research_index")

# Process results
for result in results:
    print(f"Score: {result.score}")
    print(f"Content: {result.content}")
    print(f"Metadata: {result.metadata}")
```

## Performance Optimization

### Batch Operations

Process multiple documents efficiently:

```python
# Batch document addition
documents = [
    DocumentChunk(id=f"doc_{i}", content=f"Content {i}")
    for i in range(100)
]
adapter.add_documents(documents, "batch_index")

# Batch document deletion
document_ids = [f"doc_{i}" for i in range(50)]
adapter.delete_documents(document_ids, "batch_index")
```

### Index Management

Optimize index performance:

```python
# Check index status
if adapter.index_exists("my_index"):
    print("Index exists")

# List all indices
indices = adapter.list_indices()
print(f"Available indices: {indices}")

# Clean up unused indices
for index in indices:
    if index.startswith("temp_"):
        adapter.delete_index(index)
```

### Query Optimization

Optimize search performance:

```python
# Use appropriate limit
query = TextQuery(text="search term", limit=20)  # Don't over-fetch

# Use filters to narrow results
query = TextQuery(
    text="search term",
    filters={"category": "specific_category"},  # Pre-filter
    limit=10
)

# Use minimum score for quality
query = TextQuery(
    text="search term",
    min_score=0.7,  # Filter out low-quality matches
    limit=10
)
```

## Integration with Embeddings

### Dynamic Dimension Handling

Automatically handle different embedding dimensions:

```python
from axolotl.embeddings import EmbeddingAdapterFactory, BedrockConfig

# Create embedding service
embedding_config = BedrockConfig(model_name="amazon.titan-embed-text-v1")
embeddings = EmbeddingAdapterFactory.create_adapter(embedding_config)

# Use actual embedding dimension
vector_config = OpenSearchConfig(
    endpoint="http://localhost:9200",
    dimension=embeddings.dimension,  # Dynamic dimension
    embedding_config={"provider": "bedrock", "framework": "llamaindex"}
)
```

### Consistent Embedding Usage

Ensure consistent embeddings across operations:

```python
# Generate embeddings for documents
texts = ["Document 1", "Document 2", "Document 3"]
embeddings_list = embeddings.embed_texts(texts)

# Create documents
documents = [
    DocumentChunk(
        id=f"doc_{i}",
        content=texts[i],
        metadata={"source": "batch_processing"}
    )
    for i in range(len(texts))
]
```

## Error Handling

The system provides comprehensive error handling:

```python
from axolotl.vector_store.exceptions import VectorStoreError

try:
    adapter.add_documents(documents, "my_index")
except VectorStoreError as e:
    print(f"Error: {e}")
    print(f"Details: {e.details}")
```

### Exception Hierarchy

- **VectorStoreError**: Base exception
  - **DocumentError**: Document-related errors
  - **IndexError**: Index-related errors
  - **QueryError**: Query-related errors
  - **EmbeddingError**: Embedding-related errors

## Development

### Running Examples

```bash
# OpenSearch CLI example
uv run python -m axolotl.vector_store.examples.opensearch_cli
```

### Prerequisites

- OpenSearch instance running (for OpenSearch examples)
- Python 3.12+
- Required dependencies (see pyproject.toml)

### Testing

```bash
# Run tests
uv run pytest axolotl/tests/vector_store/

# Run with coverage
uv run pytest axolotl/tests/vector_store/ --cov=axolotl.vector_store
```

## Dependencies

### Core Dependencies

- **pydantic**: Data validation and configuration
- **opensearch-py**: OpenSearch Python client

### Optional Dependencies

- **llama-index**: LlamaIndex framework (for llamaindex adapters)
- **llama-index-vector-stores-opensearch**: OpenSearch integration via LlamaIndex

### Development Dependencies

- **pytest**: Testing framework
- **pytest-cov**: Coverage reporting

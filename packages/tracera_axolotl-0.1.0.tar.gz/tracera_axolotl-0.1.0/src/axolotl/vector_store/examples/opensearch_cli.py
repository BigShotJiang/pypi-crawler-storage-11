import logging
import argparse
import sys
from dotenv import load_dotenv
import os

load_dotenv()

# Set up logging to see what's happening
logging.basicConfig(level=logging.INFO)

from llama_index.vector_stores.opensearch import OpensearchVectorClient
from opensearchpy import RequestsHttpConnection
from axolotl.vector_store.domain import VectorSearchMethod
from axolotl.vector_store import (
    VectorStoreAdapterFactory,
    OpenSearchConfig,
    DocumentChunk,
    TextQuery,
)


def connect_to_opensearch(index_name="default-index"):
    """Connect to OpenSearch."""
    print(f"Index name: {index_name}")

    username = os.getenv("OPENSEARCH_USERNAME")
    password = os.getenv("OPENSEARCH_PASSWORD")

    method = VectorSearchMethod(
        engine="faiss",
        space_type="l2",
        name="hnsw",
        parameters={"ef_construction": 100, "m": 16},
    )

    config = OpenSearchConfig(
        provider="aws",
        framework="llamaindex",
        dimension=1536,
        index=index_name,
        endpoint=os.getenv("OPENSEARCH_ENDPOINT"),
        method=method,
        client_options={
            "http_auth": (username, password),
            "connection_class": RequestsHttpConnection,
        },
        embedding_config={
            "provider": "bedrock",
            "framework": "llamaindex",
            "model_name": "amazon.titan-embed-text-v1",
            "region": "us-east-1",
        },
    )

    print(f"Connecting to OpenSearch")
    adapter = VectorStoreAdapterFactory.create_adapter(config)
    print(f"Connected to OpenSearch")

    return adapter, config


def add_documents_to_opensearch(index_name="default-index"):
    adapter, config = connect_to_opensearch(index_name)

    try:
        # Check if index exists, create if not
        if not adapter.index_exists(config.index):
            print("Index does not exist")
        else:
            print("Index already exists.")

        # Create sample documents
        documents = [
            DocumentChunk(
                id="doc1",
                content="OpenSearch is a distributed search and analytics engine.",
                metadata={"category": "technology", "source": "documentation"},
            ),
            DocumentChunk(
                id="doc2",
                content="Vector databases enable semantic search capabilities.",
                metadata={"category": "technology", "source": "blog"},
            ),
            DocumentChunk(
                id="doc3",
                content="Machine learning models can generate text embeddings.",
                metadata={"category": "ai", "source": "research"},
            ),
            DocumentChunk(
                id="doc4",
                content="LlamaIndex provides tools for building LLM applications. It is a powerful tool for building LLM applications. Best tool for building LLM applications. Pros and cons of LlamaIndex: Pros: It is a powerful tool for building LLM applications. Cons: It is bloated and slow. How to use LlamaIndex: 1. Install LlamaIndex: pip install llama-index 2. Import LlamaIndex: from llama_index import LlamaIndex 3. Use LlamaIndex: LlamaIndex.from_documents(documents).",
                metadata={"category": "ai", "source": "research"},
            ),
        ]

        # Add documents to the index
        print(f"\nAdding {len(documents)} documents...")
        doc_ids = adapter.add_documents(documents, config.index)
        print(f"Added documents with IDs: {doc_ids}")
    except Exception as e:
        print(f"Error adding documents to OpenSearch: {e}")


def clear_index_from_opensearch(index_name="default-index"):
    adapter, config = connect_to_opensearch(index_name)
    adapter.clear_index(config.index)
    print("Index cleared from OpenSearch")


def search_in_opensearch(index_name="default-index"):
    adapter, config = connect_to_opensearch(index_name)

    from llama_index.core.vector_stores import ExactMatchFilter, MetadataFilters

    filters = MetadataFilters(
        filters=[
            ExactMatchFilter(key="category", value="ai"),
        ]
    )

    query = TextQuery(
        text="machine learning",
        limit=5,
        min_score=0.1,
        filters=filters,
    )
    results = adapter.search(query, config.index)
    print(f"Search results: {results}")


def get_document_from_opensearch(index_name="default-index"):
    adapter, config = connect_to_opensearch(index_name)
    document = adapter.get_document("doc1", config.index)
    print(f"Document: \n{document}")


def delete_document_from_opensearch(index_name="default-index"):
    adapter, config = connect_to_opensearch(index_name)
    adapter.delete_documents(["doc1"], config.index)
    print("Document deleted from OpenSearch")


def list_indices_from_opensearch():
    adapter, config = connect_to_opensearch()
    indices = adapter.list_indices()
    print(f"Indices: \n{indices}")


def search_with_params(
    query_text, limit, min_score, category, index_name="default-index"
):
    """Search with custom parameters."""
    adapter, config = connect_to_opensearch(index_name)

    from llama_index.core.vector_stores import ExactMatchFilter, MetadataFilters

    filters = None
    if category:
        filters = MetadataFilters(
            filters=[ExactMatchFilter(key="category", value=category)]
        )

    query = TextQuery(
        text=query_text,
        limit=limit,
        min_score=min_score,
        filters=filters,
    )
    results = adapter.search(query, config.index)
    print(f"Search results: {results}")


def get_document_by_id(doc_id, index_name="default-index"):
    """Get document by ID."""
    adapter, config = connect_to_opensearch(index_name)
    document = adapter.get_document(doc_id, config.index)
    print(f"Document: \n{document}")


def delete_document_by_id(doc_id, index_name="default-index"):
    """Delete document by ID."""
    adapter, config = connect_to_opensearch(index_name)
    adapter.delete_documents([doc_id], config.index)
    print(f"Document '{doc_id}' deleted from OpenSearch")


def create_parser():
    """Create the command line argument parser."""
    parser = argparse.ArgumentParser(
        description="OpenSearch Vector Store CLI Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Test connection
  python opensearch_cli.py connect

  # Test connection with custom index
  python opensearch_cli.py connect --index my-custom-index

  # List all indices
  python opensearch_cli.py list-indices

  # Add sample documents
  python opensearch_cli.py add-docs

  # Add documents to custom index
  python opensearch_cli.py add-docs --index my-custom-index

  # Search documents
  python opensearch_cli.py search --query "machine learning" --limit 5

  # Search in custom index
  python opensearch_cli.py search --index my-custom-index --query "vector databases" --limit 3

  # Get specific document
  python opensearch_cli.py get-doc --doc-id doc1

  # Delete specific document
  python opensearch_cli.py delete-doc --doc-id doc1

  # Clear entire index
  python opensearch_cli.py clear-index

  # Run full workflow (add docs, search, get doc, cleanup)
  python opensearch_cli.py workflow

  # Run workflow with custom index
  python opensearch_cli.py workflow --index my-custom-index
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Connect command
    connect_parser = subparsers.add_parser(
        "connect", help="Test connection to OpenSearch"
    )
    connect_parser.add_argument(
        "--index",
        "-i",
        default="default-index",
        help="Index name (default: default-index)",
    )

    # List indices command
    subparsers.add_parser("list-indices", help="List all indices in OpenSearch")

    # Add documents command
    add_docs_parser = subparsers.add_parser(
        "add-docs", help="Add sample documents to the index"
    )
    add_docs_parser.add_argument(
        "--index",
        "-i",
        default="default-index",
        help="Index name (default: default-index)",
    )

    # Search command
    search_parser = subparsers.add_parser("search", help="Search documents")
    search_parser.add_argument(
        "--index",
        "-i",
        default="default-index",
        help="Index name (default: default-index)",
    )
    search_parser.add_argument(
        "--query",
        "-q",
        default="machine learning",
        help='Search query text (default: "machine learning")',
    )
    search_parser.add_argument(
        "--limit",
        "-l",
        type=int,
        default=5,
        help="Maximum number of results (default: 5)",
    )
    search_parser.add_argument(
        "--min-score",
        type=float,
        default=0.1,
        help="Minimum score threshold (default: 0.1)",
    )
    search_parser.add_argument(
        "--category", help='Filter by category (e.g., "ai", "technology")'
    )

    # Get document command
    get_doc_parser = subparsers.add_parser(
        "get-doc", help="Get specific document by ID"
    )
    get_doc_parser.add_argument(
        "--index",
        "-i",
        default="default-index",
        help="Index name (default: default-index)",
    )
    get_doc_parser.add_argument(
        "--doc-id", required=True, help="Document ID to retrieve"
    )

    # Delete document command
    delete_doc_parser = subparsers.add_parser(
        "delete-doc", help="Delete specific document by ID"
    )
    delete_doc_parser.add_argument(
        "--index",
        "-i",
        default="default-index",
        help="Index name (default: default-index)",
    )
    delete_doc_parser.add_argument(
        "--doc-id", required=True, help="Document ID to delete"
    )

    # Clear index command
    clear_parser = subparsers.add_parser(
        "clear-index", help="Clear entire index (WARNING: destructive)"
    )
    clear_parser.add_argument(
        "--index",
        "-i",
        default="default-index",
        help="Index name (default: default-index)",
    )

    # Workflow command
    workflow_parser = subparsers.add_parser(
        "workflow", help="Run full workflow: add docs, search, get doc, cleanup"
    )
    workflow_parser.add_argument(
        "--index",
        "-i",
        default="default-index",
        help="Index name (default: default-index)",
    )

    return parser


def run_workflow(index_name="default-index"):
    """Run the complete workflow: add docs, search, get doc, cleanup."""
    print("=== Running Complete OpenSearch Workflow ===\n")

    try:
        # Step 1: Test connection
        print("1. Testing connection...")
        adapter, config = connect_to_opensearch(index_name)
        print("✓ Connection successful\n")

        # Step 2: Add documents
        print("2. Adding sample documents...")
        add_documents_to_opensearch(index_name)
        print("✓ Documents added successfully\n")

        # Step 3: Search documents
        print("3. Searching documents...")
        search_in_opensearch(index_name)
        print("✓ Search completed successfully\n")

        # Step 4: Get document
        print("4. Retrieving specific document...")
        get_document_from_opensearch(index_name)
        print("✓ Document retrieved successfully\n")

        # Step 5: Cleanup (optional - ask user)
        response = input("Do you want to clear the index? (y/N): ").strip().lower()
        if response in ["y", "yes"]:
            print("5. Clearing index...")
            clear_index_from_opensearch(index_name)
            print("✓ Index cleared successfully")
        else:
            print("5. Skipping cleanup - index preserved")

        print("\n=== Workflow completed successfully ===")

    except Exception as e:
        print(f"❌ Workflow failed: {e}")
        sys.exit(1)


def main():
    """Main CLI entry point."""
    parser = create_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    try:
        if args.command == "connect":
            print("Testing connection to OpenSearch...")
            adapter, config = connect_to_opensearch(args.index)
            print("✓ Connection successful")

        elif args.command == "list-indices":
            print("Listing indices from OpenSearch...")
            list_indices_from_opensearch()
            print("✓ Indices listed successfully")

        elif args.command == "add-docs":
            print("Adding documents to OpenSearch...")
            add_documents_to_opensearch(args.index)
            print("✓ Documents added successfully")

        elif args.command == "search":
            print(f"Searching for: '{args.query}' (limit: {args.limit})")
            # Modify search function to accept parameters
            search_with_params(
                args.query, args.limit, args.min_score, args.category, args.index
            )
            print("✓ Search completed successfully")

        elif args.command == "get-doc":
            print(f"Getting document: {args.doc_id}")
            get_document_by_id(args.doc_id, args.index)
            print("✓ Document retrieved successfully")

        elif args.command == "delete-doc":
            print(f"Deleting document: {args.doc_id}")
            delete_document_by_id(args.doc_id, args.index)
            print("✓ Document deleted successfully")

        elif args.command == "clear-index":
            response = (
                input(
                    "⚠️  This will delete ALL documents in the index. Continue? (y/N): "
                )
                .strip()
                .lower()
            )
            if response in ["y", "yes"]:
                print("Clearing index...")
                clear_index_from_opensearch(args.index)
                print("✓ Index cleared successfully")
            else:
                print("Operation cancelled")

        elif args.command == "workflow":
            run_workflow(args.index)

    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

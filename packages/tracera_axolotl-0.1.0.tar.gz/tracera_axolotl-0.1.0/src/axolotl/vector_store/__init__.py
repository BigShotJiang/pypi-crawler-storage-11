"""Vector store package for distributed vector search and retrieval.

This package provides a unified interface for working with different vector store backends,
with initial support for OpenSearch and designed for easy extension to other providers.

Core Components:
- Domain models for documents, queries, and index configuration
- Port interfaces defining the contract for vector store operations
- Adapters implementing the ports for specific vector store backends
- Factory pattern for creating adapters based on configuration

Features:
- Semantic search with vector embeddings
- Document storage and retrieval
- Index management and configuration
- Metadata filtering and hybrid search
- Extensible architecture for multiple backends

Supported Backends:
- OpenSearch (via LlamaIndex)
- Future: Pinecone, Chroma, Weaviate, etc.

Example usage:
    from axolotl.vector_store import (
        VectorStoreAdapterFactory,
        OpenSearchConfig,
        DocumentChunk,
        TextQuery
    )

    # Configure OpenSearch
    config = OpenSearchConfig(
        endpoint="http://localhost:9200",
        dimension=384,
        default_index="documents"
    )

    # Create adapter
    adapter = VectorStoreAdapterFactory.create_adapter(config)

    # Add documents
    documents = [
        DocumentChunk(
            id="doc1",
            content="Example document content",
            metadata={"category": "example"}
        )
    ]
    adapter.add_documents(documents, "my_index")

    # Search
    query = TextQuery(text="example query", limit=5)
    results = adapter.search(query, "my_index")
"""

from .adapters import VectorStoreAdapterFactory, VectorStoreConfigProtocol
from .domain import (
    DocumentChunk,
    OpenSearchConfig,
    ScoredDocumentChunk,
    TextQuery,
)
from .exceptions import VectorStoreError
from .ports import IndexManagerPort, VectorStorePort

__all__ = [
    # Domain models
    "DocumentChunk",
    "ScoredDocumentChunk",
    "TextQuery",
    # Configuration models
    "OpenSearchConfig",
    # Interfaces
    "VectorStorePort",
    "IndexManagerPort",
    "VectorStoreConfigProtocol",
    # Factory and adapter management
    "VectorStoreAdapterFactory",
    # Exceptions
    "VectorStoreError",
]

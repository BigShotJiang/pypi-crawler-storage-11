"""S3 usage examples."""

import os
from axolotl.aws import AWSConfig
from axolotl.aws.s3 import S3Client

from dotenv import load_dotenv

load_dotenv()


def basic_s3_operations():
    """Demonstrate basic S3 operations."""
    print("=== Basic S3 Operations ===")

    # Configure AWS credentials
    config = AWSConfig(region=os.getenv("AWS_DEFAULT_REGION"))

    # Create S3 client
    s3 = S3Client(config)

    bucket_name = os.getenv("S3_BUCKET")

    # FILE OPERATIONS
    print("\n--- File Operations ---")

    s3_upload_object_key_pdf = os.getenv("S3_UPLOAD_OBJECT_KEY") + "test.pdf"
    s3_upload_object_key_json = os.getenv("S3_UPLOAD_OBJECT_KEY") + "test.json"
    s3_upload_object_key_txt = os.getenv("S3_UPLOAD_OBJECT_KEY") + "test.txt"

    # Upload file with auto-detected content type
    try:
        s3.upload_file(
            os.getenv("LOCAL_PDF_FILE"), bucket_name, s3_upload_object_key_pdf
        )
        print("✓ File uploaded successfully")
    except Exception as e:
        print(f"✗ File upload failed: {e}")

    # Upload file with specific content type and additional S3 parameters
    try:
        s3.upload_file(
            os.getenv("LOCAL_JSON_FILE"),
            bucket_name,
            s3_upload_object_key_json,
            "application/json",
            Metadata={"project": "axolotl", "version": "1.0"},
        )
        print("✓ JSON file uploaded successfully with additional parameters")
    except Exception as e:
        print(f"✗ JSON file upload failed: {e}")

    # Download file
    try:
        s3.download_file(bucket_name, s3_upload_object_key_pdf, "downloaded_report.pdf")
        print("✓ File downloaded successfully")
    except Exception as e:
        print(f"✗ File download failed: {e}")

    # OBJECT OPERATIONS
    print("\n--- Object Operations ---")

    # Upload bytes
    try:
        data = b"Hello, S3!"
        s3.put_object(bucket_name, s3_upload_object_key_txt, data, "text/plain")
        print("✓ Bytes uploaded successfully")
    except Exception as e:
        print(f"✗ Bytes upload failed: {e}")

    # Upload text with additional S3 parameters
    try:
        s3.put_object(
            bucket_name,
            s3_upload_object_key_txt,
            "Hello, World!",
            "text/plain",
            StorageClass="STANDARD",
            Metadata={"type": "greeting", "language": "en"},
            CacheControl="max-age=3600",
        )
        print("✓ Text uploaded successfully with additional parameters")
    except Exception as e:
        print(f"✗ Text upload failed: {e}")

    # Download bytes
    try:
        data = s3.get_object(bucket_name, s3_upload_object_key_txt)
        print(f"✓ Downloaded data: {data.decode()}")
    except Exception as e:
        print(f"✗ Bytes download failed: {e}")

    # LISTING OPERATIONS
    print("\n--- Listing Operations ---")

    # List all objects
    try:
        objects = s3.list_objects(bucket_name)
        print(f"✓ Found {len(objects)} objects in bucket")
        for obj in objects[:5]:  # Show first 5
            print(f"  - {obj}")
    except Exception as e:
        print(f"✗ List objects failed: {e}")

    # List objects with additional parameters
    try:
        objects = s3.list_objects(
            bucket_name, prefix="data/", MaxKeys=10, Delimiter="/"
        )
        print(f"✓ Found {len(objects)} objects in data/ folder with delimiter")
        for obj in objects:
            print(f"  - {obj}")
    except Exception as e:
        print(f"✗ List objects with parameters failed: {e}")

    # UTILITY OPERATIONS
    print("\n--- Utility Operations ---")

    # Check if object exists
    try:
        exists = s3.object_exists(bucket_name, s3_upload_object_key_txt)
        print(f"✓ Object 'test.txt' exists: {exists}")
    except Exception as e:
        print(f"✗ Check object existence failed: {e}")

    # Get object metadata
    try:
        metadata = s3.head_object(bucket_name, s3_upload_object_key_txt)
        print(f"✓ Object metadata:")
        print(f"  - Content Type: {metadata.get('ContentType')}")
        print(f"  - Size: {metadata.get('ContentLength')} bytes")
        print(f"  - Last Modified: {metadata.get('LastModified')}")
    except Exception as e:
        print(f"✗ Get metadata failed: {e}")

    # Copy object
    try:
        s3.copy_object(
            bucket_name, s3_upload_object_key_txt, bucket_name, "backup/test.txt"
        )
        print("✓ Object copied successfully")
    except Exception as e:
        print(f"✗ Copy object failed: {e}")

    # Delete object
    try:
        s3.delete_object(bucket_name, s3_upload_object_key_txt)
        print("✓ Object deleted successfully")
    except Exception as e:
        print(f"✗ Delete object failed: {e}")


def advanced_s3_features():
    """Demonstrate advanced S3 features using kwargs."""
    print("\n=== Advanced S3 Features ===")

    config = AWSConfig(region="us-west-2")
    s3 = S3Client(config)

    bucket_name = os.getenv("S3_BUCKET")

    s3_upload_object_key_txt = os.getenv("S3_UPLOAD_OBJECT_KEY") + "test.txt"

    # Upload with server-side encryption
    try:
        s3.put_object(
            bucket_name,
            s3_upload_object_key_txt,
            "Sensitive data",
            "text/plain",
            ServerSideEncryption="AES256",
            Metadata={"encrypted": "true", "sensitivity": "high"},
        )
        print("✓ Encrypted object uploaded successfully")
    except Exception as e:
        print(f"✗ Encrypted upload failed: {e}")

    # Upload with versioning and lifecycle
    try:
        s3.put_object(
            bucket_name,
            s3_upload_object_key_txt,
            "Version 1 data",
            "text/plain",
            StorageClass="STANDARD_IA",
            Metadata={"version": "1", "lifecycle": "archive"},
        )
        print("✓ Versioned object uploaded successfully")
    except Exception as e:
        print(f"✗ Versioned upload failed: {e}")

    # Copy object with metadata replacement
    try:
        s3.copy_object(
            bucket_name,
            s3_upload_object_key_txt,
            bucket_name,
            "backup/encrypted-data.txt",
            MetadataDirective="REPLACE",
            Metadata={"backup": "true", "original": "encrypted-data.txt"},
            ServerSideEncryption="AES256",
        )
        print("✓ Object copied with metadata replacement")
    except Exception as e:
        print(f"✗ Copy with metadata replacement failed: {e}")

    # List objects with pagination
    try:
        objects = s3.list_objects(
            bucket_name, prefix="", MaxKeys=5, StartAfter="backup/"
        )
        print(f"✓ Paginated listing: {len(objects)} objects")
        for obj in objects:
            print(f"  - {obj}")
    except Exception as e:
        print(f"✗ Paginated listing failed: {e}")


def error_handling_example():
    """Demonstrate error handling."""
    print("\n=== Error Handling Example ===")

    config = AWSConfig(region=os.getenv("AWS_DEFAULT_REGION"))
    s3 = S3Client(config)

    # Try to access non-existent bucket
    try:
        s3.list_objects("non-existent-bucket")
    except Exception as e:
        print(f"✓ Caught expected error for non-existent bucket: {type(e).__name__}")

    # Try to access non-existent object
    try:
        s3.get_object("my-test-bucket", "non-existent-key")
    except Exception as e:
        print(f"✓ Caught expected error for non-existent object: {type(e).__name__}")


if __name__ == "__main__":
    # basic_s3_operations()
    advanced_s3_features()
    # error_handling_example()

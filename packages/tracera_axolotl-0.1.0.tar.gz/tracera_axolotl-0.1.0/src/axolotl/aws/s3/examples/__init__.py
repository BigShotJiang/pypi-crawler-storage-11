"""S3 examples module."""

"""S3-specific exceptions."""

from ..exceptions import AWSException


class S3Exception(AWSException):
    """Base exception for S3 operations."""

    pass


class S3ObjectNotFoundError(S3Exception):
    """Raised when S3 object is not found."""

    pass


class S3BucketNotFoundError(S3Exception):
    """Raised when S3 bucket is not found."""

    pass

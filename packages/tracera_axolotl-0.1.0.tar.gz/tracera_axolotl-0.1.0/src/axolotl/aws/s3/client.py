"""S3 client for common operations."""

import mimetypes
from pathlib import Path
from typing import Any, Optional, Union

from botocore.errorfactory import ClientError

from ..config import AWSConfig
from .exceptions import S3Exception, S3ObjectNotFoundError, S3BucketNotFoundError


class S3Client:
    """Simple S3 client for common operations."""

    def __init__(self, config: AWSConfig):
        """Initialize S3 client with AWS configuration.

        Args:
            config: AWS configuration with credentials and region
        """
        self.config = config
        self._client = config.create_client("s3")

    def _detect_content_type(self, file_path: str) -> str:
        """Detect content type for file.

        Args:
            file_path: Path to the file

        Returns:
            MIME type of the file
        """
        mime_type, _ = mimetypes.guess_type(file_path)
        return mime_type or "application/octet-stream"

    def _ensure_directory(self, file_path: str) -> None:
        """Ensure directory exists for file path.

        Args:
            file_path: Path to the file
        """
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)

    # FILE OPERATIONS

    def upload_file(
        self,
        file_path: str,
        bucket: str,
        key: str,
        content_type: Optional[str] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Upload a local file to S3.

        Args:
            file_path: Path to local file
            bucket: S3 bucket name
            key: S3 object key
            content_type: MIME type (auto-detected if not provided)
            **kwargs: Additional S3 parameters (e.g., StorageClass, ServerSideEncryption, Metadata, etc.)

        Returns:
            S3 response metadata

        Raises:
            S3BucketNotFoundError: If bucket doesn't exist
            S3Exception: If upload fails
        """
        try:
            if content_type is None:
                content_type = self._detect_content_type(file_path)

            extra_args = {"ContentType": content_type}
            extra_args.update(kwargs)

            response = self._client.upload_file(
                file_path, bucket, key, ExtraArgs=extra_args
            )
            return response
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "NoSuchBucket":
                raise S3BucketNotFoundError(f"Bucket '{bucket}' not found") from e
            raise S3Exception(f"Failed to upload file: {e}") from e

    def download_file(
        self, bucket: str, key: str, file_path: str, **kwargs: Any
    ) -> dict[str, Any]:
        """Download a file from S3 to local path.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            file_path: Local path to save the file
            **kwargs: Additional S3 parameters (e.g., VersionId, SSECustomerKey, etc.)

        Returns:
            S3 response metadata

        Raises:
            S3BucketNotFoundError: If bucket doesn't exist
            S3ObjectNotFoundError: If object doesn't exist
            S3Exception: If download fails
        """
        try:
            self._ensure_directory(file_path)
            response = self._client.download_file(
                bucket, key, file_path, ExtraArgs=kwargs
            )
            return response
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "NoSuchBucket":
                raise S3BucketNotFoundError(f"Bucket '{bucket}' not found") from e
            elif error_code == "NoSuchKey":
                raise S3ObjectNotFoundError(
                    f"Object '{key}' not found in bucket '{bucket}'"
                ) from e
            raise S3Exception(f"Failed to download file: {e}") from e

    # OBJECT OPERATIONS

    def put_object(
        self,
        bucket: str,
        key: str,
        body: Union[bytes, str],
        content_type: str = "application/octet-stream",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Upload data to S3.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            body: Data to upload (bytes or string)
            content_type: MIME type of the content
            **kwargs: Additional S3 parameters (e.g., StorageClass, ServerSideEncryption, Metadata, etc.)

        Returns:
            S3 response metadata

        Raises:
            S3BucketNotFoundError: If bucket doesn't exist
            S3Exception: If upload fails
        """
        try:
            if isinstance(body, str):
                body = body.encode("utf-8")

            put_kwargs: dict[str, Any] = {
                "Bucket": bucket,
                "Key": key,
                "Body": body,
                "ContentType": content_type,
            }
            put_kwargs.update(kwargs)

            response = self._client.put_object(**put_kwargs)
            return response
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "NoSuchBucket":
                raise S3BucketNotFoundError(f"Bucket '{bucket}' not found") from e
            raise S3Exception(f"Failed to put object: {e}") from e

    def get_object(self, bucket: str, key: str, **kwargs: Any) -> bytes:
        """Download object data from S3.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            **kwargs: Additional S3 parameters (e.g., VersionId, SSECustomerKey, etc.)

        Returns:
            Object data as bytes

        Raises:
            S3BucketNotFoundError: If bucket doesn't exist
            S3ObjectNotFoundError: If object doesn't exist
            S3Exception: If download fails
        """
        try:
            get_kwargs = {"Bucket": bucket, "Key": key}
            get_kwargs.update(kwargs)
            response = self._client.get_object(**get_kwargs)
            return response["Body"].read()
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "NoSuchBucket":
                raise S3BucketNotFoundError(f"Bucket '{bucket}' not found") from e
            elif error_code == "NoSuchKey":
                raise S3ObjectNotFoundError(
                    f"Object '{key}' not found in bucket '{bucket}'"
                ) from e
            raise S3Exception(f"Failed to get object: {e}") from e

    # LISTING OPERATIONS

    def list_objects(self, bucket: str, prefix: str = "", **kwargs: Any) -> list[str]:
        """List objects in S3 bucket.

        Args:
            bucket: S3 bucket name
            prefix: Object key prefix to filter by
            **kwargs: Additional S3 parameters (e.g., MaxKeys, Delimiter, StartAfter, etc.)

        Returns:
            List of object keys

        Raises:
            S3BucketNotFoundError: If bucket doesn't exist
            S3Exception: If listing fails
        """
        try:
            list_kwargs: dict[str, Any] = {"Bucket": bucket, "Prefix": prefix}
            list_kwargs.update(kwargs)
            response = self._client.list_objects_v2(**list_kwargs)
            contents = response.get("Contents", [])
            return [obj["Key"] for obj in contents]
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "NoSuchBucket":
                raise S3BucketNotFoundError(f"Bucket '{bucket}' not found") from e
            raise S3Exception(f"Failed to list objects: {e}") from e

    # UTILITY OPERATIONS

    def object_exists(self, bucket: str, key: str, **kwargs: Any) -> bool:
        """Check if an object exists in S3.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            **kwargs: Additional S3 parameters (e.g., VersionId, SSECustomerKey, etc.)

        Returns:
            True if object exists
        """
        try:
            head_kwargs: dict[str, Any] = {"Bucket": bucket, "Key": key}
            head_kwargs.update(kwargs)
            self._client.head_object(**head_kwargs)
            return True
        except ClientError:
            return False

    def head_object(self, bucket: str, key: str, **kwargs: Any) -> dict[str, Any]:
        """Get object metadata without downloading content.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            **kwargs: Additional S3 parameters (e.g., VersionId, SSECustomerKey, etc.)

        Returns:
            Object metadata

        Raises:
            S3BucketNotFoundError: If bucket doesn't exist
            S3ObjectNotFoundError: If object doesn't exist
            S3Exception: If operation fails
        """
        try:
            head_kwargs: dict[str, Any] = {"Bucket": bucket, "Key": key}
            head_kwargs.update(kwargs)
            response = self._client.head_object(**head_kwargs)
            return response
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "NoSuchBucket":
                raise S3BucketNotFoundError(f"Bucket '{bucket}' not found") from e
            elif error_code == "NoSuchKey":
                raise S3ObjectNotFoundError(
                    f"Object '{key}' not found in bucket '{bucket}'"
                ) from e
            raise S3Exception(f"Failed to get object metadata: {e}") from e

    def delete_object(self, bucket: str, key: str, **kwargs: Any) -> dict[str, Any]:
        """Delete an object from S3.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            **kwargs: Additional S3 parameters (e.g., VersionId, MFA, etc.)

        Returns:
            S3 response metadata

        Raises:
            S3BucketNotFoundError: If bucket doesn't exist
            S3Exception: If deletion fails
        """
        try:
            delete_kwargs = {"Bucket": bucket, "Key": key}
            delete_kwargs.update(kwargs)
            response = self._client.delete_object(**delete_kwargs)
            return response
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "NoSuchBucket":
                raise S3BucketNotFoundError(f"Bucket '{bucket}' not found") from e
            raise S3Exception(f"Failed to delete object: {e}") from e

    def copy_object(
        self,
        source_bucket: str,
        source_key: str,
        dest_bucket: str,
        dest_key: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Copy an object within S3.

        Args:
            source_bucket: Source bucket name
            source_key: Source object key
            dest_bucket: Destination bucket name
            dest_key: Destination object key
            **kwargs: Additional S3 parameters (e.g., MetadataDirective, ServerSideEncryption, etc.)

        Returns:
            S3 response metadata

        Raises:
            S3BucketNotFoundError: If bucket doesn't exist
            S3ObjectNotFoundError: If source object doesn't exist
            S3Exception: If copy fails
        """
        try:
            copy_source: dict[str, str] = {"Bucket": source_bucket, "Key": source_key}
            copy_kwargs: dict[str, Any] = {
                "CopySource": copy_source,
                "Bucket": dest_bucket,
                "Key": dest_key,
            }
            copy_kwargs.update(kwargs)
            response = self._client.copy_object(**copy_kwargs)
            return response
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "NoSuchBucket":
                raise S3BucketNotFoundError(
                    f"Bucket '{source_bucket}' or '{dest_bucket}' not found"
                ) from e
            elif error_code == "NoSuchKey":
                raise S3ObjectNotFoundError(
                    f"Object '{source_key}' not found in bucket '{source_bucket}'"
                ) from e
            raise S3Exception(f"Failed to copy object: {e}") from e

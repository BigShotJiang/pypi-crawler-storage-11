"""EventBridge examples module."""

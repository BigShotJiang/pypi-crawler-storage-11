"""EventBridge usage examples."""

from datetime import datetime

from axolotl.aws import AWSConfig
from axolotl.aws.eventbridge import (
    EventBridgeClient,
    EventBridgeClientError,
    EventBridgeInvalidParameterError,
    EventBridgeResourceNotFoundError,
)


def basic_event_example():
    """Example of sending a basic event to EventBridge."""
    # Configure AWS credentials
    config = AWSConfig(region="us-west-2")

    # Create EventBridge client
    eventbridge = EventBridgeClient(config)

    # Send a simple event
    try:
        response = eventbridge.send_event(
            event_bus_name="my-event-bus",
            source="my-app",
            detail_type="UserAction",
            detail={
                "userId": "123",
                "action": "login",
                "timestamp": "2024-01-01T10:00:00Z",
            },
        )
        print(f"Event sent successfully: {response}")
    except EventBridgeClientError as e:
        print(f"Failed to send event: {e}")


def advanced_event_example():
    """Example of sending an event with additional parameters."""
    config = AWSConfig(region="us-west-2")
    eventbridge = EventBridgeClient(config)

    try:
        response = eventbridge.send_event(
            event_bus_name="my-event-bus",
            source="data-processor",
            detail_type="DataProcessed",
            detail={
                "records": 100,
                "status": "success",
                "processingTime": 45.2,
                "outputLocation": "s3://my-bucket/processed/data.json",
            },
            time=datetime.now(),
            resources=["arn:aws:s3:::my-bucket/data.json"],
        )
        print(f"Advanced event sent successfully: {response}")
    except EventBridgeResourceNotFoundError as e:
        print(f"Event bus not found: {e}")
    except EventBridgeInvalidParameterError as e:
        print(f"Invalid parameters: {e}")
    except EventBridgeClientError as e:
        print(f"Failed to send event: {e}")


def string_detail_example():
    """Example of sending an event with string detail."""
    config = AWSConfig(region="us-west-2")
    eventbridge = EventBridgeClient(config)

    try:
        response = eventbridge.send_event(
            event_bus_name="my-event-bus",
            source="legacy-system",
            detail_type="SystemAlert",
            detail='{"level": "warning", "message": "High CPU usage detected"}',
        )
        print(f"String detail event sent successfully: {response}")
    except EventBridgeClientError as e:
        print(f"Failed to send event: {e}")


def error_handling_example():
    """Example of proper error handling."""
    config = AWSConfig(region="us-west-2")
    eventbridge = EventBridgeClient(config)

    try:
        # This will likely fail if the event bus doesn't exist
        response = eventbridge.send_event(
            event_bus_name="non-existent-bus",
            source="test-app",
            detail_type="TestEvent",
            detail={"test": "data"},
        )
        print(f"Event sent: {response}")
    except EventBridgeResourceNotFoundError:
        print("Event bus not found - this is expected for this example")
    except EventBridgeInvalidParameterError as e:
        print(f"Invalid parameters: {e}")
    except EventBridgeClientError as e:
        print(f"Other EventBridge error: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")


if __name__ == "__main__":
    print("EventBridge Examples")
    print("===================")

    print("\n1. Basic Event Example:")
    basic_event_example()

    print("\n2. Advanced Event Example:")
    advanced_event_example()

    print("\n3. String Detail Example:")
    string_detail_example()

    print("\n4. Error Handling Example:")
    error_handling_example()

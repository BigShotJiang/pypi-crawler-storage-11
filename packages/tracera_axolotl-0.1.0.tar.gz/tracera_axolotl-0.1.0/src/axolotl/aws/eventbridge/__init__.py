"""EventBridge service module for axolotl."""

from .client import EventBridgeClient
from .exceptions import (
    EventBridgeException,
    EventBridgeClientError,
    EventBridgeInvalidParameterError,
    EventBridgeResourceNotFoundError,
)

__all__ = [
    "EventBridgeClient",
    "EventBridgeException",
    "EventBridgeClientError",
    "EventBridgeInvalidParameterError",
    "EventBridgeResourceNotFoundError",
]

"""EventBridge-specific exceptions."""

from ..exceptions import AWSException


class EventBridgeException(AWSException):
    """Base exception for EventBridge operations."""

    pass


class EventBridgeClientError(EventBridgeException):
    """Raised when EventBridge client operation fails."""

    pass


class EventBridgeInvalidParameterError(EventBridgeException):
    """Raised when EventBridge parameters are invalid."""

    pass


class EventBridgeResourceNotFoundError(EventBridgeException):
    """Raised when EventBridge resource (event bus) is not found."""

    pass

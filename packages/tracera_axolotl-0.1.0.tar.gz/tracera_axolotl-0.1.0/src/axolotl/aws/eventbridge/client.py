"""EventBridge client for sending events."""

import json
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from botocore.errorfactory import ClientError

from ..config import AWSConfig
from .exceptions import (
    EventBridgeException,
    EventBridgeClientError,
    EventBridgeInvalidParameterError,
    EventBridgeResourceNotFoundError,
)


class EventBridgeClient:
    """Simple EventBridge client for sending events to event buses."""

    def __init__(self, config: AWSConfig):
        """Initialize EventBridge client with AWS configuration.

        Args:
            config: AWS configuration with credentials and region
        """
        self.config = config
        self._client = config.create_client("events")

    def send_event(
        self,
        event_bus_name: str,
        source: str,
        detail_type: str,
        detail: Union[Dict[str, Any], str],
        time: Optional[datetime] = None,
        resources: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Send an event to an EventBridge event bus.

        Args:
            event_bus_name: Name of the event bus to send the event to
            source: Source of the event (e.g., "my-app", "my-service")
            detail_type: Type of the event (e.g., "UserAction", "DataProcessed")
            detail: Event detail data (dict will be JSON serialized, str used as-is)
            time: Optional timestamp for the event (defaults to current time)
            resources: Optional list of AWS resource ARNs related to the event
            **kwargs: Additional parameters to pass to put_events

        Returns:
            Response from EventBridge put_events operation

        Raises:
            EventBridgeClientError: If the EventBridge operation fails
            EventBridgeInvalidParameterError: If parameters are invalid
            EventBridgeResourceNotFoundError: If the event bus is not found
        """
        try:
            # Prepare the event entry
            entry: Dict[str, Any] = {
                "EventBusName": event_bus_name,
                "Source": source,
                "DetailType": detail_type,
            }

            # Handle detail data
            if isinstance(detail, dict):
                entry["Detail"] = json.dumps(detail)
            elif isinstance(detail, str):
                entry["Detail"] = detail
            else:
                raise EventBridgeInvalidParameterError(
                    "Detail must be a dict or string"
                )

            # Add optional parameters
            if time is not None:
                entry["Time"] = time.isoformat()

            if resources is not None:
                entry["Resources"] = resources

            # Add any additional parameters
            entry.update(kwargs)

            # Send the event
            response = self._client.put_events(Entries=[entry])

            return response

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_message = e.response.get("Error", {}).get("Message", "")

            if error_code == "ResourceNotFoundException":
                raise EventBridgeResourceNotFoundError(
                    f"Event bus '{event_bus_name}' not found: {error_message}"
                ) from e
            elif error_code in ["InvalidParameterValue", "ValidationException"]:
                raise EventBridgeInvalidParameterError(
                    f"Invalid parameter: {error_message}"
                ) from e
            else:
                raise EventBridgeClientError(
                    f"EventBridge operation failed: {error_message}"
                ) from e

        except Exception as e:
            if isinstance(e, EventBridgeException):
                raise
            raise EventBridgeClientError(f"Unexpected error: {str(e)}") from e

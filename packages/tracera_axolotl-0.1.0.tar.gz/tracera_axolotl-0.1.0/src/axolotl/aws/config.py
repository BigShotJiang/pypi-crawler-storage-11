"""Base AWS configuration for all AWS services."""

import os
from typing import Optional

import boto3
from pydantic import BaseModel, Field


class AWSConfig(BaseModel):
    """Base AWS configuration for all AWS services."""

    region: str = Field(
        default_factory=lambda: os.getenv("AWS_REGION")
        or os.getenv("AWS_DEFAULT_REGION")
        or "eu-central-1",
        description="AWS region",
    )
    access_key_id: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_ACCESS_KEY_ID"),
        description="AWS access key ID",
    )
    secret_access_key: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_SECRET_ACCESS_KEY"),
        description="AWS secret access key",
    )
    session_token: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_SESSION_TOKEN"),
        description="AWS session token",
    )
    profile_name: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_PROFILE")
        or os.getenv("AWS_DEFAULT_PROFILE"),
        description="AWS profile name",
    )

    def create_session(self) -> boto3.Session:
        """Create boto3 session with credentials.

        Returns:
            Configured boto3 session
        """
        session_kwargs = {}
        if self.profile_name:
            session_kwargs["profile_name"] = self.profile_name
        elif self.access_key_id and self.secret_access_key:
            session_kwargs["aws_access_key_id"] = self.access_key_id
            session_kwargs["aws_secret_access_key"] = self.secret_access_key
            if self.session_token:
                session_kwargs["aws_session_token"] = self.session_token

        return boto3.Session(**session_kwargs)

    def create_client(self, service_name: str) -> boto3.client:
        """Create boto3 client for specified service.

        Args:
            service_name: AWS service name (e.g., 's3', 'lambda', 'dynamodb')

        Returns:
            Configured boto3 client for the service
        """
        session = self.create_session()
        return session.client(service_name, region_name=self.region)

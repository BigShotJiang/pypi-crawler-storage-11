"""AWS services module for axolotl."""

from .config import AWSConfig
from .exceptions import (
    AWSException,
    AWSClientError,
    AWSResourceNotFoundError,
    AWSConfigurationError,
)

# Import EventBridge components
from .eventbridge import (
    EventBridgeClient,
    EventBridgeException,
    EventBridgeClientError,
    EventBridgeInvalidParameterError,
    EventBridgeResourceNotFoundError,
)

__all__ = [
    "AWSConfig",
    "AWSException",
    "AWSClientError",
    "AWSResourceNotFoundError",
    "AWSConfigurationError",
    # EventBridge exports
    "EventBridgeClient",
    "EventBridgeException",
    "EventBridgeClientError",
    "EventBridgeInvalidParameterError",
    "EventBridgeResourceNotFoundError",
]

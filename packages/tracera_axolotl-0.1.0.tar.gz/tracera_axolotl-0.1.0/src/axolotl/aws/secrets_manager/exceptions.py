"""Secrets Manager specific exceptions."""

from ..exceptions import AWSException


class SecretsManagerException(AWSException):
    """Base exception for Secrets Manager operations."""

    pass


class SecretNotFoundError(SecretsManagerException):
    """Raised when secret is not found."""

    pass


class SecretVersionNotFoundError(SecretsManagerException):
    """Raised when secret version is not found."""

    pass

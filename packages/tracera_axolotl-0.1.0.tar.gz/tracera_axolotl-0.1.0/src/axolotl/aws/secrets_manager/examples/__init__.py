"""Secrets Manager examples module."""

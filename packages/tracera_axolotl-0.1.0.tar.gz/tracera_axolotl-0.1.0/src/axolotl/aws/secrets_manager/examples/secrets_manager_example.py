"""Secrets Manager usage examples."""

from axolotl.aws import AWSConfig
from axolotl.aws.secrets_manager import SecretsManagerClient


def basic_secrets_manager_operations():
    """Demonstrate basic Secrets Manager operations."""
    print("=== Basic Secrets Manager Operations ===")

    # Configure AWS credentials
    config = AWSConfig(region="us-west-2")

    # Create Secrets Manager client
    secrets = SecretsManagerClient(config)

    # GET SECRET OPERATIONS
    print("\n--- Get Secret Operations ---")

    # Get secret as string
    try:
        api_key = secrets.get_secret_string("my-app/api-key")
        print(f"✓ Retrieved API key: {api_key[:10]}...")
    except Exception as e:
        print(f"✗ Get secret string failed: {e}")

    # Get secret as JSON
    try:
        db_config = secrets.get_secret_json("my-app/database")
        print(f"✓ Retrieved DB config: {db_config}")
    except Exception as e:
        print(f"✗ Get secret JSON failed: {e}")

    # Get secret with version stage
    try:
        current_secret = secrets.get_secret_string(
            "my-app/api-key", version_stage="AWSCURRENT"
        )
        print(f"✓ Retrieved current version: {current_secret[:10]}...")
    except Exception as e:
        print(f"✗ Get secret with version stage failed: {e}")

    # CREATE SECRET OPERATIONS
    print("\n--- Create Secret Operations ---")

    # Create string secret
    try:
        response = secrets.create_secret(
            "my-app/test-string", "my-secret-value", description="Test string secret"
        )
        print(f"✓ Created string secret: {response['ARN']}")
    except Exception as e:
        print(f"✗ Create string secret failed: {e}")

    # Create JSON secret
    try:
        json_secret = {
            "username": "admin",
            "password": "secret123",
            "host": "localhost",
            "port": 5432,
        }
        response = secrets.create_secret(
            "my-app/test-json", json_secret, description="Test JSON secret"
        )
        print(f"✓ Created JSON secret: {response['ARN']}")
    except Exception as e:
        print(f"✗ Create JSON secret failed: {e}")

    # UPDATE SECRET OPERATIONS
    print("\n--- Update Secret Operations ---")

    # Update secret value
    try:
        response = secrets.update_secret(
            "my-app/test-string",
            "updated-secret-value",
            description="Updated test secret",
        )
        print(f"✓ Updated secret: {response['ARN']}")
    except Exception as e:
        print(f"✗ Update secret failed: {e}")

    # LIST SECRETS OPERATIONS
    print("\n--- List Secrets Operations ---")

    # List all secrets
    try:
        response = secrets.list_secrets(max_results=10)
        secret_list = response.get("SecretList", [])
        print(f"✓ Found {len(secret_list)} secrets")
        for secret in secret_list[:3]:  # Show first 3
            print(
                f"  - {secret['Name']}: {secret.get('Description', 'No description')}"
            )
    except Exception as e:
        print(f"✗ List secrets failed: {e}")

    # DESCRIBE SECRET OPERATIONS
    print("\n--- Describe Secret Operations ---")

    # Describe secret
    try:
        response = secrets.describe_secret("my-app/test-string")
        print(f"✓ Secret description:")
        print(f"  - Name: {response['Name']}")
        print(f"  - Description: {response.get('Description', 'No description')}")
        print(f"  - Last Changed: {response.get('LastChangedDate', 'Unknown')}")
    except Exception as e:
        print(f"✗ Describe secret failed: {e}")

    # UTILITY OPERATIONS
    print("\n--- Utility Operations ---")

    # Check if secret exists
    try:
        exists = secrets.secret_exists("my-app/test-string")
        print(f"✓ Secret 'my-app/test-string' exists: {exists}")
    except Exception as e:
        print(f"✗ Check secret existence failed: {e}")

    # Check if non-existent secret exists
    try:
        exists = secrets.secret_exists("my-app/non-existent")
        print(f"✓ Secret 'my-app/non-existent' exists: {exists}")
    except Exception as e:
        print(f"✗ Check non-existent secret failed: {e}")

    # RESTORE SECRET OPERATIONS
    print("\n--- Restore Secret Operations ---")

    # Restore a recently deleted secret
    try:
        response = secrets.restore_secret("my-app/test-string")
        print(f"✓ Restored secret: {response['ARN']}")
    except Exception as e:
        print(f"✗ Restore secret failed: {e}")


def advanced_secrets_manager_features():
    """Demonstrate advanced Secrets Manager features using kwargs."""
    print("\n=== Advanced Secrets Manager Features ===")

    config = AWSConfig(region="us-west-2")
    secrets = SecretsManagerClient(config)

    # Create secret with KMS encryption
    try:
        response = secrets.create_secret(
            "my-app/encrypted-secret",
            "sensitive-data",
            description="Encrypted secret",
            KmsKeyId="alias/aws/secretsmanager",
        )
        print(f"✓ Created encrypted secret: {response['ARN']}")
    except Exception as e:
        print(f"✗ Create encrypted secret failed: {e}")

    # Create secret with tags
    try:
        response = secrets.create_secret(
            "my-app/tagged-secret",
            "tagged-data",
            description="Secret with tags",
            Tags=[
                {"Key": "Environment", "Value": "Production"},
                {"Key": "Team", "Value": "DevOps"},
            ],
        )
        print(f"✓ Created tagged secret: {response['ARN']}")
    except Exception as e:
        print(f"✗ Create tagged secret failed: {e}")

    # List secrets with filters
    try:
        response = secrets.list_secrets(
            max_results=5, Filters=[{"Key": "description", "Values": ["Test"]}]
        )
        secret_list = response.get("SecretList", [])
        print(f"✓ Found {len(secret_list)} filtered secrets")
    except Exception as e:
        print(f"✗ List filtered secrets failed: {e}")

    # Update secret with rotation
    try:
        response = secrets.update_secret(
            "my-app/test-string",
            "rotated-secret-value",
            description="Secret with rotation",
            RotationLambdaArn="arn:aws:lambda:us-west-2:123456789012:function:rotate-secret",
        )
        print(f"✓ Updated secret with rotation: {response['ARN']}")
    except Exception as e:
        print(f"✗ Update secret with rotation failed: {e}")


def delete_and_restore_workflow():
    """Demonstrate delete and restore workflow."""
    print("\n=== Delete and Restore Workflow ===")

    config = AWSConfig(region="us-west-2")
    secrets = SecretsManagerClient(config)

    name = "my-app/test-string"

    # Create a secret for testing
    try:
        response = secrets.create_secret(
            name,
            "workflow-test-value",
            description="Secret for delete/restore workflow testing",
        )
        print(f"✓ Created secret for workflow: {response['ARN']}")
    except Exception as e:
        print(f"✗ Create secret for workflow failed: {e}")
        return

    # Delete the secret (with recovery window)
    try:
        response = secrets.delete_secret(
            name, force_delete=False, recovery_window_days=7
        )
        print(f"✓ Deleted secret (recovery window: 7 days)")
    except Exception as e:
        print(f"✗ Delete secret failed: {e}")
        return

    # Check if secret exists (should be False for deleted secret)
    try:
        exists = secrets.secret_exists(name)
        print(f"✓ Secret exists after deletion: {exists}")
    except Exception as e:
        print(f"✗ Check secret existence after deletion failed: {e}")

    # Restore the secret
    try:
        response = secrets.restore_secret(name)
        print(f"✓ Restored secret: {response['ARN']}")
    except Exception as e:
        print(f"✗ Restore secret failed: {e}")

    # Verify secret is restored
    try:
        exists = secrets.secret_exists(name)
        print(f"✓ Secret exists after restore: {exists}")
    except Exception as e:
        print(f"✗ Check secret existence after restore failed: {e}")

    # Clean up - delete permanently
    try:
        response = secrets.delete_secret(name, force_delete=True)
        print(f"✓ Permanently deleted secret")
    except Exception as e:
        print(f"✗ Permanent delete failed: {e}")


def error_handling_example():
    """Demonstrate error handling."""
    print("\n=== Error Handling Example ===")

    config = AWSConfig(region="us-west-2")
    secrets = SecretsManagerClient(config)

    # Try to access non-existent secret
    try:
        secrets.get_secret_string("non-existent-secret")
    except Exception as e:
        print(f"✓ Caught expected error for non-existent secret: {type(e).__name__}")

    # Try to update non-existent secret
    try:
        secrets.update_secret("non-existent-secret", "new-value")
    except Exception as e:
        print(
            f"✓ Caught expected error for updating non-existent secret: {type(e).__name__}"
        )

    # Try to restore non-existent secret
    try:
        secrets.restore_secret("non-existent-secret")
    except Exception as e:
        print(
            f"✓ Caught expected error for restoring non-existent secret: {type(e).__name__}"
        )


if __name__ == "__main__":
    basic_secrets_manager_operations()
    advanced_secrets_manager_features()
    delete_and_restore_workflow()
    error_handling_example()

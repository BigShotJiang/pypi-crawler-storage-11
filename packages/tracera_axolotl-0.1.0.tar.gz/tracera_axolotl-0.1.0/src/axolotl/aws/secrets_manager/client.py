"""AWS Secrets Manager client for common operations."""

import json
from typing import Any, Optional
from botocore.errorfactory import ClientError

from ..config import AWSConfig
from .exceptions import (
    SecretsManagerException,
    SecretNotFoundError,
    SecretVersionNotFoundError,
)


class SecretsManagerClient:
    """Simple Secrets Manager client for common operations."""

    def __init__(self, config: AWSConfig):
        """Initialize Secrets Manager client with AWS configuration.

        Args:
            config: AWS configuration with credentials and region
        """
        self.config = config
        self._client = config.create_client("secretsmanager")

    def get_secret_value(
        self,
        secret_name: str,
        version_id: Optional[str] = None,
        version_stage: Optional[str] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Get secret value from AWS Secrets Manager.

        Args:
            secret_name: Name or ARN of the secret
            version_id: Specific version ID to retrieve
            version_stage: Version stage (e.g., 'AWSCURRENT', 'AWSPENDING')
            **kwargs: Additional Secrets Manager parameters

        Returns:
            dictionary containing secret data

        Raises:
            SecretNotFoundError: If secret doesn't exist
            SecretVersionNotFoundError: If secret version doesn't exist
            SecretsManagerException: If operation fails
        """
        try:
            get_kwargs = {"SecretId": secret_name}
            if version_id:
                get_kwargs["VersionId"] = version_id
            if version_stage:
                get_kwargs["VersionStage"] = version_stage
            get_kwargs.update(kwargs)

            response = self._client.get_secret_value(**get_kwargs)
            return response
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "ResourceNotFoundException":
                raise SecretNotFoundError(f"Secret '{secret_name}' not found") from e
            elif error_code == "InvalidRequestException":
                raise SecretVersionNotFoundError(
                    f"Secret version not found for '{secret_name}'"
                ) from e
            raise SecretsManagerException(f"Failed to get secret: {e}") from e

    def get_secret_string(self, secret_name: str, **kwargs: Any) -> str:
        """Get secret value as string.

        Args:
            secret_name: Name or ARN of the secret
            **kwargs: Additional Secrets Manager parameters

        Returns:
            Secret value as string
        """
        response = self.get_secret_value(secret_name, **kwargs)
        return response["SecretString"]

    def get_secret_json(self, secret_name: str, **kwargs: Any) -> dict[str, Any]:
        """Get secret value as JSON.

        Args:
            secret_name: Name or ARN of the secret
            **kwargs: Additional Secrets Manager parameters

        Returns:
            Secret value parsed as JSON dictionary
        """
        secret_string = self.get_secret_string(secret_name, **kwargs)
        return json.loads(secret_string)

    def get_secret_binary(self, secret_name: str, **kwargs: Any) -> bytes:
        """Get secret value as binary.

        Args:
            secret_name: Name or ARN of the secret
            **kwargs: Additional Secrets Manager parameters

        Returns:
            Secret value as bytes
        """
        response = self.get_secret_value(secret_name, **kwargs)
        return response["SecretBinary"]

    def list_secrets(
        self,
        max_results: Optional[int] = None,
        next_token: Optional[str] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List secrets.

        Args:
            max_results: Maximum number of secrets to return
            next_token: Token for pagination
            **kwargs: Additional Secrets Manager parameters

        Returns:
            dictionary containing list of secrets and pagination info

        Raises:
            SecretsManagerException: If listing fails
        """
        try:
            list_kwargs: dict[str, Any] = {}
            if max_results:
                list_kwargs["MaxResults"] = max_results
            if next_token:
                list_kwargs["NextToken"] = next_token
            list_kwargs.update(kwargs)

            response = self._client.list_secrets(**list_kwargs)
            return response
        except ClientError as e:
            raise SecretsManagerException(f"Failed to list secrets: {e}") from e

    def describe_secret(self, secret_name: str, **kwargs: Any) -> dict[str, Any]:
        """Get detailed information about a secret.

        Args:
            secret_name: Name or ARN of the secret
            **kwargs: Additional Secrets Manager parameters

        Returns:
            Secret metadata and details

        Raises:
            SecretNotFoundError: If secret doesn't exist
            SecretsManagerException: If operation fails
        """
        try:
            describe_kwargs = {"SecretId": secret_name}
            describe_kwargs.update(kwargs)

            response = self._client.describe_secret(**describe_kwargs)
            return response
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "ResourceNotFoundException":
                raise SecretNotFoundError(f"Secret '{secret_name}' not found") from e
            raise SecretsManagerException(f"Failed to describe secret: {e}") from e

    def secret_exists(self, secret_name: str, **kwargs: Any) -> bool:
        """Check if a secret exists.

        Args:
            secret_name: Name or ARN of the secret
            **kwargs: Additional Secrets Manager parameters

        Returns:
            True if secret exists
        """
        try:
            self.describe_secret(secret_name, **kwargs)
            return True
        except SecretNotFoundError:
            return False

"""AWS Secrets Manager service module for axolotl."""

from .client import SecretsManagerClient
from .exceptions import (
    SecretsManagerException,
    SecretNotFoundError,
    SecretVersionNotFoundError,
)

__all__ = [
    "SecretsManagerClient",
    "SecretsManagerException",
    "SecretNotFoundError",
    "SecretVersionNotFoundError",
]

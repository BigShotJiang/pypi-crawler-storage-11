# AWS Services Module

This module provides a clean, simple interface for AWS services in the axolotl package.

## Features

- **Shared Configuration**: One `AWSConfig` for all AWS services
- **Simple API**: Clean, straightforward methods for common operations
- **Automatic MIME Detection**: Files are automatically tagged with correct content types
- **Proper Error Handling**: Specific exceptions for different error types
- **Flexible**: Bucket and key passed at runtime, not in configuration

## Supported Services

- **S3**: Object storage operations (files and objects)
- **Secrets Manager**: Secure storage and retrieval of secrets
- **Parameter Store**: Configuration and secrets management
- **EventBridge**: Event publishing to AWS EventBridge event buses

## Quick Start

```python
from axolotl.aws import AWSConfig
from axolotl.aws.s3 import S3Client

# Configure AWS credentials
config = AWSConfig(region="us-west-2")

# Create S3 client
s3 = S3Client(config)

# Upload a file
s3.upload_file("document.pdf", "my-bucket", "documents/report.pdf")

# Upload with additional S3 parameters
s3.upload_file(
    "data.json",
    "my-bucket",
    "data/export.json",
    "application/json",
    StorageClass="STANDARD_IA",
    Metadata={"project": "axolotl", "version": "1.0"},
    ServerSideEncryption="AES256"
)

# Download a file
s3.download_file("my-bucket", "documents/report.pdf", "downloaded_report.pdf")

# Upload data
s3.put_object("my-bucket", "data.txt", "Hello, World!", "text/plain")

# Upload with additional parameters
s3.put_object(
    "my-bucket",
    "encrypted.txt",
    "Sensitive data",
    "text/plain",
    ServerSideEncryption="AES256",
    Metadata={"encrypted": "true"}
)

# Download data
data = s3.get_object("my-bucket", "data.txt")
print(data.decode())  # "Hello, World!"

# List objects with pagination
objects = s3.list_objects("my-bucket", prefix="data/", MaxKeys=10, Delimiter="/")

# SECRETS MANAGER
from axolotl.aws.secrets_manager import SecretsManagerClient

secrets = SecretsManagerClient(config)

# Get secret as string
api_key = secrets.get_secret_string("my-app/api-key")

# Get secret as JSON
db_config = secrets.get_secret_json("my-app/database")

# Create secret
secrets.create_secret(
    "my-app/new-secret",
    {"username": "admin", "password": "secret123"}, # pragma: allowlist secret
    description="Application credentials"
)

# Delete secret (with recovery window)
secrets.delete_secret("my-app/old-secret", recovery_window_days=7)

# Restore recently deleted secret
secrets.restore_secret("my-app/old-secret")

# PARAMETER STORE
from axolotl.aws.parameter_store import ParameterStoreClient

params = ParameterStoreClient(config)

# Get single parameter
db_host = params.get_parameter_value("/my-app/database/host")

# Get parameter as JSON
config = params.get_parameter_json("/my-app/config")

# Get parameters by path
all_params = params.get_parameters_by_path("/my-app/", recursive=True)

# Create parameter
params.put_parameter(
    "/my-app/feature-flag",
    "true",
    parameter_type="String",
    description="Feature toggle"
)

# EVENTBRIDGE
from axolotl.aws.eventbridge import EventBridgeClient

eventbridge = EventBridgeClient(config)

# Send a simple event
response = eventbridge.send_event(
    event_bus_name="my-event-bus",
    source="my-app",
    detail_type="UserAction",
    detail={"userId": "123", "action": "login"}
)

# Send event with additional parameters
response = eventbridge.send_event(
    event_bus_name="my-event-bus",
    source="data-processor",
    detail_type="DataProcessed",
    detail={"records": 100, "status": "success"},
    time=datetime.now(),
    resources=["arn:aws:s3:::my-bucket/data.json"]
)

# Send another event
response = eventbridge.send_event(
    event_bus_name="my-event-bus",
    source="user-service",
    detail_type="UserCreated",
    detail={"userId": "456", "email": "user@example.com"}
)
```

## Configuration

The `AWSConfig` class handles AWS credentials and can be configured in several ways:

### Environment Variables (Recommended)
```bash
export AWS_REGION=us-west-2
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
```

### Direct Configuration
```python
config = AWSConfig(
    region="us-west-2",
    access_key_id="your_access_key",
    secret_access_key="your_secret_key" # pragma: allowlist secret
)
```

### AWS Profile
```python
config = AWSConfig(
    region="us-west-2",
    profile_name="my-aws-profile"
)
```

## S3 Operations

### File Operations (Local Files ↔ S3)

- `upload_file(file_path, bucket, key, content_type=None, **kwargs)`: Upload local file to S3
- `download_file(bucket, key, file_path, **kwargs)`: Download S3 object to local file

### Object Operations (Memory Data ↔ S3)

- `put_object(bucket, key, body, content_type, **kwargs)`: Upload data to S3
- `get_object(bucket, key, **kwargs)`: Download object data as bytes

### Listing Operations

- `list_objects(bucket, prefix, **kwargs)`: List objects in bucket

### Utility Operations

- `object_exists(bucket, key, **kwargs)`: Check if object exists
- `head_object(bucket, key, **kwargs)`: Get object metadata
- `delete_object(bucket, key, **kwargs)`: Delete object
- `copy_object(source_bucket, source_key, dest_bucket, dest_key, **kwargs)`: Copy object

### Common S3 Parameters

You can pass any S3 parameter via `**kwargs`. Common ones include:

- `StorageClass`: "STANDARD", "STANDARD_IA", "GLACIER", etc.
- `ServerSideEncryption`: "AES256", "aws:kms", etc.
- `Metadata`: Dictionary of custom metadata
- `CacheControl`: Cache control header
- `ContentDisposition`: Content disposition header
- `VersionId`: Specific object version
- `MaxKeys`: Maximum number of keys to return (for list operations)
- `Delimiter`: Character to group keys (for list operations)
- `StartAfter`: Key to start listing after (for pagination)

## Secrets Manager Operations

### Secret Operations

- `get_secret_value(secret_name, version_id=None, version_stage=None, **kwargs)`: Get secret value
- `get_secret_string(secret_name, **kwargs)`: Get secret value as string
- `get_secret_json(secret_name, **kwargs)`: Get secret value as JSON
- `get_secret_binary(secret_name, **kwargs)`: Get secret value as binary

### Secret Management

- `create_secret(secret_name, secret_value, description=None, **kwargs)`: Create new secret
- `update_secret(secret_name, secret_value, description=None, **kwargs)`: Update existing secret
- `delete_secret(secret_name, force_delete=False, recovery_window_days=None, **kwargs)`: Delete secret
- `restore_secret(secret_name, **kwargs)`: Restore recently deleted secret

### Secret Discovery

- `list_secrets(max_results=None, next_token=None, **kwargs)`: List secrets
- `describe_secret(secret_name, **kwargs)`: Get secret metadata
- `secret_exists(secret_name, **kwargs)`: Check if secret exists

## Parameter Store Operations

### Parameter Retrieval

- `get_parameter(parameter_name, with_decryption=True, **kwargs)`: Get single parameter
- `get_parameter_value(parameter_name, with_decryption=True, **kwargs)`: Get parameter value as string
- `get_parameter_json(parameter_name, with_decryption=True, **kwargs)`: Get parameter value as JSON
- `get_parameters(parameter_names, with_decryption=True, **kwargs)`: Get multiple parameters
- `get_parameters_by_path(path, recursive=False, with_decryption=True, **kwargs)`: Get parameters by path

### Parameter Management

- `put_parameter(parameter_name, parameter_value, parameter_type="String", description=None, overwrite=False, **kwargs)`: Create/update parameter
- `delete_parameter(parameter_name, **kwargs)`: Delete single parameter
- `delete_parameters(parameter_names, **kwargs)`: Delete multiple parameters

### Parameter Discovery

- `describe_parameter(parameter_name, **kwargs)`: Get parameter metadata
- `parameter_exists(parameter_name, **kwargs)`: Check if parameter exists
- `get_parameter_history(parameter_name, **kwargs)`: Get parameter version history

## EventBridge Operations

### Event Publishing

- `send_event(event_bus_name, source, detail_type, detail, time=None, resources=None, **kwargs)`: Send event to EventBridge

### Event Parameters

- `event_bus_name`: Name of the EventBridge event bus
- `source`: Source identifier for the event (e.g., "my-app", "my-service")
- `detail_type`: Type of the event (e.g., "UserAction", "DataProcessed")
- `detail`: Event detail data (dict will be JSON serialized, str used as-is)
- `time`: Optional timestamp for the event (defaults to current time)
- `resources`: Optional list of AWS resource ARNs related to the event

### Common EventBridge Parameters

You can pass any EventBridge parameter via `**kwargs`. Common ones include:

- `Time`: Event timestamp (datetime object)
- `Resources`: List of AWS resource ARNs
- `Detail`: Event detail data (string or JSON-serializable dict)
- `Source`: Event source identifier
- `DetailType`: Event type identifier

## Error Handling

The module provides specific exceptions for different error types:

- `AWSException`: Base exception for all AWS operations
- `S3Exception`: Base exception for S3 operations
- `S3BucketNotFoundError`: Raised when bucket doesn't exist
- `S3ObjectNotFoundError`: Raised when object doesn't exist
- `SecretsManagerException`: Base exception for Secrets Manager operations
- `SecretNotFoundError`: Raised when secret doesn't exist
- `SecretVersionNotFoundError`: Raised when secret version doesn't exist
- `ParameterStoreException`: Base exception for Parameter Store operations
- `ParameterNotFoundError`: Raised when parameter doesn't exist
- `ParameterVersionNotFoundError`: Raised when parameter version doesn't exist
- `EventBridgeException`: Base exception for EventBridge operations
- `EventBridgeClientError`: Raised when EventBridge operation fails
- `EventBridgeInvalidParameterError`: Raised when EventBridge parameters are invalid
- `EventBridgeResourceNotFoundError`: Raised when EventBridge event bus is not found

## Examples

See the `examples/` directory for complete usage examples.

## Future AWS Services

This module is designed to easily support additional AWS services:

- Lambda functions
- DynamoDB operations
- SQS messaging
- And more...

Each service will follow the same pattern of accepting an `AWSConfig` and providing a clean, focused API.

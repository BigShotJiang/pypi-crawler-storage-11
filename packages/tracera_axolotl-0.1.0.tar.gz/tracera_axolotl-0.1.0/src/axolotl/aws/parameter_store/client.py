"""AWS Parameter Store client for common operations."""

import json
from typing import Any, Optional, Union
from botocore.errorfactory import ClientError

from ..config import AWSConfig
from .exceptions import ParameterStoreException, ParameterNotFoundError


class ParameterStoreClient:
    """Simple Parameter Store client for common operations."""

    def __init__(self, config: AWSConfig):
        """Initialize Parameter Store client with AWS configuration.

        Args:
            config: AWS configuration with credentials and region
        """
        self.config = config
        self._client = config.create_client("ssm")

    def get_parameter(
        self, parameter_name: str, with_decryption: bool = True, **kwargs: Any
    ) -> dict[str, Any]:
        """Get parameter value from AWS Parameter Store.

        Args:
            parameter_name: Name of the parameter
            with_decryption: Whether to decrypt SecureString parameters
            **kwargs: Additional Parameter Store parameters

        Returns:
            dictionary containing parameter data

        Raises:
            ParameterNotFoundError: If parameter doesn't exist
            ParameterStoreException: If operation fails
        """
        try:
            get_kwargs: dict[str, Any] = {
                "Name": parameter_name,
                "WithDecryption": with_decryption,
            }
            get_kwargs.update(kwargs)

            response = self._client.get_parameter(**get_kwargs)
            return response
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "ParameterNotFound":
                raise ParameterNotFoundError(
                    f"Parameter '{parameter_name}' not found"
                ) from e
            raise ParameterStoreException(f"Failed to get parameter: {e}") from e

    def get_parameter_value(
        self, parameter_name: str, with_decryption: bool = True, **kwargs: Any
    ) -> str:
        """Get parameter value as string.

        Args:
            parameter_name: Name of the parameter
            with_decryption: Whether to decrypt SecureString parameters
            **kwargs: Additional Parameter Store parameters

        Returns:
            Parameter value as string
        """
        response = self.get_parameter(parameter_name, with_decryption, **kwargs)
        return response["Parameter"]["Value"]

    def get_parameter_json(
        self, parameter_name: str, with_decryption: bool = True, **kwargs: Any
    ) -> dict[str, Any]:
        """Get parameter value as JSON.

        Args:
            parameter_name: Name of the parameter
            with_decryption: Whether to decrypt SecureString parameters
            **kwargs: Additional Parameter Store parameters

        Returns:
            Parameter value parsed as JSON dictionary
        """
        parameter_value = self.get_parameter_value(
            parameter_name, with_decryption, **kwargs
        )
        return json.loads(parameter_value)

    def get_parameters(
        self, parameter_names: list[str], with_decryption: bool = True, **kwargs: Any
    ) -> dict[str, Any]:
        """Get multiple parameters.

        Args:
            parameter_names: list of parameter names
            with_decryption: Whether to decrypt SecureString parameters
            **kwargs: Additional Parameter Store parameters

        Returns:
            dictionary containing parameters and any invalid parameters

        Raises:
            ParameterStoreException: If operation fails
        """
        try:
            get_kwargs: dict[str, Any] = {
                "Names": parameter_names,
                "WithDecryption": with_decryption,
            }
            get_kwargs.update(kwargs)

            response = self._client.get_parameters(**get_kwargs)
            return response
        except ClientError as e:
            raise ParameterStoreException(f"Failed to get parameters: {e}") from e

    def get_parameters_by_path(
        self,
        path: str,
        recursive: bool = False,
        with_decryption: bool = True,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Get parameters by path.

        Args:
            path: Path prefix for parameters
            recursive: Whether to retrieve parameters recursively
            with_decryption: Whether to decrypt SecureString parameters
            **kwargs: Additional Parameter Store parameters

        Returns:
            dictionary containing parameters and pagination info

        Raises:
            ParameterStoreException: If operation fails
        """
        try:
            get_kwargs: dict[str, Any] = {
                "Path": path,
                "Recursive": recursive,
                "WithDecryption": with_decryption,
            }
            get_kwargs.update(kwargs)

            response = self._client.get_parameters_by_path(**get_kwargs)
            return response
        except ClientError as e:
            raise ParameterStoreException(
                f"Failed to get parameters by path: {e}"
            ) from e

    def put_parameter(
        self,
        parameter_name: str,
        parameter_value: Union[str, dict[str, Any]],
        parameter_type: str = "String",
        description: Optional[str] = None,
        overwrite: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create or update a parameter.

        Args:
            parameter_name: Name of the parameter
            parameter_value: Parameter value (string or dict for JSON)
            parameter_type: Type of parameter (String, Stringlist, SecureString)
            description: Description of the parameter
            overwrite: Whether to overwrite existing parameter
            **kwargs: Additional Parameter Store parameters

        Returns:
            Creation/update response metadata

        Raises:
            ParameterStoreException: If operation fails
        """
        try:
            put_kwargs: dict[str, Any] = {
                "Name": parameter_name,
                "Value": json.dumps(parameter_value)
                if isinstance(parameter_value, dict)
                else str(parameter_value),
                "Type": parameter_type,
                "Overwrite": overwrite,
            }

            if description:
                put_kwargs["Description"] = description

            put_kwargs.update(kwargs)

            response = self._client.put_parameter(**put_kwargs)
            return response
        except ClientError as e:
            raise ParameterStoreException(f"Failed to put parameter: {e}") from e

    def delete_parameter(self, parameter_name: str, **kwargs: Any) -> dict[str, Any]:
        """Delete a parameter.

        Args:
            parameter_name: Name of the parameter
            **kwargs: Additional Parameter Store parameters

        Returns:
            Deletion response metadata

        Raises:
            ParameterNotFoundError: If parameter doesn't exist
            ParameterStoreException: If deletion fails
        """
        try:
            delete_kwargs: dict[str, Any] = {"Name": parameter_name}
            delete_kwargs.update(kwargs)

            response = self._client.delete_parameter(**delete_kwargs)
            return response
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "ParameterNotFound":
                raise ParameterNotFoundError(
                    f"Parameter '{parameter_name}' not found"
                ) from e
            raise ParameterStoreException(f"Failed to delete parameter: {e}") from e

    def delete_parameters(
        self, parameter_names: list[str], **kwargs: Any
    ) -> dict[str, Any]:
        """Delete multiple parameters.

        Args:
            parameter_names: list of parameter names
            **kwargs: Additional Parameter Store parameters

        Returns:
            Deletion response metadata with deleted and failed parameters

        Raises:
            ParameterStoreException: If operation fails
        """
        try:
            delete_kwargs: dict[str, Any] = {"Names": parameter_names}
            delete_kwargs.update(kwargs)

            response = self._client.delete_parameters(**delete_kwargs)
            return response
        except ClientError as e:
            raise ParameterStoreException(f"Failed to delete parameters: {e}") from e

    def describe_parameter(self, parameter_name: str, **kwargs: Any) -> dict[str, Any]:
        """Get detailed information about a parameter.

        Args:
            parameter_name: Name of the parameter
            **kwargs: Additional Parameter Store parameters

        Returns:
            Parameter metadata and details

        Raises:
            ParameterNotFoundError: If parameter doesn't exist
            ParameterStoreException: If operation fails
        """
        try:
            describe_kwargs: dict[str, Any] = {"Name": parameter_name}
            describe_kwargs.update(kwargs)

            response = self._client.describe_parameter(**describe_kwargs)
            return response
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "ParameterNotFound":
                raise ParameterNotFoundError(
                    f"Parameter '{parameter_name}' not found"
                ) from e
            raise ParameterStoreException(f"Failed to describe parameter: {e}") from e

    def parameter_exists(self, parameter_name: str, **kwargs: Any) -> bool:
        """Check if a parameter exists.

        Args:
            parameter_name: Name of the parameter
            **kwargs: Additional Parameter Store parameters

        Returns:
            True if parameter exists
        """
        try:
            self.describe_parameter(parameter_name, **kwargs)
            return True
        except ParameterNotFoundError:
            return False

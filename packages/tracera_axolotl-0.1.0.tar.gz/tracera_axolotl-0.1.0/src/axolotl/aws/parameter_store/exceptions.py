"""Parameter Store specific exceptions."""

from ..exceptions import AWSException


class ParameterStoreException(AWSException):
    """Base exception for Parameter Store operations."""

    pass


class ParameterNotFoundError(ParameterStoreException):
    """Raised when parameter is not found."""

    pass


class ParameterVersionNotFoundError(ParameterStoreException):
    """Raised when parameter version is not found."""

    pass

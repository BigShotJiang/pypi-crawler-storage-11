"""Parameter Store usage examples."""

import os
from axolotl.aws import AWSConfig
from axolotl.aws.parameter_store import ParameterStoreClient

from dotenv import load_dotenv

load_dotenv()


def basic_parameter_store_operations():
    """Demonstrate basic Parameter Store operations."""
    print("=== Basic Parameter Store Operations ===")

    # Configure AWS credentials
    config = AWSConfig(region=os.getenv("AWS_DEFAULT_REGION"))

    # Create Parameter Store client
    params = ParameterStoreClient(config)

    # GET PARAMETER OPERATIONS
    print("\n--- Get Parameter Operations ---")

    # Get single parameter
    try:
        db_host = params.get_parameter_value(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME")
        )
        print(f"✓ Retrieved DB host: {db_host}")
    except Exception as e:
        print(f"✗ Get parameter value failed: {e}")

    # Get parameter as JSON
    try:
        config = params.get_parameter_json(os.getenv("PARAMETER_STORE_PARAMETER_NAME"))
        print(f"✓ Retrieved config: {config}")
    except Exception as e:
        print(f"✗ Get parameter JSON failed: {e}")

    # Get multiple parameters
    try:
        response = params.get_parameters(
            [
                os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
                os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
            ]
        )
        parameters = response.get("Parameters", [])
        print(f"✓ Retrieved {len(parameters)} parameters")
        for param in parameters:
            print(f"  - {param['Name']}: {param['Value']}")
    except Exception as e:
        print(f"✗ Get multiple parameters failed: {e}")

    # Get parameters by path
    try:
        response = params.get_parameters_by_path(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME"), recursive=True
        )
        parameters = response.get("Parameters", [])
        print(f"✓ Retrieved {len(parameters)} parameters by path")
        for param in parameters[:3]:  # Show first 3
            print(f"  - {param['Name']}: {param['Value'][:20]}...")
    except Exception as e:
        print(f"✗ Get parameters by path failed: {e}")

    # PUT PARAMETER OPERATIONS
    print("\n--- Put Parameter Operations ---")

    # Create string parameter
    try:
        response = params.put_parameter(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
            "test-value",
            parameter_type="String",
            description="Test string parameter",
        )
        print(f"✓ Created string parameter: {response['Version']}")
    except Exception as e:
        print(f"✗ Create string parameter failed: {e}")

    # Create secure string parameter
    try:
        response = params.put_parameter(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
            "secret-value",
            parameter_type="SecureString",
            description="Test secure parameter",
        )
        print(f"✓ Created secure parameter: {response['Version']}")
    except Exception as e:
        print(f"✗ Create secure parameter failed: {e}")

    # Create JSON parameter
    try:
        json_config = {
            "database": {"host": "localhost", "port": 5432, "name": "myapp"},
            "features": {"new_ui": True, "beta_mode": False},
        }
        response = params.put_parameter(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
            json_config,
            parameter_type="String",
            description="Test JSON parameter",
        )
        print(f"✓ Created JSON parameter: {response['Version']}")
    except Exception as e:
        print(f"✗ Create JSON parameter failed: {e}")

    # Create string list parameter
    try:
        response = params.put_parameter(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
            "value1,value2,value3",
            parameter_type="StringList",
            description="Test string list parameter",
        )
        print(f"✓ Created string list parameter: {response['Version']}")
    except Exception as e:
        print(f"✗ Create string list parameter failed: {e}")

    # DESCRIBE PARAMETER OPERATIONS
    print("\n--- Describe Parameter Operations ---")

    # Describe parameter
    try:
        response = params.describe_parameter(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME")
        )
        print(f"✓ Parameter description:")
        print(f"  - Name: {response['Parameter']['Name']}")
        print(f"  - Type: {response['Parameter']['Type']}")
        print(
            f"  - Description: {response['Parameter'].get('Description', 'No description')}"
        )
        print(
            f"  - Last Modified: {response['Parameter'].get('LastModifiedDate', 'Unknown')}"
        )
    except Exception as e:
        print(f"✗ Describe parameter failed: {e}")

    # UTILITY OPERATIONS
    print("\n--- Utility Operations ---")

    # Check if parameter exists
    try:
        exists = params.parameter_exists(os.getenv("PARAMETER_STORE_PARAMETER_NAME"))
        print(f"✓ Parameter '/my-app/test/string-param' exists: {exists}")
    except Exception as e:
        print(f"✗ Check parameter existence failed: {e}")

    # Check if non-existent parameter exists
    try:
        exists = params.parameter_exists("/my-app/non-existent")
        print(f"✓ Parameter '/my-app/non-existent' exists: {exists}")
    except Exception as e:
        print(f"✗ Check non-existent parameter failed: {e}")

    # Get parameter history
    try:
        response = params.get_parameter_history(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME")
        )
        history = response.get("Parameters", [])
        print(f"✓ Parameter history: {len(history)} versions")
        for version in history[:2]:  # Show first 2 versions
            print(
                f"  - Version {version['Version']}: {version.get('Description', 'No description')}"
            )
    except Exception as e:
        print(f"✗ Get parameter history failed: {e}")


def advanced_parameter_store_features():
    """Demonstrate advanced Parameter Store features using kwargs."""
    print("\n=== Advanced Parameter Store Features ===")

    config = AWSConfig(region=os.getenv("AWS_DEFAULT_REGION"))
    params = ParameterStoreClient(config)

    # Create parameter with tags
    try:
        response = params.put_parameter(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
            "tagged-value",
            parameter_type="String",
            description="Parameter with tags",
            Tags=[
                {"Key": "Environment", "Value": "Production"},
                {"Key": "Team", "Value": "DevOps"},
                {"Key": "Project", "Value": "MyApp"},
            ],
        )
        print(f"✓ Created tagged parameter: {response['Version']}")
    except Exception as e:
        print(f"✗ Create tagged parameter failed: {e}")

    # Create parameter with KMS key
    try:
        response = params.put_parameter(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
            "encrypted-value",
            parameter_type="SecureString",
            description="Encrypted parameter",
            KeyId="alias/aws/ssm",
        )
        print(f"✓ Created encrypted parameter: {response['Version']}")
    except Exception as e:
        print(f"✗ Create encrypted parameter failed: {e}")

    # Get parameters with specific decryption
    try:
        response = params.get_parameters_by_path(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
            recursive=True,
            with_decryption=True,
            ParameterFilters=[
                {"Key": "Type", "Option": "Equals", "Values": ["SecureString"]}
            ],
        )
        parameters = response.get("Parameters", [])
        print(f"✓ Retrieved {len(parameters)} secure parameters")
    except Exception as e:
        print(f"✗ Get secure parameters failed: {e}")

    # Update parameter with new tier
    try:
        response = params.put_parameter(
            os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
            "updated-value",
            parameter_type="String",
            description="Updated parameter",
            overwrite=True,
            Tier="Advanced",
        )
        print(f"✓ Updated parameter with advanced tier: {response['Version']}")
    except Exception as e:
        print(f"✗ Update parameter with tier failed: {e}")


def delete_operations():
    """Demonstrate delete operations."""
    print("\n=== Delete Operations ===")

    config = AWSConfig(region=os.getenv("AWS_DEFAULT_REGION"))
    params = ParameterStoreClient(config)

    # Delete single parameter
    try:
        response = params.delete_parameter(os.getenv("PARAMETER_STORE_PARAMETER_NAME"))
        print(f"✓ Deleted single parameter")
    except Exception as e:
        print(f"✗ Delete single parameter failed: {e}")

    # Delete multiple parameters
    try:
        response = params.delete_parameters(
            [
                os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
                os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
                os.getenv("PARAMETER_STORE_PARAMETER_NAME"),
            ]
        )
        deleted = response.get("DeletedParameters", [])
        failed = response.get("InvalidParameters", [])
        print(f"✓ Deleted {len(deleted)} parameters, {len(failed)} failed")
    except Exception as e:
        print(f"✗ Delete multiple parameters failed: {e}")


def error_handling_example():
    """Demonstrate error handling."""
    print("\n=== Error Handling Example ===")

    config = AWSConfig(region=os.getenv("AWS_DEFAULT_REGION"))
    params = ParameterStoreClient(config)

    # Try to access non-existent parameter
    try:
        params.get_parameter_value("/non-existent-parameter")
    except Exception as e:
        print(f"✓ Caught expected error for non-existent parameter: {type(e).__name__}")

    # Try to delete non-existent parameter
    try:
        params.delete_parameter("/non-existent-parameter")
    except Exception as e:
        print(
            f"✓ Caught expected error for deleting non-existent parameter: {type(e).__name__}"
        )


if __name__ == "__main__":
    basic_parameter_store_operations()
    advanced_parameter_store_features()
    delete_operations()
    error_handling_example()

"""Parameter Store examples module."""

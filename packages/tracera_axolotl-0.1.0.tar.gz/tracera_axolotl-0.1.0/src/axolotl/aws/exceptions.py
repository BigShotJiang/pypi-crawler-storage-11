"""Common AWS exceptions."""


class AWSException(Exception):
    """Base exception for AWS operations."""

    pass


class AWSClientError(AWSException):
    """Raised when AWS client operation fails."""

    pass


class AWSResourceNotFoundError(AWSException):
    """Raised when AWS resource is not found."""

    pass


class AWSConfigurationError(AWSException):
    """Raised when AWS configuration is invalid."""

    pass

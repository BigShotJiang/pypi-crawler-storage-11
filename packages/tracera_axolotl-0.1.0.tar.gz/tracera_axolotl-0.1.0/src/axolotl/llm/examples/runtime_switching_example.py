#!/usr/bin/env python3
"""
Runtime Provider Switching Example

This example demonstrates how to easily switch between different LLM providers
at runtime using the new LLMConfig interface.
"""

import os
from typing import Literal, Optional
from axolotl.llm.domain.config import LLMConfig, LLMParameters
from axolotl.llm.adapters.factory import LLMClientFactory


def create_llm_client(
    provider: Literal["bedrock", "openai"],
    model: str,
    framework: Literal["langchain", "llamaindex"] = "langchain",
    **provider_kwargs,
):
    """
    Create an LLM client with automatic provider config selection.

    Args:
        provider: The LLM provider ("bedrock" or "openai")
        model: The model name to use
        framework: The framework to use (default: "langchain")
        **provider_kwargs: Provider-specific configuration parameters

    Returns:
        Tuple of (client, config) or (None, None) if creation fails
    """
    config = LLMConfig(
        provider=provider, model_name=model, framework=framework, **provider_kwargs
    )

    try:
        client = LLMClientFactory.create_client(config)
        return client, config
    except Exception as e:
        print(f"Error creating {provider} client: {e}")
        return None, None


def demonstrate_runtime_switching():
    """Demonstrate runtime switching between providers."""
    print("Runtime Provider Switching Demo")
    print("=" * 50)

    # Define different provider/model combinations
    configurations = [
        {
            "provider": "bedrock",
            "model": "claude-3-sonnet",
            "framework": "langchain",
            "description": "AWS Bedrock with Claude 3 Sonnet via LangChain",
        },
        {
            "provider": "bedrock",
            "model": "claude-3-haiku",
            "framework": "llamaindex",
            "description": "AWS Bedrock with Claude 3 Haiku via LlamaIndex",
        },
        {
            "provider": "openai",
            "model": "gpt-4",
            "framework": "langchain",
            "description": "OpenAI GPT-4 via LangChain",
            "api_key": "sk-test-key",  # Example key for demo
            "base_url": "https://api.openai.com/v1",
        },
        {
            "provider": "openai",
            "model": "gpt-3.5-turbo",
            "framework": "llamaindex",
            "description": "OpenAI GPT-3.5 Turbo via LlamaIndex",
            "api_key": "sk-test-key",
            "base_url": "https://api.openai.com/v1",
        },
    ]

    print("\nTesting different provider/framework combinations:")
    print("-" * 50)

    for i, config in enumerate(configurations, 1):
        print(f"\n{i}. {config['description']}")
        print(f"   Provider: {config['provider']}")
        print(f"   Model: {config['model']}")
        print(f"   Framework: {config['framework']}")

        # Extract provider-specific kwargs
        provider_kwargs = {
            k: v
            for k, v in config.items()
            if k not in ["provider", "model", "framework", "description"]
        }

        client, llm_config = create_llm_client(
            provider=config["provider"],
            model=config["model"],
            framework=config["framework"],
            **provider_kwargs,
        )

        if client:
            print(f"   ✅ Client created: {type(client).__name__}")
            print(f"   📍 Region/Base URL: {get_provider_location(llm_config)}")
        else:
            print(f"   ❌ Failed to create client")


def get_provider_location(config: LLMConfig) -> str:
    """Get the location information for the provider config."""
    if config.provider == "bedrock":
        return f"Region: {config.provider_config.region}"
    elif config.provider == "openai":
        base_url = config.provider_config.base_url or "default"
        return f"Base URL: {base_url}"
    return "Unknown"


def demonstrate_dynamic_selection():
    """Demonstrate dynamic provider selection based on conditions."""
    print("\n\nDynamic Provider Selection Demo")
    print("=" * 50)

    # Simulate different scenarios
    scenarios = [
        {
            "name": "High Performance Task",
            "condition": "needs_best_model",
            "provider": "bedrock",
            "model": "claude-3-sonnet",
            "reason": "Best model for complex tasks",
        },
        {
            "name": "Fast Response Task",
            "condition": "needs_fast_response",
            "provider": "bedrock",
            "model": "claude-3-haiku",
            "reason": "Fastest model for quick responses",
        },
        {
            "name": "Cost Sensitive Task",
            "condition": "needs_cost_efficiency",
            "provider": "openai",
            "model": "gpt-3.5-turbo",
            "reason": "Most cost-effective option",
        },
    ]

    for scenario in scenarios:
        print(f"\nScenario: {scenario['name']}")
        print(f"Condition: {scenario['condition']}")
        print(f"Reason: {scenario['reason']}")

        client, config = create_llm_client(
            provider=scenario["provider"], model=scenario["model"]
        )

        if client:
            print(f"✅ Selected: {config.provider} + {config.model_name}")
            print(f"   Framework: {config.framework}")
        else:
            print(f"❌ Failed to select provider for {scenario['name']}")


def demonstrate_environment_based_config():
    """Demonstrate configuration based on environment variables."""
    print("\n\nEnvironment-Based Configuration Demo")
    print("=" * 50)

    # Show how environment variables affect configuration
    print("Current environment variables:")
    env_vars = ["AWS_REGION", "AWS_ACCESS_KEY_ID", "OPENAI_API_KEY", "OPENAI_BASE_URL"]

    for var in env_vars:
        value = os.getenv(var)
        if value:
            # Mask sensitive values
            if "KEY" in var:
                display_value = f"{value[:8]}..." if len(value) > 8 else "***"
            else:
                display_value = value
            print(f"  {var}: {display_value}")
        else:
            print(f"  {var}: (not set)")

    print("\nCreating configs with environment variables:")

    # Test Bedrock with environment variables
    bedrock_config = LLMConfig("bedrock", "claude-3-sonnet")
    print(f"Bedrock config - Region: {bedrock_config.provider_config.region}")
    print(
        f"Bedrock config - Access Key: {'Set' if bedrock_config.provider_config.access_key_id else 'Not set'}"
    )

    # Test OpenAI with environment variables
    openai_config = LLMConfig("openai", "gpt-4")
    print(
        f"OpenAI config - API Key: {'Set' if openai_config.provider_config.api_key else 'Not set'}"
    )
    print(
        f"OpenAI config - Base URL: {openai_config.provider_config.base_url or 'Not set'}"
    )


def demonstrate_new_interface():
    """Demonstrate the new simplified interface."""
    print("\n\nNew Simplified Interface Demo")
    print("=" * 50)

    # Show available providers
    print("Available providers:", LLMConfig.get_available_providers())

    # Simple usage examples
    print("\n--- Simple Usage Examples ---")

    # Bedrock with automatic config
    bedrock_config = LLMConfig("bedrock", "claude-3-sonnet", region="us-west-2")
    print(f"Bedrock config - Region: {bedrock_config.provider_config.region}")

    # OpenAI with automatic config
    openai_config = LLMConfig(
        "openai", "gpt-4", api_key="sk-test", base_url="https://api.openai.com/v1"
    )
    print(f"OpenAI config - API Key: {openai_config.provider_config.api_key[:8]}...")
    print(f"OpenAI config - Base URL: {openai_config.provider_config.base_url}")

    # Test error handling for unsupported provider
    try:
        invalid_config = LLMConfig("azure", "gpt-4", api_key="test")
    except ValueError as e:
        print(f"Expected error for unsupported provider: {e}")


if __name__ == "__main__":
    demonstrate_runtime_switching()
    demonstrate_dynamic_selection()
    demonstrate_environment_based_config()
    demonstrate_new_interface()

    print("\n\n" + "=" * 50)
    print("Runtime switching examples completed!")
    print("\nKey benefits:")
    print("✅ Easy provider switching with minimal code changes")
    print("✅ Automatic provider config selection")
    print("✅ Environment variable support")
    print("✅ Type-safe configuration")
    print("✅ Clean, maintainable code")
    print("✅ Extensible provider registry")

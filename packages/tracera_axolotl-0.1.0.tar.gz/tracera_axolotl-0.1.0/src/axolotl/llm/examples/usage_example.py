#!/usr/bin/env python3
"""
Comprehensive usage example for the Axolotl LLM Module

This example demonstrates:
1. Basic client creation and usage
2. Framework switching (LangChain ↔ LlamaIndex)
3. Provider switching (Bedrock ↔ OpenAI)
4. Direct framework client usage
5. Error handling
6. System information

Run with: python usage_example.py
"""

import os
import sys
from typing import Any, Dict, List

# Add the src directory to the path so we can import axolotl
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from dotenv import load_dotenv
from axolotl.llm import (
    LLMClientFactory,
    LLMConfig,
    LLMParameters,
    BedrockProviderConfig,
    OpenAIProviderConfig,
)
from axolotl.llm.exceptions import LLMError
from langchain.prompts import PromptTemplate

load_dotenv()


def print_section(title: str) -> None:
    """Print a formatted section header."""
    print(f"\n{'=' * 60}")
    print(f" {title}")
    print(f"{'=' * 60}")


def print_subsection(title: str) -> None:
    """Print a formatted subsection header."""
    print(f"\n--- {title} ---")


def demonstrate_basic_usage():
    """Demonstrate basic client creation and usage."""
    print_section("Basic Usage Example")

    # Create a Bedrock configuration using the new interface
    config = LLMConfig(
        provider="bedrock",
        model_name="anthropic.claude-3-haiku-20240307-v1:0",
        framework="langchain",
        parameters=LLMParameters(temperature=0.7, max_tokens=100),
        region="us-east-1",  # Provider kwargs are passed directly
    )

    # Create the client
    client = LLMClientFactory.create_client(config)

    # Use with LangChain
    prompt_template = PromptTemplate(input_variables=["input"], template="{input}")
    chain = prompt_template | client
    result = chain.invoke({"input": "What is the capital of United States?"})
    print(result)


def demonstrate_framework_switching():
    """Demonstrate switching between frameworks with the same provider."""
    print_section("Framework Switching Example")

    # Start with LangChain
    config = LLMConfig(
        provider="bedrock",
        model_name="anthropic.claude-3-haiku-20240307-v1:0",
        framework="langchain",
        parameters=LLMParameters(),
        region="us-east-1",
    )

    # Create LangChain client
    langchain_client = LLMClientFactory.create_client(config)
    prompt = PromptTemplate(input_variables=["input"], template="{input}")
    chain = prompt | langchain_client
    result = chain.invoke({"input": "What is the capital of United States?!"})
    print("LangChain result:", result)

    # Switch to LlamaIndex
    config.framework = "llamaindex"
    llamaindex_client = LLMClientFactory.create_client(config)
    response = llamaindex_client.complete("What is the an LLM in short?")
    print("LlamaIndex result:", response)

    # Switch back to LangChain
    config.framework = "langchain"
    langchain_client_2 = LLMClientFactory.create_client(config)
    print("Back to LangChain:", type(langchain_client_2).__name__)


def demonstrate_provider_switching():
    """Demonstrate switching between providers with the same framework."""
    print_section("Provider Switching Example")

    # Bedrock configuration
    bedrock_config = LLMConfig(
        provider="bedrock",
        model_name="anthropic.claude-3-haiku-20240307-v1:0",
        framework="langchain",
        parameters=LLMParameters(),
        region="us-east-1",
    )

    # OpenAI configuration
    openai_config = LLMConfig(
        provider="openai",
        model_name="gpt-4o",
        framework="langchain",
        parameters=LLMParameters(),
        api_key="test-key",  # In real usage, this would be from environment
        base_url="https://api.openai.com/v1",
    )

    # Create clients
    bedrock_client = LLMClientFactory.create_client(bedrock_config)
    openai_client = LLMClientFactory.create_client(openai_config)

    print("Bedrock LangChain:", type(bedrock_client).__name__)
    print("OpenAI LangChain:", type(openai_client).__name__)

    # Switch both to LlamaIndex
    bedrock_config.framework = "llamaindex"
    openai_config.framework = "llamaindex"

    bedrock_llamaindex = LLMClientFactory.create_client(bedrock_config)
    openai_llamaindex = LLMClientFactory.create_client(openai_config)

    print("Bedrock LlamaIndex:", type(bedrock_llamaindex).__name__)
    print("OpenAI LlamaIndex:", type(openai_llamaindex).__name__)


def demonstrate_direct_framework_usage():
    """Demonstrate direct usage with framework components."""
    print_section("Direct Framework Usage Example")

    # LangChain Direct Usage
    config = LLMConfig(
        provider="bedrock",
        model_name="anthropic.claude-3-haiku-20240307-v1:0",
        framework="langchain",
        parameters=LLMParameters(),
        region="us-east-1",
    )

    client = LLMClientFactory.create_client(config)
    print("LangChain client type:", type(client).__name__)
    print("Has invoke method:", hasattr(client, "invoke"))

    # Use with LangChain components
    from langchain.prompts import ChatPromptTemplate

    prompt = ChatPromptTemplate.from_messages(
        [("system", "You are a helpful assistant."), ("human", "{input}")]
    )
    chain = prompt | client
    result = chain.invoke({"input": "What is the capital of United States?"})
    print("LangChain result:", result)

    # LlamaIndex Direct Usage
    config.framework = "llamaindex"
    llamaindex_client = LLMClientFactory.create_client(config)
    print("LlamaIndex client type:", type(llamaindex_client).__name__)
    print("Has complete method:", hasattr(llamaindex_client, "complete"))

    # Use with LlamaIndex components
    response = llamaindex_client.complete("What is the an LLM in short?")
    print("LlamaIndex result:", response)


def demonstrate_error_handling():
    """Demonstrate error handling and edge cases."""
    print_section("Error Handling Example")

    # Unsupported Provider-Framework Combination
    try:
        config = LLMConfig(
            provider="bedrock",
            model_name="test",
            framework="direct",  # Not implemented yet
            parameters=LLMParameters(),
            region="us-east-1",
        )
        LLMClientFactory.create_client(config)
    except LLMError as e:
        print("Unsupported combination error:", e)
    except Exception as e:
        print("General error:", e)

    # Invalid Framework
    try:
        config = LLMConfig(
            provider="bedrock",
            model_name="test",
            framework="invalid_framework",  # Invalid literal
            parameters=LLMParameters(),
            region="us-east-1",
        )
        LLMClientFactory.create_client(config)
    except Exception as e:
        print("Validation error:", e)

    # Missing Dependencies
    config = LLMConfig(
        provider="bedrock",
        model_name="test",
        framework="langchain",
        parameters=LLMParameters(),
        region="us-east-1",
    )

    try:
        client = LLMClientFactory.create_client(config)
        print("Client created:", type(client).__name__)
    except Exception as e:
        if "not installed" in str(e):
            print("Dependency error:", e)
        else:
            print("Unexpected error:", e)


def demonstrate_system_information():
    """Demonstrate system information and introspection."""
    print_section("System Information")

    # Get system information
    combinations = LLMClientFactory.get_supported_combinations()
    providers = LLMClientFactory.get_supported_providers()
    frameworks = LLMClientFactory.get_supported_frameworks()

    print("Supported combinations:", combinations)
    print("Supported providers:", providers)
    print("Supported frameworks:", frameworks)

    # Show adapter details
    for combination in combinations:
        provider, framework = combination.split(":")
        if provider == "bedrock":
            config = LLMConfig(
                provider="bedrock",
                model_name="test",
                framework=framework,
                parameters=LLMParameters(),
                region="us-east-1",
            )
        elif provider == "openai":
            config = LLMConfig(
                provider="openai",
                model_name="test",
                framework=framework,
                parameters=LLMParameters(),
                api_key="test",
            )
        else:
            continue

        try:
            client = LLMClientFactory.create_client(config)
            print(f"{provider.title()} + {framework.title()}: {type(client).__name__}")
        except Exception as e:
            print(f"{provider.title()} + {framework.title()}: Error - {e}")


def demonstrate_practical_workflow():
    """Demonstrate a practical workflow using the LLM module."""
    print_section("Practical Workflow Example")

    # Environment-based configuration
    bedrock_config = LLMConfig(
        provider="bedrock",
        model_name=os.getenv("BEDROCK_MODEL", "anthropic.claude-3-haiku-20240307-v1:0"),
        framework=os.getenv("FRAMEWORK", "langchain"),
        parameters=LLMParameters(),
        region=os.getenv("AWS_REGION", "us-east-1"),
    )

    openai_config = LLMConfig(
        provider="openai",
        model_name=os.getenv("OPENAI_MODEL", "gpt-4o"),
        framework=os.getenv("FRAMEWORK", "langchain"),
        parameters=LLMParameters(),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )

    # Dynamic framework selection
    def create_llm_client(provider: str, framework: str, model: str):
        if provider == "bedrock":
            return LLMClientFactory.create_client(
                LLMConfig(
                    provider="bedrock",
                    model_name=model,
                    framework=framework,
                    parameters=LLMParameters(),
                    region="us-east-1",
                )
            )
        elif provider == "openai":
            return LLMClientFactory.create_client(
                LLMConfig(
                    provider="openai",
                    model_name=model,
                    framework=framework,
                    parameters=LLMParameters(),
                    api_key=os.getenv("OPENAI_API_KEY", ""),
                )
            )

    # Use the function
    client = create_llm_client("bedrock", "langchain", "claude-3-haiku")
    print("Created client:", type(client).__name__)

    # Error recovery
    def create_client_with_fallback(config):
        try:
            return LLMClientFactory.create_client(config)
        except LLMError as e:
            print(f"Primary config failed: {e}")
            # Try with different framework
            if config.framework == "langchain":
                config.framework = "llamaindex"
            else:
                config.framework = "langchain"
            return LLMClientFactory.create_client(config)

    # Test fallback
    fallback_client = create_client_with_fallback(bedrock_config)
    print("Fallback client:", type(fallback_client).__name__)


def demonstrate_new_interface():
    """Demonstrate the new simplified interface."""
    print_section("New Simplified Interface")

    # Show available providers
    print("Available providers:", LLMConfig.get_available_providers())

    # Simple usage examples
    print("\n--- Simple Usage Examples ---")

    # Bedrock with automatic config
    bedrock_config = LLMConfig("bedrock", "claude-3-sonnet", region="us-west-2")
    print(f"Bedrock config - Region: {bedrock_config.provider_config.region}")

    # OpenAI with automatic config
    openai_config = LLMConfig(
        "openai", "gpt-4", api_key="sk-test", base_url="https://api.openai.com/v1"
    )
    print(f"OpenAI config - API Key: {openai_config.provider_config.api_key[:8]}...")
    print(f"OpenAI config - Base URL: {openai_config.provider_config.base_url}")

    # Explicit provider config (when you need full control)
    explicit_config = LLMConfig(
        "bedrock",
        "claude-3-sonnet",
        provider_config=BedrockProviderConfig(
            region="us-west-2", profile_name="my-profile"
        ),
    )
    print(f"Explicit config - Profile: {explicit_config.provider_config.profile_name}")


def main():
    """Run all usage examples."""
    print("Axolotl LLM Module - Comprehensive Usage Example")
    print("=" * 60)

    try:
        demonstrate_basic_usage()
        demonstrate_framework_switching()
        demonstrate_provider_switching()
        demonstrate_direct_framework_usage()
        demonstrate_error_handling()
        demonstrate_system_information()
        demonstrate_practical_workflow()
        demonstrate_new_interface()

        print_section("Summary")
        print("All examples completed successfully!")
        print("The LLM module provides:")
        print("- Easy framework switching (LangChain ↔ LlamaIndex)")
        print("- Easy provider switching (Bedrock ↔ OpenAI)")
        print("- Direct access to framework clients")
        print("- Simple configuration management")
        print("- Robust error handling")
        print("- Clean, maintainable code")
        print("- Extensible provider registry")

    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

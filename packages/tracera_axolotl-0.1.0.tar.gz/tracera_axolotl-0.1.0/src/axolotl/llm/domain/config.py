"""Simplified configuration models for LLM clients using composition pattern."""

import os
from typing import Any, Literal, Union, Type, Dict, Callable, Optional
from pydantic import BaseModel, Field


class LLMParameters(BaseModel):
    """Common LLM parameters used across all providers."""

    temperature: float = Field(
        default=0.7, ge=0.0, le=1.0, description="Sampling temperature"
    )
    max_tokens: int = Field(default=512, gt=0, description="Maximum tokens to generate")
    top_p: float = Field(default=0.9, ge=0.0, le=1.0, description="Top-p sampling")


class ProviderConfigRegistry:
    """Registry for provider configurations with automatic selection."""

    _providers: Dict[str, Type[BaseModel]] = {}

    @classmethod
    def register(cls, provider: str) -> Callable[[Type[BaseModel]], Type[BaseModel]]:
        """
        Decorator to register a provider configuration class.

        Args:
            provider: The provider name (e.g., "bedrock", "openai")

        Returns:
            Decorator function
        """

        def decorator(config_class: Type[BaseModel]) -> Type[BaseModel]:
            cls._providers[provider] = config_class
            return config_class

        return decorator

    @classmethod
    def create_config(cls, provider: str, **kwargs: Any) -> BaseModel:
        """
        Create a provider configuration instance.

        Args:
            provider: The provider name
            **kwargs: Configuration parameters

        Returns:
            Provider configuration instance
        """
        if provider not in cls._providers:
            available = ", ".join(cls._providers.keys())
            raise ValueError(
                f"Unsupported provider: {provider}. Available providers: {available}"
            )

        config_class = cls._providers[provider]
        return config_class(**kwargs)

    @classmethod
    def get_available_providers(cls) -> list[str]:
        """Get list of available providers."""
        return list(cls._providers.keys())


# Register provider configurations
@ProviderConfigRegistry.register("bedrock")
class BedrockProviderConfig(BaseModel):
    """Bedrock-specific provider configuration."""

    region: str = Field(
        default_factory=lambda: os.getenv("AWS_REGION", "us-east-1"),
        description="AWS region",
    )
    access_key_id: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_ACCESS_KEY_ID"),
        description="AWS access key ID",
    )
    secret_access_key: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_SECRET_ACCESS_KEY"),
        description="AWS secret access key",
    )
    session_token: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_SESSION_TOKEN"),
        description="AWS session token",
    )
    profile_name: Optional[str] = Field(
        default_factory=lambda: os.getenv("AWS_PROFILE"), description="AWS profile name"
    )


@ProviderConfigRegistry.register("openai")
class OpenAIProviderConfig(BaseModel):
    """OpenAI-specific provider configuration."""

    api_key: str = Field(
        default_factory=lambda: os.getenv("OPENAI_API_KEY", ""),
        description="OpenAI API key",
    )
    base_url: Optional[str] = Field(
        default_factory=lambda: os.getenv("OPENAI_BASE_URL"),
        description="OpenAI base URL",
    )


class LLMConfig(BaseModel):
    """Unified configuration for LLM clients using composition."""

    # Core identification
    provider: Literal["bedrock", "openai"] = Field(..., description="LLM provider")
    framework: Literal["langchain", "llamaindex", "direct"] = Field(
        default="langchain", description="Framework to use"
    )
    model_name: str = Field(..., description="Model name")

    # Composed components
    parameters: LLMParameters = Field(
        default_factory=LLMParameters, description="Common LLM parameters"
    )
    provider_config: Union[BedrockProviderConfig, OpenAIProviderConfig] = Field(
        ..., description="Provider-specific configuration"
    )

    # Framework-specific options
    framework_options: dict[str, Any] = Field(
        default_factory=dict, description="Framework-specific options"
    )

    def __init__(
        self,
        provider: Literal["bedrock", "openai"],
        model_name: str,
        framework: Literal["langchain", "llamaindex", "direct"] = "langchain",
        parameters: Optional[LLMParameters] = None,
        framework_options: Optional[dict[str, Any]] = None,
        provider_config: Optional[
            Union[BedrockProviderConfig, OpenAIProviderConfig]
        ] = None,
        **provider_kwargs: Any,
    ):
        """
        Initialize LLMConfig with automatic provider config selection.

        Args:
            provider: The LLM provider ("bedrock" or "openai")
            model_name: The model name to use
            framework: The framework to use (default: "langchain")
            parameters: Common LLM parameters (optional)
            framework_options: Framework-specific options (optional)
            provider_config: Explicit provider config (optional)
            **provider_kwargs: Provider-specific configuration parameters

        Examples:
            # Automatic provider config selection
            config = LLMConfig("bedrock", "claude-3-sonnet", region="us-west-2")

            # Explicit provider config
            config = LLMConfig("bedrock", "claude-3-sonnet",
                             provider_config=BedrockProviderConfig(region="us-west-2"))

            # OpenAI with custom parameters
            config = LLMConfig("openai", "gpt-4", api_key="sk-...", base_url="https://api.openai.com/v1")
        """
        # Set defaults
        if parameters is None:
            parameters = LLMParameters()
        if framework_options is None:
            framework_options = {}

        # Handle provider config
        if provider_config is not None:
            # Use explicit provider config
            if provider_kwargs:
                raise ValueError(
                    "Cannot provide both provider_config and provider_kwargs"
                )
        else:
            # Auto-create provider config from kwargs using registry
            created_config = ProviderConfigRegistry.create_config(
                provider, **provider_kwargs
            )
            # Type assertion since we know the registry returns the correct type
            provider_config = created_config  # type: ignore[assignment]

        super().__init__(
            provider=provider,
            framework=framework,
            model_name=model_name,
            parameters=parameters,
            provider_config=provider_config,
            framework_options=framework_options,
        )

    @classmethod
    def get_available_providers(cls) -> list[str]:
        """Get list of available providers."""
        return ProviderConfigRegistry.get_available_providers()

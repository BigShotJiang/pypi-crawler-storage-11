"""
Axolotl LLM Module

A framework-agnostic LLM client library that provides a unified interface
for working with different LLM providers and frameworks.

Key Features:
- Framework agnostic (LangChain, LlamaIndex, Direct)
- Provider agnostic (Bedrock, OpenAI, and more)
- Easy configuration management
- Automatic provider config selection
- Extensible provider registry
- Type-safe configuration

Usage:
    from axolotl.llm import LLMConfig, LLMClientFactory

    # Simple usage with automatic provider config selection
    config = LLMConfig("bedrock", "claude-3-sonnet", region="us-west-2")
    client = LLMClientFactory.create_client(config)

    # Use with LangChain
    result = client.invoke("Hello, world!")

    # Switch frameworks
    config.framework = "llamaindex"
    client = LLMClientFactory.create_client(config)
    result = client.complete("Hello, world!")
"""

from .domain.config import (
    LLMConfig,
    LLMParameters,
    BedrockProviderConfig,
    OpenAIProviderConfig,
    ProviderConfigRegistry,
)
from .adapters.factory import LLMClientFactory
from .exceptions import LLMError

__all__ = [
    # Configuration
    "LLMConfig",
    "LLMParameters",
    "BedrockProviderConfig",
    "OpenAIProviderConfig",
    "ProviderConfigRegistry",
    # Client Factory
    "LLMClientFactory",
    # Exceptions
    "LLMError",
]

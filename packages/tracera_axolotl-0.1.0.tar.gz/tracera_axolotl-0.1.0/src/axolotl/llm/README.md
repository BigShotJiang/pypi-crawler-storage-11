# LLM Module

A simplified, framework-agnostic LLM system that makes it easy to switch between providers and frameworks while returning underlying framework clients for direct use.

## Overview

This module provides a clean, simple interface for creating LLM clients from different providers and frameworks. The main goal is to make switching between providers and frameworks easy while returning the actual framework clients for direct use.

### Key Features

- **Easy Framework Switching**: Switch between LangChain and LlamaIndex with the same configuration
- **Easy Provider Switching**: Switch between Bedrock and OpenAI with the same framework
- **Direct Client Access**: Returns underlying framework clients (ChatBedrock, BedrockConverse, etc.)
- **Simple Configuration**: Unified configuration models for all providers
- **Decorator-Based Registration**: Clean adapter registration system
- **Type Safety**: Full type hints and Pydantic validation
- **Graceful Dependencies**: Clear error messages for missing dependencies
- **No Over-Wrapping**: Minimal abstraction, maximum flexibility

### Supported Providers & Frameworks

- ✅ **AWS Bedrock** (via LangChain and LlamaIndex)
- ✅ **OpenAI** (via LangChain and LlamaIndex)

## Quick Start

```python
from axolotl.llm import LLMClientFactory, BedrockConfig

# Create a Bedrock client with LangChain
config = BedrockConfig(
    model_name="anthropic.claude-3-sonnet-20240229-v1:0",
    framework="langchain",
    region="us-east-1"
)
client = LLMClientFactory.create_client(config)

# Use with LangChain directly
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

prompt = PromptTemplate(input_variables=["topic"], template="Write about {topic}")
chain = LLMChain(llm=client, prompt=prompt)
result = chain.run(topic="AI")

# Switch to LlamaIndex easily
config.framework = "llamaindex"
llamaindex_client = LLMClientFactory.create_client(config)

# Use with LlamaIndex directly
from llama_index.core.query_engine import BaseQueryEngine
# ... use llamaindex_client
```

## Architecture

### Core Components

1. **Simplified Configuration Models** (`domain/config.py`)
   - `LLMConfig` - Base configuration class
   - `BedrockConfig` - Bedrock-specific configuration
   - `OpenAIConfig` - OpenAI-specific configuration

2. **Registry System** (`adapters/registry.py`)
   - Decorator-based adapter registration
   - Automatic discovery of supported combinations
   - Clean separation of concerns

3. **Base Adapter Interface** (`adapters/base.py`)
   - `BaseLLMAdapter` - Abstract base class
   - Defines contract: `create_client()`, `provider`, `framework`

4. **Factory** (`adapters/factory.py`)
   - `LLMClientFactory` - Simple factory for creating clients
   - Error handling for unsupported combinations

### Adapter Structure

```
adapters/
├── base.py              # Base adapter interface
├── factory.py           # Client factory
├── registry.py          # Registry system
├── langchain/           # LangChain adapters
│   ├── bedrock.py       # Bedrock + LangChain
│   └── openai.py        # OpenAI + LangChain
└── llamaindex/          # LlamaIndex adapters
    ├── bedrock.py       # Bedrock + LlamaIndex
    └── openai.py        # OpenAI + LlamaIndex
```

## Supported Combinations

| Provider | Framework | Adapter | Returns |
|----------|-----------|---------|---------|
| bedrock | langchain | LangChainBedrockAdapter | `ChatBedrock` |
| bedrock | llamaindex | LlamaIndexBedrockAdapter | `BedrockConverse` |
| openai | langchain | LangChainOpenAIAdapter | `ChatOpenAI` |
| openai | llamaindex | LlamaIndexOpenAIAdapter | `OpenAI` |

## Configuration

### Bedrock Configuration

```python
from axolotl.llm import BedrockConfig

config = BedrockConfig(
    model_name="anthropic.claude-3-sonnet-20240229-v1:0",
    framework="langchain",  # or "llamaindex"
    region="us-east-1",
    temperature=0.7,
    max_tokens=1000,
    top_p=0.9
)
```

### OpenAI Configuration

```python
from axolotl.llm import OpenAIConfig

config = OpenAIConfig(
    model_name="gpt-4",
    framework="langchain",  # or "llamaindex"
    api_key="your-api-key"  # pragma: allowlist secret,  # pragma: allowlist secret
    temperature=0.7,
    max_tokens=1000
)
```

### Environment Variables

The configuration supports loading from environment variables:

**Bedrock:**
- `AWS_REGION` or `AWS_DEFAULT_REGION`
- `AWS_ACCESS_KEY_ID`
- `AWS_SECRET_ACCESS_KEY`
- `AWS_SESSION_TOKEN`
- `AWS_PROFILE`

**OpenAI:**
- `OPENAI_API_KEY`
- `OPENAI_BASE_URL`

## Usage Examples

### Basic Usage

```python
from axolotl.llm import LLMClientFactory, BedrockConfig

# Create a client
config = BedrockConfig(
    model_name="anthropic.claude-3-sonnet-20240229-v1:0",
    framework="langchain",
    region="us-east-1"
)
client = LLMClientFactory.create_client(config)

# Use with LangChain
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

prompt = PromptTemplate(input_variables=["topic"], template="Write about {topic}")
chain = LLMChain(llm=client, prompt=prompt)
result = chain.run(topic="AI")
```

### Framework Switching

```python
# Same config, different frameworks
config = BedrockConfig(
    model_name="anthropic.claude-3-sonnet-20240229-v1:0",
    region="us-east-1"
)

# LangChain
config.framework = "langchain"
langchain_client = LLMClientFactory.create_client(config)

# LlamaIndex
config.framework = "llamaindex"
llamaindex_client = LLMClientFactory.create_client(config)

# Use with frameworks directly
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

prompt = PromptTemplate(input_variables=["topic"], template="Write about {topic}")
chain = LLMChain(llm=langchain_client, prompt=prompt)
result = chain.run(topic="AI")
```

### Provider Switching

```python
# Bedrock
bedrock_config = BedrockConfig(
    model_name="anthropic.claude-3-sonnet-20240229-v1:0",
    framework="langchain",
    region="us-east-1"
)
bedrock_client = LLMClientFactory.create_client(bedrock_config)

# OpenAI
openai_config = OpenAIConfig(
    model_name="gpt-4",
    framework="langchain",
    api_key="your-api-key"  # pragma: allowlist secret
)
openai_client = LLMClientFactory.create_client(openai_config)
```

### CLI Demo

The module includes a comprehensive CLI tool for testing and demonstration:

```bash
# List all available adapters
python cli_demo.py list-adapters

# Test specific adapters
python cli_demo.py test-bedrock --framework langchain
python cli_demo.py test-openai --framework llamaindex

# Demonstrate framework switching
python cli_demo.py switch-frameworks --provider bedrock

# Demonstrate provider switching
python cli_demo.py switch-providers --framework langchain

# Test error handling
python cli_demo.py test-error-handling

# Show usage examples
python cli_demo.py show-usage-examples
```

### System Information

```python
from axolotl.llm import LLMClientFactory

# Get supported combinations
combinations = LLMClientFactory.get_supported_combinations()
print(f"Supported combinations: {combinations}")

# Get supported providers
providers = LLMClientFactory.get_supported_providers()
print(f"Supported providers: {providers}")

# Get supported frameworks
frameworks = LLMClientFactory.get_supported_frameworks()
print(f"Supported frameworks: {frameworks}")
```


## Error Handling

The module provides comprehensive error handling:

```python
from axolotl.llm import LLMClientFactory, BedrockConfig
from axolotl.llm.exceptions import LLMError

try:
    config = BedrockConfig(
        model_name="test",
        framework="direct"  # Unsupported combination
    )
    client = LLMClientFactory.create_client(config)
except LLMError as e:
    print(f"Error: {e}")
```

### Common Error Scenarios

- **Unsupported Combinations**: Clear error when provider-framework combination isn't supported
- **Missing Dependencies**: Helpful error messages with installation instructions
- **Invalid Configuration**: Pydantic validation errors for invalid config values
- **Import Errors**: Graceful handling when framework dependencies aren't installed

## Extending the Module

### Adding New Adapters

To add a new adapter:

1. Create adapter file in appropriate framework directory
2. Use decorator registration: `@LLMAdapterRegistry.register("provider", "framework")`
3. Implement `BaseLLMAdapter` interface
4. Add to framework `__init__.py`
5. Add to main adapters `__init__.py`

Example:
```python
@LLMAdapterRegistry.register("cohere", "langchain")
class LangChainCohereAdapter(BaseLLMAdapter):
    # Implementation
```

### Adding New Providers

1. Add provider to `LLMConfig` Literal type
2. Add provider-specific config field
3. Create provider-specific config class
4. Implement adapters for each framework

## Benefits

### 1. **Simplicity**
- No complex abstraction layers
- Direct access to framework clients
- Minimal learning curve

### 2. **Flexibility**
- Easy to switch between frameworks
- Easy to switch between providers
- Access to all framework features

### 3. **Maintainability**
- Clean, simple codebase
- Easy to add new adapters
- Clear separation of concerns

### 4. **Extensibility**
- Decorator-based registration
- Easy to add new providers
- Easy to add new frameworks

## Future Enhancements

- **Direct Adapters** - Provider-specific direct clients (e.g., `provider="openai"`, `framework="openai"`)
- **Additional Providers** - Cohere, Hugging Face, etc.
- **Streaming Support** - Built-in streaming capabilities
- **Async Support** - Asynchronous client creation

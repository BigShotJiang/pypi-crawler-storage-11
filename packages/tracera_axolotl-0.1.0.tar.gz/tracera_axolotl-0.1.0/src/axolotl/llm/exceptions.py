"""LLM-specific exceptions."""

from typing import Any, Optional


class LLMError(Exception):
    """Base exception for LLM operations."""

    def __init__(self, message: str, details: Optional[Any] = None) -> None:
        self.message = message
        self.details = details
        super().__init__(message)

    def __str__(self) -> str:
        if self.details is not None:
            return f"{self.message} (Details: {self.details})"
        return self.message

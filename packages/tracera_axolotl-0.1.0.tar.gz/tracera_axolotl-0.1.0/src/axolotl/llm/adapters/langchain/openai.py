"""OpenAI adapter using LangChain."""

from typing import Any
from ...domain.config import LLMConfig, OpenAIProviderConfig
from ..registry import LLMAdapterRegistry
from ..base import BaseLLMAdapter

try:
    from langchain_openai import ChatOpenAI
except ImportError:
    ChatOpenAI = None


@LLMAdapterRegistry.register("openai", "langchain")
class LangChainOpenAIAdapter(BaseLLMAdapter):
    """OpenAI adapter using LangChain."""

    @property
    def provider(self) -> str:
        return "openai"

    @property
    def framework(self) -> str:
        return "langchain"

    def create_client(self, config: LLMConfig) -> Any:
        """Create LangChain ChatOpenAI client."""
        if ChatOpenAI is None:
            raise ImportError(
                "langchain_openai is required but not installed. Install it with: pip install langchain-openai"
            )

        # Extract provider config (should be OpenAIProviderConfig)
        provider_config = config.provider_config

        if not isinstance(provider_config, OpenAIProviderConfig):
            raise ValueError(
                f"Expected OpenAIProviderConfig, got {type(provider_config)}"
            )

        openai_kwargs = {
            "model": config.model_name,
            "temperature": config.parameters.temperature,
            "max_tokens": config.parameters.max_tokens,
        }

        # Always set api_key and base_url from provider config
        if provider_config.api_key:
            openai_kwargs["api_key"] = provider_config.api_key
        if provider_config.base_url:
            openai_kwargs["base_url"] = provider_config.base_url

        if config.framework_options:
            openai_kwargs.update(config.framework_options)

        return ChatOpenAI(**openai_kwargs)

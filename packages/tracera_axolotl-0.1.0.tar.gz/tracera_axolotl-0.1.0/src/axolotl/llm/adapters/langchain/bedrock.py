"""AWS Bedrock LLM adapter using LangChain."""

from typing import Any
from ...domain.config import LLMConfig, BedrockProviderConfig
from ..registry import LLMAdapterRegistry
from ..base import BaseLLMAdapter

try:
    from langchain_aws import ChatBedrock
except ImportError:
    ChatBedrock = None


@LLMAdapterRegistry.register("bedrock", "langchain")
class LangChainBedrockAdapter(BaseLLMAdapter):
    """Bedrock adapter using LangChain."""

    @property
    def provider(self) -> str:
        return "bedrock"

    @property
    def framework(self) -> str:
        return "langchain"

    def create_client(self, config: LLMConfig) -> Any:
        """Create LangChain ChatBedrock client."""
        if ChatBedrock is None:
            raise ImportError(
                "langchain_aws is required but not installed. Install it with: pip install langchain-aws"
            )

        # Extract provider config (should be BedrockProviderConfig)
        provider_config = config.provider_config

        if not isinstance(provider_config, BedrockProviderConfig):
            raise ValueError(
                f"Expected BedrockProviderConfig, got {type(provider_config)}"
            )

        bedrock_kwargs = {
            "model_id": config.model_name,
            "region_name": provider_config.region,
            "temperature": config.parameters.temperature,
            "max_tokens": config.parameters.max_tokens,
        }

        if provider_config.profile_name:
            bedrock_kwargs["credentials_profile_name"] = provider_config.profile_name
        elif provider_config.access_key_id and provider_config.secret_access_key:
            bedrock_kwargs["aws_access_key_id"] = provider_config.access_key_id
            bedrock_kwargs["aws_secret_access_key"] = provider_config.secret_access_key
            if provider_config.session_token:
                bedrock_kwargs["aws_session_token"] = provider_config.session_token

        # Add model kwargs
        model_kwargs = {
            "top_p": config.parameters.top_p,
        }
        if config.framework_options:
            model_kwargs.update(config.framework_options)

        if model_kwargs:
            bedrock_kwargs["model_kwargs"] = model_kwargs

        return ChatBedrock(**bedrock_kwargs)

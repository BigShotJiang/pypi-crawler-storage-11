"""Registry for LLM adapters."""

from typing import Dict, Type, Callable
from .base import BaseLLMAdapter


class LLMAdapterRegistry:
    """Registry for LLM adapters."""

    _adapters: Dict[str, Type[BaseLLMAdapter]] = {}

    @classmethod
    def register(
        cls, provider: str, framework: str
    ) -> Callable[[Type[BaseLLMAdapter]], Type[BaseLLMAdapter]]:
        """Decorator to register an LLM adapter.

        Args:
            provider: Provider name (e.g., "bedrock", "openai")
            framework: Framework name (e.g., "langchain", "llamaindex")

        Returns:
            Decorator function
        """

        def decorator(adapter_class: Type[BaseLLMAdapter]) -> Type[BaseLLMAdapter]:
            key = f"{provider.lower()}:{framework.lower()}"
            cls._adapters[key] = adapter_class
            return adapter_class

        return decorator

    @classmethod
    def get_adapter(cls, provider: str, framework: str) -> Type[BaseLLMAdapter]:
        """Get an adapter class.

        Args:
            provider: Provider name
            framework: Framework name

        Returns:
            Adapter class

        Raises:
            KeyError: If adapter not found
        """
        key = f"{provider.lower()}:{framework.lower()}"
        if key not in cls._adapters:
            available = list(cls._adapters.keys())
            raise KeyError(
                f"No adapter found for {provider}:{framework}. Available: {available}"
            )
        return cls._adapters[key]

    @classmethod
    def list_adapters(cls) -> Dict[str, Type[BaseLLMAdapter]]:
        """List all registered adapters."""
        return cls._adapters.copy()

    @classmethod
    def get_supported_providers(cls) -> list[str]:
        """Get list of supported providers."""
        providers = set()
        for key in cls._adapters.keys():
            provider, _ = key.split(":", 1)
            providers.add(provider)
        return list(providers)

    @classmethod
    def get_supported_frameworks(cls) -> list[str]:
        """Get list of supported frameworks."""
        frameworks = set()
        for key in cls._adapters.keys():
            _, framework = key.split(":", 1)
            frameworks.add(framework)
        return list(frameworks)

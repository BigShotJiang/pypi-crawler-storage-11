"""Factory for creating LLM clients."""

from typing import Any
from ..domain.config import LLMConfig
from .registry import LLMAdapterRegistry
from ..exceptions import LLMError


class LLMClientFactory:
    """Factory for creating LLM clients."""

    @staticmethod
    def create_client(config: LLMConfig) -> Any:
        """Create an LLM client based on configuration.

        Args:
            config: LLM configuration

        Returns:
            The underlying framework client
        """
        try:
            adapter_class = LLMAdapterRegistry.get_adapter(
                config.provider, config.framework
            )
            adapter = adapter_class()
            return adapter.create_client(config)
        except KeyError as e:
            raise LLMError(
                f"Unsupported provider-framework combination: {config.provider}:{config.framework}"
            ) from e
        except Exception as e:
            raise LLMError(f"Failed to create client: {str(e)}") from e

    @staticmethod
    def get_supported_combinations() -> list[str]:
        """Get list of supported provider-framework combinations."""
        return list(LLMAdapterRegistry.list_adapters().keys())

    @staticmethod
    def get_supported_providers() -> list[str]:
        """Get list of supported providers."""
        return LLMAdapterRegistry.get_supported_providers()

    @staticmethod
    def get_supported_frameworks() -> list[str]:
        """Get list of supported frameworks."""
        return LLMAdapterRegistry.get_supported_frameworks()

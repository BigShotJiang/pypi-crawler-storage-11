"""AWS Bedrock LLM adapter using LlamaIndex."""

from typing import Any
from ...domain.config import LLMConfig, BedrockProviderConfig
from ..registry import LLMAdapterRegistry
from ..base import BaseLLMAdapter

try:
    from llama_index.llms.bedrock_converse import BedrockConverse
except ImportError:
    BedrockConverse = None


@LLMAdapterRegistry.register("bedrock", "llamaindex")
class LlamaIndexBedrockAdapter(BaseLLMAdapter):
    """Bedrock adapter using LlamaIndex."""

    @property
    def provider(self) -> str:
        return "bedrock"

    @property
    def framework(self) -> str:
        return "llamaindex"

    def create_client(self, config: LLMConfig) -> Any:
        """Create LlamaIndex BedrockConverse client."""
        if BedrockConverse is None:
            raise ImportError(
                "llama_index is required but not installed. Install it with: pip install llama-index"
            )

        # Extract provider config (should be BedrockProviderConfig)
        provider_config = config.provider_config

        if not isinstance(provider_config, BedrockProviderConfig):
            raise ValueError(
                f"Expected BedrockProviderConfig, got {type(provider_config)}"
            )

        bedrock_kwargs = {
            "model": config.model_name,
            "region_name": provider_config.region,
            "temperature": config.parameters.temperature,
            "max_tokens": config.parameters.max_tokens,
        }

        # Add optional credentials
        if provider_config.access_key_id:
            bedrock_kwargs["aws_access_key_id"] = provider_config.access_key_id
        if provider_config.secret_access_key:
            bedrock_kwargs["aws_secret_access_key"] = provider_config.secret_access_key
        if provider_config.session_token:
            bedrock_kwargs["aws_session_token"] = provider_config.session_token
        if provider_config.profile_name:
            bedrock_kwargs["profile_name"] = provider_config.profile_name

        # Add additional kwargs
        additional_kwargs = {
            "inferenceConfig": {
                "topP": config.parameters.top_p,
            }
        }
        if config.framework_options:
            additional_kwargs.update(config.framework_options)

        if additional_kwargs:
            bedrock_kwargs["additional_kwargs"] = additional_kwargs

        return BedrockConverse(**bedrock_kwargs)

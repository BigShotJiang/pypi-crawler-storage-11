"""OpenAI adapter using LlamaIndex."""

from typing import Any
from ...domain.config import LLMConfig, OpenAIProviderConfig
from ..registry import LLMAdapterRegistry
from ..base import BaseLLMAdapter

try:
    from llama_index.llms.openai import OpenAI
except ImportError:
    OpenAI = None


@LLMAdapterRegistry.register("openai", "llamaindex")
class LlamaIndexOpenAIAdapter(BaseLLMAdapter):
    """OpenAI adapter using LlamaIndex."""

    @property
    def provider(self) -> str:
        return "openai"

    @property
    def framework(self) -> str:
        return "llamaindex"

    def create_client(self, config: LLMConfig) -> Any:
        """Create LlamaIndex OpenAI client."""
        if OpenAI is None:
            raise ImportError(
                "llama_index is required but not installed. Install it with: pip install llama-index"
            )

        # Extract provider config (should be OpenAIProviderConfig)
        provider_config = config.provider_config

        if not isinstance(provider_config, OpenAIProviderConfig):
            raise ValueError(
                f"Expected OpenAIProviderConfig, got {type(provider_config)}"
            )

        openai_kwargs = {
            "model": config.model_name,
            "temperature": config.parameters.temperature,
            "max_tokens": config.parameters.max_tokens,
        }

        if provider_config.api_key:
            openai_kwargs["api_key"] = provider_config.api_key
        if provider_config.base_url:
            openai_kwargs["base_url"] = provider_config.base_url

        if config.framework_options:
            openai_kwargs.update(config.framework_options)

        return OpenAI(**openai_kwargs)

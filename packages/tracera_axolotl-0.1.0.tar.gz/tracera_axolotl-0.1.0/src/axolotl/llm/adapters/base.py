"""Base adapter interface for LLM clients."""

from abc import ABC, abstractmethod
from typing import Any
from ..domain.config import LLMConfig


class BaseLLMAdapter(ABC):
    """Base class for LLM adapters."""

    @abstractmethod
    def create_client(self, config: LLMConfig) -> Any:
        """Create the underlying framework client.

        Args:
            config: LLM configuration

        Returns:
            The underlying framework client
        """
        pass

    @property
    @abstractmethod
    def provider(self) -> str:
        """Get the provider name."""
        pass

    @property
    @abstractmethod
    def framework(self) -> str:
        """Get the framework name."""
        pass

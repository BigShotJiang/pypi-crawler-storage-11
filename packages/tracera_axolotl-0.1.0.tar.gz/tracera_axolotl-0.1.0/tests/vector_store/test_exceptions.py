"""Tests for vector store exceptions."""

from axolotl.vector_store.exceptions import (
    VectorStoreError,
    DocumentError,
    IndexError,
    QueryError,
    EmbeddingError,
    DocumentNotFoundError,
    DocumentValidationError,
    DuplicateDocumentError,
    IndexNotFoundError,
    IndexAlreadyExistsError,
    IndexConfigurationError,
    InvalidQueryError,
    QueryTimeoutError,
    QueryExecutionError,
    EmbeddingDimensionMismatchError,
    EmbeddingGenerationError,
    MissingEmbeddingError,
    ConnectionError,
    AuthenticationError,
    PermissionError,
)


class TestVectorStoreError:
    """Test cases for VectorStoreError base class."""

    def test_vector_store_error_creation_with_message_only(self):
        """Test VectorStoreError creation with message only."""
        error = VectorStoreError("Test error message")

        assert error.message == "Test error message"
        assert error.details is None
        assert str(error) == "Test error message"

    def test_vector_store_error_creation_with_details(self):
        """Test VectorStoreError creation with message and details."""
        details = {"key": "value", "number": 42}
        error = VectorStoreError("Test error message", details)

        assert error.message == "Test error message"
        assert error.details == details
        assert (
            str(error) == "Test error message (Details: {'key': 'value', 'number': 42})"
        )

    def test_vector_store_error_inheritance(self):
        """Test that VectorStoreError inherits from Exception."""
        error = VectorStoreError("Test")
        assert isinstance(error, Exception)

    def test_vector_store_error_str_with_none_details(self):
        """Test string representation with None details."""
        error = VectorStoreError("Test message", None)
        assert str(error) == "Test message"

    def test_vector_store_error_str_with_empty_details(self):
        """Test string representation with empty details."""
        error = VectorStoreError("Test message", {})
        assert str(error) == "Test message"  # Empty details are not shown

    def test_vector_store_error_str_with_complex_details(self):
        """Test string representation with complex details."""
        details = {"nested": {"key": "value"}, "list": [1, 2, 3], "string": "test"}
        error = VectorStoreError("Test message", details)
        expected = "Test message (Details: {'nested': {'key': 'value'}, 'list': [1, 2, 3], 'string': 'test'})"
        assert str(error) == expected


class TestDocumentError:
    """Test cases for DocumentError."""

    def test_document_error_inheritance(self):
        """Test that DocumentError inherits from VectorStoreError."""
        error = DocumentError("Test document error")
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_document_error_creation(self):
        """Test DocumentError creation."""
        error = DocumentError("Document operation failed", {"doc_id": "test"})
        assert error.message == "Document operation failed"
        assert error.details == {"doc_id": "test"}


class TestIndexError:
    """Test cases for IndexError."""

    def test_index_error_inheritance(self):
        """Test that IndexError inherits from VectorStoreError."""
        error = IndexError("Test index error")
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_index_error_creation(self):
        """Test IndexError creation."""
        error = IndexError("Index operation failed", {"index_name": "test"})
        assert error.message == "Index operation failed"
        assert error.details == {"index_name": "test"}


class TestQueryError:
    """Test cases for QueryError."""

    def test_query_error_inheritance(self):
        """Test that QueryError inherits from VectorStoreError."""
        error = QueryError("Test query error")
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_query_error_creation(self):
        """Test QueryError creation."""
        error = QueryError("Query operation failed", {"query": "test"})
        assert error.message == "Query operation failed"
        assert error.details == {"query": "test"}


class TestEmbeddingError:
    """Test cases for EmbeddingError."""

    def test_embedding_error_inheritance(self):
        """Test that EmbeddingError inherits from VectorStoreError."""
        error = EmbeddingError("Test embedding error")
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_embedding_error_creation(self):
        """Test EmbeddingError creation."""
        error = EmbeddingError("Embedding operation failed", {"model": "test"})
        assert error.message == "Embedding operation failed"
        assert error.details == {"model": "test"}


class TestDocumentNotFoundError:
    """Test cases for DocumentNotFoundError."""

    def test_document_not_found_error_with_document_id_only(self):
        """Test DocumentNotFoundError with document ID only."""
        error = DocumentNotFoundError("doc123")

        assert error.message == "Document 'doc123' not found"
        assert error.details == {"document_id": "doc123", "index_name": None}
        assert (
            str(error)
            == "Document 'doc123' not found (Details: {'document_id': 'doc123', 'index_name': None})"
        )

    def test_document_not_found_error_with_index_name(self):
        """Test DocumentNotFoundError with document ID and index name."""
        error = DocumentNotFoundError("doc123", "test_index")

        assert error.message == "Document 'doc123' not found in index 'test_index'"
        assert error.details == {"document_id": "doc123", "index_name": "test_index"}

    def test_document_not_found_error_inheritance(self):
        """Test that DocumentNotFoundError inherits from DocumentError."""
        error = DocumentNotFoundError("doc123")
        assert isinstance(error, DocumentError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)


class TestDocumentValidationError:
    """Test cases for DocumentValidationError."""

    def test_document_validation_error_inheritance(self):
        """Test that DocumentValidationError inherits from DocumentError."""
        error = DocumentValidationError("Validation failed")
        assert isinstance(error, DocumentError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_document_validation_error_creation(self):
        """Test DocumentValidationError creation."""
        error = DocumentValidationError("Invalid document format", {"field": "content"})
        assert error.message == "Invalid document format"
        assert error.details == {"field": "content"}


class TestDuplicateDocumentError:
    """Test cases for DuplicateDocumentError."""

    def test_duplicate_document_error_with_document_id_only(self):
        """Test DuplicateDocumentError with document ID only."""
        error = DuplicateDocumentError("doc123")

        assert error.message == "Document 'doc123' already exists"
        assert error.details == {"document_id": "doc123", "index_name": None}

    def test_duplicate_document_error_with_index_name(self):
        """Test DuplicateDocumentError with document ID and index name."""
        error = DuplicateDocumentError("doc123", "test_index")

        assert error.message == "Document 'doc123' already exists in index 'test_index'"
        assert error.details == {"document_id": "doc123", "index_name": "test_index"}

    def test_duplicate_document_error_inheritance(self):
        """Test that DuplicateDocumentError inherits from DocumentError."""
        error = DuplicateDocumentError("doc123")
        assert isinstance(error, DocumentError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)


class TestIndexNotFoundError:
    """Test cases for IndexNotFoundError."""

    def test_index_not_found_error_creation(self):
        """Test IndexNotFoundError creation."""
        error = IndexNotFoundError("test_index")

        assert error.message == "Index 'test_index' not found"
        assert error.details == {"index_name": "test_index"}

    def test_index_not_found_error_inheritance(self):
        """Test that IndexNotFoundError inherits from IndexError."""
        error = IndexNotFoundError("test_index")
        assert isinstance(error, IndexError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)


class TestIndexAlreadyExistsError:
    """Test cases for IndexAlreadyExistsError."""

    def test_index_already_exists_error_creation(self):
        """Test IndexAlreadyExistsError creation."""
        error = IndexAlreadyExistsError("test_index")

        assert error.message == "Index 'test_index' already exists"
        assert error.details == {"index_name": "test_index"}

    def test_index_already_exists_error_inheritance(self):
        """Test that IndexAlreadyExistsError inherits from IndexError."""
        error = IndexAlreadyExistsError("test_index")
        assert isinstance(error, IndexError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)


class TestIndexConfigurationError:
    """Test cases for IndexConfigurationError."""

    def test_index_configuration_error_inheritance(self):
        """Test that IndexConfigurationError inherits from IndexError."""
        error = IndexConfigurationError("Configuration failed")
        assert isinstance(error, IndexError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_index_configuration_error_creation(self):
        """Test IndexConfigurationError creation."""
        error = IndexConfigurationError("Invalid configuration", {"setting": "value"})
        assert error.message == "Invalid configuration"
        assert error.details == {"setting": "value"}


class TestInvalidQueryError:
    """Test cases for InvalidQueryError."""

    def test_invalid_query_error_inheritance(self):
        """Test that InvalidQueryError inherits from QueryError."""
        error = InvalidQueryError("Invalid query")
        assert isinstance(error, QueryError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_invalid_query_error_creation(self):
        """Test InvalidQueryError creation."""
        error = InvalidQueryError("Query is invalid", {"param": "value"})
        assert error.message == "Query is invalid"
        assert error.details == {"param": "value"}


class TestQueryTimeoutError:
    """Test cases for QueryTimeoutError."""

    def test_query_timeout_error_with_timeout_only(self):
        """Test QueryTimeoutError with timeout only."""
        error = QueryTimeoutError(30.5)

        assert error.message == "Query timed out after 30.5 seconds"
        assert error.details == {"timeout_seconds": 30.5, "query_type": None}

    def test_query_timeout_error_with_query_type(self):
        """Test QueryTimeoutError with timeout and query type."""
        error = QueryTimeoutError(60.0, "search")

        assert error.message == "search query timed out after 60.0 seconds"
        assert error.details == {"timeout_seconds": 60.0, "query_type": "search"}

    def test_query_timeout_error_inheritance(self):
        """Test that QueryTimeoutError inherits from QueryError."""
        error = QueryTimeoutError(30.0)
        assert isinstance(error, QueryError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)


class TestQueryExecutionError:
    """Test cases for QueryExecutionError."""

    def test_query_execution_error_inheritance(self):
        """Test that QueryExecutionError inherits from QueryError."""
        error = QueryExecutionError("Execution failed")
        assert isinstance(error, QueryError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_query_execution_error_creation(self):
        """Test QueryExecutionError creation."""
        error = QueryExecutionError("Query execution failed", {"error_code": 500})
        assert error.message == "Query execution failed"
        assert error.details == {"error_code": 500}


class TestEmbeddingDimensionMismatchError:
    """Test cases for EmbeddingDimensionMismatchError."""

    def test_embedding_dimension_mismatch_error_creation(self):
        """Test EmbeddingDimensionMismatchError creation."""
        error = EmbeddingDimensionMismatchError(384, 512)

        assert error.message == "Embedding dimension mismatch: expected 384, got 512"
        assert error.details == {"expected_dimension": 384, "actual_dimension": 512}

    def test_embedding_dimension_mismatch_error_inheritance(self):
        """Test that EmbeddingDimensionMismatchError inherits from EmbeddingError."""
        error = EmbeddingDimensionMismatchError(384, 512)
        assert isinstance(error, EmbeddingError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)


class TestEmbeddingGenerationError:
    """Test cases for EmbeddingGenerationError."""

    def test_embedding_generation_error_inheritance(self):
        """Test that EmbeddingGenerationError inherits from EmbeddingError."""
        error = EmbeddingGenerationError("Generation failed")
        assert isinstance(error, EmbeddingError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_embedding_generation_error_creation(self):
        """Test EmbeddingGenerationError creation."""
        error = EmbeddingGenerationError(
            "Failed to generate embedding", {"model": "test"}
        )
        assert error.message == "Failed to generate embedding"
        assert error.details == {"model": "test"}


class TestMissingEmbeddingError:
    """Test cases for MissingEmbeddingError."""

    def test_missing_embedding_error_without_document_id(self):
        """Test MissingEmbeddingError without document ID."""
        error = MissingEmbeddingError()

        assert error.message == "Document is missing required embedding"
        assert error.details == {"document_id": None}

    def test_missing_embedding_error_with_document_id(self):
        """Test MissingEmbeddingError with document ID."""
        error = MissingEmbeddingError("doc123")

        assert error.message == "Document 'doc123' is missing required embedding"
        assert error.details == {"document_id": "doc123"}

    def test_missing_embedding_error_inheritance(self):
        """Test that MissingEmbeddingError inherits from EmbeddingError."""
        error = MissingEmbeddingError("doc123")
        assert isinstance(error, EmbeddingError)
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)


class TestConnectionError:
    """Test cases for ConnectionError."""

    def test_connection_error_inheritance(self):
        """Test that ConnectionError inherits from VectorStoreError."""
        error = ConnectionError("Connection failed")
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_connection_error_creation(self):
        """Test ConnectionError creation."""
        error = ConnectionError(
            "Failed to connect", {"host": "localhost", "port": 9200}
        )
        assert error.message == "Failed to connect"
        assert error.details == {"host": "localhost", "port": 9200}


class TestAuthenticationError:
    """Test cases for AuthenticationError."""

    def test_authentication_error_inheritance(self):
        """Test that AuthenticationError inherits from VectorStoreError."""
        error = AuthenticationError("Authentication failed")
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_authentication_error_creation(self):
        """Test AuthenticationError creation."""
        error = AuthenticationError("Invalid credentials", {"username": "user"})
        assert error.message == "Invalid credentials"
        assert error.details == {"username": "user"}


class TestPermissionError:
    """Test cases for PermissionError."""

    def test_permission_error_inheritance(self):
        """Test that PermissionError inherits from VectorStoreError."""
        error = PermissionError("Permission denied")
        assert isinstance(error, VectorStoreError)
        assert isinstance(error, Exception)

    def test_permission_error_creation(self):
        """Test PermissionError creation."""
        error = PermissionError(
            "Insufficient permissions", {"required": "write", "current": "read"}
        )
        assert error.message == "Insufficient permissions"
        assert error.details == {"required": "write", "current": "read"}


class TestExceptionHierarchy:
    """Test cases for exception hierarchy and relationships."""

    def test_exception_hierarchy_structure(self):
        """Test the overall exception hierarchy structure."""
        # Base exception
        base_error = VectorStoreError("base")
        assert isinstance(base_error, Exception)

        # Category exceptions
        doc_error = DocumentError("doc")
        index_error = IndexError("index")
        query_error = QueryError("query")
        embedding_error = EmbeddingError("embedding")

        assert isinstance(doc_error, VectorStoreError)
        assert isinstance(index_error, VectorStoreError)
        assert isinstance(query_error, VectorStoreError)
        assert isinstance(embedding_error, VectorStoreError)

        # Specific document errors
        doc_not_found = DocumentNotFoundError("doc123")
        doc_validation = DocumentValidationError("validation")
        duplicate_doc = DuplicateDocumentError("doc123")

        assert isinstance(doc_not_found, DocumentError)
        assert isinstance(doc_validation, DocumentError)
        assert isinstance(duplicate_doc, DocumentError)

        # Specific index errors
        index_not_found = IndexNotFoundError("index")
        index_exists = IndexAlreadyExistsError("index")
        index_config = IndexConfigurationError("config")

        assert isinstance(index_not_found, IndexError)
        assert isinstance(index_exists, IndexError)
        assert isinstance(index_config, IndexError)

        # Specific query errors
        invalid_query = InvalidQueryError("invalid")
        query_timeout = QueryTimeoutError(30.0)
        query_exec = QueryExecutionError("exec")

        assert isinstance(invalid_query, QueryError)
        assert isinstance(query_timeout, QueryError)
        assert isinstance(query_exec, QueryError)

        # Specific embedding errors
        dim_mismatch = EmbeddingDimensionMismatchError(384, 512)
        gen_error = EmbeddingGenerationError("gen")
        missing_embedding = MissingEmbeddingError("doc123")

        assert isinstance(dim_mismatch, EmbeddingError)
        assert isinstance(gen_error, EmbeddingError)
        assert isinstance(missing_embedding, EmbeddingError)

    def test_exception_can_be_caught_by_base_class(self):
        """Test that specific exceptions can be caught by base classes."""
        try:
            raise DocumentNotFoundError("doc123", "index")
        except VectorStoreError as e:
            assert isinstance(e, DocumentNotFoundError)
            assert e.message == "Document 'doc123' not found in index 'index'"

        try:
            raise IndexAlreadyExistsError("index")
        except VectorStoreError as e:
            assert isinstance(e, IndexAlreadyExistsError)
            assert e.message == "Index 'index' already exists"

        try:
            raise QueryTimeoutError(30.0, "search")
        except VectorStoreError as e:
            assert isinstance(e, QueryTimeoutError)
            assert "search query timed out" in e.message

    def test_exception_details_preservation(self):
        """Test that exception details are properly preserved through inheritance."""
        # Test with complex details
        _details = {
            "document_id": "doc123",
            "index_name": "test_index",
            "error_code": 404,
            "timestamp": "2023-01-01T00:00:00Z",
        }

        error = DocumentNotFoundError("doc123", "test_index")
        assert error.details["document_id"] == "doc123"
        assert error.details["index_name"] == "test_index"

        # Test with timeout details
        timeout_error = QueryTimeoutError(60.0, "search")
        assert timeout_error.details["timeout_seconds"] == 60.0
        assert timeout_error.details["query_type"] == "search"

        # Test with dimension mismatch details
        dim_error = EmbeddingDimensionMismatchError(384, 512)
        assert dim_error.details["expected_dimension"] == 384
        assert dim_error.details["actual_dimension"] == 512

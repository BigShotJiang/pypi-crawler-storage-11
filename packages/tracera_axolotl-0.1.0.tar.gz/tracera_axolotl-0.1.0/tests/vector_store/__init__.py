"""Tests for the vector store module."""

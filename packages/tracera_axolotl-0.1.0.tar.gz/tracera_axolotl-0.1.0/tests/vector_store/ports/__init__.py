"""Tests for vector store port interfaces."""

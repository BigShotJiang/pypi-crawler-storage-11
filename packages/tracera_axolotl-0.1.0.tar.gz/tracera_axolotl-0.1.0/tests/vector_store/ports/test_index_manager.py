"""Tests for IndexManagerPort interface."""

import pytest
from abc import ABC
from typing import Any

from axolotl.vector_store.ports.index_manager import IndexManagerPort


class ConcreteIndexManagerPort(IndexManagerPort):
    """Concrete implementation of IndexManagerPort for testing."""

    def create_index(self, index_name: str, **index_config: Any) -> bool:
        """Concrete implementation of create_index."""
        return True

    def delete_index(self, index_name: str) -> bool:
        """Concrete implementation of delete_index."""
        return True

    def index_exists(self, index_name: str) -> bool:
        """Concrete implementation of index_exists."""
        return False

    def list_indices(self) -> list[str]:
        """Concrete implementation of list_indices."""
        return []


class TestIndexManagerPort:
    """Test cases for IndexManagerPort interface."""

    def test_index_manager_port_is_abstract(self):
        """Test that IndexManagerPort cannot be instantiated directly."""
        with pytest.raises(TypeError):
            IndexManagerPort()

    def test_index_manager_port_has_required_methods(self):
        """Test that IndexManagerPort has all required abstract methods."""
        required_methods = [
            "create_index",
            "delete_index",
            "index_exists",
            "list_indices",
        ]

        for method_name in required_methods:
            assert hasattr(IndexManagerPort, method_name)
            method = getattr(IndexManagerPort, method_name)
            assert callable(method)

    def test_index_manager_port_methods_are_abstract(self):
        """Test that all methods in IndexManagerPort are abstract."""
        for method_name in [
            "create_index",
            "delete_index",
            "index_exists",
            "list_indices",
        ]:
            method = getattr(IndexManagerPort, method_name)
            assert getattr(method, "__isabstractmethod__", False)

    def test_concrete_implementation_can_be_instantiated(self):
        """Test that a concrete implementation can be instantiated."""
        port = ConcreteIndexManagerPort()
        assert isinstance(port, IndexManagerPort)

    def test_create_index_signature(self):
        """Test create_index method signature."""
        port = ConcreteIndexManagerPort()

        # Test with minimal parameters
        result = port.create_index("test_index")
        assert isinstance(result, bool)
        assert result is True

        # Test with additional configuration
        result = port.create_index("test_index", dimension=384, method="hnsw")
        assert isinstance(result, bool)
        assert result is True

    def test_create_index_with_various_configs(self):
        """Test create_index with various configuration parameters."""
        port = ConcreteIndexManagerPort()

        # Test with different types of configuration
        configs = [
            {},  # Empty config
            {"dimension": 384},  # Single parameter
            {
                "dimension": 512,
                "method": "hnsw",
                "engine": "faiss",
            },  # Multiple parameters
            {"nested": {"param": "value"}, "list": [1, 2, 3]},  # Complex parameters
        ]

        for config in configs:
            result = port.create_index("test_index", **config)
            assert isinstance(result, bool)

    def test_delete_index_signature(self):
        """Test delete_index method signature."""
        port = ConcreteIndexManagerPort()

        # Test with different index names
        test_names = [
            "simple_index",
            "index-with-dashes",
            "index_with_underscores",
            "index.with.dots",
        ]

        for index_name in test_names:
            result = port.delete_index(index_name)
            assert isinstance(result, bool)
            assert result is True

    def test_index_exists_signature(self):
        """Test index_exists method signature."""
        port = ConcreteIndexManagerPort()

        # Test with different index names
        test_names = ["existing_index", "non_existing_index", "special-chars-index"]

        for index_name in test_names:
            result = port.index_exists(index_name)
            assert isinstance(result, bool)
            # Our mock implementation always returns False

    def test_list_indices_signature(self):
        """Test list_indices method signature."""
        port = ConcreteIndexManagerPort()

        result = port.list_indices()
        assert isinstance(result, list)
        # Our mock implementation returns empty list

    def test_create_index_with_keyword_arguments(self):
        """Test create_index with various keyword argument patterns."""
        port = ConcreteIndexManagerPort()

        # Test with positional and keyword arguments
        result = port.create_index("test_index", dimension=384, method="hnsw")
        assert result is True

        # Test with only keyword arguments
        result = port.create_index(index_name="test_index", dimension=512)
        assert result is True

    def test_create_index_with_complex_configuration(self):
        """Test create_index with complex configuration objects."""
        port = ConcreteIndexManagerPort()

        # Test with nested dictionaries
        complex_config = {
            "mapping": {
                "properties": {
                    "content": {"type": "text"},
                    "embedding": {"type": "dense_vector", "dims": 384},
                }
            },
            "settings": {"number_of_shards": 1, "number_of_replicas": 0},
        }

        result = port.create_index("complex_index", **complex_config)
        assert result is True

    def test_create_index_with_list_and_dict_values(self):
        """Test create_index with list and dictionary values in config."""
        port = ConcreteIndexManagerPort()

        config_with_lists = {
            "shards": [1, 2, 3],
            "replicas": ["replica1", "replica2"],
            "metadata": {"tags": ["tag1", "tag2"], "nested": {"key": "value"}},
        }

        result = port.create_index("list_config_index", **config_with_lists)
        assert result is True

    def test_delete_index_with_special_characters(self):
        """Test delete_index with index names containing special characters."""
        port = ConcreteIndexManagerPort()

        special_names = [
            "index-with-dashes",
            "index_with_underscores",
            "index.with.dots",
            "index123",
            "IndexWithCaps",
            "index-with_123.mixed",
        ]

        for index_name in special_names:
            result = port.delete_index(index_name)
            assert result is True

    def test_index_exists_with_empty_string(self):
        """Test index_exists with empty string (edge case)."""
        port = ConcreteIndexManagerPort()

        result = port.index_exists("")
        assert isinstance(result, bool)

    def test_list_indices_returns_list(self):
        """Test that list_indices always returns a list."""
        port = ConcreteIndexManagerPort()

        result = port.list_indices()
        assert isinstance(result, list)
        # Even if empty, should be a list
        assert result == []

    def test_interface_inheritance(self):
        """Test that IndexManagerPort properly inherits from ABC."""
        assert issubclass(IndexManagerPort, ABC)

        # Test that it's abstract
        assert getattr(IndexManagerPort, "__abstractmethods__", None) is not None
        abstract_methods = IndexManagerPort.__abstractmethods__
        expected_methods = {
            "create_index",
            "delete_index",
            "index_exists",
            "list_indices",
        }
        assert abstract_methods == expected_methods

    def test_concrete_implementation_satisfies_interface(self):
        """Test that concrete implementation satisfies the interface contract."""
        port = ConcreteIndexManagerPort()

        # Verify all abstract methods are implemented
        for method_name in IndexManagerPort.__abstractmethods__:
            method = getattr(port, method_name)
            assert callable(method)
            assert not getattr(method, "__isabstractmethod__", False)

    def test_method_documentation_exists(self):
        """Test that all methods have proper docstrings."""
        for method_name in [
            "create_index",
            "delete_index",
            "index_exists",
            "list_indices",
        ]:
            method = getattr(IndexManagerPort, method_name)
            assert method.__doc__ is not None
            assert len(method.__doc__.strip()) > 0

    def test_method_parameter_annotations(self):
        """Test that methods have proper type annotations."""
        # Check create_index
        create_method = IndexManagerPort.create_index
        annotations = create_method.__annotations__
        assert "index_name" in annotations
        assert "return" in annotations

        # Check delete_index
        delete_method = IndexManagerPort.delete_index
        annotations = delete_method.__annotations__
        assert "index_name" in annotations
        assert "return" in annotations

        # Check index_exists
        exists_method = IndexManagerPort.index_exists
        annotations = exists_method.__annotations__
        assert "index_name" in annotations
        assert "return" in annotations

        # Check list_indices
        list_method = IndexManagerPort.list_indices
        annotations = list_method.__annotations__
        assert "return" in annotations

    def test_create_index_accepts_any_keyword_arguments(self):
        """Test that create_index accepts any keyword arguments."""
        port = ConcreteIndexManagerPort()

        # Test with various argument types
        result = port.create_index(
            "test",
            string_arg="value",
            int_arg=42,
            bool_arg=True,
            list_arg=[1, 2, 3],
            dict_arg={"key": "value"},
            none_arg=None,
        )

        assert result is True

    def test_methods_handle_edge_cases(self):
        """Test that methods handle edge cases appropriately."""
        port = ConcreteIndexManagerPort()

        # Test with very long index names
        long_name = "a" * 1000
        result = port.create_index(long_name)
        assert result is True

        result = port.delete_index(long_name)
        assert result is True

        result = port.index_exists(long_name)
        assert isinstance(result, bool)

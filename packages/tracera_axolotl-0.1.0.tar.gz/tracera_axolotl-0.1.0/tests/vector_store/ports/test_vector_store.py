"""Tests for VectorStorePort interface."""

import pytest
from abc import ABC

from axolotl.vector_store.domain.document import DocumentChunk, ScoredDocumentChunk
from axolotl.vector_store.domain.query import TextQuery
from axolotl.vector_store.ports.vector_store import VectorStorePort


class ConcreteVectorStorePort(VectorStorePort):
    """Concrete implementation of VectorStorePort for testing."""

    def add_documents(
        self, documents: list[DocumentChunk], index_name: str
    ) -> list[str]:
        """Concrete implementation of add_documents."""
        return [doc.id for doc in documents]

    def search(self, query: TextQuery, index_name: str) -> list[ScoredDocumentChunk]:
        """Concrete implementation of search."""
        return []

    def get_document(self, document_id: str, index_name: str) -> DocumentChunk:
        """Concrete implementation of get_document."""
        return DocumentChunk(id=document_id, content="test content")

    def delete_documents(self, document_ids: list[str], index_name: str) -> bool:
        """Concrete implementation of delete_documents."""
        return True


class TestVectorStorePort:
    """Test cases for VectorStorePort interface."""

    def test_vector_store_port_is_abstract(self):
        """Test that VectorStorePort cannot be instantiated directly."""
        with pytest.raises(TypeError):
            VectorStorePort()

    def test_vector_store_port_has_required_methods(self):
        """Test that VectorStorePort has all required abstract methods."""
        required_methods = [
            "add_documents",
            "search",
            "get_document",
            "delete_documents",
        ]

        for method_name in required_methods:
            assert hasattr(VectorStorePort, method_name)
            method = getattr(VectorStorePort, method_name)
            assert callable(method)

    def test_vector_store_port_methods_are_abstract(self):
        """Test that all methods in VectorStorePort are abstract."""
        for method_name in [
            "add_documents",
            "search",
            "get_document",
            "delete_documents",
        ]:
            method = getattr(VectorStorePort, method_name)
            assert getattr(method, "__isabstractmethod__", False)

    def test_concrete_implementation_can_be_instantiated(self):
        """Test that a concrete implementation can be instantiated."""
        port = ConcreteVectorStorePort()
        assert isinstance(port, VectorStorePort)

    def test_add_documents_signature(self):
        """Test add_documents method signature."""
        port = ConcreteVectorStorePort()

        # Test with valid inputs
        documents = [
            DocumentChunk(id="doc1", content="content1"),
            DocumentChunk(id="doc2", content="content2"),
        ]
        result = port.add_documents(documents, "test_index")

        assert isinstance(result, list)
        assert result == ["doc1", "doc2"]

    def test_search_signature(self):
        """Test search method signature."""
        port = ConcreteVectorStorePort()

        # Test with valid inputs
        query = TextQuery(text="test query", limit=5)
        result = port.search(query, "test_index")

        assert isinstance(result, list)
        # Result should be list of ScoredDocumentChunk (empty in our mock)

    def test_get_document_signature(self):
        """Test get_document method signature."""
        port = ConcreteVectorStorePort()

        # Test with valid inputs
        result = port.get_document("doc1", "test_index")

        assert isinstance(result, DocumentChunk)
        assert result.id == "doc1"
        assert result.content == "test content"

    def test_delete_documents_signature(self):
        """Test delete_documents method signature."""
        port = ConcreteVectorStorePort()

        # Test with valid inputs
        result = port.delete_documents(["doc1", "doc2"], "test_index")

        assert isinstance(result, bool)
        assert result is True

    def test_add_documents_with_empty_list(self):
        """Test add_documents with empty document list."""
        port = ConcreteVectorStorePort()

        result = port.add_documents([], "test_index")
        assert result == []

    def test_add_documents_with_single_document(self):
        """Test add_documents with single document."""
        port = ConcreteVectorStorePort()

        documents = [DocumentChunk(id="single_doc", content="single content")]
        result = port.add_documents(documents, "test_index")

        assert result == ["single_doc"]

    def test_add_documents_with_metadata(self):
        """Test add_documents with documents containing metadata."""
        port = ConcreteVectorStorePort()

        documents = [
            DocumentChunk(
                id="doc1",
                content="content1",
                metadata={"category": "test", "source": "unit_test"},
            ),
            DocumentChunk(
                id="doc2", content="content2", metadata={"category": "example"}
            ),
        ]
        result = port.add_documents(documents, "test_index")

        assert result == ["doc1", "doc2"]

    def test_search_with_different_query_parameters(self):
        """Test search with different query parameters."""
        port = ConcreteVectorStorePort()

        # Test with different limit values
        query1 = TextQuery(text="test", limit=1)
        query2 = TextQuery(text="test", limit=100)

        result1 = port.search(query1, "test_index")
        result2 = port.search(query2, "test_index")

        assert isinstance(result1, list)
        assert isinstance(result2, list)

    def test_search_with_filters(self):
        """Test search with query filters."""
        port = ConcreteVectorStorePort()

        query = TextQuery(
            text="test query", filters={"category": "test"}, min_score=0.7
        )
        result = port.search(query, "test_index")

        assert isinstance(result, list)

    def test_get_document_with_different_ids(self):
        """Test get_document with different document IDs."""
        port = ConcreteVectorStorePort()

        # Test with different ID formats
        test_ids = [
            "simple_id",
            "id-with-dashes",
            "id_with_underscores",
            "id.with.dots",
        ]

        for doc_id in test_ids:
            result = port.get_document(doc_id, "test_index")
            assert isinstance(result, DocumentChunk)
            assert result.id == doc_id

    def test_delete_documents_with_different_lists(self):
        """Test delete_documents with different document ID lists."""
        port = ConcreteVectorStorePort()

        # Test with different list sizes
        test_cases = [
            (["single_id"], True),
            (["id1", "id2", "id3"], True),
            ([], True),  # Empty list should still work
        ]

        for doc_ids, expected in test_cases:
            result = port.delete_documents(doc_ids, "test_index")
            assert result == expected

    def test_methods_accept_correct_types(self):
        """Test that methods accept the correct parameter types."""
        port = ConcreteVectorStorePort()

        # Test add_documents
        documents = [DocumentChunk(id="test", content="test")]
        result = port.add_documents(documents, "index")
        assert isinstance(result, list)

        # Test search
        query = TextQuery(text="test")
        result = port.search(query, "index")
        assert isinstance(result, list)

        # Test get_document
        result = port.get_document("test", "index")
        assert isinstance(result, DocumentChunk)

        # Test delete_documents
        result = port.delete_documents(["test"], "index")
        assert isinstance(result, bool)

    def test_interface_inheritance(self):
        """Test that VectorStorePort properly inherits from ABC."""
        assert issubclass(VectorStorePort, ABC)

        # Test that it's abstract
        assert getattr(VectorStorePort, "__abstractmethods__", None) is not None
        abstract_methods = VectorStorePort.__abstractmethods__
        expected_methods = {
            "add_documents",
            "search",
            "get_document",
            "delete_documents",
        }
        assert abstract_methods == expected_methods

    def test_concrete_implementation_satisfies_interface(self):
        """Test that concrete implementation satisfies the interface contract."""
        port = ConcreteVectorStorePort()

        # Verify all abstract methods are implemented
        for method_name in VectorStorePort.__abstractmethods__:
            method = getattr(port, method_name)
            assert callable(method)
            assert not getattr(method, "__isabstractmethod__", False)

    def test_method_documentation_exists(self):
        """Test that all methods have proper docstrings."""
        for method_name in [
            "add_documents",
            "search",
            "get_document",
            "delete_documents",
        ]:
            method = getattr(VectorStorePort, method_name)
            assert method.__doc__ is not None
            assert len(method.__doc__.strip()) > 0

    def test_method_parameter_annotations(self):
        """Test that methods have proper type annotations."""
        # Check add_documents
        add_docs_method = VectorStorePort.add_documents
        annotations = add_docs_method.__annotations__
        assert "documents" in annotations
        assert "index_name" in annotations
        assert "return" in annotations

        # Check search
        search_method = VectorStorePort.search
        annotations = search_method.__annotations__
        assert "query" in annotations
        assert "index_name" in annotations
        assert "return" in annotations

        # Check get_document
        get_doc_method = VectorStorePort.get_document
        annotations = get_doc_method.__annotations__
        assert "document_id" in annotations
        assert "index_name" in annotations
        assert "return" in annotations

        # Check delete_documents
        delete_docs_method = VectorStorePort.delete_documents
        annotations = delete_docs_method.__annotations__
        assert "document_ids" in annotations
        assert "index_name" in annotations
        assert "return" in annotations

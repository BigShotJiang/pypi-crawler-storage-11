"""Integration tests for the complete vector store workflow."""

import pytest
from typing import Any

from axolotl.vector_store import (
    VectorStoreAdapterFactory,
    OpenSearchConfig,
    DocumentChunk,
    ScoredDocumentChunk,
    TextQuery,
    VectorStoreError,
)
from axolotl.vector_store.adapters.base import BaseVectorStoreAdapter


class MockVectorStoreAdapter(BaseVectorStoreAdapter):
    """Mock vector store adapter for integration testing."""

    def __init__(self, config: Any):
        super().__init__()
        self.config = config
        self._documents = {}  # In-memory storage for testing
        self._indices = set()

    def _add_documents_impl(
        self, documents: list[DocumentChunk], index_name: str
    ) -> list[str]:
        """Implementation of add_documents."""
        if index_name not in self._indices:
            raise VectorStoreError(f"Index '{index_name}' not found")

        added_ids = []
        for doc in documents:
            doc_key = f"{index_name}:{doc.id}"
            self._documents[doc_key] = doc
            added_ids.append(doc.id)
        return added_ids

    def _search_impl(
        self, query: TextQuery, index_name: str
    ) -> list[ScoredDocumentChunk]:
        """Implementation of search."""
        if index_name not in self._indices:
            raise VectorStoreError(f"Index '{index_name}' not found")

        # Simple mock search - return documents that contain query text
        results = []
        for doc_key, doc in self._documents.items():
            if index_name in doc_key and query.text.lower() in doc.content.lower():
                score = 0.8  # Mock score
                scored_doc = ScoredDocumentChunk(document_chunk=doc, score=score)
                results.append(scored_doc)

        # Sort by score (descending) and limit results
        results.sort(key=lambda x: x.score, reverse=True)
        return results[: query.limit]

    def _get_document_impl(self, document_id: str, index_name: str) -> DocumentChunk:
        """Implementation of get_document."""
        if index_name not in self._indices:
            raise VectorStoreError(f"Index '{index_name}' not found")

        doc_key = f"{index_name}:{document_id}"
        if doc_key not in self._documents:
            raise VectorStoreError(f"Document '{document_id}' not found")

        return self._documents[doc_key]

    def _delete_documents_impl(self, document_ids: list[str], index_name: str) -> bool:
        """Implementation of delete_documents."""
        if index_name not in self._indices:
            raise VectorStoreError(f"Index '{index_name}' not found")

        for doc_id in document_ids:
            doc_key = f"{index_name}:{doc_id}"
            if doc_key in self._documents:
                del self._documents[doc_key]
        return True

    def _create_index_impl(self, index_name: str, **index_config: Any) -> bool:
        """Implementation of create_index."""
        if index_name in self._indices:
            raise VectorStoreError(f"Index '{index_name}' already exists")

        self._indices.add(index_name)
        return True

    def _delete_index_impl(self, index_name: str) -> bool:
        """Implementation of delete_index."""
        if index_name not in self._indices:
            raise VectorStoreError(f"Index '{index_name}' not found")

        # Remove all documents for this index
        keys_to_remove = [
            key for key in self._documents.keys() if key.startswith(f"{index_name}:")
        ]
        for key in keys_to_remove:
            del self._documents[key]

        self._indices.remove(index_name)
        return True

    def _index_exists_impl(self, index_name: str) -> bool:
        """Implementation of index_exists."""
        return index_name in self._indices

    def _list_indices_impl(self) -> list[str]:
        """Implementation of list_indices."""
        return list(self._indices)


class TestVectorStoreIntegration:
    """Integration tests for the complete vector store workflow."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Clear the factory registry and register our mock adapter
        VectorStoreAdapterFactory._ADAPTERS.clear()
        VectorStoreAdapterFactory.register_adapter(
            "mock", "test", MockVectorStoreAdapter
        )

    def test_complete_workflow(self):
        """Test the complete vector store workflow from configuration to search."""
        # 1. Create configuration with correct provider/framework
        config = OpenSearchConfig(
            provider="mock",
            framework="test",
            endpoint="http://localhost:9200",
            dimension=384,
            index="test_index",
        )

        # 2. Create adapter using factory
        adapter = VectorStoreAdapterFactory.create_adapter(config)
        assert isinstance(adapter, MockVectorStoreAdapter)

        # 3. Create index
        success = adapter.create_index("test_index", dimension=384)
        assert success is True
        assert adapter.index_exists("test_index") is True

        # 4. Add documents
        documents = [
            DocumentChunk(
                id="doc1",
                content="This is a test document about machine learning",
                metadata={"category": "tech", "author": "test"},
            ),
            DocumentChunk(
                id="doc2",
                content="Another document about artificial intelligence and neural networks",
                metadata={"category": "tech", "author": "test"},
            ),
            DocumentChunk(
                id="doc3",
                content="A document about cooking recipes and food preparation",
                metadata={"category": "lifestyle", "author": "chef"},
            ),
        ]

        added_ids = adapter.add_documents(documents, "test_index")
        assert added_ids == ["doc1", "doc2", "doc3"]

        # 5. Search for documents
        query = TextQuery(text="machine learning", limit=5)
        results = adapter.search(query, "test_index")

        assert len(results) >= 1  # Should find at least doc1, possibly doc2
        assert all(isinstance(result, ScoredDocumentChunk) for result in results)
        assert all(result.score == 0.8 for result in results)  # Mock score

        # Verify document content
        result_contents = [result.content for result in results]
        assert any("machine learning" in content.lower() for content in result_contents)

        # 6. Get specific document
        doc = adapter.get_document("doc1", "test_index")
        assert doc.id == "doc1"
        assert "machine learning" in doc.content
        assert doc.metadata["category"] == "tech"

        # 7. List indices
        indices = adapter.list_indices()
        assert "test_index" in indices

        # 8. Delete documents
        success = adapter.delete_documents(["doc1", "doc3"], "test_index")
        assert success is True

        # Verify deletion
        with pytest.raises(VectorStoreError):
            adapter.get_document("doc1", "test_index")

        # doc2 should still exist
        doc2 = adapter.get_document("doc2", "test_index")
        assert doc2.id == "doc2"

        # 9. Delete index
        success = adapter.delete_index("test_index")
        assert success is True
        assert adapter.index_exists("test_index") is False

    def test_error_handling_workflow(self):
        """Test error handling throughout the workflow."""
        config = OpenSearchConfig(
            provider="mock",
            framework="test",
            endpoint="http://localhost:9200",
            dimension=384,
        )
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        # Test operations on non-existent index
        with pytest.raises(VectorStoreError):
            adapter.add_documents(
                [DocumentChunk(id="doc1", content="test")], "nonexistent"
            )

        with pytest.raises(VectorStoreError):
            adapter.search(TextQuery(text="test"), "nonexistent")

        with pytest.raises(VectorStoreError):
            adapter.get_document("doc1", "nonexistent")

        with pytest.raises(VectorStoreError):
            adapter.delete_documents(["doc1"], "nonexistent")

        with pytest.raises(VectorStoreError):
            adapter.delete_index("nonexistent")

        # Test document not found
        adapter.create_index("test_index")
        with pytest.raises(VectorStoreError):
            adapter.get_document("nonexistent", "test_index")

    def test_search_with_different_queries(self):
        """Test search functionality with different query types."""
        config = OpenSearchConfig(
            provider="mock",
            framework="test",
            endpoint="http://localhost:9200",
            dimension=384,
        )
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        # Create index and add documents
        adapter.create_index("search_test")

        documents = [
            DocumentChunk(id="doc1", content="Python programming language tutorial"),
            DocumentChunk(id="doc2", content="JavaScript web development guide"),
            DocumentChunk(
                id="doc3", content="Machine learning with Python and scikit-learn"
            ),
            DocumentChunk(id="doc4", content="Database design and SQL queries"),
        ]

        adapter.add_documents(documents, "search_test")

        # Test different search queries
        test_cases = [
            ("python", 2),  # Should find doc1 and doc3
            ("javascript", 1),  # Should find doc2
            ("database", 1),  # Should find doc4
            ("nonexistent", 0),  # Should find nothing
        ]

        for query_text, expected_count in test_cases:
            query = TextQuery(text=query_text, limit=10)
            results = adapter.search(query, "search_test")
            assert len(results) == expected_count

    def test_search_with_limits_and_filters(self):
        """Test search with different limits and query parameters."""
        config = OpenSearchConfig(
            provider="mock",
            framework="test",
            endpoint="http://localhost:9200",
            dimension=384,
        )
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        adapter.create_index("limit_test")

        # Add multiple documents with same content pattern
        documents = [
            DocumentChunk(id=f"doc{i}", content=f"Test document {i} about programming")
            for i in range(10)
        ]

        adapter.add_documents(documents, "limit_test")

        # Test with different limits
        query1 = TextQuery(text="programming", limit=3)
        results1 = adapter.search(query1, "limit_test")
        assert len(results1) == 3

        query2 = TextQuery(text="programming", limit=1)
        results2 = adapter.search(query2, "limit_test")
        assert len(results2) == 1

        query3 = TextQuery(text="programming", limit=100)
        results3 = adapter.search(query3, "limit_test")
        assert len(results3) == 10

    def test_metadata_handling(self):
        """Test metadata handling throughout the workflow."""
        config = OpenSearchConfig(
            provider="mock",
            framework="test",
            endpoint="http://localhost:9200",
            dimension=384,
        )
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        adapter.create_index("metadata_test")

        # Test documents with complex metadata
        documents = [
            DocumentChunk(
                id="doc1",
                content="Test content",
                metadata={
                    "category": "tech",
                    "tags": ["python", "programming"],
                    "author": {"name": "John Doe", "email": "john@example.com"},
                    "created_at": "2023-01-01T00:00:00Z",
                    "score": 95.5,
                },
            ),
            DocumentChunk(
                id="doc2",
                content="Another test",
                metadata={
                    "category": "science",
                    "tags": ["research", "data"],
                    "author": {"name": "Jane Smith", "email": "jane@example.com"},
                    "created_at": "2023-01-02T00:00:00Z",
                    "score": 87.2,
                },
            ),
        ]

        adapter.add_documents(documents, "metadata_test")

        # Retrieve and verify metadata
        doc1 = adapter.get_document("doc1", "metadata_test")
        assert doc1.metadata["category"] == "tech"
        assert doc1.metadata["tags"] == ["python", "programming"]
        assert doc1.metadata["author"]["name"] == "John Doe"
        assert doc1.metadata["score"] == 95.5

        doc2 = adapter.get_document("doc2", "metadata_test")
        assert doc2.metadata["category"] == "science"
        assert doc2.metadata["author"]["email"] == "jane@example.com"

    def test_index_management_workflow(self):
        """Test complete index management workflow."""
        config = OpenSearchConfig(
            provider="mock",
            framework="test",
            endpoint="http://localhost:9200",
            dimension=384,
        )
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        # Initially no indices
        assert adapter.list_indices() == []

        # Create multiple indices
        indices = ["index1", "index2", "index3"]
        for index_name in indices:
            success = adapter.create_index(index_name, dimension=384)
            assert success is True
            assert adapter.index_exists(index_name) is True

        # Verify all indices exist
        all_indices = adapter.list_indices()
        assert set(all_indices) == set(indices)

        # Delete one index
        success = adapter.delete_index("index2")
        assert success is True
        assert adapter.index_exists("index2") is False

        # Verify remaining indices
        remaining_indices = adapter.list_indices()
        assert set(remaining_indices) == {"index1", "index3"}

    def test_concurrent_operations_simulation(self):
        """Test simulation of concurrent operations."""
        config = OpenSearchConfig(
            provider="mock",
            framework="test",
            endpoint="http://localhost:9200",
            dimension=384,
        )
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        # Create index
        adapter.create_index("concurrent_test")

        # Simulate adding documents in batches
        batch1 = [
            DocumentChunk(id=f"batch1_doc{i}", content=f"Batch 1 document {i}")
            for i in range(5)
        ]
        batch2 = [
            DocumentChunk(id=f"batch2_doc{i}", content=f"Batch 2 document {i}")
            for i in range(5)
        ]

        # Add batches
        ids1 = adapter.add_documents(batch1, "concurrent_test")
        ids2 = adapter.add_documents(batch2, "concurrent_test")

        assert len(ids1) == 5
        assert len(ids2) == 5

        # Search should find all documents
        query = TextQuery(text="document", limit=20)
        results = adapter.search(query, "concurrent_test")
        assert len(results) == 10

        # Delete some documents
        adapter.delete_documents(ids1[:3], "concurrent_test")

        # Search should find fewer documents
        results_after_delete = adapter.search(query, "concurrent_test")
        assert len(results_after_delete) == 7

    def test_error_recovery_workflow(self):
        """Test error recovery and retry scenarios."""
        config = OpenSearchConfig(
            provider="mock",
            framework="test",
            endpoint="http://localhost:9200",
            dimension=384,
        )
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        # Test creating index after failed operation
        try:
            adapter.add_documents(
                [DocumentChunk(id="doc1", content="test")], "nonexistent"
            )
        except VectorStoreError:
            pass  # Expected error

        # Create the index and retry
        adapter.create_index("recovery_test")
        success = adapter.add_documents(
            [DocumentChunk(id="doc1", content="test")], "recovery_test"
        )
        assert success == ["doc1"]

        # Test document not found recovery
        try:
            adapter.get_document("nonexistent", "recovery_test")
        except VectorStoreError:
            pass  # Expected error

        # Add the document and retry
        adapter.add_documents(
            [DocumentChunk(id="nonexistent", content="now exists")], "recovery_test"
        )
        doc = adapter.get_document("nonexistent", "recovery_test")
        assert doc.content == "now exists"

    def test_factory_integration(self):
        """Test factory integration with different configurations."""
        # Test with different provider/framework combinations
        config1 = OpenSearchConfig(
            provider="mock",
            framework="test",
            endpoint="http://localhost:9200",
            dimension=384,
        )
        adapter1 = VectorStoreAdapterFactory.create_adapter(config1)
        assert isinstance(adapter1, MockVectorStoreAdapter)

        # Test factory methods
        providers = VectorStoreAdapterFactory.get_supported_providers()
        assert "mock" in providers

        frameworks = VectorStoreAdapterFactory.get_supported_frameworks()
        assert "test" in frameworks

        combinations = VectorStoreAdapterFactory.get_supported_combinations()
        assert "mock:test" in combinations

    def test_configuration_validation_integration(self):
        """Test configuration validation in integration context."""
        # Test invalid configuration
        with pytest.raises(Exception):  # Should fail validation
            _invalid_config = OpenSearchConfig(endpoint="", dimension=0)

        # Test valid configuration
        valid_config = OpenSearchConfig(
            provider="mock",
            framework="test",
            endpoint="http://localhost:9200",
            dimension=384,
            index="valid_test",
        )

        adapter = VectorStoreAdapterFactory.create_adapter(valid_config)
        assert adapter.config == valid_config

    def test_logging_integration(self):
        """Test that logging works correctly in integration context."""
        config = OpenSearchConfig(
            provider="mock",
            framework="test",
            endpoint="http://localhost:9200",
            dimension=384,
        )
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        # Verify logger is set up
        assert adapter.logger is not None
        assert adapter.logger.name == "MockVectorStoreAdapter"

        # Test that operations don't fail due to logging
        adapter.create_index("logging_test")
        adapter.add_documents(
            [DocumentChunk(id="doc1", content="test")], "logging_test"
        )
        results = adapter.search(TextQuery(text="test"), "logging_test")
        assert len(results) == 1

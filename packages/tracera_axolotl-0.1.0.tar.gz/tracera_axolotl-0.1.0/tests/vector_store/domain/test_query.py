"""Tests for query domain models."""

import pytest
from pydantic import ValidationError

from axolotl.vector_store.domain.query import TextQuery


class TestTextQuery:
    """Test cases for TextQuery model."""

    def test_text_query_creation_with_required_fields(self):
        """Test creating TextQuery with required fields only."""
        query = TextQuery(text="test query")

        assert query.text == "test query"
        assert query.limit == 10  # default value
        assert query.filters is None
        assert query.min_score is None
        assert query.include_metadata is True
        assert query.include_content is True

    def test_text_query_creation_with_all_fields(self):
        """Test creating TextQuery with all fields."""
        filters = {"category": "test", "status": "active"}
        query = TextQuery(
            text="test query with all fields",
            limit=5,
            filters=filters,
            min_score=0.7,
            include_metadata=False,
            include_content=False,
        )

        assert query.text == "test query with all fields"
        assert query.limit == 5
        assert query.filters == filters
        assert query.min_score == 0.7
        assert query.include_metadata is False
        assert query.include_content is False

    def test_text_query_validation_empty_text(self):
        """Test validation error for empty text."""
        with pytest.raises(ValidationError) as exc_info:
            TextQuery(text="")

        errors = exc_info.value.errors()
        assert any(error["type"] == "string_too_short" for error in errors)

    def test_text_query_validation_whitespace_text(self):
        """Test that whitespace-only text is allowed (no validation on whitespace)."""
        # Whitespace-only text is allowed by the model - validation happens at the adapter level
        query = TextQuery(text="   ")
        assert query.text == "   "

    def test_text_query_validation_limit_too_low(self):
        """Test validation error for limit below minimum."""
        with pytest.raises(ValidationError) as exc_info:
            TextQuery(text="test", limit=0)

        errors = exc_info.value.errors()
        assert any(error["type"] == "greater_than_equal" for error in errors)

    def test_text_query_validation_limit_too_high(self):
        """Test validation error for limit above maximum."""
        with pytest.raises(ValidationError) as exc_info:
            TextQuery(text="test", limit=1001)

        errors = exc_info.value.errors()
        assert any(error["type"] == "less_than_equal" for error in errors)

    def test_text_query_validation_min_score_below_zero(self):
        """Test validation error for min_score below 0."""
        with pytest.raises(ValidationError) as exc_info:
            TextQuery(text="test", min_score=-0.1)

        errors = exc_info.value.errors()
        assert any(error["type"] == "greater_than_equal" for error in errors)

    def test_text_query_validation_min_score_above_one(self):
        """Test validation error for min_score above 1."""
        with pytest.raises(ValidationError) as exc_info:
            TextQuery(text="test", min_score=1.1)

        errors = exc_info.value.errors()
        assert any(error["type"] == "less_than_equal" for error in errors)

    def test_text_query_valid_limit_range(self):
        """Test valid limit range."""
        # Test minimum valid limit
        query1 = TextQuery(text="test", limit=1)
        assert query1.limit == 1

        # Test maximum valid limit
        query2 = TextQuery(text="test", limit=1000)
        assert query2.limit == 1000

        # Test middle range
        query3 = TextQuery(text="test", limit=500)
        assert query3.limit == 500

    def test_text_query_valid_min_score_range(self):
        """Test valid min_score range."""
        # Test minimum valid score
        query1 = TextQuery(text="test", min_score=0.0)
        assert query1.min_score == 0.0

        # Test maximum valid score
        query2 = TextQuery(text="test", min_score=1.0)
        assert query2.min_score == 1.0

        # Test middle range
        query3 = TextQuery(text="test", min_score=0.5)
        assert query3.min_score == 0.5

    def test_text_query_str_representation_short_text(self):
        """Test string representation with short text."""
        query = TextQuery(text="short query")
        str_repr = str(query)

        assert "Semantic Search Query:" in str_repr
        assert "Query Text: 'short query'" in str_repr
        assert "Text Length: 11 characters" in str_repr  # Corrected length
        assert "Result Limit: 10" in str_repr
        assert "Filters: None" in str_repr
        assert "Minimum Score: None" in str_repr
        assert "Include Metadata: True" in str_repr
        assert "Include Content: True" in str_repr

    def test_text_query_str_representation_long_text(self):
        """Test string representation with long text (truncated)."""
        long_text = "This is a very long query text that should be truncated in the string representation to make it more readable and not overwhelm the output with too much text content"
        query = TextQuery(text=long_text)
        str_repr = str(query)

        assert "Semantic Search Query:" in str_repr
        assert (
            "Query Text: 'This is a very long query text that should be truncated in the string representation to make it more..."
            in str_repr
        )
        assert f"Text Length: {len(long_text)} characters" in str_repr

    def test_text_query_str_representation_with_filters(self):
        """Test string representation with filters."""
        filters = {"category": "test", "status": "active"}
        query = TextQuery(text="test", filters=filters)
        str_repr = str(query)

        assert "Filters:" in str_repr
        assert "category" in str_repr
        assert "test" in str_repr
        assert "status" in str_repr
        assert "active" in str_repr

    def test_text_query_str_representation_with_min_score(self):
        """Test string representation with min_score."""
        query = TextQuery(text="test", min_score=0.75)
        str_repr = str(query)

        assert "Minimum Score: 0.75" in str_repr

    def test_text_query_str_representation_with_all_options(self):
        """Test string representation with all options."""
        filters = {"category": "test"}
        query = TextQuery(
            text="comprehensive test query",
            limit=25,
            filters=filters,
            min_score=0.8,
            include_metadata=False,
            include_content=False,
        )
        str_repr = str(query)

        assert "Query Text: 'comprehensive test query'" in str_repr
        assert "Text Length: 24 characters" in str_repr  # Corrected length
        assert "Result Limit: 25" in str_repr
        assert "Minimum Score: 0.8" in str_repr
        assert "Include Metadata: False" in str_repr
        assert "Include Content: False" in str_repr

    def test_text_query_with_complex_filters(self):
        """Test TextQuery with complex filter structures."""
        complex_filters = {
            "nested": {"field": "value", "array": [1, 2, 3], "boolean": True},
            "simple": "test",
        }

        query = TextQuery(text="test", filters=complex_filters)
        assert query.filters == complex_filters

    def test_text_query_filters_none_vs_empty_dict(self):
        """Test that filters can be None or empty dict."""
        query1 = TextQuery(text="test", filters=None)
        query2 = TextQuery(text="test", filters={})

        assert query1.filters is None
        assert query2.filters == {}

    def test_text_query_boolean_fields(self):
        """Test boolean field behavior."""
        query1 = TextQuery(text="test", include_metadata=True, include_content=True)
        query2 = TextQuery(text="test", include_metadata=False, include_content=False)

        assert query1.include_metadata is True
        assert query1.include_content is True
        assert query2.include_metadata is False
        assert query2.include_content is False

"""Tests for document domain models."""

import pytest
from pydantic import ValidationError

from axolotl.vector_store.domain.document import DocumentChunk, ScoredDocumentChunk


class TestDocumentChunk:
    """Test cases for DocumentChunk model."""

    def test_document_chunk_creation_with_required_fields(self):
        """Test creating DocumentChunk with required fields only."""
        doc = DocumentChunk(id="test-doc-1", content="This is test content")

        assert doc.id == "test-doc-1"
        assert doc.content == "This is test content"
        assert doc.metadata == {}
        assert doc.type == "DocumentChunk"

    def test_document_chunk_creation_with_metadata(self):
        """Test creating DocumentChunk with metadata."""
        metadata = {"category": "test", "source": "unit_test"}
        doc = DocumentChunk(
            id="test-doc-2",
            content="This is test content with metadata",
            metadata=metadata,
        )

        assert doc.id == "test-doc-2"
        assert doc.content == "This is test content with metadata"
        assert doc.metadata == metadata
        assert doc.type == "DocumentChunk"

    def test_document_chunk_creation_with_custom_type(self):
        """Test creating DocumentChunk with custom type."""
        doc = DocumentChunk(
            id="test-doc-3", content="This is test content", type="DocumentChunk"
        )

        assert doc.type == "DocumentChunk"

    def test_document_chunk_validation_empty_id(self):
        """Test that empty ID is allowed (no validation on ID field)."""
        # Empty ID is allowed by the model - validation happens at the adapter level
        doc = DocumentChunk(id="", content="test content")
        assert doc.id == ""
        assert doc.content == "test content"

    def test_document_chunk_validation_empty_content(self):
        """Test validation error for empty content."""
        with pytest.raises(ValidationError) as exc_info:
            DocumentChunk(id="test-id", content="")

        errors = exc_info.value.errors()
        assert any(error["type"] == "string_too_short" for error in errors)

    def test_document_chunk_validation_whitespace_content(self):
        """Test that whitespace-only content is allowed (no validation on whitespace)."""
        # Whitespace-only content is allowed by the model - validation happens at the adapter level
        doc = DocumentChunk(id="test-id", content="   ")
        assert doc.id == "test-id"
        assert doc.content == "   "

    def test_document_chunk_str_representation(self):
        """Test string representation of DocumentChunk."""
        doc = DocumentChunk(
            id="test-doc", content="Test content", metadata={"key": "value"}
        )

        str_repr = str(doc)
        assert "Document ID: test-doc" in str_repr
        assert "Content: Test content" in str_repr
        assert "Metadata:" in str_repr
        assert "Type: DocumentChunk" in str_repr

    def test_document_chunk_repr_representation(self):
        """Test repr representation of DocumentChunk."""
        doc = DocumentChunk(
            id="test-doc", content="Test content", metadata={"key": "value"}
        )

        repr_str = repr(doc)
        assert "Document(id=test-doc" in repr_str
        assert "content=Test content" in repr_str
        assert "metadata={'key': 'value'}" in repr_str
        assert "type=DocumentChunk" in repr_str

    def test_document_chunk_metadata_default_factory(self):
        """Test that metadata uses default factory for empty dict."""
        doc1 = DocumentChunk(id="test-1", content="content1")
        doc2 = DocumentChunk(id="test-2", content="content2")

        # Both should have empty dict, but different instances
        assert doc1.metadata == {}
        assert doc2.metadata == {}
        assert doc1.metadata is not doc2.metadata

    def test_document_chunk_metadata_mutation(self):
        """Test that metadata can be mutated independently."""
        doc1 = DocumentChunk(id="test-1", content="content1")
        doc2 = DocumentChunk(id="test-2", content="content2")

        doc1.metadata["key1"] = "value1"
        doc2.metadata["key2"] = "value2"

        assert doc1.metadata == {"key1": "value1"}
        assert doc2.metadata == {"key2": "value2"}


class TestScoredDocumentChunk:
    """Test cases for ScoredDocumentChunk model."""

    def test_scored_document_chunk_creation(self):
        """Test creating ScoredDocumentChunk."""
        doc_chunk = DocumentChunk(
            id="test-doc", content="Test content", metadata={"category": "test"}
        )
        scored_doc = ScoredDocumentChunk(document_chunk=doc_chunk, score=0.85)

        assert scored_doc.document_chunk == doc_chunk
        assert scored_doc.score == 0.85
        assert scored_doc.type == "ScoredDocumentChunk"

    def test_scored_document_chunk_properties(self):
        """Test ScoredDocumentChunk property accessors."""
        doc_chunk = DocumentChunk(
            id="test-doc", content="Test content", metadata={"category": "test"}
        )
        scored_doc = ScoredDocumentChunk(document_chunk=doc_chunk, score=0.75)

        assert scored_doc.document_id == "test-doc"
        assert scored_doc.content == "Test content"
        assert scored_doc.metadata == {"category": "test"}

    def test_scored_document_chunk_score_validation_min(self):
        """Test score validation for minimum value."""
        doc_chunk = DocumentChunk(id="test", content="content")

        # Valid minimum score
        scored_doc = ScoredDocumentChunk(document_chunk=doc_chunk, score=0.0)
        assert scored_doc.score == 0.0

    def test_scored_document_chunk_score_validation_max(self):
        """Test score validation for maximum value."""
        doc_chunk = DocumentChunk(id="test", content="content")

        # Valid maximum score
        scored_doc = ScoredDocumentChunk(document_chunk=doc_chunk, score=1.0)
        assert scored_doc.score == 1.0

    def test_scored_document_chunk_score_validation_negative(self):
        """Test score validation for negative values."""
        doc_chunk = DocumentChunk(id="test", content="content")

        with pytest.raises(ValidationError) as exc_info:
            ScoredDocumentChunk(document_chunk=doc_chunk, score=-0.1)

        errors = exc_info.value.errors()
        assert any(error["type"] == "greater_than_equal" for error in errors)

    def test_scored_document_chunk_score_validation_above_one(self):
        """Test score validation for values above 1.0."""
        doc_chunk = DocumentChunk(id="test", content="content")

        with pytest.raises(ValidationError) as exc_info:
            ScoredDocumentChunk(document_chunk=doc_chunk, score=1.1)

        errors = exc_info.value.errors()
        assert any(error["type"] == "less_than_equal" for error in errors)

    def test_scored_document_chunk_str_representation(self):
        """Test string representation of ScoredDocumentChunk."""
        doc_chunk = DocumentChunk(
            id="test-doc", content="Test content", metadata={"key": "value"}
        )
        scored_doc = ScoredDocumentChunk(document_chunk=doc_chunk, score=0.85)

        str_repr = str(scored_doc)
        assert "Document ID: test-doc" in str_repr
        assert "Content: Test content" in str_repr
        assert "Score: 0.85" in str_repr
        assert "Type: DocumentChunk" in str_repr

    def test_scored_document_chunk_repr_representation(self):
        """Test repr representation of ScoredDocumentChunk."""
        doc_chunk = DocumentChunk(
            id="test-doc", content="Test content", metadata={"key": "value"}
        )
        scored_doc = ScoredDocumentChunk(document_chunk=doc_chunk, score=0.85)

        repr_str = repr(scored_doc)
        assert "ScoredDocument(document=" in repr_str
        assert "score=0.85" in repr_str

    def test_scored_document_chunk_with_different_scores(self):
        """Test ScoredDocumentChunk with various valid scores."""
        doc_chunk = DocumentChunk(id="test", content="content")

        # Test various valid scores
        valid_scores = [0.0, 0.25, 0.5, 0.75, 1.0, 0.123456789]

        for score in valid_scores:
            scored_doc = ScoredDocumentChunk(document_chunk=doc_chunk, score=score)
            assert scored_doc.score == score

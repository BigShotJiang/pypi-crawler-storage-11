"""Tests for vector store domain models."""

"""Tests for OpenSearch configuration models."""

import pytest
from pydantic import ValidationError

from axolotl.vector_store.domain.opensearch_config import (
    OpenSearchConfig,
    VectorSearchMethod,
)


class TestVectorSearchMethod:
    """Test cases for VectorSearchMethod model."""

    def test_vector_search_method_default_values(self):
        """Test VectorSearchMethod with default values."""
        method = VectorSearchMethod()

        assert method.name == "hnsw"
        assert method.engine == "faiss"
        assert method.space_type == "l2"
        assert method.parameters == {"m": 48, "ef_construction": 256}

    def test_vector_search_method_custom_values(self):
        """Test VectorSearchMethod with custom values."""
        method = VectorSearchMethod(
            name="custom_method",
            engine="custom_engine",
            space_type="cosine",
            parameters={"param1": "value1", "param2": 123},
        )

        assert method.name == "custom_method"
        assert method.engine == "custom_engine"
        assert method.space_type == "cosine"
        assert method.parameters == {"param1": "value1", "param2": 123}

    def test_vector_search_method_extra_fields_allowed(self):
        """Test that VectorSearchMethod allows extra fields."""
        method = VectorSearchMethod(
            name="test", engine="test", space_type="test", extra_field="extra_value"
        )

        assert method.name == "test"
        assert method.engine == "test"
        assert method.space_type == "test"
        # Extra field should be accessible
        assert hasattr(method, "extra_field")
        assert method.extra_field == "extra_value"


class TestOpenSearchConfig:
    """Test cases for OpenSearchConfig model."""

    def test_opensearch_config_creation_with_required_fields(self):
        """Test creating OpenSearchConfig with required fields only."""
        config = OpenSearchConfig(endpoint="http://localhost:9200", dimension=384)

        assert config.provider == "aws"
        assert config.framework == "llamaindex"
        assert config.endpoint == "http://localhost:9200"
        assert config.dimension == 384
        assert config.index is None
        assert config.text_field == "content"
        assert config.embedding_field == "embedding"
        assert config.verify_certs is True
        assert config.use_ssl is True
        assert config.client_options == {}
        assert config.embedding_config == {}

    def test_opensearch_config_creation_with_all_fields(self):
        """Test creating OpenSearchConfig with all fields."""
        method = VectorSearchMethod(
            name="custom_hnsw",
            engine="custom_faiss",
            space_type="cosine",
            parameters={"m": 32, "ef_construction": 128},
        )

        config = OpenSearchConfig(
            provider="custom",
            framework="custom_framework",
            endpoint="https://opensearch.example.com:9200",
            index="custom_index",
            text_field="text_content",
            embedding_field="vector_embedding",
            dimension=512,
            method=method,
            verify_certs=False,
            use_ssl=False,
            client_options={"timeout": 30, "max_retries": 3},
            embedding_config={"model": "custom-model", "batch_size": 32},
        )

        assert config.provider == "custom"
        assert config.framework == "custom_framework"
        assert config.endpoint == "https://opensearch.example.com:9200"
        assert config.index == "custom_index"
        assert config.text_field == "text_content"
        assert config.embedding_field == "vector_embedding"
        assert config.dimension == 512
        assert config.method == method
        assert config.verify_certs is False
        assert config.use_ssl is False
        assert config.client_options == {"timeout": 30, "max_retries": 3}
        assert config.embedding_config == {"model": "custom-model", "batch_size": 32}

    def test_opensearch_config_validation_dimension_positive(self):
        """Test dimension validation for positive values."""
        config = OpenSearchConfig(endpoint="http://localhost:9200", dimension=1)
        assert config.dimension == 1

    def test_opensearch_config_validation_dimension_zero(self):
        """Test dimension validation for zero value."""
        with pytest.raises(ValidationError) as exc_info:
            OpenSearchConfig(endpoint="http://localhost:9200", dimension=0)

        errors = exc_info.value.errors()
        assert any(error["type"] == "greater_than_equal" for error in errors)

    def test_opensearch_config_validation_dimension_negative(self):
        """Test dimension validation for negative values."""
        with pytest.raises(ValidationError) as exc_info:
            OpenSearchConfig(endpoint="http://localhost:9200", dimension=-1)

        errors = exc_info.value.errors()
        assert any(error["type"] == "greater_than_equal" for error in errors)

    def test_opensearch_config_str_representation(self):
        """Test string representation of OpenSearchConfig."""
        config = OpenSearchConfig(
            endpoint="http://localhost:9200", dimension=384, index="test_index"
        )

        str_repr = str(config)
        assert "OpenSearch Configuration:" in str_repr
        assert "Provider: aws" in str_repr
        assert "Framework: llamaindex" in str_repr
        assert "Endpoint: http://localhost:9200" in str_repr
        assert "Index: test_index" in str_repr
        assert "Text Field: content" in str_repr
        assert "Embedding Field: embedding" in str_repr
        assert "Dimension: 384" in str_repr
        assert "Verify Certs: True" in str_repr
        assert "Use SSL: True" in str_repr

    def test_opensearch_config_str_representation_with_auth(self):
        """Test string representation with masked authentication."""
        config = OpenSearchConfig(
            endpoint="http://localhost:9200",
            dimension=384,
            client_options={
                "http_auth": ("username", "password"),
                "other_option": "value",
            },
        )

        str_repr = str(config)
        assert "http_auth" in str_repr
        assert "username" in str_repr
        assert "password" not in str_repr  # Should be masked
        assert "***" in str_repr  # Should show masked password
        assert "other_option" in str_repr
        assert "value" in str_repr

    def test_opensearch_config_get_index_config_default(self):
        """Test get_index_config with default values."""
        config = OpenSearchConfig(endpoint="http://localhost:9200", dimension=384)

        index_config = config.get_index_config()

        assert index_config["dimension"] == 384
        assert index_config["text_field"] == "content"
        assert index_config["embedding_field"] == "embedding"
        assert "method" in index_config
        assert isinstance(index_config["method"], VectorSearchMethod)

    def test_opensearch_config_get_index_config_with_overrides(self):
        """Test get_index_config with overrides."""
        config = OpenSearchConfig(endpoint="http://localhost:9200", dimension=384)

        overrides = {
            "dimension": 512,
            "text_field": "custom_text",
            "custom_param": "custom_value",
        }

        index_config = config.get_index_config(**overrides)

        assert index_config["dimension"] == 512  # overridden
        assert index_config["text_field"] == "custom_text"  # overridden
        assert index_config["embedding_field"] == "embedding"  # original
        assert index_config["custom_param"] == "custom_value"  # new parameter
        assert "method" in index_config  # original

    def test_opensearch_config_method_default(self):
        """Test that method field uses default VectorSearchMethod."""
        config = OpenSearchConfig(endpoint="http://localhost:9200", dimension=384)

        assert isinstance(config.method, VectorSearchMethod)
        assert config.method.name == "hnsw"
        assert config.method.engine == "faiss"
        assert config.method.space_type == "l2"

    def test_opensearch_config_method_custom(self):
        """Test custom method configuration."""
        custom_method = VectorSearchMethod(
            name="ivf", engine="faiss", space_type="cosine", parameters={"nlist": 100}
        )

        config = OpenSearchConfig(
            endpoint="http://localhost:9200", dimension=384, method=custom_method
        )

        assert config.method == custom_method
        assert config.method.name == "ivf"
        assert config.method.space_type == "cosine"
        assert config.method.parameters == {"nlist": 100}

    def test_opensearch_config_client_options_types(self):
        """Test various types in client_options."""
        config = OpenSearchConfig(
            endpoint="http://localhost:9200",
            dimension=384,
            client_options={
                "string_option": "value",
                "int_option": 42,
                "bool_option": True,
                "list_option": [1, 2, 3],
                "dict_option": {"nested": "value"},
            },
        )

        assert config.client_options["string_option"] == "value"
        assert config.client_options["int_option"] == 42
        assert config.client_options["bool_option"] is True
        assert config.client_options["list_option"] == [1, 2, 3]
        assert config.client_options["dict_option"] == {"nested": "value"}

    def test_opensearch_config_embedding_config_types(self):
        """Test various types in embedding_config."""
        config = OpenSearchConfig(
            endpoint="http://localhost:9200",
            dimension=384,
            embedding_config={
                "model_name": "sentence-transformers/all-MiniLM-L6-v2",
                "batch_size": 32,
                "max_length": 512,
                "normalize": True,
                "device": "cuda",
            },
        )

        assert (
            config.embedding_config["model_name"]
            == "sentence-transformers/all-MiniLM-L6-v2"
        )
        assert config.embedding_config["batch_size"] == 32
        assert config.embedding_config["max_length"] == 512
        assert config.embedding_config["normalize"] is True
        assert config.embedding_config["device"] == "cuda"

    def test_opensearch_config_boolean_fields(self):
        """Test boolean field behavior."""
        config1 = OpenSearchConfig(
            endpoint="http://localhost:9200",
            dimension=384,
            verify_certs=True,
            use_ssl=True,
        )

        config2 = OpenSearchConfig(
            endpoint="http://localhost:9200",
            dimension=384,
            verify_certs=False,
            use_ssl=False,
        )

        assert config1.verify_certs is True
        assert config1.use_ssl is True
        assert config2.verify_certs is False
        assert config2.use_ssl is False

    def test_opensearch_config_optional_fields_none(self):
        """Test optional fields can be None."""
        config = OpenSearchConfig(
            endpoint="http://localhost:9200", dimension=384, index=None
        )

        assert config.index is None
        assert config.client_options == {}
        assert config.embedding_config == {}

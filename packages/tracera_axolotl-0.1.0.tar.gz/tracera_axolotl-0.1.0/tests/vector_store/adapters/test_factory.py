"""Tests for VectorStoreAdapterFactory."""

import pytest

from axolotl.vector_store.adapters.factory import (
    VectorStoreAdapterFactory,
    VectorStoreConfigProtocol,
    register_vector_store_adapter,
)
from axolotl.vector_store.ports import VectorStorePort
from axolotl.vector_store.exceptions import VectorStoreError


class MockConfig(VectorStoreConfigProtocol):
    """Mock configuration for testing."""

    def __init__(self, provider: str, framework: str):
        self.provider = provider
        self.framework = framework


class MockAdapter(VectorStorePort):
    """Mock adapter for testing."""

    def __init__(self, config: VectorStoreConfigProtocol):
        self.config = config

    def add_documents(self, documents, index_name):
        return []

    def search(self, query, index_name):
        return []

    def get_document(self, document_id, index_name):
        return None

    def delete_documents(self, document_ids, index_name):
        return True


class TestVectorStoreAdapterFactory:
    """Test cases for VectorStoreAdapterFactory."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Clear the registry before each test
        VectorStoreAdapterFactory._ADAPTERS.clear()

        # Register a test adapter
        VectorStoreAdapterFactory.register_adapter("test", "mock", MockAdapter)

    def test_factory_cannot_be_instantiated(self):
        """Test that factory cannot be instantiated."""
        # The factory is a class with only class methods, so it can be instantiated
        # but it's not designed to be used as an instance
        factory = VectorStoreAdapterFactory()
        assert isinstance(factory, VectorStoreAdapterFactory)

    def test_create_adapter_success(self):
        """Test successful adapter creation."""
        config = MockConfig("test", "mock")
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        assert isinstance(adapter, MockAdapter)
        assert adapter.config == config

    def test_create_adapter_unsupported_provider(self):
        """Test adapter creation with unsupported provider."""
        config = MockConfig("unsupported", "mock")

        with pytest.raises(VectorStoreError) as exc_info:
            VectorStoreAdapterFactory.create_adapter(config)

        assert "Unsupported provider-framework combination" in str(exc_info.value)
        assert "unsupported:mock" in str(exc_info.value)
        assert exc_info.value.details["provider"] == "unsupported"
        assert exc_info.value.details["framework"] == "mock"

    def test_create_adapter_unsupported_framework(self):
        """Test adapter creation with unsupported framework."""
        config = MockConfig("test", "unsupported")

        with pytest.raises(VectorStoreError) as exc_info:
            VectorStoreAdapterFactory.create_adapter(config)

        assert "Unsupported provider-framework combination" in str(exc_info.value)
        assert "test:unsupported" in str(exc_info.value)

    def test_create_adapter_case_insensitive(self):
        """Test that provider and framework names are case insensitive."""
        config = MockConfig("TEST", "MOCK")
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        assert isinstance(adapter, MockAdapter)

    def test_create_adapter_with_spaces(self):
        """Test adapter creation with spaces in provider/framework names."""
        # Register adapter with spaces
        VectorStoreAdapterFactory.register_adapter(" test ", " mock ", MockAdapter)
        config = MockConfig(" test ", " mock ")
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        assert isinstance(adapter, MockAdapter)

    def test_create_adapter_creation_error(self):
        """Test adapter creation when adapter constructor raises an error."""
        config = MockConfig("test", "mock")

        # Mock the adapter class to raise an error
        original_adapter = VectorStoreAdapterFactory._ADAPTERS["test:mock"]

        class FailingAdapter:
            def __init__(self, config):
                raise RuntimeError("Adapter creation failed")

        VectorStoreAdapterFactory._ADAPTERS["test:mock"] = FailingAdapter

        with pytest.raises(VectorStoreError) as exc_info:
            VectorStoreAdapterFactory.create_adapter(config)

        assert "Failed to create adapter for test:mock" in str(exc_info.value)
        assert "Adapter creation failed" in str(exc_info.value)
        assert exc_info.value.details["provider"] == "test"
        assert exc_info.value.details["framework"] == "mock"

        # Restore original adapter
        VectorStoreAdapterFactory._ADAPTERS["test:mock"] = original_adapter

    def test_create_adapter_vector_store_error_passthrough(self):
        """Test that VectorStoreError is passed through without modification."""
        config = MockConfig("test", "mock")

        # Mock the adapter class to raise a VectorStoreError
        original_adapter = VectorStoreAdapterFactory._ADAPTERS["test:mock"]

        class FailingAdapter:
            def __init__(self, config):
                raise VectorStoreError("Original error", details={"key": "value"})

        VectorStoreAdapterFactory._ADAPTERS["test:mock"] = FailingAdapter

        with pytest.raises(VectorStoreError) as exc_info:
            VectorStoreAdapterFactory.create_adapter(config)

        assert "Original error" in str(exc_info.value)
        assert exc_info.value.details == {"key": "value"}

        # Restore original adapter
        VectorStoreAdapterFactory._ADAPTERS["test:mock"] = original_adapter

    def test_get_supported_providers(self):
        """Test getting supported providers."""
        # Clear and add test providers
        VectorStoreAdapterFactory._ADAPTERS.clear()
        VectorStoreAdapterFactory._ADAPTERS["provider1:framework1"] = MockAdapter
        VectorStoreAdapterFactory._ADAPTERS["provider1:framework2"] = MockAdapter
        VectorStoreAdapterFactory._ADAPTERS["provider2:framework1"] = MockAdapter

        providers = VectorStoreAdapterFactory.get_supported_providers()

        assert set(providers) == {"provider1", "provider2"}

    def test_get_supported_frameworks(self):
        """Test getting supported frameworks."""
        # Clear and add test frameworks
        VectorStoreAdapterFactory._ADAPTERS.clear()
        VectorStoreAdapterFactory._ADAPTERS["provider1:framework1"] = MockAdapter
        VectorStoreAdapterFactory._ADAPTERS["provider2:framework1"] = MockAdapter
        VectorStoreAdapterFactory._ADAPTERS["provider1:framework2"] = MockAdapter

        frameworks = VectorStoreAdapterFactory.get_supported_frameworks()

        assert set(frameworks) == {"framework1", "framework2"}

    def test_get_supported_combinations(self):
        """Test getting supported provider-framework combinations."""
        # Clear and add test combinations
        VectorStoreAdapterFactory._ADAPTERS.clear()
        VectorStoreAdapterFactory._ADAPTERS["provider1:framework1"] = MockAdapter
        VectorStoreAdapterFactory._ADAPTERS["provider1:framework2"] = MockAdapter
        VectorStoreAdapterFactory._ADAPTERS["provider2:framework1"] = MockAdapter

        combinations = VectorStoreAdapterFactory.get_supported_combinations()

        expected = {
            "provider1:framework1",
            "provider1:framework2",
            "provider2:framework1",
        }
        assert set(combinations) == expected

    def test_register_adapter_success(self):
        """Test successful adapter registration."""
        # Clear registry
        VectorStoreAdapterFactory._ADAPTERS.clear()

        # Register adapter
        VectorStoreAdapterFactory.register_adapter(
            "new_provider", "new_framework", MockAdapter
        )

        # Verify registration
        assert "new_provider:new_framework" in VectorStoreAdapterFactory._ADAPTERS
        assert (
            VectorStoreAdapterFactory._ADAPTERS["new_provider:new_framework"]
            == MockAdapter
        )

    def test_register_adapter_case_insensitive(self):
        """Test that registration is case insensitive."""
        # Clear registry
        VectorStoreAdapterFactory._ADAPTERS.clear()

        # Register with mixed case
        VectorStoreAdapterFactory.register_adapter("Provider", "Framework", MockAdapter)

        # Should be stored in lowercase
        assert "provider:framework" in VectorStoreAdapterFactory._ADAPTERS

    def test_register_adapter_invalid_class(self):
        """Test registration with invalid adapter class."""

        class InvalidAdapter:
            pass  # Doesn't implement VectorStorePort

        with pytest.raises(VectorStoreError) as exc_info:
            VectorStoreAdapterFactory.register_adapter("test", "test", InvalidAdapter)

        assert "Adapter class must implement VectorStorePort interface" in str(
            exc_info.value
        )
        assert exc_info.value.details["provider"] == "test"
        assert exc_info.value.details["framework"] == "test"
        assert exc_info.value.details["adapter_class"] == "InvalidAdapter"

    def test_register_adapter_overwrite_existing(self):
        """Test that registration overwrites existing adapters."""
        # Clear registry
        VectorStoreAdapterFactory._ADAPTERS.clear()

        # Register first adapter
        VectorStoreAdapterFactory.register_adapter("test", "test", MockAdapter)
        assert VectorStoreAdapterFactory._ADAPTERS["test:test"] == MockAdapter

        # Register different adapter with same key
        class AnotherAdapter(MockAdapter):
            pass

        VectorStoreAdapterFactory.register_adapter("test", "test", AnotherAdapter)
        assert VectorStoreAdapterFactory._ADAPTERS["test:test"] == AnotherAdapter

    def test_is_provider_supported(self):
        """Test checking if provider is supported."""
        # Clear and add test providers
        VectorStoreAdapterFactory._ADAPTERS.clear()
        VectorStoreAdapterFactory._ADAPTERS["provider1:framework1"] = MockAdapter
        VectorStoreAdapterFactory._ADAPTERS["provider2:framework1"] = MockAdapter

        assert VectorStoreAdapterFactory.is_provider_supported("provider1") is True
        assert VectorStoreAdapterFactory.is_provider_supported("provider2") is True
        assert VectorStoreAdapterFactory.is_provider_supported("provider3") is False
        assert (
            VectorStoreAdapterFactory.is_provider_supported("PROVIDER1") is True
        )  # Case insensitive

    def test_is_combination_supported(self):
        """Test checking if provider-framework combination is supported."""
        # Clear and add test combinations
        VectorStoreAdapterFactory._ADAPTERS.clear()
        VectorStoreAdapterFactory._ADAPTERS["provider1:framework1"] = MockAdapter
        VectorStoreAdapterFactory._ADAPTERS["provider1:framework2"] = MockAdapter

        assert (
            VectorStoreAdapterFactory.is_combination_supported(
                "provider1", "framework1"
            )
            is True
        )
        assert (
            VectorStoreAdapterFactory.is_combination_supported(
                "provider1", "framework2"
            )
            is True
        )
        assert (
            VectorStoreAdapterFactory.is_combination_supported(
                "provider1", "framework3"
            )
            is False
        )
        assert (
            VectorStoreAdapterFactory.is_combination_supported(
                "provider2", "framework1"
            )
            is False
        )
        assert (
            VectorStoreAdapterFactory.is_combination_supported(
                "PROVIDER1", "FRAMEWORK1"
            )
            is True
        )  # Case insensitive

    def test_empty_registry(self):
        """Test behavior with empty registry."""
        # Clear registry
        VectorStoreAdapterFactory._ADAPTERS.clear()

        assert VectorStoreAdapterFactory.get_supported_providers() == []
        assert VectorStoreAdapterFactory.get_supported_combinations() == []
        assert VectorStoreAdapterFactory.is_provider_supported("any") is False
        assert VectorStoreAdapterFactory.is_combination_supported("any", "any") is False

    def test_adapter_key_format(self):
        """Test that adapter keys use correct format."""
        # Clear registry
        VectorStoreAdapterFactory._ADAPTERS.clear()

        VectorStoreAdapterFactory.register_adapter("Provider", "Framework", MockAdapter)

        # Check that key is stored in lowercase format
        assert "provider:framework" in VectorStoreAdapterFactory._ADAPTERS
        assert "Provider:Framework" not in VectorStoreAdapterFactory._ADAPTERS

    def test_create_adapter_with_complex_config(self):
        """Test adapter creation with complex configuration object."""

        class ComplexConfig(VectorStoreConfigProtocol):
            def __init__(self):
                self.provider = "test"
                self.framework = "mock"
                self.custom_field = "custom_value"

        config = ComplexConfig()
        adapter = VectorStoreAdapterFactory.create_adapter(config)

        assert isinstance(adapter, MockAdapter)
        assert adapter.config == config

    def test_factory_methods_are_class_methods(self):
        """Test that all factory methods are class methods."""
        methods = [
            "create_adapter",
            "get_supported_providers",
            "get_supported_frameworks",
            "get_supported_combinations",
            "register_adapter",
            "is_provider_supported",
            "is_combination_supported",
        ]

        for method_name in methods:
            method = getattr(VectorStoreAdapterFactory, method_name)
            assert callable(method)


class TestRegisterVectorStoreAdapterDecorator:
    """Test cases for the register_vector_store_adapter decorator."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Clear the registry before each test
        VectorStoreAdapterFactory._ADAPTERS.clear()

    def test_decorator_registration(self):
        """Test that decorator properly registers adapter."""
        # Clear registry
        VectorStoreAdapterFactory._ADAPTERS.clear()

        # Use decorator to register adapter
        @register_vector_store_adapter("decorator_provider", "decorator_framework")
        class DecoratedAdapter(MockAdapter):
            pass

        # Verify registration
        assert (
            "decorator_provider:decorator_framework"
            in VectorStoreAdapterFactory._ADAPTERS
        )
        assert (
            VectorStoreAdapterFactory._ADAPTERS[
                "decorator_provider:decorator_framework"
            ]
            == DecoratedAdapter
        )

    def test_decorator_case_insensitive(self):
        """Test that decorator handles case insensitive registration."""
        # Clear registry
        VectorStoreAdapterFactory._ADAPTERS.clear()

        @register_vector_store_adapter("Provider", "Framework")
        class DecoratedAdapter(MockAdapter):
            pass

        # Should be stored in lowercase
        assert "provider:framework" in VectorStoreAdapterFactory._ADAPTERS

    def test_decorator_returns_original_class(self):
        """Test that decorator returns the original class unchanged."""
        # Clear registry
        VectorStoreAdapterFactory._ADAPTERS.clear()

        @register_vector_store_adapter("test_provider", "test_framework")
        class OriginalClass(MockAdapter):
            def custom_method(self):
                return "custom"

        # Verify the class is unchanged
        assert OriginalClass.__name__ == "OriginalClass"
        assert hasattr(OriginalClass, "custom_method")

        # Verify it was registered
        assert "test_provider:test_framework" in VectorStoreAdapterFactory._ADAPTERS

    def test_decorator_multiple_registrations(self):
        """Test multiple decorator registrations."""
        # Clear registry
        VectorStoreAdapterFactory._ADAPTERS.clear()

        @register_vector_store_adapter("provider1", "framework1")
        class Adapter1(MockAdapter):
            pass

        @register_vector_store_adapter("provider2", "framework1")
        class Adapter2(MockAdapter):
            pass

        @register_vector_store_adapter("provider1", "framework2")
        class Adapter3(MockAdapter):
            pass

        # Verify all registrations
        assert "provider1:framework1" in VectorStoreAdapterFactory._ADAPTERS
        assert "provider2:framework1" in VectorStoreAdapterFactory._ADAPTERS
        assert "provider1:framework2" in VectorStoreAdapterFactory._ADAPTERS
        assert VectorStoreAdapterFactory._ADAPTERS["provider1:framework1"] == Adapter1
        assert VectorStoreAdapterFactory._ADAPTERS["provider2:framework1"] == Adapter2
        assert VectorStoreAdapterFactory._ADAPTERS["provider1:framework2"] == Adapter3

    def test_decorator_overwrite_existing(self):
        """Test that decorator overwrites existing registrations."""
        # Clear registry
        VectorStoreAdapterFactory._ADAPTERS.clear()

        @register_vector_store_adapter("test", "test")
        class FirstAdapter(MockAdapter):
            pass

        @register_vector_store_adapter("test", "test")
        class SecondAdapter(MockAdapter):
            pass

        # Second registration should overwrite first
        assert VectorStoreAdapterFactory._ADAPTERS["test:test"] == SecondAdapter


class TestVectorStoreConfigProtocol:
    """Test cases for VectorStoreConfigProtocol."""

    def test_protocol_has_required_attributes(self):
        """Test that protocol defines required attributes."""
        # Check that the protocol has the required attributes
        # Note: Protocols don't have attributes in the traditional sense,
        # they define the interface that implementing classes must have
        assert True  # This test is more about the protocol existing

    def test_protocol_is_runtime_checkable(self):
        """Test that protocol is runtime checkable."""

        # Create a mock config that implements the protocol
        class TestConfig:
            def __init__(self):
                self.provider = "test"
                self.framework = "mock"

        config = TestConfig()

        # Should be recognized as implementing the protocol
        assert isinstance(config, VectorStoreConfigProtocol)

    def test_protocol_validation_missing_provider(self):
        """Test protocol validation with missing provider."""

        class InvalidConfig:
            def __init__(self):
                self.framework = "mock"
                # Missing provider

        config = InvalidConfig()

        # Should not be recognized as implementing the protocol
        assert not isinstance(config, VectorStoreConfigProtocol)

    def test_protocol_validation_missing_framework(self):
        """Test protocol validation with missing framework."""

        class InvalidConfig:
            def __init__(self):
                self.provider = "test"
                # Missing framework

        config = InvalidConfig()

        # Should not be recognized as implementing the protocol
        assert not isinstance(config, VectorStoreConfigProtocol)

    def test_protocol_with_properties(self):
        """Test protocol with properties instead of attributes."""

        class ConfigWithProperties:
            @property
            def provider(self):
                return "test"

            @property
            def framework(self):
                return "mock"

        config = ConfigWithProperties()

        # Should be recognized as implementing the protocol
        assert isinstance(config, VectorStoreConfigProtocol)

"""Tests for LlamaIndex vector store adapters."""

"""Tests for BaseVectorStoreAdapter."""

import pytest
from unittest.mock import MagicMock, patch
from typing import Any

from axolotl.vector_store.adapters.base import BaseVectorStoreAdapter
from axolotl.vector_store.domain.document import DocumentChunk, ScoredDocumentChunk
from axolotl.vector_store.domain.query import TextQuery
from axolotl.vector_store.exceptions import VectorStoreError


class ConcreteVectorStoreAdapter(BaseVectorStoreAdapter):
    """Concrete implementation of BaseVectorStoreAdapter for testing."""

    def _add_documents_impl(
        self, documents: list[DocumentChunk], index_name: str
    ) -> list[str]:
        """Implementation of add_documents."""
        return [doc.id for doc in documents]

    def _search_impl(
        self, query: TextQuery, index_name: str
    ) -> list[ScoredDocumentChunk]:
        """Implementation of search."""
        return []

    def _get_document_impl(self, document_id: str, index_name: str) -> DocumentChunk:
        """Implementation of get_document."""
        return DocumentChunk(id=document_id, content="test content")

    def _delete_documents_impl(self, document_ids: list[str], index_name: str) -> bool:
        """Implementation of delete_documents."""
        return True

    def _create_index_impl(self, index_name: str, **index_config: Any) -> bool:
        """Implementation of create_index."""
        return True

    def _delete_index_impl(self, index_name: str) -> bool:
        """Implementation of delete_index."""
        return True

    def _index_exists_impl(self, index_name: str) -> bool:
        """Implementation of index_exists."""
        return False

    def _list_indices_impl(self) -> list[str]:
        """Implementation of list_indices."""
        return []


class TestBaseVectorStoreAdapter:
    """Test cases for BaseVectorStoreAdapter."""

    def test_base_adapter_cannot_be_instantiated_directly(self):
        """Test that BaseVectorStoreAdapter cannot be instantiated directly."""
        with pytest.raises(TypeError):
            BaseVectorStoreAdapter()

    def test_concrete_adapter_can_be_instantiated(self):
        """Test that concrete implementation can be instantiated."""
        adapter = ConcreteVectorStoreAdapter()
        assert isinstance(adapter, BaseVectorStoreAdapter)

    def test_adapter_initialization(self):
        """Test adapter initialization with default values."""
        adapter = ConcreteVectorStoreAdapter()

        assert adapter._client is None
        assert adapter.logger is not None
        assert adapter.logger.name == "ConcreteVectorStoreAdapter"

    def test_adapter_initialization_with_kwargs(self):
        """Test adapter initialization with additional kwargs."""
        adapter = ConcreteVectorStoreAdapter(custom_param="value", another_param=42)

        # Should not raise any errors
        assert adapter._client is None

    def test_client_property(self):
        """Test client property access."""
        adapter = ConcreteVectorStoreAdapter()

        # Initially None
        assert adapter.client is None

        # Set a mock client
        mock_client = MagicMock()
        adapter._client = mock_client
        assert adapter.client is mock_client

    # Tests for add_documents method

    def test_add_documents_success(self):
        """Test successful add_documents operation."""
        adapter = ConcreteVectorStoreAdapter()

        documents = [
            DocumentChunk(id="doc1", content="content1"),
            DocumentChunk(id="doc2", content="content2"),
        ]

        result = adapter.add_documents(documents, "test_index")

        assert result == ["doc1", "doc2"]

    def test_add_documents_empty_list(self):
        """Test add_documents with empty document list."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.add_documents([], "test_index")

        assert "Documents list cannot be empty" in str(exc_info.value)

    def test_add_documents_empty_index_name(self):
        """Test add_documents with empty index name."""
        adapter = ConcreteVectorStoreAdapter()
        documents = [DocumentChunk(id="doc1", content="content1")]

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.add_documents(documents, "")

        assert "Index name cannot be empty or whitespace only" in str(exc_info.value)

    def test_add_documents_whitespace_index_name(self):
        """Test add_documents with whitespace-only index name."""
        adapter = ConcreteVectorStoreAdapter()
        documents = [DocumentChunk(id="doc1", content="content1")]

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.add_documents(documents, "   ")

        assert "Index name cannot be empty or whitespace only" in str(exc_info.value)

    def test_add_documents_empty_content(self):
        """Test add_documents with document having empty content."""
        adapter = ConcreteVectorStoreAdapter()

        # Create documents with empty content using a different approach
        # since Pydantic validation will catch empty content before our validation
        documents = [
            DocumentChunk(id="doc1", content="valid content"),
            DocumentChunk(id="doc2", content="   "),  # Whitespace only content
            DocumentChunk(id="doc3", content="another valid content"),
        ]

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.add_documents(documents, "test_index")

        assert "Document at index 1 cannot have empty content" in str(exc_info.value)

    def test_add_documents_whitespace_content(self):
        """Test add_documents with document having whitespace-only content."""
        adapter = ConcreteVectorStoreAdapter()

        documents = [
            DocumentChunk(id="doc1", content="valid content"),
            DocumentChunk(id="doc2", content="   "),  # Whitespace only
        ]

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.add_documents(documents, "test_index")

        assert "Document at index 1 cannot have empty content" in str(exc_info.value)

    def test_add_documents_implementation_error(self):
        """Test add_documents when implementation raises an error."""
        adapter = ConcreteVectorStoreAdapter()

        # Mock the implementation to raise an error
        def failing_impl(documents, index_name):
            raise RuntimeError("Implementation failed")

        adapter._add_documents_impl = failing_impl

        documents = [DocumentChunk(id="doc1", content="content1")]

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.add_documents(documents, "test_index")

        assert "Failed to add documents to index 'test_index'" in str(exc_info.value)
        assert "Implementation failed" in str(exc_info.value)
        assert exc_info.value.details["index_name"] == "test_index"
        assert exc_info.value.details["document_count"] == 1

    # Tests for search method

    def test_search_success(self):
        """Test successful search operation."""
        adapter = ConcreteVectorStoreAdapter()

        query = TextQuery(text="test query", limit=5)
        result = adapter.search(query, "test_index")

        assert result == []

    def test_search_empty_query_text(self):
        """Test search with empty query text."""
        adapter = ConcreteVectorStoreAdapter()

        # Create query with whitespace-only text since Pydantic validation catches empty text
        query = TextQuery(text="   ", limit=5)

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.search(query, "test_index")

        assert "Query text cannot be empty or whitespace only" in str(exc_info.value)

    def test_search_whitespace_query_text(self):
        """Test search with whitespace-only query text."""
        adapter = ConcreteVectorStoreAdapter()

        query = TextQuery(text="   ", limit=5)

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.search(query, "test_index")

        assert "Query text cannot be empty or whitespace only" in str(exc_info.value)

    def test_search_empty_index_name(self):
        """Test search with empty index name."""
        adapter = ConcreteVectorStoreAdapter()
        query = TextQuery(text="test query")

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.search(query, "")

        assert "Index name cannot be empty or whitespace only" in str(exc_info.value)

    def test_search_implementation_error(self):
        """Test search when implementation raises an error."""
        adapter = ConcreteVectorStoreAdapter()

        def failing_impl(query, index_name):
            raise RuntimeError("Search failed")

        adapter._search_impl = failing_impl

        query = TextQuery(text="test query")

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.search(query, "test_index")

        assert "Failed to search index 'test_index'" in str(exc_info.value)
        assert "Search failed" in str(exc_info.value)
        assert exc_info.value.details["index_name"] == "test_index"
        assert exc_info.value.details["query_text_length"] == 10
        assert exc_info.value.details["query_limit"] == 10

    # Tests for get_document method

    def test_get_document_success(self):
        """Test successful get_document operation."""
        adapter = ConcreteVectorStoreAdapter()

        result = adapter.get_document("doc1", "test_index")

        assert isinstance(result, DocumentChunk)
        assert result.id == "doc1"
        assert result.content == "test content"

    def test_get_document_empty_document_id(self):
        """Test get_document with empty document ID."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.get_document("", "test_index")

        assert "Document ID cannot be empty or whitespace only" in str(exc_info.value)

    def test_get_document_whitespace_document_id(self):
        """Test get_document with whitespace-only document ID."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.get_document("   ", "test_index")

        assert "Document ID cannot be empty or whitespace only" in str(exc_info.value)

    def test_get_document_empty_index_name(self):
        """Test get_document with empty index name."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.get_document("doc1", "")

        assert "Index name cannot be empty or whitespace only" in str(exc_info.value)

    def test_get_document_implementation_error(self):
        """Test get_document when implementation raises an error."""
        adapter = ConcreteVectorStoreAdapter()

        def failing_impl(document_id, index_name):
            raise RuntimeError("Get document failed")

        adapter._get_document_impl = failing_impl

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.get_document("doc1", "test_index")

        assert "Failed to get document 'doc1' from index 'test_index'" in str(
            exc_info.value
        )
        assert "Get document failed" in str(exc_info.value)
        assert exc_info.value.details["document_id"] == "doc1"
        assert exc_info.value.details["index_name"] == "test_index"

    # Tests for delete_documents method

    def test_delete_documents_success(self):
        """Test successful delete_documents operation."""
        adapter = ConcreteVectorStoreAdapter()

        result = adapter.delete_documents(["doc1", "doc2"], "test_index")

        assert result is True

    def test_delete_documents_empty_list(self):
        """Test delete_documents with empty document IDs list."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.delete_documents([], "test_index")

        assert "Document IDs list cannot be empty" in str(exc_info.value)

    def test_delete_documents_empty_index_name(self):
        """Test delete_documents with empty index name."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.delete_documents(["doc1"], "")

        assert "Index name cannot be empty or whitespace only" in str(exc_info.value)

    def test_delete_documents_empty_document_id(self):
        """Test delete_documents with empty document ID in list."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.delete_documents(["doc1", "", "doc3"], "test_index")

        assert "Document ID at index 1 cannot be empty or whitespace only" in str(
            exc_info.value
        )

    def test_delete_documents_whitespace_document_id(self):
        """Test delete_documents with whitespace-only document ID in list."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.delete_documents(["doc1", "   ", "doc3"], "test_index")

        assert "Document ID at index 1 cannot be empty or whitespace only" in str(
            exc_info.value
        )

    def test_delete_documents_implementation_error(self):
        """Test delete_documents when implementation raises an error."""
        adapter = ConcreteVectorStoreAdapter()

        def failing_impl(document_ids, index_name):
            raise RuntimeError("Delete failed")

        adapter._delete_documents_impl = failing_impl

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.delete_documents(["doc1", "doc2"], "test_index")

        assert "Failed to delete documents from index 'test_index'" in str(
            exc_info.value
        )
        assert "Delete failed" in str(exc_info.value)
        assert exc_info.value.details["index_name"] == "test_index"
        assert exc_info.value.details["document_count"] == 2

    # Tests for create_index method

    def test_create_index_success(self):
        """Test successful create_index operation."""
        adapter = ConcreteVectorStoreAdapter()

        result = adapter.create_index("test_index", dimension=384)

        assert result is True

    def test_create_index_empty_name(self):
        """Test create_index with empty index name."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.create_index("", dimension=384)

        assert "Index name cannot be empty or whitespace only" in str(exc_info.value)

    def test_create_index_whitespace_name(self):
        """Test create_index with whitespace-only index name."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.create_index("   ", dimension=384)

        assert "Index name cannot be empty or whitespace only" in str(exc_info.value)

    def test_create_index_implementation_error(self):
        """Test create_index when implementation raises an error."""
        adapter = ConcreteVectorStoreAdapter()

        def failing_impl(index_name, **config):
            raise RuntimeError("Create index failed")

        adapter._create_index_impl = failing_impl

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.create_index("test_index", dimension=384)

        assert "Failed to create index 'test_index'" in str(exc_info.value)
        assert "Create index failed" in str(exc_info.value)
        assert exc_info.value.details["index_name"] == "test_index"
        assert "dimension" in exc_info.value.details["config_keys"]

    # Tests for delete_index method

    def test_delete_index_success(self):
        """Test successful delete_index operation."""
        adapter = ConcreteVectorStoreAdapter()

        result = adapter.delete_index("test_index")

        assert result is True

    def test_delete_index_empty_name(self):
        """Test delete_index with empty index name."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.delete_index("")

        assert "Index name cannot be empty or whitespace only" in str(exc_info.value)

    def test_delete_index_implementation_error(self):
        """Test delete_index when implementation raises an error."""
        adapter = ConcreteVectorStoreAdapter()

        def failing_impl(index_name):
            raise RuntimeError("Delete index failed")

        adapter._delete_index_impl = failing_impl

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.delete_index("test_index")

        assert "Failed to delete index 'test_index'" in str(exc_info.value)
        assert "Delete index failed" in str(exc_info.value)
        assert exc_info.value.details["index_name"] == "test_index"

    # Tests for index_exists method

    def test_index_exists_success(self):
        """Test successful index_exists operation."""
        adapter = ConcreteVectorStoreAdapter()

        result = adapter.index_exists("test_index")

        assert result is False  # Our mock implementation returns False

    def test_index_exists_empty_name(self):
        """Test index_exists with empty index name."""
        adapter = ConcreteVectorStoreAdapter()

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.index_exists("")

        assert "Index name cannot be empty or whitespace only" in str(exc_info.value)

    def test_index_exists_implementation_error(self):
        """Test index_exists when implementation raises an error."""
        adapter = ConcreteVectorStoreAdapter()

        def failing_impl(index_name):
            raise RuntimeError("Index exists check failed")

        adapter._index_exists_impl = failing_impl

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.index_exists("test_index")

        assert "Failed to check if index 'test_index' exists" in str(exc_info.value)
        assert "Index exists check failed" in str(exc_info.value)
        assert exc_info.value.details["index_name"] == "test_index"

    # Tests for list_indices method

    def test_list_indices_success(self):
        """Test successful list_indices operation."""
        adapter = ConcreteVectorStoreAdapter()

        result = adapter.list_indices()

        assert result == []  # Our mock implementation returns empty list

    def test_list_indices_implementation_error(self):
        """Test list_indices when implementation raises an error."""
        adapter = ConcreteVectorStoreAdapter()

        def failing_impl():
            raise RuntimeError("List indices failed")

        adapter._list_indices_impl = failing_impl

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.list_indices()

        assert "Failed to list indices" in str(exc_info.value)
        assert "List indices failed" in str(exc_info.value)

    # Tests for logging

    def test_logging_initialization(self):
        """Test that logger is properly initialized."""
        adapter = ConcreteVectorStoreAdapter()

        assert adapter.logger is not None
        assert adapter.logger.name == "ConcreteVectorStoreAdapter"

    @patch("axolotl.vector_store.adapters.base.logging.getLogger")
    def test_logging_get_logger_called(self, mock_get_logger):
        """Test that logging.getLogger is called with correct class name."""
        mock_logger = MagicMock()
        mock_get_logger.return_value = mock_logger

        adapter = ConcreteVectorStoreAdapter()

        mock_get_logger.assert_called_once_with("ConcreteVectorStoreAdapter")
        assert adapter.logger is mock_logger

    # Tests for abstract method requirements

    def test_abstract_methods_are_abstract(self):
        """Test that all implementation methods are abstract in base class."""
        abstract_methods = [
            "_add_documents_impl",
            "_search_impl",
            "_get_document_impl",
            "_delete_documents_impl",
            "_create_index_impl",
            "_delete_index_impl",
            "_index_exists_impl",
            "_list_indices_impl",
        ]

        for method_name in abstract_methods:
            method = getattr(BaseVectorStoreAdapter, method_name)
            assert getattr(method, "__isabstractmethod__", False)

    def test_concrete_implementation_implements_all_abstract_methods(self):
        """Test that concrete implementation implements all abstract methods."""
        adapter = ConcreteVectorStoreAdapter()

        abstract_methods = [
            "_add_documents_impl",
            "_search_impl",
            "_get_document_impl",
            "_delete_documents_impl",
            "_create_index_impl",
            "_delete_index_impl",
            "_index_exists_impl",
            "_list_indices_impl",
        ]

        for method_name in abstract_methods:
            method = getattr(adapter, method_name)
            assert callable(method)
            assert not getattr(method, "__isabstractmethod__", False)

    # Tests for error details

    def test_error_details_contain_relevant_information(self):
        """Test that error details contain relevant information."""
        adapter = ConcreteVectorStoreAdapter()

        def failing_impl(documents, index_name):
            raise RuntimeError("Test error")

        adapter._add_documents_impl = failing_impl

        documents = [DocumentChunk(id="doc1", content="content1")]

        with pytest.raises(VectorStoreError) as exc_info:
            adapter.add_documents(documents, "test_index")

        error = exc_info.value
        assert error.details["index_name"] == "test_index"
        assert error.details["document_count"] == 1

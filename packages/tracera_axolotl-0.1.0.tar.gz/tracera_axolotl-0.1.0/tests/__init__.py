"""Tests for axolotl package."""

"""Tests for LLM domain models."""

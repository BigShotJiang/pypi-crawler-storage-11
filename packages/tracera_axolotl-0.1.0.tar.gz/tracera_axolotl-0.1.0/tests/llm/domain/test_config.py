"""Tests for LLM configuration models."""

import pytest
from pydantic import ValidationError

from axolotl.llm.domain.config import (
    LLMConfig,
    LLMParameters,
    BedrockProviderConfig,
    OpenAIProviderConfig,
    ProviderConfigRegistry,
)


class TestLLMParameters:
    """Test cases for LLMParameters."""

    def test_llm_parameters_defaults(self):
        """Test LLMParameters with default values."""
        params = LLMParameters()

        assert params.temperature == 0.7
        assert params.max_tokens == 512
        assert params.top_p == 0.9

    def test_llm_parameters_custom_values(self):
        """Test LLMParameters with custom values."""
        params = LLMParameters(temperature=0.3, max_tokens=1024, top_p=0.8)

        assert params.temperature == 0.3
        assert params.max_tokens == 1024
        assert params.top_p == 0.8

    def test_llm_parameters_validation(self):
        """Test LLMParameters validation."""
        # Valid values
        params = LLMParameters(temperature=0.0, top_p=1.0, max_tokens=1)
        assert params.temperature == 0.0
        assert params.top_p == 1.0
        assert params.max_tokens == 1

        # Invalid temperature
        with pytest.raises(ValidationError):
            LLMParameters(temperature=1.5)

        # Invalid top_p
        with pytest.raises(ValidationError):
            LLMParameters(top_p=1.5)

        # Invalid max_tokens
        with pytest.raises(ValidationError):
            LLMParameters(max_tokens=0)


class TestBedrockProviderConfig:
    """Test cases for BedrockProviderConfig."""

    def test_bedrock_provider_config_defaults(self):
        """Test BedrockProviderConfig with default values."""
        config = BedrockProviderConfig()

        assert config.region == "us-east-1"  # default
        assert config.access_key_id is None
        assert config.secret_access_key is None
        assert config.session_token is None
        assert config.profile_name is None

    def test_bedrock_provider_config_custom_values(self):
        """Test BedrockProviderConfig with custom values."""
        config = BedrockProviderConfig(
            region="us-west-2",
            access_key_id="test-key",  # pragma: allowlist secret  # pragma: allowlist secret
            secret_access_key="test-secret",  # pragma: allowlist secret
            session_token="test-token",  # pragma: allowlist secret
            profile_name="test-profile",  # pragma: allowlist secret
        )

        assert config.region == "us-west-2"
        assert config.access_key_id == "test-key"  # pragma: allowlist secret
        assert config.secret_access_key == "test-secret"  # pragma: allowlist secret
        assert config.session_token == "test-token"  # pragma: allowlist secret
        assert config.profile_name == "test-profile"  # pragma: allowlist secret


class TestOpenAIProviderConfig:
    """Test cases for OpenAIProviderConfig."""

    def test_openai_provider_config_defaults(self):
        """Test OpenAIProviderConfig with default values."""
        config = OpenAIProviderConfig()

        assert config.api_key == ""  # Defaults to empty string when no env var is set
        assert config.base_url is None

    def test_openai_provider_config_custom_values(self):
        """Test OpenAIProviderConfig with custom values."""
        config = OpenAIProviderConfig(
            api_key="test-key",  # pragma: allowlist secret
            base_url="https://api.openai.com/v1",  # pragma: allowlist secret
        )

        assert config.api_key == "test-key"  # pragma: allowlist secret
        assert config.base_url == "https://api.openai.com/v1"


class TestProviderConfigRegistry:
    """Test cases for ProviderConfigRegistry."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Store original registry state
        self._original_providers = ProviderConfigRegistry._providers.copy()

    def teardown_method(self):
        """Clean up after each test method."""
        # Restore original registry state
        ProviderConfigRegistry._providers.clear()
        ProviderConfigRegistry._providers.update(self._original_providers)

    def test_register_decorator(self):
        """Test the register decorator functionality."""
        from pydantic import BaseModel

        class TestProviderConfig(BaseModel):
            test_field: str = "test"

        # Register the provider config
        registered_config = ProviderConfigRegistry.register("test")(TestProviderConfig)

        # Should return the same class
        assert registered_config is TestProviderConfig

        # Should be registered in the registry
        assert "test" in ProviderConfigRegistry._providers
        assert ProviderConfigRegistry._providers["test"] is TestProviderConfig

    def test_create_config_existing_provider(self):
        """Test creating config for existing provider."""
        from pydantic import BaseModel

        class TestProviderConfig(BaseModel):
            test_field: str = "test"

        # Register the provider config
        ProviderConfigRegistry.register("test")(TestProviderConfig)

        # Create config instance
        config = ProviderConfigRegistry.create_config("test", test_field="custom")

        assert isinstance(config, TestProviderConfig)
        assert config.test_field == "custom"

    def test_create_config_nonexistent_provider(self):
        """Test creating config for non-existent provider."""
        with pytest.raises(ValueError) as exc_info:
            ProviderConfigRegistry.create_config("nonexistent", test_field="test")

        assert "Unsupported provider: nonexistent" in str(exc_info.value)
        assert "Available providers:" in str(exc_info.value)

    def test_get_available_providers(self):
        """Test getting available providers."""
        from pydantic import BaseModel

        class TestProviderConfig1(BaseModel):
            field1: str = "test1"

        class TestProviderConfig2(BaseModel):
            field2: str = "test2"

        # Initially should have bedrock and openai
        providers = ProviderConfigRegistry.get_available_providers()
        assert "bedrock" in providers
        assert "openai" in providers

        # Register additional providers
        ProviderConfigRegistry.register("test1")(TestProviderConfig1)
        ProviderConfigRegistry.register("test2")(TestProviderConfig2)

        # Should include new providers
        providers = ProviderConfigRegistry.get_available_providers()
        assert "test1" in providers
        assert "test2" in providers


class TestLLMConfig:
    """Test cases for LLMConfig."""

    def test_llm_config_creation_with_automatic_provider_config_bedrock(self):
        """Test creating LLMConfig with automatic Bedrock provider config selection."""
        config = LLMConfig(
            provider="bedrock",
            model_name="claude-3-sonnet-20240229-v1:0",
            region="us-west-2",
        )

        assert config.provider == "bedrock"
        assert config.model_name == "claude-3-sonnet-20240229-v1:0"
        assert config.framework == "langchain"  # default
        assert config.parameters.temperature == 0.7  # default
        assert config.parameters.max_tokens == 512  # default
        assert config.parameters.top_p == 0.9  # default
        assert config.provider_config.region == "us-west-2"
        assert config.framework_options == {}  # default

    def test_llm_config_creation_with_automatic_provider_config_openai(self):
        """Test creating LLMConfig with automatic OpenAI provider config selection."""
        config = LLMConfig(
            provider="openai",
            model_name="gpt-4",
            api_key="test-key",  # pragma: allowlist secret
            base_url="https://api.openai.com/v1",
        )

        assert config.provider == "openai"
        assert config.model_name == "gpt-4"
        assert config.framework == "langchain"  # default
        assert config.parameters.temperature == 0.7  # default
        assert config.parameters.max_tokens == 512  # default
        assert config.parameters.top_p == 0.9  # default
        assert config.provider_config.api_key == "test-key"  # pragma: allowlist secret
        assert config.provider_config.base_url == "https://api.openai.com/v1"
        assert config.framework_options == {}  # default

    def test_llm_config_creation_with_explicit_provider_config(self):
        """Test creating LLMConfig with explicit provider config."""
        config = LLMConfig(
            provider="bedrock",
            model_name="claude-3-sonnet-20240229-v1:0",
            provider_config=BedrockProviderConfig(region="us-west-2"),
        )

        assert config.provider == "bedrock"
        assert config.model_name == "claude-3-sonnet-20240229-v1:0"
        assert config.framework == "langchain"  # default
        assert config.provider_config.region == "us-west-2"

    def test_llm_config_creation_with_all_fields(self):
        """Test creating LLMConfig with all fields."""
        config = LLMConfig(
            provider="openai",
            framework="llamaindex",
            model_name="gpt-4",
            parameters=LLMParameters(temperature=0.5, max_tokens=1024, top_p=0.8),
            provider_config=OpenAIProviderConfig(
                api_key="test-key",  # pragma: allowlist secret
                base_url="https://api.openai.com/v1",
            ),
            framework_options={"stream": True},
        )

        assert config.provider == "openai"
        assert config.framework == "llamaindex"
        assert config.model_name == "gpt-4"
        assert config.parameters.temperature == 0.5
        assert config.parameters.max_tokens == 1024
        assert config.parameters.top_p == 0.8
        assert config.provider_config.api_key == "test-key"  # pragma: allowlist secret
        assert config.provider_config.base_url == "https://api.openai.com/v1"
        assert config.framework_options == {"stream": True}

    def test_llm_config_creation_with_provider_kwargs_and_explicit_config_error(self):
        """Test that providing both provider_kwargs and explicit provider_config raises error."""
        with pytest.raises(ValueError) as exc_info:
            LLMConfig(
                provider="bedrock",
                model_name="test",
                provider_config=BedrockProviderConfig(region="us-west-2"),
                region="us-east-1",  # This should cause an error
            )

        assert "Cannot provide both provider_config and provider_kwargs" in str(
            exc_info.value
        )

    def test_llm_config_invalid_provider(self):
        """Test LLMConfig with invalid provider."""
        with pytest.raises(ValueError) as exc_info:
            LLMConfig(provider="invalid", model_name="test")

        assert "Unsupported provider: invalid" in str(exc_info.value)

    def test_llm_config_invalid_framework(self):
        """Test LLMConfig with invalid framework."""
        with pytest.raises(ValidationError) as exc_info:
            LLMConfig(provider="bedrock", model_name="test", framework="invalid")

        assert "Input should be 'langchain', 'llamaindex' or 'direct'" in str(
            exc_info.value
        )

    def test_llm_config_missing_required_fields(self):
        """Test LLMConfig with missing required fields."""
        with pytest.raises(TypeError) as exc_info:
            LLMConfig(provider="bedrock")

        assert "missing 1 required positional argument: 'model_name'" in str(
            exc_info.value
        )

    def test_llm_config_unsupported_provider_in_kwargs(self):
        """Test LLMConfig with unsupported provider in kwargs."""
        with pytest.raises(ValueError) as exc_info:
            LLMConfig(
                provider="azure",  # This will pass Pydantic validation but fail in registry
                model_name="test",
            )

        assert "Unsupported provider: azure" in str(exc_info.value)

    def test_llm_config_get_available_providers(self):
        """Test getting available providers from LLMConfig."""
        providers = LLMConfig.get_available_providers()

        # Should include the registered providers
        assert "bedrock" in providers
        assert "openai" in providers
        assert isinstance(providers, list)

    def test_llm_config_automatic_provider_config_with_custom_parameters(self):
        """Test automatic provider config with custom parameters."""
        custom_params = LLMParameters(temperature=0.5, max_tokens=1000)
        custom_options = {"stream": True, "callbacks": ["test"]}

        config = LLMConfig(
            provider="bedrock",
            model_name="claude-3-haiku",
            framework="llamaindex",
            parameters=custom_params,
            framework_options=custom_options,
            region="us-east-1",
            access_key_id="test-key",  # pragma: allowlist secret
        )

        assert config.provider == "bedrock"
        assert config.model_name == "claude-3-haiku"
        assert config.framework == "llamaindex"
        assert config.parameters.temperature == 0.5
        assert config.parameters.max_tokens == 1000
        assert config.framework_options == custom_options
        assert config.provider_config.region == "us-east-1"
        assert (
            config.provider_config.access_key_id == "test-key"
        )  # pragma: allowlist secret

    def test_llm_config_automatic_provider_config_openai_with_custom_parameters(self):
        """Test automatic provider config with OpenAI and custom parameters."""
        config = LLMConfig(
            provider="openai",
            model_name="gpt-4",
            framework="llamaindex",
            parameters=LLMParameters(temperature=0.3, max_tokens=2048),
            api_key="sk-test",  # pragma: allowlist secret
            base_url="https://api.openai.com/v1",
        )

        assert config.provider == "openai"
        assert config.model_name == "gpt-4"
        assert config.framework == "llamaindex"
        assert config.provider_config.api_key == "sk-test"  # pragma: allowlist secret
        assert config.provider_config.base_url == "https://api.openai.com/v1"
        assert config.parameters.temperature == 0.3
        assert config.parameters.max_tokens == 2048

    def test_llm_config_environment_variable_defaults(self):
        """Test that environment variables are used as defaults."""
        import os
        from unittest.mock import patch

        with patch.dict(
            os.environ,
            {
                "AWS_REGION": "us-west-2",
                "AWS_ACCESS_KEY_ID": "env-key",
                "OPENAI_API_KEY": "env-openai-key",  # pragma: allowlist secret
            },
        ):
            # Test Bedrock with environment variables
            bedrock_config = LLMConfig("bedrock", "claude-3-sonnet")
            assert bedrock_config.provider_config.region == "us-west-2"
            assert bedrock_config.provider_config.access_key_id == "env-key"

            # Test OpenAI with environment variables
            openai_config = LLMConfig("openai", "gpt-4")
            assert (
                openai_config.provider_config.api_key
                == "env-openai-key"  # pragma: allowlist secret
            )

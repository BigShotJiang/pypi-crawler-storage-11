"""Integration tests for the LLM module."""

import pytest
from unittest.mock import MagicMock, patch

from axolotl.llm import LLMClientFactory, LLMConfig
from axolotl.llm.domain.config import LLMParameters, BedrockProviderConfig
from axolotl.llm.exceptions import LLMError

# Import adapters to register them


class TestLLMIntegration:
    """Integration tests for the LLM module."""

    def test_end_to_end_bedrock_langchain_automatic_config(self):
        """Test end-to-end Bedrock with LangChain using automatic provider config."""
        with patch(
            "axolotl.llm.adapters.langchain.bedrock.ChatBedrock"
        ) as mock_chat_bedrock:
            mock_client = MagicMock()
            mock_chat_bedrock.return_value = mock_client

            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                region="us-east-1",
            )

            client = LLMClientFactory.create_client(config)

            assert client == mock_client
            mock_chat_bedrock.assert_called_once()

    def test_end_to_end_bedrock_langchain_explicit_config(self):
        """Test end-to-end Bedrock with LangChain using explicit provider config."""
        with patch(
            "axolotl.llm.adapters.langchain.bedrock.ChatBedrock"
        ) as mock_chat_bedrock:
            mock_client = MagicMock()
            mock_chat_bedrock.return_value = mock_client

            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                parameters=LLMParameters(),
                provider_config=BedrockProviderConfig(region="us-east-1"),
            )

            client = LLMClientFactory.create_client(config)

            assert client == mock_client
            mock_chat_bedrock.assert_called_once()

    def test_end_to_end_bedrock_llamaindex_automatic_config(self):
        """Test end-to-end Bedrock with LlamaIndex using automatic provider config."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                region="us-east-1",
            )

            client = LLMClientFactory.create_client(config)

            assert client == mock_client
            mock_bedrock_converse.assert_called_once()

    def test_end_to_end_openai_langchain_automatic_config(self):
        """Test end-to-end OpenAI with LangChain using automatic provider config."""
        with patch(
            "axolotl.llm.adapters.langchain.openai.ChatOpenAI"
        ) as mock_chat_openai:
            mock_client = MagicMock()
            mock_chat_openai.return_value = mock_client

            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="langchain",
                api_key="test-key",  # pragma: allowlist secret
            )

            client = LLMClientFactory.create_client(config)

            assert client == mock_client
            mock_chat_openai.assert_called_once()

    def test_end_to_end_openai_llamaindex_automatic_config(self):
        """Test end-to-end OpenAI with LlamaIndex using automatic provider config."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                api_key="test-key",  # pragma: allowlist secret
            )

            client = LLMClientFactory.create_client(config)

            assert client == mock_client
            mock_openai.assert_called_once()

    def test_framework_switching_same_provider_automatic_config(self):
        """Test switching between frameworks for the same provider using automatic config."""
        with (
            patch(
                "axolotl.llm.adapters.langchain.bedrock.ChatBedrock"
            ) as mock_langchain,
            patch(
                "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
            ) as mock_llamaindex,
        ):
            mock_langchain_client = MagicMock()
            mock_llamaindex_client = MagicMock()
            mock_langchain.return_value = mock_langchain_client
            mock_llamaindex.return_value = mock_llamaindex_client

            # Test LangChain with automatic config
            config1 = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                region="us-east-1",
            )
            client1 = LLMClientFactory.create_client(config1)
            assert client1 == mock_langchain_client

            # Test LlamaIndex with automatic config
            config2 = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                region="us-east-1",
            )
            client2 = LLMClientFactory.create_client(config2)
            assert client2 == mock_llamaindex_client

            # Verify both were called
            mock_langchain.assert_called_once()
            mock_llamaindex.assert_called_once()

    def test_provider_switching_same_framework_automatic_config(self):
        """Test switching between providers for the same framework using automatic config."""
        with (
            patch("axolotl.llm.adapters.langchain.bedrock.ChatBedrock") as mock_bedrock,
            patch("axolotl.llm.adapters.langchain.openai.ChatOpenAI") as mock_openai,
        ):
            mock_bedrock_client = MagicMock()
            mock_openai_client = MagicMock()
            mock_bedrock.return_value = mock_bedrock_client
            mock_openai.return_value = mock_openai_client

            # Test Bedrock with automatic config
            config1 = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                region="us-east-1",
            )
            client1 = LLMClientFactory.create_client(config1)
            assert client1 == mock_bedrock_client

            # Test OpenAI with automatic config
            config2 = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="langchain",
                api_key="test-key",  # pragma: allowlist secret
            )
            client2 = LLMClientFactory.create_client(config2)
            assert client2 == mock_openai_client

            # Verify both were called
            mock_bedrock.assert_called_once()
            mock_openai.assert_called_once()

    def test_unsupported_combination_error(self):
        """Test error handling for unsupported provider-framework combinations."""
        # Use a valid provider but invalid framework
        config = LLMConfig(
            provider="bedrock",
            model_name="test",
            framework="direct",  # This is valid but not supported by any adapter
            region="us-east-1",
        )

        with pytest.raises(LLMError) as exc_info:
            LLMClientFactory.create_client(config)

        assert "Unsupported provider-framework combination" in str(exc_info.value)

    def test_supported_combinations_listing(self):
        """Test listing supported combinations."""
        combinations = LLMClientFactory.get_supported_combinations()
        expected_combinations = [
            "bedrock:langchain",
            "openai:langchain",
            "bedrock:llamaindex",
            "openai:llamaindex",
        ]

        for combination in expected_combinations:
            assert combination in combinations

    def test_supported_providers_listing(self):
        """Test listing supported providers."""
        providers = LLMClientFactory.get_supported_providers()
        expected_providers = ["bedrock", "openai"]

        for provider in expected_providers:
            assert provider in providers

    def test_supported_frameworks_listing(self):
        """Test listing supported frameworks."""
        frameworks = LLMClientFactory.get_supported_frameworks()
        expected_frameworks = ["langchain", "llamaindex"]

        for framework in expected_frameworks:
            assert framework in frameworks

    def test_config_validation_integration(self):
        """Test config validation in integration."""
        # Valid config should work
        config = LLMConfig(
            provider="bedrock",
            model_name="claude-3-sonnet-20240229-v1:0",
            framework="langchain",
            region="us-east-1",
        )

        with patch("axolotl.llm.adapters.langchain.bedrock.ChatBedrock"):
            client = LLMClientFactory.create_client(config)
            assert client is not None

        # Invalid config should raise validation error
        with pytest.raises(Exception):  # Pydantic validation error
            LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="invalid",
                region="us-east-1",
            )

    def test_error_propagation(self):
        """Test that errors are properly propagated through the system."""
        with patch(
            "axolotl.llm.adapters.langchain.bedrock.ChatBedrock"
        ) as mock_chat_bedrock:
            mock_chat_bedrock.side_effect = Exception("Bedrock service error")

            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                region="us-east-1",
            )

            with pytest.raises(LLMError) as exc_info:
                LLMClientFactory.create_client(config)

            assert "Failed to create client" in str(exc_info.value)
            assert "Bedrock service error" in str(exc_info.value)

    def test_multiple_client_creation_automatic_config(self):
        """Test creating multiple clients with different configurations using automatic config."""
        with (
            patch("axolotl.llm.adapters.langchain.bedrock.ChatBedrock") as mock_bedrock,
            patch("axolotl.llm.adapters.langchain.openai.ChatOpenAI") as mock_openai,
        ):
            mock_bedrock_client = MagicMock()
            mock_openai_client = MagicMock()
            mock_bedrock.return_value = mock_bedrock_client
            mock_openai.return_value = mock_openai_client

            # Create multiple clients with automatic config
            config1 = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                region="us-east-1",
            )
            client1 = LLMClientFactory.create_client(config1)

            config2 = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="langchain",
                api_key="test-key",  # pragma: allowlist secret
            )
            client2 = LLMClientFactory.create_client(config2)

            # Both clients should be different
            assert client1 == mock_bedrock_client
            assert client2 == mock_openai_client
            assert client1 != client2

            # Both adapters should have been called
            mock_bedrock.assert_called_once()
            mock_openai.assert_called_once()

    def test_framework_options_passthrough_automatic_config(self):
        """Test that framework_options are properly passed through with automatic config."""
        with patch(
            "axolotl.llm.adapters.langchain.bedrock.ChatBedrock"
        ) as mock_chat_bedrock:
            mock_client = MagicMock()
            mock_chat_bedrock.return_value = mock_client

            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                region="us-east-1",
                framework_options={"stream": True, "callbacks": ["test_callback"]},
            )

            LLMClientFactory.create_client(config)

            # Verify framework_options were passed through
            call_kwargs = mock_chat_bedrock.call_args[1]
            # Framework options are passed through
            assert (
                "stream" in call_kwargs
                or call_kwargs.get("model_kwargs", {}).get("stream") is True
            )
            assert call_kwargs["model_kwargs"]["callbacks"] == ["test_callback"]

    def test_provider_config_passthrough_automatic_config(self):
        """Test that provider-specific configs are properly passed through with automatic config."""
        with patch(
            "axolotl.llm.adapters.langchain.bedrock.ChatBedrock"
        ) as mock_chat_bedrock:
            mock_client = MagicMock()
            mock_chat_bedrock.return_value = mock_client

            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                region="us-east-1",
                profile_name="test-profile",  # pragma: allowlist secret
            )
            # Add model_kwargs to framework_options
            config.framework_options["model_kwargs"] = {"top_p": 0.9}

            LLMClientFactory.create_client(config)

            # Verify bedrock_config was passed through
            call_kwargs = mock_chat_bedrock.call_args[1]
            assert (
                call_kwargs["profile_name"] == "test-profile"
            )  # pragma: allowlist secret
            # The adapter adds model_kwargs to the call
            assert "model_kwargs" in call_kwargs
            assert call_kwargs["model_kwargs"]["top_p"] == 0.9

    def test_automatic_vs_explicit_config_equivalence(self):
        """Test that automatic and explicit config creation produce equivalent results."""
        # Automatic config
        auto_config = LLMConfig(
            provider="bedrock",
            model_name="claude-3-sonnet",
            framework="langchain",
            region="us-west-2",
            access_key_id="test-key",  # pragma: allowlist secret
        )

        # Explicit config
        explicit_config = LLMConfig(
            provider="bedrock",
            model_name="claude-3-sonnet",
            framework="langchain",
            provider_config=BedrockProviderConfig(
                region="us-west-2",
                access_key_id="test-key",  # pragma: allowlist secret
            ),
        )

        # Both should have the same provider config values
        assert (
            auto_config.provider_config.region == explicit_config.provider_config.region
        )
        assert (
            auto_config.provider_config.access_key_id
            == explicit_config.provider_config.access_key_id
        )
        assert auto_config.provider == explicit_config.provider
        assert auto_config.model_name == explicit_config.model_name
        assert auto_config.framework == explicit_config.framework

    def test_unsupported_provider_error(self):
        """Test error handling for unsupported provider."""
        with pytest.raises(ValueError) as exc_info:
            LLMConfig(
                provider="azure",  # This will pass Pydantic validation but fail in registry
                model_name="test",
            )

        assert "Unsupported provider: azure" in str(exc_info.value)

    def test_provider_kwargs_and_explicit_config_conflict(self):
        """Test that providing both provider kwargs and explicit config raises error."""
        with pytest.raises(ValueError) as exc_info:
            LLMConfig(
                provider="bedrock",
                model_name="test",
                provider_config=BedrockProviderConfig(region="us-west-2"),
                region="us-east-1",  # This should cause an error
            )

        assert "Cannot provide both provider_config and provider_kwargs" in str(
            exc_info.value
        )

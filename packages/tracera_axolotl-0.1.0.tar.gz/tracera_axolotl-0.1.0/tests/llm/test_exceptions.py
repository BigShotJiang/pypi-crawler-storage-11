"""Tests for LLM exceptions."""

import pytest

from axolotl.llm.exceptions import LLMError


class TestLLMError:
    """Test cases for LLMError."""

    def test_llm_error_creation_with_message_only(self):
        """Test creating LLMError with message only."""
        error = LLMError("Test error message")

        assert error.message == "Test error message"
        assert error.details is None
        assert str(error) == "Test error message"

    def test_llm_error_creation_with_message_and_details(self):
        """Test creating LLMError with message and details."""
        details = {"error_code": "INVALID_MODEL", "provider": "bedrock"}
        error = LLMError("Test error message", details)

        assert error.message == "Test error message"
        assert error.details == details
        assert (
            str(error)
            == "Test error message (Details: {'error_code': 'INVALID_MODEL', 'provider': 'bedrock'})"
        )

    def test_llm_error_inheritance(self):
        """Test that LLMError inherits from Exception."""
        error = LLMError("Test error")

        assert isinstance(error, Exception)
        assert isinstance(error, LLMError)

    def test_llm_error_str_representation(self):
        """Test string representation of LLMError."""
        # Without details
        error1 = LLMError("Simple error")
        assert str(error1) == "Simple error"

        # With details
        error2 = LLMError("Complex error", {"key": "value"})
        assert str(error2) == "Complex error (Details: {'key': 'value'})"

        # With None details (should not show details)
        error3 = LLMError("Error with None details", None)
        assert str(error3) == "Error with None details"

    def test_llm_error_with_various_detail_types(self):
        """Test LLMError with various types of details."""
        # String details
        error1 = LLMError("Error", "string details")
        assert str(error1) == "Error (Details: string details)"

        # List details
        error2 = LLMError("Error", ["item1", "item2"])
        assert str(error2) == "Error (Details: ['item1', 'item2'])"

        # Integer details
        error3 = LLMError("Error", 42)
        assert str(error3) == "Error (Details: 42)"

        # Boolean details
        error4 = LLMError("Error", True)
        assert str(error4) == "Error (Details: True)"

    def test_llm_error_equality(self):
        """Test LLMError equality comparison."""
        error1 = LLMError("Test error", {"key": "value"})
        error2 = LLMError("Test error", {"key": "value"})
        error3 = LLMError("Different error", {"key": "value"})
        error4 = LLMError("Test error", {"different": "value"})

        # Exception objects are not typically compared for equality
        # Instead, compare their string representations
        assert str(error1) == str(error2)

        # Different message should not be equal
        assert str(error1) != str(error3)

        # Different details should not be equal
        assert str(error1) != str(error4)

    def test_llm_error_raising_and_catching(self):
        """Test raising and catching LLMError."""
        with pytest.raises(LLMError) as exc_info:
            raise LLMError("Test error", {"error_code": "TEST"})

        assert exc_info.value.message == "Test error"
        assert exc_info.value.details == {"error_code": "TEST"}

    def test_llm_error_chaining(self):
        """Test LLMError with exception chaining."""
        original_error = ValueError("Original error")

        with pytest.raises(LLMError) as exc_info:
            try:
                raise original_error
            except ValueError as e:
                raise LLMError("Wrapped error", {"original": str(e)}) from e

        assert exc_info.value.message == "Wrapped error"
        assert exc_info.value.details == {"original": "Original error"}
        assert exc_info.value.__cause__ is original_error

"""Pytest configuration and shared fixtures for LLM tests."""

import os
from collections.abc import Generator
from unittest.mock import MagicMock, patch

import pytest

from axolotl.llm.domain.config import (
    LLMConfig,
    LLMParameters,
    BedrockProviderConfig,
    OpenAIProviderConfig,
)


@pytest.fixture
def clean_environment() -> Generator[None, None, None]:
    """Fixture to ensure clean environment variables for tests."""
    # AWS environment variables that might affect tests
    aws_env_vars = [
        "AWS_REGION",
        "AWS_DEFAULT_REGION",
        "AWS_ACCESS_KEY_ID",
        "AWS_SECRET_ACCESS_KEY",
        "AWS_SESSION_TOKEN",
        "AWS_PROFILE",
    ]

    # OpenAI environment variables that might affect tests
    openai_env_vars = [
        "OPENAI_API_KEY",
        "OPENAI_API_BASE",
        "OPENAI_API_VERSION",
    ]

    # Store original values
    original_values = {}
    for var in aws_env_vars + openai_env_vars:
        if var in os.environ:
            original_values[var] = os.environ[var]
            del os.environ[var]

    yield

    # Restore original values
    for var, value in original_values.items():
        os.environ[var] = value


@pytest.fixture
def mock_langchain_bedrock() -> Generator[MagicMock, None, None]:
    """Fixture providing a mocked LangChain ChatBedrock."""
    with patch("axolotl.llm.adapters.langchain.bedrock.ChatBedrock") as mock:
        # Setup default successful behavior
        mock_instance = mock.return_value
        mock_instance.invoke.return_value = MagicMock(content="Test response")
        mock_instance.stream.return_value = [MagicMock(content="Test response")]
        yield mock


@pytest.fixture
def mock_langchain_openai() -> Generator[MagicMock, None, None]:
    """Fixture providing a mocked LangChain ChatOpenAI."""
    with patch("axolotl.llm.adapters.langchain.openai.ChatOpenAI") as mock:
        # Setup default successful behavior
        mock_instance = mock.return_value
        mock_instance.invoke.return_value = MagicMock(content="Test response")
        mock_instance.stream.return_value = [MagicMock(content="Test response")]
        yield mock


@pytest.fixture
def mock_llamaindex_bedrock() -> Generator[MagicMock, None, None]:
    """Fixture providing a mocked LlamaIndex BedrockConverse."""
    with patch("axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse") as mock:
        # Setup default successful behavior
        mock_instance = mock.return_value
        mock_instance.complete.return_value = MagicMock(text="Test response")
        mock_instance.stream_complete.return_value = [MagicMock(text="Test response")]
        yield mock


@pytest.fixture
def mock_llamaindex_openai() -> Generator[MagicMock, None, None]:
    """Fixture providing a mocked LlamaIndex OpenAI."""
    with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock:
        # Setup default successful behavior
        mock_instance = mock.return_value
        mock_instance.complete.return_value = MagicMock(text="Test response")
        mock_instance.stream_complete.return_value = [MagicMock(text="Test response")]
        yield mock


@pytest.fixture
def sample_bedrock_config() -> LLMConfig:
    """Fixture providing a sample Bedrock LLMConfig."""
    return LLMConfig(
        provider="bedrock",
        model_name="claude-3-sonnet-20240229-v1:0",
        framework="langchain",
        parameters=LLMParameters(),
        provider_config=BedrockProviderConfig(region="us-east-1"),
    )


@pytest.fixture
def sample_openai_config() -> LLMConfig:
    """Fixture providing a sample OpenAI LLMConfig."""
    return LLMConfig(
        provider="openai",
        model_name="gpt-4",
        framework="langchain",
        parameters=LLMParameters(),
        provider_config=OpenAIProviderConfig(api_key="test-key"),
    )


@pytest.fixture
def sample_llm_config() -> LLMConfig:
    """Fixture providing a sample LLMConfig."""
    return LLMConfig(
        provider="bedrock",
        model_name="claude-3-sonnet-20240229-v1:0",
        framework="langchain",
        parameters=LLMParameters(),
        provider_config=BedrockProviderConfig(),
    )


@pytest.fixture
def mock_all_adapters():
    """Fixture that mocks all LLM adapters."""
    with (
        patch(
            "axolotl.llm.adapters.langchain.bedrock.ChatBedrock"
        ) as mock_langchain_bedrock,
        patch(
            "axolotl.llm.adapters.langchain.openai.ChatOpenAI"
        ) as mock_langchain_openai,
        patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_llamaindex_bedrock,
        patch(
            "axolotl.llm.adapters.llamaindex.openai.OpenAI"
        ) as mock_llamaindex_openai,
    ):
        # Setup default successful behavior for all mocks
        mock_langchain_bedrock.return_value = MagicMock()
        mock_langchain_openai.return_value = MagicMock()
        mock_llamaindex_bedrock.return_value = MagicMock()
        mock_llamaindex_openai.return_value = MagicMock()

        yield {
            "langchain_bedrock": mock_langchain_bedrock,
            "langchain_openai": mock_langchain_openai,
            "llamaindex_bedrock": mock_llamaindex_bedrock,
            "llamaindex_openai": mock_llamaindex_openai,
        }

"""Tests for LlamaIndex OpenAI adapter."""

import pytest
from unittest.mock import MagicMock, patch

from axolotl.llm.adapters.llamaindex.openai import LlamaIndexOpenAIAdapter
from axolotl.llm.domain.config import (
    LLMConfig,
    LLMParameters,
    OpenAIProviderConfig,
    BedrockProviderConfig,
)


class TestLlamaIndexOpenAIAdapter:
    """Test cases for LlamaIndexOpenAIAdapter."""

    def test_adapter_properties(self):
        """Test adapter properties."""
        adapter = LlamaIndexOpenAIAdapter()

        assert adapter.provider == "openai"
        assert adapter.framework == "llamaindex"

    def test_create_client_success_with_explicit_config(self):
        """Test successful client creation with explicit provider config."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                parameters=LLMParameters(),
                provider_config=OpenAIProviderConfig(api_key="test-key"),
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "gpt-4"
            assert call_kwargs["api_key"] == "test-key"  # pragma: allowlist secret
            assert call_kwargs["temperature"] == 0.7  # default
            assert call_kwargs["max_tokens"] == 512  # default

            assert client == mock_client

    def test_create_client_success_with_automatic_config(self):
        """Test successful client creation with automatic provider config."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                api_key="test-key",  # pragma: allowlist secret
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "gpt-4"
            assert call_kwargs["api_key"] == "test-key"  # pragma: allowlist secret
            assert call_kwargs["temperature"] == 0.7  # default
            assert call_kwargs["max_tokens"] == 512  # default

            assert client == mock_client

    def test_create_client_with_custom_parameters_explicit_config(self):
        """Test client creation with custom parameters using explicit config."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                parameters=LLMParameters(temperature=0.5, max_tokens=1024, top_p=0.8),
                provider_config=OpenAIProviderConfig(
                    api_key="test-key",  # pragma: allowlist secret
                    base_url="https://api.openai.com/v1",
                ),
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "gpt-4"
            assert call_kwargs["api_key"] == "test-key"  # pragma: allowlist secret
            assert call_kwargs["base_url"] == "https://api.openai.com/v1"
            assert call_kwargs["temperature"] == 0.5
            assert call_kwargs["max_tokens"] == 1024
            # Note: LlamaIndex OpenAI adapter doesn't pass top_p directly

            assert client == mock_client

    def test_create_client_with_custom_parameters_automatic_config(self):
        """Test client creation with custom parameters using automatic config."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                parameters=LLMParameters(temperature=0.5, max_tokens=1024, top_p=0.8),
                api_key="test-key",  # pragma: allowlist secret
                base_url="https://api.openai.com/v1",
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "gpt-4"
            assert call_kwargs["api_key"] == "test-key"  # pragma: allowlist secret
            assert call_kwargs["base_url"] == "https://api.openai.com/v1"
            assert call_kwargs["temperature"] == 0.5
            assert call_kwargs["max_tokens"] == 1024
            # Note: LlamaIndex OpenAI adapter doesn't pass top_p directly

            assert client == mock_client

    def test_create_client_with_framework_options_explicit_config(self):
        """Test client creation with framework options using explicit config."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                parameters=LLMParameters(),
                provider_config=OpenAIProviderConfig(api_key="test-key"),
                framework_options={
                    "stream": True,
                    "callbacks": ["test_callback"],
                    "model_kwargs": {"top_p": 0.9},
                },
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "gpt-4"
            assert call_kwargs["api_key"] == "test-key"  # pragma: allowlist secret
            assert call_kwargs["stream"] is True
            assert call_kwargs["callbacks"] == ["test_callback"]
            assert call_kwargs["model_kwargs"]["top_p"] == 0.9

            assert client == mock_client

    def test_create_client_with_framework_options_automatic_config(self):
        """Test client creation with framework options using automatic config."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                api_key="test-key",  # pragma: allowlist secret
                framework_options={
                    "stream": True,
                    "callbacks": ["test_callback"],
                    "model_kwargs": {"top_p": 0.9},
                },
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "gpt-4"
            assert call_kwargs["api_key"] == "test-key"  # pragma: allowlist secret
            assert call_kwargs["stream"] is True
            assert call_kwargs["callbacks"] == ["test_callback"]
            assert call_kwargs["model_kwargs"]["top_p"] == 0.9

            assert client == mock_client

    def test_create_client_with_base_url_explicit_config(self):
        """Test client creation with custom base URL using explicit config."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                parameters=LLMParameters(),
                provider_config=OpenAIProviderConfig(
                    api_key="test-key",  # pragma: allowlist secret
                    base_url="https://api.anthropic.com/v1",
                ),
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "gpt-4"
            assert call_kwargs["api_key"] == "test-key"  # pragma: allowlist secret
            assert call_kwargs["base_url"] == "https://api.anthropic.com/v1"

            assert client == mock_client

    def test_create_client_with_base_url_automatic_config(self):
        """Test client creation with custom base URL using automatic config."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                api_key="test-key",  # pragma: allowlist secret
                base_url="https://api.anthropic.com/v1",
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "gpt-4"
            assert call_kwargs["api_key"] == "test-key"  # pragma: allowlist secret
            assert call_kwargs["base_url"] == "https://api.anthropic.com/v1"

            assert client == mock_client

    def test_create_client_with_minimal_config(self):
        """Test client creation with minimal configuration."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                # Uses default framework (llamaindex) and api_key from environment
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "gpt-4"
            # Note: LlamaIndex OpenAI adapter doesn't set api_key when empty
            assert call_kwargs["temperature"] == 0.7  # default
            assert call_kwargs["max_tokens"] == 512  # default

            assert client == mock_client

    def test_create_client_error_handling(self):
        """Test error handling during client creation."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_openai.side_effect = Exception("OpenAI initialization error")

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                api_key="test-key",  # pragma: allowlist secret
            )

            with pytest.raises(Exception) as exc_info:
                adapter.create_client(config)

            assert "OpenAI initialization error" in str(exc_info.value)

    def test_create_client_parameter_override(self):
        """Test that parameters can be overridden by framework_options."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                parameters=LLMParameters(temperature=0.5, max_tokens=1024),
                api_key="test-key",  # pragma: allowlist secret
                framework_options={
                    "model_kwargs": {
                        "temperature": 0.8,  # This should override the parameter
                        "top_p": 0.9,
                    }
                },
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "gpt-4"
            assert call_kwargs["api_key"] == "test-key"  # pragma: allowlist secret
            assert call_kwargs["temperature"] == 0.5  # From parameters (not overridden)
            assert call_kwargs["max_tokens"] == 1024  # From parameters
            # Note: LlamaIndex OpenAI adapter doesn't pass top_p directly

            assert client == mock_client

    def test_create_client_with_gpt_3_5_turbo(self):
        """Test client creation with GPT-3.5 Turbo model."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-3.5-turbo",
                framework="llamaindex",
                api_key="test-key",  # pragma: allowlist secret
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "gpt-3.5-turbo"
            assert call_kwargs["api_key"] == "test-key"  # pragma: allowlist secret

            assert client == mock_client

    def test_create_client_with_custom_model(self):
        """Test client creation with custom model name."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="custom-model-v1",
                framework="llamaindex",
                api_key="test-key",  # pragma: allowlist secret
            )

            client = adapter.create_client(config)

            # Verify OpenAI was called with correct parameters
            mock_openai.assert_called_once()
            call_kwargs = mock_openai.call_args[1]

            assert call_kwargs["model"] == "custom-model-v1"
            assert call_kwargs["api_key"] == "test-key"  # pragma: allowlist secret

            assert client == mock_client

    def test_create_client_import_error(self):
        """Test client creation when llama_index is not installed."""
        # Mock the import to return None
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI", None):
            adapter = LlamaIndexOpenAIAdapter()
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                provider_config=OpenAIProviderConfig(
                    api_key="test-key"
                ),  # pragma: allowlist secret
            )

            with pytest.raises(
                ImportError, match="llama_index is required but not installed"
            ):
                adapter.create_client(config)

    def test_create_client_wrong_provider_config_type(self):
        """Test client creation with wrong provider config type."""
        with patch("axolotl.llm.adapters.llamaindex.openai.OpenAI") as mock_openai:
            mock_client = MagicMock()
            mock_openai.return_value = mock_client

            adapter = LlamaIndexOpenAIAdapter()
            # Create config with BedrockProviderConfig instead of OpenAIProviderConfig
            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="llamaindex",
                provider_config=BedrockProviderConfig(region="us-east-1"),
            )

            with pytest.raises(ValueError, match="Expected OpenAIProviderConfig, got"):
                adapter.create_client(config)

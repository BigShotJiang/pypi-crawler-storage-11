"""Tests for LlamaIndex Bedrock adapter."""

import pytest
from unittest.mock import MagicMock, patch

from axolotl.llm.adapters.llamaindex.bedrock import LlamaIndexBedrockAdapter
from axolotl.llm.domain.config import (
    LLMConfig,
    LLMParameters,
    BedrockProviderConfig,
    OpenAIProviderConfig,
)


class TestLlamaIndexBedrockAdapter:
    """Test cases for LlamaIndexBedrockAdapter."""

    def test_adapter_properties(self):
        """Test adapter properties."""
        adapter = LlamaIndexBedrockAdapter()

        assert adapter.provider == "bedrock"
        assert adapter.framework == "llamaindex"

    def test_create_client_success_with_explicit_config(self):
        """Test successful client creation with explicit provider config."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                parameters=LLMParameters(),
                provider_config=BedrockProviderConfig(region="us-east-1"),
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-east-1"
            assert call_kwargs["temperature"] == 0.7  # default
            assert call_kwargs["max_tokens"] == 512  # default

            assert client == mock_client

    def test_create_client_success_with_automatic_config(self):
        """Test successful client creation with automatic provider config."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                region="us-east-1",
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-east-1"
            assert call_kwargs["temperature"] == 0.7  # default
            assert call_kwargs["max_tokens"] == 512  # default

            assert client == mock_client

    def test_create_client_with_custom_parameters_explicit_config(self):
        """Test client creation with custom parameters using explicit config."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                parameters=LLMParameters(temperature=0.5, max_tokens=1024, top_p=0.8),
                provider_config=BedrockProviderConfig(
                    region="us-west-2",
                    access_key_id="test-key",  # pragma: allowlist secret
                    secret_access_key="test-secret",  # pragma: allowlist secret
                ),
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-west-2"
            assert call_kwargs["temperature"] == 0.5
            assert call_kwargs["max_tokens"] == 1024
            assert call_kwargs["additional_kwargs"]["inferenceConfig"]["topP"] == 0.8

            assert client == mock_client

    def test_create_client_with_custom_parameters_automatic_config(self):
        """Test client creation with custom parameters using automatic config."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                parameters=LLMParameters(temperature=0.5, max_tokens=1024, top_p=0.8),
                region="us-west-2",
                access_key_id="test-key",  # pragma: allowlist secret
                secret_access_key="test-secret",  # pragma: allowlist secret
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-west-2"
            assert call_kwargs["temperature"] == 0.5
            assert call_kwargs["max_tokens"] == 1024
            assert call_kwargs["additional_kwargs"]["inferenceConfig"]["topP"] == 0.8

            assert client == mock_client

    def test_create_client_with_framework_options_explicit_config(self):
        """Test client creation with framework options using explicit config."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                parameters=LLMParameters(),
                provider_config=BedrockProviderConfig(region="us-east-1"),
                framework_options={
                    "stream": True,
                    "callbacks": ["test_callback"],
                    "model_kwargs": {"top_p": 0.9},
                },
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-east-1"
            assert call_kwargs["additional_kwargs"]["stream"] is True
            assert call_kwargs["additional_kwargs"]["callbacks"] == ["test_callback"]
            assert call_kwargs["additional_kwargs"]["inferenceConfig"]["topP"] == 0.9

            assert client == mock_client

    def test_create_client_with_framework_options_automatic_config(self):
        """Test client creation with framework options using automatic config."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                region="us-east-1",
                framework_options={
                    "stream": True,
                    "callbacks": ["test_callback"],
                    "model_kwargs": {"top_p": 0.9},
                },
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-east-1"
            assert call_kwargs["additional_kwargs"]["stream"] is True
            assert call_kwargs["additional_kwargs"]["callbacks"] == ["test_callback"]
            assert call_kwargs["additional_kwargs"]["inferenceConfig"]["topP"] == 0.9

            assert client == mock_client

    def test_create_client_with_profile_name_explicit_config(self):
        """Test client creation with profile name using explicit config."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                parameters=LLMParameters(),
                provider_config=BedrockProviderConfig(
                    region="us-east-1", profile_name="test-profile"
                ),
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-east-1"
            assert call_kwargs["profile_name"] == "test-profile"

            assert client == mock_client

    def test_create_client_with_profile_name_automatic_config(self):
        """Test client creation with profile name using automatic config."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                region="us-east-1",
                profile_name="test-profile",
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-east-1"
            assert call_kwargs["profile_name"] == "test-profile"

            assert client == mock_client

    def test_create_client_with_credentials_explicit_config(self):
        """Test client creation with explicit credentials using explicit config."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                parameters=LLMParameters(),
                provider_config=BedrockProviderConfig(
                    region="us-east-1",
                    access_key_id="test-access-key",
                    secret_access_key="test-secret-key",  # pragma: allowlist secret  # pragma: allowlist secret
                    session_token="test-session-token",
                ),
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-east-1"
            assert (
                call_kwargs["aws_access_key_id"] == "test-access-key"
            )  # pragma: allowlist secret
            assert (
                call_kwargs["aws_secret_access_key"]
                == "test-secret-key"  # pragma: allowlist secret
            )  # pragma: allowlist secret
            assert (
                call_kwargs["aws_session_token"] == "test-session-token"
            )  # pragma: allowlist secret

            assert client == mock_client

    def test_create_client_with_credentials_automatic_config(self):
        """Test client creation with explicit credentials using automatic config."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                region="us-east-1",
                access_key_id="test-access-key",
                secret_access_key="test-secret-key",  # pragma: allowlist secret
                session_token="test-session-token",
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-east-1"
            assert (
                call_kwargs["aws_access_key_id"] == "test-access-key"
            )  # pragma: allowlist secret
            assert (
                call_kwargs["aws_secret_access_key"]
                == "test-secret-key"  # pragma: allowlist secret
            )  # pragma: allowlist secret
            assert (
                call_kwargs["aws_session_token"] == "test-session-token"
            )  # pragma: allowlist secret

            assert client == mock_client

    def test_create_client_error_handling(self):
        """Test error handling during client creation."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_bedrock_converse.side_effect = Exception(
                "Bedrock initialization error"
            )

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                region="us-east-1",
            )

            with pytest.raises(Exception) as exc_info:
                adapter.create_client(config)

            assert "Bedrock initialization error" in str(exc_info.value)

    def test_create_client_with_minimal_config(self):
        """Test client creation with minimal configuration."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                # Uses default framework (llamaindex) and region from environment
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-east-1"  # default
            assert call_kwargs["temperature"] == 0.7  # default
            assert call_kwargs["max_tokens"] == 512  # default

            assert client == mock_client

    def test_create_client_parameter_override(self):
        """Test that parameters can be overridden by framework_options."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock_converse:
            mock_client = MagicMock()
            mock_bedrock_converse.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="llamaindex",
                parameters=LLMParameters(temperature=0.5, max_tokens=1024),
                region="us-east-1",
                framework_options={
                    "model_kwargs": {
                        "temperature": 0.8,  # This should override the parameter
                        "top_p": 0.9,
                    }
                },
            )

            client = adapter.create_client(config)

            # Verify BedrockConverse was called with correct parameters
            mock_bedrock_converse.assert_called_once()
            call_kwargs = mock_bedrock_converse.call_args[1]

            assert call_kwargs["model"] == "claude-3-sonnet-20240229-v1:0"
            assert call_kwargs["region_name"] == "us-east-1"
            assert call_kwargs["temperature"] == 0.5  # From parameters (not overridden)
            assert call_kwargs["max_tokens"] == 1024  # From parameters
            assert (
                call_kwargs["additional_kwargs"]["inferenceConfig"]["topP"] == 0.9
            )  # From framework_options

            assert client == mock_client

    def test_create_client_import_error(self):
        """Test client creation when llama_index is not installed."""
        # Mock the import to return None
        with patch("axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse", None):
            adapter = LlamaIndexBedrockAdapter()
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet",
                framework="llamaindex",
                provider_config=BedrockProviderConfig(region="us-east-1"),
            )

            with pytest.raises(
                ImportError, match="llama_index is required but not installed"
            ):
                adapter.create_client(config)

    def test_create_client_wrong_provider_config_type(self):
        """Test client creation with wrong provider config type."""
        with patch(
            "axolotl.llm.adapters.llamaindex.bedrock.BedrockConverse"
        ) as mock_bedrock:
            mock_client = MagicMock()
            mock_bedrock.return_value = mock_client

            adapter = LlamaIndexBedrockAdapter()
            # Create config with OpenAIProviderConfig instead of BedrockProviderConfig
            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet",
                framework="llamaindex",
                provider_config=OpenAIProviderConfig(
                    api_key="test-key"
                ),  # pragma: allowlist secret
            )

            with pytest.raises(ValueError, match="Expected BedrockProviderConfig, got"):
                adapter.create_client(config)

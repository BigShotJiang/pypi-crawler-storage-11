"""Tests for LlamaIndex adapters."""

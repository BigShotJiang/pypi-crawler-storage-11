"""Tests for LangChain adapters."""

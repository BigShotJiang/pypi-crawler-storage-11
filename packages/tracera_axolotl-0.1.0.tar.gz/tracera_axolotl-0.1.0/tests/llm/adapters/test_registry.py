"""Tests for LLM adapter registry."""

import pytest

from axolotl.llm.adapters.registry import LLMAdapterRegistry
from axolotl.llm.adapters.base import BaseLLMAdapter
from axolotl.llm.domain.config import LLMConfig


class TestLLMAdapterRegistry:
    """Test cases for LLMAdapterRegistry."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Store original registry state
        self._original_adapters = LLMAdapterRegistry._adapters.copy()
        # Clear the registry before each test
        LLMAdapterRegistry._adapters.clear()

    def teardown_method(self):
        """Clean up after each test method."""
        # Restore original registry state
        LLMAdapterRegistry._adapters.clear()
        LLMAdapterRegistry._adapters.update(self._original_adapters)

    def test_register_decorator(self):
        """Test the register decorator functionality."""

        class TestAdapter(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "test"

            @property
            def framework(self) -> str:
                return "test"

            def create_client(self, config: LLMConfig):
                return "test_client"

        # Register the adapter
        registered_adapter = LLMAdapterRegistry.register("test", "test")(TestAdapter)

        # Should return the same class
        assert registered_adapter is TestAdapter

        # Should be registered in the registry
        assert "test:test" in LLMAdapterRegistry._adapters
        assert LLMAdapterRegistry._adapters["test:test"] is TestAdapter

    def test_register_multiple_adapters(self):
        """Test registering multiple adapters."""

        class Adapter1(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "provider1"

            @property
            def framework(self) -> str:
                return "framework1"

            def create_client(self, config: LLMConfig):
                return "client1"

        class Adapter2(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "provider2"

            @property
            def framework(self) -> str:
                return "framework2"

            def create_client(self, config: LLMConfig):
                return "client2"

        # Register both adapters
        LLMAdapterRegistry.register("provider1", "framework1")(Adapter1)
        LLMAdapterRegistry.register("provider2", "framework2")(Adapter2)

        # Both should be registered
        assert "provider1:framework1" in LLMAdapterRegistry._adapters
        assert "provider2:framework2" in LLMAdapterRegistry._adapters
        assert LLMAdapterRegistry._adapters["provider1:framework1"] is Adapter1
        assert LLMAdapterRegistry._adapters["provider2:framework2"] is Adapter2

    def test_register_case_insensitive(self):
        """Test that registration is case insensitive."""

        class TestAdapter(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "test"

            @property
            def framework(self) -> str:
                return "test"

            def create_client(self, config: LLMConfig):
                return "test_client"

        # Register with different cases
        LLMAdapterRegistry.register("TEST", "FRAMEWORK")(TestAdapter)

        # Should be accessible with any case
        assert LLMAdapterRegistry.get_adapter("test", "framework") is TestAdapter
        assert LLMAdapterRegistry.get_adapter("TEST", "FRAMEWORK") is TestAdapter
        assert LLMAdapterRegistry.get_adapter("Test", "Framework") is TestAdapter

    def test_get_adapter_existing(self):
        """Test getting an existing adapter."""

        class TestAdapter(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "test"

            @property
            def framework(self) -> str:
                return "test"

            def create_client(self, config: LLMConfig):
                return "test_client"

        LLMAdapterRegistry.register("test", "test")(TestAdapter)

        # Should return the registered adapter
        adapter = LLMAdapterRegistry.get_adapter("test", "test")
        assert adapter is TestAdapter

    def test_get_adapter_nonexistent(self):
        """Test getting a non-existent adapter."""
        with pytest.raises(KeyError) as exc_info:
            LLMAdapterRegistry.get_adapter("nonexistent", "adapter")

        assert "No adapter found for nonexistent:adapter" in str(exc_info.value)
        assert "Available: []" in str(exc_info.value)

    def test_get_adapter_with_available_adapters(self):
        """Test getting adapter when other adapters are available."""

        class TestAdapter(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "test"

            @property
            def framework(self) -> str:
                return "test"

            def create_client(self, config: LLMConfig):
                return "test_client"

        LLMAdapterRegistry.register("test", "test")(TestAdapter)

        with pytest.raises(KeyError) as exc_info:
            LLMAdapterRegistry.get_adapter("nonexistent", "adapter")

        assert "No adapter found for nonexistent:adapter" in str(exc_info.value)
        assert "Available: ['test:test']" in str(exc_info.value)

    def test_list_adapters(self):
        """Test listing all adapters."""

        class Adapter1(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "provider1"

            @property
            def framework(self) -> str:
                return "framework1"

            def create_client(self, config: LLMConfig):
                return "client1"

        class Adapter2(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "provider2"

            @property
            def framework(self) -> str:
                return "framework2"

            def create_client(self, config: LLMConfig):
                return "client2"

        # Initially empty
        assert LLMAdapterRegistry.list_adapters() == {}

        # Register adapters
        LLMAdapterRegistry.register("provider1", "framework1")(Adapter1)
        LLMAdapterRegistry.register("provider2", "framework2")(Adapter2)

        # Should list both adapters
        adapters = LLMAdapterRegistry.list_adapters()
        assert len(adapters) == 2
        assert "provider1:framework1" in adapters
        assert "provider2:framework2" in adapters
        assert adapters["provider1:framework1"] is Adapter1
        assert adapters["provider2:framework2"] is Adapter2

    def test_list_adapters_returns_copy(self):
        """Test that list_adapters returns a copy of the registry."""

        class TestAdapter(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "test"

            @property
            def framework(self) -> str:
                return "test"

            def create_client(self, config: LLMConfig):
                return "test_client"

        LLMAdapterRegistry.register("test", "test")(TestAdapter)

        # Get the list
        adapters = LLMAdapterRegistry.list_adapters()

        # Modify the returned dict
        adapters["test:test"] = "modified"

        # Original registry should be unchanged
        assert LLMAdapterRegistry._adapters["test:test"] is TestAdapter

    def test_get_supported_providers(self):
        """Test getting supported providers."""

        class Adapter1(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "provider1"

            @property
            def framework(self) -> str:
                return "framework1"

            def create_client(self, config: LLMConfig):
                return "client1"

        class Adapter2(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "provider2"

            @property
            def framework(self) -> str:
                return "framework2"

            def create_client(self, config: LLMConfig):
                return "client2"

        class Adapter3(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "provider1"  # Same provider as Adapter1

            @property
            def framework(self) -> str:
                return "framework3"

            def create_client(self, config: LLMConfig):
                return "client3"

        # Initially empty
        assert LLMAdapterRegistry.get_supported_providers() == []

        # Register adapters
        LLMAdapterRegistry.register("provider1", "framework1")(Adapter1)
        LLMAdapterRegistry.register("provider2", "framework2")(Adapter2)
        LLMAdapterRegistry.register("provider1", "framework3")(Adapter3)

        # Should return unique providers
        providers = LLMAdapterRegistry.get_supported_providers()
        assert len(providers) == 2
        assert "provider1" in providers
        assert "provider2" in providers

    def test_get_supported_frameworks(self):
        """Test getting supported frameworks."""

        class Adapter1(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "provider1"

            @property
            def framework(self) -> str:
                return "framework1"

            def create_client(self, config: LLMConfig):
                return "client1"

        class Adapter2(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "provider2"

            @property
            def framework(self) -> str:
                return "framework2"

            def create_client(self, config: LLMConfig):
                return "client2"

        class Adapter3(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "provider3"

            @property
            def framework(self) -> str:
                return "framework1"  # Same framework as Adapter1

            def create_client(self, config: LLMConfig):
                return "client3"

        # Initially empty
        assert LLMAdapterRegistry.get_supported_frameworks() == []

        # Register adapters
        LLMAdapterRegistry.register("provider1", "framework1")(Adapter1)
        LLMAdapterRegistry.register("provider2", "framework2")(Adapter2)
        LLMAdapterRegistry.register("provider3", "framework1")(Adapter3)

        # Should return unique frameworks
        frameworks = LLMAdapterRegistry.get_supported_frameworks()
        assert len(frameworks) == 2
        assert "framework1" in frameworks
        assert "framework2" in frameworks

    def test_register_overwrites_existing(self):
        """Test that registering with the same key overwrites existing adapter."""

        class Adapter1(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "test"

            @property
            def framework(self) -> str:
                return "test"

            def create_client(self, config: LLMConfig):
                return "client1"

        class Adapter2(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "test"

            @property
            def framework(self) -> str:
                return "test"

            def create_client(self, config: LLMConfig):
                return "client2"

        # Register first adapter
        LLMAdapterRegistry.register("test", "test")(Adapter1)
        assert LLMAdapterRegistry.get_adapter("test", "test") is Adapter1

        # Register second adapter with same key
        LLMAdapterRegistry.register("test", "test")(Adapter2)
        assert LLMAdapterRegistry.get_adapter("test", "test") is Adapter2

    def test_registry_thread_safety(self):
        """Test that registry operations are thread-safe (basic test)."""
        import threading
        import time

        class TestAdapter(BaseLLMAdapter):
            @property
            def provider(self) -> str:
                return "test"

            @property
            def framework(self) -> str:
                return "test"

            def create_client(self, config: LLMConfig):
                return "test_client"

        def register_adapter():
            time.sleep(0.01)  # Small delay to ensure race condition
            LLMAdapterRegistry.register("test", "test")(TestAdapter)

        # Start multiple threads
        threads = []
        for _ in range(5):
            thread = threading.Thread(target=register_adapter)
            threads.append(thread)
            thread.start()

        # Wait for all threads to complete
        for thread in threads:
            thread.join()

        # Should have exactly one adapter registered
        assert len(LLMAdapterRegistry.list_adapters()) == 1
        assert "test:test" in LLMAdapterRegistry._adapters

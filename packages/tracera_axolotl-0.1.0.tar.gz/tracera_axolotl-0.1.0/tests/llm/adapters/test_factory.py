"""Tests for LLM client factory."""

import pytest
from unittest.mock import MagicMock, patch

from axolotl.llm.adapters.factory import LLMClientFactory
from axolotl.llm.adapters.registry import LLMAdapterRegistry
from axolotl.llm.domain.config import LLMConfig, OpenAIProviderConfig
from axolotl.llm.exceptions import LLMError

# Import adapters to register them


class TestLLMClientFactory:
    """Test cases for LLMClientFactory."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Store original registry state
        self._original_adapters = LLMAdapterRegistry._adapters.copy()

    def teardown_method(self):
        """Clean up after each test method."""
        # Restore original registry state
        LLMAdapterRegistry._adapters.clear()
        LLMAdapterRegistry._adapters.update(self._original_adapters)

    def test_create_client_success(self):
        """Test successful client creation."""
        with patch(
            "axolotl.llm.adapters.langchain.bedrock.ChatBedrock"
        ) as mock_chat_bedrock:
            mock_client = MagicMock()
            mock_chat_bedrock.return_value = mock_client

            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                region="us-east-1",
            )
            client = LLMClientFactory.create_client(config)

            assert client == mock_client

    def test_create_client_with_automatic_provider_config(self):
        """Test client creation with automatic provider config selection."""

        class MockAdapter:
            def __init__(self):
                self.provider = "bedrock"
                self.framework = "langchain"

            def create_client(self, config):
                return f"bedrock_client_{config.model_name}"

        # Register mock adapter
        LLMAdapterRegistry.register("bedrock", "langchain")(MockAdapter)

        config = LLMConfig(
            provider="bedrock",
            model_name="claude-3-sonnet-20240229-v1:0",
            framework="langchain",
            region="us-east-1",
        )
        client = LLMClientFactory.create_client(config)

        assert client == "bedrock_client_claude-3-sonnet-20240229-v1:0"

    def test_create_client_with_explicit_provider_config(self):
        """Test client creation with explicit provider config."""

        class MockAdapter:
            def __init__(self):
                self.provider = "openai"
                self.framework = "llamaindex"

            def create_client(self, config):
                return f"openai_client_{config.model_name}"

        # Register mock adapter
        LLMAdapterRegistry.register("openai", "llamaindex")(MockAdapter)

        config = LLMConfig(
            provider="openai",
            model_name="gpt-4",
            framework="llamaindex",
            provider_config=OpenAIProviderConfig(api_key="test-key"),
        )
        client = LLMClientFactory.create_client(config)

        assert client == "openai_client_gpt-4"

    def test_create_client_unsupported_combination(self):
        """Test client creation with unsupported provider-framework combination."""
        config = LLMConfig(
            provider="bedrock",
            model_name="test",
            framework="direct",
            region="us-east-1",
        )

        with pytest.raises(LLMError) as exc_info:
            LLMClientFactory.create_client(config)

        assert "Unsupported provider-framework combination: bedrock:direct" in str(
            exc_info.value
        )

    def test_create_client_adapter_error(self):
        """Test client creation when adapter raises an error."""
        with patch(
            "axolotl.llm.adapters.langchain.bedrock.ChatBedrock"
        ) as mock_chat_bedrock:
            mock_chat_bedrock.side_effect = Exception("Bedrock error")

            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                region="us-east-1",
            )

            with pytest.raises(LLMError) as exc_info:
                LLMClientFactory.create_client(config)

            assert "Failed to create client: Bedrock error" in str(exc_info.value)

    def test_create_client_registry_error(self):
        """Test client creation when registry raises an error."""
        config = LLMConfig(
            provider="bedrock",
            model_name="test",
            framework="direct",
            region="us-east-1",
        )

        with pytest.raises(LLMError) as exc_info:
            LLMClientFactory.create_client(config)

        assert "Unsupported provider-framework combination: bedrock:direct" in str(
            exc_info.value
        )

    def test_get_supported_combinations(self):
        """Test getting supported combinations."""
        combinations = LLMClientFactory.get_supported_combinations()
        expected_combinations = [
            "bedrock:langchain",
            "openai:langchain",
            "bedrock:llamaindex",
            "openai:llamaindex",
        ]

        for combination in expected_combinations:
            assert combination in combinations

    def test_get_supported_providers(self):
        """Test getting supported providers."""
        providers = LLMClientFactory.get_supported_providers()
        expected_providers = ["bedrock", "openai"]

        for provider in expected_providers:
            assert provider in providers

    def test_get_supported_frameworks(self):
        """Test getting supported frameworks."""
        frameworks = LLMClientFactory.get_supported_frameworks()
        expected_frameworks = ["langchain", "llamaindex"]

        for framework in expected_frameworks:
            assert framework in frameworks

    def test_create_client_with_different_config_types(self):
        """Test client creation with different config types."""
        with (
            patch("axolotl.llm.adapters.langchain.bedrock.ChatBedrock") as mock_bedrock,
            patch("axolotl.llm.adapters.langchain.openai.ChatOpenAI") as mock_openai,
        ):
            mock_bedrock.return_value = MagicMock()
            mock_openai.return_value = MagicMock()

            # Test with automatic Bedrock config
            config1 = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                region="us-east-1",
            )
            client1 = LLMClientFactory.create_client(config1)
            assert client1 is not None

            # Test with automatic OpenAI config
            config2 = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="langchain",
                api_key="test-key",  # pragma: allowlist secret
            )
            client2 = LLMClientFactory.create_client(config2)
            assert client2 is not None

    def test_factory_methods_are_static(self):
        """Test that all factory methods are static."""
        import inspect

        # Check that all methods are static
        assert inspect.isfunction(LLMClientFactory.create_client)
        assert inspect.isfunction(LLMClientFactory.get_supported_combinations)
        assert inspect.isfunction(LLMClientFactory.get_supported_providers)
        assert inspect.isfunction(LLMClientFactory.get_supported_frameworks)

    def test_create_client_with_provider_kwargs(self):
        """Test client creation with provider kwargs."""
        with patch(
            "axolotl.llm.adapters.langchain.bedrock.ChatBedrock"
        ) as mock_chat_bedrock:
            mock_client = MagicMock()
            mock_chat_bedrock.return_value = mock_client

            config = LLMConfig(
                provider="bedrock",
                model_name="claude-3-sonnet-20240229-v1:0",
                framework="langchain",
                region="us-west-2",
                access_key_id="test-key",  # pragma: allowlist secret
                profile_name="test-profile",  # pragma: allowlist secret
            )
            client = LLMClientFactory.create_client(config)

            assert client == mock_client
            # Verify the provider config was created with the kwargs
            assert config.provider_config.region == "us-west-2"
            assert (
                config.provider_config.access_key_id == "test-key"
            )  # pragma: allowlist secret
            assert (
                config.provider_config.profile_name == "test-profile"
            )  # pragma: allowlist secret

    def test_create_client_with_openai_kwargs(self):
        """Test client creation with OpenAI provider kwargs."""
        with patch(
            "axolotl.llm.adapters.langchain.openai.ChatOpenAI"
        ) as mock_chat_openai:
            mock_client = MagicMock()
            mock_chat_openai.return_value = mock_client

            config = LLMConfig(
                provider="openai",
                model_name="gpt-4",
                framework="langchain",
                api_key="sk-test-key",  # pragma: allowlist secret
                base_url="https://api.openai.com/v1",
            )
            client = LLMClientFactory.create_client(config)

            assert client == mock_client
            # Verify the provider config was created with the kwargs
            assert (
                config.provider_config.api_key
                == "sk-test-key"  # pragma: allowlist secret
            )  # pragma: allowlist secret
            assert config.provider_config.base_url == "https://api.openai.com/v1"

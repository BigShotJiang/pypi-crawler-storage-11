"""Tests for base LLM adapter."""

import pytest
from abc import ABC

from axolotl.llm.adapters.base import BaseLLMAdapter
from axolotl.llm.domain.config import (
    LLMConfig,
    LLMParameters,
    BedrockProviderConfig,
    OpenAIProviderConfig,
)


class TestBaseLLMAdapter:
    """Test cases for BaseLLMAdapter."""

    def test_base_adapter_is_abstract(self):
        """Test that BaseLLMAdapter is abstract and cannot be instantiated."""
        with pytest.raises(TypeError) as exc_info:
            BaseLLMAdapter()

        assert "Can't instantiate abstract class" in str(exc_info.value)

    def test_base_adapter_has_required_methods(self):
        """Test that BaseLLMAdapter has required abstract methods."""
        # Check that the class has the required abstract methods
        assert hasattr(BaseLLMAdapter, "create_client")
        assert hasattr(BaseLLMAdapter, "provider")
        assert hasattr(BaseLLMAdapter, "framework")

        # Check that these are abstract methods
        assert getattr(BaseLLMAdapter.create_client, "__isabstractmethod__", False)
        assert getattr(BaseLLMAdapter.provider, "__isabstractmethod__", False)
        assert getattr(BaseLLMAdapter.framework, "__isabstractmethod__", False)

    def test_base_adapter_inheritance(self):
        """Test that BaseLLMAdapter inherits from ABC."""
        assert issubclass(BaseLLMAdapter, ABC)

    def test_concrete_adapter_implementation(self):
        """Test that a concrete adapter can be implemented."""

        class ConcreteAdapter(BaseLLMAdapter):
            """Concrete implementation of BaseLLMAdapter."""

            @property
            def provider(self) -> str:
                return "test_provider"

            @property
            def framework(self) -> str:
                return "test_framework"

            def create_client(self, config: LLMConfig):
                return "test_client"

        # Should be able to instantiate concrete adapter
        adapter = ConcreteAdapter()
        assert adapter.provider == "test_provider"
        assert adapter.framework == "test_framework"

        # Should be able to call create_client
        config = LLMConfig(
            provider="bedrock",
            model_name="test",
            parameters=LLMParameters(),
            provider_config=BedrockProviderConfig(region="us-east-1"),
        )
        client = adapter.create_client(config)
        assert client == "test_client"

    def test_concrete_adapter_missing_methods(self):
        """Test that concrete adapter without all methods cannot be instantiated."""

        class IncompleteAdapter(BaseLLMAdapter):
            """Incomplete implementation missing create_client method."""

            @property
            def provider(self) -> str:
                return "test_provider"

            @property
            def framework(self) -> str:
                return "test_framework"

        with pytest.raises(TypeError) as exc_info:
            IncompleteAdapter()

        assert "Can't instantiate abstract class" in str(exc_info.value)
        assert "create_client" in str(exc_info.value)

    def test_concrete_adapter_missing_provider_property(self):
        """Test that concrete adapter without provider property cannot be instantiated."""

        class IncompleteAdapter(BaseLLMAdapter):
            """Incomplete implementation missing provider property."""

            @property
            def framework(self) -> str:
                return "test_framework"

            def create_client(self, config: LLMConfig):
                return "test_client"

        with pytest.raises(TypeError) as exc_info:
            IncompleteAdapter()

        assert "Can't instantiate abstract class" in str(exc_info.value)
        assert "provider" in str(exc_info.value)

    def test_concrete_adapter_missing_framework_property(self):
        """Test that concrete adapter without framework property cannot be instantiated."""

        class IncompleteAdapter(BaseLLMAdapter):
            """Incomplete implementation missing framework property."""

            @property
            def provider(self) -> str:
                return "test_provider"

            def create_client(self, config: LLMConfig):
                return "test_client"

        with pytest.raises(TypeError) as exc_info:
            IncompleteAdapter()

        assert "Can't instantiate abstract class" in str(exc_info.value)
        assert "framework" in str(exc_info.value)

    def test_adapter_with_different_config_types(self):
        """Test that adapter can work with different config types."""

        class FlexibleAdapter(BaseLLMAdapter):
            """Adapter that works with different config types."""

            @property
            def provider(self) -> str:
                return "flexible"

            @property
            def framework(self) -> str:
                return "flexible"

            def create_client(self, config: LLMConfig):
                return f"client_for_{config.provider}_{config.framework}"

        adapter = FlexibleAdapter()

        # Test with different configs
        config1 = LLMConfig(
            provider="bedrock",
            model_name="test",
            framework="langchain",
            parameters=LLMParameters(),
            provider_config=BedrockProviderConfig(region="us-east-1"),
        )
        client1 = adapter.create_client(config1)
        assert client1 == "client_for_bedrock_langchain"

        config2 = LLMConfig(
            provider="openai",
            model_name="test",
            framework="llamaindex",
            parameters=LLMParameters(),
            provider_config=OpenAIProviderConfig(api_key="test-key"),
        )
        client2 = adapter.create_client(config2)
        assert client2 == "client_for_openai_llamaindex"

    def test_adapter_error_handling(self):
        """Test that adapter can handle errors in create_client."""

        class ErrorAdapter(BaseLLMAdapter):
            """Adapter that raises errors."""

            @property
            def provider(self) -> str:
                return "error"

            @property
            def framework(self) -> str:
                return "error"

            def create_client(self, config: LLMConfig):
                raise ValueError("Test error")

        adapter = ErrorAdapter()
        config = LLMConfig(
            provider="bedrock",
            model_name="test",
            parameters=LLMParameters(),
            provider_config=BedrockProviderConfig(region="us-east-1"),
        )

        with pytest.raises(ValueError) as exc_info:
            adapter.create_client(config)

        assert "Test error" in str(exc_info.value)

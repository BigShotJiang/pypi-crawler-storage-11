"""Tests for LLM adapters."""

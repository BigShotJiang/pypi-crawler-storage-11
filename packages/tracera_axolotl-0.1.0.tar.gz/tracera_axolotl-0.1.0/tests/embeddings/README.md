# Embeddings Module Tests

This directory contains comprehensive tests for the embeddings module.

## Test Structure

```
tests/embeddings/
├── domain/
│   └── test_config.py              # Tests for BedrockConfig and domain models
├── ports/
│   └── test_embeddings.py          # Tests for EmbeddingsPort interface
├── adapters/
│   ├── test_base.py                # Tests for BaseEmbeddingAdapter
│   ├── test_factory.py             # Tests for EmbeddingAdapterFactory
│   └── llamaindex/
│       └── test_bedrock.py         # Tests for LlamaindxBedrockEmbeddingAdapter
├── test_exceptions.py              # Tests for EmbeddingError
├── test_integration.py             # End-to-end integration tests
└── README.md                       # This file
```

## Test Categories

### Unit Tests
- **Domain Tests** (`domain/`): Test configuration models, validation, environment variable support
- **Port Tests** (`ports/`): Test abstract interface definitions and contracts
- **Adapter Tests** (`adapters/`): Test base adapter functionality and concrete implementations
- **Exception Tests**: Test custom exception behavior and error handling

### Integration Tests
- **End-to-End Workflows**: Test complete workflows from configuration to embedding generation
- **Factory Integration**: Test adapter creation and provider selection
- **Error Propagation**: Test error handling across all layers

## Running Tests

### Run All Embeddings Tests
```bash
cd /path/to/axolotl
pytest tests/embeddings/ -v
```

### Run Specific Test Categories
```bash
# Domain model tests
pytest tests/embeddings/domain/ -v

# Adapter tests
pytest tests/embeddings/adapters/ -v

# Integration tests
pytest tests/embeddings/test_integration.py -v
```

### Run with Coverage
```bash
pytest tests/embeddings/ --cov=axolotl.embeddings --cov-report=html
```

## Test Fixtures

The tests use several shared fixtures defined in `conftest.py`:

- `clean_environment`: Ensures clean AWS environment variables
- `mock_bedrock_embedding`: Provides mocked LlamaIndex BedrockEmbedding
- `sample_bedrock_config`: Provides a sample configuration for testing

## Mocking Strategy

Tests extensively use mocking to:
- **Avoid AWS API calls**: All AWS Bedrock interactions are mocked
- **Test error conditions**: Simulate various failure scenarios
- **Isolate units**: Test individual components without dependencies
- **Speed up tests**: No network calls or external dependencies

## Key Test Scenarios

### Configuration Tests
- Environment variable loading and precedence
- Validation of provider and framework values
- Credential handling and security
- Serialization/deserialization

### Adapter Tests
- Abstract method enforcement
- Error handling and propagation
- Logging and debugging support
- Dimension caching
- Input validation

### Factory Tests
- Provider-framework combination routing
- Protocol-based configuration acceptance
- Registry management and extensibility
- Model discovery and listing

### Integration Tests
- Complete workflow testing
- Cross-layer error propagation
- Module import/export verification
- Real-world usage scenarios

## Adding New Tests

When adding new functionality to the embeddings module:

1. **Add unit tests** for the specific component
2. **Add integration tests** for cross-component interactions
3. **Use appropriate fixtures** to avoid duplication
4. **Mock external dependencies** (AWS, LlamaIndex, etc.)
5. **Test both success and failure scenarios**
6. **Update this README** if new test categories are added

## Common Test Patterns

### Testing Configuration
```python
def test_config_feature():
    config = BedrockConfig(model_name="test-model")
    assert config.provider == "bedrock"
```

### Testing Adapters with Mocking
```python
@patch('module.BedrockEmbedding')
def test_adapter_feature(mock_bedrock):
    mock_bedrock.return_value.get_text_embedding.return_value = [1.0, 2.0]
    # Test adapter functionality
```

### Testing Error Conditions
```python
def test_error_scenario():
    with pytest.raises(EmbeddingError) as exc_info:
        # Code that should raise error
        pass
    assert "expected error message" in str(exc_info.value)
```

## Test Quality Guidelines

- **High Coverage**: Aim for >90% code coverage
- **Clear Test Names**: Use descriptive test method names
- **Isolated Tests**: Each test should be independent
- **Fast Execution**: Use mocking to avoid slow operations
- **Comprehensive Scenarios**: Test both happy path and edge cases
- **Documentation**: Document complex test scenarios

"""Tests for embeddings port interface."""

from abc import ABC
from typing import get_type_hints

import pytest

from axolotl.embeddings.ports.embeddings import EmbeddingsPort


class TestEmbeddingsPort:
    """Test EmbeddingsPort interface definition."""

    def test_is_abstract_base_class(self) -> None:
        """Test that EmbeddingsPort is an abstract base class."""
        assert issubclass(EmbeddingsPort, ABC)

        # Should not be able to instantiate directly
        with pytest.raises(TypeError):
            EmbeddingsPort()

    def test_has_required_abstract_methods(self) -> None:
        """Test that all required abstract methods are defined."""
        # Get all abstract methods
        abstract_methods = EmbeddingsPort.__abstractmethods__

        expected_methods = {"embed_text", "embed_texts", "dimension"}
        assert abstract_methods == expected_methods

    def test_embed_text_signature(self) -> None:
        """Test embed_text method signature."""
        method = EmbeddingsPort.embed_text
        hints = get_type_hints(method)

        assert "text" in hints
        assert hints["text"] is str
        assert hints["return"] == list[float]

    def test_embed_texts_signature(self) -> None:
        """Test embed_texts method signature."""
        method = EmbeddingsPort.embed_texts
        hints = get_type_hints(method)

        assert "texts" in hints
        assert hints["texts"] == list[str]
        assert hints["return"] == list[list[float]]

    def test_dimension_property_signature(self) -> None:
        """Test dimension property signature."""
        # Check that dimension is a property
        dimension_descriptor = EmbeddingsPort.dimension
        assert isinstance(dimension_descriptor, property)

        # Check type hints on the getter
        if hasattr(dimension_descriptor.fget, "__annotations__"):
            hints = get_type_hints(dimension_descriptor.fget)
            assert hints.get("return") is int

    def test_concrete_implementation_requirements(self) -> None:
        """Test that concrete implementations must implement all methods."""

        # Incomplete implementation should fail
        class IncompleteImplementation(EmbeddingsPort):
            def embed_text(self, text: str) -> list[float]:
                return [1.0, 2.0, 3.0]

            # Missing embed_texts and dimension

        with pytest.raises(TypeError):
            IncompleteImplementation()

        # Complete implementation should work
        class CompleteImplementation(EmbeddingsPort):
            def embed_text(self, text: str) -> list[float]:
                return [1.0, 2.0, 3.0]

            def embed_texts(self, texts: list[str]) -> list[list[float]]:
                return [[1.0, 2.0, 3.0] for _ in texts]

            @property
            def dimension(self) -> int:
                return 3

        # Should be able to instantiate
        impl = CompleteImplementation()
        assert isinstance(impl, EmbeddingsPort)

        # Should be able to call methods
        assert impl.embed_text("test") == [1.0, 2.0, 3.0]
        assert impl.embed_texts(["test1", "test2"]) == [
            [1.0, 2.0, 3.0],
            [1.0, 2.0, 3.0],
        ]
        assert impl.dimension == 3

    def test_method_docstrings(self) -> None:
        """Test that all methods have proper docstrings."""
        assert EmbeddingsPort.embed_text.__doc__ is not None
        assert "text to vector embedding" in EmbeddingsPort.embed_text.__doc__.lower()

        assert EmbeddingsPort.embed_texts.__doc__ is not None
        assert "multiple texts" in EmbeddingsPort.embed_texts.__doc__.lower()

        assert EmbeddingsPort.dimension.__doc__ is not None
        assert "dimension" in EmbeddingsPort.dimension.__doc__.lower()

    def test_interface_consistency(self) -> None:
        """Test that the interface is consistent and well-defined."""
        # Test that all expected methods exist
        assert hasattr(EmbeddingsPort, "embed_text")
        assert hasattr(EmbeddingsPort, "embed_texts")
        assert hasattr(EmbeddingsPort, "dimension")

        # Test that these are the only abstract methods
        all_methods = [
            name
            for name in dir(EmbeddingsPort)
            if not name.startswith("_")
            and callable(getattr(EmbeddingsPort, name, None))
        ]
        all_properties = [
            name
            for name in dir(EmbeddingsPort)
            if not name.startswith("_")
            and isinstance(getattr(EmbeddingsPort, name, None), property)
        ]

        expected_methods = ["embed_text", "embed_texts"]
        expected_properties = ["dimension"]

        assert set(all_methods) >= set(expected_methods)
        assert set(all_properties) >= set(expected_properties)

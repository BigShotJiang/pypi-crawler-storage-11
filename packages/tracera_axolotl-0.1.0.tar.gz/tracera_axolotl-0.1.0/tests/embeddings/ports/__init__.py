"""Tests for embeddings ports."""

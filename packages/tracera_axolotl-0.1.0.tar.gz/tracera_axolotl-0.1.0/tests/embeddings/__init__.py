"""Tests for embeddings module."""

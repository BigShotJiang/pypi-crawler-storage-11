"""Tests for embeddings exceptions."""

import pytest

from axolotl.embeddings.exceptions import EmbeddingError


class TestEmbeddingError:
    """Test EmbeddingError exception class."""

    def test_basic_initialization(self) -> None:
        """Test basic error initialization with just message."""
        error = EmbeddingError("Test error message")

        assert str(error) == "Test error message"
        assert error.message == "Test error message"
        assert error.details is None

    def test_initialization_with_details(self) -> None:
        """Test error initialization with details."""
        details = {"model": "test-model", "provider": "test-provider"}
        error = EmbeddingError("Test error message", details=details)

        assert error.message == "Test error message"
        assert error.details == details

    def test_str_representation_without_details(self) -> None:
        """Test string representation without details."""
        error = EmbeddingError("Simple error")
        assert str(error) == "Simple error"

    def test_str_representation_with_details(self) -> None:
        """Test string representation with details."""
        details = {"key1": "value1", "key2": "value2"}
        error = EmbeddingError("Error with details", details=details)

        error_str = str(error)
        assert "Error with details" in error_str
        assert "Details:" in error_str
        assert "key1" in error_str
        assert "value1" in error_str

    def test_str_representation_with_none_details(self) -> None:
        """Test string representation when details is explicitly None."""
        error = EmbeddingError("Error message", details=None)
        assert str(error) == "Error message"

    def test_inheritance_from_exception(self) -> None:
        """Test that EmbeddingError inherits from Exception."""
        error = EmbeddingError("Test error")
        assert isinstance(error, Exception)

    def test_raising_and_catching(self) -> None:
        """Test raising and catching the exception."""
        with pytest.raises(EmbeddingError) as exc_info:
            raise EmbeddingError("Test exception")

        assert str(exc_info.value) == "Test exception"
        assert exc_info.value.message == "Test exception"

    def test_raising_with_details(self) -> None:
        """Test raising exception with details."""
        details = {"operation": "embed_text", "model": "test-model"}

        with pytest.raises(EmbeddingError) as exc_info:
            raise EmbeddingError("Operation failed", details=details)

        error = exc_info.value
        assert error.message == "Operation failed"
        assert error.details == details
        assert error.details["operation"] == "embed_text"
        assert error.details["model"] == "test-model"

    def test_chaining_from_other_exception(self) -> None:
        """Test exception chaining from other exceptions."""
        original_error = ValueError("Original error")

        try:
            raise original_error
        except ValueError as e:
            embedding_error = EmbeddingError(
                "Wrapped error", details={"original": str(e)}
            )

            # Test that we can chain exceptions
            with pytest.raises(EmbeddingError) as exc_info:
                raise embedding_error from e

            assert exc_info.value.message == "Wrapped error"
            assert exc_info.value.details["original"] == "Original error"

    def test_details_with_various_types(self) -> None:
        """Test details with various data types."""
        details = {
            "string_value": "test",
            "int_value": 42,
            "float_value": 3.14,
            "bool_value": True,
            "list_value": [1, 2, 3],
            "dict_value": {"nested": "value"},
            "none_value": None,
        }

        error = EmbeddingError("Complex details", details=details)

        assert error.details == details
        assert error.details["string_value"] == "test"
        assert error.details["int_value"] == 42
        assert error.details["float_value"] == 3.14
        assert error.details["bool_value"] is True
        assert error.details["list_value"] == [1, 2, 3]
        assert error.details["dict_value"]["nested"] == "value"
        assert error.details["none_value"] is None

    def test_empty_details_dict(self) -> None:
        """Test with empty details dictionary."""
        error = EmbeddingError("Error message", details={})

        error_str = str(error)
        assert "Error message" in error_str
        assert "Details:" in error_str
        assert "{}" in error_str

    def test_repr_method(self) -> None:
        """Test __repr__ method."""
        error = EmbeddingError("Test error")
        repr_str = repr(error)

        # Should contain class name and message
        assert "EmbeddingError" in repr_str
        assert "Test error" in repr_str

    def test_equality_and_comparison(self) -> None:
        """Test equality behavior."""
        error1 = EmbeddingError("Same message")
        error2 = EmbeddingError("Same message")
        error3 = EmbeddingError("Different message")

        # Exceptions are not equal by default (they're objects)
        assert error1 != error2
        assert error1 != error3

        # But messages should be the same
        assert error1.message == error2.message
        assert error1.message != error3.message

    def test_details_immutability_concern(self) -> None:
        """Test that details can be accessed and modified (documenting current behavior)."""
        original_details = {"key": "value"}
        error = EmbeddingError("Test", details=original_details)

        # Current behavior: details is the same object
        assert error.details is original_details

        # Modifying original affects the error (documenting this behavior)
        original_details["new_key"] = "new_value"
        assert "new_key" in error.details

        # If this becomes a problem, details should be copied in __init__

    def test_use_in_logging_context(self) -> None:
        """Test that error works well in logging contexts."""
        import logging
        from io import StringIO

        # Create a string buffer to capture log output
        log_buffer = StringIO()
        handler = logging.StreamHandler(log_buffer)
        logger = logging.getLogger("test_logger")
        logger.addHandler(handler)
        logger.setLevel(logging.ERROR)

        try:
            details = {"model": "test-model", "operation": "embed_text"}
            error = EmbeddingError("Embedding operation failed", details=details)
            logger.error("An error occurred: %s", error)

            log_output = log_buffer.getvalue()
            assert "Embedding operation failed" in log_output
            assert "Details:" in log_output

        finally:
            logger.removeHandler(handler)

"""Integration tests for the embeddings module."""

from unittest.mock import Mock, patch

import pytest

from axolotl.embeddings import (
    BedrockConfig,
    EmbeddingAdapterFactory,
    EmbeddingError,
    EmbeddingsPort,
    LlamaindexBedrockEmbeddingAdapter,
)


class TestEmbeddingsIntegration:
    """Integration tests for the complete embeddings workflow."""

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_end_to_end_workflow(self, mock_bedrock_embedding) -> None:
        """Test complete end-to-end workflow from config to embeddings."""
        # Setup mock
        mock_embedding_instance = Mock()
        mock_embedding_instance.get_text_embedding.return_value = [1.0, 2.0, 3.0]
        mock_embedding_instance.get_text_embedding_batch.return_value = [
            [1.0, 2.0, 3.0],
            [4.0, 5.0, 6.0],
        ]
        mock_bedrock_embedding.return_value = mock_embedding_instance

        # 1. Create configuration
        config = BedrockConfig(
            model_name="amazon.titan-embed-text-v1",
            framework="llamaindex",
            region="us-east-1",
        )

        # 2. Create adapter using factory
        adapter = EmbeddingAdapterFactory.create_adapter(config)

        # 3. Verify adapter type
        assert isinstance(adapter, LlamaindexBedrockEmbeddingAdapter)
        assert isinstance(adapter, EmbeddingsPort)

        # 4. Use adapter for single embedding
        single_result = adapter.embed_text("Hello world")
        assert single_result == [1.0, 2.0, 3.0]

        # 5. Use adapter for batch embeddings
        batch_result = adapter.embed_texts(["Hello", "world"])
        assert batch_result == [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]]

        # 6. Get dimension
        assert adapter.dimension == 3

        # Verify underlying calls
        # get_text_embedding is called during initialization (for dimension) and during the test
        assert mock_embedding_instance.get_text_embedding.call_count >= 2
        # Check that it was called with "Hello world" at least once
        assert any(
            call[0][0] == "Hello world"
            for call in mock_embedding_instance.get_text_embedding.call_args_list
        )
        mock_embedding_instance.get_text_embedding_batch.assert_called_with(
            ["Hello", "world"]
        )

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_factory_provider_framework_selection(self, mock_bedrock_embedding) -> None:
        """Test that factory correctly selects adapters based on provider and framework."""
        mock_embedding_instance = Mock()
        mock_bedrock_embedding.return_value = mock_embedding_instance

        # Test bedrock:llamaindex combination
        config = BedrockConfig(
            model_name="amazon.titan-embed-text-v1",
            provider="bedrock",
            framework="llamaindex",
        )

        adapter = EmbeddingAdapterFactory.create_adapter(config)
        assert isinstance(adapter, LlamaindexBedrockEmbeddingAdapter)

        # Test case insensitivity
        config.provider = "BEDROCK"
        config.framework = "LLAMAINDEX"

        adapter = EmbeddingAdapterFactory.create_adapter(config)
        assert isinstance(adapter, LlamaindexBedrockEmbeddingAdapter)

    def test_config_environment_variable_integration(self) -> None:
        """Test that config properly loads from environment variables."""
        with patch.dict(
            "os.environ",
            {
                "AWS_REGION": "eu-west-1",
                "AWS_ACCESS_KEY_ID": "AKIATEST123",
                "AWS_SECRET_ACCESS_KEY": "secret-key",  # pragma: allowlist secret
                "AWS_PROFILE": "test-profile",
            },
        ):
            config = BedrockConfig(model_name="amazon.titan-embed-text-v1")

            assert config.region == "eu-west-1"
            assert config.access_key_id == "AKIATEST123"
            assert config.secret_access_key == "secret-key"  # pragma: allowlist secret
            assert config.profile_name == "test-profile"

    def test_error_propagation_through_layers(self) -> None:
        """Test that errors are properly propagated through all layers."""

        # Test unsupported provider
        class UnsupportedConfig:
            provider = "unsupported"
            framework = "llamaindex"
            model_name = "test-model"

        config = UnsupportedConfig()

        with pytest.raises(EmbeddingError) as exc_info:
            EmbeddingAdapterFactory.create_adapter(config)

        assert "Unsupported provider-framework combination" in str(exc_info.value)
        assert exc_info.value.details["provider"] == "unsupported"
        assert exc_info.value.details["framework"] == "llamaindex"

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_adapter_initialization_error_propagation(
        self, mock_bedrock_embedding
    ) -> None:
        """Test error propagation when adapter initialization fails."""
        mock_bedrock_embedding.side_effect = RuntimeError("AWS authentication failed")

        config = BedrockConfig(model_name="amazon.titan-embed-text-v1")

        with pytest.raises(EmbeddingError) as exc_info:
            EmbeddingAdapterFactory.create_adapter(config)

        error = exc_info.value
        assert "Failed to initialize Bedrock embedding adapter" in str(error)
        assert error.details["provider"] == "bedrock"
        assert error.details["model_name"] == "amazon.titan-embed-text-v1"

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_runtime_error_propagation(self, mock_bedrock_embedding) -> None:
        """Test error propagation during runtime operations."""
        mock_embedding_instance = Mock()
        mock_embedding_instance.get_text_embedding.side_effect = RuntimeError(
            "Model overloaded"
        )
        mock_bedrock_embedding.return_value = mock_embedding_instance

        config = BedrockConfig(model_name="amazon.titan-embed-text-v1")
        adapter = EmbeddingAdapterFactory.create_adapter(config)

        with pytest.raises(EmbeddingError) as exc_info:
            adapter.embed_text("test")

        error = exc_info.value
        assert "Failed to generate embedding for text" in str(error)
        assert error.details["model"] == "amazon.titan-embed-text-v1"
        assert error.details["text_length"] == 4

    def test_module_imports_and_exports(self) -> None:
        """Test that all expected classes are properly imported and exported."""
        from axolotl.embeddings import (
            BedrockConfig,
            EmbeddingAdapterFactory,
            EmbeddingError,
            EmbeddingsPort,
            LlamaindexBedrockEmbeddingAdapter,
        )

        # Verify all classes are available
        assert EmbeddingsPort is not None
        assert EmbeddingError is not None
        assert EmbeddingAdapterFactory is not None
        assert LlamaindexBedrockEmbeddingAdapter is not None
        assert BedrockConfig is not None

        # Verify inheritance relationships
        assert issubclass(LlamaindexBedrockEmbeddingAdapter, EmbeddingsPort)
        assert issubclass(EmbeddingError, Exception)

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_supported_models_integration(self, mock_bedrock_embedding) -> None:
        """Test supported models functionality integration."""
        mock_models = [
            "amazon.titan-embed-text-v1",
            "amazon.titan-embed-text-v2:0",
            "cohere.embed-english-v3",
        ]
        mock_bedrock_embedding.list_supported_models.return_value = mock_models

        # Test via factory
        factory_models = EmbeddingAdapterFactory.get_supported_models(
            "bedrock", "llamaindex"
        )
        assert factory_models == mock_models

        # Test via adapter class
        adapter_models = LlamaindexBedrockEmbeddingAdapter.get_supported_models()
        assert adapter_models == mock_models

        # Test default framework parameter
        default_models = EmbeddingAdapterFactory.get_supported_models("bedrock")
        assert default_models == mock_models

    def test_factory_registry_operations(self) -> None:
        """Test factory registry operations."""
        # Test getting supported providers and frameworks
        providers = EmbeddingAdapterFactory.get_supported_providers()
        frameworks = EmbeddingAdapterFactory.get_supported_frameworks()
        combinations = EmbeddingAdapterFactory.get_supported_combinations()

        assert "bedrock" in providers
        assert "llamaindex" in frameworks
        assert "bedrock:llamaindex" in combinations

        # Test support checking
        assert EmbeddingAdapterFactory.is_provider_supported("bedrock")
        assert EmbeddingAdapterFactory.is_combination_supported("bedrock", "llamaindex")
        assert not EmbeddingAdapterFactory.is_provider_supported("unsupported")
        assert not EmbeddingAdapterFactory.is_combination_supported(
            "bedrock", "unsupported"
        )

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_configuration_flexibility(self, mock_bedrock_embedding) -> None:
        """Test different configuration scenarios."""
        mock_embedding_instance = Mock()
        mock_bedrock_embedding.return_value = mock_embedding_instance

        # Test minimal configuration
        config1 = BedrockConfig(model_name="amazon.titan-embed-text-v1")
        adapter1 = EmbeddingAdapterFactory.create_adapter(config1)
        assert adapter1.config.region == "us-east-1"  # Default

        # Test with explicit credentials
        config2 = BedrockConfig(
            model_name="amazon.titan-embed-text-v1",
            region="us-west-2",
            access_key_id="AKIATEST123",
            secret_access_key="secret-key",  # pragma: allowlist secret
        )
        adapter2 = EmbeddingAdapterFactory.create_adapter(config2)
        assert adapter2.config.region == "us-west-2"
        assert adapter2.config.access_key_id == "AKIATEST123"

        # Test with additional kwargs
        config3 = BedrockConfig(
            model_name="amazon.titan-embed-text-v1",
            additional_kwargs={"timeout": 30, "max_retries": 3},
        )
        adapter3 = EmbeddingAdapterFactory.create_adapter(config3)
        assert adapter3.config.additional_kwargs["timeout"] == 30
        assert adapter3.config.additional_kwargs["max_retries"] == 3

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_logging_integration(self, mock_bedrock_embedding) -> None:
        """Test that logging works properly throughout the system."""
        import logging
        from io import StringIO

        # Setup logging capture
        log_buffer = StringIO()
        handler = logging.StreamHandler(log_buffer)
        handler.setLevel(logging.DEBUG)

        # Add handler to relevant loggers
        loggers = [
            logging.getLogger("LlamaindexBedrockEmbeddingAdapter"),
            logging.getLogger("BaseEmbeddingAdapter"),
        ]

        for logger in loggers:
            logger.addHandler(handler)
            logger.setLevel(logging.DEBUG)

        try:
            mock_embedding_instance = Mock()
            mock_embedding_instance.get_text_embedding.return_value = [1.0, 2.0, 3.0]
            mock_bedrock_embedding.return_value = mock_embedding_instance

            config = BedrockConfig(model_name="amazon.titan-embed-text-v1")
            adapter = EmbeddingAdapterFactory.create_adapter(config)
            adapter.embed_text("test")

            # Check that log messages were generated
            log_buffer.getvalue()
            # Note: Actual log content depends on implementation details

        finally:
            # Clean up handlers
            for logger in loggers:
                logger.removeHandler(handler)

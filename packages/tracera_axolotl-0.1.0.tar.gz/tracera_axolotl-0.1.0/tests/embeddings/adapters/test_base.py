"""Tests for base embedding adapter."""

import logging
from unittest.mock import Mock, patch

import pytest

from axolotl.embeddings.adapters.base import BaseEmbeddingAdapter
from axolotl.embeddings.exceptions import EmbeddingError


class TestBaseEmbeddingAdapter:
    """Test BaseEmbeddingAdapter functionality."""

    def create_test_adapter(self) -> type[BaseEmbeddingAdapter]:
        """Create a test adapter implementation."""

        class TestAdapter(BaseEmbeddingAdapter):
            def __init__(self, model_name: str = "test-model", dimension: int = 3):
                super().__init__(model_name)
                self._test_dimension = dimension
                self._embed_single_calls: list[str] = []
                self._embed_multiple_calls: list[list[str]] = []

            def _embed_single_text(self, text: str) -> list[float]:
                self._embed_single_calls.append(text)
                return [1.0, 2.0, 3.0]

            def _embed_multiple_texts(self, texts: list[str]) -> list[list[float]]:
                self._embed_multiple_calls.append(texts)
                return [[1.0, 2.0, 3.0] for _ in texts]

            def _get_dimension(self) -> int:
                return self._test_dimension

        return TestAdapter

    def test_initialization(self) -> None:
        """Test base adapter initialization."""
        TestAdapter = self.create_test_adapter()
        adapter = TestAdapter(model_name="test-model")

        assert adapter.model_name == "test-model"
        assert isinstance(adapter.logger, logging.Logger)
        assert adapter.logger.name == "TestAdapter"
        assert adapter._dimension is None  # Not cached yet

    def test_embed_text_success(self) -> None:
        """Test successful single text embedding."""
        TestAdapter = self.create_test_adapter()
        adapter = TestAdapter()

        result = adapter.embed_text("hello world")

        assert result == [1.0, 2.0, 3.0]
        assert adapter._embed_single_calls == ["hello world"]

    def test_embed_text_empty_input(self) -> None:
        """Test embed_text with empty input."""
        TestAdapter = self.create_test_adapter()
        adapter = TestAdapter()

        # Empty string
        with pytest.raises(EmbeddingError) as exc_info:
            adapter.embed_text("")
        assert "cannot be empty" in str(exc_info.value)

        # Whitespace only
        with pytest.raises(EmbeddingError) as exc_info:
            adapter.embed_text("   ")
        assert "cannot be empty" in str(exc_info.value)

    def test_embed_text_implementation_error(self) -> None:
        """Test embed_text when implementation raises an error."""

        class FailingAdapter(BaseEmbeddingAdapter):
            def __init__(self) -> None:
                super().__init__("failing-model")

            def _embed_single_text(self, text: str) -> list[float]:
                raise ValueError("Simulated failure")

            def _embed_multiple_texts(self, texts: list[str]) -> list[list[float]]:
                return []

            def _get_dimension(self) -> int:
                return 3

        adapter = FailingAdapter()

        with pytest.raises(EmbeddingError) as exc_info:
            adapter.embed_text("test")

        assert "Failed to generate embedding for text" in str(exc_info.value)
        assert exc_info.value.details["model"] == "failing-model"
        assert exc_info.value.details["text_length"] == 4

    def test_embed_texts_success(self) -> None:
        """Test successful multiple texts embedding."""
        TestAdapter = self.create_test_adapter()
        adapter = TestAdapter()

        texts = ["hello", "world", "test"]
        result = adapter.embed_texts(texts)

        expected = [[1.0, 2.0, 3.0], [1.0, 2.0, 3.0], [1.0, 2.0, 3.0]]
        assert result == expected
        assert adapter._embed_multiple_calls == [texts]

    def test_embed_texts_empty_list(self) -> None:
        """Test embed_texts with empty list."""
        TestAdapter = self.create_test_adapter()
        adapter = TestAdapter()

        with pytest.raises(EmbeddingError) as exc_info:
            adapter.embed_texts([])
        assert "cannot be empty" in str(exc_info.value)

    def test_embed_texts_empty_text_in_list(self) -> None:
        """Test embed_texts with empty text in list."""
        TestAdapter = self.create_test_adapter()
        adapter = TestAdapter()

        with pytest.raises(EmbeddingError) as exc_info:
            adapter.embed_texts(["hello", "", "world"])
        assert "Text at index 1 cannot be empty" in str(exc_info.value)

    def test_embed_texts_inconsistent_dimensions(self) -> None:
        """Test embed_texts with inconsistent embedding dimensions."""

        class InconsistentAdapter(BaseEmbeddingAdapter):
            def __init__(self) -> None:
                super().__init__("inconsistent-model")

            def _embed_single_text(self, text: str) -> list[float]:
                return [1.0, 2.0, 3.0]

            def _embed_multiple_texts(self, texts: list[str]) -> list[list[float]]:
                # Return inconsistent dimensions
                return [[1.0, 2.0, 3.0], [1.0, 2.0]]  # Different lengths

            def _get_dimension(self) -> int:
                return 3

        adapter = InconsistentAdapter()

        with pytest.raises(EmbeddingError) as exc_info:
            adapter.embed_texts(["text1", "text2"])
        assert "Inconsistent embedding dimensions" in str(exc_info.value)

    def test_embed_texts_implementation_error(self) -> None:
        """Test embed_texts when implementation raises an error."""

        class FailingAdapter(BaseEmbeddingAdapter):
            def __init__(self) -> None:
                super().__init__("failing-model")

            def _embed_single_text(self, text: str) -> list[float]:
                return [1.0, 2.0, 3.0]

            def _embed_multiple_texts(self, texts: list[str]) -> list[list[float]]:
                raise RuntimeError("Batch processing failed")

            def _get_dimension(self) -> int:
                return 3

        adapter = FailingAdapter()

        with pytest.raises(EmbeddingError) as exc_info:
            adapter.embed_texts(["test1", "test2"])

        assert "Failed to generate embeddings for 2 texts" in str(exc_info.value)
        assert exc_info.value.details["model"] == "failing-model"
        assert exc_info.value.details["batch_size"] == 2

    def test_dimension_property_caching(self) -> None:
        """Test that dimension property caches the result."""
        TestAdapter = self.create_test_adapter()
        adapter = TestAdapter(dimension=5)

        # Mock the _get_dimension method to count calls
        with patch.object(
            adapter, "_get_dimension", return_value=5
        ) as mock_get_dimension:
            # First call
            dim1 = adapter.dimension
            assert dim1 == 5
            assert mock_get_dimension.call_count == 1

            # Second call should use cached value
            dim2 = adapter.dimension
            assert dim2 == 5
            assert mock_get_dimension.call_count == 1  # Not called again

    def test_dimension_property_error(self) -> None:
        """Test dimension property when implementation raises an error."""

        class FailingDimensionAdapter(BaseEmbeddingAdapter):
            def __init__(self) -> None:
                super().__init__("failing-dimension-model")

            def _embed_single_text(self, text: str) -> list[float]:
                return [1.0, 2.0, 3.0]

            def _embed_multiple_texts(self, texts: list[str]) -> list[list[float]]:
                return [[1.0, 2.0, 3.0] for _ in texts]

            def _get_dimension(self) -> int:
                raise ConnectionError("Cannot determine dimension")

        adapter = FailingDimensionAdapter()

        with pytest.raises(EmbeddingError) as exc_info:
            _ = adapter.dimension

        assert "Failed to get embedding dimension" in str(exc_info.value)
        assert exc_info.value.details["model"] == "failing-dimension-model"

    @patch("axolotl.embeddings.adapters.base.logging.getLogger")
    def test_logging_configuration(self, mock_get_logger: Mock) -> None:
        """Test that logging is properly configured."""
        mock_logger = Mock()
        mock_get_logger.return_value = mock_logger

        TestAdapter = self.create_test_adapter()
        adapter = TestAdapter(model_name="test-model")

        # Verify logger was configured with class name
        mock_get_logger.assert_called_once_with("TestAdapter")
        assert adapter.logger == mock_logger

    def test_logging_calls(self) -> None:
        """Test that appropriate log messages are generated."""
        TestAdapter = self.create_test_adapter()
        adapter = TestAdapter()

        with patch.object(adapter.logger, "debug") as mock_debug:
            adapter.embed_text("test")

            # Should log debug messages
            debug_calls = [call.args[0] for call in mock_debug.call_args_list]
            assert any(
                "Generating embedding for text of length" in msg for msg in debug_calls
            )
            assert any(
                "Successfully generated embedding with dimension" in msg
                for msg in debug_calls
            )

    def test_abstract_methods_enforcement(self) -> None:
        """Test that abstract methods must be implemented."""

        # Missing all abstract methods
        class IncompleteAdapter(BaseEmbeddingAdapter):
            pass

        with pytest.raises(TypeError):
            IncompleteAdapter("test")

        # Missing some abstract methods
        class PartialAdapter(BaseEmbeddingAdapter):
            def _embed_single_text(self, text: str) -> list[float]:
                return [1.0, 2.0, 3.0]

            # Missing _embed_multiple_texts and _get_dimension

        with pytest.raises(TypeError):
            PartialAdapter("test")

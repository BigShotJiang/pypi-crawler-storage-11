"""Tests for LlamaIndex Bedrock embedding adapter."""

from typing import Any
from unittest.mock import Mock, patch

import pytest

from axolotl.embeddings.adapters.llamaindex.bedrock import (
    LlamaindexBedrockEmbeddingAdapter,
)
from axolotl.embeddings.domain.config import BedrockConfig
from axolotl.embeddings.exceptions import EmbeddingError
from axolotl.embeddings.ports import EmbeddingsPort


class TestLlamaindexBedrockEmbeddingAdapter:
    """Test LlamaIndex Bedrock embedding adapter."""

    def create_test_config(self, **kwargs: Any) -> BedrockConfig:
        """Create a test BedrockConfig."""
        defaults = {"model_name": "amazon.titan-embed-text-v1", "region": "us-east-1"}
        defaults.update(kwargs)
        return BedrockConfig(**defaults)

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_initialization_success(self, mock_bedrock_embedding: Mock) -> None:
        """Test successful adapter initialization."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        mock_bedrock_embedding.return_value = mock_embedding_instance

        adapter = LlamaindexBedrockEmbeddingAdapter(config)

        # Verify initialization
        assert adapter.config == config
        assert adapter.model_name == "amazon.titan-embed-text-v1"
        assert adapter._embedding_model == mock_embedding_instance

        # Verify BedrockEmbedding was called with correct arguments
        expected_kwargs = {
            "model_name": "amazon.titan-embed-text-v1",
            "region_name": "us-east-1",
        }
        mock_bedrock_embedding.assert_called_once_with(**expected_kwargs)

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_initialization_with_credentials(
        self, mock_bedrock_embedding: Mock
    ) -> None:
        """Test initialization with AWS credentials."""
        config = self.create_test_config(
            access_key_id="AKIATEST123",
            secret_access_key="secret-key",  # pragma: allowlist secret
            session_token="session-token",
            profile_name="test-profile",
            additional_kwargs={"timeout": 30},
        )

        LlamaindexBedrockEmbeddingAdapter(config)

        # Verify BedrockEmbedding was called with credentials
        expected_kwargs = {
            "model_name": "amazon.titan-embed-text-v1",
            "region_name": "us-east-1",
            "aws_access_key_id": "AKIATEST123",
            "aws_secret_access_key": "secret-key",  # pragma: allowlist secret
            "aws_session_token": "session-token",
            "profile_name": "test-profile",
            "timeout": 30,
        }
        mock_bedrock_embedding.assert_called_once_with(**expected_kwargs)

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_initialization_with_partial_credentials(
        self, mock_bedrock_embedding: Mock
    ) -> None:
        """Test initialization with only some credentials provided."""
        config = self.create_test_config(
            access_key_id="AKIATEST123",
            # secret_access_key not provided
            profile_name="test-profile",
        )

        LlamaindexBedrockEmbeddingAdapter(config)

        # Should only include provided credentials
        expected_kwargs = {
            "model_name": "amazon.titan-embed-text-v1",
            "region_name": "us-east-1",
            "aws_access_key_id": "AKIATEST123",
            "profile_name": "test-profile",
        }
        mock_bedrock_embedding.assert_called_once_with(**expected_kwargs)

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_initialization_failure(self, mock_bedrock_embedding: Mock) -> None:
        """Test adapter initialization failure."""
        config = self.create_test_config()
        mock_bedrock_embedding.side_effect = ValueError("Invalid credentials")

        with pytest.raises(EmbeddingError) as exc_info:
            LlamaindexBedrockEmbeddingAdapter(config)

        error = exc_info.value
        assert "Failed to initialize Bedrock embedding adapter" in str(error)
        assert error.details["model_name"] == "amazon.titan-embed-text-v1"
        assert error.details["region"] == "us-east-1"
        assert error.details["provider"] == "bedrock"

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_embed_single_text_success(self, mock_bedrock_embedding: Mock) -> None:
        """Test successful single text embedding."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        mock_embedding_instance.get_text_embedding.return_value = [1.0, 2.0, 3.0]
        mock_bedrock_embedding.return_value = mock_embedding_instance

        adapter = LlamaindexBedrockEmbeddingAdapter(config)
        result = adapter._embed_single_text("hello world")

        assert result == [1.0, 2.0, 3.0]
        mock_embedding_instance.get_text_embedding.assert_called_once_with(
            "hello world"
        )

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_embed_single_text_failure(self, mock_bedrock_embedding: Mock) -> None:
        """Test single text embedding failure."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        mock_embedding_instance.get_text_embedding.side_effect = RuntimeError(
            "API error"
        )
        mock_bedrock_embedding.return_value = mock_embedding_instance

        adapter = LlamaindexBedrockEmbeddingAdapter(config)

        with pytest.raises(EmbeddingError) as exc_info:
            adapter._embed_single_text("test")

        error = exc_info.value
        assert "Bedrock embedding failed for single text" in str(error)
        assert error.details["model_name"] == "amazon.titan-embed-text-v1"
        assert error.details["text_length"] == 4
        assert error.details["provider"] == "bedrock"

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_embed_multiple_texts_success(self, mock_bedrock_embedding: Mock) -> None:
        """Test successful multiple texts embedding."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        expected_result = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]]
        mock_embedding_instance.get_text_embedding_batch.return_value = expected_result
        mock_bedrock_embedding.return_value = mock_embedding_instance

        adapter = LlamaindexBedrockEmbeddingAdapter(config)
        texts = ["hello", "world"]
        result = adapter._embed_multiple_texts(texts)

        assert result == expected_result
        mock_embedding_instance.get_text_embedding_batch.assert_called_once_with(texts)

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_embed_multiple_texts_failure(self, mock_bedrock_embedding: Mock) -> None:
        """Test multiple texts embedding failure."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        mock_embedding_instance.get_text_embedding_batch.side_effect = RuntimeError(
            "Batch API error"
        )
        mock_bedrock_embedding.return_value = mock_embedding_instance

        adapter = LlamaindexBedrockEmbeddingAdapter(config)
        texts = ["hello", "world"]

        with pytest.raises(EmbeddingError) as exc_info:
            adapter._embed_multiple_texts(texts)

        error = exc_info.value
        assert "Bedrock batch embedding failed for 2 texts" in str(error)
        assert error.details["model_name"] == "amazon.titan-embed-text-v1"
        assert error.details["batch_size"] == 2
        assert error.details["provider"] == "bedrock"

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_get_dimension_success(self, mock_bedrock_embedding: Mock) -> None:
        """Test successful dimension retrieval."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        mock_bedrock_embedding.return_value = mock_embedding_instance

        adapter = LlamaindexBedrockEmbeddingAdapter(config)

        # Mock the _embed_single_text method to return a test embedding
        with patch.object(adapter, "_embed_single_text", return_value=[1.0, 2.0, 3.0]):
            dimension = adapter._get_dimension()
            assert dimension == 3

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_get_dimension_failure(self, mock_bedrock_embedding: Mock) -> None:
        """Test dimension retrieval failure."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        mock_bedrock_embedding.return_value = mock_embedding_instance

        adapter = LlamaindexBedrockEmbeddingAdapter(config)

        # Mock _embed_single_text to fail
        with patch.object(
            adapter, "_embed_single_text", side_effect=RuntimeError("Embedding failed")
        ):
            with pytest.raises(EmbeddingError) as exc_info:
                adapter._get_dimension()

            error = exc_info.value
            assert "Failed to determine Bedrock embedding dimension" in str(error)
            assert error.details["model_name"] == "amazon.titan-embed-text-v1"
            assert error.details["provider"] == "bedrock"

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_validate_model_name_success(self, mock_bedrock_embedding: Mock) -> None:
        """Test successful model name validation."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        mock_bedrock_embedding.return_value = mock_embedding_instance
        mock_bedrock_embedding.list_supported_models.return_value = [
            "amazon.titan-embed-text-v1",
            "amazon.titan-embed-text-v2:0",
        ]

        adapter = LlamaindexBedrockEmbeddingAdapter(config)
        result = adapter._validate_model_name()

        assert result is True
        # list_supported_models is called during initialization and again in the test
        assert mock_bedrock_embedding.list_supported_models.call_count == 2

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_validate_model_name_unsupported_model(
        self, mock_bedrock_embedding: Mock
    ) -> None:
        """Test validation with unsupported model."""
        config = self.create_test_config(model_name="unsupported-model")
        mock_embedding_instance = Mock()
        mock_bedrock_embedding.return_value = mock_embedding_instance
        mock_bedrock_embedding.list_supported_models.return_value = [
            "amazon.titan-embed-text-v1",
            "amazon.titan-embed-text-v2:0",
        ]

        with patch.object(mock_embedding_instance, "logger") as mock_logger:
            adapter = LlamaindexBedrockEmbeddingAdapter(config)

            with patch.object(adapter, "logger", mock_logger):
                result = adapter._validate_model_name()

                assert result is False
                # Should log warning about unsupported model
                mock_logger.warning.assert_called_once()

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_validate_model_name_api_failure(
        self, mock_bedrock_embedding: Mock
    ) -> None:
        """Test validation when API call fails."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        mock_bedrock_embedding.return_value = mock_embedding_instance
        mock_bedrock_embedding.list_supported_models.side_effect = RuntimeError(
            "API error"
        )

        adapter = LlamaindexBedrockEmbeddingAdapter(config)

        with patch.object(adapter, "logger") as mock_logger:
            result = adapter._validate_model_name()

            assert result is True  # Should assume valid on error
            mock_logger.debug.assert_called_once()

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_get_supported_models_success(self, mock_bedrock_embedding: Mock) -> None:
        """Test successful retrieval of supported models."""
        expected_models = [
            "amazon.titan-embed-text-v1",
            "amazon.titan-embed-text-v2:0",
            "cohere.embed-english-v3",
        ]
        mock_bedrock_embedding.list_supported_models.return_value = expected_models

        result = LlamaindexBedrockEmbeddingAdapter.get_supported_models()

        assert result == expected_models
        mock_bedrock_embedding.list_supported_models.assert_called_once()

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_get_supported_models_failure(self, mock_bedrock_embedding: Mock) -> None:
        """Test supported models retrieval failure."""
        mock_bedrock_embedding.list_supported_models.side_effect = RuntimeError(
            "API error"
        )

        with pytest.raises(Exception) as exc_info:
            LlamaindexBedrockEmbeddingAdapter.get_supported_models()

        assert "Failed to retrieve Bedrock models" in str(exc_info.value)
        assert "AWS authentication issues" in str(exc_info.value)

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_integration_with_base_adapter(self, mock_bedrock_embedding: Mock) -> None:
        """Test integration with base adapter functionality."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        mock_embedding_instance.get_text_embedding.return_value = [1.0, 2.0, 3.0]
        mock_embedding_instance.get_text_embedding_batch.return_value = [
            [1.0, 2.0, 3.0],
            [4.0, 5.0, 6.0],
        ]
        mock_bedrock_embedding.return_value = mock_embedding_instance

        adapter = LlamaindexBedrockEmbeddingAdapter(config)

        # Test that it implements EmbeddingsPort
        assert isinstance(adapter, EmbeddingsPort)

        # Test inherited methods work
        result = adapter.embed_text("test")
        assert result == [1.0, 2.0, 3.0]

        batch_result = adapter.embed_texts(["test1", "test2"])
        assert batch_result == [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]]

        # Test dimension property
        with patch.object(adapter, "_embed_single_text", return_value=[1.0, 2.0, 3.0]):
            assert adapter.dimension == 3

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_repr_method(self, mock_bedrock_embedding: Mock) -> None:
        """Test string representation."""
        config = self.create_test_config(region="us-west-2")
        adapter = LlamaindexBedrockEmbeddingAdapter(config)

        repr_str = repr(adapter)
        assert "LlamaindexBedrockEmbeddingAdapter" in repr_str
        assert "amazon.titan-embed-text-v1" in repr_str
        assert "us-west-2" in repr_str

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_initialization_with_validation_call(
        self, mock_bedrock_embedding: Mock
    ) -> None:
        """Test that validation is called during initialization."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        mock_bedrock_embedding.return_value = mock_embedding_instance

        with patch.object(
            LlamaindexBedrockEmbeddingAdapter, "_validate_model_name", return_value=True
        ) as mock_validate:
            LlamaindexBedrockEmbeddingAdapter(config)
            mock_validate.assert_called_once()

    @patch("axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding")
    def test_initialization_validation_failure_continues(
        self, mock_bedrock_embedding: Mock
    ) -> None:
        """Test that initialization continues even if validation fails."""
        config = self.create_test_config()
        mock_embedding_instance = Mock()
        mock_bedrock_embedding.return_value = mock_embedding_instance

        with patch.object(
            LlamaindexBedrockEmbeddingAdapter,
            "_validate_model_name",
            side_effect=Exception("Validation error"),
        ):
            # Should not raise exception, just log debug message
            adapter = LlamaindexBedrockEmbeddingAdapter(config)
            assert adapter is not None

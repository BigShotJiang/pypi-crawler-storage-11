"""Tests for LlamaIndex embeddings adapters."""

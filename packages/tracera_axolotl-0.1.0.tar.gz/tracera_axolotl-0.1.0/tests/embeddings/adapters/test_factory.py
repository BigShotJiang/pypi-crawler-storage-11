"""Tests for embedding adapter factory."""

from unittest.mock import Mock, patch

import pytest

from axolotl.embeddings.adapters.factory import (
    EmbeddingAdapterFactory,
    EmbeddingConfigProtocol,
)
from axolotl.embeddings.domain.config import BedrockConfig
from axolotl.embeddings.exceptions import EmbeddingError
from axolotl.embeddings.ports import EmbeddingsPort


class TestEmbeddingConfigProtocol:
    """Test EmbeddingConfigProtocol."""

    def test_protocol_compliance_bedrock_config(self) -> None:
        """Test that BedrockConfig implements the protocol."""
        config = BedrockConfig(model_name="amazon.titan-embed-text-v1")

        # Should have required attributes
        assert hasattr(config, "provider")
        assert hasattr(config, "framework")
        assert hasattr(config, "model_name")

        # Should be compatible with protocol
        assert isinstance(config, EmbeddingConfigProtocol)

    def test_protocol_with_custom_config(self) -> None:
        """Test protocol with a custom config class."""

        class CustomConfig:
            def __init__(self) -> None:
                self.provider = "custom"
                self.framework = "llamaindex"
                self.model_name = "custom-model"

        config = CustomConfig()

        # Should be compatible with protocol due to structural typing
        assert hasattr(config, "provider")
        assert hasattr(config, "framework")
        assert hasattr(config, "model_name")


class TestEmbeddingAdapterFactory:
    """Test EmbeddingAdapterFactory functionality."""

    def setup_method(self) -> None:
        """Set up test fixtures."""
        # Create mock adapter class
        self.mock_adapter_class = Mock()
        self.mock_adapter_instance = Mock()
        self.mock_adapter_class.return_value = self.mock_adapter_instance

        # Store original registry for cleanup
        self.original_adapters = EmbeddingAdapterFactory._ADAPTERS.copy()

    def teardown_method(self) -> None:
        """Clean up after tests."""
        # Restore original registry
        EmbeddingAdapterFactory._ADAPTERS = self.original_adapters

    def test_registry_initialization(self) -> None:
        """Test that the adapter registry is properly initialized."""
        adapters = EmbeddingAdapterFactory._ADAPTERS

        # Should have bedrock:llamaindex registered
        assert "bedrock:llamaindex" in adapters
        assert (
            adapters["bedrock:llamaindex"].__name__
            == "LlamaindexBedrockEmbeddingAdapter"
        )

    def test_create_adapter_bedrock_success(self) -> None:
        """Test successful creation of Bedrock adapter."""
        config = BedrockConfig(model_name="amazon.titan-embed-text-v1")

        # Mock the actual adapter class
        with patch(
            "axolotl.embeddings.adapters.llamaindex.bedrock.LlamaindexBedrockEmbeddingAdapter"
        ) as mock_adapter:
            mock_instance = Mock()
            mock_adapter.return_value = mock_instance

            # Temporarily replace registry
            EmbeddingAdapterFactory._ADAPTERS["bedrock:llamaindex"] = mock_adapter

            result = EmbeddingAdapterFactory.create_adapter(config)

            assert result == mock_instance
            mock_adapter.assert_called_once_with(config)

    def test_create_adapter_unsupported_combination(self) -> None:
        """Test creating adapter with unsupported provider-framework combination."""

        class UnsupportedConfig:
            provider = "unsupported"
            framework = "unknown"
            model_name = "test-model"

        config = UnsupportedConfig()

        with pytest.raises(EmbeddingError) as exc_info:
            EmbeddingAdapterFactory.create_adapter(config)

        error = exc_info.value
        assert (
            "Unsupported provider-framework combination: 'unsupported:unknown'"
            in str(error)
        )
        assert error.details["provider"] == "unsupported"
        assert error.details["framework"] == "unknown"
        assert error.details["adapter_key"] == "unsupported:unknown"

    def test_create_adapter_wrong_config_type(self) -> None:
        """Test creating adapter with wrong config type for provider."""

        class WrongConfig:
            provider = "bedrock"
            framework = "llamaindex"
            model_name = "test-model"

        config = WrongConfig()

        with pytest.raises(EmbeddingError) as exc_info:
            EmbeddingAdapterFactory.create_adapter(config)

        error = exc_info.value
        assert "BedrockConfig required for provider 'bedrock'" in str(error)
        assert error.details["provider"] == "bedrock"
        assert error.details["config_type"] == "WrongConfig"

    def test_create_adapter_initialization_failure(self) -> None:
        """Test adapter creation when adapter initialization fails."""
        config = BedrockConfig(model_name="amazon.titan-embed-text-v1")

        # Mock adapter that fails during initialization
        failing_adapter = Mock()
        failing_adapter.side_effect = ValueError("Initialization failed")

        EmbeddingAdapterFactory._ADAPTERS["bedrock:llamaindex"] = failing_adapter

        with pytest.raises(EmbeddingError) as exc_info:
            EmbeddingAdapterFactory.create_adapter(config)

        error = exc_info.value
        assert "Failed to create adapter for bedrock:llamaindex" in str(error)
        assert error.details["provider"] == "bedrock"
        assert error.details["framework"] == "llamaindex"
        assert error.details["model_name"] == "amazon.titan-embed-text-v1"

    def test_get_supported_providers(self) -> None:
        """Test getting supported providers."""
        # Add some test adapters
        EmbeddingAdapterFactory._ADAPTERS.update(
            {
                "provider1:framework1": Mock(),
                "provider1:framework2": Mock(),
                "provider2:framework1": Mock(),
            }
        )

        providers = EmbeddingAdapterFactory.get_supported_providers()

        # Should extract unique providers
        assert "bedrock" in providers  # From original registry
        assert "provider1" in providers
        assert "provider2" in providers

        # Should not have duplicates
        assert len(set(providers)) == len(providers)

    def test_get_supported_frameworks(self) -> None:
        """Test getting supported frameworks."""
        # Add some test adapters
        EmbeddingAdapterFactory._ADAPTERS.update(
            {
                "provider1:framework1": Mock(),
                "provider1:framework2": Mock(),
                "provider2:framework1": Mock(),
            }
        )

        frameworks = EmbeddingAdapterFactory.get_supported_frameworks()

        # Should extract unique frameworks
        assert "llamaindex" in frameworks  # From original registry
        assert "framework1" in frameworks
        assert "framework2" in frameworks

        # Should not have duplicates
        assert len(set(frameworks)) == len(frameworks)

    def test_get_supported_combinations(self) -> None:
        """Test getting supported combinations."""
        # Add some test adapters
        test_combinations = {
            "provider1:framework1": Mock(),
            "provider2:framework2": Mock(),
        }
        EmbeddingAdapterFactory._ADAPTERS.update(test_combinations)

        combinations = EmbeddingAdapterFactory.get_supported_combinations()

        # Should include original and new combinations
        assert "bedrock:llamaindex" in combinations
        assert "provider1:framework1" in combinations
        assert "provider2:framework2" in combinations

    def test_is_provider_supported(self) -> None:
        """Test checking if provider is supported."""
        # Add test provider
        EmbeddingAdapterFactory._ADAPTERS["testprovider:llamaindex"] = Mock()

        assert EmbeddingAdapterFactory.is_provider_supported("bedrock")
        assert EmbeddingAdapterFactory.is_provider_supported("testprovider")
        assert not EmbeddingAdapterFactory.is_provider_supported("unsupported")

        # Case insensitive
        assert EmbeddingAdapterFactory.is_provider_supported("BEDROCK")

    def test_is_combination_supported(self) -> None:
        """Test checking if provider-framework combination is supported."""
        # Add test combination
        EmbeddingAdapterFactory._ADAPTERS["testprovider:testframework"] = Mock()

        assert EmbeddingAdapterFactory.is_combination_supported("bedrock", "llamaindex")
        assert EmbeddingAdapterFactory.is_combination_supported(
            "testprovider", "testframework"
        )
        assert not EmbeddingAdapterFactory.is_combination_supported(
            "bedrock", "unsupported"
        )
        assert not EmbeddingAdapterFactory.is_combination_supported(
            "unsupported", "llamaindex"
        )

        # Case insensitive
        assert EmbeddingAdapterFactory.is_combination_supported("BEDROCK", "LLAMAINDEX")

    def test_get_supported_models_bedrock_llamaindex(self) -> None:
        """Test getting supported models for bedrock:llamaindex."""
        mock_models = ["model1", "model2", "model3"]

        # Mock the adapter class in the registry
        mock_adapter = Mock()
        mock_adapter.get_supported_models.return_value = mock_models
        EmbeddingAdapterFactory._ADAPTERS["bedrock:llamaindex"] = mock_adapter

        result = EmbeddingAdapterFactory.get_supported_models("bedrock", "llamaindex")

        assert result == mock_models
        mock_adapter.get_supported_models.assert_called_once()

    def test_get_supported_models_unsupported_combination(self) -> None:
        """Test getting models for unsupported combination."""
        with pytest.raises(EmbeddingError) as exc_info:
            EmbeddingAdapterFactory.get_supported_models("unsupported", "framework")

        error = exc_info.value
        assert (
            "Unsupported provider-framework combination: 'unsupported:framework'"
            in str(error)
        )

    def test_get_supported_models_not_implemented(self) -> None:
        """Test getting models for combination without implementation."""

        # Create a real class without get_supported_models method
        class AdapterWithoutModels:
            pass

        # Add combination without model listing implementation
        EmbeddingAdapterFactory._ADAPTERS["newprovider:newframework"] = (
            AdapterWithoutModels
        )

        with pytest.raises(EmbeddingError) as exc_info:
            EmbeddingAdapterFactory.get_supported_models("newprovider", "newframework")

        error = exc_info.value
        assert (
            "Model listing not implemented for combination: 'newprovider:newframework'"
            in str(error)
        )

    def test_get_supported_models_adapter_failure(self) -> None:
        """Test getting models when adapter method fails."""
        # Mock the adapter class in the registry
        mock_adapter = Mock()
        mock_adapter.get_supported_models.side_effect = RuntimeError("API failure")
        EmbeddingAdapterFactory._ADAPTERS["bedrock:llamaindex"] = mock_adapter

        with pytest.raises(EmbeddingError) as exc_info:
            EmbeddingAdapterFactory.get_supported_models("bedrock", "llamaindex")

        error = exc_info.value
        assert "Failed to get supported models for bedrock:llamaindex" in str(error)

    def test_register_adapter(self) -> None:
        """Test registering a new adapter."""

        class MockEmbeddingsPort(EmbeddingsPort):
            def embed_text(self, text: str) -> list[float]:
                return [1.0, 2.0]

            def embed_texts(self, texts: list[str]) -> list[list[float]]:
                return [[1.0, 2.0] for _ in texts]

            @property
            def dimension(self) -> int:
                return 2

        # Register new adapter
        EmbeddingAdapterFactory.register_adapter(
            "newprovider", "newframework", MockEmbeddingsPort
        )

        # Should be added to registry
        assert "newprovider:newframework" in EmbeddingAdapterFactory._ADAPTERS
        assert (
            EmbeddingAdapterFactory._ADAPTERS["newprovider:newframework"]
            == MockEmbeddingsPort
        )

        # Should be detectable
        assert EmbeddingAdapterFactory.is_combination_supported(
            "newprovider", "newframework"
        )

    def test_register_adapter_invalid_class(self) -> None:
        """Test registering adapter with invalid class."""

        class InvalidAdapter:
            pass  # Doesn't implement EmbeddingsPort

        with pytest.raises(EmbeddingError) as exc_info:
            EmbeddingAdapterFactory.register_adapter(
                "provider", "framework", InvalidAdapter
            )

        error = exc_info.value
        assert "Adapter class must implement EmbeddingsPort interface" in str(error)
        assert error.details["provider"] == "provider"
        assert error.details["framework"] == "framework"
        assert error.details["adapter_class"] == "InvalidAdapter"

    def test_case_insensitive_operations(self) -> None:
        """Test that factory operations are case insensitive."""
        config = BedrockConfig(model_name="amazon.titan-embed-text-v1")

        # Mock the adapter class in the registry
        mock_adapter = Mock()
        mock_instance = Mock()
        mock_adapter.return_value = mock_instance
        EmbeddingAdapterFactory._ADAPTERS["bedrock:llamaindex"] = mock_adapter

        # Test with different case combinations
        config.provider = "BEDROCK"
        config.framework = "LLAMAINDEX"

        result = EmbeddingAdapterFactory.create_adapter(config)
        assert result == mock_instance

    def test_default_framework_parameter(self) -> None:
        """Test that get_supported_models uses llamaindex as default framework."""
        mock_models = ["model1", "model2"]

        # Mock the adapter class in the registry
        mock_adapter = Mock()
        mock_adapter.get_supported_models.return_value = mock_models
        EmbeddingAdapterFactory._ADAPTERS["bedrock:llamaindex"] = mock_adapter

        # Call without framework parameter
        result = EmbeddingAdapterFactory.get_supported_models("bedrock")

        assert result == mock_models
        mock_adapter.get_supported_models.assert_called_once()

    def test_create_adapter_future_provider_fallback(self) -> None:
        """Test creating adapter for future provider using fallback case."""
        config = Mock()
        config.provider = "future"
        config.framework = "framework"

        # Mock a future provider adapter that doesn't have specific type checking
        class FutureProviderAdapter:
            def __init__(self, config):
                self.config = config

        # Add future provider to registry
        EmbeddingAdapterFactory._ADAPTERS["future:framework"] = FutureProviderAdapter

        result = EmbeddingAdapterFactory.create_adapter(config)

        assert isinstance(result, FutureProviderAdapter)
        assert result.config == config

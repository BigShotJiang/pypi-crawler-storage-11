"""Tests for embeddings adapters."""

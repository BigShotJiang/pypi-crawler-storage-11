"""Tests for embeddings domain configuration models."""

import os
from unittest.mock import patch

import pytest
from pydantic import ValidationError

from axolotl.embeddings.domain.config import BedrockConfig


class TestBedrockConfig:
    """Test BedrockConfig domain model."""

    def test_minimal_config(self) -> None:
        """Test creating config with only required fields."""
        config = BedrockConfig(model_name="amazon.titan-embed-text-v1")

        assert config.provider == "bedrock"
        assert config.framework == "llamaindex"
        assert config.model_name == "amazon.titan-embed-text-v1"
        assert config.region == "us-east-1"  # Default
        assert config.access_key_id is None
        assert config.secret_access_key is None
        assert config.session_token is None
        assert config.profile_name is None
        assert config.additional_kwargs == {}

    def test_explicit_config(self) -> None:
        """Test creating config with all fields explicitly set."""
        config = BedrockConfig(
            model_name="amazon.titan-embed-text-v2:0",
            framework="langchain",
            region="us-west-2",
            access_key_id="AKIATEST123",
            secret_access_key="secret-test-key",  # pragma: allowlist secret
            session_token="session-token",
            profile_name="test-profile",
            additional_kwargs={"timeout": 30},
        )

        assert config.provider == "bedrock"
        assert config.framework == "langchain"
        assert config.model_name == "amazon.titan-embed-text-v2:0"
        assert config.region == "us-west-2"
        assert config.access_key_id == "AKIATEST123"
        assert config.secret_access_key == "secret-test-key"  # pragma: allowlist secret
        assert config.session_token == "session-token"
        assert config.profile_name == "test-profile"
        assert config.additional_kwargs == {"timeout": 30}

    def test_provider_literal_validation(self) -> None:
        """Test that provider defaults to 'bedrock' but accepts any string."""
        # Valid provider (default)
        config = BedrockConfig(model_name="test-model")
        assert config.provider == "bedrock"

        # Provider can be overridden to any string value
        config_custom = BedrockConfig(provider="openai", model_name="test-model")
        assert config_custom.provider == "openai"

    def test_framework_literal_validation(self) -> None:
        """Test that framework defaults to 'llamaindex' but accepts any string."""
        # Valid frameworks
        config1 = BedrockConfig(model_name="test-model", framework="llamaindex")
        assert config1.framework == "llamaindex"

        config2 = BedrockConfig(model_name="test-model", framework="langchain")
        assert config2.framework == "langchain"

        # Framework can be overridden to any string value
        config_custom = BedrockConfig(model_name="test-model", framework="invalid")
        assert config_custom.framework == "invalid"

    def test_model_name_required(self) -> None:
        """Test that model_name is required."""
        with pytest.raises(ValidationError) as exc_info:
            BedrockConfig()

        assert "Field required" in str(exc_info.value)
        assert "model_name" in str(exc_info.value)

    def test_extra_fields_forbidden(self) -> None:
        """Test that extra fields are not allowed."""
        with pytest.raises(ValidationError) as exc_info:
            BedrockConfig(model_name="test-model", invalid_field="should-fail")

        assert "Extra inputs are not permitted" in str(exc_info.value)

    @patch.dict(os.environ, {}, clear=True)
    def test_environment_variables_aws_region(self) -> None:
        """Test loading AWS_REGION from environment."""
        with patch.dict(os.environ, {"AWS_REGION": "eu-west-1"}):
            config = BedrockConfig(model_name="test-model")
            assert config.region == "eu-west-1"

    @patch.dict(os.environ, {}, clear=True)
    def test_environment_variables_aws_default_region(self) -> None:
        """Test loading AWS_DEFAULT_REGION from environment."""
        with patch.dict(os.environ, {"AWS_DEFAULT_REGION": "ap-southeast-2"}):
            config = BedrockConfig(model_name="test-model")
            assert config.region == "ap-southeast-2"

    @patch.dict(os.environ, {}, clear=True)
    def test_environment_variables_region_precedence(self) -> None:
        """Test that AWS_REGION takes precedence over AWS_DEFAULT_REGION."""
        with patch.dict(
            os.environ, {"AWS_REGION": "us-west-1", "AWS_DEFAULT_REGION": "us-west-2"}
        ):
            config = BedrockConfig(model_name="test-model")
            assert config.region == "us-west-1"

    @patch.dict(os.environ, {}, clear=True)
    def test_environment_variables_credentials(self) -> None:
        """Test loading AWS credentials from environment."""
        with patch.dict(
            os.environ,
            {
                "AWS_ACCESS_KEY_ID": "AKIATEST123",
                "AWS_SECRET_ACCESS_KEY": "secret-test-key",  # pragma: allowlist secret
                "AWS_SESSION_TOKEN": "session-token",
                "AWS_PROFILE": "test-profile",
            },
        ):
            config = BedrockConfig(model_name="test-model")
            assert config.access_key_id == "AKIATEST123"
            assert (
                config.secret_access_key
                == "secret-test-key"  # pragma: allowlist secret
            )  # pragma: allowlist secret
            assert config.session_token == "session-token"
            assert config.profile_name == "test-profile"

    @patch.dict(os.environ, {}, clear=True)
    def test_explicit_override_environment(self) -> None:
        """Test that explicit values override environment variables."""
        with patch.dict(
            os.environ,
            {
                "AWS_REGION": "us-west-1",
                "AWS_ACCESS_KEY_ID": "AKIAENV123",
                "AWS_PROFILE": "env-profile",
            },
        ):
            config = BedrockConfig(
                model_name="test-model",
                region="us-east-1",  # Override env
                access_key_id="AKIAEXPLICIT123",  # Override env
                # profile_name not specified - should use env
            )

            assert config.region == "us-east-1"  # Explicit override
            assert config.access_key_id == "AKIAEXPLICIT123"  # Explicit override
            assert config.profile_name == "env-profile"  # From environment

    @patch.dict(os.environ, {}, clear=True)
    def test_empty_string_to_none_validator(self) -> None:
        """Test that empty strings are converted to None for optional fields."""
        config = BedrockConfig(
            model_name="test-model",
            access_key_id="",  # Empty string should become None
            secret_access_key="",
            session_token="",
            profile_name="",
        )

        assert config.access_key_id is None
        assert config.secret_access_key is None
        assert config.session_token is None
        assert config.profile_name is None

    @patch.dict(os.environ, {}, clear=True)
    def test_no_environment_variables_fallback(self) -> None:
        """Test fallback behavior when no environment variables are set."""
        config = BedrockConfig(model_name="test-model")

        assert config.region == "us-east-1"  # Default fallback
        assert config.access_key_id is None
        assert config.secret_access_key is None
        assert config.session_token is None
        assert config.profile_name is None

    def test_config_serialization(self) -> None:
        """Test that config can be serialized/deserialized."""
        original_config = BedrockConfig(
            model_name="amazon.titan-embed-text-v1",
            framework="langchain",
            region="us-west-2",
            access_key_id="AKIATEST123",
            additional_kwargs={"timeout": 30},
        )

        # Serialize to dict
        config_dict = original_config.model_dump()

        # Deserialize from dict
        reconstructed_config = BedrockConfig(**config_dict)

        assert reconstructed_config.model_name == original_config.model_name
        assert reconstructed_config.framework == original_config.framework
        assert reconstructed_config.region == original_config.region
        assert reconstructed_config.access_key_id == original_config.access_key_id
        assert (
            reconstructed_config.additional_kwargs == original_config.additional_kwargs
        )

    def test_repr_and_str(self) -> None:
        """Test string representations."""
        config = BedrockConfig(
            model_name="amazon.titan-embed-text-v1", region="us-west-2"
        )

        # Should not raise exceptions
        repr_str = repr(config)
        assert "BedrockConfig" in repr_str

        # Should be able to convert to string
        str_repr = str(config)
        assert isinstance(str_repr, str)

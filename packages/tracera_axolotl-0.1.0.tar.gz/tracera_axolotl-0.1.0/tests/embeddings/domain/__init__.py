"""Tests for embeddings domain models."""

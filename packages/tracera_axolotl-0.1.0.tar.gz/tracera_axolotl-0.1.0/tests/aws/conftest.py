"""Test fixtures for AWS module tests."""

import pytest
from unittest.mock import MagicMock, patch
from botocore.exceptions import ClientError

from axolotl.aws.config import AWSConfig


@pytest.fixture
def aws_config():
    """Create a test AWS configuration."""
    return AWSConfig(
        region="us-west-2",
        access_key_id="test_access_key",
        secret_access_key="test_secret_key",
    )


@pytest.fixture
def mock_boto3_session():
    """Mock boto3 session."""
    with patch("boto3.Session") as mock_session:
        yield mock_session


@pytest.fixture
def mock_s3_client():
    """Mock S3 client."""
    mock_client = MagicMock()
    with patch("axolotl.aws.config.AWSConfig.create_client", return_value=mock_client):
        yield mock_client


@pytest.fixture
def mock_secrets_manager_client():
    """Mock Secrets Manager client."""
    mock_client = MagicMock()
    with patch("axolotl.aws.config.AWSConfig.create_client", return_value=mock_client):
        yield mock_client


@pytest.fixture
def mock_parameter_store_client():
    """Mock Parameter Store client."""
    mock_client = MagicMock()
    with patch("axolotl.aws.config.AWSConfig.create_client", return_value=mock_client):
        yield mock_client


@pytest.fixture
def s3_client_error():
    """S3 ClientError for testing error handling."""
    return ClientError(
        error_response={
            "Error": {"Code": "NoSuchBucket", "Message": "Bucket not found"}
        },
        operation_name="GetObject",
    )


@pytest.fixture
def secrets_manager_error():
    """Secrets Manager ClientError for testing error handling."""
    return ClientError(
        error_response={
            "Error": {
                "Code": "ResourceNotFoundException",
                "Message": "Secret not found",
            }
        },
        operation_name="GetSecretValue",
    )


@pytest.fixture
def parameter_store_error():
    """Parameter Store ClientError for testing error handling."""
    return ClientError(
        error_response={
            "Error": {"Code": "ParameterNotFound", "Message": "Parameter not found"}
        },
        operation_name="GetParameter",
    )


@pytest.fixture
def s3_upload_response():
    """Mock S3 upload response."""
    return {
        "ETag": '"d41d8cd98f00b204e9800998ecf8427e"',
        "VersionId": "test-version-id",
    }


@pytest.fixture
def s3_download_response():
    """Mock S3 download response."""
    return {
        "ContentLength": 1024,
        "ContentType": "text/plain",
        "ETag": '"d41d8cd98f00b204e9800998ecf8427e"',
    }


@pytest.fixture
def s3_list_response():
    """Mock S3 list objects response."""
    return {
        "Contents": [
            {
                "Key": "test-file-1.txt",
                "Size": 1024,
                "LastModified": "2023-01-01T00:00:00Z",
            },
            {
                "Key": "test-file-2.txt",
                "Size": 2048,
                "LastModified": "2023-01-02T00:00:00Z",
            },
        ],
        "IsTruncated": False,
    }


@pytest.fixture
def secrets_manager_get_response():
    """Mock Secrets Manager get secret response."""
    return {
        "ARN": "arn:aws:secretsmanager:us-west-2:123456789012:secret:test-secret",
        "Name": "test-secret",
        "SecretString": "test-secret-value",
        "VersionId": "test-version-id",
        "VersionStages": ["AWSCURRENT"],
    }


@pytest.fixture
def parameter_store_get_response():
    """Mock Parameter Store get parameter response."""
    return {
        "Parameter": {
            "Name": "/test/parameter",
            "Type": "String",
            "Value": "test-parameter-value",
            "Version": 1,
            "LastModifiedDate": "2023-01-01T00:00:00Z",
        }
    }


@pytest.fixture
def parameter_store_put_response():
    """Mock Parameter Store put parameter response."""
    return {
        "Version": 1,
        "Tier": "Standard",
    }

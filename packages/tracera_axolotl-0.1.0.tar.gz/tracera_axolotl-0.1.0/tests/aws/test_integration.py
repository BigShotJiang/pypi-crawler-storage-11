"""Integration tests for AWS services."""

from unittest.mock import patch, MagicMock

from axolotl.aws.config import AWSConfig
from axolotl.aws.s3.client import S3Client
from axolotl.aws.secrets_manager.client import SecretsManagerClient
from axolotl.aws.parameter_store.client import ParameterStoreClient


class TestAWSIntegration:
    """Integration tests for AWS services."""

    def test_aws_config_shared_across_services(self):
        """Test that AWS config is shared across all services."""
        config = AWSConfig(region="us-west-2", access_key_id="test_key")

        with patch("boto3.Session") as mock_session_class:
            mock_session = MagicMock()
            mock_client = MagicMock()
            mock_session.client.return_value = mock_client
            mock_session_class.return_value = mock_session

            s3_client = S3Client(config)
            secrets_client = SecretsManagerClient(config)
            param_client = ParameterStoreClient(config)

            # All clients should use the same config
            assert s3_client.config == config
            assert secrets_client.config == config
            assert param_client.config == config

            # All clients should be created with the same session
            assert mock_session_class.call_count == 3

    def test_aws_services_with_environment_variables(self):
        """Test AWS services with environment variables."""
        with patch.dict(
            "os.environ",
            {
                "AWS_DEFAULT_REGION": "us-east-1",
                "AWS_ACCESS_KEY_ID": "env_key",
                "AWS_SECRET_ACCESS_KEY": "env_secret",
            },
        ):
            config = AWSConfig()

            assert config.region == "us-east-1"
            assert config.access_key_id == "env_key"
            assert config.secret_access_key == "env_secret"

    def test_aws_services_error_handling_consistency(self):
        """Test that all AWS services handle errors consistently."""
        config = AWSConfig(region="us-west-2")

        with patch("boto3.Session") as mock_session_class:
            mock_session = MagicMock()
            mock_client = MagicMock()
            mock_session.client.return_value = mock_client
            mock_session_class.return_value = mock_session

            s3_client = S3Client(config)
            secrets_client = SecretsManagerClient(config)
            param_client = ParameterStoreClient(config)

            # All clients should have similar error handling patterns
            assert hasattr(s3_client, "_client")
            assert hasattr(secrets_client, "_client")
            assert hasattr(param_client, "_client")

    def test_aws_services_kwargs_support(self):
        """Test that all AWS services support **kwargs consistently."""
        config = AWSConfig(region="us-west-2")

        with patch("boto3.Session") as mock_session_class:
            mock_session = MagicMock()
            mock_client = MagicMock()
            mock_session.client.return_value = mock_client
            mock_session_class.return_value = mock_session

            s3_client = S3Client(config)
            secrets_client = SecretsManagerClient(config)
            param_client = ParameterStoreClient(config)

            # Test that methods accept **kwargs
            import inspect

            # S3 methods
            s3_methods = [
                "upload_file",
                "download_file",
                "put_object",
                "get_object",
                "list_objects",
            ]
            for method_name in s3_methods:
                method = getattr(s3_client, method_name)
                sig = inspect.signature(method)
                assert "**kwargs" in str(sig)

            # Secrets Manager methods
            secrets_methods = [
                "get_secret_value",
                "list_secrets",
                "describe_secret",
                "secret_exists",
            ]
            for method_name in secrets_methods:
                method = getattr(secrets_client, method_name)
                sig = inspect.signature(method)
                assert "**kwargs" in str(sig)

            # Parameter Store methods
            param_methods = [
                "get_parameter",
                "put_parameter",
                "delete_parameter",
                "describe_parameter",
            ]
            for method_name in param_methods:
                method = getattr(param_client, method_name)
                sig = inspect.signature(method)
                assert "**kwargs" in str(sig)

    def test_aws_services_type_annotations(self):
        """Test that all AWS services have proper type annotations."""
        config = AWSConfig(region="us-west-2")

        with patch("boto3.Session") as mock_session_class:
            mock_session = MagicMock()
            mock_client = MagicMock()
            mock_session.client.return_value = mock_client
            mock_session_class.return_value = mock_session

            s3_client = S3Client(config)
            secrets_client = SecretsManagerClient(config)
            param_client = ParameterStoreClient(config)

            # Test that methods have proper return type annotations
            import inspect

            # Check S3 methods
            s3_method = getattr(s3_client, "upload_file")
            sig = inspect.signature(s3_method)
            assert sig.return_annotation != inspect.Signature.empty

            # Check Secrets Manager methods
            secrets_method = getattr(secrets_client, "get_secret_value")
            sig = inspect.signature(secrets_method)
            assert sig.return_annotation != inspect.Signature.empty

            # Check Parameter Store methods
            param_method = getattr(param_client, "get_parameter")
            sig = inspect.signature(param_method)
            assert sig.return_annotation != inspect.Signature.empty

    def test_aws_services_import_consistency(self):
        """Test that all AWS services can be imported consistently."""
        from axolotl.aws import AWSConfig
        from axolotl.aws.s3 import S3Client
        from axolotl.aws.secrets_manager import SecretsManagerClient
        from axolotl.aws.parameter_store import ParameterStoreClient

        # All classes should be importable
        assert AWSConfig is not None
        assert S3Client is not None
        assert SecretsManagerClient is not None
        assert ParameterStoreClient is not None

    def test_aws_services_exception_hierarchy(self):
        """Test that all AWS services have consistent exception hierarchy."""
        from axolotl.aws.exceptions import AWSException
        from axolotl.aws.s3.exceptions import S3Exception
        from axolotl.aws.secrets_manager.exceptions import SecretsManagerException
        from axolotl.aws.parameter_store.exceptions import ParameterStoreException

        # All service exceptions should inherit from AWSException
        assert issubclass(S3Exception, AWSException)
        assert issubclass(SecretsManagerException, AWSException)
        assert issubclass(ParameterStoreException, AWSException)

    def test_aws_services_configuration_validation(self):
        """Test that AWS services validate configuration properly."""
        # Test with valid config
        config = AWSConfig(region="us-west-2")
        assert config.region == "us-west-2"

        # Test with environment variables
        with patch.dict("os.environ", {"AWS_DEFAULT_REGION": "us-east-1"}):
            config = AWSConfig()
            assert config.region == "us-east-1"

    def test_aws_services_mock_integration(self):
        """Test that AWS services work correctly with mocked clients."""
        config = AWSConfig(region="us-west-2")

        with patch("boto3.Session") as mock_session_class:
            mock_session = MagicMock()
            mock_s3_client = MagicMock()
            mock_secrets_client = MagicMock()
            mock_param_client = MagicMock()

            def mock_client_factory(service_name, region_name=None):
                if service_name == "s3":
                    return mock_s3_client
                elif service_name == "secretsmanager":
                    return mock_secrets_client
                elif service_name == "ssm":
                    return mock_param_client
                return MagicMock()

            mock_session.client.side_effect = mock_client_factory
            mock_session_class.return_value = mock_session

            # Create all clients
            s3_client = S3Client(config)
            secrets_client = SecretsManagerClient(config)
            param_client = ParameterStoreClient(config)

            # Verify correct clients are assigned
            assert s3_client._client == mock_s3_client
            assert secrets_client._client == mock_secrets_client
            assert param_client._client == mock_param_client

            # Verify session was created correctly
            mock_session_class.assert_called_with()

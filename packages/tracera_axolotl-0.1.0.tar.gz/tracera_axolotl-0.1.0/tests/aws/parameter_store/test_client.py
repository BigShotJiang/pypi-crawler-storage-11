"""Tests for Parameter Store client."""

import pytest
from botocore.exceptions import ClientError

from axolotl.aws.parameter_store.client import ParameterStoreClient
from axolotl.aws.parameter_store.exceptions import (
    ParameterStoreException,
    ParameterNotFoundError,
)


class TestParameterStoreClient:
    """Test cases for ParameterStoreClient class."""

    def test_parameter_store_client_initialization(
        self, aws_config, mock_parameter_store_client
    ):
        """Test ParameterStoreClient initialization."""
        client = ParameterStoreClient(aws_config)

        assert client.config == aws_config
        assert client._client == mock_parameter_store_client

    def test_get_parameter_success(
        self, aws_config, mock_parameter_store_client, parameter_store_get_response
    ):
        """Test successful parameter retrieval."""
        mock_parameter_store_client.get_parameter.return_value = (
            parameter_store_get_response
        )

        client = ParameterStoreClient(aws_config)

        result = client.get_parameter("/test/parameter")

        mock_parameter_store_client.get_parameter.assert_called_once_with(
            Name="/test/parameter", WithDecryption=True
        )
        assert result == parameter_store_get_response

    def test_get_parameter_without_decryption(
        self, aws_config, mock_parameter_store_client, parameter_store_get_response
    ):
        """Test parameter retrieval without decryption."""
        mock_parameter_store_client.get_parameter.return_value = (
            parameter_store_get_response
        )

        client = ParameterStoreClient(aws_config)

        result = client.get_parameter("/test/parameter", with_decryption=False)

        mock_parameter_store_client.get_parameter.assert_called_once_with(
            Name="/test/parameter", WithDecryption=False
        )
        assert result == parameter_store_get_response

    def test_get_parameter_not_found(
        self, aws_config, mock_parameter_store_client, parameter_store_error
    ):
        """Test parameter retrieval with parameter not found error."""
        mock_parameter_store_client.get_parameter.side_effect = parameter_store_error

        client = ParameterStoreClient(aws_config)

        with pytest.raises(
            ParameterNotFoundError, match="Parameter '/test/parameter' not found"
        ):
            client.get_parameter("/test/parameter")

    def test_get_parameter_generic_error(self, aws_config, mock_parameter_store_client):
        """Test parameter retrieval with generic error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "AccessDenied", "Message": "Access denied"}
            },
            operation_name="GetParameter",
        )
        mock_parameter_store_client.get_parameter.side_effect = error

        client = ParameterStoreClient(aws_config)

        with pytest.raises(ParameterStoreException, match="Failed to get parameter"):
            client.get_parameter("/test/parameter")

    def test_get_parameter_value(
        self, aws_config, mock_parameter_store_client, parameter_store_get_response
    ):
        """Test parameter value retrieval."""
        mock_parameter_store_client.get_parameter.return_value = (
            parameter_store_get_response
        )

        client = ParameterStoreClient(aws_config)

        result = client.get_parameter_value("/test/parameter")

        assert result == "test-parameter-value"

    def test_get_parameter_json(self, aws_config, mock_parameter_store_client):
        """Test parameter JSON retrieval."""
        json_response = {
            "Parameter": {
                "Name": "/test/parameter",
                "Value": '{"username": "admin", "password": "secret123"}',  # pragma: allowlist secret
            }
        }
        mock_parameter_store_client.get_parameter.return_value = json_response

        client = ParameterStoreClient(aws_config)

        result = client.get_parameter_json("/test/parameter")

        assert result == {"username": "admin", "password": "secret123"}

    def test_get_parameters_success(self, aws_config, mock_parameter_store_client):
        """Test successful multiple parameters retrieval."""
        parameters_response = {
            "Parameters": [
                {
                    "Name": "/test/param1",
                    "Value": "value1",
                    "Type": "String",
                },
                {
                    "Name": "/test/param2",
                    "Value": "value2",
                    "Type": "String",
                },
            ],
            "InvalidParameters": [],
        }
        mock_parameter_store_client.get_parameters.return_value = parameters_response

        client = ParameterStoreClient(aws_config)

        result = client.get_parameters(["/test/param1", "/test/param2"])

        mock_parameter_store_client.get_parameters.assert_called_once_with(
            Names=["/test/param1", "/test/param2"], WithDecryption=True
        )
        assert result == parameters_response

    def test_get_parameters_error(self, aws_config, mock_parameter_store_client):
        """Test multiple parameters retrieval with error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "AccessDenied", "Message": "Access denied"}
            },
            operation_name="GetParameters",
        )
        mock_parameter_store_client.get_parameters.side_effect = error

        client = ParameterStoreClient(aws_config)

        with pytest.raises(ParameterStoreException, match="Failed to get parameters"):
            client.get_parameters(["/test/param1", "/test/param2"])

    def test_get_parameters_by_path_success(
        self, aws_config, mock_parameter_store_client
    ):
        """Test successful parameters by path retrieval."""
        path_response = {
            "Parameters": [
                {
                    "Name": "/test/app/database/host",
                    "Value": "localhost",
                    "Type": "String",
                },
                {
                    "Name": "/test/app/database/port",
                    "Value": "5432",
                    "Type": "String",
                },
            ],
            "NextToken": "next-token",
        }
        mock_parameter_store_client.get_parameters_by_path.return_value = path_response

        client = ParameterStoreClient(aws_config)

        result = client.get_parameters_by_path(
            "/test/app/", recursive=True, with_decryption=False
        )

        mock_parameter_store_client.get_parameters_by_path.assert_called_once_with(
            Path="/test/app/", Recursive=True, WithDecryption=False
        )
        assert result == path_response

    def test_get_parameters_by_path_error(
        self, aws_config, mock_parameter_store_client
    ):
        """Test parameters by path retrieval with error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "AccessDenied", "Message": "Access denied"}
            },
            operation_name="GetParametersByPath",
        )
        mock_parameter_store_client.get_parameters_by_path.side_effect = error

        client = ParameterStoreClient(aws_config)

        with pytest.raises(
            ParameterStoreException, match="Failed to get parameters by path"
        ):
            client.get_parameters_by_path("/test/app/")

    def test_put_parameter_string(
        self, aws_config, mock_parameter_store_client, parameter_store_put_response
    ):
        """Test string parameter creation."""
        mock_parameter_store_client.put_parameter.return_value = (
            parameter_store_put_response
        )

        client = ParameterStoreClient(aws_config)

        result = client.put_parameter(
            "/test/parameter", "test-value", "String", "Test parameter"
        )

        mock_parameter_store_client.put_parameter.assert_called_once_with(
            Name="/test/parameter",
            Value="test-value",
            Type="String",
            Overwrite=False,
            Description="Test parameter",
        )
        assert result == parameter_store_put_response

    def test_put_parameter_dict(
        self, aws_config, mock_parameter_store_client, parameter_store_put_response
    ):
        """Test dictionary parameter creation."""
        mock_parameter_store_client.put_parameter.return_value = (
            parameter_store_put_response
        )

        client = ParameterStoreClient(aws_config)

        param_dict = {"username": "admin", "password": "secret123"}
        result = client.put_parameter(
            "/test/parameter", param_dict, "String", "Test parameter"
        )

        mock_parameter_store_client.put_parameter.assert_called_once_with(
            Name="/test/parameter",
            Value='{"username": "admin", "password": "secret123"}',
            Type="String",
            Overwrite=False,
            Description="Test parameter",
        )
        assert result == parameter_store_put_response

    def test_put_parameter_secure_string(
        self, aws_config, mock_parameter_store_client, parameter_store_put_response
    ):
        """Test SecureString parameter creation."""
        mock_parameter_store_client.put_parameter.return_value = (
            parameter_store_put_response
        )

        client = ParameterStoreClient(aws_config)

        result = client.put_parameter(
            "/test/parameter",
            "secret-value",
            "SecureString",
            "Test secret",
            overwrite=True,
        )

        mock_parameter_store_client.put_parameter.assert_called_once_with(
            Name="/test/parameter",
            Value="secret-value",
            Type="SecureString",
            Overwrite=True,
            Description="Test secret",
        )
        assert result == parameter_store_put_response

    def test_put_parameter_error(self, aws_config, mock_parameter_store_client):
        """Test parameter creation with error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "AccessDenied", "Message": "Access denied"}
            },
            operation_name="PutParameter",
        )
        mock_parameter_store_client.put_parameter.side_effect = error

        client = ParameterStoreClient(aws_config)

        with pytest.raises(ParameterStoreException, match="Failed to put parameter"):
            client.put_parameter("/test/parameter", "test-value")

    def test_delete_parameter_success(
        self, aws_config, mock_parameter_store_client, parameter_store_put_response
    ):
        """Test successful parameter deletion."""
        mock_parameter_store_client.delete_parameter.return_value = (
            parameter_store_put_response
        )

        client = ParameterStoreClient(aws_config)

        result = client.delete_parameter("/test/parameter")

        mock_parameter_store_client.delete_parameter.assert_called_once_with(
            Name="/test/parameter"
        )
        assert result == parameter_store_put_response

    def test_delete_parameter_not_found(
        self, aws_config, mock_parameter_store_client, parameter_store_error
    ):
        """Test parameter deletion with parameter not found error."""
        mock_parameter_store_client.delete_parameter.side_effect = parameter_store_error

        client = ParameterStoreClient(aws_config)

        with pytest.raises(
            ParameterNotFoundError, match="Parameter '/test/parameter' not found"
        ):
            client.delete_parameter("/test/parameter")

    def test_delete_parameter_error(self, aws_config, mock_parameter_store_client):
        """Test parameter deletion with generic error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "AccessDenied", "Message": "Access denied"}
            },
            operation_name="DeleteParameter",
        )
        mock_parameter_store_client.delete_parameter.side_effect = error

        client = ParameterStoreClient(aws_config)

        with pytest.raises(ParameterStoreException, match="Failed to delete parameter"):
            client.delete_parameter("/test/parameter")

    def test_delete_parameters_success(
        self, aws_config, mock_parameter_store_client, parameter_store_put_response
    ):
        """Test successful multiple parameters deletion."""
        delete_response = {
            "DeletedParameters": ["/test/param1", "/test/param2"],
            "InvalidParameters": [],
        }
        mock_parameter_store_client.delete_parameters.return_value = delete_response

        client = ParameterStoreClient(aws_config)

        result = client.delete_parameters(["/test/param1", "/test/param2"])

        mock_parameter_store_client.delete_parameters.assert_called_once_with(
            Names=["/test/param1", "/test/param2"]
        )
        assert result == delete_response

    def test_delete_parameters_error(self, aws_config, mock_parameter_store_client):
        """Test multiple parameters deletion with error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "AccessDenied", "Message": "Access denied"}
            },
            operation_name="DeleteParameters",
        )
        mock_parameter_store_client.delete_parameters.side_effect = error

        client = ParameterStoreClient(aws_config)

        with pytest.raises(
            ParameterStoreException, match="Failed to delete parameters"
        ):
            client.delete_parameters(["/test/param1", "/test/param2"])

    def test_describe_parameter_success(self, aws_config, mock_parameter_store_client):
        """Test successful parameter description."""
        describe_response = {
            "Parameter": {
                "Name": "/test/parameter",
                "Type": "String",
                "Value": "test-value",
                "Version": 1,
                "LastModifiedDate": "2023-01-01T00:00:00Z",
                "Description": "Test parameter",
            }
        }
        mock_parameter_store_client.describe_parameter.return_value = describe_response

        client = ParameterStoreClient(aws_config)

        result = client.describe_parameter("/test/parameter")

        mock_parameter_store_client.describe_parameter.assert_called_once_with(
            Name="/test/parameter"
        )
        assert result == describe_response

    def test_describe_parameter_not_found(
        self, aws_config, mock_parameter_store_client, parameter_store_error
    ):
        """Test parameter description with parameter not found error."""
        mock_parameter_store_client.describe_parameter.side_effect = (
            parameter_store_error
        )

        client = ParameterStoreClient(aws_config)

        with pytest.raises(
            ParameterNotFoundError, match="Parameter '/test/parameter' not found"
        ):
            client.describe_parameter("/test/parameter")

    def test_describe_parameter_error(self, aws_config, mock_parameter_store_client):
        """Test parameter description with generic error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "AccessDenied", "Message": "Access denied"}
            },
            operation_name="DescribeParameter",
        )
        mock_parameter_store_client.describe_parameter.side_effect = error

        client = ParameterStoreClient(aws_config)

        with pytest.raises(
            ParameterStoreException, match="Failed to describe parameter"
        ):
            client.describe_parameter("/test/parameter")

    def test_parameter_exists_true(self, aws_config, mock_parameter_store_client):
        """Test parameter exists when parameter is found."""
        mock_parameter_store_client.describe_parameter.return_value = {}

        client = ParameterStoreClient(aws_config)

        result = client.parameter_exists("/test/parameter")

        mock_parameter_store_client.describe_parameter.assert_called_once_with(
            Name="/test/parameter"
        )
        assert result is True

    def test_parameter_exists_false(
        self, aws_config, mock_parameter_store_client, parameter_store_error
    ):
        """Test parameter exists when parameter is not found."""
        mock_parameter_store_client.describe_parameter.side_effect = (
            parameter_store_error
        )

        client = ParameterStoreClient(aws_config)

        result = client.parameter_exists("/test/parameter")

        assert result is False

    def test_get_parameter_with_kwargs(
        self, aws_config, mock_parameter_store_client, parameter_store_get_response
    ):
        """Test parameter retrieval with additional kwargs."""
        mock_parameter_store_client.get_parameter.return_value = (
            parameter_store_get_response
        )

        client = ParameterStoreClient(aws_config)

        result = client.get_parameter("/test/parameter", Version=1, Label="test-label")

        mock_parameter_store_client.get_parameter.assert_called_once_with(
            Name="/test/parameter", WithDecryption=True, Version=1, Label="test-label"
        )
        assert result == parameter_store_get_response

    def test_put_parameter_with_kwargs(
        self, aws_config, mock_parameter_store_client, parameter_store_put_response
    ):
        """Test parameter creation with additional kwargs."""
        mock_parameter_store_client.put_parameter.return_value = (
            parameter_store_put_response
        )

        client = ParameterStoreClient(aws_config)

        result = client.put_parameter(
            "/test/parameter",
            "test-value",
            "String",
            "Test parameter",
            Tier="Advanced",
            Tags=[{"Key": "Environment", "Value": "Test"}],
        )

        mock_parameter_store_client.put_parameter.assert_called_once_with(
            Name="/test/parameter",
            Value="test-value",
            Type="String",
            Overwrite=False,
            Description="Test parameter",
            Tier="Advanced",
            Tags=[{"Key": "Environment", "Value": "Test"}],
        )
        assert result == parameter_store_put_response

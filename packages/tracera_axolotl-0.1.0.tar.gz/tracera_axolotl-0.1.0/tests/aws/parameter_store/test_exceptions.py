"""Tests for Parameter Store exceptions."""

from axolotl.aws.parameter_store.exceptions import (
    ParameterStoreException,
    ParameterNotFoundError,
)


class TestParameterStoreExceptions:
    """Test cases for Parameter Store exception classes."""

    def test_parameter_store_exception_creation(self):
        """Test ParameterStoreException creation."""
        exception = ParameterStoreException("Test error message")

        assert str(exception) == "Test error message"
        assert isinstance(exception, Exception)

    def test_parameter_not_found_error_creation(self):
        """Test ParameterNotFoundError creation."""
        exception = ParameterNotFoundError("Parameter not found")

        assert str(exception) == "Parameter not found"
        assert isinstance(exception, ParameterStoreException)

    def test_parameter_store_exception_with_cause(self):
        """Test ParameterStoreException with cause."""
        cause = ValueError("Original error")
        exception = ParameterStoreException("Test error message")
        exception.__cause__ = cause

        assert "Test error message" in str(exception)
        assert exception.__cause__ == cause

    def test_parameter_store_exception_inheritance(self):
        """Test ParameterStoreException inheritance hierarchy."""
        parameter_error = ParameterNotFoundError("Parameter error")

        assert isinstance(parameter_error, ParameterStoreException)
        assert isinstance(parameter_error, Exception)

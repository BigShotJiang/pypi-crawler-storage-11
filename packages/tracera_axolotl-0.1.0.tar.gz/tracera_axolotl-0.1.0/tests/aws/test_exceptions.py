"""Tests for AWS exceptions."""

from axolotl.aws.exceptions import (
    AWSException,
    AWSClientError,
    AWSResourceNotFoundError,
    AWSConfigurationError,
)


class TestAWSExceptions:
    """Test cases for AWS exception classes."""

    def test_aws_exception_creation(self):
        """Test AWSException creation."""
        exception = AWSException("Test error message")

        assert str(exception) == "Test error message"
        assert isinstance(exception, Exception)

    def test_aws_client_error_creation(self):
        """Test AWSClientError creation."""
        exception = AWSClientError("Client error message")

        assert str(exception) == "Client error message"
        assert isinstance(exception, AWSException)

    def test_aws_resource_not_found_error_creation(self):
        """Test AWSResourceNotFoundError creation."""
        exception = AWSResourceNotFoundError("Resource not found")

        assert str(exception) == "Resource not found"
        assert isinstance(exception, AWSException)

    def test_aws_configuration_error_creation(self):
        """Test AWSConfigurationError creation."""
        exception = AWSConfigurationError("Configuration error")

        assert str(exception) == "Configuration error"
        assert isinstance(exception, AWSException)

    def test_aws_exception_with_cause(self):
        """Test AWSException with cause."""
        cause = ValueError("Original error")
        exception = AWSException("Test error message")
        exception.__cause__ = cause

        assert "Test error message" in str(exception)
        assert exception.__cause__ == cause

    def test_aws_exception_inheritance(self):
        """Test AWSException inheritance hierarchy."""
        client_error = AWSClientError("Client error")
        resource_error = AWSResourceNotFoundError("Resource error")
        config_error = AWSConfigurationError("Config error")

        assert isinstance(client_error, AWSException)
        assert isinstance(resource_error, AWSException)
        assert isinstance(config_error, AWSException)
        assert isinstance(client_error, Exception)
        assert isinstance(resource_error, Exception)
        assert isinstance(config_error, Exception)

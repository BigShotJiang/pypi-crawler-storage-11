"""Tests for S3 exceptions."""

from axolotl.aws.s3.exceptions import (
    S3Exception,
    S3ObjectNotFoundError,
    S3BucketNotFoundError,
)


class TestS3Exceptions:
    """Test cases for S3 exception classes."""

    def test_s3_exception_creation(self):
        """Test S3Exception creation."""
        exception = S3Exception("Test error message")

        assert str(exception) == "Test error message"
        assert isinstance(exception, Exception)

    def test_s3_object_not_found_error_creation(self):
        """Test S3ObjectNotFoundError creation."""
        exception = S3ObjectNotFoundError("Object not found")

        assert str(exception) == "Object not found"
        assert isinstance(exception, S3Exception)

    def test_s3_bucket_not_found_error_creation(self):
        """Test S3BucketNotFoundError creation."""
        exception = S3BucketNotFoundError("Bucket not found")

        assert str(exception) == "Bucket not found"
        assert isinstance(exception, S3Exception)

    def test_s3_exception_with_cause(self):
        """Test S3Exception with cause."""
        cause = ValueError("Original error")
        exception = S3Exception("Test error message")
        exception.__cause__ = cause

        assert "Test error message" in str(exception)
        assert exception.__cause__ == cause

    def test_s3_exception_inheritance(self):
        """Test S3Exception inheritance hierarchy."""
        object_error = S3ObjectNotFoundError("Object error")
        bucket_error = S3BucketNotFoundError("Bucket error")

        assert isinstance(object_error, S3Exception)
        assert isinstance(bucket_error, S3Exception)
        assert isinstance(object_error, Exception)
        assert isinstance(bucket_error, Exception)

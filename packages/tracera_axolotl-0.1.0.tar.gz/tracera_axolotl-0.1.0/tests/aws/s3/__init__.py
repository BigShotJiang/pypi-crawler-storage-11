"""Tests for S3 module."""

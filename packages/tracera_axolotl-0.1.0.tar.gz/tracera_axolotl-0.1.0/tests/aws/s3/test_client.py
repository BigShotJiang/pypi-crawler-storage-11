"""Tests for S3 client."""

import pytest
from unittest.mock import patch, MagicMock, mock_open
from botocore.exceptions import ClientError

from axolotl.aws.s3.client import S3Client
from axolotl.aws.s3.exceptions import (
    S3Exception,
    S3ObjectNotFoundError,
    S3BucketNotFoundError,
)


class TestS3Client:
    """Test cases for S3Client class."""

    def test_s3_client_initialization(self, aws_config, mock_s3_client):
        """Test S3Client initialization."""
        client = S3Client(aws_config)

        assert client.config == aws_config
        assert client._client == mock_s3_client

    def test_detect_content_type(self, aws_config):
        """Test content type detection."""
        client = S3Client(aws_config)

        # Test with known file extension
        assert client._detect_content_type("test.txt") == "text/plain"
        assert client._detect_content_type("test.json") == "application/json"
        assert client._detect_content_type("test.pdf") == "application/pdf"

        # Test with unknown file extension
        assert client._detect_content_type("test.unknown") == "application/octet-stream"

    @patch("pathlib.Path.mkdir")
    def test_ensure_directory(self, mock_mkdir, aws_config):
        """Test directory creation."""
        client = S3Client(aws_config)

        client._ensure_directory("/path/to/file.txt")

        mock_mkdir.assert_called_once_with(parents=True, exist_ok=True)

    @patch("builtins.open", new_callable=mock_open, read_data=b"test content")
    def test_upload_file_success(
        self, mock_file, aws_config, mock_s3_client, s3_upload_response
    ):
        """Test successful file upload."""
        mock_s3_client.upload_file.return_value = s3_upload_response

        client = S3Client(aws_config)

        result = client.upload_file("test.txt", "test-bucket", "test-key", "text/plain")

        mock_s3_client.upload_file.assert_called_once()
        assert result == s3_upload_response

    @patch("builtins.open", new_callable=mock_open, read_data=b"test content")
    def test_upload_file_auto_detect_content_type(
        self, mock_file, aws_config, mock_s3_client
    ):
        """Test file upload with auto-detected content type."""
        mock_s3_client.upload_file.return_value = {}

        client = S3Client(aws_config)

        client.upload_file("test.txt", "test-bucket", "test-key")

        # Check that upload_file was called with detected content type
        call_args = mock_s3_client.upload_file.call_args
        assert call_args[1]["ExtraArgs"]["ContentType"] == "text/plain"

    def test_upload_file_bucket_not_found(
        self, aws_config, mock_s3_client, s3_client_error
    ):
        """Test file upload with bucket not found error."""
        mock_s3_client.upload_file.side_effect = s3_client_error

        client = S3Client(aws_config)

        with pytest.raises(
            S3BucketNotFoundError, match="Bucket 'test-bucket' not found"
        ):
            client.upload_file("test.txt", "test-bucket", "test-key")

    def test_upload_file_generic_error(self, aws_config, mock_s3_client):
        """Test file upload with generic error."""
        mock_s3_client.upload_file.side_effect = ClientError(
            error_response={
                "Error": {"Code": "AccessDenied", "Message": "Access denied"}
            },
            operation_name="UploadFile",
        )

        client = S3Client(aws_config)

        with pytest.raises(S3Exception, match="Failed to upload file"):
            client.upload_file("test.txt", "test-bucket", "test-key")

    @patch("builtins.open", new_callable=mock_open)
    def test_download_file_success(
        self, mock_file, aws_config, mock_s3_client, s3_download_response
    ):
        """Test successful file download."""
        mock_s3_client.download_file.return_value = s3_download_response

        client = S3Client(aws_config)

        result = client.download_file("test-bucket", "test-key", "local-file.txt")

        mock_s3_client.download_file.assert_called_once_with(
            "test-bucket", "test-key", "local-file.txt", ExtraArgs={}
        )
        assert result == s3_download_response

    def test_download_file_bucket_not_found(
        self, aws_config, mock_s3_client, s3_client_error
    ):
        """Test file download with bucket not found error."""
        mock_s3_client.download_file.side_effect = s3_client_error

        client = S3Client(aws_config)

        with pytest.raises(
            S3BucketNotFoundError, match="Bucket 'test-bucket' not found"
        ):
            client.download_file("test-bucket", "test-key", "local-file.txt")

    def test_put_object_success(self, aws_config, mock_s3_client, s3_upload_response):
        """Test successful object upload."""
        mock_s3_client.put_object.return_value = s3_upload_response

        client = S3Client(aws_config)

        result = client.put_object(
            "test-bucket", "test-key", "test content", "text/plain"
        )

        mock_s3_client.put_object.assert_called_once()
        call_args = mock_s3_client.put_object.call_args[1]
        assert call_args["Bucket"] == "test-bucket"
        assert call_args["Key"] == "test-key"
        assert call_args["Body"] == b"test content"
        assert call_args["ContentType"] == "text/plain"
        assert result == s3_upload_response

    def test_put_object_with_string_body(self, aws_config, mock_s3_client):
        """Test object upload with string body."""
        mock_s3_client.put_object.return_value = {}

        client = S3Client(aws_config)

        client.put_object("test-bucket", "test-key", "test content", "text/plain")

        call_args = mock_s3_client.put_object.call_args[1]
        assert call_args["Body"] == b"test content"

    def test_put_object_with_bytes_body(self, aws_config, mock_s3_client):
        """Test object upload with bytes body."""
        mock_s3_client.put_object.return_value = {}

        client = S3Client(aws_config)

        client.put_object("test-bucket", "test-key", b"test content", "text/plain")

        call_args = mock_s3_client.put_object.call_args[1]
        assert call_args["Body"] == b"test content"

    def test_put_object_bucket_not_found(
        self, aws_config, mock_s3_client, s3_client_error
    ):
        """Test object upload with bucket not found error."""
        mock_s3_client.put_object.side_effect = s3_client_error

        client = S3Client(aws_config)

        with pytest.raises(
            S3BucketNotFoundError, match="Bucket 'test-bucket' not found"
        ):
            client.put_object("test-bucket", "test-key", "test content", "text/plain")

    def test_get_object_success(self, aws_config, mock_s3_client):
        """Test successful object retrieval."""
        mock_response = {"Body": MagicMock()}
        mock_response["Body"].read.return_value = b"test content"
        mock_s3_client.get_object.return_value = mock_response

        client = S3Client(aws_config)

        result = client.get_object("test-bucket", "test-key")

        mock_s3_client.get_object.assert_called_once_with(
            Bucket="test-bucket", Key="test-key"
        )
        assert result == b"test content"

    def test_get_object_not_found(self, aws_config, mock_s3_client):
        """Test object retrieval with object not found error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "NoSuchKey", "Message": "Object not found"}
            },
            operation_name="GetObject",
        )
        mock_s3_client.get_object.side_effect = error

        client = S3Client(aws_config)

        with pytest.raises(
            S3ObjectNotFoundError,
            match="Object 'test-key' not found in bucket 'test-bucket'",
        ):
            client.get_object("test-bucket", "test-key")

    def test_list_objects_success(self, aws_config, mock_s3_client, s3_list_response):
        """Test successful object listing."""
        mock_s3_client.list_objects_v2.return_value = s3_list_response

        client = S3Client(aws_config)

        result = client.list_objects("test-bucket", "test-prefix")

        mock_s3_client.list_objects_v2.assert_called_once_with(
            Bucket="test-bucket", Prefix="test-prefix"
        )
        assert result == ["test-file-1.txt", "test-file-2.txt"]

    def test_list_objects_bucket_not_found(
        self, aws_config, mock_s3_client, s3_client_error
    ):
        """Test object listing with bucket not found error."""
        mock_s3_client.list_objects_v2.side_effect = s3_client_error

        client = S3Client(aws_config)

        with pytest.raises(
            S3BucketNotFoundError, match="Bucket 'test-bucket' not found"
        ):
            client.list_objects("test-bucket", "test-prefix")

    def test_object_exists_true(self, aws_config, mock_s3_client):
        """Test object exists when object is found."""
        mock_s3_client.head_object.return_value = {}

        client = S3Client(aws_config)

        result = client.object_exists("test-bucket", "test-key")

        mock_s3_client.head_object.assert_called_once_with(
            Bucket="test-bucket", Key="test-key"
        )
        assert result is True

    def test_object_exists_false(self, aws_config, mock_s3_client):
        """Test object exists when object is not found."""
        mock_s3_client.head_object.side_effect = ClientError(
            error_response={"Error": {"Code": "NoSuchKey", "Message": "Not found"}},
            operation_name="HeadObject",
        )

        client = S3Client(aws_config)

        result = client.object_exists("test-bucket", "test-key")

        assert result is False

    def test_head_object_success(
        self, aws_config, mock_s3_client, s3_download_response
    ):
        """Test successful head object operation."""
        mock_s3_client.head_object.return_value = s3_download_response

        client = S3Client(aws_config)

        result = client.head_object("test-bucket", "test-key")

        mock_s3_client.head_object.assert_called_once_with(
            Bucket="test-bucket", Key="test-key"
        )
        assert result == s3_download_response

    def test_head_object_not_found(self, aws_config, mock_s3_client):
        """Test head object with object not found error."""
        error = ClientError(
            error_response={"Error": {"Code": "NoSuchKey", "Message": "Not found"}},
            operation_name="HeadObject",
        )
        mock_s3_client.head_object.side_effect = error

        client = S3Client(aws_config)

        with pytest.raises(
            S3ObjectNotFoundError,
            match="Object 'test-key' not found in bucket 'test-bucket'",
        ):
            client.head_object("test-bucket", "test-key")

    def test_delete_object_success(
        self, aws_config, mock_s3_client, s3_upload_response
    ):
        """Test successful object deletion."""
        mock_s3_client.delete_object.return_value = s3_upload_response

        client = S3Client(aws_config)

        result = client.delete_object("test-bucket", "test-key")

        mock_s3_client.delete_object.assert_called_once_with(
            Bucket="test-bucket", Key="test-key"
        )
        assert result == s3_upload_response

    def test_delete_object_bucket_not_found(
        self, aws_config, mock_s3_client, s3_client_error
    ):
        """Test object deletion with bucket not found error."""
        mock_s3_client.delete_object.side_effect = s3_client_error

        client = S3Client(aws_config)

        with pytest.raises(
            S3BucketNotFoundError, match="Bucket 'test-bucket' not found"
        ):
            client.delete_object("test-bucket", "test-key")

    def test_copy_object_success(self, aws_config, mock_s3_client, s3_upload_response):
        """Test successful object copy."""
        mock_s3_client.copy_object.return_value = s3_upload_response

        client = S3Client(aws_config)

        result = client.copy_object(
            "source-bucket", "source-key", "dest-bucket", "dest-key"
        )

        mock_s3_client.copy_object.assert_called_once()
        call_args = mock_s3_client.copy_object.call_args[1]
        assert call_args["CopySource"] == {
            "Bucket": "source-bucket",
            "Key": "source-key",
        }
        assert call_args["Bucket"] == "dest-bucket"
        assert call_args["Key"] == "dest-key"
        assert result == s3_upload_response

    def test_copy_object_source_not_found(self, aws_config, mock_s3_client):
        """Test object copy with source object not found error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "NoSuchKey", "Message": "Source not found"}
            },
            operation_name="CopyObject",
        )
        mock_s3_client.copy_object.side_effect = error

        client = S3Client(aws_config)

        with pytest.raises(
            S3ObjectNotFoundError,
            match="Object 'source-key' not found in bucket 'source-bucket'",
        ):
            client.copy_object("source-bucket", "source-key", "dest-bucket", "dest-key")

    def test_upload_file_with_kwargs(self, aws_config, mock_s3_client):
        """Test file upload with additional kwargs."""
        mock_s3_client.upload_file.return_value = {}

        client = S3Client(aws_config)

        with patch("builtins.open", mock_open(read_data=b"test content")):
            client.upload_file(
                "test.txt",
                "test-bucket",
                "test-key",
                "text/plain",
                StorageClass="STANDARD_IA",
                ServerSideEncryption="AES256",
                Metadata={"key": "value"},
            )

        call_args = mock_s3_client.upload_file.call_args
        extra_args = call_args[1]["ExtraArgs"]
        assert extra_args["StorageClass"] == "STANDARD_IA"
        assert extra_args["ServerSideEncryption"] == "AES256"
        assert extra_args["Metadata"] == {"key": "value"}

    def test_put_object_with_kwargs(self, aws_config, mock_s3_client):
        """Test object upload with additional kwargs."""
        mock_s3_client.put_object.return_value = {}

        client = S3Client(aws_config)

        client.put_object(
            "test-bucket",
            "test-key",
            "test content",
            "text/plain",
            StorageClass="STANDARD_IA",
            ServerSideEncryption="AES256",
        )

        call_args = mock_s3_client.put_object.call_args[1]
        assert call_args["StorageClass"] == "STANDARD_IA"
        assert call_args["ServerSideEncryption"] == "AES256"

    def test_list_objects_with_kwargs(
        self, aws_config, mock_s3_client, s3_list_response
    ):
        """Test object listing with additional kwargs."""
        mock_s3_client.list_objects_v2.return_value = s3_list_response

        client = S3Client(aws_config)

        client.list_objects("test-bucket", "test-prefix", MaxKeys=10, Delimiter="/")

        call_args = mock_s3_client.list_objects_v2.call_args[1]
        assert call_args["MaxKeys"] == 10
        assert call_args["Delimiter"] == "/"

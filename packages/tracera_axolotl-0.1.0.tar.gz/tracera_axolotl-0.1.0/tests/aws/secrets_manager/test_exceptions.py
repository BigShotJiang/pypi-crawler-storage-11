"""Tests for Secrets Manager exceptions."""

from axolotl.aws.secrets_manager.exceptions import (
    SecretsManagerException,
    SecretNotFoundError,
    SecretVersionNotFoundError,
)


class TestSecretsManagerExceptions:
    """Test cases for Secrets Manager exception classes."""

    def test_secrets_manager_exception_creation(self):
        """Test SecretsManagerException creation."""
        exception = SecretsManagerException("Test error message")

        assert str(exception) == "Test error message"
        assert isinstance(exception, Exception)

    def test_secret_not_found_error_creation(self):
        """Test SecretNotFoundError creation."""
        exception = SecretNotFoundError("Secret not found")

        assert str(exception) == "Secret not found"
        assert isinstance(exception, SecretsManagerException)

    def test_secret_version_not_found_error_creation(self):
        """Test SecretVersionNotFoundError creation."""
        exception = SecretVersionNotFoundError("Secret version not found")

        assert str(exception) == "Secret version not found"
        assert isinstance(exception, SecretsManagerException)

    def test_secrets_manager_exception_with_cause(self):
        """Test SecretsManagerException with cause."""
        cause = ValueError("Original error")
        exception = SecretsManagerException("Test error message")
        exception.__cause__ = cause

        assert "Test error message" in str(exception)
        assert exception.__cause__ == cause

    def test_secrets_manager_exception_inheritance(self):
        """Test SecretsManagerException inheritance hierarchy."""
        secret_error = SecretNotFoundError("Secret error")
        version_error = SecretVersionNotFoundError("Version error")

        assert isinstance(secret_error, SecretsManagerException)
        assert isinstance(version_error, SecretsManagerException)
        assert isinstance(secret_error, Exception)
        assert isinstance(version_error, Exception)

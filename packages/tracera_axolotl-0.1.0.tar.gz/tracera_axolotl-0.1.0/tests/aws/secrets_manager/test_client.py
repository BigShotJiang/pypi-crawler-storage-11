"""Tests for Secrets Manager client."""

import pytest
from botocore.exceptions import ClientError

from axolotl.aws.secrets_manager.client import SecretsManagerClient
from axolotl.aws.secrets_manager.exceptions import (
    SecretsManagerException,
    SecretNotFoundError,
    SecretVersionNotFoundError,
)


class TestSecretsManagerClient:
    """Test cases for SecretsManagerClient class."""

    def test_secrets_manager_client_initialization(
        self, aws_config, mock_secrets_manager_client
    ):
        """Test SecretsManagerClient initialization."""
        client = SecretsManagerClient(aws_config)

        assert client.config == aws_config
        assert client._client == mock_secrets_manager_client

    def test_get_secret_value_success(
        self, aws_config, mock_secrets_manager_client, secrets_manager_get_response
    ):
        """Test successful secret value retrieval."""
        mock_secrets_manager_client.get_secret_value.return_value = (
            secrets_manager_get_response
        )

        client = SecretsManagerClient(aws_config)

        result = client.get_secret_value("test-secret")

        mock_secrets_manager_client.get_secret_value.assert_called_once_with(
            SecretId="test-secret"
        )
        assert result == secrets_manager_get_response

    def test_get_secret_value_with_version_id(
        self, aws_config, mock_secrets_manager_client, secrets_manager_get_response
    ):
        """Test secret value retrieval with version ID."""
        mock_secrets_manager_client.get_secret_value.return_value = (
            secrets_manager_get_response
        )

        client = SecretsManagerClient(aws_config)

        result = client.get_secret_value("test-secret", version_id="version-123")

        mock_secrets_manager_client.get_secret_value.assert_called_once_with(
            SecretId="test-secret", VersionId="version-123"
        )
        assert result == secrets_manager_get_response

    def test_get_secret_value_with_version_stage(
        self, aws_config, mock_secrets_manager_client, secrets_manager_get_response
    ):
        """Test secret value retrieval with version stage."""
        mock_secrets_manager_client.get_secret_value.return_value = (
            secrets_manager_get_response
        )

        client = SecretsManagerClient(aws_config)

        result = client.get_secret_value("test-secret", version_stage="AWSCURRENT")

        mock_secrets_manager_client.get_secret_value.assert_called_once_with(
            SecretId="test-secret", VersionStage="AWSCURRENT"
        )
        assert result == secrets_manager_get_response

    def test_get_secret_value_not_found(
        self, aws_config, mock_secrets_manager_client, secrets_manager_error
    ):
        """Test secret value retrieval with secret not found error."""
        mock_secrets_manager_client.get_secret_value.side_effect = secrets_manager_error

        client = SecretsManagerClient(aws_config)

        with pytest.raises(SecretNotFoundError, match="Secret 'test-secret' not found"):
            client.get_secret_value("test-secret")

    def test_get_secret_value_version_not_found(
        self, aws_config, mock_secrets_manager_client
    ):
        """Test secret value retrieval with version not found error."""
        error = ClientError(
            error_response={
                "Error": {
                    "Code": "InvalidRequestException",
                    "Message": "Version not found",
                }
            },
            operation_name="GetSecretValue",
        )
        mock_secrets_manager_client.get_secret_value.side_effect = error

        client = SecretsManagerClient(aws_config)

        with pytest.raises(
            SecretVersionNotFoundError,
            match="Secret version not found for 'test-secret'",
        ):
            client.get_secret_value("test-secret")

    def test_get_secret_value_generic_error(
        self, aws_config, mock_secrets_manager_client
    ):
        """Test secret value retrieval with generic error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "AccessDenied", "Message": "Access denied"}
            },
            operation_name="GetSecretValue",
        )
        mock_secrets_manager_client.get_secret_value.side_effect = error

        client = SecretsManagerClient(aws_config)

        with pytest.raises(SecretsManagerException, match="Failed to get secret"):
            client.get_secret_value("test-secret")

    def test_get_secret_string(
        self, aws_config, mock_secrets_manager_client, secrets_manager_get_response
    ):
        """Test secret string retrieval."""
        mock_secrets_manager_client.get_secret_value.return_value = (
            secrets_manager_get_response
        )

        client = SecretsManagerClient(aws_config)

        result = client.get_secret_string("test-secret")

        assert result == "test-secret-value"

    def test_get_secret_json(self, aws_config, mock_secrets_manager_client):
        """Test secret JSON retrieval."""
        json_response = {
            "SecretString": '{"username": "admin", "password": "secret123"}',
            "ARN": "arn:aws:secretsmanager:us-west-2:123456789012:secret:test-secret",
        }
        mock_secrets_manager_client.get_secret_value.return_value = json_response

        client = SecretsManagerClient(aws_config)

        result = client.get_secret_json("test-secret")

        assert result == {"username": "admin", "password": "secret123"}

    def test_get_secret_binary(self, aws_config, mock_secrets_manager_client):
        """Test secret binary retrieval."""
        binary_response = {
            "SecretBinary": b"binary-data",
            "ARN": "arn:aws:secretsmanager:us-west-2:123456789012:secret:test-secret",
        }
        mock_secrets_manager_client.get_secret_value.return_value = binary_response

        client = SecretsManagerClient(aws_config)

        result = client.get_secret_binary("test-secret")

        assert result == b"binary-data"

    def test_list_secrets_success(self, aws_config, mock_secrets_manager_client):
        """Test successful secrets listing."""
        list_response = {
            "SecretList": [
                {
                    "ARN": "arn:aws:secretsmanager:us-west-2:123456789012:secret:secret1",
                    "Name": "secret1",
                    "Description": "First secret",
                },
                {
                    "ARN": "arn:aws:secretsmanager:us-west-2:123456789012:secret:secret2",
                    "Name": "secret2",
                    "Description": "Second secret",
                },
            ],
            "NextToken": "next-token",
        }
        mock_secrets_manager_client.list_secrets.return_value = list_response

        client = SecretsManagerClient(aws_config)

        result = client.list_secrets(max_results=10, next_token="token")

        mock_secrets_manager_client.list_secrets.assert_called_once_with(
            MaxResults=10, NextToken="token"
        )
        assert result == list_response

    def test_list_secrets_error(self, aws_config, mock_secrets_manager_client):
        """Test secrets listing with error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "AccessDenied", "Message": "Access denied"}
            },
            operation_name="ListSecrets",
        )
        mock_secrets_manager_client.list_secrets.side_effect = error

        client = SecretsManagerClient(aws_config)

        with pytest.raises(SecretsManagerException, match="Failed to list secrets"):
            client.list_secrets()

    def test_describe_secret_success(self, aws_config, mock_secrets_manager_client):
        """Test successful secret description."""
        describe_response = {
            "ARN": "arn:aws:secretsmanager:us-west-2:123456789012:secret:test-secret",
            "Name": "test-secret",
            "Description": "Test secret",
            "KmsKeyId": "alias/aws/secretsmanager",
            "RotationEnabled": False,
        }
        mock_secrets_manager_client.describe_secret.return_value = describe_response

        client = SecretsManagerClient(aws_config)

        result = client.describe_secret("test-secret")

        mock_secrets_manager_client.describe_secret.assert_called_once_with(
            SecretId="test-secret"
        )
        assert result == describe_response

    def test_describe_secret_error(self, aws_config, mock_secrets_manager_client):
        """Test secret description with error."""
        error = ClientError(
            error_response={
                "Error": {"Code": "AccessDenied", "Message": "Access denied"}
            },
            operation_name="DescribeSecret",
        )
        mock_secrets_manager_client.describe_secret.side_effect = error

        client = SecretsManagerClient(aws_config)

        with pytest.raises(SecretsManagerException, match="Failed to describe secret"):
            client.describe_secret("test-secret")

    def test_secret_exists_true(self, aws_config, mock_secrets_manager_client):
        """Test secret exists when secret is found."""
        mock_secrets_manager_client.describe_secret.return_value = {}

        client = SecretsManagerClient(aws_config)

        result = client.secret_exists("test-secret")

        mock_secrets_manager_client.describe_secret.assert_called_once_with(
            SecretId="test-secret"
        )
        assert result is True

    def test_secret_exists_false(
        self, aws_config, mock_secrets_manager_client, secrets_manager_error
    ):
        """Test secret exists when secret is not found."""
        mock_secrets_manager_client.describe_secret.side_effect = secrets_manager_error

        client = SecretsManagerClient(aws_config)

        result = client.secret_exists("test-secret")

        assert result is False

    def test_get_secret_value_with_kwargs(
        self, aws_config, mock_secrets_manager_client, secrets_manager_get_response
    ):
        """Test secret value retrieval with additional kwargs."""
        mock_secrets_manager_client.get_secret_value.return_value = (
            secrets_manager_get_response
        )

        client = SecretsManagerClient(aws_config)

        result = client.get_secret_value(
            "test-secret",
            VersionId="12345678-1234-1234-1234-123456789012",
            VersionStage="AWSCURRENT",
        )

        mock_secrets_manager_client.get_secret_value.assert_called_once_with(
            SecretId="test-secret",
            VersionId="12345678-1234-1234-1234-123456789012",
            VersionStage="AWSCURRENT",
        )
        assert result == secrets_manager_get_response

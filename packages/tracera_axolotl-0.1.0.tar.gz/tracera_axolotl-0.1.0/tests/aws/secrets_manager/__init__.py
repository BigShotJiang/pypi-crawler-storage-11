"""Tests for Secrets Manager module."""

"""Tests for AWS config module."""

from unittest.mock import patch, MagicMock

from axolotl.aws.config import AWSConfig


class TestAWSConfig:
    """Test cases for AWSConfig class."""

    def test_aws_config_creation_with_all_params(self):
        """Test AWSConfig creation with all parameters."""
        config = AWSConfig(
            region="us-east-1",
            access_key_id="test_key",
            secret_access_key="test_secret",
            session_token="test_token",
            profile_name="test_profile",
        )

        assert config.region == "us-east-1"
        assert config.access_key_id == "test_key"
        assert config.secret_access_key == "test_secret"
        assert config.session_token == "test_token"
        assert config.profile_name == "test_profile"

    def test_aws_config_creation_with_minimal_params(self):
        """Test AWSConfig creation with minimal parameters."""
        config = AWSConfig()

        assert config.region == "eu-central-1"  # Default region
        assert config.access_key_id is None
        assert config.secret_access_key is None
        assert config.session_token is None
        assert config.profile_name is None

    @patch.dict(
        "os.environ",
        {
            "AWS_DEFAULT_REGION": "us-west-2",
            "AWS_ACCESS_KEY_ID": "env_key",
            "AWS_SECRET_ACCESS_KEY": "env_secret",
            "AWS_SESSION_TOKEN": "env_token",
            "AWS_DEFAULT_PROFILE": "env_profile",
        },
    )
    def test_aws_config_environment_variables(self):
        """Test AWSConfig with environment variables."""
        config = AWSConfig()

        assert config.region == "us-west-2"
        assert config.access_key_id == "env_key"
        assert config.secret_access_key == "env_secret"
        assert config.session_token == "env_token"
        assert config.profile_name == "env_profile"

    @patch("boto3.Session")
    def test_create_session(self, mock_session_class):
        """Test create_session method."""
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session

        config = AWSConfig(
            region="us-west-2",
            access_key_id="test_key",
            secret_access_key="test_secret",
        )

        session = config.create_session()

        mock_session_class.assert_called_once_with(
            aws_access_key_id="test_key",
            aws_secret_access_key="test_secret",
        )
        assert session == mock_session

    @patch("boto3.Session")
    def test_create_session_with_profile(self, mock_session_class):
        """Test create_session method with profile."""
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session

        config = AWSConfig(profile_name="test_profile")

        session = config.create_session()

        mock_session_class.assert_called_once_with(profile_name="test_profile")
        assert session == mock_session

    @patch("boto3.Session")
    def test_create_client(self, mock_session_class):
        """Test create_client method."""
        mock_session = MagicMock()
        mock_client = MagicMock()
        mock_session.client.return_value = mock_client
        mock_session_class.return_value = mock_session

        config = AWSConfig(region="us-west-2")

        client = config.create_client("s3")

        mock_session_class.assert_called_once()
        mock_session.client.assert_called_once_with("s3", region_name="us-west-2")
        assert client == mock_client

    @patch("boto3.Session")
    def test_create_client_with_session_token(self, mock_session_class):
        """Test create_client method with session token."""
        mock_session = MagicMock()
        mock_client = MagicMock()
        mock_session.client.return_value = mock_client
        mock_session_class.return_value = mock_session

        config = AWSConfig(
            region="us-west-2",
            access_key_id="test_key",
            secret_access_key="test_secret",
            session_token="test_token",
        )

        client = config.create_client("secretsmanager")

        mock_session_class.assert_called_once_with(
            aws_access_key_id="test_key",
            aws_secret_access_key="test_secret",
            aws_session_token="test_token",
        )
        mock_session.client.assert_called_once_with(
            "secretsmanager", region_name="us-west-2"
        )
        assert client == mock_client

    def test_aws_config_equality(self):
        """Test AWSConfig equality comparison."""
        config1 = AWSConfig(region="us-west-2", access_key_id="key1")
        config2 = AWSConfig(region="us-west-2", access_key_id="key1")
        config3 = AWSConfig(region="us-east-1", access_key_id="key1")

        assert config1 == config2
        assert config1 != config3

    def test_aws_config_repr(self):
        """Test AWSConfig string representation."""
        config = AWSConfig(region="us-west-2", access_key_id="test_key")
        repr_str = repr(config)

        assert "AWSConfig" in repr_str
        assert "us-west-2" in repr_str
        assert "test_key" in repr_str

"""Tests for AWS module."""

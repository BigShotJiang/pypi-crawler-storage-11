"""Pytest configuration and shared fixtures."""

import os
from collections.abc import Generator
from unittest.mock import MagicMock, patch

import pytest

from axolotl.embeddings.domain.config import BedrockConfig


@pytest.fixture
def clean_environment() -> Generator[None, None, None]:
    """Fixture to ensure clean environment variables for tests."""
    # AWS environment variables that might affect tests
    aws_env_vars = [
        "AWS_REGION",
        "AWS_DEFAULT_REGION",
        "AWS_ACCESS_KEY_ID",
        "AWS_SECRET_ACCESS_KEY",
        "AWS_SESSION_TOKEN",
        "AWS_PROFILE",
    ]

    # Store original values
    original_values = {}
    for var in aws_env_vars:
        if var in os.environ:
            original_values[var] = os.environ[var]
            del os.environ[var]

    yield

    # Restore original values
    for var, value in original_values.items():
        os.environ[var] = value


@pytest.fixture
def mock_bedrock_embedding() -> Generator[MagicMock, None, None]:
    """Fixture providing a mocked BedrockEmbedding."""
    with patch(
        "axolotl.embeddings.adapters.llamaindex.bedrock.BedrockEmbedding"
    ) as mock:
        # Setup default successful behavior
        mock_instance = mock.return_value
        mock_instance.get_text_embedding.return_value = [1.0, 2.0, 3.0]
        mock_instance.get_text_embedding_batch.return_value = [
            [1.0, 2.0, 3.0],
            [4.0, 5.0, 6.0],
        ]
        mock.list_supported_models.return_value = [
            "amazon.titan-embed-text-v1",
            "amazon.titan-embed-text-v2:0",
            "cohere.embed-english-v3",
        ]
        yield mock


@pytest.fixture
def sample_bedrock_config() -> BedrockConfig:
    """Fixture providing a sample BedrockConfig."""

    return BedrockConfig(model_name="amazon.titan-embed-text-v1", region="us-east-1")

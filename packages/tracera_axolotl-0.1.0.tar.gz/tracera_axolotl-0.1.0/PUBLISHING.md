# Publishing to Organization PyPI Index

This guide explains how to build and publish the `tracera-axolotl` package to an organization's PyPI index.

## Prerequisites

1. **Access to Organization PyPI**: Ensure you have credentials (username/token) for your organization's PyPI index
2. **Repository URL**: Know the URL of your organization's PyPI repository
   - Example: `https://pypi.example.com/simple/` or `https://pypi.example.com`
   - GitHub Packages: `https://pypi.github.com/simple/ORG-NAME/`
   - Azure Artifacts: `https://pkgs.dev.azure.com/ORG/PROJECT/_packaging/REPO/pypi/simple/`

## Method 1: Using `.pypirc` Configuration File (Recommended)

Create a `.pypirc` file in your home directory (`~/.pypirc`):

```ini
[distutils]
index-servers =
    org-pypi

[org-pypi]
repository = https://your-org-pypi.com/simple/
username = __token__
password = pypi-your-token-here
```

Or for a custom server:

```ini
[distutils]
index-servers =
    org-pypi

[org-pypi]
repository = https://pypi.example.com/
username = your-username
password = your-password
```

**Security Note**: Consider using environment variables for sensitive values:

```ini
[org-pypi]
repository = https://pypi.example.com/
username = __token__
password = ${PYPIPASSWORD}
```

Then set the environment variable:
```bash
export PYPIPASSWORD="pypi-your-token-here"
```

## Method 2: Using Environment Variables

You can configure publishing via environment variables:

```bash
# Repository URL
export TWINE_REPOSITORY_URL="https://your-org-pypi.com/simple/"

# Credentials
export TWINE_USERNAME="__token__"
export TWINE_PASSWORD="pypi-your-token-here"

# Or for username/password auth
export TWINE_USERNAME="your-username"
export TWINE_PASSWORD="your-password"
```

## Method 3: Using pip Configuration

Create or edit `~/.pip/pip.conf` (Linux/Mac) or `%APPDATA%\pip\pip.ini` (Windows):

```ini
[global]
extra-index-url = https://your-org-pypi.com/simple/
trusted-host = your-org-pypi.com

# Optional: For publishing
[distutils]
index-servers = org-pypi

[org-pypi]
repository = https://your-org-pypi.com/simple/
username = __token__
password = pypi-your-token-here
```

## Building the Package

### Using `uv` (Recommended)

```bash
# Build the package
uv build

# This creates:
# - dist/tracera_axolotl-0.1.0-py3-none-any.whl
# - dist/tracera_axolotl-0.1.0.tar.gz
```

### Using `build` (Standard)

```bash
# Install build tool
uv pip install build

# Build the package
python -m build

# Outputs to dist/ directory
```

## Publishing the Package

### Using `uv publish` (If Available)

```bash
# If uv publish is available in your version
uv publish --repository-url https://your-org-pypi.com/simple/ \
  --username __token__ \
  --password pypi-your-token-here
```

### Using `twine` (Recommended for Custom Repositories)

1. **Install twine**:
   ```bash
   uv pip install twine
   ```

2. **Publish to organization PyPI**:
   ```bash
   # Using .pypirc configuration
   twine upload --repository org-pypi dist/*

   # Or specify directly
   twine upload --repository-url https://your-org-pypi.com/simple/ \
     --username __token__ \
     --password pypi-your-token-here \
     dist/*
   ```

3. **Verify upload**:
   ```bash
   twine check dist/*
   ```

### Using `pip` (For Installation Index Only)

For installing from the organization index (not publishing):

```bash
pip install --index-url https://your-org-pypi.com/simple/ tracera-axolotl
```

Or add to `pyproject.toml` dependencies:

```toml
[tool.uv.sources]
tracera-axolotl = { index = "org-pypi" }
```

## Complete Example Workflow

```bash
# 1. Set up credentials (choose one method above)
export TWINE_REPOSITORY_URL="https://pypi.example.com/simple/"
export TWINE_USERNAME="__token__"
export TWINE_PASSWORD="pypi-your-token-here"

# 2. Build the package
uv build

# 3. Verify the build
twine check dist/*

# 4. Publish
twine upload dist/*

# 5. Verify installation
pip install --index-url https://pypi.example.com/simple/ tracera-axolotl
```

## GitHub Actions / CI/CD

For automated publishing in CI/CD:

```yaml
- name: Publish to Organization PyPI
  env:
    TWINE_REPOSITORY_URL: ${{ secrets.ORG_PYPI_URL }}
    TWINE_USERNAME: __token__
    TWINE_PASSWORD: ${{ secrets.ORG_PYPI_TOKEN }}
  run: |
    uv build
    twine upload dist/*
```

## Troubleshooting

### SSL Certificate Issues

If you encounter SSL certificate errors:

```bash
# Disable SSL verification (not recommended for production)
twine upload --repository-url https://your-org-pypi.com/simple/ \
  --skip-existing \
  --cert /path/to/cert.pem \
  dist/*
```

### Authentication Errors

- Ensure your token has the correct permissions
- Check that the repository URL is correct (include trailing slash for `/simple/` endpoints)
- Verify credentials in `.pypirc` or environment variables

### Package Already Exists

```bash
# Skip existing versions
twine upload --skip-existing dist/*
```

## Version Management

Before publishing, update the version in `pyproject.toml`:

```toml
[project]
version = "0.1.1"  # Increment version
```

Then rebuild and republish.


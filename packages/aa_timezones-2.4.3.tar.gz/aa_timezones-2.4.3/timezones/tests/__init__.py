"""
Initialize our tests
"""

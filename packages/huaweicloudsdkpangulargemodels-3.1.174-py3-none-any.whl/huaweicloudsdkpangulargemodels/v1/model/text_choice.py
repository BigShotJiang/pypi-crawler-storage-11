# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class TextChoice:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'index': 'int',
        'text': 'str'
    }

    attribute_map = {
        'index': 'index',
        'text': 'text'
    }

    def __init__(self, index=None, text=None):
        r"""TextChoice

        The model defined in huaweicloud sdk

        :param index: 回复的索引
        :type index: int
        :param text: 模型响应
        :type text: str
        """
        
        

        self._index = None
        self._text = None
        self.discriminator = None

        self.index = index
        self.text = text

    @property
    def index(self):
        r"""Gets the index of this TextChoice.

        回复的索引

        :return: The index of this TextChoice.
        :rtype: int
        """
        return self._index

    @index.setter
    def index(self, index):
        r"""Sets the index of this TextChoice.

        回复的索引

        :param index: The index of this TextChoice.
        :type index: int
        """
        self._index = index

    @property
    def text(self):
        r"""Gets the text of this TextChoice.

        模型响应

        :return: The text of this TextChoice.
        :rtype: str
        """
        return self._text

    @text.setter
    def text(self, text):
        r"""Sets the text of this TextChoice.

        模型响应

        :param text: The text of this TextChoice.
        :type text: str
        """
        self._text = text

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, TextChoice):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

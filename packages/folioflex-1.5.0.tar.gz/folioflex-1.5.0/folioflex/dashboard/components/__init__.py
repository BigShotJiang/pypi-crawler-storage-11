"""Dashboard components."""

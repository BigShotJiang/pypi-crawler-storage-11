class NoDataClass:
    pass

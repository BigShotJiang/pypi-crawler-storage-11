from .main import clipitTab

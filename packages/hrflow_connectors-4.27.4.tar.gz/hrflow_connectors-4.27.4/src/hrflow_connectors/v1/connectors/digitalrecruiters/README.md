# 📖 Summary

- [📖 Summary](#-summary)
- [💼 About Digitalrecruiters](#-about-digitalrecruiters)
  - [😍 Why is it a big deal for Digitalrecruiters customers & partners?](#-why-is-it-a-big-deal-for-digitalrecruiters-customers--partners)
- [🔧 How does it work?](#-how-does-it-work)
  - [📊 Data integration capabilities:](#-data-integration-capabilities)
- [🔌 Connector Actions](#-connector-actions)
- [💍 Quick Start Examples](#-quick-start-examples)
- [🔗 Useful Links](#-useful-links)
- [👏 Special Thanks](#-special-thanks)

# 💼 About Digitalrecruiters

> Digital Recruiters: Tech-driven hiring platform with job posting, automation, and analytics. Simplify recruitment, reduce time-to-hire, and elevate candidate experience. Streamline the hiring process for businesses with advanced features and integration capabilities.

## 😍 Why is it a big deal for Digitalrecruiters customers & partners?

This new connector will enable:

- ⚡ A Fastlane Talent & Workforce data integration for Digitalrecruiters customers & partners
- 🤖 Cutting-edge AI-powered Talent Experiences & Recruiter Experiences for Digitalrecruiters customers

# 🔧 How does it work?

## 📊 Data integration capabilities

- ⬅️ Send Profiles data from Digitalrecruiters to a Destination of your choice.
- ➡️ Send Profiles data from a Source of your choice to Digitalrecruiters.
- ⬅️ Send Jobs data from Digitalrecruiters to a Destination of your choice.

# 🔌 Connector Actions
<p align="center">

| Action | Description |
| ------- | ----------- |
| [**Pull job list**](docs/pull_job_list.md) | Retrieves all jobs from Digital Recruiters and sends them to an Hrflow.ai Board. |
| [**Pull profile list**](docs/pull_profile_list.md) | Retrieves all profiles from Digital Recruiters and sends them to an Hrflow.ai Source. |
| [**Push profile**](docs/push_profile.md) | Pushes a profile from Hrflow.ai to Digital Recruiters. |


</p>

<p align="center">
<image src=https://github.com/Riminder/hrflow-connectors/assets/135601200/2c4a0f4e-d55d-408d-8f0e-b3b5c4ac15e7 width=90% height=100% >
</p>

# 💍 Quick Start Examples

To make sure you can successfully run the latest versions of the example scripts, you have to **install the package from PyPi**.

To browse the examples of actions corresponding to released versions of 🤗 this connector, you just need to import the module like this :

<p align="center">
<image src=https://github.com/Riminder/hrflow-connectors/assets/135601200/089bc6d4-f7bb-4095-8b26-dda7b0de2538 width=90% height=100% >
</p>
  
Once the connector module is imported, you can leverage all the different actions that it offers.

For more code details checkout connector code.

# 🔗 Useful Links

- 📄Visit [Digitalrecruiters](https://www.digitalrecruiters.com/) to learn more.
- 💻 [Connector code](https://github.com/Riminder/hrflow-connectors/tree/master/src/hrflow_connectors/connectors/digitalrecruiters) on our Github.

# 👏 Special Thanks

- 💻 HrFlow.ai : Abdellahi Mezid - Software Engineer

"""
MinifyModule - Python Module Minification Tool
A comprehensive tool for reducing Python file sizes by removing unnecessary elements
while maintaining functionality.
"""

import ast
import tokenize
from io import StringIO
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import time
from typing import Dict, List, Set, Tuple, Optional, Union
from dataclasses import dataclass
from functools import lru_cache
import re

from .importer import Modulex
from .path.filetools import read, write


@dataclass
class MinificationStats:
    """
    Statistics for minification operations.
    
    Attributes:
        original_size (int): Total size of files before minification (bytes)
        minified_size (int): Total size of files after minification (bytes)
        files_processed (int): Number of files processed
        processing_time (float): Time taken for minification (seconds)
        compression_ratio (float): Percentage size reduction
        removed_lines (int): Number of empty lines removed
        removed_spaces (int): Number of extra spaces removed
    """
    original_size: int = 0
    minified_size: int = 0
    files_processed: int = 0
    processing_time: float = 0.0
    compression_ratio: float = 0.0
    removed_lines: int = 0
    removed_spaces: int = 0


class MinifyModule:
    """
     module minification with multiple optimization techniques
    and parallel processing for maximum performance.
    
    Features:
        - Remove comments and docstrings
        - Remove empty lines and extra spaces
        - Optimize import statements
        - Parallel file processing
        - Caching system for performance
        - Backup and restore functionality
    
    Args:
        ModuleName (str): Name of the module to minify
        workers (int, optional): Number of worker threads for parallel processing
    
    Raises:
        TypeError: If ModuleName is not a string
    
    Example:
        >>> minifier = MinifyModule('requests')
        >>> stats = minifier.minify_entire_module()
        >>> print(f"Reduced size by {stats.compression_ratio:.1f}%")
    """
    
    def __init__(self, ModuleName: str, workers: int = None):
        # Validate input type
        if not isinstance(ModuleName, str):
            raise TypeError(f"Expected 'ModuleName' to be str, got {type(ModuleName).__name__}")
        
        self.name = ModuleName
        self.modx = Modulex(self.name)
        self.structure = self.modx.structure()
        
        # Set number of workers for parallel processing
        self.workers = workers or min(32, (os.cpu_count() or 1) + 4)
        
        # Create cache directory
        self.cache_dir = Path(".minify_cache")
        self.cache_dir.mkdir(exist_ok=True)
        
        # Default optimization settings
        self.optimizations = {
            'remove_comments': True,      # Remove single-line and multi-line comments
            'remove_docstrings': True,    # Remove function/class docstrings
            'remove_empty_lines': True,   # Remove blank lines
            'remove_extra_spaces': True,  # Remove unnecessary whitespace
            'shorten_variable_names': False,  # Dangerous - can break code
            'convert_tabs': True,         # Convert spaces to tabs
            'optimize_imports': True,     # Remove duplicate imports
            'remove_unused_imports': False,   # Requires AST analysis
        }

    def _get_file_hash(self, file_path: str) -> str:
        """
        Generate MD5 hash of file content for caching.
        
        Args:
            file_path (str): Path to the file
            
        Returns:
            str: MD5 hash of file content
        """
        content = read(file_path, 'rb')
        return hashlib.md5(content).hexdigest()

    def _load_from_cache(self, file_path: str, operation: str) -> Optional[str]:
        """
        Load minified content from cache if available and valid.
        
        Args:
            file_path (str): Path to original file
            operation (str): Cache operation identifier
            
        Returns:
            Optional[str]: Cached content if valid, None otherwise
        """
        file_hash = self._get_file_hash(file_path)
        cache_file = self.cache_dir / f"{operation}_{file_hash}.cache"
        
        if cache_file.exists():
            cached_content = read(str(cache_file), 'r')
            cache_time = cache_file.stat().st_mtime
            file_time = Path(file_path).stat().st_mtime
            
            # Return cached content only if it's newer than the file
            if cache_time > file_time:
                return cached_content
        return None

    def _save_to_cache(self, file_path: str, operation: str, content: str):
        """
        Save minified content to cache for future use.
        
        Args:
            file_path (str): Path to original file
            operation (str): Cache operation identifier
            content (str): Minified content to cache
        """
        file_hash = self._get_file_hash(file_path)
        cache_file = self.cache_dir / f"{operation}_{file_hash}.cache"
        write(str(cache_file), content)

    def _remove_comments(self, content: str) -> str:
        """
        Remove all comments from Python code.
        
        Args:
            content (str): Original Python code
            
        Returns:
            str: Code with comments removed
            
        Example:
            >>> self._remove_comments("# This is a comment\\nprint('hello')")
            "print('hello')"
        """
        # Remove single-line comments
        content = re.sub(r'#.*$', '', content, flags=re.MULTILINE)
        
        # Remove multi-line comments (triple quotes)
        content = re.sub(r'\'\'\'.*?\'\'\'|""".*?"""', '', content, flags=re.DOTALL)
        
        return content

    def _remove_docstrings(self, content: str) -> str:
        """
        Remove docstrings from functions, classes, and modules.
        
        Uses AST parsing for accuracy, falls back to regex if AST fails.
        
        Args:
            content (str): Original Python code
            
        Returns:
            str: Code with docstrings removed
        """
        try:
            # Parse code into AST and remove docstrings
            tree = ast.parse(content)
            
            for node in ast.walk(tree):
                # Check for function, class, or module definitions
                if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.Module)):
                    # Remove first expression if it's a string (docstring)
                    if (node.body and isinstance(node.body[0], ast.Expr) and
                        isinstance(node.body[0].value, ast.Str)):
                        node.body = node.body[1:]
            
            # Convert AST back to code
            return ast.unparse(tree)
        except SyntaxError:
            # Fallback to regex if AST parsing fails
            return re.sub(r'^\s*(\'\'\'.*?\'\'\'|""".*?""")', '', content, 
                         flags=re.DOTALL | re.MULTILINE)

    def _optimize_imports(self, content: str) -> str:
        """
        Optimize import statements by removing duplicates and organizing.
        
        Args:
            content (str): Original Python code
            
        Returns:
            str: Code with optimized imports
        """
        lines = content.split('\n')
        import_lines = []
        other_lines = []
        in_import_section = True
        
        # Separate import lines from other code
        for line in lines:
            stripped = line.strip()
            if in_import_section and (stripped.startswith(('import ', 'from ')) or not stripped):
                import_lines.append(line)
            else:
                in_import_section = False
                other_lines.append(line)
        
        # Remove duplicate imports while preserving order
        seen_imports = set()
        unique_imports = []
        
        for line in import_lines:
            if line.strip() and line not in seen_imports:
                seen_imports.add(line)
                unique_imports.append(line)
        
        # Combine unique imports with remaining code
        return '\n'.join(unique_imports + other_lines)

    def _remove_extra_spaces(self, content: str) -> str:
        """
        Remove unnecessary whitespace from code.
        
        Args:
            content (str): Original Python code
            
        Returns:
            str: Code with extra spaces removed
        """
        # Remove spaces around operators
        content = re.sub(r'\s*([=+\-*/%&|^<>!]+)\s*', r'\1', content)
        
        # Remove spaces inside parentheses and brackets
        content = re.sub(r'\(\s+', '(', content)
        content = re.sub(r'\s+\)', ')', content)
        content = re.sub(r'\[\s+', '[', content)
        content = re.sub(r'\s+\]', ']', content)
        content = re.sub(r'{\s+', '{', content)
        content = re.sub(r'\s+}', '}', content)
        
        # Remove multiple consecutive spaces
        content = re.sub(r' +', ' ', content)
        
        # Remove trailing spaces at end of lines
        content = re.sub(r'[ \t]+$', '', content, flags=re.MULTILINE)
        
        return content

    def _minify_file(self, file_path: str, optimizations: dict = None) -> Tuple[str, int, int]:
        """
        Minify a single Python file with specified optimizations.
        
        Args:
            file_path (str): Path to the file to minify
            optimizations (dict, optional): Optimization settings to apply
            
        Returns:
            Tuple[str, int, int]: 
                - Minified content
                - Number of lines removed
                - Number of spaces removed
        """
        if optimizations is None:
            optimizations = self.optimizations
        
        # Generate cache key based on optimization settings
        cache_key = "minify_" + hashlib.md5(str(optimizations).encode()).hexdigest()
        
        # Check cache first
        cached = self._load_from_cache(file_path, cache_key)
        if cached:
            return cached, 0, 0
        
        # Read original file
        original_content = read(file_path)
        original_size = len(original_content)
        original_lines = original_content.count('\n')
        
        content = original_content
        removed_lines = 0
        removed_spaces = 0
        
        # Apply optimizations in sequence
        if optimizations['remove_comments']:
            before = len(content)
            content = self._remove_comments(content)
            removed_spaces += before - len(content)
        
        if optimizations['remove_docstrings']:
            before = len(content)
            content = self._remove_docstrings(content)
            removed_spaces += before - len(content)
        
        if optimizations['optimize_imports']:
            content = self._optimize_imports(content)
        
        if optimizations['remove_extra_spaces']:
            before = len(content)
            content = self._remove_extra_spaces(content)
            removed_spaces += before - len(content)
        
        if optimizations['remove_empty_lines']:
            lines = content.split('\n')
            non_empty_lines = [line for line in lines if line.strip()]
            removed_lines = len(lines) - len(non_empty_lines)
            content = '\n'.join(non_empty_lines)
        
        if optimizations['convert_tabs']:
            content = content.replace('    ', '\t')
        
        # Save to cache for future use
        self._save_to_cache(file_path, cache_key, content)
        
        return content, removed_lines, removed_spaces

    def minify_entire_module(self, output_dir: str = None, 
                           optimizations: dict = None,
                           backup: bool = True) -> MinificationStats:
        """
        Minify all Python files in the module with parallel processing.
        
        Args:
            output_dir (str, optional): Directory to save minified files.
                                      If None, modifies files in-place.
            optimizations (dict, optional): Custom optimization settings.
            backup (bool): Create backup of original files before minification.
            
        Returns:
            MinificationStats: Detailed statistics about the minification process.
            
        Example:
            >>> minifier = MinifyModule('mymodule')
            >>> stats = minifier.minify_entire_module(output_dir='minified/')
            >>> print(f"Processed {stats.files_processed} files")
            >>> print(f"Reduced size by {stats.compression_ratio:.1f}%")
        """
        start_time = time.time()
        
        # Get all Python files in module
        files = self.structure.files(suffix='*.py')
        stats = MinificationStats()
        stats.files_processed = len(files)
        
        # Create backup if modifying in-place
        if backup and output_dir is None:
            self._create_backup()
        
        # Process files in parallel using thread pool
        with ThreadPoolExecutor(max_workers=self.workers) as executor:
            # Submit all files for processing
            future_to_file = {
                executor.submit(self._minify_file, file, optimizations): file 
                for file in files
            }
            
            # Process completed tasks
            for future in as_completed(future_to_file):
                file = future_to_file[future]
                try:
                    minified_content, removed_lines, removed_spaces = future.result()
                    
                    # Calculate file sizes
                    original_size = len(read(file))
                    minified_size = len(minified_content)
                    
                    # Update statistics
                    stats.original_size += original_size
                    stats.minified_size += minified_size
                    stats.removed_lines += removed_lines
                    stats.removed_spaces += removed_spaces
                    
                    # Save minified file
                    if output_dir:
                        output_path = Path(output_dir) / Path(file).name
                        write(str(output_path), minified_content)
                    else:
                        # In-place modification
                        write(file, minified_content)
                        
                except Exception as e:
                    # Continue processing other files if one fails
                    continue
        
        # Calculate final statistics
        stats.processing_time = time.time() - start_time
        if stats.original_size > 0:
            stats.compression_ratio = (stats.original_size - stats.minified_size) / stats.original_size * 100
        
        return stats

    def _create_backup(self):
        """
        Create a backup of the original module before minification.
        
        The backup is stored in a timestamped directory.
        """
        timestamp = int(time.time())
        backup_dir = Path(f"backup_{self.name}_{timestamp}")
        self.modx.copy(backup_dir, errors=False)

    def restore_backup(self, backup_dir: str):
        """
        Restore module files from a backup directory.
        
        Args:
            backup_dir (str): Path to the backup directory
            
        Raises:
            ValueError: If backup directory doesn't exist
            
        Example:
            >>> minifier.restore_backup('backup_mymodule_1234567890')
        """
        backup_path = Path(backup_dir)
        if not backup_path.exists():
            raise ValueError(f"Backup directory {backup_dir} not found")
        
        # Copy backup files back to original locations
        for file in backup_path.rglob("*.py"):
            relative_path = file.relative_to(backup_path)
            original_path = self.modx.path() / relative_path
            write(str(original_path), read(str(file)))

    def compare_files(self, original_dir: str, minified_dir: str) -> Dict[str, Dict]:
        """
        Compare original and minified files to show size reductions.
        
        Args:
            original_dir (str): Directory containing original files
            minified_dir (str): Directory containing minified files
            
        Returns:
            Dict[str, Dict]: Comparison data for each file
            
        Example:
            >>> comparison = minifier.compare_files('original/', 'minified/')
            >>> for file, data in comparison.items():
            ...     print(f"{file}: {data['reduction_percent']:.1f}% reduction")
        """
        comparison = {}
        original_path = Path(original_dir)
        minified_path = Path(minified_dir)
        
        # Compare each Python file
        for file in original_path.rglob("*.py"):
            if file.is_file():
                rel_path = file.relative_to(original_path)
                minified_file = minified_path / rel_path
                
                if minified_file.exists():
                    orig_content = read(str(file))
                    min_content = read(str(minified_file))
                    
                    comparison[str(rel_path)] = {
                        'original_size': len(orig_content),
                        'minified_size': len(min_content),
                        'reduction': len(orig_content) - len(min_content),
                        'reduction_percent': (len(orig_content) - len(min_content)) / len(orig_content) * 100
                    }
        
        return comparison

    def auto_minify(self, aggression: str = 'medium') -> MinificationStats:
        """
        Minify module using preset optimization levels.
        
        Args:
            aggression (str): Optimization level - 'light', 'medium', or 'aggressive'
            
        Returns:
            MinificationStats: Minification statistics
            
        Example:
            >>> # Light optimization - safe for most projects
            >>> stats = minifier.auto_minify('light')
            >>>
            >>> # Aggressive optimization - maximum size reduction
            >>> stats = minifier.auto_minify('aggressive')
        """
        # Define optimization presets
        presets = {
            'light': {
                'remove_comments': True,
                'remove_docstrings': False,  # Keep docstrings
                'remove_empty_lines': True,
                'remove_extra_spaces': True,
                'convert_tabs': False,
                'optimize_imports': True,
            },
            'medium': {
                'remove_comments': True,
                'remove_docstrings': True,   # Remove docstrings
                'remove_empty_lines': True,
                'remove_extra_spaces': True,
                'convert_tabs': True,
                'optimize_imports': True,
            },
            'aggressive': {
                'remove_comments': True,
                'remove_docstrings': True,
                'remove_empty_lines': True,
                'remove_extra_spaces': True,
                'convert_tabs': True,
                'optimize_imports': True,
                'remove_unused_imports': True,  # More aggressive
            }
        }
        
        # Use medium preset if specified level not found
        optimization_preset = presets.get(aggression, presets['medium'])
        return self.minify_entire_module(optimizations=optimization_preset)

    def analyze_module(self) -> Dict:
        """
        Analyze module to estimate minification potential.
        
        Returns:
            Dict: Analysis results including potential savings
            
        Example:
            >>> analysis = minifier.analyze_module()
            >>> print(f"Potential savings: {analysis['potential_savings']} bytes")
            >>> print(f"Total comments: {analysis['comments_count']}")
        """
        files = self.structure.files(suffix='*.py')
        analysis = {
            'total_files': len(files),
            'total_size': 0,
            'average_file_size': 0,
            'comments_count': 0,
            'empty_lines_count': 0,
            'import_statements': 0,
            'potential_savings': 0
        }
        
        # Analyze each file
        for file in files:
            content = read(file)
            analysis['total_size'] += len(content)
            
            # Count comments
            analysis['comments_count'] += content.count('#')
            analysis['comments_count'] += content.count("'''") + content.count('"""')
            
            # Count empty lines
            analysis['empty_lines_count'] += sum(1 for line in content.split('\n') if not line.strip())
            
            # Count import statements
            analysis['import_statements'] += content.count('import ')
            analysis['import_statements'] += content.count('from ')
        
        # Calculate averages
        if files:
            analysis['average_file_size'] = analysis['total_size'] / len(files)
        
        # Estimate potential savings
        analysis['potential_savings'] = (
            analysis['comments_count'] * 10 +    # Average comment size
            analysis['empty_lines_count'] * 2 +  # Newline characters
            analysis['import_statements'] * 5    # Import optimization
        )
        
        return analysis

    def batch_minify(self, module_names: List[str], **kwargs) -> Dict[str, MinificationStats]:
        """
        Minify multiple modules in a single batch operation.
        
        Args:
            module_names (List[str]): List of module names to minify
            **kwargs: Additional arguments passed to minify_entire_module
            
        Returns:
            Dict[str, MinificationStats]: Minification results for each module
            
        Example:
            >>> modules = ['requests', 'numpy', 'pandas']
            >>> results = minifier.batch_minify(modules)
            >>> for module, stats in results.items():
            ...     if stats:
            ...         print(f"{module}: {stats.compression_ratio:.1f}%")
        """
        results = {}
        
        for module_name in module_names:
            try:
                # Create minifier for each module
                minifier = MinifyModule(module_name)
                stats = minifier.minify_entire_module(**kwargs)
                results[module_name] = stats
            except Exception as e:
                # Store None for failed modules
                results[module_name] = None
        
        return results

"""
__init__.py
"""

from .importer import Modulex as Modulex
from ._builtin import isbuiltin as isbuiltin
from .path.utils import isdunder
from .path.sources import Source as Source
from .path.metafile import (
    getmetafilepkg as getmetafilepkg,
    getsitepath as getsitepath,
    getmetapath as getmetapath,
    getlocation as getlocation,
    getmodules as getmodules,
    getpackages as getpackages,
)
from .metadata.metatext import MetaText as MetaText
from .pkgs import pkgs as pkgs
from .metadata.meta import (
    metafiles as metafiles,
    version as version,
    hasmeta as hasmeta,
    show as show,
)
from .text.tree import *
from .ImporterException import ImporterException as ImporterException
from .pymodex import pmeX as pmeX
from .BackupsModule import ModuleBackup as ModuleBackup
from .zipmodule import ZipModule
from .make import MakeModule
from ._utils._installation import installs as installs
from ._search_pypi import search_package as search_package, search_sync as search_sync, PyPISearch
from .minify import MinifyModule

__version__ = "1.1.19"

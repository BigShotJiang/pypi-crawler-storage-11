"""
MIME type detection functionality for lumelab-jaci.

This extra provides MIME type detection for files using
python-magic or filetype libraries.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional, Dict, Any

# Try to import python-magic first (most accurate)
try:
    import magic
    _PYTHON_MAGIC_AVAILABLE = True
except ImportError:
    _PYTHON_MAGIC_AVAILABLE = False

# Fallback to filetype
try:
    import filetype
    _FILETYPE_AVAILABLE = True
except ImportError:
    _FILETYPE_AVAILABLE = False


class MimeTypeDetector:
    """
    MIME type detector with multiple backend support.
    
    Supports python-magic (libmagic) and filetype as fallbacks.
    """
    
    def __init__(self, backend: Optional[str] = None):
        """
        Initialize MIME type detector.
        
        Args:
            backend: Backend to use ('python-magic', 'filetype', or None for auto)
        """
        self.backend = self._select_backend(backend)
        self.mime_cache: Dict[str, str] = {}
    
    def _select_backend(self, backend: Optional[str]) -> str:
        """Select appropriate MIME detection backend."""
        if backend == "python-magic":
            if not _PYTHON_MAGIC_AVAILABLE:
                raise ImportError("python-magic is not available")
            return "python-magic"
        elif backend == "filetype":
            if not _FILETYPE_AVAILABLE:
                raise ImportError("filetype is not available")
            return "filetype"
        elif backend is None:
            # Auto-select: prefer python-magic, fallback to filetype
            if _PYTHON_MAGIC_AVAILABLE:
                return "python-magic"
            elif _FILETYPE_AVAILABLE:
                return "filetype"
            else:
                raise ImportError("No MIME detection backend available. Install 'python-magic' or 'filetype'.")
        else:
            raise ValueError(f"Unknown backend: {backend}. Use 'python-magic', 'filetype', or None.")
    
    def detect_mime_type(self, path: Path, use_cache: bool = True) -> Optional[str]:
        """
        Detect MIME type for a file.
        
        Args:
            path: Path to file
            use_cache: Whether to use cached results
            
        Returns:
            MIME type string or None if detection failed
        """
        if not path.exists() or not path.is_file():
            return None
        
        # Check cache first
        cache_key = str(path)
        if use_cache and cache_key in self.mime_cache:
            return self.mime_cache[cache_key]
        
        mime_type = None
        
        try:
            if self.backend == "python-magic":
                mime_type = self._detect_with_python_magic(path)
            elif self.backend == "filetype":
                mime_type = self._detect_with_filetype(path)
        except Exception:
            # Silently fall back to None on detection errors
            pass
        
        # Cache the result
        if use_cache and mime_type:
            self.mime_cache[cache_key] = mime_type
        
        return mime_type
    
    def _detect_with_python_magic(self, path: Path) -> Optional[str]:
        """Detect MIME type using python-magic."""
        try:
            # Try mime type detection first
            mime_type = magic.from_file(str(path), mime=True)
            return mime_type
        except Exception:
            # Fallback to file type detection
            try:
                file_type = magic.from_file(str(path))
                # Map common file types to MIME types
                return self._map_file_type_to_mime(file_type)
            except Exception:
                return None
    
    def _detect_with_filetype(self, path: Path) -> Optional[str]:
        """Detect MIME type using filetype."""
        try:
            kind = filetype.guess(str(path))
            if kind:
                return kind.mime
            return None
        except Exception:
            return None
    
    def _map_file_type_to_mime(self, file_type: str) -> str:
        """Map file type description to MIME type."""
        file_type_lower = file_type.lower()
        
        # Common mappings
        if 'text' in file_type_lower:
            return 'text/plain'
        elif 'html' in file_type_lower:
            return 'text/html'
        elif 'json' in file_type_lower:
            return 'application/json'
        elif 'xml' in file_type_lower:
            return 'application/xml'
        elif 'pdf' in file_type_lower:
            return 'application/pdf'
        elif 'zip' in file_type_lower:
            return 'application/zip'
        elif 'jpeg' in file_type_lower or 'jpg' in file_type_lower:
            return 'image/jpeg'
        elif 'png' in file_type_lower:
            return 'image/png'
        elif 'gif' in file_type_lower:
            return 'image/gif'
        elif 'mp3' in file_type_lower:
            return 'audio/mpeg'
        elif 'mp4' in file_type_lower:
            return 'video/mp4'
        elif 'elf' in file_type_lower:
            return 'application/x-executable'
        else:
            return 'application/octet-stream'
    
    def clear_cache(self) -> None:
        """Clear MIME type cache."""
        self.mime_cache.clear()
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            "cache_size": len(self.mime_cache),
            "backend": self.backend,
        }
    
    @property
    def is_available(self) -> bool:
        """Check if any MIME detection backend is available."""
        return _PYTHON_MAGIC_AVAILABLE or _FILETYPE_AVAILABLE


# Extension-based MIME type mapping as fallback
EXTENSION_MIME_MAP = {
    # Text files
    '.txt': 'text/plain',
    '.md': 'text/markdown',
    '.rst': 'text/x-rst',
    '.html': 'text/html',
    '.htm': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.xml': 'application/xml',
    '.yaml': 'application/x-yaml',
    '.yml': 'application/x-yaml',
    '.csv': 'text/csv',
    '.tsv': 'text/tab-separated-values',
    
    # Images
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.bmp': 'image/bmp',
    '.svg': 'image/svg+xml',
    '.webp': 'image/webp',
    '.ico': 'image/x-icon',
    
    # Audio
    '.mp3': 'audio/mpeg',
    '.wav': 'audio/wav',
    '.flac': 'audio/flac',
    '.ogg': 'audio/ogg',
    '.m4a': 'audio/mp4',
    
    # Video
    '.mp4': 'video/mp4',
    '.avi': 'video/x-msvideo',
    '.mov': 'video/quicktime',
    '.wmv': 'video/x-ms-wmv',
    '.flv': 'video/x-flv',
    '.webm': 'video/webm',
    
    # Archives
    '.zip': 'application/zip',
    '.tar': 'application/x-tar',
    '.gz': 'application/gzip',
    '.bz2': 'application/x-bzip2',
    '.7z': 'application/x-7z-compressed',
    '.rar': 'application/x-rar-compressed',
    
    # Documents
    '.pdf': 'application/pdf',
    '.doc': 'application/msword',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.xls': 'application/vnd.ms-excel',
    '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    '.ppt': 'application/vnd.ms-powerpoint',
    '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    
    # Code files
    '.py': 'text/x-python',
    '.java': 'text/x-java-source',
    '.c': 'text/x-c',
    '.cpp': 'text/x-c++',
    '.h': 'text/x-c',
    '.hpp': 'text/x-c++',
    '.rs': 'text/x-rust',
    '.go': 'text/x-go',
    '.js': 'application/javascript',
    '.ts': 'application/typescript',
    '.jsx': 'text/jsx',
    '.tsx': 'text/tsx',
    '.php': 'application/x-httpd-php',
    '.rb': 'text/x-ruby',
    '.sh': 'application/x-sh',
    '.bat': 'application/x-msdos-program',
    '.ps1': 'application/x-powershell',
}


def get_mime_type_by_extension(path: Path) -> Optional[str]:
    """
    Get MIME type based on file extension.
    
    Args:
        path: Path to file
        
    Returns:
        MIME type string or None if unknown extension
    """
    extension = path.suffix.lower()
    return EXTENSION_MIME_MAP.get(extension)


def create_mime_detector(backend: Optional[str] = None) -> MimeTypeDetector:
    """
    Create a MIME type detector with common configurations.
    
    Args:
        backend: Backend to use
        
    Returns:
        Configured MimeTypeDetector instance
    """
    return MimeTypeDetector(backend=backend)


def get_available_backends() -> list[str]:
    """Get list of available MIME detection backends."""
    backends = []
    if _PYTHON_MAGIC_AVAILABLE:
        backends.append("python-magic")
    if _FILETYPE_AVAILABLE:
        backends.append("filetype")
    return backends


def is_mime_type_available() -> bool:
    """Check if any MIME type detection is available."""
    return _PYTHON_MAGIC_AVAILABLE or _FILETYPE_AVAILABLE
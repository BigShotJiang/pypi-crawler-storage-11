"""
Sorting strategy implementations.

This module provides concrete sorting implementations for different criteria
including natural sort for alphanumeric strings.
"""

from __future__ import annotations

import re
from typing import Any, Callable, List

from ..models import Entry


class BaseSorter:
    """Base class for sorting strategies."""
    
    def __init__(self, reverse: bool = False) -> None:
        """
        Initialize sorter.
        
        Args:
            reverse: Whether to sort in descending order
        """
        self.reverse = reverse
    
    def get_key_function(self) -> Callable[[Entry], Any]:
        """Get the key function for sorting."""
        raise NotImplementedError
    
    def sort(self, entries: List[Entry]) -> List[Entry]:
        """Sort a list of entries."""
        key_func = self.get_key_function()
        return sorted(entries, key=key_func, reverse=self.reverse)


class NameSorter(BaseSorter):
    """Sort entries by name (case-insensitive)."""
    
    def get_key_function(self) -> Callable[[Entry], str]:
        """Get key function for name sorting."""
        return lambda entry: entry.name.lower()


class SizeSorter(BaseSorter):
    """Sort entries by size."""
    
    def get_key_function(self) -> Callable[[Entry], int]:
        """Get key function for size sorting."""
        return lambda entry: entry.size


class MtimeSorter(BaseSorter):
    """Sort entries by modification time."""
    
    def get_key_function(self) -> Callable[[Entry], float]:
        """Get key function for modification time sorting."""
        return lambda entry: entry.mtime


class ExtensionSorter(BaseSorter):
    """Sort entries by file extension."""
    
    def get_key_function(self) -> Callable[[Entry], str]:
        """Get key function for extension sorting."""
        return lambda entry: entry.extension or ""


class NaturalSorter(BaseSorter):
    """
    Sort entries using natural sort for alphanumeric strings.
    
    Natural sort treats numeric substrings as numbers rather than
    individual characters, so "file2.txt" comes before "file10.txt".
    """
    
    def __init__(self, field: str = "name", reverse: bool = False) -> None:
        """
        Initialize natural sorter.
        
        Args:
            field: Field to sort by ("name" or "extension")
            reverse: Whether to sort in descending order
        """
        super().__init__(reverse)
        if field not in ("name", "extension"):
            raise ValueError("Natural sort only supports 'name' and 'extension' fields")
        self.field = field
    
    def get_key_function(self) -> Callable[[Entry], List[Any]]:
        """Get key function for natural sorting."""
        def alphanum_key(entry: Entry) -> List[Any]:
            if self.field == "name":
                text = entry.name
            else:  # extension
                text = entry.extension or ""
            
            # Split text into numeric and non-numeric parts
            return [int(part) if part.isdigit() else part.lower() 
                    for part in re.split(r'([0-9]+)', text)]
        
        return alphanum_key


class MultiFieldSorter(BaseSorter):
    """Sort entries by multiple fields with priority."""
    
    def __init__(self, fields: List[tuple[str, bool]]) -> None:
        """
        Initialize multi-field sorter.
        
        Args:
            fields: List of (field_name, reverse) tuples
        """
        self.fields = fields
    
    def get_key_function(self) -> Callable[[Entry], tuple]:
        """Get key function for multi-field sorting."""
        def multi_key(entry: Entry) -> tuple:
            keys = []
            for field, reverse in self.fields:
                if field == "name":
                    key = entry.name.lower()
                elif field == "size":
                    key = entry.size
                elif field == "mtime":
                    key = entry.mtime
                elif field == "ext":
                    key = entry.extension or ""
                else:
                    raise ValueError(f"Unknown sort field: {field}")
                
                # For reverse sorting, we invert the key
                if reverse:
                    if isinstance(key, (int, float)):
                        key = -key
                    else:
                        key = chr(0x10FFFF - ord(key[0])) + key[1:] if key else ""
                
                keys.append(key)
            
            return tuple(keys)
        
        return multi_key
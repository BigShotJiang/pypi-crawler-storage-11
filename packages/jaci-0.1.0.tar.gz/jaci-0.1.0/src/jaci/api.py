"""
Main API functions for lumelab-jaci.

This module provides the public API that users interact with, including
list, search, stat, watch, resolve, and capabilities functions.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Iterable, Optional, Union

if TYPE_CHECKING:
    from .models import Entry, Query, Order, FuzzySpec, WatchEvent
    from .providers.local import LocalProvider
    from .utils.logging import MetricsCollector
    from .cache.ttl import DirectoryCache

# Runtime imports
from .models import Entry, Query, Order, FuzzySpec, WatchEvent
from .providers.local import LocalProvider
from .utils.logging import MetricsCollector
from .cache.ttl import DirectoryCache

# Type aliases
EntryOrScored = Union[Entry, tuple[Entry, float]]
EntryStream = Iterable[EntryOrScored]
EventStream = Iterable[WatchEvent]

# Global provider instance
_provider: Optional[LocalProvider] = None


def _get_provider() -> LocalProvider:
    """Get or create the global provider instance."""
    global _provider
    if _provider is None:
        # Get the global cache instance and pass it to the provider
        cache = get_cache()
        _provider = LocalProvider(cache=cache)
    return _provider


def list(
    directory: Path,
    query: Optional[Query] = None,
    order: Optional[Order] = None,
) -> EntryStream:
    """
    List entries in a directory with optional filtering and sorting.

    Args:
        directory: The directory to list
        query: Filtering criteria (optional)
        order: Sorting specification (optional)

    Yields:
        Entry objects matching the criteria

    Raises:
        PathNotFoundError: If directory doesn't exist
        PermissionDeniedError: If lacking read permissions
    """
    provider = _get_provider()
    yield from provider.iter_entries(directory, query, order)


def search(
    directory: Path,
    query: str,
    fuzzy_spec: Optional[FuzzySpec] = None,
) -> EntryStream:
    """
    Search for entries matching a query with optional fuzzy matching.

    Args:
        directory: The directory to search in
        query: Search query string
        fuzzy_spec: Fuzzy search specification (optional)

    Yields:
        Entry objects or (Entry, score) tuples for fuzzy results

    Raises:
        PathNotFoundError: If directory doesn't exist
        PermissionDeniedError: If lacking read permissions
    """
    # For now, implement basic search without fuzzy matching
    # Fuzzy search will be implemented in the 'fuzzy' extra
    search_query = Query()
    search_query.name_regex = f".*{query}.*"  # Simple regex match

    provider = _get_provider()
    yield from provider.iter_entries(directory, search_query)


def stat(path: Path) -> Entry:
    """
    Get metadata for a single file or directory.

    Args:
        path: The path to get metadata for

    Returns:
        Entry object with full metadata

    Raises:
        PathNotFoundError: If path doesn't exist
        PermissionDeniedError: If lacking read permissions
    """
    provider = _get_provider()
    return provider.stat(path)


def watch(
    directory: Path,
    query: Optional[Query] = None,
    recursive: bool = True,
    debounce_ms: int = 100,
) -> EventStream:
    """
    Watch a directory for file system events.

    Args:
        directory: The directory to watch
        query: Filter events for specific entries (optional)
        recursive: Whether to watch subdirectories
        debounce_ms: Debounce time in milliseconds

    Yields:
        WatchEvent objects as they occur

    Raises:
        UnsupportedOperationError: If watching is not supported
        PermissionDeniedError: If lacking permissions
    """
    provider = _get_provider()
    yield from provider.watch(directory, query, recursive, debounce_ms)


def resolve(
    directory: Path,
    relative_path: str,
    sandbox_root: Optional[Path] = None,
) -> Path:
    """
    Resolve a relative path safely within optional sandbox constraints.

    Args:
        directory: Base directory
        relative_path: Relative path to resolve
        sandbox_root: Optional sandbox root directory

    Returns:
        Resolved absolute path

    Raises:
        SandboxViolationError: If path is outside sandbox
        SymlinkLoopError: If symlink loop is detected
    """
    provider = _get_provider()
    target_path = directory / relative_path
    return provider.resolve_path(target_path, sandbox_root)


def capabilities() -> Dict[str, Any]:
    """
    Get capabilities and features supported by the current provider.

    Returns:
        Dictionary mapping feature names to capability information
        Example: {"watch": True, "fuzzy": False, "mime": True, "provider": "local"}
    """
    provider = _get_provider()
    provider_caps = provider.capabilities()

    # Add provider type
    return {
        "provider": provider_caps.get("provider", "local"),
        **provider_caps,
    }


def probe(directory: Path) -> Dict[str, Any]:
    """
    Probe a directory for provider-specific diagnostics.

    Args:
        directory: The directory to probe

    Returns:
        Diagnostic information about directory and provider
    """
    provider = _get_provider()
    return provider.probe(directory)


# Utility functions for metrics and logging
def get_metrics() -> MetricsCollector:
    """
    Get the global metrics collector.

    Returns:
        MetricsCollector instance for tracking performance
    """
    from .utils.logging import get_metrics as _get_metrics

    return _get_metrics()


def reset_metrics() -> None:
    """Reset the global metrics collector."""
    from .utils.logging import reset_metrics as _reset_metrics

    _reset_metrics()


# Cache management
def get_cache() -> DirectoryCache:
    """
    Get the global directory cache.

    Returns:
        DirectoryCache instance for caching directory listings
    """
    from .cache.ttl import get_cache as _get_cache

    return _get_cache()


def clear_cache() -> None:
    """Clear the global directory cache."""
    from .cache.ttl import clear_cache as _clear_cache

    _clear_cache()

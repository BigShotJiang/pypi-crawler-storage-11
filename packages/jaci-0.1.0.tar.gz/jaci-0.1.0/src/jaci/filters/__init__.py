"""
Composable filter implementations for file system entries.

This module provides filter classes that can be combined using AND, OR, and NOT
logic to create complex filtering criteria.
"""

from .base import FilterProtocol
from .composables import (
    GlobFilter,
    ExtensionFilter,
    SizeFilter,
    MtimeFilter,
    HiddenFilter,
    SelectionModeFilter,
    AndFilter,
    OrFilter,
    NotFilter,
)

__all__ = [
    "FilterProtocol",
    "GlobFilter",
    "ExtensionFilter", 
    "SizeFilter",
    "MtimeFilter",
    "HiddenFilter",
    "SelectionModeFilter",
    "AndFilter",
    "OrFilter",
    "NotFilter",
]
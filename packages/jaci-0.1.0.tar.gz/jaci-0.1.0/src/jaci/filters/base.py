"""
Base filter protocol and common interfaces.

This module defines the FilterProtocol that all filters must implement
to ensure consistent behavior and composability.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from ..models import Entry


class FilterProtocol(ABC):
    """
    Abstract base class defining the interface for entry filters.
    
    All filters must implement the accept method to determine whether
    an entry should be included in results.
    """
    
    @abstractmethod
    def accept(self, entry: Entry) -> bool:
        """
        Determine if an entry should be included in results.
        
        Args:
            entry: The entry to evaluate
            
        Returns:
            True if the entry should be included, False otherwise
        """
        ...
    
    def __and__(self, other: FilterProtocol) -> FilterProtocol:
        """Combine this filter with another using AND logic."""
        from .composables import AndFilter
        return AndFilter(self, other)
    
    def __or__(self, other: FilterProtocol) -> FilterProtocol:
        """Combine this filter with another using OR logic."""
        from .composables import OrFilter
        return OrFilter(self, other)
    
    def __invert__(self) -> FilterProtocol:
        """Create a negated version of this filter."""
        from .composables import NotFilter
        return NotFilter(self)
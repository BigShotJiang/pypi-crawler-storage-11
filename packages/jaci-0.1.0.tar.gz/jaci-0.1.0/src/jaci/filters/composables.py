"""
Composable filter implementations.

This module provides concrete filter implementations that can be combined
using logical operators to create complex filtering criteria.
"""

from __future__ import annotations

import fnmatch
import re
from pathlib import Path
from typing import Iterable, Tuple

from ..models import Entry, SelectionMode
from .base import FilterProtocol


class GlobFilter(FilterProtocol):
    """Filter entries based on glob patterns."""

    def __init__(self, pattern: str, include: bool = True) -> None:
        """
        Initialize glob filter.

        Args:
            pattern: Glob pattern to match against
            include: True to include matches, False to exclude matches
        """
        self.pattern = pattern
        self.include = include

    def accept(self, entry: Entry) -> bool:
        """Check if entry matches glob pattern."""
        matches = fnmatch.fnmatch(entry.name, self.pattern)
        return matches if self.include else not matches


class ExtensionFilter(FilterProtocol):
    """Filter entries based on file extensions."""

    def __init__(self, extensions: Iterable[str]) -> None:
        """
        Initialize extension filter.

        Args:
            extensions: Iterable of extensions to include (without dots)
        """
        self.extensions = {ext.lower().lstrip(".") for ext in extensions}

    def accept(self, entry: Entry) -> bool:
        """Check if entry has one of the specified extensions."""
        if entry.is_dir:
            return False  # Directories don't have extensions

        return entry.extension in self.extensions


class SizeFilter(FilterProtocol):
    """Filter entries based on file size."""

    def __init__(self, size_range: Tuple[int, int]) -> None:
        """
        Initialize size filter.

        Args:
            size_range: Tuple of (min_size, max_size) in bytes
        """
        self.min_size, self.max_size = size_range

    def accept(self, entry: Entry) -> bool:
        """Check if entry size is within the specified range."""
        return self.min_size <= entry.size <= self.max_size


class MtimeFilter(FilterProtocol):
    """Filter entries based on modification time."""

    def __init__(self, mtime_range: Tuple[float, float]) -> None:
        """
        Initialize modification time filter.

        Args:
            mtime_range: Tuple of (min_mtime, max_mtime) as Unix timestamps
        """
        self.min_mtime, self.max_mtime = mtime_range

    def accept(self, entry: Entry) -> bool:
        """Check if entry modification time is within the specified range."""
        return self.min_mtime <= entry.mtime <= self.max_mtime


class NameRegexFilter(FilterProtocol):
    """Filter entries based on name using regular expressions."""

    def __init__(self, pattern: str, flags: int = 0) -> None:
        """
        Initialize name regex filter.

        Args:
            pattern: Regular expression pattern
            flags: Regex flags (e.g., re.IGNORECASE)
        """
        self.regex = re.compile(pattern, flags)

    def accept(self, entry: Entry) -> bool:
        """Check if entry name matches the regex pattern."""
        return bool(self.regex.search(entry.name))


class HiddenFilter(FilterProtocol):
    """Filter hidden files and directories."""

    def __init__(self, include: bool = False) -> None:
        """
        Initialize hidden filter.

        Args:
            include: True to include hidden entries, False to exclude them
        """
        self.include = include

    def accept(self, entry: Entry) -> bool:
        """Check if entry should be included based on hidden status."""
        return entry.is_hidden if self.include else not entry.is_hidden


class SelectionModeFilter(FilterProtocol):
    """Filter entries based on selection mode (files only, directories only, or both)."""

    def __init__(self, mode: SelectionMode) -> None:
        """
        Initialize selection mode filter.

        Args:
            mode: Selection mode to apply
        """
        self.mode = mode

    def accept(self, entry: Entry) -> bool:
        """Check if entry matches the selection mode."""
        if self.mode == SelectionMode.FILES_ONLY:
            return not entry.is_dir
        elif self.mode == SelectionMode.DIRECTORIES_ONLY:
            return entry.is_dir
        else:  # SelectionMode.BOTH
            return True


class AndFilter(FilterProtocol):
    """Combine multiple filters with AND logic."""

    def __init__(self, *filters: FilterProtocol) -> None:
        """Initialize AND filter with multiple sub-filters."""
        self.filters = filters

    def accept(self, entry: Entry) -> bool:
        """Check if entry matches all sub-filters."""
        return all(f.accept(entry) for f in self.filters)


class OrFilter(FilterProtocol):
    """Combine multiple filters with OR logic."""

    def __init__(self, *filters: FilterProtocol) -> None:
        """Initialize OR filter with multiple sub-filters."""
        self.filters = filters

    def accept(self, entry: Entry) -> bool:
        """Check if entry matches any sub-filter."""
        return any(f.accept(entry) for f in self.filters)


class NotFilter(FilterProtocol):
    """Negate another filter."""

    def __init__(self, filter: FilterProtocol) -> None:
        """Initialize NOT filter with a sub-filter to negate."""
        self.filter = filter

    def accept(self, entry: Entry) -> bool:
        """Check if entry does NOT match the sub-filter."""
        return not self.filter.accept(entry)

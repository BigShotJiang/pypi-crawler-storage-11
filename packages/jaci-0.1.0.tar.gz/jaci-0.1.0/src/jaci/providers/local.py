"""
Local file system provider implementation.

This module provides the LocalProvider class that implements the ProviderProtocol
for local file system access using Python's standard library.
"""

from __future__ import annotations

import os
import platform
import stat
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Iterable, Optional, Set

if TYPE_CHECKING:
    from ..exceptions import (
        PathNotFoundError,
        PermissionDeniedError,
        SandboxViolationError,
        SymlinkLoopError,
        UnsupportedOperationError,
    )
    from ..models import Entry, Query, Order, WatchEvent, SelectionMode
    from .base import ProviderProtocol
    from ..cache.ttl import DirectoryCache

# Runtime imports
from ..exceptions import (
    PathNotFoundError,
    PermissionDeniedError,
    SandboxViolationError,
    SymlinkLoopError,
    UnsupportedOperationError,
)
from ..models import Entry, Query, Order, WatchEvent, SelectionMode
from .base import ProviderProtocol

# Optional cache import
try:
    from ..cache.ttl import get_cache
except ImportError:
    get_cache = None


def _check_extra_available(module_name: str) -> bool:
    """Check if an extra module is available."""
    try:
        __import__(module_name)
        return True
    except ImportError:
        return False


class LocalProvider(ProviderProtocol):
    """
    Local file system provider using Python's standard library.

    This provider implements all core functionality using only stdlib modules:
    - Directory iteration with filtering and sorting
    - File metadata retrieval
    - Safe path resolution with sandboxing
    - Symlink loop detection
    """

    def __init__(self, cache: Optional["DirectoryCache"] = None) -> None:
        """
        Initialize local provider.

        Args:
            cache: Optional cache instance. If None, uses global cache.
        """
        self._visited_symlinks: Set[Path] = set()
        self._cache = cache

        # Initialize logger
        try:
            from ..utils.logging import get_logger

            self._logger = get_logger(f"{__name__}.LocalProvider")
        except ImportError:
            import logging

            self._logger = logging.getLogger(f"{__name__}.LocalProvider")

    def iter_entries(
        self,
        directory: Path,
        query: Optional["Query"] = None,
        order: Optional["Order"] = None,
    ) -> Iterable["Entry"]:
        """Iterate over entries in a directory with optional filtering and sorting."""
        query = query or Query()
        order = order or Order()

        # Validate directory exists and is accessible
        if not directory.exists():
            raise PathNotFoundError(str(directory))

        if not directory.is_dir():
            raise PathNotFoundError(f"Path is not a directory: {directory}")

        if not os.access(directory, os.R_OK):
            raise PermissionDeniedError(str(directory), "read")

        # Reset symlink tracking for this iteration
        self._visited_symlinks.clear()

        # Try to get from cache first (if cache is enabled and no depth limiting)
        cache = self._cache
        cached_entries = None
        # Don't use cache when max_depth is set to avoid returning wrong recursive results
        if cache and query.max_depth is None:
            cached_entries = cache.get_directory_listing(directory)
            if cached_entries is not None:
                self._logger.debug(f"Cache hit for directory: {directory}")
                # Apply filters, pagination and sorting to cached entries
                filtered_entries = [
                    entry
                    for entry in cached_entries
                    if self._matches_query(entry, query)
                ]

                # Apply pagination
                if query.offset > 0:
                    filtered_entries = filtered_entries[query.offset :]
                if query.limit is not None:
                    filtered_entries = filtered_entries[: query.limit]

                # Apply sorting
                filtered_entries = self._sort_entries(filtered_entries, order)
                yield from filtered_entries
                return

        # Cache miss - collect entries from filesystem
        entries = []
        for entry_path in self._iter_directory_recursive(directory, query):
            if self._matches_query(entry_path, query):
                entries.append(entry_path)

        # Apply pagination
        if query.offset > 0:
            entries = entries[query.offset :]

        if query.limit is not None:
            entries = entries[: query.limit]

        # Apply sorting
        entries = self._sort_entries(entries, order)

        # Cache the full unfiltered listing for future use (only if no depth limiting in query)
        if cache and query.max_depth is None:
            full_entries = []
            for entry_path in self._iter_directory_recursive(directory, Query()):
                full_entries.append(entry_path)
            cache.set_directory_listing(directory, full_entries)

        yield from entries

    def stat(self, path: Path) -> "Entry":
        """Get metadata for a single file or directory."""
        # Try cache first
        cache = self._cache or (get_cache() if get_cache else None)
        if cache:
            cached_entry = cache.get_entry_metadata(path)
            if cached_entry is not None:
                self._logger.debug(f"Cache hit for entry: {path}")
                return cached_entry

        if not path.exists():
            raise PathNotFoundError(str(path))

        try:
            stat_info = path.stat()
        except PermissionError as e:
            raise PermissionDeniedError(str(path), "stat") from e

        entry = self._create_entry(path, stat_info)

        # Cache the entry
        if cache:
            cache.set_entry_metadata(entry)

        return entry

    def watch(
        self,
        directory: Path,
        query: Optional["Query"] = None,
        recursive: bool = True,
        debounce_ms: int = 100,
    ) -> Iterable["WatchEvent"]:
        """Watch a directory for file system events."""
        # Local provider doesn't implement watching by default
        # This will be implemented in the 'watch' extra
        raise UnsupportedOperationError(
            "watch", "File watching requires the 'watch' extra to be installed"
        )

    def capabilities(self) -> Dict[str, Any]:
        """Get provider capabilities."""
        return {
            "provider": "local",
            "features": {
                "list": True,
                "stat": True,
                "watch": _check_extra_available("watchfiles")
                or _check_extra_available("watchdog"),
                "ignore": _check_extra_available("pathspec"),
                "fuzzy": _check_extra_available("rapidfuzz"),
                "mime": _check_extra_available("python-magic")
                or _check_extra_available("filetype"),
                "remotes": _check_extra_available("fsspec"),
            },
            "platform": platform.system().lower(),
        }

    def probe(self, directory: Path) -> Dict[str, Any]:
        """
        Probe a directory for diagnostic information.

        Args:
            directory: Directory path to probe

        Returns:
            Diagnostic information about the directory and provider
        """
        try:
            # Basic directory info
            stat_info = directory.stat()

            # Test listing capabilities
            try:
                entries = list(directory.iterdir())
                entry_count = len(entries)
                can_list = True
            except (PermissionError, OSError):
                entry_count = 0
                can_list = False

            # Test symlink following
            can_follow_symlinks = True
            try:
                directory.resolve(strict=False)
            except Exception:
                can_follow_symlinks = False

            # Check for special files
            has_gitignore = (directory / ".gitignore").exists()
            has_git = (directory / ".git").exists()

            return {
                "directory": {
                    "path": str(directory),
                    "exists": directory.exists(),
                    "is_dir": directory.is_dir(),
                    "readable": os.access(directory, os.R_OK),
                    "writable": os.access(directory, os.W_OK),
                    "entry_count": entry_count,
                    "can_list": can_list,
                    "size": stat_info.st_size,
                    "mtime": stat_info.st_mtime,
                },
                "provider": {
                    "name": "local",
                    "platform": platform.system().lower(),
                    "can_follow_symlinks": can_follow_symlinks,
                },
                "features": {
                    "has_gitignore": has_gitignore,
                    "has_git": has_git,
                },
                "capabilities": self.capabilities(),
            }

        except Exception as e:
            return {
                "directory": {
                    "path": str(directory),
                    "error": str(e),
                },
                "provider": {
                    "name": "local",
                    "platform": platform.system().lower(),
                },
                "error": str(e),
            }

    def resolve_path(
        self,
        path: Path,
        sandbox_root: Optional[Path] = None,
    ) -> Path:
        """Resolve a path safely within optional sandbox constraints."""
        try:
            # Resolve to absolute path
            resolved = path.resolve(strict=False)

            # Check sandbox constraints
            if sandbox_root is not None:
                sandbox_resolved = sandbox_root.resolve()
                try:
                    resolved.relative_to(sandbox_resolved)
                except ValueError:
                    raise SandboxViolationError(str(resolved), str(sandbox_resolved))

            return resolved

        except RuntimeError as e:
            # This can happen with symlink loops
            raise SymlinkLoopError(str(path), str(path)) from e

    def _iter_directory_recursive(
        self,
        directory: Path,
        query: Query,
        current_depth: int = 0,
    ) -> Iterable[Entry]:
        """Recursively iterate over directory entries."""
        try:
            for item in directory.iterdir():
                try:
                    # Handle symlinks
                    if item.is_symlink():
                        if not query.follow_symlinks:
                            continue

                        # Check for symlink loops
                        if item in self._visited_symlinks:
                            continue  # Skip loops

                        self._visited_symlinks.add(item)

                        # Resolve symlink target
                        try:
                            target = item.resolve()
                            if not target.exists():
                                continue
                        except (OSError, RuntimeError):
                            continue  # Skip broken symlinks

                    # Create entry
                    stat_info = item.stat()
                    entry = self._create_entry(item, stat_info)

                    # Yield the entry
                    yield entry

                    # Recurse into directories if needed
                    if entry.is_dir and (
                        query.max_depth is None or current_depth < query.max_depth
                    ):
                        yield from self._iter_directory_recursive(
                            item, query, current_depth + 1
                        )

                except (PermissionError, OSError):
                    # Skip entries we can't access
                    continue

        except (PermissionError, OSError):
            # Skip directories we can't access
            return

    def _create_entry(self, path: Path, stat_info: os.stat_result) -> Entry:
        """Create an Entry from a path and stat info."""
        import stat as stat_module

        extension = None
        if not stat_module.S_ISDIR(stat_info.st_mode) and "." in path.name:
            extension = path.name.rsplit(".", 1)[-1].lower()

        # Detect MIME type if available and it's a file
        mime_type = None
        if not stat_module.S_ISDIR(stat_info.st_mode):
            try:
                from ..mime import create_mime_detector

                detector = create_mime_detector()
                mime_type = detector.detect_mime_type(path)
            except Exception:
                # MIME detection is optional, fail silently
                pass

        return Entry(
            path=path,
            name=path.name,
            parent=path.parent,
            is_dir=stat_module.S_ISDIR(stat_info.st_mode),
            size=stat_info.st_size,
            mtime=stat_info.st_mtime,
            permissions=stat_info.st_mode,
            mime=mime_type,
        )

    def _matches_query(self, entry: Entry, query: Query) -> bool:
        """Check if an entry matches the query criteria."""
        # Selection mode filtering
        if query.selection_mode == SelectionMode.FILES_ONLY and entry.is_dir:
            return False
        elif (
            query.selection_mode == SelectionMode.DIRECTORIES_ONLY and not entry.is_dir
        ):
            return False

        # Hidden files
        if not query.include_hidden and entry.is_hidden:
            return False

        # Name regex filtering
        if query.name_regex:
            import re

            if not re.search(query.name_regex, entry.name):
                return False

        # Glob patterns
        if query.include_glob:
            import fnmatch

            if not fnmatch.fnmatch(str(entry.path), query.include_glob):
                return False

        if query.exclude_glob:
            import fnmatch

            if fnmatch.fnmatch(str(entry.path), query.exclude_glob):
                return False

        # Extension filtering
        if query.extensions and not entry.is_dir:
            if entry.extension is None or entry.extension not in query.extensions:
                return False

        # Size filtering
        if query.size_range:
            min_size, max_size = query.size_range
            if entry.size < min_size or entry.size > max_size:
                return False

        # Modification time filtering
        if query.mtime_range:
            min_mtime, max_mtime = query.mtime_range
            if entry.mtime < min_mtime or entry.mtime > max_mtime:
                return False

        return True

    def _sort_entries(self, entries: list[Entry], order: Order) -> list[Entry]:
        """Sort entries according to the order specification."""
        reverse = order.direction == "desc"

        if order.by == "name":
            key_func = lambda e: e.name.lower()
        elif order.by == "size":
            key_func = lambda e: e.size
        elif order.by == "mtime":
            key_func = lambda e: e.mtime
        elif order.by == "ext":
            key_func = lambda e: e.extension or ""
        else:
            key_func = lambda e: e.name.lower()

        # Apply natural sort if requested
        if order.natural and order.by in ("name", "ext"):
            # Simple natural sort implementation
            import re

            def alphanum_key(s: str) -> list:
                return [
                    int(text) if text.isdigit() else text.lower()
                    for text in re.split("([0-9]+)", s)
                ]

            if order.by == "name":
                key_func = lambda e: alphanum_key(e.name)
            elif order.by == "ext":
                key_func = lambda e: alphanum_key(e.extension or "")

        return sorted(entries, key=key_func, reverse=reverse)

    def _is_cacheable_query(self, query: Query) -> bool:
        """
        Check if a query is simple enough to be cached.

        Args:
            query: Query to check

        Returns:
            True if query is cacheable, False otherwise
        """
        # Only cache simple queries without complex filters
        if (
            query.name_regex
            or query.exclude_glob
            or query.size_range
            or query.mtime_range
            or query.max_depth is not None
            or query.selection_mode != SelectionMode.BOTH
        ):
            return False

        # Cache queries with simple glob patterns and extension filters
        return True

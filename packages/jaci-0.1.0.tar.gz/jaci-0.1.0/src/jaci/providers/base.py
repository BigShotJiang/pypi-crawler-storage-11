"""
Base provider protocol and common interfaces.

This module defines the ProviderProtocol that all file system providers
must implement to ensure consistent behavior across different backends.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Iterable, Optional, Set

if TYPE_CHECKING:
    from ..models import Entry, Query, Order, WatchEvent


class ProviderProtocol(ABC):
    """
    Abstract base class defining the interface for file system providers.

    All providers (local, remote, etc.) must implement this protocol
    to ensure consistent behavior and feature detection.
    """

    @abstractmethod
    def iter_entries(
        self,
        directory: Path,
        query: Optional["Query"] = None,
        order: Optional["Order"] = None,
    ) -> Iterable["Entry"]:
        """
        Iterate over entries in a directory according to query and order.

        Args:
            directory: The directory to iterate over
            query: Filtering criteria (optional)
            order: Sorting specification (optional)

        Yields:
            Entry objects matching the criteria

        Raises:
            PathNotFoundError: If directory doesn't exist
            PermissionDeniedError: If lacking read permissions
            ProviderUnavailableError: If provider is not available
        """
        ...

    @abstractmethod
    def stat(self, path: Path) -> "Entry":
        """
        Get metadata for a single file or directory.

        Args:
            path: The path to get metadata for

        Returns:
            Entry object with full metadata

        Raises:
            PathNotFoundError: If path doesn't exist
            PermissionDeniedError: If lacking read permissions
        """
        ...

    @abstractmethod
    def watch(
        self,
        directory: Path,
        query: Optional["Query"] = None,
        recursive: bool = True,
        debounce_ms: int = 100,
    ) -> Iterable["WatchEvent"]:
        """
        Watch a directory for file system events.

        Args:
            directory: The directory to watch
            query: Filter events for specific entries (optional)
            recursive: Whether to watch subdirectories
            debounce_ms: Debounce time in milliseconds

        Yields:
            WatchEvent objects as they occur

        Raises:
            UnsupportedOperationError: If watching is not supported
            PermissionDeniedError: If lacking permissions
        """
        ...

    @abstractmethod
    def capabilities(self) -> Dict[str, Any]:
        """
        Get the capabilities and features supported by this provider.

        Returns:
            Dictionary mapping feature names to capability information
            Example: {"watch": True, "fuzzy": False, "mime": True}
        """
        ...

    @abstractmethod
    def resolve_path(
        self,
        path: Path,
        sandbox_root: Optional[Path] = None,
    ) -> Path:
        """
        Resolve a path safely within optional sandbox constraints.

        Args:
            path: The path to resolve
            sandbox_root: Optional sandbox root directory

        Returns:
            Canonical, absolute path

        Raises:
            SandboxViolationError: If path is outside sandbox
            SymlinkLoopError: If symlink loop is detected
        """
        ...

    def probe(self, directory: Path) -> Dict[str, Any]:
        """
        Probe a directory for provider-specific diagnostics.

        This default implementation returns basic information.
        Providers can override to provide more detailed diagnostics.

        Args:
            directory: The directory to probe

        Returns:
            Diagnostic information about directory and provider
        """
        try:
            entry = self.stat(directory)
            return {
                "exists": True,
                "is_directory": getattr(entry, "is_dir", False),
                "readable": True,
                "provider": self.__class__.__name__,
            }
        except Exception as e:
            return {
                "exists": False,
                "readable": False,
                "error": str(e),
                "provider": self.__class__.__name__,
            }

    def validate_query(self, query: Optional["Query"]) -> "Query":
        """
        Validate and normalize query parameters.

        Args:
            query: Query to validate (optional)

        Returns:
            Validated Query object
        """
        if query is None:
            from ..models import Query

            return Query()
        return query

    def validate_order(self, order: Optional["Order"]) -> "Order":
        """
        Validate and normalize order parameters.

        Args:
            order: Order to validate (optional)

        Returns:
            Validated Order object
        """
        if order is None:
            from ..models import Order

            return Order()
        return order

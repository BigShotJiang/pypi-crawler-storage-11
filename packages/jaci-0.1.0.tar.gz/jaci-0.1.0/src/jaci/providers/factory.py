"""
Provider factory for creating and managing different file system providers.

This module provides a factory pattern for creating providers based on
configuration and available extras.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Any, Optional, Type
from .base import ProviderProtocol
from .local import LocalProvider

# Try to import remote provider
try:
    from ..remotes.provider import RemoteProvider

    _REMOTE_PROVIDER_AVAILABLE = True
except ImportError:
    _REMOTE_PROVIDER_AVAILABLE = False


class ProviderFactory:
    """
    Factory for creating file system providers.

    Supports creating local and remote providers based on configuration.
    """

    def __init__(self):
        """Initialize provider factory."""
        self._provider_registry: Dict[str, Type[ProviderProtocol]] = {
            "local": LocalProvider,
        }

        # Register remote provider if available
        if _REMOTE_PROVIDER_AVAILABLE:
            self._provider_registry["remote"] = RemoteProvider

    def create_provider(
        self, provider_type: str = "local", config: Optional[Dict[str, Any]] = None
    ) -> ProviderProtocol:
        """
        Create a provider instance.

        Args:
            provider_type: Type of provider to create
            config: Provider-specific configuration

        Returns:
            Provider instance

        Raises:
            ValueError: If provider type is not supported
            ImportError: If required dependencies are missing
        """
        if provider_type not in self._provider_registry:
            available = list(self._provider_registry.keys())
            raise ValueError(
                f"Unknown provider type: {provider_type}. Available: {available}"
            )

        provider_class = self._provider_registry[provider_type]
        config = config or {}

        # Create provider with configuration
        if provider_type == "local":
            # Get cache instance for local provider
            try:
                from ..cache.ttl import get_cache

                cache = get_cache()
                return provider_class(cache=cache, **config)
            except ImportError:
                return provider_class(**config)

        elif provider_type == "remote":
            if not _REMOTE_PROVIDER_AVAILABLE:
                raise ImportError("Remote provider requires 'fsspec' dependency")

            # Create remote provider with config
            return provider_class(**config)

        else:
            # Generic provider creation
            return provider_class(**config)

    def get_available_providers(self) -> list[str]:
        """
        Get list of available provider types.

        Returns:
            List of provider type names
        """
        return list(self._provider_registry.keys())

    def register_provider(
        self, name: str, provider_class: Type[ProviderProtocol]
    ) -> None:
        """
        Register a new provider type.

        Args:
            name: Provider type name
            provider_class: Provider class
        """
        self._provider_registry[name] = provider_class

    def create_from_config(self, config: Dict[str, Any]) -> ProviderProtocol:
        """
        Create provider from configuration dictionary.

        Args:
            config: Configuration with provider settings

        Returns:
            Provider instance
        """
        provider_type = config.get("type", "local")
        provider_config = config.get("config", {})

        return self.create_provider(provider_type, provider_config)


# Global factory instance
_factory: Optional[ProviderFactory] = None


def get_provider_factory() -> ProviderFactory:
    """
    Get the global provider factory instance.

    Returns:
        ProviderFactory instance
    """
    global _factory
    if _factory is None:
        _factory = ProviderFactory()
    return _factory


def create_provider(
    provider_type: str = "local", config: Optional[Dict[str, Any]] = None
) -> ProviderProtocol:
    """
    Create a provider using the global factory.

    Args:
        provider_type: Type of provider to create
        config: Provider-specific configuration

    Returns:
        Provider instance
    """
    factory = get_provider_factory()
    return factory.create_provider(provider_type, config)


def create_provider_from_config(config: Dict[str, Any]) -> ProviderProtocol:
    """
    Create provider from configuration using the global factory.

    Args:
        config: Configuration with provider settings

    Returns:
        Provider instance
    """
    factory = get_provider_factory()
    return factory.create_from_config(config)


def get_available_providers() -> list[str]:
    """
    Get list of available provider types.

    Returns:
        List of provider type names
    """
    factory = get_provider_factory()
    return factory.get_available_providers()


def register_provider(name: str, provider_class: Type[ProviderProtocol]) -> None:
    """
    Register a new provider type using the global factory.

    Args:
        name: Provider type name
        provider_class: Provider class
    """
    factory = get_provider_factory()
    factory.register_provider(name, provider_class)

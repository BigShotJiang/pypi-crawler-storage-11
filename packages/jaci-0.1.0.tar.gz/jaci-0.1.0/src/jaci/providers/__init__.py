"""
Provider implementations for different file system backends.

This module contains the base provider protocol and concrete implementations
for local and remote file systems.
"""

try:
    from .base import ProviderProtocol
    from .local import LocalProvider
    
    __all__ = [
        "ProviderProtocol",
        "LocalProvider",
    ]
except ImportError:
    __all__ = []
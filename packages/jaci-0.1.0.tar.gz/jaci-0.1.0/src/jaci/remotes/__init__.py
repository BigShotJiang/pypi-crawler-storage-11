"""
Remote file system functionality for lumelab-jaci.

This extra provides support for remote file systems using fsspec
including S3, GCS, Azure Blob Storage, and other remote providers.
"""

from __future__ import annotations

from pathlib import Path, PurePosixPath
from typing import Iterable, Optional, Dict, Any, Union, TYPE_CHECKING
from dataclasses import dataclass

if TYPE_CHECKING:
    try:
        import fsspec
        from fsspec.spec import AbstractFileSystem
    except ImportError:
        fsspec = None
        AbstractFileSystem = None

# Try to import fsspec for remote file system support
try:
    import fsspec
    from fsspec.spec import AbstractFileSystem

    _FSSPEC_AVAILABLE = True
except ImportError:
    _FSSPEC_AVAILABLE = False
    fsspec = None
    AbstractFileSystem = None


@dataclass
class RemoteConfig:
    """
    Configuration for remote file system connections.

    Contains connection parameters and authentication details.
    """

    # Protocol type (s3, gcs, az, etc.)
    protocol: str

    # Connection parameters
    host: Optional[str] = None
    port: Optional[int] = None
    username: Optional[str] = None
    password: Optional[str] = None
    token: Optional[str] = None

    # Protocol-specific options
    bucket: Optional[str] = None
    region: Optional[str] = None
    project_id: Optional[str] = None
    account_name: Optional[str] = None
    account_key: Optional[str] = None

    # Additional fsspec options
    extra_options: Optional[Dict[str, Any]] = None

    def __post_init__(self) -> None:
        """Validate configuration."""
        if not self.protocol:
            raise ValueError("Protocol is required")

        # Protocol-specific validation
        if self.protocol == "s3" and not self.bucket:
            raise ValueError("Bucket is required for S3 protocol")
        elif self.protocol == "gcs" and not self.bucket:
            raise ValueError("Bucket is required for GCS protocol")
        elif self.protocol == "az" and not self.account_name:
            raise ValueError("Account name is required for Azure protocol")

    def to_fsspec_kwargs(self) -> Dict[str, Any]:
        """Convert to fsspec filesystem kwargs."""
        kwargs = {}

        if self.host:
            kwargs["host"] = self.host
        if self.port:
            kwargs["port"] = self.port
        if self.username:
            kwargs["username"] = self.username
        if self.password:
            kwargs["password"] = self.password
        if self.token:
            kwargs["token"] = self.token
        if self.bucket:
            kwargs["bucket"] = self.bucket
        if self.region:
            kwargs["region"] = self.region
        if self.project_id:
            kwargs["project"] = self.project_id
        if self.account_name:
            kwargs["account_name"] = self.account_name
        if self.account_key:
            kwargs["account_key"] = self.account_key

        # Add extra options
        if self.extra_options:
            kwargs.update(self.extra_options)

        return kwargs


class RemoteFileSystem:
    """
    Remote file system wrapper using fsspec.

    Provides unified interface for various remote file systems.
    """

    def __init__(self, config: RemoteConfig):
        """
        Initialize remote file system.

        Args:
            config: Remote configuration
        """
        if not _FSSPEC_AVAILABLE:
            raise ImportError(
                "fsspec is not available. Install 'fsspec' and required protocol packages."
            )

        self.config = config
        self.fs = self._create_filesystem()

    def _create_filesystem(self):
        """Create fsspec filesystem instance."""
        if not _FSSPEC_AVAILABLE or fsspec is None:
            raise ImportError("fsspec is not available")
        kwargs = self.config.to_fsspec_kwargs()
        return fsspec.filesystem(self.config.protocol, **kwargs)

    def list_directory(self, path: str) -> Iterable[str]:
        """
        List contents of a remote directory.

        Args:
            path: Remote path to list

        Yields:
            Path strings of directory contents
        """
        if not _FSSPEC_AVAILABLE or self.fs is None:
            raise RuntimeError("fsspec is not available")

        try:
            for info in self.fs.ls(path, detail=True):
                yield info["name"]
        except Exception as e:
            raise RuntimeError(f"Failed to list directory {path}: {e}")

    def get_file_info(self, path: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a remote file or directory.

        Args:
            path: Remote path

        Returns:
            File information dictionary or None if not found
        """
        try:
            return self.fs.info(path)
        except FileNotFoundError:
            return None
        except Exception as e:
            raise RuntimeError(f"Failed to get info for {path}: {e}")

    def exists(self, path: str) -> bool:
        """Check if remote path exists."""
        try:
            return self.fs.exists(path)
        except Exception:
            return False

    def is_file(self, path: str) -> bool:
        """Check if path is a file."""
        try:
            info = self.fs.info(path)
            return info["type"] == "file"
        except Exception:
            return False

    def is_directory(self, path: str) -> bool:
        """Check if path is a directory."""
        try:
            info = self.fs.info(path)
            return info["type"] == "directory"
        except Exception:
            return False

    def get_size(self, path: str) -> Optional[int]:
        """Get file size in bytes."""
        try:
            info = self.fs.info(path)
            return info.get("size")
        except Exception:
            return None

    def get_modified_time(self, path: str) -> Optional[float]:
        """Get modification time as Unix timestamp."""
        try:
            info = self.fs.info(path)
            return info.get("modified")
        except Exception:
            return None

    def open_file(self, path: str, mode: str = "rb"):
        """
        Open a remote file for reading/writing.

        Args:
            path: Remote file path
            mode: File open mode

        Returns:
            File-like object
        """
        try:
            return self.fs.open(path, mode)
        except Exception as e:
            raise RuntimeError(f"Failed to open file {path}: {e}")

    def read_file(self, path: str) -> bytes:
        """Read entire remote file content."""
        try:
            with self.fs.open(path, "rb") as f:
                return f.read()
        except Exception as e:
            raise RuntimeError(f"Failed to read file {path}: {e}")

    def write_file(self, path: str, content: Union[str, bytes]) -> None:
        """Write content to remote file."""
        try:
            with self.fs.open(path, "wb") as f:
                if isinstance(content, str):
                    content = content.encode("utf-8")
                f.write(content)
        except Exception as e:
            raise RuntimeError(f"Failed to write file {path}: {e}")

    def delete_file(self, path: str) -> None:
        """Delete a remote file."""
        try:
            self.fs.rm(path)
        except Exception as e:
            raise RuntimeError(f"Failed to delete file {path}: {e}")

    def create_directory(self, path: str) -> None:
        """Create a remote directory."""
        try:
            self.fs.makedirs(path, exist_ok=True)
        except Exception as e:
            raise RuntimeError(f"Failed to create directory {path}: {e}")

    def delete_directory(self, path: str, recursive: bool = False) -> None:
        """Delete a remote directory."""
        try:
            self.fs.rm(path, recursive=recursive)
        except Exception as e:
            raise RuntimeError(f"Failed to delete directory {path}: {e}")

    def copy_file(self, src: str, dst: str) -> None:
        """Copy a file within remote file system."""
        try:
            self.fs.copy(src, dst)
        except Exception as e:
            raise RuntimeError(f"Failed to copy file from {src} to {dst}: {e}")

    def move_file(self, src: str, dst: str) -> None:
        """Move/rename a file within remote file system."""
        try:
            self.fs.mv(src, dst)
        except Exception as e:
            raise RuntimeError(f"Failed to move file from {src} to {dst}: {e}")

    def sync_directory(self, src: str, dst: str, delete: bool = False) -> None:
        """
        Sync a directory to another location.

        Args:
            src: Source directory
            dst: Destination directory
            delete: Whether to delete files in destination not in source
        """
        try:
            self.fs.sync(src, dst, delete=delete)
        except Exception as e:
            raise RuntimeError(f"Failed to sync directory from {src} to {dst}: {e}")

    @property
    def protocol(self) -> str:
        """Get protocol being used."""
        return self.config.protocol

    @property
    def is_available(self) -> bool:
        """Check if fsspec is available."""
        return _FSSPEC_AVAILABLE


def create_s3_config(
    bucket: str,
    region: Optional[str] = None,
    access_key: Optional[str] = None,
    secret_key: Optional[str] = None,
    token: Optional[str] = None,
    endpoint_url: Optional[str] = None,
    **extra_options,
) -> RemoteConfig:
    """
    Create S3 configuration.

    Args:
        bucket: S3 bucket name
        region: AWS region
        access_key: AWS access key
        secret_key: AWS secret key
        token: AWS session token
        endpoint_url: Custom endpoint URL (for S3-compatible services)
        **extra_options: Additional fsspec options

    Returns:
        RemoteConfig for S3
    """
    config = RemoteConfig(
        protocol="s3",
        bucket=bucket,
        region=region,
        token=token,
        host=endpoint_url,
        extra_options=extra_options,
    )

    # Add credentials to extra options
    if access_key or secret_key:
        if not config.extra_options:
            config.extra_options = {}
        if access_key:
            config.extra_options["key"] = access_key
        if secret_key:
            config.extra_options["secret"] = secret_key

    return config


def create_gcs_config(
    bucket: str,
    project_id: Optional[str] = None,
    token: Optional[str] = None,
    **extra_options,
) -> RemoteConfig:
    """
    Create Google Cloud Storage configuration.

    Args:
        bucket: GCS bucket name
        project_id: GCP project ID
        token: GCP authentication token
        **extra_options: Additional fsspec options

    Returns:
        RemoteConfig for GCS
    """
    return RemoteConfig(
        protocol="gcs",
        bucket=bucket,
        project_id=project_id,
        token=token,
        extra_options=extra_options,
    )


def create_azure_config(
    account_name: str,
    account_key: Optional[str] = None,
    connection_string: Optional[str] = None,
    **extra_options,
) -> RemoteConfig:
    """
    Create Azure Blob Storage configuration.

    Args:
        account_name: Azure storage account name
        account_key: Azure storage account key
        connection_string: Azure connection string
        **extra_options: Additional fsspec options

    Returns:
        RemoteConfig for Azure Blob Storage
    """
    config = RemoteConfig(
        protocol="az",
        account_name=account_name,
        account_key=account_key,
        extra_options=extra_options,
    )

    if connection_string:
        if not config.extra_options:
            config.extra_options = {}
        config.extra_options["connection_string"] = connection_string

    return config


def create_remote_filesystem(config: RemoteConfig) -> RemoteFileSystem:
    """
    Create a remote file system from configuration.

    Args:
        config: Remote configuration

    Returns:
        RemoteFileSystem instance
    """
    return RemoteFileSystem(config)


def get_supported_protocols() -> list[str]:
    """Get list of supported remote protocols."""
    if not _FSSPEC_AVAILABLE:
        return []

    # Common protocols that fsspec supports
    return [
        "s3",
        "s3a",
        "gs",
        "gcs",
        "az",
        "abfs",
        "adl",
        "ftp",
        "sftp",
        "hdfs",
        "webdav",
        "http",
        "https",
    ]


def get_available_providers() -> list[str]:
    """Get list of available remote providers."""
    if not _FSSPEC_AVAILABLE:
        return []

    return [
        "s3",
        "gcs",
        "azure",
        "ftp",
        "sftp",
        "http",
        "https",
    ]


def is_remote_available() -> bool:
    """Check if remote file system support is available."""
    return _FSSPEC_AVAILABLE

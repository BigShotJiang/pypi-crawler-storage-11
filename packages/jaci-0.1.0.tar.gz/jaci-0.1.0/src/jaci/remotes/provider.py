"""
Remote file system provider implementation.

This module provides RemoteProvider class that implements the ProviderProtocol
for remote file systems using fsspec.
"""

from __future__ import annotations

import os
import stat
from pathlib import Path, PurePosixPath
from typing import TYPE_CHECKING, Any, Dict, Iterable, Optional, Set

if TYPE_CHECKING:
    from ..exceptions import (
        PathNotFoundError,
        PermissionDeniedError,
        SandboxViolationError,
        SymlinkLoopError,
        UnsupportedOperationError,
    )
    from ..models import Entry, Query, Order, WatchEvent, SelectionMode
    from ..providers.base import ProviderProtocol
    from . import RemoteFileSystem, RemoteConfig

# Runtime imports
from ..exceptions import (
    PathNotFoundError,
    PermissionDeniedError,
    SandboxViolationError,
    SymlinkLoopError,
    UnsupportedOperationError,
)
from ..models import Entry, Query, Order, WatchEvent, SelectionMode
from ..providers.base import ProviderProtocol

# Optional remote imports
try:
    from . import RemoteFileSystem, RemoteConfig

    _REMOTES_AVAILABLE = True
except ImportError:
    _REMOTES_AVAILABLE = False


class RemoteProvider(ProviderProtocol):
    """
    Remote file system provider using fsspec.

    This provider implements all core functionality for remote file systems:
    - Directory iteration with filtering and sorting
    - File metadata retrieval
    - Safe path resolution with sandboxing
    - Remote-specific optimizations
    """

    def __init__(self, remote_fs: Optional[RemoteFileSystem] = None) -> None:
        """
        Initialize remote provider.

        Args:
            remote_fs: Optional RemoteFileSystem instance
        """
        if not _REMOTES_AVAILABLE:
            raise UnsupportedOperationError(
                "remote",
                "Remote file system support requires the 'remotes' extra to be installed",
            )

        self._remote_fs = remote_fs
        self._visited_symlinks: Set[str] = set()

        # Initialize logger
        try:
            from ..utils.logging import get_logger

            self._logger = get_logger(f"{__name__}.RemoteProvider")
        except ImportError:
            import logging

            self._logger = logging.getLogger(f"{__name__}.RemoteProvider")

    def iter_entries(
        self,
        directory: Path,
        query: Optional[Query] = None,
        order: Optional[Order] = None,
    ) -> Iterable[Entry]:
        """Iterate over entries in a remote directory with optional filtering and sorting."""
        if not self._remote_fs:
            raise UnsupportedOperationError(
                "remote", "No remote file system configured"
            )

        query = query or Query()
        order = order or Order()

        # Convert to remote path
        remote_path = self._to_remote_path(directory)

        # Validate directory exists and is accessible
        if not self._remote_fs.exists(remote_path):
            raise PathNotFoundError(str(directory))

        if not self._remote_fs.is_directory(remote_path):
            raise PathNotFoundError(f"Path is not a directory: {directory}")

        # Reset symlink tracking for this iteration
        self._visited_symlinks.clear()

        # Collect entries
        entries = []
        for entry_path in self._iter_directory_recursive(remote_path, query):
            if self._matches_query(entry_path, query):
                entries.append(entry_path)

        # Apply pagination
        if query.offset > 0:
            entries = entries[query.offset :]

        if query.limit is not None:
            entries = entries[: query.limit]

        # Apply sorting
        entries = self._sort_entries(entries, order)

        yield from entries

    def stat(self, path: Path) -> Entry:
        """Get metadata for a single remote file or directory."""
        if not self._remote_fs:
            raise UnsupportedOperationError(
                "remote", "No remote file system configured"
            )

        remote_path = self._to_remote_path(path)

        if not self._remote_fs.exists(remote_path):
            raise PathNotFoundError(str(path))

        try:
            info = self._remote_fs.get_file_info(remote_path)
            if not info:
                raise PathNotFoundError(str(path))
        except Exception as e:
            raise PermissionDeniedError(str(path), "stat") from e

        return self._create_entry(path, info)

    def watch(
        self,
        directory: Path,
        query: Optional[Query] = None,
        recursive: bool = True,
        debounce_ms: int = 100,
    ) -> Iterable[WatchEvent]:
        """Watch a remote directory for file system events."""
        # Remote provider doesn't implement watching by default
        # This would require remote-specific event mechanisms
        raise UnsupportedOperationError(
            "watch", "File watching for remote systems is not supported"
        )

    def capabilities(self) -> Dict[str, Any]:
        """Get provider capabilities."""
        return {
            "provider": "remote",
            "features": {
                "list": True,
                "stat": True,
                "watch": False,
                "ignore": False,  # Could be implemented with remote patterns
                "fuzzy": True,  # Can work with remote entries
                "mime": True,  # Can work with remote files
            },
            "protocol": self._remote_fs.protocol if self._remote_fs else "unknown",
            "remotes_available": _REMOTES_AVAILABLE,
        }

    def probe(self, directory: Path) -> Dict[str, Any]:
        """
        Probe a remote directory for diagnostic information.
        """
        if not self._remote_fs:
            return {
                "directory": {"path": str(directory), "configured": False},
                "provider": {"name": "remote", "configured": False},
                "error": "No remote file system configured",
            }

        remote_path = self._to_remote_path(directory)

        try:
            info = self._remote_fs.get_file_info(remote_path)
            exists = info is not None
            is_dir = info.get("type") == "directory" if info else False
            size = info.get("size", 0) if info else 0
            mtime = info.get("modified", 0) if info else 0

            # Count entries if it's a directory
            entry_count = 0
            if is_dir:
                try:
                    entry_count = len(list(self._remote_fs.list_directory(remote_path)))
                except Exception:
                    pass

            return {
                "directory": {
                    "path": str(directory),
                    "remote_path": remote_path,
                    "exists": exists,
                    "is_dir": is_dir,
                    "readable": exists,  # Assume readable if exists
                    "writable": True,  # Assume writable (may vary by provider)
                    "entry_count": entry_count,
                    "size": size,
                    "mtime": mtime,
                    "can_list": is_dir,
                },
                "provider": {
                    "name": "remote",
                    "protocol": self._remote_fs.protocol,
                    "configured": True,
                },
                "features": {
                    "has_ignore": False,
                    "has_git": False,
                },
                "capabilities": self.capabilities(),
            }
        except Exception as e:
            return {
                "directory": {"path": str(directory), "error": str(e)},
                "provider": {"name": "remote", "error": str(e)},
                "error": str(e),
            }

    def resolve_path(self, path: Path, sandbox_root: Optional[Path] = None) -> Path:
        """Resolve a remote path safely within optional sandbox constraints."""
        # For remote paths, we work with PurePosixPath
        resolved_path = PurePosixPath(str(path))

        if sandbox_root:
            sandbox_root_remote = self._to_remote_path(sandbox_root)
            try:
                resolved_path.relative_to(sandbox_root_remote)
            except ValueError:
                raise SandboxViolationError(str(path), str(sandbox_root))

        return Path(resolved_path)

    def _to_remote_path(self, path: Path) -> str:
        """Convert local Path to remote path string."""
        # Convert to POSIX path for remote systems
        if isinstance(path, PurePosixPath):
            return str(path)
        else:
            return str(path.as_posix())

    def _iter_directory_recursive(
        self, remote_path: str, query: Query
    ) -> Iterable[Entry]:
        """Iterate over entries in a remote directory recursively."""
        if not self._remote_fs:
            return

        try:
            for item_path in self._remote_fs.list_directory(remote_path):
                # Convert back to Path for Entry creation
                local_path = Path(item_path)

                # Get file info
                info = self._remote_fs.get_file_info(item_path)
                if not info:
                    continue

                entry = self._create_entry(local_path, info)

                # Apply selection mode filter
                if not self._matches_selection_mode(entry, query):
                    continue

                # Apply hidden files filter
                if not query.include_hidden and entry.is_hidden:
                    continue

                yield entry

                # Recurse into subdirectories if requested
                if (
                    entry.is_dir
                    and query.follow_symlinks  # For remote, this means follow directories
                    and (query.max_depth is None or query.max_depth > 0)
                ):
                    # Adjust max_depth for recursion
                    if query.max_depth is not None:
                        query.max_depth -= 1

                    yield from self._iter_directory_recursive(item_path, query)

                    # Restore max_depth
                    if query.max_depth is not None:
                        query.max_depth += 1

        except Exception as e:
            self._logger.warning(
                f"Failed to iterate remote directory {remote_path}: {e}"
            )

    def _create_entry(self, path: Path, info: Dict[str, Any]) -> Entry:
        """Create an Entry from a path and remote file info."""
        # Extract information from remote file info
        is_dir = info.get("type") == "directory"
        size = info.get("size", 0)
        mtime = info.get("modified", 0)

        return Entry(
            path=path,
            name=path.name,
            parent=path.parent,
            is_dir=is_dir,
            size=size,
            mtime=mtime,
            permissions=0,  # Remote systems may not have POSIX permissions
        )

    def _matches_selection_mode(self, entry: Entry, query: Query) -> bool:
        """Check if entry matches selection mode."""
        if query.selection_mode == SelectionMode.FILES_ONLY:
            return not entry.is_dir
        elif query.selection_mode == SelectionMode.DIRECTORIES_ONLY:
            return entry.is_dir
        else:  # SelectionMode.BOTH
            return True

    def _matches_query(self, entry: Entry, query: Query) -> bool:
        """Check if an entry matches query criteria."""
        # Selection mode
        if not self._matches_selection_mode(entry, query):
            return False

        # Hidden files
        if not query.include_hidden and entry.is_hidden:
            return False

        # Glob patterns
        if query.include_glob:
            import fnmatch

            if not fnmatch.fnmatch(entry.name, query.include_glob):
                return False

        if query.exclude_glob:
            import fnmatch

            if fnmatch.fnmatch(entry.name, query.exclude_glob):
                return False

        # Extension filtering
        if query.extensions and not entry.is_dir:
            if entry.extension is None or entry.extension not in query.extensions:
                return False

        # Size filtering
        if query.size_range:
            min_size, max_size = query.size_range
            if entry.size < min_size or entry.size > max_size:
                return False

        # Modification time filtering
        if query.mtime_range:
            min_mtime, max_mtime = query.mtime_range
            if entry.mtime < min_mtime or entry.mtime > max_mtime:
                return False

        return True

    def _sort_entries(self, entries: list[Entry], order: Order) -> list[Entry]:
        """Sort entries according to order specification."""
        reverse = order.direction == "desc"

        if order.by == "name":
            key_func = lambda e: e.name.lower()
        elif order.by == "size":
            key_func = lambda e: e.size
        elif order.by == "mtime":
            key_func = lambda e: e.mtime
        elif order.by == "ext":
            key_func = lambda e: e.extension or ""
        else:
            key_func = lambda e: e.name.lower()

        # Apply natural sort if requested
        if order.natural and order.by in ("name", "ext"):
            # Simple natural sort implementation
            import re

            def alphanum_key(s: str) -> list:
                return [
                    int(text) if text.isdigit() else text.lower()
                    for text in re.split("([0-9]+)", s)
                ]

            if order.by == "name":
                key_func = lambda e: alphanum_key(e.name)
            elif order.by == "ext":
                key_func = lambda e: alphanum_key(e.extension or "")

        return sorted(entries, key=key_func, reverse=reverse)


def create_remote_provider(config: RemoteConfig) -> RemoteProvider:
    """
    Create a remote provider from configuration.

    Args:
        config: Remote configuration

    Returns:
        RemoteProvider instance
    """
    if not _REMOTES_AVAILABLE:
        raise UnsupportedOperationError(
            "remote",
            "Remote file system support requires the 'remotes' extra to be installed",
        )

    from . import RemoteFileSystem

    remote_fs = RemoteFileSystem(config)
    return RemoteProvider(remote_fs)


def is_remote_available() -> bool:
    """Check if remote file system support is available."""
    return _REMOTES_AVAILABLE

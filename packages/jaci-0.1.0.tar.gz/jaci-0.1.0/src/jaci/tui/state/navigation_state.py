"""
Navigation state management for the TUI interface.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from ...models import Entry


@dataclass
class NavigationState:
    """Manages the navigation state of the file browser."""
    
    current_path: Path
    column_paths: List[Path] = field(default_factory=list)
    visible_columns: List[int] = field(default_factory=list)  # indices of visible columns
    selected_items: Dict[Path, Entry] = field(default_factory=dict)
    scroll_offset: int = 0  # which column is most left visible
    max_visible_columns: int = 5
    
    def add_column(self, path: Path) -> None:
        """Add a new column to the navigation."""
        self.column_paths.append(path)
        
        # Update visible columns
        if len(self.column_paths) <= self.max_visible_columns:
            self.visible_columns = list(range(len(self.column_paths)))
        else:
            # Need to scroll
            self.scroll_offset += 1
            start = self.scroll_offset
            end = start + self.max_visible_columns
            self.visible_columns = list(range(start, end))
    
    def remove_last_column(self) -> None:
        """Remove the last column from navigation."""
        if self.column_paths:
            removed_path = self.column_paths.pop()
            self.selected_items.pop(removed_path, None)
            
            # Update visible columns
            if len(self.column_paths) < self.max_visible_columns:
                self.scroll_offset = max(0, self.scroll_offset - 1)
                self.visible_columns = list(range(len(self.column_paths)))
    
    def get_visible_paths(self) -> List[Path]:
        """Get paths of currently visible columns."""
        return [self.column_paths[i] for i in self.visible_columns if i < len(self.column_paths)]
    
    def set_selected_item(self, column_path: Path, entry: Entry) -> None:
        """Set the selected item for a column."""
        self.selected_items[column_path] = entry
    
    def get_selected_item(self, column_path: Path) -> Optional[Entry]:
        """Get the selected item for a column."""
        return self.selected_items.get(column_path)
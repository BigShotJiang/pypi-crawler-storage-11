"""
State management for the TUI interface.
"""

from .navigation_state import NavigationState

__all__ = ["NavigationState"]
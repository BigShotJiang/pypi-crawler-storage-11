"""
Multi-column TUI file navigator for lumelab-jaci.
"""

import sys
from pathlib import Path

# Add src to path for standalone execution
if __name__ == "__main__" and "src" not in sys.path:
    sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from textual.app import App, ComposeResult
from textual.widgets import Static, Footer
from textual.containers import Vertical, Horizontal, HorizontalScroll
from textual.binding import Binding
from textual.reactive import reactive
from textual.screen import Screen

from ..models import Entry, Query, Order
from ..api import list as list_entries


class FileItem(Static):
    """Widget for displaying a file or directory."""
    
    def __init__(self, entry: Entry):
        self.entry = entry
        icon = "📁" if entry.is_dir else "📄"
        name = f"{icon} {entry.name}"
        super().__init__(name, classes="file-item")
        self.can_focus = True
    
    def on_click(self) -> None:
        """Handle file item click."""
        if self.entry.is_dir:
            self.app.add_column_for_directory(self.entry.path)
        else:
            self.app.notify(f"Selected file: {self.entry.path}")
    
    def on_enter(self) -> None:
        """Handle mouse enter."""
        self.add_class("hovered")
    
    def on_leave(self) -> None:
        """Handle mouse leave."""
        self.remove_class("hovered")
    
    def on_focus(self) -> None:
        """Handle focus."""
        self.add_class("focused")
    
    def on_blur(self) -> None:
        """Handle blur."""
        self.remove_class("focused")


class FileColumn(Vertical):
    """Column displaying directory contents."""
    
    def __init__(self, directory: Path, show_full_path: bool = False):
        self.directory = directory
        self.entries = []
        self.show_full_path = show_full_path
        super().__init__(classes="file-column")
    
    def compose(self) -> ComposeResult:
        """Compose column."""
        # Header
        if self.show_full_path:
            header_text = f"📁 {self.directory}"
        else:
            header_text = f"📁 {self.directory.name}"
        yield Static(header_text, classes="column-header")
        
        # Load entries and display them
        try:
            query = Query(include_hidden=False)
            order = Order(by="name", natural=True)
            raw_entries = list(list_entries(self.directory, query=query, order=order))
            
            # Extract Entry objects from EntryOrScored
            self.entries = []
            for item in raw_entries:
                if isinstance(item, tuple):
                    entry, score = item
                    self.entries.append(entry)
                else:
                    self.entries.append(item)
            
            # Show directories first, then files
            directories = [e for e in self.entries if e.is_dir]
            files = [e for e in self.entries if not e.is_dir]
            
            # Limit display for performance
            max_items = 50
            shown_dirs = directories[:max_items]
            shown_files = files[:max_items - len(shown_dirs)]
            
            for entry in shown_dirs:
                yield FileItem(entry)
            
            for entry in shown_files:
                yield FileItem(entry)
                
            # Show "more" message if needed
            total_items = len(self.entries)
            shown_items = len(shown_dirs) + len(shown_files)
            if total_items > shown_items:
                yield Static(f"... and {total_items - shown_items} more", classes="info-message")
                
        except Exception as e:
            yield Static(f"Error: {e}", classes="error-message")


class StatusBar(Static):
    """Status bar showing current path and navigation info."""
    
    def __init__(self):
        super().__init__("", id="status-bar")
    
    def update_path(self, path: Path) -> None:
        """Update displayed path."""
        self.update(f"📍 {path}")


class MultiColumnNavigatorApp(App):
    """Multi-column file navigator TUI app."""
    
    CSS = """
    HorizontalScroll {
        height: 1fr;
    }
    
    .file-column {
        width: 30;
        min-width: 25;
        max-width: 40;
        border: solid $primary;
        margin: 0 1 0 0;
        height: 100%;
    }
    
    .column-header {
        background: $primary;
        color: $text;
        padding: 0 1;
        height: 1;
        content-align: center middle;
        text-style: bold;
    }
    
    .file-item {
        padding: 0 1;
        height: 1;
    }
    
    .file-item:hover, .file-item.hovered {
        background: $secondary;
    }
    
    .file-item.focused {
        background: $accent;
        color: $text;
    }
    
    .current-column {
        border: solid $accent;
    }
    
    .error-message {
        color: $error;
        padding: 0 1;
        height: 1;
    }
    
    .info-message {
        color: $text-muted;
        padding: 0 1;
        height: 1;
        text-style: italic;
    }
    """
    
    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("ctrl+c", "quit", "Quit"),
        Binding("left", "go_back", "Go Back"),
        Binding("right", "go_forward", "Go Forward"),
        Binding("up", "navigate_up", "Navigate Up"),
        Binding("down", "navigate_down", "Navigate Down"),
        Binding("enter", "enter_directory", "Enter Directory"),
        Binding("r", "refresh", "Refresh"),
        Binding("tab", "next_column", "Next Column"),
        Binding("shift+tab", "prev_column", "Previous Column"),
    ]
    
    navigation_history: reactive[list[Path]] = reactive([])
    current_index: reactive[int] = reactive(0)
    
    def __init__(self, initial_path: Path = None):
        self.initial_path = initial_path or Path.cwd()
        super().__init__()
        self.navigation_history = [self.initial_path]
        self.current_index = 0
        self.columns = []  # Track all columns
    
    def compose(self) -> ComposeResult:
        """Compose app layout."""
        yield StatusBar()
        with HorizontalScroll(id="column-container"):
            yield FileColumn(self.initial_path, show_full_path=True)
        yield Footer()
    
    def on_mount(self) -> None:
        """Set initial focus when app is mounted."""
        # Focus first file item in first column
        container = self.query_one("#column-container", HorizontalScroll)
        if container.children:
            first_column = container.children[0]
            file_items = [child for child in first_column.children if isinstance(child, FileItem)]
            if file_items:
                file_items[0].focus()
                self.set_focus(file_items[0])
    
    def add_column_for_directory(self, path: Path) -> None:
        """Add a new column for the specified directory."""
        # Remove any columns after the current one
        container = self.query_one("#column-container", HorizontalScroll)
        
        # Remove columns to the right of current column
        current_column_index = self.current_index
        while len(container.children) > current_column_index + 1:
            container.children[-1].remove()
        
        # Add new column
        new_column = FileColumn(path, show_full_path=False)
        container.mount(new_column)
        
        # Update navigation history
        self.navigation_history = self.navigation_history[:self.current_index + 1]
        self.navigation_history.append(path)
        self.current_index = len(self.navigation_history) - 1
        
        # Focus first file item in new column
        file_items = [child for child in new_column.children if isinstance(child, FileItem)]
        if file_items:
            file_items[0].focus()
            self.set_focus(file_items[0])
        
        # Scroll to show the new column
        container.scroll_end()
        
        # Update status bar
        self.query_one(StatusBar).update_path(path)
    
    def navigate_to_directory(self, path: Path) -> None:
        """Navigate to a directory, adding to history."""
        # For now, delegate to add_column_for_directory
        self.add_column_for_directory(path)
    
    def action_go_back(self) -> None:
        """Go back in navigation history."""
        if self.current_index > 0:
            self.current_index -= 1
            self._refresh_columns()
    
    def action_go_forward(self) -> None:
        """Go forward in navigation history."""
        if self.current_index < len(self.navigation_history) - 1:
            self.current_index += 1
            self._refresh_columns()
    
    def action_refresh(self) -> None:
        """Refresh current directory."""
        self._refresh_columns()
    
    def action_navigate_up(self) -> None:
        """Navigate up in current column."""
        focused = self.focused
        if focused and isinstance(focused, FileItem):
            # Find previous FileItem in the same column
            parent = focused.parent
            if parent:
                file_items = [child for child in parent.children if isinstance(child, FileItem)]
                current_index = file_items.index(focused)
                if current_index > 0:
                    file_items[current_index - 1].focus()
    
    def action_navigate_down(self) -> None:
        """Navigate down in current column."""
        focused = self.focused
        if focused and isinstance(focused, FileItem):
            # Find next FileItem in the same column
            parent = focused.parent
            if parent:
                file_items = [child for child in parent.children if isinstance(child, FileItem)]
                current_index = file_items.index(focused)
                if current_index < len(file_items) - 1:
                    file_items[current_index + 1].focus()
    
    def action_enter_directory(self) -> None:
        """Enter selected directory."""
        focused = self.focused
        if focused and isinstance(focused, FileItem) and focused.entry.is_dir:
            self.add_column_for_directory(focused.entry.path)
    
    def action_next_column(self) -> None:
        """Navigate to next column."""
        container = self.query_one("#column-container", HorizontalScroll)
        columns = [child for child in container.children if isinstance(child, FileColumn)]
        
        focused = self.focused
        if focused:
            current_column = focused.parent
            if current_column and current_column in columns:
                current_index = columns.index(current_column)
                if current_index < len(columns) - 1:
                    # Focus first file item in next column
                    next_column = columns[current_index + 1]
                    file_items = [child for child in next_column.children if isinstance(child, FileItem)]
                    if file_items:
                        file_items[0].focus()
    
    def action_prev_column(self) -> None:
        """Navigate to previous column."""
        container = self.query_one("#column-container", HorizontalScroll)
        columns = [child for child in container.children if isinstance(child, FileColumn)]
        
        focused = self.focused
        if focused:
            current_column = focused.parent
            if current_column and current_column in columns:
                current_index = columns.index(current_column)
                if current_index > 0:
                    # Focus first file item in previous column
                    prev_column = columns[current_index - 1]
                    file_items = [child for child in prev_column.children if isinstance(child, FileItem)]
                    if file_items:
                        file_items[0].focus()
    
    def _refresh_columns(self) -> None:
        """Refresh all columns based on navigation history."""
        container = self.query_one("#column-container", HorizontalScroll)
        container.remove_children()
        
        # Show up to 5 columns: current + 4 previous directories
        start_index = max(0, self.current_index - 4)
        end_index = self.current_index + 1
        
        for i in range(start_index, end_index):
            path = self.navigation_history[i]
            is_current = (i == self.current_index)
            show_full = (i == 0)  # Show full path for first column
            column = FileColumn(path, show_full_path=show_full)
            
            if is_current:
                column.add_class("current-column")
            
            container.mount(column)
        
        # Update status bar
        current_path = self.navigation_history[self.current_index]
        self.query_one(StatusBar).update_path(current_path)
        
        # Scroll to show current column
        container.scroll_end()


def main():
    """Entry point for the TUI application."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Lumelab Jaci TUI File Navigator")
    parser.add_argument("path", nargs="?", default=Path.cwd(), 
                       help="Initial directory path (default: current directory)")
    
    args = parser.parse_args()
    initial_path = Path(args.path).resolve()
    
    if not initial_path.exists():
        print(f"Error: Path '{initial_path}' does not exist")
        sys.exit(1)
    
    if not initial_path.is_dir():
        print(f"Error: Path '{initial_path}' is not a directory")
        sys.exit(1)
    
    app = MultiColumnNavigatorApp(initial_path)
    app.run()


if __name__ == "__main__":
    main()
"""
TUI (Terminal User Interface) for lumelab-jaci file navigator.

This module provides a Textual-based interface similar to macOS Finder,
with column-based navigation and integration with lumelab-jaci core functionality.
"""

from .app import FileNavigatorApp

__all__ = ["FileNavigatorApp"]
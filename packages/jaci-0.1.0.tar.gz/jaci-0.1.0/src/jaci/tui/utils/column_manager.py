"""
Utility for managing column operations and navigation logic.
"""

from pathlib import Path
from typing import List, Optional

from ..state.navigation_state import NavigationState


class ColumnManager:
    """Manages column creation, removal, and navigation logic."""
    
    def __init__(self, max_visible_columns: int = 5):
        self.max_visible_columns = max_visible_columns
    
    def should_create_column(self, state: NavigationState, new_path: Path) -> bool:
        """Determine if a new column should be created."""
        # Don't create column for the same path
        if state.column_paths and state.column_paths[-1] == new_path:
            return False
        
        # Don't create column if going back to parent
        if len(state.column_paths) > 1:
            parent = state.column_paths[-2]
            if new_path == parent:
                return False
        
        return True
    
    def handle_backspace(self, state: NavigationState) -> Optional[Path]:
        """Handle backspace key to go back."""
        if len(state.column_paths) > 1:
            # Remove last column and return to previous
            state.remove_last_column()
            return state.column_paths[-1] if state.column_paths else None
        return None
    
    def get_navigation_path(self, state: NavigationState) -> Path:
        """Get the current navigation path."""
        return state.column_paths[-1] if state.column_paths else state.current_path
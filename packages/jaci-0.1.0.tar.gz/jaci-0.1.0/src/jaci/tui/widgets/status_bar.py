"""
Status bar widget for displaying information about current state.
"""

from textual.widgets import Static
from textual.reactive import reactive
from pathlib import Path


class StatusBar(Static):
    """Status bar showing current directory and item count."""
    
    current_path: reactive[Path] = reactive(Path.cwd())
    item_count: reactive[int] = reactive(0)
    selected_count: reactive[int] = reactive(0)
    
    def __init__(self):
        super().__init__("", id="status-bar")
    
    def render(self) -> str:
        """Render status bar content."""
        path_str = str(self.current_path)
        
        # Truncate long paths
        if len(path_str) > 50:
            path_str = "..." + path_str[-47:]
        
        status = f"📍 {path_str}"
        
        if self.item_count > 0:
            status += f" | 📁 {self.item_count} items"
        
        if self.selected_count > 0:
            status += f" | ✅ {self.selected_count} selected"
        
        return status
    
    def update_path(self, path: Path) -> None:
        """Update current path."""
        self.current_path = path
    
    def update_counts(self, item_count: int, selected_count: int = 0) -> None:
        """Update item and selection counts."""
        self.item_count = item_count
        self.selected_count = selected_count
"""
File item widget for displaying entries in navigation columns.
"""

from textual.widgets import Button
from textual.reactive import reactive

from ...models import Entry


class FileItem(Button):
    """Widget representing a file or directory entry."""
    
    entry: reactive[Entry] = reactive(None)
    
    def __init__(self, entry: Entry):
        self.entry = entry
        # Choose icon based on entry type
        icon = "📁" if entry.is_dir else "📄"
        label = f"{icon} {entry.name}"
        
        super().__init__(label, id=f"file-item-{entry.name}")
    
    def render(self) -> str:
        """Render the file item with appropriate styling."""
        if not self.entry:
            return ""
        
        # Base icon
        icon = "📁" if self.entry.is_dir else "📄"
        
        # Add size info for files
        if self.entry.is_file and self.entry.size > 0:
            size_str = self._format_size(self.entry.size)
            return f"{icon} {self.entry.name:<30} {size_str:>8}"
        
        return f"{icon} {self.entry.name}"
    
    def _format_size(self, size_bytes: int) -> str:
        """Format file size in human readable format."""
        if size_bytes < 1024:
            return f"{size_bytes}B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes // 1024}K"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{size_bytes // (1024 * 1024)}M"
        else:
            return f"{size_bytes // (1024 * 1024 * 1024)}G"
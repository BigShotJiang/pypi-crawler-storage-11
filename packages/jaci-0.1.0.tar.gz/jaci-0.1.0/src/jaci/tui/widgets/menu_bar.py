"""
Menu bar widget for the TUI interface.
"""

from textual.containers import Horizontal
from textual.widgets import Button
from textual.message import Message


class MenuBar(Horizontal):
    """Top menu bar with File, Edit, and Config menus."""
    
    class MenuPressed(Message):
        """Message emitted when a menu is pressed."""
        
        def __init__(self, menu_name: str) -> None:
            self.menu_name = menu_name
            super().__init__()
    
    def compose(self):
        """Compose the menu bar."""
        yield Button("File (F1)", id="file-menu", name="file")
        yield Button("Edit (F2)", id="edit-menu", name="edit")
        yield Button("Config (F3)", id="config-menu", name="config")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        button = event.button
        menu_name = button.name
        
        # Emit message for the app to handle
        self.post_message(self.MenuPressed(menu_name))
        
        # Update visual state
        self._highlight_menu(menu_name)
    
    def _highlight_menu(self, menu_name: str) -> None:
        """Highlight the active menu."""
        # Remove highlight from all menus
        for button in self.query("Button"):
            button.remove_class("active")
        
        # Add highlight to active menu
        active_button = self.query_one(f"#{menu_name}-menu")
        active_button.add_class("active")
"""
Main TUI application for lumelab-jaci file navigator.
"""

from textual.app import App, ComposeResult
from textual.binding import Binding
from pathlib import Path

from .widgets.menu_bar import MenuBar
from .widgets.status_bar import StatusBar
from .containers.column_container import ColumnContainer
from .styles.styles import STYLES


class FileNavigatorApp(App):
    """Main application class for the file navigator TUI."""
    
    CSS_PATH = STYLES
    TITLE = "Jaci File Navigator"
    
    BINDINGS = [
        Binding("f1", "file_menu", "File Menu"),
        Binding("f2", "edit_menu", "Edit Menu"),
        Binding("f3", "config_menu", "Config Menu"),
        Binding("q", "quit", "Quit"),
        Binding("ctrl+c", "quit", "Quit"),
    ]
    
    def __init__(self, initial_path: Path = None):
        self.initial_path = initial_path or Path.cwd()
        super().__init__()
    
    def compose(self) -> ComposeResult:
        """Compose the application layout."""
        yield MenuBar()
        yield ColumnContainer(self.initial_path)
        yield StatusBar()
    
    def on_mount(self) -> None:
        """Initialize application after mounting."""
        # Set initial status
        status_bar = self.query_one("#status-bar", StatusBar)
        status_bar.update_path(self.initial_path)
    
    def action_file_menu(self) -> None:
        """Handle File menu activation."""
        menu_bar = self.query_one(MenuBar)
        menu_bar._highlight_menu("file")
        self._show_file_menu_actions()
    
    def action_edit_menu(self) -> None:
        """Handle Edit menu activation."""
        menu_bar = self.query_one(MenuBar)
        menu_bar._highlight_menu("edit")
        self._show_edit_menu_actions()
    
    def action_config_menu(self) -> None:
        """Handle Config menu activation."""
        menu_bar = self.query_one(MenuBar)
        menu_bar._highlight_menu("config")
        self._show_config_menu_actions()
    
    def _show_file_menu_actions(self) -> None:
        """Show File menu actions."""
        # TODO: Implement File menu dropdown
        self.notify("File menu: New Folder, Open, Copy, Delete, Properties, Refresh, Exit")
    
    def _show_edit_menu_actions(self) -> None:
        """Show Edit menu actions."""
        # TODO: Implement Edit menu dropdown
        self.notify("Edit menu: Search, Filter, Sort, Select All")
    
    def _show_config_menu_actions(self) -> None:
        """Show Config menu actions."""
        # TODO: Implement Config menu dropdown
        self.notify("Config menu: Preferences, Hidden Files, Sandbox, Capabilities")
    
    def on_menu_bar_menu_pressed(self, event) -> None:
        """Handle menu bar button presses."""
        if event.menu_name == "file":
            self._show_file_menu_actions()
        elif event.menu_name == "edit":
            self._show_edit_menu_actions()
        elif event.menu_name == "config":
            self._show_config_menu_actions()


if __name__ == "__main__":
    app = FileNavigatorApp()
    app.run()
"""
Styles package for lumelab-jaci TUI.
"""
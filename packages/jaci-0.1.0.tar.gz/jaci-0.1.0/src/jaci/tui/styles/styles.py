"""
CSS styles for lumelab-jaci TUI.
"""

STYLES = """
/* Main application styles */
Screen {
    background: $background;
}

/* Status bar */
#status-bar {
    background: $panel;
    color: $text;
    padding: 0 1;
    height: 1;
    text-style: bold;
}

/* Column container */
#column-container {
    height: 1fr;
}

/* File columns */
.file-column {
    width: 30;
    min-width: 25;
    max-width: 40;
    border: solid $primary;
    margin: 0 1 0 0;
    height: 100%;
}

.current-column {
    border-style: double;
    border-color: $accent;
}

/* Column headers */
.column-header {
    background: $primary;
    color: $text;
    padding: 0 1;
    height: 1;
    content-align: center middle;
    text-style: bold;
}

/* File items */
.file-item {
    padding: 0 1;
    height: 1;
}

.file-item:hover {
    background: $secondary;
}

.file-item.selected {
    background: $accent;
    color: $background;
}

/* Messages */
.error-message {
    color: $error;
    padding: 0 1;
    height: 1;
}

.info-message {
    color: $text-muted;
    padding: 0 1;
    height: 1;
    text-style: italic;
}

/* Menu bar */
.menu-bar {
    height: 1;
    background: $panel;
    dock: top;
}

.menu-button {
    padding: 0 1;
    height: 1;
    text-style: bold;
}

.menu-button:hover {
    background: $secondary;
}

.menu-button.active {
    background: $primary;
    color: $text;
}
"""
"""
Column container for managing navigation columns with horizontal scrolling.
"""

from textual.containers import HorizontalScroll
from textual.reactive import reactive
from pathlib import Path
from typing import List, Optional

from ..state.navigation_state import NavigationState
from .navigation_column import NavigationColumn


class ColumnContainer(HorizontalScroll):
    """Container managing navigation columns with 5-column limit."""
    
    navigation_state: reactive[NavigationState] = reactive(None)
    columns: reactive[List[NavigationColumn]] = reactive([])
    
    def __init__(self, initial_path: Path):
        self.navigation_state = NavigationState(current_path=initial_path)
        super().__init__(id="column-container")
        self._initialize_columns()
    
    def _initialize_columns(self) -> None:
        """Initialize with the first column."""
        initial_path = self.navigation_state.current_path
        self.navigation_state.add_column(initial_path)
        self._refresh_columns()
    
    def compose(self):
        """Compose visible columns."""
        for column in self.columns:
            yield column
    
    def add_column(self, path: Path) -> None:
        """Add a new column for the given path."""
        self.navigation_state.add_column(path)
        self._refresh_columns()
        
        # Scroll to show the new column
        self.scroll_end()
    
    def remove_last_column(self) -> None:
        """Remove the last column."""
        self.navigation_state.remove_last_column()
        self._refresh_columns()
    
    def _refresh_columns(self) -> None:
        """Refresh the columns based on navigation state."""
        visible_paths = self.navigation_state.get_visible_paths()
        
        # Clear existing columns
        self.columns.clear()
        self.remove_children()
        
        # Create new columns for visible paths
        for path in visible_paths:
            column = NavigationColumn(path)
            self.columns.append(column)
            self.mount(column)
    
    def on_navigation_column_directory_selected(self, event) -> None:
        """Handle directory selection from a column."""
        self.add_column(event.path)
    
    def watch_navigation_state(self, state: NavigationState) -> None:
        """React to navigation state changes."""
        self._refresh_columns()
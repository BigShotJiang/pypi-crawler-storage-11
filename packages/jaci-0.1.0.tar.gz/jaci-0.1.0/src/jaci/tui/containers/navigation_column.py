"""
Navigation column widget for displaying directory contents.
"""

from textual.containers import VerticalScroll
from textual.widgets import Static
from textual.reactive import reactive
from pathlib import Path
from typing import List, Optional

from ...models import Entry, Query, Order
from ..widgets.file_item import FileItem


class NavigationColumn(VerticalScroll):
    """Column displaying contents of a directory."""
    
    directory: reactive[Path] = reactive(Path.cwd())
    entries: reactive[List[Entry]] = reactive([])
    selected_entry: reactive[Optional[Entry]] = reactive(None)
    
    def __init__(self, directory: Path):
        self.directory = directory
        super().__init__(id=f"column-{directory.name}")
        self.load_entries()
    
    def compose(self):
        """Compose column with header and file items."""
        # Column header
        yield Static(f"📁 {self.directory.name}", classes="column-header")
        
        # File items
        for entry in self.entries:
            yield FileItem(entry)
    
    def load_entries(self) -> None:
        """Load entries from directory using lumelab-jaci."""
        try:
            # Import here to avoid circular imports
            from ...api import list as list_entries
            
            # Create query for this directory
            query = Query(include_hidden=False)
            order = Order(by="name", natural=True)
            
            # Load entries
            self.entries = list(list_entries(self.directory, query=query, order=order))
            
        except Exception as e:
            # Handle errors gracefully
            self.entries = []
            print(f"Error loading directory {self.directory}: {e}")
    
    def watch_directory(self, directory: Path) -> None:
        """React to directory changes."""
        self.load_entries()
    
    def on_file_item_pressed(self, event: FileItem.Pressed) -> None:
        """Handle file item selection."""
        file_item = event.button
        self.selected_entry = file_item.entry
        
        # Update visual selection
        for item in self.query("FileItem"):
            item.remove_class("selected")
        file_item.add_class("selected")
        
        # If it's a directory, notify parent to create new column
        if file_item.entry.is_dir:
            self.post_message(self.DirectorySelected(file_item.entry.path))
    
    class DirectorySelected:
        """Message emitted when a directory is selected."""
        
        def __init__(self, path: Path) -> None:
            self.path = path
            super().__init__()
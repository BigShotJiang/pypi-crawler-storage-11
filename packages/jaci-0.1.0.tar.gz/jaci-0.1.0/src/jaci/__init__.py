"""
jaci: A fast, extensible file system navigation library.

This library provides a stable, fast, and extensible API for navigating,
filtering, searching, and watching local file systems (and remote via extras).

Core functionality requires only Python standard library. Optional features
are available through extras: ignore, fuzzy, watch, mime, remotes.

Main operations:
- list(): Stream directory contents with pagination
- search(): Search files with relevance ranking
- stat(): Get file/directory metadata
- watch(): Monitor file system events
- resolve(): Safe path resolution with sandboxing
- capabilities(): Check available features
"""

from __future__ import annotations

__version__ = "0.1.0"

# Try to import core components
try:
    from .models import Entry, Query, Order, FuzzySpec, SelectionMode

    _models_available = True
except ImportError:
    _models_available = False

try:
    from .exceptions import (
        JaciError,
        SandboxViolationError,
        SymlinkLoopError,
        ProviderUnavailableError,
        PermissionDeniedError,
        PathNotFoundError,
        UnsupportedOperationError,
    )

    _exceptions_available = True
except ImportError:
    _exceptions_available = False

try:
    from .api import (
        list,
        search,
        stat,
        watch,
        resolve,
        capabilities,
        probe,
        clear_cache,
    )

    _api_available = True
except ImportError:
    _api_available = False

# Define what's available based on successful imports
__all__ = [
    "__version__",
]

if _models_available:
    __all__.extend(
        [
            "Entry",
            "Query",
            "Order",
            "FuzzySpec",
            "SelectionMode",
        ]
    )

if _exceptions_available:
    __all__.extend(
        [
            "JaciError",
            "SandboxViolationError",
            "SymlinkLoopError",
            "ProviderUnavailableError",
            "PermissionDeniedError",
            "PathNotFoundError",
            "UnsupportedOperationError",
        ]
    )

if _api_available:
    __all__.extend(
        [
            "list",
            "search",
            "stat",
            "watch",
            "resolve",
            "capabilities",
            "probe",
            "clear_cache",
        ]
    )

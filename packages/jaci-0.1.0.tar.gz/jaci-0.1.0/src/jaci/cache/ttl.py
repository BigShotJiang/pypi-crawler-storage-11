"""
TTL-based caching implementation.

This module provides time-based caching with automatic expiration
and size limits for directory listings and metadata.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Tuple

if TYPE_CHECKING:
    from ..models import Entry

# Runtime import
from ..models import Entry

try:
    from ..utils.logging import get_logger
except ImportError:
    import logging

    def get_logger(name: str = "lumelab.jaci"):
        return logging.getLogger(name)


class CacheEntry:
    """Single cache entry with TTL support."""

    def __init__(self, value: Any, ttl_seconds: float) -> None:
        """
        Initialize cache entry.

        Args:
            value: Value to cache
            ttl_seconds: Time-to-live in seconds
        """
        self.value = value
        self.expires_at = time.time() + ttl_seconds

    def is_expired(self) -> bool:
        """Check if this cache entry has expired."""
        return time.time() > self.expires_at

    def refresh(self, ttl_seconds: float) -> None:
        """Refresh expiration time."""
        self.expires_at = time.time() + ttl_seconds


class TTLCache:
    """
    Generic TTL-based cache with size limits.

    This cache automatically expires entries and maintains a maximum
    size to prevent memory issues.
    """

    def __init__(self, max_size: int = 1000, default_ttl: float = 300.0) -> None:
        """
        Initialize TTL cache.

        Args:
            max_size: Maximum number of entries to cache
            default_ttl: Default TTL in seconds
        """
        self.max_size = max_size
        self.default_ttl = default_ttl
        self._cache: Dict[str, CacheEntry] = {}
        self._logger = get_logger()

    def get(self, key: str) -> Optional[Any]:
        """
        Get a value from cache.

        Args:
            key: Cache key

        Returns:
            Cached value or None if not found/expired
        """
        entry = self._cache.get(key)

        if entry is None:
            return None

        if entry.is_expired():
            del self._cache[key]
            self._logger.debug(f"Cache entry expired: {key}")
            return None

        return entry.value

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """
        Set a value in cache.

        Args:
            key: Cache key
            value: Value to cache
            ttl: Custom TTL (uses default if None)
        """
        ttl = ttl or self.default_ttl

        # Remove expired entries if cache is full
        if len(self._cache) >= self.max_size:
            self._cleanup_expired()

        # If still full, remove oldest entry
        if len(self._cache) >= self.max_size:
            oldest_key = next(iter(self._cache))
            del self._cache[oldest_key]
            self._logger.debug(f"Evicted oldest cache entry: {oldest_key}")

        self._cache[key] = CacheEntry(value, ttl)
        self._logger.debug(f"Cached entry: {key} (TTL: {ttl}s)")

    def delete(self, key: str) -> bool:
        """
        Delete a specific cache entry.

        Args:
            key: Cache key to delete

        Returns:
            True if entry was deleted, False if not found
        """
        if key in self._cache:
            del self._cache[key]
            self._logger.debug(f"Deleted cache entry: {key}")
            return True
        return False

    def clear(self) -> None:
        """Clear all cache entries."""
        count = len(self._cache)
        self._cache.clear()
        self._logger.debug(f"Cleared {count} cache entries")

    def _cleanup_expired(self) -> int:
        """
        Remove all expired entries from cache.

        Returns:
            Number of entries removed
        """
        expired_keys = [key for key, entry in self._cache.items() if entry.is_expired()]

        for key in expired_keys:
            del self._cache[key]

        if expired_keys:
            self._logger.debug(f"Cleaned up {len(expired_keys)} expired cache entries")

        return len(expired_keys)

    def size(self) -> int:
        """Get current number of entries in cache."""
        return len(self._cache)

    def stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            "size": len(self._cache),
            "max_size": self.max_size,
            "default_ttl": self.default_ttl,
        }


class DirectoryCache:
    """
    Specialized cache for directory listings and metadata.

    This cache provides intelligent invalidation based on directory
    modification times and supports both full listings and individual
    entry metadata.
    """

    def __init__(self, ttl_seconds: float = 300.0, max_entries: int = 1000) -> None:
        """
        Initialize directory cache.

        Args:
            ttl_seconds: Default TTL for cached entries
            max_entries: Maximum number of directories to cache
        """
        self.ttl_seconds = ttl_seconds
        self.max_entries = max_entries
        self._cache = TTLCache(max_entries, ttl_seconds)
        self._logger = get_logger()

    def get_directory_listing(self, directory: Path) -> Optional[List[Entry]]:
        """
        Get cached directory listing.

        Args:
            directory: Directory path

        Returns:
            List of entries or None if not cached/expired
        """
        key = f"listing:{directory}"
        return self._cache.get(key)

    def set_directory_listing(self, directory: Path, entries: List[Entry]) -> None:
        """
        Cache directory listing.

        Args:
            directory: Directory path
            entries: List of directory entries
        """
        key = f"listing:{directory}"
        self._cache.set(key, entries, self.ttl_seconds)
        self._logger.debug(f"Cached listing for {directory}: {len(entries)} entries")

    def get_entry_metadata(self, path: Path) -> Optional[Entry]:
        """
        Get cached entry metadata.

        Args:
            path: Entry path

        Returns:
            Entry metadata or None if not cached/expired
        """
        key = f"entry:{path}"
        return self._cache.get(key)

    def set_entry_metadata(self, entry: Entry) -> None:
        """
        Cache entry metadata.

        Args:
            entry: Entry to cache
        """
        key = f"entry:{getattr(entry, 'path', 'unknown')}"
        self._cache.set(key, entry, self.ttl_seconds)
        self._logger.debug(f"Cached metadata for {getattr(entry, 'path', 'unknown')}")

    def invalidate_directory(self, directory: Path) -> int:
        """
        Invalidate all cached data for a directory.

        Args:
            directory: Directory to invalidate

        Returns:
            Number of cache entries invalidated
        """
        dir_str = str(directory)
        keys_to_delete = []

        for key in self._cache._cache.keys():
            if key.startswith(f"listing:{dir_str}") or key.startswith(
                f"entry:{dir_str}"
            ):
                keys_to_delete.append(key)
            elif key.startswith(f"entry:{dir_str}/"):
                keys_to_delete.append(key)

        for key in keys_to_delete:
            self._cache.delete(key)

        if keys_to_delete:
            self._logger.debug(
                f"Invalidated {len(keys_to_delete)} cache entries for {directory}"
            )

        return len(keys_to_delete)

    def invalidate_path(self, path: Path) -> bool:
        """
        Invalidate cached data for a specific path.

        Args:
            path: Path to invalidate

        Returns:
            True if entry was invalidated, False if not found
        """
        # Invalidate entry metadata
        entry_key = f"entry:{path}"
        entry_invalidated = self._cache.delete(entry_key)

        # Invalidate parent directory listing
        parent = path.parent
        listing_key = f"listing:{parent}"
        listing_invalidated = self._cache.delete(listing_key)

        if entry_invalidated or listing_invalidated:
            self._logger.debug(f"Invalidated cache for {path}")

        return entry_invalidated or listing_invalidated

    def clear(self) -> None:
        """Clear all cached data."""
        self._cache.clear()
        self._logger.debug("Cleared directory cache")

    def stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        stats = self._cache.stats()
        stats.update(
            {
                "ttl_seconds": self.ttl_seconds,
                "type": "directory",
            }
        )
        return stats


# Global cache instance for the application
_global_cache: Optional[DirectoryCache] = None


def get_cache() -> DirectoryCache:
    """
    Get the global directory cache instance.

    Returns:
        Global DirectoryCache instance
    """
    global _global_cache
    if _global_cache is None:
        _global_cache = DirectoryCache()
    return _global_cache


def clear_cache() -> None:
    """Clear the global directory cache."""
    global _global_cache
    if _global_cache is not None:
        _global_cache.clear()

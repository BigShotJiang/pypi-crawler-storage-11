"""
File system watching functionality for lumelab-jaci.

This extra provides file system event monitoring with configurable
backends (watchfiles or watchdog) and debouncing.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Iterable, Optional, Set, Dict, Any, Callable
from dataclasses import dataclass

# Try to import watchfiles first (preferred)
try:
    from watchfiles import awatch, watch
    _WATCHFILES_AVAILABLE = True
except ImportError:
    _WATCHFILES_AVAILABLE = False

# Fallback to watchdog
try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler, FileSystemEvent
    _WATCHDOG_AVAILABLE = True
except ImportError:
    _WATCHDOG_AVAILABLE = False
    # Create dummy classes for type checking
    class Observer:
        def __init__(self):
            pass
        def schedule(self, handler, path, recursive=True):
            pass
        def start(self):
            pass
        def stop(self):
            pass
        def is_alive(self):
            return False
        def join(self):
            pass
    
    class FileSystemEventHandler:
        pass
    
    class FileSystemEvent:
        def __init__(self, src_path):
            self.src_path = src_path
            self.is_directory = False


@dataclass
class FileEvent:
    """
    File system event from watching operations.
    
    Represents a change to a file or directory with metadata.
    """
    
    # Event type
    event_type: str  # created|deleted|modified|moved
    
    # The path that changed
    path: Path
    
    # Timestamp of the event
    timestamp: float
    
    # For move events, the destination path
    destination: Optional[Path] = None
    
    # Whether the path is a directory
    is_dir: bool = False
    
    def __post_init__(self) -> None:
        valid_events = {"created", "deleted", "modified", "moved"}
        if self.event_type not in valid_events:
            raise ValueError(f"Invalid event type: {self.event_type}. Must be one of {valid_events}")


class Debouncer:
    """
    Event debouncer to reduce noise from rapid file changes.
    
    Groups multiple events for the same file within a time window.
    """
    
    def __init__(self, debounce_ms: int = 100):
        """
        Initialize debouncer.
        
        Args:
            debounce_ms: Debounce time in milliseconds
        """
        self.debounce_ms = debounce_ms
        self.pending_events: Dict[str, FileEvent] = {}
        self.last_flush = time.time()
    
    def add_event(self, event: FileEvent) -> Optional[FileEvent]:
        """
        Add an event to the debouncer.
        
        Args:
            event: File event to add
            
        Returns:
            Event if ready to emit, None if debounced
        """
        now = time.time()
        key = str(event.path)
        
        # Update pending event
        self.pending_events[key] = event
        
        # Check if ready to flush
        if now - self.last_flush >= (self.debounce_ms / 1000.0):
            return self.flush()
        
        return None
    
    def flush(self) -> Optional[FileEvent]:
        """
        Flush all pending events.
        
        Returns:
            Latest event for each unique path, or None if no pending events
        """
        if not self.pending_events:
            return None
        
        # Get the latest event for each path
        events = list(self.pending_events.values())
        self.pending_events.clear()
        self.last_flush = time.time()
        
        # Return events one by one (caller should call repeatedly)
        if events:
            event = events[0]  # Return first event, rest will be returned on subsequent calls
            return event
        
        return None
    
    def has_pending(self) -> bool:
        """Check if there are pending events."""
        return bool(self.pending_events)


class WatchBackend:
    """Abstract base class for watch backends."""
    
    def watch(
        self,
        path: Path,
        recursive: bool = True,
        event_handler: Optional[Callable[[FileEvent], None]] = None
    ) -> Iterable[FileEvent]:
        """
        Watch a path for file system events.
        
        Args:
            path: Path to watch
            recursive: Whether to watch subdirectories
            event_handler: Optional callback for events
            
        Yields:
            FileEvent objects as they occur
        """
        raise NotImplementedError


class WatchfilesBackend(WatchBackend):
    """Watch backend using watchfiles library."""
    
    def __init__(self):
        if not _WATCHFILES_AVAILABLE:
            raise ImportError("watchfiles is not available")
    
    def watch(
        self,
        path: Path,
        recursive: bool = True,
        event_handler: Optional[Callable[[FileEvent], None]] = None
    ) -> Iterable[FileEvent]:
        """Watch path using watchfiles."""
        for changes in watch(path, recursive=recursive):
            for change_type, change_path in changes:
                event_type = self._convert_change_type(change_type)
                if event_type:
                    event = FileEvent(
                        event_type=event_type,
                        path=Path(change_path),
                        timestamp=time.time(),
                        is_dir=Path(change_path).is_dir()
                    )
                    
                    if event_handler:
                        event_handler(event)
                    
                    yield event
    
    def _convert_change_type(self, change_type: int) -> Optional[str]:
        """Convert watchfiles change type to event type."""
        if change_type == 1:  # added
            return "created"
        elif change_type == 2:  # modified
            return "modified"
        elif change_type == 3:  # deleted
            return "deleted"
        else:
            return None


class WatchdogBackend(WatchBackend):
    """Watch backend using watchdog library."""
    
    def __init__(self):
        if not _WATCHDOG_AVAILABLE:
            raise ImportError("watchdog is not available")
        
        self.observer = Observer()
        self.events: list[FileEvent] = []
    
    def watch(
        self,
        path: Path,
        recursive: bool = True,
        event_handler: Optional[Callable[[FileEvent], None]] = None
    ) -> Iterable[FileEvent]:
        """Watch path using watchdog."""
        handler = _WatchdogEventHandler(self.events, event_handler)
        self.observer.schedule(handler, str(path), recursive=recursive)
        self.observer.start()
        
        try:
            while True:
                if self.events:
                    event = self.events.pop(0)
                    yield event
                else:
                    time.sleep(0.1)  # Small delay to prevent busy waiting
        except KeyboardInterrupt:
            self.observer.stop()
        
        self.observer.join()
    
    def __del__(self):
        """Cleanup observer on deletion."""
        if hasattr(self, 'observer') and self.observer.is_alive():
            self.observer.stop()


class _WatchdogEventHandler(FileSystemEventHandler):
    """Event handler for watchdog backend."""
    
    def __init__(self, events: list[FileEvent], event_handler: Optional[Callable[[FileEvent], None]]):
        self.events = events
        self.event_handler = event_handler
    
    def on_created(self, event: FileSystemEvent):
        self._handle_event(event, "created")
    
    def on_deleted(self, event: FileSystemEvent):
        self._handle_event(event, "deleted")
    
    def on_modified(self, event: FileSystemEvent):
        self._handle_event(event, "modified")
    
    def on_moved(self, event: FileSystemEvent):
        file_event = FileEvent(
            event_type="moved",
            path=Path(event.src_path),
            timestamp=time.time(),
            destination=Path(event.dest_path) if hasattr(event, 'dest_path') else None,
            is_dir=event.is_directory
        )
        
        self.events.append(file_event)
        if self.event_handler:
            self.event_handler(file_event)
    
    def _handle_event(self, event: FileSystemEvent, event_type: str):
        """Handle a watchdog event."""
        file_event = FileEvent(
            event_type=event_type,
            path=Path(event.src_path),
            timestamp=time.time(),
            is_dir=event.is_directory
        )
        
        self.events.append(file_event)
        if self.event_handler:
            self.event_handler(file_event)


class FileWatcher:
    """
    High-level file system watcher with backend selection and debouncing.
    
    Provides a unified interface for watching file system changes.
    """
    
    def __init__(
        self,
        backend: Optional[str] = None,
        debounce_ms: int = 100,
        event_handler: Optional[Callable[[FileEvent], None]] = None
    ):
        """
        Initialize file watcher.
        
        Args:
            backend: Backend to use ('watchfiles', 'watchdog', or None for auto)
            debounce_ms: Debounce time in milliseconds
            event_handler: Optional callback for events
        """
        self.debounce_ms = debounce_ms
        self.event_handler = event_handler
        self.debouncer = Debouncer(debounce_ms)
        
        # Select backend
        self.backend = self._select_backend(backend)
    
    def _select_backend(self, backend: Optional[str]) -> WatchBackend:
        """Select appropriate watch backend."""
        if backend == "watchfiles":
            return WatchfilesBackend()
        elif backend == "watchdog":
            return WatchdogBackend()
        elif backend is None:
            # Auto-select: prefer watchfiles, fallback to watchdog
            if _WATCHFILES_AVAILABLE:
                return WatchfilesBackend()
            elif _WATCHDOG_AVAILABLE:
                return WatchdogBackend()
            else:
                raise ImportError("No watch backend available. Install 'watchfiles' or 'watchdog'.")
        else:
            raise ValueError(f"Unknown backend: {backend}. Use 'watchfiles', 'watchdog', or None.")
    
    def watch(
        self,
        path: Path,
        recursive: bool = True,
        filter_func: Optional[Callable[[FileEvent], bool]] = None
    ) -> Iterable[FileEvent]:
        """
        Watch a path for file system events.
        
        Args:
            path: Path to watch
            recursive: Whether to watch subdirectories
            filter_func: Optional filter function for events
            
        Yields:
            FileEvent objects as they occur
        """
        for raw_event in self.backend.watch(path, recursive):
            # Apply filtering
            if filter_func and not filter_func(raw_event):
                continue
            
            # Apply debouncing
            debounced_event = self.debouncer.add_event(raw_event)
            if debounced_event:
                yield debounced_event
        
        # Flush any remaining events
        while self.debouncer.has_pending():
            final_event = self.debouncer.flush()
            if final_event and (not filter_func or filter_func(final_event)):
                yield final_event
    
    @property
    def backend_name(self) -> str:
        """Get the name of the backend being used."""
        if isinstance(self.backend, WatchfilesBackend):
            return "watchfiles"
        elif isinstance(self.backend, WatchdogBackend):
            return "watchdog"
        else:
            return "unknown"
    
    @property
    def is_available(self) -> bool:
        """Check if any watch backend is available."""
        return _WATCHFILES_AVAILABLE or _WATCHDOG_AVAILABLE


def create_watcher(
    backend: Optional[str] = None,
    debounce_ms: int = 100,
    event_handler: Optional[Callable[[FileEvent], None]] = None
) -> FileWatcher:
    """
    Create a file watcher with common configurations.
    
    Args:
        backend: Backend to use
        debounce_ms: Debounce time in milliseconds
        event_handler: Optional event callback
        
    Returns:
        Configured FileWatcher instance
    """
    return FileWatcher(
        backend=backend,
        debounce_ms=debounce_ms,
        event_handler=event_handler
    )


def get_available_backends() -> Set[str]:
    """Get set of available watch backends."""
    backends = set()
    if _WATCHFILES_AVAILABLE:
        backends.add("watchfiles")
    if _WATCHDOG_AVAILABLE:
        backends.add("watchdog")
    return backends
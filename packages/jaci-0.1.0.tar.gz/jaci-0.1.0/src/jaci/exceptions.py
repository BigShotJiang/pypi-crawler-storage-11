"""
Exception hierarchy for lumelab-jaci.

All exceptions inherit from JaciError to provide a common base for error handling.
"""

from __future__ import annotations

from typing import Optional


class JaciError(Exception):
    """Base exception for all lumelab-jaci errors."""
    
    def __init__(self, message: str, path: Optional[str] = None) -> None:
        super().__init__(message)
        self.message = message
        self.path = path


class SandboxViolationError(JaciError):
    """Raised when attempting to access paths outside the configured sandbox."""
    
    def __init__(self, path: str, sandbox_root: str) -> None:
        message = f"Path '{path}' violates sandbox root '{sandbox_root}'"
        super().__init__(message, path)
        self.sandbox_root = sandbox_root


class SymlinkLoopError(JaciError):
    """Raised when a symlink loop is detected during path traversal."""
    
    def __init__(self, path: str, loop_start: str) -> None:
        message = f"Symlink loop detected at '{path}', loop starts at '{loop_start}'"
        super().__init__(message, path)
        self.loop_start = loop_start


class ProviderUnavailableError(JaciError):
    """Raised when a required provider (local, remote, etc.) is unavailable."""
    
    def __init__(self, provider_name: str, reason: Optional[str] = None) -> None:
        message = f"Provider '{provider_name}' is unavailable"
        if reason:
            message += f": {reason}"
        super().__init__(message)


class PermissionDeniedError(JaciError):
    """Raised when lacking permissions to access a path or perform an operation."""
    
    def __init__(self, path: str, operation: str) -> None:
        message = f"Permission denied for {operation} on '{path}'"
        super().__init__(message, path)
        self.operation = operation


class PathNotFoundError(JaciError):
    """Raised when attempting to access a non-existent path."""
    
    def __init__(self, path: str) -> None:
        message = f"Path not found: '{path}'"
        super().__init__(message, path)


class UnsupportedOperationError(JaciError):
    """Raised when attempting an operation that is not supported."""
    
    def __init__(self, operation: str, reason: Optional[str] = None) -> None:
        message = f"Unsupported operation: {operation}"
        if reason:
            message += f" ({reason})"
        super().__init__(message)
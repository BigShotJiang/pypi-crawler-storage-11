"""
Ignore functionality for lumelab-jaci.

This extra provides .gitignore-style pattern matching for filtering
file system entries. It uses the 'pathspec' library when available.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional, Set

# Try to import pathspec for .gitignore support
try:
    import pathspec

    _PATHSPEC_AVAILABLE = True
except ImportError:
    _PATHSPEC_AVAILABLE = False


class IgnoreEngine:
    """
    Engine for matching paths against ignore patterns.

    Supports .gitignore-style patterns when pathspec is available,
    otherwise falls back to basic glob patterns.
    """

    def __init__(
        self,
        patterns: Optional[Iterable[str]] = None,
        gitignore_paths: Optional[Iterable[Path]] = None,
    ):
        """
        Initialize ignore engine.

        Args:
            patterns: List of ignore patterns (e.g., "*.pyc", "__pycache__")
            gitignore_paths: Paths to .gitignore files to load patterns from
        """
        self._patterns: list[str] = []
        self._matcher: Optional[object] = None

        # Load patterns from arguments
        if patterns:
            self._patterns.extend(patterns)

        # Load patterns from .gitignore files
        if gitignore_paths:
            for gitignore_path in gitignore_paths:
                if gitignore_path.exists():
                    self._load_gitignore(gitignore_path)

        # Compile patterns if pathspec is available
        if _PATHSPEC_AVAILABLE and self._patterns:
            self._compile_pathspec()

    def _load_gitignore(self, gitignore_path: Path) -> None:
        """Load patterns from a .gitignore file."""
        try:
            with open(gitignore_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    # Skip empty lines and comments
                    if line and not line.startswith("#"):
                        self._patterns.append(line)
        except (OSError, UnicodeDecodeError) as e:
            # Log warning but continue
            import logging

            logger = logging.getLogger(__name__)
            logger.warning(f"Failed to read {gitignore_path}: {e}")

    def _compile_pathspec(self) -> None:
        """Compile patterns using pathspec library."""
        if not _PATHSPEC_AVAILABLE:
            return

        try:
            self._matcher = pathspec.PathSpec.from_lines(
                pathspec.patterns.GitWildMatchPattern, self._patterns
            )
        except Exception as e:
            # Fallback to basic matching if pathspec fails
            import logging

            logger = logging.getLogger(__name__)
            logger.warning(f"Failed to compile pathspec patterns: {e}")
            self._matcher = None

    def is_ignored(self, path: Path, is_dir: bool = False) -> bool:
        """
        Check if a path should be ignored.

        Args:
            path: Path to check
            is_dir: Whether path is a directory

        Returns:
            True if path should be ignored
        """
        if not self._patterns:
            return False

        # Use pathspec if available
        if _PATHSPEC_AVAILABLE and self._matcher:
            try:
                # For directories, add trailing slash for matching
                path_str = str(path)
                if is_dir:
                    path_str = path_str + "/"
                return self._matcher.match_file(path_str)
            except Exception:
                # Fallback to basic matching
                pass

        # Fallback to basic glob matching
        return self._basic_match(path, is_dir)

    def _basic_match(self, path: Path, is_dir: bool) -> bool:
        """Basic pattern matching without pathspec."""
        import fnmatch

        # Convert path to relative string for matching
        path_str = str(path)

        for pattern in self._patterns:
            # Handle directory-specific patterns
            if pattern.endswith("/"):
                if not is_dir:
                    continue
                # For directory patterns, match against directory name
                dir_pattern = pattern.rstrip("/")
                if fnmatch.fnmatch(path.name, dir_pattern):
                    return True
                # Also match against full path with trailing slash
                if fnmatch.fnmatch(path_str + "/", pattern):
                    return True
            else:
                # Regular file pattern
                if fnmatch.fnmatch(path_str, pattern) or fnmatch.fnmatch(
                    path.name, pattern
                ):
                    return True

        return False

    @property
    def patterns(self) -> list[str]:
        """Get the list of ignore patterns."""
        return self._patterns.copy()

    @property
    def is_available(self) -> bool:
        """Check if pathspec is available for advanced matching."""
        return _PATHSPEC_AVAILABLE and self._matcher is not None


def create_ignore_engine(
    patterns: Optional[Iterable[str]] = None,
    gitignore_paths: Optional[Iterable[Path]] = None,
    from_gitignore: bool = True,
    gitignore_name: str = ".gitignore",
) -> IgnoreEngine:
    """
    Create an ignore engine with common configurations.

    Args:
        patterns: Additional ignore patterns
        gitignore_paths: Specific .gitignore files to load
        from_gitignore: Whether to automatically look for .gitignore files
        gitignore_name: Name of gitignore files to look for

    Returns:
        Configured IgnoreEngine instance
    """
    gitignore_files = list(gitignore_paths) if gitignore_paths else []

    # Auto-discover .gitignore files if requested
    if from_gitignore:
        # Look for .gitignore in current directory and parents
        current = Path.cwd()
        while current != current.parent:
            gitignore_file = current / gitignore_name
            if gitignore_file.exists() and gitignore_file not in gitignore_files:
                gitignore_files.append(gitignore_file)
            current = current.parent

    return IgnoreEngine(patterns=patterns, gitignore_paths=gitignore_files)


# Common ignore patterns for different scenarios
COMMON_PATTERNS = {
    "python": [
        "*.pyc",
        "*.pyo",
        "*.pyd",
        "__pycache__/",
        ".pytest_cache/",
        ".mypy_cache/",
        "*.egg-info/",
        "dist/",
        "build/",
    ],
    "node": [
        "node_modules/",
        "npm-debug.log*",
        "yarn-debug.log*",
        "yarn-error.log*",
        ".npm/",
        ".cache/",
    ],
    "git": [
        ".git/",
        ".gitignore",
        ".gitmodules",
        ".gitattributes",
    ],
    "ide": [
        ".vscode/",
        ".idea/",
        "*.swp",
        "*.swo",
        "*~",
    ],
}


def get_common_patterns(categories: Iterable[str]) -> list[str]:
    """
    Get common ignore patterns for specified categories.

    Args:
        categories: List of category names (e.g., ["python", "git"])

    Returns:
        Combined list of ignore patterns
    """
    patterns = []
    for category in categories:
        if category in COMMON_PATTERNS:
            patterns.extend(COMMON_PATTERNS[category])
    return patterns

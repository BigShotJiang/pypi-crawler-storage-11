"""
Logging utilities for lumelab-jaci.

This module provides logging configuration and utilities including
sensitive data masking and structured logging.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, Optional, List

try:
    from ..config.loader import get_config
except ImportError:
    get_config = None


def get_logger(name: str = "lumelab.jaci") -> logging.Logger:
    """
    Get a logger instance with proper configuration.
    
    Args:
        name: Logger name (defaults to 'lumelab.jaci')
        
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)
    
    # Only configure if not already configured
    if not logger.handlers:
        # Get configuration
        if get_config is not None:
            config = get_config()
            level_str = config.get("jaci.logging.level", "INFO")
        else:
            level_str = "INFO"
        
        # Convert string level to logging constant
        level = getattr(logging, level_str.upper(), logging.INFO)
        logger.setLevel(level)
        
        # Create console handler
        handler = logging.StreamHandler()
        handler.setLevel(level)
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        
        # Add handler to logger
        logger.addHandler(handler)
    
    return logger


def mask_sensitive_data(data: str, patterns: Optional[List[str]] = None) -> str:
    """
    Mask sensitive information in log messages.
    
    Args:
        data: String data to mask
        patterns: List of patterns to mask (defaults to config)
        
    Returns:
        Masked string
    """
    if patterns is None:
        if get_config is not None:
            try:
                config = get_config()
                patterns = config.get("jaci.logging.sensitive_patterns", [])
            except Exception:
                patterns = []
        else:
            patterns = []
    
    masked_data = data
    
    if patterns:
        for pattern in patterns:
            # Create regex pattern to match sensitive data
            # This matches pattern followed by common separators and values
            regex_pattern = re.compile(
                r'(' + pattern + r'[=:\s]+)([^\s&;,}]+)',
                re.IGNORECASE
            )
            
            # Replace with masked version
            masked_data = regex_pattern.sub(r'\1***MASKED***', masked_data)
    
    return masked_data


class MetricsCollector:
    """
    Simple metrics collector for performance and usage tracking.
    
    This is a no-op implementation by default. Real telemetry
    can be enabled by setting up a proper metrics backend.
    """
    
    def __init__(self) -> None:
        """Initialize metrics collector."""
        self._metrics: Dict[str, Any] = {}
        self._logger = get_logger()
    
    def increment(self, metric_name: str, value: int = 1) -> None:
        """
        Increment a counter metric.
        
        Args:
            metric_name: Name of metric
            value: Value to increment by
        """
        self._metrics[metric_name] = self._metrics.get(metric_name, 0) + value
    
    def timing(self, metric_name: str, duration_ms: float) -> None:
        """
        Record a timing metric.
        
        Args:
            metric_name: Name of metric
            duration_ms: Duration in milliseconds
        """
        if metric_name not in self._metrics:
            self._metrics[metric_name] = []
        
        self._metrics[metric_name].append(duration_ms)
    
    def gauge(self, metric_name: str, value: float) -> None:
        """
        Set a gauge metric.
        
        Args:
            metric_name: Name of metric
            value: Gauge value
        """
        self._metrics[metric_name] = value
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get all collected metrics."""
        return self._metrics.copy()
    
    def reset(self) -> None:
        """Reset all metrics."""
        self._metrics.clear()
    
    def log_summary(self) -> None:
        """Log a summary of collected metrics."""
        if not self._metrics:
            return
        
        self._logger.info("Metrics Summary:")
        for name, value in self._metrics.items():
            if isinstance(value, list):
                # Timing metrics
                avg = sum(value) / len(value)
                self._logger.info(f"  {name}: avg={avg:.2f}ms, count={len(value)}")
            elif isinstance(value, (int, float)):
                # Counter or gauge metrics
                self._logger.info(f"  {name}: {value}")


# Global metrics instance
_global_metrics: Optional[MetricsCollector] = None


def get_metrics() -> MetricsCollector:
    """Get global metrics collector instance."""
    global _global_metrics
    
    if _global_metrics is None:
        _global_metrics = MetricsCollector()
    
    return _global_metrics


def reset_metrics() -> None:
    """Reset global metrics collector (mainly for testing)."""
    global _global_metrics
    _global_metrics = None
"""
Security utilities for lumelab-jaci.

This module provides security-related utilities including path canonicalization,
sandbox enforcement, and symlink loop detection.
"""

from __future__ import annotations

import os
import stat
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Set

if TYPE_CHECKING:
    from ..exceptions import SandboxViolationError, SymlinkLoopError

# Runtime imports
from ..exceptions import SandboxViolationError, SymlinkLoopError


def canonicalize_path(path: Path) -> Path:
    """
    Canonicalize a path to its absolute, resolved form.

    This function resolves symlinks and normalizes path while
    handling edge cases like broken symlinks and permission issues.

    Args:
        path: Path to canonicalize

    Returns:
        Canonicalized absolute path

    Raises:
        SymlinkLoopError: If a symlink loop is detected
    """
    try:
        # Use resolve() with strict=False to handle broken symlinks
        return path.resolve(strict=False)
    except (RuntimeError, FileNotFoundError, OSError) as e:
        # RuntimeError can occur with symlink loops
        # FileNotFoundError can occur when current directory is not accessible
        if isinstance(e, RuntimeError):
            raise SymlinkLoopError(str(path), str(path)) from e
        else:
            # For other path resolution errors, try to construct absolute path manually
            try:
                import os

                cwd = os.getcwd()
                return Path(cwd) / path
            except (FileNotFoundError, OSError):
                # If current directory is not accessible, try to make path absolute
                # using a safe fallback approach
                if path.is_absolute():
                    return path
                else:
                    # For relative paths, construct from parts without using cwd
                    # This is a fallback for test environments
                    return (
                        Path("/") / path.relative_to(".")
                        if "." in path.parts
                        else Path("/") / path
                    )


def is_within_sandbox(path: Path, sandbox_root: Path) -> bool:
    """
    Check if a path is within the specified sandbox directory.

    Args:
        path: Path to check
        sandbox_root: Sandbox root directory

    Returns:
        True if path is within sandbox, False otherwise
    """
    try:
        path.relative_to(sandbox_root)
        return True
    except ValueError:
        return False


def detect_symlink_loop(start_path: Path, visited: Optional[Set[Path]] = None) -> bool:
    """
    Detect if following symlinks from start_path would create a loop.

    Args:
        start_path: Starting path
        visited: Set of already visited paths (for recursion)

    Returns:
        True if a symlink loop would be detected
    """
    if visited is None:
        visited = set()

    # Normalize path
    try:
        current = start_path.resolve(strict=False)
    except (RuntimeError, FileNotFoundError, OSError):
        # If we can't resolve the path, assume no loop for safety
        return False

    # Check if we've already visited this path
    if current in visited:
        return True

    visited.add(current)

    # If this is a symlink, check its target
    if current.is_symlink():
        try:
            target = current.readlink()
            return detect_symlink_loop(target, visited)
        except (OSError, RuntimeError):
            return True  # Assume loop on read error

    return False


def safe_resolve_path(
    path: Path,
    sandbox_root: Optional[Path] = None,
    allow_symlinks: bool = True,
) -> Path:
    """
    Safely resolve a path with optional sandbox constraints.

    This function canonicalizes path, checks for symlink loops,
    and enforces sandbox constraints if specified.

    Args:
        path: Path to resolve
        sandbox_root: Optional sandbox root directory
        allow_symlinks: Whether to allow symlink resolution

    Returns:
        Resolved safe path

    Raises:
        SandboxViolationError: If path is outside sandbox
        SymlinkLoopError: If symlink loop is detected
    """
    # Canonicalize path
    resolved = canonicalize_path(path)

    # Check for symlink loops if symlinks are allowed
    if allow_symlinks and detect_symlink_loop(resolved):
        raise SymlinkLoopError(str(path), str(resolved))

    # Enforce sandbox constraints
    if sandbox_root is not None:
        sandbox_resolved = canonicalize_path(sandbox_root)

        if not is_within_sandbox(resolved, sandbox_resolved):
            raise SandboxViolationError(str(resolved), str(sandbox_resolved))

    return resolved


def validate_path_security(
    path: Path,
    sandbox_root: Optional[Path] = None,
    allow_symlinks: bool = True,
) -> bool:
    """
    Validate that a path meets security requirements.

    Args:
        path: Path to validate
        sandbox_root: Optional sandbox root directory
        allow_symlinks: Whether to allow symlinks

    Returns:
        True if path is secure, False otherwise
    """
    try:
        safe_resolve_path(path, sandbox_root, allow_symlinks)
        return True
    except (SandboxViolationError, SymlinkLoopError):
        return False


def normalize_path_separators(path: Path) -> Path:
    """
    Normalize path separators for cross-platform compatibility.

    Args:
        path: Path to normalize

    Returns:
        Path with normalized separators
    """
    # Convert to string and normalize separators
    normalized = str(path).replace("\\", "/")
    return Path(normalized)


def is_hidden_path(path: Path) -> bool:
    """
    Check if a path should be considered hidden.

    This function checks both Unix-style hidden files (starting with .)
    and Windows-style hidden files.

    Args:
        path: Path to check

    Returns:
        True if path should be considered hidden
    """
    # Unix-style hidden files
    if path.name.startswith("."):
        return True

    # Windows-style hidden files (check file attributes)
    if os.name == "nt":
        try:
            import stat

            if path.exists():
                attrs = path.stat().st_file_attributes
                return bool(attrs & stat.FILE_ATTRIBUTE_HIDDEN)
        except (AttributeError, OSError):
            pass

    return False


def sanitize_path_for_logging(path: Path, max_length: int = 200) -> str:
    """
    Sanitize a path for safe logging.

    This function truncates long paths and removes potentially sensitive
    information while maintaining useful context.

    Args:
        path: Path to sanitize
        max_length: Maximum length for logged path

    Returns:
        Sanitized path string
    """
    path_str = str(path)

    # Truncate if too long
    if len(path_str) > max_length:
        # Keep the beginning and end, truncate the middle
        half = (max_length - 3) // 2
        path_str = path_str[:half] + "..." + path_str[-half:]

    return path_str

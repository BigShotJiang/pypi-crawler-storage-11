"""
Configuration loader with layered precedence.

This module implements configuration loading from multiple sources with
proper precedence: API overrides → environment variables → YAML files → defaults.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, Optional

try:
    import yaml

    _YAML_AVAILABLE = True
except ImportError:
    yaml = None
    _YAML_AVAILABLE = False

try:
    import platformdirs

    _PLATFORMDIRS_AVAILABLE = True
except ImportError:
    platformdirs = None
    _PLATFORMDIRS_AVAILABLE = False


class Config:
    """
    Configuration container with layered precedence.

    Configuration is loaded from multiple sources in order of precedence:
    1. API overrides (passed during initialization)
    2. Environment variables (LUMELAB_JACI_*)
    3. YAML configuration files
    4. Built-in defaults
    """

    # Default configuration values
    DEFAULTS: Dict[str, Any] = {
        "jaci": {
            "sandbox_root": None,
            "follow_symlinks": False,
            "ignore": {
                "from_gitignore": True,
                "patterns": [],
            },
            "fuzzy": {
                "enabled": False,
                "score_threshold": 60,
                "max_results": 100,
            },
            "watch": {
                "provider": "watchfiles",  # watchfiles|watchdog
                "debounce_ms": 100,
            },
            "mime": {
                "enabled": False,
                "provider": "python-magic",  # python-magic|filetype
            },
            "cache": {
                "ttl_seconds": 300,  # 5 minutes
                "max_entries": 1000,
            },
            "logging": {
                "level": "INFO",
                "sensitive_patterns": ["password", "secret", "token", "key"],
            },
        }
    }

    def __init__(self, overrides: Optional[Dict[str, Any]] = None) -> None:
        """
        Initialize configuration.

        Args:
            overrides: API-level configuration overrides
        """
        self._config: Dict[str, Any] = {}
        self._overrides = overrides or {}
        self._load_config()

    def _load_config(self) -> None:
        """Load configuration from all sources with proper precedence."""
        # Start with defaults
        self._config = self._deep_copy_dict(self.DEFAULTS)

        # Load from YAML files
        yaml_config = self._load_yaml_config()
        if yaml_config:
            self._deep_merge(self._config, yaml_config)

        # Load from environment variables
        env_config = self._load_env_config()
        if env_config:
            self._deep_merge(self._config, env_config)

        # Apply API overrides
        if self._overrides:
            self._deep_merge(self._config, self._overrides)

    def _load_yaml_config(self) -> Optional[Dict[str, Any]]:
        """Load configuration from YAML files."""
        if not _YAML_AVAILABLE or not yaml:
            return None

        config_paths = self._get_config_paths()

        for config_path in config_paths:
            if config_path.exists() and config_path.is_file():
                try:
                    with open(config_path, "r", encoding="utf-8") as f:
                        return yaml.safe_load(f) or {}
                except Exception:
                    # Skip invalid YAML files
                    continue

        return None

    def _get_config_paths(self) -> list[Path]:
        """Get possible configuration file paths."""
        paths = []

        if (
            _PLATFORMDIRS_AVAILABLE
            and platformdirs
            and hasattr(platformdirs, "user_config_dir")
        ):
            # Use platformdirs for cross-platform config directories
            config_dir = Path(platformdirs.user_config_dir("lumelab", "jaci"))
            paths.append(config_dir / "config.yaml")
            paths.append(config_dir / "config.yml")
        else:
            # Fallback to standard locations
            home = Path.home()
            paths.extend(
                [
                    home / ".config" / "lumelab" / "jaci" / "config.yaml",
                    home / ".config" / "lumelab" / "jaci" / "config.yml",
                    home / ".lumelab" / "jaci" / "config.yaml",
                    home / ".lumelab" / "jaci" / "config.yml",
                ]
            )

        # Current directory (for development)
        try:
            cwd = Path.cwd()
            paths.append(cwd / "jaci.yaml")
            paths.append(cwd / "jaci.yml")
            paths.append(cwd / ".jaci.yaml")
            paths.append(cwd / ".jaci.yml")
        except (FileNotFoundError, OSError):
            # Current directory is not accessible, skip local config files
            pass

        return paths

    def _load_env_config(self) -> Dict[str, Any]:
        """Load configuration from environment variables."""
        env_config = {}
        prefix = "LUMELAB_JACI_"

        for key, value in os.environ.items():
            if key.startswith(prefix):
                # Convert LUMELAB_JACI_FOO_BAR to jaci.foo.bar
                config_key = key[len(prefix) :].lower().replace("_", ".")

                # Parse the value
                parsed_value = self._parse_env_value(value)

                # Set nested key
                self._set_nested_key(env_config, config_key, parsed_value)

        return env_config

    def _parse_env_value(self, value: str) -> Any:
        """Parse environment variable value to appropriate type."""
        # Boolean values
        if value.lower() in ("true", "yes", "1", "on"):
            return True
        elif value.lower() in ("false", "no", "0", "off"):
            return False

        # Numeric values
        try:
            if "." in value:
                return float(value)
            else:
                return int(value)
        except ValueError:
            pass

        # String values
        return value

    def _set_nested_key(
        self, config: Dict[str, Any], key_path: str, value: Any
    ) -> None:
        """Set a nested configuration key using dot notation."""
        keys = key_path.split(".")
        current = config

        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            current = current[key]

        current[keys[-1]] = value

    def get(self, key_path: str, default: Any = None) -> Any:
        """
        Get a configuration value using dot notation.

        Args:
            key_path: Dot-separated path to the key (e.g., 'jaci.sandbox_root')
            default: Default value if key is not found

        Returns:
            Configuration value or default
        """
        keys = key_path.split(".")
        current = self._config

        try:
            for key in keys:
                current = current[key]
            return current
        except (KeyError, TypeError):
            return default

    def set(self, key_path: str, value: Any) -> None:
        """
        Set a configuration value using dot notation.

        Args:
            key_path: Dot-separated path to the key
            value: Value to set
        """
        self._set_nested_key(self._config, key_path, value)

    def get_section(self, section: str) -> Dict[str, Any]:
        """
        Get an entire configuration section.

        Args:
            section: Section name (e.g., 'jaci')

        Returns:
            Configuration section as dictionary
        """
        return self.get(section, {})

    def to_dict(self) -> Dict[str, Any]:
        """Get the complete configuration as a dictionary."""
        return self._deep_copy_dict(self._config)

    def _deep_copy_dict(self, d: Dict[str, Any]) -> Dict[str, Any]:
        """Create a deep copy of a dictionary."""
        import copy

        return copy.deepcopy(d)

    def _deep_merge(self, base: Dict[str, Any], update: Dict[str, Any]) -> None:
        """Deep merge update dictionary into base dictionary."""
        for key, value in update.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_merge(base[key], value)
            else:
                base[key] = value


# Global configuration instance
_global_config: Optional[Config] = None


def get_config(overrides: Optional[Dict[str, Any]] = None) -> Config:
    """
    Get the global configuration instance.

    Args:
        overrides: API-level configuration overrides (only used on first call)

    Returns:
        Configuration instance
    """
    global _global_config

    if _global_config is None:
        _global_config = Config(overrides)

    return _global_config


def reset_config() -> None:
    """Reset the global configuration instance (mainly for testing)."""
    global _global_config
    _global_config = None

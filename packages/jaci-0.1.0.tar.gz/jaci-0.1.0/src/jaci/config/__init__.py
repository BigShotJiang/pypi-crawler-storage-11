"""
Configuration management for lumelab-jaci.

This module provides layered configuration loading from environment variables,
YAML files, and defaults with proper precedence handling.
"""

from .loader import Config, get_config

__all__ = [
    "Config",
    "get_config",
]
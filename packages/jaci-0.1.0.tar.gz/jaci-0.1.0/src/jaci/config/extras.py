"""
Extras configuration and discovery for lumelab-jaci.

This module provides configuration management for optional extras
including automatic discovery and capability detection.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, Any, Optional, Set, List
from dataclasses import dataclass

try:
    from .loader import get_config

    _CONFIG_AVAILABLE = True
except ImportError:
    get_config = None
    _CONFIG_AVAILABLE = False


@dataclass
class ExtraInfo:
    """
    Information about an available extra.
    """

    # Extra identifier
    name: str

    # Human-readable description
    description: str

    # Whether the extra is installed and available
    available: bool

    # Required dependencies
    dependencies: List[str]

    # Optional dependencies
    optional_dependencies: List[str]

    # Configuration schema (if any)
    config_schema: Optional[Dict[str, Any]] = None

    # Current configuration
    config: Optional[Dict[str, Any]] = None


class SimpleConfigManager:
    """Simple config manager fallback when loader is not available."""

    def __init__(self):
        self._config = {}

    def get(self, key: str, default: Any = None) -> Any:
        """Get config value."""
        return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Set config value."""
        self._config[key] = value


class ExtrasManager:
    """
    Manager for discovering and configuring extras.

    Provides automatic discovery of available extras and
    unified configuration management.
    """

    def __init__(self):
        """Initialize extras manager."""
        if _CONFIG_AVAILABLE and get_config:
            self._config_manager = get_config()
        else:
            self._config_manager = SimpleConfigManager()
        self._extras_cache: Optional[Dict[str, ExtraInfo]] = None

    def discover_extras(self) -> Dict[str, ExtraInfo]:
        """
        Discover all available extras.

        Returns:
            Dictionary mapping extra names to ExtraInfo objects
        """
        if self._extras_cache is not None:
            return self._extras_cache

        extras = {}

        # Define all known extras
        known_extras = {
            "ignore": ExtraInfo(
                name="ignore",
                description=".gitignore-style pattern matching for filtering files",
                available=self._check_ignore_available(),
                dependencies=["pathspec"],
                optional_dependencies=[],
                config_schema={
                    "type": "object",
                    "properties": {
                        "from_gitignore": {
                            "type": "boolean",
                            "default": True,
                            "description": "Automatically load .gitignore files",
                        },
                        "gitignore_name": {
                            "type": "string",
                            "default": ".gitignore",
                            "description": "Name of gitignore files to look for",
                        },
                        "patterns": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Additional ignore patterns",
                        },
                    },
                },
            ),
            "fuzzy": ExtraInfo(
                name="fuzzy",
                description="Fuzzy string matching for file searches with relevance ranking",
                available=self._check_fuzzy_available(),
                dependencies=["rapidfuzz"],
                optional_dependencies=[],
                config_schema={
                    "type": "object",
                    "properties": {
                        "enabled": {
                            "type": "boolean",
                            "default": True,
                            "description": "Enable fuzzy search",
                        },
                        "algorithm": {
                            "type": "string",
                            "enum": [
                                "fuzz_ratio",
                                "fuzz_partial_ratio",
                                "fuzz_token_sort_ratio",
                                "fuzz_WRatio",
                            ],
                            "default": "fuzz_partial_ratio",
                            "description": "Fuzzy matching algorithm",
                        },
                        "score_threshold": {
                            "type": "integer",
                            "minimum": 0,
                            "maximum": 100,
                            "default": 60,
                            "description": "Minimum score threshold for matches",
                        },
                        "max_results": {
                            "type": "integer",
                            "minimum": 1,
                            "default": 20,
                            "description": "Maximum number of results to return",
                        },
                        "normalize_diacritics": {
                            "type": "boolean",
                            "default": True,
                            "description": "Normalize diacritics in search strings",
                        },
                    },
                },
            ),
            "mime": ExtraInfo(
                name="mime",
                description="MIME type detection for files using multiple backends",
                available=self._check_mime_available(),
                dependencies=[],
                optional_dependencies=["python-magic", "filetype"],
                config_schema={
                    "type": "object",
                    "properties": {
                        "enabled": {
                            "type": "boolean",
                            "default": True,
                            "description": "Enable MIME type detection",
                        },
                        "backend": {
                            "type": "string",
                            "enum": ["auto", "python-magic", "filetype"],
                            "default": "auto",
                            "description": "MIME detection backend to use",
                        },
                        "cache_results": {
                            "type": "boolean",
                            "default": True,
                            "description": "Cache MIME detection results",
                        },
                    },
                },
            ),
            "watch": ExtraInfo(
                name="watch",
                description="Real-time file system event monitoring with debouncing",
                available=self._check_watch_available(),
                dependencies=[],
                optional_dependencies=["watchfiles", "watchdog"],
                config_schema={
                    "type": "object",
                    "properties": {
                        "enabled": {
                            "type": "boolean",
                            "default": True,
                            "description": "Enable file watching",
                        },
                        "backend": {
                            "type": "string",
                            "enum": ["auto", "watchfiles", "watchdog"],
                            "default": "auto",
                            "description": "File watching backend to use",
                        },
                        "debounce_ms": {
                            "type": "integer",
                            "minimum": 0,
                            "default": 100,
                            "description": "Debounce time in milliseconds",
                        },
                    },
                },
            ),
            "remotes": ExtraInfo(
                name="remotes",
                description="Remote file system support using fsspec (S3, GCS, Azure, etc.)",
                available=self._check_remotes_available(),
                dependencies=["fsspec"],
                optional_dependencies=["s3fs", "gcsfs", "adlfs"],
                config_schema={
                    "type": "object",
                    "properties": {
                        "enabled": {
                            "type": "boolean",
                            "default": False,
                            "description": "Enable remote file system support",
                        },
                        "default_protocol": {
                            "type": "string",
                            "enum": ["s3", "gcs", "az", "ftp", "sftp"],
                            "default": "s3",
                            "description": "Default remote protocol",
                        },
                    },
                },
            ),
        }

        # Load configuration for each extra
        for name, info in known_extras.items():
            info.config = self._get_extra_config(name)
            extras[name] = info

        self._extras_cache = extras
        return extras

    def get_extra_info(self, name: str) -> Optional[ExtraInfo]:
        """
        Get information about a specific extra.

        Args:
            name: Extra name

        Returns:
            ExtraInfo object or None if not found
        """
        extras = self.discover_extras()
        return extras.get(name)

    def is_extra_available(self, name: str) -> bool:
        """
        Check if an extra is available.

        Args:
            name: Extra name

        Returns:
            True if extra is available
        """
        info = self.get_extra_info(name)
        return info.available if info else False

    def get_available_extras(self) -> Set[str]:
        """
        Get set of available extra names.

        Returns:
            Set of available extra names
        """
        extras = self.discover_extras()
        return {name for name, info in extras.items() if info.available}

    def get_extra_config(self, name: str) -> Dict[str, Any]:
        """
        Get configuration for a specific extra.

        Args:
            name: Extra name

        Returns:
            Configuration dictionary
        """
        return self._get_extra_config(name)

    def set_extra_config(self, name: str, config: Dict[str, Any]) -> None:
        """
        Set configuration for a specific extra.

        Args:
            name: Extra name
            config: Configuration dictionary
        """
        # Validate against schema if available
        info = self.get_extra_info(name)
        if info and info.config_schema:
            self._validate_config(config, info.config_schema, name)

        # Save configuration
        self._config_manager.set(f"jaci.extras.{name}", config)

        # Clear cache
        self._extras_cache = None

    def get_capabilities(self) -> Dict[str, Any]:
        """
        Get overall capabilities based on available extras.

        Returns:
            Capabilities dictionary
        """
        extras = self.discover_extras()
        capabilities = {
            "extras": {},
            "features": {
                "ignore": False,
                "fuzzy": False,
                "mime": False,
                "watch": False,
                "remotes": False,
            },
        }

        for name, info in extras.items():
            capabilities["extras"][name] = {
                "available": info.available,
                "description": info.description,
                "dependencies": info.dependencies,
                "optional_dependencies": info.optional_dependencies,
            }

            # Map extras to features
            if name in capabilities["features"]:
                capabilities["features"][name] = info.available

        return capabilities

    def _get_extra_config(self, name: str) -> Dict[str, Any]:
        """Get configuration for a specific extra from config manager."""
        return self._config_manager.get(f"jaci.extras.{name}", {})

    def _validate_config(
        self, config: Dict[str, Any], schema: Dict[str, Any], extra_name: str
    ) -> None:
        """Validate configuration against schema."""
        # Simple validation - in real implementation would use jsonschema
        if not isinstance(config, dict):
            raise ValueError(f"Configuration for {extra_name} must be a dictionary")

        properties = schema.get("properties", {})
        for key, value in config.items():
            if key not in properties:
                # Log warning but allow
                import logging

                logger = logging.getLogger(__name__)
                logger.warning(
                    f"Unknown configuration key '{key}' for extra '{extra_name}'"
                )

    def _check_ignore_available(self) -> bool:
        """Check if ignore extra is available."""
        try:
            import pathspec

            return True
        except ImportError:
            return False

    def _check_fuzzy_available(self) -> bool:
        """Check if fuzzy extra is available."""
        try:
            import rapidfuzz

            return True
        except ImportError:
            return False

    def _check_mime_available(self) -> bool:
        """Check if mime extra is available."""
        try:
            import magic

            return True
        except ImportError:
            try:
                import filetype

                return True
            except ImportError:
                return False

    def _check_watch_available(self) -> bool:
        """Check if watch extra is available."""
        try:
            import watchfiles

            return True
        except ImportError:
            try:
                import watchdog

                return True
            except ImportError:
                return False

    def _check_remotes_available(self) -> bool:
        """Check if remotes extra is available."""
        try:
            import fsspec

            return True
        except ImportError:
            return False


# Global extras manager instance
_extras_manager: Optional[ExtrasManager] = None


def get_extras_manager() -> ExtrasManager:
    """
    Get the global extras manager instance.

    Returns:
        ExtrasManager instance
    """
    global _extras_manager
    if _extras_manager is None:
        _extras_manager = ExtrasManager()
    return _extras_manager


def discover_extras() -> Dict[str, ExtraInfo]:
    """
    Discover all available extras.

    Returns:
        Dictionary mapping extra names to ExtraInfo objects
    """
    return get_extras_manager().discover_extras()


def is_extra_available(name: str) -> bool:
    """
    Check if an extra is available.

    Args:
        name: Extra name

    Returns:
        True if extra is available
    """
    return get_extras_manager().is_extra_available(name)


def get_extra_config(name: str) -> Dict[str, Any]:
    """
    Get configuration for a specific extra.

    Args:
        name: Extra name

    Returns:
        Configuration dictionary
    """
    return get_extras_manager().get_extra_config(name)


def set_extra_config(name: str, config: Dict[str, Any]) -> None:
    """
    Set configuration for a specific extra.

    Args:
        name: Extra name
        config: Configuration dictionary
    """
    get_extras_manager().set_extra_config(name, config)


def get_capabilities() -> Dict[str, Any]:
    """
    Get overall capabilities based on available extras.

    Returns:
        Capabilities dictionary
    """
    return get_extras_manager().get_capabilities()

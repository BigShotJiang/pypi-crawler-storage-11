"""
Fuzzy search functionality for lumelab-jaci.

This extra provides fuzzy string matching for file searches with
relevance ranking and configurable algorithms.
"""

from __future__ import annotations

from typing import Iterable, List, Tuple, Optional, Union

# Try to import rapidfuzz for fuzzy matching
try:
    from rapidfuzz import fuzz, process

    _RAPIDFUZZ_AVAILABLE = True
except ImportError:
    _RAPIDFUZZ_AVAILABLE = False


class FuzzyMatcher:
    """
    Fuzzy string matching engine with configurable algorithms.

    Supports multiple matching algorithms and scoring thresholds.
    """

    def __init__(
        self,
        algorithm: str = "fuzz_ratio",
        score_threshold: int = 60,
        max_results: Optional[int] = None,
        normalize_diacritics: bool = True,
    ):
        """
        Initialize fuzzy matcher.

        Args:
            algorithm: Matching algorithm to use
            score_threshold: Minimum score (0-100) for matches
            max_results: Maximum number of results to return
            normalize_diacritics: Whether to normalize diacritics
        """
        self.algorithm = algorithm
        self.score_threshold = score_threshold
        self.max_results = max_results
        self.normalize_diacritics = normalize_diacritics

        # Validate algorithm
        if _RAPIDFUZZ_AVAILABLE:
            valid_algorithms = {
                "fuzz_ratio",
                "fuzz_partial_ratio",
                "fuzz_token_sort_ratio",
                "fuzz_token_set_ratio",
                "fuzz_token_ratio",
                "fuzz_WRatio",
            }
            if algorithm not in valid_algorithms:
                raise ValueError(
                    f"Invalid algorithm: {algorithm}. Must be one of {valid_algorithms}"
                )

    def match(
        self, query: str, choices: Iterable[str], limit: Optional[int] = None
    ) -> List[Tuple[str, int]]:
        """
        Find fuzzy matches for query in choices.

        Args:
            query: Search query string
            choices: Iterable of strings to search in
            limit: Maximum number of results (overrides max_results)

        Returns:
            List of (choice, score) tuples sorted by score (descending)
        """
        if not _RAPIDFUZZ_AVAILABLE:
            # Fallback to basic substring matching
            return self._basic_match(query, choices, limit)

        choices_list = list(choices)
        if not choices_list:
            return []

        # Normalize query and choices if requested
        if self.normalize_diacritics:
            query = self._normalize_diacritics(query)
            choices_list = [
                self._normalize_diacritics(choice) for choice in choices_list
            ]

        # Use rapidfuzz for matching
        if self.algorithm == "fuzz_ratio":
            scorer = fuzz.ratio
        elif self.algorithm == "fuzz_partial_ratio":
            scorer = fuzz.partial_ratio
        elif self.algorithm == "fuzz_token_sort_ratio":
            scorer = fuzz.token_sort_ratio
        elif self.algorithm == "fuzz_token_set_ratio":
            scorer = fuzz.token_set_ratio
        elif self.algorithm == "fuzz_token_ratio":
            scorer = fuzz.token_ratio
        elif self.algorithm == "fuzz_WRatio":
            scorer = fuzz.WRatio
        else:
            scorer = fuzz.ratio

        # Get matches with scores
        results = process.extract(
            query,
            choices_list,
            scorer=scorer,
            limit=limit or self.max_results or len(choices_list),
            score_cutoff=self.score_threshold,
        )

        # Convert 3-element tuples (choice, score, index) to 2-element tuples (choice, score)
        return [(choice, score) for choice, score, _ in results]

    def _basic_match(
        self, query: str, choices: Iterable[str], limit: Optional[int] = None
    ) -> List[Tuple[str, int]]:
        """
        Basic substring matching fallback.

        Args:
            query: Search query string
            choices: Iterable of strings to search in
            limit: Maximum number of results

        Returns:
            List of (choice, score) tuples
        """
        query_lower = query.lower()
        choices_list = list(choices)

        results = []
        for choice in choices_list:
            choice_lower = choice.lower()

            # Simple substring matching with basic scoring
            if query_lower in choice_lower:
                # Score based on position and length match
                pos = choice_lower.find(query_lower)
                score = max(0, 100 - (pos * 2) - abs(len(choice) - len(query)))
                results.append((choice, score))

        # Sort by score (descending) and limit results
        results.sort(key=lambda x: x[1], reverse=True)
        if limit:
            results = results[:limit]

        return results

    def _normalize_diacritics(self, text: str) -> str:
        """Normalize diacritics in text."""
        try:
            import unicodedata

            # Normalize to NFD form and remove combining characters
            normalized = unicodedata.normalize("NFD", text)
            return "".join(c for c in normalized if not unicodedata.combining(c))
        except ImportError:
            return text

    @property
    def is_available(self) -> bool:
        """Check if rapidfuzz is available."""
        return _RAPIDFUZZ_AVAILABLE


class FuzzySearchEngine:
    """
    High-level fuzzy search engine for file system entries.

    Integrates with Entry objects and provides file-aware matching.
    """

    def __init__(self, matcher: Optional[FuzzyMatcher] = None):
        """
        Initialize fuzzy search engine.

        Args:
            matcher: Custom fuzzy matcher (creates default if None)
        """
        self.matcher = matcher or FuzzyMatcher()

    def search_entries(
        self,
        query: str,
        entries: Iterable,
        search_fields: Optional[List[str]] = None,
        include_scores: bool = True,
    ) -> List[Union]:
        """
        Search for entries matching the fuzzy query.

        Args:
            query: Search query string
            entries: Iterable of Entry objects
            search_fields: List of Entry fields to search in (default: ['name'])
            include_scores: Whether to include scores in results

        Returns:
            List of Entry objects or (Entry, score) tuples
        """
        search_fields = search_fields or ["name"]
        entries_list = list(entries)

        if not entries_list:
            return []

        # Create search strings for each entry
        search_strings = []
        for entry in entries_list:
            parts = []
            for field in search_fields:
                if hasattr(entry, field):
                    value = getattr(entry, field)
                    if value is not None:
                        parts.append(str(value))
            search_strings.append(" ".join(parts))

        # Perform fuzzy matching
        matches = self.matcher.match(query, search_strings)

        # Map back to entries
        results = []
        for match_str, score in matches:
            # Find the corresponding entry
            for i, search_str in enumerate(search_strings):
                if search_str == match_str:
                    entry = entries_list[i]
                    if include_scores:
                        results.append((entry, score))
                    else:
                        results.append(entry)
                    break

        return results

    def search_paths(
        self, query: str, paths: Iterable[str], include_scores: bool = True
    ) -> List[Union]:
        """
        Search for paths matching the fuzzy query.

        Args:
            query: Search query string
            paths: Iterable of path strings
            include_scores: Whether to include scores in results

        Returns:
            List of path strings or (path, score) tuples
        """
        matches = self.matcher.match(query, paths)

        if include_scores:
            return matches
        else:
            return [path for path, _ in matches]


def create_fuzzy_matcher(
    algorithm: str = "fuzz_ratio",
    score_threshold: int = 60,
    max_results: Optional[int] = None,
    normalize_diacritics: bool = True,
) -> FuzzyMatcher:
    """
    Create a fuzzy matcher with common configurations.

    Args:
        algorithm: Matching algorithm
        score_threshold: Minimum score threshold
        max_results: Maximum results
        normalize_diacritics: Whether to normalize diacritics

    Returns:
        Configured FuzzyMatcher instance
    """
    return FuzzyMatcher(
        algorithm=algorithm,
        score_threshold=score_threshold,
        max_results=max_results,
        normalize_diacritics=normalize_diacritics,
    )


# Predefined configurations for different use cases
FUZZY_CONFIGS = {
    "filename": {
        "algorithm": "fuzz_partial_ratio",
        "score_threshold": 60,
        "max_results": 20,
        "normalize_diacritics": True,
    },
    "path": {
        "algorithm": "fuzz_token_sort_ratio",
        "score_threshold": 70,
        "max_results": 10,
        "normalize_diacritics": True,
    },
    "exact": {
        "algorithm": "fuzz_ratio",
        "score_threshold": 90,
        "max_results": 5,
        "normalize_diacritics": False,
    },
}


def get_fuzzy_config(name: str) -> dict:
    """
    Get predefined fuzzy configuration.

    Args:
        name: Configuration name ('filename', 'path', 'exact')

    Returns:
        Configuration dictionary
    """
    if name not in FUZZY_CONFIGS:
        raise ValueError(
            f"Unknown fuzzy config: {name}. Available: {list(FUZZY_CONFIGS.keys())}"
        )

    return FUZZY_CONFIGS[name].copy()

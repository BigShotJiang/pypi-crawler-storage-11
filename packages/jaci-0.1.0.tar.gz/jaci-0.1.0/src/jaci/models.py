"""
Core data models for lumelab-jaci.

This module defines the main data structures used throughout the library:
- Entry: Immutable file/directory metadata
- Query: Composable filtering criteria
- Order: Sorting specifications
- FuzzySpec: Fuzzy search configuration
- SelectionMode: File/directory selection modes
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import (
    Any,
    Dict,
    Iterable,
    Optional,
    Tuple,
    Union,
)


class SelectionMode(Enum):
    """Controls whether to include files, directories, or both in results."""

    FILES_ONLY = "files_only"
    DIRECTORIES_ONLY = "directories_only"
    BOTH = "both"


@dataclass(frozen=True)
class Entry:
    """
    Immutable representation of a file system entry.

    Contains metadata about a file or directory, including path information,
    size, timestamps, permissions, and optional MIME type.
    """

    path: Path
    name: str
    parent: Path
    is_dir: bool
    size: int
    mtime: float
    permissions: Optional[int] = None
    extension: Optional[str] = field(default=None, init=False)
    mime: Optional[str] = None

    def __post_init__(self) -> None:
        # Derive extension from name for files (but not hidden files starting with .)
        if not self.is_dir and "." in self.name and not self.name.startswith("."):
            object.__setattr__(self, "extension", self.name.rsplit(".", 1)[-1].lower())

    @property
    def is_file(self) -> bool:
        """True if this entry represents a regular file."""
        return not self.is_dir

    @property
    def is_hidden(self) -> bool:
        """True if this entry should be considered hidden."""
        return self.name.startswith(".")

    def __str__(self) -> str:
        return str(self.path)

    def __repr__(self) -> str:
        return f"Entry(path={self.path!r}, is_dir={self.is_dir}, size={self.size})"


@dataclass
class Query:
    """
    Composable filtering criteria for file system entries.

    All filter criteria are optional and combined with AND logic.
    """

    # Glob patterns
    include_glob: Optional[str] = None
    exclude_glob: Optional[str] = None

    # Extension filtering
    extensions: Optional[Iterable[str]] = None

    # Name filtering with regex
    name_regex: Optional[str] = None

    # Size filtering (in bytes)
    size_range: Optional[Tuple[int, int]] = None  # (min_size, max_size)

    # Modification time filtering (Unix timestamp)
    mtime_range: Optional[Tuple[float, float]] = None  # (min_mtime, max_mtime)

    # Behavior controls
    include_hidden: bool = False
    follow_symlinks: bool = False
    max_depth: Optional[int] = None

    # Pagination
    limit: Optional[int] = None
    offset: int = 0

    # Selection mode
    selection_mode: SelectionMode = SelectionMode.BOTH


@dataclass
class Order:
    """
    Sorting specification for query results.
    """

    # Sort field
    by: str = "name"  # name|size|mtime|ext

    # Sort direction
    direction: str = "asc"  # asc|desc

    # Natural sort for alphanumeric strings
    natural: bool = False

    def __post_init__(self) -> None:
        valid_fields = {"name", "size", "mtime", "ext"}
        if self.by not in valid_fields:
            raise ValueError(
                f"Invalid sort field: {self.by}. Must be one of {valid_fields}"
            )

        valid_directions = {"asc", "desc"}
        if self.direction not in valid_directions:
            raise ValueError(
                f"Invalid sort direction: {self.direction}. Must be one of {valid_directions}"
            )


@dataclass
class FuzzySpec:
    """
    Configuration for fuzzy search operations.
    """

    # Search query
    query: str

    # Algorithm selection (depends on backend)
    algorithm: str = "default"

    # Minimum score threshold (0-100)
    score_threshold: int = 60

    # Maximum results to return
    max_results: Optional[int] = None

    # Normalize diacritics (é -> e, etc.)
    normalize_diacritics: bool = True

    def __post_init__(self) -> None:
        if not (0 <= self.score_threshold <= 100):
            raise ValueError("score_threshold must be between 0 and 100")


@dataclass
class WatchEvent:
    """
    File system event from watching operations.
    """

    # Event type
    event: str  # created|deleted|modified|moved

    # The entry that changed
    entry: Entry

    # Timestamp of the event
    at: float

    # For move events, the destination path
    destination: Optional[Path] = None

    def __post_init__(self) -> None:
        valid_events = {"created", "deleted", "modified", "moved"}
        if self.event not in valid_events:
            raise ValueError(
                f"Invalid event type: {self.event}. Must be one of {valid_events}"
            )


# Type aliases for better readability
EntryOrScored = Union[Entry, Tuple[Entry, int]]
EntryStream = Iterable[Entry]
EventStream = Iterable[WatchEvent]

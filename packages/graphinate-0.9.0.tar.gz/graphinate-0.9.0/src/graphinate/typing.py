"""
Typing Module

Attributes:
  Node (Node): Node Type
  Edge (Edge): Edge Type
  Element (Element): Element Type
  Extractor (Extractor): Source of data for an Element
  UniverseNode (UniverseNode): The Universe Node Type. All Node Types are the implicit children of UniverseNodeType.
"""

from collections.abc import Callable, Iterable
from types import NoneType
from typing import Any, NamedTuple, NewType, Protocol, TypeAlias, TypeVar, Union

NodeTuple: TypeAlias = tuple[str, Any]
EdgeTuple: TypeAlias = tuple[str, str, Any]

IdentifierStr = NewType('IdentifierStr', str)
IdentifierStr.__doc__ = 'A string that is a valid Python identifier (i.e., `isidentifier()` is True).'

NodeTypeAbsoluteId = NewType('NodeTypeAbsoluteId', tuple[str, str])
NodeTypeAbsoluteId.__doc__ = 'A unique identifier for a node type.'

UniverseNode = NewType('UniverseNode', NoneType)
UniverseNode.__doc__ = 'The UniverseNode Type. All Node Types are the implicit children of the Universe Node Type.'

# A node in a graph.
Node = Union[type[NamedTuple], NodeTuple]  # noqa: UP007

# An edge in a graph.
Edge = Union[type[NamedTuple], EdgeTuple]  # noqa: UP007

# An element in a graph.
Element = Union[Node, Edge]  # noqa: UP007

# A source of data for an element.
Extractor = Union[str, Callable[[Any], str]]  # noqa: UP007

T = TypeVar('T')


class Items(Protocol):
    """Protocol for callable objects that return an iterable of items."""

    def __call__(self, **kwargs) -> Iterable[T]:  # pragma: no cover
        ...


class Nodes(Protocol):
    """Protocol for callable objects that return an iterable of nodes."""

    def __call__(self, **kwargs) -> Iterable[Node]:  # pragma: no cover
        ...


class Edges(Protocol):
    """Protocol for callable objects that return an iterable of edges."""

    def __call__(self, **kwargs) -> Iterable[Edge]:  # pragma: no cover
        ...


class Predicate(Protocol):
    """Protocol for callable objects that evaluate a condition."""

    def __call__(self, **kwargs) -> bool:  # pragma: no cover
        ...


class Supplier(Protocol):
    """Protocol for callable objects that supply a value."""

    def __call__(self) -> Any:  # pragma: no cover
        ...

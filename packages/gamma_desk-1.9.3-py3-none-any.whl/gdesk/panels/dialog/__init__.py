from .proxy import DialogGuiProxy

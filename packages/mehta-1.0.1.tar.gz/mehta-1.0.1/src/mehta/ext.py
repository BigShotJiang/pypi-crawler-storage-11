import telebot
from telebot import *
import random

class telegram:
    def __init__(self):
        self.bot = None
        self.commandhandlers = {}
        self.messagehandler = None
        
    def commands(self, commandlist):
        def decorator(func):
            for cmd in commandlist:
                self.commandhandlers[cmd] = func
            return func
        return decorator
    
    def message(self):
        def decorator(func):
            self.messagehandler = func
            return func
        return decorator
    
    def run(self, token):
        self.bot = telebot.TeleBot(token)
        
        for cmd, handler in self.commandhandlers.items():
            @self.bot.message_handler(commands=[cmd])
            def handlecommand(message, handler=handler):
                result = handler(message)
                self.response(message, result)
        
        if self.messagehandler:
            @self.bot.message_handler(func=lambda message: True)
            def handlemessage(message):
                result = self.messagehandler(message)
                self.response(message, result)
        
        self.bot.polling()
    
    def response(self, message, result):
        if isinstance(result, dict):
            type = result.get('type')
            
            if type == 'photo':
                self.bot.send_photo(message.chat.id, result['url'], caption=result.get('caption', ''))
                
            elif type == 'video':
                self.bot.send_video(message.chat.id, result['url'], caption=result.get('caption', ''))
                
            elif type == 'audio':
                self.bot.send_audio(message.chat.id, result['url'], caption=result.get('caption', ''))
                
            elif type == 'document':
                self.bot.send_document(message.chat.id, result['url'], caption=result.get('caption', ''))
                
            elif type == 'location':
                self.bot.send_location(message.chat.id, result['lat'], result['lon'])
                
            elif type == 'contact':
                self.bot.send_contact(
                    message.chat.id, 
                    result['phone'], 
                    result['first_name'],
                    result.get('last_name', '')
                )
                
            elif type == 'poll':
                self.bot.send_poll(
                    message.chat.id,
                    result['question'],
                    result['options']
                )
                
            elif type == 'dice':
                self.bot.send_dice(message.chat.id)
                
            elif type == 'sticker':
                self.bot.send_sticker(message.chat.id, result['url'])
                
            elif type == 'voice':
                self.bot.send_voice(message.chat.id, result['url'])
                
            elif type == 'animation':
                self.bot.send_animation(message.chat.id, result['url'])
                
            elif type == 'venue':
                self.bot.send_venue(
                    message.chat.id,
                    result['lat'],
                    result['lon'],
                    result['title'],
                    result['address']
                )
                
            elif type == 'keyboard':
                markup = ReplyKeyboardMarkup(resize_keyboard=True)
                for row in result['buttons']:
                    markup.add(*[KeyboardButton(btn) for btn in row])
                self.bot.send_message(message.chat.id, result['text'], reply_markup=markup)
                
            else:
                self.bot.reply_to(message, str(result))
                
        else:
            self.bot.reply_to(message, str(result))
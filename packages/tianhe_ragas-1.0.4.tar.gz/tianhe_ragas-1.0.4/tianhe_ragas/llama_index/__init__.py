from tianhe_ragas.llama_index.evaluation import evaluate

__all__ = ["evaluate"]

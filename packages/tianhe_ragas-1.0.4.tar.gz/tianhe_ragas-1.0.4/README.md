## What is tianhe-langchain?

tianhe-ragas is an open-source rag extending library built to power building LLM application.
tianhe-ragas provides more components to support Chinese LLMs and and Chinese based token environments for prompt engineering and ICL template.


The project is a sub-module of [tianhe](https://github.com/cicit/tianhe).


## Key features

- Retrival Enhancement components, like ESIndex, DBIndex, GraphIndex 
- Supporting Open LLMs and embeddings models 
- High performance QAs Chains
- High Semanticly Chinese token processing


## Quick start

### Start with Tianhe Platform.

We provide a open cloud service for easily use. See [free trial](https://www.tianhe.cn/).


### Install tianhe-ragas

- Install from pip: `pip install tianhe-ragas`
- [Quick Start Guide](https://scn3v8ba0o9m.feishu.cn/wiki/XTRVw4tUHi4ZQ2kDQpXc0l47nLg)


## Documentation

For guidance on installation, development, deployment, and administration, 
check out [tianhe-ragas Dev Docs](https://scn3v8ba0o9m.feishu.cn/wiki/XTRVw4tUHi4ZQ2kDQpXc0l47nLg). 


## Acknowledgments

tianhe-ragas adopts dependencies from the following:


# FastAPI OAuth 2.0

![GitHub Workflow Status (with event)](https://img.shields.io/github/actions/workflow/status/fastapi-practices/fastapi_oauth20/ci.yml?logo=github)
[![GitHub](https://img.shields.io/github/license/wu-clan/httpfpt)](https://github.com/wu-clan/httpfpt/blob/master/LICENSE)
![GitHub release (with filter)](https://img.shields.io/github/v/release/fastapi-practices/fastapi_oauth20)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

在 FastAPI 中异步授权 OAuth 2.0 客户端

我们的目标是集成多个 CN 第三方客户端

## Download

```shell
pip install fastapi_oauth20
```

## Docs

[fastapi oauth20](https://fastapi-practices.github.io/fastapi-oauth20/)

## Sponsor

如果此项目能够帮助到你，你可以赞助作者一些咖啡豆表示鼓励：[:coffee: Sponsor :coffee:](https://wu-clan.github.io/sponsor/)

import sys
from types import SimpleNamespace
from typing import Optional

import pytest


def test_load_sdk_config_invokes_dotenv(monkeypatch: pytest.MonkeyPatch) -> None:
    invoked = SimpleNamespace(count=0)

    def _fake_load() -> None:
        invoked.count += 1

    monkeypatch.setattr("dotenv.load_dotenv", _fake_load)
    monkeypatch.delitem(sys.modules, "zoho_projects_sdk.config", raising=False)
    import zoho_projects_sdk.config as config_module  # type: ignore # noqa F401

    assert invoked.count == 1


def test_settings_reads_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    env = {
        "ZOHO_PROJECTS_CLIENT_ID": "id",
        "ZOHO_PROJECTS_CLIENT_SECRET": "secret",
        "ZOHO_PROJECTS_REFRESH_TOKEN": "refresh",
        "ZOHO_PROJECTS_PORTAL_ID": "portal",
    }

    def _fake_getenv(key: str, default: Optional[str] = None) -> Optional[str]:
        return env.get(key, default)

    monkeypatch.setattr("zoho_projects_sdk.config.os.getenv", _fake_getenv)
    from importlib import reload

    import zoho_projects_sdk.config as config_module

    reload(config_module)
    assert config_module.settings.ZOHO_PROJECTS_CLIENT_ID == "id"
    assert config_module.settings.ZOHO_PROJECTS_PORTAL_ID == "portal"

import os
from typing import cast
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from zoho_projects_sdk.api.attachments import AttachmentsAPI
from zoho_projects_sdk.api.baselines import BaselinesAPI
from zoho_projects_sdk.api.issues import IssuesAPI
from zoho_projects_sdk.api.business_hours import BusinessHoursAPI
from zoho_projects_sdk.api.clients import ClientsAPI
from zoho_projects_sdk.api.comments import CommentsAPI
from zoho_projects_sdk.api.contacts import ContactsAPI
from zoho_projects_sdk.api.events import EventsAPI
from zoho_projects_sdk.api.milestones import MilestonesAPI
from zoho_projects_sdk.api.phases import PhasesAPI
from zoho_projects_sdk.api.portals import PortalsAPI
from zoho_projects_sdk.api.projects import ProjectsAPI
from zoho_projects_sdk.api.roles import RolesAPI
from zoho_projects_sdk.api.tags import TagsAPI
from zoho_projects_sdk.api.tasklists import TasklistsAPI
from zoho_projects_sdk.api.tasks import TasksAPI
from zoho_projects_sdk.api.timelogs import TimelogsAPI
from zoho_projects_sdk.api.users import UsersAPI
from zoho_projects_sdk.client import ZohoProjects
from zoho_projects_sdk.http_client import ApiClient


@pytest.fixture()
def sdk_client() -> ZohoProjects:
    return ZohoProjects(
        client_id="id",
        client_secret="secret",
        refresh_token="refresh",
        portal_id="portal",
    )


@pytest.mark.parametrize(
    ("attr", "expected"),
    [
        ("projects", ProjectsAPI),
        ("portals", PortalsAPI),
        ("tasks", TasksAPI),
        ("tasklists", TasklistsAPI),
        ("issues", IssuesAPI),
        ("users", UsersAPI),
        ("timelogs", TimelogsAPI),
        ("comments", CommentsAPI),
        ("events", EventsAPI),
        ("milestones", MilestonesAPI),
        ("phases", PhasesAPI),
        ("business_hours", BusinessHoursAPI),
        ("baselines", BaselinesAPI),
        ("attachments", AttachmentsAPI),
        ("tags", TagsAPI),
        ("clients", ClientsAPI),
        ("contacts", ContactsAPI),
        ("roles", RolesAPI),
    ],
)
def test_property_returns_expected_api_instances(
    sdk_client: ZohoProjects, attr: str, expected: type
) -> None:
    assert isinstance(getattr(sdk_client, attr), expected)


def test_api_instances_share_http_client(sdk_client: ZohoProjects) -> None:
    projects = sdk_client.projects
    tasks = sdk_client.tasks
    assert projects._client is tasks._client
    assert projects._client is sdk_client._api_client


@pytest.mark.asyncio()
async def test_close_delegates_to_api_client(sdk_client: ZohoProjects) -> None:
    closer = AsyncMock()
    sdk_client._api_client.close = closer
    await sdk_client.close()
    closer.assert_awaited_once()


@pytest.mark.asyncio()
async def test_close_handles_missing_api_client(sdk_client: ZohoProjects) -> None:
    sdk_client._api_client = cast(ApiClient, None)
    await sdk_client.close()


@pytest.mark.asyncio()
async def test_async_context_manager_returns_self() -> None:
    client = ZohoProjects(
        client_id="id",
        client_secret="secret",
        refresh_token="refresh",
        portal_id="portal",
    )
    closer = AsyncMock()
    client._api_client.close = closer

    async with client as context_client:
        assert context_client is client

    closer.assert_awaited_once()


@pytest.mark.asyncio()
async def test_async_context_manager_handles_missing_api_client(
    sdk_client: ZohoProjects,
) -> None:
    sdk_client._api_client = cast(ApiClient, None)

    async with sdk_client:
        pass


@pytest.mark.asyncio()
async def test_async_context_manager_propagates_exceptions() -> None:
    client = ZohoProjects(
        client_id="id",
        client_secret="secret",
        refresh_token="refresh",
        portal_id="portal",
    )
    closer = AsyncMock()
    client._api_client.close = closer

    with pytest.raises(RuntimeError):
        async with client:
            raise RuntimeError("boom")

    closer.assert_awaited_once()


@pytest.mark.asyncio()
async def test_dunder_async_context_methods() -> None:
    client = ZohoProjects(
        client_id="id",
        client_secret="secret",
        refresh_token="refresh",
        portal_id="portal",
    )
    closer = AsyncMock()
    client._api_client.close = closer

    result = await client.__aenter__()
    assert result is client

    await client.__aexit__(None, None, None)
    closer.assert_awaited_once()


def test_init_with_parameters() -> None:
    """
    Test initialization with explicit parameters.
    """
    client = ZohoProjects(
        client_id="test_client_id",
        client_secret="test_client_secret",
        refresh_token="test_refresh_token",
        portal_id="test_portal_id",
    )

    assert client._auth_handler.client_id == "test_client_id"
    assert client._auth_handler.client_secret == "test_client_secret"
    assert client._auth_handler.refresh_token == "test_refresh_token"
    assert client._auth_handler.portal_id == "test_portal_id"
    assert client._api_client is not None


def test_init_with_none_parameters() -> None:
    """
    Test initialization with None parameters (should use environment variables).
    """
    with patch.dict(
        "os.environ",
        {
            "ZOHO_PROJECTS_CLIENT_ID": "env_client_id",
            "ZOHO_PROJECTS_CLIENT_SECRET": "env_client_secret",
            "ZOHO_PROJECTS_REFRESH_TOKEN": "env_refresh_token",
            "ZOHO_PROJECTS_PORTAL_ID": "env_portal_id",
        },
    ):
        client = ZohoProjects(
            client_id=None,
            client_secret=None,
            refresh_token=None,
            portal_id=None,
        )

        assert client._auth_handler.client_id == "env_client_id"
        assert client._auth_handler.client_secret == "env_client_secret"
        assert client._auth_handler.refresh_token == "env_refresh_token"
        assert client._auth_handler.portal_id == "env_portal_id"
        assert client._api_client is not None


def test_init_creates_api_client_with_auth_handler() -> None:
    """
    Test that initialization creates ApiClient with the correct auth handler.
    """
    client = ZohoProjects(
        client_id="test_client_id",
        client_secret="test_client_secret",
        refresh_token="test_refresh_token",
        portal_id="test_portal_id",
    )

    assert client._api_client is not None
    api_client = client._api_client
    assert api_client is not None
    assert api_client._auth_handler is client._auth_handler


def test_init_auth_handler_and_api_client_are_different_instances() -> None:
    """
    Test that auth handler and API client are separate instances.
    """
    client = ZohoProjects(
        client_id="test_client_id",
        client_secret="test_client_secret",
        refresh_token="test_refresh_token",
        portal_id="test_portal_id",
    )

    assert client._auth_handler is not client._api_client
    api_client = client._api_client
    assert api_client is not None
    assert client._auth_handler is api_client._auth_handler

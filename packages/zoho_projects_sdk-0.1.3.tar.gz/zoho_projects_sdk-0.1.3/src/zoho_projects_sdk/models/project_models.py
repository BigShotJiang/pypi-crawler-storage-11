"""
Pydantic models for Zoho Projects API entities, such as projects.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field
from pydantic.config import ConfigDict


class Project(BaseModel):
    """
    A Pydantic model representing a project in Zoho Projects.
    """

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)

    id: int = Field(..., alias="id")
    name: str = Field(..., alias="name")
    status: str = Field(..., alias="status")
    description: Optional[str] = Field(None, alias="description")
    created_time: Optional[str] = Field(None, alias="created_time")
    updated_time: Optional[str] = Field(None, alias="updated_time")
    start_date: Optional[str] = Field(None, alias="start_date")
    end_date: Optional[str] = Field(None, alias="end_date")
    owner: Optional[Dict[str, Any]] = Field(None, alias="owner")  # Zoho user details
    portal_id: Optional[str] = Field(None, alias="portal_id")
    prefix: Optional[str] = Field(None, alias="prefix")
    is_active: Optional[bool] = Field(None, alias="is_active")

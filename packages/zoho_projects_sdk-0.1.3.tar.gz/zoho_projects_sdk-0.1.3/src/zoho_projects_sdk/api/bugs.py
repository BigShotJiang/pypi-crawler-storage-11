"""API methods for interacting with Zoho Issues (Bugs)."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from pydantic import BaseModel

from ..models.bug_models import (
    Issue,
    IssueCreateRequest,
    IssueUpdateRequest,
)


if TYPE_CHECKING:
    from ..http_client import ApiClient


class BugsAPI:
    """Helpers for the Zoho Projects Issues endpoints."""

    def __init__(self, client: "ApiClient"):
        self._client = client

    @property
    def _portal_id(self) -> str:
        portal_id = self._client.portal_id
        if portal_id is None:
            raise ValueError("Portal ID is not configured on the API client")
        return portal_id

    async def list_by_portal(
        self,
        *,
        page: int = 1,
        per_page: int = 20,
        sort_by: Optional[str] = None,
        view_id: Optional[Union[int, str]] = None,
        issue_ids: Optional[str] = None,
        filter_: Optional[Union[str, Dict[str, Any]]] = None,
    ) -> List[Issue]:
        """Retrieve issues across the entire portal."""

        endpoint = f"/portal/{self._portal_id}/issues"
        params = self._build_list_params(
            page=page,
            per_page=per_page,
            sort_by=sort_by,
            view_id=view_id,
            issue_ids=issue_ids,
            filter_=filter_,
        )
        response_data = await self._client.get(endpoint, params=params)
        return [Issue.model_validate(issue) for issue in response_data.get("bugs", [])]

    async def list_by_project(
        self,
        project_id: Union[int, str],
        *,
        page: int = 1,
        per_page: int = 20,
        sort_by: Optional[str] = None,
        view_id: Optional[Union[int, str]] = None,
        issue_ids: Optional[str] = None,
        filter_: Optional[Union[str, Dict[str, Any]]] = None,
    ) -> List[Issue]:
        """Retrieve issues scoped to a single project."""

        endpoint = f"/portal/{self._portal_id}/projects/{project_id}/issues"
        params = self._build_list_params(
            page=page,
            per_page=per_page,
            sort_by=sort_by,
            view_id=view_id,
            issue_ids=issue_ids,
            filter_=filter_,
        )
        response_data = await self._client.get(endpoint, params=params)
        return [Issue.model_validate(issue) for issue in response_data.get("bugs", [])]

    async def get(
        self, project_id: Union[int, str], issue_id: Union[int, str]
    ) -> Issue:
        """Fetch details for a specific issue within a project."""

        endpoint = f"/portal/{self._portal_id}/projects/{project_id}/issues/{issue_id}"
        response_data = await self._client.get(endpoint)
        issues = response_data.get("bugs", [])
        if issues:
            return Issue.model_validate(issues[0])
        return Issue.model_construct(id=None)

    async def create(
        self,
        project_id: Union[int, str],
        issue_data: Union[IssueCreateRequest, Issue, Dict[str, Any]],
    ) -> Issue:
        """Create an issue within the specified project."""

        endpoint = f"/portal/{self._portal_id}/projects/{project_id}/issues"
        payload = self._serialize_payload(issue_data)
        response_data = await self._client.post(endpoint, json=payload)
        issue = response_data.get("issue") or response_data.get("bug", {})
        return Issue.model_validate(issue)

    async def update(
        self,
        project_id: Union[int, str],
        issue_id: Union[int, str],
        issue_data: Union[IssueUpdateRequest, Issue, Dict[str, Any]],
    ) -> Issue:
        """Update an issue within the specified project."""

        endpoint = f"/portal/{self._portal_id}/projects/{project_id}/issues/{issue_id}"
        payload = self._serialize_payload(issue_data)
        response_data = await self._client.patch(endpoint, json=payload)
        issue = response_data.get("issue") or response_data.get("bug", {})
        return Issue.model_validate(issue)

    async def delete(
        self, project_id: Union[int, str], issue_id: Union[int, str]
    ) -> bool:
        """Delete an issue by its ID within a project."""

        endpoint = f"/portal/{self._portal_id}/projects/{project_id}/issues/{issue_id}"
        await self._client.delete(endpoint)
        return True

    async def get_all(
        self, project_id: Union[int, str], page: int = 1, per_page: int = 20
    ) -> List[Issue]:
        """Backward compatible alias for list_by_project."""

        return await self.list_by_project(project_id, page=page, per_page=per_page)

    @staticmethod
    def _build_list_params(
        *,
        page: int,
        per_page: int,
        sort_by: Optional[str],
        view_id: Optional[Union[int, str]],
        issue_ids: Optional[str],
        filter_: Optional[Union[str, Dict[str, Any]]],
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {"page": page, "per_page": per_page}
        if sort_by is not None:
            params["sort_by"] = sort_by
        if view_id is not None:
            params["view_id"] = view_id
        if issue_ids is not None:
            params["issue_ids"] = issue_ids
        if filter_ is not None:
            filter_value = filter_ if isinstance(filter_, str) else json.dumps(filter_)
            params["filter"] = filter_value
        return params

    @staticmethod
    def _serialize_payload(
        data: Union[IssueCreateRequest, IssueUpdateRequest, Issue, Dict[str, Any]],
    ) -> Dict[str, Any]:
        if isinstance(data, BaseModel):
            return data.model_dump(by_alias=True, exclude_none=True)
        if isinstance(data, dict):
            return {key: value for key, value in data.items() if value is not None}
        raise TypeError(
            "issue_data must be an IssueCreateRequest, IssueUpdateRequest, "
            "Issue, or dict"
        )


# Backwards compatibility alias for naming consistency
IssuesAPI = BugsAPI

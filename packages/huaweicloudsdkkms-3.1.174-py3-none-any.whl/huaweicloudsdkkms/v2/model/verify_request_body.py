# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class VerifyRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'key_id': 'str',
        'message': 'str',
        'signature': 'str',
        'signing_algorithm': 'str',
        'message_type': 'str',
        'sequence': 'str'
    }

    attribute_map = {
        'key_id': 'key_id',
        'message': 'message',
        'signature': 'signature',
        'signing_algorithm': 'signing_algorithm',
        'message_type': 'message_type',
        'sequence': 'sequence'
    }

    def __init__(self, key_id=None, message=None, signature=None, signing_algorithm=None, message_type=None, sequence=None):
        r"""VerifyRequestBody

        The model defined in huaweicloud sdk

        :param key_id: 密钥ID，36字节，满足正则匹配“^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$”。 例如：0d0466b0-e727-4d9c-b35d-f84bb474a37f。
        :type key_id: str
        :param message: 待签名的消息摘要或者消息，消息长度要求小于4096字节，使用Base64编码。
        :type message: str
        :param signature: 待验证的签名值，使用Base64编码。
        :type signature: str
        :param signing_algorithm: 签名算法，枚举如下：  - RSASSA_PSS_SHA_256  - RSASSA_PSS_SHA_384  - RSASSA_PSS_SHA_512  - RSASSA_PKCS1_V1_5_SHA_256  - RSASSA_PKCS1_V1_5_SHA_384  - RSASSA_PKCS1_V1_5_SHA_512  - ECDSA_SHA_256  - ECDSA_SHA_384  - ECDSA_SHA_512  - SM2DSA_SM3
        :type signing_algorithm: str
        :param message_type: 消息类型，默认为“DIGEST”，枚举如下：  - DIGEST 表示消息摘要  - RAW 表示消息原文
        :type message_type: str
        :param sequence: 请求消息序列号，36字节序列号。 例如：919c82d4-8046-4722-9094-35c3c6524cff。
        :type sequence: str
        """
        
        

        self._key_id = None
        self._message = None
        self._signature = None
        self._signing_algorithm = None
        self._message_type = None
        self._sequence = None
        self.discriminator = None

        self.key_id = key_id
        self.message = message
        self.signature = signature
        self.signing_algorithm = signing_algorithm
        if message_type is not None:
            self.message_type = message_type
        if sequence is not None:
            self.sequence = sequence

    @property
    def key_id(self):
        r"""Gets the key_id of this VerifyRequestBody.

        密钥ID，36字节，满足正则匹配“^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$”。 例如：0d0466b0-e727-4d9c-b35d-f84bb474a37f。

        :return: The key_id of this VerifyRequestBody.
        :rtype: str
        """
        return self._key_id

    @key_id.setter
    def key_id(self, key_id):
        r"""Sets the key_id of this VerifyRequestBody.

        密钥ID，36字节，满足正则匹配“^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$”。 例如：0d0466b0-e727-4d9c-b35d-f84bb474a37f。

        :param key_id: The key_id of this VerifyRequestBody.
        :type key_id: str
        """
        self._key_id = key_id

    @property
    def message(self):
        r"""Gets the message of this VerifyRequestBody.

        待签名的消息摘要或者消息，消息长度要求小于4096字节，使用Base64编码。

        :return: The message of this VerifyRequestBody.
        :rtype: str
        """
        return self._message

    @message.setter
    def message(self, message):
        r"""Sets the message of this VerifyRequestBody.

        待签名的消息摘要或者消息，消息长度要求小于4096字节，使用Base64编码。

        :param message: The message of this VerifyRequestBody.
        :type message: str
        """
        self._message = message

    @property
    def signature(self):
        r"""Gets the signature of this VerifyRequestBody.

        待验证的签名值，使用Base64编码。

        :return: The signature of this VerifyRequestBody.
        :rtype: str
        """
        return self._signature

    @signature.setter
    def signature(self, signature):
        r"""Sets the signature of this VerifyRequestBody.

        待验证的签名值，使用Base64编码。

        :param signature: The signature of this VerifyRequestBody.
        :type signature: str
        """
        self._signature = signature

    @property
    def signing_algorithm(self):
        r"""Gets the signing_algorithm of this VerifyRequestBody.

        签名算法，枚举如下：  - RSASSA_PSS_SHA_256  - RSASSA_PSS_SHA_384  - RSASSA_PSS_SHA_512  - RSASSA_PKCS1_V1_5_SHA_256  - RSASSA_PKCS1_V1_5_SHA_384  - RSASSA_PKCS1_V1_5_SHA_512  - ECDSA_SHA_256  - ECDSA_SHA_384  - ECDSA_SHA_512  - SM2DSA_SM3

        :return: The signing_algorithm of this VerifyRequestBody.
        :rtype: str
        """
        return self._signing_algorithm

    @signing_algorithm.setter
    def signing_algorithm(self, signing_algorithm):
        r"""Sets the signing_algorithm of this VerifyRequestBody.

        签名算法，枚举如下：  - RSASSA_PSS_SHA_256  - RSASSA_PSS_SHA_384  - RSASSA_PSS_SHA_512  - RSASSA_PKCS1_V1_5_SHA_256  - RSASSA_PKCS1_V1_5_SHA_384  - RSASSA_PKCS1_V1_5_SHA_512  - ECDSA_SHA_256  - ECDSA_SHA_384  - ECDSA_SHA_512  - SM2DSA_SM3

        :param signing_algorithm: The signing_algorithm of this VerifyRequestBody.
        :type signing_algorithm: str
        """
        self._signing_algorithm = signing_algorithm

    @property
    def message_type(self):
        r"""Gets the message_type of this VerifyRequestBody.

        消息类型，默认为“DIGEST”，枚举如下：  - DIGEST 表示消息摘要  - RAW 表示消息原文

        :return: The message_type of this VerifyRequestBody.
        :rtype: str
        """
        return self._message_type

    @message_type.setter
    def message_type(self, message_type):
        r"""Sets the message_type of this VerifyRequestBody.

        消息类型，默认为“DIGEST”，枚举如下：  - DIGEST 表示消息摘要  - RAW 表示消息原文

        :param message_type: The message_type of this VerifyRequestBody.
        :type message_type: str
        """
        self._message_type = message_type

    @property
    def sequence(self):
        r"""Gets the sequence of this VerifyRequestBody.

        请求消息序列号，36字节序列号。 例如：919c82d4-8046-4722-9094-35c3c6524cff。

        :return: The sequence of this VerifyRequestBody.
        :rtype: str
        """
        return self._sequence

    @sequence.setter
    def sequence(self, sequence):
        r"""Sets the sequence of this VerifyRequestBody.

        请求消息序列号，36字节序列号。 例如：919c82d4-8046-4722-9094-35c3c6524cff。

        :param sequence: The sequence of this VerifyRequestBody.
        :type sequence: str
        """
        self._sequence = sequence

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, VerifyRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

"""Tests for collection services."""

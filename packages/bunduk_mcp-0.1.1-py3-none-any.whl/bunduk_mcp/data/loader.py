"""Data loading and indexing functionality for BiogRef and TextRef datasets."""

import csv
import os
from pathlib import Path
from typing import Dict, List, Optional, Any, Set
import logging
from ..schemas import Person, TextRefLite

logger = logging.getLogger(__name__)


class DataRegistry:
    """Registry for loading and indexing BiogRef/TextRef CSV files."""

    def __init__(self, references_dir: Optional[str] = None, active_dir: Optional[str] = None):
        """Initialize the data registry.

        Args:
            references_dir: Path to the references directory containing CSV files
            active_dir: Path to the active data directory (alternative to references_dir)
        """
        self.references_dir = Path(active_dir or references_dir or "references")
        self._person_indices: Dict[str, Dict[str, Person]] = {}
        self._text_indices: Dict[str, Dict[str, TextRefLite]] = {}
        self._meta_data: Dict[str, Any] = {}

    def load_all(self) -> None:
        """Load all available datasets."""
        self._load_biogref_datasets()
        self._load_textref_datasets()

    def _load_biogref_datasets(self) -> None:
        """Load all biographical reference datasets."""
        biogref_files = list(self.references_dir.glob("biogref-*-data.csv"))

        for data_file in biogref_files:
            source = data_file.stem.replace("-data", "").replace("biogref-", "")
            try:
                persons = self._load_biogref_file(data_file)
                self._person_indices[source] = {p.person_id: p for p in persons}
                logger.info(f"Loaded {len(persons)} persons from {source}")
            except Exception as e:
                logger.error(f"Error loading {data_file}: {e}")

    def _load_textref_datasets(self) -> None:
        """Load all textual reference datasets."""
        textref_files = list(self.references_dir.glob("textref*.csv"))

        for data_file in textref_files:
            # Extract source name from filename
            if "textref-" in data_file.name:
                source = data_file.stem.replace("-data", "").replace("textref-", "")
            else:
                source = data_file.stem.replace("textref", "")

            try:
                texts = self._load_textref_file(data_file)
                self._text_indices[source] = {t.primary_id: t for t in texts}
                logger.info(f"Loaded {len(texts)} texts from {source}")
            except Exception as e:
                logger.error(f"Error loading {data_file}: {e}")

    def _load_biogref_file(self, file_path: Path) -> List[Person]:
        """Load persons from a biographical reference CSV file."""
        persons = []

        with open(file_path, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    person = Person(
                        person_id=row.get('person_id', ''),
                        name=row.get('name', ''),
                        zi=row.get('zi', ''),
                        hao=row.get('hao', ''),
                        dynasty=row.get('dynasty', ''),
                        birth_year=row.get('birth_year', ''),
                        death_year=row.get('death_year', ''),
                        source=row.get('source', ''),
                        notes=row.get('notes', '')
                    )
                    persons.append(person)
                except Exception as e:
                    logger.warning(f"Error parsing person row: {e}")

        return persons

    def _load_textref_file(self, file_path: Path) -> List[TextRefLite]:
        """Load texts from a textual reference CSV file."""
        texts = []

        with open(file_path, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    text = TextRefLite(
                        primary_id=row.get('primary_id', ''),
                        title=row.get('title', ''),
                        author=row.get('author', ''),
                        dynasty=row.get('dynasty', ''),
                        genre=row.get('genre', ''),
                        has_fulltext=row.get('has_fulltext', '').lower() == 'true',
                        source=row.get('source', ''),
                        notes=row.get('notes', '')
                    )
                    texts.append(text)
                except Exception as e:
                    logger.warning(f"Error parsing text row: {e}")

        return texts

    def search_persons(self, query: str, sources: Optional[List[str]] = None) -> List[Person]:
        """Search for persons by name or other fields."""
        results = []

        sources_to_search = sources or list(self._person_indices.keys())

        for source in sources_to_search:
            if source not in self._person_indices:
                continue

            for person in self._person_indices[source].values():
                if self._matches_query(person, query):
                    results.append(person)

        return results

    def search_texts(self, query: str, sources: Optional[List[str]] = None) -> List[TextRefLite]:
        """Search for texts by title or other fields."""
        results = []

        sources_to_search = sources or list(self._text_indices.keys())

        for source in sources_to_search:
            if source not in self._text_indices:
                continue

            for text in self._text_indices[source].values():
                if self._matches_text_query(text, query):
                    results.append(text)

        return results

    def get_person(self, person_id: str, source: str) -> Optional[Person]:
        """Get a specific person by ID and source."""
        return self._person_indices.get(source, {}).get(person_id)

    def get_text(self, primary_id: str, source: str) -> Optional[TextRefLite]:
        """Get a specific text by ID and source."""
        return self._text_indices.get(source, {}).get(primary_id)

    def _matches_query(self, person: Person, query: str) -> bool:
        """Check if a person matches the search query."""
        query_lower = query.lower()

        return (
            query_lower in person.name.lower() or
            (person.zi and query_lower in person.zi.lower()) or
            (person.hao and query_lower in person.hao.lower()) or
            (person.dynasty and query_lower in person.dynasty.lower())
        )

    def _matches_text_query(self, text: TextRefLite, query: str) -> bool:
        """Check if a text matches the search query."""
        query_lower = query.lower()

        return (
            query_lower in text.title.lower() or
            (text.author and query_lower in text.author.lower()) or
            (text.dynasty and query_lower in text.dynasty.lower()) or
            (text.genre and query_lower in text.genre.lower())
        )

    def get_available_sources(self) -> Dict[str, List[str]]:
        """Get lists of available data sources."""
        return {
            "persons": list(self._person_indices.keys()),
            "texts": list(self._text_indices.keys())
        }
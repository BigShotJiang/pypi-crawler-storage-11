"""django-temp-permissions exceptions."""

# customTraceback

## A quick and easy way to customize your Python tracebacks

```py
import customTraceback

def myTraceback(name, value, tb, line): 
    print(f"🔥 Exception: {name}") # name: name of the exception
    print(f"💬 {value}") # value: Value (description) of the exception
    print(f"📜 Trace: {tb}") # tb: Traceback (default traceback without colors)
    print(f"📄 At Line: {line}") # line: the line number (string)

customTraceback.setTraceBack(myTraceback)

1 / 0
```
### This replaces any Exception with a custom traceback, but in this example, it raises zerodevisionerror
**This is a basic example this package is a fun package to make cool tracebacks**
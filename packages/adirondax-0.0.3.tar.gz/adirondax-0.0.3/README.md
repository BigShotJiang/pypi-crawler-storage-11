<p align="center">
  <a href="https://adirondax.readthedocs.io">
    <img src="docs/_static/adirondax-logo.svg" alt="adirondax" width="400"/>
  </a>
</p>

# adirondax

[![Repo Status][status-badge]][status-link]
[![PyPI Version Status][pypi-badge]][pypi-link]
[![Test Status][workflow-test-badge]][workflow-test-link]
[![Coverage][coverage-badge]][coverage-link]
[![Ruff][ruff-badge]][ruff-link]
[![asv][asv-badge]][asv-link]
[![Readthedocs Status][docs-badge]][docs-link]
[![License][license-badge]][license-link]

[status-link]:         https://www.repostatus.org/#active
[status-badge]:        https://www.repostatus.org/badges/latest/active.svg
[pypi-link]:           https://pypi.org/project/adirondax
[pypi-badge]:          https://img.shields.io/pypi/v/adirondax?label=PyPI&logo=pypi
[workflow-test-link]:  https://github.com/AdirondaxProject/adirondax/actions/workflows/test-package.yml
[workflow-test-badge]: https://github.com/AdirondaxProject/adirondax/actions/workflows/test-package.yml/badge.svg?event=push
[coverage-link]:       https://app.codecov.io/gh/AdirondaxProject/adirondax
[coverage-badge]:      https://codecov.io/github/adirondaxproject/adirondax/graph/adirondax-server/badge.svg
[ruff-link]:           https://github.com/astral-sh/ruff
[ruff-badge]:          https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json
[asv-link]:            https://adirondaxproject.github.io/adirondax-benchmarks/
[asv-badge]:           https://img.shields.io/badge/benchmarked%20by-asv-blue.svg?style=flat
[docs-link]:           https://adirondax.readthedocs.io
[docs-badge]:          https://readthedocs.org/projects/adirondax/badge
[license-link]:        https://opensource.org/licenses/Apache-2.0
[license-badge]:       https://img.shields.io/badge/License-Apache_2.0-blue.svg

A differentiable astrophysics simulator in JAX

Author: [Philip Mocz (@pmocz)](https://github.com/pmocz/)

⚠️ Adirondax is currently being built and is not yet ready for use. Check back later ⚠️

Adirondax is a scientific research software for conducting astrophysical and cosmological simulations and solving inverse problems. It is written in JAX and GPU-ready.

Adirondax has a simpler companion project dedicated to Fuzzy Dark Matter simulations: [Jaxion](https://github.com/JaxionProject/jaxion)


## Getting started

Install with 

```console
pip install adirondax
```


## Examples

Check out the `examples/` directory for demonstrations of using Adirondax.


## Links

* [Code repository](https://github.com/AdirondaxProject/adirondax) on GitHub (this page).
* [Documentation](https://adirondax.readthedocs.io) for up-to-date information about installing and running adirondax.
* [asv benchmarks](https://adirondaxproject.github.io/adirondax-benchmarks) to view timing of benchmark test problems (for Developers).


## Cite this repository


# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListAgenciesResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'existing_agencies': 'list[AgenciesInfo]'
    }

    attribute_map = {
        'existing_agencies': 'existing_agencies'
    }

    def __init__(self, existing_agencies=None):
        r"""ListAgenciesResponse

        The model defined in huaweicloud sdk

        :param existing_agencies: 委托信息。
        :type existing_agencies: list[:class:`huaweicloudsdkworkspace.v2.AgenciesInfo`]
        """
        
        super().__init__()

        self._existing_agencies = None
        self.discriminator = None

        if existing_agencies is not None:
            self.existing_agencies = existing_agencies

    @property
    def existing_agencies(self):
        r"""Gets the existing_agencies of this ListAgenciesResponse.

        委托信息。

        :return: The existing_agencies of this ListAgenciesResponse.
        :rtype: list[:class:`huaweicloudsdkworkspace.v2.AgenciesInfo`]
        """
        return self._existing_agencies

    @existing_agencies.setter
    def existing_agencies(self, existing_agencies):
        r"""Sets the existing_agencies of this ListAgenciesResponse.

        委托信息。

        :param existing_agencies: The existing_agencies of this ListAgenciesResponse.
        :type existing_agencies: list[:class:`huaweicloudsdkworkspace.v2.AgenciesInfo`]
        """
        self._existing_agencies = existing_agencies

    def to_dict(self):
        import warnings
        warnings.warn("ListAgenciesResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListAgenciesResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

"""Tests for KohakuVault."""

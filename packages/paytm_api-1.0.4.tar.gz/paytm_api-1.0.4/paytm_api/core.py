import hmac
import hashlib
import json
import requests

def verify_paytm(mid: str, order_id: str) -> dict:

    if not mid or not order_id:
        return {"RESPCODE": "335", "RESPMSG": "Missing parameters 'mid' or 'order_id'"}

    if len(mid) >= 36 or len(order_id) <= 6:
        return {"RESPCODE": "335", "RESPMSG": "Invalid parameters."}

    try:
        data = {"MID": mid, "ORDERID": order_id}
        json_data = json.dumps(data)

        # Create checksum using HMAC SHA256
        checksum = hmac.new(mid.encode(), json_data.encode(), hashlib.sha256).hexdigest()

        # Paytm API endpoint
        url = (
            "https://securegw.paytm.in/merchant-status/getTxnStatus"
            f"?JsonData={requests.utils.quote(json_data)}"
            f"&CHECKSUMHASH={requests.utils.quote(checksum)}"
        )

        response = requests.get(url, timeout=10)
        return response.json() if response.ok else {"RESPCODE": "500", "RESPMSG": "Failed to contact Paytm"}

    except Exception as e:
        return {"RESPCODE": "500", "RESPMSG": str(e)}

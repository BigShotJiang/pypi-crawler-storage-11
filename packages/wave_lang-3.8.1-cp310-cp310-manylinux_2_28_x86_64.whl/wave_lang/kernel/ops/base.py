"""Support for defining the op library and dispatch."""

import functools
from typing import Type, TypeVar

from .._support import context

T = TypeVar("T")
OpDispatcherT = TypeVar("OpDispatcherT", bound="OpDispatcher")


class OpDispatcher:
    """Handles dispatch of operations by their idname.

    Operations are dispatched by looking up a function on the dispatcher like:
      def handle_{idname}(self, operator, *args, **kwargs)
    """

    __wave_context_idname__ = "OpDispatcher"

    @classmethod
    def current(cls: Type[OpDispatcherT]) -> OpDispatcherT:
        return context.current(cls)

    def __enter__(self) -> "OpDispatcher":
        return context.push(OpDispatcher, self)

    def __exit__(self, exc_type, exc_val, exc_tb):
        context.pop(OpDispatcher, self)


def define_op(f: T) -> T:
    idname = f.__name__

    @functools.wraps(f)
    def wrapped(*args, **kwargs):
        dispatcher = OpDispatcher.current()
        try:
            handler = getattr(dispatcher, f"handle_{idname}")
        except AttributeError:
            raise AttributeError(
                f"The current OpDispatcher ({dispatcher}) does not register a handler for {idname}"
            )
        return handler(wrapped, *args, **kwargs)

    wrapped.__wave_op_idname__ = idname
    return wrapped


def define_schedule_op(f: T) -> T:
    idname = f.__name__

    @functools.wraps(f)
    def wrapped(*args, **kwargs):
        dispatcher = OpDispatcher.current()
        try:
            handler = getattr(dispatcher, f"handle_{idname}")
        except AttributeError:
            raise AttributeError(
                f"The current OpDispatcher ({dispatcher}) does not register a handler for {idname}"
            )
        return handler(*args, **kwargs)

    wrapped.__wave_schedule_op_idname__ = idname
    return wrapped

from setuptools import setup, find_packages

setup(
    name='mytestpkg-bipin',  # change name if already taken
    version='0.0.1',
    packages=find_packages(),
    author='Bipin Yadav',
    description='A test pip package for global upload verification',
    long_description='This is a test package to verify new PyPI account setup.',
    long_description_content_type='text/plain',
    url='https://pypi.org/project/mytestpkg-bipin/',
)


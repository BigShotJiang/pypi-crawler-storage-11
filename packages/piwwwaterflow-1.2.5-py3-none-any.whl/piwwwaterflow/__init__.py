""" _init_ """
__version__ = "1.2.5"

from .webservice import PiWWWaterflowService

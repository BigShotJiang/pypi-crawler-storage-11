import { R as Wo, L as qo, c as Zo, A as yn, i as Go, __tla as __tla_0 } from "./index-wfwXefED.js";
import { d as oe, p as yt, b as bt, i as de, r as R, A as N, o as x, a3 as xe, f as G, au as Jo, R as Ue, B as y, S as re, G as W, I as ie, J as K, j as Z, u as S, N as J, H as A, as as ct, a2 as ot, K as H, a8 as ao, a9 as Ze, V as le, W as we, a1 as At, aA as bn, aB as kn, M as Te, a0 as Xt, ag as Ko, a4 as en, a6 as tn, aC as io, ai as lo, aD as Yo, a as Dt, U as $t, ah as Qo, g as ge, x as nn, am as Ne, aE as Xo, L as es, aF as wn, aG as ts, aH as ns, ad as co, y as uo, aI as po, aj as os, n as Be, aJ as ss, aw as rs, s as et, z as as, h as Je, aK as on, af as xn, aL as _n, aM as is, aN as ls, aO as cs, aP as fo, aQ as us, aR as ds, aS as ps, a5 as Ft, O as Oe, Q as kt, aT as fs, aU as hs, w as ho, aV as gs, aW as ms, aX as vs, aY as ys } from "./primevue-BhybIXDC.js";
import { a as bs, b as ks, g as go, c as ws, i as xs, d as _s, e as Cs, f as Ss, h as $s, S as Ts, M as Es, s as Os, j as mo, k as Rs, l as Ps } from "./jupyterlab-Bq9OOClR.js";
import { _ as Tt } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import { E as Ve, V as tt, J as vo, Z as As, _ as Is, Q as Bs, $ as Ns, a0 as js, S as Ms, a1 as Ls, a2 as Vs, f as U, a3 as zs, a4 as Cn, a5 as Ds, a6 as Fs, a7 as Us, H as Hs, a8 as Sn, r as Ws, a9 as qs } from "./codemirror-CEJpu35t.js";
import { r as Zs, u as Gs } from "./xlsx-C3u7rb2R.js";
let ze, Fl, Qc, Kc, Jc, Ho, Yc, Uc, Gc, wr, Wc, Pl, Zc, Hc, Fc, xo, qc, Xi, mt, rt, te, Co, yr, Ut, _o, Xc;
let __tla = Promise.all([
    (()=>{
        try {
            return __tla_0;
        } catch  {}
    })()
]).then(async ()=>{
    const Js = {};
    var Ks = bs(), wt = ks();
    const pe = [];
    for(let t = 0; t < 256; ++t)pe.push((t + 256).toString(16).slice(1));
    function Ys(t, e = 0) {
        return (pe[t[e + 0]] + pe[t[e + 1]] + pe[t[e + 2]] + pe[t[e + 3]] + "-" + pe[t[e + 4]] + pe[t[e + 5]] + "-" + pe[t[e + 6]] + pe[t[e + 7]] + "-" + pe[t[e + 8]] + pe[t[e + 9]] + "-" + pe[t[e + 10]] + pe[t[e + 11]] + pe[t[e + 12]] + pe[t[e + 13]] + pe[t[e + 14]] + pe[t[e + 15]]).toLowerCase();
    }
    let It;
    const Qs = new Uint8Array(16);
    function Xs() {
        if (!It) {
            if (typeof crypto > "u" || !crypto.getRandomValues) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
            It = crypto.getRandomValues.bind(crypto);
        }
        return It(Qs);
    }
    const er = typeof crypto < "u" && crypto.randomUUID && crypto.randomUUID.bind(crypto), $n = {
        randomUUID: er
    };
    function st(t, e, n) {
        if ($n.randomUUID && !t) return $n.randomUUID();
        t = t || {};
        const o = t.random ?? t.rng?.() ?? Xs();
        if (o.length < 16) throw new Error("Random bytes length must be >= 16");
        return o[6] = o[6] & 15 | 64, o[8] = o[8] & 63 | 128, Ys(o);
    }
    var fe = typeof globalThis < "u" && globalThis || typeof self < "u" && self || typeof global < "u" && global || {}, ve = {
        searchParams: "URLSearchParams" in fe,
        iterable: "Symbol" in fe && "iterator" in Symbol,
        blob: "FileReader" in fe && "Blob" in fe && (function() {
            try {
                return new Blob, !0;
            } catch  {
                return !1;
            }
        })(),
        formData: "FormData" in fe,
        arrayBuffer: "ArrayBuffer" in fe
    };
    function tr(t) {
        return t && DataView.prototype.isPrototypeOf(t);
    }
    if (ve.arrayBuffer) var nr = [
        "[object Int8Array]",
        "[object Uint8Array]",
        "[object Uint8ClampedArray]",
        "[object Int16Array]",
        "[object Uint16Array]",
        "[object Int32Array]",
        "[object Uint32Array]",
        "[object Float32Array]",
        "[object Float64Array]"
    ], or = ArrayBuffer.isView || function(t) {
        return t && nr.indexOf(Object.prototype.toString.call(t)) > -1;
    };
    function Ke(t) {
        if (typeof t != "string" && (t = String(t)), /[^a-z0-9\-#$%&'*+.^_`|~!]/i.test(t) || t === "") throw new TypeError('Invalid character in header field name: "' + t + '"');
        return t.toLowerCase();
    }
    function sn(t) {
        return typeof t != "string" && (t = String(t)), t;
    }
    function rn(t) {
        var e = {
            next: function() {
                var n = t.shift();
                return {
                    done: n === void 0,
                    value: n
                };
            }
        };
        return ve.iterable && (e[Symbol.iterator] = function() {
            return e;
        }), e;
    }
    function ce(t) {
        this.map = {}, t instanceof ce ? t.forEach(function(e, n) {
            this.append(n, e);
        }, this) : Array.isArray(t) ? t.forEach(function(e) {
            if (e.length != 2) throw new TypeError("Headers constructor: expected name/value pair to be length 2, found" + e.length);
            this.append(e[0], e[1]);
        }, this) : t && Object.getOwnPropertyNames(t).forEach(function(e) {
            this.append(e, t[e]);
        }, this);
    }
    ce.prototype.append = function(t, e) {
        t = Ke(t), e = sn(e);
        var n = this.map[t];
        this.map[t] = n ? n + ", " + e : e;
    };
    ce.prototype.delete = function(t) {
        delete this.map[Ke(t)];
    };
    ce.prototype.get = function(t) {
        return t = Ke(t), this.has(t) ? this.map[t] : null;
    };
    ce.prototype.has = function(t) {
        return this.map.hasOwnProperty(Ke(t));
    };
    ce.prototype.set = function(t, e) {
        this.map[Ke(t)] = sn(e);
    };
    ce.prototype.forEach = function(t, e) {
        for(var n in this.map)this.map.hasOwnProperty(n) && t.call(e, this.map[n], n, this);
    };
    ce.prototype.keys = function() {
        var t = [];
        return this.forEach(function(e, n) {
            t.push(n);
        }), rn(t);
    };
    ce.prototype.values = function() {
        var t = [];
        return this.forEach(function(e) {
            t.push(e);
        }), rn(t);
    };
    ce.prototype.entries = function() {
        var t = [];
        return this.forEach(function(e, n) {
            t.push([
                n,
                e
            ]);
        }), rn(t);
    };
    ve.iterable && (ce.prototype[Symbol.iterator] = ce.prototype.entries);
    function Bt(t) {
        if (!t._noBody) {
            if (t.bodyUsed) return Promise.reject(new TypeError("Already read"));
            t.bodyUsed = !0;
        }
    }
    function yo(t) {
        return new Promise(function(e, n) {
            t.onload = function() {
                e(t.result);
            }, t.onerror = function() {
                n(t.error);
            };
        });
    }
    function sr(t) {
        var e = new FileReader, n = yo(e);
        return e.readAsArrayBuffer(t), n;
    }
    function rr(t) {
        var e = new FileReader, n = yo(e), o = /charset=([A-Za-z0-9_-]+)/.exec(t.type), s = o ? o[1] : "utf-8";
        return e.readAsText(t, s), n;
    }
    function ar(t) {
        for(var e = new Uint8Array(t), n = new Array(e.length), o = 0; o < e.length; o++)n[o] = String.fromCharCode(e[o]);
        return n.join("");
    }
    function Tn(t) {
        if (t.slice) return t.slice(0);
        var e = new Uint8Array(t.byteLength);
        return e.set(new Uint8Array(t)), e.buffer;
    }
    function bo() {
        return this.bodyUsed = !1, this._initBody = function(t) {
            this.bodyUsed = this.bodyUsed, this._bodyInit = t, t ? typeof t == "string" ? this._bodyText = t : ve.blob && Blob.prototype.isPrototypeOf(t) ? this._bodyBlob = t : ve.formData && FormData.prototype.isPrototypeOf(t) ? this._bodyFormData = t : ve.searchParams && URLSearchParams.prototype.isPrototypeOf(t) ? this._bodyText = t.toString() : ve.arrayBuffer && ve.blob && tr(t) ? (this._bodyArrayBuffer = Tn(t.buffer), this._bodyInit = new Blob([
                this._bodyArrayBuffer
            ])) : ve.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(t) || or(t)) ? this._bodyArrayBuffer = Tn(t) : this._bodyText = t = Object.prototype.toString.call(t) : (this._noBody = !0, this._bodyText = ""), this.headers.get("content-type") || (typeof t == "string" ? this.headers.set("content-type", "text/plain;charset=UTF-8") : this._bodyBlob && this._bodyBlob.type ? this.headers.set("content-type", this._bodyBlob.type) : ve.searchParams && URLSearchParams.prototype.isPrototypeOf(t) && this.headers.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8"));
        }, ve.blob && (this.blob = function() {
            var t = Bt(this);
            if (t) return t;
            if (this._bodyBlob) return Promise.resolve(this._bodyBlob);
            if (this._bodyArrayBuffer) return Promise.resolve(new Blob([
                this._bodyArrayBuffer
            ]));
            if (this._bodyFormData) throw new Error("could not read FormData body as blob");
            return Promise.resolve(new Blob([
                this._bodyText
            ]));
        }), this.arrayBuffer = function() {
            if (this._bodyArrayBuffer) {
                var t = Bt(this);
                return t || (ArrayBuffer.isView(this._bodyArrayBuffer) ? Promise.resolve(this._bodyArrayBuffer.buffer.slice(this._bodyArrayBuffer.byteOffset, this._bodyArrayBuffer.byteOffset + this._bodyArrayBuffer.byteLength)) : Promise.resolve(this._bodyArrayBuffer));
            } else {
                if (ve.blob) return this.blob().then(sr);
                throw new Error("could not read as ArrayBuffer");
            }
        }, this.text = function() {
            var t = Bt(this);
            if (t) return t;
            if (this._bodyBlob) return rr(this._bodyBlob);
            if (this._bodyArrayBuffer) return Promise.resolve(ar(this._bodyArrayBuffer));
            if (this._bodyFormData) throw new Error("could not read FormData body as text");
            return Promise.resolve(this._bodyText);
        }, ve.formData && (this.formData = function() {
            return this.text().then(cr);
        }), this.json = function() {
            return this.text().then(JSON.parse);
        }, this;
    }
    var ir = [
        "CONNECT",
        "DELETE",
        "GET",
        "HEAD",
        "OPTIONS",
        "PATCH",
        "POST",
        "PUT",
        "TRACE"
    ];
    function lr(t) {
        var e = t.toUpperCase();
        return ir.indexOf(e) > -1 ? e : t;
    }
    function De(t, e) {
        if (!(this instanceof De)) throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.');
        e = e || {};
        var n = e.body;
        if (t instanceof De) {
            if (t.bodyUsed) throw new TypeError("Already read");
            this.url = t.url, this.credentials = t.credentials, e.headers || (this.headers = new ce(t.headers)), this.method = t.method, this.mode = t.mode, this.signal = t.signal, !n && t._bodyInit != null && (n = t._bodyInit, t.bodyUsed = !0);
        } else this.url = String(t);
        if (this.credentials = e.credentials || this.credentials || "same-origin", (e.headers || !this.headers) && (this.headers = new ce(e.headers)), this.method = lr(e.method || this.method || "GET"), this.mode = e.mode || this.mode || null, this.signal = e.signal || this.signal || (function() {
            if ("AbortController" in fe) {
                var r = new AbortController;
                return r.signal;
            }
        })(), this.referrer = null, (this.method === "GET" || this.method === "HEAD") && n) throw new TypeError("Body not allowed for GET or HEAD requests");
        if (this._initBody(n), (this.method === "GET" || this.method === "HEAD") && (e.cache === "no-store" || e.cache === "no-cache")) {
            var o = /([?&])_=[^&]*/;
            if (o.test(this.url)) this.url = this.url.replace(o, "$1_=" + new Date().getTime());
            else {
                var s = /\?/;
                this.url += (s.test(this.url) ? "&" : "?") + "_=" + new Date().getTime();
            }
        }
    }
    De.prototype.clone = function() {
        return new De(this, {
            body: this._bodyInit
        });
    };
    function cr(t) {
        var e = new FormData;
        return t.trim().split("&").forEach(function(n) {
            if (n) {
                var o = n.split("="), s = o.shift().replace(/\+/g, " "), r = o.join("=").replace(/\+/g, " ");
                e.append(decodeURIComponent(s), decodeURIComponent(r));
            }
        }), e;
    }
    function ur(t) {
        var e = new ce, n = t.replace(/\r?\n[\t ]+/g, " ");
        return n.split("\r").map(function(o) {
            return o.indexOf(`
`) === 0 ? o.substr(1, o.length) : o;
        }).forEach(function(o) {
            var s = o.split(":"), r = s.shift().trim();
            if (r) {
                var a = s.join(":").trim();
                try {
                    e.append(r, a);
                } catch (i) {
                    console.warn("Response " + i.message);
                }
            }
        }), e;
    }
    bo.call(De.prototype);
    function Ee(t, e) {
        if (!(this instanceof Ee)) throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.');
        if (e || (e = {}), this.type = "default", this.status = e.status === void 0 ? 200 : e.status, this.status < 200 || this.status > 599) throw new RangeError("Failed to construct 'Response': The status provided (0) is outside the range [200, 599].");
        this.ok = this.status >= 200 && this.status < 300, this.statusText = e.statusText === void 0 ? "" : "" + e.statusText, this.headers = new ce(e.headers), this.url = e.url || "", this._initBody(t);
    }
    bo.call(Ee.prototype);
    Ee.prototype.clone = function() {
        return new Ee(this._bodyInit, {
            status: this.status,
            statusText: this.statusText,
            headers: new ce(this.headers),
            url: this.url
        });
    };
    Ee.error = function() {
        var t = new Ee(null, {
            status: 200,
            statusText: ""
        });
        return t.ok = !1, t.status = 0, t.type = "error", t;
    };
    var dr = [
        301,
        302,
        303,
        307,
        308
    ];
    Ee.redirect = function(t, e) {
        if (dr.indexOf(e) === -1) throw new RangeError("Invalid status code");
        return new Ee(null, {
            status: e,
            headers: {
                location: t
            }
        });
    };
    var Me = fe.DOMException;
    try {
        new Me;
    } catch  {
        Me = function(e, n) {
            this.message = e, this.name = n;
            var o = Error(e);
            this.stack = o.stack;
        }, Me.prototype = Object.create(Error.prototype), Me.prototype.constructor = Me;
    }
    function ko(t, e) {
        return new Promise(function(n, o) {
            var s = new De(t, e);
            if (s.signal && s.signal.aborted) return o(new Me("Aborted", "AbortError"));
            var r = new XMLHttpRequest;
            function a() {
                r.abort();
            }
            r.onload = function() {
                var l = {
                    statusText: r.statusText,
                    headers: ur(r.getAllResponseHeaders() || "")
                };
                s.url.indexOf("file://") === 0 && (r.status < 200 || r.status > 599) ? l.status = 200 : l.status = r.status, l.url = "responseURL" in r ? r.responseURL : l.headers.get("X-Request-URL");
                var p = "response" in r ? r.response : r.responseText;
                setTimeout(function() {
                    n(new Ee(p, l));
                }, 0);
            }, r.onerror = function() {
                setTimeout(function() {
                    o(new TypeError("Network request failed"));
                }, 0);
            }, r.ontimeout = function() {
                setTimeout(function() {
                    o(new TypeError("Network request timed out"));
                }, 0);
            }, r.onabort = function() {
                setTimeout(function() {
                    o(new Me("Aborted", "AbortError"));
                }, 0);
            };
            function i(l) {
                try {
                    return l === "" && fe.location.href ? fe.location.href : l;
                } catch  {
                    return l;
                }
            }
            if (r.open(s.method, i(s.url), !0), s.credentials === "include" ? r.withCredentials = !0 : s.credentials === "omit" && (r.withCredentials = !1), "responseType" in r && (ve.blob ? r.responseType = "blob" : ve.arrayBuffer && (r.responseType = "arraybuffer")), e && typeof e.headers == "object" && !(e.headers instanceof ce || fe.Headers && e.headers instanceof fe.Headers)) {
                var c = [];
                Object.getOwnPropertyNames(e.headers).forEach(function(l) {
                    c.push(Ke(l)), r.setRequestHeader(l, sn(e.headers[l]));
                }), s.headers.forEach(function(l, p) {
                    c.indexOf(p) === -1 && r.setRequestHeader(p, l);
                });
            } else s.headers.forEach(function(l, p) {
                r.setRequestHeader(p, l);
            });
            s.signal && (s.signal.addEventListener("abort", a), r.onreadystatechange = function() {
                r.readyState === 4 && s.signal.removeEventListener("abort", a);
            }), r.send(typeof s._bodyInit > "u" ? null : s._bodyInit);
        });
    }
    ko.polyfill = !0;
    fe.fetch || (fe.fetch = ko, fe.Headers = ce, fe.Request = De, fe.Response = Ee);
    var Nt, En;
    function pr() {
        return En || (En = 1, Nt = self.fetch.bind(self)), Nt;
    }
    var fr = pr();
    const hr = go(fr);
    var gr = ws(), On;
    (function(t) {
        t.unknown = "unknown", t.starting = "starting", t.idle = "idle", t.busy = "busy", t.terminating = "terminating", t.restarting = "restarting", t.autorestarting = "autorestarting", t.dead = "dead";
    })(On || (On = {}));
    const mr = (t)=>`beaker-${st().replaceAll("-", "").slice(0, 16)}-${t}`;
    class vr extends gr.KernelFutureHandler {
        constructor(e, n, o, s, r){
            if (!s) throw Error("Unable to send message. Not connected to kernel.");
            if (!r) throw Error("Cannot execute in cell as cell is undefined or invalid.");
            const a = e.header.msg_id;
            e.channel === void 0 && (e.channel = "shell");
            const i = ()=>{
                s._futures.delete(a);
            };
            super(i, e, n, o, s), s._futures?.set(a, this), this.cell = r, this.onIOPub = (c)=>Ge.handleIOPub(c, this.cell), this.onReply = (c)=>Ge.handleReply(c, this.cell);
        }
        cell;
    }
    var Ge;
    (function(t) {
        t.handleIOPub = (e, n)=>{
            const o = e.header.msg_type, s = e.content;
            o === "status" ? n.status = s.execution_state : o === "execute_result" ? (n.busy = !1, s.execution_count && (n.execution_count = s.execution_count), n.outputs.push({
                output_type: "execute_result",
                ...s
            })) : o === "stream" ? n.outputs.push({
                output_type: "stream",
                ...s
            }) : o === "display_data" && n.outputs.push({
                output_type: "display_data",
                ...s
            });
        }, t.handleReply = (e, n)=>{
            if (n.busy = !1, e.content.status === "ok") n.last_execution = {
                ...n.last_execution,
                status: "ok"
            }, n.execution_count = Number(e.content.execution_count);
            else if (e.content.status === "error") {
                n.execution_count = Number(e.content.execution_count);
                const o = {
                    ename: e.content.ename,
                    evalue: e.content.evalue,
                    traceback: e.content.traceback
                };
                n.last_execution = {
                    status: "error",
                    ...o
                }, n.outputs.push({
                    output_type: "error",
                    ...o
                });
            } else if (e.content.status === "abort") {
                n.execution_count = e.content.execution_count;
                const o = {
                    ename: "Execution aborted",
                    evalue: "Execution aborted",
                    traceback: []
                };
                n.last_execution = {
                    status: "error",
                    ...o
                }, n.outputs.push({
                    output_type: "error",
                    content: o
                });
            }
        };
    })(Ge || (Ge = {}));
    const ut = 1024 * 2;
    function wo(t) {
        const e = t.toIPynb(), n = e.cells;
        e.cells = [];
        for (const r of n){
            if (xs(r)) {
                for (const a of r.outputs)if (_s(a) || Cs(a)) for (const i of Object.keys(a.data))i.startsWith("text") || delete a.data[i];
                else if (Ss(a)) for (const i of Object.keys(a.data)){
                    var o = a.data[i];
                    JSON.stringify(o).length > ut && (Array.isArray(o) && o.every((l)=>typeof l == "string") && (o = o.join(`
`)), typeof o == "string" ? o = o.substring(0, ut) + " ... <truncated>" : o = `<item of type ${typeof o} removed due to size>`, a.data[i] = o);
                }
                else if ($s(a)) {
                    var s = a.text;
                    JSON.stringify(s).length > ut && (Array.isArray(s) && s.every((c)=>typeof c == "string") && (o = s.join(`
`)), typeof s == "string" ? s = s.substring(0, ut) + " ... <truncated>" : s = `<item of type ${typeof s} removed due to size>`, a.text = s);
                }
            }
            e.cells.push({
                ...r
            });
        }
        return e;
    }
    class Ie {
        static IPYNB_KEYS = [
            "cell_type",
            "source",
            "metadata",
            "id",
            "attachments",
            "outputs",
            "execution_count"
        ];
        id = Ie.generateId();
        metadata = {};
        source = "";
        status = "idle";
        children = [];
        constructor(e){
            Object.assign(this, e), e.id === void 0 && (this.id = Ie.generateId());
        }
        static generateId() {
            return st();
        }
        fromJSON(e) {
            Object.keys(e).forEach((n)=>{
                this[n] = e[n];
            });
        }
        toJSON() {
            return {
                ...this
            };
        }
        fromIPynb(e) {
            Object.keys(e).forEach((n)=>{
                this[n] = e[n];
            });
        }
        toIPynb() {
            const e = {};
            for (const n of Object.keys(this))Ie.IPYNB_KEYS.includes(n) && (e[n] = this[n]);
            return e;
        }
    }
    Ut = class extends Ie {
        cell_type = "raw";
        attachments;
        constructor(e){
            super(e), Object.assign(this, e);
        }
        execute(e) {
            return null;
        }
    };
    rt = class extends Ie {
        cell_type = "code";
        outputs = [];
        execution_count = null;
        last_execution = {
            status: "none"
        };
        busy = !1;
        constructor(e){
            super({
                ...e
            }), Object.assign(this, e), Array.isArray(this.source) && (this.source = this.source.join(""));
        }
        execute(e, n) {
            this.busy = !0;
            var o;
            return this.outputs.splice(0, this.outputs.length), n !== void 0 ? o = n : (o = e.sendBeakerMessage("execute_request", {
                code: this.source,
                silent: !1,
                store_history: !0,
                user_expressions: {},
                allow_stdin: !0,
                stop_on_error: !1
            }), o.onIOPub = (s)=>Ge.handleIOPub(s, this), o.onReply = (s)=>Ge.handleReply(s, this)), o;
        }
        rollback(e) {
            if (this?.last_execution?.status === "ok") {
                const n = e.executeAction("rollback", {
                    checkpoint_index: this.last_execution.checkpoint_index || null
                });
                return this.busy = !0, n.done.then((o)=>{
                    o.content.status === "ok" ? (this.busy = !1, this.last_execution = {
                        status: "none"
                    }, this.execution_count = null, this.outputs.splice(0, this.outputs.length), this.children.splice(0, this.children.length)) : o.content.status === "error" && (this.last_execution = o.content, this.outputs.push({
                        ...o.content,
                        output_type: "error"
                    }));
                }), n;
            }
            return null;
        }
        reset_execution_state() {
            this.last_execution = {
                status: "modified"
            };
        }
        toIPynb() {
            return {
                ...super.toIPynb(),
                cell_type: "code",
                outputs: this.outputs.map((n)=>({
                        ...n,
                        transient: void 0
                    })),
                execution_count: this.execution_count
            };
        }
    };
    ze = class extends Ie {
        static IPYNB_KEYS = [
            "cell_type",
            "source",
            "metadata",
            "id",
            "attachments"
        ];
        cell_type = "markdown";
        attachments;
        constructor(e){
            super({
                ...e
            }), Object.assign(this, e);
        }
        execute(e) {
            return null;
        }
        toIPynb() {
            const e = {};
            for (const n of Object.keys(this))ze.IPYNB_KEYS.includes(n) && (e[n] = this[n]);
            return e;
        }
    };
    xo = class extends Ie {
        cell_type = "query";
        events = [];
        _current_input_request_message;
        constructor(e){
            super({
                cell_type: "query",
                ...e
            }), Object.assign(this, e);
        }
        execute(e, n = !0) {
            this.events.splice(0, this.events.length), this.children.splice(0, this.children.length);
            let o = null;
            const s = async (l)=>{
                const p = l.header.msg_type, u = l.content;
                if (p === "status") this.status = u.execution_state;
                else if (p === "llm_thought") {
                    if (u.thought === "") return;
                    this.events.push({
                        type: "thought",
                        content: {
                            ...u,
                            background_code_executions: []
                        }
                    });
                } else if (p === "beaker__execute_input") u.execution_type === "tool" && u.execution_item_name == "run_code" || (o = {
                    ...u
                });
                else if (p === "beaker__execute_reply") {
                    if (!(u.execution_type === "tool" && u.execution_item_name == "run_code")) {
                        const f = (g)=>"type" in g && g.type === "thought";
                        let v = this.events.findLast(f);
                        v !== void 0 && v.content.background_code_executions.push({
                            ...o,
                            ...u
                        }), o = null;
                    }
                } else if (p === "llm_response" && u.name === "response_text") this.events.push({
                    type: "response",
                    content: u.text
                });
                else if (p === "code_cell") {
                    const f = e.notebook, v = new rt({
                        cell_type: "code",
                        source: u.code,
                        metadata: {
                            parent_cell: this.id
                        },
                        outputs: []
                    }), g = f.cells.findIndex((C)=>C.id === this.id);
                    g >= 0 ? e.notebook.cells.splice(g + 1, 0, v) : f.addCell(v);
                } else if (p === "add_child_codecell") {
                    const f = u.autoexecute, v = new rt({
                        cell_type: "code",
                        source: u.code,
                        metadata: {
                            parent_cell: this.id
                        },
                        outputs: [],
                        busy: !0
                    });
                    v.last_execution = {
                        status: "pending",
                        checkpoint_index: u.checkpoint_index
                    }, this.events.push({
                        type: "code_cell",
                        content: {
                            parent_id: this.id,
                            cell_id: v.id,
                            metadata: {}
                        }
                    }), this.children.push(v);
                    const g = this.children[this.children.length - 1];
                    if (f && u.execute_request_msg) {
                        const C = u.execute_request_msg;
                        new vr(C, !0, !0, e.kernel, g);
                    }
                } else if (p == "update_child_codecell") {
                    const f = u.id, v = this.children.find((C)=>C.id === f);
                    if (v == null) throw console.log("Can't find cell"), Error("Cell to be updated not found ");
                    v.execution_count = u.execution_count;
                    let g = {
                        status: u.execution_status
                    };
                    if (u.execution_status === "error") {
                        const C = {
                            ename: l.content.ename,
                            evalue: l.content.evalue,
                            traceback: l.content.traceback
                        };
                        v.outputs.push({
                            output_type: "error",
                            ...C
                        }), g = {
                            ...g,
                            ...C
                        };
                    } else g.status === "ok" && (g = {
                        ...g,
                        checkpoint_index: u.checkpoint_index
                    }, v.outputs.push({
                        output_type: "execute_result",
                        data: {
                            "text/plain": u.execution_return
                        }
                    }));
                    v.last_execution = g;
                }
            }, r = async (l)=>{
                wt.isInputRequestMsg(l) && (this.events.push({
                    type: "user_question",
                    content: l.content.prompt
                }), this.status = "awaiting_input", this._current_input_request_message = l);
            }, a = async (l)=>{
                if (l.content.status === "ok") this.last_execution = {
                    status: "ok"
                };
                else if (l.content.status === "error") {
                    const p = {
                        ename: l.content.ename,
                        evalue: l.content.evalue,
                        traceback: l.content.traceback
                    };
                    this.last_execution = {
                        status: "error",
                        ...p
                    }, this.events.push({
                        type: "error",
                        content: {
                            ...l.content
                        }
                    });
                } else l.content.status === "abort" && (this.last_execution = {
                    status: "abort"
                }, this.events.push({
                    type: "abort",
                    content: "Request aborted"
                }));
            };
            var i = {};
            if (n) {
                const l = wo(e.notebook);
                l.cells = l.cells.filter((p)=>p.id !== this.id && p.metadata?.parent_cell !== this.id), i.notebook_state = l;
            }
            const c = e.sendBeakerMessage("llm_request", {
                request: this.source
            }, void 0, i);
            return c.onIOPub = s, c.onStdin = r, c.onReply = a, c;
        }
        respond(e, n) {
            this.status !== "awaiting_input" || !this._current_input_request_message || (this.events.push({
                type: "user_answer",
                content: e
            }), n.kernel?.sendInputReply({
                value: e,
                status: "ok"
            }, this._current_input_request_message.header), this.status = "busy", this._current_input_request_message = void 0);
        }
        toMultipleCells() {
            class e extends String {
                prefix = "";
                suffix = "";
            }
            class n extends e {
                prefix = `
### Agent:
<div style="display: flex; width: 100%;">
<div style="padding: 0.2rem; margin: 0.2rem; margin-left: 4rem;">

`;
                suffix = `</div></div>

`;
            }
            class o extends n {
            }
            class s extends e {
                prefix = `
### User:
<div style="display: flex; width: 100%;">
<div style="padding: 0.2rem; margin: 0.2rem; margin-left: 4rem;">

`;
                suffix = `</div></div>

`;
            }
            const r = {
                ...this.metadata,
                beaker_cell_type: "query",
                prompt: this.source,
                events: this.events
            }, a = this.events.map((u)=>{
                if (u.type === "thought") return new n(`${u.content.thought}  
`);
                if (u.type === "user_question") return new n(`**Agent Question:**  
> ${u.content}
`);
                if (u.type === "user_answer") return new s(`**User Response:**  
> ${u.content}
`);
                if (u.type === "code_cell") {
                    const v = this.children.find((g)=>g.id === u.content.cell_id);
                    if (v === void 0) throw `Failed to find child cell ${u.content.cell_id} in children`;
                    return v.metadata.beaker_child_of = this.id, v.metadata.beakerQueryCellChild = !0, v;
                } else if (u.type === "response") {
                    var f;
                    return typeof u.content == "string" ? f = `
${u.content.split(`
`).map((g)=>/^\s*$/.test(g) ? "" : `${g}`).map((g)=>/^#+\s+/.test(g) ? `###${g}` : g).join(`
`)}` : f = `
${u.content}`, new o(f);
                } else return u.type === "abort" ? new e(u.content) : u.type === "error" ? new ze({
                    cell_type: "markdown",
                    id: st(),
                    source: [
                        JSON.stringify(u.content, void 0, 2)
                    ],
                    metadata: {
                        ...r,
                        parentQueryCell: !0,
                        beakerQueryCellChild: !0
                    }
                }) : new e(`Error: Unhandled query event type "${u.type}".`);
            });
            let i = [
                new s(`${this.source}`),
                ...a
            ], c = null, l = new ze({
                cell_type: "markdown",
                id: this.id,
                source: [],
                metadata: {
                    ...r,
                    parentQueryCell: !0
                }
            });
            const p = [
                l
            ];
            for (let u of i)u instanceof e ? (c === null && u.prefix && u.prefix && l.source.push(u.prefix), c === null || c.constructor === u.constructor ? l.source.push(u) : c instanceof e ? (c.suffix && l.source.push(c.suffix), u.prefix && l.source.push(u.prefix), l.source.push(u)) : (l = new ze({
                cell_type: "markdown",
                id: st(),
                source: [],
                metadata: {
                    skipWhenLoading: !0,
                    beakerQueryCellChild: !0
                }
            }), u instanceof o && (l.metadata.finalResponse = !0), u.prefix && l.source.push(u.prefix), l.source.push(u), p.push(l))) : (c instanceof e && c.suffix && l.source.push(c.suffix), p.push(u)), c = u;
            return p;
        }
        fromIPynb(e) {
            if (this.metadata.beaker_cell_type !== "query") throw TypeError("Cell is trying to be parsed as a query cell, but doesn't have the required metadata.");
            this.source = e.metadata.prompt, this.events = e.metadata.events;
        }
        toIPynb() {
            return this.toMultipleCells().flatMap((e)=>e.toIPynb());
        }
    };
    yr = class {
        constructor(){
            this.content = {
                nbformat: 4,
                nbformat_minor: 5,
                cells: [],
                metadata: {
                    kernelspec: {
                        display_name: "Beaker Kernel",
                        name: "beaker",
                        language: "beaker"
                    },
                    language_info: this.subkernelInfo
                }
            }, this.cells = new Proxy(this.content.cells, {});
        }
        toJSON() {
            return this.content.metadata.language_info = this.subkernelInfo, {
                ...this.content
            };
        }
        fromJSON(e) {
            Object.keys(e).forEach((n)=>{
                this.content[n] = e[n];
            }), this.cells = new Proxy(this.content.cells, {});
        }
        loadFromIPynb(e) {
            this.content.nbformat = e.nbformat, this.content.nbformat_minor = e.nbformat_minor;
            const n = e.cells.map((r)=>r.cell_type === "raw" ? new Ut(r) : r.cell_type === "code" ? new rt(r) : r.metadata.beaker_cell_type === "query" ? new xo({
                    cell_type: "query",
                    id: r.id,
                    source: r.metadata.prompt,
                    events: r.metadata.events,
                    metadata: r.metadata
                }) : r.cell_type === "markdown" ? r.metadata?.skipWhenLoading === !0 ? void 0 : new ze(r) : new Ut(r)).filter((r)=>r);
            let o = {};
            n.forEach((r)=>{
                o[r.id] = r;
            });
            let s = 0;
            for(; s < n.length;){
                const r = n[s];
                typeof r.metadata.beaker_child_of < "u" ? o[r.metadata.beaker_child_of].children.push(n.splice(s, 1)[0]) : s++;
            }
            this.cells.splice(0, this.cells.length, ...n), this.content.metadata = e.metadata;
        }
        toIPynb() {
            return this.content.metadata.language_info = this.subkernelInfo, {
                nbformat: this.content.nbformat,
                nbformat_minor: this.content.nbformat_minor,
                cells: this.content.cells.flatMap((e)=>e.toIPynb()),
                metadata: this.content.metadata
            };
        }
        addCell(e) {
            this.cells.push(e);
        }
        insertCell(e, n) {
            this.cells.splice(n, 0, e);
        }
        removeCell(e) {
            this.cells.splice(e, 1);
        }
        cutCell(e) {
            const n = this.cells.splice(e, 1);
            return n.length > 0 ? n[0] : null;
        }
        moveCell(e, n) {
            if (e !== n) {
                const o = this.cutCell(e);
                o && this.insertCell(o, n);
            }
        }
        setSubkernelInfo(e) {
            this.subkernelInfo = {
                name: e.subkernel,
                display_name: e.language
            };
        }
        content;
        cells;
        subkernelInfo;
    };
    class br {
        constructor(e){
            this.sessionId = e, this.events = [];
        }
        addEvent(e) {
            this.events.push(e);
        }
        clear() {
            this.events.splice(0, this.events.splice.length);
        }
        sessionId;
        events;
    }
    class kr {
        rank = 100;
        mimetypes = [];
        render(e, n, o) {
            return new HTMLElement;
        }
    }
    wr = class extends kr {
        constructor(e){
            super(), this._factory = e, this.rank = e.defaultRank || 100, this.mimetypes = [
                ...e.mimeTypes
            ];
        }
        render(e, n, o) {
            const s = this._factory.createRenderer({
                mimeType: e,
                resolver: null,
                sanitizer: new Ts,
                linkHandler: null,
                latexTypesetter: null,
                markdownParser: null,
                translator: void 0
            }), r = new Es({
                trusted: !0,
                data: {
                    [e]: n
                },
                metadata: o
            });
            return s.renderModel(r), s.node;
        }
        _factory;
    };
    class xr {
        constructor(e){
            this._renderers = {};
            for (const n of Os){
                const o = new wr(n);
                this.addRenderer(o);
            }
            for (const n of e?.renderers || [])this.addRenderer(n);
        }
        addRenderer(e) {
            for (const n of e.mimetypes)if (!Object.keys(this._renderers).includes(n)) this._renderers[n] = e;
            else {
                const o = this._renderers[n];
                e.rank <= o.rank && (this._renderers[n] = e);
            }
        }
        get rankedMimetypes() {
            const e = Object.keys(this._renderers);
            return e.sort((n, o)=>this._renderers[n].rank - this._renderers[o].rank), e;
        }
        render(e, n, o) {
            const s = this._renderers[e];
            if (s) return s.render(e, n, o || {});
        }
        renderMimeBundle(e, n) {
            return Object.fromEntries(Object.entries(e).map(([o, s])=>[
                    o,
                    this.render(o, s, n)
                ]));
        }
        rankedMimetypesInBundle(e) {
            return this.rankedMimetypes.filter((o)=>e && Object.keys(e).includes(o));
        }
        _renderers;
    }
    let _r = class {
        constructor(e){
            this._sessionId = e?.sessionId ?? st(), this._sessionOptions = e, this._serverSettings = Ks.ServerConnection.makeSettings(e?.settings), this._services = new mo.ServiceManager({
                serverSettings: this._serverSettings
            }), this._hasBeenConnected = !1, this._services.connectionFailure.connect(this._connectionFailureHandler), this._renderer = new xr(e?.rendererOptions), this._history = new br(this._sessionId), this.notebook = new yr, this._initialized = new Promise(async (n, o)=>{
                this._services.ready.then(async ()=>{
                    if (await this.initialize(e), e?.context) {
                        const s = await this.activeContext();
                        (s.slug !== e.context.slug || JSON.stringify(s.config) !== JSON.stringify(e.context.payload)) && await this.setContext({
                            context: e.context.slug,
                            context_info: e.context.payload
                        });
                    }
                }), n();
            });
        }
        async initialize(e) {
            this._sessionContext = new Rs({
                sessionManager: this._services.sessions,
                specsManager: this._services.kernelspecs,
                name: e?.name,
                path: e?.sessionId,
                kernelPreference: {
                    name: e?.kernelName
                }
            }), this._sessionContext.kernelChanged.connect((n, { oldValue: o, newValue: s, name: r })=>{
                o?.anyMessage.disconnect(this._sessionMessageHandler, this), s?.anyMessage.disconnect(this._sessionMessageHandler, this), s?.anyMessage.connect(this._sessionMessageHandler, this), s && (this._lastKernelModel = s?.model, this._prevClientId = s?.clientId);
            }), this._sessionContext.connectionStatusChanged.connect((n, o)=>{
                !this._hasBeenConnected && o == "connected" && (this._hasBeenConnected = !0);
            }), await this._sessionContext.initialize(), await this._sessionContext.ready, e?.messageHandler ? (this._messageHandler = e.messageHandler, this._sessionContext.iopubMessage.connect(this._messageHandler)) : this._messageHandler = void 0;
        }
        async reconnect() {
            return this._sessionContext.connectionStatusChanged.emit("connecting"), this._sessionContext.dispose, await this.initialize(this._sessionOptions), this._sessionContext;
        }
        sendBeakerMessage(e, n, o, s) {
            if (o || (o = mr(e)), !this.kernel) throw Error("Unable to send message. Not connected to kernel.");
            const r = wt.createMessage({
                session: this.session.session?.id || this.kernel?.clientId,
                channel: "shell",
                msgType: e,
                content: n,
                msgId: o,
                metadata: s
            }), a = this.kernel.sendShellMessage(r, !0, !0);
            return a.msgId = o, a;
        }
        _sessionMessageHandler(e, { msg: n, direction: o }) {
            if (n.header.msg_type === "context_setup_response" || n.header.msg_type === "context_info_response") n.header.msg_type === "context_setup_response" ? this._sessionInfo = n.content : n.header.msg_type === "context_info_response" && (this._sessionInfo = n.content.info), this.notebook.setSubkernelInfo(this._sessionInfo);
            else if (n.header.msg_type === "kernel_info_reply") this._kernelInfo = n.content;
            else if (n.header.msg_type === "notebook_state_request") {
                const s = wt.createMessage({
                    session: e.clientId,
                    channel: "shell",
                    msgType: "notebook_state_response",
                    content: wo(this.notebook),
                    msgId: n.header.msg_id + "_reply",
                    metadata: {}
                });
                e.sendShellMessage(s, !1, !0);
            }
        }
        _connectionFailureHandler(e, n) {
            console.log("CONNECTION ERROR:", typeof n), console.log({
                cause: n.cause,
                message: n.message,
                name: n.name,
                stack: n.stack
            }), console.error(n), console.error();
        }
        async availableContexts() {
            return new Promise(async (e)=>{
                `${this._serverSettings.baseUrl}`;
                const o = await (await hr(`${this._serverSettings.baseUrl}contexts`)).json();
                e(o);
            });
        }
        async activeContext() {
            return new Promise(async (e, n)=>{
                await this.sessionReady;
                const o = this.sendBeakerMessage("context_info_request", {});
                o !== void 0 && (o.onIOPub = async (s)=>{
                    s.header.msg_type === "context_info_response" && e({
                        ...s.content,
                        kernelInfo: await this.kernel?.info
                    });
                }, await o.done), n({});
            });
        }
        async setContext(e) {
            return new Promise(async (n, o)=>{
                const s = this.sendBeakerMessage("context_setup_request", e);
                if (s) {
                    await s.done;
                    const r = s.msg.content, a = await this.kernel?.requestKernelInfo();
                    n({
                        ...r,
                        kernelInfo: a?.content
                    });
                }
                o({});
            });
        }
        executeAction(e, n, o) {
            const s = `${e}_request`, r = `${e}_response`, a = this.sendBeakerMessage(s, n, o);
            if (a) {
                const i = async (c)=>{
                    if (c.header.msg_type === r && a.onResponse) await a.onResponse(c);
                    else if (c.header.msg_type === "code_cell") {
                        const l = this.notebook, p = new rt({
                            cell_type: "code",
                            source: c.content.code,
                            metadata: {},
                            outputs: []
                        });
                        l.addCell(p);
                    }
                    return !0;
                };
                a.registerMessageHook(i);
            }
            return a;
        }
        interrupt() {
            return this.session.session?.kernel ? this.session.session.kernel.interrupt() : new Promise(()=>{});
        }
        addCodeCell(e, n = {}, o = []) {
            const s = new rt({
                cell_type: "code",
                source: e,
                metadata: n,
                outputs: o
            });
            return this.notebook.addCell(s), s;
        }
        addMarkdownCell(e, n = {}) {
            const o = new ze({
                cell_type: "markdown",
                source: e,
                metadata: n
            });
            return this.notebook.addCell(o), o;
        }
        addRawCell(e, n = {}) {
            const o = new Ut({
                cell_type: "raw",
                source: e,
                metadata: n
            });
            return this.notebook.addCell(o), o;
        }
        addQueryCell(e, n = {}) {
            const o = new xo({
                cell_type: "query",
                source: e,
                metadata: n
            });
            return this.notebook.addCell(o), o;
        }
        loadNotebook(e) {
            this.notebook.loadFromIPynb(e);
        }
        reset() {
            this.notebook.cells.splice(0, this.notebook.cells.length), this._history.clear(), this._sessionContext.restartKernel();
        }
        get sessionReady() {
            return new Promise(async (e)=>{
                await this._services.ready, await this._sessionContext.ready, await this._initialized, e();
            });
        }
        get session() {
            return this._sessionContext;
        }
        get status() {
            const e = this.kernel?.connectionStatus, n = this.kernel?.status;
            return e === "connected" && n ? n : e === "connecting" && this._hasBeenConnected ? "reconnecting" : e ? e || "unknown" : "disconnected";
        }
        get kernel() {
            return this._sessionContext?.session?.kernel || null;
        }
        get kernelInfo() {
            return this._kernelInfo;
        }
        get lastKernelModel() {
            return this._lastKernelModel;
        }
        get prevClientId() {
            return this._prevClientId;
        }
        get services() {
            return this._services;
        }
        get renderer() {
            return this._renderer;
        }
        get sessionId() {
            return this._sessionContext.path;
        }
        _initialized;
        _sessionId;
        _sessionOptions;
        _services;
        _serverSettings;
        _sessionContext;
        _messageHandler;
        _history;
        _sessionInfo;
        _renderer;
        _kernelInfo;
        _lastKernelModel;
        _prevClientId;
        _hasBeenConnected;
        notebook;
    };
    if (Js === void 0) throw new Error("Unable to extend Jupyterlab types");
    const Rn = (t)=>{
        const e = t?.component;
        if (e !== void 0) return bt({
            cell: e.proxy.cell,
            enter: e.exposed.enter,
            exit: e.exposed.exit,
            execute: e.exposed.execute,
            clear: e.exposed.clear,
            editor: e.exposed.editor,
            lintAnnotations: e.exposed.lintAnnotations,
            $: e
        });
    }, Cr = oe({
        props: {
            connectionSettings: Object,
            sessionName: {
                type: String,
                required: !1
            },
            sessionId: String,
            defaultKernel: String,
            renderers: Object,
            context: {
                type: Object,
                required: !1
            }
        },
        emits: [
            "iopub-msg",
            "unhandled-msg",
            "any-msg",
            "session-status-changed",
            "context-changed",
            "connection-failure"
        ],
        setup (t, { emit: e }) {
            const n = R("unknown"), o = R({}), s = R(), r = R(), a = t.sessionName ?? t.sessionId, i = new _r({
                settings: t.connectionSettings,
                name: a,
                sessionId: t.sessionId,
                kernelName: t.defaultKernel,
                rendererOptions: {
                    renderers: t.renderers || []
                },
                context: t.context
            });
            n.value = "connecting", i.services.connectionFailure.connect((p, u)=>{
                e("connection-failure", u), console.log("Error connecting to kernel/api", u);
            });
            const c = async (p)=>{
                p.iopubMessage.connect((u, f)=>{
                    if (e("iopub-msg", f), wt.isStatusMsg(f)) {
                        const v = f?.content?.execution_state || "unknown";
                        n.value = i.status, e("session-status-changed", v);
                    }
                }), p.session.anyMessage.connect((u, { msg: f, direction: v })=>{
                    e("any-msg", f, v);
                }), p.unhandledMessage.connect((u, f)=>{
                    e("unhandled-msg", f);
                }), p.connectionStatusChanged.connect((u, f)=>{
                    n.value = i.status;
                });
            };
            i?.sessionReady.then(async ()=>{
                await c(i.session);
            });
            const l = bt(i);
            return {
                activeContext: s,
                session: l,
                status: n,
                cellRegistry: o,
                notebookComponent: r,
                setSignalHandlers: c
            };
        },
        methods: {
            findNotebookCell (t) {
                for (const e of this.cellRegistry)if (t(e)) return Rn(e);
            },
            findNotebookCellById (t) {
                const e = this.cellRegistry[t];
                if (e !== void 0) return Rn(e);
            },
            async updateContextInfo () {
                const t = await this.session.activeContext();
                this.activeContext = t, this.$emit("context-changed", this.activeContext);
            },
            setContext (t) {
                const e = de("show_toast");
                this.activeContext = {};
                const n = this.session.setContext(t);
                return n.then((o)=>{
                    if (o?.status === "error") {
                        let s = o?.content?.evalue;
                        s && (/\.$/.test(s) || (s += ".")), e({
                            title: "Context Setup Failed",
                            severity: "error",
                            detail: `${s} Please try again or contact us.`,
                            life: 0
                        });
                        return;
                    }
                    if (o?.status === "abort") {
                        e({
                            title: "Context Setup Aborted",
                            severity: "warning",
                            detail: o?.content?.evalue,
                            life: 6e3
                        });
                        return;
                    }
                    this.updateContextInfo();
                }), n;
            },
            async reconnect () {
                const t = await this.session.reconnect();
                await this.setSignalHandlers(t), this.setContext({
                    context: this.activeContext.slug,
                    context_info: this.activeContext.config,
                    language: this.activeContext.language.slug,
                    debug: this.activeContext.info.debug,
                    verbose: this.activeContext.info.verbose
                });
            },
            getSession () {
                return this.session;
            }
        },
        beforeMount () {
            yt("beakerSession", bt(this)), yt("session", this.session);
        },
        mounted () {
            this.updateContextInfo();
        }
    }), Sr = {
        class: "beaker-session-container"
    };
    function $r(t, e, n, o, s, r) {
        return x(), N("div", Sr, [
            xe(t.$slots, "default")
        ]);
    }
    const Tr = Tt(Cr, [
        [
            "render",
            $r
        ]
    ]), Er = {
        class: "status-container"
    }, Or = {
        class: "status-label"
    }, Rr = oe({
        __name: "SessionStatus",
        props: [
            "connectionStatus",
            "loading",
            "kernel"
        ],
        setup (t) {
            const e = t, n = de("beakerSession"), o = G(()=>e.connectionStatus || n.status);
            G(()=>e.loading || !n.activeContext?.slug);
            const s = {
                idle: "Ready",
                dead: "Disconnected"
            }, r = G(()=>s[o.value] || Jo(o.value || ""));
            return (a, i)=>{
                const c = Ue("tooltip");
                return x(), N("div", Er, [
                    y("span", {
                        class: ie([
                            "pi pi-circle-fill status-indicator",
                            o.value
                        ])
                    }, null, 2),
                    y("span", Or, K(r.value), 1),
                    o.value === "dead" || o.value === "disconnected" ? re((x(), Z(S(J), {
                        key: 0,
                        class: "reconnect-button",
                        size: "small",
                        icon: "pi pi-refresh",
                        outlined: !0,
                        text: "",
                        onClick: i[0] || (i[0] = (l)=>S(n).reconnect())
                    }, null, 512)), [
                        [
                            c,
                            "Reconnect"
                        ]
                    ]) : W("", !0)
                ]);
            };
        }
    });
    _o = function(t) {
        const e = G(()=>t?.activeContext?.info?.workflow_info?.workflows), n = G(()=>t?.activeContext?.info?.workflow_info?.state?.workflow_id), o = G(()=>e.value?.[n.value]), s = G(()=>t?.activeContext?.info?.workflow_info?.state?.progress), r = G(()=>t?.activeContext?.info?.workflow_info?.state?.final_response);
        return {
            workflows: e,
            attachedWorkflowId: n,
            attachedWorkflow: o,
            attachedWorkflowProgress: s,
            attachedWorkflowFinalResponse: r
        };
    };
    const Pr = {
        class: "workflow-dialog"
    }, Ar = {
        class: "attached-workflow"
    }, Ir = {
        key: 0
    }, Br = {
        class: "attached-workflow-inner"
    }, Nr = {
        class: "attached-label"
    }, jr = {
        key: 1,
        class: "attached-label",
        style: {
            margin: "0"
        }
    }, Mr = {
        class: "workflow-content"
    }, Lr = {
        class: "workflow-list"
    }, Vr = {
        class: "card-badges"
    }, zr = {
        class: "text-muted"
    }, Dr = {
        key: 0,
        class: "workflow-preview"
    }, Fr = {
        class: "preview-content-scrollable"
    }, Ur = {
        class: "flex gap-2 mt-2"
    }, Hr = {
        class: "preview-content"
    }, Wr = {
        class: "section"
    }, qr = {
        key: 1,
        class: "mb-4"
    }, Zr = {
        class: "bg-surface-100 border border-surface-200 rounded p-3 font-mono text-sm"
    }, Gr = {
        key: 3,
        class: "section"
    }, Jr = {
        class: "stages-list"
    }, Kr = {
        class: "stage-number"
    }, Yr = {
        class: "stage-name"
    }, Qr = {
        class: "floating-action-gutter"
    }, Xr = {
        key: 1,
        class: "workflow-preview empty-preview"
    }, ea = oe({
        __name: "WorkflowSelectDialog",
        setup (t) {
            const e = de("beakerSession"), n = de("session"), o = de("dialogRef"), s = R(void 0), r = R(void 0), a = R(void 0), i = (_)=>{
                n.executeAction("set_workflow", {
                    workflow: _ || null
                }), o.value.close();
            }, c = (_)=>{
                r.value = _;
            }, l = ()=>{
                r.value && i(r.value);
            }, p = ()=>i(null), { workflows: u, attachedWorkflowId: f, attachedWorkflow: v } = _o(e), g = G(()=>!r.value || !u.value ? null : u.value[r.value]), C = G(()=>u.value ? Object.fromEntries(Object.entries(u.value).filter(([_, h])=>a.value === "" || a.value === void 0 || [
                        h.human_description,
                        h.title,
                        h.category
                    ].join(" ").toLocaleLowerCase().includes(a.value.toLocaleLowerCase()))) : {});
            return (_, h)=>{
                const T = Ue("tooltip");
                return x(), N("div", Pr, [
                    h[10] || (h[10] = y("p", null, " Workflows are pre-configured approaches for the LLM agent to use for guidance on tackling larger problems using tried-and-true to-do lists of tasks. One workflow may be active at a time for framing the agent's thoughts towards a particular goal. ", -1)),
                    A(S(ct)),
                    y("div", Ar, [
                        S(v) ? (x(), N("div", Ir, [
                            h[3] || (h[3] = y("p", {
                                class: "attached-label"
                            }, "Currently Active:", -1)),
                            y("div", Br, [
                                A(S(J), {
                                    onClick: p,
                                    label: "Clear",
                                    icon: "pi pi-times",
                                    small: ""
                                }),
                                y("span", Nr, K(S(v).title), 1)
                            ])
                        ])) : (x(), N("p", jr, "No workflow active.")),
                        A(S(ot), {
                            style: {
                                margin: "auto 0 0 auto",
                                width: "50%"
                            }
                        }, {
                            default: H(()=>[
                                    A(S(ao), null, {
                                        default: H(()=>[
                                                ...h[4] || (h[4] = [
                                                    y("i", {
                                                        class: "pi pi-search"
                                                    }, null, -1)
                                                ])
                                            ]),
                                        _: 1
                                    }),
                                    A(S(Ze), {
                                        placeholder: "Search Workflows...",
                                        modelValue: a.value,
                                        "onUpdate:modelValue": h[0] || (h[0] = (O)=>a.value = O)
                                    }, null, 8, [
                                        "modelValue"
                                    ]),
                                    a.value !== void 0 && a.value !== "" ? re((x(), Z(S(J), {
                                        key: 0,
                                        icon: "pi pi-times",
                                        severity: "danger",
                                        onClick: h[1] || (h[1] = ()=>{
                                            a.value = void 0;
                                        })
                                    }, null, 512)), [
                                        [
                                            T,
                                            "Clear Search"
                                        ]
                                    ]) : W("", !0)
                                ]),
                            _: 1
                        })
                    ]),
                    A(S(ct)),
                    y("div", Mr, [
                        y("div", Lr, [
                            (x(!0), N(le, null, we(C.value, (O, b)=>(x(), Z(S(At), {
                                    class: ie([
                                        "workflow-card",
                                        {
                                            "selected-card": r.value === b,
                                            "current-card": b === S(f)
                                        }
                                    ]),
                                    onClick: (B)=>c(b),
                                    onMouseleave: h[2] || (h[2] = (B)=>s.value = void 0),
                                    onMouseenter: (B)=>s.value = b
                                }, {
                                    title: H(()=>[
                                            Te(K(O.title), 1)
                                        ]),
                                    subtitle: H(()=>[
                                            y("div", Vr, [
                                                b === S(f) ? (x(), Z(S(bn), {
                                                    key: 0,
                                                    value: "Current",
                                                    severity: "success"
                                                })) : W("", !0),
                                                O.category ? (x(), Z(S(kn), {
                                                    key: 1,
                                                    label: O.category,
                                                    class: "p-chip-sm"
                                                }, null, 8, [
                                                    "label"
                                                ])) : W("", !0)
                                            ])
                                        ]),
                                    content: H(()=>[
                                            y("p", null, K(O.human_description), 1),
                                            y("small", zr, K(O.stages?.length || 0) + " stages", 1)
                                        ]),
                                    _: 2
                                }, 1032, [
                                    "class",
                                    "onClick",
                                    "onMouseenter"
                                ]))), 256))
                        ]),
                        g.value ? (x(), N("div", Dr, [
                            y("div", Fr, [
                                A(S(At), {
                                    class: "preview-card"
                                }, {
                                    title: H(()=>[
                                            Te(K(g.value.title), 1)
                                        ]),
                                    subtitle: H(()=>[
                                            y("div", Ur, [
                                                g.value.category ? (x(), Z(S(kn), {
                                                    key: 0,
                                                    label: g.value.category
                                                }, null, 8, [
                                                    "label"
                                                ])) : W("", !0),
                                                A(S(bn), {
                                                    value: `${g.value.stages?.length || 0} stages`,
                                                    severity: "info"
                                                }, null, 8, [
                                                    "value"
                                                ])
                                            ])
                                        ]),
                                    content: H(()=>[
                                            y("div", Hr, [
                                                y("div", Wr, [
                                                    h[5] || (h[5] = y("h4", null, "Description", -1)),
                                                    y("p", null, K(g.value.human_description), 1)
                                                ]),
                                                g.value.example_prompt ? (x(), Z(S(ct), {
                                                    key: 0
                                                })) : W("", !0),
                                                g.value.example_prompt ? (x(), N("div", qr, [
                                                    h[6] || (h[6] = y("h4", {
                                                        class: "text-lg font-semibold mb-2"
                                                    }, "Example Usage", -1)),
                                                    y("div", Zr, K(g.value.example_prompt), 1)
                                                ])) : W("", !0),
                                                g.value.stages?.length ? (x(), Z(S(ct), {
                                                    key: 2
                                                })) : W("", !0),
                                                g.value.stages?.length ? (x(), N("div", Gr, [
                                                    h[7] || (h[7] = y("h4", null, "Workflow Stages", -1)),
                                                    y("div", Jr, [
                                                        (x(!0), N(le, null, we(g.value.stages, (O, b)=>(x(), N("div", {
                                                                key: b,
                                                                class: "stage-item"
                                                            }, [
                                                                y("span", Kr, K(b + 1), 1),
                                                                y("span", Yr, K(O.name), 1)
                                                            ]))), 128))
                                                    ])
                                                ])) : W("", !0),
                                                h[8] || (h[8] = y("div", {
                                                    style: {
                                                        height: "80px"
                                                    }
                                                }, null, -1))
                                            ])
                                        ]),
                                    _: 1
                                })
                            ]),
                            y("div", Qr, [
                                A(S(J), {
                                    label: r.value === S(f) ? "Already Active" : `Start ${g.value.title}`,
                                    disabled: r.value === S(f),
                                    onClick: l,
                                    icon: "pi pi-play",
                                    class: "select-button",
                                    size: "large"
                                }, null, 8, [
                                    "label",
                                    "disabled"
                                ])
                            ])
                        ])) : (x(), N("div", Xr, [
                            A(S(At), {
                                class: "preview-card"
                            }, {
                                content: H(()=>[
                                        ...h[9] || (h[9] = [
                                            y("div", {
                                                class: "empty-state"
                                            }, [
                                                y("i", {
                                                    class: "pi pi-arrow-left",
                                                    style: {
                                                        "font-size": "2rem",
                                                        color: "var(--p-surface-400)"
                                                    }
                                                }),
                                                y("p", null, "Select a workflow to see details")
                                            ], -1)
                                        ])
                                    ]),
                                _: 1
                            })
                        ]))
                    ])
                ]);
            };
        }
    }), ta = Tt(ea, [
        [
            "__scopeId",
            "data-v-c5eaf260"
        ]
    ]), na = {
        key: 2
    }, oa = {
        class: "title"
    }, sa = [
        "src"
    ], ra = {
        key: 1,
        class: "title-extra"
    }, aa = {
        class: "flex"
    }, ia = oe({
        __name: "BeakerHeader",
        props: {
            title: {
                default: "Beaker"
            },
            titleExtra: {},
            nav: {}
        },
        emits: [
            "selectKernel"
        ],
        setup (t, { emit: e }) {
            const n = t, o = e, { theme: s, toggleDarkMode: r } = de("theme"), a = de("beakerSession"), i = de("beakerAppConfig"), c = G(()=>n.nav ? n.nav : [
                    {
                        type: "button",
                        icon: s.mode === "dark" ? "sun" : "moon",
                        command: r,
                        label: `Switch to ${s.mode === "dark" ? "light" : "dark"} mode.`
                    },
                    {
                        type: "link",
                        href: "https://jataware.github.io/beaker-kernel",
                        label: "Beaker Documentation",
                        icon: "book",
                        rel: "noopener",
                        target: "_blank"
                    },
                    {
                        type: "link",
                        href: "https://github.com/jataware/beaker-kernel",
                        label: "Check us out on Github",
                        icon: "github",
                        rel: "noopener",
                        target: "_blank"
                    }
                ]);
            function l() {
                o("selectKernel");
            }
            const p = Xt(), u = G(()=>!a.activeContext?.slug), { workflows: f, attachedWorkflow: v } = _o(a), g = G(()=>f.value === void 0 ? !1 : Object.keys(f.value).length > 0), C = G(()=>i?.currentPage?.value === "dev" ? !0 : i?.config?.default_context?.single_context !== !0);
            return (_, h)=>{
                const T = Ue("tooltip");
                return x(), Z(S(Ko), {
                    class: "beaker-toolbar"
                }, {
                    start: H(()=>[
                            A(Rr, {
                                "connection-status": S(a).status
                            }, null, 8, [
                                "connection-status"
                            ]),
                            C.value ? re((x(), Z(S(J), {
                                key: 0,
                                outlined: "",
                                size: "small",
                                icon: "pi pi-angle-down",
                                iconPos: "right",
                                class: "connection-button",
                                onClick: l,
                                label: S(a).activeContext?.slug,
                                loading: u.value
                            }, null, 8, [
                                "label",
                                "loading"
                            ])), [
                                [
                                    T,
                                    _.$tmpl._("select_kernel_tooltip", "Change or update the context"),
                                    void 0,
                                    {
                                        bottom: !0
                                    }
                                ]
                            ]) : u.value ? re((x(), Z(S(J), {
                                key: 1,
                                text: "",
                                size: "small",
                                loading: u.value,
                                disabled: !0
                            }, null, 8, [
                                "loading"
                            ])), [
                                [
                                    T,
                                    "Connecting",
                                    void 0,
                                    {
                                        bottom: !0
                                    }
                                ]
                            ]) : W("", !0),
                            g.value ? (x(), N("div", na, [
                                re(A(S(J), {
                                    outlined: "",
                                    size: "small",
                                    icon: "pi pi-angle-down",
                                    iconPos: "right",
                                    class: "connection-button",
                                    label: S(v)?.title ?? "No Workflow",
                                    loading: u.value,
                                    onClick: h[0] || (h[0] = (O)=>S(p).open(ta, {
                                            props: {
                                                modal: !0,
                                                header: "Workflows"
                                            }
                                        }))
                                }, null, 8, [
                                    "label",
                                    "loading"
                                ]), [
                                    [
                                        T,
                                        "Change Workflow",
                                        void 0,
                                        {
                                            bottom: !0
                                        }
                                    ]
                                ])
                            ])) : W("", !0)
                        ]),
                    center: H(()=>[
                            y("div", oa, [
                                _.$tmpl.hasAsset("header_logo") ? (x(), N("img", io({
                                    key: 0,
                                    class: "header-logo",
                                    src: _.$tmpl.getAsset("header_logo").src
                                }, _.$tmpl.getAsset("header_logo").attrs), null, 16, sa)) : W("", !0),
                                y("h4", null, K(_.title ?? "Beaker Notebook"), 1),
                                _.titleExtra ? (x(), N("span", ra, K(_.titleExtra), 1)) : W("", !0)
                            ])
                        ]),
                    end: H(()=>[
                            y("nav", aa, [
                                (x(!0), N(le, null, we(c.value, (O)=>(x(), N(le, {
                                        key: O
                                    }, [
                                        O.type === "link" ? re((x(), Z(S(Wo), {
                                            key: 0,
                                            to: O.href,
                                            "aria-label": O.label,
                                            rel: O.rel,
                                            target: O.target,
                                            style: {
                                                margin: "auto"
                                            }
                                        }, {
                                            default: H(()=>[
                                                    A(S(J), {
                                                        icon: O.icon ? `pi pi-${O.icon}` : "pi",
                                                        text: ""
                                                    }, {
                                                        default: H(()=>[
                                                                O.component ? (x(), Z(en(O.component), {
                                                                    key: 0,
                                                                    item: O,
                                                                    style: tn(O.componentStyle)
                                                                }, null, 8, [
                                                                    "item",
                                                                    "style"
                                                                ])) : W("", !0)
                                                            ]),
                                                        _: 2
                                                    }, 1032, [
                                                        "icon"
                                                    ])
                                                ]),
                                            _: 2
                                        }, 1032, [
                                            "to",
                                            "aria-label",
                                            "rel",
                                            "target"
                                        ])), [
                                            [
                                                T,
                                                O.label,
                                                void 0,
                                                {
                                                    bottom: !0
                                                }
                                            ]
                                        ]) : O.type === "button" ? re((x(), Z(S(J), {
                                            key: 1,
                                            icon: `pi pi-${O.icon}`,
                                            text: "",
                                            onClick: O.command,
                                            "aria-label": O.label
                                        }, null, 8, [
                                            "icon",
                                            "onClick",
                                            "aria-label"
                                        ])), [
                                            [
                                                T,
                                                O.label,
                                                void 0,
                                                {
                                                    bottom: !0
                                                }
                                            ]
                                        ]) : W("", !0)
                                    ], 64))), 128))
                            ])
                        ]),
                    _: 1
                });
            };
        }
    }), la = {
        style: {
            "font-weight": "bold"
        }
    }, ca = oe({
        __name: "InlineInput",
        props: {
            modelValue: {},
            modelModifiers: {}
        },
        emits: [
            "update:modelValue"
        ],
        setup (t) {
            const e = lo(t, "modelValue"), n = R(e.value || ""), o = R(), s = R(), r = R(!1), a = ()=>{
                n.value !== e.value && (e.value = n.value), r.value = !1;
            }, i = ()=>{
                r.value = !1, n.value = e.value;
            };
            return (c, l)=>(x(), Z(S(Yo), {
                    ref_key: "inPlaceRef",
                    ref: o,
                    active: r.value,
                    "onUpdate:active": l[1] || (l[1] = (p)=>r.value = p),
                    onOpen: l[2] || (l[2] = (p)=>n.value = e.value)
                }, {
                    display: H(()=>[
                            A(S(ot), null, {
                                default: H(()=>[
                                        A(S(ao), {
                                            style: {
                                                flex: "1"
                                            }
                                        }, {
                                            default: H(()=>[
                                                    y("span", la, K(e.value), 1)
                                                ]),
                                            _: 1
                                        }),
                                        A(S(J), {
                                            icon: "pi pi-pencil"
                                        })
                                    ]),
                                _: 1
                            })
                        ]),
                    content: H(()=>[
                            A(S(ot), null, {
                                default: H(()=>[
                                        A(S(Ze), {
                                            ref_key: "inputTextRef",
                                            ref: s,
                                            "model-value": n.value,
                                            "onUpdate:modelValue": l[0] || (l[0] = (p)=>n.value = p),
                                            autofocus: "",
                                            "original-value": new String($t(e.value)),
                                            onKeydown: [
                                                Dt(a, [
                                                    "enter"
                                                ]),
                                                Dt(i, [
                                                    "escape"
                                                ])
                                            ]
                                        }, null, 8, [
                                            "model-value",
                                            "original-value"
                                        ]),
                                        A(S(J), {
                                            icon: "pi pi-check",
                                            severity: "success",
                                            onClick: a
                                        }),
                                        A(S(J), {
                                            icon: "pi pi-times",
                                            severity: "warning",
                                            onClick: i
                                        })
                                    ]),
                                _: 1
                            })
                        ]),
                    _: 1
                }, 8, [
                    "active"
                ]));
        }
    }), Pn = (t)=>typeof t == "object" && t != null && t.nodeType === 1, An = (t, e)=>(!e || t !== "hidden") && t !== "visible" && t !== "clip", dt = (t, e)=>{
        if (t.clientHeight < t.scrollHeight || t.clientWidth < t.scrollWidth) {
            const n = getComputedStyle(t, null);
            return An(n.overflowY, e) || An(n.overflowX, e) || ((o)=>{
                const s = ((r)=>{
                    if (!r.ownerDocument || !r.ownerDocument.defaultView) return null;
                    try {
                        return r.ownerDocument.defaultView.frameElement;
                    } catch  {
                        return null;
                    }
                })(o);
                return !!s && (s.clientHeight < o.scrollHeight || s.clientWidth < o.scrollWidth);
            })(t);
        }
        return !1;
    }, pt = (t, e, n, o, s, r, a, i)=>r < t && a > e || r > t && a < e ? 0 : r <= t && i <= n || a >= e && i >= n ? r - t - o : a > e && i < n || r < t && i > n ? a - e + s : 0, ua = (t)=>{
        const e = t.parentElement;
        return e ?? (t.getRootNode().host || null);
    }, In = (t, e)=>{
        var n, o, s, r;
        if (typeof document > "u") return [];
        const { scrollMode: a, block: i, inline: c, boundary: l, skipOverflowHiddenElements: p } = e, u = typeof l == "function" ? l : (P)=>P !== l;
        if (!Pn(t)) throw new TypeError("Invalid target");
        const f = document.scrollingElement || document.documentElement, v = [];
        let g = t;
        for(; Pn(g) && u(g);){
            if (g = ua(g), g === f) {
                v.push(g);
                break;
            }
            g != null && g === document.body && dt(g) && !dt(document.documentElement) || g != null && dt(g, p) && v.push(g);
        }
        const C = (o = (n = window.visualViewport) == null ? void 0 : n.width) != null ? o : innerWidth, _ = (r = (s = window.visualViewport) == null ? void 0 : s.height) != null ? r : innerHeight, { scrollX: h, scrollY: T } = window, { height: O, width: b, top: B, right: $, bottom: k, left: w } = t.getBoundingClientRect(), { top: V, right: D, bottom: Q, left: q } = ((P)=>{
            const d = window.getComputedStyle(P);
            return {
                top: parseFloat(d.scrollMarginTop) || 0,
                right: parseFloat(d.scrollMarginRight) || 0,
                bottom: parseFloat(d.scrollMarginBottom) || 0,
                left: parseFloat(d.scrollMarginLeft) || 0
            };
        })(t);
        let I = i === "start" || i === "nearest" ? B - V : i === "end" ? k + Q : B + O / 2 - V + Q, j = c === "center" ? w + b / 2 - q + D : c === "end" ? $ + D : w - q;
        const F = [];
        for(let P = 0; P < v.length; P++){
            const d = v[P], { height: m, width: E, top: L, right: M, bottom: X, left: ne } = d.getBoundingClientRect();
            if (a === "if-needed" && B >= 0 && w >= 0 && k <= _ && $ <= C && (d === f && !dt(d) || B >= L && k <= X && w >= ne && $ <= M)) return F;
            const ue = getComputedStyle(d), he = parseInt(ue.borderLeftWidth, 10), Y = parseInt(ue.borderTopWidth, 10), ae = parseInt(ue.borderRightWidth, 10), se = parseInt(ue.borderBottomWidth, 10);
            let me = 0, _e = 0;
            const Ae = "offsetWidth" in d ? d.offsetWidth - d.clientWidth - he - ae : 0, Se = "offsetHeight" in d ? d.offsetHeight - d.clientHeight - Y - se : 0, Rt = "offsetWidth" in d ? d.offsetWidth === 0 ? 0 : E / d.offsetWidth : 0, Pt = "offsetHeight" in d ? d.offsetHeight === 0 ? 0 : m / d.offsetHeight : 0;
            if (f === d) me = i === "start" ? I : i === "end" ? I - _ : i === "nearest" ? pt(T, T + _, _, Y, se, T + I, T + I + O, O) : I - _ / 2, _e = c === "start" ? j : c === "center" ? j - C / 2 : c === "end" ? j - C : pt(h, h + C, C, he, ae, h + j, h + j + b, b), me = Math.max(0, me + T), _e = Math.max(0, _e + h);
            else {
                me = i === "start" ? I - L - Y : i === "end" ? I - X + se + Se : i === "nearest" ? pt(L, X, m, Y, se + Se, I, I + O, O) : I - (L + m / 2) + Se / 2, _e = c === "start" ? j - ne - he : c === "center" ? j - (ne + E / 2) + Ae / 2 : c === "end" ? j - M + ae + Ae : pt(ne, M, E, he, ae + Ae, j, j + b, b);
                const { scrollLeft: mn, scrollTop: vn } = d;
                me = Pt === 0 ? 0 : Math.max(0, Math.min(vn + me / Pt, d.scrollHeight - m / Pt + Se)), _e = Rt === 0 ? 0 : Math.max(0, Math.min(mn + _e / Rt, d.scrollWidth - E / Rt + Ae)), I += vn - me, j += mn - _e;
            }
            F.push({
                el: d,
                top: me,
                left: _e
            });
        }
        return F;
    }, da = (t)=>t === !1 ? {
            block: "end",
            inline: "nearest"
        } : ((e)=>e === Object(e) && Object.keys(e).length !== 0)(t) ? t : {
            block: "start",
            inline: "nearest"
        };
    Co = function(t, e) {
        if (!t.isConnected || !((s)=>{
            let r = s;
            for(; r && r.parentNode;){
                if (r.parentNode === document) return !0;
                r = r.parentNode instanceof ShadowRoot ? r.parentNode.host : r.parentNode;
            }
            return !1;
        })(t)) return;
        const n = ((s)=>{
            const r = window.getComputedStyle(s);
            return {
                top: parseFloat(r.scrollMarginTop) || 0,
                right: parseFloat(r.scrollMarginRight) || 0,
                bottom: parseFloat(r.scrollMarginBottom) || 0,
                left: parseFloat(r.scrollMarginLeft) || 0
            };
        })(t);
        if (((s)=>typeof s == "object" && typeof s.behavior == "function")(e)) return e.behavior(In(t, e));
        const o = typeof e == "boolean" || e == null ? void 0 : e.behavior;
        for (const { el: s, top: r, left: a } of In(t, da(e))){
            const i = r - n.top + n.bottom, c = a - n.left + n.right;
            s.scroll({
                top: i,
                left: c,
                behavior: o
            });
        }
    };
    const pa = [
        "type-str"
    ], fa = [
        "for"
    ], ha = {
        key: 1,
        style: {
            display: "flex",
            "flex-direction": "row"
        }
    }, ga = [
        "value"
    ], ma = [
        "value"
    ], va = {
        key: 4,
        class: "horizontal-flex"
    }, ya = {
        key: 0,
        class: "label"
    }, ba = {
        key: 5,
        class: "horizontal-flex"
    }, ka = {
        key: 0,
        class: "label"
    }, wa = {
        key: 0,
        class: "pi pi-chevron-up"
    }, xa = {
        key: 1,
        class: "pi pi-chevron-down"
    }, So = oe({
        __name: "ConfigEntryComponent",
        props: Qo({
            name: {},
            schema: {},
            configObject: {},
            keyValue: {},
            label: {},
            sensitive: {
                type: Boolean,
                default: !1
            }
        }, {
            modelValue: {},
            modelModifiers: {}
        }),
        emits: [
            "update:modelValue"
        ],
        setup (t) {
            const e = t, n = uo(), o = lo(t, "modelValue"), s = de("show_toast"), r = R(!1), a = R(""), i = R(), c = G(()=>r.value || JSON.stringify(o.value) !== JSON.stringify(i.value));
            ge(o, (u)=>{
                e.schema?.metadata?.sensitive && e.schema?.type_str?.startsWith("str") && !r.value && i.value === null && u === "" && (o.value = i.value);
            });
            const l = G(()=>r.value ? "Value will be cleared." : o.value === null ? "Leave blank to keep unchanged." : "No value saved. Enter to set value."), p = ()=>{
                r.value ? (a.value = o.value, o.value = "") : (o.value = a.value, a.value = null);
            };
            return nn(()=>{
                i.value = structuredClone($t(o.value));
            }), Ne(()=>{
                if (e.schema?.type_str?.startsWith("Choice")) {
                    const u = e.configObject[e.schema?.choice_source];
                    u && ge(u, ()=>{
                        u.map((f)=>f.name).includes(o.value) || (o.value = "", s({
                            title: "Warning",
                            detail: `Changing this value has caused property '${e.keyValue}' to become unset. Please make sure to update that value before saving.`,
                            severity: "warn",
                            life: 15e3
                        }), setTimeout(()=>{
                            const f = n.vnode.el.parentElement;
                            Co(f, {
                                scrollMode: "if-needed",
                                block: "center",
                                behavior: "smooth"
                            }), f.style.outline = "red 1px solid", f.style.outlineOffset = "0.5rem", setTimeout(()=>{
                                f.style.outline = "unset", f.style.outlineOffset = "unset";
                            }, 3e3);
                        }, 500));
                    });
                }
            }), (u, f)=>{
                const v = Xo("ConfigEntryComponent", !0), g = Ue("tooltip");
                return u.schema?.type_str?.startsWith("Dataclass") ? (x(!0), N(le, {
                    key: 0
                }, we(u.schema.fields, (C, _)=>(x(), N("div", {
                        class: "config-option dataclass",
                        "type-str": C?.type_str,
                        key: `${u.keyValue}-${_}`
                    }, [
                        y("label", {
                            for: _
                        }, K(_), 9, fa),
                        y("small", null, K(C.description), 1),
                        A(v, {
                            schema: C,
                            name: _,
                            "key-value": u.keyValue?.split(".").concat(_).join("."),
                            "config-object": u.configObject,
                            modelValue: o.value[_],
                            "onUpdate:modelValue": (h)=>o.value[_] = h
                        }, null, 8, [
                            "schema",
                            "name",
                            "key-value",
                            "config-object",
                            "modelValue",
                            "onUpdate:modelValue"
                        ])
                    ], 8, pa))), 128)) : u.schema?.metadata?.sensitive && u.schema?.type_str?.startsWith("str") && (typeof o.value == "string" || o.value === null) ? (x(), N("div", ha, [
                    A(S(Ze), {
                        disabled: r.value,
                        style: {
                            flex: "1"
                        },
                        id: u.keyValue,
                        name: u.keyValue,
                        class: ie({
                            dirty: c.value
                        }),
                        modelValue: o.value,
                        "onUpdate:modelValue": f[0] || (f[0] = (C)=>o.value = C),
                        feedback: !1,
                        type: "password",
                        placeholder: l.value
                    }, null, 8, [
                        "disabled",
                        "id",
                        "name",
                        "class",
                        "modelValue",
                        "placeholder"
                    ]),
                    re((x(), Z(S(es), {
                        class: "clear-sensitive-checkbox",
                        modelValue: r.value,
                        "onUpdate:modelValue": f[1] || (f[1] = (C)=>r.value = C),
                        "on-label": "",
                        "off-label": "",
                        "aria-label": "Clear saved value",
                        onChange: p
                    }, {
                        icon: H(({ value: C })=>[
                                y("span", {
                                    class: ie([
                                        "clear-icon pi pi-eraser",
                                        {
                                            checked: C
                                        }
                                    ])
                                }, null, 2)
                            ]),
                        _: 1
                    }, 8, [
                        "modelValue"
                    ])), [
                        [
                            g,
                            "Clear saved value"
                        ]
                    ])
                ])) : u.schema?.type_str?.startsWith("Choice") || u.schema?.type_str?.startsWith("str") && u.schema?.metadata?.options ? (x(), N("div", {
                    key: 2,
                    class: ie([
                        "select-wrap p-dropdown",
                        {
                            dirty: c.value
                        }
                    ])
                }, [
                    f[10] || (f[10] = y("div", {
                        class: "select-dropdown p-dropdown-trigger"
                    }, [
                        y("svg", {
                            width: "14",
                            height: "14",
                            viewBox: "0 0 14 14",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            class: "p-icon p-dropdown-trigger-icon",
                            "aria-hidden": "true",
                            "data-pc-section": "dropdownicon"
                        }, [
                            y("path", {
                                d: "M7.01744 10.398C6.91269 10.3985 6.8089 10.378 6.71215 10.3379C6.61541 10.2977 6.52766 10.2386 6.45405 10.1641L1.13907 4.84913C1.03306 4.69404 0.985221 4.5065 1.00399 4.31958C1.02276 4.13266 1.10693 3.95838 1.24166 3.82747C1.37639 3.69655 1.55301 3.61742 1.74039 3.60402C1.92777 3.59062 2.11386 3.64382 2.26584 3.75424L7.01744 8.47394L11.769 3.75424C11.9189 3.65709 12.097 3.61306 12.2748 3.62921C12.4527 3.64535 12.6199 3.72073 12.7498 3.84328C12.8797 3.96582 12.9647 4.12842 12.9912 4.30502C13.0177 4.48162 12.9841 4.662 12.8958 4.81724L7.58083 10.1322C7.50996 10.2125 7.42344 10.2775 7.32656 10.3232C7.22968 10.3689 7.12449 10.3944 7.01744 10.398Z",
                                fill: "currentColor"
                            })
                        ])
                    ], -1)),
                    u.schema?.type_str?.startsWith("Choice") ? re((x(), N("select", {
                        key: 0,
                        "onUpdate:modelValue": f[2] || (f[2] = (C)=>o.value = C),
                        class: "p-inputtext"
                    }, [
                        f[8] || (f[8] = y("option", {
                            value: "",
                            disabled: ""
                        }, "Select an option", -1)),
                        (x(!0), N(le, null, we(u.configObject[u.schema?.choice_source] || {}, (C, _)=>(x(), N("option", {
                                value: _,
                                key: _
                            }, K(_), 9, ga))), 128))
                    ], 512)), [
                        [
                            wn,
                            o.value
                        ]
                    ]) : re((x(), N("select", {
                        key: 1,
                        "onUpdate:modelValue": f[3] || (f[3] = (C)=>o.value = C),
                        class: "p-inputtext"
                    }, [
                        f[9] || (f[9] = y("option", {
                            value: "",
                            disabled: ""
                        }, "Select an option", -1)),
                        (x(!0), N(le, null, we(u.schema.metadata.options, (C, _)=>(x(), N("option", {
                                value: C,
                                key: _
                            }, K(_), 9, ma))), 128))
                    ], 512)), [
                        [
                            wn,
                            o.value
                        ]
                    ])
                ], 2)) : u.schema?.type_str?.startsWith("str") && (typeof o.value == "string" || o.value === null) ? (x(), Z(S(Ze), {
                    key: 3,
                    id: u.keyValue,
                    class: ie({
                        dirty: c.value
                    }),
                    name: u.keyValue,
                    modelValue: o.value,
                    "onUpdate:modelValue": f[4] || (f[4] = (C)=>o.value = C),
                    placeholder: u.schema.metadata?.placeholder_text || void 0
                }, null, 8, [
                    "id",
                    "class",
                    "name",
                    "modelValue",
                    "placeholder"
                ])) : u.schema?.type_str == "bool" && typeof o.value == "boolean" ? (x(), N("div", va, [
                    u.label ? (x(), N("span", ya, K(u.label), 1)) : W("", !0),
                    A(S(ts), {
                        id: u.keyValue,
                        class: ie({
                            dirty: c.value
                        }),
                        name: u.keyValue,
                        modelValue: o.value,
                        "onUpdate:modelValue": f[5] || (f[5] = (C)=>o.value = C)
                    }, null, 8, [
                        "id",
                        "class",
                        "name",
                        "modelValue"
                    ])
                ])) : u.schema?.type_str == "int" && typeof o.value == "number" ? (x(), N("div", ba, [
                    u.label ? (x(), N("span", ka, K(u.label), 1)) : W("", !0),
                    A(S(ns), {
                        id: u.keyValue,
                        style: {
                            padding: "2px 8px"
                        },
                        class: ie({
                            dirty: c.value
                        }),
                        name: u.keyValue,
                        modelValue: o.value,
                        "onUpdate:modelValue": f[6] || (f[6] = (C)=>o.value = C),
                        min: u.schema?.metadata?.extra?.min,
                        max: u.schema?.metadata?.extra?.max
                    }, null, 8, [
                        "id",
                        "class",
                        "name",
                        "modelValue",
                        "min",
                        "max"
                    ])
                ])) : u.schema?.type_str?.startsWith("Table") && Array.isArray(o.value) ? (x(), N(le, {
                    key: 6
                }, [
                    (x(!0), N(le, null, we(o.value, (C, _)=>(x(), Z(S(co), {
                            key: `${u.keyValue}-${C.name}`,
                            toggleable: "",
                            class: ie({
                                dirty: !i.value.map((h)=>h.name).includes(C.name)
                            })
                        }, {
                            togglericon: H(({ collapsed: h })=>[
                                    h ? (x(), N("span", wa)) : (x(), N("span", xa))
                                ]),
                            header: H(()=>[
                                    A(ca, {
                                        modelValue: o.value[_].name,
                                        "onUpdate:modelValue": (h)=>o.value[_].name = h
                                    }, null, 8, [
                                        "modelValue",
                                        "onUpdate:modelValue"
                                    ])
                                ]),
                            icons: H(()=>[
                                    re(A(S(J), {
                                        icon: "pi pi-trash",
                                        text: "",
                                        size: "small",
                                        onClick: (h)=>o.value.splice(_, 1)
                                    }, null, 8, [
                                        "onClick"
                                    ]), [
                                        [
                                            g,
                                            `Delete '${C.name}'`
                                        ]
                                    ])
                                ]),
                            default: H(()=>[
                                    A(v, {
                                        schema: u.schema.type_args[0],
                                        name: `${u.keyValue}.value-${_}`,
                                        "key-value": `${u.keyValue}.value-${_}`,
                                        "config-object": u.configObject,
                                        modelValue: o.value[_].value,
                                        "onUpdate:modelValue": (h)=>o.value[_].value = h,
                                        label: u.schema.metadata?.label
                                    }, null, 8, [
                                        "schema",
                                        "name",
                                        "key-value",
                                        "config-object",
                                        "modelValue",
                                        "onUpdate:modelValue",
                                        "label"
                                    ])
                                ]),
                            _: 2
                        }, 1032, [
                            "class"
                        ]))), 128)),
                    A(S(J), {
                        icon: "pi pi-plus",
                        onClick: f[7] || (f[7] = (C)=>o.value.push({
                                name: "",
                                value: u.schema.type_args[0].default_value
                            }))
                    })
                ], 64)) : W("", !0);
            };
        }
    }), _a = {
        key: 0,
        class: "config-panel"
    }, Ca = {
        class: "config-panel-container"
    }, Sa = {
        key: 1,
        class: "loading"
    };
    function Ht(t, e) {
        if (t.type_str.startsWith("Dataclass")) {
            const n = {};
            for (const o of Object.keys(t.fields)){
                const s = e[o], r = t.fields[o];
                n[o] = Ht(r, s);
            }
            return n;
        } else return t.type_str.startsWith("Table") && Array.isArray(e) ? Object.fromEntries(e.map((n)=>[
                n.name,
                Ht(t.type_args[0], n.value)
            ])) : e;
    }
    function at(t, e) {
        if (t.type_str.startsWith("Dataclass")) {
            const n = {};
            for (const o of Object.keys(t.fields)){
                const s = e[o], r = t.fields[o];
                n[o] = at(r, s);
            }
            return n;
        } else return t.type_str.startsWith("Table") ? Object.entries(e).map(([n, o])=>({
                name: n,
                value: at(t.type_args[0], o)
            })) : e;
    }
    function Wt(t, e, n) {
        if (t.type_str.startsWith("Dataclass")) {
            const o = {};
            for (const s of Object.keys(t.fields)){
                const r = e[s], a = t.fields[s], i = n && n[s], c = Wt(a, r, i);
                o[s] = c;
            }
            return o;
        } else if (t.type_str.startsWith("Table")) {
            const o = {};
            for (const [s, r] of Object.entries(e)){
                const a = Wt(t.type_args[0], r, n[s]);
                o[s] = a;
            }
            return o;
        } else return e === n ? null : e;
    }
    async function $o(t) {
        const n = `${t.session.services.serverSettings.baseUrl}config/control`, o = n + "?schema", s = fetch(n), r = fetch(o), a = await s, i = await r, c = await a.json(), l = await i.json();
        return {
            config: c,
            schema: l
        };
    }
    async function To(t, e, n, o) {
        const r = `${t.session.services.serverSettings.baseUrl}config/control`, a = Wt(e, Ht(e, n), o);
        return a === null ? void 0 : await fetch(r, {
            method: "POST",
            body: JSON.stringify(a)
        });
    }
    let $a, Ta, Ea, Oa, Ra, Pa, Aa, Ia;
    Fc = oe({
        __name: "ConfigPanel",
        emits: [
            "restartSession"
        ],
        setup (t, { emit: e }) {
            const n = de("beakerSession"), o = R(), s = R(), r = R({}), a = R(), i = po(), c = R(0), l = e, p = async ()=>{
                const f = `You are about to update ${o.value.config_type} '${o.value.config_id}'.
Proceed?`;
                i.require({
                    message: f,
                    header: "Apply Changes",
                    accept: async ()=>{
                        const v = await To(n, s.value, r.value, o.value.config), g = await v.json();
                        o.value = g, r.value = Object.assign({}, at(s.value, g.config)), Be(()=>{
                            c.value++;
                        }), v.ok && i.require({
                            header: "Restart Session",
                            message: `Restart kernel to apply changes?

Your notebook contents will not be affected, but chat history will be lost and cells will need to be rerun.`,
                            accept: ()=>{
                                l("restartSession");
                            }
                        });
                    }
                });
            }, u = async ()=>{
                const { schema: f, config: v } = await $o(n);
                s.value = f, o.value = v, r.value = Object.assign({}, at(f, v.config)), a.value = [
                    JSON.stringify(r.value)
                ], Be(()=>{
                    c.value++;
                });
            };
            return nn(()=>{
                n.session.sessionReady.then(async ()=>{
                    u();
                });
            }), (f, v)=>o.value ? (x(), N("div", _a, [
                    y("div", Ca, [
                        (x(), Z(So, {
                            key: c.value.toString(),
                            schema: s.value,
                            modelValue: r.value,
                            "onUpdate:modelValue": v[0] || (v[0] = (g)=>r.value = g),
                            "key-value": "config",
                            "config-object": o.value.config
                        }, null, 8, [
                            "schema",
                            "modelValue",
                            "config-object"
                        ]))
                    ]),
                    y("div", null, [
                        A(S(J), {
                            onClick: p,
                            label: "Save",
                            style: {
                                "margin-right": "1rem"
                            }
                        }),
                        A(S(J), {
                            onClick: u,
                            label: "Reset"
                        })
                    ])
                ])) : (x(), N("div", Sa, [
                    v[1] || (v[1] = y("h2", null, "Loading...", -1)),
                    A(S(os))
                ]));
        }
    });
    $a = {
        id: "provider-select"
    };
    Ta = {
        key: 0,
        id: "provider-select-container",
        class: "config-option"
    };
    Ea = {
        id: "provider-select-selector"
    };
    Oa = {
        id: "provider-select-providers"
    };
    Ra = {
        class: "list-buttons"
    };
    Pa = {
        class: "dialog-buttons"
    };
    Aa = {
        key: 1
    };
    Ia = oe({
        __name: "ProviderSelector",
        props: [
            "configType"
        ],
        emits: [
            "setAgentModel",
            "closeDialog"
        ],
        setup (t, { emit: e }) {
            const n = de("beakerSession"), o = R(), s = R(), r = R(), a = R({}), i = R(), c = po(), l = R(), p = R(), u = t, f = ()=>C.value ? Object.fromEntries(Object.entries(C.value.fields).map(([k, w])=>[
                        k,
                        w.default_value
                    ])) : {}, v = G(()=>a.value.provider), g = G(()=>{
                const k = Array.isArray(a.value?.providers) ? a.value.providers : [];
                return v.value && !k.map((w)=>w.name).includes(v.value) && k.splice(0, 0, {
                    name: v.value,
                    value: f()
                }), a.value?.providers?.map((w)=>w.name);
            }), C = G(()=>r.value?.fields.providers.type_args[0]), _ = G({
                get () {
                    if (!a.value) return f();
                    const k = Array.isArray(a.value.providers) ? Object.fromEntries(a.value?.providers?.map((w)=>[
                            w.name,
                            w.value
                        ])) : {};
                    return Object.hasOwn(k, v.value) ? k[v.value] : f();
                },
                set (k) {}
            }), h = e, T = async (k = !1)=>{
                if (!a.value.provider && !k) c.require({
                    message: `Without a provider selected, you will
not be able to use the Beaker Agent.`,
                    header: "Warning: No provider selected",
                    icon: "pi pi-exclamation-triangle",
                    acceptLabel: "Proceed",
                    rejectLabel: "Cancel",
                    accept: ()=>{
                        Be(()=>T(!0));
                    }
                });
                else {
                    let w, V;
                    s.value.config_type === "file" ? (w = `You are about to update file '${s.value.config_id}'.
Proceed?`, V = async ()=>{
                        (await To(n, r.value, a.value, s.value.config)).ok && (h("setAgentModel", _.value, !0), h("closeDialog"));
                    }) : s.value.config_type === "session" && (w = `You are about to set the configuration for this session only. No values will be saved.
Proceed?`, V = async ()=>{
                        h("setAgentModel", {
                            provider_id: v.value,
                            model_config: _.value
                        }, !0), h("closeDialog");
                    }), c.require({
                        message: w,
                        header: "Apply Changes",
                        accept: V
                    });
                }
            }, O = async ()=>{
                const { schema: k, config: w } = await $o(n);
                r.value = k, s.value = w, a.value = Object.assign({}, at(k, w.config)), i.value = [
                    JSON.stringify(a.value)
                ];
            }, b = ()=>{
                const k = l.value;
                a.value.providers.map((w)=>w.name).includes(k) || (a.value.providers.push({
                    name: k,
                    value: f()
                }), o.value.hide(), l.value = "", Be(()=>{
                    a.value.provider = k;
                }));
            }, B = ()=>{
                const k = a.value.providers.findIndex((w)=>w.name === a.value.provider);
                a.value.provider = "", a.value.providers.splice(k, 1);
            }, $ = ()=>{
                h("closeDialog");
            };
            return nn(()=>{
                n.session.sessionReady.then(async ()=>{
                    O();
                });
            }), (k, w)=>(x(), N("div", $a, [
                    u.configType !== "server" && s.value?.config_type !== "server" ? (x(), N("div", Ta, [
                        y("div", Ea, [
                            A(S(ss), {
                                modelValue: a.value.provider,
                                "onUpdate:modelValue": w[0] || (w[0] = (V)=>a.value.provider = V),
                                options: g.value
                            }, null, 8, [
                                "modelValue",
                                "options"
                            ])
                        ]),
                        y("div", Oa, [
                            A(So, {
                                schema: C.value,
                                modelValue: _.value,
                                "onUpdate:modelValue": w[1] || (w[1] = (V)=>_.value = V),
                                "key-value": "config.providers",
                                "config-object": a.value
                            }, null, 8, [
                                "schema",
                                "modelValue",
                                "config-object"
                            ])
                        ]),
                        y("div", Ra, [
                            A(S(J), {
                                icon: "pi pi-plus",
                                onClick: w[2] || (w[2] = (V)=>o.value.toggle(V)),
                                severity: "info"
                            }),
                            A(S(rs), {
                                class: "saveas-overlay",
                                ref_key: "saveAsHoverMenuRef",
                                ref: o,
                                popup: !0
                            }, {
                                default: H(()=>[
                                        w[9] || (w[9] = y("div", null, "Provider name", -1)),
                                        A(S(ot), null, {
                                            default: H(()=>[
                                                    A(S(Ze), {
                                                        class: "newProviderName-input",
                                                        ref_key: "newProviderNameInputRef",
                                                        ref: p,
                                                        modelValue: l.value,
                                                        "onUpdate:modelValue": w[3] || (w[3] = (V)=>l.value = V),
                                                        onKeydown: w[4] || (w[4] = Dt((V)=>b(), [
                                                            "enter"
                                                        ])),
                                                        autofocus: ""
                                                    }, null, 8, [
                                                        "modelValue"
                                                    ]),
                                                    A(S(J), {
                                                        label: "Save",
                                                        onClick: w[5] || (w[5] = (V)=>b())
                                                    })
                                                ]),
                                            _: 1
                                        })
                                    ]),
                                _: 1
                            }, 512),
                            A(S(J), {
                                icon: "pi pi-trash",
                                disabled: !a.value.provider,
                                onClick: B,
                                severity: "danger"
                            }, null, 8, [
                                "disabled"
                            ])
                        ]),
                        y("div", Pa, [
                            A(S(J), {
                                onClick: w[6] || (w[6] = (V)=>O()),
                                label: "Reset",
                                severity: "warning"
                            }),
                            A(S(J), {
                                onClick: w[7] || (w[7] = (V)=>$()),
                                label: "Cancel",
                                severity: "danger"
                            }),
                            A(S(J), {
                                onClick: w[8] || (w[8] = (V)=>T(!1)),
                                label: "Save",
                                severity: "success"
                            })
                        ])
                    ])) : (x(), N("div", Aa, [
                        ...w[10] || (w[10] = [
                            y("h3", null, "Please contact the system administrator to resolve the above issue(s) with the LLM provider or service.", -1)
                        ])
                    ]))
                ]));
        }
    });
    var jt, Bn;
    function Ba() {
        if (Bn) return jt;
        Bn = 1;
        function t(a, i) {
            for(; a.length < i;)a = "0" + a;
            return a;
        }
        function e(a, i) {
            var c, l, p;
            if (i.length === 0) return a;
            for(c = 0, p = i.length; c < p; c++)l = i.charCodeAt(c), a = (a << 5) - a + l, a |= 0;
            return a < 0 ? a * -2 : a;
        }
        function n(a, i, c) {
            return Object.keys(i).sort().reduce(l, a);
            function l(p, u) {
                return o(p, i[u], u, c);
            }
        }
        function o(a, i, c, l) {
            var p = e(e(e(a, c), s(i)), typeof i);
            if (i === null) return e(p, "null");
            if (i === void 0) return e(p, "undefined");
            if (typeof i == "object" || typeof i == "function") {
                if (l.indexOf(i) !== -1) return e(p, "[Circular]" + c);
                l.push(i);
                var u = n(p, i, l);
                if (!("valueOf" in i) || typeof i.valueOf != "function") return u;
                try {
                    return e(u, String(i.valueOf()));
                } catch (f) {
                    return e(u, "[valueOf exception]" + (f.stack || f.message));
                }
            }
            return e(p, i.toString());
        }
        function s(a) {
            return Object.prototype.toString.call(a);
        }
        function r(a) {
            return t(o(0, a, "", []).toString(16), 8);
        }
        return jt = r, jt;
    }
    var Na = Ba();
    const Nn = go(Na);
    var ja = Object.freeze({
        autofocus: !1,
        disabled: !1,
        indentWithTab: !0,
        tabSize: 2,
        placeholder: "",
        autoDestroy: !0,
        extensions: [
            Ns
        ]
    }), Ma = Symbol("vue-codemirror-global-config"), ye, La = function(t) {
        var e = t.onUpdate, n = t.onChange, o = t.onFocus, s = t.onBlur, r = (function(a, i) {
            var c = {};
            for(var l in a)Object.prototype.hasOwnProperty.call(a, l) && i.indexOf(l) < 0 && (c[l] = a[l]);
            if (a != null && typeof Object.getOwnPropertySymbols == "function") {
                var p = 0;
                for(l = Object.getOwnPropertySymbols(a); p < l.length; p++)i.indexOf(l[p]) < 0 && Object.prototype.propertyIsEnumerable.call(a, l[p]) && (c[l[p]] = a[l[p]]);
            }
            return c;
        })(t, [
            "onUpdate",
            "onChange",
            "onFocus",
            "onBlur"
        ]);
        return tt.create({
            doc: r.doc,
            selection: r.selection,
            extensions: (Array.isArray(r.extensions) ? r.extensions : [
                r.extensions
            ]).concat([
                Ve.updateListener.of((function(a) {
                    e(a), a.docChanged && n(a.state.doc.toString(), a), a.focusChanged && (a.view.hasFocus ? o(a) : s(a));
                }))
            ])
        });
    }, qe = function(t) {
        var e = new js;
        return {
            compartment: e,
            run: function(n) {
                e.get(t.state) ? t.dispatch({
                    effects: e.reconfigure(n)
                }) : t.dispatch({
                    effects: Ms.appendConfig.of(e.of(n))
                });
            }
        };
    }, jn = function(t, e) {
        var n = qe(t), o = n.compartment, s = n.run;
        return function(r) {
            var a = o.get(t.state);
            s(r ?? a !== e ? e : []);
        };
    }, ft = {
        type: Boolean,
        default: void 0
    }, Va = {
        autofocus: ft,
        disabled: ft,
        indentWithTab: ft,
        tabSize: Number,
        placeholder: String,
        style: Object,
        autoDestroy: ft,
        phrases: Object,
        root: Object,
        extensions: Array,
        selection: Object
    }, za = {
        modelValue: {
            type: String,
            default: ""
        }
    }, Da = Object.assign(Object.assign({}, Va), za);
    (function(t) {
        t.Change = "change", t.Update = "update", t.Focus = "focus", t.Blur = "blur", t.Ready = "ready", t.ModelUpdate = "update:modelValue";
    })(ye || (ye = {}));
    var Le = {};
    Le[ye.Change] = function(t, e) {
        return !0;
    }, Le[ye.Update] = function(t) {
        return !0;
    }, Le[ye.Focus] = function(t) {
        return !0;
    }, Le[ye.Blur] = function(t) {
        return !0;
    }, Le[ye.Ready] = function(t) {
        return !0;
    };
    var Eo = {};
    Eo[ye.ModelUpdate] = Le[ye.Change];
    var Fa = Object.assign(Object.assign({}, Le), Eo), Ua = oe({
        name: "VueCodemirror",
        props: Object.assign({}, Da),
        emits: Object.assign({}, Fa),
        setup: function(t, e) {
            var n = et(), o = et(), s = et(), r = Object.assign(Object.assign({}, ja), de(Ma, {})), a = G((function() {
                var i = {};
                return Object.keys($t(t)).forEach((function(c) {
                    var l;
                    c !== "modelValue" && (i[c] = (l = t[c]) !== null && l !== void 0 ? l : r[c]);
                })), i;
            }));
            return Ne((function() {
                var i;
                o.value = La({
                    doc: t.modelValue,
                    selection: a.value.selection,
                    extensions: (i = r.extensions) !== null && i !== void 0 ? i : [],
                    onFocus: function(l) {
                        return e.emit(ye.Focus, l);
                    },
                    onBlur: function(l) {
                        return e.emit(ye.Blur, l);
                    },
                    onUpdate: function(l) {
                        return e.emit(ye.Update, l);
                    },
                    onChange: function(l, p) {
                        l !== t.modelValue && (e.emit(ye.Change, l, p), e.emit(ye.ModelUpdate, l, p));
                    }
                }), s.value = (function(l) {
                    return new Ve(Object.assign({}, l));
                })({
                    state: o.value,
                    parent: n.value,
                    root: a.value.root
                });
                var c = (function(l) {
                    var p = function() {
                        return l.state.doc.toString();
                    }, u = qe(l).run, f = jn(l, [
                        Ve.editable.of(!1),
                        tt.readOnly.of(!0)
                    ]), v = jn(l, vo.of([
                        As
                    ])), g = qe(l).run, C = qe(l).run, _ = qe(l).run, h = qe(l).run;
                    return {
                        focus: function() {
                            return l.focus();
                        },
                        getDoc: p,
                        setDoc: function(T) {
                            T !== p() && l.dispatch({
                                changes: {
                                    from: 0,
                                    to: l.state.doc.length,
                                    insert: T
                                }
                            });
                        },
                        reExtensions: u,
                        toggleDisabled: f,
                        toggleIndentWithTab: v,
                        setTabSize: function(T) {
                            g([
                                tt.tabSize.of(T),
                                Bs.of(" ".repeat(T))
                            ]);
                        },
                        setPhrases: function(T) {
                            C([
                                tt.phrases.of(T)
                            ]);
                        },
                        setPlaceholder: function(T) {
                            _(Is(T));
                        },
                        setStyle: function(T) {
                            T === void 0 && (T = {}), h(Ve.theme({
                                "&": Object.assign({}, T)
                            }));
                        }
                    };
                })(s.value);
                ge((function() {
                    return t.modelValue;
                }), (function(l) {
                    l !== c.getDoc() && c.setDoc(l);
                })), ge((function() {
                    return t.extensions;
                }), (function(l) {
                    return c.reExtensions(l || []);
                }), {
                    immediate: !0
                }), ge((function() {
                    return a.value.disabled;
                }), (function(l) {
                    return c.toggleDisabled(l);
                }), {
                    immediate: !0
                }), ge((function() {
                    return a.value.indentWithTab;
                }), (function(l) {
                    return c.toggleIndentWithTab(l);
                }), {
                    immediate: !0
                }), ge((function() {
                    return a.value.tabSize;
                }), (function(l) {
                    return c.setTabSize(l);
                }), {
                    immediate: !0
                }), ge((function() {
                    return a.value.phrases;
                }), (function(l) {
                    return c.setPhrases(l || {});
                }), {
                    immediate: !0
                }), ge((function() {
                    return a.value.placeholder;
                }), (function(l) {
                    return c.setPlaceholder(l);
                }), {
                    immediate: !0
                }), ge((function() {
                    return a.value.style;
                }), (function(l) {
                    return c.setStyle(l);
                }), {
                    immediate: !0
                }), a.value.autofocus && c.focus(), e.emit(ye.Ready, {
                    state: o.value,
                    view: s.value,
                    container: n.value
                });
            })), as((function() {
                a.value.autoDestroy && s.value && (function(i) {
                    i.destroy();
                })(s.value);
            })), function() {
                return Je("div", {
                    class: "v-codemirror",
                    style: {
                        display: "contents"
                    },
                    ref: n
                });
            };
        }
    }), Ha = Ua;
    let Wa, Mn, qa, Za, gt, qt, Ga, Ja, Ln, Ka, Ya, Vn, zn, Mt, Qa, Dn, Xa, ei, ti, ni, oi, si, ri, ai, ii, li, ci, ui, di, pi, fi, hi, gi;
    Wa = "#e5c07b";
    Mn = "#e06c75";
    qa = "#56b6c2";
    Za = "#ffffff";
    gt = "#abb2bf";
    qt = "#7d8799";
    Ga = "#61afef";
    Ja = "#98c379";
    Ln = "#d19a66";
    Ka = "#c678dd";
    Ya = "#21252b";
    Vn = "#2c313a";
    zn = "#282c34";
    Mt = "#353a42";
    Qa = "#3E4451";
    Dn = "#528bff";
    Xa = Ve.theme({
        "&": {
            color: gt,
            backgroundColor: zn
        },
        ".cm-content": {
            caretColor: Dn
        },
        ".cm-cursor, .cm-dropCursor": {
            borderLeftColor: Dn
        },
        "&.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection": {
            backgroundColor: Qa
        },
        ".cm-panels": {
            backgroundColor: Ya,
            color: gt
        },
        ".cm-panels.cm-panels-top": {
            borderBottom: "2px solid black"
        },
        ".cm-panels.cm-panels-bottom": {
            borderTop: "2px solid black"
        },
        ".cm-searchMatch": {
            backgroundColor: "#72a1ff59",
            outline: "1px solid #457dff"
        },
        ".cm-searchMatch.cm-searchMatch-selected": {
            backgroundColor: "#6199ff2f"
        },
        ".cm-activeLine": {
            backgroundColor: "#6699ff0b"
        },
        ".cm-selectionMatch": {
            backgroundColor: "#aafe661a"
        },
        "&.cm-focused .cm-matchingBracket, &.cm-focused .cm-nonmatchingBracket": {
            backgroundColor: "#bad0f847"
        },
        ".cm-gutters": {
            backgroundColor: zn,
            color: qt,
            border: "none"
        },
        ".cm-activeLineGutter": {
            backgroundColor: Vn
        },
        ".cm-foldPlaceholder": {
            backgroundColor: "transparent",
            border: "none",
            color: "#ddd"
        },
        ".cm-tooltip": {
            border: "none",
            backgroundColor: Mt
        },
        ".cm-tooltip .cm-tooltip-arrow:before": {
            borderTopColor: "transparent",
            borderBottomColor: "transparent"
        },
        ".cm-tooltip .cm-tooltip-arrow:after": {
            borderTopColor: Mt,
            borderBottomColor: Mt
        },
        ".cm-tooltip-autocomplete": {
            "& > ul > li[aria-selected]": {
                backgroundColor: Vn,
                color: gt
            }
        }
    }, {
        dark: !0
    });
    ei = Vs.define([
        {
            tag: U.keyword,
            color: Ka
        },
        {
            tag: [
                U.name,
                U.deleted,
                U.character,
                U.propertyName,
                U.macroName
            ],
            color: Mn
        },
        {
            tag: [
                U.function(U.variableName),
                U.labelName
            ],
            color: Ga
        },
        {
            tag: [
                U.color,
                U.constant(U.name),
                U.standard(U.name)
            ],
            color: Ln
        },
        {
            tag: [
                U.definition(U.name),
                U.separator
            ],
            color: gt
        },
        {
            tag: [
                U.typeName,
                U.className,
                U.number,
                U.changed,
                U.annotation,
                U.modifier,
                U.self,
                U.namespace
            ],
            color: Wa
        },
        {
            tag: [
                U.operator,
                U.operatorKeyword,
                U.url,
                U.escape,
                U.regexp,
                U.link,
                U.special(U.string)
            ],
            color: qa
        },
        {
            tag: [
                U.meta,
                U.comment
            ],
            color: qt
        },
        {
            tag: U.strong,
            fontWeight: "bold"
        },
        {
            tag: U.emphasis,
            fontStyle: "italic"
        },
        {
            tag: U.strikethrough,
            textDecoration: "line-through"
        },
        {
            tag: U.link,
            color: qt,
            textDecoration: "underline"
        },
        {
            tag: U.heading,
            fontWeight: "bold",
            color: Mn
        },
        {
            tag: [
                U.atom,
                U.bool,
                U.special(U.variableName)
            ],
            color: Ln
        },
        {
            tag: [
                U.processingInstruction,
                U.string,
                U.inserted
            ],
            color: Ja
        },
        {
            tag: U.invalid,
            color: Za
        }
    ]);
    ti = [
        Xa,
        Ls(ei)
    ];
    mt = oe({
        __name: "CodeEditor",
        props: {
            displayMode: {
                default: "light"
            },
            language: {},
            languageOptions: {},
            autocompleteEnabled: {
                type: Boolean,
                default: !0
            },
            autocompleteOptions: {},
            modelValue: {},
            autofocus: {
                type: Boolean,
                default: !1
            },
            disabled: {
                type: Boolean,
                default: !1
            },
            readonly: {
                type: Boolean
            },
            annotations: {
                default: ()=>[]
            },
            annotationProvider: {
                default: "linter"
            }
        },
        emits: [
            "submit",
            "update:modelValue"
        ],
        setup (t, { expose: e, emit: n }) {
            const o = de("session"), s = t, r = R(s.modelValue), a = n, { theme: i } = de("theme"), c = et(), l = et(), p = ({ view: _, state: h })=>{
                c.value = _, l.value = h;
            }, u = (_)=>{
                a("update:modelValue", _);
            }, f = G(()=>i.mode === "default" ? "light" : i.mode), v = G(()=>{
                const h = [
                    ...zs.filter((b)=>![
                            "Tab",
                            "Escape"
                        ].includes(b.key)),
                    {
                        key: "Tab",
                        run: (b)=>{
                            const B = b.state, $ = B.selection.main, k = B.doc.lineAt($.from), w = k.text.match(/\S|$/)?.index || 0, V = $.from >= k.from && $.from <= k.from + w;
                            return Cn(B) === "active" && Ds(B) !== null ? qs(b) : V ? !1 : (Fs(b), !0);
                        }
                    },
                    {
                        any (b, B) {
                            if (B.key === "Escape") {
                                const $ = b.state;
                                return Cn($) === "active" && (B.stopImmediatePropagation(), B.stopPropagation(), B.preventDefault(), Us(b)), !0;
                            }
                            return !1;
                        }
                    }
                ], T = [
                    Hs.highest(vo.of(h)),
                    tt.readOnly.of(s.readonly ?? !1),
                    Ve.lineWrapping,
                    [
                        Ve.theme({
                            ".cm-scroller": {
                                fontFamily: "'Ubuntu Mono', 'Courier New', Courier, monospace"
                            }
                        })
                    ]
                ];
                f.value === "dark" && T.push(ti);
                const O = qo.get(s.language);
                if (s.autocompleteEnabled) {
                    let b;
                    s.autocompleteOptions ? b = Sn({
                        override: [
                            Ws(s.autocompleteOptions)
                        ],
                        defaultKeymap: !1,
                        activateOnCompletion: O?.activateOnCompletion
                    }) : b = Sn({
                        override: [
                            (B)=>Zo(B, o)
                        ],
                        defaultKeymap: !1,
                        activateOnCompletion: O?.activateOnCompletion
                    }), T.push(b);
                }
                if (O !== void 0) {
                    const b = O.initializer(s.languageOptions);
                    T.push(b);
                }
                if (s.annotations?.length) try {
                    const B = yn.create(s.annotationProvider || "decoration").createExtensions(s.annotations);
                    T.push(...B);
                } catch (b) {
                    console.warn(`Failed to create annotation provider '${s.annotationProvider}':`, b);
                    const $ = yn.create("linter").createExtensions(s.annotations);
                    T.push(...$);
                }
                return T;
            });
            return e({
                focus: ()=>{
                    c.value?.focus();
                },
                blur: ()=>{
                    c.value?.contentDOM?.blur();
                },
                view: c,
                update: u,
                model: r
            }), (_, h)=>(x(), Z(S(Ha), {
                    modelValue: r.value,
                    "onUpdate:modelValue": [
                        h[0] || (h[0] = (T)=>r.value = T),
                        u
                    ],
                    extensions: v.value,
                    disabled: s.disabled,
                    autofocus: s.autofocus,
                    onReady: p
                }, null, 8, [
                    "modelValue",
                    "extensions",
                    "disabled",
                    "autofocus"
                ]));
        }
    });
    ni = {
        class: "code-container"
    };
    oi = {
        class: "flex",
        style: {
            "align-items": "center"
        }
    };
    si = {
        class: "labeled-check"
    };
    ri = {
        class: "labeled-check ml-2"
    };
    ai = {
        style: {
            width: "100%",
            "text-align": "center"
        }
    };
    ii = oe({
        __name: "BeakerContextSelection",
        props: [
            "isOpen",
            "contextProcessing"
        ],
        emits: [
            "update-context-info",
            "context-changed",
            "close-context-selection"
        ],
        setup (t, { emit: e }) {
            const n = t, o = R(void 0), s = R([]), r = R([]), a = de("beakerSession"), i = e, c = R(), l = R(void 0), p = R({}), u = ()=>{
                i("close-context-selection");
            }, f = G(()=>{
                const _ = Object.keys(o.value || {});
                return Array.isArray(_) ? _.map((h)=>({
                        slug: h
                    })) : [];
            }), v = G(()=>{
                if (o.value !== void 0 && c.value) return o.value[c.value];
            }), g = G(()=>!o.value || v.value === void 0 ? [] : v.value.languages);
            ge(c, (_)=>{
                const h = g.value, T = l.value;
                T && Array.isArray(h) && h.length && (h.map((B)=>B.subkernel).includes(T) || (l.value = h[0].subkernel), p.value[_] || (p.value[_] = o.value[c.value].defaultPayload));
            }), ge(()=>n.isOpen, (_)=>{
                if (_ && (a.activeContext.language && (l.value = a.activeContext.language.subkernel, c.value = a.activeContext.slug, p.value[c.value] || (p.value[c.value] = JSON.stringify(a.activeContext.config))), a.activeContext.info)) {
                    const h = a.activeContext.info.debug.toString();
                    s.value.length ? s.value[0] = h : s.value.push(h);
                    const T = a.activeContext.info.verbose.toString();
                    r.value.length ? r.value[0] = T : r.value.push(T);
                }
            });
            const C = async ()=>{
                const _ = s.value.includes("true"), h = r.value.includes("true"), T = p.value[c.value], O = {
                    context: c.value,
                    language: l.value,
                    context_info: JSON.parse(T || ""),
                    debug: _,
                    verbose: h
                };
                i("context-changed", O), i("close-context-selection");
            };
            return Ne(async ()=>{
                const _ = await a?.session?.availableContexts();
                _ && (o.value = _, c.value = Object.keys(_)[0]);
            }), (_, h)=>(x(), Z(S(on), {
                    visible: n.isOpen,
                    "onUpdate:visible": u,
                    closable: "",
                    modal: "",
                    header: "Configure Context",
                    style: {
                        width: "40rem"
                    }
                }, {
                    footer: H(()=>[
                            y("div", ai, [
                                A(S(J), {
                                    loading: n.contextProcessing,
                                    raised: "",
                                    onClick: C,
                                    label: "Apply",
                                    size: "small"
                                }, null, 8, [
                                    "loading"
                                ])
                            ])
                        ]),
                    default: H(()=>[
                            h[8] || (h[8] = y("p", null, " Select context and language. ", -1)),
                            A(S(ot), null, {
                                default: H(()=>[
                                        A(S(xn), {
                                            modelValue: c.value,
                                            "onUpdate:modelValue": h[0] || (h[0] = (T)=>c.value = T),
                                            options: f.value,
                                            "option-label": "slug",
                                            "option-value": "slug"
                                        }, null, 8, [
                                            "modelValue",
                                            "options"
                                        ]),
                                        A(S(xn), {
                                            modelValue: l.value,
                                            "onUpdate:modelValue": h[1] || (h[1] = (T)=>l.value = T),
                                            options: g.value,
                                            "option-label": "slug",
                                            "option-value": "subkernel"
                                        }, null, 8, [
                                            "modelValue",
                                            "options"
                                        ])
                                    ]),
                                _: 1
                            }),
                            h[9] || (h[9] = y("h4", {
                                class: "h-less-pad"
                            }, "Context Info", -1)),
                            y("div", ni, [
                                A(mt, {
                                    "tab-size": 2,
                                    language: "javascript",
                                    modelValue: p.value[c.value],
                                    "onUpdate:modelValue": h[2] || (h[2] = (T)=>p.value[c.value] = T)
                                }, null, 8, [
                                    "modelValue"
                                ])
                            ]),
                            y("div", null, [
                                h[7] || (h[7] = y("h4", {
                                    class: "h-less-pad"
                                }, "Logging", -1)),
                                y("div", oi, [
                                    y("div", si, [
                                        A(S(_n), {
                                            modelValue: s.value,
                                            "onUpdate:modelValue": h[3] || (h[3] = (T)=>s.value = T),
                                            inputId: "logging-debug-check",
                                            value: "true"
                                        }, null, 8, [
                                            "modelValue"
                                        ]),
                                        h[5] || (h[5] = y("label", {
                                            for: "logging-debug-check",
                                            class: "ml-1"
                                        }, "Debug", -1))
                                    ]),
                                    y("div", ri, [
                                        A(S(_n), {
                                            modelValue: r.value,
                                            "onUpdate:modelValue": h[4] || (h[4] = (T)=>r.value = T),
                                            inputId: "logging-verbose-check",
                                            value: "true"
                                        }, null, 8, [
                                            "modelValue"
                                        ]),
                                        h[6] || (h[6] = y("label", {
                                            for: "logging-verbose-check",
                                            class: "ml-1"
                                        }, "Verbose", -1))
                                    ])
                                ])
                            ])
                        ]),
                    _: 1
                }, 8, [
                    "visible"
                ]));
        }
    });
    li = {
        key: 0,
        class: "footer-pane"
    };
    ci = oe({
        __name: "FooterDrawer",
        setup (t) {
            const e = R(!1), n = R([
                {
                    label: "Shortcuts & help",
                    icon: "pi pi-compass",
                    command: ()=>{
                        e.value = !e.value;
                    }
                }
            ]);
            return (o, s)=>(x(), N(le, null, [
                    A(S(is), {
                        model: n.value,
                        breakpoint: "800",
                        class: "footer-menu-bar"
                    }, null, 8, [
                        "model"
                    ]),
                    A(ls, {
                        name: "slide"
                    }, {
                        default: H(()=>[
                                e.value ? (x(), N("div", li, [
                                    ...s[0] || (s[0] = [
                                        y("div", null, [
                                            y("h3", null, "Keyboard Shortcuts"),
                                            y("pre", null, `Select cell above                           - ArrowUp | j | J
Select cell below                           - ArrowDown | k | K
Edit selected cell                          - Enter
Stop editing selected cell                  - Esc
Insert cell above selected cell             - a | A
Insert cell below selected cell             - b | B
Delete selected cell                        - d | D * twice *
Execute selected cell and step to next cell - Shift-Enter
Execute selected cell                       - Ctrl-Enter
        `)
                                        ], -1),
                                        y("div", null, [
                                            y("h3", null, "Magic commands"),
                                            y("pre", null, `%set_context {context_slug} {language} {context_confg (json object)}

%run_action {action_name} {payload (json object)}
        `)
                                        ], -1)
                                    ])
                                ])) : W("", !0)
                            ]),
                        _: 1
                    })
                ], 64));
        }
    });
    ui = Tt(ci, [
        [
            "__scopeId",
            "data-v-05c37518"
        ]
    ]);
    di = {
        id: "left-panel"
    };
    pi = [
        "id"
    ];
    fi = {
        id: "right-panel"
    };
    hi = {
        key: 0,
        style: {
            "margin-bottom": "1rem"
        }
    };
    gi = {
        style: {
            "font-style": "italic"
        }
    };
    Uc = oe({
        __name: "BaseInterface",
        props: {
            title: {},
            titleExtra: {},
            savefile: {},
            headerNav: {},
            apiKeyPrompt: {
                type: Boolean
            },
            pageClass: {}
        },
        emits: [
            "notebook-autosaved",
            "open-file"
        ],
        setup (t, { expose: e, emit: n }) {
            const o = Xt(), s = cs(), r = R(), a = R(), i = (I)=>{
                const { title: j, detail: F, life: P = 3e3, severity: d = "success" } = I;
                s.add({
                    summary: j,
                    detail: F,
                    life: P,
                    severity: d
                });
            }, c = t, l = n, p = R("connecting"), u = R(), f = R(), v = R(c.apiKeyPrompt || !1);
            R("");
            const g = R(""), C = R(), _ = R(), h = R(), T = R(!1), O = R(!1), b = ()=>{
                T.value = !T.value;
            }, B = (I)=>{
                const j = a.value;
                I ? j.classList.add("maximized") : j.classList.remove("maximized");
            }, $ = (I, j)=>{
                var F;
                typeof I == "string" && (I = Je("div", {
                    innerHTML: I
                })), Go(I) && (I = A("div", null, [
                    A("h3", null, [
                        Te("Error:")
                    ]),
                    A("div", {
                        style: "font-weight: bold"
                    }, [
                        I.ename
                    ]),
                    A("div", null, [
                        I.evalue
                    ]),
                    I.traceback ? A("div", null, [
                        A("h3", null, [
                            Te("Traceback:")
                        ]),
                        A("div", {
                            class: "traceback"
                        }, [
                            I.traceback.join("")
                        ])
                    ]) : void 0
                ])), F = A("div", {
                    id: "overlay"
                }, [
                    A("div", {
                        id: "overlay-content"
                    }, [
                        I
                    ]),
                    A("div", {
                        id: "overlay-footer"
                    }, [
                        A(J, {
                            label: "Close",
                            onClick: ()=>{
                                h.value.close();
                            }
                        }, null)
                    ])
                ]), F && (h.value = o.open(F, {
                    props: {
                        style: {
                            minWidth: "75vw",
                            minHeight: "75vh"
                        },
                        modal: !0,
                        draggable: !1,
                        header: j || "Alert",
                        contentStyle: {
                            flex: 1
                        },
                        contentClass: "overlay-dialog"
                    }
                }));
            };
            yt("show_toast", i), yt("show_overlay", $);
            const k = R(!0), w = (I)=>{
                let j = I.name, F = I.message;
                j === "TypeError" && F === "Failed to fetch" && (j = "ConnectionError", F = "Unable to reach server."), i({
                    title: `Error connecting - ${j}`,
                    detail: `${F}`,
                    severity: "error",
                    life: 5e3
                });
            };
            Ne(async ()=>{
                const I = f.value.session;
                await I.sessionReady;
                var j;
                try {
                    j = JSON.parse(localStorage.getItem("notebookData")) || {};
                } catch (d) {
                    console.error(d), j = {};
                }
                I.session.ready.then(()=>{
                    $t(I.session.session).iopubMessage.connect(V);
                });
                const F = I.sessionId, P = j[F];
                P && Be(async ()=>{
                    if (P.filename !== void 0) {
                        const m = await I.services.contents.get(P.filename);
                        r.value = P.checksum, l("open-file", m.content, m.path, {
                            selectedCell: P.selectedCell
                        });
                    } else P.data !== void 0 && l("open-file", P.data, void 0, {
                        selectedCell: P.selectedCell
                    });
                    P.selectedCell !== void 0 && f.value.notebookComponent && Be(()=>f.value.notebookComponent.selectCell(P.selectedCell));
                }), u.value = setInterval(Q, 3e4), window.addEventListener("beforeunload", Q);
            });
            const V = (I, j)=>{
                j.header.msg_type === "llm_auth_failure" && (v.value = !0, g.value = j.content.msg, j.cell !== void 0 && (C.value = j.cell));
            }, D = async (I = null, j = !1)=>{
                const F = f.value.session;
                await F.sendBeakerMessage("set_agent_model", I).done, j && C.value && C.value.execute(F);
            };
            fo(()=>{
                clearInterval(u.value), u.value = null, window.removeEventListener("beforeunload", Q);
            });
            const Q = async ()=>{
                var I;
                try {
                    I = JSON.parse(localStorage.getItem("notebookData")) || {};
                } catch (d) {
                    console.error(d), I = {};
                }
                const j = f.value.session, F = j.sessionId;
                Object.keys(I).includes(F) || (I[F] = {});
                const P = I[F];
                if (j.notebook) {
                    P.data = j.notebook.toIPynb();
                    const d = f.value.notebookComponent;
                    if (d && (P.selectedCell = d.selectedCellId), c.savefile && typeof c.savefile == "string") {
                        const m = j.notebook.toIPynb(), E = Nn(m);
                        if (!r.value || r.value != E) {
                            r.value = E;
                            const L = j.services.contents, M = c.savefile, X = await L.save(M, {
                                type: "notebook",
                                content: m,
                                format: "text"
                            });
                            l("notebook-autosaved", X.path), i({
                                title: "Autosave",
                                detail: `Auto-saved notebook to file ${c.savefile}.`
                            }), P.filename = X.path, P.checksum = E;
                        }
                    } else {
                        const m = j.notebook.toIPynb(), E = Nn(m);
                        P.filename = void 0, P.data = m, P.checksum = E;
                    }
                    localStorage.setItem("notebookData", JSON.stringify(I));
                }
            }, q = ()=>{};
            return e({
                beakerSession: f,
                showToast: i,
                setMaximized: B,
                getSession: ()=>f.value.getSession()
            }), (I, j)=>(x(), Z(Tr, {
                    id: "beaker-session-container",
                    ref_key: "beakerSession",
                    ref: f,
                    onConnectionFailure: w
                }, {
                    default: H(()=>[
                            y("div", {
                                id: "page",
                                class: ie(c.pageClass)
                            }, [
                                y("header", null, [
                                    xe(I.$slots, "header", {}, ()=>[
                                            A(ia, {
                                                connectionStatus: p.value,
                                                onSelectKernel: b,
                                                title: c.title,
                                                "title-extra": c.titleExtra,
                                                nav: c.headerNav
                                            }, null, 8, [
                                                "connectionStatus",
                                                "title",
                                                "title-extra",
                                                "nav"
                                            ])
                                        ])
                                ]),
                                y("main", {
                                    ref_key: "mainRef",
                                    ref: a
                                }, [
                                    xe(I.$slots, "main", {}, ()=>[
                                            y("div", di, [
                                                xe(I.$slots, "left-panel")
                                            ]),
                                            y("div", {
                                                id: `center-panel${k.value ? "-chat-override" : ""}`
                                            }, [
                                                xe(I.$slots, "default")
                                            ], 8, pi),
                                            y("div", fi, [
                                                xe(I.$slots, "right-panel")
                                            ])
                                        ])
                                ], 512),
                                y("footer", null, [
                                    xe(I.$slots, "footer", {}, ()=>[
                                            A(ui)
                                        ])
                                ]),
                                xe(I.$slots, "context-selection-popup", {}, ()=>[
                                        A(ii, {
                                            isOpen: T.value,
                                            toggleOpen: b,
                                            contextProcessing: O.value,
                                            onContextChanged: j[0] || (j[0] = (F)=>{
                                                f.value.setContext(F);
                                            }),
                                            onCloseContextSelection: j[1] || (j[1] = (F)=>T.value = !1)
                                        }, null, 8, [
                                            "isOpen",
                                            "contextProcessing"
                                        ])
                                    ]),
                                xe(I.$slots, "toast", {}, ()=>[
                                        A(S(ds), {
                                            position: "bottom-right"
                                        })
                                    ]),
                                xe(I.$slots, "confirmation", {}, ()=>[
                                        A(S(ps))
                                    ])
                            ], 2),
                            xe(I.$slots, "login-dialog", {}, ()=>[
                                    A(S(on), {
                                        ref_key: "loginDialogRef",
                                        ref: _,
                                        visible: v.value,
                                        "onUpdate:visible": j[3] || (j[3] = (F)=>v.value = F),
                                        modal: "",
                                        draggable: !1,
                                        header: "Model Provider Configuration",
                                        onShow: q
                                    }, {
                                        default: H(()=>[
                                                g.value ? (x(), N("div", hi, [
                                                    j[4] || (j[4] = y("h3", null, "Message from service:", -1)),
                                                    y("span", gi, K(g.value), 1)
                                                ])) : W("", !0),
                                                A(Ia, {
                                                    "config-type": f.value?.connectionSettings?.config_type,
                                                    onSetAgentModel: D,
                                                    onCloseDialog: j[2] || (j[2] = (F)=>v.value = !1)
                                                }, null, 8, [
                                                    "config-type"
                                                ])
                                            ]),
                                        _: 1
                                    }, 8, [
                                        "visible"
                                    ])
                                ]),
                            A(S(us))
                        ]),
                    _: 3
                }, 512));
        }
    });
    function an() {
        return {
            async: !1,
            breaks: !1,
            extensions: null,
            gfm: !0,
            hooks: null,
            pedantic: !1,
            renderer: null,
            silent: !1,
            tokenizer: null,
            walkTokens: null
        };
    }
    var He = an();
    function Oo(t) {
        He = t;
    }
    var nt = {
        exec: ()=>null
    };
    function ee(t, e = "") {
        let n = typeof t == "string" ? t : t.source;
        const o = {
            replace: (s, r)=>{
                let a = typeof r == "string" ? r : r.source;
                return a = a.replace(be.caret, "$1"), n = n.replace(s, a), o;
            },
            getRegex: ()=>new RegExp(n, e)
        };
        return o;
    }
    var be = {
        codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm,
        outputLinkReplace: /\\([\[\]])/g,
        indentCodeCompensation: /^(\s+)(?:```)/,
        beginningSpace: /^\s+/,
        endingHash: /#$/,
        startingSpaceChar: /^ /,
        endingSpaceChar: / $/,
        nonSpaceChar: /[^ ]/,
        newLineCharGlobal: /\n/g,
        tabCharGlobal: /\t/g,
        multipleSpaceGlobal: /\s+/g,
        blankLine: /^[ \t]*$/,
        doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
        blockquoteStart: /^ {0,3}>/,
        blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g,
        blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
        listReplaceTabs: /^\t+/,
        listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
        listIsTask: /^\[[ xX]\] /,
        listReplaceTask: /^\[[ xX]\] +/,
        anyLine: /\n.*\n/,
        hrefBrackets: /^<(.*)>$/,
        tableDelimiter: /[:|]/,
        tableAlignChars: /^\||\| *$/g,
        tableRowBlankLine: /\n[ \t]*$/,
        tableAlignRight: /^ *-+: *$/,
        tableAlignCenter: /^ *:-+: *$/,
        tableAlignLeft: /^ *:-+ *$/,
        startATag: /^<a /i,
        endATag: /^<\/a>/i,
        startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
        endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
        startAngleBracket: /^</,
        endAngleBracket: />$/,
        pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
        unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
        escapeTest: /[&<>"']/,
        escapeReplace: /[&<>"']/g,
        escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
        escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
        unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig,
        caret: /(^|[^\[])\^/g,
        percentDecode: /%25/g,
        findPipe: /\|/g,
        splitPipe: / \|/,
        slashPipe: /\\\|/g,
        carriageReturn: /\r\n|\r/g,
        spaceLine: /^ +$/gm,
        notSpaceStart: /^\S*/,
        endingNewline: /\n$/,
        listItemRegex: (t)=>new RegExp(`^( {0,3}${t})((?:[	 ][^\\n]*)?(?:\\n|$))`),
        nextBulletRegex: (t)=>new RegExp(`^ {0,${Math.min(3, t - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),
        hrRegex: (t)=>new RegExp(`^ {0,${Math.min(3, t - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),
        fencesBeginRegex: (t)=>new RegExp(`^ {0,${Math.min(3, t - 1)}}(?:\`\`\`|~~~)`),
        headingBeginRegex: (t)=>new RegExp(`^ {0,${Math.min(3, t - 1)}}#`),
        htmlBeginRegex: (t)=>new RegExp(`^ {0,${Math.min(3, t - 1)}}<(?:[a-z].*>|!--)`, "i")
    }, mi = /^(?:[ \t]*(?:\n|$))+/, vi = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, yi = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, lt = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, bi = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, ln = /(?:[*+-]|\d{1,9}[.)])/, Ro = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, Po = ee(Ro).replace(/bull/g, ln).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), ki = ee(Ro).replace(/bull/g, ln).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), cn = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, wi = /^[^\n]+/, un = /(?!\s*\])(?:\\.|[^\[\]\\])+/, xi = ee(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", un).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), _i = ee(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, ln).getRegex(), Et = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", dn = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Ci = ee("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", dn).replace("tag", Et).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Ao = ee(cn).replace("hr", lt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Et).getRegex(), Si = ee(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Ao).getRegex(), pn = {
        blockquote: Si,
        code: vi,
        def: xi,
        fences: yi,
        heading: bi,
        hr: lt,
        html: Ci,
        lheading: Po,
        list: _i,
        newline: mi,
        paragraph: Ao,
        table: nt,
        text: wi
    }, Fn = ee("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", lt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Et).getRegex(), $i = {
        ...pn,
        lheading: ki,
        table: Fn,
        paragraph: ee(cn).replace("hr", lt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Fn).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Et).getRegex()
    }, Ti = {
        ...pn,
        html: ee(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", dn).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
        def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
        heading: /^(#{1,6})(.*)(?:\n+|$)/,
        fences: nt,
        lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
        paragraph: ee(cn).replace("hr", lt).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Po).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
    }, Ei = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Oi = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Io = /^( {2,}|\\)\n(?!\s*$)/, Ri = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Ot = /[\p{P}\p{S}]/u, fn = /[\s\p{P}\p{S}]/u, Bo = /[^\s\p{P}\p{S}]/u, Pi = ee(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, fn).getRegex(), No = /(?!~)[\p{P}\p{S}]/u, Ai = /(?!~)[\s\p{P}\p{S}]/u, Ii = /(?:[^\s\p{P}\p{S}]|~)/u, Bi = /\[[^[\]]*?\]\((?:\\.|[^\\\(\)]|\((?:\\.|[^\\\(\)])*\))*\)|`[^`]*?`|<[^<>]*?>/g, jo = /^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/, Ni = ee(jo, "u").replace(/punct/g, Ot).getRegex(), ji = ee(jo, "u").replace(/punct/g, No).getRegex(), Mo = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", Mi = ee(Mo, "gu").replace(/notPunctSpace/g, Bo).replace(/punctSpace/g, fn).replace(/punct/g, Ot).getRegex(), Li = ee(Mo, "gu").replace(/notPunctSpace/g, Ii).replace(/punctSpace/g, Ai).replace(/punct/g, No).getRegex(), Vi = ee("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, Bo).replace(/punctSpace/g, fn).replace(/punct/g, Ot).getRegex(), zi = ee(/\\(punct)/, "gu").replace(/punct/g, Ot).getRegex(), Di = ee(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Fi = ee(dn).replace("(?:-->|$)", "-->").getRegex(), Ui = ee("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Fi).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), xt = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Hi = ee(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label", xt).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Lo = ee(/^!?\[(label)\]\[(ref)\]/).replace("label", xt).replace("ref", un).getRegex(), Vo = ee(/^!?\[(ref)\](?:\[\])?/).replace("ref", un).getRegex(), Wi = ee("reflink|nolink(?!\\()", "g").replace("reflink", Lo).replace("nolink", Vo).getRegex(), hn = {
        _backpedal: nt,
        anyPunctuation: zi,
        autolink: Di,
        blockSkip: Bi,
        br: Io,
        code: Oi,
        del: nt,
        emStrongLDelim: Ni,
        emStrongRDelimAst: Mi,
        emStrongRDelimUnd: Vi,
        escape: Ei,
        link: Hi,
        nolink: Vo,
        punctuation: Pi,
        reflink: Lo,
        reflinkSearch: Wi,
        tag: Ui,
        text: Ri,
        url: nt
    }, qi = {
        ...hn,
        link: ee(/^!?\[(label)\]\((.*?)\)/).replace("label", xt).getRegex(),
        reflink: ee(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", xt).getRegex()
    }, Zt = {
        ...hn,
        emStrongRDelimAst: Li,
        emStrongLDelim: ji,
        url: ee(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
        _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
        del: /^(~~?)(?=[^\s~])((?:\\.|[^\\])*?(?:\\.|[^\s~\\]))\1(?=[^~]|$)/,
        text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
    }, Zi = {
        ...Zt,
        br: ee(Io).replace("{2,}", "*").getRegex(),
        text: ee(Zt.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
    }, ht = {
        normal: pn,
        gfm: $i,
        pedantic: Ti
    }, Ye = {
        normal: hn,
        gfm: Zt,
        breaks: Zi,
        pedantic: qi
    }, Gi = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }, Un = (t)=>Gi[t];
    function $e(t, e) {
        if (e) {
            if (be.escapeTest.test(t)) return t.replace(be.escapeReplace, Un);
        } else if (be.escapeTestNoEncode.test(t)) return t.replace(be.escapeReplaceNoEncode, Un);
        return t;
    }
    function Hn(t) {
        try {
            t = encodeURI(t).replace(be.percentDecode, "%");
        } catch  {
            return null;
        }
        return t;
    }
    function Wn(t, e) {
        const n = t.replace(be.findPipe, (r, a, i)=>{
            let c = !1, l = a;
            for(; --l >= 0 && i[l] === "\\";)c = !c;
            return c ? "|" : " |";
        }), o = n.split(be.splitPipe);
        let s = 0;
        if (o[0].trim() || o.shift(), o.length > 0 && !o.at(-1)?.trim() && o.pop(), e) if (o.length > e) o.splice(e);
        else for(; o.length < e;)o.push("");
        for(; s < o.length; s++)o[s] = o[s].trim().replace(be.slashPipe, "|");
        return o;
    }
    function Qe(t, e, n) {
        const o = t.length;
        if (o === 0) return "";
        let s = 0;
        for(; s < o && t.charAt(o - s - 1) === e;)s++;
        return t.slice(0, o - s);
    }
    function Ji(t, e) {
        if (t.indexOf(e[1]) === -1) return -1;
        let n = 0;
        for(let o = 0; o < t.length; o++)if (t[o] === "\\") o++;
        else if (t[o] === e[0]) n++;
        else if (t[o] === e[1] && (n--, n < 0)) return o;
        return n > 0 ? -2 : -1;
    }
    function qn(t, e, n, o, s) {
        const r = e.href, a = e.title || null, i = t[1].replace(s.other.outputLinkReplace, "$1");
        o.state.inLink = !0;
        const c = {
            type: t[0].charAt(0) === "!" ? "image" : "link",
            raw: n,
            href: r,
            title: a,
            text: i,
            tokens: o.inlineTokens(i)
        };
        return o.state.inLink = !1, c;
    }
    function Ki(t, e, n) {
        const o = t.match(n.other.indentCodeCompensation);
        if (o === null) return e;
        const s = o[1];
        return e.split(`
`).map((r)=>{
            const a = r.match(n.other.beginningSpace);
            if (a === null) return r;
            const [i] = a;
            return i.length >= s.length ? r.slice(s.length) : r;
        }).join(`
`);
    }
    var _t = class {
        options;
        rules;
        lexer;
        constructor(t){
            this.options = t || He;
        }
        space(t) {
            const e = this.rules.block.newline.exec(t);
            if (e && e[0].length > 0) return {
                type: "space",
                raw: e[0]
            };
        }
        code(t) {
            const e = this.rules.block.code.exec(t);
            if (e) {
                const n = e[0].replace(this.rules.other.codeRemoveIndent, "");
                return {
                    type: "code",
                    raw: e[0],
                    codeBlockStyle: "indented",
                    text: this.options.pedantic ? n : Qe(n, `
`)
                };
            }
        }
        fences(t) {
            const e = this.rules.block.fences.exec(t);
            if (e) {
                const n = e[0], o = Ki(n, e[3] || "", this.rules);
                return {
                    type: "code",
                    raw: n,
                    lang: e[2] ? e[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : e[2],
                    text: o
                };
            }
        }
        heading(t) {
            const e = this.rules.block.heading.exec(t);
            if (e) {
                let n = e[2].trim();
                if (this.rules.other.endingHash.test(n)) {
                    const o = Qe(n, "#");
                    (this.options.pedantic || !o || this.rules.other.endingSpaceChar.test(o)) && (n = o.trim());
                }
                return {
                    type: "heading",
                    raw: e[0],
                    depth: e[1].length,
                    text: n,
                    tokens: this.lexer.inline(n)
                };
            }
        }
        hr(t) {
            const e = this.rules.block.hr.exec(t);
            if (e) return {
                type: "hr",
                raw: Qe(e[0], `
`)
            };
        }
        blockquote(t) {
            const e = this.rules.block.blockquote.exec(t);
            if (e) {
                let n = Qe(e[0], `
`).split(`
`), o = "", s = "";
                const r = [];
                for(; n.length > 0;){
                    let a = !1;
                    const i = [];
                    let c;
                    for(c = 0; c < n.length; c++)if (this.rules.other.blockquoteStart.test(n[c])) i.push(n[c]), a = !0;
                    else if (!a) i.push(n[c]);
                    else break;
                    n = n.slice(c);
                    const l = i.join(`
`), p = l.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
                    o = o ? `${o}
${l}` : l, s = s ? `${s}
${p}` : p;
                    const u = this.lexer.state.top;
                    if (this.lexer.state.top = !0, this.lexer.blockTokens(p, r, !0), this.lexer.state.top = u, n.length === 0) break;
                    const f = r.at(-1);
                    if (f?.type === "code") break;
                    if (f?.type === "blockquote") {
                        const v = f, g = v.raw + `
` + n.join(`
`), C = this.blockquote(g);
                        r[r.length - 1] = C, o = o.substring(0, o.length - v.raw.length) + C.raw, s = s.substring(0, s.length - v.text.length) + C.text;
                        break;
                    } else if (f?.type === "list") {
                        const v = f, g = v.raw + `
` + n.join(`
`), C = this.list(g);
                        r[r.length - 1] = C, o = o.substring(0, o.length - f.raw.length) + C.raw, s = s.substring(0, s.length - v.raw.length) + C.raw, n = g.substring(r.at(-1).raw.length).split(`
`);
                        continue;
                    }
                }
                return {
                    type: "blockquote",
                    raw: o,
                    tokens: r,
                    text: s
                };
            }
        }
        list(t) {
            let e = this.rules.block.list.exec(t);
            if (e) {
                let n = e[1].trim();
                const o = n.length > 1, s = {
                    type: "list",
                    raw: "",
                    ordered: o,
                    start: o ? +n.slice(0, -1) : "",
                    loose: !1,
                    items: []
                };
                n = o ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = o ? n : "[*+-]");
                const r = this.rules.other.listItemRegex(n);
                let a = !1;
                for(; t;){
                    let c = !1, l = "", p = "";
                    if (!(e = r.exec(t)) || this.rules.block.hr.test(t)) break;
                    l = e[0], t = t.substring(l.length);
                    let u = e[2].split(`
`, 1)[0].replace(this.rules.other.listReplaceTabs, (h)=>" ".repeat(3 * h.length)), f = t.split(`
`, 1)[0], v = !u.trim(), g = 0;
                    if (this.options.pedantic ? (g = 2, p = u.trimStart()) : v ? g = e[1].length + 1 : (g = e[2].search(this.rules.other.nonSpaceChar), g = g > 4 ? 1 : g, p = u.slice(g), g += e[1].length), v && this.rules.other.blankLine.test(f) && (l += f + `
`, t = t.substring(f.length + 1), c = !0), !c) {
                        const h = this.rules.other.nextBulletRegex(g), T = this.rules.other.hrRegex(g), O = this.rules.other.fencesBeginRegex(g), b = this.rules.other.headingBeginRegex(g), B = this.rules.other.htmlBeginRegex(g);
                        for(; t;){
                            const $ = t.split(`
`, 1)[0];
                            let k;
                            if (f = $, this.options.pedantic ? (f = f.replace(this.rules.other.listReplaceNesting, "  "), k = f) : k = f.replace(this.rules.other.tabCharGlobal, "    "), O.test(f) || b.test(f) || B.test(f) || h.test(f) || T.test(f)) break;
                            if (k.search(this.rules.other.nonSpaceChar) >= g || !f.trim()) p += `
` + k.slice(g);
                            else {
                                if (v || u.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || O.test(u) || b.test(u) || T.test(u)) break;
                                p += `
` + f;
                            }
                            !v && !f.trim() && (v = !0), l += $ + `
`, t = t.substring($.length + 1), u = k.slice(g);
                        }
                    }
                    s.loose || (a ? s.loose = !0 : this.rules.other.doubleBlankLine.test(l) && (a = !0));
                    let C = null, _;
                    this.options.gfm && (C = this.rules.other.listIsTask.exec(p), C && (_ = C[0] !== "[ ] ", p = p.replace(this.rules.other.listReplaceTask, ""))), s.items.push({
                        type: "list_item",
                        raw: l,
                        task: !!C,
                        checked: _,
                        loose: !1,
                        text: p,
                        tokens: []
                    }), s.raw += l;
                }
                const i = s.items.at(-1);
                if (i) i.raw = i.raw.trimEnd(), i.text = i.text.trimEnd();
                else return;
                s.raw = s.raw.trimEnd();
                for(let c = 0; c < s.items.length; c++)if (this.lexer.state.top = !1, s.items[c].tokens = this.lexer.blockTokens(s.items[c].text, []), !s.loose) {
                    const l = s.items[c].tokens.filter((u)=>u.type === "space"), p = l.length > 0 && l.some((u)=>this.rules.other.anyLine.test(u.raw));
                    s.loose = p;
                }
                if (s.loose) for(let c = 0; c < s.items.length; c++)s.items[c].loose = !0;
                return s;
            }
        }
        html(t) {
            const e = this.rules.block.html.exec(t);
            if (e) return {
                type: "html",
                block: !0,
                raw: e[0],
                pre: e[1] === "pre" || e[1] === "script" || e[1] === "style",
                text: e[0]
            };
        }
        def(t) {
            const e = this.rules.block.def.exec(t);
            if (e) {
                const n = e[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), o = e[2] ? e[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", s = e[3] ? e[3].substring(1, e[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : e[3];
                return {
                    type: "def",
                    tag: n,
                    raw: e[0],
                    href: o,
                    title: s
                };
            }
        }
        table(t) {
            const e = this.rules.block.table.exec(t);
            if (!e || !this.rules.other.tableDelimiter.test(e[2])) return;
            const n = Wn(e[1]), o = e[2].replace(this.rules.other.tableAlignChars, "").split("|"), s = e[3]?.trim() ? e[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], r = {
                type: "table",
                raw: e[0],
                header: [],
                align: [],
                rows: []
            };
            if (n.length === o.length) {
                for (const a of o)this.rules.other.tableAlignRight.test(a) ? r.align.push("right") : this.rules.other.tableAlignCenter.test(a) ? r.align.push("center") : this.rules.other.tableAlignLeft.test(a) ? r.align.push("left") : r.align.push(null);
                for(let a = 0; a < n.length; a++)r.header.push({
                    text: n[a],
                    tokens: this.lexer.inline(n[a]),
                    header: !0,
                    align: r.align[a]
                });
                for (const a of s)r.rows.push(Wn(a, r.header.length).map((i, c)=>({
                        text: i,
                        tokens: this.lexer.inline(i),
                        header: !1,
                        align: r.align[c]
                    })));
                return r;
            }
        }
        lheading(t) {
            const e = this.rules.block.lheading.exec(t);
            if (e) return {
                type: "heading",
                raw: e[0],
                depth: e[2].charAt(0) === "=" ? 1 : 2,
                text: e[1],
                tokens: this.lexer.inline(e[1])
            };
        }
        paragraph(t) {
            const e = this.rules.block.paragraph.exec(t);
            if (e) {
                const n = e[1].charAt(e[1].length - 1) === `
` ? e[1].slice(0, -1) : e[1];
                return {
                    type: "paragraph",
                    raw: e[0],
                    text: n,
                    tokens: this.lexer.inline(n)
                };
            }
        }
        text(t) {
            const e = this.rules.block.text.exec(t);
            if (e) return {
                type: "text",
                raw: e[0],
                text: e[0],
                tokens: this.lexer.inline(e[0])
            };
        }
        escape(t) {
            const e = this.rules.inline.escape.exec(t);
            if (e) return {
                type: "escape",
                raw: e[0],
                text: e[1]
            };
        }
        tag(t) {
            const e = this.rules.inline.tag.exec(t);
            if (e) return !this.lexer.state.inLink && this.rules.other.startATag.test(e[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(e[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(e[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(e[0]) && (this.lexer.state.inRawBlock = !1), {
                type: "html",
                raw: e[0],
                inLink: this.lexer.state.inLink,
                inRawBlock: this.lexer.state.inRawBlock,
                block: !1,
                text: e[0]
            };
        }
        link(t) {
            const e = this.rules.inline.link.exec(t);
            if (e) {
                const n = e[2].trim();
                if (!this.options.pedantic && this.rules.other.startAngleBracket.test(n)) {
                    if (!this.rules.other.endAngleBracket.test(n)) return;
                    const r = Qe(n.slice(0, -1), "\\");
                    if ((n.length - r.length) % 2 === 0) return;
                } else {
                    const r = Ji(e[2], "()");
                    if (r === -2) return;
                    if (r > -1) {
                        const i = (e[0].indexOf("!") === 0 ? 5 : 4) + e[1].length + r;
                        e[2] = e[2].substring(0, r), e[0] = e[0].substring(0, i).trim(), e[3] = "";
                    }
                }
                let o = e[2], s = "";
                if (this.options.pedantic) {
                    const r = this.rules.other.pedanticHrefTitle.exec(o);
                    r && (o = r[1], s = r[3]);
                } else s = e[3] ? e[3].slice(1, -1) : "";
                return o = o.trim(), this.rules.other.startAngleBracket.test(o) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(n) ? o = o.slice(1) : o = o.slice(1, -1)), qn(e, {
                    href: o && o.replace(this.rules.inline.anyPunctuation, "$1"),
                    title: s && s.replace(this.rules.inline.anyPunctuation, "$1")
                }, e[0], this.lexer, this.rules);
            }
        }
        reflink(t, e) {
            let n;
            if ((n = this.rules.inline.reflink.exec(t)) || (n = this.rules.inline.nolink.exec(t))) {
                const o = (n[2] || n[1]).replace(this.rules.other.multipleSpaceGlobal, " "), s = e[o.toLowerCase()];
                if (!s) {
                    const r = n[0].charAt(0);
                    return {
                        type: "text",
                        raw: r,
                        text: r
                    };
                }
                return qn(n, s, n[0], this.lexer, this.rules);
            }
        }
        emStrong(t, e, n = "") {
            let o = this.rules.inline.emStrongLDelim.exec(t);
            if (!o || o[3] && n.match(this.rules.other.unicodeAlphaNumeric)) return;
            if (!(o[1] || o[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
                const r = [
                    ...o[0]
                ].length - 1;
                let a, i, c = r, l = 0;
                const p = o[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
                for(p.lastIndex = 0, e = e.slice(-1 * t.length + r); (o = p.exec(e)) != null;){
                    if (a = o[1] || o[2] || o[3] || o[4] || o[5] || o[6], !a) continue;
                    if (i = [
                        ...a
                    ].length, o[3] || o[4]) {
                        c += i;
                        continue;
                    } else if ((o[5] || o[6]) && r % 3 && !((r + i) % 3)) {
                        l += i;
                        continue;
                    }
                    if (c -= i, c > 0) continue;
                    i = Math.min(i, i + c + l);
                    const u = [
                        ...o[0]
                    ][0].length, f = t.slice(0, r + o.index + u + i);
                    if (Math.min(r, i) % 2) {
                        const g = f.slice(1, -1);
                        return {
                            type: "em",
                            raw: f,
                            text: g,
                            tokens: this.lexer.inlineTokens(g)
                        };
                    }
                    const v = f.slice(2, -2);
                    return {
                        type: "strong",
                        raw: f,
                        text: v,
                        tokens: this.lexer.inlineTokens(v)
                    };
                }
            }
        }
        codespan(t) {
            const e = this.rules.inline.code.exec(t);
            if (e) {
                let n = e[2].replace(this.rules.other.newLineCharGlobal, " ");
                const o = this.rules.other.nonSpaceChar.test(n), s = this.rules.other.startingSpaceChar.test(n) && this.rules.other.endingSpaceChar.test(n);
                return o && s && (n = n.substring(1, n.length - 1)), {
                    type: "codespan",
                    raw: e[0],
                    text: n
                };
            }
        }
        br(t) {
            const e = this.rules.inline.br.exec(t);
            if (e) return {
                type: "br",
                raw: e[0]
            };
        }
        del(t) {
            const e = this.rules.inline.del.exec(t);
            if (e) return {
                type: "del",
                raw: e[0],
                text: e[2],
                tokens: this.lexer.inlineTokens(e[2])
            };
        }
        autolink(t) {
            const e = this.rules.inline.autolink.exec(t);
            if (e) {
                let n, o;
                return e[2] === "@" ? (n = e[1], o = "mailto:" + n) : (n = e[1], o = n), {
                    type: "link",
                    raw: e[0],
                    text: n,
                    href: o,
                    tokens: [
                        {
                            type: "text",
                            raw: n,
                            text: n
                        }
                    ]
                };
            }
        }
        url(t) {
            let e;
            if (e = this.rules.inline.url.exec(t)) {
                let n, o;
                if (e[2] === "@") n = e[0], o = "mailto:" + n;
                else {
                    let s;
                    do s = e[0], e[0] = this.rules.inline._backpedal.exec(e[0])?.[0] ?? "";
                    while (s !== e[0]);
                    n = e[0], e[1] === "www." ? o = "http://" + e[0] : o = e[0];
                }
                return {
                    type: "link",
                    raw: e[0],
                    text: n,
                    href: o,
                    tokens: [
                        {
                            type: "text",
                            raw: n,
                            text: n
                        }
                    ]
                };
            }
        }
        inlineText(t) {
            const e = this.rules.inline.text.exec(t);
            if (e) {
                const n = this.lexer.state.inRawBlock;
                return {
                    type: "text",
                    raw: e[0],
                    text: e[0],
                    escaped: n
                };
            }
        }
    }, Re = class Gt {
        tokens;
        options;
        state;
        tokenizer;
        inlineQueue;
        constructor(e){
            this.tokens = [], this.tokens.links = Object.create(null), this.options = e || He, this.options.tokenizer = this.options.tokenizer || new _t, this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
                inLink: !1,
                inRawBlock: !1,
                top: !0
            };
            const n = {
                other: be,
                block: ht.normal,
                inline: Ye.normal
            };
            this.options.pedantic ? (n.block = ht.pedantic, n.inline = Ye.pedantic) : this.options.gfm && (n.block = ht.gfm, this.options.breaks ? n.inline = Ye.breaks : n.inline = Ye.gfm), this.tokenizer.rules = n;
        }
        static get rules() {
            return {
                block: ht,
                inline: Ye
            };
        }
        static lex(e, n) {
            return new Gt(n).lex(e);
        }
        static lexInline(e, n) {
            return new Gt(n).inlineTokens(e);
        }
        lex(e) {
            e = e.replace(be.carriageReturn, `
`), this.blockTokens(e, this.tokens);
            for(let n = 0; n < this.inlineQueue.length; n++){
                const o = this.inlineQueue[n];
                this.inlineTokens(o.src, o.tokens);
            }
            return this.inlineQueue = [], this.tokens;
        }
        blockTokens(e, n = [], o = !1) {
            for(this.options.pedantic && (e = e.replace(be.tabCharGlobal, "    ").replace(be.spaceLine, "")); e;){
                let s;
                if (this.options.extensions?.block?.some((a)=>(s = a.call({
                        lexer: this
                    }, e, n)) ? (e = e.substring(s.raw.length), n.push(s), !0) : !1)) continue;
                if (s = this.tokenizer.space(e)) {
                    e = e.substring(s.raw.length);
                    const a = n.at(-1);
                    s.raw.length === 1 && a !== void 0 ? a.raw += `
` : n.push(s);
                    continue;
                }
                if (s = this.tokenizer.code(e)) {
                    e = e.substring(s.raw.length);
                    const a = n.at(-1);
                    a?.type === "paragraph" || a?.type === "text" ? (a.raw += `
` + s.raw, a.text += `
` + s.text, this.inlineQueue.at(-1).src = a.text) : n.push(s);
                    continue;
                }
                if (s = this.tokenizer.fences(e)) {
                    e = e.substring(s.raw.length), n.push(s);
                    continue;
                }
                if (s = this.tokenizer.heading(e)) {
                    e = e.substring(s.raw.length), n.push(s);
                    continue;
                }
                if (s = this.tokenizer.hr(e)) {
                    e = e.substring(s.raw.length), n.push(s);
                    continue;
                }
                if (s = this.tokenizer.blockquote(e)) {
                    e = e.substring(s.raw.length), n.push(s);
                    continue;
                }
                if (s = this.tokenizer.list(e)) {
                    e = e.substring(s.raw.length), n.push(s);
                    continue;
                }
                if (s = this.tokenizer.html(e)) {
                    e = e.substring(s.raw.length), n.push(s);
                    continue;
                }
                if (s = this.tokenizer.def(e)) {
                    e = e.substring(s.raw.length);
                    const a = n.at(-1);
                    a?.type === "paragraph" || a?.type === "text" ? (a.raw += `
` + s.raw, a.text += `
` + s.raw, this.inlineQueue.at(-1).src = a.text) : this.tokens.links[s.tag] || (this.tokens.links[s.tag] = {
                        href: s.href,
                        title: s.title
                    });
                    continue;
                }
                if (s = this.tokenizer.table(e)) {
                    e = e.substring(s.raw.length), n.push(s);
                    continue;
                }
                if (s = this.tokenizer.lheading(e)) {
                    e = e.substring(s.raw.length), n.push(s);
                    continue;
                }
                let r = e;
                if (this.options.extensions?.startBlock) {
                    let a = 1 / 0;
                    const i = e.slice(1);
                    let c;
                    this.options.extensions.startBlock.forEach((l)=>{
                        c = l.call({
                            lexer: this
                        }, i), typeof c == "number" && c >= 0 && (a = Math.min(a, c));
                    }), a < 1 / 0 && a >= 0 && (r = e.substring(0, a + 1));
                }
                if (this.state.top && (s = this.tokenizer.paragraph(r))) {
                    const a = n.at(-1);
                    o && a?.type === "paragraph" ? (a.raw += `
` + s.raw, a.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = a.text) : n.push(s), o = r.length !== e.length, e = e.substring(s.raw.length);
                    continue;
                }
                if (s = this.tokenizer.text(e)) {
                    e = e.substring(s.raw.length);
                    const a = n.at(-1);
                    a?.type === "text" ? (a.raw += `
` + s.raw, a.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = a.text) : n.push(s);
                    continue;
                }
                if (e) {
                    const a = "Infinite loop on byte: " + e.charCodeAt(0);
                    if (this.options.silent) {
                        console.error(a);
                        break;
                    } else throw new Error(a);
                }
            }
            return this.state.top = !0, n;
        }
        inline(e, n = []) {
            return this.inlineQueue.push({
                src: e,
                tokens: n
            }), n;
        }
        inlineTokens(e, n = []) {
            let o = e, s = null;
            if (this.tokens.links) {
                const i = Object.keys(this.tokens.links);
                if (i.length > 0) for(; (s = this.tokenizer.rules.inline.reflinkSearch.exec(o)) != null;)i.includes(s[0].slice(s[0].lastIndexOf("[") + 1, -1)) && (o = o.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
            }
            for(; (s = this.tokenizer.rules.inline.anyPunctuation.exec(o)) != null;)o = o.slice(0, s.index) + "++" + o.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
            for(; (s = this.tokenizer.rules.inline.blockSkip.exec(o)) != null;)o = o.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
            let r = !1, a = "";
            for(; e;){
                r || (a = ""), r = !1;
                let i;
                if (this.options.extensions?.inline?.some((l)=>(i = l.call({
                        lexer: this
                    }, e, n)) ? (e = e.substring(i.raw.length), n.push(i), !0) : !1)) continue;
                if (i = this.tokenizer.escape(e)) {
                    e = e.substring(i.raw.length), n.push(i);
                    continue;
                }
                if (i = this.tokenizer.tag(e)) {
                    e = e.substring(i.raw.length), n.push(i);
                    continue;
                }
                if (i = this.tokenizer.link(e)) {
                    e = e.substring(i.raw.length), n.push(i);
                    continue;
                }
                if (i = this.tokenizer.reflink(e, this.tokens.links)) {
                    e = e.substring(i.raw.length);
                    const l = n.at(-1);
                    i.type === "text" && l?.type === "text" ? (l.raw += i.raw, l.text += i.text) : n.push(i);
                    continue;
                }
                if (i = this.tokenizer.emStrong(e, o, a)) {
                    e = e.substring(i.raw.length), n.push(i);
                    continue;
                }
                if (i = this.tokenizer.codespan(e)) {
                    e = e.substring(i.raw.length), n.push(i);
                    continue;
                }
                if (i = this.tokenizer.br(e)) {
                    e = e.substring(i.raw.length), n.push(i);
                    continue;
                }
                if (i = this.tokenizer.del(e)) {
                    e = e.substring(i.raw.length), n.push(i);
                    continue;
                }
                if (i = this.tokenizer.autolink(e)) {
                    e = e.substring(i.raw.length), n.push(i);
                    continue;
                }
                if (!this.state.inLink && (i = this.tokenizer.url(e))) {
                    e = e.substring(i.raw.length), n.push(i);
                    continue;
                }
                let c = e;
                if (this.options.extensions?.startInline) {
                    let l = 1 / 0;
                    const p = e.slice(1);
                    let u;
                    this.options.extensions.startInline.forEach((f)=>{
                        u = f.call({
                            lexer: this
                        }, p), typeof u == "number" && u >= 0 && (l = Math.min(l, u));
                    }), l < 1 / 0 && l >= 0 && (c = e.substring(0, l + 1));
                }
                if (i = this.tokenizer.inlineText(c)) {
                    e = e.substring(i.raw.length), i.raw.slice(-1) !== "_" && (a = i.raw.slice(-1)), r = !0;
                    const l = n.at(-1);
                    l?.type === "text" ? (l.raw += i.raw, l.text += i.text) : n.push(i);
                    continue;
                }
                if (e) {
                    const l = "Infinite loop on byte: " + e.charCodeAt(0);
                    if (this.options.silent) {
                        console.error(l);
                        break;
                    } else throw new Error(l);
                }
            }
            return n;
        }
    }, Ct = class {
        options;
        parser;
        constructor(t){
            this.options = t || He;
        }
        space(t) {
            return "";
        }
        code({ text: t, lang: e, escaped: n }) {
            const o = (e || "").match(be.notSpaceStart)?.[0], s = t.replace(be.endingNewline, "") + `
`;
            return o ? '<pre><code class="language-' + $e(o) + '">' + (n ? s : $e(s, !0)) + `</code></pre>
` : "<pre><code>" + (n ? s : $e(s, !0)) + `</code></pre>
`;
        }
        blockquote({ tokens: t }) {
            return `<blockquote>
${this.parser.parse(t)}</blockquote>
`;
        }
        html({ text: t }) {
            return t;
        }
        heading({ tokens: t, depth: e }) {
            return `<h${e}>${this.parser.parseInline(t)}</h${e}>
`;
        }
        hr(t) {
            return `<hr>
`;
        }
        list(t) {
            const e = t.ordered, n = t.start;
            let o = "";
            for(let a = 0; a < t.items.length; a++){
                const i = t.items[a];
                o += this.listitem(i);
            }
            const s = e ? "ol" : "ul", r = e && n !== 1 ? ' start="' + n + '"' : "";
            return "<" + s + r + `>
` + o + "</" + s + `>
`;
        }
        listitem(t) {
            let e = "";
            if (t.task) {
                const n = this.checkbox({
                    checked: !!t.checked
                });
                t.loose ? t.tokens[0]?.type === "paragraph" ? (t.tokens[0].text = n + " " + t.tokens[0].text, t.tokens[0].tokens && t.tokens[0].tokens.length > 0 && t.tokens[0].tokens[0].type === "text" && (t.tokens[0].tokens[0].text = n + " " + $e(t.tokens[0].tokens[0].text), t.tokens[0].tokens[0].escaped = !0)) : t.tokens.unshift({
                    type: "text",
                    raw: n + " ",
                    text: n + " ",
                    escaped: !0
                }) : e += n + " ";
            }
            return e += this.parser.parse(t.tokens, !!t.loose), `<li>${e}</li>
`;
        }
        checkbox({ checked: t }) {
            return "<input " + (t ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
        }
        paragraph({ tokens: t }) {
            return `<p>${this.parser.parseInline(t)}</p>
`;
        }
        table(t) {
            let e = "", n = "";
            for(let s = 0; s < t.header.length; s++)n += this.tablecell(t.header[s]);
            e += this.tablerow({
                text: n
            });
            let o = "";
            for(let s = 0; s < t.rows.length; s++){
                const r = t.rows[s];
                n = "";
                for(let a = 0; a < r.length; a++)n += this.tablecell(r[a]);
                o += this.tablerow({
                    text: n
                });
            }
            return o && (o = `<tbody>${o}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + o + `</table>
`;
        }
        tablerow({ text: t }) {
            return `<tr>
${t}</tr>
`;
        }
        tablecell(t) {
            const e = this.parser.parseInline(t.tokens), n = t.header ? "th" : "td";
            return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
        }
        strong({ tokens: t }) {
            return `<strong>${this.parser.parseInline(t)}</strong>`;
        }
        em({ tokens: t }) {
            return `<em>${this.parser.parseInline(t)}</em>`;
        }
        codespan({ text: t }) {
            return `<code>${$e(t, !0)}</code>`;
        }
        br(t) {
            return "<br>";
        }
        del({ tokens: t }) {
            return `<del>${this.parser.parseInline(t)}</del>`;
        }
        link({ href: t, title: e, tokens: n }) {
            const o = this.parser.parseInline(n), s = Hn(t);
            if (s === null) return o;
            t = s;
            let r = '<a href="' + t + '"';
            return e && (r += ' title="' + $e(e) + '"'), r += ">" + o + "</a>", r;
        }
        image({ href: t, title: e, text: n, tokens: o }) {
            o && (n = this.parser.parseInline(o, this.parser.textRenderer));
            const s = Hn(t);
            if (s === null) return $e(n);
            t = s;
            let r = `<img src="${t}" alt="${n}"`;
            return e && (r += ` title="${$e(e)}"`), r += ">", r;
        }
        text(t) {
            return "tokens" in t && t.tokens ? this.parser.parseInline(t.tokens) : "escaped" in t && t.escaped ? t.text : $e(t.text);
        }
    }, gn = class {
        strong({ text: t }) {
            return t;
        }
        em({ text: t }) {
            return t;
        }
        codespan({ text: t }) {
            return t;
        }
        del({ text: t }) {
            return t;
        }
        html({ text: t }) {
            return t;
        }
        text({ text: t }) {
            return t;
        }
        link({ text: t }) {
            return "" + t;
        }
        image({ text: t }) {
            return "" + t;
        }
        br() {
            return "";
        }
    }, Pe = class Jt {
        options;
        renderer;
        textRenderer;
        constructor(e){
            this.options = e || He, this.options.renderer = this.options.renderer || new Ct, this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new gn;
        }
        static parse(e, n) {
            return new Jt(n).parse(e);
        }
        static parseInline(e, n) {
            return new Jt(n).parseInline(e);
        }
        parse(e, n = !0) {
            let o = "";
            for(let s = 0; s < e.length; s++){
                const r = e[s];
                if (this.options.extensions?.renderers?.[r.type]) {
                    const i = r, c = this.options.extensions.renderers[i.type].call({
                        parser: this
                    }, i);
                    if (c !== !1 || ![
                        "space",
                        "hr",
                        "heading",
                        "code",
                        "table",
                        "blockquote",
                        "list",
                        "html",
                        "paragraph",
                        "text"
                    ].includes(i.type)) {
                        o += c || "";
                        continue;
                    }
                }
                const a = r;
                switch(a.type){
                    case "space":
                        {
                            o += this.renderer.space(a);
                            continue;
                        }
                    case "hr":
                        {
                            o += this.renderer.hr(a);
                            continue;
                        }
                    case "heading":
                        {
                            o += this.renderer.heading(a);
                            continue;
                        }
                    case "code":
                        {
                            o += this.renderer.code(a);
                            continue;
                        }
                    case "table":
                        {
                            o += this.renderer.table(a);
                            continue;
                        }
                    case "blockquote":
                        {
                            o += this.renderer.blockquote(a);
                            continue;
                        }
                    case "list":
                        {
                            o += this.renderer.list(a);
                            continue;
                        }
                    case "html":
                        {
                            o += this.renderer.html(a);
                            continue;
                        }
                    case "paragraph":
                        {
                            o += this.renderer.paragraph(a);
                            continue;
                        }
                    case "text":
                        {
                            let i = a, c = this.renderer.text(i);
                            for(; s + 1 < e.length && e[s + 1].type === "text";)i = e[++s], c += `
` + this.renderer.text(i);
                            n ? o += this.renderer.paragraph({
                                type: "paragraph",
                                raw: c,
                                text: c,
                                tokens: [
                                    {
                                        type: "text",
                                        raw: c,
                                        text: c,
                                        escaped: !0
                                    }
                                ]
                            }) : o += c;
                            continue;
                        }
                    default:
                        {
                            const i = 'Token with "' + a.type + '" type was not found.';
                            if (this.options.silent) return console.error(i), "";
                            throw new Error(i);
                        }
                }
            }
            return o;
        }
        parseInline(e, n = this.renderer) {
            let o = "";
            for(let s = 0; s < e.length; s++){
                const r = e[s];
                if (this.options.extensions?.renderers?.[r.type]) {
                    const i = this.options.extensions.renderers[r.type].call({
                        parser: this
                    }, r);
                    if (i !== !1 || ![
                        "escape",
                        "html",
                        "link",
                        "image",
                        "strong",
                        "em",
                        "codespan",
                        "br",
                        "del",
                        "text"
                    ].includes(r.type)) {
                        o += i || "";
                        continue;
                    }
                }
                const a = r;
                switch(a.type){
                    case "escape":
                        {
                            o += n.text(a);
                            break;
                        }
                    case "html":
                        {
                            o += n.html(a);
                            break;
                        }
                    case "link":
                        {
                            o += n.link(a);
                            break;
                        }
                    case "image":
                        {
                            o += n.image(a);
                            break;
                        }
                    case "strong":
                        {
                            o += n.strong(a);
                            break;
                        }
                    case "em":
                        {
                            o += n.em(a);
                            break;
                        }
                    case "codespan":
                        {
                            o += n.codespan(a);
                            break;
                        }
                    case "br":
                        {
                            o += n.br(a);
                            break;
                        }
                    case "del":
                        {
                            o += n.del(a);
                            break;
                        }
                    case "text":
                        {
                            o += n.text(a);
                            break;
                        }
                    default:
                        {
                            const i = 'Token with "' + a.type + '" type was not found.';
                            if (this.options.silent) return console.error(i), "";
                            throw new Error(i);
                        }
                }
            }
            return o;
        }
    }, vt = class {
        options;
        block;
        constructor(t){
            this.options = t || He;
        }
        static passThroughHooks = new Set([
            "preprocess",
            "postprocess",
            "processAllTokens"
        ]);
        preprocess(t) {
            return t;
        }
        postprocess(t) {
            return t;
        }
        processAllTokens(t) {
            return t;
        }
        provideLexer() {
            return this.block ? Re.lex : Re.lexInline;
        }
        provideParser() {
            return this.block ? Pe.parse : Pe.parseInline;
        }
    }, Yi = class {
        defaults = an();
        options = this.setOptions;
        parse = this.parseMarkdown(!0);
        parseInline = this.parseMarkdown(!1);
        Parser = Pe;
        Renderer = Ct;
        TextRenderer = gn;
        Lexer = Re;
        Tokenizer = _t;
        Hooks = vt;
        constructor(...t){
            this.use(...t);
        }
        walkTokens(t, e) {
            let n = [];
            for (const o of t)switch(n = n.concat(e.call(this, o)), o.type){
                case "table":
                    {
                        const s = o;
                        for (const r of s.header)n = n.concat(this.walkTokens(r.tokens, e));
                        for (const r of s.rows)for (const a of r)n = n.concat(this.walkTokens(a.tokens, e));
                        break;
                    }
                case "list":
                    {
                        const s = o;
                        n = n.concat(this.walkTokens(s.items, e));
                        break;
                    }
                default:
                    {
                        const s = o;
                        this.defaults.extensions?.childTokens?.[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((r)=>{
                            const a = s[r].flat(1 / 0);
                            n = n.concat(this.walkTokens(a, e));
                        }) : s.tokens && (n = n.concat(this.walkTokens(s.tokens, e)));
                    }
            }
            return n;
        }
        use(...t) {
            const e = this.defaults.extensions || {
                renderers: {},
                childTokens: {}
            };
            return t.forEach((n)=>{
                const o = {
                    ...n
                };
                if (o.async = this.defaults.async || o.async || !1, n.extensions && (n.extensions.forEach((s)=>{
                    if (!s.name) throw new Error("extension name required");
                    if ("renderer" in s) {
                        const r = e.renderers[s.name];
                        r ? e.renderers[s.name] = function(...a) {
                            let i = s.renderer.apply(this, a);
                            return i === !1 && (i = r.apply(this, a)), i;
                        } : e.renderers[s.name] = s.renderer;
                    }
                    if ("tokenizer" in s) {
                        if (!s.level || s.level !== "block" && s.level !== "inline") throw new Error("extension level must be 'block' or 'inline'");
                        const r = e[s.level];
                        r ? r.unshift(s.tokenizer) : e[s.level] = [
                            s.tokenizer
                        ], s.start && (s.level === "block" ? e.startBlock ? e.startBlock.push(s.start) : e.startBlock = [
                            s.start
                        ] : s.level === "inline" && (e.startInline ? e.startInline.push(s.start) : e.startInline = [
                            s.start
                        ]));
                    }
                    "childTokens" in s && s.childTokens && (e.childTokens[s.name] = s.childTokens);
                }), o.extensions = e), n.renderer) {
                    const s = this.defaults.renderer || new Ct(this.defaults);
                    for(const r in n.renderer){
                        if (!(r in s)) throw new Error(`renderer '${r}' does not exist`);
                        if ([
                            "options",
                            "parser"
                        ].includes(r)) continue;
                        const a = r, i = n.renderer[a], c = s[a];
                        s[a] = (...l)=>{
                            let p = i.apply(s, l);
                            return p === !1 && (p = c.apply(s, l)), p || "";
                        };
                    }
                    o.renderer = s;
                }
                if (n.tokenizer) {
                    const s = this.defaults.tokenizer || new _t(this.defaults);
                    for(const r in n.tokenizer){
                        if (!(r in s)) throw new Error(`tokenizer '${r}' does not exist`);
                        if ([
                            "options",
                            "rules",
                            "lexer"
                        ].includes(r)) continue;
                        const a = r, i = n.tokenizer[a], c = s[a];
                        s[a] = (...l)=>{
                            let p = i.apply(s, l);
                            return p === !1 && (p = c.apply(s, l)), p;
                        };
                    }
                    o.tokenizer = s;
                }
                if (n.hooks) {
                    const s = this.defaults.hooks || new vt;
                    for(const r in n.hooks){
                        if (!(r in s)) throw new Error(`hook '${r}' does not exist`);
                        if ([
                            "options",
                            "block"
                        ].includes(r)) continue;
                        const a = r, i = n.hooks[a], c = s[a];
                        vt.passThroughHooks.has(r) ? s[a] = (l)=>{
                            if (this.defaults.async) return Promise.resolve(i.call(s, l)).then((u)=>c.call(s, u));
                            const p = i.call(s, l);
                            return c.call(s, p);
                        } : s[a] = (...l)=>{
                            let p = i.apply(s, l);
                            return p === !1 && (p = c.apply(s, l)), p;
                        };
                    }
                    o.hooks = s;
                }
                if (n.walkTokens) {
                    const s = this.defaults.walkTokens, r = n.walkTokens;
                    o.walkTokens = function(a) {
                        let i = [];
                        return i.push(r.call(this, a)), s && (i = i.concat(s.call(this, a))), i;
                    };
                }
                this.defaults = {
                    ...this.defaults,
                    ...o
                };
            }), this;
        }
        setOptions(t) {
            return this.defaults = {
                ...this.defaults,
                ...t
            }, this;
        }
        lexer(t, e) {
            return Re.lex(t, e ?? this.defaults);
        }
        parser(t, e) {
            return Pe.parse(t, e ?? this.defaults);
        }
        parseMarkdown(t) {
            return (n, o)=>{
                const s = {
                    ...o
                }, r = {
                    ...this.defaults,
                    ...s
                }, a = this.onError(!!r.silent, !!r.async);
                if (this.defaults.async === !0 && s.async === !1) return a(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
                if (typeof n > "u" || n === null) return a(new Error("marked(): input parameter is undefined or null"));
                if (typeof n != "string") return a(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
                r.hooks && (r.hooks.options = r, r.hooks.block = t);
                const i = r.hooks ? r.hooks.provideLexer() : t ? Re.lex : Re.lexInline, c = r.hooks ? r.hooks.provideParser() : t ? Pe.parse : Pe.parseInline;
                if (r.async) return Promise.resolve(r.hooks ? r.hooks.preprocess(n) : n).then((l)=>i(l, r)).then((l)=>r.hooks ? r.hooks.processAllTokens(l) : l).then((l)=>r.walkTokens ? Promise.all(this.walkTokens(l, r.walkTokens)).then(()=>l) : l).then((l)=>c(l, r)).then((l)=>r.hooks ? r.hooks.postprocess(l) : l).catch(a);
                try {
                    r.hooks && (n = r.hooks.preprocess(n));
                    let l = i(n, r);
                    r.hooks && (l = r.hooks.processAllTokens(l)), r.walkTokens && this.walkTokens(l, r.walkTokens);
                    let p = c(l, r);
                    return r.hooks && (p = r.hooks.postprocess(p)), p;
                } catch (l) {
                    return a(l);
                }
            };
        }
        onError(t, e) {
            return (n)=>{
                if (n.message += `
Please report this to https://github.com/markedjs/marked.`, t) {
                    const o = "<p>An error occurred:</p><pre>" + $e(n.message + "", !0) + "</pre>";
                    return e ? Promise.resolve(o) : o;
                }
                if (e) return Promise.reject(n);
                throw n;
            };
        }
    }, Fe = new Yi;
    te = function(t, e) {
        return Fe.parse(t, e);
    };
    te.options = te.setOptions = function(t) {
        return Fe.setOptions(t), te.defaults = Fe.defaults, Oo(te.defaults), te;
    };
    te.getDefaults = an;
    te.defaults = He;
    te.use = function(...t) {
        return Fe.use(...t), te.defaults = Fe.defaults, Oo(te.defaults), te;
    };
    te.walkTokens = function(t, e) {
        return Fe.walkTokens(t, e);
    };
    te.parseInline = Fe.parseInline;
    te.Parser = Pe;
    te.parser = Pe.parse;
    te.Renderer = Ct;
    te.TextRenderer = gn;
    te.Lexer = Re;
    te.lexer = Re.lex;
    te.Tokenizer = _t;
    te.Hooks = vt;
    te.parse = te;
    te.options;
    te.setOptions;
    te.use;
    te.walkTokens;
    te.parseInline;
    Pe.parse;
    Re.lex;
    var Xe = {}, Zn;
    function Qi() {
        if (Zn) return Xe;
        Zn = 1, Object.defineProperty(Xe, "__esModule", {
            value: !0
        }), Xe.parse = a, Xe.serialize = l;
        const t = /^[\u0021-\u003A\u003C\u003E-\u007E]+$/, e = /^[\u0021-\u003A\u003C-\u007E]*$/, n = /^([.]?[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)([.][a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/i, o = /^[\u0020-\u003A\u003D-\u007E]*$/, s = Object.prototype.toString, r = (()=>{
            const f = function() {};
            return f.prototype = Object.create(null), f;
        })();
        function a(f, v) {
            const g = new r, C = f.length;
            if (C < 2) return g;
            const _ = v?.decode || p;
            let h = 0;
            do {
                const T = f.indexOf("=", h);
                if (T === -1) break;
                const O = f.indexOf(";", h), b = O === -1 ? C : O;
                if (T > b) {
                    h = f.lastIndexOf(";", T - 1) + 1;
                    continue;
                }
                const B = i(f, h, T), $ = c(f, T, B), k = f.slice(B, $);
                if (g[k] === void 0) {
                    let w = i(f, T + 1, b), V = c(f, b, w);
                    const D = _(f.slice(w, V));
                    g[k] = D;
                }
                h = b + 1;
            }while (h < C);
            return g;
        }
        function i(f, v, g) {
            do {
                const C = f.charCodeAt(v);
                if (C !== 32 && C !== 9) return v;
            }while (++v < g);
            return g;
        }
        function c(f, v, g) {
            for(; v > g;){
                const C = f.charCodeAt(--v);
                if (C !== 32 && C !== 9) return v + 1;
            }
            return g;
        }
        function l(f, v, g) {
            const C = g?.encode || encodeURIComponent;
            if (!t.test(f)) throw new TypeError(`argument name is invalid: ${f}`);
            const _ = C(v);
            if (!e.test(_)) throw new TypeError(`argument val is invalid: ${v}`);
            let h = f + "=" + _;
            if (!g) return h;
            if (g.maxAge !== void 0) {
                if (!Number.isInteger(g.maxAge)) throw new TypeError(`option maxAge is invalid: ${g.maxAge}`);
                h += "; Max-Age=" + g.maxAge;
            }
            if (g.domain) {
                if (!n.test(g.domain)) throw new TypeError(`option domain is invalid: ${g.domain}`);
                h += "; Domain=" + g.domain;
            }
            if (g.path) {
                if (!o.test(g.path)) throw new TypeError(`option path is invalid: ${g.path}`);
                h += "; Path=" + g.path;
            }
            if (g.expires) {
                if (!u(g.expires) || !Number.isFinite(g.expires.valueOf())) throw new TypeError(`option expires is invalid: ${g.expires}`);
                h += "; Expires=" + g.expires.toUTCString();
            }
            if (g.httpOnly && (h += "; HttpOnly"), g.secure && (h += "; Secure"), g.partitioned && (h += "; Partitioned"), g.priority) switch(typeof g.priority == "string" ? g.priority.toLowerCase() : void 0){
                case "low":
                    h += "; Priority=Low";
                    break;
                case "medium":
                    h += "; Priority=Medium";
                    break;
                case "high":
                    h += "; Priority=High";
                    break;
                default:
                    throw new TypeError(`option priority is invalid: ${g.priority}`);
            }
            if (g.sameSite) switch(typeof g.sameSite == "string" ? g.sameSite.toLowerCase() : g.sameSite){
                case !0:
                case "strict":
                    h += "; SameSite=Strict";
                    break;
                case "lax":
                    h += "; SameSite=Lax";
                    break;
                case "none":
                    h += "; SameSite=None";
                    break;
                default:
                    throw new TypeError(`option sameSite is invalid: ${g.sameSite}`);
            }
            return h;
        }
        function p(f) {
            if (f.indexOf("%") === -1) return f;
            try {
                return decodeURIComponent(f);
            } catch  {
                return f;
            }
        }
        function u(f) {
            return s.call(f) === "[object Date]";
        }
        return Xe;
    }
    Xi = Qi();
    const el = "array", tl = "bit", Gn = "bits", nl = "byte", Jn = "bytes", We = "", ol = "exponent", sl = "function", Kn = "iec", rl = "Invalid number", al = "Invalid rounding method", Lt = "jedec", il = "object", Yn = ".", ll = "round", cl = "s", ul = "si", dl = "kbit", pl = "kB", fl = " ", hl = "string", gl = "0", Vt = {
        symbol: {
            iec: {
                bits: [
                    "bit",
                    "Kibit",
                    "Mibit",
                    "Gibit",
                    "Tibit",
                    "Pibit",
                    "Eibit",
                    "Zibit",
                    "Yibit"
                ],
                bytes: [
                    "B",
                    "KiB",
                    "MiB",
                    "GiB",
                    "TiB",
                    "PiB",
                    "EiB",
                    "ZiB",
                    "YiB"
                ]
            },
            jedec: {
                bits: [
                    "bit",
                    "Kbit",
                    "Mbit",
                    "Gbit",
                    "Tbit",
                    "Pbit",
                    "Ebit",
                    "Zbit",
                    "Ybit"
                ],
                bytes: [
                    "B",
                    "KB",
                    "MB",
                    "GB",
                    "TB",
                    "PB",
                    "EB",
                    "ZB",
                    "YB"
                ]
            }
        },
        fullform: {
            iec: [
                "",
                "kibi",
                "mebi",
                "gibi",
                "tebi",
                "pebi",
                "exbi",
                "zebi",
                "yobi"
            ],
            jedec: [
                "",
                "kilo",
                "mega",
                "giga",
                "tera",
                "peta",
                "exa",
                "zetta",
                "yotta"
            ]
        }
    };
    function ml(t, { bits: e = !1, pad: n = !1, base: o = -1, round: s = 2, locale: r = We, localeOptions: a = {}, separator: i = We, spacer: c = fl, symbols: l = {}, standard: p = We, output: u = hl, fullform: f = !1, fullforms: v = [], exponent: g = -1, roundingMethod: C = ll, precision: _ = 0 } = {}) {
        let h = g, T = Number(t), O = [], b = 0, B = We;
        p === ul ? (o = 10, p = Lt) : p === Kn || p === Lt ? o = 2 : o === 2 ? p = Kn : (o = 10, p = Lt);
        const $ = o === 10 ? 1e3 : 1024, k = f === !0, w = T < 0, V = Math[C];
        if (typeof t != "bigint" && isNaN(t)) throw new TypeError(rl);
        if (typeof V !== sl) throw new TypeError(al);
        if (w && (T = -T), (h === -1 || isNaN(h)) && (h = Math.floor(Math.log(T) / Math.log($)), h < 0 && (h = 0)), h > 8 && (_ > 0 && (_ += 8 - h), h = 8), u === ol) return h;
        if (T === 0) O[0] = 0, B = O[1] = Vt.symbol[p][e ? Gn : Jn][h];
        else {
            b = T / (o === 2 ? Math.pow(2, h * 10) : Math.pow(1e3, h)), e && (b = b * 8, b >= $ && h < 8 && (b = b / $, h++));
            const D = Math.pow(10, h > 0 ? s : 0);
            O[0] = V(b * D) / D, O[0] === $ && h < 8 && g === -1 && (O[0] = 1, h++), B = O[1] = o === 10 && h === 1 ? e ? dl : pl : Vt.symbol[p][e ? Gn : Jn][h];
        }
        if (w && (O[0] = -O[0]), _ > 0 && (O[0] = O[0].toPrecision(_)), O[1] = l[O[1]] || O[1], r === !0 ? O[0] = O[0].toLocaleString() : r.length > 0 ? O[0] = O[0].toLocaleString(r, a) : i.length > 0 && (O[0] = O[0].toString().replace(Yn, i)), n && s > 0) {
            const D = O[0].toString(), Q = i || (D.match(/(\D)/g) || []).pop() || Yn, q = D.toString().split(Q), I = q[1] || We, j = I.length, F = s - j;
            O[0] = `${q[0]}${Q}${I.padEnd(j + F, gl)}`;
        }
        return k && (O[1] = v[h] ? v[h] : Vt.fullform[p][h] + (e ? tl : nl) + (O[0] === 1 ? We : cl)), u === el ? O : u === il ? {
            value: O[0],
            symbol: O[1],
            exponent: h,
            unit: B
        } : O.join(c);
    }
    let vl, yl, bl, kl, wl, xl, _l, Cl, Sl, $l, Tl, El, Ol, Rl, Al, Il, Bl, Nl, jl, Ml, Ll, Vl, zl, Dl, Ul, Hl;
    vl = {
        class: "file-container pre"
    };
    yl = {
        class: "file-container-header"
    };
    bl = {
        class: "header-path"
    };
    kl = [
        "value"
    ];
    wl = [
        "id"
    ];
    xl = {
        key: 0
    };
    _l = {
        key: 1,
        style: {
            display: "flex",
            "justify-content": "center"
        }
    };
    Cl = {
        key: 0
    };
    Sl = {
        key: 1,
        style: {
            display: "flex",
            "justify-content": "center"
        }
    };
    $l = {
        class: "p-text-secondary preview-dialog-text"
    };
    Tl = {
        class: "preview-dialog-button-container"
    };
    El = 10 * 1e6;
    Hc = oe({
        __name: "FilePanel",
        props: {
            disabledColumns: {},
            hideUploads: {
                type: Boolean
            }
        },
        emits: [
            "open-file",
            "preview-file"
        ],
        setup (t, { expose: e, emit: n }) {
            const o = (P, d)=>{
                r("preview-file", `/files/${P}`, d);
            }, s = R("."), r = n, a = new mo.ContentsManager({}), c = Xi.parse(document.cookie)._xsrf, l = de("show_toast"), p = R(void 0), u = R(void 0), f = R(void 0), v = R(!1), g = R(), C = R(), _ = R(), h = (P)=>P !== null ? Ps.Time.formatHuman(P) : "-", T = (P)=>P !== null ? ml(P, {
                    spacer: ""
                }) : "-", O = ()=>{
                p.value?.click();
            }, b = G(()=>`/${s.value === "." ? "" : s.value}`), B = (P)=>{
                const d = [];
                return P.type === "file" ? d.push("pi", "pi-file") : P.type === "directory" ? d.push("pi", "pi-folder") : P.type === "notebook" && d.push("notebook-icon"), d;
            }, $ = ({ data: P })=>{
                P.type === "directory" ? (s.value = P.path, j()) : P.type === "notebook" ? window.confirm(`Open notebook ${P.name}?

Opening this file will replace your current notebook and reset the session. Proceed?`) && w(P).then((d)=>{
                    r("open-file", d, P.path);
                }) : P.size >= El ? (_.value = `approximately ${Math.floor(P.size / 1e6)} MB`, k(()=>o(P.path, P.mimetype))) : o(P.path, P.mimetype);
            }, k = (P)=>{
                C.value = !0, g.value = P;
            }, w = async (P)=>{
                v.value = !0;
                try {
                    const d = await a.get(P.path);
                    return v.value = !1, d.content;
                } catch  {
                    v.value = !1, l({
                        title: "Invalid File",
                        detail: "Unable to load. Please check file contains valid ipynb json data.",
                        severity: "error",
                        life: 1e4
                    });
                }
            }, V = (P)=>{
                [
                    ...P.dataTransfer.items
                ].filter((m)=>m.kind === "file").length > 0 && P.preventDefault();
            }, D = async (P)=>{
                P.preventDefault(), await q(P.dataTransfer.files);
            }, Q = async ()=>{
                const P = u.value.uploadfiles?.files;
                await q(P);
            }, q = async (P)=>{
                const d = [], m = Array.from(P).map(async (E)=>{
                    const L = `${s.value}/${E.name}`, M = [], X = E.stream().getReader();
                    let ne = (await X.read()).value;
                    for(; ne?.length > 0;)M.push(Array.from(ne, (me)=>String.fromCharCode(me)).join("")), ne = (await X.read()).value;
                    const ue = E.type !== "" ? E.type : "application/octet-stream", he = btoa(M.join("")), ae = {
                        type: ue,
                        format: "base64",
                        content: he
                    };
                    let se;
                    try {
                        se = await a.save(L, ae);
                    } catch (me) {
                        l({
                            title: "Upload failed",
                            detail: `Unable to upload file "${L}": ${me}`,
                            severity: "error",
                            life: 8e3
                        });
                        return;
                    }
                    se && se.created && se.size ? l({
                        title: "Upload complete",
                        detail: `File "${se.path}" (${se.size} bytes) successfully uploaded.`,
                        severity: "success",
                        life: 4e3
                    }) : l({
                        title: "Upload failed",
                        detail: `Unable to upload file "${L}".`,
                        severity: "error",
                        life: 8e3
                    });
                });
                return await Promise.all(m), await j(), d;
            }, I = async (P)=>{
                let d = await a.getDownloadUrl(P.path);
                /download=/.test(d) || (/\?/.test(d) ? d = d + "&download=1" : d = d + "?download=1"), window.location.href = d;
            }, j = async ()=>{
                v.value = !0;
                const d = (await a.get(s.value)).content;
                if (d.sort((m, E)=>m.type === "directory" && E.type !== "directory" ? -1 : E.type === "directory" && m.type !== "directory" ? 1 : m.name.localeCompare(E.name)), s.value !== ".") {
                    const m = a.normalize(`${s.value}/..`);
                    d.splice(0, 0, {
                        name: "..",
                        path: m,
                        last_modified: null,
                        created: null,
                        content: null,
                        format: null,
                        mimetype: null,
                        size: null,
                        writable: !0,
                        hash: null,
                        hash_algorithm: null,
                        type: "directory"
                    });
                }
                f.value = d, v.value = !1;
            }, F = async (P)=>{
                const d = document.getElementById(`file-list::${P}`);
                if (!d) return;
                const m = d.closest("tr");
                m && (Co(m, {
                    behavior: "smooth"
                }), m.classList.add("flash"), m.addEventListener("animationend", ()=>m.classList.remove("flash"), {
                    once: !0
                }), m.style.backgroundColor = "rgba(255, 0, 0, 0)");
            };
            return Ne(async ()=>{
                await j();
            }), e({
                refresh: j,
                flashFile: F,
                directory: s
            }), (P, d)=>{
                const m = Ue("tooltip");
                return x(), N(le, null, [
                    y("div", vl, [
                        y("div", yl, [
                            y("span", null, [
                                d[3] || (d[3] = Te("Contents of: ", -1)),
                                y("span", bl, K(b.value), 1)
                            ]),
                            d[4] || (d[4] = y("span", {
                                style: {
                                    flex: "1"
                                }
                            }, null, -1)),
                            re(A(S(J), {
                                onClick: O,
                                icon: "pi pi-cloud-upload",
                                size: "small"
                            }, null, 512), [
                                [
                                    m,
                                    {
                                        value: "Files to upload",
                                        showDelay: 300
                                    },
                                    void 0,
                                    {
                                        bottom: !0
                                    }
                                ],
                                [
                                    Ft,
                                    !P.hideUploads
                                ]
                            ]),
                            y("form", {
                                ref_key: "uploadForm",
                                ref: u
                            }, [
                                y("input", {
                                    onChange: Q,
                                    ref_key: "fileInput",
                                    ref: p,
                                    type: "file",
                                    multiple: "",
                                    style: {
                                        display: "none"
                                    },
                                    name: "uploadfiles"
                                }, null, 544),
                                y("input", {
                                    type: "hidden",
                                    name: "_xsrf",
                                    value: S(c)
                                }, null, 8, kl)
                            ], 512),
                            re(A(S(J), {
                                onClick: j,
                                icon: "pi pi-refresh",
                                size: "small"
                            }, null, 512), [
                                [
                                    m,
                                    {
                                        value: "Refresh files ",
                                        showDelay: 300
                                    },
                                    void 0,
                                    {
                                        bottom: !0
                                    }
                                ]
                            ])
                        ]),
                        A(S(kt), {
                            value: f.value,
                            size: "small",
                            stripedRows: "",
                            class: "file-table",
                            removableSort: "",
                            onRowDblclick: $,
                            resizableColumns: "",
                            columnResizeMode: "fit",
                            rowHover: "",
                            loading: v.value,
                            onDragover: V,
                            onDrop: D
                        }, {
                            default: H(()=>[
                                    P.disabledColumns?.includes("downloads") ? W("", !0) : (x(), Z(S(Oe), {
                                        key: 0,
                                        header: "",
                                        class: "download-column"
                                    }, {
                                        header: H(()=>[
                                                ...d[5] || (d[5] = [
                                                    y("span", {
                                                        class: "pi pi-cloud-download",
                                                        style: {
                                                            "font-weight": "lighter"
                                                        }
                                                    }, null, -1)
                                                ])
                                            ]),
                                        body: H((E)=>[
                                                E.data.type === "file" || E.data.type === "notebook" ? re((x(), Z(S(J), {
                                                    key: 0,
                                                    icon: "pi pi-cloud-download",
                                                    class: "download-button",
                                                    onClick: (L)=>I(E.data)
                                                }, null, 8, [
                                                    "onClick"
                                                ])), [
                                                    [
                                                        m,
                                                        {
                                                            value: "Download",
                                                            showDelay: 0,
                                                            hideDelay: 0
                                                        },
                                                        void 0,
                                                        {
                                                            left: !0
                                                        }
                                                    ]
                                                ]) : W("", !0)
                                            ]),
                                        _: 1
                                    })),
                                    P.disabledColumns?.includes("filename") ? W("", !0) : (x(), Z(S(Oe), {
                                        key: 1,
                                        field: "name",
                                        header: "Name",
                                        class: "filename-column",
                                        sortable: ""
                                    }, {
                                        body: H((E)=>[
                                                y("span", {
                                                    class: ie([
                                                        ...B(E.data),
                                                        "file-icon",
                                                        E.data.type
                                                    ])
                                                }, null, 2),
                                                y("span", {
                                                    id: `file-list::${E.data.path}`,
                                                    class: ie([
                                                        "file-name monospace",
                                                        E.data.type
                                                    ])
                                                }, K(E.data.name), 11, wl)
                                            ]),
                                        _: 1
                                    })),
                                    P.disabledColumns?.includes("timestamp") ? W("", !0) : (x(), Z(S(Oe), {
                                        key: 2,
                                        field: "last_modified",
                                        header: "Last Modified",
                                        sortable: "",
                                        style: {
                                            "max-width": "25%"
                                        }
                                    }, {
                                        body: H((E)=>[
                                                E.data.last_modified ? re((x(), N("span", xl, [
                                                    Te(K(h(E.data.last_modified)), 1)
                                                ])), [
                                                    [
                                                        m,
                                                        E.data.last_modified
                                                    ]
                                                ]) : (x(), N("span", _l, " - "))
                                            ]),
                                        _: 1
                                    })),
                                    P.disabledColumns?.includes("filesize") ? W("", !0) : (x(), Z(S(Oe), {
                                        key: 3,
                                        field: "size",
                                        header: "Size",
                                        sortable: "",
                                        style: {
                                            "max-width": "25%"
                                        }
                                    }, {
                                        body: H((E)=>[
                                                E.data.size ? re((x(), N("span", Cl, [
                                                    Te(K(T(E.data.size)), 1)
                                                ])), [
                                                    [
                                                        m,
                                                        `${E.data.size} bytes`
                                                    ]
                                                ]) : (x(), N("span", Sl, " - "))
                                            ]),
                                        _: 1
                                    }))
                                ]),
                            _: 1
                        }, 8, [
                            "value",
                            "loading"
                        ])
                    ]),
                    A(S(on), {
                        modal: "",
                        visible: C.value,
                        "onUpdate:visible": d[2] || (d[2] = (E)=>C.value = E),
                        header: "Large File Preview",
                        style: {
                            width: "30em"
                        }
                    }, {
                        default: H(()=>[
                                y("span", $l, [
                                    d[6] || (d[6] = Te(" You are attempting to open a file that is ", -1)),
                                    y("b", null, K(_.value) + ".", 1)
                                ]),
                                d[7] || (d[7] = y("span", {
                                    class: "p-text-secondary preview-dialog-text"
                                }, " This requires downloading the file over the network. ", -1)),
                                y("div", Tl, [
                                    A(S(J), {
                                        type: "button",
                                        label: "Cancel",
                                        outlined: "",
                                        onClick: d[0] || (d[0] = ()=>{
                                            C.value = !1, g.value = ()=>{};
                                        })
                                    }),
                                    A(S(J), {
                                        type: "button",
                                        label: "Preview",
                                        onClick: d[1] || (d[1] = ()=>{
                                            C.value = !1, g.value(), g.value = ()=>{};
                                        })
                                    })
                                ])
                            ]),
                        _: 1
                    }, 8, [
                        "visible"
                    ])
                ], 64);
            };
        }
    });
    Ol = {
        class: "side-panel-title"
    };
    Rl = {
        class: "side-panel-content"
    };
    Pl = oe({
        __name: "SideMenuPanel",
        props: {
            id: {},
            icon: {},
            label: {},
            noOverflow: {
                type: Boolean,
                default: void 0
            },
            lazy: {
                type: Boolean,
                default: !1
            },
            selected: {
                type: Boolean,
                default: !1
            },
            position: {
                default: "top"
            }
        },
        setup (t) {
            const e = R([]), n = t, o = R(!n.lazy);
            return n.noOverflow !== void 0 && e.value.push("no-overflow"), ge(n, (s)=>{
                s.selected && !o.value && (o.value = !0);
            }), (s, r)=>!s.lazy || s.lazy && o.value ? (x(), N("div", {
                    key: 0,
                    class: ie([
                        "side-panel",
                        e.value
                    ])
                }, [
                    y("div", Ol, K(n.label), 1),
                    y("div", Rl, [
                        xe(s.$slots, "default")
                    ])
                ], 2)) : W("", !0);
        }
    });
    Al = [
        "position"
    ];
    Il = {
        role: "menu",
        class: "sidemenu-panel-container"
    };
    Bl = {
        key: 0,
        class: "sidemenu-gutter-handle"
    };
    Nl = 50;
    jl = 8;
    Wc = oe({
        __name: "SideMenu",
        props: {
            style: {
                default: ()=>({})
            },
            expanded: {
                type: Boolean,
                default: !0
            },
            position: {
                default: "right"
            },
            highlight: {
                default: "full"
            },
            showLabel: {
                type: Boolean,
                default: !1
            },
            showTooltip: {
                type: Boolean,
                default: !0
            },
            staticSize: {
                type: Boolean,
                default: !1
            },
            initialWidth: {
                default: "100%"
            },
            resizable: {
                type: Boolean,
                default: !0
            },
            maximized: {
                type: Boolean,
                default: !1
            }
        },
        emits: [
            "panel-hide",
            "panel-show",
            "resize"
        ],
        setup (t, { expose: e, emit: n }) {
            const o = t, s = n, r = fs(), a = R(o.expanded ? 0 : null), i = R(null), c = R({
                move: null,
                end: null
            }), l = R(null), p = R(null), u = R(null), f = R(null), v = R(null), g = R(null), C = R(!1), _ = R(), h = R(), T = uo();
            let O, b, B;
            const $ = G(()=>a.value !== null), k = G(()=>r.default().filter((m)=>hs(m) && m.type === Pl)), w = G(()=>{
                const d = {
                    top: [],
                    middle: [],
                    bottom: []
                };
                return k.value?.forEach((m, E)=>{
                    const L = m.props.position || "top";
                    d[L].push({
                        panel: m,
                        idx: E
                    });
                }), d;
            }), V = G(()=>{
                if ($.value) {
                    let d;
                    if (i.value !== null) d = `${i.value}px`;
                    else if (o.maximized) d = o.initialWidth;
                    else {
                        const m = T?.vnode?.el?.clientWidth;
                        m ? d = `${m}px` : d = o.initialWidth;
                    }
                    return {
                        ...o.style,
                        width: d
                    };
                } else return {
                    ...o.style
                };
            });
            ge($, ()=>{
                Be(()=>{
                    const d = T.vnode.el.offsetParent, m = d.scrollWidth - d.offsetWidth;
                    m > 0 && (i.value -= m);
                });
            });
            const D = G(()=>({
                    position: {
                        left: "right",
                        right: "left"
                    }[o.position]
                })), Q = (d)=>{
                if (c.value.move !== null) {
                    try {
                        document.removeEventListener("mousemove", c.value.move);
                    } catch  {}
                    c.value.move = null;
                }
                if (c.value.end !== null) {
                    try {
                        document.removeEventListener("mouseup", c.value.end);
                    } catch  {}
                    c.value.end = null;
                }
                c.value.move = document.addEventListener("mousemove", q), c.value.end = document.addEventListener("mouseup", I), l.value = d.x, p.value = i.value || f.value.clientWidth, b = v.value.clientWidth, B = b + jl, O = b + Nl;
            }, q = (d)=>{
                let m, E = !0;
                u.value = d.x - l.value, o.position === "left" ? m = p.value + u.value : m = p.value - u.value, m <= O ? (E = !1, i.value != B && (E = !0, m = B, C.value = !0)) : C.value = !1, E && (i.value = m), Be(()=>{
                    const L = T.vnode.el.offsetParent, M = L.scrollWidth - L.offsetWidth;
                    M > 0 && (i.value -= M);
                });
            }, I = (d)=>{
                document.removeEventListener("mousemove", q), document.removeEventListener("mouseup", I), i.value = Math.round(i.value), i.value <= O && (a.value = null, i.value = null), l.value = null, u.value = null, C.value = !1;
            }, j = (d)=>{
                a.value !== d ? (a.value = d, s("panel-show")) : (a.value = null, s("panel-hide"));
            }, F = ()=>{
                a.value = null;
            }, P = (d)=>{
                a.value = k.value.findIndex((m)=>m.props?.label === d || m.props?.id === d), C.value && (C.value = !1);
            };
            return Ne(()=>{
                const d = document.body;
                _.value = new ResizeObserver((E)=>{
                    for (const L of E)if (!h.value) h.value = L.contentRect;
                    else if (L.contentRect !== h.value) {
                        if (i.value) {
                            const M = L.contentRect.width / h.value.width;
                            i.value = i.value * M;
                        }
                        h.value = L.contentRect;
                    }
                }), _.value.observe(d);
                const m = T?.vnode?.el?.clientWidth;
                m && (i.value = m);
            }), fo(()=>{
                _.value.disconnect(), _.value = null;
            }), e({
                selectPanel: P,
                getSelectedPanelInfo: ()=>{
                    if (a.value === null) return null;
                    const d = k.value[a.value];
                    return {
                        index: a.value,
                        label: d?.props?.label,
                        id: d?.props?.id
                    };
                },
                hidePanel: F
            }), (d, m)=>{
                const E = Ue("tooltip");
                return x(), N("div", {
                    class: ie([
                        "sidemenu-container",
                        [
                            d.position
                        ]
                    ])
                }, [
                    y("div", {
                        class: ie([
                            "sidemenu",
                            [
                                d.position,
                                C.value ? "minimize" : void 0
                            ]
                        ]),
                        style: tn(V.value),
                        ref_key: "panelRef",
                        ref: f
                    }, [
                        y("div", {
                            class: ie([
                                "sidemenu-menu-selection",
                                [
                                    d.position
                                ]
                            ]),
                            ref_key: "menuRef",
                            ref: v
                        }, [
                            (x(), N(le, null, we([
                                "top",
                                "middle",
                                "bottom"
                            ], (L)=>y("div", {
                                    key: L,
                                    position: L,
                                    class: ie([
                                        "button-panel",
                                        `${L}-buttons`
                                    ])
                                }, [
                                    (x(!0), N(le, null, we(w.value[L], ({ panel: M, idx: X })=>re((x(), Z(S(J), {
                                            key: `button-${L}-${X}`,
                                            class: ie([
                                                "menu-button",
                                                o.highlight,
                                                o.position,
                                                a.value === X ? "selected" : void 0,
                                                o.showLabel ? "show-label" : void 0
                                            ]),
                                            icon: M.props?.icon,
                                            label: o.showLabel ? M.props.label : void 0,
                                            "icon-pos": "top",
                                            onClick: (ne)=>j(X),
                                            text: ""
                                        }, null, 8, [
                                            "class",
                                            "icon",
                                            "label",
                                            "onClick"
                                        ])), [
                                            [
                                                E,
                                                o.showTooltip ? M.props.label : void 0,
                                                D.value
                                            ]
                                        ])), 128))
                                ], 10, Al)), 64))
                        ], 2),
                        re(y("div", Il, [
                            (x(!0), N(le, null, we(k.value, (L, M)=>re((x(), Z(en(L), {
                                    key: `panel-${M}`,
                                    selected: a.value === M
                                }, null, 8, [
                                    "selected"
                                ])), [
                                    [
                                        Ft,
                                        a.value === M
                                    ]
                                ])), 128))
                        ], 512), [
                            [
                                Ft,
                                $.value
                            ]
                        ]),
                        $.value && !d.staticSize ? (x(), N("div", {
                            key: 0,
                            class: "sidemenu-gutter",
                            onMousedown: ho(Q, [
                                "prevent"
                            ]),
                            ref_key: "gutterRef",
                            ref: g
                        }, [
                            d.staticSize ? W("", !0) : (x(), N("div", Bl))
                        ], 544)) : W("", !0)
                    ], 6)
                ], 2);
            };
        }
    });
    Ml = {
        class: "image-zoom-container"
    };
    Ll = [
        "src",
        "alt"
    ];
    Vl = {
        class: "image-zoom-controls"
    };
    zl = {
        class: "zoom-level"
    };
    Dl = oe({
        __name: "ImageZoomDialog",
        emits: [
            "close"
        ],
        setup (t, { emit: e }) {
            const n = de("dialogRef"), o = R({
                imageSrc: null,
                imageAlt: "Zoomed image",
                ...n.value.data
            });
            Ne(()=>{
                v();
            }), R(!1);
            const s = R(1), r = R(1), a = R(0), i = R(0), c = R(!1), l = R(0), p = R(0), u = R(), f = R(), v = ()=>{
                if (!f.value || !u.value) return;
                const $ = f.value, k = u.value, w = $.naturalWidth, V = $.naturalHeight, D = k.clientWidth, Q = k.clientHeight, q = D / w, I = Q / V, j = Math.min(q, I, 1);
                r.value = j, s.value = j;
            }, g = ()=>{
                n.value?.close();
            }, C = ()=>{
                s.value < 4 && (s.value = Math.min(s.value * 1.25, 4));
            }, _ = ()=>{
                const $ = Math.min(.25, r.value);
                s.value > $ && (s.value = Math.max(s.value * .8, $));
            }, h = ()=>{
                s.value = r.value, a.value = 0, i.value = 0;
            }, T = ($)=>{
                const k = $.deltaY > 0 ? .9 : 1.1, w = Math.max(.25, Math.min(4, s.value * k));
                s.value = w;
            }, O = ($)=>{
                c.value = !0, l.value = $.clientX, p.value = $.clientY, $.preventDefault();
            }, b = ($)=>{
                if (c.value) {
                    const k = $.clientX - l.value, w = $.clientY - p.value;
                    a.value += k / s.value, i.value += w / s.value, l.value = $.clientX, p.value = $.clientY;
                }
            }, B = ()=>{
                c.value = !1;
            };
            return ($, k)=>(x(), N(le, null, [
                    A(S(J), {
                        icon: "pi pi-times",
                        class: "image-zoom-close",
                        onClick: g,
                        "aria-label": "Close zoom",
                        severity: "secondary"
                    }),
                    y("div", Ml, [
                        y("div", {
                            class: "image-zoom-content",
                            ref_key: "imageContainer",
                            ref: u,
                            onWheel: ho(T, [
                                "prevent"
                            ]),
                            onMousedown: O,
                            onMousemove: b,
                            onMouseup: B,
                            onMouseleave: B
                        }, [
                            y("img", {
                                ref_key: "zoomedImage",
                                ref: f,
                                src: o.value.imageSrc,
                                alt: o.value.imageAlt,
                                style: tn({
                                    transform: `scale(${s.value}) translate(${a.value}px, ${i.value}px)`,
                                    cursor: c.value ? "grabbing" : "grab"
                                })
                            }, null, 12, Ll)
                        ], 544),
                        y("div", Vl, [
                            A(S(J), {
                                icon: "pi pi-minus",
                                class: "zoom-btn zoom-out",
                                onClick: _,
                                disabled: s.value <= .25,
                                "aria-label": "Zoom out",
                                severity: "secondary"
                            }, null, 8, [
                                "disabled"
                            ]),
                            y("span", zl, K(Math.round(s.value * 100)) + "%", 1),
                            A(S(J), {
                                icon: "pi pi-plus",
                                class: "zoom-btn zoom-in",
                                onClick: C,
                                disabled: s.value >= 4,
                                "aria-label": "Zoom in",
                                severity: "secondary"
                            }, null, 8, [
                                "disabled"
                            ]),
                            A(S(J), {
                                class: "zoom-btn zoom-reset",
                                onClick: h,
                                "aria-label": "Reset zoom",
                                severity: "secondary",
                                label: "Reset"
                            })
                        ])
                    ])
                ], 64));
        }
    });
    Fl = Tt(Dl, [
        [
            "__scopeId",
            "data-v-3f6dde54"
        ]
    ]);
    Ul = {
        key: 0,
        class: "mime-select-container"
    };
    Hl = {
        class: "mime-payload"
    };
    qc = oe({
        __name: "BeakerMimeBundle",
        props: [
            "mimeBundle",
            "collapse"
        ],
        setup (t) {
            const e = t, n = de("session"), o = Xt(), s = R(), r = G(()=>n.renderer.renderMimeBundle(e.mimeBundle)), a = G(()=>n.renderer.rankedMimetypesInBundle(e.mimeBundle).filter((l)=>!!r.value[l])), i = R(a.value[0]);
            ge(a, (l, p)=>{
                i.value = l[0];
            });
            const c = (l)=>{
                const p = l.target;
                if (p.tagName.toLowerCase() === "img") {
                    l.preventDefault(), l.stopPropagation();
                    const u = p;
                    s.value = o.open(Fl, {
                        data: {
                            imageSrc: u.src,
                            imageAlt: u.alt || "Zoomed image"
                        },
                        props: {
                            modal: !0,
                            draggable: !1,
                            showHeader: !1,
                            closeButtonProps: {
                                class: "my-close-props"
                            },
                            style: {
                                width: "95vw",
                                maxHeight: "calc(95vh - 3rem)",
                                height: "100%",
                                position: "relative",
                                top: "1.5rem"
                            },
                            contentStyle: {
                                display: "flex",
                                flex: "1",
                                padding: "var(--p-overlay-modal-padding)"
                            }
                        }
                    });
                }
            };
            return (l, p)=>(x(), N("div", null, [
                    e.collapse && a.value.length === 1 ? W("", !0) : (x(), N("div", Ul, [
                        A(S(gs), {
                            allowEmpty: !1,
                            modelValue: i.value,
                            "onUpdate:modelValue": p[0] || (p[0] = (u)=>i.value = u),
                            options: a.value
                        }, null, 8, [
                            "modelValue",
                            "options"
                        ])
                    ])),
                    y("div", Hl, [
                        r.value[i.value]?.component ? (x(), Z(en(r.value[i.value].component), io({
                            key: 0
                        }, r.value[i.value].bindMapping, {
                            class: `rendered-output ${i.value.replace("/", "-")}`,
                            onClick: c
                        }), null, 16, [
                            "class"
                        ])) : W("", !0)
                    ])
                ]));
        }
    });
    var Wl = {
        207: (t, e, n)=>{
            t.exports = n(452);
        },
        452: (t)=>{
            var e = (function(n) {
                var o, s = Object.prototype, r = s.hasOwnProperty, a = typeof Symbol == "function" ? Symbol : {}, i = a.iterator || "@@iterator", c = a.asyncIterator || "@@asyncIterator", l = a.toStringTag || "@@toStringTag";
                function p(d, m, E) {
                    return Object.defineProperty(d, m, {
                        value: E,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), d[m];
                }
                try {
                    p({}, "");
                } catch  {
                    p = function(m, E, L) {
                        return m[E] = L;
                    };
                }
                function u(d, m, E, L) {
                    var M = m && m.prototype instanceof T ? m : T, X = Object.create(M.prototype), ne = new j(L || []);
                    return X._invoke = (function(ue, he, Y) {
                        var ae = v;
                        return function(se, me) {
                            if (ae === C) throw new Error("Generator is already running");
                            if (ae === _) {
                                if (se === "throw") throw me;
                                return P();
                            }
                            for(Y.method = se, Y.arg = me;;){
                                var _e = Y.delegate;
                                if (_e) {
                                    var Ae = Q(_e, Y);
                                    if (Ae) {
                                        if (Ae === h) continue;
                                        return Ae;
                                    }
                                }
                                if (Y.method === "next") Y.sent = Y._sent = Y.arg;
                                else if (Y.method === "throw") {
                                    if (ae === v) throw ae = _, Y.arg;
                                    Y.dispatchException(Y.arg);
                                } else Y.method === "return" && Y.abrupt("return", Y.arg);
                                ae = C;
                                var Se = f(ue, he, Y);
                                if (Se.type === "normal") {
                                    if (ae = Y.done ? _ : g, Se.arg === h) continue;
                                    return {
                                        value: Se.arg,
                                        done: Y.done
                                    };
                                }
                                Se.type === "throw" && (ae = _, Y.method = "throw", Y.arg = Se.arg);
                            }
                        };
                    })(d, E, ne), X;
                }
                function f(d, m, E) {
                    try {
                        return {
                            type: "normal",
                            arg: d.call(m, E)
                        };
                    } catch (L) {
                        return {
                            type: "throw",
                            arg: L
                        };
                    }
                }
                n.wrap = u;
                var v = "suspendedStart", g = "suspendedYield", C = "executing", _ = "completed", h = {};
                function T() {}
                function O() {}
                function b() {}
                var B = {};
                p(B, i, (function() {
                    return this;
                }));
                var $ = Object.getPrototypeOf, k = $ && $($(F([])));
                k && k !== s && r.call(k, i) && (B = k);
                var w = b.prototype = T.prototype = Object.create(B);
                function V(d) {
                    [
                        "next",
                        "throw",
                        "return"
                    ].forEach((function(m) {
                        p(d, m, (function(E) {
                            return this._invoke(m, E);
                        }));
                    }));
                }
                function D(d, m) {
                    function E(M, X, ne, ue) {
                        var he = f(d[M], d, X);
                        if (he.type !== "throw") {
                            var Y = he.arg, ae = Y.value;
                            return ae && typeof ae == "object" && r.call(ae, "__await") ? m.resolve(ae.__await).then((function(se) {
                                E("next", se, ne, ue);
                            }), (function(se) {
                                E("throw", se, ne, ue);
                            })) : m.resolve(ae).then((function(se) {
                                Y.value = se, ne(Y);
                            }), (function(se) {
                                return E("throw", se, ne, ue);
                            }));
                        }
                        ue(he.arg);
                    }
                    var L;
                    this._invoke = function(M, X) {
                        function ne() {
                            return new m((function(ue, he) {
                                E(M, X, ue, he);
                            }));
                        }
                        return L = L ? L.then(ne, ne) : ne();
                    };
                }
                function Q(d, m) {
                    var E = d.iterator[m.method];
                    if (E === o) {
                        if (m.delegate = null, m.method === "throw") {
                            if (d.iterator.return && (m.method = "return", m.arg = o, Q(d, m), m.method === "throw")) return h;
                            m.method = "throw", m.arg = new TypeError("The iterator does not provide a 'throw' method");
                        }
                        return h;
                    }
                    var L = f(E, d.iterator, m.arg);
                    if (L.type === "throw") return m.method = "throw", m.arg = L.arg, m.delegate = null, h;
                    var M = L.arg;
                    return M ? M.done ? (m[d.resultName] = M.value, m.next = d.nextLoc, m.method !== "return" && (m.method = "next", m.arg = o), m.delegate = null, h) : M : (m.method = "throw", m.arg = new TypeError("iterator result is not an object"), m.delegate = null, h);
                }
                function q(d) {
                    var m = {
                        tryLoc: d[0]
                    };
                    1 in d && (m.catchLoc = d[1]), 2 in d && (m.finallyLoc = d[2], m.afterLoc = d[3]), this.tryEntries.push(m);
                }
                function I(d) {
                    var m = d.completion || {};
                    m.type = "normal", delete m.arg, d.completion = m;
                }
                function j(d) {
                    this.tryEntries = [
                        {
                            tryLoc: "root"
                        }
                    ], d.forEach(q, this), this.reset(!0);
                }
                function F(d) {
                    if (d) {
                        var m = d[i];
                        if (m) return m.call(d);
                        if (typeof d.next == "function") return d;
                        if (!isNaN(d.length)) {
                            var E = -1, L = function M() {
                                for(; ++E < d.length;)if (r.call(d, E)) return M.value = d[E], M.done = !1, M;
                                return M.value = o, M.done = !0, M;
                            };
                            return L.next = L;
                        }
                    }
                    return {
                        next: P
                    };
                }
                function P() {
                    return {
                        value: o,
                        done: !0
                    };
                }
                return O.prototype = b, p(w, "constructor", b), p(b, "constructor", O), O.displayName = p(b, l, "GeneratorFunction"), n.isGeneratorFunction = function(d) {
                    var m = typeof d == "function" && d.constructor;
                    return !!m && (m === O || (m.displayName || m.name) === "GeneratorFunction");
                }, n.mark = function(d) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(d, b) : (d.__proto__ = b, p(d, l, "GeneratorFunction")), d.prototype = Object.create(w), d;
                }, n.awrap = function(d) {
                    return {
                        __await: d
                    };
                }, V(D.prototype), p(D.prototype, c, (function() {
                    return this;
                })), n.AsyncIterator = D, n.async = function(d, m, E, L, M) {
                    M === void 0 && (M = Promise);
                    var X = new D(u(d, m, E, L), M);
                    return n.isGeneratorFunction(m) ? X : X.next().then((function(ne) {
                        return ne.done ? ne.value : X.next();
                    }));
                }, V(w), p(w, l, "Generator"), p(w, i, (function() {
                    return this;
                })), p(w, "toString", (function() {
                    return "[object Generator]";
                })), n.keys = function(d) {
                    var m = [];
                    for(var E in d)m.push(E);
                    return m.reverse(), function L() {
                        for(; m.length;){
                            var M = m.pop();
                            if (M in d) return L.value = M, L.done = !1, L;
                        }
                        return L.done = !0, L;
                    };
                }, n.values = F, j.prototype = {
                    constructor: j,
                    reset: function(d) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = o, this.done = !1, this.delegate = null, this.method = "next", this.arg = o, this.tryEntries.forEach(I), !d) for(var m in this)m.charAt(0) === "t" && r.call(this, m) && !isNaN(+m.slice(1)) && (this[m] = o);
                    },
                    stop: function() {
                        this.done = !0;
                        var d = this.tryEntries[0].completion;
                        if (d.type === "throw") throw d.arg;
                        return this.rval;
                    },
                    dispatchException: function(d) {
                        if (this.done) throw d;
                        var m = this;
                        function E(he, Y) {
                            return X.type = "throw", X.arg = d, m.next = he, Y && (m.method = "next", m.arg = o), !!Y;
                        }
                        for(var L = this.tryEntries.length - 1; L >= 0; --L){
                            var M = this.tryEntries[L], X = M.completion;
                            if (M.tryLoc === "root") return E("end");
                            if (M.tryLoc <= this.prev) {
                                var ne = r.call(M, "catchLoc"), ue = r.call(M, "finallyLoc");
                                if (ne && ue) {
                                    if (this.prev < M.catchLoc) return E(M.catchLoc, !0);
                                    if (this.prev < M.finallyLoc) return E(M.finallyLoc);
                                } else if (ne) {
                                    if (this.prev < M.catchLoc) return E(M.catchLoc, !0);
                                } else {
                                    if (!ue) throw new Error("try statement without catch or finally");
                                    if (this.prev < M.finallyLoc) return E(M.finallyLoc);
                                }
                            }
                        }
                    },
                    abrupt: function(d, m) {
                        for(var E = this.tryEntries.length - 1; E >= 0; --E){
                            var L = this.tryEntries[E];
                            if (L.tryLoc <= this.prev && r.call(L, "finallyLoc") && this.prev < L.finallyLoc) {
                                var M = L;
                                break;
                            }
                        }
                        M && (d === "break" || d === "continue") && M.tryLoc <= m && m <= M.finallyLoc && (M = null);
                        var X = M ? M.completion : {};
                        return X.type = d, X.arg = m, M ? (this.method = "next", this.next = M.finallyLoc, h) : this.complete(X);
                    },
                    complete: function(d, m) {
                        if (d.type === "throw") throw d.arg;
                        return d.type === "break" || d.type === "continue" ? this.next = d.arg : d.type === "return" ? (this.rval = this.arg = d.arg, this.method = "return", this.next = "end") : d.type === "normal" && m && (this.next = m), h;
                    },
                    finish: function(d) {
                        for(var m = this.tryEntries.length - 1; m >= 0; --m){
                            var E = this.tryEntries[m];
                            if (E.finallyLoc === d) return this.complete(E.completion, E.afterLoc), I(E), h;
                        }
                    },
                    catch: function(d) {
                        for(var m = this.tryEntries.length - 1; m >= 0; --m){
                            var E = this.tryEntries[m];
                            if (E.tryLoc === d) {
                                var L = E.completion;
                                if (L.type === "throw") {
                                    var M = L.arg;
                                    I(E);
                                }
                                return M;
                            }
                        }
                        throw new Error("illegal catch attempt");
                    },
                    delegateYield: function(d, m, E) {
                        return this.delegate = {
                            iterator: F(d),
                            resultName: m,
                            nextLoc: E
                        }, this.method === "next" && (this.arg = o), h;
                    }
                }, n;
            })(t.exports);
            try {
                regeneratorRuntime = e;
            } catch  {
                typeof globalThis == "object" ? globalThis.regeneratorRuntime = e : Function("r", "regeneratorRuntime = r")(e);
            }
        }
    }, Qn = {};
    function Ce(t) {
        var e = Qn[t];
        if (e !== void 0) return e.exports;
        var n = Qn[t] = {
            exports: {}
        };
        return Wl[t](n, n.exports, Ce), n.exports;
    }
    Ce.n = (t)=>{
        var e = t && t.__esModule ? ()=>t.default : ()=>t;
        return Ce.d(e, {
            a: e
        }), e;
    }, Ce.d = (t, e)=>{
        for(var n in e)Ce.o(e, n) && !Ce.o(t, n) && Object.defineProperty(t, n, {
            enumerable: !0,
            get: e[n]
        });
    }, Ce.o = (t, e)=>Object.prototype.hasOwnProperty.call(t, e);
    var zo = {};
    function Kt(t, e) {
        (e == null || e > t.length) && (e = t.length);
        for(var n = 0, o = new Array(e); n < e; n++)o[n] = t[n];
        return o;
    }
    function Do(t, e) {
        if (t) {
            if (typeof t == "string") return Kt(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            return n === "Object" && t.constructor && (n = t.constructor.name), n === "Map" || n === "Set" ? Array.from(t) : n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? Kt(t, e) : void 0;
        }
    }
    function St(t) {
        return (function(e) {
            if (Array.isArray(e)) return Kt(e);
        })(t) || (function(e) {
            if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
        })(t) || Do(t) || (function() {
            throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
        })();
    }
    function it(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t;
    }
    Ce.d(zo, {
        A: ()=>Yl
    });
    const z = (Xn = {
        Fragment: ()=>le,
        computed: ()=>G,
        createTextVNode: ()=>Te,
        createVNode: ()=>A,
        defineComponent: ()=>oe,
        reactive: ()=>bt,
        ref: ()=>R,
        watch: ()=>ge,
        watchEffect: ()=>ms
    }, zt = {}, Ce.d(zt, Xn), zt), ql = (0, z.defineComponent)({
        props: {
            data: {
                required: !0,
                type: String
            },
            onClick: Function
        },
        render: function() {
            var t = this.data, e = this.onClick;
            return (0, z.createVNode)("span", {
                class: "vjs-tree-brackets",
                onClick: e
            }, [
                t
            ]);
        }
    }), Zl = (0, z.defineComponent)({
        emits: [
            "change",
            "update:modelValue"
        ],
        props: {
            checked: {
                type: Boolean,
                default: !1
            },
            isMultiple: Boolean,
            onChange: Function
        },
        setup: function(t, e) {
            var n = e.emit;
            return {
                uiType: (0, z.computed)((function() {
                    return t.isMultiple ? "checkbox" : "radio";
                })),
                model: (0, z.computed)({
                    get: function() {
                        return t.checked;
                    },
                    set: function(o) {
                        return n("update:modelValue", o);
                    }
                })
            };
        },
        render: function() {
            var t = this.uiType, e = this.model, n = this.$emit;
            return (0, z.createVNode)("label", {
                class: [
                    "vjs-check-controller",
                    e ? "is-checked" : ""
                ],
                onClick: function(o) {
                    return o.stopPropagation();
                }
            }, [
                (0, z.createVNode)("span", {
                    class: "vjs-check-controller-inner is-".concat(t)
                }, null),
                (0, z.createVNode)("input", {
                    checked: e,
                    class: "vjs-check-controller-original is-".concat(t),
                    type: t,
                    onChange: function() {
                        return n("change", e);
                    }
                }, null)
            ]);
        }
    }), Gl = (0, z.defineComponent)({
        props: {
            nodeType: {
                required: !0,
                type: String
            },
            onClick: Function
        },
        render: function() {
            var t = this.nodeType, e = this.onClick, n = t === "objectStart" || t === "arrayStart";
            return n || t === "objectCollapsed" || t === "arrayCollapsed" ? (0, z.createVNode)("span", {
                class: "vjs-carets vjs-carets-".concat(n ? "open" : "close"),
                onClick: e
            }, [
                (0, z.createVNode)("svg", {
                    viewBox: "0 0 1024 1024",
                    focusable: "false",
                    "data-icon": "caret-down",
                    width: "1em",
                    height: "1em",
                    fill: "currentColor",
                    "aria-hidden": "true"
                }, [
                    (0, z.createVNode)("path", {
                        d: "M840.4 300H183.6c-19.7 0-30.7 20.8-18.5 35l328.4 380.8c9.4 10.9 27.5 10.9 37 0L858.9 335c12.2-14.2 1.2-35-18.5-35z"
                    }, null)
                ])
            ]) : null;
        }
    });
    var Xn, zt;
    function Yt(t) {
        return Yt = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
            return typeof e;
        } : function(e) {
            return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
        }, Yt(t);
    }
    function Fo(t) {
        return Object.prototype.toString.call(t).slice(8, -1).toLowerCase();
    }
    function je(t) {
        var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "root", n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0, o = (arguments.length > 3 ? arguments[3] : void 0) || {}, s = o.key, r = o.index, a = o.type, i = a === void 0 ? "content" : a, c = o.showComma, l = c !== void 0 && c, p = o.length, u = p === void 0 ? 1 : p, f = Fo(t);
        if (f === "array") {
            var v = eo(t.map((function(_, h, T) {
                return je(_, "".concat(e, "[").concat(h, "]"), n + 1, {
                    index: h,
                    showComma: h !== T.length - 1,
                    length: u,
                    type: i
                });
            })));
            return [
                je("[", e, n, {
                    showComma: !1,
                    key: s,
                    length: t.length,
                    type: "arrayStart"
                })[0]
            ].concat(v, je("]", e, n, {
                showComma: l,
                length: t.length,
                type: "arrayEnd"
            })[0]);
        }
        if (f === "object") {
            var g = Object.keys(t), C = eo(g.map((function(_, h, T) {
                return je(t[_], /^[a-zA-Z_]\w*$/.test(_) ? "".concat(e, ".").concat(_) : "".concat(e, '["').concat(_, '"]'), n + 1, {
                    key: _,
                    showComma: h !== T.length - 1,
                    length: u,
                    type: i
                });
            })));
            return [
                je("{", e, n, {
                    showComma: !1,
                    key: s,
                    index: r,
                    length: g.length,
                    type: "objectStart"
                })[0]
            ].concat(C, je("}", e, n, {
                showComma: l,
                length: g.length,
                type: "objectEnd"
            })[0]);
        }
        return [
            {
                content: t,
                level: n,
                key: s,
                index: r,
                path: e,
                showComma: l,
                length: u,
                type: i
            }
        ];
    }
    function eo(t) {
        if (typeof Array.prototype.flat == "function") return t.flat();
        for(var e = St(t), n = []; e.length;){
            var o = e.shift();
            Array.isArray(o) ? e.unshift.apply(e, St(o)) : n.push(o);
        }
        return n;
    }
    function Qt(t) {
        var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : new WeakMap;
        if (t == null) return t;
        if (t instanceof Date) return new Date(t);
        if (t instanceof RegExp) return new RegExp(t);
        if (Yt(t) !== "object") return t;
        if (e.get(t)) return e.get(t);
        if (Array.isArray(t)) {
            var n = t.map((function(r) {
                return Qt(r, e);
            }));
            return e.set(t, n), n;
        }
        var o = {};
        for(var s in t)o[s] = Qt(t[s], e);
        return e.set(t, o), o;
    }
    function to(t, e, n, o, s, r, a) {
        try {
            var i = t[r](a), c = i.value;
        } catch (l) {
            return void n(l);
        }
        i.done ? e(c) : Promise.resolve(c).then(o, s);
    }
    var Jl = Ce(207), no = Ce.n(Jl);
    function oo(t, e) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
            var o = Object.getOwnPropertySymbols(t);
            e && (o = o.filter((function(s) {
                return Object.getOwnPropertyDescriptor(t, s).enumerable;
            }))), n.push.apply(n, o);
        }
        return n;
    }
    function so(t) {
        for(var e = 1; e < arguments.length; e++){
            var n = arguments[e] != null ? arguments[e] : {};
            e % 2 ? oo(Object(n), !0).forEach((function(o) {
                it(t, o, n[o]);
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : oo(Object(n)).forEach((function(o) {
                Object.defineProperty(t, o, Object.getOwnPropertyDescriptor(n, o));
            }));
        }
        return t;
    }
    var Uo = {
        data: {
            type: [
                String,
                Number,
                Boolean,
                Array,
                Object
            ],
            default: null
        },
        rootPath: {
            type: String,
            default: "root"
        },
        indent: {
            type: Number,
            default: 2
        },
        showLength: {
            type: Boolean,
            default: !1
        },
        showDoubleQuotes: {
            type: Boolean,
            default: !0
        },
        renderNodeKey: Function,
        renderNodeValue: Function,
        renderNodeActions: {
            type: [
                Boolean,
                Function
            ],
            default: void 0
        },
        selectableType: String,
        showSelectController: {
            type: Boolean,
            default: !1
        },
        showLine: {
            type: Boolean,
            default: !0
        },
        showLineNumber: {
            type: Boolean,
            default: !1
        },
        selectOnClickNode: {
            type: Boolean,
            default: !0
        },
        nodeSelectable: {
            type: Function,
            default: function() {
                return !0;
            }
        },
        highlightSelectedNode: {
            type: Boolean,
            default: !0
        },
        showIcon: {
            type: Boolean,
            default: !1
        },
        theme: {
            type: String,
            default: "light"
        },
        showKeyValueSpace: {
            type: Boolean,
            default: !0
        },
        editable: {
            type: Boolean,
            default: !1
        },
        editableTrigger: {
            type: String,
            default: "click"
        },
        onNodeClick: {
            type: Function
        },
        onNodeMouseover: {
            type: Function
        },
        onBracketsClick: {
            type: Function
        },
        onIconClick: {
            type: Function
        },
        onValueChange: {
            type: Function
        }
    };
    const Kl = (0, z.defineComponent)({
        name: "TreeNode",
        props: so(so({}, Uo), {}, {
            node: {
                type: Object,
                required: !0
            },
            collapsed: Boolean,
            checked: Boolean,
            style: Object,
            onSelectedChange: {
                type: Function
            }
        }),
        emits: [
            "nodeClick",
            "nodeMouseover",
            "bracketsClick",
            "iconClick",
            "selectedChange",
            "valueChange"
        ],
        setup: function(t, e) {
            var n = e.emit, o = (0, z.computed)((function() {
                return Fo(t.node.content);
            })), s = (0, z.computed)((function() {
                return "vjs-value vjs-value-".concat(o.value);
            })), r = (0, z.computed)((function() {
                return t.showDoubleQuotes ? '"'.concat(t.node.key, '"') : t.node.key;
            })), a = (0, z.computed)((function() {
                return t.selectableType === "multiple";
            })), i = (0, z.computed)((function() {
                return t.selectableType === "single";
            })), c = (0, z.computed)((function() {
                return t.nodeSelectable(t.node) && (a.value || i.value);
            })), l = (0, z.reactive)({
                editing: !1
            }), p = function($) {
                var k, w, V = (w = (k = $.target) === null || k === void 0 ? void 0 : k.value) === "null" ? null : w === "undefined" ? void 0 : w === "true" || w !== "false" && (w[0] + w[w.length - 1] === '""' || w[0] + w[w.length - 1] === "''" ? w.slice(1, -1) : typeof Number(w) == "number" && !isNaN(Number(w)) || w === "NaN" ? Number(w) : w);
                n("valueChange", V, t.node.path);
            }, u = (0, z.computed)((function() {
                var $, k = ($ = t.node) === null || $ === void 0 ? void 0 : $.content;
                return k === null ? k = "null" : k === void 0 && (k = "undefined"), o.value === "string" ? '"'.concat(k, '"') : k + "";
            })), f = function() {
                var $ = t.renderNodeValue;
                return $ ? $({
                    node: t.node,
                    defaultValue: u.value
                }) : u.value;
            }, v = function() {
                n("bracketsClick", !t.collapsed, t.node);
            }, g = function() {
                n("iconClick", !t.collapsed, t.node);
            }, C = function() {
                n("selectedChange", t.node);
            }, _ = function() {
                n("nodeClick", t.node), c.value && t.selectOnClickNode && n("selectedChange", t.node);
            }, h = function() {
                n("nodeMouseover", t.node);
            }, T = function($) {
                if (t.editable && !l.editing) {
                    l.editing = !0;
                    var k = function w(V) {
                        var D;
                        V.target !== $.target && ((D = V.target) === null || D === void 0 ? void 0 : D.parentElement) !== $.target && (l.editing = !1, document.removeEventListener("click", w));
                    };
                    document.removeEventListener("click", k), document.addEventListener("click", k);
                }
            }, O = (function() {
                var $ = (0, z.ref)(!1), k = (function() {
                    var w, V = (w = no().mark((function D(Q) {
                        return no().wrap((function(q) {
                            for(;;)switch(q.prev = q.next){
                                case 0:
                                    return q.prev = 0, q.next = 3, navigator.clipboard.writeText(Q);
                                case 3:
                                    $.value = !0, setTimeout((function() {
                                        $.value = !1;
                                    }), 300), q.next = 10;
                                    break;
                                case 7:
                                    q.prev = 7, q.t0 = q.catch(0), console.error("[vue-json-pretty] Copy failed: ", q.t0);
                                case 10:
                                case "end":
                                    return q.stop();
                            }
                        }), D, null, [
                            [
                                0,
                                7
                            ]
                        ]);
                    })), function() {
                        var D = this, Q = arguments;
                        return new Promise((function(q, I) {
                            var j = w.apply(D, Q);
                            function F(d) {
                                to(j, q, I, F, P, "next", d);
                            }
                            function P(d) {
                                to(j, q, I, F, P, "throw", d);
                            }
                            F(void 0);
                        }));
                    });
                    return function(D) {
                        return V.apply(this, arguments);
                    };
                })();
                return {
                    copy: k
                };
            })().copy, b = function() {
                var $ = t.node, k = $.key, w = $.path, V = t.rootPath, D = new Function("data", "return data".concat(w.slice(V.length)))(t.data), Q = JSON.stringify(k ? it({}, k, D) : D, null, 2);
                O(Q);
            }, B = function() {
                var $ = t.renderNodeActions;
                if (!$) return null;
                var k = {
                    copy: b
                };
                return typeof $ == "function" ? $({
                    node: t.node,
                    defaultActions: k
                }) : (0, z.createVNode)("span", {
                    onClick: b,
                    class: "vjs-tree-node-actions-item"
                }, [
                    (0, z.createTextVNode)("copy")
                ]);
            };
            return function() {
                var $, k = t.node;
                return (0, z.createVNode)("div", {
                    class: {
                        "vjs-tree-node": !0,
                        "has-selector": t.showSelectController,
                        "has-carets": t.showIcon,
                        "is-highlight": t.highlightSelectedNode && t.checked,
                        dark: t.theme === "dark"
                    },
                    onClick: _,
                    onMouseover: h,
                    style: t.style
                }, [
                    t.showLineNumber && (0, z.createVNode)("span", {
                        class: "vjs-node-index"
                    }, [
                        k.id + 1
                    ]),
                    t.showSelectController && c.value && k.type !== "objectEnd" && k.type !== "arrayEnd" && (0, z.createVNode)(Zl, {
                        isMultiple: a.value,
                        checked: t.checked,
                        onChange: C
                    }, null),
                    (0, z.createVNode)("div", {
                        class: "vjs-indent"
                    }, [
                        Array.from(Array(k.level)).map((function(w, V) {
                            return (0, z.createVNode)("div", {
                                key: V,
                                class: {
                                    "vjs-indent-unit": !0,
                                    "has-line": t.showLine
                                }
                            }, [
                                Array.from(Array(t.indent)).map((function() {
                                    return (0, z.createVNode)(z.Fragment, null, [
                                        (0, z.createTextVNode)(" ")
                                    ]);
                                }))
                            ]);
                        })),
                        t.showIcon && (0, z.createVNode)(Gl, {
                            nodeType: k.type,
                            onClick: g
                        }, null)
                    ]),
                    k.key && (0, z.createVNode)("span", {
                        class: "vjs-key"
                    }, [
                        ($ = t.renderNodeKey, $ ? $({
                            node: t.node,
                            defaultKey: r.value || ""
                        }) : r.value),
                        (0, z.createVNode)("span", {
                            class: "vjs-colon"
                        }, [
                            ":".concat(t.showKeyValueSpace ? " " : "")
                        ])
                    ]),
                    (0, z.createVNode)("span", null, [
                        k.type !== "content" && k.content ? (0, z.createVNode)(ql, {
                            data: k.content.toString(),
                            onClick: v
                        }, null) : (0, z.createVNode)("span", {
                            class: s.value,
                            onClick: !t.editable || t.editableTrigger && t.editableTrigger !== "click" ? void 0 : T,
                            onDblclick: t.editable && t.editableTrigger === "dblclick" ? T : void 0
                        }, [
                            t.editable && l.editing ? (0, z.createVNode)("input", {
                                value: u.value,
                                onChange: p,
                                style: {
                                    padding: "3px 8px",
                                    border: "1px solid #eee",
                                    boxShadow: "none",
                                    boxSizing: "border-box",
                                    borderRadius: 5,
                                    fontFamily: "inherit"
                                }
                            }, null) : f()
                        ]),
                        k.showComma && (0, z.createVNode)("span", null, [
                            ","
                        ]),
                        t.showLength && t.collapsed && (0, z.createVNode)("span", {
                            class: "vjs-comment"
                        }, [
                            (0, z.createTextVNode)(" // "),
                            k.length,
                            (0, z.createTextVNode)(" items ")
                        ])
                    ]),
                    t.renderNodeActions && (0, z.createVNode)("span", {
                        class: "vjs-tree-node-actions"
                    }, [
                        B()
                    ])
                ]);
            };
        }
    });
    function ro(t, e) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
            var o = Object.getOwnPropertySymbols(t);
            e && (o = o.filter((function(s) {
                return Object.getOwnPropertyDescriptor(t, s).enumerable;
            }))), n.push.apply(n, o);
        }
        return n;
    }
    function ke(t) {
        for(var e = 1; e < arguments.length; e++){
            var n = arguments[e] != null ? arguments[e] : {};
            e % 2 ? ro(Object(n), !0).forEach((function(o) {
                it(t, o, n[o]);
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : ro(Object(n)).forEach((function(o) {
                Object.defineProperty(t, o, Object.getOwnPropertyDescriptor(n, o));
            }));
        }
        return t;
    }
    const Yl = (0, z.defineComponent)({
        name: "Tree",
        props: ke(ke({}, Uo), {}, {
            collapsedNodeLength: {
                type: Number,
                default: 1 / 0
            },
            deep: {
                type: Number,
                default: 1 / 0
            },
            pathCollapsible: {
                type: Function,
                default: function() {
                    return !1;
                }
            },
            virtual: {
                type: Boolean,
                default: !1
            },
            height: {
                type: Number,
                default: 400
            },
            itemHeight: {
                type: Number,
                default: 20
            },
            selectedValue: {
                type: [
                    String,
                    Array
                ],
                default: function() {
                    return "";
                }
            },
            collapsedOnClickBrackets: {
                type: Boolean,
                default: !0
            },
            style: Object,
            onSelectedChange: {
                type: Function
            },
            theme: {
                type: String,
                default: "light"
            }
        }),
        slots: [
            "renderNodeKey",
            "renderNodeValue",
            "renderNodeActions"
        ],
        emits: [
            "nodeClick",
            "nodeMouseover",
            "bracketsClick",
            "iconClick",
            "selectedChange",
            "update:selectedValue",
            "update:data"
        ],
        setup: function(t, e) {
            var n = e.emit, o = e.slots, s = (0, z.ref)(), r = (0, z.computed)((function() {
                return je(t.data, t.rootPath);
            })), a = function(b, B) {
                return r.value.reduce((function($, k) {
                    var w, V = k.level >= b || k.length >= B, D = (w = t.pathCollapsible) === null || w === void 0 ? void 0 : w.call(t, k);
                    return k.type !== "objectStart" && k.type !== "arrayStart" || !V && !D ? $ : ke(ke({}, $), {}, it({}, k.path, 1));
                }), {});
            }, i = (0, z.reactive)({
                translateY: 0,
                visibleData: null,
                hiddenPaths: a(t.deep, t.collapsedNodeLength)
            }), c = (0, z.computed)((function() {
                for(var b = null, B = [], $ = r.value.length, k = 0; k < $; k++){
                    var w = ke(ke({}, r.value[k]), {}, {
                        id: k
                    }), V = i.hiddenPaths[w.path];
                    if (b && b.path === w.path) {
                        var D = b.type === "objectStart", Q = ke(ke(ke({}, w), b), {}, {
                            showComma: w.showComma,
                            content: D ? "{...}" : "[...]",
                            type: D ? "objectCollapsed" : "arrayCollapsed"
                        });
                        b = null, B.push(Q);
                    } else {
                        if (V && !b) {
                            b = w;
                            continue;
                        }
                        if (b) continue;
                        B.push(w);
                    }
                }
                return B;
            })), l = (0, z.computed)((function() {
                var b = t.selectedValue;
                return b && t.selectableType === "multiple" && Array.isArray(b) ? b : [
                    b
                ];
            })), p = (0, z.computed)((function() {
                return !t.selectableType || t.selectOnClickNode || t.showSelectController ? "" : "When selectableType is not null, selectOnClickNode and showSelectController cannot be false at the same time, because this will cause the selection to fail.";
            })), u = function() {
                var b = c.value;
                if (t.virtual) {
                    var B, $ = t.height / t.itemHeight, k = ((B = s.value) === null || B === void 0 ? void 0 : B.scrollTop) || 0, w = Math.floor(k / t.itemHeight), V = w < 0 ? 0 : w + $ > b.length ? b.length - $ : w;
                    V < 0 && (V = 0);
                    var D = V + $;
                    i.translateY = V * t.itemHeight, i.visibleData = b.filter((function(Q, q) {
                        return q >= V && q < D;
                    }));
                } else i.visibleData = b;
            }, f = function() {
                u();
            }, v = function(b) {
                var B, $, k = b.path, w = t.selectableType;
                if (w === "multiple") {
                    var V = l.value.findIndex((function(I) {
                        return I === k;
                    })), D = St(l.value);
                    V !== -1 ? D.splice(V, 1) : D.push(k), n("update:selectedValue", D), n("selectedChange", D, St(l.value));
                } else if (w === "single" && l.value[0] !== k) {
                    var Q = (B = l.value, $ = 1, (function(I) {
                        if (Array.isArray(I)) return I;
                    })(B) || (function(I, j) {
                        var F = I == null ? null : typeof Symbol < "u" && I[Symbol.iterator] || I["@@iterator"];
                        if (F != null) {
                            var P, d, m = [], E = !0, L = !1;
                            try {
                                for(F = F.call(I); !(E = (P = F.next()).done) && (m.push(P.value), !j || m.length !== j); E = !0);
                            } catch (M) {
                                L = !0, d = M;
                            } finally{
                                try {
                                    E || F.return == null || F.return();
                                } finally{
                                    if (L) throw d;
                                }
                            }
                            return m;
                        }
                    })(B, $) || Do(B, $) || (function() {
                        throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
                    })())[0], q = k;
                    n("update:selectedValue", q), n("selectedChange", q, Q);
                }
            }, g = function(b) {
                n("nodeClick", b);
            }, C = function(b) {
                n("nodeMouseover", b);
            }, _ = function(b, B) {
                if (b) i.hiddenPaths = ke(ke({}, i.hiddenPaths), {}, it({}, B, 1));
                else {
                    var $ = ke({}, i.hiddenPaths);
                    delete $[B], i.hiddenPaths = $;
                }
            }, h = function(b, B) {
                t.collapsedOnClickBrackets && _(b, B.path), n("bracketsClick", b, B);
            }, T = function(b, B) {
                _(b, B.path), n("iconClick", b, B);
            }, O = function(b, B) {
                var $ = Qt(t.data), k = t.rootPath;
                new Function("data", "val", "data".concat(B.slice(k.length), "=val"))($, b), n("update:data", $);
            };
            return (0, z.watchEffect)((function() {
                p.value && (function(b) {
                    throw new Error("[VueJSONPretty] ".concat(b));
                })(p.value);
            })), (0, z.watchEffect)((function() {
                c.value && u();
            })), (0, z.watch)((function() {
                return t.deep;
            }), (function(b) {
                b && (i.hiddenPaths = a(b, t.collapsedNodeLength));
            })), (0, z.watch)((function() {
                return t.collapsedNodeLength;
            }), (function(b) {
                b && (i.hiddenPaths = a(t.deep, b));
            })), function() {
                var b, B, $, k, w = (b = t.renderNodeKey) !== null && b !== void 0 ? b : o.renderNodeKey, V = (B = t.renderNodeValue) !== null && B !== void 0 ? B : o.renderNodeValue, D = ($ = (k = t.renderNodeActions) !== null && k !== void 0 ? k : o.renderNodeActions) !== null && $ !== void 0 && $, Q = i.visibleData && i.visibleData.map((function(q) {
                    return (0, z.createVNode)(Kl, {
                        key: q.id,
                        data: t.data,
                        rootPath: t.rootPath,
                        indent: t.indent,
                        node: q,
                        collapsed: !!i.hiddenPaths[q.path],
                        theme: t.theme,
                        showDoubleQuotes: t.showDoubleQuotes,
                        showLength: t.showLength,
                        checked: l.value.includes(q.path),
                        selectableType: t.selectableType,
                        showLine: t.showLine,
                        showLineNumber: t.showLineNumber,
                        showSelectController: t.showSelectController,
                        selectOnClickNode: t.selectOnClickNode,
                        nodeSelectable: t.nodeSelectable,
                        highlightSelectedNode: t.highlightSelectedNode,
                        editable: t.editable,
                        editableTrigger: t.editableTrigger,
                        showIcon: t.showIcon,
                        showKeyValueSpace: t.showKeyValueSpace,
                        renderNodeKey: w,
                        renderNodeValue: V,
                        renderNodeActions: D,
                        onNodeClick: g,
                        onNodeMouseover: C,
                        onBracketsClick: h,
                        onIconClick: T,
                        onSelectedChange: v,
                        onValueChange: O,
                        style: t.itemHeight && t.itemHeight !== 20 ? {
                            lineHeight: "".concat(t.itemHeight, "px")
                        } : {}
                    }, null);
                }));
                return (0, z.createVNode)("div", {
                    ref: s,
                    class: {
                        "vjs-tree": !0,
                        "is-virtual": t.virtual,
                        dark: t.theme === "dark"
                    },
                    onScroll: t.virtual ? f : void 0,
                    style: t.showLineNumber ? ke({
                        paddingLeft: "".concat(12 * Number(r.value.length.toString().length), "px")
                    }, t.style) : t.style
                }, [
                    t.virtual ? (0, z.createVNode)("div", {
                        class: "vjs-tree-list",
                        style: {
                            height: "".concat(t.height, "px")
                        }
                    }, [
                        (0, z.createVNode)("div", {
                            class: "vjs-tree-list-holder",
                            style: {
                                height: "".concat(c.value.length * t.itemHeight, "px")
                            }
                        }, [
                            (0, z.createVNode)("div", {
                                class: "vjs-tree-list-holder-inner",
                                style: {
                                    transform: "translateY(".concat(i.translateY, "px)")
                                }
                            }, [
                                Q
                            ])
                        ])
                    ]) : Q
                ]);
            };
        }
    });
    Ho = zo.A;
    let Ql, Xl, ec, tc, nc, oc, sc, rc, ac, ic, lc, cc, uc, dc, pc, fc, hc, gc, mc, vc, yc, bc, kc, wc, xc, _c, Cc, Sc, $c, Tc, Ec, Oc, Rc, Pc, Ac, Ic, Bc;
    Ql = {
        class: "debug-message"
    };
    Xl = {
        class: "debug-message-header-container"
    };
    ec = {
        class: "debug-message-title"
    };
    tc = {
        style: {
            "font-weight": "500"
        }
    };
    nc = {
        class: "debug-message-date"
    };
    oc = {
        class: "debug-message-body"
    };
    sc = {
        key: 0
    };
    rc = {
        key: 0
    };
    ac = {
        key: 1
    };
    ic = {
        key: 1,
        style: {
            color: "var(--p-surface-h)"
        }
    };
    lc = {
        key: 2
    };
    cc = {
        key: 3
    };
    uc = {
        class: "debug-tool-call-title"
    };
    dc = {
        style: {
            "font-family": "monospace",
            "margin-bottom": "0.25rem"
        }
    };
    pc = {
        key: 0
    };
    fc = {
        key: 4
    };
    hc = {
        key: 0,
        class: "debug-tool-info"
    };
    gc = {
        class: "debug-tool-call-title"
    };
    mc = {
        style: {
            "font-family": "monospace"
        }
    };
    vc = {
        key: 2
    };
    yc = [
        "onclick"
    ];
    bc = {
        class: "debug-dropdown-label"
    };
    kc = {
        key: 1,
        class: "log-dropdown-additional-details"
    };
    wc = [
        "onclick"
    ];
    xc = {
        class: "debug-dropdown-label"
    };
    _c = {
        key: 1,
        class: "debug-dropdown-body"
    };
    Cc = oe({
        __name: "DebugLogMessage",
        props: [
            "logEntry",
            "options"
        ],
        setup (t) {
            const e = t, n = G(()=>e.options?.value?.includes("quotes")), o = G(()=>e.options?.value?.includes("linenum")), s = {
                execution_start: "Execution Start",
                execution_end: "Execution End",
                debug_update: "Debug Update",
                new_kernel: "New Kernel",
                "init-agent": "Agent Initialization",
                llm_query: "Agent Query",
                agent_llm_request: "Agent Message",
                agent_llm_response: "Agent Response",
                agent_react_tool: "Tool Invocation",
                agent_react_tool_output: "Tool Output",
                agent_react_final_answer: "Agent Final Answer"
            }, r = [
                "new_kernel",
                "llm_query"
            ], a = [
                "debug_update",
                "init-agent",
                "undefined"
            ], i = G(()=>[
                    "get_subkernel_state",
                    "preview"
                ].includes(e?.logEntry?.body?.metadata?.type)), c = G(()=>{
                const u = e?.logEntry?.body?.metadata?.type, f = e?.logEntry?.type === "execution_start" ? "Start" : e?.logEntry?.type === "execution_end" ? "End" : "";
                if (u === "get_subkernel_state") return `Fetch Subkernel State (${f})`;
                if (u === "preview") return `Subkernel Preview (${f})`;
                const v = e?.logEntry?.type?.startsWith("agent_") ? e?.logEntry?.type?.slice(6) : e?.logEntry?.type;
                return s?.[e?.logEntry?.type] ?? v ?? "Message";
            }), l = R(!1), p = R(!1);
            return (u, f)=>(x(), N("div", Ql, [
                    t.logEntry?.body ? (x(), Z(S(co), {
                        key: 0,
                        class: "debug-message-panel"
                    }, {
                        header: H(()=>[
                                y("div", Xl, [
                                    y("div", ec, [
                                        y("span", tc, K(c.value), 1)
                                    ]),
                                    y("span", nc, K(t.logEntry?.timestamp.split("T")[1].slice(0, -1)), 1)
                                ])
                            ]),
                        default: H(()=>[
                                y("p", oc, [
                                    t.logEntry?.type === "agent_llm_response" ? (x(), N("span", sc, [
                                        t.logEntry?.body?.split("tool_calls=")?.[1]?.split("'")?.[3] === "final_answer" ? (x(), N("span", rc, "Processing final answer from tool output.")) : (x(), N("span", ac, K(t.logEntry?.body?.split("tool_calls=")?.[0]?.split("text=")?.[1].slice(1, -3)), 1))
                                    ])) : W("", !0),
                                    t.logEntry?.type === "agent_llm_request" ? (x(), N("span", ic, "Agent context setup and conversation history -- see details below")) : W("", !0),
                                    r.includes(t.logEntry?.type) || !Object.keys(s).includes(t.logEntry?.type) ? (x(), N("span", lc, K(t.logEntry?.body), 1)) : W("", !0),
                                    t.logEntry?.type === "agent_react_tool_output" ? (x(), N("span", cc, [
                                        y("span", uc, [
                                            y("span", dc, K(t.logEntry?.body?.tool), 1)
                                        ]),
                                        t.logEntry?.body?.tool === "run_code" ? (x(), N("span", pc, " tool output is usually verbose and is hidden by default -- see details below ")) : (x(), Z(mt, {
                                            key: 1,
                                            readonly: "",
                                            modelValue: t.logEntry?.body?.output?.trim(),
                                            class: "debug-code-display"
                                        }, null, 8, [
                                            "modelValue"
                                        ]))
                                    ])) : W("", !0),
                                    t.logEntry?.type === "agent_react_final_answer" ? (x(), N("span", fc, K(t.logEntry?.body?.final_answer?.response), 1)) : W("", !0)
                                ]),
                                t.logEntry?.type === "agent_react_tool" ? (x(), N("div", hc, [
                                    y("span", gc, [
                                        f[0] || (f[0] = Te(" Tool: ", -1)),
                                        y("span", mc, K(t.logEntry?.body?.tool), 1)
                                    ]),
                                    A(S(kt), {
                                        showGridlines: "",
                                        stripedRows: "",
                                        class: "debug-info-datatable",
                                        value: Object.entries(t.logEntry?.body?.input).map(([v, g])=>({
                                                key: v,
                                                value: g
                                            }))
                                    }, {
                                        default: H(()=>[
                                                A(S(Oe), {
                                                    field: "key"
                                                }),
                                                A(S(Oe), {
                                                    field: "value"
                                                })
                                            ]),
                                        _: 1
                                    }, 8, [
                                        "value"
                                    ])
                                ])) : W("", !0),
                                a.includes(t.logEntry?.type) && t.logEntry?.body && Object.keys(t.logEntry?.body).length > 0 ? (x(), Z(S(kt), {
                                    key: 1,
                                    showGridlines: "",
                                    stripedRows: "",
                                    class: "debug-info-datatable",
                                    value: Object.entries(t.logEntry?.body).map(([v, g])=>({
                                            key: v,
                                            value: g
                                        }))
                                }, {
                                    default: H(()=>[
                                            A(S(Oe), {
                                                field: "key"
                                            }),
                                            A(S(Oe), {
                                                field: "value"
                                            })
                                        ]),
                                    _: 1
                                }, 8, [
                                    "value"
                                ])) : (x(), N("div", vc, [
                                    t.logEntry?.type === "execution_start" && !i.value ? (x(), Z(mt, {
                                        key: 0,
                                        readonly: "",
                                        modelValue: t.logEntry?.body?.command?.trim(),
                                        class: "debug-code-display"
                                    }, null, 8, [
                                        "modelValue"
                                    ])) : W("", !0),
                                    f[1] || (f[1] = y("div", {
                                        class: "debug-separator"
                                    }, null, -1)),
                                    y("div", {
                                        class: "debug-dropdown debug-dropdown-details",
                                        onclick: ()=>{
                                            l.value = !l.value;
                                        }
                                    }, [
                                        y("span", {
                                            class: ie([
                                                "pi",
                                                {
                                                    "pi-angle-right": !l.value,
                                                    "pi-angle-down": l.value
                                                }
                                            ])
                                        }, null, 2),
                                        y("span", bc, K(l.value ? "Hide" : "Show") + " Additional Details ", 1)
                                    ], 8, yc),
                                    l.value ? (x(), N("div", kc, [
                                        t.logEntry?.type === "execution_start" && i.value ? (x(), Z(mt, {
                                            key: 0,
                                            readonly: "",
                                            modelValue: t.logEntry?.body?.command?.trim(),
                                            class: "debug-code-display"
                                        }, null, 8, [
                                            "modelValue"
                                        ])) : W("", !0),
                                        y("div", {
                                            class: "debug-dropdown debug-dropdown-raw",
                                            onclick: ()=>{
                                                p.value = !p.value;
                                            }
                                        }, [
                                            y("span", {
                                                class: ie([
                                                    "pi",
                                                    {
                                                        "pi-angle-right": !p.value,
                                                        "pi-angle-down": p.value
                                                    }
                                                ])
                                            }, null, 2),
                                            y("span", xc, K(p.value ? "Hide" : "Show") + " Raw Message (JSON) ", 1)
                                        ], 8, wc),
                                        p.value ? (x(), N("div", _c, [
                                            A(S(Ho), {
                                                data: t.logEntry.body,
                                                deep: 2,
                                                showLength: "",
                                                showIcon: "",
                                                showDoubleQuotes: n.value,
                                                showLineNumber: o.value
                                            }, null, 8, [
                                                "data",
                                                "showDoubleQuotes",
                                                "showLineNumber"
                                            ])
                                        ])) : W("", !0)
                                    ])) : W("", !0)
                                ]))
                            ]),
                        _: 1
                    })) : W("", !0)
                ]));
        }
    });
    Sc = {
        class: "debug-panel-wrapper"
    };
    $c = {
        class: "debug-log-container"
    };
    Tc = {
        class: "debug-flex-container"
    };
    Ec = {
        class: "p-input-icon-right",
        style: {
            padding: "0",
            margin: "0"
        }
    };
    Oc = {
        class: "debug-sort-actions p-buttonset"
    };
    Rc = {
        class: "debug-bottom-actions"
    };
    Pc = {
        key: 1
    };
    Zc = oe({
        __name: "DebugPanel",
        props: [
            "entries",
            "sortby"
        ],
        emits: [
            "clearLogs"
        ],
        setup (t, { emit: e }) {
            const n = t, o = R(""), s = R("asc"), r = R(!1), a = G(()=>{
                const i = n.sortby || ((f)=>f.timestamp), c = (f, v)=>i(f) > i(v) ? 1 : i(f) < i(v) ? -1 : 0, l = (f, v)=>i(f) < i(v) ? 1 : i(f) > i(v) ? -1 : 0, p = (f)=>!!([
                        "new_kernel",
                        "init-agent",
                        "debug_update",
                        "execution_start",
                        "execution_end"
                    ].includes(f.type) || [
                        "get_subkernel_state",
                        "preview"
                    ].includes(f?.body?.metadata?.type)), u = n.entries?.filter((f)=>o.value !== "" ? f?.type?.includes(o.value) : !0)?.filter((f)=>r.value ? !p(f) : !0);
                return s.value === "asc" ? u.sort(c) : u.sort(l);
            });
            return (i, c)=>{
                const l = Ue("tooltip");
                return x(), N("div", Sc, [
                    y("div", $c, [
                        y("div", Tc, [
                            y("span", Ec, [
                                c[4] || (c[4] = y("i", {
                                    class: "pi pi-search"
                                }, null, -1)),
                                A(S(Ze), {
                                    modelValue: o.value,
                                    "onUpdate:modelValue": c[0] || (c[0] = (p)=>o.value = p),
                                    size: "small",
                                    placeholder: "Type"
                                }, null, 8, [
                                    "modelValue"
                                ])
                            ]),
                            y("div", Oc, [
                                re(A(S(J), {
                                    onClick: c[1] || (c[1] = (p)=>s.value = "asc"),
                                    outlined: "",
                                    size: "small",
                                    icon: "pi pi-sort-numeric-down",
                                    "aria-label": "Sort Time Asc"
                                }, null, 512), [
                                    [
                                        l,
                                        "Sort Asc",
                                        void 0,
                                        {
                                            bottom: !0
                                        }
                                    ]
                                ]),
                                re(A(S(J), {
                                    onClick: c[2] || (c[2] = (p)=>s.value = "desc"),
                                    outlined: "",
                                    size: "small",
                                    icon: "pi pi-sort-numeric-up-alt",
                                    "aria-label": "Sort Time Desc"
                                }, null, 512), [
                                    [
                                        l,
                                        "Sort Desc",
                                        void 0,
                                        {
                                            bottom: !0
                                        }
                                    ]
                                ])
                            ])
                        ]),
                        (x(!0), N(le, null, we(a.value, (p)=>(x(), Z(Cc, {
                                "log-entry": p,
                                key: `${p.type}-${p.timestamp}`
                            }, null, 8, [
                                "log-entry"
                            ]))), 128)),
                        y("div", Rc, [
                            a.value.length ? (x(), Z(S(J), {
                                key: 0,
                                label: "Clear Logs",
                                severity: "warning",
                                size: "small",
                                onClick: c[3] || (c[3] = (p)=>i.$emit("clearLogs"))
                            })) : (x(), N("p", Pc, " No logs yet. "))
                        ])
                    ])
                ]);
            };
        }
    });
    Ac = {
        class: "table-renderer"
    };
    Ic = [
        "innerHTML"
    ];
    Bc = oe({
        __name: "TablePreview",
        props: [
            "data",
            "mimeType"
        ],
        setup (t) {
            const e = t, n = (c)=>c === "application/vnd.ms-excel" || c === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", o = R(), s = (c, l, p)=>{
                if (c === void 0 || c === "") return {
                    columns: [],
                    values: []
                };
                const u = c.split(l), f = u[0].split(p), v = u.slice(1).map((g)=>g.split(",").reduce((C, _, h)=>({
                            [f[h]]: _.trim(),
                            ...C
                        }), {}));
                return {
                    columns: f,
                    values: v
                };
            }, r = (c)=>{
                const l = Zs(c);
                return l.SheetNames.map((u)=>({
                        name: u,
                        html: Gs.sheet_to_html(l.Sheets[u])
                    }));
            }, a = G(()=>e.mimeType === "text/csv" ? s(e?.data, `
`, ",") : e.mimeType === "text/tsv" ? s(e?.data, "	", ",") : e.data), i = R(!1);
            return Ne(()=>{
                e.mimeType.startsWith("application/vnd") && (i.value = !0, o.value = r(e.data), i.value = !1);
            }), (c, l)=>(x(), N("div", Ac, [
                    t.mimeType.startsWith("text/") ? (x(), Z(S(kt), {
                        key: 0,
                        value: a.value.values,
                        paginator: "",
                        rows: 20,
                        rowsPerPageOptions: [
                            10,
                            20,
                            50
                        ]
                    }, {
                        default: H(()=>[
                                (x(!0), N(le, null, we(a.value.columns, (p)=>(x(), Z(S(Oe), {
                                        field: p,
                                        header: p,
                                        key: p
                                    }, null, 8, [
                                        "field",
                                        "header"
                                    ]))), 128))
                            ]),
                        _: 1
                    }, 8, [
                        "value"
                    ])) : W("", !0),
                    n(t.mimeType) ? (x(), Z(S(ys), {
                        key: 1,
                        pt: {
                            panelContainer: (p)=>({
                                    class: "xlsx-panel-container"
                                })
                        }
                    }, {
                        default: H(()=>[
                                (x(!0), N(le, null, we(o.value, ({ name: p, html: u })=>(x(), Z(S(vs), {
                                        header: p,
                                        key: p,
                                        value: p
                                    }, {
                                        default: H(()=>[
                                                i.value ? W("", !0) : (x(), N("div", {
                                                    key: 0,
                                                    class: "xlsx-table",
                                                    innerHTML: u
                                                }, null, 8, Ic))
                                            ]),
                                        _: 2
                                    }, 1032, [
                                        "header",
                                        "value"
                                    ]))), 128))
                            ]),
                        _: 1
                    })) : W("", !0)
                ]));
        }
    });
    Gc = {
        rank: 60,
        mimetypes: [
            "application/json",
            "text/json"
        ],
        render: (t, e, n)=>({
                component: Ho,
                bindMapping: {
                    data: e,
                    deep: "2",
                    showLength: !0,
                    showIcon: !0,
                    showDoubleQuotes: "isQuotes",
                    showLineNumber: "linenum",
                    style: {
                        whiteSpace: "pre"
                    }
                }
            })
    };
    Jc = {
        rank: 40,
        mimetypes: [
            "text/markdown",
            "text/x-markdown"
        ],
        render: (t, e, n)=>{
            const o = te.parse(e.toString());
            return {
                component: oe((s)=>()=>Je("div", {
                            innerHTML: s.html
                        }), {
                    props: [
                        "html"
                    ]
                }),
                bindMapping: {
                    html: o
                }
            };
        }
    };
    Kc = {
        rank: 40,
        mimetypes: [
            "text/latex",
            "application/latex"
        ],
        render: (t, e, n)=>(e.toString(), {
                component: oe((s)=>()=>Je("div", {
                            class: "beaker-latex",
                            innerHTML: s.html,
                            style: {
                                fontSize: "1.5rem"
                            }
                        }), {
                    props: [
                        "html"
                    ]
                }),
                bindMapping: {
                    html: "DEBUG TESTING DEADBEEF"
                }
            })
    };
    Yc = {
        rank: 40,
        mimetypes: [
            "text/csv",
            "text/tsv",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        ],
        render: (t, e, n)=>({
                component: Bc,
                bindMapping: {
                    data: e,
                    mimeType: t
                }
            })
    };
    Qc = {
        rank: 45,
        mimetypes: [
            "text/javascript",
            "application/javascript"
        ],
        render: (t, e, n)=>({
                component: oe((o)=>()=>Je("script", {
                            innerHTML: o.html
                        })),
                bindMapping: {
                    html: e,
                    mimeType: t
                }
            })
    };
    Xc = function(t) {
        return {
            rank: t.rank - 10,
            mimetypes: t.mimetypes,
            render: (e, n, o)=>{
                const s = t.render(e, n, o);
                return {
                    component: oe(()=>()=>Je("div", {
                                onVnodeBeforeMount: (r)=>{
                                    r.el.appendChild(s);
                                }
                            })),
                    bindMapping: {}
                };
            }
        };
    };
});
export { ze as B, Fl as I, Qc as J, Kc as L, Jc as M, Ho as P, Yc as T, Uc as _, Gc as a, wr as b, Wc as c, Pl as d, Zc as e, Hc as f, Fc as g, xo as h, qc as i, Xi as j, mt as k, rt as l, te as m, Co as n, yr as o, Ut as p, _o as u, Xc as w, __tla };

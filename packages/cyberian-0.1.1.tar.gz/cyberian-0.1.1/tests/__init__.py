"""Tests for cyberian."""

"""
Promotexter MCP Server

A Model Context Protocol (MCP) server for Promotexter SMS API.
Provides tools for SMS messaging and balance inquiry.
"""

__version__ = "0.1.1"
__author__ = "John Alvero"

from promotexter_mcp.server import mcp

__all__ = ["mcp"]

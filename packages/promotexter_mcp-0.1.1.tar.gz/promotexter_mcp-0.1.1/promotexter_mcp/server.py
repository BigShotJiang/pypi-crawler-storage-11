#!/usr/bin/env python3
"""
Promotexter MCP Server
Provides tools for SMS messaging and balance inquiry via Promotexter API.
"""

import os
import httpx
from typing import Optional
from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("Promotexter")

# Base URLs
BASE_URL = "https://api.promotexter.com"


def get_credentials() -> tuple[str, str, str]:
    """
    Get API credentials from environment variables.

    Returns:
        Tuple of (api_key, api_secret, sender_id)

    Raises:
        ValueError: If credentials are not found
    """
    api_key = os.getenv("PROMOTEXTER_API_KEY")
    api_secret = os.getenv("PROMOTEXTER_API_SECRET")
    sender_id = os.getenv("PROMOTEXTER_SENDER_ID")

    if not api_key or not api_secret:
        raise ValueError(
            "PROMOTEXTER_API_KEY and PROMOTEXTER_API_SECRET environment variables must be set"
        )

    if not sender_id:
        raise ValueError(
            "PROMOTEXTER_SENDER_ID environment variable must be set"
        )

    return api_key, api_secret, sender_id


@mcp.tool()
async def get_balance() -> str:
    """
    Get the current account balance from Promotexter.

    Returns:
        Account balance information
    """
    try:
        api_key, api_secret, _ = get_credentials()

        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{BASE_URL}/api/account/balance",
                params={
                    "apiKey": api_key,
                    "apiSecret": api_secret
                },
                timeout=30.0
            )
            response.raise_for_status()
            data = response.json()

            # Format the response
            available_balance = data.get("availableBalance", "N/A")
            account_balance = data.get("accountBalance", "N/A")
            credit_limit = data.get("creditLimit", "N/A")
            withheld = data.get("withheld", "N/A")

            result = []
            result.append(f"Available Balance: {available_balance}")
            result.append(f"Account Balance: {account_balance}")
            result.append(f"Credit Limit: {credit_limit}")
            result.append(f"Withheld: {withheld}")

            return "\n".join(result)

    except httpx.HTTPStatusError as e:
        return f"HTTP Error: {e.response.status_code} - {e.response.text}"
    except ValueError as e:
        return f"Configuration Error: {str(e)}"
    except Exception as e:
        return f"Error retrieving balance: {str(e)}"


@mcp.tool()
async def send_sms(
    to: str,
    text: str,
    reference_id: Optional[str] = None
) -> str:
    """
    Send a single SMS message via Promotexter.

    Args:
        to: Recipient mobile number (must be valid mobile number format)
        text: Message content (maximum 1000 characters)
        reference_id: Optional reference ID for tracking

    Returns:
        SMS send response with transaction details
    """
    try:
        api_key, api_secret, sender_id = get_credentials()

        # Validate inputs
        if not to or not text:
            return "Error: 'to' and 'text' are required parameters"

        if len(text) > 1000:
            return "Error: Message text exceeds maximum length of 1000 characters"

        # Build request payload
        payload = {
            "apiKey": api_key,
            "apiSecret": api_secret,
            "from": sender_id,
            "to": to,
            "text": text
        }

        if reference_id:
            payload["referenceId"] = reference_id

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{BASE_URL}/sms/send",
                json=payload,
                timeout=30.0
            )
            response.raise_for_status()
            data = response.json()

            # Format the response
            result = []
            result.append("SMS Sent Successfully!")
            result.append(f"Message ID: {data.get('id', 'N/A')}")
            result.append(f"Remaining Balance: {data.get('remainingBalance', 'N/A')}")
            result.append(f"Transaction Cost: {data.get('transactionCost', 'N/A')}")
            result.append(f"Unit Cost: {data.get('unitCost', 'N/A')}")
            result.append(f"Message Parts: {data.get('messageParts', 'N/A')}")
            result.append(f"Operator: {data.get('operatorCode', 'N/A')}")
            result.append(f"To: {data.get('to', to)}")
            result.append(f"From: {data.get('from', sender_id)}")

            if reference_id:
                result.append(f"Reference ID: {data.get('referenceId', reference_id)}")

            return "\n".join(result)

    except httpx.HTTPStatusError as e:
        return f"HTTP Error: {e.response.status_code} - {e.response.text}"
    except ValueError as e:
        return f"Configuration Error: {str(e)}"
    except Exception as e:
        return f"Error sending SMS: {str(e)}"


def main():
    """Main entry point for the CLI."""
    mcp.run()


if __name__ == "__main__":
    main()

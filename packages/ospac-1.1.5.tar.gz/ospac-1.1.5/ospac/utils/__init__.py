"""
OSPAC utility functions.
"""
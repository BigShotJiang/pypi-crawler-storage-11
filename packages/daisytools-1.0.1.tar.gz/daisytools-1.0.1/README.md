# DaisyTools - Daisy Framework Development Tools

[![PyPI version](https://img.shields.io/pypi/v/daisytools.svg)](https://pypi.org/project/daisytools/)
[![Python versions](https://img.shields.io/pypi/pyversions/daisytools.svg)](https://pypi.org/project/daisytools/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview

DaisyTools is a comprehensive toolset for Python code style checking and formatting in Daisy framework projects. It provides automated code quality tools to help developers maintain consistent code style across Daisy software.

## Features

- **Code Style Checking**: Check Python code for formatting issues
- **Code Style Fixing**: Automatically fix formatting and import sorting
- **Python Environment Management**: Python interpreter wrapper
- **Recursive Directory Scanning**: Automatically finds all Python files
- **Import File Detection**: Skips files marked as imported
- **Multiple Output Formats**: Check mode, fix mode, and flake8 reporting

## Installation

### From PyPI (Recommended)

```bash
pip install daisytools
```

### From Source

```bash
git clone https://github.com/huy/daisytools.git
cd daisytools
pip install .
```

### Development Installation

```bash
git clone https://github.com/huy/daisytools.git
cd daisytools
pip install -e .
```

## Usage

### Code Style Checking

```bash
# Check all Python files in current directory
daisy-code-style-check

# Check specific files
daisy-code-style-check file1.py file2.py

# Check with flake8 output
daisy-code-style-check -p
```

### Code Style Fixing

```bash
# Fix all Python files in current directory
daisy-code-style-fix

# Fix specific files
daisy-code-style-fix file1.py file2.py

# Preview changes without applying them
daisy-code-style-fix -n

# Preview changes with flake8 output
daisy-code-style-fix -n -p
```

### Python Wrapper

```bash
# Use the best available Python interpreter
daisypython script.py
```

## Configuration

The tools automatically look for configuration files in your project:
- `.flake8`
- `pyproject.toml`

If these files are not found, default configurations are used:
- **Black**: Line length 88, Python 3.6+ compatibility
- **isort**: Black profile for import sorting
- **flake8**: Max line length 88, ignores E203 and W503

## Command Line Options

### daisy-code-style-check

- `files`: Python files to check (optional, defaults to all Python files in current directory)
- `-p, --flake8`: Show flake8 output instead of code changes

### daisy-code-style-fix

- `files`: Python files to fix (optional, defaults to all Python files in current directory)
- `-n, --check`: Only show what would be changed without applying fixes
- `-p, --flake8`: Show flake8 output (only with -n option)

## Development

### Running Tests

```bash
python -m pytest tests/
```

### Building the Package

```bash
python -m build
```

### Publishing to PyPI

```bash
python -m twine upload dist/*
```

## License

MIT License - see [LICENSE](LICENSE) file for details.
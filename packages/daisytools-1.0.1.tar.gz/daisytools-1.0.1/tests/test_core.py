"""
Tests for daisytools core functionality.
"""

import os
import tempfile
from pathlib import Path

import pytest

from daisytools.core import (
    find_python_files,
    is_imported_file,
    check_crlf_line_endings,
)


def test_find_python_files():
    """Test finding Python files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create some Python files
        (Path(tmpdir) / "test1.py").write_text("print('hello')")
        (Path(tmpdir) / "test2.py").write_text("print('world')")
        (Path(tmpdir) / "subdir").mkdir(parents=True)
        (Path(tmpdir) / "subdir" / "test3.py").write_text("print('subdir')")

        # Create a non-Python file
        (Path(tmpdir) / "not_python.txt").write_text("not python")

        # Test recursive search
        files = find_python_files(tmpdir, recursive=True)
        assert len(files) == 3
        assert any("test1.py" in f for f in files)
        assert any("test2.py" in f for f in files)
        assert any("test3.py" in f for f in files)

        # Test non-recursive search
        files = find_python_files(tmpdir, recursive=False)
        assert len(files) == 2
        assert any("test1.py" in f for f in files)
        assert any("test2.py" in f for f in files)


def test_is_imported_file():
    """Test imported file detection."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)

        # Create a Python file
        python_file = tmpdir_path / "test.py"
        python_file.write_text("print('test')")

        # File should not be imported initially
        assert not is_imported_file(str(python_file))

        # Create .imported file in parent directory
        imported_marker = tmpdir_path / ".imported"
        imported_marker.write_text("")

        # File should now be detected as imported
        assert is_imported_file(str(python_file))


def test_check_crlf_line_endings():
    """Test CRLF line ending detection."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)

        # Create file with LF line endings
        lf_file = tmpdir_path / "lf_file.py"
        lf_file.write_text("line1\nline2\n")

        # Create file with CRLF line endings
        crlf_file = tmpdir_path / "crlf_file.py"
        with open(crlf_file, 'wb') as f:
            f.write(b"line1\r\nline2\r\n")

        # Test detection
        assert not check_crlf_line_endings(str(lf_file))
        assert check_crlf_line_endings(str(crlf_file))


def test_find_python_files_empty_directory():
    """Test finding Python files in empty directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        files = find_python_files(tmpdir)
        assert files == []
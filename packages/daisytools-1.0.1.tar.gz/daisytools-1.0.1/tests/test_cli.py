"""
Tests for daisytools CLI functionality.
"""

import subprocess
import sys
import tempfile
from pathlib import Path

import pytest


def test_cli_help():
    """Test CLI help commands."""
    # Test daisy-code-style-check help
    result = subprocess.run(
        [sys.executable, "-m", "daisytools.cli", "check", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0
    assert "Check Python code style" in result.stdout

    # Test daisy-code-style-fix help
    result = subprocess.run(
        [sys.executable, "-m", "daisytools.cli", "fix", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0
    assert "Fix Python code style" in result.stdout


def test_cli_check_nonexistent_file():
    """Test CLI with non-existent file."""
    result = subprocess.run(
        ["daisy-code-style-check", "nonexistent.py"],
        capture_output=True,
        text=True
    )
    # The command should handle non-existent files gracefully
    # It might return non-zero exit code but should provide helpful output
    assert "does not exist" in result.stdout or "does not exist" in result.stderr


def test_cli_fix_nonexistent_file():
    """Test CLI with non-existent file."""
    result = subprocess.run(
        ["daisy-code-style-fix", "nonexistent.py"],
        capture_output=True,
        text=True
    )
    # The command should handle non-existent files gracefully
    # It might return non-zero exit code but should provide helpful output
    assert "does not exist" in result.stdout or "does not exist" in result.stderr
from blues_lib.type.executor.Executor import Executor
from blues_lib.type.model.Model import Model
from blues_lib.namespace.CrawlerName import CrawlerName
from blues_lib.namespace.CommandName import CommandName
from blues_lib.command.hook.mapping.Mapper import Mapper

class AbsMapping(Executor):
  
  POSITION = None
  
  def __init__(self,context:dict,input:Model,name:CommandName):
    '''
    @param {dict} context : the flow's context
    @param {Model} input : the basic command node's input
    @param {CommandName} name : the current command's name
    '''
    self._context:dict = context
    self._input = input
    self._name = name
    # only model input can have a mapping config
    self._map_confs = self._get_confs()
  
  def _get_confs(self)->list[dict]:
    hook_conf = self._input.config.get(self.POSITION.value,{})
    map_confs:list[dict]|dict = hook_conf.get(CrawlerName.Field.MAPPING.value)
    return map_confs if isinstance(map_confs,list) else [map_confs]

  def execute(self) -> bool:
    '''
    map a value from source to target
    - source: task_id/attr_chain or bizdata/attr_chain
    - target: bizdata/attr_chain or task_id/attr_chain
    
    support multi mapping
    '''
    for map_conf in self._map_confs:
      Mapper(self._context,self._input,map_conf).execute()
    return True

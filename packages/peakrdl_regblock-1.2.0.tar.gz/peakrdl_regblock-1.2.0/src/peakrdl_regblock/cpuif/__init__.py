from .base import CpuifBase

"""Library version."""

VERSION = "2025.10.1"

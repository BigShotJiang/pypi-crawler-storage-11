# Dependencies

<details open>
<summary>Explicit dependencies</summary>

|Dependency|Before|After|Change|Package|Environments|
|-|-|-|-|-|-|
|[setuptools](https://pypi.org/project/setuptools)|74.1.3|75.6.0|Major Upgrade|pypi|*all envs* on osx-arm64|
|[polars](https://prefix.dev/channels/conda-forge/packages/polars)|1.15.0|1.16.0|Minor Upgrade|conda|*all envs* on osx-arm64|
|pkg|0.23.0|0.23.0|Other|conda|*all envs* on linux-64|
|[private-package](https://prefix.dev/channels/setup-pixi-test/packages/private-package)|0.0.1|0.0.1|Other|conda|*all envs* on osx-arm64|
|my-package|py313hc743ca1_0|py313hc743ca1_1|Only build string|conda|*all envs* on osx-arm64|

</details>

<details open>
<summary>Implicit dependencies</summary>

|Dependency|Before|After|Change|Package|Environments|
|-|-|-|-|-|-|
|my-package2||0.0.0|Added|conda|*all envs* on osx-arm64|
|microsoft_python_type_stubs|none|none|Other|pypi|*all envs* on linux-64|
|my-package3|pyh4616a5c_0|pyhabaa311_0|Only build string|conda|*all envs* on osx-arm64|

</details>

[^1]: **Bold** means explicit dependency.
[^2]: Dependency got downgraded.

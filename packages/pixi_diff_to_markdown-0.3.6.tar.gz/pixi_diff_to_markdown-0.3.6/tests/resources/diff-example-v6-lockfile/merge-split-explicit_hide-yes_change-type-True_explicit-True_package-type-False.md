# Dependencies

<details open>
<summary>Explicit dependencies</summary>

|Dependency|Before|After|Change|Explicit|Environments|
|-|-|-|-|-|-|
|[setuptools](https://pypi.org/project/setuptools)|74.1.3|75.6.0|Major Upgrade|true|*all envs* on osx-arm64|
|[polars](https://prefix.dev/channels/conda-forge/packages/polars)|1.15.0|1.16.0|Minor Upgrade|true|*all envs* on osx-arm64|
|pkg|0.23.0|0.23.0|Other|true|*all envs* on linux-64|
|[private-package](https://prefix.dev/channels/setup-pixi-test/packages/private-package)|0.0.1|0.0.1|Other|true|*all envs* on osx-arm64|
|my-package|py313hc743ca1_0|py313hc743ca1_1|Only build string|true|*all envs* on osx-arm64|

</details>

<details open>
<summary>Implicit dependencies</summary>

|Dependency|Before|After|Change|Explicit|Environments|
|-|-|-|-|-|-|
|my-package2||0.0.0|Added|false|*all envs* on osx-arm64|
|microsoft_python_type_stubs|none|none|Other|false|*all envs* on linux-64|
|my-package3|pyh4616a5c_0|pyhabaa311_0|Only build string|false|*all envs* on osx-arm64|

</details>

[^1]: **Bold** means explicit dependency.
[^2]: Dependency got downgraded.

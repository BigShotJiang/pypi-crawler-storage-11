# default

<details open>
<summary>osx-arm64</summary>

|Dependency|Before|After|Change|Explicit|
|-|-|-|-|-|
|[setuptools](https://pypi.org/project/setuptools)|74.1.3|75.6.0|Major Upgrade|true|
|[polars](https://prefix.dev/channels/conda-forge/packages/polars)|1.15.0|1.16.0|Minor Upgrade|true|
|[private-package](https://prefix.dev/channels/setup-pixi-test/packages/private-package)|0.0.1|0.0.1|Other|true|
|my-package|py313hc743ca1_0|py313hc743ca1_1|Only build string|true|
|my-package2||0.0.0|Added|false|
|my-package3|pyh4616a5c_0|pyhabaa311_0|Only build string|false|

</details>

<details open>
<summary>linux-64</summary>

|Dependency|Before|After|Change|Explicit|
|-|-|-|-|-|
|pkg|0.23.0|0.23.0|Other|true|
|microsoft_python_type_stubs|none|none|Other|false|

</details>

[^1]: **Bold** means explicit dependency.
[^2]: Dependency got downgraded.

# default

<details open>
<summary>osx-arm64</summary>

|Dependency|Before|After|Explicit|Package|
|-|-|-|-|-|
|[setuptools](https://pypi.org/project/setuptools)|74.1.3|75.6.0|true|pypi|
|[polars](https://prefix.dev/channels/conda-forge/packages/polars)|1.15.0|1.16.0|true|conda|
|[private-package](https://prefix.dev/channels/setup-pixi-test/packages/private-package)|0.0.1|0.0.1|true|conda|
|my-package|py313hc743ca1_0|py313hc743ca1_1|true|conda|
|my-package2||0.0.0|false|conda|
|my-package3|pyh4616a5c_0|pyhabaa311_0|false|conda|

</details>

<details open>
<summary>linux-64</summary>

|Dependency|Before|After|Explicit|Package|
|-|-|-|-|-|
|pkg|0.23.0|0.23.0|true|conda|
|microsoft_python_type_stubs|none|none|false|pypi|

</details>

[^1]: **Bold** means explicit dependency.
[^2]: Dependency got downgraded.

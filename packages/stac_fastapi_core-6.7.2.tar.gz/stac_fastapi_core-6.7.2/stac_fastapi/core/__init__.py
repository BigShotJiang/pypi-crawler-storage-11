"""Core library."""

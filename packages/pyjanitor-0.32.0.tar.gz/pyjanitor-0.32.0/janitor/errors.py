class JanitorError(Exception):
    pass

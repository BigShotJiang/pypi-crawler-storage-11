"""
Copyright 2023-2023 VMware Inc.
SPDX-License-Identifier: Apache-2.0

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import click
import hcs_core.sglib.cli_options as cli
import httpx
from hcs_core.ctxp import recent

from hcs_cli.service import admin


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
@cli.wait
@cli.force
@cli.confirm
def delete(id: str, org: str, wait: str, force: bool, confirm: bool):
    """Delete UAG by ID"""

    org_id = cli.get_org_id(org)
    id = recent.require("uag", id)

    ret = admin.uag.get(id, org_id)

    if not confirm:
        click.confirm(f"Delete UAG {ret['name']} ({id})?", abort=True)

    try:
        ret = admin.uag.delete(id, org_id, force=force)
        if not ret:
            return "", 1
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 409:
            pass
        else:
            raise
    if wait == "0":
        return ret
    admin.uag.wait_for_deleted(id, org_id, wait)

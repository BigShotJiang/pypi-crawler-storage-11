"""
Integration tests for the spacemouse package.
"""

import pytest

from spacemouse import SpacemouseClient, SpacemouseError


class TestPackageIntegration:
    """Integration tests for the spacemouse package."""

    def test_package_imports(self):
        """Test that main package imports work correctly."""
        # Test that we can import the main classes
        from spacemouse import SpacemouseClient, SpacemouseError
        
        assert SpacemouseClient is not None
        assert SpacemouseError is not None

    def test_version_available(self):
        """Test that package version is available."""
        import spacemouse
        
        assert hasattr(spacemouse, '__version__')
        assert isinstance(spacemouse.__version__, str)

    def test_author_info_available(self):
        """Test that author information is available."""
        import spacemouse
        
        assert hasattr(spacemouse, '__author__')
        assert hasattr(spacemouse, '__email__')

    def test_client_basic_workflow(self):
        """Test basic client workflow integration."""
        # Initialize client
        client = SpacemouseClient()
        
        # Check initial state
        assert not client.is_connected()
        
        # Connect
        client.connect()
        assert client.is_connected()
        
        # Get device info
        info = client.get_device_info()
        assert isinstance(info, dict)
        assert "status" in info
        
        # Disconnect
        client.disconnect()
        assert not client.is_connected()

    def test_context_manager_integration(self):
        """Test context manager integration."""
        device_info = None
        
        with SpacemouseClient() as client:
            assert client.is_connected()
            device_info = client.get_device_info()
        
        # Verify we got device info and client disconnected
        assert device_info is not None
        assert not client.is_connected()

    def test_error_handling_integration(self):
        """Test error handling integration across modules."""
        from spacemouse.exceptions import SpacemouseDeviceNotFoundError
        
        client = SpacemouseClient(device_id="invalid")
        
        with pytest.raises(SpacemouseDeviceNotFoundError):
            client.connect()
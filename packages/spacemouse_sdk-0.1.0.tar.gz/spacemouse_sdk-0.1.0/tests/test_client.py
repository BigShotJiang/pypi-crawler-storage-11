"""
Tests for the SpacemouseClient class.
"""

import pytest
from unittest.mock import patch, MagicMock

from spacemouse import SpacemouseClient
from spacemouse.exceptions import SpacemouseConnectionError, SpacemouseDeviceNotFoundError


class TestSpacemouseClient:
    """Test cases for SpacemouseClient."""

    def test_client_initialization(self):
        """Test that client initializes correctly."""
        client = SpacemouseClient()
        assert client.device_id is None
        assert client.config == {}
        assert not client.is_connected()

    def test_client_initialization_with_params(self, sample_config):
        """Test client initialization with parameters."""
        device_id = "test_device"
        client = SpacemouseClient(device_id=device_id, config=sample_config)
        
        assert client.device_id == device_id
        assert client.config == sample_config
        assert not client.is_connected()

    def test_successful_connection(self, spacemouse_client):
        """Test successful device connection."""
        result = spacemouse_client.connect()
        
        assert result is True
        assert spacemouse_client.is_connected()

    def test_connection_with_invalid_device(self):
        """Test connection failure with invalid device."""
        client = SpacemouseClient(device_id="invalid")
        
        with pytest.raises(SpacemouseDeviceNotFoundError):
            client.connect()

    def test_disconnect(self, connected_client):
        """Test device disconnection."""
        assert connected_client.is_connected()
        
        connected_client.disconnect()
        
        assert not connected_client.is_connected()

    def test_get_device_info_when_connected(self, connected_client):
        """Test getting device info when connected."""
        info = connected_client.get_device_info()
        
        assert isinstance(info, dict)
        assert "device_id" in info
        assert "status" in info
        assert info["status"] == "connected"

    def test_get_device_info_when_not_connected(self, spacemouse_client):
        """Test getting device info when not connected."""
        with pytest.raises(SpacemouseConnectionError):
            spacemouse_client.get_device_info()

    def test_context_manager(self):
        """Test using client as context manager."""
        with SpacemouseClient() as client:
            assert client.is_connected()
        
        assert not client.is_connected()

    def test_context_manager_with_exception(self):
        """Test context manager handles exceptions properly."""
        try:
            with SpacemouseClient() as client:
                assert client.is_connected()
                raise ValueError("Test exception")
        except ValueError:
            pass
        
        assert not client.is_connected()

    @patch('spacemouse.client.logger')
    def test_logging_on_initialization(self, mock_logger):
        """Test that initialization logs are created."""
        device_id = "test_device"
        SpacemouseClient(device_id=device_id)
        
        mock_logger.info.assert_called()

    @patch('spacemouse.client.logger')
    def test_logging_on_connection(self, mock_logger, spacemouse_client):
        """Test that connection logs are created."""
        spacemouse_client.connect()
        
        assert mock_logger.info.call_count >= 2  # At least connect attempt and success
# Spacemouse SDK

A Python SDK for spacemouse functionality.

## Installation

You can install the package from PyPI:

```bash
pip install spacemouse-sdk
```

Or install from source:

```bash
git clone https://github.com/simonfall/spacemouse.git
cd spacemouse
pip install -e .
```

## Usage

```python
import spacemouse

# Example usage
client = spacemouse.SpacemouseClient()
client.connect()
```

## Development

### Setup Development Environment

1. Clone the repository:
```bash
git clone https://github.com/simonfall/spacemouse.git
cd spacemouse
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install development dependencies:
```bash
pip install -e ".[dev]"
```

### Running Tests

```bash
pytest
```

### Code Formatting

```bash
black src tests
isort src tests
```

### Type Checking

```bash
mypy src
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a list of changes.
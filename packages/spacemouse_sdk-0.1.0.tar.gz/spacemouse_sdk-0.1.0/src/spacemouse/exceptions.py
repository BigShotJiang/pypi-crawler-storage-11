"""
Custom exceptions for the spacemouse package.
"""


class SpacemouseError(Exception):
    """Base exception class for spacemouse package."""
    pass


class SpacemouseConnectionError(SpacemouseError):
    """Exception raised when connection to spacemouse device fails."""
    pass


class SpacemouseDeviceNotFoundError(SpacemouseError):
    """Exception raised when spacemouse device is not found."""
    pass


class SpacemouseConfigurationError(SpacemouseError):
    """Exception raised when spacemouse configuration is invalid."""
    pass
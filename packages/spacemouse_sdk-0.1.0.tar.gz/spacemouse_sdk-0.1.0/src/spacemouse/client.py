"""
Main client class for spacemouse functionality.
"""

from typing import Optional, Dict, Any
import logging

from .exceptions import SpacemouseConnectionError, SpacemouseDeviceNotFoundError

logger = logging.getLogger(__name__)


class SpacemouseClient:
    """
    Main client for interacting with spacemouse devices.
    
    This class provides the primary interface for connecting to and
    controlling spacemouse devices.
    """

    def __init__(self, device_id: Optional[str] = None, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the SpacemouseClient.
        
        Args:
            device_id: Optional device identifier to connect to specific device
            config: Optional configuration dictionary for client settings
        """
        self.device_id = device_id
        self.config = config or {}
        self._connected = False
        self._device = None
        
        logger.info(f"Initialized SpacemouseClient with device_id: {device_id}")

    def connect(self) -> bool:
        """
        Connect to the spacemouse device.
        
        Returns:
            bool: True if connection successful, False otherwise
            
        Raises:
            SpacemouseConnectionError: If connection fails
            SpacemouseDeviceNotFoundError: If device not found
        """
        try:
            logger.info("Attempting to connect to spacemouse device...")
            
            # TODO: Implement actual device connection logic
            # This is a placeholder implementation
            
            if self.device_id == "invalid":
                raise SpacemouseDeviceNotFoundError(f"Device {self.device_id} not found")
            
            self._connected = True
            logger.info("Successfully connected to spacemouse device")
            return True
            
        except SpacemouseDeviceNotFoundError:
            # Re-raise device not found errors as-is
            raise
        except Exception as e:
            logger.error(f"Failed to connect to spacemouse device: {e}")
            raise SpacemouseConnectionError(f"Connection failed: {e}") from e

    def disconnect(self) -> None:
        """Disconnect from the spacemouse device."""
        if self._connected:
            logger.info("Disconnecting from spacemouse device...")
            self._connected = False
            self._device = None
            logger.info("Disconnected from spacemouse device")

    def is_connected(self) -> bool:
        """Check if client is connected to a device."""
        return self._connected

    def get_device_info(self) -> Dict[str, Any]:
        """
        Get information about the connected device.
        
        Returns:
            dict: Device information
            
        Raises:
            SpacemouseConnectionError: If not connected to a device
        """
        if not self._connected:
            raise SpacemouseConnectionError("Not connected to any device")
        
        # TODO: Implement actual device info retrieval
        return {
            "device_id": self.device_id or "default",
            "status": "connected",
            "version": "1.0.0"
        }

    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.disconnect()
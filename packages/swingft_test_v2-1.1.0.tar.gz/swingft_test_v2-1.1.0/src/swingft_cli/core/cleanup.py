"""임시 파일 정리 모듈"""
import os
import shutil
from .tui import _trace


import os
import tempfile
import shutil
import importlib
import importlib.resources as resources

# optional fallback (deprecated) but useful
try:
    import pkg_resources
except Exception:
    pkg_resources = None

def get_package_dir_or_extract(package: str) -> str:
    """
    package (예: "swingft_cli.Obfuscation_Pipeline")에 대해
    - 가능하면 실제 파일시스템상의 디렉터리 경로를 반환
    - 그렇지 않으면 패키지 내용을 임시 디렉터리에 풀어 그 경로를 반환
    호출자(사용자)는 임시 디렉터리를 지울 책임이 있음(필요하면 반환값과 함께 bool 표시).
    """
    # 0) 패키지 import 확인
    try:
        importlib.import_module(package)
    except ModuleNotFoundError as e:
        raise FileNotFoundError(f"패키지 '{package}'를 찾을 수 없습니다.") from e

    # 1) importlib.resources.files (Python 3.9+)
    files_api = getattr(resources, "files", None)
    if files_api is not None:
        try:
            trav = resources.files(package)  # Traversable
            # Traversable을 문자열로 바꾸면, 패키지가 디스크에 풀려 있으면 디렉터리 경로가 된다
            candidate = str(trav)
            if os.path.isdir(candidate):
                return candidate
        except Exception:
            # 무시하고 다음으로
            pass

    # 2) pkg_resources fallback (경우에 따라 설치 경로 반환)
    if pkg_resources is not None:
        try:
            candidate = pkg_resources.resource_filename(package, "")
            if os.path.isdir(candidate):
                return candidate
        except Exception:
            pass

    # 3) 최종: 패키지의 모든 리소스를 임시 디렉터리로 추출
    temp_dir = tempfile.mkdtemp(prefix=f"{package.replace('.', '_')}_")
    def _extract(pkg, target_dir):
        for name in resources.contents(pkg):
            if name.startswith("__"):
                continue
            # 하위 패키지인지 시도
            full_sub = f"{pkg}.{name}"
            is_pkg = False
            try:
                importlib.import_module(full_sub)
                is_pkg = True
            except ModuleNotFoundError:
                is_pkg = False
            if is_pkg:
                subdir = os.path.join(target_dir, name)
                os.makedirs(subdir, exist_ok=True)
                _extract(full_sub, subdir)
            else:
                # 리소스 파일 읽어서 씀 (binary)
                try:
                    data = resources.read_binary(pkg, name)
                except (FileNotFoundError, IsADirectoryError):
                    continue
                out_path = os.path.join(target_dir, name)
                os.makedirs(os.path.dirname(out_path), exist_ok=True)
                with open(out_path, "wb") as fo:
                    fo.write(data)

    _extract(package, temp_dir)
    return temp_dir

def cleanup_before_obfuscation(output_path: str) -> None:
    package = "swingft_cli.Obfuscation_Pipeline"
    # 이 리턴값이 '패키지 루트 디렉터리'가 된다 (디스크 경로 또는 임시 추출 디렉터리)
    try:
        pipeline_dir = get_package_dir_or_extract(package)
    except FileNotFoundError:
        print("[ERROR] 패키지를 찾을 수 없습니다:", package)
        raise

    # 이제 안전하게 AST/output 경로를 얻을 수 있음
    pipeline_path = os.path.join(pipeline_dir, "obf_pipeline.py")
    ast_output_dir = os.path.join(pipeline_dir, "AST", "output")

    """난독화 시작 전 임시 파일 정리 (obfuscate_cmd.py용)"""
    try:
        # 프로젝트 루트 디렉토리
        project_root = os.getcwd()
        # Obfuscation_Pipeline 디렉토리
        pipeline_dir = pipeline_dir
        
        # AST/output 디렉토리 삭제
        ast_output = os.path.join(pipeline_dir, "AST", "output")
        if os.path.isdir(ast_output):
            shutil.rmtree(ast_output)
        
        # Mapping/output 디렉토리 삭제
        mapping_output = os.path.join(pipeline_dir, "Mapping", "output")
        if os.path.isdir(mapping_output):
            shutil.rmtree(mapping_output)
        
        # obf_project_dir_cfg 디렉토리 삭제
        obf_project_dir_cfg = os.path.join(os.path.dirname(output_path), "cfg")
        if os.path.isdir(obf_project_dir_cfg):
            shutil.rmtree(obf_project_dir_cfg)
        
        # 루트 .swingft 폴더 삭제
        swingft_dir = os.path.join(project_root, ".swingft")
        if os.path.isdir(swingft_dir):
            shutil.rmtree(swingft_dir)
        
        # externals/obfuscation-analyzer/analysis_output 디렉토리 삭제
        analyzer_output_dir = os.path.join(project_root, "externals", "obfuscation-analyzer", "analysis_output")
        if os.path.isdir(analyzer_output_dir):
            shutil.rmtree(analyzer_output_dir)
        
        # String_Encryption 디렉토리의 JSON 파일들 삭제
        se_dir = os.path.join(pipeline_dir, "String_Encryption")
        se_strings = os.path.join(se_dir, "strings.json")
        if os.path.exists(se_strings):
            os.remove(se_strings)
        se_targets = os.path.join(se_dir, "targets_swift_paths.json")
        if os.path.exists(se_targets):
            os.remove(se_targets)
        
        # 루트 디렉토리의 JSON 파일들 삭제
        root_json_files = [
            "mapping_result.json",
            "mapping_result_s.json",
            "type_info.json",
            "swift_file_list.txt",
            "targets_swift_paths.json"
        ]
        for filename in root_json_files:
            file_path = os.path.join(pipeline_dir, filename)
            if os.path.exists(file_path):
                os.remove(file_path)
        
        _trace("이전 임시 파일 정리 완료")
    except Exception as e:
        _trace("임시 파일 정리 실패 (계속 진행): %s", e)


"""
String data files.
"""

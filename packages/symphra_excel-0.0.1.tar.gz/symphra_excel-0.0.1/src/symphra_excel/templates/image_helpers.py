"""
图片处理辅助函数模块
支持 {% img %} 语法
"""

import re
from typing import Any, Dict


def process_img_tags(text: str, context: Dict[str, Any], image_helper) -> str:
    """
    处理 {% img variable_name %} 语法，转换为 insert_image 调用

    参数:
        text: 包含 {% img %} 标记的文本
        context: 模板上下文
        image_helper: insert_image 辅助函数

    返回:
        替换后的文本
    """
    if not isinstance(text, str):
        return text

    # 匹配 {% img variable_name %} 或 {% img variable_name, width=80, height=40 %}
    pattern = r"{%\s*img\s+([^,\s]+)(?:\s*,\s*(.+?))?\s*%}"

    def replacer(match):
        var_name = match.group(1).strip()
        params_str = match.group(2)

        # 从上下文获取图片路径
        image_path = context.get(var_name)
        if not image_path:
            return ""

        # 解析参数
        kwargs = {}
        if params_str:
            # 解析 width=80, height=40 格式
            for param in params_str.split(","):
                if "=" in param:
                    key, value = param.split("=", 1)
                    key = key.strip()
                    value = value.strip()
                    # 尝试转换为数字
                    try:
                        value = int(value)
                    except ValueError:
                        pass
                    kwargs[key] = value

        # 调用 insert_image 辅助函数
        return image_helper(image_path, **kwargs)

    return re.sub(pattern, replacer, text)

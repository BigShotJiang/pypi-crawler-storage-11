"""
恢复原始的 SpreadsheetDrawing 行为
不进行任何命名空间修复以确保WPS兼容性
"""



# 不应用任何修复，保持原始行为
def apply_drawing_fix():
    """不应用任何修复，保持原始行为以确保WPS兼容性"""
    pass


def remove_drawing_fix():
    """不移除任何修复，因为没有应用修复"""
    pass

"""
Symphra Excel - 面向Python 3.11+的高性能Excel处理库

一个全面的Excel处理库，提供高性能的Excel文件操作功能，
支持模板、样式、图像和异步操作。
"""

__version__ = "0.1.0"
__author__ = "getaix"
__email__ = "develop@getaix.tech"

# 核心模块导入
from .core.workbook import Workbook
from .core.worksheet import Worksheet
from .templates.template_workbook import TemplateWorkbook
from .styles.cell_style import CellStyle, Color
from .utils.exceptions import (
    FileFormatError,
    SymphraExcelError,
    TemplateError,
    ValidationError,
)

# 可选模块导入（可能失败，但不影响核心功能）
try:
    from .async_support import (
        AsyncBatchProcessor,  # noqa: F401
        AsyncWorkbook,  # noqa: F401
        AsyncWorksheet,  # noqa: F401
    )

    _has_async = True
except ImportError:
    _has_async = False

try:
    from .styles.predefined_styles import Colors, PredefinedStyles  # noqa: F401

    _has_styles = True
except ImportError:
    _has_styles = False

# 基础模块导入（可能有依赖问题）
try:
    from .memory_ops import (
        InMemoryTemplateWorkbook,  # noqa: F401
        InMemoryWorkbook,  # noqa: F401
        MemoryOptimizedWorkbook,  # noqa: F401
    )

    _has_memory = True
except ImportError:
    _has_memory = False

__all__ = [
    "Workbook",
    "Worksheet",
    "TemplateWorkbook",
    "CellStyle",
    "Color",
    "SymphraExcelError",
    "FileFormatError",
    "TemplateError",
    "ValidationError",
]

if _has_async:
    __all__.extend(
        [
            "AsyncWorkbook",
            "AsyncWorksheet",
            "AsyncBatchProcessor",
        ]
    )

if _has_styles:
    __all__.extend(
        [
            "Colors",
            "PredefinedStyles",
        ]
    )

if _has_memory:
    __all__.extend(
        [
            "InMemoryWorkbook",
            "InMemoryTemplateWorkbook",
            "MemoryOptimizedWorkbook",
        ]
    )

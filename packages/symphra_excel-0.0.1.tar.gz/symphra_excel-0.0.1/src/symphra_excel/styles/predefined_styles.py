"""
Symphra Excel库的预定义样式
"""

from ..styles.cell_style import CellStyle, Color


class PredefinedStyles:
    """预定义单元格样式集合"""

    @staticmethod
    def header_style() -> CellStyle:
        """创建带有粗体字体和背景色的标题样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=12, bold=True, color=Color.WHITE)
            .set_fill(pattern="solid", fg_color=Color.LIGHT_BLUE)
            .set_alignment(horizontal="center", vertical="center")
            .set_border(bottom="thin", bottom_color=Color.BLACK)
        )

    @staticmethod
    def title_style() -> CellStyle:
        """创建带有大号粗体字体的标题样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=16, bold=True)
            .set_alignment(horizontal="center", vertical="center")
        )

    @staticmethod
    def subtitle_style() -> CellStyle:
        """创建带有中等粗体字体的副标题样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=14, bold=True)
            .set_alignment(horizontal="center", vertical="center")
        )

    @staticmethod
    def data_style() -> CellStyle:
        """创建标准数据单元格样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11)
            .set_alignment(horizontal="left", vertical="center")
            .set_border(bottom="hair", bottom_color="CCCCCC")
        )

    @staticmethod
    def number_style() -> CellStyle:
        """创建带有右对齐的数字数据样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11)
            .set_alignment(horizontal="right", vertical="center")
            .set_number_format("#,##0.00")
            .set_border(bottom="hair", bottom_color="CCCCCC")
        )

    @staticmethod
    def currency_style() -> CellStyle:
        """创建带有会计格式的货币样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11)
            .set_alignment(horizontal="right", vertical="center")
            .set_number_format('_($* #,##0.00_);_($* (#,##0.00);_($* "-"??_);_(@_)')
            .set_border(bottom="hair", bottom_color="CCCCCC")
        )

    @staticmethod
    def date_style() -> CellStyle:
        """创建带有日期格式的日期样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11)
            .set_alignment(horizontal="center", vertical="center")
            .set_number_format("mm/dd/yyyy")
            .set_border(bottom="hair", bottom_color="CCCCCC")
        )

    @staticmethod
    def percentage_style() -> CellStyle:
        """创建百分比样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11)
            .set_alignment(horizontal="right", vertical="center")
            .set_number_format("0.00%")
            .set_border(bottom="hair", bottom_color="CCCCCC")
        )

    @staticmethod
    def error_style() -> CellStyle:
        """创建带有红色背景的错误样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11, color="FFFFFF")
            .set_fill(pattern="solid", fg_color="FF0000")
            .set_alignment(horizontal="center", vertical="center")
        )

    @staticmethod
    def warning_style() -> CellStyle:
        """创建带有黄色背景的警告样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11, color="000000")
            .set_fill(pattern="solid", fg_color="FFFF00")
            .set_alignment(horizontal="center", vertical="center")
        )

    @staticmethod
    def success_style() -> CellStyle:
        """创建带有绿色背景的成功样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11, color="FFFFFF")
            .set_fill(pattern="solid", fg_color="00FF00")
            .set_alignment(horizontal="center", vertical="center")
        )

    @staticmethod
    def info_style() -> CellStyle:
        """创建带有蓝色背景的信息样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11, color="FFFFFF")
            .set_fill(pattern="solid", fg_color="0080FF")
            .set_alignment(horizontal="center", vertical="center")
        )

    @staticmethod
    def total_style() -> CellStyle:
        """创建带有粗体字体和顶部边框的总计/摘要样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11, bold=True)
            .set_alignment(horizontal="right", vertical="center")
            .set_border(
                top="medium", top_color="000000", bottom="double", bottom_color="000000"
            )
        )

    @staticmethod
    def alternating_row_style() -> CellStyle:
        """创建带有浅灰色背景的交替行样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11)
            .set_fill(pattern="solid", fg_color="F2F2F2")
            .set_alignment(horizontal="left", vertical="center")
        )

    @staticmethod
    def hyperlink_style() -> CellStyle:
        """创建带有蓝色下划线字体的超链接样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11, color="0000FF", underline="single")
            .set_alignment(horizontal="left", vertical="center")
        )

    @staticmethod
    def note_style() -> CellStyle:
        """创建带有斜体字体的注释/评论样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=10, italic=True, color="808080")
            .set_alignment(horizontal="left", vertical="top", wrap_text=True)
        )

    @staticmethod
    def highlight_style() -> CellStyle:
        """创建带有亮黄色背景的高亮样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11, bold=True)
            .set_fill(pattern="solid", fg_color=Color.YELLOW)
            .set_alignment(horizontal="center", vertical="center")
        )

    @staticmethod
    def border_style() -> CellStyle:
        """创建带有所有边框的边框样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11)
            .set_alignment(horizontal="center", vertical="center")
            .set_border(
                left="thin",
                right="thin",
                top="thin",
                bottom="thin",
                left_color="000000",
                right_color="000000",
                top_color="000000",
                bottom_color="000000",
            )
        )

    @staticmethod
    def grid_style() -> CellStyle:
        """创建带有浅色边框的网格样式"""
        return (
            CellStyle()
            .set_font(name="Arial", size=11)
            .set_alignment(horizontal="center", vertical="center")
            .set_border(
                left="hair",
                right="hair",
                top="hair",
                bottom="hair",
                left_color="D3D3D3",
                right_color="D3D3D3",
                top_color="D3D3D3",
                bottom_color="D3D3D3",
            )
        )


# 预定义颜色常量
class Colors:
    """常用颜色常量"""

    # 基本颜色
    BLACK = Color.from_hex("000000")
    WHITE = Color.from_hex("FFFFFF")
    RED = Color.from_hex("FF0000")
    GREEN = Color.from_hex("00FF00")
    BLUE = Color.from_hex("0000FF")
    YELLOW = Color.from_hex("FFFF00")
    CYAN = Color.from_hex("00FFFF")
    MAGENTA = Color.from_hex("FF00FF")

    # 灰度色
    GRAY_25 = Color.from_hex("F2F2F2")
    GRAY_50 = Color.from_hex("D9D9D9")
    GRAY_75 = Color.from_hex("A6A6A6")
    GRAY = Color.from_hex("808080")
    DARK_GRAY = Color.from_hex("404040")

    # 主题颜色
    LIGHT_BLUE = Color.from_hex("E1F5FE")
    BLUE_GRAY = Color.from_hex("4472C4")
    DARK_BLUE = Color.from_hex("002060")
    LIGHT_GREEN = Color.from_hex("E8F5E8")
    DARK_GREEN = Color.from_hex("548235")
    LIGHT_YELLOW = Color.from_hex("FFF2CC")
    DARK_YELLOW = Color.from_hex("BF9000")
    LIGHT_RED = Color.from_hex("FFE6E6")
    DARK_RED = Color.from_hex("C5504B")

    # 状态颜色
    SUCCESS = Color.from_hex("00B050")
    WARNING = Color.from_hex("FFC000")
    ERROR = Color.from_hex("FF0000")
    INFO = Color.from_hex("00B0F0")

    # 强调色
    ACCENT_1 = Color.from_hex("5B9BD5")
    ACCENT_2 = Color.from_hex("ED7D31")
    ACCENT_3 = Color.from_hex("A5A5A5")
    ACCENT_4 = Color.from_hex("FFC000")
    ACCENT_5 = Color.from_hex("4472C4")
    ACCENT_6 = Color.from_hex("70AD47")

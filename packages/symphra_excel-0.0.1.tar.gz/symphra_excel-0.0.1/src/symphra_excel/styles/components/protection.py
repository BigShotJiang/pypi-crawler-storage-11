"""
保护样式组件模块
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict

from openpyxl.cell import Cell as OpenpyxlCell
from openpyxl.styles import Protection

from .base import BaseStyleComponent


@dataclass
class ProtectionStyle(BaseStyleComponent):
    """
    保护样式组件

    管理单元格保护相关的样式属性:
    - 锁定: 工作表保护时是否锁定单元格
    - 隐藏: 是否隐藏公式
    """

    locked: bool | None = None
    hidden: bool | None = None

    def set(
        self,
        locked: bool | None = None,
        hidden: bool | None = None,
    ) -> ProtectionStyle:
        """
        设置保护属性

        参数:
            locked: 是否锁定单元格
            hidden: 是否隐藏公式

        返回:
            self, 支持链式调用
        """
        if locked is not None:
            self.locked = locked
        if hidden is not None:
            self.hidden = hidden
        return self

    def apply_to_cell(self, cell: OpenpyxlCell) -> None:
        """
        应用保护样式到单元格

        参数:
            cell: openpyxl单元格对象
        """
        if self.locked is not None or self.hidden is not None:
            cell.protection = Protection(
                locked=self.locked if self.locked is not None else True,
                hidden=self.hidden if self.hidden is not None else False,
            )

    def to_dict(self) -> Dict[str, Any]:
        """
        序列化为字典

        返回:
            包含保护属性的字典
        """
        result: Dict[str, Any] = {}

        if self.locked is not None:
            result["locked"] = self.locked
        if self.hidden is not None:
            result["hidden"] = self.hidden

        return result

    def from_dict(self, data: Dict[str, Any]) -> None:
        """
        从字典反序列化

        参数:
            data: 包含保护属性的字典
        """
        if "locked" in data:
            self.locked = data["locked"]
        if "hidden" in data:
            self.hidden = data["hidden"]

    def copy(self) -> ProtectionStyle:
        """
        深拷贝保护样式

        返回:
            新的ProtectionStyle实例
        """
        return ProtectionStyle(
            locked=self.locked,
            hidden=self.hidden,
        )

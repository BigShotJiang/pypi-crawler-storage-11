"""
对齐样式组件模块
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict

from openpyxl.cell import Cell as OpenpyxlCell
from openpyxl.styles import Alignment

from .base import BaseStyleComponent


@dataclass
class AlignmentStyle(BaseStyleComponent):
    """
    对齐样式组件

    管理单元格对齐相关的样式属性:
    - 水平对齐
    - 垂直对齐
    - 文本旋转
    - 自动换行
    - 缩小字体填充
    - 缩进
    - 阅读顺序
    """

    horizontal: str | None = (
        None  # 'general', 'left', 'center', 'right', 'fill', 'justify', etc.
    )
    vertical: str | None = None  # 'top', 'center', 'bottom', 'justify', 'distributed'
    text_rotation: int | None = None  # 0-180度
    wrap_text: bool | None = None
    shrink_to_fit: bool | None = None
    indent: int | None = None
    reading_order: int | None = None  # 0=context, 1=left-to-right, 2=right-to-left

    def set(
        self,
        horizontal: str | None = None,
        vertical: str | None = None,
        text_rotation: int | None = None,
        wrap_text: bool | None = None,
        shrink_to_fit: bool | None = None,
        indent: int | None = None,
        reading_order: int | None = None,
    ) -> AlignmentStyle:
        """
        批量设置对齐属性

        参数:
            horizontal: 水平对齐方式
            vertical: 垂直对齐方式
            text_rotation: 文本旋转角度 (0-180)
            wrap_text: 是否自动换行
            shrink_to_fit: 是否缩小字体以适应单元格
            indent: 缩进级别
            reading_order: 阅读顺序

        返回:
            self, 支持链式调用
        """
        if horizontal is not None:
            self.horizontal = horizontal
        if vertical is not None:
            self.vertical = vertical
        if text_rotation is not None:
            self.text_rotation = text_rotation
        if wrap_text is not None:
            self.wrap_text = wrap_text
        if shrink_to_fit is not None:
            self.shrink_to_fit = shrink_to_fit
        if indent is not None:
            self.indent = indent
        if reading_order is not None:
            self.reading_order = reading_order
        return self

    def apply_to_cell(self, cell: OpenpyxlCell) -> None:
        """
        应用对齐样式到单元格

        参数:
            cell: openpyxl单元格对象
        """
        if not self.has_settings():
            return

        alignment_kwargs: Dict[str, Any] = {}

        if self.horizontal is not None:
            alignment_kwargs["horizontal"] = self.horizontal
        if self.vertical is not None:
            alignment_kwargs["vertical"] = self.vertical
        if self.text_rotation is not None:
            alignment_kwargs["textRotation"] = self.text_rotation
        if self.wrap_text is not None:
            alignment_kwargs["wrapText"] = self.wrap_text
        if self.shrink_to_fit is not None:
            alignment_kwargs["shrinkToFit"] = self.shrink_to_fit
        if self.indent is not None:
            alignment_kwargs["indent"] = self.indent
        if self.reading_order is not None:
            alignment_kwargs["readingOrder"] = self.reading_order

        if alignment_kwargs:
            cell.alignment = Alignment(**alignment_kwargs)

    def to_dict(self) -> Dict[str, Any]:
        """
        序列化为字典

        返回:
            包含所有非None对齐属性的字典
        """
        result: Dict[str, Any] = {}

        if self.horizontal is not None:
            result["horizontal"] = self.horizontal
        if self.vertical is not None:
            result["vertical"] = self.vertical
        if self.text_rotation is not None:
            result["text_rotation"] = self.text_rotation
        if self.wrap_text is not None:
            result["wrap_text"] = self.wrap_text
        if self.shrink_to_fit is not None:
            result["shrink_to_fit"] = self.shrink_to_fit
        if self.indent is not None:
            result["indent"] = self.indent
        if self.reading_order is not None:
            result["reading_order"] = self.reading_order

        return result

    def from_dict(self, data: Dict[str, Any]) -> None:
        """
        从字典反序列化

        参数:
            data: 包含对齐属性的字典
        """
        if "horizontal" in data:
            self.horizontal = data["horizontal"]
        if "vertical" in data:
            self.vertical = data["vertical"]
        if "text_rotation" in data:
            self.text_rotation = data["text_rotation"]
        if "wrap_text" in data:
            self.wrap_text = data["wrap_text"]
        if "shrink_to_fit" in data:
            self.shrink_to_fit = data["shrink_to_fit"]
        if "indent" in data:
            self.indent = data["indent"]
        if "reading_order" in data:
            self.reading_order = data["reading_order"]

    def copy(self) -> AlignmentStyle:
        """
        深拷贝对齐样式

        返回:
            新的AlignmentStyle实例
        """
        return AlignmentStyle(
            horizontal=self.horizontal,
            vertical=self.vertical,
            text_rotation=self.text_rotation,
            wrap_text=self.wrap_text,
            shrink_to_fit=self.shrink_to_fit,
            indent=self.indent,
            reading_order=self.reading_order,
        )

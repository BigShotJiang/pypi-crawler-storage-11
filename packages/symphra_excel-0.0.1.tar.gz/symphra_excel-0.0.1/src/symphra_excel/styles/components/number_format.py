"""
数字格式样式组件模块
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict

from openpyxl.cell import Cell as OpenpyxlCell

from .base import BaseStyleComponent


@dataclass
class NumberFormatStyle(BaseStyleComponent):
    """
    数字格式样式组件

    管理单元格的数字格式属性,例如:
    - 日期格式: 'yyyy-mm-dd'
    - 货币格式: '$#,##0.00'
    - 百分比格式: '0.00%'
    - 自定义格式
    """

    format_code: str | None = None

    def set(self, format_code: str) -> NumberFormatStyle:
        """
        设置数字格式代码

        参数:
            format_code: 数字格式代码字符串

        返回:
            self, 支持链式调用
        """
        self.format_code = format_code
        return self

    def apply_to_cell(self, cell: OpenpyxlCell) -> None:
        """
        应用数字格式到单元格

        参数:
            cell: openpyxl单元格对象
        """
        if self.format_code is not None:
            cell.number_format = self.format_code

    def to_dict(self) -> Dict[str, Any]:
        """
        序列化为字典

        返回:
            包含数字格式的字典
        """
        result: Dict[str, Any] = {}

        if self.format_code is not None:
            result["format_code"] = self.format_code

        return result

    def from_dict(self, data: Dict[str, Any]) -> None:
        """
        从字典反序列化

        参数:
            data: 包含数字格式属性的字典
        """
        if "format_code" in data:
            self.format_code = data["format_code"]

    def copy(self) -> NumberFormatStyle:
        """
        深拷贝数字格式样式

        返回:
            新的NumberFormatStyle实例
        """
        return NumberFormatStyle(format_code=self.format_code)

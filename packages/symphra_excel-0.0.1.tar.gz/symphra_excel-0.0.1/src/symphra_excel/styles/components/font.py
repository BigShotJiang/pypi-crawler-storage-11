"""
字体样式组件模块
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict

from openpyxl.cell import Cell as OpenpyxlCell
from openpyxl.styles import Font

from ..color import Color
from .base import BaseStyleComponent


@dataclass
class FontStyle(BaseStyleComponent):
    """
    字体样式组件

    管理所有与字体相关的样式属性,包括:
    - 字体名称和大小
    - 粗体、斜体、下划线、删除线
    - 字体颜色
    - 垂直对齐(上标、下标)
    """

    name: str | None = "Calibri"
    size: float | None = 11
    bold: bool | None = None
    italic: bool | None = None
    underline: str | None = None  # 'single', 'double', etc.
    strikethrough: bool | None = None
    color: Color | None = None
    vert_align: str | None = None  # 'superscript', 'subscript', 'baseline'

    def set(
        self,
        name: str | None = None,
        size: float | None = None,
        bold: bool | None = None,
        italic: bool | None = None,
        underline: str | None = None,
        color: str | Color | None = None,
        strikethrough: bool | None = None,
        vert_align: str | None = None,
    ) -> FontStyle:
        """
        批量设置字体属性

        参数:
            name: 字体名称 (如 "Arial", "宋体")
            size: 字体大小 (磅值)
            bold: 是否粗体
            italic: 是否斜体
            underline: 下划线样式 ('single', 'double' 等)
            color: 字体颜色 (十六进制字符串或Color对象)
            strikethrough: 是否删除线
            vert_align: 垂直对齐 ('superscript', 'subscript', 'baseline')

        返回:
            self, 支持链式调用
        """
        if name is not None:
            self.name = name
        if size is not None:
            self.size = size
        if bold is not None:
            self.bold = bold
        if italic is not None:
            self.italic = italic
        if underline is not None:
            self.underline = underline
        if strikethrough is not None:
            self.strikethrough = strikethrough
        if vert_align is not None:
            self.vert_align = vert_align

        if color is not None:
            self.color = Color.from_hex(color) if isinstance(color, str) else color

        return self

    def apply_to_cell(self, cell: OpenpyxlCell) -> None:
        """
        应用字体样式到单元格

        参数:
            cell: openpyxl单元格对象
        """
        if not self.has_settings():
            return

        font_kwargs: Dict[str, Any] = {}

        if self.name is not None:
            font_kwargs["name"] = self.name
        if self.size is not None:
            font_kwargs["size"] = self.size
        if self.bold is not None:
            font_kwargs["bold"] = self.bold
        if self.italic is not None:
            font_kwargs["italic"] = self.italic
        if self.underline is not None:
            font_kwargs["underline"] = self.underline
        if self.strikethrough is not None:
            font_kwargs["strikethrough"] = self.strikethrough
        if self.color is not None:
            font_kwargs["color"] = self.color.to_openpyxl_color()
        if self.vert_align is not None:
            font_kwargs["vertAlign"] = self.vert_align

        cell.font = Font(**font_kwargs)

    def to_dict(self) -> Dict[str, Any]:
        """
        序列化为字典

        返回:
            包含所有非None字体属性的字典
        """
        result: Dict[str, Any] = {}

        if self.name is not None:
            result["name"] = self.name
        if self.size is not None:
            result["size"] = self.size
        if self.bold is not None:
            result["bold"] = self.bold
        if self.italic is not None:
            result["italic"] = self.italic
        if self.underline is not None:
            result["underline"] = self.underline
        if self.strikethrough is not None:
            result["strikethrough"] = self.strikethrough
        if self.color is not None:
            result["color"] = self.color.rgb if self.color.rgb else None
        if self.vert_align is not None:
            result["vert_align"] = self.vert_align

        return result

    def from_dict(self, data: Dict[str, Any]) -> None:
        """
        从字典反序列化

        参数:
            data: 包含字体属性的字典
        """
        if "name" in data:
            self.name = data["name"]
        if "size" in data:
            self.size = data["size"]
        if "bold" in data:
            self.bold = data["bold"]
        if "italic" in data:
            self.italic = data["italic"]
        if "underline" in data:
            self.underline = data["underline"]
        if "strikethrough" in data:
            self.strikethrough = data["strikethrough"]
        if "color" in data and data["color"]:
            self.color = Color(rgb=data["color"])
        if "vert_align" in data:
            self.vert_align = data["vert_align"]

    def copy(self) -> FontStyle:
        """
        深拷贝字体样式

        返回:
            新的FontStyle实例
        """
        return FontStyle(
            name=self.name,
            size=self.size,
            bold=self.bold,
            italic=self.italic,
            underline=self.underline,
            strikethrough=self.strikethrough,
            color=(
                Color(
                    rgb=self.color.rgb,
                    indexed=self.color.indexed,
                    auto=self.color.auto,
                    theme=self.color.theme,
                    tint=self.color.tint,
                )
                if self.color
                else None
            ),
            vert_align=self.vert_align,
        )

"""
样式组件基础类模块
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict

from openpyxl.cell import Cell as OpenpyxlCell


class BaseStyleComponent(ABC):
    """
    样式组件基类

    所有样式组件必须继承此基类并实现其抽象方法。
    每个组件负责管理一个样式维度(字体、填充、边框等)。
    """

    @abstractmethod
    def apply_to_cell(self, cell: OpenpyxlCell) -> None:
        """
        应用样式到openpyxl单元格

        参数:
            cell: openpyxl单元格对象
        """
        pass

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """
        序列化为字典

        返回:
            包含所有非None属性的字典
        """
        pass

    @abstractmethod
    def from_dict(self, data: Dict[str, Any]) -> None:
        """
        从字典反序列化

        参数:
            data: 包含样式属性的字典
        """
        pass

    @abstractmethod
    def copy(self) -> BaseStyleComponent:
        """
        深拷贝组件

        返回:
            组件的深拷贝
        """
        pass

    def has_settings(self) -> bool:
        """
        检查组件是否有任何设置

        返回:
            如果有任何设置则返回True,否则False
        """
        return bool(self.to_dict())

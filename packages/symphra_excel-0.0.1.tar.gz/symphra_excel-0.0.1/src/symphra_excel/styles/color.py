"""
颜色类模块
"""

from __future__ import annotations

from typing import Any, ClassVar

from openpyxl.styles import Color as OpenpyxlColor


class Color:
    """
    Excel样式的颜色表示

    支持多种颜色定义方式:
    - RGB颜色 (ARGB格式)
    - 索引颜色
    - 主题颜色
    - 自动颜色
    """

    # 颜色常量 - 类型注解仅声明,实际赋值在类定义后
    RED: ClassVar[Color]
    YELLOW: ClassVar[Color]
    BLACK: ClassVar[Color]
    LIGHT_BLUE: ClassVar[Color]
    WHITE: ClassVar[Color]

    def __init__(
        self,
        rgb: str | None = None,
        indexed: int | None = None,
        auto: bool | None = None,
        theme: int | None = None,
        tint: float | None = None,
    ) -> None:
        """
        初始化颜色

        参数:
            rgb: RGB颜色值 (例如: 'FFFF0000' 表示红色, ARGB格式)
            indexed: 索引颜色 (0-63)
            auto: 自动颜色标志
            theme: 主题颜色索引
            tint: 颜色色调 (-1.0 到 1.0)
        """
        self.rgb = rgb
        self.indexed = indexed
        self.auto = auto
        self.theme = theme
        self.tint = tint

    def to_openpyxl_color(self) -> OpenpyxlColor:
        """
        转换为openpyxl Color对象

        返回:
            openpyxl的Color对象
        """
        # openpyxl不接受None值,需要过滤掉
        kwargs: dict[str, Any] = {}
        if self.rgb is not None:
            kwargs["rgb"] = self.rgb
        if self.indexed is not None:
            kwargs["indexed"] = self.indexed
        if self.auto is not None:
            kwargs["auto"] = self.auto
        if self.theme is not None:
            kwargs["theme"] = self.theme
        if self.tint is not None:
            kwargs["tint"] = self.tint
        return OpenpyxlColor(**kwargs)

    @classmethod
    def from_hex(cls, hex_color: str) -> Color:
        """
        从十六进制字符串创建颜色

        参数:
            hex_color: 十六进制颜色字符串 (例如: '#FF0000' 或 'FF0000')

        返回:
            Color对象
        """
        hex_color = hex_color.lstrip("#")
        if len(hex_color) == 6:
            hex_color = "FF" + hex_color  # 添加透明度通道
        return cls(rgb=hex_color.upper())

    @classmethod
    def from_rgb(cls, r: int, g: int, b: int, a: int = 255) -> Color:
        """
        从RGB值创建颜色

        参数:
            r: 红色分量 (0-255)
            g: 绿色分量 (0-255)
            b: 蓝色分量 (0-255)
            a: 透明度分量 (0-255, 默认255)

        返回:
            Color对象
        """
        return cls(rgb=f"{a:02X}{r:02X}{g:02X}{b:02X}")

    def __eq__(self, other: object) -> bool:
        """颜色相等性比较"""
        if not isinstance(other, Color):
            return False
        return (
            self.rgb == other.rgb
            and self.indexed == other.indexed
            and self.auto == other.auto
            and self.theme == other.theme
            and self.tint == other.tint
        )

    def __repr__(self) -> str:
        """颜色的字符串表示"""
        if self.rgb:
            return f"Color(rgb='{self.rgb}')"
        elif self.indexed is not None:
            return f"Color(indexed={self.indexed})"
        elif self.theme is not None:
            return f"Color(theme={self.theme})"
        return "Color()"


# 初始化颜色常量
Color.RED = Color.from_hex("FF0000")
Color.YELLOW = Color.from_hex("FFFF00")
Color.BLACK = Color.from_hex("000000")
Color.LIGHT_BLUE = Color.from_hex("ADD8E6")
Color.WHITE = Color.from_hex("FFFFFF")

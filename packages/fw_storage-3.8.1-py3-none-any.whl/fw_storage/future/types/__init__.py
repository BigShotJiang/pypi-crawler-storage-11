"""Storage type implementations."""

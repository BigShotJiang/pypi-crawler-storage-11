"""
AI-Powered Natural Language Query Engine for Outhad_Edge.

This module provides natural language query capabilities using LLMs (GPT-4, Claude)
with RAG architecture, vector embeddings, and semantic caching.

Example:
    >>> from outhad_edge import Eventstream
    >>> stream = Eventstream(df)
    >>> nlq = stream.nlq(model="gpt-4")
    >>> result = nlq.ask("What is the conversion rate?")
    >>> print(result['answer'])
"""

__version__ = "0.1.0"

# Import guard for optional dependencies
try:
    from .nlq_engine import NaturalLanguageQuery
    from .semantic_layer import SemanticLayer, ColumnMetadata, TableMetadata
    from .vector_store import VectorStore, initialize_vector_store
    from .code_executor import CodeExecutor
    from .cache_manager import CacheManager
    from .example_queries import ExampleQueryLibrary, get_all_tags
    from .initialization import (
        initialize_nlq_system,
        reinitialize_vector_store,
        check_nlq_status
    )
    # Modular LLM agent and class-based prompts
    from .llm_agent import LLMAgent
    from .prompt_templates import PromptTemplates
    # Code validation and safe execution
    from .code_validator import CodeValidator
    # Monitoring and observability
    from .monitoring import NLQMonitoring

    __all__ = [
        "NaturalLanguageQuery",
        "SemanticLayer",
        "ColumnMetadata",
        "TableMetadata",
        "VectorStore",
        "initialize_vector_store",
        "CodeExecutor",
        "CacheManager",
        "ExampleQueryLibrary",
        "get_all_tags",
        "initialize_nlq_system",
        "reinitialize_vector_store",
        "check_nlq_status",
        "LLMAgent",
        "PromptTemplates",
        "CodeValidator",
        "NLQMonitoring",
    ]

    AI_AVAILABLE = True

except ImportError as e:
    AI_AVAILABLE = False
    _import_error = e

    def _raise_import_error(*args, **kwargs):
        """Raise helpful error message when AI dependencies are missing."""
        raise ImportError(
            "AI features require additional dependencies. "
            "Install them with:\n\n"
            "  pip install outhad_edge[ai]\n\n"
            "Or install manually:\n\n"
            "  pip install -r requirements-ai.txt\n\n"
            f"Original error: {_import_error}"
        )

    # Create placeholder classes
    NaturalLanguageQuery = _raise_import_error
    SemanticLayer = _raise_import_error
    VectorStore = _raise_import_error
    CodeExecutor = _raise_import_error
    CacheManager = _raise_import_error

    __all__ = []


def check_ai_dependencies():
    """
    Check if AI dependencies are installed.

    Returns:
        bool: True if all AI dependencies are available, False otherwise.
    """
    return AI_AVAILABLE


def get_ai_status():
    """
    Get detailed status of AI module availability.

    Returns:
        dict: Status information including availability and missing dependencies.
    """
    if AI_AVAILABLE:
        return {
            "available": True,
            "message": "All AI dependencies are installed and ready to use.",
            "version": __version__
        }
    else:
        return {
            "available": False,
            "message": "AI dependencies are not installed.",
            "error": str(_import_error),
            "installation": "pip install outhad_edge[ai]"
        }

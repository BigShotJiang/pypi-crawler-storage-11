class BaseReteException(Exception):
    pass

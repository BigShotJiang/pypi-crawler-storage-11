from .utils import RETE_CONFIG
from .__version__ import __version__
from .utils import check_version, supress_warnings
from . import (
    datasets,
    eventstream,
    preprocessing_graph,
    params_model,
    preprocessor,
    tooling,
    widget,
    data_processor,
    data_processors_lib,
)

# Import Eventstream directly for easier access
from .eventstream import Eventstream

# Optional AI module
try:
    from . import ai
    _ai_available = True
except ImportError:
    ai = None  # type: ignore
    _ai_available = False

__all__ = (
    # Core classes
    "Eventstream",
    # Modules
    "datasets",
    "eventstream",
    "preprocessing_graph",
    "params_model",
    "preprocessor",
    "tooling",
    "widget",
    "data_processor",
    "data_processors_lib",
    "ai",
    # Utils
    "__version__",
    "RETE_CONFIG",
)

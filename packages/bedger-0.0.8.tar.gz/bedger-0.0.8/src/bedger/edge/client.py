from __future__ import annotations

import socket
import logging
from http.client import HTTPConnection
from typing import Any

from .config import Config
from .entities.device_event import DeviceEvent
from . import entities
from .errors import (
    ConnectionError,
    SendError,
    HTTPRequestError,
    JSONSerializationError,
    map_socket_error,
)

logger = logging.getLogger("bedger.edge.client")


class UnixSocketHTTPConnection(HTTPConnection):
    """HTTPConnection subclass that communicates via UNIX domain sockets."""

    def __init__(self, unix_socket_path: str):
        super().__init__("localhost")  # dummy host
        self.unix_socket_path = unix_socket_path

    def connect(self):
        """Override to connect to a UNIX socket instead of TCP."""
        try:
            self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self.sock.connect(self.unix_socket_path)
        except Exception as e:
            raise map_socket_error(e, self.unix_socket_path)


class Client:
    """
    Bedger Edge Client that communicates with the local agent's HTTP API
    over a UNIX socket. Matches BedgerConnection interface.
    """

    def __init__(self, config: Config = Config()):
        self._config = config
        self._connection: UnixSocketHTTPConnection | None = None

    def __enter__(self) -> Client:
        self._connect()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self._disconnect()

    def _connect(self) -> None:
        socket_path = self._config.socket_path
        logger.info(f"Connecting to Bedger Edge API at {socket_path}")
        try:
            self._connection = UnixSocketHTTPConnection(socket_path)
        except Exception as e:
            raise ConnectionError(socket_path, e)

    def _disconnect(self) -> None:
        if self._connection:
            try:
                self._connection.close()
                logger.info("Connection closed")
            except Exception as e:
                logger.warning(f"Error closing connection: {e}")
            finally:
                self._connection = None

    def send_event(
        self, event_type: str, severity: entities.Severity, payload: dict[str, Any]
    ) -> None:
        """Send a DeviceEvent to /device/events."""
        if not self._connection:
            raise ConnectionError(self._config.socket_path)

        try:
            event = DeviceEvent(event_type=event_type, severity=severity, details=payload)
            serialized = event.model_dump_json(by_alias=True).encode("utf-8")
        except Exception as e:
            raise JSONSerializationError(f"Failed to serialize DeviceEvent {event_type}") from e

        try:
            self._connection.request(
                "POST",
                "/device/events",
                body=serialized,
                headers={"Content-Type": "application/json"},
            )

            response = self._connection.getresponse()
            response_data = response.read().decode("utf-8")

            if response.status != 200:
                raise HTTPRequestError(response.status, response_data)

            logger.info(f"Event sent successfully: {response_data}")
        except HTTPRequestError:
            raise
        except Exception as e:
            raise SendError("Failed to send DeviceEvent", e)

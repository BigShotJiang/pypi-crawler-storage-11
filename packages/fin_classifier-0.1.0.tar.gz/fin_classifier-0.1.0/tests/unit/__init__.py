"""Testes unitários do classificador."""

"""
Testes completos para o sistema de classificação de extratos
"""

import pytest

from classifier import Amount, BaseClassifier, ClassificationResult, Rule, Text, Transaction


class ClassificacaoExtrato(BaseClassifier):
    """
    Classificador de extratos bancários com regras de negócio.

    """

    # Ativos de Renda Fixa - Juros
    __ativo_juros = Rule(Text.any_of("cri", "deb", "lci", "lca") & Text.contains("juros") & Amount.positive())

    # Ativos de Renda Fixa - Amortização
    __ativo_amort = Rule(Text.any_of("cri", "deb", "lci", "lca") & Text.contains("amort") & Amount.positive())

    # Tesouro Direto
    __tesouro_direto = Rule(Text.contains("tesouro", "direto") & Amount.positive())

    # Dividendos
    __dividendos = Rule(Text.any_of("dividendo", "jcp", "jscp") & Amount.positive())

    # Despesas Operacionais
    __despesas = Rule(Text.contains("custo") & ~Text.any_of("custodia", "oferta") & Amount.negative())

    # Taxas e Impostos
    __taxas_impostos = Rule(Text.any_of("taxa", "imposto", "ir", "iof") & Amount.negative())

    # Transferências
    __transferencias = Rule(Text.any_of("transferencia", "pix", "ted", "doc") & Amount.negative())

    # Aplicações (saída de dinheiro para investimento)
    __aplicacoes = Rule(Text.any_of("aplicacao", "aquisicao", "compra") & Amount.negative())

    # Resgates (entrada de dinheiro de investimento)
    __resgates = Rule(Text.any_of("resgate", "venda", "liquidacao") & Amount.positive())

    # Fallback - deve ser sempre a última regra
    __outros = Rule()


# ===== FIXTURES =====


@pytest.fixture
def sample_transactions() -> list[Transaction]:
    """Fixture com transações de exemplo para testes"""
    return [
        Transaction("Rendimento CRI XPTO Juros Mensais", 150.50),
        Transaction("Amortização DEB ABC Extraordinária", 1000.00),
        Transaction("TESOURO DIRETO SELIC 2029", 500.00),
        Transaction("Dividendos PETR4", 85.30),
        Transaction("Custo Operacional Escritório", -250.00),
        Transaction("Taxa Custódia Mensal", -15.00),
        Transaction("TAXA BOLSA B3", -10.50),
        Transaction("Imposto de Renda Retido", -45.20),
        Transaction("Transferência PIX para João", -300.00),
        Transaction("TED Banco XYZ", -150.00),
        Transaction("Aplicação CDB Liquidez Diária", -5000.00),
        Transaction("Aquisição LCI Banco ABC", -10000.00),
        Transaction("Resgate Fundo DI", 7500.00),
        Transaction("Venda Ações VALE3", 3200.00),
        Transaction("Pagamento Cartão de Crédito", -1500.00),
    ]


@pytest.fixture
def classifier():
    """Fixture com o classificador"""
    return ClassificacaoExtrato


# ===== TESTES DE CONDIÇÕES BÁSICAS =====


class TestTextConditions:
    """Testes para condições de texto"""

    def test_text_contains_all(self):
        """Testa TextContainsAll"""
        condition = Text.contains("banco", "brasil")

        assert condition.matches(Transaction("Banco do Brasil", 100))
        assert not condition.matches(Transaction("Banco Itau", 100))
        assert not condition.matches(Transaction("Brasil", 100))

    def test_text_any_of(self):
        """Testa TextContainsAny"""
        condition = Text.any_of("cri", "deb", "lci")

        assert condition.matches(Transaction("Rendimento CRI", 100))
        assert condition.matches(Transaction("Amortização DEB", 100))
        assert condition.matches(Transaction("LCI Banco", 100))
        assert not condition.matches(Transaction("Dividendos", 100))

    def test_text_case_insensitive(self):
        """Testa case insensitivity por padrão"""
        condition = Text.contains("banco")

        assert condition.matches(Transaction("BANCO", 100))
        assert condition.matches(Transaction("banco", 100))
        assert condition.matches(Transaction("BaNcO", 100))

    def test_text_case_sensitive(self):
        """Testa case sensitivity quando ativado"""
        condition = Text.contains("Banco", case_sensitive=True)

        assert condition.matches(Transaction("Banco do Brasil", 100))
        assert not condition.matches(Transaction("BANCO DO BRASIL", 100))
        assert not condition.matches(Transaction("banco do brasil", 100))

    def test_text_starts_with(self):
        """Testa TextStartsWith"""
        condition = Text.starts_with("pix", "ted")

        assert condition.matches(Transaction("PIX para João", -100))
        assert condition.matches(Transaction("TED Banco XYZ", -100))
        assert not condition.matches(Transaction("Transferência PIX", -100))

    def test_text_ends_with(self):
        """Testa TextEndsWith"""
        condition = Text.ends_with("mensais", "anuais")

        assert condition.matches(Transaction("Juros Mensais", 100))
        assert condition.matches(Transaction("Taxas Anuais", -50))
        assert not condition.matches(Transaction("Mensais Juros", 100))

    def test_text_equals(self):
        """Testa TextEquals"""
        condition = Text.equals("pix")

        assert condition.matches(Transaction("PIX", -100))
        assert not condition.matches(Transaction("PIX para João", -100))


class TestAmountConditions:
    """Testes para condições de valor"""

    def test_amount_gt(self):
        """Testa maior que"""
        condition = Amount.gt(100)

        assert condition.matches(Transaction("Test", 150))
        assert not condition.matches(Transaction("Test", 100))
        assert not condition.matches(Transaction("Test", 50))

    def test_amount_lt(self):
        """Testa menor que"""
        condition = Amount.lt(-100)

        assert condition.matches(Transaction("Test", -150))
        assert not condition.matches(Transaction("Test", -100))
        assert not condition.matches(Transaction("Test", -50))

    def test_amount_gte(self):
        """Testa maior ou igual"""
        condition = Amount.gte(100)

        assert condition.matches(Transaction("Test", 150))
        assert condition.matches(Transaction("Test", 100))
        assert not condition.matches(Transaction("Test", 50))

    def test_amount_lte(self):
        """Testa menor ou igual"""
        condition = Amount.lte(100)

        assert condition.matches(Transaction("Test", 50))
        assert condition.matches(Transaction("Test", 100))
        assert not condition.matches(Transaction("Test", 150))

    def test_amount_eq(self):
        """Testa igualdade com tolerância"""
        condition = Amount.eq(100, tolerance=0.01)

        assert condition.matches(Transaction("Test", 100.00))
        assert condition.matches(Transaction("Test", 100.005))
        assert not condition.matches(Transaction("Test", 100.02))

    def test_amount_between(self):
        """Testa intervalo"""
        condition = Amount.between(100, 1000)

        assert condition.matches(Transaction("Test", 100))
        assert condition.matches(Transaction("Test", 500))
        assert condition.matches(Transaction("Test", 1000))
        assert not condition.matches(Transaction("Test", 50))
        assert not condition.matches(Transaction("Test", 1500))

    def test_amount_positive(self):
        """Testa valor positivo"""
        condition = Amount.positive()

        assert condition.matches(Transaction("Test", 0.01))
        assert condition.matches(Transaction("Test", 100))
        assert not condition.matches(Transaction("Test", 0))
        assert not condition.matches(Transaction("Test", -100))

    def test_amount_negative(self):
        """Testa valor negativo"""
        condition = Amount.negative()

        assert condition.matches(Transaction("Test", -0.01))
        assert condition.matches(Transaction("Test", -100))
        assert not condition.matches(Transaction("Test", 0))
        assert not condition.matches(Transaction("Test", 100))


class TestLogicalOperators:
    """Testes para operadores lógicos"""

    def test_and_operator(self):
        """Testa operador & (AND)"""
        condition = Text.contains("banco") & Amount.positive()

        assert condition.matches(Transaction("Banco do Brasil", 100))
        assert not condition.matches(Transaction("Banco do Brasil", -100))
        assert not condition.matches(Transaction("Supermercado", 100))

    def test_or_operator(self):
        """Testa operador | (OR)"""
        condition = Text.contains("banco") | Text.contains("caixa")

        assert condition.matches(Transaction("Banco do Brasil", 100))
        assert condition.matches(Transaction("Caixa Econômica", 100))
        assert not condition.matches(Transaction("Supermercado", 100))

    def test_not_operator(self):
        """Testa operador ~ (NOT)"""
        condition = ~Text.contains("custodia")

        assert condition.matches(Transaction("Taxa Bolsa", -10))
        assert not condition.matches(Transaction("Taxa Custodia", -10))

    def test_complex_composition(self):
        """Testa composição complexa de operadores"""
        condition = Text.any_of("cri", "deb") & Text.contains("juros") & Amount.positive() & ~Text.contains("provisao")

        assert condition.matches(Transaction("Rendimento CRI Juros", 100))
        assert condition.matches(Transaction("DEB Juros Mensais", 100))
        assert not condition.matches(Transaction("CRI Juros Provisao", 100))
        assert not condition.matches(Transaction("CRI Juros", -100))
        assert not condition.matches(Transaction("CRI Amortizacao", 100))

    def test_operator_precedence(self):
        """Testa precedência de operadores"""
        # condicao (A | B) & C  # noqa: ERA001
        condition1 = (Text.contains("a") | Text.contains("b")) & Amount.positive()

        assert condition1.matches(Transaction("a", 100))
        assert condition1.matches(Transaction("b", 100))
        assert not condition1.matches(Transaction("a", -100))

        # A | (B & C)  # noqa: ERA001
        condition2 = Text.contains("a") | (Text.contains("b") & Amount.positive())

        assert condition2.matches(Transaction("a", -100))  # Diferente de condition1
        assert condition2.matches(Transaction("b", 100))
        assert not condition2.matches(Transaction("b", -100))


# ===== TESTES DO CLASSIFICADOR =====


class TestClassifier:
    """Testes do classificador completo"""

    def test_ativo_juros_classification(self, classifier):
        """Testa classificação de juros de ativos"""
        transactions = [
            Transaction("Rendimento CRI XPTO Juros", 150.50),
            Transaction("DEB ABC Juros Mensais", 200.00),
            Transaction("LCI Banco Juros", 75.00),
        ]

        for trans in transactions:
            result = classifier.classify(trans)
            assert result.category == "ativo_juros"
            assert result.priority == 0

    def test_ativo_amort_classification(self, classifier):
        """Testa classificação de amortização"""
        transactions = [
            Transaction("Amortização CRI XPTO", 1000.00),
            Transaction("DEB ABC Amortização Extraordinária", 5000.00),
        ]

        for trans in transactions:
            result = classifier.classify(trans)
            assert result.category == "ativo_amort"
            assert result.priority == 1

    def test_tesouro_direto_classification(self, classifier):
        """Testa classificação de Tesouro Direto"""
        transactions = [
            Transaction("TESOURO DIRETO SELIC 2029", 500.00),
            Transaction("Resgate Tesouro Direto IPCA", 10000.00),
        ]

        for trans in transactions:
            result = classifier.classify(trans)
            assert result.category == "tesouro_direto"

    def test_dividendos_classification(self, classifier):
        """Testa classificação de dividendos"""
        transactions = [
            Transaction("Dividendos PETR4", 85.30),
            Transaction("JCP VALE3", 120.00),
            Transaction("JSCP Empresa XYZ", 50.00),
        ]

        for trans in transactions:
            result = classifier.classify(trans)
            assert result.category == "dividendos"

    def test_despesas_classification(self, classifier):
        """Testa classificação de despesas"""
        transactions = [
            Transaction("Custo Operacional Escritório", -250.00),
            Transaction("Custo Administrativo", -100.00),
        ]

        for trans in transactions:
            result = classifier.classify(trans)
            assert result.category == "despesas"

    def test_despesas_excludes_custodia(self, classifier):
        """Testa que despesas não incluem custódia"""
        trans = Transaction("Custo Custodia Mensal", -15.00)
        result = classifier.classify(trans)

        assert result.category != "despesas"
        # Deve ser classificado como taxas_impostos
        assert result.category == "taxas_impostos"

    def test_taxas_impostos_classification(self, classifier):
        """Testa classificação de taxas e impostos"""
        transactions = [
            Transaction("Taxa Custódia", -15.00),
            Transaction("TAXA BOLSA B3", -10.50),
            Transaction("Imposto de Renda", -45.20),
            Transaction("IOF Operação", -5.00),
        ]

        for trans in transactions:
            result = classifier.classify(trans)
            assert result.category == "taxas_impostos"

    def test_transferencias_classification(self, classifier):
        """Testa classificação de transferências"""
        transactions = [
            Transaction("Transferência PIX", -300.00),
            Transaction("TED Banco XYZ", -150.00),
            Transaction("DOC Pagamento", -200.00),
        ]

        for trans in transactions:
            result = classifier.classify(trans)
            assert result.category == "transferencias"

    def test_aplicacoes_classification(self, classifier):
        """Testa classificação de aplicações"""
        transactions = [
            Transaction("Aplicação CDB", -5000.00),
            Transaction("Aquisição LCI", -10000.00),
            Transaction("Compra Ações PETR4", -2000.00),
        ]

        for trans in transactions:
            result = classifier.classify(trans)
            assert result.category == "aplicacoes"

    def test_resgates_classification(self, classifier):
        """Testa classificação de resgates"""
        transactions = [
            Transaction("Resgate Fundo DI", 7500.00),
            Transaction("Venda Ações VALE3", 3200.00),
            Transaction("Liquidação CDB", 10000.00),
        ]

        for trans in transactions:
            result = classifier.classify(trans)
            assert result.category == "resgates"

    def test_outros_fallback(self, classifier):
        """Testa classificação fallback para transações não reconhecidas"""
        transactions = [
            Transaction("Pagamento Cartão de Crédito", -1500.00),
            Transaction("Compra Supermercado", -250.00),
            Transaction("Salário", 5000.00),
        ]

        for trans in transactions:
            result = classifier.classify(trans)
            assert result.category == "outros"

    def test_priority_order(self, classifier):
        """Testa que a ordem de prioridade é respeitada"""
        # Esta transação poderia ser "ativo_juros" ou "resgates"
        # Mas "ativo_juros" tem prioridade maior (0 vs 8)
        trans = Transaction("Rendimento CRI Juros Resgate", 1000.00)
        result = classifier.classify(trans)

        assert result.category == "ativo_juros"
        assert result.priority == 0

    def test_batch_classification(self, classifier, sample_transactions):
        """Testa classificação em lote"""
        results = classifier.classify_batch(sample_transactions)

        assert len(results) == len(sample_transactions)
        assert all(isinstance(r, ClassificationResult) for r in results)

        # Verifica categorias esperadas
        expected_categories = {
            "ativo_juros",
            "ativo_amort",
            "tesouro_direto",
            "dividendos",
            "despesas",
            "taxas_impostos",
            "transferencias",
            "aplicacoes",
            "resgates",
            "outros",
        }

        found_categories = {r.category for r in results}
        assert found_categories.issubset(expected_categories)


# ===== TESTES DE EDGE CASES =====


class TestEdgeCases:
    """Testes de casos extremos"""

    def test_empty_description(self, classifier):
        """Testa transação com descrição vazia"""
        trans = Transaction("", 100.00)
        result = classifier.classify(trans)

        # Deve cair no fallback
        assert result.category == "outros"

    def test_zero_amount(self, classifier):
        """Testa transação com valor zero"""
        trans = Transaction("Ajuste Contábil", 0.00)
        result = classifier.classify(trans)

        # Não deve ser classificado como positivo nem negativo
        assert result.category == "outros"

    def test_very_large_amount(self, classifier):
        """Testa transação com valor muito grande"""
        trans = Transaction("Rendimento CRI Juros", 1_000_000_000.00)
        result = classifier.classify(trans)

        assert result.category == "ativo_juros"

    def test_special_characters(self, classifier):
        """Testa descrições com caracteres especiais"""
        transactions = [
            Transaction("Rendimento CRI @#$% Juros", 100.00),
            Transaction("DEB (Extraordinária) Juros", 100.00),
            Transaction("Custo & Despesas", -100.00),
        ]

        results = [classifier.classify(t) for t in transactions]

        assert results[0].category == "ativo_juros"
        assert results[1].category == "ativo_juros"
        assert results[2].category == "despesas"

    def test_unicode_characters(self, classifier):
        """Testa descrições com caracteres unicode"""
        transactions = [
            Transaction("Rendimento CRI José João Juros", 100.00),
            Transaction("Amortização DEB São Paulo", 1000.00),
            Transaction("Custo Operação €", -50.00),
        ]

        results = [classifier.classify(t) for t in transactions]

        assert results[0].category == "ativo_juros"
        assert results[1].category == "ativo_amort"
        assert results[2].category == "despesas"

    def test_multiple_spaces(self, classifier):
        """Testa descrições com múltiplos espaços"""
        trans = Transaction("Rendimento    CRI    Juros", 100.00)
        result = classifier.classify(trans)

        assert result.category == "ativo_juros"


# ===== TESTES DE VALIDAÇÃO =====


class TestValidation:
    """Testes de validação"""

    def test_invalid_transaction_description(self):
        """Testa transação com descrição inválida"""
        with pytest.raises(TypeError):
            Transaction(123, 100.00)  # descrição não é string # ty: ignore

    def test_invalid_transaction_amount(self):
        """Testa transação com valor inválido"""
        with pytest.raises(TypeError):
            Transaction("Test", "100")  # amount não é numérico # ty: ignore

    def test_text_condition_empty_terms(self):
        """Testa condição de texto sem termos"""
        with pytest.raises(ValueError):  # noqa: PT011
            Text.contains()

    def test_amount_between_invalid_range(self):
        """Testa Amount.between com intervalo inválido"""
        with pytest.raises(ValueError):  # noqa: PT011
            Amount.between(100, 50)  # min > max

    def test_rule_without_condition(self):
        """Testa regra sem condição (deve usar AlwaysTrue)"""
        rule = Rule()
        trans = Transaction("Test", 100)

        assert rule.matches(trans)  # AlwaysTrue sempre retorna True


# ===== TESTES DE PERFORMANCE =====


class TestPerformance:
    """Testes de performance (opcional, mas útil)"""

    def test_classify_large_batch(self, classifier, benchmark):
        """Testa performance com grande volume de transações"""
        transactions = [Transaction(f"Rendimento CRI {i} Juros", 100.00 + i) for i in range(1000)]

        # Usa pytest-benchmark se disponível
        if benchmark:
            results = benchmark(classifier.classify_batch, transactions)
            assert len(results) == 1000

    def test_complex_condition_performance(self, benchmark):
        """Testa performance de condição complexa"""
        condition = (
            (Text.any_of("a", "b", "c") | Text.any_of("d", "e", "f"))
            & (Amount.between(100, 1000) | Amount.gt(5000))
            & ~Text.contains("exclusao")
            & (Text.starts_with("pref") | Text.ends_with("suf"))
        )

        trans = Transaction("Prefixo test suffix", 500)

        if benchmark:
            result = benchmark(condition.matches, trans)
            assert result is True


# ===== TESTES DE DESCRIBE =====


class TestDescribe:
    """Testes dos métodos describe()"""

    def test_condition_describe(self):
        """Testa describe de condições"""
        condition = Text.contains("banco") & Amount.positive()
        description = condition.describe()

        assert "banco" in description
        assert "AND" in description
        assert ">" in description

    def test_rule_describe(self, classifier):
        """Testa describe de regras"""
        rules = classifier.get_rules()

        for rule in rules:
            description = rule.describe()
            assert rule.category in description
            assert str(rule.priority) in description

    def test_classifier_describe_rules(self, classifier):
        """Testa describe do classificador completo"""
        description = classifier.describe_rules()

        assert "ClassificacaoExtrato" in description
        assert "ativo_juros" in description
        assert "ativo_amort" in description
        assert "despesas" in description


# ===== CONFIGURAÇÃO DO PYTEST =====


def pytest_configure(config):
    """Configuração do pytest"""
    config.addinivalue_line("markers", "slow: marks tests as slow (deselect with '-m \"not slow\"')")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])

## What is tianhe-pyautogen?

tianhe-pyautogen is an open-source autogen extending library built to power building LLM application.
tianhe-pyautogen provides more components to support Chinese LLMs and and Chinese based token environments for prompt engineering and ICL template.


The project is a sub-module of [tianhe](https://github.com/cicit/tianhe).


## Key features

- Retrival Enhancement components, like ESIndex, DBIndex, GraphIndex 
- Supporting Open LLMs and embeddings models 
- High performance QAs Chains
- High Semanticly Chinese token processing


## Quick start

### Start with Tianhe Platform.

We provide a open cloud service for easily use. See [free trial](https://www.tianhe-ai.com/).


### Install tianhe-pyautogen

- Install from pip: `pip install tianhe-pyautogen`
- [Quick Start Guide](https://scn3v8ba0o9m.feishu.cn/wiki/XTRVw4tUHi4ZQ2kDQpXc0l47nLg)


## Documentation

For guidance on installation, development, deployment, and administration, 
check out [tianhe-pyautogen Dev Docs](https://scn3v8ba0o9m.feishu.cn/wiki/XTRVw4tUHi4ZQ2kDQpXc0l47nLg). 


## Acknowledgments

tianhe-pyautogen adopts dependencies from the following:

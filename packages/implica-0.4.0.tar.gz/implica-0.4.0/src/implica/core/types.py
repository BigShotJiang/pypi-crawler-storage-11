"""
Type system for minimal implicational logic.

This module defines the type hierarchy for the implicational logic graph:
- BaseType: Abstract base for all types
- Variable: Simple type variables (e.g., A, B, C)
- Application: Function application types (e.g., A -> B)
"""

import hashlib
from abc import ABC, abstractmethod
from functools import cached_property
from typing import List

from pydantic import BaseModel, ConfigDict, Field, field_validator


class BaseType(BaseModel, ABC):
    """Abstract base class for all types in the implicational logic system."""

    model_config = ConfigDict(frozen=True)  # Make immutable

    @cached_property
    @abstractmethod
    def uid(self) -> str:
        """
        Unique identifier for this type, computed as a hash.

        This property is cached for performance and should uniquely identify
        the type based on its structure.

        Returns:
            str: A unique string identifier for this type
        """
        pass

    @property
    @abstractmethod
    def variables(self) -> List["Variable"]:
        """
        Return the list of all variables in this type.

        This property is computed recursively on each access.
        The list may contain duplicate variables if they appear multiple times.

        Returns:
            List[Variable]: A list of all Variable instances in this type
        """
        pass

    @abstractmethod
    def __str__(self) -> str:
        """String representation of the type."""
        pass


class Variable(BaseType):
    """
    A simple type variable (e.g., A, B, C).

    Variables represent atomic types in the type system.
    """

    name: str = Field(..., min_length=1, description="Name of the type variable")

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate that the variable name is non-empty and contains valid characters."""
        if not v or not v.strip():
            raise ValueError("Variable name cannot be empty or whitespace")
        return v.strip()

    @cached_property
    def uid(self) -> str:
        """Return the variable name hashed as its unique identifier."""
        content = f"Var({self.name})"
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    @property
    def variables(self) -> List["Variable"]:
        """
        Return the list of variables in this type.

        For a Variable, this returns a list containing only itself.

        Returns:
            List[Variable]: A list containing only this variable
        """
        return [self]

    def __str__(self) -> str:
        """Return the variable name."""
        return self.name

    def __repr__(self) -> str:
        """Return a detailed representation."""
        return f"Variable(name='{self.name}')"


class Application(BaseType):
    """
    A function application type (e.g., A -> B).

    Represents the type of a function that takes `input_type` and returns `output_type`.
    In notation: input_type -> output_type
    """

    input_type: BaseType = Field(..., description="Input type of the function")
    output_type: BaseType = Field(..., description="Output type of the function")

    @cached_property
    def uid(self) -> str:
        """
        Compute unique identifier based on input and output types.

        Returns:
            str: A SHA256 hash of the structure
        """
        content = f"App({self.input_type.uid},{self.output_type.uid})"
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    @property
    def variables(self) -> List[Variable]:
        """
        Return the list of variables in this type.

        For an Application, this recursively collects all variables from
        both the input_type and output_type.

        Returns:
            List[Variable]: A list of all variables in this application type
        """
        return self.input_type.variables + self.output_type.variables

    def __str__(self) -> str:
        """
        Return a human-readable string representation.

        Uses parentheses for nested applications to maintain clarity.
        """
        # Add parentheses around input if it's also an Application
        if isinstance(self.input_type, Application):
            input_str = f"({self.input_type})"
        else:
            input_str = str(self.input_type)

        return f"{input_str} -> {self.output_type}"

    def __repr__(self) -> str:
        """Return a detailed representation."""
        return f"Application(input_type={repr(self.input_type)}, output_type={repr(self.output_type)})"


# Helper function to create types more easily
def var(name: str) -> Variable:
    """
    Helper function to create a Variable.

    Args:
        name: Name of the variable

    Returns:
        Variable: A new Variable instance
    """
    return Variable(name=name)


def app(input_type: BaseType, output_type: BaseType) -> Application:
    """
    Helper function to create an Application.

    Args:
        input_type: The input type
        output_type: The output type

    Returns:
        Application: A new Application instance
    """
    return Application(input_type=input_type, output_type=output_type)


def type_from_string(type_str: str) -> BaseType:
    """
    Parse a string representation of a type into a BaseType instance.

    Supports simple variables (e.g., "A") and implication types (e.g., "A -> B").
    Handles nested types with parentheses (e.g., "(A -> B) -> C").
    The arrow operator (->) is right-associative, so "A -> B -> C" is parsed as "A -> (B -> C)".

    Args:
        type_str: String representation of the type

    Returns:
        BaseType: The parsed type (Variable or Application)

    Raises:
        ValueError: If the string cannot be parsed as a valid type

    Examples:
        >>> type_from_string("A")
        Variable(name='A')
        >>> type_from_string("A -> B")
        Application(input_type=Variable(name='A'), output_type=Variable(name='B'))
        >>> type_from_string("(A -> B) -> C")
        Application(input_type=Application(...), output_type=Variable(name='C'))
    """
    if not type_str or not type_str.strip():
        raise ValueError("Type string cannot be empty")

    type_str = type_str.strip()

    # Tokenize the input using the utils module
    from implica.utils import tokenize, parse_type

    tokens = tokenize(type_str)

    # Parse the tokens into a type using the utils module
    result, remaining = parse_type(tokens)

    if remaining:
        raise ValueError(f"Unexpected tokens after parsing: {' '.join(remaining)}")

    return result

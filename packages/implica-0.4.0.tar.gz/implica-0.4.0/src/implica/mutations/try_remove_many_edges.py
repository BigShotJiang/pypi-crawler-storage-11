from typing import TYPE_CHECKING

from ..graph.elements import Edge
from .base import Mutation

if TYPE_CHECKING:
    from ..graph.graph import Graph


class TryRemoveManyEdges(Mutation):
    """Mutation to remove multiple edges from the graph, skipping edges that don't exist."""

    def __init__(self, edge_uids: list[str]):
        """
        Initialize the TryRemoveManyEdges mutation.

        Args:
            edge_uids: List of edge UIDs to remove
        """
        self.edge_uids = edge_uids
        self._removed_edges: list[Edge] = []

    def forward(self, graph: "Graph") -> None:
        """
        Try to remove all edges from the graph.

        Edges that don't exist in the graph are skipped without raising an error.

        Args:
            graph: The graph to modify
        """
        self._removed_edges = []

        for edge_uid in self.edge_uids:
            if graph.has_edge(edge_uid):
                # Store the edge for rollback
                removed_edge = graph.get_edge(edge_uid)
                self._removed_edges.append(removed_edge)

                # Remove the edge
                graph._remove_edge(edge_uid)

    def backward(self, graph: "Graph") -> None:
        """
        Re-add all edges that were removed.

        Args:
            graph: The graph to modify
        """
        for edge in reversed(self._removed_edges):
            graph._add_edge(edge)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"TryRemoveManyEdges(count={len(self.edge_uids)}, removed={len(self._removed_edges)})"

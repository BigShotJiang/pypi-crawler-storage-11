from typing import TYPE_CHECKING

from ..graph.elements import Node
from .base import Mutation

if TYPE_CHECKING:
    from ..graph.graph import Graph


class TryAddManyNodes(Mutation):
    """Mutation to add multiple nodes to the graph, skipping nodes that already exist."""

    def __init__(self, nodes: list[Node]):
        """
        Initialize the TryAddManyNodes mutation.

        Args:
            nodes: List of nodes to add
        """
        self.nodes = nodes
        self._added_nodes: list[Node] = []

    def forward(self, graph: "Graph") -> None:
        """
        Try to add all nodes to the graph.

        Nodes that already exist in the graph are skipped without raising an error.

        Args:
            graph: The graph to modify
        """
        self._added_nodes = []

        for node in self.nodes:
            if not graph.has_node(node.uid):
                graph._add_node(node)
                self._added_nodes.append(node)

    def backward(self, graph: "Graph") -> None:
        """
        Remove all nodes that were added.

        Args:
            graph: The graph to modify
        """
        for node in reversed(self._added_nodes):
            graph._remove_node(node.uid)

    def __str__(self) -> str:
        """Return a string representation."""
        return (
            f"TryAddManyNodes(count={len(self.nodes)}, added={len(self._added_nodes)})"
        )

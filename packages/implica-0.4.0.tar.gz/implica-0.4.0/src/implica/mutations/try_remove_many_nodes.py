from typing import TYPE_CHECKING

from ..graph import Edge, Node
from .base import Mutation

if TYPE_CHECKING:
    from ..graph import Graph


class TryRemoveManyNodes(Mutation):
    """Mutation to remove multiple nodes from the graph, skipping nodes that don't exist."""

    def __init__(self, node_uids: list[str]):
        """
        Initialize the TryRemoveManyNodes mutation.

        Args:
            node_uids: List of node UIDs to remove
        """
        self.node_uids = node_uids
        self._removed_data: list[tuple[Node, list[Edge]]] = []

    def forward(self, graph: "Graph") -> None:
        """
        Try to remove all nodes from the graph.

        Nodes that don't exist in the graph are skipped without raising an error.

        Args:
            graph: The graph to modify
        """
        self._removed_data = []

        for node_uid in self.node_uids:
            if graph.has_node(node_uid):
                # Store the node and its edges for rollback
                removed_node = graph.get_node(node_uid)
                removed_edges = graph.get_edges_for_node(node_uid)
                self._removed_data.append((removed_node, removed_edges))

                # Remove the node
                graph._remove_node(node_uid)

    def backward(self, graph: "Graph") -> None:
        """
        Re-add all nodes and edges that were removed.

        Args:
            graph: The graph to modify
        """
        for removed_node, removed_edges in reversed(self._removed_data):
            graph._add_node(removed_node)
            for edge in removed_edges:
                graph._add_edge(edge)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"TryRemoveManyNodes(count={len(self.node_uids)}, removed={len(self._removed_data)})"

from typing import TYPE_CHECKING

from ..graph.elements import Edge
from .base import Mutation

if TYPE_CHECKING:
    from ..graph.graph import Graph


class TryAddManyEdges(Mutation):
    """Mutation to add multiple edges to the graph, skipping edges that already exist."""

    def __init__(self, edges: list[Edge]):
        """
        Initialize the TryAddManyEdges mutation.

        Args:
            edges: List of edges to add
        """
        self.edges = edges
        self._added_edges: list[Edge] = []

    def forward(self, graph: "Graph") -> None:
        """
        Try to add all edges to the graph.

        Edges that already exist in the graph are skipped without raising an error.

        Args:
            graph: The graph to modify

        Raises:
            KeyError: If source or destination nodes don't exist for an edge
        """
        self._added_edges = []

        try:
            for edge in self.edges:
                if not graph.has_edge(edge.uid):
                    graph._add_edge(edge)
                    self._added_edges.append(edge)
        except Exception:
            # Rollback: remove all edges that were added
            for edge in self._added_edges:
                graph._remove_edge(edge.uid)
            self._added_edges = []
            raise

    def backward(self, graph: "Graph") -> None:
        """
        Remove all edges that were added.

        Args:
            graph: The graph to modify
        """
        for edge in reversed(self._added_edges):
            graph._remove_edge(edge.uid)

    def __str__(self) -> str:
        """Return a string representation."""
        return (
            f"TryAddManyEdges(count={len(self.edges)}, added={len(self._added_edges)})"
        )

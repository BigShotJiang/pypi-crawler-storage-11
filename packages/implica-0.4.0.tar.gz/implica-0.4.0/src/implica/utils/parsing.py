"""
Utility functions for parsing type strings.

This module contains helper functions for parsing and manipulating types.
"""

from typing import List, TYPE_CHECKING

if TYPE_CHECKING:
    from implica.core.types import BaseType


def tokenize(type_str: str) -> List[str]:
    """
    Tokenize a type string into a list of tokens.

    Tokens include: variable names, '(', ')', and '->'.

    Args:
        type_str: The type string to tokenize

    Returns:
        List[str]: List of tokens

    Raises:
        ValueError: If invalid characters are found
    """
    tokens = []
    i = 0
    while i < len(type_str):
        char = type_str[i]

        # Skip whitespace
        if char.isspace():
            i += 1
            continue

        # Handle parentheses
        if char in "()":
            tokens.append(char)
            i += 1
            continue

        # Handle arrow operator
        if char == "-":
            if i + 1 < len(type_str) and type_str[i + 1] == ">":
                tokens.append("->")
                i += 2
                continue
            else:
                raise ValueError(f"Invalid character '-' at position {i}")

        # Handle variable names (alphanumeric and underscores)
        if char.isalnum() or char == "_":
            var_name = ""
            while i < len(type_str) and (type_str[i].isalnum() or type_str[i] == "_"):
                var_name += type_str[i]
                i += 1
            tokens.append(var_name)
            continue

        # Invalid character
        raise ValueError(f"Invalid character '{char}' at position {i}")

    return tokens


def parse_type(tokens: List[str]) -> tuple["BaseType", List[str]]:
    """
    Parse a list of tokens into a type.

    Uses recursive descent parsing with right-associativity for the arrow operator.

    Args:
        tokens: List of tokens to parse

    Returns:
        tuple[BaseType, List[str]]: Parsed type and remaining tokens

    Raises:
        ValueError: If tokens cannot be parsed
    """
    from implica.core.types import Application

    if not tokens:
        raise ValueError("Unexpected end of input")

    # Parse the left-hand side (either a variable or a parenthesized type)
    left, remaining = parse_primary(tokens)

    # Check if we have an arrow operator
    if remaining and remaining[0] == "->":
        # Consume the arrow
        remaining = remaining[1:]

        # Parse the right-hand side (right-associative)
        right, remaining = parse_type(remaining)

        # Create application
        return Application(input_type=left, output_type=right), remaining

    # No arrow, just return the primary type
    return left, remaining


def parse_primary(tokens: List[str]) -> tuple["BaseType", List[str]]:
    """
    Parse a primary type (variable or parenthesized type).

    Args:
        tokens: List of tokens to parse

    Returns:
        tuple[BaseType, List[str]]: Parsed type and remaining tokens

    Raises:
        ValueError: If tokens cannot be parsed
    """
    from implica.core.types import Variable

    if not tokens:
        raise ValueError("Unexpected end of input")

    token = tokens[0]

    # Handle parenthesized type
    if token == "(":
        # Find matching closing parenthesis
        depth = 1
        i = 1
        while i < len(tokens) and depth > 0:
            if tokens[i] == "(":
                depth += 1
            elif tokens[i] == ")":
                depth -= 1
            i += 1

        if depth != 0:
            raise ValueError("Mismatched parentheses")

        # Parse the content inside parentheses
        inner_tokens = tokens[1 : i - 1]
        if not inner_tokens:
            raise ValueError("Empty parentheses")

        result, inner_remaining = parse_type(inner_tokens)

        if inner_remaining:
            raise ValueError(
                f"Unexpected tokens inside parentheses: {' '.join(inner_remaining)}"
            )

        return result, tokens[i:]

    # Handle variable name
    if token not in ["->", ")"]:
        return Variable(name=token), tokens[1:]

    raise ValueError(f"Unexpected token: {token}")

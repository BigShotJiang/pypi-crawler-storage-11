"""
Implica - Implicational Logic Graph Library

A Python package for working with graphs representing minimal implicational
logic models. This library provides tools for constructing and manipulating
type systems based on combinatory logic, with support for transactional
graph operations.

Import as 'imp' for a clean, concise API:
    import implica as imp

    graph = imp.Graph()
    A = imp.var("A")
    B = imp.var("B")

    with graph.connect() as conn:
        conn.add_node(imp.node(A))
        conn.add_node(imp.node(B))
"""

from .core import *
from .graph import Node, Edge, node, edge, Graph, Connection
from . import mutations


__all__ = [
    "BaseType",
    "Variable",
    "Application",
    "var",
    "app",
    "type_from_string",
    "Combinator",
    "S",
    "K",
    "Node",
    "Edge",
    "node",
    "edge",
    "Graph",
    "Connection",
    "mutations",
]

__version__ = "0.4.0"

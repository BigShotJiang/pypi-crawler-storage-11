#!/usr/bin/env python3
"""
Decommission Scorer Framework - Risk-Based Prioritization for EC2 & WorkSpaces

This module provides scoring algorithms for prioritizing EC2 and WorkSpaces
decommissioning candidates based on multiple risk signals.

Scoring Framework:
- EC2 Signals (7 signals, 0-100 scale):
  E1: Compute Optimizer Idle (60 points) - Max CPU ≤1% over 14 days
  E2: SSM Agent Offline/Stale (8 points) - >7 days since heartbeat
  E3: No Network Activity (8 points) - NetworkIn <threshold MB/day
  E4: Stopped State (8 points) - Instance stopped >30 days
  E5: Old Snapshot (6 points) - AMI/snapshot >180 days old
  E6: No Tags/Owner (5 points) - Missing critical tags
  E7: Dev/Test Environment (3 points) - Non-production classification

- WorkSpaces Signals (6 signals, 0-100 scale):
  W1: No Connection (45 points) - >90 days since last connection
  W2: Connection History (25 points) - <10% connection days over 90 days
  W3: ALWAYS_ON Non-Compliant (10 points) - <40 hrs/mo usage
  W4: Stopped State (10 points) - WorkSpace stopped >30 days
  W5: No User Tags (5 points) - Missing cost allocation tags
  W6: Test/Dev Environment (5 points) - Non-production classification

Decommission Tiers (0-100 scale):
- MUST (80-100): Immediate candidates (high confidence)
- SHOULD (50-79): Strong candidates (review recommended)
- COULD (25-49): Potential candidates (manual review required)
- KEEP (<25): Active resources (no action)

Pattern: Follows base_enrichers.py pattern (Rich CLI, configurable thresholds)

Usage:
    from runbooks.finops.decommission_scorer import calculate_ec2_score

    # Calculate EC2 decommission score
    signals = {
        'E1': 60,  # Compute Optimizer Idle
        'E2': 8,   # SSM Agent Offline
        'E3': 8,   # No Network Activity
        'E4': 0,   # Running (not stopped)
        'E5': 6,   # Old Snapshot
        'E6': 5,   # No Tags
        'E7': 3    # Dev Environment
    }

    result = calculate_ec2_score(signals)
    # Returns: {
    #     'total_score': 90,
    #     'tier': 'MUST',
    #     'recommendation': 'Immediate decommission candidate',
    #     'signals': signals,
    #     'confidence': 'High'
    # }

Strategic Alignment:
- Objective 1 (runbooks package): Reusable scoring for notebooks
- Enterprise SDLC: Evidence-based prioritization with audit trails
- KISS/DRY/LEAN: Configurable thresholds, transparent calculations
"""

import logging
from typing import Dict, List, Optional

from ..common.rich_utils import (
    console,
    create_table,
    print_error,
    print_info,
    print_success,
    print_warning,
)

logger = logging.getLogger(__name__)

# Default EC2 signal weights (0-100 scale, total: 100 points max)
# Reference: .claude/prompts/aws-compute/ec2-workspaces.scoring.md lines 56-64
DEFAULT_EC2_WEIGHTS = {
    'E1': 60,  # Compute Optimizer Idle (max CPU ≤1% for 14 days)
    'E2': 10,  # CloudWatch CPU+Network (p95 CPU ≤3%, Network ≤10MB/day)
    'E3': 8,   # CloudTrail activity (no write events for 90 days)
    'E4': 8,   # SSM heartbeat (PingStatus != Online OR LastPingDateTime > 14d)
    'E5': 6,   # Service attachment (not in ASG/LB/ECS/EKS)
    'E6': 5,   # Storage I/O (p95 DiskReadOps+DiskWriteOps ≈ 0)
    'E7': 3    # Cost Explorer rightsizing (terminate savings > $0)
}

# Default WorkSpaces signal weights (0-100 scale, total: 100 points max)
DEFAULT_WORKSPACES_WEIGHTS = {
    'W1': 45,  # No Connection (>90 days)
    'W2': 25,  # Connection History (<10% days)
    'W3': 10,  # ALWAYS_ON Non-Compliant (<40 hrs/mo)
    'W4': 10,  # Stopped State (>30 days)
    'W5': 5,   # No User Tags
    'W6': 5    # Test/Dev Environment
}

# Decommission tier thresholds
TIER_THRESHOLDS = {
    'MUST': 80,     # 80-100: Immediate candidates
    'SHOULD': 50,   # 50-79: Strong candidates
    'COULD': 25,    # 25-49: Potential candidates
    'KEEP': 0       # 0-24: Active resources
}


def calculate_ec2_score(
    signals: Dict[str, int],
    custom_weights: Optional[Dict[str, int]] = None,
    tier_thresholds: Optional[Dict[str, int]] = None
) -> Dict:
    """
    Calculate EC2 decommission score from multiple signals.

    Scoring Logic:
    - Sum of weighted signals (0-100 scale)
    - Each signal contributes its weight if criteria met
    - Tier classification based on total score
    - High transparency: breakdown included in result

    Args:
        signals: Dictionary of signal scores (E1-E7)
                 Signal key → score (0 for absent, weight for present)
                 Example: {'E1': 60, 'E2': 0, 'E3': 8, 'E4': 0, 'E5': 6, 'E6': 5, 'E7': 3}
        custom_weights: Optional custom signal weights (override defaults)
        tier_thresholds: Optional custom tier thresholds (override defaults)

    Returns:
        Dictionary with scoring results:
        {
            'total_score': 82,
            'tier': 'MUST',
            'recommendation': 'Immediate decommission candidate',
            'signals': {
                'E1': {'score': 60, 'weight': 60, 'description': 'Compute Optimizer Idle'},
                'E2': {'score': 0, 'weight': 8, 'description': 'SSM Agent Offline/Stale'},
                ...
            },
            'confidence': 'High',  # Based on signal coverage
            'breakdown': 'E1(60) + E3(8) + E5(6) + E6(5) + E7(3) = 82'
        }

    Example:
        >>> signals = {'E1': 60, 'E2': 0, 'E3': 8, 'E4': 0, 'E5': 6, 'E6': 5, 'E7': 3}
        >>> result = calculate_ec2_score(signals)
        >>> print(f"Score: {result['total_score']}, Tier: {result['tier']}")
        Score: 82, Tier: MUST

    Signal Descriptions (per ec2-workspaces.scoring.md):
        E1: Compute Optimizer identifies instance as idle (max CPU ≤1% over 14 days)
        E2: CloudWatch metrics show low activity (p95 CPU ≤3%, Network ≤10MB/day)
        E3: CloudTrail shows no write events for instance over 90 days
        E4: SSM agent heartbeat offline or stale (PingStatus != Online OR >14d)
        E5: No service attachment (not in ASG/LB/ECS/EKS cluster)
        E6: Storage I/O minimal (p95 DiskReadOps + DiskWriteOps ≈ 0)
        E7: Cost Explorer recommends termination with savings > $0
    """
    try:
        # Use custom weights if provided, otherwise defaults
        weights = custom_weights or DEFAULT_EC2_WEIGHTS
        thresholds = tier_thresholds or TIER_THRESHOLDS

        # Signal descriptions for transparency (matches specification)
        signal_descriptions = {
            'E1': 'Compute Optimizer Idle (max CPU ≤1% for 14d)',
            'E2': 'CloudWatch CPU+Network (p95 ≤3%, ≤10MB/day)',
            'E3': 'CloudTrail no write events (90d)',
            'E4': 'SSM heartbeat (offline or >14d stale)',
            'E5': 'No service attachment (ASG/LB/ECS/EKS)',
            'E6': 'Storage I/O idle (p95 DiskOps ≈ 0)',
            'E7': 'Cost Explorer terminate savings'
        }

        # Calculate total score
        total_score = 0
        signal_breakdown = {}
        contributing_signals = []

        for signal_id, signal_score in signals.items():
            if signal_id not in weights:
                logger.warning(f"Unknown EC2 signal: {signal_id} (skipped)")
                continue

            weight = weights[signal_id]
            description = signal_descriptions.get(signal_id, f"Signal {signal_id}")

            # Add to total if signal is present (score > 0)
            if signal_score > 0:
                total_score += signal_score
                contributing_signals.append(f"{signal_id}({signal_score})")

            signal_breakdown[signal_id] = {
                'score': signal_score,
                'weight': weight,
                'description': description,
                'contributing': signal_score > 0
            }

        # Determine tier
        tier = 'KEEP'
        for tier_name, threshold in sorted(thresholds.items(), key=lambda x: x[1], reverse=True):
            if total_score >= threshold:
                tier = tier_name
                break

        # Determine recommendation
        recommendations = {
            'MUST': 'Immediate decommission candidate (high confidence)',
            'SHOULD': 'Strong decommission candidate (review recommended)',
            'COULD': 'Potential decommission candidate (manual review required)',
            'KEEP': 'Active resource (no decommission action)'
        }
        recommendation = recommendations.get(tier, 'Unknown')

        # Determine confidence based on signal coverage
        signal_count = len([s for s in signals.values() if s > 0])
        if signal_count >= 4:
            confidence = 'High'
        elif signal_count >= 2:
            confidence = 'Medium'
        else:
            confidence = 'Low'

        # Build breakdown string
        if contributing_signals:
            breakdown = ' + '.join(contributing_signals) + f' = {total_score}'
        else:
            breakdown = 'No signals detected = 0'

        return {
            'total_score': total_score,
            'tier': tier,
            'recommendation': recommendation,
            'signals': signal_breakdown,
            'confidence': confidence,
            'breakdown': breakdown,
            'signal_count': signal_count,
            'max_possible_score': sum(weights.values())
        }

    except Exception as e:
        logger.error(f"EC2 score calculation error: {e}", exc_info=True)
        return {
            'total_score': 0,
            'tier': 'ERROR',
            'recommendation': f'Scoring error: {str(e)}',
            'signals': {},
            'confidence': 'N/A',
            'breakdown': 'Error',
            'error': str(e)
        }


def calculate_workspaces_score(
    signals: Dict[str, int],
    custom_weights: Optional[Dict[str, int]] = None,
    tier_thresholds: Optional[Dict[str, int]] = None
) -> Dict:
    """
    Calculate WorkSpaces decommission score from multiple signals.

    Scoring Logic:
    - Sum of weighted signals (0-100 scale)
    - Each signal contributes its weight if criteria met
    - Tier classification based on total score
    - High transparency: breakdown included in result

    Args:
        signals: Dictionary of signal scores (W1-W6)
                 Signal key → score (0 for absent, weight for present)
                 Example: {'W1': 45, 'W2': 25, 'W3': 0, 'W4': 0, 'W5': 5, 'W6': 5}
        custom_weights: Optional custom signal weights (override defaults)
        tier_thresholds: Optional custom tier thresholds (override defaults)

    Returns:
        Dictionary with scoring results:
        {
            'total_score': 80,
            'tier': 'MUST',
            'recommendation': 'Immediate decommission candidate',
            'signals': {
                'W1': {'score': 45, 'weight': 45, 'description': 'No Connection (>90 days)'},
                'W2': {'score': 25, 'weight': 25, 'description': 'Connection History (<10%)'},
                ...
            },
            'confidence': 'High',
            'breakdown': 'W1(45) + W2(25) + W5(5) + W6(5) = 80'
        }

    Example:
        >>> signals = {'W1': 45, 'W2': 25, 'W3': 0, 'W4': 0, 'W5': 5, 'W6': 5}
        >>> result = calculate_workspaces_score(signals)
        >>> print(f"Score: {result['total_score']}, Tier: {result['tier']}")
        Score: 80, Tier: MUST

    Signal Descriptions:
        W1: No connection detected (>90 days since last user connection)
        W2: Low connection history (<10% connection days over 90 days)
        W3: ALWAYS_ON mode with low usage (<40 hours/month breakeven threshold)
        W4: WorkSpace in stopped state (>30 days)
        W5: Missing user/cost allocation tags
        W6: Classified as test/dev environment (non-production)
    """
    try:
        # Use custom weights if provided, otherwise defaults
        weights = custom_weights or DEFAULT_WORKSPACES_WEIGHTS
        thresholds = tier_thresholds or TIER_THRESHOLDS

        # Signal descriptions for transparency
        signal_descriptions = {
            'W1': 'No Connection (>90 days)',
            'W2': 'Connection History (<10% days)',
            'W3': 'ALWAYS_ON Non-Compliant (<40 hrs/mo)',
            'W4': 'Stopped State (>30 days)',
            'W5': 'No User Tags',
            'W6': 'Test/Dev Environment'
        }

        # Calculate total score
        total_score = 0
        signal_breakdown = {}
        contributing_signals = []

        for signal_id, signal_score in signals.items():
            if signal_id not in weights:
                logger.warning(f"Unknown WorkSpaces signal: {signal_id} (skipped)")
                continue

            weight = weights[signal_id]
            description = signal_descriptions.get(signal_id, f"Signal {signal_id}")

            # Add to total if signal is present (score > 0)
            if signal_score > 0:
                total_score += signal_score
                contributing_signals.append(f"{signal_id}({signal_score})")

            signal_breakdown[signal_id] = {
                'score': signal_score,
                'weight': weight,
                'description': description,
                'contributing': signal_score > 0
            }

        # Determine tier
        tier = 'KEEP'
        for tier_name, threshold in sorted(thresholds.items(), key=lambda x: x[1], reverse=True):
            if total_score >= threshold:
                tier = tier_name
                break

        # Determine recommendation
        recommendations = {
            'MUST': 'Immediate decommission candidate (high confidence)',
            'SHOULD': 'Strong decommission candidate (review recommended)',
            'COULD': 'Potential decommission candidate (manual review required)',
            'KEEP': 'Active resource (no decommission action)'
        }
        recommendation = recommendations.get(tier, 'Unknown')

        # Determine confidence based on signal coverage
        signal_count = len([s for s in signals.values() if s > 0])
        if signal_count >= 3:
            confidence = 'High'
        elif signal_count >= 2:
            confidence = 'Medium'
        else:
            confidence = 'Low'

        # Build breakdown string
        if contributing_signals:
            breakdown = ' + '.join(contributing_signals) + f' = {total_score}'
        else:
            breakdown = 'No signals detected = 0'

        return {
            'total_score': total_score,
            'tier': tier,
            'recommendation': recommendation,
            'signals': signal_breakdown,
            'confidence': confidence,
            'breakdown': breakdown,
            'signal_count': signal_count,
            'max_possible_score': sum(weights.values())
        }

    except Exception as e:
        logger.error(f"WorkSpaces score calculation error: {e}", exc_info=True)
        return {
            'total_score': 0,
            'tier': 'ERROR',
            'recommendation': f'Scoring error: {str(e)}',
            'signals': {},
            'confidence': 'N/A',
            'breakdown': 'Error',
            'error': str(e)
        }


def display_scoring_summary(
    scores: List[Dict],
    resource_type: str = 'EC2'
) -> None:
    """
    Display scoring summary with Rich CLI formatting.

    Args:
        scores: List of scoring results from calculate_ec2_score() or calculate_workspaces_score()
        resource_type: 'EC2' or 'WorkSpaces' for display customization

    Example:
        >>> ec2_scores = [calculate_ec2_score(s) for s in signal_list]
        >>> display_scoring_summary(ec2_scores, resource_type='EC2')
    """
    try:
        # Count by tier
        tier_counts = {
            'MUST': 0,
            'SHOULD': 0,
            'COULD': 0,
            'KEEP': 0
        }

        for score in scores:
            tier = score.get('tier', 'KEEP')
            if tier in tier_counts:
                tier_counts[tier] += 1

        # Create summary table
        table = create_table(
            title=f"{resource_type} Decommission Scoring Summary",
            columns=[
                {"header": "Tier", "style": "cyan bold"},
                {"header": "Count", "style": "yellow"},
                {"header": "Percentage", "style": "green"},
                {"header": "Recommendation", "style": "blue"}
            ]
        )

        total = len(scores)
        if total == 0:
            print_warning("⚠️  No scores to display")
            return

        recommendations = {
            'MUST': 'Immediate decommission (80-100)',
            'SHOULD': 'Review for decommission (50-79)',
            'COULD': 'Manual review required (25-49)',
            'KEEP': 'Active resource (<25)'
        }

        for tier in ['MUST', 'SHOULD', 'COULD', 'KEEP']:
            count = tier_counts[tier]
            percentage = (count / total * 100) if total > 0 else 0
            recommendation = recommendations[tier]

            table.add_row(
                tier,
                str(count),
                f"{percentage:.1f}%",
                recommendation
            )

        console.print(table)

        # Priority statistics
        priority_count = tier_counts['MUST'] + tier_counts['SHOULD']
        priority_pct = (priority_count / total * 100) if total > 0 else 0

        if priority_count > 0:
            print_success(f"✅ Identified {priority_count} priority decommission candidates ({priority_pct:.1f}%)")
        else:
            print_info(f"ℹ️  No high-priority decommission candidates identified")

    except Exception as e:
        print_error(f"❌ Scoring summary display failed: {e}")
        logger.error(f"Display error: {e}", exc_info=True)


def export_scores_to_dataframe(
    scores: List[Dict],
    resource_ids: List[str]
):
    """
    Export scoring results to pandas DataFrame.

    Args:
        scores: List of scoring results
        resource_ids: List of resource IDs (instance IDs or WorkSpace IDs)

    Returns:
        pandas DataFrame with scoring columns

    Example:
        >>> scores = [calculate_ec2_score(s) for s in signals_list]
        >>> df = export_scores_to_dataframe(scores, instance_ids)
        >>> df.to_excel('ec2-decommission-scores.xlsx', index=False)
    """
    import pandas as pd

    try:
        # Build DataFrame records
        records = []

        for i, score in enumerate(scores):
            resource_id = resource_ids[i] if i < len(resource_ids) else f"resource-{i}"

            record = {
                'resource_id': resource_id,
                'total_score': score.get('total_score', 0),
                'tier': score.get('tier', 'KEEP'),
                'recommendation': score.get('recommendation', 'N/A'),
                'confidence': score.get('confidence', 'N/A'),
                'signal_count': score.get('signal_count', 0),
                'breakdown': score.get('breakdown', 'N/A')
            }

            records.append(record)

        df = pd.DataFrame(records)

        print_success(f"✅ Exported {len(df)} scores to DataFrame")

        return df

    except Exception as e:
        print_error(f"❌ DataFrame export failed: {e}")
        logger.error(f"Export error: {e}", exc_info=True)
        return pd.DataFrame()

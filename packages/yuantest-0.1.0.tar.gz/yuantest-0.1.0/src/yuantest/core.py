# coding=utf-8
def hello(name="World"):
    return f"Hello, {name}!"

import logging
from typing import Optional


def setup_logger(
    name: str = "meta-analysis",
    level: int = logging.INFO,
    format_str: str = "%(asctime)s | %(levelname)s: %(message)s",
    log_file: Optional[str] = None,
) -> logging.Logger:
    """Configure and return a logger with the specified settings.

    Parameters
    ----------
    name : str
        Name of the logger
    level : int
        Logging level (e.g., logging.INFO, logging.DEBUG)
    format_str : str
        Format string for log messages
    log_file : str, optional
        Path to log file if logging to file is desired

    Returns
    -------
    logging.Logger
        Configured logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Clear existing handlers to avoid duplicate logs
    if logger.hasHandlers():
        logger.handlers.clear()

    # Create formatter
    formatter = logging.Formatter(format_str)

    # Create console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # Add file handler if log_file is specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger

"""
Auxiliary Plotting Functions - Specialized plotting utilities for BBAM analysis results.

This module provides the AuxPlots class with plotting functions for visualizing
model results, calibration outcomes, and comparative analyses.
"""

from __future__ import annotations

from typing import Any, List, Optional, Tuple

import arviz as az
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import numpy as np
import pandas as pd


class AuxPlots:
    """Auxiliary plotting functions for BBAM analysis results.

    This class provides specialized plotting methods for visualizing:
    - Event posteriors with experiment, observational, and posterior estimates
    - Calibration results comparing unpaired observations with calibrated estimates
    - Combined plots showing both paired and unpaired data
    """

    def __init__(self) -> None:
        """Initialize the AuxPlots class with default plotting parameters."""
        self.default_params = {
            "axes.labelsize": 22,
            "axes.titlesize": 16,
            "xtick.labelsize": 16,
            "ytick.labelsize": 16,
            "axes.titlepad": 5,
            "axes.labelpad": 5,
            "font.size": 20,
            "lines.linewidth": 2,
        }

    def _get_tau_parameters(self, post_summary: pd.DataFrame) -> pd.DataFrame:
        """Extract tau parameters excluding derived z_ parameters.

        Parameters
        ----------
        post_summary : pd.DataFrame
            Posterior summary DataFrame

        Returns
        -------
        pd.DataFrame
            Filtered DataFrame with tau parameters
        """
        return post_summary.loc[
            [idx for idx in post_summary.index if idx.startswith("tau[") and not idx.startswith("z_")]
        ]

    def _get_experiment_ati_parameters(self, post_summary: pd.DataFrame) -> pd.DataFrame:
        """Extract experiment_true_ati parameters excluding derived z_ parameters.

        Parameters
        ----------
        post_summary : pd.DataFrame
            Posterior summary DataFrame

        Returns
        -------
        pd.DataFrame
            Filtered DataFrame with experiment_true_ati parameters
        """
        return post_summary.loc[
            [idx for idx in post_summary.index if idx.startswith("experiment_true_ati[") and not idx.startswith("z_")]
        ]

    def _get_experiment_size_parameters(self, post_summary: pd.DataFrame) -> pd.DataFrame:
        """Extract experiment_true_size parameters excluding derived z_ parameters.

        Parameters
        ----------
        post_summary : pd.DataFrame
            Posterior summary DataFrame

        Returns
        -------
        pd.DataFrame
            Filtered DataFrame with experiment_true_size parameters
        """
        return post_summary.loc[
            [idx for idx in post_summary.index if idx.startswith("experiment_true_size[") and not idx.startswith("z_")]
        ]

    def _setup_plot_style(self) -> np.ndarray:
        """Set up consistent plotting style."""
        plt.rcParams.update(plt.rcParamsDefault)
        plt.rcdefaults()
        plt.rcParams.update(self.default_params)
        plt.rcParams["axes.prop_cycle"] = plt.cycler("color", plt.cm.viridis(np.linspace(0, 1, 10)))  # type: ignore
        return plt.cm.viridis(np.linspace(0.15, 0.85, 10))  # type: ignore

    def _format_y_axis(self, ax: plt.Axes, ylabel_units: str = "raw") -> None:
        """Format y-axis based on units specification."""
        if "percent" in ylabel_units.lower():
            ax.set_ylabel("Point Estimate [%]")
            _scale = 1.0  # Default scale
            if "-" in ylabel_units:
                _scale = float(ylabel_units.split("-")[1])
            ax.yaxis.set_major_formatter(mtick.PercentFormatter(_scale))
        else:
            ax.set_ylabel(f"Point Estimate [{ylabel_units}]")

    def _finalize_plot(
        self, fig: plt.Figure, ax: plt.Axes, title: str, ylabel_units: str, xlabel: str = "Experiment ID"
    ) -> None:
        """Apply consistent formatting and finalization.

        Parameters
        ----------
        fig : plt.Figure
            Matplotlib figure object
        ax : plt.Axes
            Matplotlib axes object
        title : str
            Plot title
        ylabel_units : str
            Y-axis units
        xlabel : str, optional
            X-axis label, default "Experiment ID"
        """
        # Reference line at zero
        ax.axhline(y=0, color="k", lw=0.6, alpha=0.8)

        # Formatting
        ax.set_xlabel(xlabel)
        self._format_y_axis(ax, ylabel_units)
        ax.grid(True, alpha=0.3)
        ax.xaxis.set_major_formatter(mtick.StrMethodFormatter("{x:.0f}"))

        # Legend
        ax.legend(fontsize=18, bbox_to_anchor=(1, 0.8))

        # Title
        fig.text(0.02, 1.08, title, fontsize=22)
        plt.tight_layout()

    def plot_event_posteriors(
        self,
        df_processed: pd.DataFrame,
        idata_base: Any,
        post_summary: pd.DataFrame,
        hp_mask: Optional[List[int]] = None,
        title: Optional[str] = None,
        ylabel_units: str = "raw",
        show_means: bool = False,
        figsize: Tuple[int, int] = (20, 6),
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Plot experiment, observational, and posterior estimates.

        Parameters
        ----------
        df_processed : pd.DataFrame
            Processed data with experiment and observational estimates
        idata_base : arviz.InferenceData
            Inference data from fitted model
        post_summary : pd.DataFrame
            Posterior summary statistics
        hp_mask : List[int], optional
            Indices of high-priority experiments to highlight
        title : str, optional
            Custom plot title
        ylabel_units : str, optional
            Y-axis units ('raw' or 'percent'), default 'raw'
        show_means : bool, optional
            Whether to show mean lines and bands, default False
        figsize : Tuple[int, int], optional
            Figure size, default (20, 6)

        Returns
        -------
        Tuple[plt.Figure, plt.Axes]
            Figure and axes objects
        """
        colors = self._setup_plot_style()

        # Create figure and axis
        fig, ax = plt.subplots(figsize=figsize)

        # Experiment results
        x_values = idata_base.observed_data["tau_experiment_est_likelihood_dim_0"].values
        y_values = df_processed["experiment_est"].values
        yerr_values = 1.645 * df_processed["experiment_est_se"].values
        ax.errorbar(
            x=x_values,
            y=y_values,
            yerr=yerr_values,
            fmt="o",
            capsize=5,
            label="Experiment with 90% CI",
            color=colors[0],
            ecolor=colors[0],
        )

        # High-precision experiments (if provided)
        if hp_mask is not None and len(hp_mask) > 0:
            x_values_hp = idata_base.observed_data["tau_experiment_est_likelihood_dim_0"].values[hp_mask]
            y_values_hp = df_processed.iloc[hp_mask]["experiment_est"].values
            yerr_values_hp = 1.645 * df_processed.iloc[hp_mask]["experiment_est_se"].values
            ax.errorbar(
                x=x_values_hp,
                y=y_values_hp,
                yerr=yerr_values_hp,
                fmt="o",
                capsize=5,
                label="High-precision experiments with 90% CI",
                color="red",
                ecolor="red",
            )

        # Observational model results
        x_values_obs = idata_base.observed_data["tau_obs_model_est_likelihood_dim_0"].values + 0.2
        y_values_obs = df_processed["obs_model_est"].values
        yerr_values_obs = 1.645 * df_processed["obs_model_est_se"].values
        ax.errorbar(
            x=x_values_obs,
            y=y_values_obs,
            yerr=yerr_values_obs,
            fmt="o",
            capsize=5,
            label="Obs.model with 90% CI",
            color=colors[4],
            ecolor=colors[4],
        )

        # Posterior estimates using helper method
        x_values_post = idata_base.observed_data["tau_experiment_est_likelihood_dim_0"].values + 0.4
        tau_params = self._get_tau_parameters(post_summary)
        y_values_post = tau_params["mean"].values
        # Use HDI intervals instead of CI
        yerr_lower = y_values_post - tau_params["hdi_5%"].values
        yerr_upper = tau_params["hdi_95%"].values - y_values_post
        yerr_values_post = [yerr_lower, yerr_upper]

        ax.errorbar(
            x=x_values_post,
            y=y_values_post,
            yerr=np.abs(yerr_values_post),
            fmt="o",
            capsize=5,
            label="Treatment effect posterior with 90% HDI",
            color="orange",
            ecolor="orange",
        )

        # Optional mean lines and bands
        if show_means and "mu_tau" in post_summary.index:
            ax.axhspan(
                ymin=post_summary.loc["mu_tau", "hdi_5%"],
                ymax=post_summary.loc["mu_tau", "hdi_95%"],
                color="r",
                alpha=0.2,
                label=None,
                lw=0.2,
                zorder=-100,
            )
            ax.axhline(
                y=post_summary.loc["mu_tau", "mean"],
                color="r",
                lw=1.0,
                linestyle="-",
                label="Avg. treatment effect with 90% HDI",
            )

            if "mean_bias" in post_summary.index:
                ax.axhline(
                    y=post_summary.loc["mu_tau", "mean"] + post_summary.loc["mean_bias", "mean"],
                    color="m",
                    lw=2.0,
                    linestyle="--",
                    label="Avg. treatment effect + mean bias",
                )

        # Apply consistent formatting and finalization
        if title is None:
            title = "Point estimates with 90%CI and treatment effect posteriors with 90%HDI"
        self._finalize_plot(fig, ax, title, ylabel_units)

        return fig, ax

    def plot_intensity_posteriors(
        self,
        df_processed: pd.DataFrame,
        idata_base: Any,
        post_summary: pd.DataFrame,
        hp_mask: Optional[List[int]] = None,
        title: Optional[str] = None,
        ylabel_units: str = "raw",
        show_means: bool = False,
        posterior_metric: str = "experiment_true_ati",
        use_monte_carlo_uncertainty: bool = True,
        figsize: Tuple[int, int] = (20, 6),
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Plot experiment, observational, and posterior treatment intensity estimates.

        This function plots treatment intensities (ATI) instead of treatment effects.
        Treatment intensity = treatment_effect / experiment_scale.

        Parameters
        ----------
        df_processed : pd.DataFrame
            Processed data with experiment and observational estimates
        idata_base : arviz.InferenceData
            Inference data from fitted model
        post_summary : pd.DataFrame
            Posterior summary statistics
        hp_mask : List[int], optional
            Indices of high-priority experiments to highlight
        title : str, optional
            Custom plot title
        ylabel_units : str, optional
            Y-axis units ('raw' or 'percent'), default 'raw'
        show_means : bool, optional
            Whether to show mean lines and bands, default False
        posterior_metric : str, optional
            Posterior metric to use: 'experiment_true_ati' (default) or 'tau'
            If 'tau', values are divided by 'experiment_true_size'
        use_monte_carlo_uncertainty : bool, optional
            Whether to use Monte Carlo sampling for uncertainty propagation when
            posterior_metric='tau'. If True, samples from posterior distributions
            to properly account for joint uncertainty. If False, uses conservative
            worst-case error propagation. Default True.
        figsize : Tuple[int, int], optional
            Figure size, default (20, 6)

        Returns
        -------
        Tuple[plt.Figure, plt.Axes]
            Figure and axes objects
        """
        colors = self._setup_plot_style()

        # Create figure and axis
        fig, ax = plt.subplots(figsize=figsize)

        # Calculate treatment intensities from the data
        # ATI = experiment_est / experiment_scale
        ati_exp = df_processed["experiment_est"] / df_processed["experiment_scale"]
        # Uncertainty propagation: sZ = Z * sqrt((sX/X)^2 + (sY/Y)^2)
        ati_exp_se = np.abs(ati_exp) * np.sqrt(
            (df_processed["experiment_est_se"] / df_processed["experiment_est"]) ** 2
            + (df_processed["experiment_scale_se"] / df_processed["experiment_scale"]) ** 2
        )

        # Observational model treatment intensities
        obs_ati = df_processed["obs_model_est"] / df_processed["experiment_scale"]
        obs_ati_se = np.abs(obs_ati) * np.sqrt(
            (df_processed["obs_model_est_se"] / df_processed["obs_model_est"]) ** 2
            + (df_processed["experiment_scale_se"] / df_processed["experiment_scale"]) ** 2
        )

        # Experiment intensity results
        x_values = idata_base.observed_data["tau_experiment_est_likelihood_dim_0"].values
        y_values = ati_exp.values
        yerr_values = 1.645 * ati_exp_se.values
        ax.errorbar(
            x=x_values,
            y=y_values,
            yerr=yerr_values,
            fmt="o",
            capsize=5,
            label="Experiment intensity with 90% CI",
            color=colors[0],
            ecolor=colors[0],
        )

        # High-precision experiments (if provided)
        if hp_mask is not None and len(hp_mask) > 0:
            x_values_hp = idata_base.observed_data["tau_experiment_est_likelihood_dim_0"].values[hp_mask]
            y_values_hp = ati_exp.iloc[hp_mask].values
            yerr_values_hp = 1.645 * ati_exp_se.iloc[hp_mask].values
            ax.errorbar(
                x=x_values_hp,
                y=y_values_hp,
                yerr=yerr_values_hp,
                fmt="o",
                capsize=5,
                label="High-precision experiment intensity with 90% CI",
                color="red",
                ecolor="red",
            )

        # Observational model intensity results
        x_values_obs = idata_base.observed_data["tau_obs_model_est_likelihood_dim_0"].values + 0.2
        y_values_obs = obs_ati.values
        yerr_values_obs = 1.645 * obs_ati_se.values
        ax.errorbar(
            x=x_values_obs,
            y=y_values_obs,
            yerr=yerr_values_obs,
            fmt="o",
            capsize=5,
            label="Obs.model intensity with 90% CI",
            color=colors[4],
            ecolor=colors[4],
        )

        # Posterior intensity estimates
        x_values_post = idata_base.observed_data["tau_experiment_est_likelihood_dim_0"].values + 0.4

        if posterior_metric == "experiment_true_ati":
            # Use experiment_true_ati directly from post_summary using helper method
            ati_params = self._get_experiment_ati_parameters(post_summary)
            y_values_post = ati_params["mean"].values
            # Use HDI intervals instead of CI
            yerr_lower = y_values_post - ati_params["hdi_5%"].values
            yerr_upper = ati_params["hdi_95%"].values - y_values_post
            yerr_values_post = [yerr_lower, yerr_upper]

        elif posterior_metric == "tau":
            # Use tau divided by experiment_true_size using helper methods
            tau_params = self._get_tau_parameters(post_summary)
            size_params = self._get_experiment_size_parameters(post_summary)

            tau_values = tau_params["mean"].values
            size_values = size_params["mean"].values
            y_values_post = tau_values / size_values

            if use_monte_carlo_uncertainty:
                # Monte Carlo sampling for proper uncertainty propagation
                try:
                    # Extract posterior samples for tau and experiment_true_size with defensive access
                    tau_posterior = idata_base.posterior["tau"]
                    size_posterior = idata_base.posterior["experiment_true_size"]

                    # Use defensive pattern similar to _extract_posterior_values
                    if hasattr(tau_posterior, "values"):
                        tau_samples = tau_posterior.values.flatten()
                    else:
                        tau_samples = tau_posterior.flatten()

                    if hasattr(size_posterior, "values"):
                        size_samples = size_posterior.values.flatten()
                    else:
                        size_samples = size_posterior.flatten()

                    # Reshape samples to match observation dimensions
                    n_obs = len(tau_values)
                    n_samples_per_obs = len(tau_samples) // n_obs
                    tau_samples_reshaped = tau_samples.reshape(n_samples_per_obs, n_obs)
                    size_samples_reshaped = size_samples.reshape(n_samples_per_obs, n_obs)

                    # Calculate ratio samples for each observation
                    ratio_samples = tau_samples_reshaped / size_samples_reshaped

                    # Calculate HDI from ratio distribution for each observation
                    yerr_lower = y_values_post - np.percentile(ratio_samples, 5, axis=0)
                    yerr_upper = np.percentile(ratio_samples, 95, axis=0) - y_values_post
                    yerr_values_post = [yerr_lower, yerr_upper]

                except (KeyError, AttributeError, ValueError, TypeError):
                    # Fallback to conservative error propagation if Monte Carlo fails
                    tau_hdi_lower = tau_params["hdi_5%"].values
                    tau_hdi_upper = tau_params["hdi_95%"].values
                    size_hdi_lower = size_params["hdi_5%"].values
                    size_hdi_upper = size_params["hdi_95%"].values

                    # Conservative error propagation (worst-case scenarios)
                    yerr_lower = y_values_post - (tau_hdi_lower / size_hdi_upper)
                    yerr_upper = (tau_hdi_upper / size_hdi_lower) - y_values_post
                    yerr_values_post = [yerr_lower, yerr_upper]
            else:
                # Conservative error propagation (original approach)
                tau_hdi_lower = tau_params["hdi_5%"].values
                tau_hdi_upper = tau_params["hdi_95%"].values
                size_hdi_lower = size_params["hdi_5%"].values
                size_hdi_upper = size_params["hdi_95%"].values

                # Conservative error propagation (worst-case scenarios)
                yerr_lower = y_values_post - (tau_hdi_lower / size_hdi_upper)
                yerr_upper = (tau_hdi_upper / size_hdi_lower) - y_values_post
                yerr_values_post = [yerr_lower, yerr_upper]
        else:
            raise ValueError(f"Invalid posterior_metric: {posterior_metric}. Must be 'experiment_true_ati' or 'tau'")

        ax.errorbar(
            x=x_values_post,
            y=y_values_post,
            yerr=np.abs(yerr_values_post),
            fmt="o",
            capsize=5,
            label="Treatment intensity posterior with 90% HDI",
            color="orange",
            ecolor="orange",
        )

        # Optional mean lines and bands
        if show_means and "mu_ati" in post_summary.index:
            ax.axhspan(
                ymin=post_summary.loc["mu_ati", "hdi_5%"],
                ymax=post_summary.loc["mu_ati", "hdi_95%"],
                color="r",
                alpha=0.2,
                label=None,
                lw=0.2,
                zorder=-100,
            )
            ax.axhline(
                y=post_summary.loc["mu_ati", "mean"],
                color="r",
                lw=1.0,
                linestyle="-",
                label="Avg. treatment intensity with 90% HDI",
            )

        # Apply consistent formatting and finalization
        if title is None:
            title = "Treatment Intensity Estimates with 90%CI and Posteriors with 90%HDI"
        self._finalize_plot(fig, ax, title, ylabel_units)

        return fig, ax

    def plot_calibration_results(
        self,
        df_unpaired: pd.DataFrame,
        calibration_trace: Any,
        show_bias_corrections: bool = False,
        title: Optional[str] = None,
        ylabel_units: str = "raw",
        figsize: Tuple[int, int] = (20, 6),
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create calibration results plot showing unpaired obs estimates vs calibrated posteriors.

        Parameters
        ----------
        df_unpaired : pd.DataFrame
            Unpaired observational data
        calibration_trace : arviz.InferenceData
            Trace from calibration model
        show_bias_corrections : bool, optional
            Whether to show bias corrections as points, default False
        title : str, optional
            Custom plot title
        ylabel_units : str, optional
            Y-axis units ('raw' or 'percent'), default 'raw'
        figsize : Tuple[int, int], optional
            Figure size, default (20, 6)

        Returns
        -------
        Tuple[plt.Figure, plt.Axes]
            Figure and axes objects
        """
        colors = self._setup_plot_style()

        # Get calibrated estimates summary
        calibrated_summary = az.summary(calibration_trace, var_names=["calibrated_estimates"])

        # Create figure and axis
        fig, ax = plt.subplots(figsize=figsize)

        # Unpaired observational model estimates
        x_values = np.arange(len(df_unpaired))
        y_values = df_unpaired["obs_model_est"].values
        yerr_values = 1.645 * df_unpaired["obs_model_est_se"].values  # 90% CI

        ax.errorbar(
            x=x_values,
            y=y_values,
            yerr=yerr_values,
            fmt="o",
            capsize=5,
            label="Unpaired obs.model with 90% CI",
            color=colors[4],
            ecolor=colors[4],
        )

        # Calibrated estimates from posterior
        x_values_cal = x_values + 0.2
        calibrated_means = calibrated_summary["mean"].values

        # Use HDI intervals if available, otherwise fall back to CI
        if "hdi_5%" in calibrated_summary.columns and "hdi_95%" in calibrated_summary.columns:
            yerr_cal_lower = calibrated_means - calibrated_summary["hdi_5%"].values
            yerr_cal_upper = calibrated_summary["hdi_95%"].values - calibrated_means
            yerr_cal = [yerr_cal_lower, yerr_cal_upper]
            label_text = "Calibrated estimates with 90% HDI"
        else:
            yerr_cal_values = 1.645 * calibrated_summary["sd"].values
            yerr_cal = [yerr_cal_values, yerr_cal_values]
            label_text = "Calibrated estimates with 90% CI"

        ax.errorbar(
            x=x_values_cal,
            y=calibrated_means,
            yerr=yerr_cal,
            fmt="o",
            capsize=5,
            label=label_text,
            color="orange",
            ecolor="orange",
        )

        # Optional bias corrections
        if show_bias_corrections:
            bias_corrections = y_values - calibrated_means
            x_values_bias = x_values + 0.4
            ax.scatter(
                x=x_values_bias, y=bias_corrections, marker="s", s=80, label="Bias corrections", color="red", alpha=0.7
            )

        # Apply consistent formatting and finalization
        if title is None:
            title = "Calibration Results: Unpaired Obs.Model vs Calibrated Estimates with 90%HDI"
        self._finalize_plot(fig, ax, title, ylabel_units, "Unpaired Observation ID")

        return fig, ax

    def plot_combined_paired_unpaired_results(
        self,
        df_processed: pd.DataFrame,
        idata_base: Any,
        post_summary: pd.DataFrame,
        df_unpaired: pd.DataFrame,
        calibration_trace: Any,
        hp_mask: Optional[List[int]] = None,
        title: Optional[str] = None,
        ylabel_units: str = "raw",
        figsize: Tuple[int, int] = (20, 6),
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create combined plot showing paired experiments and unpaired calibrated results.

        Parameters
        ----------
        df_processed : pd.DataFrame
            Original paired data
        idata_base : arviz.InferenceData
            Inference data from main model
        post_summary : pd.DataFrame
            Posterior summary from main model
        df_unpaired : pd.DataFrame
            Unpaired observational data
        calibration_trace : arviz.InferenceData
            Trace from calibration model
        hp_mask : List[int], optional
            Indices of high-priority experiments
        title : str, optional
            Custom plot title
        ylabel_units : str, optional
            Y-axis units ('raw' or 'percent'), default 'raw'
        figsize : Tuple[int, int], optional
            Figure size, default (20, 6)

        Returns
        -------
        Tuple[plt.Figure, plt.Axes]
            Figure and axes objects
        """
        colors = self._setup_plot_style()

        # Get calibrated estimates summary
        calibrated_summary = az.summary(calibration_trace, var_names=["calibrated_estimates"])

        # Create figure and axis
        fig, ax = plt.subplots(figsize=figsize)

        n_paired = len(df_processed)
        n_unpaired = len(df_unpaired)

        # PAIRED DATA SECTION (indices 0 to n_paired-1)

        # Experiment results (paired)
        x_values = np.arange(n_paired)
        y_values = df_processed["experiment_est"].values
        yerr_values = 1.645 * df_processed["experiment_est_se"].values
        ax.errorbar(
            x=x_values,
            y=y_values,
            yerr=yerr_values,
            fmt="o",
            capsize=5,
            label="Experiment with 90% CI",
            color=colors[0],
            ecolor=colors[0],
        )

        # High-precision experiments (if provided)
        if hp_mask is not None and len(hp_mask) > 0:
            x_values_hp = np.array(hp_mask)
            y_values_hp = df_processed.iloc[hp_mask]["experiment_est"].values
            yerr_values_hp = 1.645 * df_processed.iloc[hp_mask]["experiment_est_se"].values
            ax.errorbar(
                x=x_values_hp,
                y=y_values_hp,
                yerr=yerr_values_hp,
                fmt="o",
                capsize=5,
                label="High-precision experiments with 90% CI",
                color="red",
                ecolor="red",
            )

        # Observational model results (paired)
        x_values_obs = x_values + 0.2
        y_values_obs = df_processed["obs_model_est"].values
        yerr_values_obs = 1.645 * df_processed["obs_model_est_se"].values
        ax.errorbar(
            x=x_values_obs,
            y=y_values_obs,
            yerr=yerr_values_obs,
            fmt="o",
            capsize=5,
            label="Paired obs.model with 90% CI",
            color=colors[4],
            ecolor=colors[4],
        )

        # True effect posterior (paired) using helper method
        x_values_post = x_values + 0.4
        tau_params = self._get_tau_parameters(post_summary)
        y_values_post = tau_params["mean"].values

        # Use HDI intervals if available, otherwise fall back to CI
        if "hdi_5%" in tau_params.columns and "hdi_95%" in tau_params.columns:
            yerr_post_lower = y_values_post - tau_params["hdi_5%"].values
            yerr_post_upper = tau_params["hdi_95%"].values - y_values_post
            yerr_values_post = [yerr_post_lower, yerr_post_upper]
            label_text = "Treatment effect posterior with 90% HDI"
        else:
            yerr_values_post = 1.645 * tau_params["sd"].values
            label_text = "Treatment effect posterior with 90% CI"

        ax.errorbar(
            x=x_values_post,
            y=y_values_post,
            yerr=yerr_values_post,
            fmt="o",
            capsize=5,
            label=label_text,
            color="orange",
            ecolor="orange",
        )

        # UNPAIRED DATA SECTION (indices n_paired to n_paired+n_unpaired-1)

        # Unpaired observational model estimates
        x_values_unpaired = np.arange(n_paired, n_paired + n_unpaired)
        y_values_unpaired = df_unpaired["obs_model_est"].values
        yerr_values_unpaired = 1.645 * df_unpaired["obs_model_est_se"].values
        ax.errorbar(
            x=x_values_unpaired,
            y=y_values_unpaired,
            yerr=yerr_values_unpaired,
            fmt="s",
            capsize=5,
            label="Unpaired obs.model with 90% CI",
            color=colors[6],
            ecolor=colors[6],
        )

        # Calibrated estimates (unpaired)
        x_values_cal = x_values_unpaired + 0.2
        calibrated_means = calibrated_summary["mean"].values

        # Use HDI intervals if available, otherwise fall back to CI
        if "hdi_5%" in calibrated_summary.columns and "hdi_95%" in calibrated_summary.columns:
            yerr_cal_lower = calibrated_means - calibrated_summary["hdi_5%"].values
            yerr_cal_upper = calibrated_summary["hdi_95%"].values - calibrated_means
            yerr_cal = [yerr_cal_lower, yerr_cal_upper]
            label_text = "Calibrated estimates with 90% HDI"
        else:
            yerr_cal_values = 1.645 * calibrated_summary["sd"].values
            yerr_cal = [yerr_cal_values, yerr_cal_values]
            label_text = "Calibrated estimates with 90% CI"

        ax.errorbar(
            x=x_values_cal,
            y=calibrated_means,
            yerr=yerr_cal,
            fmt="s",
            capsize=5,
            label=label_text,
            color="purple",
            ecolor="purple",
        )

        # Add vertical line to separate paired from unpaired
        ax.axvline(x=n_paired - 0.5, color="gray", linestyle="--", alpha=0.5, linewidth=1)
        ax.text(n_paired / 2, ax.get_ylim()[1] * 0.9, "Paired Data", ha="center", fontsize=16, alpha=0.7)
        ax.text(n_paired + n_unpaired / 2, ax.get_ylim()[1] * 0.9, "Unpaired Data", ha="center", fontsize=16, alpha=0.7)

        # Apply consistent formatting and finalization
        if title is None:
            title = "Combined Results: Paired RCT+Obs vs Unpaired Calibrated Estimates with 90%HDI"
        self._finalize_plot(fig, ax, title, ylabel_units)

        return fig, ax

    def plot_experiment_scaled_results(
        self,
        df_processed: pd.DataFrame,
        idata_base: Any,
        post_summary: pd.DataFrame,
        hp_mask: Optional[List[int]] = None,
        title: Optional[str] = None,
        ylabel_units: str = "scaled raw",
        show_means: bool = False,
        posterior_metric: str = "experiment_true_ati",
        scaling_metric: str = "experiment_scale",
        experiment_ati_metric: str = "experiment_est",
        experiment_ati_se_metric: str = "experiment_est_se",
        obs_ati_metric: str = "obs_model_est",
        obs_ati_se_metric: str = "obs_model_est_se",
        figsize: Tuple[int, int] = (20, 6),
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Plot experiment, observational, and posterior ATI estimates scaled to total treatment effects.

        This is the scaled version of plot_intensity_posteriors. It takes ATI estimates and scales them
        up to total treatment effects by multiplying by the experiment_scale values.

        Parameters
        ----------
        df_processed : pd.DataFrame
            Processed data with experiment and observational ATI estimates
        idata_base : arviz.InferenceData
            Inference data from fitted model
        post_summary : pd.DataFrame
            Posterior summary statistics containing ATI posteriors
        hp_mask : List[int], optional
            Indices of high-priority experiments to highlight
        title : str, optional
            Custom plot title
        ylabel_units : str, optional
            Y-axis units ('scaled raw' or 'scaled percent'), default 'scaled raw'
        show_means : bool, optional
            Whether to show mean lines and bands, default False
        posterior_metric : str, optional
            Posterior metric to use and scale: 'experiment_true_ati' (default), 'tau', or 'bias'
        scaling_metric : str, optional
            Column name for scaling values, default 'experiment_scale'
        experiment_ati_metric : str, optional
            Column name for experiment ATI estimates, default 'experiment_est'
        experiment_ati_se_metric : str, optional
            Column name for experiment ATI standard errors, default 'experiment_est_se'
        obs_ati_metric : str, optional
            Column name for observational ATI estimates, default 'obs_model_est'
        obs_ati_se_metric : str, optional
            Column name for observational ATI standard errors, default 'obs_model_est_se'
        figsize : Tuple[int, int], optional
            Figure size, default (20, 6)

        Returns
        -------
        Tuple[plt.Figure, plt.Axes]
            Figure and axes objects
        """
        colors = self._setup_plot_style()

        # Create figure and axis
        fig, ax = plt.subplots(figsize=figsize)

        # Get scaling values from the dataframe
        scaling_values = df_processed[scaling_metric].values

        # Get experiment ATI estimates and scale to total treatment effects
        ati_exp = df_processed[experiment_ati_metric].values
        ati_exp_se = df_processed[experiment_ati_se_metric].values
        scaled_exp_est = ati_exp * scaling_values

        # Uncertainty propagation for scaled experiment estimates
        if f"{scaling_metric}_se" in df_processed.columns:
            scaling_se = df_processed[f"{scaling_metric}_se"].values
            scaled_exp_est_se = np.abs(scaled_exp_est) * np.sqrt(
                (ati_exp_se / ati_exp) ** 2 + (scaling_se / scaling_values) ** 2
            )
        else:
            scaled_exp_est_se = ati_exp_se * scaling_values

        # Experiment scaled results
        x_values = idata_base.observed_data["tau_experiment_est_likelihood_dim_0"].values
        y_values = scaled_exp_est
        yerr_values = 1.645 * scaled_exp_est_se
        ax.errorbar(
            x=x_values,
            y=y_values,
            yerr=yerr_values,
            fmt="o",
            capsize=5,
            label="Experiment scaled with 90% CI",
            color=colors[0],
            ecolor=colors[0],
        )

        # High-precision experiments (if provided)
        if hp_mask is not None and len(hp_mask) > 0:
            x_values_hp = idata_base.observed_data["tau_experiment_est_likelihood_dim_0"].values[hp_mask]
            y_values_hp = scaled_exp_est[hp_mask]
            yerr_values_hp = 1.645 * scaled_exp_est_se[hp_mask]
            ax.errorbar(
                x=x_values_hp,
                y=y_values_hp,
                yerr=yerr_values_hp,
                fmt="o",
                capsize=5,
                label="High-precision experiment scaled with 90% CI",
                color="red",
                ecolor="red",
            )

        # Get observational ATI estimates and scale to total treatment effects
        obs_ati = df_processed[obs_ati_metric].values
        obs_ati_se = df_processed[obs_ati_se_metric].values
        scaled_obs_est = obs_ati * scaling_values

        # Uncertainty propagation for scaled observational estimates
        if f"{scaling_metric}_se" in df_processed.columns:
            scaling_se = df_processed[f"{scaling_metric}_se"].values
            scaled_obs_est_se = np.abs(scaled_obs_est) * np.sqrt(
                (obs_ati_se / obs_ati) ** 2 + (scaling_se / scaling_values) ** 2
            )
        else:
            scaled_obs_est_se = obs_ati_se * scaling_values

        # Observational model scaled results
        x_values_obs = idata_base.observed_data["tau_obs_model_est_likelihood_dim_0"].values + 0.2
        y_values_obs = scaled_obs_est
        yerr_values_obs = 1.645 * scaled_obs_est_se
        ax.errorbar(
            x=x_values_obs,
            y=y_values_obs,
            yerr=yerr_values_obs,
            fmt="o",
            capsize=5,
            label="Obs.model scaled with 90% CI",
            color=colors[4],
            ecolor=colors[4],
        )

        # Scale posterior ATI estimates to total treatment effects
        x_values_post = idata_base.observed_data["tau_experiment_est_likelihood_dim_0"].values + 0.4

        if posterior_metric == "experiment_true_ati":
            # Use experiment_true_ati directly from post_summary and scale
            posterior_mask = post_summary.index.str.contains(
                r"experiment_true_ati\["
            ) & ~post_summary.index.str.contains(r"z_")
            ati_post_means = post_summary[posterior_mask]["mean"].values
            scaled_post_means = ati_post_means * scaling_values

            # Scale HDI intervals
            ati_hdi_lower = post_summary[posterior_mask]["hdi_5%"].values
            ati_hdi_upper = post_summary[posterior_mask]["hdi_95%"].values
            scaled_hdi_lower = ati_hdi_lower * scaling_values
            scaled_hdi_upper = ati_hdi_upper * scaling_values
            yerr_post_lower = scaled_post_means - scaled_hdi_lower
            yerr_post_upper = scaled_hdi_upper - scaled_post_means
            yerr_values_post = [yerr_post_lower, yerr_post_upper]

        elif posterior_metric == "tau":
            # Scale tau (scaling is applied by default, expecting pre-scaled to un-scale)
            tau_mask = post_summary.index.str.contains(r"tau\[") & ~post_summary.index.str.contains(r"z_")
            scaled_post_means = post_summary[tau_mask]["mean"].values * scaling_values
            yerr_post_lower = scaled_post_means - post_summary[tau_mask]["hdi_5%"].values * scaling_values
            yerr_post_upper = post_summary[tau_mask]["hdi_95%"].values * scaling_values - scaled_post_means
            yerr_values_post = [yerr_post_lower, yerr_post_upper]

        elif posterior_metric == "bias":
            # Scale bias (scaling applied by default)
            bias_mask = post_summary.index.str.contains(r"bias\[") & ~post_summary.index.str.contains(r"z_")
            scaled_post_means = post_summary[bias_mask]["mean"].values * scaling_values
            yerr_post_lower = scaled_post_means - post_summary[bias_mask]["hdi_5%"].values * scaling_values
            yerr_post_upper = post_summary[bias_mask]["hdi_95%"].values * scaling_values - scaled_post_means
            yerr_values_post = [yerr_post_lower, yerr_post_upper]
        else:
            raise ValueError(
                f"Invalid posterior_metric: {posterior_metric}. Must be 'experiment_true_ati', 'tau', or 'bias'"
            )

        ax.errorbar(
            x=x_values_post,
            y=scaled_post_means,
            yerr=np.abs(yerr_values_post),
            fmt="o",
            capsize=5,
            label="Treatment effect posterior scaled with 90% HDI",
            color="orange",
            ecolor="orange",
        )

        # Optional mean lines and bands (scaled)
        if show_means and "mu_ati" in post_summary.index:
            # Scale the mean ATI to total treatment effect
            mean_scaling = scaling_values.mean()  # Use average scaling for overall mean
            scaled_mu_ati_mean = post_summary.loc["mu_ati", "mean"] * mean_scaling
            scaled_mu_ati_hdi_lower = post_summary.loc["mu_ati", "hdi_5%"] * mean_scaling
            scaled_mu_ati_hdi_upper = post_summary.loc["mu_ati", "hdi_95%"] * mean_scaling

            ax.axhspan(
                ymin=scaled_mu_ati_hdi_lower,
                ymax=scaled_mu_ati_hdi_upper,
                color="r",
                alpha=0.2,
                label=None,
                lw=0.2,
                zorder=-100,
            )
            ax.axhline(
                y=scaled_mu_ati_mean,
                color="r",
                lw=1.0,
                linestyle="-",
                label="Avg. treatment effect scaled with 90% HDI",
            )

        # Apply consistent formatting and finalization
        if title is None:
            title = f"Scaled Treatment Effects: ATI Estimates × {scaling_metric} with 90%HDI"
        self._finalize_plot(fig, ax, title, ylabel_units)

        return fig, ax

    def plot_calibration_scaled_results(
        self,
        df_unpaired: pd.DataFrame,
        calibration_trace: Any,
        show_bias_corrections: bool = False,
        title: Optional[str] = None,
        ylabel_units: str = "scaled raw",
        scaling_metric: str = "experiment_scale",
        obs_ati_metric: str = "obs_model_est",
        obs_ati_se_metric: str = "obs_model_est_se",
        calibrated_ati_metric: str = "experiment_true_ati_unpaired",
        figsize: Tuple[int, int] = (20, 6),
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create calibration scaled results plot showing unpaired ATI estimates scaled to total treatment effects.

        This function takes ATI estimates from a basic model and scales them up to total treatment effects
        by multiplying by the experiment_scale values. This is the scaled version of plot_calibration_results.

        Parameters
        ----------
        df_unpaired : pd.DataFrame
            Unpaired observational data containing ATI estimates and scaling metrics
        calibration_trace : arviz.InferenceData
            Trace from calibration model containing ATI posteriors
        show_bias_corrections : bool, optional
            Whether to show bias corrections as points, default False
        title : str, optional
            Custom plot title
        ylabel_units : str, optional
            Y-axis units ('scaled raw' or 'scaled percent'), default 'scaled raw'
        scaling_metric : str, optional
            Column name in df_unpaired to use for scaling, default 'experiment_scale'
        obs_ati_metric : str, optional
            Column name for observational ATI estimates, default 'obs_model_est'
        obs_ati_se_metric : str, optional
            Column name for observational ATI standard errors, default 'obs_model_est_se'
        calibrated_ati_metric : str, optional
            Variable name for calibrated ATI posteriors, default 'experiment_true_ati_unpaired'
            Use 'calibrated_estimates' if model is pre-scaled
        figsize : Tuple[int, int], optional
            Figure size, default (20, 6)

        Returns
        -------
        Tuple[plt.Figure, plt.Axes]
            Figure and axes objects
        """
        colors = self._setup_plot_style()

        # Get calibrated ATI estimates summary - handle both pre-scaled and ATI models
        try:
            calibrated_summary = az.summary(calibration_trace, var_names=[calibrated_ati_metric])
        except KeyError:
            # Fallback to calibrated_estimates if the specified metric doesn't exist
            calibrated_summary = az.summary(calibration_trace, var_names=["calibrated_estimates"])
            calibrated_ati_metric = "calibrated_estimates"

        # Create figure and axis
        fig, ax = plt.subplots(figsize=figsize)

        # Get scaling values from the dataframe
        scaling_values = df_unpaired[scaling_metric].values

        # Get observational ATI estimates
        obs_ati = df_unpaired[obs_ati_metric].values
        obs_ati_se = df_unpaired[obs_ati_se_metric].values

        # Scale ATI estimates to total treatment effects
        scaled_obs_est = obs_ati * scaling_values
        # Uncertainty propagation: sZ = Z * sqrt((sX/X)^2 + (sY/Y)^2)
        if f"{scaling_metric}_se" in df_unpaired.columns:
            scaling_se = df_unpaired[f"{scaling_metric}_se"].values
            scaled_obs_est_se = np.abs(scaled_obs_est) * np.sqrt(
                (obs_ati_se / obs_ati) ** 2 + (scaling_se / scaling_values) ** 2
            )
        else:
            # If no scaling uncertainty, just scale the ATI uncertainty
            scaled_obs_est_se = obs_ati_se * scaling_values

        # Unpaired observational model scaled estimates
        x_values = np.arange(len(df_unpaired))
        y_values = scaled_obs_est
        yerr_values = 1.645 * scaled_obs_est_se  # 90% CI

        ax.errorbar(
            x=x_values,
            y=y_values,
            yerr=yerr_values,
            fmt="o",
            capsize=5,
            label="Unpaired obs.model scaled with 90% CI",
            color=colors[4],
            ecolor=colors[4],
        )

        # Scale calibrated ATI estimates to total treatment effects
        x_values_cal = x_values + 0.2
        calibrated_ati_means = calibrated_summary["mean"].values
        scaled_calibrated_means = calibrated_ati_means * scaling_values

        # Use HDI intervals if available, otherwise fall back to CI
        if "hdi_5%" in calibrated_summary.columns and "hdi_95%" in calibrated_summary.columns:
            # Scale HDI intervals by scaling_metric
            scaled_hdi_lower = calibrated_summary["hdi_5%"].values * scaling_values
            scaled_hdi_upper = calibrated_summary["hdi_95%"].values * scaling_values
            yerr_cal_lower = scaled_calibrated_means - scaled_hdi_lower
            yerr_cal_upper = scaled_hdi_upper - scaled_calibrated_means
            yerr_cal = [yerr_cal_lower, yerr_cal_upper]
            label_text = "Calibrated scaled estimates with 90% HDI"
        else:
            # Scale standard deviation by scaling_metric
            scaled_sd = calibrated_summary["sd"].values * scaling_values
            yerr_cal_values = 1.645 * scaled_sd
            yerr_cal = [yerr_cal_values, yerr_cal_values]
            label_text = "Calibrated scaled estimates with 90% CI"

        ax.errorbar(
            x=x_values_cal,
            y=scaled_calibrated_means,
            yerr=yerr_cal,
            fmt="o",
            capsize=5,
            label=label_text,
            color="orange",
            ecolor="orange",
        )

        # Optional bias corrections (scaled)
        if show_bias_corrections:
            bias_corrections = y_values - scaled_calibrated_means
            x_values_bias = x_values + 0.4
            ax.scatter(
                x=x_values_bias,
                y=bias_corrections,
                marker="s",
                s=80,
                label="Scaled bias corrections",
                color="red",
                alpha=0.7,
            )

        # Apply consistent formatting and finalization
        if title is None:
            title = f"Calibration Scaled Results: ATI Estimates × {scaling_metric} with 90%HDI"
        self._finalize_plot(fig, ax, title, ylabel_units, "Unpaired Observation ID")

        return fig, ax

    def plot_combined_paired_unpaired_scaled_results(
        self,
        df_processed: pd.DataFrame,
        idata_base: Any,
        post_summary: pd.DataFrame,
        df_unpaired: pd.DataFrame,
        calibration_trace: Any,
        hp_mask: Optional[List[int]] = None,
        title: Optional[str] = None,
        ylabel_units: str = "scaled raw",
        posterior_metric: str = "experiment_true_ati",
        scaling_metric: str = "experiment_scale",
        experiment_ati_metric: str = "experiment_est",
        experiment_ati_se_metric: str = "experiment_est_se",
        obs_ati_metric: str = "obs_model_est",
        obs_ati_se_metric: str = "obs_model_est_se",
        calibrated_ati_metric: str = "experiment_true_ati_unpaired",
        figsize: Tuple[int, int] = (20, 6),
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create combined scaled plot showing paired ATI experiments and unpaired calibrated ATI results,
           all scaled to total effects.

        This function takes ATI estimates from a basic model and scales them up to total treatment effects
        by multiplying by the experiment_scale values. This is the scaled version of
        plot_combined_paired_unpaired_results.

        Parameters
        ----------
        df_processed : pd.DataFrame
            Original paired data containing ATI estimates and scaling metrics
        idata_base : arviz.InferenceData
            Inference data from main model
        post_summary : pd.DataFrame
            Posterior summary from main model (containing ATI posteriors)
        df_unpaired : pd.DataFrame
            Unpaired observational data containing ATI estimates and scaling metrics
        calibration_trace : arviz.InferenceData
            Trace from calibration model containing ATI posteriors
        hp_mask : List[int], optional
            Indices of high-priority experiments
        title : str, optional
            Custom plot title
        ylabel_units : str, optional
            Y-axis units ('scaled raw' or 'scaled percent'), default 'scaled raw'
        posterior_metric : str, optional
            Posterior metric to use for paired data: 'experiment_true_ati' (default), 'tau', or 'bias'
        scaling_metric : str, optional
            Column name to use for scaling, default 'experiment_scale'
        experiment_ati_metric : str, optional
            Column name for experiment ATI estimates, default 'experiment_est'
        experiment_ati_se_metric : str, optional
            Column name for experiment ATI standard errors, default 'experiment_est_se'
        obs_ati_metric : str, optional
            Column name for observational ATI estimates, default 'obs_model_est'
        obs_ati_se_metric : str, optional
            Column name for observational ATI standard errors, default 'obs_model_est_se'
        calibrated_ati_metric : str, optional
            Variable name for calibrated ATI posteriors, default 'experiment_true_ati_unpaired'
            Use 'calibrated_estimates' if model is pre-scaled
        figsize : Tuple[int, int], optional
            Figure size, default (20, 6)

        Returns
        -------
        Tuple[plt.Figure, plt.Axes]
            Figure and axes objects
        """
        colors = self._setup_plot_style()

        # Get calibrated ATI estimates summary - handle both pre-scaled and ATI models
        try:
            calibrated_summary = az.summary(calibration_trace, var_names=[calibrated_ati_metric])
        except KeyError:
            # Fallback to calibrated_estimates if the specified metric doesn't exist
            calibrated_summary = az.summary(calibration_trace, var_names=["calibrated_estimates"])
            calibrated_ati_metric = "calibrated_estimates"

        # Create figure and axis
        fig, ax = plt.subplots(figsize=figsize)

        n_paired = len(df_processed)
        n_unpaired = len(df_unpaired)

        # PAIRED DATA SECTION (indices 0 to n_paired-1)

        # Get scaling values for paired data
        paired_scaling_values = df_processed[scaling_metric].values

        # Get experiment ATI estimates
        ati_exp = df_processed[experiment_ati_metric].values
        ati_exp_se = df_processed[experiment_ati_se_metric].values

        # Scale experiment ATI to total treatment effects
        scaled_exp_est = ati_exp * paired_scaling_values
        # Uncertainty propagation
        if f"{scaling_metric}_se" in df_processed.columns:
            paired_scaling_se = df_processed[f"{scaling_metric}_se"].values
            scaled_exp_est_se = np.abs(scaled_exp_est) * np.sqrt(
                (ati_exp_se / ati_exp) ** 2 + (paired_scaling_se / paired_scaling_values) ** 2
            )
        else:
            # If no scaling uncertainty, just scale the ATI uncertainty
            scaled_exp_est_se = ati_exp_se * paired_scaling_values

        # Experiment scaled results (paired)
        x_values = np.arange(n_paired)
        y_values = scaled_exp_est
        yerr_values = 1.645 * scaled_exp_est_se
        ax.errorbar(
            x=x_values,
            y=y_values,
            yerr=yerr_values,
            fmt="o",
            capsize=5,
            label="Experiment scaled with 90% CI",
            color=colors[0],
            ecolor=colors[0],
        )

        # High-precision experiments (if provided)
        if hp_mask is not None and len(hp_mask) > 0:
            x_values_hp = np.array(hp_mask)
            y_values_hp = scaled_exp_est[hp_mask]
            yerr_values_hp = 1.645 * scaled_exp_est_se[hp_mask]
            ax.errorbar(
                x=x_values_hp,
                y=y_values_hp,
                yerr=yerr_values_hp,
                fmt="o",
                capsize=5,
                label="High-precision experiment scaled with 90% CI",
                color="red",
                ecolor="red",
            )

        # Get observational ATI estimates for paired data
        obs_ati = df_processed[obs_ati_metric].values
        obs_ati_se = df_processed[obs_ati_se_metric].values

        # Scale observational ATI to total treatment effects
        scaled_obs_est = obs_ati * paired_scaling_values
        # Uncertainty propagation
        if f"{scaling_metric}_se" in df_processed.columns:
            paired_scaling_se = df_processed[f"{scaling_metric}_se"].values
            scaled_obs_est_se = np.abs(scaled_obs_est) * np.sqrt(
                (obs_ati_se / obs_ati) ** 2 + (paired_scaling_se / paired_scaling_values) ** 2
            )
        else:
            # If no scaling uncertainty, just scale the ATI uncertainty
            scaled_obs_est_se = obs_ati_se * paired_scaling_values

        # Observational model scaled results (paired)
        x_values_obs = x_values + 0.2
        y_values_obs = scaled_obs_est
        yerr_values_obs = 1.645 * scaled_obs_est_se
        ax.errorbar(
            x=x_values_obs,
            y=y_values_obs,
            yerr=yerr_values_obs,
            fmt="o",
            capsize=5,
            label="Paired obs.model scaled with 90% CI",
            color=colors[4],
            ecolor=colors[4],
        )

        # Scale posterior ATI estimates to total treatment effects (paired)
        x_values_post = x_values + 0.4

        if posterior_metric == "experiment_true_ati":
            # Use experiment_true_ati directly from post_summary
            posterior_mask = post_summary.index.str.contains(
                r"experiment_true_ati\["
            ) & ~post_summary.index.str.contains(r"z_")
            ati_post_means = post_summary[posterior_mask]["mean"].values
            scaled_post_means = ati_post_means * paired_scaling_values

            # Scale HDI intervals
            ati_hdi_lower = post_summary[posterior_mask]["hdi_5%"].values
            ati_hdi_upper = post_summary[posterior_mask]["hdi_95%"].values
            scaled_hdi_lower = ati_hdi_lower * paired_scaling_values
            scaled_hdi_upper = ati_hdi_upper * paired_scaling_values
            yerr_post_lower = scaled_post_means - scaled_hdi_lower
            yerr_post_upper = scaled_hdi_upper - scaled_post_means
            yerr_values_post = [yerr_post_lower, yerr_post_upper]
            label_text = "Treatment effect posterior scaled with 90% HDI"

        elif posterior_metric == "tau":
            tau_mask = post_summary.index.str.contains(r"tau\[") & ~post_summary.index.str.contains(r"z_")
            scaled_post_means = post_summary[tau_mask]["mean"].values * paired_scaling_values
            yerr_post_lower = scaled_post_means - post_summary[tau_mask]["hdi_5%"].values * paired_scaling_values
            yerr_post_upper = post_summary[tau_mask]["hdi_95%"].values * paired_scaling_values - scaled_post_means
            yerr_values_post = [yerr_post_lower, yerr_post_upper]
            label_text = "Treatment effect posterior with 90% HDI"

        elif posterior_metric == "bias":
            bias_mask = post_summary.index.str.contains(r"bias\[") & ~post_summary.index.str.contains(r"z_")
            scaled_post_means = post_summary[bias_mask]["mean"].values * paired_scaling_values
            yerr_post_lower = scaled_post_means - post_summary[bias_mask]["hdi_5%"].values * paired_scaling_values
            yerr_post_upper = post_summary[bias_mask]["hdi_95%"].values * paired_scaling_values - scaled_post_means
            yerr_values_post = [yerr_post_lower, yerr_post_upper]
            label_text = "Bias posterior with 90% HDI"
        else:
            raise ValueError(
                f"Invalid posterior_metric: {posterior_metric}. Must be 'experiment_true_ati', 'tau', or 'bias'"
            )

        ax.errorbar(
            x=x_values_post,
            y=scaled_post_means,
            yerr=np.abs(yerr_values_post),
            fmt="o",
            capsize=5,
            label=label_text,
            color="orange",
            ecolor="orange",
        )

        # UNPAIRED DATA SECTION (indices n_paired to n_paired+n_unpaired-1)

        # Get scaling values for unpaired data
        unpaired_scaling_values = df_unpaired[scaling_metric].values

        # Get unpaired observational ATI estimates
        unpaired_obs_ati = df_unpaired[obs_ati_metric].values
        unpaired_obs_ati_se = df_unpaired[obs_ati_se_metric].values

        # Scale unpaired observational ATI to total treatment effects
        scaled_unpaired_obs_est = unpaired_obs_ati * unpaired_scaling_values
        # Uncertainty propagation
        if f"{scaling_metric}_se" in df_unpaired.columns:
            unpaired_scaling_se = df_unpaired[f"{scaling_metric}_se"].values
            scaled_unpaired_obs_est_se = np.abs(scaled_unpaired_obs_est) * np.sqrt(
                (unpaired_obs_ati_se / unpaired_obs_ati) ** 2 + (unpaired_scaling_se / unpaired_scaling_values) ** 2
            )
        else:
            # If no scaling uncertainty, just scale the ATI uncertainty
            scaled_unpaired_obs_est_se = unpaired_obs_ati_se * unpaired_scaling_values

        # Unpaired observational model scaled estimates
        x_values_unpaired = np.arange(n_paired, n_paired + n_unpaired)
        y_values_unpaired = scaled_unpaired_obs_est
        yerr_values_unpaired = 1.645 * scaled_unpaired_obs_est_se
        ax.errorbar(
            x=x_values_unpaired,
            y=y_values_unpaired,
            yerr=yerr_values_unpaired,
            fmt="s",
            capsize=5,
            label="Unpaired obs.model scaled with 90% CI",
            color=colors[6],
            ecolor=colors[6],
        )

        # Scale calibrated ATI estimates to total treatment effects (unpaired)
        x_values_cal_unpaired = x_values_unpaired + 0.2
        calibrated_ati_means_unpaired = calibrated_summary["mean"].values
        scaled_calibrated_means_unpaired = calibrated_ati_means_unpaired * unpaired_scaling_values

        # Use HDI intervals if available, otherwise fall back to CI
        if "hdi_5%" in calibrated_summary.columns and "hdi_95%" in calibrated_summary.columns:
            # Scale HDI intervals by experiment_scale
            scaled_hdi_lower_unpaired = calibrated_summary["hdi_5%"].values * unpaired_scaling_values
            scaled_hdi_upper_unpaired = calibrated_summary["hdi_95%"].values * unpaired_scaling_values
            yerr_cal_lower_unpaired = scaled_calibrated_means_unpaired - scaled_hdi_lower_unpaired
            yerr_cal_upper_unpaired = scaled_hdi_upper_unpaired - scaled_calibrated_means_unpaired
            yerr_cal_unpaired = [yerr_cal_lower_unpaired, yerr_cal_upper_unpaired]
            label_text_unpaired = "Calibrated scaled estimates with 90% HDI"
        else:
            # Scale standard deviation by experiment_scale
            scaled_sd_unpaired = calibrated_summary["sd"].values * unpaired_scaling_values
            yerr_cal_values_unpaired = 1.645 * scaled_sd_unpaired
            yerr_cal_unpaired = [yerr_cal_values_unpaired, yerr_cal_values_unpaired]
            label_text_unpaired = "Calibrated scaled estimates with 90% CI"

        ax.errorbar(
            x=x_values_cal_unpaired,
            y=scaled_calibrated_means_unpaired,
            yerr=yerr_cal_unpaired,
            fmt="s",
            capsize=5,
            label=label_text_unpaired,
            color="purple",
            ecolor="purple",
        )

        # Add vertical line to separate paired from unpaired
        ax.axvline(x=n_paired - 0.5, color="gray", linestyle="--", alpha=0.5, linewidth=1)

        # Use axis coordinates (0-1) for text positioning to avoid issues with axis limit changes
        ax.text(
            n_paired / 2, 0.95, "Paired Data", ha="center", fontsize=16, alpha=0.7, transform=ax.get_xaxis_transform()
        )
        ax.text(
            n_paired + n_unpaired / 2,
            0.95,
            "Unpaired Data",
            ha="center",
            fontsize=16,
            alpha=0.7,
            transform=ax.get_xaxis_transform(),
        )

        # Apply consistent formatting and finalization
        if title is None:
            title = f"Combined Scaled Results: Paired RCT+Obs vs Unpaired Calibrated ATI × {scaling_metric} with 90%HDI"
        self._finalize_plot(fig, ax, title, ylabel_units)

        return fig, ax

    def plot_calibration_intensity_results(
        self,
        df_unpaired: pd.DataFrame,
        calibration_trace: Any,
        show_bias_corrections: bool = False,
        title: Optional[str] = None,
        ylabel_units: str = "raw",
        posterior_metric: str = "experiment_true_ati_unpaired",
        figsize: Tuple[int, int] = (20, 6),
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create calibration intensity results plot showing unpaired obs intensity estimates
           vs calibrated intensity posteriors.

        Parameters
        ----------
        df_unpaired : pd.DataFrame
            Unpaired observational data
        calibration_trace : arviz.InferenceData
            Trace from calibration model
        show_bias_corrections : bool, optional
            Whether to show bias corrections as points, default False
        title : str, optional
            Custom plot title
        ylabel_units : str, optional
            Y-axis units ('raw' or 'percent'), default 'raw'
        posterior_metric : str, optional
            Posterior metric to use: 'experiment_true_ati_unpaired' (default) or 'calibrated_estimates'
            If 'calibrated_estimates', values are divided by 'experiment_scale'
        figsize : Tuple[int, int], optional
            Figure size, default (20, 6)

        Returns
        -------
        Tuple[plt.Figure, plt.Axes]
            Figure and axes objects
        """
        colors = self._setup_plot_style()

        # Get calibrated estimates summary
        if posterior_metric == "experiment_true_ati_unpaired":
            calibrated_summary = az.summary(calibration_trace, var_names=["experiment_true_ati_unpaired"])
        else:
            calibrated_summary = az.summary(calibration_trace, var_names=["calibrated_estimates"])

        # Create figure and axis
        fig, ax = plt.subplots(figsize=figsize)

        # Calculate unpaired observational model intensity estimates
        # ATI = obs_model_est / experiment_scale
        obs_ati = df_unpaired["obs_model_est"] / df_unpaired["experiment_scale"]
        # Uncertainty propagation: sZ = Z * sqrt((sX/X)^2 + (sY/Y)^2)
        obs_ati_se = np.abs(obs_ati) * np.sqrt(
            (df_unpaired["obs_model_est_se"] / df_unpaired["obs_model_est"]) ** 2
            + (df_unpaired["experiment_scale_se"] / df_unpaired["experiment_scale"]) ** 2
        )

        # Unpaired observational model intensity estimates
        x_values = np.arange(len(df_unpaired))
        y_values = obs_ati.values
        yerr_values = 1.645 * obs_ati_se.values  # 90% CI

        ax.errorbar(
            x=x_values,
            y=y_values,
            yerr=yerr_values,
            fmt="o",
            capsize=5,
            label="Unpaired obs.model intensity with 90% CI",
            color=colors[4],
            ecolor=colors[4],
        )

        # Calibrated intensity estimates from posterior
        x_values_cal = x_values + 0.2

        if posterior_metric == "experiment_true_ati_unpaired":
            # Use experiment_true_ati_unpaired directly
            calibrated_means = calibrated_summary["mean"].values
        else:
            # Use calibrated_estimates divided by experiment_scale
            calibrated_means = calibrated_summary["mean"].values / df_unpaired["experiment_scale"].values

        # Use HDI intervals if available, otherwise fall back to CI
        if "hdi_5%" in calibrated_summary.columns and "hdi_95%" in calibrated_summary.columns:
            if posterior_metric == "experiment_true_ati_unpaired":
                yerr_cal_lower = calibrated_means - calibrated_summary["hdi_5%"].values
                yerr_cal_upper = calibrated_summary["hdi_95%"].values - calibrated_means
            else:
                # Scale HDI intervals by experiment_scale
                yerr_cal_lower = calibrated_means - (
                    calibrated_summary["hdi_5%"].values / df_unpaired["experiment_scale"].values
                )
                yerr_cal_upper = (
                    calibrated_summary["hdi_95%"].values / df_unpaired["experiment_scale"].values
                ) - calibrated_means
            yerr_cal = [yerr_cal_lower, yerr_cal_upper]
            label_text = "Calibrated intensity estimates with 90% HDI"
        else:
            if posterior_metric == "experiment_true_ati_unpaired":
                yerr_cal_values = 1.645 * calibrated_summary["sd"].values
            else:
                yerr_cal_values = 1.645 * (calibrated_summary["sd"].values / df_unpaired["experiment_scale"].values)
            yerr_cal = [yerr_cal_values, yerr_cal_values]
            label_text = "Calibrated intensity estimates with 90% CI"

        ax.errorbar(
            x=x_values_cal,
            y=calibrated_means,
            yerr=yerr_cal,
            fmt="o",
            capsize=5,
            label=label_text,
            color="orange",
            ecolor="orange",
        )

        # Optional bias corrections
        if show_bias_corrections:
            bias_corrections = y_values - calibrated_means
            x_values_bias = x_values + 0.4
            ax.scatter(
                x=x_values_bias,
                y=bias_corrections,
                marker="s",
                s=80,
                label="Intensity bias corrections",
                color="red",
                alpha=0.7,
            )

        # Apply consistent formatting and finalization
        if title is None:
            title = "Calibration Intensity Results: Unpaired Obs.Model vs Calibrated Intensity Estimates with 90%HDI"
        self._finalize_plot(fig, ax, title, ylabel_units, "Unpaired Observation ID")

        return fig, ax

    def plot_combined_paired_unpaired_intensity_results(
        self,
        df_processed: pd.DataFrame,
        idata_base: Any,
        post_summary: pd.DataFrame,
        df_unpaired: pd.DataFrame,
        calibration_trace: Any,
        hp_mask: Optional[List[int]] = None,
        title: Optional[str] = None,
        ylabel_units: str = "raw",
        posterior_metric: str = "experiment_true_ati",
        calibration_metric: str = "experiment_true_ati_unpaired",
        figsize: Tuple[int, int] = (20, 6),
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create combined intensity plot showing paired experiments and unpaired calibrated intensity results.

        Parameters
        ----------
        df_processed : pd.DataFrame
            Original paired data
        idata_base : arviz.InferenceData
            Inference data from main model
        post_summary : pd.DataFrame
            Posterior summary from main model
        df_unpaired : pd.DataFrame
            Unpaired observational data
        calibration_trace : arviz.InferenceData
            Trace from calibration model
        hp_mask : List[int], optional
            Indices of high-priority experiments
        title : str, optional
            Custom plot title
        ylabel_units : str, optional
            Y-axis units ('raw' or 'percent'), default 'raw'
        posterior_metric : str, optional
            Posterior metric to use for paired data: 'experiment_true_ati' (default), 'tau', or 'bias'
        calibration_metric : str, optional
            Calibration metric to use: 'experiment_true_ati_unpaired' (default) or 'calibrated_estimates'
        figsize : Tuple[int, int], optional
            Figure size, default (20, 6)

        Returns
        -------
        Tuple[plt.Figure, plt.Axes]
            Figure and axes objects
        """
        colors = self._setup_plot_style()

        # Get calibrated estimates summary
        if calibration_metric == "experiment_true_ati_unpaired":
            calibrated_summary = az.summary(calibration_trace, var_names=["experiment_true_ati_unpaired"])
        else:
            calibrated_summary = az.summary(calibration_trace, var_names=["calibrated_estimates"])

        # Create figure and axis
        fig, ax = plt.subplots(figsize=figsize)

        n_paired = len(df_processed)
        n_unpaired = len(df_unpaired)

        # PAIRED DATA SECTION (indices 0 to n_paired-1)

        # Calculate treatment intensities from the paired data
        # ATI = experiment_est / experiment_scale
        ati_exp = df_processed["experiment_est"] / df_processed["experiment_scale"]
        # Uncertainty propagation: sZ = Z * sqrt((sX/X)^2 + (sY/Y)^2)
        ati_exp_se = np.abs(ati_exp) * np.sqrt(
            (df_processed["experiment_est_se"] / df_processed["experiment_est"]) ** 2
            + (df_processed["experiment_scale_se"] / df_processed["experiment_scale"]) ** 2
        )

        # Observational model treatment intensities
        obs_ati = df_processed["obs_model_est"] / df_processed["experiment_scale"]
        obs_ati_se = np.abs(obs_ati) * np.sqrt(
            (df_processed["obs_model_est_se"] / df_processed["obs_model_est"]) ** 2
            + (df_processed["experiment_scale_se"] / df_processed["experiment_scale"]) ** 2
        )

        # Experiment intensity results (paired)
        x_values = np.arange(n_paired)
        y_values = ati_exp.values
        yerr_values = 1.645 * ati_exp_se.values
        ax.errorbar(
            x=x_values,
            y=y_values,
            yerr=yerr_values,
            fmt="o",
            capsize=5,
            label="Experiment intensity with 90% CI",
            color=colors[0],
            ecolor=colors[0],
        )

        # High-precision experiments (if provided)
        if hp_mask is not None and len(hp_mask) > 0:
            x_values_hp = np.array(hp_mask)
            y_values_hp = ati_exp.iloc[hp_mask].values
            yerr_values_hp = 1.645 * ati_exp_se.iloc[hp_mask].values
            ax.errorbar(
                x=x_values_hp,
                y=y_values_hp,
                yerr=yerr_values_hp,
                fmt="o",
                capsize=5,
                label="High-precision experiment intensity with 90% CI",
                color="red",
                ecolor="red",
            )

        # Observational model intensity results (paired)
        x_values_obs = x_values + 0.2
        y_values_obs = obs_ati.values
        yerr_values_obs = 1.645 * obs_ati_se.values
        ax.errorbar(
            x=x_values_obs,
            y=y_values_obs,
            yerr=yerr_values_obs,
            fmt="o",
            capsize=5,
            label="Paired obs.model intensity with 90% CI",
            color=colors[4],
            ecolor=colors[4],
        )

        # True intensity posterior (paired)
        x_values_post = x_values + 0.4

        if posterior_metric == "experiment_true_ati":
            # Use experiment_true_ati directly from post_summary
            posterior_mask = post_summary.index.str.contains(
                r"experiment_true_ati\["
            ) & ~post_summary.index.str.contains(r"z_")
            y_values_post = post_summary[posterior_mask]["mean"].values
            # Use HDI intervals instead of CI
            yerr_post_lower = y_values_post - post_summary[posterior_mask]["hdi_5%"].values
            yerr_post_upper = post_summary[posterior_mask]["hdi_95%"].values - y_values_post
            yerr_values_post = [yerr_post_lower, yerr_post_upper]
            label_text = "Treatment intensity posterior with 90% HDI"

        elif posterior_metric == "tau":
            # Use tau divided by experiment_true_size
            tau_mask = post_summary.index.str.contains(r"tau\[") & ~post_summary.index.str.contains(r"z_")
            size_mask = post_summary.index.str.contains(r"experiment_true_size\[") & ~post_summary.index.str.contains(
                r"z_"
            )

            tau_values = post_summary[tau_mask]["mean"].values
            size_values = post_summary[size_mask]["mean"].values
            y_values_post = tau_values / size_values

            # Approximate error propagation for tau/size
            tau_hdi_lower = post_summary[tau_mask]["hdi_5%"].values
            tau_hdi_upper = post_summary[tau_mask]["hdi_95%"].values
            size_hdi_lower = post_summary[size_mask]["hdi_5%"].values
            size_hdi_upper = post_summary[size_mask]["hdi_95%"].values

            # Conservative error propagation
            yerr_post_lower = y_values_post - (tau_hdi_lower / size_hdi_upper)
            yerr_post_upper = (tau_hdi_upper / size_hdi_lower) - y_values_post
            yerr_values_post = [yerr_post_lower, yerr_post_upper]
            label_text = "Treatment intensity posterior with 90% HDI"

        elif posterior_metric == "bias":
            # Use bias divided by experiment_true_size
            bias_mask = post_summary.index.str.contains(r"bias\[") & ~post_summary.index.str.contains(r"z_")
            size_mask = post_summary.index.str.contains(r"experiment_true_size\[") & ~post_summary.index.str.contains(
                r"z_"
            )

            bias_values = post_summary[bias_mask]["mean"].values
            size_values = post_summary[size_mask]["mean"].values
            y_values_post = bias_values / size_values

            # Approximate error propagation for bias/size
            bias_hdi_lower = post_summary[bias_mask]["hdi_5%"].values
            bias_hdi_upper = post_summary[bias_mask]["hdi_95%"].values
            size_hdi_lower = post_summary[size_mask]["hdi_5%"].values
            size_hdi_upper = post_summary[size_mask]["hdi_95%"].values

            # Conservative error propagation
            yerr_post_lower = y_values_post - (bias_hdi_lower / size_hdi_upper)
            yerr_post_upper = (bias_hdi_upper / size_hdi_lower) - y_values_post
            yerr_values_post = [yerr_post_lower, yerr_post_upper]
            label_text = "Bias intensity posterior with 90% HDI"
        else:
            raise ValueError(
                f"Invalid posterior_metric: {posterior_metric}. Must be 'experiment_true_ati', 'tau', or 'bias'"
            )

        ax.errorbar(
            x=x_values_post,
            y=y_values_post,
            yerr=np.abs(yerr_values_post),
            fmt="o",
            capsize=5,
            label=label_text,
            color="orange",
            ecolor="orange",
        )

        # UNPAIRED DATA SECTION (indices n_paired to n_paired+n_unpaired-1)

        # Calculate unpaired observational model intensity estimates
        # ATI = obs_model_est / experiment_scale
        unpaired_obs_ati = df_unpaired["obs_model_est"] / df_unpaired["experiment_scale"]
        # Uncertainty propagation: sZ = Z * sqrt((sX/X)^2 + (sY/Y)^2)
        unpaired_obs_ati_se = np.abs(unpaired_obs_ati) * np.sqrt(
            (df_unpaired["obs_model_est_se"] / df_unpaired["obs_model_est"]) ** 2
            + (df_unpaired["experiment_scale_se"] / df_unpaired["experiment_scale"]) ** 2
        )

        # Unpaired observational model intensity estimates
        x_values_unpaired = np.arange(n_paired, n_paired + n_unpaired)
        y_values_unpaired = unpaired_obs_ati.values
        yerr_values_unpaired = 1.645 * unpaired_obs_ati_se.values
        ax.errorbar(
            x=x_values_unpaired,
            y=y_values_unpaired,
            yerr=yerr_values_unpaired,
            fmt="s",
            capsize=5,
            label="Unpaired obs.model intensity with 90% CI",
            color=colors[6],
            ecolor=colors[6],
        )

        # Calibrated intensity estimates (unpaired)
        x_values_cal = x_values_unpaired + 0.2

        if calibration_metric == "experiment_true_ati_unpaired":
            # Use experiment_true_ati_unpaired directly
            calibrated_means = calibrated_summary["mean"].values
        else:
            # Use calibrated_estimates divided by experiment_scale
            calibrated_means = calibrated_summary["mean"].values / df_unpaired["experiment_scale"].values

        # Use HDI intervals if available, otherwise fall back to CI
        if "hdi_5%" in calibrated_summary.columns and "hdi_95%" in calibrated_summary.columns:
            if calibration_metric == "experiment_true_ati_unpaired":
                yerr_cal_lower = calibrated_means - calibrated_summary["hdi_5%"].values
                yerr_cal_upper = calibrated_summary["hdi_95%"].values - calibrated_means
            else:
                # Scale HDI intervals by experiment_scale
                yerr_cal_lower = calibrated_means - (
                    calibrated_summary["hdi_5%"].values / df_unpaired["experiment_scale"].values
                )
                yerr_cal_upper = (
                    calibrated_summary["hdi_95%"].values / df_unpaired["experiment_scale"].values
                ) - calibrated_means
            yerr_cal = [yerr_cal_lower, yerr_cal_upper]
            label_text = "Calibrated intensity estimates with 90% HDI"
        else:
            if calibration_metric == "experiment_true_ati_unpaired":
                yerr_cal_values = 1.645 * calibrated_summary["sd"].values
            else:
                yerr_cal_values = 1.645 * (calibrated_summary["sd"].values / df_unpaired["experiment_scale"].values)
            yerr_cal = [yerr_cal_values, yerr_cal_values]
            label_text = "Calibrated intensity estimates with 90% CI"

        ax.errorbar(
            x=x_values_cal,
            y=calibrated_means,
            yerr=yerr_cal,
            fmt="s",
            capsize=5,
            label=label_text,
            color="purple",
            ecolor="purple",
        )

        # Add vertical line to separate paired from unpaired
        ax.axvline(x=n_paired - 0.5, color="gray", linestyle="--", alpha=0.5, linewidth=1)

        # Use axis coordinates (0-1) for text positioning to avoid issues with axis limit changes
        ax.text(
            n_paired / 2, 0.95, "Paired Data", ha="center", fontsize=16, alpha=0.7, transform=ax.get_xaxis_transform()
        )
        ax.text(
            n_paired + n_unpaired / 2,
            0.95,
            "Unpaired Data",
            ha="center",
            fontsize=16,
            alpha=0.7,
            transform=ax.get_xaxis_transform(),
        )

        # Apply consistent formatting and finalization
        if title is None:
            title = "Combined Intensity Results: Paired RCT+Obs vs Unpaired Calibrated Intensity Estimates with 90%HDI"
        self._finalize_plot(fig, ax, title, ylabel_units)

        return fig, ax

"""
Enumeration classes for meta-analysis models.

This module contains Enum classes that define constants used throughout the meta-analysis package.
"""

from enum import Enum
from typing import List


class ModelTypes(Enum):
    """Enumeration of available model types for BBAM analysis.

    Available model types:
    - STANDARD: Standard hierarchical Bayesian meta-analysis model
    - RCT_ONLY: Model using only RCT data without observational pairs
    - SCALED: Extension of the HBM with experiment scale metrics (impressions, spend, observations)
    """

    STANDARD = "standard"
    RCT_ONLY = "rct_only"
    SCALED = "scaled"

    @classmethod
    def values(cls) -> List[str]:
        """Get all valid string values for this enum.

        Returns
        -------
        List[str]
            List of valid string values
        """
        return [e.value for e in cls]


class BiasSpecification(Enum):
    """Bias specification types for meta-analysis models.

    These values determine how bias is modeled in the RCTObsModelHBM class:
    - BOTH_INT_MULT: Both intercept and multiplier components (bias = beta_0 + beta_1 * tau)
    - ONLY_INT: Only intercept component (bias = beta_0)
    - ONLY_MULT: Only multiplier component (bias = beta_1 * tau)
    """

    BOTH_INT_MULT = "BOTH_INT_MULT"
    ONLY_INT = "ONLY_INT"
    ONLY_MULT = "ONLY_MULT"

    @classmethod
    def values(cls) -> List[str]:
        """Get all valid string values for this enum.

        Returns
        -------
        List[str]
            List of valid string values
        """
        return [e.value for e in cls]


class LikelihoodDistribution(Enum):
    """Likelihood distribution types for model estimation.

    These values determine which probability distribution is used for the likelihood function:
    - NORMAL: Normal (Gaussian) distribution
    - STUDENT_T: Student's t-distribution (requires additional degrees of freedom parameter)
    """

    NORMAL = "normal"
    STUDENT_T = "student_t"

    @classmethod
    def values(cls) -> List[str]:
        """Get all valid string values for this enum.

        Returns
        -------
        List[str]
            List of valid string values
        """
        return [e.value for e in cls]


class IntervalType(Enum):
    """Interval types for credible intervals in Bayesian analysis.

    These values determine which type of credible interval is calculated:
    - HDI: Highest Density Interval (the shortest interval containing the specified probability mass)
    - ETI: Equal-tailed Interval (equal probability is excluded from each tail)
    """

    HDI = "HDI"
    ETI = "ETI"

    @classmethod
    def values(cls) -> List[str]:
        """Get all valid string values for this enum.

        Returns
        -------
        List[str]
            List of valid string values
        """
        return [e.value for e in cls]


class WarningLevel(Enum):
    """Warning levels for convergence diagnostics.

    These values determine the strictness of convergence diagnostics:
    - NORMAL: Standard convergence criteria
    - RELAXED: More lenient convergence criteria
    """

    NORMAL = "normal"
    RELAXED = "relaxed"

    @classmethod
    def values(cls) -> List[str]:
        """Get all valid string values for this enum.

        Returns
        -------
        List[str]
            List of valid string values
        """
        return [e.value for e in cls]


class PriorSpecifications:
    """Prior parameter specifications for different model types.

    This class defines the required priors for each model type, enabling
    consistent validation and reducing code duplication.
    """

    # Common priors shared across multiple model types
    BETA_PRIORS = [
        "mu_beta_0",
        "sigma_beta_0",  # Bias intercept parameters
        "mu_beta_1",
        "sigma_beta_1",  # Bias multiplier parameters
    ]

    SIGMA_TAU_PRIOR = ["sigma_tau"]  # Treatment effect variance

    # Model-specific prior specifications
    STANDARD_PRIORS = ["mu_tau"] + SIGMA_TAU_PRIOR + BETA_PRIORS

    RCT_ONLY_PRIORS = ["mu_tau"] + SIGMA_TAU_PRIOR

    SCALED_PRIORS = (
        [
            "mu_ati",
            "sigma_ati",  # Treatment effect intensity parameters
            "mu_scale",
            "sigma_scale",  # Experiment scale parameters
        ]
        + SIGMA_TAU_PRIOR
        + BETA_PRIORS
    )

    @classmethod
    def get_required_priors(cls, model_type: str) -> List[str]:
        """Get required priors for a specific model type.

        Parameters
        ----------
        model_type : str
            Model type ('standard', 'rct_only', 'scaled')

        Returns
        -------
        List[str]
            List of required prior parameter names

        Raises
        ------
        ValueError
            If model_type is not supported
        """
        if model_type == "standard":
            return cls.STANDARD_PRIORS.copy()
        elif model_type == "rct_only":
            return cls.RCT_ONLY_PRIORS.copy()
        elif model_type == "scaled":
            return cls.SCALED_PRIORS.copy()
        else:
            valid_types = ["standard", "rct_only", "scaled"]
            raise ValueError(f"Unknown model type: {model_type}. Valid types are: {valid_types}")

    @classmethod
    def get_common_priors(cls) -> List[str]:
        """Get priors that are common across multiple model types.

        Returns
        -------
        List[str]
            List of common prior parameter names
        """
        return cls.BETA_PRIORS + cls.SIGMA_TAU_PRIOR

    @classmethod
    def get_bias_priors(cls) -> List[str]:
        """Get bias-related priors.

        Returns
        -------
        List[str]
            List of bias prior parameter names
        """
        return cls.BETA_PRIORS.copy()

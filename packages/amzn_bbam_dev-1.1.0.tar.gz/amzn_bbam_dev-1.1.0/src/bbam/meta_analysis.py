from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

import arviz as az
import numpy as np
import pandas as pd
import pymc as pm
from yaml import safe_load

from .config.run_metadata import RunMetadata
from .diagnostics.convergence_diagnostics import ConvergenceDiagnostics
from .models import Model
from .utils.enums import IntervalType, WarningLevel


class BayesianRCTMetaAnalysis:
    """Main class for Bayesian meta-analysis of RCTs (Randomized Controlled Trials).

    This class orchestrates the Bayesian meta-analysis workflow using PyMC,
    separating the analysis framework from model-specific implementations.
    It handles data loading, configuration management, MCMC sampling,
    convergence diagnostics, and result summarization, while delegating
    model-specific logic to the provided model object.
    """

    config: Dict[str, Any]

    def __init__(
        self,
        model: Model,
        data: pd.DataFrame,
        config_path: str,
        logger: Optional[Any] = None,
        run_id: Optional[str] = None,
    ) -> None:
        """Initialize the meta-analysis with a model, data, and configuration.

        Parameters
        ----------
        model : Model
            The model to use for the meta-analysis
        data : pd.DataFrame
            The data to analyze
        config_path : str
            Path to the configuration file
        logger : logging.Logger, optional
            Logger instance to use. If None, a default logger will be created.
        run_id : str, optional
            Unique identifier for the run. If None, a timestamp-based ID will be generated.
        """
        if logger:
            self.logger = logging.getLogger(f"{logger.name}.meta_analysis")
        else:
            self.logger = logging.getLogger("meta_analysis_class")

        self.logger.info("Initializing meta-analysis workflow")

        self.model = model
        self.required_data_columns = self.model.get_required_data_columns()
        self.run_metadata = RunMetadata(run_id=run_id, logger=logger)
        self._load_data(data)

        self.logger.info(f"Loading configuration from {config_path}")
        self._load_config(config_path)

        # Share config with model and get back potentially modified config
        self.config = self.model.set_and_process_config(self.config.copy())

        # Log the final config after all modifications
        self.run_metadata.log_config(self.config)

    def _prepare_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare and validate configuration.

        This method checks that all required configuration parameters
        are present, sets default values where needed, and validates values.

        Parameters
        ----------
        config : Dict[str, Any]
            Raw configuration dictionary loaded from file

        Returns
        -------
        Dict[str, Any]
            The prepared configuration dictionary

        Raises
        ------
        ValueError
            If the configuration is invalid
        """
        # Check if "data_driven" parameter is provided, if not set to false
        if "data_driven_priors" not in config:
            config["data_driven_priors"] = False

        # check that priors are provided, if data driven priors flag set to False
        if not config["data_driven_priors"]:
            if "priors" not in config:
                raise ValueError(
                    "Priors must be provided in 'priors' section of the config "
                    "if data-driven flag set to False or omitted"
                )

        # Ensure sampling_settings section exists
        if "sampling_settings" not in config:
            config["sampling_settings"] = {}

        # Set default value for n_sample_posterior if not present
        if "n_sample_posterior" not in config["sampling_settings"]:
            config["sampling_settings"]["n_sample_posterior"] = 0

        # Assert that config['sampling_settings'] is not negative
        assert config["sampling_settings"]["n_sample_posterior"] >= 0, "n_sample_posterior must be non-negative"

        # check if is_random_seed is provided, if not set to false
        if "is_random_seed" not in config["sampling_settings"]:
            config["sampling_settings"]["is_random_seed"] = False

        if not config["sampling_settings"]["is_random_seed"]:
            # if is_random_seed is False, check that seed is provided
            if "seed" not in config["sampling_settings"]:
                raise ValueError(
                    "Seed must be provided in 'sampling_settings' section of the config "
                    "if is_random_seed flag set to False or omitted"
                )
            self.logger.info(f"Seed provided: {config['sampling_settings']['seed']}")
        else:
            # if is_random_seed is True, generate random seed
            # save it into config for reproducibility
            config["sampling_settings"]["generated_seed"] = np.random.randint(1, 1000000)
            config["sampling_settings"]["seed"] = config["sampling_settings"]["generated_seed"]
            self.logger.info(f"Random seed generated: {config['sampling_settings']['seed']}")

        # check that all required sections are provided
        required_sections = [
            "sampling_settings",
            "warning_level_setting",
            "warning_level_definition",
        ]
        for section in required_sections:
            if section not in config:
                raise ValueError(f"Missing required section: {section}")

        # check that chosen warning level is defined
        if config["warning_level_setting"] not in config["warning_level_definition"]:
            raise ValueError(
                f"Warning level {config['warning_level_setting']} not defined in "
                f"'warning_level_definition' section of the config"
            )

        # Validate warning level against enum
        if config["warning_level_setting"] not in WarningLevel.values():
            raise ValueError(
                f"Invalid warning level: {config['warning_level_setting']}. Must be one of {WarningLevel.values()}"
            )

        return config

    def _validate_data(self, data: pd.DataFrame) -> None:
        """Validate input data structure and content.

        Parameters
        ----------
        data : pd.DataFrame
            Input data to validate

        Raises
        ------
        ValueError
            If data validation fails (e.g., missing required columns)
        TypeError
            If data is not a pandas DataFrame
        """
        if not isinstance(data, pd.DataFrame):
            raise ValueError("Input must be a pandas DataFrame")
        # Check required columns (defined by child classes)
        missing_cols = [col for col in self.required_data_columns if col not in data.columns]
        if missing_cols:
            raise ValueError(f"Missing required columns: {missing_cols}")

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration for the analysis.

        Parameters
        ----------
        config_path : str
            Path to the YAML configuration file

        Returns
        -------
        Dict[str, Any]
            Configuration dictionary containing model settings and specifications

        Raises
        ------
        FileNotFoundError
            If the configuration file does not exist
        ValueError
            If the configuration is invalid
        """
        with open(config_path, "r") as f:
            config = safe_load(f)
            self.config = self._prepare_config(config)  # prepare and validate general meta-analysis config
        return self.config

    def _load_data(self, data: pd.DataFrame) -> pd.DataFrame:
        """Load and validate data for the analysis.

        Parameters
        ----------
        data : pd.DataFrame
            The data to analyze

        Returns
        -------
        pd.DataFrame
            Processed dataframe

        Raises
        ------
        ValueError
            If the data validation fails
        """
        self._validate_data(data)
        self.data = data[self.required_data_columns]
        self.run_metadata.log_data_summary(self.data)  # Log data summary
        self.logger.info(f"Loaded dataset with {len(self.data)} observations")
        return self.data

    def run(self) -> BayesianRCTMetaAnalysis:
        """Run the meta-analysis sampling.

        This method sets up the model with hyperpriors, builds the model,
        and runs the MCMC sampling to generate posterior distributions.
        It also performs convergence diagnostics.

        Returns
        -------
        BayesianRCTMetaAnalysis
            Self reference for method chaining

        Raises
        ------
        Exception
            If an error occurs during sampling
        """
        self.logger.info("Setting up priors and building model")
        self.model.set_priors(data=self.data)
        self.run_metadata.log_priors(self.model.priors)  # Log priors in metadata
        self.model.build(data=self.data)

        try:
            sampling_params = {
                "tune": self.config["sampling_settings"]["tune"],  # Number of tuning steps
                "draws": self.config["sampling_settings"]["draws"],  # Number of posterior samples
                "chains": self.config["sampling_settings"]["chains"],  # Number of parallel chains
                "cores": self.config["sampling_settings"]["cores"],  # Cores to use
                "target_accept": self.config["sampling_settings"]["target_accept"],  # Target acceptance for sampler
                "nuts_sampler": "nutpie",
                "nuts_sampler_kwargs": {"maxdepth": self.config["sampling_settings"]["maxdepth"]},
                "random_seed": self.config["sampling_settings"]["seed"],  # random seed for Bayesian sampler
            }
            self.logger.info("Running MCMC sampling...")
            with self.model.pymc_model:
                self.trace = pm.sample(**sampling_params)
            self.logger.info("MCMC sampling completed successfully")

            # Perform posterior predictive sampling after main MCMC sampling if requested
            if self.config["sampling_settings"]["n_sample_posterior"] > 0:
                self.sample_posterior_predictive()

        except Exception as e:
            self.logger.error(f"Error during sampling: {str(e)}")
            raise

        self.logger.info("Running convergence diagnostics")
        self.convergence_diagnostics()
        return self

    def convergence_diagnostics(self) -> bool:
        """Get convergence diagnostics for the model.

        This method calculates and reports various convergence diagnostics
        for the MCMC sampling: divergent transitions, max treed depth, R-hat, and effective sample size.

        Returns
        -------
        bool
            Boolean flag indicating whether all convergence diagnostics pass
        """
        convergence_result = ConvergenceDiagnostics(self.config, logger=self.logger).has_passed_convergence_checks(
            self.trace
        )
        return convergence_result.passed

    def sample_posterior_predictive(self) -> None:
        """Sample from the posterior predictive distribution.

        This method performs posterior predictive sampling after the main MCMC sampling
        is complete.

        Returns
        -------
        None
        """
        n_samples = self.config["sampling_settings"]["n_sample_posterior"]
        self.logger.info("Sampling from posterior predictive distribution")

        try:
            with self.model.pymc_model:
                # Create posterior predictive variables based on the model type
                self.model.define_posterior_predictive_vars(n_samples)

                # Sample from posterior predictive distribution
                self.posterior_predictive_trace = pm.sample_posterior_predictive(
                    self.trace,
                    var_names=self.model.get_posterior_predictive_vars(),
                    random_seed=self.config["sampling_settings"]["seed"],
                )
            self.logger.info("Posterior predictive sampling completed successfully")
        except Exception as e:
            self.logger.error(f"Error during posterior predictive sampling: {str(e)}")
            raise

    def save_run_metadata(self, output_dir: str) -> str:
        """Save run metadata to a file.

        Parameters
        ----------
        output_dir : str
            Directory to save the metadata

        Returns
        -------
        str
            Path to the saved metadata file
        """
        return self.run_metadata.save(output_dir)

    def summary_table(
        self,
        vars_to_summarize: Optional[List[str]] = None,
        round_to: int = 6,
        interval_type: str = IntervalType.HDI.value,
        prob_interval: float = 0.95,
        output_dir: Optional[str] = None,
        full_output: bool = False,
    ) -> pd.DataFrame:
        """Get summary table for the model with mean, median, and credible intervals of posterior distribution.

        Parameters
        ----------
        vars_to_summarize : list, optional
            List of variable names to include in the summary table.
            If None, uses model's table variables based on full_output setting
        round_to : int, optional
            Number of decimal places to round to, by default 6
        interval_type : str, optional
            Type of interval to compute, either IntervalType.HDI (Highest Density Interval) or
            IntervalType.ETI (Equal-tailed Interval), by default IntervalType.HDI
        prob_interval : float, optional
            Probability mass to include in the interval, by default 0.95 (95% interval)
        output_dir : str, optional
            If provided, saves the summary table to this directory, by default None
        full_output : bool, optional
            If True, use full variable set, otherwise use short set (default: False)

        Returns
        -------
        pd.DataFrame
            Summary table for the model with mean and credible intervals
        """
        self.logger.info(f"Generating summary table using {interval_type} intervals")
        post_summary = pd.DataFrame()

        # Validate probability interval
        if interval_type not in IntervalType.values():
            raise ValueError(f"Invalid interval type: {interval_type}. Must be one of {IntervalType.values()}")

        if not 0 < prob_interval < 1:
            raise ValueError(f"prob_interval must be between 0 and 1, got {prob_interval}")

        # Calculate interval parameters
        interval_params = self._calculate_interval_params(interval_type, prob_interval)

        # Determine variables to summarize
        vars_to_summarize = self._get_vars_to_summarize(vars_to_summarize, full_output)

        # Process variables from trace and posterior predictive
        trace_vars, pp_vars = self._get_available_variables(vars_to_summarize)

        # Get display names if available
        var_display_names = self.model.vars_display_names

        # Process trace variables
        self._add_variables_to_summary(
            post_summary,
            trace_vars,
            self.trace.posterior,
            var_display_names,
            round_to,
            interval_type,
            interval_params,
        )

        # Process posterior predictive variables if available
        if pp_vars:
            self._add_variables_to_summary(
                post_summary,
                pp_vars,
                self.posterior_predictive_trace.posterior_predictive,
                var_display_names,
                round_to,
                interval_type,
                interval_params,
            )

        self.logger.info(f"\n{post_summary}")

        # Save to file if output_dir is provided
        if output_dir is not None:
            self._save_summary_table(post_summary, output_dir)

        return post_summary

    def _get_vars_to_summarize(self, vars_to_summarize: Optional[List[str]], full_output: bool) -> List[str]:
        """Determine which variables to include in the summary table.

        Parameters
        ----------
        vars_to_summarize : Optional[List[str]]
            User-specified list of variables to summarize, if provided
        full_output : bool
            Whether to use the full variable set or the short set

        Returns
        -------
        List[str]
            List of variable names to include in the summary table

        Raises
        ------
        ValueError
            If the model's variable list is empty
        """
        if vars_to_summarize is not None:
            return vars_to_summarize

        if full_output:
            vars_list = self.model.vars_table_full
        else:
            vars_list = self.model.vars_table_short

        # Check if vars_to_summarize is empty after assignment
        if not vars_list:
            table_type = "vars_table_full" if full_output else "vars_table_short"
            raise ValueError(
                f"No variables to summarize. Model {self.model.__class__.__name__} has empty {table_type} list."
            )

        return vars_list

    def _get_available_variables(self, vars_to_summarize: List[str]) -> tuple[List[str], List[str]]:
        """Check which variables are available in trace vs posterior predictive.

        Parameters
        ----------
        vars_to_summarize : List[str]
            List of variable names to check for availability

        Returns
        -------
        tuple[List[str], List[str]]
            A tuple containing two lists:
            - First list: variables available in the trace
            - Second list: variables available in the posterior predictive
        """
        trace_vars = []
        pp_vars = []
        posterior_predictive_vars = self.model.get_posterior_predictive_vars()

        for var in vars_to_summarize:
            if var in self.trace.posterior.data_vars:
                trace_vars.append(var)
            elif var in posterior_predictive_vars:
                pp_vars.append(var)
            else:
                self.logger.warning(f"Variable {var} not found in trace or posterior predictive")

        return trace_vars, pp_vars

    def _calculate_interval_params(self, interval_type: str, prob_interval: float) -> Dict[str, Any]:
        """Calculate parameters for the specified interval type.

        Parameters
        ----------
        interval_type : str
            Type of interval to compute (HDI or ETI)
        prob_interval : float
            Probability mass to include in the interval (between 0 and 1)

        Returns
        -------
        Dict[str, Any]
            Dictionary containing parameters for the specified interval type:
            - For HDI: {'prob': probability, 'label': formatted label string}
            - For ETI: {'lower_percentile': lower percentile value,
                        'upper_percentile': upper percentile value,
                        'label': formatted label string}

        Raises
        ------
        ValueError
            If an invalid interval type is provided
        """
        if interval_type == IntervalType.HDI.value:
            interval_label = f"{prob_interval:.0%} HDI"
            return {"prob": prob_interval, "label": interval_label}
        elif interval_type == IntervalType.ETI.value:
            alpha = 1 - prob_interval
            lower_percentile = alpha / 2 * 100
            upper_percentile = 100 - lower_percentile
            interval_label = f"{prob_interval:.0%} ETI"
            return {
                "lower_percentile": lower_percentile,
                "upper_percentile": upper_percentile,
                "label": interval_label,
            }
        else:
            raise ValueError(f"Invalid interval type: {interval_type}. Must be one of {IntervalType.values()}")

    def _add_variables_to_summary(
        self,
        summary_df: pd.DataFrame,
        variables: List[str],
        data_source: Any,
        display_names: Dict[str, str],
        round_to: int,
        interval_type: str,
        interval_params: Dict[str, Any],
    ) -> None:
        """Add variables to summary dataframe with calculated statistics.

        Parameters
        ----------
        summary_df : pd.DataFrame
            DataFrame to add variable summaries to
        variables : List[str]
            List of variable names to process
        data_source : Any
            Source of data (trace or posterior predictive) containing the variables
        display_names : Dict[str, str]
            Dictionary mapping variable names to display names
        round_to : int
            Number of decimal places to round to
        interval_type : str
            Type of interval to compute (HDI or ETI)
        interval_params : Dict[str, Any]
            Parameters for interval calculation

        Returns
        -------
        None
            The summary_df is modified in-place

        Notes
        -----
        For HDI intervals, uses arviz.hdi() function
        For ETI intervals, uses numpy.percentile()
        """
        for var in variables:
            var_values = data_source[var].values.flatten()

            # Get display name if available
            display_name = display_names.get(var, "")
            summary_df.loc[var, "Description"] = display_name
            summary_df.loc[var, "Mean"] = np.mean(var_values).round(round_to)

            # Calculate median
            median_value = np.median(var_values).round(round_to)

            # Calculate intervals
            if interval_type == IntervalType.HDI.value:
                hdi_interval = az.hdi(var_values, hdi_prob=interval_params["prob"])
                summary_df.loc[var, f'Lower {interval_params["label"]}'] = round(float(hdi_interval[0]), round_to)
                summary_df.loc[var, "Median"] = median_value
                summary_df.loc[var, f'Upper {interval_params["label"]}'] = round(float(hdi_interval[1]), round_to)
            elif interval_type == IntervalType.ETI.value:
                summary_df.loc[var, f'Lower {interval_params["label"]}'] = np.percentile(
                    var_values, interval_params["lower_percentile"]
                ).round(round_to)
                summary_df.loc[var, "Median"] = median_value
                summary_df.loc[var, f'Upper {interval_params["label"]}'] = np.percentile(
                    var_values, interval_params["upper_percentile"]
                ).round(round_to)
            else:
                raise ValueError(f"Invalid interval type: {interval_type}. Must be one of {IntervalType.values()}")

    def _save_summary_table(self, summary_df: pd.DataFrame, output_dir: str) -> str:
        """Save summary table to a CSV file.

        Parameters
        ----------
        summary_df : pd.DataFrame
            DataFrame containing the summary table to save
        output_dir : str
            Directory to save the summary table

        Returns
        -------
        str
            Path to the saved summary table file

        Notes
        -----
        Creates output directory and subdirectory with run_id if they don't exist
        """
        os.makedirs(output_dir, exist_ok=True)
        output_subdir = os.path.join(output_dir, self.run_metadata.run_id)
        os.makedirs(output_subdir, exist_ok=True)
        output_path = os.path.join(output_subdir, f"summary_table_{self.run_metadata.run_id}.csv")
        summary_df.to_csv(output_path)
        self.logger.info(f"Summary table saved to {output_path}")
        return output_path

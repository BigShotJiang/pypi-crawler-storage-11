import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import pandas as pd


class RunMetadata:
    """Class to store and save metadata about a meta-analysis run."""

    def __init__(self, run_id: Optional[str] = None, logger: Optional[Any] = None) -> None:
        """Initialize run metadata.

        Parameters
        ----------
        run_id : str, optional
            Unique identifier for the run. If None, a timestamp-based ID will be generated.
        logger : logging.Logger, optional
            Logger instance to use. If None, a default logger will be created.
        """
        if logger:
            self.logger = logging.getLogger(f"{logger.name}.run_metadata")
        else:
            self.logger = logging.getLogger("run_metadata")

        self.run_id = run_id or datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        self.timestamp = datetime.now(timezone.utc).isoformat()
        self.config: Dict[str, Any] = {}
        self.priors: Dict[str, Any] = {}
        self.data_summary: Dict[str, Any] = {}
        self.convergence_results: Dict[str, Any] = {}
        self.sampling_stats: Dict[str, Any] = {}

    def log_config(self, config: Dict[str, Any]) -> None:
        """Log the configuration used for the run.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration dictionary to log

        Returns
        -------
        None
        """
        self.config = config

    def log_priors(self, priors: Dict[str, Any]) -> None:
        """Log the priors used for the run.

        Parameters
        ----------
        priors : Dict[str, Any]
            Prior distributions dictionary to log

        Returns
        -------
        None
        """
        self.priors = priors

    def log_data_summary(self, data: pd.DataFrame) -> None:
        """Log summary statistics about the input data.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing the input data to summarize

        Returns
        -------
        None
        """
        self.data_summary = {
            "n_observations": len(data),
            "columns": list(data.columns),
            "column_means": data.mean(numeric_only=True).to_dict(),
            "column_stds": data.std(numeric_only=True).to_dict(),
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert metadata to dictionary.

        Returns
        -------
        Dict[str, Any]
            Dictionary representation of the run metadata
        """
        return {
            "run_id": self.run_id,
            "timestamp": self.timestamp,
            "config": self.config,
            "priors_used_in_analysis": self.priors,
            "data_summary": self.data_summary,
        }

    def save(self, output_dir: str) -> str:
        """Save metadata to a JSON file.

        Parameters
        ----------
        output_dir : str
            Directory to save the metadata file

        Returns
        -------
        str
            Path to the saved metadata file
        """
        os.makedirs(output_dir, exist_ok=True)
        output_subdir = os.path.join(output_dir, self.run_id)
        os.makedirs(output_subdir, exist_ok=True)
        filepath = os.path.join(output_subdir, f"run_metadata_{self.run_id}.json")

        with open(filepath, "w") as f:
            json.dump(self.to_dict(), f, indent=2, default=str)

        self.logger.info(f"Run metadata saved to {filepath}")

        return filepath

"""
Configuration - Centralized configuration management and validation for BBAM.

This module provides the ConfigurationManager class that handles all configuration
operations including loading, validation, defaults, and comprehensive error checking.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import numpy as np
from yaml import safe_dump, safe_load

from ..utils.enums import BiasSpecification, IntervalType, LikelihoodDistribution, PriorSpecifications, WarningLevel


class ConfigurationError(Exception):
    """Custom exception for configuration-related errors."""

    pass


class ConfigurationValidationError(ConfigurationError):
    """Specific exception for configuration validation failures."""

    pass


class ConfigurationManager:
    """Centralized configuration management for BBAM models.

    This class handles all configuration operations including:
    - Loading configurations from files, dictionaries, or defaults
    - Comprehensive validation with detailed error messages
    - Model-specific configuration generation
    - Configuration templating and schema validation
    - File I/O operations with proper error handling
    - Configuration merging and inheritance
    """

    def __init__(self, logger: Optional[logging.Logger] = None):
        """Initialize the configuration manager.

        Parameters
        ----------
        logger : logging.Logger, optional
            Logger instance to use. If None, creates a default logger.
        """
        if logger:
            self.logger = logging.getLogger(f"{logger.name}.configuration")
        else:
            self.logger = logging.getLogger("bbam.configuration")

    def load_configuration(
        self,
        config: Optional[Union[Dict[str, Any], str, Path]] = None,
        model_type: str = "standard",
    ) -> Dict[str, Any]:
        """Load and validate configuration from various sources.

        Parameters
        ----------
        config : Union[Dict[str, Any], str, Path], optional
            Configuration source. Can be:
            - Dict: Configuration dictionary
            - str/Path: Path to YAML configuration file
            - None: Use default configuration
        model_type : str, optional
            Model type for default configuration generation (default: 'standard')

        Returns
        -------
        Dict[str, Any]
            Validated and prepared configuration dictionary

        Raises
        ------
        ConfigurationError
            If configuration loading fails
        ConfigurationValidationError
            If configuration validation fails
        """
        try:
            self.logger.info("Loading configuration")

            # Load raw configuration
            if config is None:
                raw_config = self._get_default_configuration(model_type)
                self.logger.info("Using default configuration")
            elif isinstance(config, dict):
                raw_config = config.copy()
                self.logger.info("Using provided configuration dictionary")
            elif isinstance(config, (str, Path)):
                raw_config = self._load_from_file(config)
                self.logger.info(f"Loaded configuration from file: {config}")
            else:
                raise ConfigurationError(
                    f"Invalid configuration type: {type(config)}. " "Must be dict, str, Path, or None"
                )

            # Validate and prepare configuration
            validated_config = self._validate_configuration(raw_config, model_type)

            self.logger.info("Configuration loaded and validated successfully")
            return validated_config

        except Exception as e:
            error_msg = f"Failed to load configuration: {str(e)}"
            self.logger.error(error_msg)
            if isinstance(e, (ConfigurationError, ConfigurationValidationError)):
                raise
            else:
                raise ConfigurationError(error_msg)

    def _load_from_file(self, file_path: Union[str, Path]) -> Dict[str, Any]:
        """Load configuration from YAML file.

        Parameters
        ----------
        file_path : Union[str, Path]
            Path to the configuration file

        Returns
        -------
        Dict[str, Any]
            Configuration dictionary loaded from file

        Raises
        ------
        ConfigurationError
            If file loading fails
        """
        try:
            file_path = Path(file_path)

            if not file_path.exists():
                raise FileNotFoundError(f"Configuration file not found: {file_path}")

            if not file_path.is_file():
                raise ValueError(f"Configuration path is not a file: {file_path}")

            with open(file_path, "r") as f:
                config = safe_load(f)

            if config is None:
                raise ValueError(f"Configuration file is empty or invalid: {file_path}")

            if not isinstance(config, dict):
                raise ValueError(f"Configuration file must contain a dictionary: {file_path}")

            return config

        except Exception as e:
            raise ConfigurationError(f"Failed to load configuration file {file_path}: {e}")

    def _get_default_configuration(self, model_type: str = "standard") -> Dict[str, Any]:
        """Generate default configuration for specified model type.

        Parameters
        ----------
        model_type : str, optional
            Model type ('standard', 'rct_only', 'scaled')

        Returns
        -------
        Dict[str, Any]
            Default configuration dictionary
        """
        base_config = {
            "data_driven_priors": False,
            "priors": self._get_default_priors(model_type),
            "sampling_settings": {
                "tune": 1000,
                "draws": 1000,
                "chains": 4,
                "cores": 4,
                "target_accept": 0.8,
                "maxdepth": 10,
                "n_sample_posterior": 0,
                "is_random_seed": False,
                "seed": 42,
            },
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": LikelihoodDistribution.NORMAL.value,
                "skip_model_posterior_metrics": False,
            },
            "warning_level_setting": WarningLevel.NORMAL.value,
            "warning_level_definition": {
                WarningLevel.NORMAL.value: {"rhat_threshold": 1.01},
                WarningLevel.RELAXED.value: {"rhat_threshold": 1.05},
            },
            "data_driven_priors_settings": self._get_default_data_driven_settings(model_type),
            "results_settings": {
                "prob_interval": 0.9,
                "round_to": 6,
                "interval_type": IntervalType.HDI.value,
            },
            "output_settings": {
                "save_samples": False,
                "save_diagnostics": True,
                "save_plots": False,
                "output_format": "csv",
            },
        }

        # Model-specific adjustments
        model_settings = base_config["model_settings"]
        assert isinstance(model_settings, dict), "model_settings must be a dictionary"
        if model_type == "rct_only":
            # RCT-only model doesn't need bias specifications
            model_settings["bias_spec"] = None

        return base_config

    def _get_default_priors(self, model_type: str) -> Dict[str, Any]:
        """Get default priors based on model type.

        Parameters
        ----------
        model_type : str
            Model type ('standard', 'rct_only', 'scaled')

        Returns
        -------
        Dict[str, Any]
            Default priors dictionary
        """
        if model_type == "rct_only":
            return {
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
            }
        elif model_type == "scaled":
            return {
                "mu_ati": {"delta_mu_ati": 0.0, "gamma_mu_ati": 1.0},
                "sigma_ati": {"zeta_sigma_ati": 1.0},
                "sigma_tau": {"eta_sigma_tau": 0.5, "zeta_sigma_tau": 0.3},
                "mu_scale": {"delta_mu_scale": 1.0, "gamma_mu_scale": 1.0},
                "sigma_scale": {"zeta_sigma_scale": 1.0},
                "mu_beta_0": {"delta_beta_0": 0.0, "gamma_beta_0": 1.0},
                "sigma_beta_0": {"zeta_beta_0": 1.0},
                "mu_beta_1": {"delta_beta_1": 1.0, "gamma_beta_1": 0.5},
                "sigma_beta_1": {"zeta_beta_1": 0.5},
            }
        else:  # standard
            return {
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
                "mu_beta_0": {"delta_beta_0": 0.0, "gamma_beta_0": 1.0},
                "sigma_beta_0": {"zeta_beta_0": 1.0},
                "mu_beta_1": {"delta_beta_1": 1.0, "gamma_beta_1": 0.5},
                "sigma_beta_1": {"zeta_beta_1": 0.5},
            }

    def _get_default_data_driven_settings(self, model_type: str) -> Dict[str, Any]:
        """Get default data-driven priors settings.

        Parameters
        ----------
        model_type : str
            Model type

        Returns
        -------
        Dict[str, Any]
            Default data-driven priors settings
        """
        if model_type == "rct_only":
            return {"treatment_effect": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 0.5}}
        elif model_type == "scaled":
            return {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_intercept": {"scale_prior_width_mean": 0.005, "scale_prior_width_sigma": 0.01},
                "bias_multiplier": {
                    "center_prior_mean": 0.5,
                    "prior_width_mean": 1.0,
                    "prior_width_sigma": 2.0,
                },
            }
        else:  # standard or scaled
            return {
                "treatment_effect": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 0.5},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 0.5},
                "bias_multiplier": {
                    "center_prior_mean": 1.0,
                    "prior_width_mean": 0.5,
                    "prior_width_sigma": 0.25,
                },
            }

    def _validate_configuration(self, config: Dict[str, Any], model_type: str) -> Dict[str, Any]:
        """Comprehensive configuration validation and preparation.

        Parameters
        ----------
        config : Dict[str, Any]
            Raw configuration dictionary to validate
        model_type : str
            Model type for validation context

        Returns
        -------
        Dict[str, Any]
            Validated and prepared configuration

        Raises
        ------
        ConfigurationValidationError
            If validation fails
        """
        try:
            self.logger.debug("Starting comprehensive configuration validation")

            # Create a copy to avoid modifying the original
            validated_config = config.copy()

            # Validate core structure
            self._validate_core_structure(validated_config)

            # Validate and prepare priors
            self._validate_priors_section(validated_config, model_type)

            # Validate sampling settings
            self._validate_sampling_settings(validated_config)

            # Validate model settings
            self._validate_model_settings(validated_config, model_type)

            # Validate warning levels
            self._validate_warning_levels(validated_config)

            # Validate data-driven priors if enabled
            if validated_config.get("data_driven_priors", False):
                self._validate_data_driven_priors(validated_config, model_type)

            # Validate results settings
            self._validate_results_settings(validated_config)

            # Validate output settings
            self._validate_output_settings(validated_config)

            # Add any missing defaults
            self._add_missing_defaults(validated_config, model_type)

            # Final consistency checks
            self._validate_consistency(validated_config, model_type)

            self.logger.info("Configuration validation completed successfully")
            return validated_config

        except Exception as e:
            error_msg = f"Configuration validation failed: {str(e)}"
            self.logger.error(error_msg)
            raise ConfigurationValidationError(error_msg)

    def _validate_core_structure(self, config: Dict[str, Any]) -> None:
        """Validate core configuration structure.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to validate
        """
        required_sections = [
            "sampling_settings",
            "warning_level_setting",
            "warning_level_definition",
        ]

        missing_sections = [section for section in required_sections if section not in config]
        if missing_sections:
            raise ValueError(f"Missing required configuration sections: {missing_sections}")

    def _validate_priors_section(self, config: Dict[str, Any], model_type: str) -> None:
        """Validate priors configuration section.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to validate
        model_type : str
            Model type for context
        """
        # Set default data_driven_priors if not provided
        if "data_driven_priors" not in config:
            config["data_driven_priors"] = False

        # If not using data-driven priors, ensure static priors are provided
        if not config["data_driven_priors"]:
            if "priors" not in config:
                raise ValueError(
                    "Priors must be provided in 'priors' section when " "data_driven_priors is False or omitted"
                )

            # Validate prior structure
            self._validate_prior_structure(config["priors"], model_type)

    def _validate_prior_structure(self, priors: Dict[str, Any], model_type: str) -> None:
        """Validate the structure of priors dictionary.

        Parameters
        ----------
        priors : Dict[str, Any]
            Priors dictionary to validate
        model_type : str
            Model type for context
        """
        # Get required priors using shared definitions from PriorSpecifications
        try:
            required_priors = PriorSpecifications.get_required_priors(model_type)
        except ValueError as e:
            raise ValueError(f"Invalid model type in prior validation: {e}")

        missing_priors = [prior for prior in required_priors if prior not in priors]
        if missing_priors:
            raise ValueError(f"Missing required priors for {model_type} model: {missing_priors}")

        # Validate individual prior structures
        for prior_name, prior_spec in priors.items():
            if not isinstance(prior_spec, dict):
                raise ValueError(f"Prior '{prior_name}' must be a dictionary")

    def _validate_sampling_settings(self, config: Dict[str, Any]) -> None:
        """Validate sampling settings section.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to validate
        """
        sampling = config["sampling_settings"]

        # Required integer parameters with their minimum values
        int_params = {"tune": 100, "draws": 100, "chains": 1, "cores": 1, "maxdepth": 5}

        for param, min_val in int_params.items():
            if param not in sampling:
                raise ValueError(f"Missing required sampling parameter: {param}")

            value = sampling[param]
            if not isinstance(value, int) or value < min_val:
                raise ValueError(f"Parameter '{param}' must be an integer >= {min_val}, got {value}")

        # Validate target_accept
        if "target_accept" not in sampling:
            sampling["target_accept"] = 0.8
        else:
            target_accept = sampling["target_accept"]
            if not isinstance(target_accept, (int, float)) or not 0 < target_accept < 1:
                raise ValueError(f"target_accept must be between 0 and 1, got {target_accept}")

        # Validate n_sample_posterior
        if "n_sample_posterior" not in sampling:
            sampling["n_sample_posterior"] = 0
        else:
            n_posterior = sampling["n_sample_posterior"]
            if not isinstance(n_posterior, int) or n_posterior < 0:
                raise ValueError(f"n_sample_posterior must be non-negative integer, got {n_posterior}")

        # Validate random seed settings
        if "is_random_seed" not in sampling:
            sampling["is_random_seed"] = False

        if not sampling["is_random_seed"]:
            if "seed" not in sampling:
                raise ValueError("Seed must be provided when is_random_seed is False or omitted")
            seed = sampling["seed"]
            if not isinstance(seed, int):
                raise ValueError(f"Seed must be an integer, got {type(seed)}")
        else:
            # Generate random seed if requested
            sampling["generated_seed"] = np.random.randint(1, 1000000)
            sampling["seed"] = sampling["generated_seed"]

    def _validate_model_settings(self, config: Dict[str, Any], model_type: str) -> None:
        """Validate model settings section.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to validate
        model_type : str
            Model type for context
        """
        if "model_settings" not in config:
            config["model_settings"] = {}

        model_settings = config["model_settings"]

        # Validate bias specification for relevant models
        if model_type in ["standard", "scaled"]:
            if "bias_spec" not in model_settings:
                model_settings["bias_spec"] = BiasSpecification.BOTH_INT_MULT.value

            bias_spec = model_settings["bias_spec"]
            if bias_spec not in BiasSpecification.values():
                raise ValueError(f"Invalid bias_spec: {bias_spec}. " f"Must be one of {BiasSpecification.values()}")

        # Validate likelihood distribution
        if "likelihood_distribution" not in model_settings:
            model_settings["likelihood_distribution"] = LikelihoodDistribution.NORMAL.value

        likelihood_dist = model_settings["likelihood_distribution"]
        if likelihood_dist not in LikelihoodDistribution.values():
            raise ValueError(
                f"Invalid likelihood_distribution: {likelihood_dist}. "
                f"Must be one of {LikelihoodDistribution.values()}"
            )

        # Validate Student's t degrees of freedom if needed
        if likelihood_dist == LikelihoodDistribution.STUDENT_T.value:
            if "student_df" not in model_settings:
                raise ValueError("student_df parameter required when using Student's t likelihood")

            student_df = model_settings["student_df"]
            if not isinstance(student_df, (int, float)) or student_df <= 0:
                raise ValueError(f"student_df must be positive, got {student_df}")

        # Validate skip_model_posterior_metrics option
        if "skip_model_posterior_metrics" not in model_settings:
            model_settings["skip_model_posterior_metrics"] = False

        skip_metrics = model_settings["skip_model_posterior_metrics"]
        if not isinstance(skip_metrics, bool):
            raise ValueError(f"skip_model_posterior_metrics must be a boolean, got {type(skip_metrics)}")

    def _validate_warning_levels(self, config: Dict[str, Any]) -> None:
        """Validate warning level configuration.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to validate
        """
        warning_level = config["warning_level_setting"]
        warning_definitions = config["warning_level_definition"]

        # Validate warning level enum
        if warning_level not in WarningLevel.values():
            raise ValueError(
                f"Invalid warning_level_setting: {warning_level}. " f"Must be one of {WarningLevel.values()}"
            )

        # Check that the chosen warning level is defined
        if warning_level not in warning_definitions:
            raise ValueError(f"Warning level '{warning_level}' not defined in warning_level_definition")

        # Validate warning level definitions
        for level, definition in warning_definitions.items():
            if not isinstance(definition, dict):
                raise ValueError(f"Warning level definition for '{level}' must be a dictionary")

            if "rhat_threshold" not in definition:
                raise ValueError(f"Missing rhat_threshold in warning level '{level}'")

            threshold = definition["rhat_threshold"]
            if not isinstance(threshold, (int, float)) or threshold <= 1.0:
                raise ValueError(f"rhat_threshold must be > 1.0, got {threshold} for level '{level}'")

    def _validate_prior_settings(self, settings: Dict[str, Any], section_name: str, required_params: List[str]) -> None:
        """Validate prior settings parameters are present and positive.

        Parameters
        ----------
        settings : Dict[str, Any]
            Settings dictionary to validate
        section_name : str
            Name of the section for error messages
        required_params : List[str]
            List of required parameter names

        Raises
        ------
        ValueError
            If validation fails
        """
        for param in required_params:
            if param not in settings:
                raise ValueError(f"Missing {param} in {section_name} settings")

            value = settings[param]
            if not isinstance(value, (int, float)) or value <= 0:
                raise ValueError(f"{section_name} {param} must be positive, got {value}")

    def _validate_data_driven_priors(self, config: Dict[str, Any], model_type: str) -> None:
        """Validate data-driven priors configuration.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to validate
        model_type : str
            Model type for context
        """
        if "data_driven_priors_settings" not in config:
            raise ValueError("data_driven_priors_settings section required when data_driven_priors is True")

        dd_settings = config["data_driven_priors_settings"]

        # Validate treatment effect settings (model-specific field names)
        if model_type == "scaled":
            # Scaled model uses treatment_effect_intensity for TTI priors
            if "treatment_effect_intensity" not in dd_settings:
                raise ValueError(
                    "treatment_effect_intensity section required in data_driven_priors_settings for scaled model"
                )
            te_settings = dd_settings["treatment_effect_intensity"]
            te_field_name = "treatment_effect_intensity"
        else:
            # Other models use treatment_effect
            if "treatment_effect" not in dd_settings:
                raise ValueError("treatment_effect section required in data_driven_priors_settings")
            te_settings = dd_settings["treatment_effect"]
            te_field_name = "treatment_effect"

        # Use helper function for treatment effect validation
        self._validate_prior_settings(te_settings, te_field_name, ["scale_prior_width_mean", "scale_prior_width_sigma"])

        # Validate experiment scale settings for scaled model
        if model_type == "scaled":
            if "experiment_scale" not in dd_settings:
                raise ValueError("experiment_scale section required in data_driven_priors_settings for scaled model")

            exp_scale_settings = dd_settings["experiment_scale"]
            # Use helper function for experiment scale validation
            self._validate_prior_settings(
                exp_scale_settings, "experiment_scale", ["scale_prior_width_mean", "scale_prior_width_sigma"]
            )

        # Validate bias settings for relevant models
        if model_type in ["standard", "scaled"]:
            required_bias_sections = ["bias_intercept", "bias_multiplier"]

            for section in required_bias_sections:
                if section not in dd_settings:
                    raise ValueError(f"{section} section required in data_driven_priors_settings")

            # Validate bias intercept using helper function
            bias_int = dd_settings["bias_intercept"]
            self._validate_prior_settings(
                bias_int, "bias_intercept", ["scale_prior_width_mean", "scale_prior_width_sigma"]
            )

            # Validate bias multiplier - special case with different parameter requirements
            bias_mult = dd_settings["bias_multiplier"]
            required_mult_params = ["center_prior_mean", "prior_width_mean", "prior_width_sigma"]

            for param in required_mult_params:
                if param not in bias_mult:
                    raise ValueError(f"Missing {param} in bias_multiplier settings")

                value = bias_mult[param]
                if not isinstance(value, (int, float)):
                    raise ValueError(f"bias_multiplier {param} must be numeric, got {type(value)}")

                # Only width parameters need to be positive, center_prior_mean can be any value
                if param in ["prior_width_mean", "prior_width_sigma"] and value <= 0:
                    raise ValueError(f"bias_multiplier {param} must be positive, got {value}")

    def _validate_results_settings(self, config: Dict[str, Any]) -> None:
        """Validate results settings section.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to validate
        """
        if "results_settings" not in config:
            config["results_settings"] = {}

        results = config["results_settings"]

        # Set defaults for missing options
        defaults = {"prob_interval": 0.9, "round_to": 6, "interval_type": IntervalType.HDI.value}

        for key, default_value in defaults.items():
            if key not in results:
                results[key] = default_value

        # Validate prob_interval
        prob_interval = results["prob_interval"]
        if not isinstance(prob_interval, (int, float)) or not 0 < prob_interval < 1:
            raise ValueError(f"prob_interval must be between 0 and 1, got {prob_interval}")

        # Validate round_to
        round_to = results["round_to"]
        if not isinstance(round_to, int) or round_to < 0:
            raise ValueError(f"round_to must be a non-negative integer, got {round_to}")

        # Validate interval_type
        interval_type = results["interval_type"]
        if interval_type not in IntervalType.values():
            raise ValueError(f"Invalid interval_type: {interval_type}. " f"Must be one of {IntervalType.values()}")

    def _validate_output_settings(self, config: Dict[str, Any]) -> None:
        """Validate output settings section.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to validate
        """
        if "output_settings" not in config:
            config["output_settings"] = {}

        output = config["output_settings"]

        # Set defaults for missing options
        defaults = {
            "save_samples": False,
            "save_diagnostics": True,
            "save_plots": False,
            "output_format": "csv",
        }

        for key, default_value in defaults.items():
            if key not in output:
                output[key] = default_value

        # Validate output format
        valid_formats = ["csv", "json", "excel", "parquet"]
        if output["output_format"] not in valid_formats:
            raise ValueError(f"Invalid output_format: {output['output_format']}. " f"Must be one of {valid_formats}")

    def _add_missing_defaults(self, config: Dict[str, Any], model_type: str) -> None:
        """Add any missing default values to configuration.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to complete
        model_type : str
            Model type for context
        """
        # Add defaults that might be missing after validation
        default_config = self._get_default_configuration(model_type)

        # Recursively add missing defaults
        self._merge_defaults(config, default_config)

    def _merge_defaults(self, config: Dict[str, Any], defaults: Dict[str, Any]) -> None:
        """Recursively merge default values into configuration.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to update
        defaults : Dict[str, Any]
            Default values to merge
        """
        for key, default_value in defaults.items():
            if key not in config:
                config[key] = default_value
            elif isinstance(default_value, dict) and isinstance(config[key], dict):
                self._merge_defaults(config[key], default_value)

    def _validate_consistency(self, config: Dict[str, Any], model_type: str) -> None:
        """Perform final consistency checks on configuration.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to validate
        model_type : str
            Model type for context
        """
        # Check chains vs cores consistency
        sampling = config["sampling_settings"]
        if sampling["cores"] > sampling["chains"]:
            self.logger.warning(
                f"More cores ({sampling['cores']}) than chains ({sampling['chains']}) " "may not improve performance"
            )

        # Check posterior predictive sampling consistency
        if sampling["n_sample_posterior"] > 0:
            if sampling["n_sample_posterior"] > sampling["draws"]:
                self.logger.warning(
                    f"Posterior predictive samples ({sampling['n_sample_posterior']}) "
                    f"exceed MCMC draws ({sampling['draws']})"
                )

        # Model-specific consistency checks
        if model_type == "rct_only":
            if config.get("data_driven_priors", False):
                dd_settings = config.get("data_driven_priors_settings", {})
                if "bias_intercept" in dd_settings or "bias_multiplier" in dd_settings:
                    self.logger.warning(
                        "RCT-only model has bias settings in data_driven_priors_settings, " "which will be ignored"
                    )

    def save_configuration(
        self, config: Dict[str, Any], file_path: Union[str, Path], include_comments: bool = True
    ) -> str:
        """Save configuration to YAML file.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to save
        file_path : Union[str, Path]
            Path where to save the configuration
        include_comments : bool, optional
            Whether to include helpful comments in the output (default: True)

        Returns
        -------
        str
            Path to the saved configuration file

        Raises
        ------
        ConfigurationError
            If saving fails
        """
        try:
            file_path = Path(file_path)

            # Ensure directory exists
            file_path.parent.mkdir(parents=True, exist_ok=True)

            # Add comments if requested
            if include_comments:
                config_to_save = self._add_configuration_comments(config)
            else:
                config_to_save = config

            # Save to file
            with open(file_path, "w") as f:
                safe_dump(config_to_save, f, default_flow_style=False, indent=2, sort_keys=False)

            self.logger.info(f"Configuration saved to {file_path}")
            return str(file_path)

        except Exception as e:
            error_msg = f"Failed to save configuration to {file_path}: {e}"
            self.logger.error(error_msg)
            raise ConfigurationError(error_msg)

    def _add_configuration_comments(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Add helpful comments to configuration for better documentation.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration to document

        Returns
        -------
        Dict[str, Any]
            Configuration with added comments
        """
        # This would add YAML comments if we used a more advanced YAML library
        # For now, return the config as-is
        # In a real implementation, you might use ruamel.yaml for comment support
        return config

    def create_template_configuration(
        self, model_type: str = "standard", include_all_options: bool = False
    ) -> Dict[str, Any]:
        """Create a template configuration with documentation.

        Parameters
        ----------
        model_type : str, optional
            Model type for template (default: 'standard')
        include_all_options : bool, optional
            Whether to include all available options (default: False)

        Returns
        -------
        Dict[str, Any]
            Template configuration dictionary
        """
        template = self._get_default_configuration(model_type)

        if include_all_options:
            # Add optional sections that aren't in the default
            template["results_settings"] = {
                "interval_type": IntervalType.HDI.value,
                "prob_interval": 0.90,
                "round_to": 6,
            }

            template["diagnostics_settings"] = {
                "check_divergences": True,
                "check_energy": True,
                "check_rhat": True,
                "check_ess": True,
            }

        return template


# Convenience functions for backward compatibility
def load_configuration(
    config: Optional[Union[Dict[str, Any], str, Path]] = None,
    model_type: str = "standard",
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """Convenience function for loading configuration.

    Parameters
    ----------
    config : Union[Dict[str, Any], str, Path], optional
        Configuration source
    model_type : str, optional
        Model type (default: 'standard')
    logger : logging.Logger, optional
        Logger instance

    Returns
    -------
    Dict[str, Any]
        Validated configuration
    """
    manager = ConfigurationManager(logger=logger)
    return manager.load_configuration(config, model_type)


def create_default_configuration(model_type: str = "standard") -> Dict[str, Any]:
    """Create a default configuration for the specified model type.

    Parameters
    ----------
    model_type : str, optional
        Model type (default: 'standard')

    Returns
    -------
    Dict[str, Any]
        Default configuration dictionary
    """
    manager = ConfigurationManager()
    return manager._get_default_configuration(model_type)

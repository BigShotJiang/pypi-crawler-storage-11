"""
BBAM Core - Core components for BBAM framework.

This package provides the core components for the BBAM framework,
including data processing, results processing, and other utilities.
"""

from .data_processor import DataProcessor, DataValidationError
from .results_processor import ResultsProcessingError, ResultsProcessor

__all__ = ["DataProcessor", "DataValidationError", "ResultsProcessor", "ResultsProcessingError"]

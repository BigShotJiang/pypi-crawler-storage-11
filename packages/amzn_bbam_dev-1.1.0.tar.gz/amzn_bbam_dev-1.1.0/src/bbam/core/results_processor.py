"""
Results Processor - Handles results processing, HDI calculations, and metrics for BBAM.

This module provides the ResultsProcessor class that centralizes all results processing logic,
including summary statistics, credible intervals, and output formatting.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd

from ..utils.enums import IntervalType


class ResultsProcessingError(Exception):
    """Custom exception for results processing errors."""

    pass


class ResultsProcessor:
    """Handles results processing, summary statistics, and HDI calculations for BBAM models.

    This class centralizes all results-related operations including:
    - Summary table generation with mean, median, and credible intervals
    - HDI (Highest Density Interval) and ETI (Equal-Tailed Interval) calculations
    - Variable separation between trace and posterior predictive
    - Multiple output formats (DataFrame, dict, JSON, CSV)
    - Enhanced metrics and diagnostics
    - File saving and export capabilities
    """

    def __init__(self, logger: Optional[logging.Logger] = None):
        """Initialize the results processor.

        Parameters
        ----------
        logger : logging.Logger, optional
            Logger instance to use. If None, creates a default logger.
        """
        if logger:
            self.logger = logging.getLogger(f"{logger.name}.results_processor")
        else:
            self.logger = logging.getLogger("bbam.results_processor")

    def generate_summary_table(
        self,
        trace: Any,
        posterior_predictive_trace: Optional[Any],
        model_vars_metadata: Dict[str, Any],
        vars_to_summarize: Optional[List[str]] = None,
        round_to: int = 6,
        interval_type: str = IntervalType.HDI.value,
        prob_interval: float = 0.95,
        full_output: bool = False,
    ) -> pd.DataFrame:
        """Generate comprehensive summary table for model results.

        Parameters
        ----------
        trace : arviz.InferenceData
            MCMC trace containing posterior samples
        posterior_predictive_trace : arviz.InferenceData, optional
            Posterior predictive trace containing predicted samples
        model_vars_metadata : Dict[str, Any]
            Dictionary containing model variable metadata:
            - 'vars_table_full': List of all variables for full output
            - 'vars_table_short': List of key variables for default output
            - 'vars_display_names': Dictionary mapping variable names to display names
            - 'posterior_predictive_vars': List of posterior predictive variable names
        vars_to_summarize : List[str], optional
            Specific variables to include. If None, uses model metadata.
        round_to : int, optional
            Number of decimal places to round to (default: 6)
        interval_type : str, optional
            Type of credible interval ('HDI' or 'ETI', default: 'HDI')
        prob_interval : float, optional
            Probability mass for credible interval (default: 0.95)
        full_output : bool, optional
            Whether to include all variables or just key ones (default: False)

        Returns
        -------
        pd.DataFrame
            Summary table with statistics for each variable

        Raises
        ------
        ResultsProcessingError
            If results processing fails
        """
        try:
            self.logger.info(f"Generating summary table using {interval_type} intervals")

            # Validate inputs
            self._validate_interval_params(interval_type, prob_interval)

            # Determine which variables to summarize
            vars_to_summarize = self._get_vars_to_summarize(vars_to_summarize, model_vars_metadata, full_output)

            # Separate trace variables from posterior predictive variables
            trace_vars, pp_vars = self._get_available_variables(
                vars_to_summarize,
                trace,
                posterior_predictive_trace,
                model_vars_metadata.get("posterior_predictive_vars", []),
            )

            # Calculate interval parameters
            interval_params = self._calculate_interval_params(interval_type, prob_interval)

            # Create summary dataframe
            post_summary = pd.DataFrame()

            # Get display names
            var_display_names = model_vars_metadata.get("vars_display_names", {})

            # Process trace variables
            if trace_vars:
                self._add_variables_to_summary(
                    post_summary,
                    trace_vars,
                    trace.posterior,
                    var_display_names,
                    round_to,
                    interval_type,
                    interval_params,
                    variable_source="trace",
                )
                post_summary = self._get_variables_rhat(post_summary, trace_vars, trace.posterior)

            # Process posterior predictive variables
            if pp_vars and posterior_predictive_trace is not None:
                # Try to get the correct data source for posterior predictive variables
                pp_data_source = None
                try:
                    if hasattr(posterior_predictive_trace, "posterior_predictive"):
                        pp_data_source = posterior_predictive_trace.posterior_predictive
                    elif hasattr(posterior_predictive_trace, "posterior"):
                        pp_data_source = posterior_predictive_trace.posterior

                    if pp_data_source is not None:
                        self._add_variables_to_summary(
                            post_summary,
                            pp_vars,
                            pp_data_source,
                            var_display_names,
                            round_to,
                            interval_type,
                            interval_params,
                            variable_source="posterior_predictive",
                        )
                        post_summary = self._get_variables_rhat(post_summary, pp_vars, pp_data_source)
                    else:
                        self.logger.warning("Could not access posterior predictive data source")
                except Exception as e:
                    self.logger.warning(f"Failed to process posterior predictive variables: {e}")

            self.logger.info(f"Summary table generated successfully with {len(post_summary)} variables")
            post_summary = self.format_results(post_summary, "dataframe")
            return post_summary

        except Exception as e:
            error_msg = f"Failed to generate summary table: {str(e)}"
            self.logger.error(error_msg)
            raise ResultsProcessingError(error_msg)

    def _validate_interval_params(self, interval_type: str, prob_interval: float) -> None:
        """Validate interval parameters.

        Parameters
        ----------
        interval_type : str
            Type of interval to validate
        prob_interval : float
            Probability interval to validate

        Raises
        ------
        ValueError
            If parameters are invalid
        """
        if interval_type not in IntervalType.values():
            raise ValueError(f"Invalid interval type: {interval_type}. Must be one of {IntervalType.values()}")

        if not 0 < prob_interval < 1:
            raise ValueError(f"prob_interval must be between 0 and 1, got {prob_interval}")

    def _get_vars_to_summarize(
        self,
        vars_to_summarize: Optional[List[str]],
        model_vars_metadata: Dict[str, Any],
        full_output: bool,
    ) -> List[str]:
        """Determine which variables to include in the summary table.

        Parameters
        ----------
        vars_to_summarize : Optional[List[str]]
            User-specified list of variables, if provided
        model_vars_metadata : Dict[str, Any]
            Model variable metadata
        full_output : bool
            Whether to use full variable set or short set

        Returns
        -------
        List[str]
            List of variable names to summarize

        Raises
        ------
        ValueError
            If no variables are available to summarize
        """
        if vars_to_summarize is not None:
            return vars_to_summarize

        if full_output:
            vars_list = model_vars_metadata.get("vars_table_full", [])
        else:
            vars_list = model_vars_metadata.get("vars_table_short", [])

        if not vars_list:
            raise ValueError(
                f"No variables to summarize. Model metadata has empty "
                f"{'vars_table_full' if full_output else 'vars_table_short'} list."
            )

        return list(vars_list)

    def _get_available_variables(
        self,
        vars_to_summarize: List[str],
        trace: Any,
        posterior_predictive_trace: Optional[Any],
        posterior_predictive_var_names: List[str],
    ) -> tuple[List[str], List[str]]:
        """Separate variables into trace variables and posterior predictive variables.

        Parameters
        ----------
        vars_to_summarize : List[str]
            List of variable names to categorize
        trace : arviz.InferenceData
            MCMC trace
        posterior_predictive_trace : arviz.InferenceData
            Posterior predictive trace
        posterior_predictive_var_names : List[str]
            Names of known posterior predictive variables

        Returns
        -------
        tuple[List[str], List[str]]
            Tuple of (trace_vars, posterior_predictive_vars)
        """
        trace_vars = []
        pp_vars = []

        # Get available variable names from trace
        trace_var_names = []
        if trace is not None:
            try:
                trace_var_names = list(trace.posterior.data_vars)
            except Exception as e:
                self.logger.warning(f"Could not access trace.posterior.data_vars: {e}")

        # Get available variable names from posterior predictive trace
        pp_var_names = []
        if posterior_predictive_trace is not None:
            try:
                # Try different possible structures for posterior predictive traces
                if hasattr(posterior_predictive_trace, "posterior_predictive"):
                    pp_var_names = list(posterior_predictive_trace.posterior_predictive.data_vars)
                elif hasattr(posterior_predictive_trace, "posterior"):
                    # Fallback: some traces might store PP data in posterior
                    pp_var_names = list(posterior_predictive_trace.posterior.data_vars)
                else:
                    self.logger.warning("Posterior predictive trace structure not recognized")
            except Exception as e:
                self.logger.warning(f"Could not access posterior predictive variables: {e}")

        # Categorize each variable
        for var in vars_to_summarize:
            if var in trace_var_names:
                trace_vars.append(var)
            elif var in pp_var_names:
                pp_vars.append(var)
            elif var in posterior_predictive_var_names:
                # Variable is expected to be in posterior predictive but not found
                self.logger.warning(f"Expected posterior predictive variable '{var}' not found")
            else:
                self.logger.warning(f"Variable '{var}' not found in trace or posterior predictive")

        return trace_vars, pp_vars

    def _calculate_interval_params(self, interval_type: str, prob_interval: float) -> Dict[str, Any]:
        """Calculate parameters for the specified credible interval type.

        Parameters
        ----------
        interval_type : str
            Type of interval ('HDI' or 'ETI')
        prob_interval : float
            Probability mass for the interval

        Returns
        -------
        Dict[str, Any]
            Parameters for interval calculation
        """
        if interval_type == IntervalType.HDI.value:
            return {
                "prob": prob_interval,
                "label": f"{prob_interval:.0%} HDI",
                "lower_col": f"Lower {prob_interval:.0%} HDI",
                "upper_col": f"Upper {prob_interval:.0%} HDI",
            }
        elif interval_type == IntervalType.ETI.value:
            alpha = 1 - prob_interval
            lower_percentile = alpha / 2 * 100
            upper_percentile = 100 - lower_percentile
            return {
                "lower_percentile": lower_percentile,
                "upper_percentile": upper_percentile,
                "label": f"{prob_interval:.0%} ETI",
                "lower_col": f"Lower {prob_interval:.0%} ETI",
                "upper_col": f"Upper {prob_interval:.0%} ETI",
            }
        else:
            raise ValueError(f"Invalid interval type: {interval_type}")

    def _add_variables_to_summary(
        self,
        summary_df: pd.DataFrame,
        variables: List[str],
        data_source: Any,
        display_names: Dict[str, str],
        round_to: int,
        interval_type: str,
        interval_params: Dict[str, Any],
        variable_source: str = "unknown",
    ) -> None:
        """Add variables to summary dataframe with calculated statistics.

        Parameters
        ----------
        summary_df : pd.DataFrame
            DataFrame to add summaries to (modified in-place)
        variables : List[str]
            Variable names to process
        data_source : Any
            Data source containing the variables (trace or posterior predictive)
        display_names : Dict[str, str]
            Variable name to display name mapping
        round_to : int
            Number of decimal places to round to
        interval_type : str
            Type of credible interval
        interval_params : Dict[str, Any]
            Interval calculation parameters
        variable_source : str, optional
            Source of variables for logging (default: 'unknown')
        """
        for var in variables:
            try:
                var_values = data_source[var].values.flatten()

                # Basic statistics
                display_name = display_names.get(var, "")
                summary_df.loc[var, "Description"] = display_name
                summary_df.loc[var, "Mean"] = np.mean(var_values).round(round_to)
                summary_df.loc[var, "Median"] = np.median(var_values).round(round_to)
                summary_df.loc[var, "Std"] = np.std(var_values).round(round_to)

                # Calculate credible intervals
                self._calculate_credible_intervals(
                    summary_df, var, var_values, interval_type, interval_params, round_to
                )

                # Additional metrics
                self._add_additional_metrics(summary_df, var, var_values, round_to)

            except Exception as e:
                self.logger.warning(f"Failed to process variable '{var}' from {variable_source}: {e}")

    def _calculate_credible_intervals(
        self,
        summary_df: pd.DataFrame,
        var: str,
        var_values: np.ndarray,
        interval_type: str,
        interval_params: Dict[str, Any],
        round_to: int,
    ) -> None:
        """Calculate and add credible intervals to summary.

        Parameters
        ----------
        summary_df : pd.DataFrame
            Summary dataframe to update
        var : str
            Variable name
        var_values : np.ndarray
            Variable values
        interval_type : str
            Type of interval
        interval_params : Dict[str, Any]
            Interval parameters
        round_to : int
            Decimal places to round to
        """
        try:
            if interval_type == IntervalType.HDI.value:
                # Try to use arviz for HDI calculation
                try:
                    import arviz as az

                    hdi_interval = az.hdi(var_values, hdi_prob=interval_params["prob"])
                    summary_df.loc[var, interval_params["lower_col"]] = round(float(hdi_interval[0]), round_to)
                    summary_df.loc[var, interval_params["upper_col"]] = round(float(hdi_interval[1]), round_to)
                except ImportError:
                    self.logger.warning("ArviZ not available, falling back to ETI for HDI calculation")
                    self._calculate_eti_interval(summary_df, var, var_values, interval_params, round_to)
                except Exception as e:
                    self.logger.warning(f"HDI calculation failed for {var}, falling back to ETI: {e}")
                    self._calculate_eti_interval(summary_df, var, var_values, interval_params, round_to)

            elif interval_type == IntervalType.ETI.value:
                self._calculate_eti_interval(summary_df, var, var_values, interval_params, round_to)

        except Exception as e:
            self.logger.error(f"Failed to calculate credible intervals for {var}: {e}")

    def _calculate_eti_interval(
        self,
        summary_df: pd.DataFrame,
        var: str,
        var_values: np.ndarray,
        interval_params: Dict[str, Any],
        round_to: int,
    ) -> None:
        """Calculate Equal-Tailed Interval using percentiles.

        Parameters
        ----------
        summary_df : pd.DataFrame
            Summary dataframe to update
        var : str
            Variable name
        var_values : np.ndarray
            Variable values
        interval_params : Dict[str, Any]
            Interval parameters containing percentiles
        round_to : int
            Decimal places to round to
        """
        if "lower_percentile" in interval_params and "upper_percentile" in interval_params:
            summary_df.loc[var, interval_params["lower_col"]] = np.percentile(
                var_values, interval_params["lower_percentile"]
            ).round(round_to)
            summary_df.loc[var, interval_params["upper_col"]] = np.percentile(
                var_values, interval_params["upper_percentile"]
            ).round(round_to)
        else:
            # Default to 95% ETI if parameters missing
            summary_df.loc[var, interval_params["lower_col"]] = np.percentile(var_values, 2.5).round(round_to)
            summary_df.loc[var, interval_params["upper_col"]] = np.percentile(var_values, 97.5).round(round_to)

    def _get_variables_rhat(self, summary_df: pd.DataFrame, vars: List[str], trace: Any) -> pd.DataFrame:
        """Get Gelman-Rubin statistic for each variable.

        Returns
        -------
        Dict[str, float]
            Dictionary of variable names and their R-hat values
        """
        try:
            import arviz as az

            rhat_values = az.rhat(trace)
            self.logger.debug(f"R-hat values:\n{rhat_values}")
            for var in vars:
                if var not in rhat_values.data_vars:
                    self.logger.warning(f"R-hat value not found for variable: {var}")
                else:
                    summary_df.loc[var, "Max R_hat"] = float(rhat_values[var].max())
            return summary_df
        except Exception as e:
            self.logger.warning(f"Failed to calculate R-hat values: {e}")
            return summary_df

    def _add_additional_metrics(
        self, summary_df: pd.DataFrame, var: str, var_values: np.ndarray, round_to: int
    ) -> None:
        """Add additional statistical metrics to the summary.

        Parameters
        ----------
        summary_df : pd.DataFrame
            Summary dataframe to update
        var : str
            Variable name
        var_values : np.ndarray
            Variable values
        round_to : int
            Decimal places to round to
        """
        try:
            # Monte Carlo Standard Error (MCSE)
            mcse = np.std(var_values) / np.sqrt(len(var_values))
            summary_df.loc[var, "MCSE"] = mcse.round(round_to + 2)  # Extra precision for MCSE

            # Effective Sample Size (if arviz available)
            try:
                import arviz as az

                # Create simple dataset for ESS calculation
                import xarray as xr

                var_data = xr.DataArray(
                    var_values.reshape(-1, 1, 1),
                    dims=["draw", "chain", "var"],
                    coords={"var": [var]},
                )
                ess = az.ess(var_data)
                summary_df.loc[var, "ESS"] = float(ess.values)
            except Exception:
                # Fallback ESS estimation
                summary_df.loc[var, "ESS"] = len(var_values)  # Conservative estimate

            # Probability of direction (proportion > 0 or < 0)
            if np.any(var_values > 0) and np.any(var_values < 0):
                prob_positive = np.mean(var_values > 0)
                prob_direction = max(prob_positive, 1 - prob_positive)
                summary_df.loc[var, "P_Direction"] = prob_direction.round(round_to)

        except Exception as e:
            self.logger.debug(f"Failed to calculate additional metrics for {var}: {e}")

    def format_results(
        self, summary_df: pd.DataFrame, format_type: str = "dataframe"
    ) -> Union[pd.DataFrame, Dict[str, Any], str]:
        """Format results in the specified output format.

        Parameters
        ----------
        summary_df : pd.DataFrame
            Summary dataframe to format
        format_type : str, optional
            Output format ('dataframe', 'dict', 'json', default: 'dataframe')

        Returns
        -------
        Union[pd.DataFrame, Dict[str, Any], str]
            Formatted results

        Raises
        ------
        ValueError
            If format_type is not supported
        """
        valid_formats = ["dataframe", "dict", "json"]
        if format_type not in valid_formats:
            raise ValueError(f"Invalid format: {format_type}. Must be one of {valid_formats}")

        def reorder_columns(df: pd.DataFrame, preferred_order: List[str]) -> pd.DataFrame:
            # Create a priority dict for sorting
            priority = {col: i for i, col in enumerate(preferred_order)}

            # Sort columns based on whether they contain preferred terms
            def get_column_priority(col_name: str) -> int:
                # Find the first matching preferred term, or use max priority + 1 if none match
                for term, pri in priority.items():
                    if term in col_name:
                        return pri
                return len(preferred_order)

            # Sort columns using the priority function
            ordered_columns = sorted(df.columns, key=get_column_priority)
            return df[ordered_columns]

        preferred_order_terms = [
            "Description",
            "Mean",
            "Lower",
            "Median",
            "Upper",
            "Std",
            "R_hat",
            "ESS",
            "MCSE",
            "P_Direction",
        ]
        summary_df = reorder_columns(summary_df, preferred_order_terms)

        if format_type == "dataframe":
            return summary_df
        elif format_type == "dict":
            return summary_df.to_dict("index")
        elif format_type == "json":
            return summary_df.to_json(orient="index", indent=2)

        # This should never be reached due to validation above, but is added for type consistency
        return summary_df

    def save_results(self, summary_df: pd.DataFrame, output_path: str, format_type: str = "csv", **kwargs: Any) -> str:
        """Save results to file.

        Parameters
        ----------
        summary_df : pd.DataFrame
            Summary dataframe to save
        output_path : str
            Path where to save the results
        format_type : str, optional
            File format ('csv', 'excel', 'json', default: 'csv')
        **kwargs : dict
            Additional arguments passed to the save function

        Returns
        -------
        str
            Path to the saved file

        Raises
        ------
        ResultsProcessingError
            If saving fails
        """
        try:
            # Ensure output directory exists
            os.makedirs(os.path.dirname(output_path), exist_ok=True)

            if format_type == "csv":
                summary_df.to_csv(output_path, **kwargs)
            elif format_type == "excel":
                summary_df.to_excel(output_path, **kwargs)
            elif format_type == "json":
                with open(output_path, "w") as f:
                    f.write(summary_df.to_json(orient="index", indent=2))
            else:
                raise ValueError(f"Unsupported save format: {format_type}")

            self.logger.info(f"Results saved to {output_path}")
            return output_path

        except Exception as e:
            error_msg = f"Failed to save results to {output_path}: {str(e)}"
            self.logger.error(error_msg)
            raise ResultsProcessingError(error_msg)

    def calculate_model_comparison_metrics(
        self, trace1: Any, trace2: Any, model1_name: str = "Model 1", model2_name: str = "Model 2"
    ) -> Dict[str, Any]:
        """Calculate model comparison metrics between two traces.

        Parameters
        ----------
        trace1 : arviz.InferenceData
            First model trace
        trace2 : arviz.InferenceData
            Second model trace
        model1_name : str, optional
            Name of first model (default: "Model 1")
        model2_name : str, optional
            Name of second model (default: "Model 2")

        Returns
        -------
        Dict[str, Any]
            Dictionary of comparison metrics

        Raises
        ------
        ResultsProcessingError
            If comparison calculation fails
        """
        try:
            comparison_metrics = {}

            # Try to calculate WAIC and LOO if possible
            try:
                import arviz as az

                # WAIC comparison
                if hasattr(trace1, "log_likelihood") and hasattr(trace2, "log_likelihood"):
                    waic1 = az.waic(trace1)
                    waic2 = az.waic(trace2)
                    comparison_metrics["WAIC"] = {
                        model1_name: float(waic1.waic),
                        model2_name: float(waic2.waic),
                        "difference": float(waic2.waic - waic1.waic),
                    }

                # LOO comparison
                if hasattr(trace1, "log_likelihood") and hasattr(trace2, "log_likelihood"):
                    loo1 = az.loo(trace1)
                    loo2 = az.loo(trace2)
                    comparison_metrics["LOO"] = {
                        model1_name: float(loo1.loo),
                        model2_name: float(loo2.loo),
                        "difference": float(loo2.loo - loo1.loo),
                    }

            except Exception as e:
                self.logger.warning(f"Could not calculate WAIC/LOO: {e}")

            # Basic diagnostics comparison
            try:
                import arviz as az

                # R-hat comparison
                rhat1 = az.rhat(trace1)
                rhat2 = az.rhat(trace2)

                comparison_metrics["Diagnostics"] = {
                    f"{model1_name}_max_rhat": float(rhat1.max()),
                    f"{model2_name}_max_rhat": float(rhat2.max()),
                    f"{model1_name}_mean_rhat": float(rhat1.mean()),
                    f"{model2_name}_mean_rhat": float(rhat2.mean()),
                }

            except Exception as e:
                self.logger.warning(f"Could not calculate diagnostics comparison: {e}")

            return comparison_metrics

        except Exception as e:
            error_msg = f"Failed to calculate model comparison metrics: {str(e)}"
            self.logger.error(error_msg)
            raise ResultsProcessingError(error_msg)


# Convenience functions for backward compatibility and simple operations


def calculate_hdi(samples: np.ndarray, prob: float = 0.95) -> tuple[float, float]:
    """Calculate Highest Density Interval for samples.

    Parameters
    ----------
    samples : np.ndarray
        Sample values
    prob : float, optional
        Probability mass (default: 0.95)

    Returns
    -------
    tuple[float, float]
        Lower and upper bounds of HDI
    """
    try:
        import arviz as az

        hdi = az.hdi(samples, hdi_prob=prob)
        return float(hdi[0]), float(hdi[1])
    except ImportError:
        # Fallback to ETI if arviz not available
        alpha = 1 - prob
        lower_percentile = alpha / 2 * 100
        upper_percentile = 100 - lower_percentile
        return np.percentile(samples, lower_percentile), np.percentile(samples, upper_percentile)

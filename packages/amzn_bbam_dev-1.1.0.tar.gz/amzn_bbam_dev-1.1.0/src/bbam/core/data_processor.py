"""
Data Processor - Handles data validation, processing, and column mapping for BBAM.

This module provides the DataProcessor class that centralizes all data handling logic,
including validation, column mapping, and preprocessing operations.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd


class DataValidationError(Exception):
    """Custom exception for data validation errors."""

    pass


class DataProcessor:
    """Handles data validation, processing, and flexible column mapping for BBAM models.

    This class centralizes all data-related operations including:
    - Input data validation and type checking
    - Flexible column name mapping from user data to model requirements
    - Data preprocessing and cleaning operations
    - Missing value detection and handling
    - Statistical validation (e.g., positive standard errors)
    """

    def __init__(self, logger: Optional[logging.Logger] = None):
        """Initialize the data processor.

        Parameters
        ----------
        logger : logging.Logger, optional
            Logger instance to use. If None, creates a default logger.
        """
        if logger:
            self.logger = logging.getLogger(f"{logger.name}.data_processor")
        else:
            self.logger = logging.getLogger("bbam.data_processor")

        # Standard column mapping for different model types
        self._standard_column_mappings = {
            "standard": [
                "experiment_est",
                "experiment_est_se",
                "obs_model_est",
                "obs_model_est_se",
            ],
            "rct_only": ["experiment_est", "experiment_est_se"],
            "scaled": [
                "experiment_est",
                "experiment_est_se",
                "obs_model_est",
                "obs_model_est_se",
                "experiment_scale",
                "experiment_scale_se",
            ],
        }

    def get_required_columns(self, model_type: str) -> List[str]:
        """Get the required column names for a specific model type.

        Parameters
        ----------
        model_type : str
            Type of model ('standard', 'rct_only', 'scaled')

        Returns
        -------
        List[str]
            List of required column names

        Raises
        ------
        ValueError
            If model_type is not supported
        """
        if model_type not in self._standard_column_mappings:
            raise ValueError(
                f"Unsupported model type: {model_type}. "
                f"Must be one of {list(self._standard_column_mappings.keys())}"
            )

        return self._standard_column_mappings[model_type].copy()

    def validate_data(
        self,
        data: pd.DataFrame,
        required_columns: List[str],
        validate_positive_se: bool = True,
        validate_positive_experiment_scale: bool = True,
    ) -> None:
        """Validate input data structure and content.

        Parameters
        ----------
        data : pd.DataFrame
            Input data to validate
        required_columns : List[str]
            List of column names that must be present
        validate_positive_se : bool, optional
            Whether to validate that standard error columns are positive (default: True)
        validate_positive_experiment_scale : bool, optional
            Whether to validate that experiment_scale is positive (default: True)

        Raises
        ------
        DataValidationError
            If data validation fails
        """
        try:
            self.logger.debug(f"Validating data with shape {data.shape}")

            # Check data type
            if not isinstance(data, pd.DataFrame):
                raise ValueError("Input must be a pandas DataFrame")

            # Check for empty data
            if data.empty:
                raise ValueError("Input DataFrame is empty")

            # Check required columns
            missing_cols = [col for col in required_columns if col not in data.columns]
            if missing_cols:
                raise ValueError(f"Missing required columns: {missing_cols}")

            # Check for missing values in required columns
            for col in required_columns:
                if data[col].isnull().any():
                    n_missing = data[col].isnull().sum()
                    raise ValueError(
                        f"Missing values found in required column '{col}': {n_missing} out of {len(data)} rows"
                    )

            # Check for infinite values in required columns
            for col in required_columns:
                if data[col].dtype in ["float64", "float32", "int64", "int32"]:
                    if not data[col].replace([float("inf"), float("-inf")], float("nan")).notna().all():
                        raise ValueError(f"Infinite values found in column '{col}'")

            # Validate standard error columns are positive
            if validate_positive_se:
                se_columns = [col for col in required_columns if col.endswith("_se")]
                for col in se_columns:
                    if (data[col] <= 0).any():
                        n_invalid = (data[col] <= 0).sum()
                        raise ValueError(
                            f"Standard error column '{col}' must be positive. "
                            f"Found {n_invalid} non-positive values."
                        )

            # Validate experiment scale if present and requested
            if validate_positive_experiment_scale and "experiment_scale" in required_columns:
                if (data["experiment_scale"] <= 0).any():
                    n_invalid = (data["experiment_scale"] <= 0).sum()
                    raise ValueError(f"Experiment scale must be positive. " f"Found {n_invalid} non-positive values.")

            self.logger.info(f"Data validation passed for {len(data)} observations with columns: {required_columns}")

        except Exception as e:
            error_msg = f"Data validation failed: {str(e)}"
            self.logger.error(error_msg)
            raise DataValidationError(error_msg)

    def map_columns(
        self,
        data: pd.DataFrame,
        column_mapping: Dict[str, str],
        required_columns: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        """Map user column names to standard BBAM column names.

        Parameters
        ----------
        data : pd.DataFrame
            Input data with user-defined column names
        column_mapping : Dict[str, str]
            Mapping from BBAM standard names to user column names
            e.g., {'experiment_est': 'rct_estimate', 'experiment_est_se': 'rct_se'}
        required_columns : List[str], optional
            List of required standard column names. If provided, validates that all
            required columns are present in the mapping.

        Returns
        -------
        pd.DataFrame
            DataFrame with columns renamed to BBAM standard names

        Raises
        ------
        DataValidationError
            If column mapping is invalid or user columns don't exist
        """
        try:
            self.logger.debug(f"Applying column mapping: {column_mapping}")

            # Validate that all user columns exist in the data
            missing_user_cols = [user_col for user_col in column_mapping.values() if user_col not in data.columns]
            if missing_user_cols:
                raise ValueError(f"User columns not found in data: {missing_user_cols}")

            # If required_columns is provided, check that all are mapped
            if required_columns:
                missing_mappings = [col for col in required_columns if col not in column_mapping]
                if missing_mappings:
                    raise ValueError(f"Missing column mappings for required columns: {missing_mappings}")

            # Create the mapped dataframe
            mapped_data = data.copy()

            # Apply the reverse mapping (user_col -> standard_col)
            reverse_mapping = {user_col: standard_col for standard_col, user_col in column_mapping.items()}

            mapped_data = mapped_data.rename(columns=reverse_mapping)

            self.logger.info(f"Successfully mapped {len(column_mapping)} columns")
            return mapped_data

        except Exception as e:
            error_msg = f"Column mapping failed: {str(e)}"
            self.logger.error(error_msg)
            raise DataValidationError(error_msg)

    def process_data(
        self,
        data: pd.DataFrame,
        model_type: str,
        column_mapping: Optional[Dict[str, str]] = None,
        validate_positive_se: bool = True,
        validate_positive_experiment_scale: bool = True,
        return_full_data: bool = False,
    ) -> pd.DataFrame:
        """Complete data processing pipeline: mapping, validation, and filtering.

        Parameters
        ----------
        data : pd.DataFrame
            Input data to process
        model_type : str
            Type of model ('standard', 'rct_only', 'scaled')
        column_mapping : Dict[str, str], optional
            Mapping from BBAM standard names to user column names.
            If None, assumes data already has standard column names.
        validate_positive_se : bool, optional
            Whether to validate that standard error columns are positive (default: True)
        validate_positive_experiment_scale : bool, optional
            Whether to validate that experiment_scale is positive (default: True)
        return_full_data : bool, optional
            If True, return the complete dataset. If False, return only required columns (default: False)

        Returns
        -------
        pd.DataFrame
            Processed and validated DataFrame ready for model fitting

        Raises
        ------
        DataValidationError
            If data processing fails at any step
        """
        try:
            self.logger.info(f"Starting data processing pipeline for model type: {model_type}")

            # Get required columns for this model type
            required_columns = self.get_required_columns(model_type)

            # Apply column mapping if provided
            if column_mapping:
                processed_data = self.map_columns(data, column_mapping, required_columns)
            else:
                processed_data = data.copy()

            # Validate the processed data
            self.validate_data(
                processed_data,
                required_columns,
                validate_positive_se=validate_positive_se,
                validate_positive_experiment_scale=validate_positive_experiment_scale,
            )

            # Return appropriate subset of data
            if return_full_data:
                result_data = processed_data
            else:
                result_data = processed_data[required_columns].copy()

            self.logger.info(f"Data processing completed successfully. " f"Output shape: {result_data.shape}")

            return result_data

        except Exception as e:
            if isinstance(e, DataValidationError):
                raise
            else:
                error_msg = f"Data processing failed: {str(e)}"
                self.logger.error(error_msg)
                raise DataValidationError(error_msg)

    def clean_data(
        self,
        data: pd.DataFrame,
        remove_duplicates: bool = False,
        handle_outliers: bool = False,
        outlier_method: str = "iqr",
        outlier_threshold: float = 3.0,
    ) -> pd.DataFrame:
        """Clean data by handling duplicates and outliers.

        Parameters
        ----------
        data : pd.DataFrame
            Input data to clean
        remove_duplicates : bool, optional
            Whether to remove duplicate rows (default: False)
        handle_outliers : bool, optional
            Whether to detect and handle outliers (default: False)
        outlier_method : str, optional
            Method for outlier detection ('iqr' or 'zscore', default: 'iqr')
        outlier_threshold : float, optional
            Threshold for outlier detection (default: 3.0)

        Returns
        -------
        pd.DataFrame
            Cleaned DataFrame

        Raises
        ------
        DataValidationError
            If data cleaning fails
        """
        try:
            cleaned_data = data.copy()
            original_shape = cleaned_data.shape

            # Remove duplicates if requested
            if remove_duplicates:
                before_dup = len(cleaned_data)
                cleaned_data = cleaned_data.drop_duplicates()
                after_dup = len(cleaned_data)
                if before_dup > after_dup:
                    self.logger.info(f"Removed {before_dup - after_dup} duplicate rows")

            # Handle outliers if requested
            if handle_outliers:
                numeric_cols = cleaned_data.select_dtypes(include=["float64", "float32", "int64", "int32"]).columns

                for col in numeric_cols:
                    before_outliers = len(cleaned_data)

                    if outlier_method == "iqr":
                        q1 = cleaned_data[col].quantile(0.25)
                        q3 = cleaned_data[col].quantile(0.75)
                        iqr = q3 - q1
                        lower_bound = q1 - outlier_threshold * iqr
                        upper_bound = q3 + outlier_threshold * iqr
                        cleaned_data = cleaned_data[
                            (cleaned_data[col] >= lower_bound) & (cleaned_data[col] <= upper_bound)
                        ]

                    elif outlier_method == "zscore":
                        z_scores = abs((cleaned_data[col] - cleaned_data[col].mean()) / cleaned_data[col].std())
                        cleaned_data = cleaned_data[z_scores <= outlier_threshold]

                    after_outliers = len(cleaned_data)
                    if before_outliers > after_outliers:
                        self.logger.info(f"Removed {before_outliers - after_outliers} outliers from column '{col}'")

            final_shape = cleaned_data.shape
            self.logger.info(f"Data cleaning completed. Shape: {original_shape} -> {final_shape}")

            return cleaned_data

        except Exception as e:
            error_msg = f"Data cleaning failed: {str(e)}"
            self.logger.error(error_msg)
            raise DataValidationError(error_msg)

    def get_data_summary(self, data: pd.DataFrame, required_columns: List[str]) -> Dict[str, Any]:
        """Generate a summary of the data for logging and reporting.

        Parameters
        ----------
        data : pd.DataFrame
            Input data to summarize
        required_columns : List[str]
            List of required columns to focus summary on

        Returns
        -------
        Dict[str, Any]
            Dictionary containing data summary statistics
        """
        try:
            summary = {
                "n_observations": len(data),
                "n_columns": len(data.columns),
                "required_columns": required_columns,
                "column_stats": {},
            }

            # Generate statistics for each required column
            column_stats: Dict[str, Any] = {}
            for col in required_columns:
                if col in data.columns:
                    col_data = data[col]
                    column_stats[col] = {
                        "dtype": str(col_data.dtype),
                        "n_missing": col_data.isnull().sum(),
                        "mean": (
                            float(col_data.mean())
                            if col_data.dtype in ["float64", "float32", "int64", "int32"]
                            else None
                        ),
                        "std": (
                            float(col_data.std())
                            if col_data.dtype in ["float64", "float32", "int64", "int32"]
                            else None
                        ),
                        "min": (
                            float(col_data.min())
                            if col_data.dtype in ["float64", "float32", "int64", "int32"]
                            else None
                        ),
                        "max": (
                            float(col_data.max())
                            if col_data.dtype in ["float64", "float32", "int64", "int32"]
                            else None
                        ),
                    }
            summary["column_stats"] = column_stats

            return summary

        except Exception as e:
            self.logger.warning(f"Failed to generate data summary: {e}")
            return {
                "n_observations": len(data) if isinstance(data, pd.DataFrame) else 0,
                "error": str(e),
            }


# Convenience functions for backward compatibility
def validate_data(data: pd.DataFrame, required_columns: List[str], logger: Optional[logging.Logger] = None) -> None:
    """Convenience function for data validation.

    Parameters
    ----------
    data : pd.DataFrame
        Input data to validate
    required_columns : List[str]
        List of required column names
    logger : logging.Logger, optional
        Logger instance to use

    Raises
    ------
    DataValidationError
        If data validation fails
    """
    processor = DataProcessor(logger=logger)
    processor.validate_data(data, required_columns)


def process_data_for_model(
    data: pd.DataFrame,
    model_type: str,
    column_mapping: Optional[Dict[str, str]] = None,
    logger: Optional[logging.Logger] = None,
) -> pd.DataFrame:
    """Convenience function for complete data processing.

    Parameters
    ----------
    data : pd.DataFrame
        Input data to process
    model_type : str
        Type of model ('standard', 'rct_only', 'scaled')
    column_mapping : Dict[str, str], optional
        Column name mapping
    logger : logging.Logger, optional
        Logger instance to use

    Returns
    -------
    pd.DataFrame
        Processed DataFrame

    Raises
    ------
    DataValidationError
        If data processing fails
    """
    processor = DataProcessor(logger=logger)
    return processor.process_data(data, model_type, column_mapping)


def simulate_unpaired_data(
    df_processed: pd.DataFrame,
    n_unpaired: int = 40,
    noise_sigma: float = 0.01,
    se_noise_sigma: float = 0.01,
    linear_constant: float = 0.005,
    random_seed: int = 42,
) -> pd.DataFrame:
    """
    Create simulated unpaired data based on processed results.

    This function generates synthetic unpaired observational data for testing calibration
    functionality. It samples from the existing processed data and adds controlled noise
    and trends to create realistic test scenarios.

    Parameters
    ----------
    df_processed : pd.DataFrame
        Your existing processed dataframe containing observational estimates
    n_unpaired : int, default=40
        Number of unpaired observations to generate. Default chosen to provide
        sufficient sample size for testing while keeping computation manageable.
    noise_sigma : float, default=0.01
        Standard deviation for Gaussian noise added to observation estimates.
        Default value (0.01) represents typical measurement uncertainty in
        observational models.
    se_noise_sigma : float, default=0.01
        Standard deviation for Gaussian noise added to standard errors.
        Default value ensures realistic variation in uncertainty estimates
        while maintaining positive standard errors.
    linear_constant : float, default=0.005
        Constant for linear trend added to values based on index position.
        Creates systematic variation across observations. Default value
        (0.005) provides subtle trend without overwhelming the base signal.
    random_seed : int, default=42
        Seed for reproducible random number generation. Default ensures
        consistent results across runs for testing purposes.

    Returns
    -------
    pd.DataFrame
        DataFrame containing simulated unpaired data with columns:
        - obs_model_est: Observational model estimates with added noise and trend
        - obs_model_est_se: Standard errors with added noise (always positive)
        - experiment_scale: Scale metrics (if present in input data)
        - experiment_scale_se: Scale standard errors (if present in input data)

    Notes
    -----
    The function automatically detects if the input data contains experiment_scale
    columns (for scaled models) and generates corresponding simulated data.

    The generated data maintains realistic relationships between estimates and
    standard errors while introducing controlled variation for testing.
    """
    np.random.seed(random_seed)  # For reproducibility

    # Sample base observational values from existing data
    base_obs_values = np.random.choice(df_processed["obs_model_est"].values, size=n_unpaired, replace=True)
    base_obs_se = np.random.choice(df_processed["obs_model_est_se"].values, size=n_unpaired, replace=True)

    # Add Gaussian noise
    noise = np.random.normal(0, noise_sigma, n_unpaired)
    se_noise = np.random.normal(0, se_noise_sigma, n_unpaired)

    # Add linear term proportional to index
    linear_term = linear_constant * np.arange(n_unpaired)

    # Create unpaired dataframe
    df_unpaired = pd.DataFrame(
        {"obs_model_est": base_obs_values + noise + linear_term, "obs_model_est_se": base_obs_se + np.abs(se_noise)}
    )

    # For scale model, also add experiment_scale columns
    if "experiment_scale" in df_processed.columns:
        base_scale = np.random.choice(df_processed["experiment_scale"].values, size=n_unpaired, replace=True)
        base_scale_se = np.random.choice(df_processed["experiment_scale_se"].values, size=n_unpaired, replace=True)

        df_unpaired["experiment_scale"] = base_scale * (1 + np.random.normal(0, 0.1, n_unpaired))
        df_unpaired["experiment_scale_se"] = base_scale_se * (1 + np.abs(np.random.normal(0, 0.05, n_unpaired)))

    return df_unpaired

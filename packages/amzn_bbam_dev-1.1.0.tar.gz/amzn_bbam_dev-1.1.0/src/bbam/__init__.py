"""
BBAM (Bayesian Bias Assessment Model) Package.

This package provides tools for Bayesian meta-analysis of randomized controlled trials (RCTs)
and observational studies to assess and calibrate model bias.
"""

from .bbam_analyzer import (
    BbamAnalyzer,
    BbamError,
    CalibrationError,
    ConfigurationError,
    DataValidationError,
    ModelFittingError,
    ModelNotFittedError,
)
from .core.data_processor import DataProcessor, simulate_unpaired_data
from .diagnostics.convergence_diagnostics import ConvergenceDiagnostics

# Legacy imports for backward compatibility
from .meta_analysis import BayesianRCTMetaAnalysis
from .models import Model, RCTObsHBM, RCTOnlyHBM, RCTScaledHBM
from .utils.enums import BiasSpecification, IntervalType, LikelihoodDistribution, WarningLevel

__version__ = "1.1.0"

# Main public API
__all__ = [
    # Main interface
    "BbamAnalyzer",
    # Exceptions
    "BbamError",
    "ConfigurationError",
    "DataValidationError",
    "ModelFittingError",
    "ModelNotFittedError",
    "CalibrationError",
    # Diagnostics
    "ConvergenceDiagnostics",
    # Data processing
    "DataProcessor",
    "simulate_unpaired_data",
    # Legacy classes (for backward compatibility)
    "BayesianRCTMetaAnalysis",
    "Model",
    "RCTOnlyHBM",
    "RCTObsHBM",
    "RCTScaledHBM",
    # Enums
    "BiasSpecification",
    "LikelihoodDistribution",
    "IntervalType",
    "WarningLevel",
]

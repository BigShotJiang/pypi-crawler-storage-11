"""
BBAM Analyzer - Main interface class for Bayesian Bias Assessment Model.

This module provides the primary BbamAnalyzer class that serves as the main entry point
for all BBAM operations, implementing the Package Interface Specification.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
import pymc as pm
from yaml import safe_load

from .config.run_metadata import RunMetadata
from .data_structures import CalibrationResults
from .diagnostics.convergence_diagnostics import ConvergenceDiagnostics
from .models import Model, RCTObsHBM, RCTOnlyHBM, RCTScaledHBM
from .types import ConfigDict, LoggerType
from .utils.enums import IntervalType, ModelTypes


class BbamError(Exception):
    """Base class for all BBAM exceptions."""

    pass


class ConfigurationError(BbamError):
    """Invalid configuration error."""

    pass


class DataValidationError(BbamError):
    """Input data validation error."""

    pass


class ModelFittingError(BbamError):
    """Model fitting error."""

    pass


class ModelNotFittedError(BbamError):
    """Model not fitted error - raised when trying to access results before fitting."""

    pass


class CalibrationError(BbamError):
    """Calibration error."""

    pass


class BbamAnalyzer:
    """Main interface class for Bayesian Bias Assessment Model (BBAM) analysis.

    This class serves as the primary analyzer for all BBAM operations,
    providing a clean API for model fitting, calibration, and result analysis
    while delegating model-specific logic to underlying HBM implementations.

    The analyzer supports three model variants:
    - 'standard': Basic HBM using observational-RCT pairs
    - 'scaled': Extended model incorporating experiment scale metrics
    - 'rct_only': Model using only RCT data without observational pairs
    """

    def __init__(
        self,
        model_type: str = ModelTypes.STANDARD.value,
        config: Optional[Union[Dict[str, Any], str]] = None,
        logger: Optional[logging.Logger] = None,
        run_id: Optional[str] = None,
    ) -> None:
        """Initialize the BBAM analyzer.

        Parameters
        ----------
        model_type : str, optional
            Model variant to use. Options:
            - 'standard': Basic HBM using observational-RCT pairs
            - 'scaled': Extended model incorporating experiment scale metrics
            - 'rct_only': Model using only RCT data without observational pairs
        config : dict, str, optional
            Configuration dictionary or path to configuration file.
            If None, default configuration is used.
        run_id : str, optional
            Unique identifier for the run. If None, a timestamp-based ID will be generated.
            This is used for organizing output files and tracking analysis runs.
        logger : logging.Logger, optional
            Logger instance to use. If None, a default logger will be created.

        Raises
        ------
        ValueError
            If model_type is not one of the supported options
        ConfigurationError
            If configuration is invalid
        """
        # Set up logger
        if logger:
            self.logger = logging.getLogger(f"{logger.name}.BbamAnalyzer")
        else:
            self.logger = logging.getLogger("bbam.BbamAnalyzer")
        self.logger.info("Initializing BBAM analyzer")

        # Validate model type
        valid_model_types = ModelTypes.values()
        if model_type not in valid_model_types:
            raise ValueError(f"Invalid model_type: {model_type}. Must be one of {valid_model_types}")

        self.model_type = model_type
        self.run_id = run_id
        self.config: Optional[Dict[str, Any]] = None
        self.model: Optional[Model] = None
        self.data: Optional[pd.DataFrame] = None
        self.trace: Optional[Any] = None
        self.posterior_predictive_trace: Optional[Any] = None
        self.run_metadata: Optional[RunMetadata] = None
        self._fitted = False

        # Load configuration
        self._load_config(config)

        # Initialize the appropriate model
        self._initialize_model()

        self.logger.info(f"BBAM model initialized with type: {model_type}")

    def _load_config(self, config: Optional[Union[Dict[str, Any], str]]) -> None:
        """Load and validate configuration.

        Parameters
        ----------
        config : dict, str, optional
            Configuration dictionary or path to configuration file
        """
        if config is None:
            # Use default configuration
            self.config = self._get_default_config()
        elif isinstance(config, str):
            # Load from file
            try:
                with open(config, "r") as f:
                    self.config = safe_load(f)
            except FileNotFoundError:
                raise ConfigurationError(f"Configuration file not found: {config}")
            except Exception as e:
                raise ConfigurationError(f"Error loading configuration file: {e}")
        elif isinstance(config, dict):
            # Use provided dictionary
            self.config = config.copy()
        else:
            raise ConfigurationError("Config must be None, dict, or path to configuration file")

        # Prepare and validate configuration
        if self.config is not None:
            self.config = self._prepare_config(self.config)

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration for BBAM models.

        Returns
        -------
        Dict[str, Any]
            Default configuration dictionary
        """
        return {
            "data_driven_priors": False,
            "priors": self._get_default_priors(),
            "sampling_settings": {
                "tune": 1000,
                "draws": 1000,
                "chains": 4,
                "cores": 4,
                "target_accept": 0.8,
                "maxdepth": 10,
                "n_sample_posterior": 0,
                "is_random_seed": False,
                "seed": 42,
            },
            "model_settings": {"bias_spec": "BOTH_INT_MULT", "likelihood_distribution": "normal"},
            "results_settings": {"prob_interval": 0.9, "round_to": 6, "interval_type": "HDI"},
            "warning_level_setting": "normal",
            "warning_level_definition": {
                "normal": {"rhat_threshold": 1.01},
                "relaxed": {"rhat_threshold": 1.05},
            },
        }

    def _get_default_priors(self) -> Dict[str, Any]:
        """Get default priors based on model type.

        Returns
        -------
        Dict[str, Any]
            Default priors dictionary
        """
        if self.model_type == "rct_only":
            return {
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
            }
        else:  # standard or scaled
            return {
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
                "mu_beta_0": {"delta_beta_0": 0.0, "gamma_beta_0": 1.0},
                "sigma_beta_0": {"zeta_beta_0": 1.0},
                "mu_beta_1": {"delta_beta_1": 1.0, "gamma_beta_1": 0.5},
                "sigma_beta_1": {"zeta_beta_1": 0.5},
            }

    def _prepare_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare and validate configuration.

        This method delegates to ConfigurationManager for proper separation of concerns.
        """
        from .config.configuration import ConfigurationManager

        config_manager = ConfigurationManager(logger=self.logger)
        return config_manager._validate_configuration(config, self.model_type)

    def _initialize_model(self) -> None:
        """Initialize the appropriate model based on model_type."""
        if self.model_type == "standard":
            self.model = RCTObsHBM(logger=self.logger)
        elif self.model_type == "rct_only":
            self.model = RCTOnlyHBM(logger=self.logger)
        elif self.model_type == "scaled":
            self.model = RCTScaledHBM(logger=self.logger)
        else:
            valid_types = ModelTypes.values()
            raise ValueError(f"Unknown model type: {self.model_type}. Valid types are: {valid_types}")

    def fit(self, data: pd.DataFrame, **kwargs: Any) -> "BbamAnalyzer":
        """Fit the analyzer to the provided data.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing RCT and observational data.
            Required columns depend on the model_type:
            - 'standard': 'obs_model_est', 'obs_model_est_se', 'experiment_est', 'experiment_est_se'
            - 'scaled': Additional 'experiment_scale' and 'experiment_scale_se' columns
            - 'rct_only': Only 'experiment_est' and 'experiment_est_se' required
        **kwargs : dict
            Additional model-specific parameters:
            - chains (int): Number of sampling chains (default: 4)
            - iterations (int): Number of sampling iterations (default: 2000)
            - burn_in (int): Number of burn-in samples (default: 1000)
            - seed (int): Random seed for reproducibility

        Returns
        -------
        BbamAnalyzer
            The fitted analyzer instance

        Raises
        ------
        DataValidationError
            If data does not contain required columns
        ModelFittingError
            If model fails to converge
        """
        try:
            self.logger.info("Starting model fitting")

            # Validate data
            self._validate_data(data)

            # Store data
            if self.model is None:
                raise ModelFittingError("Model not initialized")
            required_columns = self.model.get_required_data_columns()
            self.data = data[required_columns].copy()

            # Initialize run metadata with run_id
            self.run_metadata = RunMetadata(run_id=self.run_id, logger=self.logger)
            self.run_metadata.log_data_summary(self.data)

            # Update config with kwargs
            if self.config is None:
                raise ModelFittingError("Configuration not loaded")
            config_copy = self.config.copy()
            sampling_settings = config_copy["sampling_settings"].copy()

            # Override with kwargs if provided
            if "chains" in kwargs:
                sampling_settings["chains"] = kwargs["chains"]
            if "iterations" in kwargs:
                sampling_settings["draws"] = kwargs["iterations"]
            if "burn_in" in kwargs:
                sampling_settings["tune"] = kwargs["burn_in"]
            if "seed" in kwargs:
                sampling_settings["seed"] = kwargs["seed"]
                sampling_settings["is_random_seed"] = False

            config_copy["sampling_settings"] = sampling_settings

            # Set and process config with model
            config_copy = self.model.set_and_process_config(config_copy)
            self.run_metadata.log_config(config_copy)

            # Set priors and build model
            self.logger.info("Setting up priors and building model")
            self.model.set_priors(data=self.data)
            self.run_metadata.log_priors(self.model.priors)
            self.model.build(data=self.data)

            # Run MCMC sampling
            sampling_params = {
                "tune": config_copy["sampling_settings"]["tune"],
                "draws": config_copy["sampling_settings"]["draws"],
                "chains": config_copy["sampling_settings"]["chains"],
                "cores": config_copy["sampling_settings"]["cores"],
                "target_accept": config_copy["sampling_settings"]["target_accept"],
                "nuts_sampler": "nutpie",
                "nuts_sampler_kwargs": {"maxdepth": config_copy["sampling_settings"]["maxdepth"]},
                "random_seed": config_copy["sampling_settings"]["seed"],
            }

            self.logger.info("Running MCMC sampling...")
            with self.model.pymc_model:
                self.trace = pm.sample(**sampling_params)
            self.logger.info("MCMC sampling completed successfully")

            # Perform posterior predictive sampling if requested
            if config_copy["sampling_settings"]["n_sample_posterior"] > 0:
                self._sample_posterior_predictive(config_copy)

            # Run convergence diagnostics
            self.logger.info("Running convergence diagnostics")
            self._convergence_diagnostics()

            self._fitted = True
            self.logger.info("Model fitting completed successfully")

            return self

        except Exception as e:
            self.logger.error(f"Error during model fitting: {str(e)}")
            if isinstance(e, (DataValidationError, ModelFittingError)):
                raise
            else:
                raise ModelFittingError(f"Model fitting failed: {e}")

    def _validate_data(self, data: pd.DataFrame) -> None:
        """Validate input data structure and content.

        Parameters
        ----------
        data : pd.DataFrame
            Input data to validate

        Raises
        ------
        DataValidationError
            If data validation fails
        """
        try:
            if not isinstance(data, pd.DataFrame):
                raise ValueError("Input must be a pandas DataFrame")

            # Check required columns
            if self.model is None:
                raise ValueError("Model not initialized")
            required_columns = self.model.get_required_data_columns()
            missing_cols = [col for col in required_columns if col not in data.columns]
            if missing_cols:
                raise ValueError(f"Missing required columns: {missing_cols}")

            # Check for missing values in required columns
            for col in required_columns:
                if data[col].isnull().any():
                    raise ValueError(f"Missing values found in required column: {col}")

            # Check that standard error columns are positive
            se_columns = [col for col in required_columns if col.endswith("_se")]
            for col in se_columns:
                if (data[col] <= 0).any():
                    raise ValueError(f"Standard error column {col} must be positive")

            # Additional validation for experiment scale if applicable
            if "experiment_scale" in required_columns:
                if (data["experiment_scale"] <= 0).any():
                    raise ValueError("Experiment scale must be positive")

        except Exception as e:
            raise DataValidationError(f"Data validation failed: {e}")

    def _sample_posterior_predictive(self, config: Dict[str, Any]) -> None:
        """Sample from the posterior predictive distribution.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration dictionary
        """
        n_samples = config["sampling_settings"]["n_sample_posterior"]
        self.logger.info("Sampling from posterior predictive distribution")

        try:
            if self.model is None:
                raise ModelFittingError("Model not initialized")
            with self.model.pymc_model:
                # Create posterior predictive variables based on the model type
                self.model.define_posterior_predictive_vars(n_samples)

                # Sample from posterior predictive distribution
                self.posterior_predictive_trace = pm.sample_posterior_predictive(
                    self.trace,
                    var_names=self.model.get_posterior_predictive_vars(),
                    random_seed=config["sampling_settings"]["seed"],
                )
            self.logger.info("Posterior predictive sampling completed successfully")
        except Exception as e:
            self.logger.error(f"Error during posterior predictive sampling: {str(e)}")
            raise ModelFittingError(f"Posterior predictive sampling failed: {e}")

    def _convergence_diagnostics(self) -> bool:
        """Get convergence diagnostics for the model.

        This method calculates and reports various convergence diagnostics
        for the MCMC sampling: divergent transitions, max treed depth, R-hat, and effective sample size.

        Returns:
            Boolean flag indicating whether all convergence diagnostics pass
        """
        if self.config is None:
            raise ModelFittingError("Configuration not loaded")
        if self.trace is None:
            raise ModelFittingError("No trace available for diagnostics")

        # Cast to proper types for ConvergenceDiagnostics
        config_dict: ConfigDict = self.config
        logger_type: LoggerType = self.logger

        convergence_result = ConvergenceDiagnostics(config_dict, logger=logger_type).has_passed_convergence_checks(
            self.trace
        )

        # Log additional details about failed checks if any
        if not convergence_result.passed:
            self.logger.warning(f"Convergence issues in: {', '.join(convergence_result.failed_checks)}")

        return convergence_result.passed

    def calibrate(self, target_data: pd.DataFrame, **kwargs: Any) -> Any:
        """Calibrate observational estimates using the fitted model.

        This method provides a high-level interface for calibrating unpaired observational
        data using the bias corrections learned from the fitted model. It wraps the
        PyMC sampling functionality and returns results in a convenient format.

        Parameters
        ----------
        target_data : pd.DataFrame
            DataFrame with observational data to calibrate.
            Required columns: 'obs_model_est', 'obs_model_est_se'
            For scale-aware models, also requires: 'experiment_scale', 'experiment_scale_se'
        **kwargs : dict
            Additional calibration parameters:
            - chains (int): Number of MCMC chains (default: from config)
            - draws (int): Number of MCMC draws per chain (default: from config)
            - tune (int): Number of tuning steps (default: from config)
            - cores (int): Number of cores to use (default: from config)
            - seed (int): Random seed for reproducibility (default: from config)

        Returns
        -------
        CalibrationResults
            Object with convenient access methods:
            - .values: Calibrated point estimates (numpy array)
            - .uncertainties: Calibrated standard errors (numpy array)
            - .hdi_lower/.hdi_upper: HDI bounds (numpy arrays)
            - .summary: ArviZ summary DataFrame
            - .trace: Raw calibration trace
            - .to_dataframe(): Convert to DataFrame with all results

        Raises
        ------
        ModelNotFittedError
            If called before model fitting
        DataValidationError
            If target_data lacks required columns
        CalibrationError
            If calibration fails

        Examples
        --------
        >>> # Fit standard model
        >>> model = BbamAnalyzer(model_type="standard")
        >>> model.fit(paired_data)
        >>>
        >>> # Calibrate unpaired data
        >>> calibrated_results = model.calibrate(df_unpaired)
        >>>
        >>> # Access calibrated estimates
        >>> calibrated_values = calibrated_results.values
        >>> calibrated_uncertainties = calibrated_results.uncertainties
        """
        if not self._fitted:
            raise ModelNotFittedError("Model must be fitted before calibration")

        if self.model_type == "rct_only":
            raise CalibrationError("Calibration not supported for RCT-only model")

        try:
            # Validate target data
            required_cols = ["obs_model_est", "obs_model_est_se"]

            # For scale-aware models, additional columns are required
            if self.model_type == "scaled":
                required_cols.extend(["experiment_scale", "experiment_scale_se"])

            missing_cols = [col for col in required_cols if col not in target_data.columns]
            if missing_cols:
                raise DataValidationError(f"Missing required columns for calibration: {missing_cols}")

            # Check for missing values
            for col in required_cols:
                if target_data[col].isnull().any():
                    raise DataValidationError(f"Missing values found in required column: {col}")

            # Check that standard error columns are positive
            se_columns = [col for col in required_cols if col.endswith("_se")]
            for col in se_columns:
                if (target_data[col] <= 0).any():
                    raise DataValidationError(f"Standard error column {col} must be positive")

            self.logger.info(f"Starting calibration for {len(target_data)} unpaired observations")

            # Get sampling parameters from config or kwargs
            if self.config is None:
                raise CalibrationError("Configuration not available")

            sampling_settings = self.config.get("sampling_settings", {})
            chains = kwargs.get("chains", sampling_settings.get("chains", 4))
            draws = kwargs.get("draws", sampling_settings.get("draws", 1000))
            tune = kwargs.get("tune", sampling_settings.get("tune", 1000))
            cores = kwargs.get("cores", sampling_settings.get("cores", 4))
            seed = kwargs.get("seed", sampling_settings.get("seed", None))
            target_accept = kwargs.get("target_accept", sampling_settings.get("target_accept", 0.8))
            maxdepth = kwargs.get("maxdepth", sampling_settings.get("maxdepth", 10))

            # Build calibration model using the underlying model's method
            if self.model is None or self.trace is None:
                raise CalibrationError("Model or trace not available")

            calibration_model = self.model.build_calibration_model(target_data, self.trace)

            # Sample from calibration model
            self.logger.info("Running MCMC sampling for calibration...")
            sampling_params = {
                "chains": chains,
                "tune": tune,
                "draws": draws,
                "cores": cores,
                "target_accept": target_accept,
                "nuts_sampler": "nutpie",
                "nuts_sampler_kwargs": {"maxdepth": maxdepth},
            }

            if seed is not None:
                sampling_params["random_seed"] = seed

            with calibration_model:
                calibration_trace = pm.sample(**sampling_params)

            self.logger.info("Calibration sampling completed successfully")

            # Get calibrated estimates summary using ArviZ
            import arviz as az

            calibrated_summary = az.summary(calibration_trace, var_names=["calibrated_estimates"])

            # Extract calibrated means
            calibrated_means = calibrated_summary["mean"].values

            # Use HDI intervals if available, otherwise fall back to CI
            if "hdi_5%" in calibrated_summary.columns and "hdi_95%" in calibrated_summary.columns:
                hdi_lower = calibrated_summary["hdi_5%"].values
                hdi_upper = calibrated_summary["hdi_95%"].values
                uncertainties = calibrated_summary["sd"].values
            else:
                # Fallback to standard deviations
                uncertainties = calibrated_summary["sd"].values
                hdi_lower = calibrated_means - 1.645 * uncertainties  # 90% CI approximation
                hdi_upper = calibrated_means + 1.645 * uncertainties

            # Create and return results object
            calibration_results = CalibrationResults(
                means=calibrated_means,
                uncertainties=uncertainties,
                hdi_lower=hdi_lower,
                hdi_upper=hdi_upper,
                summary=calibrated_summary,
                trace=calibration_trace,
                original_data=target_data,
            )

            self.logger.info(f"Calibration completed successfully for {len(target_data)} observations")
            return calibration_results

        except Exception as e:
            if isinstance(e, (ModelNotFittedError, DataValidationError, CalibrationError)):
                raise
            else:
                raise CalibrationError(f"Calibration failed: {e}")

    def get_results(
        self,
        format: str = "dataframe",
        round_to: Optional[int] = 6,
        interval_type: Optional[str] = IntervalType.HDI.value,
        prob_interval: Optional[float] = 0.9,
        full_output: bool = False,
    ) -> Union[pd.DataFrame, Dict[str, Any], str]:
        """Get model results.

        Parameters
        ----------
        format : str, optional
            Output format ('dataframe', 'dict', 'json')

        Returns
        -------
        Union[pd.DataFrame, dict, str]
            Model results in the specified format.
            The results include:
            - Model parameters
            - Convergence metrics
            - Average true effect (posterior)
            - Expected model bias
            - Expected observational value
            - HDI bounds (5% and 95%)
            - Standard errors

        Raises
        ------
        ModelNotFittedError
            If called before model fitting
        ValueError
            If format is not one of the supported options
        """
        if not self._fitted:
            raise ModelNotFittedError("Model must be fitted before accessing results")

        valid_formats = ["dataframe", "dict", "json"]
        if format not in valid_formats:
            raise ValueError(f"Invalid format: {format}. Must be one of {valid_formats}")

        try:
            # Use configured values if parameters are None
            if self.config is None:
                raise BbamError("Configuration not loaded")
            results_settings = self.config.get("results_settings", {})

            if round_to is None:
                round_to = results_settings.get("round_to", 6)
            if interval_type is None:
                interval_type = results_settings.get("interval_type", IntervalType.HDI.value)
            if prob_interval is None:
                prob_interval = results_settings.get("prob_interval", 0.9)

            # Generate summary table using existing logic
            summary_df = self._get_summary_table(
                round_to=round_to,
                interval_type=interval_type,
                prob_interval=prob_interval,
                full_output=full_output,
            )

            if format == "dataframe":
                return summary_df
            elif format == "dict":
                return summary_df.to_dict("index")
            elif format == "json":
                return summary_df.to_json(orient="index", indent=2)

            # This should never be reached due to validation above, but is added for type consistency
            return summary_df

        except Exception as e:
            raise BbamError(f"Failed to get results: {e}")

    def _get_summary_table(
        self,
        vars_to_summarize: Optional[List[str]] = None,
        round_to: int = 6,
        interval_type: str = IntervalType.HDI.value,
        prob_interval: float = 0.95,
        full_output: bool = False,
    ) -> pd.DataFrame:
        """Get summary table for the model (internal method).

        This method delegates to ResultsProcessor for proper separation of concerns.
        """
        from .core.results_processor import ResultsProcessor

        # Initialize ResultsProcessor
        results_processor = ResultsProcessor(logger=self.logger)

        # Prepare model metadata
        if self.model is None:
            raise BbamError("Model not initialized")
        model_vars_metadata = {
            "vars_table_full": self.model.vars_table_full,
            "vars_table_short": self.model.vars_table_short,
            "vars_display_names": self.model.vars_display_names,
            "posterior_predictive_vars": self.model.get_posterior_predictive_vars(),
        }

        summary_df = results_processor.generate_summary_table(
            trace=self.trace,
            posterior_predictive_trace=self.posterior_predictive_trace,
            model_vars_metadata=model_vars_metadata,
            vars_to_summarize=vars_to_summarize,
            round_to=round_to,
            interval_type=interval_type,
            prob_interval=prob_interval,
            full_output=full_output,
        )

        return summary_df

    def get_samples(self, parameter: Optional[str] = None) -> Union[Dict[str, np.ndarray], np.ndarray]:
        """Get raw posterior samples from the model.

        Parameters
        ----------
        parameter : str, optional
            Specific parameter to retrieve samples for.
            If None, returns samples for all parameters.

        Returns
        -------
        dict or numpy.ndarray
            Dictionary of parameter samples or array for a specific parameter

        Raises
        ------
        ModelNotFittedError
            If called before model fitting
        ValueError
            If parameter name is invalid
        """
        if not self._fitted:
            raise ModelNotFittedError("Model must be fitted before accessing samples")

        try:
            if self.trace is None:
                raise ModelNotFittedError("No trace available")
            if parameter is None:
                # Return all samples
                samples = {}
                for var_name in self.trace.posterior.data_vars:
                    samples[var_name] = self.trace.posterior[var_name].values
                return samples
            else:
                # Return specific parameter
                if parameter not in self.trace.posterior.data_vars:
                    raise ValueError(f"Parameter '{parameter}' not found in model results")
                return np.array(self.trace.posterior[parameter].values)

        except Exception as e:
            if isinstance(e, (ModelNotFittedError, ValueError)):
                raise
            else:
                raise BbamError(f"Failed to get samples: {e}")

    def plot(self, plot_type: str, **kwargs: Any) -> Union[Any, str]:
        """Generate plots from model results.

        Parameters
        ----------
        plot_type : str
            Type of plot to generate. Options:
            - 'bias': Distribution of bias parameters
            - 'true_effect': Distribution of true effect
            - 'calibration': Comparison of pre/post calibration
            - 'diagnostics': Convergence diagnostics
            - 'scatter': Scatter plot of RCT vs observational
        **kwargs : dict
            Additional plotting parameters:
            - output_path (str): Path to save the plot
            - format (str): File format ('png', 'pdf', 'svg')
            - figsize (tuple): Figure size as (width, height)
            - dpi (int): Resolution for raster formats

        Returns
        -------
        matplotlib.Figure or str
            Plot object (if output_path is None) or path to saved file

        Raises
        ------
        ModelNotFittedError
            If called before model fitting
        ValueError
            If plot_type is not supported
        """
        if not self._fitted:
            raise ModelNotFittedError("Model must be fitted before plotting")

        # TODO: Implement plotting functionality in Phase 3
        raise NotImplementedError("Plotting functionality not yet implemented")

    def save(self, path: str, include_samples: bool = False) -> Dict[str, str]:
        """Save model results and configuration to disk.

        Parameters
        ----------
        path : str
            Directory path to save results
        include_samples : bool, optional
            Whether to save raw posterior samples (default: False)

        Returns
        -------
        dict
            Dictionary of saved file paths

        Raises
        ------
        ModelNotFittedError
            If called before model fitting
        IOError
            If saving fails
        """
        if not self._fitted:
            raise ModelNotFittedError("Model must be fitted before saving")

        try:
            # Create output directory
            os.makedirs(path, exist_ok=True)
            if self.run_id is None:
                raise IOError("Run ID not set")
            os.makedirs(os.path.join(path, self.run_id), exist_ok=True)

            saved_files = {}

            # Save results summary using configured settings
            if self.config is None:
                raise IOError("Configuration not loaded")
            results_settings = self.config.get("results_settings", {})
            prob_interval = results_settings.get("prob_interval", 0.95)
            round_to = results_settings.get("round_to", 6)
            interval_type = results_settings.get("interval_type", "HDI")

            results_df = self.get_results(
                format="dataframe",
                prob_interval=prob_interval,
                round_to=round_to,
                interval_type=interval_type,
            )
            # Type guard: get_results with format="dataframe" always returns pd.DataFrame
            if not isinstance(results_df, pd.DataFrame):
                raise IOError("Expected DataFrame from get_results")
            results_path = os.path.join(path, self.run_id, "model_results.csv")
            results_df.to_csv(results_path)
            saved_files["results"] = results_path

            # Save configuration
            config_path = os.path.join(path, self.run_id, "config.yaml")
            with open(config_path, "w") as f:
                import yaml

                yaml.dump(self.config, f, default_flow_style=False)
            saved_files["config"] = config_path

            # Save metadata if available
            if self.run_metadata:
                metadata_path = self.run_metadata.save(path)
                saved_files["metadata"] = metadata_path

            # Save samples if requested
            if include_samples:
                samples_dir = os.path.join(path, self.run_id, "samples")
                os.makedirs(samples_dir, exist_ok=True)
                samples = self.get_samples()
                # Type guard: get_samples() with no parameter returns a dict
                if isinstance(samples, dict):
                    for param_name, param_samples in samples.items():
                        sample_path = os.path.join(samples_dir, f"{param_name}.npy")
                        np.save(sample_path, param_samples)
                        saved_files[f"samples_{param_name}"] = sample_path

            return saved_files

        except Exception as e:
            raise IOError(f"Failed to save model: {e}")

    @classmethod
    def load(cls, path: str) -> "BbamAnalyzer":
        """Load a previously saved analyzer.

        Parameters
        ----------
        path : str
            Path to saved analyzer directory or file

        Returns
        -------
        BbamAnalyzer
            Loaded analyzer instance

        Raises
        ------
        FileNotFoundError
            If analyzer file not found
        ValueError
            If file format is invalid
        """
        # TODO: Implement analyzer loading in Phase 3
        raise NotImplementedError("Analyzer loading functionality not yet implemented")

    def get_diagnostics(self) -> Dict[str, Any]:
        """Get model convergence diagnostics.

        Returns
        -------
        dict
            Dictionary of diagnostic metrics including:
            - 'r_hat': Gelman-Rubin statistic
            - 'effective_sample_size': Effective sample size
            - 'divergences': Number of divergent transitions
            - 'energy': E-BFMI values

        Raises
        ------
        ModelNotFittedError
            If called before model fitting
        """
        if not self._fitted:
            raise ModelNotFittedError("Model must be fitted before accessing diagnostics")

        # TODO: Implement proper diagnostics in Phase 2
        # For now, return basic diagnostics
        try:
            import arviz as az

            if self.trace is None:
                raise ModelNotFittedError("No trace available")

            diagnostics = {
                "r_hat": az.rhat(self.trace).to_dict(),
                "effective_sample_size": az.ess(self.trace).to_dict(),
                "divergences": (
                    self.trace.sample_stats.diverging.sum().item() if hasattr(self.trace, "sample_stats") else 0
                ),
                "energy": {},
            }
        except Exception:
            # Fallback diagnostics
            diagnostics = {
                "r_hat": {"status": "not_calculated"},
                "effective_sample_size": {"status": "not_calculated"},
                "divergences": 0,
                "energy": {},
            }

        return diagnostics

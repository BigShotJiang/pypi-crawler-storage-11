"""
Type definitions and protocols for BBAM package.

This module defines common type protocols and interfaces used throughout
the BBAM codebase to improve type safety and reduce the need for type ignores.
"""

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Protocol, runtime_checkable


@runtime_checkable
class InferenceDataProtocol(Protocol):
    """Protocol for ArviZ InferenceData objects."""

    sample_stats: Any
    posterior: Any


@runtime_checkable
class ConfigProtocol(Protocol):
    """Protocol for BBAM configuration dictionaries."""

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value with optional default."""
        ...

    def __getitem__(self, key: str) -> Any:
        """Get configuration value by key."""
        ...

    def __contains__(self, key: str) -> bool:
        """Check if key exists in configuration."""
        ...


@runtime_checkable
class TraceProtocol(Protocol):
    """Protocol for PyMC trace objects."""

    sample_stats: Any
    posterior: Any

    def __len__(self) -> int:
        """Return length of trace."""
        ...


@dataclass
class ConvergenceResult:
    """
    Structured result from convergence diagnostics.

    Attributes:
        passed: Whether all convergence checks passed overall
        failed_checks: List of specific diagnostic methods that failed
        results: Dictionary mapping each diagnostic method to its boolean result
    """

    passed: bool
    failed_checks: List[str]
    results: Dict[str, bool]


# Type aliases for common types
ConfigDict = Dict[str, Any]
ThresholdDict = Dict[str, float]
LoggerType = logging.Logger

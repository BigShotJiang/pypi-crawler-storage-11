"""
Scale Model - Hierarchical Bayesian model for RCT + Observational meta-analysis with experiment scale.

This module provides the RCTScaledHBM class for meta-analysis that validates
observational measurement models against RCT evidence, incorporating experiment scale metrics.
"""

from __future__ import annotations

from typing import Any, Dict, List

import pandas as pd
import pymc as pm
import pytensor.tensor as pt

from ..utils.enums import BiasSpecification, LikelihoodDistribution, PriorSpecifications
from .base_model import Model

# Constants for numerical stability
EPSILON_DIVISION = 1e-10  # Small constant to prevent division by near-zero values


class RCTScaledHBM(Model):
    """Builder for hierarchical Bayesian meta-analysis models that validate
    observational measurement models against RCT evidence with experiment scale.

    This class implements a meta-analysis of randomized controlled trials (RCTs)
    and observational model measurements, incorporating experiment scale metrics
    (such as impressions, spend, or number of observations). It estimates the overall
    treatment effect, between-study heterogeneity, observational model's bias, and
    the relationship between treatment effects and experiment scale.
    """

    def get_required_data_columns(self) -> List[str]:
        """Define required columns

        Returns
        -------
        List[str]
            List of required column names
        """
        return [
            "experiment_est",
            "experiment_est_se",
            "obs_model_est",
            "obs_model_est_se",
            "experiment_scale",
            "experiment_scale_se",
        ]

    def _prepare_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and prepare the model configuration.

        Validates the configuration and sets default values where needed.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration dictionary containing model settings and specifications

        Returns
        -------
        Dict[str, Any]
            Validated and prepared configuration dictionary

        Raises
        ------
        ValueError
            If the provided configuration is invalid
        """
        if config is None:
            raise ValueError("Configuration cannot be None")

        # Ensure model_settings section exists
        if "model_settings" not in config:
            raise ValueError("Missing required section: model_settings")

        # Validate bias_spec if present
        if "bias_spec" not in config["model_settings"]:
            raise ValueError("Missing required parameter: bias_spec in model_settings section")

        # Validate bias_spec value
        if config["model_settings"]["bias_spec"] not in BiasSpecification.values():
            raise ValueError(
                f"Invalid bias_spec value: {config['model_settings']['bias_spec']}. "
                f"Must be one of {BiasSpecification.values()}"
            )

        # Add likelihood_distribution if missing
        if "likelihood_distribution" not in config["model_settings"]:
            config["model_settings"]["likelihood_distribution"] = LikelihoodDistribution.NORMAL.value

        # Validate likelihood_distribution value
        if config["model_settings"]["likelihood_distribution"] not in LikelihoodDistribution.values():
            raise ValueError(
                f"Invalid likelihood_distribution value: "
                f"{config['model_settings']['likelihood_distribution']}. "
                f"Must be one of {LikelihoodDistribution.values()}"
            )

        # Add skip_model_posterior_metrics if missing (default: False)
        if "skip_model_posterior_metrics" not in config["model_settings"]:
            config["model_settings"]["skip_model_posterior_metrics"] = False

        # Validate skip_model_posterior_metrics value
        if not isinstance(config["model_settings"]["skip_model_posterior_metrics"], bool):
            raise ValueError(
                f"Invalid skip_model_posterior_metrics value: "
                f"{config['model_settings']['skip_model_posterior_metrics']}. "
                f"Must be a boolean (True or False)"
            )

        # If likelihood_distribution is student's t, the config must provide the degree of freedoms parameter student_df
        if config["model_settings"]["likelihood_distribution"] == LikelihoodDistribution.STUDENT_T.value:
            if "student_df" not in config["model_settings"]:
                raise ValueError(
                    "If likelihood_distribution is student's t, the config must provide "
                    "the degree of freedoms parameter student_df"
                )
            else:
                # validate the student_df is a positive number
                if (
                    not isinstance(config["model_settings"]["student_df"], (int, float))
                    or config["model_settings"]["student_df"] <= 0
                ):
                    raise ValueError("student_df must be a positive number")

        # Validate data_driven_priors_settings only if data_driven_priors is True
        if config["data_driven_priors"]:
            # Ensure data_driven_priors_settings section exists
            if "data_driven_priors_settings" not in config:
                raise ValueError(
                    "'data_driven_priors_settings' section must be provided in configuration, "
                    "if data_drive_priors is True"
                )

            # Validate prior settings for treatment effect intensity (ATI)
            if "treatment_effect_intensity" not in config["data_driven_priors_settings"]:
                raise ValueError(
                    "'treatment_effect_intensity' section must be provided in 'data_driven_priors_settings' "
                    "of the configuration, if data_drive_priors is True"
                )
            else:
                ati_settings = config["data_driven_priors_settings"]["treatment_effect_intensity"]

            if "scale_prior_width_mean" not in ati_settings:
                raise ValueError(
                    "scale_prior_width_mean parameter must be provided in the 'treatment_effect_intensity' "
                    "of 'data_driven_priors_settings' in the configuration"
                )
            if "scale_prior_width_sigma" not in ati_settings:
                raise ValueError(
                    "scale_prior_width_sigma parameter must be provided in the 'treatment_effect_intensity' "
                    "of 'data_driven_priors_settings' in the configuration"
                )

            # Validate prior settings for experiment scale
            if "experiment_scale" not in config["data_driven_priors_settings"]:
                raise ValueError(
                    "'experiment_scale' section must be provided in 'data_driven_priors_settings' "
                    "of the configuration, if data_drive_priors is True"
                )
            else:
                scale_settings = config["data_driven_priors_settings"]["experiment_scale"]

            if "scale_prior_width_mean" not in scale_settings:
                raise ValueError(
                    "scale_prior_width_mean parameter must be provided in the 'experiment_scale' "
                    "of 'data_driven_priors_settings' in the configuration"
                )
            if "scale_prior_width_sigma" not in scale_settings:
                raise ValueError(
                    "scale_prior_width_sigma parameter must be provided in the 'experiment_scale' "
                    "of 'data_driven_priors_settings' in the configuration"
                )

            # Validate prior settings for bias intercept
            if "bias_intercept" not in config["data_driven_priors_settings"]:
                raise ValueError(
                    "'bias_intercept' section must be provided in 'data_driven_priors_settings' "
                    "of the configuration, if data_drive_priors is True"
                )
            else:
                bias_int_settings = config["data_driven_priors_settings"]["bias_intercept"]

            if "scale_prior_width_mean" not in bias_int_settings:
                raise ValueError(
                    "scale_prior_width_mean parameter must be provided in the 'bias_intercept' "
                    "of 'data_driven_priors_settings' in the configuration"
                )
            if "scale_prior_width_sigma" not in bias_int_settings:
                raise ValueError(
                    "scale_prior_width_sigma parameter must be provided in the 'bias_intercept' "
                    "of 'data_driven_priors_settings' in the configuration"
                )

            # Validate prior settings for bias multiplier
            if "bias_multiplier" not in config["data_driven_priors_settings"]:
                raise ValueError(
                    "'bias_multiplier' section must be provided in 'data_driven_priors_settings' "
                    "of the configuration, if data_drive_priors is True"
                )
            else:
                bias_mult_settings = config["data_driven_priors_settings"]["bias_multiplier"]

            if "center_prior_mean" not in bias_mult_settings:
                raise ValueError(
                    "center_prior_mean parameter must be provided in the 'bias_multiplier' "
                    "of 'data_driven_priors_settings' in the configuration"
                )
            if "prior_width_mean" not in bias_mult_settings:
                raise ValueError(
                    "prior_width_mean parameter must be provided in the 'bias_multiplier' "
                    "of 'data_driven_priors_settings' in the configuration"
                )
            if "prior_width_sigma" not in bias_mult_settings:
                raise ValueError(
                    "prior_width_sigma parameter must be provided in the 'bias_multiplier' "
                    "of 'data_driven_priors_settings' in the configuration"
                )

        return config

    def _get_data_driven_priors(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Calculate data-driven priors based on input data.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing experiment data used to calculate priors

        Returns
        -------
        Dict[str, Any]
            Dictionary containing data-driven prior specifications
        """
        # Calculate treatment effect intensity (TTI) metrics
        # Add epsilon to prevent division by near-zero values
        tti = data["experiment_est"] / (data["experiment_scale"] + EPSILON_DIVISION)

        # Compute summary statistics
        median_scale = data["experiment_scale"].median()
        sigma_scale = data["experiment_scale"].std()

        sigma_tte = data["experiment_est"].std()
        mean_tti = tti.median()
        sigma_tti = tti.std()

        # Get prior settings from config
        data_driven_priors_settings = self.config["data_driven_priors_settings"]

        # Get settings for priors on treatment effect intensity
        ati_settings = data_driven_priors_settings["treatment_effect_intensity"]
        ati_scale_mean = ati_settings["scale_prior_width_mean"]
        ati_scale_sigma = ati_settings["scale_prior_width_sigma"]

        # Get settings for priors on experiment scale
        scale_settings = data_driven_priors_settings["experiment_scale"]
        scale_scale_mean = scale_settings["scale_prior_width_mean"]
        scale_scale_sigma = scale_settings["scale_prior_width_sigma"]

        # Get settings for priors on bias intercept
        bias_int_settings = data_driven_priors_settings["bias_intercept"]
        bias_int_scale_mean = bias_int_settings["scale_prior_width_mean"]
        bias_int_scale_sigma = bias_int_settings["scale_prior_width_sigma"]

        # Get settings for priors on bias multiplier
        bias_mult_settings = data_driven_priors_settings["bias_multiplier"]
        delta_beta_1 = bias_mult_settings["center_prior_mean"]
        gamma_beta_1 = bias_mult_settings["prior_width_mean"]
        zeta_beta_1 = bias_mult_settings["prior_width_sigma"]

        # Specify priors
        priors = {
            # mean of treatment effect intensity distribution
            "mu_ati": {
                "delta_mu_ati": mean_tti,
                "gamma_mu_ati": ati_scale_mean * sigma_tti,
            },
            # std. dev. of treatment effect intensity distribution
            "sigma_ati": {"zeta_sigma_ati": ati_scale_sigma * sigma_tti},
            # treatment effect total effect std dev (now learnable LogNormal)
            "sigma_tau": {
                "eta_sigma_tau": sigma_tte,
                "zeta_sigma_tau": 0.5 * sigma_tte,
            },
            # mean of experiment scale distribution
            "mu_scale": {
                "delta_mu_scale": median_scale * 0.5,
                "gamma_mu_scale": sigma_scale * scale_scale_mean,
            },
            # std. dev. of experiment scale distribution
            "sigma_scale": {"zeta_sigma_scale": sigma_scale * scale_scale_sigma},
            # mean of the bias intercept component
            "mu_beta_0": {
                "delta_beta_0": 0.0,  # center prior at zero
                "gamma_beta_0": bias_int_scale_mean * sigma_tte,
            },
            # std. dev. of the bias intercept component
            "sigma_beta_0": {"zeta_beta_0": bias_int_scale_sigma * sigma_tte},
            # mean of the bias multiplier component
            "mu_beta_1": {
                "delta_beta_1": delta_beta_1,
                "gamma_beta_1": gamma_beta_1,
            },
            # std. dev. of the bias multiplier component
            "sigma_beta_1": {"zeta_beta_1": zeta_beta_1},
        }

        return priors

    def _validate_priors(self, priors: Dict[str, Any]) -> bool:
        """Validate that provided priors meet model requirements.

        Parameters
        ----------
        priors : Dict[str, Any]
            Dictionary of prior specifications to validate

        Returns
        -------
        bool
            True if priors are valid

        Raises
        ------
        ValueError
            If required priors are missing
        """
        # Check for scale model priors first, then fallback to standard model priors for backward compatibility
        if "mu_ati" in priors and "sigma_ati" in priors:
            # Use scale model priors from PriorSpecifications
            required_priors = PriorSpecifications.get_required_priors("scaled")
        else:
            # Fallback to standard model priors (backward compatibility)
            # This supports legacy configurations that use mu_tau instead of mu_ati
            required_priors = ["mu_tau", "sigma_tau", "mu_scale", "sigma_scale"] + PriorSpecifications.get_bias_priors()

        missing_priors = [p for p in required_priors if p not in priors]
        if missing_priors:
            raise ValueError(f"Missing required priors for scaled model: {missing_priors}")
        return True

    def _set_variables_metadata(self) -> "RCTScaledHBM":
        """Set up variable names for output tables and plots.

        Returns
        -------
        RCTScaledHBM
            Self reference for method chaining
        """
        # Set variables for trace plots
        self.vars_trace_plot = [
            "mu_tau",
            "mu_ati",
            "sigma_ati",
            "mu_scale",
            "sigma_scale",
            "mu_beta_0",
            "sigma_beta_0",
            "mu_beta_1",
            "sigma_beta_1",
            "mean_bias",
            "mean_obs_model",
            "mean_experiment_scale",
        ]

        # Set variables for full summary tables
        self.vars_table_full = [
            "mu_tau",
            "mean_experiment_scale",
            "mean_bias",
            "mean_obs_model",
            "mu_ati",
            "mu_beta_0",
            "mu_beta_1",
            "std_tau",
            "std_experiment_scale",
            "std_bias",
            "std_obs_model",
            "sigma_ati",
            "sigma_beta_0",
            "sigma_beta_1",
        ]

        # Set variables for short summary tables (default)
        self.vars_table_short = [
            "mu_tau",
            "mean_bias",
            "mean_obs_model",
            "mu_ati",
            "mean_experiment_scale",
            "mu_beta_0",
            "mu_beta_1",
        ]

        # Set display names for variables
        self.vars_display_names = {
            "mu_tau": "Avg. treatment effect",
            "mean_experiment_scale": "Avg. experiment scale",
            "mean_bias": "Average model bias across observations",
            "mean_obs_model": "Average observational model estimate across observations",
            "mu_ati": "Avg. treatment effect intensity",
            "mu_beta_0": "Mean of bias intercept component",
            "mu_beta_1": "Mean of bias multiplier component",
            "std_tau": "Std. dev. of treatment effect",
            "std_experiment_scale": "Std. dev. of experiment scale",
            "std_bias": "Model bias std. dev. across observations",
            "std_obs_model": "Obs. model std. dev. across observations",
            "sigma_ati": "Std. dev. of treatment effect intensity",
            "sigma_beta_0": "Std. dev. of bias intercept component",
            "sigma_beta_1": "Std. dev. of bias multiplier component",
        }

        # Add posterior predictive variables if enabled
        if self.config["sampling_settings"]["n_sample_posterior"] > 0:
            posterior_vars = self.get_posterior_predictive_vars()
            self.vars_table_full.extend(posterior_vars)
            self.vars_display_names.update(
                {
                    "mean_ati_tilde": "Avg. treatment effect intensity (posterior predictive)",
                    "ati_tilde": "Treatment effect intensity in individual measurement",
                    "std_ati_tilde": "Std. dev. of treatment effect intensity (posterior predictive)",
                    "mean_tau_tilde": "Avg. treatment effect (posterior predictive)",
                    "bias_tilde": "Bias in individual measurement",
                    "mean_bias_tilde": "Expected model bias (posterior predictive)",
                    "obs_model_est_tilde": "Observational model estimate in individual measurement",
                    "mean_obs_model_est_tilde": "Expected observational model estimate (posterior predictive)",
                    "scale_tilde": "Experiment scale in individual measurement",
                    "mean_scale_tilde": "Avg. experiment scale (posterior predictive)",
                    "std_tau_tilde": "Std. dev. of treatment effect (posterior predictive)",
                    "std_bias_tilde": "Model bias std. dev. (posterior predictive)",
                    "std_obs_model_est_tilde": "Obs. model std. dev. (posterior predictive)",
                    "std_scale_tilde": "Std. dev. of experiment scale (posterior predictive)",
                }
            )

        return self

    def get_posterior_predictive_vars(self) -> List[str]:
        """Get the names of variables to include in posterior predictive sampling.

        Returns
        -------
        List[str]
            List of variable names for posterior predictive sampling
        """
        return [
            "mean_ati_tilde",
            "ati_tilde",
            "mean_scale_tilde",
            "scale_tilde",
            "mean_tau_tilde",
            "tau_tilde",
            "mean_bias_tilde",
            "bias_tilde",
            "mean_obs_model_est_tilde",
            "obs_model_est_tilde",
            "std_ati_tilde",
            "std_scale_tilde",
            "std_tau_tilde",
            "std_bias_tilde",
            "std_obs_model_est_tilde",
        ]

    def define_posterior_predictive_vars(self, n_samples: int) -> None:
        """Create posterior predictive variables in the PyMC model.

        Parameters
        ----------
        n_samples : int
            Number of posterior predictive samples to generate
        """
        # Get the parameters from the model
        params = {}
        params["mu_ati"] = self.pymc_model.mu_ati
        params["sigma_ati"] = self.pymc_model.sigma_ati
        params["mu_scale"] = self.pymc_model.mu_scale
        params["sigma_scale"] = self.pymc_model.sigma_scale

        # Treatment effect intensity in individual measurement (posterior predictive)
        z_ati_tilde = pm.Normal("z_ati_tilde", mu=0, sigma=1, shape=n_samples)
        ati_tilde = pm.Deterministic("ati_tilde", params["mu_ati"] + z_ati_tilde * params["sigma_ati"])
        pm.Deterministic("mean_ati_tilde", pm.math.mean(ati_tilde))

        # Experiment scale in individual measurement (posterior predictive)
        scale_tilde = pm.LogNormal(
            "scale_tilde",
            mu=params["mu_scale"],
            sigma=params["sigma_scale"],
            shape=n_samples,
        )
        pm.Deterministic("mean_scale_tilde", pm.math.mean(scale_tilde))

        # Total treatment effect (intensity * scale)
        tau_tilde = pm.Deterministic("tau_tilde", ati_tilde * scale_tilde)
        pm.Deterministic("mean_tau_tilde", pm.math.mean(tau_tilde))

        # Bias components based on bias specification
        bias_spec = self.config["model_settings"]["bias_spec"]
        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_INT.value]:
            params["mu_beta_0"] = self.pymc_model.mu_beta_0
            params["sigma_beta_0"] = self.pymc_model.sigma_beta_0
            # bias intercept component (posterior predictive)
            z_beta_0_tilde = pm.Normal("z_beta_0_tilde", mu=0, sigma=1, shape=n_samples)
            beta_0_tilde = pm.Deterministic(
                "beta_0_tilde", params["mu_beta_0"] + z_beta_0_tilde * params["sigma_beta_0"]
            )

        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_MULT.value]:
            params["mu_beta_1"] = self.pymc_model.mu_beta_1
            params["sigma_beta_1"] = self.pymc_model.sigma_beta_1
            # bias multiplier component (posterior predictive)
            z_beta_1_tilde = pm.Normal("z_beta_1_tilde", mu=0, sigma=1, shape=n_samples)
            beta_1_tilde = pm.Deterministic(
                "beta_1_tilde", params["mu_beta_1"] + z_beta_1_tilde * params["sigma_beta_1"]
            )

        # Bias in individual measurement (posterior predictive)
        if bias_spec == BiasSpecification.BOTH_INT_MULT.value:
            bias_tilde = pm.Deterministic("bias_tilde", beta_0_tilde + beta_1_tilde * tau_tilde)
        elif bias_spec == BiasSpecification.ONLY_INT.value:
            bias_tilde = pm.Deterministic("bias_tilde", beta_0_tilde)
        elif bias_spec == BiasSpecification.ONLY_MULT.value:
            bias_tilde = pm.Deterministic("bias_tilde", beta_1_tilde * tau_tilde)

        # Average bias across posterior predictive samples
        pm.Deterministic("mean_bias_tilde", pm.math.mean(bias_tilde))

        # Obs model individual estimates (posterior predictive)
        obs_model_est_tilde = pm.Deterministic("obs_model_est_tilde", tau_tilde + bias_tilde)
        # Expected obs. model estimate across posterior predictive samples
        pm.Deterministic("mean_obs_model_est_tilde", pm.math.mean(obs_model_est_tilde))

        # Std. dev. of treatment effect, scale, bias, and obs. model estimate, across posterior predictive samples
        pm.Deterministic("std_ati_tilde", pt.std(ati_tilde))
        pm.Deterministic("std_scale_tilde", pt.std(scale_tilde))
        pm.Deterministic("std_tau_tilde", pt.std(tau_tilde))
        pm.Deterministic("std_bias_tilde", pt.std(bias_tilde))
        pm.Deterministic("std_obs_model_est_tilde", pt.std(obs_model_est_tilde))

    def _define_data(self, data: pd.DataFrame, model: Any) -> Dict[str, Any]:
        """Set up data variables in the PyMC model.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing data
        model : pm.Model
            PyMC model to add data variables to

        Returns
        -------
        Dict[str, Any]
            Dictionary containing data variables and number of observations
        """
        data_vars = {}

        # Number of observations
        data_vars["n_obs"] = len(data)

        # Experiment (RCT) data
        data_vars["experiment_est"] = pm.Data("experiment_est", data["experiment_est"].values)
        data_vars["experiment_est_se"] = pm.Data("experiment_est_se", data["experiment_est_se"].values)

        # Observational model data
        data_vars["obs_model_est"] = pm.Data("obs_model_est", data["obs_model_est"].values)
        data_vars["obs_model_est_se"] = pm.Data("obs_model_est_se", data["obs_model_est_se"].values)

        # Experiment scale data
        data_vars["experiment_scale"] = pm.Data("experiment_scale", data["experiment_scale"].values)
        data_vars["experiment_scale_se"] = pm.Data("experiment_scale_se", data["experiment_scale_se"].values)

        return data_vars

    def _define_priors_on_params(self) -> Dict[str, Any]:
        """Define prior distributions for the model parameters.

        Returns
        -------
        Dict[str, Any]
            Dictionary containing model parameters
        """
        params = {}

        # Treatment effect intensity parameters
        # Handle both new scale model priors and legacy standard model priors
        if "mu_ati" in self.priors:
            params["mu_ati"] = pm.Normal(
                "mu_ati",
                mu=self.priors["mu_ati"]["delta_mu_ati"],
                sigma=self.priors["mu_ati"]["gamma_mu_ati"],
            )
            params["sigma_ati"] = pm.HalfCauchy("sigma_ati", beta=self.priors["sigma_ati"]["zeta_sigma_ati"])
        else:
            # Fallback to standard model prior names for backward compatibility
            mu_tau_prior = self.priors.get("mu_tau", {})
            params["mu_ati"] = pm.Normal(
                "mu_ati",
                mu=mu_tau_prior.get("delta_mu_tau", 0.0),
                sigma=mu_tau_prior.get("gamma_mu_tau", 1.0),
            )
            sigma_tau_prior = self.priors.get("sigma_tau", {})
            params["sigma_ati"] = pm.HalfCauchy("sigma_ati", beta=sigma_tau_prior.get("zeta_sigma_tau", 1.0))

        # Experiment scale parameters
        params["mu_scale"] = pm.LogNormal(
            "mu_scale",
            mu=self.priors["mu_scale"]["delta_mu_scale"],
            sigma=self.priors["mu_scale"]["gamma_mu_scale"],
        )
        params["sigma_scale"] = pm.HalfCauchy("sigma_scale", beta=self.priors["sigma_scale"]["zeta_sigma_scale"])

        bias_spec = self.config["model_settings"]["bias_spec"]

        # Bias multiplier parameters
        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_MULT.value]:
            params["mu_beta_1"] = pm.Normal(
                "mu_beta_1",
                mu=self.priors["mu_beta_1"]["delta_beta_1"],
                sigma=self.priors["mu_beta_1"]["gamma_beta_1"],
            )
            params["sigma_beta_1"] = pm.HalfCauchy("sigma_beta_1", beta=self.priors["sigma_beta_1"]["zeta_beta_1"])

        # Bias intercept parameters
        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_INT.value]:
            params["mu_beta_0"] = pm.Normal(
                "mu_beta_0",
                mu=self.priors["mu_beta_0"]["delta_beta_0"],
                sigma=self.priors["mu_beta_0"]["gamma_beta_0"],
            )
            params["sigma_beta_0"] = pm.HalfCauchy("sigma_beta_0", beta=self.priors["sigma_beta_0"]["zeta_beta_0"])

        params["sigma_tau"] = pm.LogNormal(
            "sigma_tau",
            mu=self.priors["sigma_tau"]["eta_sigma_tau"],
            sigma=self.priors["sigma_tau"]["zeta_sigma_tau"],
        )

        return params

    def _define_model_structure(self, params: Dict[str, Any], n_obs: int) -> Dict[str, Any]:
        """Define the core model structure including treatment effects and bias.

        Parameters
        ----------
        params : Dict[str, Any]
            Dictionary containing model parameters
        n_obs : int
            Number of observations

        Returns
        -------
        Dict[str, Any]
            Dictionary containing model variables
        """
        model_vars = {}

        # Bias intercept and multiplier
        bias_spec = self.config["model_settings"]["bias_spec"]
        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_INT.value]:
            obs_model_bias_intercept = pm.Normal(
                "obs_model_bias_intercept", mu=params["mu_beta_0"], sigma=params["sigma_beta_0"], shape=n_obs
            )
            model_vars["obs_model_bias_intercept"] = obs_model_bias_intercept
        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_MULT.value]:
            obs_model_bias_multiplier = pm.Normal(
                "obs_model_bias_multiplier", mu=params["mu_beta_1"], sigma=params["sigma_beta_1"], shape=n_obs
            )
            model_vars["obs_model_bias_multiplier"] = obs_model_bias_multiplier

        # True experiment scale
        experiment_true_size = pm.LogNormal(
            "experiment_true_size",
            mu=params["mu_scale"],
            sigma=params["sigma_scale"],
            shape=n_obs,
        )
        model_vars["experiment_true_size"] = experiment_true_size

        # True treatment effect intensity
        experiment_true_ati = pm.Normal(
            "experiment_true_ati", mu=params["mu_ati"], sigma=params["sigma_ati"], shape=n_obs
        )
        model_vars["experiment_true_ati"] = experiment_true_ati

        # True total treatment effect (intensity * scale)
        mu_true_tte = experiment_true_ati * experiment_true_size
        pm.Deterministic("mu_true_pp", mu_true_tte)
        model_vars["mu_true_tte"] = mu_true_tte

        # True treatment effect with additional variance
        tau = pm.Normal("tau", mu=mu_true_tte, sigma=params["sigma_tau"], shape=n_obs)
        model_vars["tau"] = tau

        # Combined bias
        if bias_spec == BiasSpecification.BOTH_INT_MULT.value:
            bias = obs_model_bias_intercept + obs_model_bias_multiplier * mu_true_tte
        elif bias_spec == BiasSpecification.ONLY_MULT.value:
            bias = obs_model_bias_multiplier * mu_true_tte
        elif bias_spec == BiasSpecification.ONLY_INT.value:
            bias = obs_model_bias_intercept
        else:
            raise ValueError(f"Invalid bias specification: {bias_spec}")
        pm.Deterministic("bias_pp", bias)
        model_vars["bias"] = bias

        return model_vars

    def _define_likelihood_for_observables(
        self, model_vars: Dict[str, Any], data_vars: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Define likelihood for observable variables in the model.

        Parameters
        ----------
        model_vars : Dict[str, Any]
            Dictionary containing model variables
        data_vars : Dict[str, Any]
            Dictionary containing data variables

        Returns
        -------
        Dict[str, Any]
            Dictionary containing likelihood variables
        """
        likelihoods = {}
        likelihood_dist = self.config["model_settings"]["likelihood_distribution"]
        student_nu = self.config["model_settings"].get("student_df", 6)

        if likelihood_dist == LikelihoodDistribution.NORMAL.value:
            self.logger.info("Using normal likelihood for RCT, observational model, and scale estimates (default)")

            # Experiment scale likelihood
            likelihoods["experiment_scale_likelihood"] = pm.Normal(
                "experiment_scale_likelihood",
                mu=model_vars["experiment_true_size"],
                sigma=data_vars["experiment_scale_se"],
                observed=data_vars["experiment_scale"],
            )

            # RCT estimate likelihood
            likelihoods["tau_experiment_est_likelihood"] = pm.Normal(
                "tau_experiment_est_likelihood",
                mu=model_vars["tau"],
                sigma=data_vars["experiment_est_se"],
                observed=data_vars["experiment_est"],
            )

            # Observational model estimate likelihood
            likelihoods["tau_obs_model_est_likelihood"] = pm.Normal(
                "tau_obs_model_est_likelihood",
                mu=model_vars["tau"] + model_vars["bias"],
                sigma=data_vars["obs_model_est_se"],
                observed=data_vars["obs_model_est"],
            )

        elif likelihood_dist == LikelihoodDistribution.STUDENT_T.value:
            self.logger.info(
                f"Using student's t likelihood for RCT, observational model, and scale estimates "
                f"with degrees of freedom: {student_nu}"
            )

            # Experiment scale likelihood
            likelihoods["experiment_scale_likelihood"] = pm.StudentT(
                "experiment_scale_likelihood",
                nu=student_nu,
                mu=model_vars["experiment_true_size"],
                sigma=data_vars["experiment_scale_se"],
                observed=data_vars["experiment_scale"],
            )

            # RCT estimate likelihood
            likelihoods["tau_experiment_est_likelihood"] = pm.StudentT(
                "tau_experiment_est_likelihood",
                nu=student_nu,
                mu=model_vars["tau"],
                sigma=data_vars["experiment_est_se"],
                observed=data_vars["experiment_est"],
            )

            # Observational model estimate likelihood
            likelihoods["tau_obs_model_est_likelihood"] = pm.StudentT(
                "tau_obs_model_est_likelihood",
                nu=student_nu,
                mu=model_vars["tau"] + model_vars["bias"],
                sigma=data_vars["obs_model_est_se"],
                observed=data_vars["obs_model_est"],
            )

        return likelihoods

    def _define_posterior_metrics(self, model_vars: Dict[str, Any]) -> Dict[str, Any]:
        """Define posterior metrics for the model.

        These metrics compute conditional averages across observations in the fitted dataset,
        serving as diagnostic tools to compare against posterior predictive expectations.

        Parameters
        ----------
        model_vars : Dict[str, Any]
            Dictionary containing model variables with shape (n_obs,) for bias and experiment effects

        Returns
        -------
        Dict[str, Any]
            Dictionary containing posterior metrics as conditional averages (empty if skipped)
        """
        posterior_metrics: Dict[str, Any] = {}

        # Check if posterior metrics should be skipped (for convergence-sensitive cases)
        if self.config["model_settings"].get("skip_model_posterior_metrics", False):
            self.logger.info("Skipping posterior metrics computation (skip_model_posterior_metrics=True)")
            return posterior_metrics

        self.logger.info("Defining posterior metrics (conditional averages across observations)")

        # Average treatment effect
        posterior_metrics["mu_tau"] = pm.Deterministic("mu_tau", pm.math.mean(model_vars["mu_true_tte"]))

        # Average experiment scale across observations
        posterior_metrics["mean_experiment_scale"] = pm.Deterministic(
            "mean_experiment_scale", pm.math.mean(model_vars["experiment_true_size"])
        )

        # Average model bias across observations in the fitted dataset (conditional on data)
        posterior_metrics["mean_bias"] = pm.Deterministic("mean_bias", pm.math.mean(model_vars["bias"]))

        # Average observational model estimate across observations in the fitted dataset (conditional on data)
        posterior_metrics["mean_obs_model"] = pm.Deterministic(
            "mean_obs_model", pm.math.mean(model_vars["tau"] + model_vars["bias"])
        )

        # Standard deviation of treatment effects
        posterior_metrics["std_tau"] = pm.Deterministic("std_tau", pt.std(model_vars["mu_true_tte"]))

        # Standard deviation of experiment scale across observations
        posterior_metrics["std_experiment_scale"] = pm.Deterministic(
            "std_experiment_scale", pt.std(model_vars["experiment_true_size"])
        )

        # Standard deviation of model bias
        posterior_metrics["std_bias"] = pm.Deterministic("std_bias", pt.std(model_vars["bias"]))

        # Standard deviation of observational model estimate across observations
        posterior_metrics["std_obs_model"] = pm.Deterministic(
            "std_obs_model", pt.std(model_vars["tau"] + model_vars["bias"])
        )

        return posterior_metrics

    def _extract_posterior_values(self, trace: Any, param_name: str) -> Any:
        """Extract posterior values from trace, handling different trace formats.

        Parameters
        ----------
        trace : Any
            Posterior trace containing samples
        param_name : str
            Name of the parameter to extract

        Returns
        -------
        Any
            Flattened posterior samples
        """
        posterior = trace.posterior[param_name]
        if hasattr(posterior, "values"):
            return posterior.values.flatten()
        else:
            return posterior.flatten()

    def _check_posterior_normality(self, trace: Any, param_name: str) -> bool:
        """Check if a posterior distribution is approximately normal.

        Parameters
        ----------
        trace : Any
            Posterior trace containing samples
        param_name : str
            Name of the parameter to check

        Returns
        -------
        bool
            True if posterior appears normal, False otherwise
        """
        try:
            # Extract posterior samples using consistent defensive pattern
            samples = self._extract_posterior_values(trace, param_name)

            # Check for multi-modality or skewness
            from scipy import stats

            skewness = stats.skew(samples)
            kurtosis = stats.kurtosis(samples)

            if abs(skewness) > 0.5 or abs(kurtosis) > 0.5:
                self.logger.warning(
                    f"Posterior for {param_name} may be non-normal (skew={skewness:.2f}, kurt={kurtosis:.2f}). "
                    f"Consider using median or mode instead of mean for calibration."
                )
                return False
            return True
        except Exception as e:
            self.logger.warning(f"Could not check normality for {param_name}: {e}")
            return True  # Default to assuming normal if check fails

    def build(self, data: pd.DataFrame) -> "RCTScaledHBM":
        """Build PyMC model for meta-analysis validating observational model estimates against RCT evidence with scale.

        This model extends the standard HBM by incorporating experiment scale metrics and modeling
        treatment effects as the product of treatment intensity and experiment scale.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing RCT and observational model estimates with standard errors and scale metrics

        Returns
        -------
        RCTScaledHBM
            Self reference for method chaining
        """
        # Check if config is properly set before using it
        if self.config is None or not self.config or "model_settings" not in self.config:
            raise ValueError("Configuration must be provided to build the model")

        # Check if priors are properly set
        if self.priors is None or not self.priors:
            raise ValueError("Priors must be set before building the model")

        with pm.Model() as pymc_model:
            # Set up data variables
            data_vars = self._define_data(data, pymc_model)

            # Define prior distributions
            params = self._define_priors_on_params()

            # Define model structure (treatment effects and bias)
            model_vars = self._define_model_structure(params, data_vars["n_obs"])

            # Define observable variables (likelihoods)
            _ = self._define_likelihood_for_observables(model_vars, data_vars)

            self._define_posterior_metrics(model_vars)

        self._set_variables_metadata()  # specify the list of variables for output tables and plots
        self.pymc_model = pymc_model
        self.logger.info(f"{self.__class__.__name__} model built successfully")
        return self

    def build_calibration_model(self, df_unpaired: pd.DataFrame, trace: Any) -> Any:
        """Build a calibration model for unpaired observational data using fitted model parameters.

        This method creates a new PyMC model that uses the posterior distributions from the fitted
        model as priors for calibrating unpaired observational estimates.

        Parameters
        ----------
        df_unpaired : pd.DataFrame
            DataFrame containing unpaired observational estimates with columns:
            - obs_model_est: observational model estimates
            - obs_model_est_se: standard errors of observational model estimates
            - experiment_scale: experiment scale metrics
            - experiment_scale_se: standard errors of experiment scale
        trace : arviz.InferenceData or similar
            Posterior samples from fitted model

        Returns
        -------
        pm.Model
            PyMC model for calibration
        """
        if df_unpaired is None or len(df_unpaired) == 0:
            raise ValueError("df_unpaired cannot be None or empty")

        # Validate required columns
        required_cols = ["obs_model_est", "obs_model_est_se", "experiment_scale", "experiment_scale_se"]
        missing_cols = [col for col in required_cols if col not in df_unpaired.columns]
        if missing_cols:
            raise ValueError(f"Missing required columns in df_unpaired: {missing_cols}")

        self.logger.info(f"Building calibration model for {len(df_unpaired)} unpaired observations")

        N_unpaired = len(df_unpaired)
        bias_spec = self.config["model_settings"]["bias_spec"]
        likelihood_dist = self.config["model_settings"]["likelihood_distribution"]
        student_nu = self.config["model_settings"].get("student_df", 6)

        with pm.Model() as calibration_model:
            # Unpaired data variables
            obs_model_est_unpaired = pm.Data("obs_model_est_unpaired", df_unpaired["obs_model_est"].values)
            obs_model_est_se_unpaired = pm.Data("obs_model_est_se_unpaired", df_unpaired["obs_model_est_se"].values)
            experiment_scale_unpaired = pm.Data("experiment_scale_unpaired", df_unpaired["experiment_scale"].values)
            experiment_scale_se_unpaired = pm.Data(
                "experiment_scale_se_unpaired", df_unpaired["experiment_scale_se"].values
            )

            # Check posterior normality and extract summary statistics using helper methods
            # Use means of posterior from fitted model as scalar hyperparameters
            if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_INT.value]:
                self._check_posterior_normality(trace, "mu_beta_0")
                self._check_posterior_normality(trace, "sigma_beta_0")
                mu_beta_0_posterior_values = self._extract_posterior_values(trace, "mu_beta_0")
                sigma_beta_0_posterior_values = self._extract_posterior_values(trace, "sigma_beta_0")
                bias_intercept_posterior = mu_beta_0_posterior_values.mean()
                sigma_bias_intercept_posterior = sigma_beta_0_posterior_values.mean()
            if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_MULT.value]:
                self._check_posterior_normality(trace, "mu_beta_1")
                self._check_posterior_normality(trace, "sigma_beta_1")
                mu_beta_1_posterior_values = self._extract_posterior_values(trace, "mu_beta_1")
                sigma_beta_1_posterior_values = self._extract_posterior_values(trace, "sigma_beta_1")
                bias_multiplier_posterior = mu_beta_1_posterior_values.mean()
                sigma_bias_multiplier_posterior = sigma_beta_1_posterior_values.mean()

            self._check_posterior_normality(trace, "mu_ati")
            self._check_posterior_normality(trace, "sigma_ati")
            self._check_posterior_normality(trace, "mu_scale")
            self._check_posterior_normality(trace, "sigma_scale")
            self._check_posterior_normality(trace, "sigma_tau")

            mu_ati_posterior = self._extract_posterior_values(trace, "mu_ati").mean()
            sigma_ati_posterior = self._extract_posterior_values(trace, "sigma_ati").mean()
            mu_scale_posterior = self._extract_posterior_values(trace, "mu_scale").mean()
            sigma_scale_posterior = self._extract_posterior_values(trace, "sigma_scale").mean()
            sigma_tau_posterior = self._extract_posterior_values(trace, "sigma_tau").mean()

            # Bias intercept and multiplier for unpaired data
            if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_INT.value]:
                obs_model_bias_intercept_unpaired = pm.Normal(
                    "obs_model_bias_intercept_unpaired",
                    mu=bias_intercept_posterior,
                    sigma=sigma_bias_intercept_posterior,
                    shape=N_unpaired,
                )
            if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_MULT.value]:
                obs_model_bias_multiplier_unpaired = pm.Normal(
                    "obs_model_bias_multiplier_unpaired",
                    mu=bias_multiplier_posterior,
                    sigma=sigma_bias_multiplier_posterior,
                    shape=N_unpaired,
                )

            # Unpaired data model
            experiment_true_size_unpaired = pm.LogNormal(
                "experiment_true_size_unpaired",
                mu=mu_scale_posterior,
                sigma=sigma_scale_posterior,
                shape=N_unpaired,
            )
            experiment_true_ati_unpaired = pm.Normal(
                "experiment_true_ati_unpaired",
                mu=mu_ati_posterior,
                sigma=sigma_ati_posterior,
                shape=N_unpaired,
            )

            mu_true_tte_unpaired = experiment_true_ati_unpaired * experiment_true_size_unpaired
            tau_unpaired = pm.Normal(
                "tau_unpaired", mu=mu_true_tte_unpaired, sigma=sigma_tau_posterior, shape=N_unpaired
            )

            # Bias calculation
            if bias_spec == BiasSpecification.BOTH_INT_MULT.value:
                bias_level_unpaired = (
                    obs_model_bias_intercept_unpaired + obs_model_bias_multiplier_unpaired * mu_true_tte_unpaired
                )
            elif bias_spec == BiasSpecification.ONLY_INT.value:
                bias_level_unpaired = obs_model_bias_intercept_unpaired
            elif bias_spec == BiasSpecification.ONLY_MULT.value:
                bias_level_unpaired = obs_model_bias_multiplier_unpaired * mu_true_tte_unpaired
            else:
                raise ValueError(f"Invalid bias specification: {bias_spec}")

            # Calibrated estimates
            pm.Deterministic("calibrated_estimates", obs_model_est_unpaired - bias_level_unpaired)

            # Likelihood
            if likelihood_dist == LikelihoodDistribution.NORMAL.value:
                pm.Normal(
                    "tau_obs_model_est_likelihood_unpaired",
                    mu=tau_unpaired + bias_level_unpaired,
                    sigma=obs_model_est_se_unpaired,
                    observed=obs_model_est_unpaired,
                )
                pm.Normal(
                    "experiment_scale_likelihood_unpaired",
                    mu=experiment_true_size_unpaired,
                    sigma=experiment_scale_se_unpaired,
                    observed=experiment_scale_unpaired,
                )
            elif likelihood_dist == LikelihoodDistribution.STUDENT_T.value:
                pm.StudentT(
                    "experiment_scale_likelihood_unpaired",
                    nu=student_nu,
                    mu=experiment_true_size_unpaired,
                    sigma=experiment_scale_se_unpaired,
                    observed=experiment_scale_unpaired,
                )
                pm.StudentT(
                    "tau_obs_model_est_likelihood_unpaired",
                    nu=student_nu,
                    mu=tau_unpaired + bias_level_unpaired,
                    sigma=obs_model_est_se_unpaired,
                    observed=obs_model_est_unpaired,
                )

        self.logger.info("Calibration model built successfully")

        return calibration_model

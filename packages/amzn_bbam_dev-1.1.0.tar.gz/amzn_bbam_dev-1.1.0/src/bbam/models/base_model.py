"""
Base Model - Abstract base class for BBAM models.

This module provides the abstract Model class that serves as the foundation
for all BBAM model implementations.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

import pandas as pd


class Model(ABC):
    """Abstract base class for building PyMC models for Bayesian meta-analysis."""

    pymc_model: Any

    def __init__(self, logger: Optional[Any] = None) -> None:
        """Initialize the model with a logger.

        Parameters
        ----------
        logger : logging.Logger, optional
            Logger instance to use. If None, a default logger will be created.
        """
        if logger:
            self.logger = logging.getLogger(f"{logger.name}.model")
        else:
            self.logger = logging.getLogger("model_class")

        # Initialize metadata attributes
        self.vars_trace_plot: List[str] = []
        self.vars_table_full: List[str] = []
        self.vars_table_short: List[str] = []
        self.vars_display_names: Dict[str, str] = {}
        self.config: Dict[str, Any] = {}
        self.priors: Dict[str, Any] = {}

        self.logger.info(f"Initializing {self.__class__.__name__}")

    def set_and_process_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Set the configuration for the model.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration dictionary containing model settings and specifications

        Returns
        -------
        Dict[str, Any]
            The potentially modified configuration
        """
        self.config = self._prepare_config(config)
        self.logger.info("Configuration set successfully")
        return self.config

    @abstractmethod
    def _prepare_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and prepare the model configuration.

        Validates the configuration and sets default values where needed.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration dictionary containing model settings and specifications

        Returns
        -------
        Dict[str, Any]
            Validated and prepared configuration dictionary

        Raises
        ------
        ValueError
            If the provided configuration is invalid
        """
        raise NotImplementedError("Subclasses must implement _prepare_config()")

    @abstractmethod
    def get_required_data_columns(self) -> List[str]:
        """Define required columns for the analysis.

        Returns
        -------
        List[str]
            List of column names that must be present in the input data
        """
        raise NotImplementedError("Subclasses must implement get_required_data_columns()")

    @abstractmethod
    def _get_data_driven_priors(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Calculate data-driven priors based on input data.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing experiment data used to calculate priors

        Returns
        -------
        Dict[str, Any]
            Dictionary containing data-driven prior specifications
        """
        raise NotImplementedError("Subclasses must implement _get_data_driven_priors()")

    @abstractmethod
    def _validate_priors(self, priors: Dict[str, Any]) -> bool:
        """Validate that provided priors meet model requirements.

        Parameters
        ----------
        priors : Dict[str, Any]
            Dictionary of prior specifications to validate

        Returns
        -------
        bool
            True if priors are valid

        Raises
        ------
        ValueError
            If required priors are missing
        """
        raise NotImplementedError("Subclasses must implement _validate_priors()")

    @abstractmethod
    def _set_variables_metadata(self) -> "Model":
        """Set up variable names for output tables and plots.

        Returns
        -------
        Model
            Self reference for method chaining
        """
        raise NotImplementedError("Subclasses must implement _set_variables_metadata()")

    def get_posterior_predictive_vars(self) -> List[str]:
        """Get the names of variables to include in posterior predictive sampling.

        Returns
        -------
        List[str]
            List of variable names for posterior predictive sampling
        """
        return []

    def define_posterior_predictive_vars(self, n_samples: int) -> None:
        """Create posterior predictive variables in the PyMC model.

        Default implementation does nothing. Subclasses should override this
        method if they support posterior predictive sampling.

        Parameters
        ----------
        n_samples : int
            Number of posterior predictive samples to generate
        """
        pass

    @abstractmethod
    def build(self, data: pd.DataFrame) -> "Model":
        """Build PyMC model with specified priors.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing experiment data

        Returns
        -------
        Model
            Self reference for method chaining
        """
        raise NotImplementedError("Subclasses must implement build()")

    @abstractmethod
    def build_calibration_model(self, df_unpaired: pd.DataFrame, trace: Any) -> Any:
        """Build a calibration model for unpaired observational data using fitted model parameters.

        This method creates a new PyMC model that uses the posterior distributions from the fitted
        model as priors for calibrating unpaired observational estimates.

        Parameters
        ----------
        df_unpaired : pd.DataFrame
            DataFrame containing unpaired observational estimates
        trace : Any
            Posterior samples from fitted model

        Returns
        -------
        Any
            PyMC model for calibration

        Raises
        ------
        ValueError
            If df_unpaired is invalid or missing required columns
        """
        raise NotImplementedError("Subclasses must implement build_calibration_model()")

    def set_priors(self, data: Optional[pd.DataFrame] = None) -> "Model":
        """Set priors for the model.

        Parameters
        ----------
        data : pd.DataFrame, optional
            DataFrame containing experiment data, required if data_driven_priors is True.

        Returns
        -------
        Model
            Self reference for method chaining

        Raises
        ------
        ValueError
            If data_driven_priors is True but no data is provided
        Exception
            If an error occurs during prior setting
        """
        if self.config["data_driven_priors"]:
            if data is None:
                raise ValueError("Data must be provided to set data-driven priors")
            self.priors = self._get_data_driven_priors(data)
            self.logger.info("Using data driven priors")
        else:
            try:
                self._validate_priors(self.config["priors"])
                self.priors = self.config[
                    "priors"
                ].copy()  # Create a copy of priors_config to avoid modifying the original
                self.logger.info("Using provided priors")
            except Exception as e:
                self.logger.error(f"Error during setting priors: {str(e)}")
                raise
        return self

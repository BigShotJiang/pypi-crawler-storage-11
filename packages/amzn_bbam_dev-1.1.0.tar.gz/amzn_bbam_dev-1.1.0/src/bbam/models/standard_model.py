"""
Standard Model - Hierarchical Bayesian model for RCT + Observational meta-analysis.

This module provides the RCTObsHBM class for meta-analysis that validates
observational measurement models against RCT evidence.
"""

from __future__ import annotations

from typing import Any, Dict, List

import pandas as pd
import pymc as pm
import pytensor.tensor as pt

from ..utils.enums import BiasSpecification, LikelihoodDistribution, PriorSpecifications
from .base_model import Model


class RCTObsHBM(Model):
    """Builder for hierarchical Bayesian meta-analysis models that validate
    observational measurement models against RCT evidence.

    This class implements a meta-analysis of randomized controlled trials (RCTs)
    and observational model measurements. It estimates the overall treatment effect,
    between-study heterogeneity, and observational model's bias.
    """

    def get_required_data_columns(self) -> List[str]:
        """Define required columns

        Returns
        -------
        List[str]
            List of required column names
        """
        return ["experiment_est", "experiment_est_se", "obs_model_est", "obs_model_est_se"]

    def _prepare_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and prepare the model configuration.

        Validates the configuration and sets default values where needed.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration dictionary containing model settings and specifications

        Returns
        -------
        Dict[str, Any]
            Validated and prepared configuration dictionary

        Raises
        ------
        ValueError
            If the provided configuration is invalid
        """
        if config is None:
            raise ValueError("Configuration cannot be None")

        # Ensure model_settings section exists
        if "model_settings" not in config:
            raise ValueError("Missing required section: model_settings")

        # Validate bias_spec if present
        if "bias_spec" not in config["model_settings"]:
            raise ValueError("Missing required parameter: bias_spec in model_settings section")

        # Validate bias_spec value
        if config["model_settings"]["bias_spec"] not in BiasSpecification.values():
            raise ValueError(
                f"Invalid bias_spec value: {config['model_settings']['bias_spec']}. "
                f"Must be one of {BiasSpecification.values()}"
            )

        # Add likelihood_distribution if missing
        if "likelihood_distribution" not in config["model_settings"]:
            config["model_settings"]["likelihood_distribution"] = LikelihoodDistribution.NORMAL.value

        # Validate likelihood_distribution value
        if config["model_settings"]["likelihood_distribution"] not in LikelihoodDistribution.values():
            raise ValueError(
                f"Invalid likelihood_distribution value: "
                f"{config['model_settings']['likelihood_distribution']}. "
                f"Must be one of {LikelihoodDistribution.values()}"
            )

        # Add skip_model_posterior_metrics if missing (default: False)
        if "skip_model_posterior_metrics" not in config["model_settings"]:
            config["model_settings"]["skip_model_posterior_metrics"] = False

        # Validate skip_model_posterior_metrics value
        if not isinstance(config["model_settings"]["skip_model_posterior_metrics"], bool):
            raise ValueError(
                f"Invalid skip_model_posterior_metrics value: "
                f"{config['model_settings']['skip_model_posterior_metrics']}. "
                f"Must be a boolean (True or False)"
            )

        # If likelihood_distribution is student's t, the config must provide the degree of freedoms parameter student_df
        if config["model_settings"]["likelihood_distribution"] == LikelihoodDistribution.STUDENT_T.value:
            if "student_df" not in config["model_settings"]:
                raise ValueError(
                    "If likelihood_distribution is student's t, the config must provide "
                    "the degree of freedoms parameter student_df"
                )
            else:
                # validate the student_df is a positive number
                if (
                    not isinstance(config["model_settings"]["student_df"], (int, float))
                    or config["model_settings"]["student_df"] <= 0
                ):
                    raise ValueError("student_df must be a positive number")

        # Ensure data_driven_priors_settings section exists if config['data_driven_priors'] is True
        if config["data_driven_priors"] and "data_driven_priors_settings" not in config:
            raise ValueError(
                "'data_driven_priors_settings' section must be provided in configuration, if data_drive_priors is True"
            )

        # Validate prior settings for treatment effect
        if "treatment_effect" not in config["data_driven_priors_settings"]:
            raise ValueError(
                "'treatment_effect' section must be provided in 'data_driven_priors_settings' "
                "of the configuration, if data_drive_priors is True"
            )
        else:
            te_settings = config["data_driven_priors_settings"]["treatment_effect"]

        if "scale_prior_width_mean" not in te_settings:
            raise ValueError(
                "scale_prior_width_mean parameter must be provided in the 'treatment_effect' "
                "of 'data_driven_priors_settings' in the configuration"
            )
        if "scale_prior_width_sigma" not in te_settings:
            raise ValueError(
                "scale_prior_width_sigma parameter must be provided in the 'treatment_effect' "
                "of 'data_driven_priors_settings' in the configuration"
            )

        # Validate prior settings for bias intercept
        if "bias_intercept" not in config["data_driven_priors_settings"]:
            raise ValueError(
                "'bias_intercept' section must be provided in 'data_driven_priors_settings' "
                "of the configuration, if data_drive_priors is True"
            )
        else:
            bias_int_settings = config["data_driven_priors_settings"]["bias_intercept"]

        if "scale_prior_width_mean" not in bias_int_settings:
            raise ValueError(
                "scale_prior_width_mean parameter must be provided in the 'bias_intercept' "
                "of 'data_driven_priors_settings' in the configuration"
            )
        if "scale_prior_width_sigma" not in bias_int_settings:
            raise ValueError(
                "scale_prior_width_sigma parameter must be provided in the 'bias_intercept' "
                "of 'data_driven_priors_settings' in the configuration"
            )

        # Validate prior settings for bias intercept
        if "bias_multiplier" not in config["data_driven_priors_settings"]:
            raise ValueError(
                "'bias_multiplier' section must be provided in 'data_driven_priors_settings' "
                "of the configuration, if data_drive_priors is True"
            )
        else:
            bias_mult_settings = config["data_driven_priors_settings"]["bias_multiplier"]

        if "center_prior_mean" not in bias_mult_settings:
            raise ValueError(
                "center_prior_mean parameter must be provided in the 'bias_multiplier' "
                "of 'data_driven_priors_settings' in the configuration"
            )
        if "prior_width_mean" not in bias_mult_settings:
            raise ValueError(
                "prior_width_mean parameter must be provided in the 'bias_multiplier' "
                "of 'data_driven_priors_settings' in the configuration"
            )
        if "prior_width_sigma" not in bias_mult_settings:
            raise ValueError(
                "prior_width_sigma parameter must be provided in the 'bias_multiplier' "
                "of 'data_driven_priors_settings' in the configuration"
            )

        return config

    def _get_data_driven_priors(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Calculate data-driven priors based on input data.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing experiment data used to calculate priors

        Returns
        -------
        Dict[str, Any]
            Dictionary containing data-driven prior specifications
        """
        # Compute data-driven priors
        point_est_mean = data["experiment_est"].mean()
        point_est_sd = data["experiment_est"].std()

        # Get prior settings from config
        data_driven_priors_settings = self.config["data_driven_priors_settings"]

        # Get settings for priors on treatment effect
        te_settings = data_driven_priors_settings["treatment_effect"]
        if "center_prior_mean" in te_settings.keys():
            self.logger.info(
                f"Overriding data-driven TTE center prior (data mean: {point_est_mean:.4f})"
                f" with config: {te_settings['center_prior_mean']:.4f}"
            )
            point_est_mean = te_settings["center_prior_mean"]
        te_scale_mean = te_settings["scale_prior_width_mean"]
        te_scale_sigma = te_settings["scale_prior_width_sigma"]

        # Get settings for priors on bias intercept
        bias_int_settings = data_driven_priors_settings["bias_intercept"]
        bias_int_scale_mean = bias_int_settings["scale_prior_width_mean"]
        bias_int_scale_sigma = bias_int_settings["scale_prior_width_sigma"]

        # Get settings for priors on bias multiplier
        bias_mult_settings = data_driven_priors_settings["bias_multiplier"]
        delta_beta_1 = bias_mult_settings["center_prior_mean"]
        gamma_beta_1 = bias_mult_settings["prior_width_mean"]
        zeta_beta_1 = bias_mult_settings["prior_width_sigma"]

        # specify priors
        priors = {
            # mean of treatment effect distribution
            "mu_tau": {
                "delta_mu_tau": point_est_mean,
                "gamma_mu_tau": te_scale_mean * point_est_sd,
            },
            # std. dev. of treatment effect distribution
            "sigma_tau": {"zeta_sigma_tau": te_scale_sigma * point_est_sd},
            # mean of the bias intercept component
            "mu_beta_0": {
                "delta_beta_0": 0.0,  # center prior at zero
                "gamma_beta_0": bias_int_scale_mean * point_est_sd,
            },
            # std. dev. of the bias intercept component
            "sigma_beta_0": {"zeta_beta_0": bias_int_scale_sigma * point_est_sd},
            # mean of the bias multiplier component
            "mu_beta_1": {
                "delta_beta_1": delta_beta_1,
                "gamma_beta_1": gamma_beta_1,  # fixed value, not data-dependent
            },
            # std. dev. of the bias multiplier component
            "sigma_beta_1": {"zeta_beta_1": zeta_beta_1},  # fixed value, not data-dependent
        }

        return priors

    def _validate_priors(self, priors: Dict[str, Any]) -> bool:
        """Validate that provided priors meet model requirements.

        Parameters
        ----------
        priors : Dict[str, Any]
            Dictionary of prior specifications to validate

        Returns
        -------
        bool
            True if priors are valid

        Raises
        ------
        ValueError
            If required priors are missing
        """
        # Use shared prior specifications from PriorSpecifications
        required_priors = PriorSpecifications.get_required_priors("standard")
        missing_priors = [p for p in required_priors if p not in priors]
        if missing_priors:
            raise ValueError(f"Missing required priors: {missing_priors}")
        return True

    def _set_variables_metadata(self) -> "RCTObsHBM":
        """Set up variable names for output tables and plots.

        Returns
        -------
        RCTObsHBM
            Self reference for method chaining
        """
        # Set variables for trace plots
        self.vars_trace_plot = [
            "mu_tau",
            "sigma_tau",
            "std_bias",
            "std_obs_model",
            "mu_beta_0",
            "sigma_beta_0",
            "mu_beta_1",
            "sigma_beta_1",
            "mean_bias",
            "mean_obs_model",
        ]

        # Set variables for full summary tables
        self.vars_table_full = [
            "mu_tau",
            "sigma_tau",
            "mean_bias",
            "mean_obs_model",
            "mu_beta_0",
            "sigma_beta_0",
            "mu_beta_1",
            "sigma_beta_1",
            "std_bias",
            "std_obs_model",
        ]

        # Set variables for short summary tables (default)
        self.vars_table_short = ["mu_tau", "mean_bias", "mean_obs_model"]

        # Set display names for variables
        self.vars_display_names = {
            "mu_tau": "Avg. treatment effect",
            "sigma_tau": "Std. dev. of treatment effects",
            "mean_bias": "Average model bias across observations",
            "mean_obs_model": "Average observational model estimate across observations",
            "mu_beta_0": "Mean of bias intercept component",
            "sigma_beta_0": "Std. dev. of bias intercept component",
            "mu_beta_1": "Mean of bias multiplier component",
            "sigma_beta_1": "Std. dev. of bias multiplier component",
            "std_bias": "Model bias std. dev. across observations",
            "std_obs_model": "Obs. model std. dev. across observations",
        }

        # Add posterior predictive variables if enabled
        if self.config["sampling_settings"]["n_sample_posterior"] > 0:
            posterior_vars = self.get_posterior_predictive_vars()
            self.vars_table_full.extend(posterior_vars)
            self.vars_display_names.update(
                {
                    "mean_tau_tilde": "Avg. treatment effect (posterior predictive)",
                    "tau_tilde": "Treatment effect in individual measurement",
                    "mean_bias_tilde": "Expected model bias (posterior predictive)",
                    "bias_tilde": "Bias in individual measurement",
                    "mean_obs_model_est_tilde": "Expected observational model estimate (posterior predictive)",
                    "obs_model_est_tilde": "Observational model estimate in individual measurement",
                    "std_tau_tilde": "Std. dev. of treatment effect in individual measurement",
                    "std_bias_tilde": "Std. dev. of observational model bias (posterior predictive)",
                    "std_obs_model_est_tilde": "Std. dev. of observational model estimate (posterior predictive)",
                }
            )

        return self

    def get_posterior_predictive_vars(self) -> List[str]:
        """Get the names of variables to include in posterior predictive sampling.

        Returns
        -------
        List[str]
            List of variable names for posterior predictive sampling
        """
        return [
            "mean_tau_tilde",
            "tau_tilde",
            "mean_bias_tilde",
            "bias_tilde",
            "mean_obs_model_est_tilde",
            "obs_model_est_tilde",
            "std_tau_tilde",
            "std_bias_tilde",
            "std_obs_model_est_tilde",
        ]

    def define_posterior_predictive_vars(self, n_samples: int) -> None:
        """Create posterior predictive variables in the PyMC model.

        Parameters
        ----------
        n_samples : int
            Number of posterior predictive samples to generate
        """
        # Get the parameters from the model
        params = {}
        params["mu_tau"] = self.pymc_model.mu_tau
        params["sigma_tau"] = self.pymc_model.sigma_tau

        # Treatment effect in indiviudal measurement (posterior predictive, non-centered parametrization)
        z_tau_tilde = pm.Normal("z_tau_tilde", mu=0, sigma=1, shape=n_samples)
        tau_tilde = pm.Deterministic("tau_tilde", params["mu_tau"] + z_tau_tilde * params["sigma_tau"])
        # Avg. teatment effect across posterior predictive samples
        mean_tau_tilde = pm.Deterministic("mean_tau_tilde", pm.math.mean(tau_tilde))  # noqa: F841

        # Bias components based on bias specification
        bias_spec = self.config["model_settings"]["bias_spec"]
        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_INT.value]:
            params["mu_beta_0"] = self.pymc_model.mu_beta_0
            params["sigma_beta_0"] = self.pymc_model.sigma_beta_0
            # bias intercept component (posterior predictive, non-centered parametrization)
            z_beta_0_tilde = pm.Normal("z_beta_0_tilde", mu=0, sigma=1, shape=n_samples)
            beta_0_tilde = pm.Deterministic(
                "beta_0_tilde", params["mu_beta_0"] + z_beta_0_tilde * params["sigma_beta_0"]
            )

        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_MULT.value]:
            params["mu_beta_1"] = self.pymc_model.mu_beta_1
            params["sigma_beta_1"] = self.pymc_model.sigma_beta_1
            # bias multiplier component (posterior predictive, non-centered parametrization)
            z_beta_1_tilde = pm.Normal("z_beta_1_tilde", mu=0, sigma=1, shape=n_samples)
            beta_1_tilde = pm.Deterministic(
                "beta_1_tilde", params["mu_beta_1"] + z_beta_1_tilde * params["sigma_beta_1"]
            )

        # Bias in individual measurement (posterior predictive)
        if bias_spec == BiasSpecification.BOTH_INT_MULT.value:
            bias_tilde = pm.Deterministic("bias_tilde", beta_0_tilde + beta_1_tilde * tau_tilde)
        elif bias_spec == BiasSpecification.ONLY_INT.value:
            bias_tilde = pm.Deterministic("bias_tilde", beta_0_tilde)
        elif bias_spec == BiasSpecification.ONLY_MULT.value:
            bias_tilde = pm.Deterministic("bias_tilde", beta_1_tilde * tau_tilde)

        # Average bias across posterior predictive samples
        pm.Deterministic("mean_bias_tilde", pm.math.mean(bias_tilde))

        # Obs model individual estimates (posterior predictive)
        obs_model_est_tilde = pm.Deterministic("obs_model_est_tilde", tau_tilde + bias_tilde)
        # Expected obs. model estimate across posterior predictive samples
        pm.Deterministic("mean_obs_model_est_tilde", pm.math.mean(obs_model_est_tilde))

        # Std. dev. of treatment effect, bias, and obs. model estimate, across posterior predictive samples
        pm.Deterministic("std_tau_tilde", pt.std(tau_tilde))
        pm.Deterministic("std_bias_tilde", pt.std(bias_tilde))
        pm.Deterministic("std_obs_model_est_tilde", pt.std(obs_model_est_tilde))

    def _define_data(self, data: pd.DataFrame, model: Any) -> Dict[str, Any]:
        """Set up data variables in the PyMC model.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing data
        model : pm.Model
            PyMC model to add data variables to

        Returns
        -------
        Dict[str, Any]
            Dictionary containing data variables and number of observations
        """
        data_vars = {}

        # Number of observations
        data_vars["n_obs"] = len(data)

        # Experiment (RCT) data
        data_vars["tau_experiment_est"] = pm.Data("tau_experiment_est", data["experiment_est"].values)  # point estimate
        data_vars["sigma_experiment_est"] = pm.Data(
            "sigma_experiment_est", data["experiment_est_se"].values
        )  # standard error

        # Observational model data
        data_vars["tau_obs_model_est"] = pm.Data("tau_obs_model_est", data["obs_model_est"].values)  # point estimate
        data_vars["sigma_obs_model_est"] = pm.Data(
            "sigma_obs_model_est", data["obs_model_est_se"].values
        )  # standard error
        return data_vars

    def _define_priors_on_params(self) -> Dict[str, Any]:
        """Define prior distributions for the model parameters.

        Returns
        -------
        Dict[str, Any]
            Dictionary containing model parameters
        """
        params = {}

        # Treatment effect parameters
        mu_tau_prior = self.priors.get("mu_tau", {})
        params["mu_tau"] = pm.Normal(
            "mu_tau",
            mu=mu_tau_prior.get("delta_mu_tau", 0.0),
            sigma=mu_tau_prior.get("gamma_mu_tau", 1.0),
        )
        sigma_tau_prior = self.priors.get("sigma_tau", {})
        params["sigma_tau"] = pm.HalfCauchy("sigma_tau", beta=sigma_tau_prior.get("zeta_sigma_tau", 1.0))

        # Bias intercept parameters
        bias_spec = self.config["model_settings"]["bias_spec"]
        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_INT.value]:
            mu_beta_0_prior = self.priors.get("mu_beta_0", {})
            params["mu_beta_0"] = pm.Normal(
                "mu_beta_0",
                mu=mu_beta_0_prior.get("delta_beta_0", 0.0),
                sigma=mu_beta_0_prior.get("gamma_beta_0", 1.0),
            )
            sigma_beta_0_prior = self.priors.get("sigma_beta_0", {})
            params["sigma_beta_0"] = pm.HalfCauchy("sigma_beta_0", beta=sigma_beta_0_prior.get("zeta_beta_0", 1.0))

        # Bias multiplier parameters
        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_MULT.value]:
            mu_beta_1_prior = self.priors.get("mu_beta_1", {})
            params["mu_beta_1"] = pm.Normal(
                "mu_beta_1",
                mu=mu_beta_1_prior.get("delta_beta_1", 0.0),
                sigma=mu_beta_1_prior.get("gamma_beta_1", 1.0),
            )
            sigma_beta_1_prior = self.priors.get("sigma_beta_1", {})
            params["sigma_beta_1"] = pm.HalfCauchy("sigma_beta_1", beta=sigma_beta_1_prior.get("zeta_beta_1", 1.0))
        return params

    def _define_model_structure(self, params: Dict[str, Any], n_obs: int) -> Dict[str, Any]:
        """Define the core model structure including treatment effects and bias.

        Parameters
        ----------
        params : Dict[str, Any]
            Dictionary containing model parameters
        n_obs : int
            Number of observations

        Returns
        -------
        Dict[str, Any]
            Dictionary containing model variables
        """
        model_vars = {}

        # Treatment effect (non-centered parametrization)
        z_tau = pm.Normal("z_tau", mu=0, sigma=1, shape=n_obs)
        model_vars["tau"] = pm.Deterministic("tau", params["mu_tau"] + z_tau * params["sigma_tau"])

        # Bias intercept component (non-centered parametrization)
        bias_spec = self.config["model_settings"]["bias_spec"]
        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_INT.value]:
            z_beta_0 = pm.Normal("z_beta_0", mu=0, sigma=1, shape=n_obs)
            model_vars["beta_0"] = pm.Deterministic("beta_0", params["mu_beta_0"] + z_beta_0 * params["sigma_beta_0"])

        # Bias multiplier component (non-centered parametrization)
        if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_MULT.value]:
            z_beta_1 = pm.Normal("z_beta_1", mu=0, sigma=1, shape=n_obs)
            model_vars["beta_1"] = pm.Deterministic("beta_1", params["mu_beta_1"] + z_beta_1 * params["sigma_beta_1"])

        # Combined bias
        if bias_spec == BiasSpecification.BOTH_INT_MULT.value:
            model_vars["bias"] = pm.Deterministic(
                "bias", model_vars["beta_0"] + model_vars["beta_1"] * model_vars["tau"]
            )
        elif bias_spec == BiasSpecification.ONLY_INT.value:
            model_vars["bias"] = pm.Deterministic("bias", model_vars["beta_0"])
        elif bias_spec == BiasSpecification.ONLY_MULT.value:
            model_vars["bias"] = pm.Deterministic("bias", model_vars["beta_1"] * model_vars["tau"])
        else:
            raise ValueError(f"Invalid bias specification: {bias_spec}")

        return model_vars

    def _define_likelihood_for_observables(
        self, model_vars: Dict[str, Any], data_vars: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Define likelihood for observable variables in the model.

        Parameters
        ----------
        model_vars : Dict[str, Any]
            Dictionary containing model variables
        data_vars : Dict[str, Any]
            Dictionary containing data variables

        Returns
        -------
        Dict[str, Any]
            Dictionary containing likelihood variables
        """
        likelihoods = {}
        likelihood_dist = self.config["model_settings"]["likelihood_distribution"]

        if likelihood_dist == LikelihoodDistribution.NORMAL.value:
            self.logger.info("Using normal likelihood for RCT and observational model estimates (default)")
            # RCT estimate likelihood
            likelihoods["tau_experiment_est_likelihood"] = pm.Normal(
                "tau_experiment_est_likelihood",
                mu=model_vars["tau"],
                sigma=data_vars["sigma_experiment_est"],
                observed=data_vars["tau_experiment_est"],
            )
            # Observational model estimate likelihood
            likelihoods["tau_obs_model_est_likelihood"] = pm.Normal(
                "tau_obs_model_est_likelihood",
                mu=model_vars["tau"] + model_vars["bias"],
                sigma=data_vars["sigma_obs_model_est"],
                observed=data_vars["tau_obs_model_est"],
            )
        elif likelihood_dist == LikelihoodDistribution.STUDENT_T.value:
            self.logger.info(
                f"Using student's t likelihood for RCT and observational model estimates "
                f"with the degrees of freedom: {self.config['model_settings']['student_df']}"
            )
            # RCT estimate likelihood
            likelihoods["tau_experiment_est_likelihood"] = pm.StudentT(
                "tau_experiment_est_likelihood",
                nu=self.config["model_settings"]["student_df"],
                mu=model_vars["tau"],
                sigma=data_vars["sigma_experiment_est"],
                observed=data_vars["tau_experiment_est"],
            )
            # Observational model estimate likelihood
            likelihoods["tau_obs_model_est_likelihood"] = pm.StudentT(
                "tau_obs_model_est_likelihood",
                nu=self.config["model_settings"]["student_df"],
                mu=model_vars["tau"] + model_vars["bias"],
                sigma=data_vars["sigma_obs_model_est"],
                observed=data_vars["tau_obs_model_est"],
            )
        return likelihoods

    def _define_posterior_metrics(self, model_vars: Dict[str, Any]) -> Dict[str, Any]:
        """Define posterior metrics for the model.

        These metrics compute conditional averages across observations in the fitted dataset,
        serving as diagnostic tools to compare against posterior predictive expectations.
        They must be computed at build time (not in posterior sampling) because they are
        conditional on the observed data and represent the model's fit to the current dataset.

        These conditional averages serve important diagnostic purposes:
        - Compare conditional vs. posterior predictive estimates to assess model stability
        - In healthy datasets, conditional and predictive means should converge (law of large numbers)
        - Provide 'stress testing' between generalized expectations and conditional averages
        - Enable efficient computation without requiring posterior predictive sampling

        Can be optionally disabled via config setting 'skip_model_posterior_metrics' if these
        computations affect model convergence in specific use cases.

        Parameters
        ----------
        model_vars : Dict[str, Any]
            Dictionary containing model variables with shape (n_obs,) for bias and tau

        Returns
        -------
        Dict[str, Any]
            Dictionary containing posterior metrics as conditional averages (empty if skipped)
        """
        posterior_metrics: Dict[str, Any] = {}

        # Check if posterior metrics should be skipped (for convergence-sensitive cases)
        if self.config["model_settings"].get("skip_model_posterior_metrics", False):
            self.logger.info("Skipping posterior metrics computation (skip_model_posterior_metrics=True)")
            return posterior_metrics

        self.logger.info("Defining posterior metrics (conditional averages across observations)")

        # Average model bias across observations in the fitted dataset (conditional on data)
        posterior_metrics["mean_bias"] = pm.Deterministic("mean_bias", pm.math.mean(model_vars["bias"]))
        posterior_metrics["std_bias"] = pm.Deterministic("std_bias", pt.std(model_vars["bias"]))

        # Average observational model estimate across observations in the fitted dataset (conditional on data)
        posterior_metrics["mean_obs_model"] = pm.Deterministic(
            "mean_obs_model", pm.math.mean(model_vars["tau"] + model_vars["bias"])
        )
        posterior_metrics["std_obs_model"] = pm.Deterministic(
            "std_obs_model", pt.std(model_vars["tau"] + model_vars["bias"])
        )

        return posterior_metrics

    def _extract_posterior_values(self, trace: Any, param_name: str) -> Any:
        """Extract posterior values from trace, handling different trace formats.

        Parameters
        ----------
        trace : Any
            Posterior trace containing samples
        param_name : str
            Name of the parameter to extract

        Returns
        -------
        Any
            Flattened posterior samples
        """
        posterior = trace.posterior[param_name]
        if hasattr(posterior, "values"):
            return posterior.values.flatten()
        else:
            return posterior.flatten()

    def build(self, data: pd.DataFrame) -> "RCTObsHBM":
        """Build PyMC model for meta-analysis validating observational model estimates against RCT evidence.
        The code implements meta-analysis framework described in:
        https://quip-amazon.com/t4FlA8AAqh26/RCT-Meta-Analysis-for-CCM-Example-of-Deliverable-Updated-103024

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing RCT and observational model estimates with standard errors

        Returns
        -------
        RCTObsHBM
            Self reference for method chaining
        """
        # Check if config is None before using it
        if self.config is None:
            raise ValueError("Configuration must be provided to build the model")

        with pm.Model() as pymc_model:
            # Set up data variables
            data_vars = self._define_data(data, pymc_model)

            # Define prior distributions
            params = self._define_priors_on_params()

            # Define model structure (treatment effects and bias)
            model_vars = self._define_model_structure(params, data_vars["n_obs"])

            # Define observable variables (likelihoods)
            _ = self._define_likelihood_for_observables(model_vars, data_vars)

            self._define_posterior_metrics(model_vars)

        self._set_variables_metadata()  # specify the list of variables for output tables and plots
        self.pymc_model = pymc_model
        self.logger.info(f"{self.__class__.__name__} model built successfully")
        return self

    def build_calibration_model(self, df_unpaired: pd.DataFrame, trace: Any) -> Any:
        """Build a calibration model for unpaired observational data using fitted model parameters.

        This method creates a new PyMC model that uses the posterior distributions from the fitted
        model as priors for calibrating unpaired observational estimates.

        Parameters
        ----------
        df_unpaired : pd.DataFrame
            DataFrame containing unpaired observational estimates with columns:
            - obs_model_est: observational model estimates
            - obs_model_est_se: standard errors of observational model estimates
        trace : arviz.InferenceData or similar
            Posterior samples from fitted model

        Returns
        -------
        pm.Model
            PyMC model for calibration
        """
        if df_unpaired is None or len(df_unpaired) == 0:
            raise ValueError("df_unpaired cannot be None or empty")

        # Validate required columns
        required_cols = ["obs_model_est", "obs_model_est_se"]
        missing_cols = [col for col in required_cols if col not in df_unpaired.columns]
        if missing_cols:
            raise ValueError(f"Missing required columns in df_unpaired: {missing_cols}")

        self.logger.info(f"Building calibration model for {len(df_unpaired)} unpaired observations")

        N_unpaired = len(df_unpaired)
        bias_spec = self.config["model_settings"]["bias_spec"]
        likelihood_dist = self.config["model_settings"]["likelihood_distribution"]
        student_nu = self.config["model_settings"].get("student_df", 6)

        with pm.Model() as calibration_model:
            # Unpaired data variables
            obs_model_est_unpaired = pm.Data("obs_model_est_unpaired", df_unpaired["obs_model_est"].values)
            obs_model_est_se_unpaired = pm.Data("obs_model_est_se_unpaired", df_unpaired["obs_model_est_se"].values)

            # Extract posterior values using helper method
            mu_tau_posterior = self._extract_posterior_values(trace, "mu_tau")
            sigma_tau_posterior = self._extract_posterior_values(trace, "sigma_tau")

            # Use fitted model parameters as priors for unpaired data
            mu_tau_cal = pm.Normal("mu_tau_cal", mu=mu_tau_posterior.mean(), sigma=mu_tau_posterior.std())
            sigma_tau_cal = pm.HalfCauchy("sigma_tau_cal", beta=sigma_tau_posterior.mean())

            # Bias parameters from fitted model using helper method
            if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_INT.value]:
                mu_beta_0_posterior = self._extract_posterior_values(trace, "mu_beta_0")
                sigma_beta_0_posterior = self._extract_posterior_values(trace, "sigma_beta_0")
                mu_beta_0_cal = pm.Normal(
                    "mu_beta_0_cal", mu=mu_beta_0_posterior.mean(), sigma=mu_beta_0_posterior.std()
                )
                sigma_beta_0_cal = pm.HalfCauchy("sigma_beta_0_cal", beta=sigma_beta_0_posterior.mean())

            if bias_spec in [BiasSpecification.BOTH_INT_MULT.value, BiasSpecification.ONLY_MULT.value]:
                mu_beta_1_posterior = self._extract_posterior_values(trace, "mu_beta_1")
                sigma_beta_1_posterior = self._extract_posterior_values(trace, "sigma_beta_1")
                mu_beta_1_cal = pm.Normal(
                    "mu_beta_1_cal", mu=mu_beta_1_posterior.mean(), sigma=mu_beta_1_posterior.std()
                )
                sigma_beta_1_cal = pm.HalfCauchy("sigma_beta_1_cal", beta=sigma_beta_1_posterior.mean())

            # Unpaired data model structure
            tau_unpaired = pm.Normal("tau_unpaired", mu=mu_tau_cal, sigma=sigma_tau_cal, shape=N_unpaired)

            # Bias for unpaired data
            if bias_spec == BiasSpecification.BOTH_INT_MULT.value:
                bias_intercept_unpaired = pm.Normal(
                    "bias_intercept_unpaired", mu=mu_beta_0_cal, sigma=sigma_beta_0_cal, shape=N_unpaired
                )
                bias_multiplier_unpaired = pm.Normal(
                    "bias_multiplier_unpaired", mu=mu_beta_1_cal, sigma=sigma_beta_1_cal, shape=N_unpaired
                )
                bias_level_unpaired = bias_intercept_unpaired + bias_multiplier_unpaired * tau_unpaired
            elif bias_spec == BiasSpecification.ONLY_INT.value:
                bias_intercept_unpaired = pm.Normal(
                    "bias_intercept_unpaired", mu=mu_beta_0_cal, sigma=sigma_beta_0_cal, shape=N_unpaired
                )
                bias_level_unpaired = bias_intercept_unpaired
            elif bias_spec == BiasSpecification.ONLY_MULT.value:
                bias_multiplier_unpaired = pm.Normal(
                    "bias_multiplier_unpaired", mu=mu_beta_1_cal, sigma=sigma_beta_1_cal, shape=N_unpaired
                )
                bias_level_unpaired = bias_multiplier_unpaired * tau_unpaired
            else:
                raise ValueError(f"Invalid bias specification: {bias_spec}")

            # Calibrated estimates for unpaired data
            pm.Deterministic("calibrated_estimates", obs_model_est_unpaired - bias_level_unpaired)

            # Likelihood for unpaired observational data
            if likelihood_dist == LikelihoodDistribution.NORMAL.value:
                pm.Normal(
                    "obs_model_est_likelihood_unpaired",
                    mu=tau_unpaired + bias_level_unpaired,
                    sigma=obs_model_est_se_unpaired,
                    observed=obs_model_est_unpaired,
                )
            elif likelihood_dist == LikelihoodDistribution.STUDENT_T.value:
                pm.StudentT(
                    "obs_model_est_likelihood_unpaired",
                    nu=student_nu,
                    mu=tau_unpaired + bias_level_unpaired,
                    sigma=obs_model_est_se_unpaired,
                    observed=obs_model_est_unpaired,
                )

        self.logger.info("Calibration model built successfully")
        return calibration_model

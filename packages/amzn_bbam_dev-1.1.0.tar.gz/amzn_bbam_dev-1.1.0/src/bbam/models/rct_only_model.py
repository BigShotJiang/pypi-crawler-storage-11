"""
RCT-Only Model - Hierarchical Bayesian model for RCT-only meta-analysis.

This module provides the RCTOnlyHBM class for meta-analysis of randomized
controlled trials without incorporating observational data.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import pandas as pd
import pymc as pm

from ..utils.enums import PriorSpecifications
from .base_model import Model


class RCTOnlyHBM(Model):
    """Builder for RCT-only hierarchical Bayesian meta-analysis models.

    This class implements a model for meta-analysis of randomized controlled trials (RCTs)
    without incorporating observational data. It estimates the overall treatment effect
    and between-study heterogeneity.
    """

    def __init__(self, logger: Optional[Any] = None) -> None:
        """Initialize the RCT-only model with a logger.

        Parameters
        ----------
        logger : logging.Logger, optional
            Logger instance to use. If None, a default logger will be created.
        """
        super().__init__(logger=logger)

    def get_required_data_columns(self) -> List[str]:
        """Define required columns for RCT-only meta-analysis.

        Returns
        -------
        List[str]
            List of required column names: ['experiment_est', 'experiment_est_se']
        """
        return ["experiment_est", "experiment_est_se"]

    def _prepare_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and prepare the model configuration.

        Validates the configuration and sets default values where needed.

        Parameters
        ----------
        config : Dict[str, Any]
            Configuration dictionary containing model settings and specifications

        Returns
        -------
        Dict[str, Any]
            Validated and prepared configuration dictionary

        Raises
        ------
        ValueError
            If the provided configuration is invalid
        """
        if config is None:
            raise ValueError("Configuration cannot be None")

        # Ensure data_driven_priors_settings section exists if config['data_driven_priors'] is True
        if config["data_driven_priors"] and "data_driven_priors_settings" not in config:
            raise ValueError(
                "'data_driven_priors_settings' section must be provided in configuration, if data_drive_priors is True"
            )

        # Validate prior settings for treatment effect
        if "treatment_effect" not in config["data_driven_priors_settings"]:
            raise ValueError(
                "'treatment_effect' section must be provided in 'data_driven_priors_settings' "
                "of the configuration, if data_drive_priors is True"
            )
        else:
            te_settings = config["data_driven_priors_settings"]["treatment_effect"]

        if "scale_prior_width_mean" not in te_settings:
            raise ValueError(
                "scale_prior_width_mean parameter must be provided in the 'treatment_effect' "
                "of 'data_driven_priors_settings' in the configuration"
            )
        if "scale_prior_width_sigma" not in te_settings:
            raise ValueError(
                "scale_prior_width_sigma parameter must be provided in the 'treatment_effect' "
                "of 'data_driven_priors_settings' in the configuration"
            )

        return config

    def _get_data_driven_priors(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Calculate data-driven priors based on input data.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing experiment data used to calculate priors

        Returns
        -------
        Dict[str, Any]
            Dictionary containing data-driven prior specifications
        """
        # Compute data-driven priors
        point_est_mean = data["experiment_est"].mean()
        point_est_sd = data["experiment_est"].std()

        # Get prior settings from config
        te_settings = self.config["data_driven_priors_settings"]["treatment_effect"]
        te_scale_mean = te_settings["scale_prior_width_mean"]
        te_scale_sigma = te_settings["scale_prior_width_sigma"]

        priors = {
            "mu_tau": {
                "delta_mu_tau": point_est_mean,
                "gamma_mu_tau": te_scale_mean * point_est_sd,
            },
            "sigma_tau": {"zeta_sigma_tau": te_scale_sigma * point_est_sd},
        }
        return priors

    def _validate_priors(self, priors: Dict[str, Any]) -> bool:
        """Validate that provided priors meet model requirements.

        Parameters
        ----------
        priors : Dict[str, Any]
            Dictionary of prior specifications to validate

        Returns
        -------
        bool
            True if priors are valid

        Raises
        ------
        ValueError
            If required priors are missing
        """
        # Use shared prior specifications from PriorSpecifications
        required_priors = PriorSpecifications.get_required_priors("rct_only")
        missing_priors = [p for p in required_priors if p not in priors]
        if missing_priors:
            raise ValueError(f"Missing required priors: {missing_priors}")
        return True

    def _set_variables_metadata(self) -> "RCTOnlyHBM":
        """Set up variable names for output tables and plots.

        Returns
        -------
        RCTOnlyHBM
            Self reference for method chaining
        """
        # Set variables for trace plots
        self.vars_trace_plot = ["mu_tau", "sigma_tau"]

        # Set variables for full summary tables
        self.vars_table_full = ["mu_tau", "sigma_tau"]

        # Set variables for short summary tables (default)
        self.vars_table_short = ["mu_tau"]

        # Set display names for variables
        self.vars_display_names = {
            "mu_tau": "Average treatment effect",
            "sigma_tau": "Std. dev. of treatment effects",
        }

        # Add posterior predictive variables if enabled
        if self.config["sampling_settings"]["n_sample_posterior"] > 0:
            posterior_vars = self.get_posterior_predictive_vars()
            self.vars_table_full.extend(posterior_vars)
            self.vars_table_short.append("tau_tilde")
            self.vars_display_names.update(
                {
                    "mean_tau_tilde": "Average treatment effect (posterior predictive)",
                    "tau_tilde": "Treatment effect in individual measurement",
                }
            )

        return self

    def get_posterior_predictive_vars(self) -> List[str]:
        """Get the names of variables to include in posterior predictive sampling.

        Returns
        -------
        List[str]
            List of variable names for posterior predictive sampling
        """
        return ["mean_tau_tilde", "tau_tilde"]

    def define_posterior_predictive_vars(self, n_samples: int) -> None:
        """Create posterior predictive variables in the PyMC model.

        Parameters
        ----------
        n_samples : int
            Number of posterior predictive samples to generate
        """
        # Create posterior predictive variables for RCTOnlyHBM
        mu_tau = self.pymc_model.mu_tau
        sigma_tau = self.pymc_model.sigma_tau

        # Treatment effect in individual measurement (posterior predictive, non-centered parametrization)
        z_tau_tilde = pm.Normal("z_tau_tilde", mu=0, sigma=1, shape=n_samples)
        tau_tilde = pm.Deterministic("tau_tilde", mu_tau + z_tau_tilde * sigma_tau)
        # Average treatment effect across simulated posterior predictive draws
        mean_tau_tilde = pm.Deterministic("mean_tau_tilde", pm.math.mean(tau_tilde))  # noqa: F841

    def _define_data(self, data: pd.DataFrame, model: Any) -> Dict[str, Any]:
        """Set up data variables in the PyMC model.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing data
        model : pm.Model
            PyMC model to add data variables to

        Returns
        -------
        Dict[str, Any]
            Dictionary containing data variables and number of observations
        """
        data_vars = {}

        # Number of observations
        data_vars["n_obs"] = len(data)

        # Experiment (RCT) data
        data_vars["tau_experiment_est"] = pm.Data("tau_experiment_est", data["experiment_est"].values)  # point estimate
        data_vars["sigma_experiment_est"] = pm.Data(
            "sigma_experiment_est", data["experiment_est_se"].values
        )  # standard error

        return data_vars

    def build(self, data: pd.DataFrame) -> "RCTOnlyHBM":
        """Build PyMC model for RCT-only meta-analysis.

        Parameters
        ----------
        data : pd.DataFrame
            DataFrame containing RCT point estimates with standard errors

        Returns
        -------
        RCTOnlyHBM
            Self reference for method chaining
        """
        with pm.Model() as pymc_model:
            # Set up data variables
            data_vars = self._define_data(data, pymc_model)
            n_obs = data_vars["n_obs"]

            # Priors on model parameters
            mu_tau = pm.Normal(
                "mu_tau",
                mu=self.priors["mu_tau"]["delta_mu_tau"],
                sigma=self.priors["mu_tau"]["gamma_mu_tau"],
            )
            sigma_tau = pm.HalfCauchy("sigma_tau", beta=self.priors["sigma_tau"]["zeta_sigma_tau"])

            # Model
            # Non-centered parametrization for true experiment draw
            z_tau = pm.Normal("z_tau", mu=0, sigma=1, shape=n_obs)
            tau = pm.Deterministic("tau", mu_tau + z_tau * sigma_tau)

            # Likelihood for observable variables in the model
            tau_experiment_est_likelihood = pm.Normal(  # noqa: F841
                "tau_experiment_est_likelihood",
                mu=tau,
                sigma=data_vars["sigma_experiment_est"],
                observed=data_vars["tau_experiment_est"],
            )

        self._set_variables_metadata()  # specify the list of variables for output tables and plots
        self.pymc_model = pymc_model
        self.logger.info(f"{self.__class__.__name__} model built successfully")
        return self

    def build_calibration_model(self, df_unpaired: pd.DataFrame, trace: Any) -> Any:
        """Build a calibration model for unpaired observational data.

        RCT-only models do not support calibration as they do not incorporate
        observational data or bias estimation.

        Parameters
        ----------
        df_unpaired : pd.DataFrame
            DataFrame containing unpaired observational estimates
        trace : Any
            Posterior samples from fitted model

        Returns
        -------
        Any
            PyMC model for calibration

        Raises
        ------
        NotImplementedError
            Always raised as RCT-only models do not support calibration
        """
        raise NotImplementedError(
            "Calibration is not supported for RCT-only models. "
            "Use 'standard' or 'scaled' model types for calibration functionality."
        )

"""
Data Structures - Container classes for BBAM results and data.

This module provides data structure classes for organizing and accessing
BBAM analysis results in a convenient format.
"""

from .calibration_results import CalibrationResults

__all__ = ["CalibrationResults"]

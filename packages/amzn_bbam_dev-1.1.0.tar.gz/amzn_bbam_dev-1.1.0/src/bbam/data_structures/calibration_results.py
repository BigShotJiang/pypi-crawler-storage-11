"""
Calibration Results - Container for calibration output with convenient access methods.

This module provides the CalibrationResults class that wraps calibration outputs
and provides convenient access to calibrated values and uncertainties.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd


class CalibrationResults:
    """Container for calibration results with convenient access methods.

    This class provides a clean interface for accessing calibrated estimates,
    uncertainties, and credible intervals from the calibration process.
    """

    def __init__(
        self,
        means: np.ndarray,
        uncertainties: np.ndarray,
        hdi_lower: np.ndarray,
        hdi_upper: np.ndarray,
        summary: pd.DataFrame,
        trace: Any,
        original_data: pd.DataFrame,
    ) -> None:
        """Initialize calibration results.

        Parameters
        ----------
        means : np.ndarray
            Array of calibrated point estimates
        uncertainties : np.ndarray
            Array of calibrated standard errors
        hdi_lower : np.ndarray
            Array of lower HDI bounds
        hdi_upper : np.ndarray
            Array of upper HDI bounds
        summary : pd.DataFrame
            ArviZ summary DataFrame with full statistics
        trace : Any
            Raw calibration trace for advanced analysis
        original_data : pd.DataFrame
            Original unpaired data that was calibrated
        """
        self.values = means
        self.uncertainties = uncertainties
        self.hdi_lower = hdi_lower
        self.hdi_upper = hdi_upper
        self.summary = summary
        self.trace = trace
        self._original_data = original_data.copy()

    def to_dataframe(self) -> pd.DataFrame:
        """Convert results to a pandas DataFrame.

        Returns
        -------
        pd.DataFrame
            DataFrame with original data and calibration results
        """
        result_df = self._original_data.copy()
        result_df["calibrated_estimate"] = self.values
        result_df["calibrated_se"] = self.uncertainties
        result_df["hdi_lower"] = self.hdi_lower
        result_df["hdi_upper"] = self.hdi_upper
        return result_df

    def __repr__(self) -> str:
        """String representation of calibration results."""
        return f"CalibrationResults(n_obs={len(self.values)}, " f"mean_calibrated={np.mean(self.values):.4f})"

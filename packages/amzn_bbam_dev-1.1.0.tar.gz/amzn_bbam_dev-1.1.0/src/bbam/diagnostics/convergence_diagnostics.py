import logging
from typing import Any, Dict

import arviz as az
import numpy as np

from ..types import ConfigDict, ConvergenceResult, InferenceDataProtocol, LoggerType


class ConvergenceDiagnostics:
    """
    Class to handle MCMC convergence diagnostics with configurable warning levels.

    This class provides methods to analyze various MCMC convergence diagnostics
    including divergent transitions, maximum tree depth, R-hat, effective sample
    size (ESS), and ESS ratio. It uses configurable thresholds to determine
    whether diagnostics indicate potential issues.

    Attributes:
        config: Configuration dictionary loaded from YAML containing warning levels and sampling settings
        thresholds: Warning thresholds for various diagnostics extracted from config
        logger: Logger instance for outputting diagnostic information
    """

    config: ConfigDict
    thresholds: Dict[str, Any]
    logger: LoggerType

    def __init__(
        self,
        config: ConfigDict,
        logger: LoggerType,
    ):
        """
        Initialize diagnostics with specified warning level and thresholds.

        Args:
            config: Configuration dictionary containing warning levels and sampling settings
            logger: Logger instance to use
        """
        self.config = config
        self.thresholds = self._validate_config_parameters(logger)
        self.logger = logging.getLogger(f"{logger.name}.convergence_diagnostics")

    def _validate_config_parameters(self, logger: logging.Logger) -> Dict[str, Any]:
        """
        Validate configuration parameters and set defaults for missing values.

        This method ensures that all required threshold parameters exist in the
        configuration, providing sensible defaults if any are missing. It also
        validates the overall config structure.

        Args:
            logger: Logger instance for warning messages

        Returns:
            Dictionary containing validated threshold parameters
        """
        # Validate config structure and extract thresholds with fallbacks
        thresholds: Dict[str, Any] = {}
        try:
            # Check if warning_level_setting exists in config
            if "warning_level_setting" not in self.config:
                logger.warning("Missing 'warning_level_setting' in config, using default: 'normal'")
                warning_level = "normal"
            else:
                warning_level = self.config["warning_level_setting"]

            # Check if warning_level_definition exists in config
            if "warning_level_definition" not in self.config:
                logger.warning("Missing 'warning_level_definition' in config, using default thresholds")
            else:
                # Check if the specific warning level exists in the definition
                if warning_level not in self.config["warning_level_definition"]:
                    logger.warning(f"Warning level '{warning_level}' not found in config, using default thresholds")
                else:
                    thresholds = self.config["warning_level_definition"][warning_level].copy()
        except (KeyError, TypeError) as e:
            logger.warning(f"Error accessing config structure: {e}. Using default thresholds")

        # Ensure all required thresholds exist
        required_thresholds = ["fraction_divergent_threshold", "rhat_threshold", "ess_threshold", "ess_ratio_threshold"]

        # Add default values for any missing thresholds
        defaults = {
            "fraction_divergent_threshold": 0.0,
            "rhat_threshold": 1.01,
            "ess_threshold": 1000,
            "ess_ratio_threshold": 0.1,
        }

        for threshold in required_thresholds:
            if threshold not in thresholds:
                thresholds[threshold] = defaults[threshold]
                logger.warning(f"Missing threshold '{threshold}', using default: {defaults[threshold]}")

        return thresholds

    def has_divergent_transitions(self, idata: InferenceDataProtocol) -> bool:
        """
        Analyze divergent transitions in the MCMC chains and provide recommendations.

        Counts the number and percentage of divergent transitions across all chains
        and compares against configured thresholds. Divergent transitions indicate
        potential issues with convergence.

        Args:
            idata: InferenceData object containing MCMC samples and diagnostics

        Returns:
            True if the percentage of divergent transitions exceeds the threshold,
            False otherwise
        """
        self.logger.info("")
        self.logger.info("=== Analyzing divergent transitions ===")

        n_divergent = idata.sample_stats["diverging"].values.sum()
        self.logger.info(f"Total number of divergent transitions: {n_divergent}")

        percent_divergent = (n_divergent / idata.sample_stats["diverging"].size) * 100.0
        self.logger.info(f"Percentage of divergent transitions: {percent_divergent:.2f}%")

        divergences_per_chain = idata.sample_stats["diverging"].sum(dim="draw").values
        self.logger.info("Divergences per chain:")
        for chain_idx, n_divs in enumerate(divergences_per_chain):
            self.logger.info(f"  Chain {chain_idx}: {n_divs} divergences")

        if percent_divergent > 100.0 * self.thresholds["fraction_divergent_threshold"]:
            has_issues = True
            self.logger.warning("Number of divergent transitions exceeds threshold!")
            self.logger.info("Suggestions for improvement:")
            # Safely access sampling_settings with fallback
            try:
                target_accept = self.config.get("sampling_settings", {}).get("target_accept", "unknown")
                self.logger.info(f"  - Consider increasing target_accept (currently {target_accept})")
            except (KeyError, TypeError):
                self.logger.info("  - Consider increasing target_accept parameter")
        else:
            has_issues = False
            if percent_divergent > 0:
                self.logger.info("Divergent transitions present but below threshold.")
            else:
                self.logger.info("No divergences detected.")

        return has_issues

    def is_max_treedepth_reached(self, idata: InferenceDataProtocol) -> bool:
        """
        Analyze maximum tree depth issues in the MCMC chains.

        Checks if any chains hit the maximum tree depth constraint, which can
        indicate potential biases in the posterior.

        Args:
            idata: InferenceData object containing MCMC samples and diagnostics

        Returns:
            True if any chains hit the maximum tree depth, False otherwise
        """
        self.logger.info("")
        self.logger.info("=== Analyzing max tree depth constraint ===")

        max_treedepth_reached = np.max(idata.sample_stats.depth.values)
        chains_hit_max = sum(idata.sample_stats.maxdepth_reached.values.any(axis=1))

        self.logger.info(f"Highest tree depth reached across all chains: {max_treedepth_reached}")
        self.logger.info(
            f"{chains_hit_max} chains out of {idata.posterior.sizes['chain']} " "hit max tree depth constraint"
        )

        if chains_hit_max > 0:
            has_issues = True
            # Safely access sampling_settings with fallback
            try:
                maxdepth = self.config.get("sampling_settings", {}).get("maxdepth", "unknown")
                self.logger.warning(f"Consider increasing max_treedepth parameter (currently {maxdepth})")
            except (KeyError, TypeError):
                self.logger.warning("Consider increasing max_treedepth parameter")
        else:
            has_issues = False

        return has_issues

    def has_rhat_convergence_issues(self, idata: InferenceDataProtocol, detailed_output: bool = False) -> bool:
        """
        Analyze R-hat convergence diagnostic for all parameters.

        R-hat (Gelman-Rubin statistic) measures convergence between chains.
        Values close to 1.0 indicate good convergence, while values significantly
        above 1.0 suggest that chains have not mixed well.

        Args:
            idata: InferenceData object containing MCMC samples and diagnostics
            detailed_output : Whether to print R-hat values for all parameters

        Returns:
            True if any parameter's R-hat exceeds the threshold, False otherwise
        """
        self.logger.info("")
        self.logger.info("=== Analyzing R-hat values ===")
        rhat_values = az.rhat(idata)
        problems = {}

        self.logger.info("R-hat values for all parameters:")
        for name, value in rhat_values.items():
            rhat = float(value.max() if value.size > 1 else value)

            # Check for invalid R-hat values (NaN or infinite)
            if np.isnan(rhat) or np.isinf(rhat):
                problems[name] = float("inf")  # Mark as problematic
                self.logger.warning(f"  - {name}: Invalid R-hat (NaN/Inf) indicates severe convergence issues")
            else:
                self.logger.info(f"  - {name}: {rhat:.4f}")
                if rhat > self.thresholds["rhat_threshold"]:
                    problems[name] = rhat
                if detailed_output:
                    self.logger.info(f"  - {name}: R-hat = {rhat:.4f}")

        if not problems:
            self.logger.info(f"All parameters show good convergence (R-hat ≤ {self.thresholds['rhat_threshold']})")
            return False

        self.logger.warning(f"R-hat exceeds threshold ({self.thresholds['rhat_threshold']}) for:")
        for param, rhat in problems.items():
            self.logger.warning(f"  - {param}: {rhat:.4f}")
        self.logger.info("R-hat values > 1 indicate lack of convergence between chains")
        self.logger.info("Suggestions for improvement:")
        self.logger.info("  - Increase the number of tuning iterations")
        self.logger.info("  - Increase the number of draws")
        self.logger.info("  - Check for model specification issues")
        return True

    def is_low_ess(self, idata: InferenceDataProtocol, detailed_output: bool = False) -> bool:
        """
        Analyze Effective Sample Size (ESS) for all parameters.

        ESS measures how many independent samples the MCMC chains effectively
        contain. Low ESS values indicate high autocorrelation and potentially
        unreliable posterior estimates.

        Args:
            idata: InferenceData object containing MCMC samples and diagnostics
            detailed_output: Whether to print ESS values for all parameters

        Returns:
            True if any parameter's ESS is below the threshold, False otherwise
        """
        self.logger.info("")
        self.logger.info("=== Analyzing ESS ===")

        ess_values = az.ess(idata)
        problems = {}

        for name, value in ess_values.items():
            ess = float(value.min() if value.size > 1 else value)

            # Check for invalid ESS values (NaN or infinite)
            if np.isnan(ess) or np.isinf(ess):
                problems[name] = 0.0  # Mark as problematic with zero ESS
                self.logger.warning(f"  - {name}: Invalid ESS (NaN/Inf) indicates severe sampling issues")
            else:
                if ess < self.thresholds["ess_threshold"]:
                    problems[name] = ess
                if detailed_output:
                    self.logger.info(f"  - {name}: ESS = {ess:.0f}")

        if not problems:
            self.logger.info(f"All parameters show good ESS values (ESS ≥ {self.thresholds['ess_threshold']})")
            return False

        self.logger.warning(f"ESS below threshold ({self.thresholds['ess_threshold']}) for:")
        for param, ess in problems.items():
            self.logger.warning(f"  - {param}: ESS = {ess:.0f}")
        self.logger.info("Suggestions for improvement:")
        self.logger.info("  - Increase the number of draws")
        return True

    def is_low_ess_ratio(self, idata: InferenceDataProtocol, detailed_output: bool = False) -> bool:
        """
        Analyze ESS ratio (effective samples / total samples) for all parameters.

        ESS ratio measures sampling efficiency. Low ratios indicate inefficient
        sampling but may still produce reliable posterior estimates if absolute
        ESS values are acceptable.

        Args:
            idata: InferenceData object containing MCMC samples and diagnostics
            detailed_output: Whether to print ESS ratio values for all parameters

        Returns:
            True if any parameter's ESS ratio is below the threshold, False otherwise
        """
        self.logger.info("")
        self.logger.info("=== Analyzing ESS ratio ===")

        ess_values = az.ess(idata)
        problems = {}
        total_samples = len(idata.posterior.draw) * len(idata.posterior.chain)

        for name, value in ess_values.items():
            ess = float(value.min() if value.size > 1 else value)
            ratio = ess / total_samples
            if ratio < self.thresholds["ess_ratio_threshold"]:
                problems[name] = (ess, ratio)
            if detailed_output:
                self.logger.info(f"  - {name}: ESS = {ess:.0f}, ratio = {ratio:.1%}")

        if not problems:
            self.logger.info(
                f"All parameters show good ESS ratios (ratio ≥ {self.thresholds['ess_ratio_threshold']:.1%})"
            )
            return False

        self.logger.warning(f"ESS ratio below threshold ({self.thresholds['ess_ratio_threshold']:.1%}) for:")
        for param, (ess, ratio) in problems.items():
            self.logger.warning(f"  - {param}: ESS = {ess:.0f}, ratio = {ratio:.1%}")

        if all(ess >= self.thresholds["ess_threshold"] for ess, _ in problems.values()):
            self.logger.info(
                "Note: While ESS ratios are low, absolute ESS values are acceptable."
                "This indicates inefficient sampling but likely reliable posterior estimates."
                "For complex models, some inefficiency in sampling might be expected."
            )

        self.logger.info("Suggestions for improvement:")
        self.logger.info("  - Check for model specification/parametrization issues")
        return True

    def has_passed_convergence_checks(self, idata: InferenceDataProtocol) -> ConvergenceResult:
        """
        Run all convergence diagnostics and provide a comprehensive summary.

        Executes all diagnostic checks (divergent transitions, maximum tree depth,
        R-hat) and provides an overall assessment of MCMC convergence quality.

        Args:
            idata : InferenceData object containing MCMC samples and diagnostics

        Returns:
            ConvergenceResult containing detailed information about which checks
            passed or failed, allowing callers to make informed decisions
        """
        self.logger.info("Getting diagnostics summary")
        results = {
            "has_divergent_transitions": self.has_divergent_transitions(idata),
            "is_max_treedepth_reached": self.is_max_treedepth_reached(idata),
            "has_rhat_convergence_issues": self.has_rhat_convergence_issues(idata),
            "is_low_ess": self.is_low_ess(idata),
            "is_low_ess_ratio": self.is_low_ess_ratio(idata),
        }
        self.logger.info("")
        self.logger.info("=== CONVERGENCE CHECKS SUMMARY ===")

        issues = [check for check, has_issues in results.items() if has_issues]
        if not issues:
            self.logger.info("All diagnostics look good! No convergence issues detected.")
            return ConvergenceResult(passed=True, failed_checks=[], results=results)

        # Special case: If only ESS ratio fails but the rest of checks pass
        only_ess_ratio_issue = (
            results["is_low_ess_ratio"]
            and not results["is_low_ess"]
            and not results["has_rhat_convergence_issues"]
            and not results["has_divergent_transitions"]
            and not results["is_max_treedepth_reached"]
        )
        if only_ess_ratio_issue:
            self.logger.info("R-hat and ESS indicate good convergence.")
            self.logger.info("ESS ratio indicates inefficient sampling, which might be expected for complex models.")
            return ConvergenceResult(passed=True, failed_checks=issues, results=results)

        self.logger.warning("Convergence issues detected!")
        self.logger.warning("The following diagnostics indicate problems:")
        for issue in issues:
            self.logger.warning(f"  - {issue}")
        return ConvergenceResult(passed=False, failed_checks=issues, results=results)

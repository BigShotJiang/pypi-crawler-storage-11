# BBAM Package Interface Specification

## Overview

This document specifies the package interfaces for the Bayesian Bias Assessment Model (BBAM), detailing how teams can integrate with the package through direct usage or wrapper libraries. The specification covers class interfaces, method signatures, configuration options, and usage patterns.

## Core Classes

### BbamAnalyzer

The primary class for interacting with the BBAM package. This class serves as the main entry point for all model operations.

```python
class BbamAnalyzer:
    def __init__(self, model_type='standard', config=None, run_id=None, logger=None):
        """Initialize the BBAM model.
        
        Args:
            model_type (str): Model variant to use. Options:
                - 'standard': Basic HBM using observational-RCT pairs
                - 'rct_only': Model using only RCT data without observational pairs
                - 'campaign_size': Extended model incorporating campaign size metrics (NOT YET IMPLEMENTED)
            config (dict, str, Optional): Configuration dictionary or path to configuration file.
                If None, default configuration is used.
            run_id (str, Optional): Unique identifier for the run. If None, a timestamp-based ID 
                will be generated. Used for organizing output files and tracking analysis runs.
            logger (logging.Logger, Optional): Logger instance to use. If None, a default logger 
                will be created.
        
        Returns:
            BbamAnalyzer: Initialized model instance
        
        Raises:
            ValueError: If model_type is not one of the supported options
            ConfigurationError: If configuration is invalid
        """
        pass

    def fit(self, data, **kwargs):
        """Fit the model to the provided data.
        
        Args:
            data (pandas.DataFrame): DataFrame containing RCT and observational data.
                Required columns depend on the model_type:
                - 'standard': 'obs_model_est', 'obs_model_est_se', 'experiment_est', 'experiment_est_se'
                - 'campaign_size': Additional 'campaign_size' column
                - 'rct_only': Only 'experiment_est' and 'experiment_est_se' required
            **kwargs: Additional model-specific parameters:
                - chains (int): Number of sampling chains (default: 4)
                - iterations (int): Number of sampling iterations (default: 2000)
                - burn_in (int): Number of burn-in samples (default: 1000)
                - seed (int): Random seed for reproducibility
        
        Returns:
            self: The fitted model instance
            
        Raises:
            DataValidationError: If data does not contain required columns
            ModelFittingError: If model fails to converge
        """
        pass

    def calibrate(self, target_data, **kwargs):
        """Calibrate observational estimates using the fitted model.
        
        Args:
            target_data (pandas.DataFrame): DataFrame with observational data to calibrate.
                Required columns: 'obs_model_est', 'obs_model_est_se'
            **kwargs: Additional calibration parameters:
                - method (str): Calibration method ('additive', 'multiplicative')
                - uncertainty (bool): Whether to propagate uncertainty (default: True)
        
        Returns:
            pandas.DataFrame: Calibrated estimates with columns:
                - 'calibrated_estimate': Calibrated point estimate
                - 'calibrated_se': Standard error of calibrated estimate
                - 'hdi_low': Lower bound of 90% HDI
                - 'hdi_high': Upper bound of 90% HDI
            
        Raises:
            ModelNotFittedError: If called before model fitting
            DataValidationError: If target_data lacks required columns
        """
        pass

    def get_results(self, format='dataframe'):
        """Get model results.
        
        Args:
            format (str): Output format ('dataframe', 'dict', 'json')
            
        Returns:
            Union[pandas.DataFrame, dict, str]: Model results in the specified format.
            The results include:
                - Model parameters
                - Convergence metrics
                - Average true effect (posterior)
                - Expected model bias
                - Expected observational value
                - HDI bounds (5% and 95%)
                - Standard errors
        
        Raises:
            ModelNotFittedError: If called before model fitting
            ValueError: If format is not one of the supported options
        """
        pass

    def get_samples(self, parameter=None):
        """Get raw posterior samples from the model.
        
        Args:
            parameter (str, Optional): Specific parameter to retrieve samples for.
                If None, returns samples for all parameters.
                
        Returns:
            dict or numpy.ndarray: Dictionary of parameter samples or array for a specific parameter
            
        Raises:
            ModelNotFittedError: If called before model fitting
            ValueError: If parameter name is invalid
        """
        pass

    def plot(self, plot_type, **kwargs):
        """Generate plots from model results.
        
        Args:
            plot_type (str): Type of plot to generate. Options:
                - 'bias': Distribution of bias parameters
                - 'true_effect': Distribution of true effect
                - 'calibration': Comparison of pre/post calibration
                - 'diagnostics': Convergence diagnostics
                - 'scatter': Scatter plot of RCT vs observational
            **kwargs: Additional plotting parameters:
                - output_path (str): Path to save the plot
                - format (str): File format ('png', 'pdf', 'svg')
                - figsize (tuple): Figure size as (width, height)
                - dpi (int): Resolution for raster formats
        
        Returns:
            matplotlib.Figure: Plot object (if output_path is None)
            str: Path to saved file (if output_path is provided)
            
        Raises:
            ModelNotFittedError: If called before model fitting
            ValueError: If plot_type is not supported
        """
        pass

    def save(self, path, include_samples=False):
        """Save model results and configuration to disk.
        
        Args:
            path (str): Directory path to save results
            include_samples (bool): Whether to save raw posterior samples (default: False)
            
        Returns:
            dict: Dictionary of saved file paths
            
        Raises:
            IOError: If saving fails
        """
        pass

    @classmethod
    def load(cls, path):
        """Load a previously saved model.
        
        Args:
            path (str): Path to saved model directory or file
            
        Returns:
            BbamAnalyzer: Loaded model instance
            
        Raises:
            FileNotFoundError: If model file not found
            ValueError: If file format is invalid
        """
        pass

    def get_diagnostics(self):
        """Get model convergence diagnostics.
        
        Returns:
            dict: Dictionary of diagnostic metrics including:
                - 'r_hat': Gelman-Rubin statistic
                - 'effective_sample_size': Effective sample size
                - 'divergences': Number of divergent transitions
                - 'energy': E-BFMI values
        
        Raises:
            ModelNotFittedError: If called before model fitting
        """
        pass
```

### ConfigManager

Class for managing model configuration, including priors and sampling parameters.

```python
class ConfigManager:
    def __init__(self, config=None):
        """Initialize the configuration manager.
        
        Args:
            config (dict, str, Optional): Configuration dictionary or path to configuration file.
                If None, default configuration is used.
        
        Raises:
            ConfigurationError: If configuration is invalid
        """
        pass
    
    def set_prior(self, parameter, prior_spec):
        """Set prior distribution for a specific parameter.
        
        Args:
            parameter (str): Name of the parameter
            prior_spec (dict): Prior specification with distribution type and parameters
                Example: {'distribution': 'normal', 'mu': 0, 'sigma': 1}
                
        Returns:
            self: The updated configuration manager
            
        Raises:
            ValueError: If parameter or prior specification is invalid
        """
        pass
    
    def get_prior(self, parameter):
        """Get prior distribution for a specific parameter.
        
        Args:
            parameter (str): Name of the parameter
            
        Returns:
            dict: Prior specification
            
        Raises:
            ValueError: If parameter is not found
        """
        pass
    
    def set_sampling_params(self, **params):
        """Set sampling parameters.
        
        Args:
            **params: Sampling parameters including:
                - chains (int): Number of sampling chains
                - iterations (int): Number of sampling iterations
                - burn_in (int): Number of burn-in samples
                - seed (int): Random seed for reproducibility
                - adaptation_window (int): Number of adaptation steps
                
        Returns:
            self: The updated configuration manager
        """
        pass
    
    def save(self, path):
        """Save configuration to file.
        
        Args:
            path (str): Path to save configuration file
            
        Returns:
            str: Path to saved file
            
        Raises:
            IOError: If saving fails
        """
        pass
    
    @classmethod
    def load(cls, path):
        """Load configuration from file.
        
        Args:
            path (str): Path to configuration file
            
        Returns:
            ConfigManager: Loaded configuration manager
            
        Raises:
            FileNotFoundError: If configuration file not found
            ValueError: If file format is invalid
        """
        pass
```

### DataProcessor

Class for handling and validating input data.

```python
class DataProcessor:
    def __init__(self, model_type='standard'):
        """Initialize the data processor.
        
        Args:
            model_type (str): Model type to determine required columns
                
        Raises:
            ValueError: If model_type is not supported
        """
        pass
    
    def validate_data(self, data, for_calibration=False):
        """Validate input data format and contents.
        
        Args:
            data (pandas.DataFrame): Input data
            for_calibration (bool): Whether this is calibration target data
            
        Returns:
            bool: True if data is valid
            
        Raises:
            DataValidationError: If data validation fails, with details on missing columns or format issues
        """
        pass
    
    def prepare_data(self, data):
        """Prepare data for model fitting.
        
        Args:
            data (pandas.DataFrame): Input data
            
        Returns:
            dict: Prepared data structures for model fitting
            
        Raises:
            DataValidationError: If data cannot be prepared
        """
        pass
```

## Configuration Specification

### Configuration File Format

BBAM supports configuration via Python dictionaries or YAML files. The structure follows this format:

```python
{
    "data_driven_priors": False,
    "priors": {
        # Model-specific priors (see Default Priors section)
    },
    "sampling_settings": {
        "tune": 1000,           # Number of tuning (burn-in) samples
        "draws": 1000,          # Number of posterior samples
        "chains": 4,            # Number of MCMC chains
        "cores": 4,             # Number of CPU cores to use
        "target_accept": 0.8,   # Target acceptance rate
        "maxdepth": 10,         # Maximum tree depth for NUTS sampler
        "n_sample_posterior": 0, # Number of posterior predictive samples
        "is_random_seed": False, # Whether to use random seed
        "seed": 42              # Random seed for reproducibility
    },
    "model_settings": {
        "bias_spec": "BOTH_INT_MULT",        # Bias specification: BOTH_INT_MULT, ONLY_INT, ONLY_MULT
        "likelihood_distribution": "normal"   # Likelihood distribution: normal, student_t
    },
    "results_settings": {
        "prob_interval": 0.9,     # Probability for credible intervals
        "round_to": 6,            # Number of decimal places for rounding
        "interval_type": "HDI"    # Interval type: HDI or ETI
    },
    "warning_level_setting": "normal",  # Warning level: normal or relaxed
    "warning_level_definition": {
        "normal": {"rhat_threshold": 1.01},
        "relaxed": {"rhat_threshold": 1.05}
    }
}
```

### Prior Distributions

The following prior distributions are supported:

| Distribution | Parameters | Description |
|--------------|------------|-------------|
| normal | mu, sigma | Normal distribution |
| student_t | nu, mu, sigma | Student's t-distribution |
| half_normal | sigma | Half-normal distribution |
| uniform | lower, upper | Uniform distribution |
| beta | alpha, beta | Beta distribution |
| gamma | alpha, beta | Gamma distribution |

### Default Priors

The default priors for each model variant use a parameterization specific to BBAM's implementation:

#### RCT-Only Model
```python
{
    "mu_tau": {
        "delta_mu_tau": 0.0,    # Location parameter for mu_tau prior
        "gamma_mu_tau": 1.0     # Scale parameter for mu_tau prior
    },
    "sigma_tau": {
        "zeta_sigma_tau": 1.0   # Scale parameter for sigma_tau half-normal prior
    }
}
```

#### Standard Model (Observational + RCT)
```python
{
    "mu_tau": {
        "delta_mu_tau": 0.0,    # Location parameter for mu_tau (true effect) prior
        "gamma_mu_tau": 1.0     # Scale parameter for mu_tau prior
    },
    "sigma_tau": {
        "zeta_sigma_tau": 1.0   # Scale parameter for sigma_tau half-normal prior
    },
    "mu_beta_0": {
        "delta_beta_0": 0.0,    # Location parameter for bias intercept prior
        "gamma_beta_0": 1.0     # Scale parameter for bias intercept prior
    },
    "sigma_beta_0": {
        "zeta_beta_0": 1.0      # Scale parameter for bias intercept variance prior
    },
    "mu_beta_1": {
        "delta_beta_1": 1.0,    # Location parameter for bias slope prior
        "gamma_beta_1": 0.5     # Scale parameter for bias slope prior
    },
    "sigma_beta_1": {
        "zeta_beta_1": 0.5      # Scale parameter for bias slope variance prior
    }
}
```

#### Campaign Size Model (Not Yet Implemented)
```python
{
    # Will extend Standard Model with additional campaign-size related parameters
    # Implementation pending
}
```

**Note**: The prior parameterization uses BBAM-specific parameter names that correspond to the underlying statistical model structure. These parameters define Normal and Half-Normal priors in the hierarchical Bayesian model.

## Integration Patterns

### Direct Usage

```python
import pandas as pd
from bbam import BbamAnalyzer

# Load data
data = pd.read_csv("rct_obs_pairs.csv")

# Initialize and fit model
model = BbamAnalyzer(model_type="standard")
model.fit(data)

# Get results
results = model.get_results()
print(results)

# Generate and save plots
model.plot("bias", output_path="bias_plot.png")
model.plot("true_effect", output_path="true_effect_plot.png")

# Save model results
model.save("./model_results/")
```

### Using Custom Configuration

```python
import pandas as pd
from bbam import BbamAnalyzer, ConfigManager

# Create custom configuration
config = {
    "model": {
        "type": "campaign_size",
        "priors": {
            "mu_beta": {"distribution": "normal", "mu": 0, "sigma": 2},
            "sigma_beta": {"distribution": "half_normal", "sigma": 2}
        }
    },
    "sampling": {
        "chains": 6,
        "iterations": 3000,
        "seed": 42
    }
}

# Load data
data = pd.read_csv("campaign_data.csv")

# Initialize and fit model with custom config
model = BbamAnalyzer(model_type="campaign_size", config=config)
model.fit(data)

# Get and export results
results = model.get_results(format="dataframe")
results.to_csv("model_results.csv")
```

### Calibration Workflow

```python
import pandas as pd
from bbam import BbamAnalyzer

# Load training data (RCT-Observational pairs)
training_data = pd.read_csv("training_pairs.csv")

# Load target data (Observational only, to be calibrated)
target_data = pd.read_csv("target_obs.csv")

# Initialize and fit model
model = BbamAnalyzer(model_type="standard")
model.fit(training_data)

# Calibrate target observational estimates
calibrated = model.calibrate(target_data)

# Save calibrated results
calibrated.to_csv("calibrated_results.csv")

# Generate calibration plot
model.plot("calibration", output_path="calibration_plot.png")
```

### Team Wrapper Example

```python
from team_pipeline import DataLoader, ResultsWriter
from bbam import BbamAnalyzer

class TeamBbamWrapper:
    def __init__(self, config_path=None):
        """Initialize the team-specific BBAM wrapper.
        
        Args:
            config_path (str, Optional): Path to team configuration file
        """
        self.config = self._load_team_config(config_path)
        self.bbam = BbamAnalyzer(
            model_type=self.config.get("model_type", "standard"),
            config=self.config.get("bbam_config")
        )
        
    def _load_team_config(self, config_path):
        # Team-specific configuration loading
        pass
        
    def run_assessment(self, input_data_path, output_path):
        """Run full assessment workflow.
        
        Args:
            input_data_path (str): Path to team-specific input data
            output_path (str): Path to write results
            
        Returns:
            dict: Assessment results and metrics
        """
        # Load and transform data to BBAM format
        loader = DataLoader()
        bbam_data = loader.transform(input_data_path)
        
        # Run BBAM model
        self.bbam.fit(bbam_data)
        results = self.bbam.get_results()
        
        # Transform and write results in team-specific format
        writer = ResultsWriter(output_path)
        writer.write(results)
        
        # Generate team-specific reports
        self._generate_team_reports(results, output_path)
        
        return results
        
    def _generate_team_reports(self, results, output_path):
        # Team-specific reporting logic
        pass
```

## Data Format Requirements

### Input Data Format

#### Standard Model

Required columns:
- `obs_model_est`: Observational model point estimate
- `obs_model_est_se`: Standard error of observational estimate
- `experiment_est`: RCT point estimate
- `experiment_est_se`: Standard error of RCT estimate

Optional metadata columns (any additional columns are preserved and included in output):
- `campaign_id`: Unique identifier for each campaign
- `country`: Country code
- `channel`: Marketing channel

Example:
```
campaign_id,country,channel,obs_model_est,obs_model_est_se,experiment_est,experiment_est_se
1,US,SEARCH,0.15,0.02,0.12,0.03
2,UK,DISPLAY,0.08,0.01,0.06,0.02
3,DE,SOCIAL,0.22,0.03,0.18,0.04
```

#### Campaign Size Model

Additional required column:
- `campaign_size`: Metric of campaign size (impressions, spend, or treated units)

Example:
```
campaign_id,country,channel,obs_model_est,obs_model_est_se,experiment_est,experiment_est_se,campaign_size
1,US,SEARCH,0.15,0.02,0.12,0.03,1000000
2,UK,DISPLAY,0.08,0.01,0.06,0.02,500000
3,DE,SOCIAL,0.22,0.03,0.18,0.04,750000
```

#### RCT-Only Model

Required columns:
- `experiment_est`: RCT point estimate
- `experiment_est_se`: Standard error of RCT estimate

Example:
```
campaign_id,country,channel,experiment_est,experiment_est_se
1,US,SEARCH,0.12,0.03
2,UK,DISPLAY,0.06,0.02
3,DE,SOCIAL,0.18,0.04
```

#### Calibration Target Data

Required columns:
- `obs_model_est`: Observational model point estimate
- `obs_model_est_se`: Standard error of observational estimate

Example:
```
campaign_id,country,channel,obs_model_est,obs_model_est_se
4,FR,SEARCH,0.18,0.02
5,IT,DISPLAY,0.10,0.01
6,ES,SOCIAL,0.25,0.03
```

### Output Data Format

#### Model Results DataFrame

Contains the following columns:
- All input metadata columns
- `true_effect_mean`: Posterior mean of true effect
- `true_effect_se`: Standard error of true effect estimate
- `true_effect_hdi_low`: Lower bound of 90% HDI for true effect
- `true_effect_hdi_high`: Upper bound of 90% HDI for true effect
- `bias_mean`: Posterior mean of bias
- `bias_se`: Standard error of bias estimate
- `bias_hdi_low`: Lower bound of 90% HDI for bias
- `bias_hdi_high`: Upper bound of 90% HDI for bias
- `convergence_metrics`: Dictionary of convergence statistics

#### Calibrated Results DataFrame

Contains the following columns:
- All input metadata columns
- `obs_model_est`: Original observational estimate
- `obs_model_est_se`: Original standard error
- `calibrated_estimate`: Calibrated point estimate
- `calibrated_se`: Standard error of calibrated estimate
- `calibrated_hdi_low`: Lower bound of 90% HDI for calibrated estimate
- `calibrated_hdi_high`: Upper bound of 90% HDI for calibrated estimate

## Configuration Validation

BBAM validates all configuration settings upon initialization. The validation includes:
- Required configuration keys
- Parameter data types
- Value ranges and constraints
- Prior distribution validity

When validation fails, specific error messages are provided to guide users in correcting issues.

## Error Handling

BBAM uses custom exception classes to provide clear error messages:

- `BbamError`: Base class for all BBAM exceptions
- `ConfigurationError`: Invalid configuration
- `DataValidationError`: Input data issues
- `ModelFittingError`: Problems during model fitting
- `ModelNotFittedError`: When results are requested before fitting
- `CalibrationError`: Issues during calibration

Example error handling:

```python
from bbam import BbamAnalyzer, BbamError, DataValidationError

try:
    model = BbamAnalyzer(model_type="standard")
    model.fit(data)
except DataValidationError as e:
    print(f"Data validation failed: {e}")
    # Take corrective action
except BbamError as e:
    print(f"BBAM error: {e}")
    # Handle other errors
```

## Logging

BBAM uses Python's standard logging module. To configure logging:

```python
import logging
logging.basicConfig(level=logging.INFO)

# Get BBAM logger
bbam_logger = logging.getLogger('bbam')
bbam_logger.setLevel(logging.DEBUG)

# Add handler if needed
handler = logging.FileHandler('bbam.log')
handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
bbam_logger.addHandler(handler)
```

## Performance Considerations

- For large datasets (>100 campaigns), consider increasing the `chains` parameter to take advantage of multi-core processing
- Model fitting time scales primarily with the number of iterations and chains
- Memory usage scales with the number of parameters and posterior samples
- Consider setting `include_samples=False` when saving models with large posterior distributions to reduce file size

## Versioning and Compatibility

BBAM uses semantic versioning (MAJOR.MINOR.PATCH):
- MAJOR: Incompatible API changes
- MINOR: Functionality added in a backward-compatible manner
- PATCH: Backward-compatible bug fixes

Configuration files and saved models include version information to ensure compatibility across BBAM versions.

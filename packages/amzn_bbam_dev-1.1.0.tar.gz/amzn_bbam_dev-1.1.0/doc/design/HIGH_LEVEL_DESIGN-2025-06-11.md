# BBAM High-Level Design

## Executive Summary

The Bayesian Bias Assessment Model (BBAM) is a Python package that implements a hierarchical Bayesian model to estimate observational model bias by comparing observational models against Randomized Controlled Trials (RCTs). This document outlines the high-level design for implementing BBAM as a centralized Amazon-wide solution that can be easily integrated into various team workflows through wrapper libraries. The core design focuses on flexibility, maintainability, and standardization while allowing teams to customize integration approaches according to their specific needs.

## Strategic Context

### Current Pain Points and Limitations

Currently, multiple teams across Amazon implement their own versions of Hierarchical Bayesian Models (HBM) for evaluating observational models against RCTs. This approach leads to:

- Duplicated development efforts
- Inconsistent implementations and methodologies
- Varied levels of testing and validation
- Challenges in maintaining multiple codebases
- Difficulty sharing improvements across teams
- Blurred ownership boundaries between science and engineering teams

By centralizing the HBM functionality in a single BBAM package, we can establish a unified, well-tested implementation that raises the bar for model evaluation across Amazon while allowing teams to maintain their customized workflow integrations. This approach enables a clear separation of concerns, with science teams owning the core statistical methodology and engineering teams focusing on integration and operational aspects through wrapper implementations.

## Technical Architecture

The BBAM package follows a modular architecture with clear separation of concerns:

### Core Components

1. **BbamAnalyzer (Main Interface)**
   - Primary API for all BBAM functionality
   - Orchestrates the complete modeling workflow
   - Manages model fitting, calibration, and results
   - Integrates visualization and output capabilities

2. **Data Processor**
   - Validates and prepares input data
   - Handles data transformation and normalization
   - Manages metadata extraction and validation
   - Located in `bbam.core.data_processor`

3. **Model Implementations**
   - **Standard Model (RCTObsHBM)**: Compares observational and RCT data
   - **RCT-Only Model (RCTOnlyHBM)**: Meta-analysis of RCT data only
   - Base Model class provides common functionality
   - Located in `bbam.models`

4. **Results Processor**
   - Computes output metrics and statistics
   - Generates HDI and uncertainty measures
   - Handles credible intervals and convergence diagnostics
   - Located in `bbam.core.results_processor`

5. **Configuration Manager**
   - Manages model hyperparameters and prior configurations
   - Handles YAML configuration files and defaults
   - Validates configuration consistency
   - Located in `bbam.config.configuration`

6. **Meta-Analysis Legacy Interface**
   - BayesianRCTMetaAnalysis class for backward compatibility
   - Maintained for existing integrations
   - Located in `bbam.meta_analysis`

### Component Interaction Flow

The components interact in a logical flow:

1. The **Data Processor** validates and prepares the input data
2. The **Configuration Manager** sets up the model parameters
3. The **Model Engine** executes the statistical analysis
4. The **Results Processor** computes the required metrics
5. The **Visualization Engine** generates plots and visualizations
6. The **I/O Interface** handles output saving and export

### Technology Stack

- **Programming Language**: Python 3.7+
- **Core Libraries**: PyMC3, Nutpie, NumPy, Pandas, Matplotlib
- **Package Management**: Brazil package system
- **Testing**: pytest
- **Documentation**: Sphinx

## Implementation Strategy

### Package Structure

```
bbam/
│
├── __init__.py                    # Main package interface
├── bbam_analyzer.py                  # Primary BbamAnalyzer API
├── meta_analysis.py               # Legacy BayesianRCTMetaAnalysis interface
├── py.typed                       # Type checking support
│
├── core/
│   ├── __init__.py
│   ├── data_processor.py          # Data validation and preprocessing
│   └── results_processor.py       # Results computation and formatting
│
├── models/
│   ├── __init__.py
│   ├── base_model.py              # Abstract base model class
│   ├── standard_model.py          # RCTObsHBM - standard obs vs RCT model
│   └── rct_only_model.py          # RCTOnlyHBM - RCT meta-analysis only
│
├── config/
│   ├── __init__.py
│   ├── configuration.py           # Configuration management and validation
│   └── run_metadata.py            # Run metadata tracking
│
├── utils/
│   ├── __init__.py
│   ├── enums.py                   # Enumeration definitions
│   └── logging_config.py          # Logging configuration
│
└── examples/
    ├── __init__.py
    ├── configs/                   # Example configuration files
    │   ├── analysis_config.yaml
    │   ├── nom_config.yaml
    │   └── test_config.yaml
    ├── data/                      # Sample datasets
    │   ├── data_sample_1.csv
    │   ├── ace/
    │   └── nom/
    ├── notebooks/                 # Jupyter notebook examples
    │   ├── bbam_minimal.ipynb
    │   └── bbam_nom_v0.ipynb
    └── scripts/                   # Python script examples
        ├── run_bbam_example.py
        ├── run_bbam_minimal.py
        ├── run_meta_analysis_legacy.py
        └── run_meta_analysis.py
```

### Development Phases

1. **Phase 1: Core Implementation**
   - Develop the base model framework
   - Implement data processing and validation
   - Create the standard HBM model variant

2. **Phase 2: Extended Functionality**
   - Implement campaign size model variant
   - Implement RCT-only model variant
   - Add calibration capabilities

3. **Phase 3: Integration and Usability**
   - Develop API interfaces for external integration
   - Create standalone execution capabilities
   - Build example notebooks and scripts

4. **Phase 4: Testing and Validation**
   - Implement comprehensive unit tests
   - Conduct integration testing
   - Perform performance testing and optimization

### Key Interfaces

**BbamAnalyzer API** (Primary class for interaction)
```python
class BbamAnalyzer:
    def __init__(self, model_type='standard', config=None):
        """Initialize the BBAM model.
        
        Args:
            model_type: One of 'standard', 'campaign_size', or 'rct_only'
            config: Optional configuration dictionary or path to config file
        """
        pass
        
    def fit(self, data, **kwargs):
        """Fit the model to the provided data.
        
        Args:
            data: Pandas DataFrame with RCT and observational data
            **kwargs: Additional model-specific parameters
        
        Returns:
            self: The fitted model instance
        """
        pass
        
    def calibrate(self, target_data, **kwargs):
        """Calibrate observational estimates using the fitted model.
        
        Args:
            target_data: Pandas DataFrame with observational data to calibrate
            **kwargs: Additional calibration parameters
            
        Returns:
            DataFrame: Calibrated estimates and uncertainty measures
        """
        pass
        
    def get_results(self, format='dataframe'):
        """Get model results.
        
        Args:
            format: Output format ('dataframe', 'dict', or 'json')
            
        Returns:
            Model results in the specified format
        """
        pass
        
    def plot(self, plot_type, **kwargs):
        """Generate plots from model results.
        
        Args:
            plot_type: Type of plot to generate
            **kwargs: Additional plotting parameters
            
        Returns:
            Plot object or saves to file based on parameters
        """
        pass
        
    def save(self, path, **kwargs):
        """Save model results to disk.
        
        Args:
            path: Path to save results
            **kwargs: Additional saving parameters
        """
        pass
```

## Operational Considerations

### Performance Optimization

- Leverage PyMC3's parallel sampling capabilities
- Implement efficient data handling for large datasets
- Optimize model parameterization for faster convergence
- Use advanced sampling techniques available in Nutpie

### Error Handling and Validation

- Comprehensive input validation
- Clear error messages with actionable suggestions
- Graceful handling of convergence issues
- Warning system for potential statistical concerns

### Documentation and Examples

- Comprehensive API documentation
- Usage examples for common scenarios
- Jupyter notebooks demonstrating typical workflows
- Best practices guide for model configuration

## Alternatives Analysis

### Alternative 1: Separate Team Implementations

**Pros:**
- Teams maintain full control over implementation
- Customized to specific team workflows

**Cons:**
- Duplication of effort
- Inconsistent implementations
- Higher maintenance burden
- Limited knowledge sharing

### Alternative 2: Single Monolithic Implementation

**Pros:**
- Fully standardized approach
- Single codebase to maintain

**Cons:**
- Less flexible for team-specific needs
- More complex to adapt to varied workflows

### Alternative 3: Proposed Core + Wrappers Approach

**Pros:**
- Standardized core implementation
- Teams retain flexibility through wrappers
- Reduced maintenance burden
- Knowledge sharing across teams
- Facilitates continuous improvement

**Cons:**
- Requires initial coordination across teams
- Teams must adapt to common interfaces

The Core + Wrappers approach was selected as it provides the best balance between standardization and flexibility, allowing teams to benefit from a shared implementation while maintaining their workflow-specific integrations.

## Success Metrics

### Technical Success Metrics

- **Accuracy**: Consistent statistical results compared to previous implementations
- **Performance**: Model fitting completed in under 10 minutes
- **Usability**: Successful integration with at least 3 team workflows
- **Quality**: >90% test coverage, all critical paths tested

### Business Success Metrics

- **Adoption**: Number of teams using the BBAM package
- **Efficiency**: Reduced development time for new observational models
- **Consistency**: Increased consistency in model evaluations across teams
- **Innovation**: New capabilities added to the framework over time

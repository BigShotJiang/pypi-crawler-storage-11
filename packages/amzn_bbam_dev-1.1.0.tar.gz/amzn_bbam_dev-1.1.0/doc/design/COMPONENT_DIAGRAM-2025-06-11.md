# BBAM Component Diagram

This diagram illustrates the core components of the Bayesian Bias Assessment Model (BBAM) package and their interactions, as well as the integration points for team-specific wrapper libraries.

```mermaid
graph TD
    %% External Systems and Users
    User[Team User/Pipeline] --> Wrapper[Team Wrapper Libraries]
    Wrapper --> BbamAnalyzer[BbamAnalyzer API]
    User --> |Standalone Usage| BbamAnalyzer
    User --> |Legacy Usage| MetaAnalysis[BayesianRCTMetaAnalysis]
    
    %% Core BbamAnalyzer Components
    BbamAnalyzer --> |Configuration| Config[Configuration Manager]
    BbamAnalyzer --> |Data Processing| DataProc[Data Processor]
    BbamAnalyzer --> |Model Execution| ModelImpl[Model Implementation]
    BbamAnalyzer --> |Results Processing| ResultsProc[Results Processor]
    
    %% Model Implementation Selection
    ModelImpl --> StandardModel[RCTObsHBM<br/>Standard Model]
    ModelImpl --> RCTModel[RCTOnlyHBM<br/>RCT-Only Model]
    ModelImpl --> BaseModel[Base Model<br/>Abstract Class]
    
    %% Configuration Flow
    Config --> |Priors & Settings| ModelImpl
    Config --> |Validation| DataProc
    
    %% Data Processing Flow
    DataProc --> |Validated Data| ModelImpl
    DataProc --> |Metadata| RunMeta[Run Metadata]
    
    %% Results Flow
    ModelImpl --> |Model Results| ResultsProc
    ResultsProc --> |Formatted Results| BbamAnalyzer
    ResultsProc --> |Plots & Visualizations| BbamAnalyzer
    
    %% Utility Components
    Config --> Enums[Enums & Types]
    DataProc --> Logging[Logging Config]
    ResultsProc --> Enums
    
    %% Legacy Interface
    MetaAnalysis --> DataProc
    MetaAnalysis --> ResultsProc
    MetaAnalysis --> StandardModel
    
    %% Styling
    classDef core fill:#f9f,stroke:#333,stroke-width:2px
    classDef external fill:#bbf,stroke:#333,stroke-width:1px
    classDef models fill:#bfb,stroke:#333,stroke-width:1px
    classDef utils fill:#ffb,stroke:#333,stroke-width:1px
    classDef legacy fill:#fbb,stroke:#333,stroke-width:1px
    
    class BbamAnalyzer,DataProc,ResultsProc,Config,ModelImpl core
    class User,Wrapper external
    class StandardModel,RCTModel,BaseModel models
    class Enums,Logging,RunMeta utils
    class MetaAnalysis legacy
```

## Component Descriptions

### Primary Interfaces

1. **BbamAnalyzer API** (`bbam.bbam_analyzer.BbamAnalyzer`)
   - Main entry point for all BBAM functionality
   - Orchestrates model fitting, calibration, and results generation
   - Provides integrated visualization and export capabilities
   - Supports both programmatic and configuration-file driven usage

2. **BayesianRCTMetaAnalysis** (`bbam.meta_analysis.BayesianRCTMetaAnalysis`)
   - Legacy interface maintained for backward compatibility
   - Direct interface to statistical model execution
   - Used by existing team integrations

### Core Processing Components

3. **Data Processor** (`bbam.core.data_processor.DataProcessor`)
   - Validates input data structure and required columns
   - Transforms data into model-compatible formats
   - Handles data cleaning and column mapping
   - Generates data summaries and statistics

4. **Results Processor** (`bbam.core.results_processor.ResultsProcessor`)
   - Computes statistical summaries from model traces
   - Calculates credible intervals (HDI and ETI)
   - Generates convergence diagnostics (R-hat statistics)
   - Formats results for output and visualization

5. **Configuration Manager** (`bbam.config.configuration.ConfigurationManager`)
   - Loads and validates YAML configuration files
   - Manages default configurations and priors
   - Provides configuration templates and validation
   - Handles data-driven prior settings

### Model Implementations

6. **RCTObsHBM** (`bbam.models.standard_model.RCTObsHBM`)
   - Standard hierarchical Bayesian model
   - Compares observational and RCT data to estimate bias
   - Implements bias correction and calibration capabilities

7. **RCTOnlyHBM** (`bbam.models.rct_only_model.RCTOnlyHBM`)
   - Meta-analysis model using only RCT data
   - Provides baseline estimates without observational bias
   - Used for RCT pooling and effect size estimation

8. **Base Model** (`bbam.models.base_model.Model`)
   - Abstract base class for all model implementations
   - Defines common interface and shared functionality
   - Manages prior specification and model configuration

### Utility Components

9. **Enums & Types** (`bbam.utils.enums`)
   - Defines model types, bias specifications, and interval types
   - Provides validation constants and type checking
   - Includes warning levels and likelihood distributions

10. **Run Metadata** (`bbam.config.run_metadata.RunMetadata`)
    - Tracks run configuration and data summaries
    - Generates unique run identifiers
    - Saves metadata for reproducibility

11. **Logging Configuration** (`bbam.utils.logging_config`)
    - Provides standardized logging setup
    - Configurable log levels and formats
    - Integrated with model execution tracking

### External Integration Points

12. **Team Wrapper Libraries**
    - Custom integration points developed by teams
    - Handle team-specific data transformation and workflow integration
    - Customize BBAM usage for specific pipelines and data sources

## Data Flow Overview

### Primary Workflow (BbamAnalyzer API)
1. Users instantiate `BbamAnalyzer` with desired model type ('standard' or 'rct_only')
2. Configuration Manager loads and validates configuration (YAML file or defaults)
3. Data Processor validates input DataFrame and transforms data for model compatibility
4. Selected Model Implementation (RCTObsHBM or RCTOnlyHBM) builds and fits the Bayesian model
5. Results Processor computes summaries, credible intervals, and convergence diagnostics
6. BbamAnalyzer provides results through `get_results()`, `plot()`, and `save()` methods
7. Optional calibration workflow uses fitted model to calibrate new observational data

### Legacy Workflow (BayesianRCTMetaAnalysis)
1. Users instantiate `BayesianRCTMetaAnalysis` with configuration and data
2. Direct execution using `run()` method with internal data processing
3. Results accessed through `summary_table()` and direct trace analysis
4. Maintained for backward compatibility with existing team integrations

### Configuration and Metadata Flow
- Configuration Manager handles YAML config files and provides templates
- Run Metadata tracks configuration, data summaries, and run identifiers
- Enums provide type validation and constants throughout the system
- Logging Configuration provides standardized logging across all components

## Integration Points

The architecture supports multiple integration approaches:

1. **Direct API Usage**: Teams use `BbamAnalyzer` directly in scripts and notebooks
2. **Configuration-Driven**: Teams use YAML configuration files for reproducible analysis
3. **Wrapper Libraries**: Teams build custom wrappers around BBAM for pipeline integration
4. **Legacy Interface**: Existing integrations continue using `BayesianRCTMetaAnalysis`

This component structure ensures flexibility while maintaining a clean separation of concerns and providing multiple entry points for different team requirements and migration paths.

# BBAM Requirements Specification

## Overview

The Bayesian Bias Assessment Model (BBAM) is a hierarchical Bayesian model implemented as a Python package designed to estimate observational model bias from a collection of Randomized Controlled Trial (RCT) and observational model pairs. This tool enables teams across Amazon to evaluate and calibrate observational causal models against experimental evidence.

## Business Context

The Hierarchical Bayesian Model (HBM) has found multiple applications across Amazon, particularly for causal model assessment and calibration solutions:

- MIDS teams are working to incorporate HBM into model evaluation pipelines
- CCM designates HBM as a recommended approach for evaluating marketing measurement models against RCT evidence
- GME Science has developed a CCM version of the HBM package to support certifications for teams without their own RCT meta-analysis solutions

This project aims to create a unified code-base with high standards for automation and science advancement, allowing teams to develop wrappers around the HBM core to integrate into their respective artifacts and workflows. This modular approach addresses separation of concerns between science and engineering ownership by providing a pipeline-ready science module, which is primarily owned by science teams, while engineering teams can build and maintain integration wrappers for their specific environments.

## Functional Requirements

### 1. Core Model Functionality

#### 1.1 Input Data Processing
- **FR-1.1.1:** Accept pandas DataFrame with observational and RCT pairs
- **FR-1.1.2:** Process meta-data values (country, channel, campaign name, campaign ID, etc.)
- **FR-1.1.3:** Accept estimates and standard errors for each pair
- **FR-1.1.4:** Support optional campaign size metric (treated units, impressions, or spend)

#### 1.2 Model Variants
- **FR-1.2.1:** Support basic default model using observational-RCT pairs
- **FR-1.2.2:** Support model with campaign size (requiring metric of campaign size)
- **FR-1.2.3:** Support RCT-only model variant (requiring only RCT values without observational pairs)
- **FR-1.2.4:** Provide optional calibration functionality (requiring a 'calibration target' of observational estimates without RCT pairs when enabled)

#### 1.3 Statistical Processing
- **FR-1.3.1:** Allow configuration of hyper-priors or selection from predefined priors
- **FR-1.3.2:** Fit model parameters and resolve sampling distributions
- **FR-1.3.3:** Store all input hyperparameters (sampling options, randomization seeds)
- **FR-1.3.4:** Support optional predictive posterior analysis with enhanced sampling results storage

#### 1.4 Output Generation
- **FR-1.4.1:** Generate model parameters and convergence metrics
- **FR-1.4.2:** Calculate average true effect (posterior)
- **FR-1.4.3:** Determine expected model bias and expected observational model value
- **FR-1.4.4:** When calibration is enabled, output calibrated values for all provided observational values
- **FR-1.4.5:** Include highest density interval (HDI) at 5% and 95% for all estimated values
- **FR-1.4.6:** Calculate estimated standard errors for all outputs
- **FR-1.4.7:** Provide results as accessible pandas DataFrame within the model class
- **FR-1.4.8:** Support optional writing of outputs to CSV files
- **FR-1.4.9:** Generate visualization plots in PNG format

### 2. Integration Requirements

#### 2.1 Package Structure
- **FR-2.1.1:** Implement as a Python library in a Brazil package
- **FR-2.1.2:** Support import via `brazil ws use --package BBAM` command
- **FR-2.1.3:** Allow easy integration into any pipeline or version set
- **FR-2.1.4:** Handle package dependencies (PyMC3, Nutpie) during setup

#### 2.2 Standalone Functionality
- **FR-2.2.1:** Provide basic dataset reading capabilities for standalone use cases
- **FR-2.2.2:** Include standalone scripts or notebooks to run the model independently

## Non-Functional Requirements

### 1. Performance Requirements
- **NFR-1.1:** Complete model fitting and sampling in less than 10 minutes
- **NFR-1.2:** Support parallelization through configurable number of chains
- **NFR-1.3:** Leverage PyMC3's multi-CPU capabilities for performance optimization

### 2. Maintainability Requirements
- **NFR-2.1:** Implement comprehensive unit testing
- **NFR-2.2:** Support peer and code reviewing workflows
- **NFR-2.3:** Follow Python best practices for package structure and documentation
- **NFR-2.4:** Version control all code and configurations

### 3. Integration Requirements
- **NFR-3.1:** Design for minimal external dependencies
- **NFR-3.2:** Support flexible integration methods for different team requirements
- **NFR-3.3:** Design clean interfaces for wrapper development by other teams

## Architecture Constraints

### 1. Technical Constraints
- **AC-1.1:** Implement using Python with PyMC3 and Nutpie libraries
- **AC-1.2:** Package must be deployable through Brazil package management system

### 2. Design Constraints
- **AC-2.1:** Focus on a minimal core HBM implementation to allow teams to develop custom wrappers
- **AC-2.2:** Support various input data formats and meta-data schemas to accommodate diverse team needs

## System Context

### 1. Target Users
- MIDS teams for model evaluation pipelines
- Marketing measurement teams across Amazon
- GME Science for CCM certifications
- Teams without their own RCT meta-analysis solutions (e.g., Audible, Music)

### 2. Integration Points
- Custom wrapper libraries by teams to handle I/O with the HBM
- Assessment pipelines for new observational model development
- Calibration strategies and continuous measurement evaluation workflows

## Glossary

- **HBM:** Hierarchical Bayesian Model
- **RCT:** Randomized Controlled Trial
- **BBAM:** Bayesian Bias Assessment Model
- **MIDS:** Measurement and Inference Data Science
- **CCM:** Customer-Centric Marketing
- **GME:** Growth Marketing & Engagement
- **HDI:** Highest Density Interval
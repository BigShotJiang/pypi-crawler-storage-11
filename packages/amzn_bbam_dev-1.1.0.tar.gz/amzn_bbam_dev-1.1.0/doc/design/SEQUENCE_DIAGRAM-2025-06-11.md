# BBAM Sequence Diagrams

This document provides sequence diagrams illustrating the key workflows and component interactions in the BBAM package.

## Model Fitting Workflow

This sequence diagram shows the flow of interactions when a user fits a BBAM model to input data.

```mermaid
sequenceDiagram
    participant User as User/Wrapper
    participant BM as BbamAnalyzer
    participant CM as ConfigManager
    participant DP as DataProcessor
    participant ME as ModelEngine
    participant SM as StatisticalModel
    participant RP as ResultsProcessor
    
    User->>BM: fit(data)
    activate BM
    
    BM->>CM: validate_config()
    CM-->>BM: configuration validated
    
    BM->>DP: validate_data(data)
    activate DP
    DP-->>BM: validation result
    deactivate DP
    
    BM->>DP: prepare_data(data)
    activate DP
    DP-->>BM: prepared_data
    deactivate DP
    
    BM->>ME: create_model(model_type)
    activate ME
    ME->>SM: initialize()
    ME-->>BM: model instance
    deactivate ME
    
    BM->>ME: fit_model(prepared_data, config)
    activate ME
    ME->>SM: sample(data, priors)
    activate SM
    Note over SM: PyMC3/Nutpie sampling
    SM-->>ME: raw_samples
    deactivate SM
    ME-->>BM: fitting_results
    deactivate ME
    
    BM->>ME: check_convergence()
    activate ME
    ME-->>BM: convergence_metrics
    deactivate ME
    
    BM->>RP: process_results(fitting_results)
    activate RP
    RP-->>BM: processed_results
    deactivate RP
    
    BM-->>User: fitted model
    deactivate BM
```

## Calibration Workflow

This sequence diagram illustrates how the calibration process works with a pre-fitted model.

```mermaid
sequenceDiagram
    participant User as User/Wrapper
    participant BM as BbamAnalyzer
    participant DP as DataProcessor
    participant ME as ModelEngine
    participant RP as ResultsProcessor
    
    User->>BM: calibrate(target_data)
    activate BM
    
    BM->>BM: check if model is fitted
    
    BM->>DP: validate_data(target_data, for_calibration=True)
    activate DP
    DP-->>BM: validation result
    deactivate DP
    
    BM->>DP: prepare_data(target_data)
    activate DP
    DP-->>BM: prepared_target_data
    deactivate DP
    
    BM->>ME: apply_calibration(prepared_target_data)
    activate ME
    ME->>ME: extract_bias_parameters()
    ME->>ME: compute_calibration_factors()
    ME-->>BM: calibrated_values
    deactivate ME
    
    BM->>RP: process_calibration(calibrated_values)
    activate RP
    RP->>RP: calculate_uncertainty()
    RP->>RP: calculate_hdi()
    RP-->>BM: processed_calibration
    deactivate RP
    
    BM-->>User: calibrated results (DataFrame)
    deactivate BM
```

## Results and Visualization Workflow

This sequence diagram shows how results are retrieved and visualizations are generated.

```mermaid
sequenceDiagram
    participant User as User/Wrapper
    participant BM as BbamAnalyzer
    participant RP as ResultsProcessor
    participant IO as IOInterface
    
    User->>BM: get_results(format='dataframe')
    activate BM
    BM->>BM: check if model is fitted
    BM->>RP: format_results(format)
    activate RP
    RP-->>BM: formatted_results
    deactivate RP
    BM-->>User: results
    deactivate BM
    
    User->>BM: plot('bias', output_path='bias.png')
    activate BM
    BM->>RP: generate_plot('bias')
    activate RP
    RP->>RP: create visualization
    RP-->>BM: plot_object
    deactivate RP
    
    BM->>IO: save_plot(plot_object, 'bias.png')
    activate IO
    IO-->>BM: saved_path
    deactivate IO
    
    BM-->>User: path to saved plot
    deactivate BM
    
    User->>BM: save('./results/')
    activate BM
    BM->>RP: get_serializable_results()
    activate RP
    RP-->>BM: serializable_results
    deactivate RP
    
    BM->>IO: save_results(results, './results/')
    activate IO
    IO->>IO: write results files
    IO->>IO: write configuration
    IO->>IO: write metadata
    IO-->>BM: saved_paths
    deactivate IO
    
    BM-->>User: dict of saved files
    deactivate BM
```

## Team Wrapper Integration Workflow

This sequence diagram illustrates how a team-specific wrapper might integrate with BBAM.

```mermaid
sequenceDiagram
    participant User as User
    participant TW as TeamWrapper
    participant DL as TeamDataLoader
    participant BM as BbamAnalyzer
    participant RW as TeamResultsWriter
    
    User->>TW: run_assessment(input_path, output_path)
    activate TW
    
    TW->>DL: load_data(input_path)
    activate DL
    DL->>DL: extract team-specific data
    DL->>DL: transform to BBAM format
    DL-->>TW: bbam_compatible_data
    deactivate DL
    
    TW->>BM: fit(bbam_compatible_data)
    activate BM
    Note over BM: Standard model fitting workflow
    BM-->>TW: fitted model
    deactivate BM
    
    TW->>BM: get_results()
    activate BM
    BM-->>TW: bbam_results
    deactivate BM
    
    TW->>RW: write_results(bbam_results, output_path)
    activate RW
    RW->>RW: transform to team format
    RW->>RW: generate team-specific reports
    RW-->>TW: team_results_paths
    deactivate RW
    
    TW-->>User: assessment_results
    deactivate TW
```

These sequence diagrams illustrate the principal flows of information and control between components in the BBAM system. They demonstrate how the modular architecture facilitates clear separation of concerns while enabling seamless integration through well-defined interfaces.
# BBAM Data Model Specification

This document details the data structures, schemas, and formats that the Bayesian Bias Assessment Model (BBAM) package will use both internally and for external interfaces.

## Input Data Models

### Core Input DataFrame

The primary input to the BBAM model is a pandas DataFrame containing paired observational and experimental data.

#### Required Columns for Standard Model

| Column Name | Data Type | Description |
|-------------|-----------|-------------|
| `experiment_est` | float | Point estimate from RCT experiment |
| `experiment_est_se` | float | Standard error of RCT estimate |
| `obs_model_est` | float | Point estimate from observational model |
| `obs_model_est_se` | float | Standard error of observational model estimate |

#### Additional Columns for Campaign Size Model

| Column Name | Data Type | Description |
|-------------|-----------|-------------|
| `campaign_size` | float | Metric representing campaign size (impressions, spend, or treated units) |

#### Metadata Columns (Optional but Recommended)

| Column Name | Data Type | Description |
|-------------|-----------|-------------|
| `campaign_id` | str | Unique identifier for campaign |
| `campaign_name` | str | Human-readable name for campaign |
| `country` | str | Country code for campaign |
| `channel` | str | Marketing channel identifier |
| `rct_start_date` | datetime | Start date of RCT experiment |
| `rct_end_date` | datetime | End date of RCT experiment |
| `measurement_start_date` | datetime | Start date of measurement window within RCT |
| `measurement_end_date` | datetime | End date of measurement window within RCT |
| `attribution_window` | int | Attribution window in days |
| `vertical` | str | Business vertical |

#### Example Input DataFrame

```python
data = pd.DataFrame({
    'campaign_id': ['camp_001', 'camp_002', 'camp_003'],
    'campaign_name': ['US_Search_Q1', 'UK_Display_Q2', 'DE_Social_Q1'],
    'country': ['US', 'UK', 'DE'],
    'channel': ['search', 'display', 'social'],
    'experiment_est': [0.15, 0.08, 0.12],
    'experiment_est_se': [0.03, 0.02, 0.04],
    'obs_model_est': [0.18, 0.05, 0.14],
    'obs_model_est_se': [0.02, 0.01, 0.02],
    'campaign_size': [1000000, 500000, 750000]
})
```

### Calibration Target DataFrame

For calibration functionality, a similar DataFrame structure is used for the target data, but without the experimental columns.

#### Required Columns for Calibration Target

| Column Name | Data Type | Description |
|-------------|-----------|-------------|
| `obs_model_est` | float | Point estimate from observational model to be calibrated |
| `obs_model_est_se` | float | Standard error of observational model estimate |

#### Optional Columns for Calibration Target

Same metadata columns as the core input DataFrame may be included.

## Configuration Data Models

### Configuration Dictionary

The configuration for BBAM models is represented as a nested dictionary structure.

#### Top-Level Configuration

```python
config = {
    'model': {
        'type': 'standard',  # One of 'standard', 'campaign_size', 'rct_only'
        'priors': {...},     # Prior specifications
    },
    'sampling': {
        'chains': 4,         # Number of MCMC chains
        'iterations': 2000,  # Total number of samples per chain
        'burn_in': 1000,     # Number of burn-in samples to discard
        'seed': 42,          # Random seed for reproducibility
    },
    'calibration': {
        'enabled': False,    # Whether to enable calibration
        'method': 'additive' # Calibration method ('additive' or 'multiplicative')
    },
    'output': {
        'save_path': './results/',  # Directory to save results
        'save_plots': True,         # Whether to save plots
        'plot_format': 'png',       # Format for saved plots
    }
}
```

### Prior Specifications

Priors are specified as nested dictionaries within the configuration:

```python
priors = {
    'mu_beta': {
        'distribution': 'normal',
        'mu': 0.0,
        'sigma': 1.0
    },
    'sigma_beta': {
        'distribution': 'half_normal',
        'sigma': 1.0
    },
    'mu_delta': {
        'distribution': 'normal',
        'mu': 0.0, 
        'sigma': 0.5
    },
    'sigma_delta': {
        'distribution': 'half_normal',
        'sigma': 0.5
    },
    # Additional priors based on model type
}
```

### Configuration File Format (YAML)

Configuration can also be specified in YAML format:

```yaml
model:
  type: standard
  priors:
    mu_beta:
      distribution: normal
      mu: 0.0
      sigma: 1.0
    sigma_beta:
      distribution: half_normal
      sigma: 1.0
    mu_delta:
      distribution: normal
      mu: 0.0
      sigma: 0.5
    sigma_delta:
      distribution: half_normal
      sigma: 0.5

sampling:
  chains: 4
  iterations: 2000
  burn_in: 1000
  seed: 42

calibration:
  enabled: false
  method: additive

output:
  save_path: ./results/
  save_plots: true
  plot_format: png
```

## Output Data Models

### Results DataFrame

The primary output from BBAM is a pandas DataFrame containing the model results.

#### Core Result Columns

| Column Name | Data Type | Description |
|-------------|-----------|-------------|
| `campaign_id` | str | Identifier from input data |
| `true_effect` | float | Estimated true effect (posterior) |
| `true_effect_se` | float | Standard error of true effect |
| `true_effect_hdi_low` | float | 5% HDI bound of true effect |
| `true_effect_hdi_high` | float | 95% HDI bound of true effect |
| `model_bias` | float | Estimated observational model bias |
| `model_bias_se` | float | Standard error of bias estimate |
| `model_bias_hdi_low` | float | 5% HDI bound of bias |
| `model_bias_hdi_high` | float | 95% HDI bound of bias |
| `bias_percent` | float | Bias as percentage of true effect |

#### Additional Columns for Campaign Size Model

| Column Name | Data Type | Description |
|-------------|-----------|-------------|
| `campaign_size` | float | Campaign size from input data |
| `size_effect` | float | Estimated effect of campaign size on bias |
| `size_effect_se` | float | Standard error of size effect |

#### Calibration Result Columns

When calibration is performed, additional columns are included:

| Column Name | Data Type | Description |
|-------------|-----------|-------------|
| `calibrated_estimate` | float | Calibrated point estimate |
| `calibrated_estimate_se` | float | Standard error of calibrated estimate |
| `calibrated_estimate_hdi_low` | float | 5% HDI bound of calibrated estimate |
| `calibrated_estimate_hdi_high` | float | 95% HDI bound of calibrated estimate |

### Model Parameters Object

The fitted model parameters are returned as a dictionary:

```python
model_parameters = {
    'mu_beta': 0.12,          # Global mean of true effects
    'sigma_beta': 0.05,       # Global standard deviation of true effects
    'mu_delta': 0.03,         # Global mean of bias
    'sigma_delta': 0.02,      # Global standard deviation of bias
    'beta': [0.15, 0.08, 0.12],  # True effects for each campaign
    'delta': [0.03, -0.03, 0.02], # Bias for each campaign
    # Additional parameters for campaign size model
    'gamma': 0.0001,          # Effect of campaign size on bias (if applicable)
}
```

### Convergence Diagnostics

Convergence diagnostics are returned as a dictionary:

```python
diagnostics = {
    'r_hat': {
        'mu_beta': 1.001,
        'sigma_beta': 1.002,
        'mu_delta': 1.001,
        'sigma_delta': 1.003,
        # Additional parameters
    },
    'effective_sample_size': {
        'mu_beta': 1850,
        'sigma_beta': 1720,
        'mu_delta': 1900,
        'sigma_delta': 1780,
        # Additional parameters
    },
    'divergences': 0,
    'energy': {
        'e_bfmi': [0.9, 0.85, 0.92, 0.88]  # For each chain
    }
}
```

### Posterior Samples

Raw posterior samples are stored as a dictionary of numpy arrays:

```python
samples = {
    'mu_beta': np.array([...]),  # Shape: (chains * samples,)
    'sigma_beta': np.array([...]),
    'mu_delta': np.array([...]),
    'sigma_delta': np.array([...]),
    'beta': np.array([...]),      # Shape: (chains * samples, n_campaigns)
    'delta': np.array([...]),     # Shape: (chains * samples, n_campaigns)
    # Additional parameters
}
```

## Internal Data Models

### Prepared Data Object

Internally, the Data Processor converts the input DataFrame to a structured dictionary used by the Model Engine:

```python
prepared_data = {
    'n_campaigns': 3,
    'experiment_est': np.array([0.15, 0.08, 0.12]),
    'experiment_est_se': np.array([0.03, 0.02, 0.04]),
    'obs_model_est': np.array([0.18, 0.05, 0.14]),
    'obs_model_est_se': np.array([0.02, 0.01, 0.02]),
    'campaign_size': np.array([1000000, 500000, 750000]),  # For campaign size model
    'metadata': {
        'campaign_id': ['camp_001', 'camp_002', 'camp_003'],
        'campaign_name': ['US_Search_Q1', 'UK_Display_Q2', 'DE_Social_Q1'],
        'country': ['US', 'UK', 'DE'],
        'channel': ['search', 'display', 'social'],
    }
}
```

### Model Results Object

The internal representation of model results:

```python
model_results = {
    'parameters': {
        # Model parameters as described above
    },
    'diagnostics': {
        # Convergence diagnostics as described above
    },
    'samples': {
        # Posterior samples as described above
    },
    'input_data': prepared_data,  # Reference to input data
    'metadata': {
        'model_type': 'standard',
        'fit_timestamp': '2023-06-11T14:30:00',
        'config_hash': '8f7d56c...',  # Hash of configuration for tracking
        'version': '1.0.0',          # BBAM version
    }
}
```

## Serialization Formats

### Results CSV Format

Results are saved as CSV files with the columns described in the Results DataFrame section.

### Model Storage Format

When saving a fitted model, BBAM uses a directory structure:

```
results/
├── model_results.csv        # Results DataFrame as CSV
├── model_parameters.json    # Model parameters as JSON
├── diagnostics.json         # Convergence diagnostics as JSON
├── config.yaml              # Configuration used for the model
├── metadata.json            # Metadata about the run
└── samples/                 # Optional directory for posterior samples
    ├── mu_beta.npy         # NumPy array file for each parameter
    ├── sigma_beta.npy
    └── ...
```

### Visualization Outputs

Plots are saved in the specified format (default: PNG) with standardized filenames:

- `bias_distribution.png` - Distribution of bias parameters
- `true_effect_distribution.png` - Distribution of true effects
- `calibration_comparison.png` - Comparison of pre/post calibration
- `convergence_diagnostics.png` - Trace and density plots for key parameters
- `scatter_comparison.png` - Scatter plot of RCT vs observational estimates

## Data Validation Rules

### Input Validation Rules

1. Required columns must be present for the selected model type
2. Numeric columns must contain valid floating-point numbers
3. Standard error columns must be positive
4. No missing values allowed in required columns
5. Campaign size must be positive (when using campaign size model)

### Configuration Validation Rules

1. Model type must be one of the supported values
2. Prior distributions must have valid parameters
3. Sampling parameters must be positive integers
4. Calibration method must be valid if calibration is enabled
5. Output paths must be valid and writable

## Data Transformation Rules

### Input Transformations

1. Campaign size is normalized (divided by its mean) when used in the model
2. Optional columns are preserved but not used by the core model
3. Missing metadata is filled with placeholders

### Output Transformations

1. HDI calculation uses PyMC's `arviz` library for reliable interval estimation
2. Percentage bias is calculated relative to the absolute value of the true effect
3. When calibration is requested, the calibration function is applied to new observational estimates

This data model specification provides a comprehensive reference for the data structures used by the BBAM package, ensuring consistency in data handling throughout the implementation.
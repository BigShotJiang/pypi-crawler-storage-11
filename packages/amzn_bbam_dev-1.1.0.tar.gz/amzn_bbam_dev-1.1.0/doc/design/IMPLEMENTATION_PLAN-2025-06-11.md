# BBAM Implementation Plan

This document outlines the plan for refactoring the existing hierarchical Bayesian model implementation into the BBAM package structure according to the requirements and design specifications.

## Current vs. Future Structure

### Current Structure
```
- run_meta_analysis.py      # Example script to run an analysis
- analysis_config.yaml      # Analysis configuration 
- enums.py                  # Enumerated settings
- logging_config.py         # Logging handler
- meta_analysis.py          # Meta analysis class using core models
- models.py                 # Core bias assessment models
- run_metadata.py           # Handler for configurations and results
```

### Target BBAM Package Structure
```
bbam/
│
├── core/
│   ├── __init__.py
│   ├── data_processor.py     # New component for data validation and preparation
│   ├── model_engine.py       # Refactored from models.py
│   ├── results_processor.py  # Refactored partially from meta_analysis.py and run_metadata.py
│   └── visualization.py      # New component for plot generation
│
├── models/
│   ├── __init__.py
│   ├── base_model.py         # Abstract base class for all models
│   ├── standard_model.py     # Refactored from models.py
│   ├── campaign_size_model.py # Refactored from models.py
│   └── rct_only_model.py     # Refactored from models.py
│
├── config/
│   ├── __init__.py
│   ├── configuration.py      # Refactored from run_metadata.py
│   └── default_priors.py     # Extracted from models.py
│
├── io/
│   ├── __init__.py
│   ├── data_reader.py        # New component
│   └── data_writer.py        # Refactored partially from run_metadata.py
│
├── utils/
│   ├── __init__.py
│   ├── enums.py              # Refactored from enums.py
│   ├── logging_config.py     # Refactored from logging_config.py
│   └── helpers.py            # New utility functions
│
├── __init__.py               # Package initialization
├── bbam_analyzer.py             # Main interface class, refactored from meta_analysis.py
│
└── examples/
    ├── notebooks/
    │   └── bbam_example.ipynb # New example notebook
    └── scripts/
        └── run_bbam.py       # Refactored from run_meta_analysis.py
```

## Component Mapping and Refactoring Steps

### 1. Package Interface (bbam_analyzer.py)

**Source:** meta_analysis.py

**Refactoring Steps:**
1. Create new `bbam_analyzer.py` file implementing the `BbamAnalyzer` class
2. Extract the core interface methods from `meta_analysis.py`
3. Implement the specified interface according to Package Interface Specification
4. Delegate functionality to appropriate subcomponents (data processor, model engine, etc.)

**Key Changes:**
- Simplified and standardized API
- Clear separation of concerns
- Support for all three model variants
- Comprehensive error handling

### 2. Data Processor (core/data_processor.py)

**Source:** meta_analysis.py (partial)

**Refactoring Steps:**
1. Create new `DataProcessor` class
2. Extract data validation and preparation logic from meta_analysis.py
3. Implement flexible column mapping for different data formats
4. Add comprehensive validation rules and informative error messages

**Key Changes:**
- Dedicated component for data validation
- Clear validation rules for each model type
- Support for custom column mapping

### 3. Model Engine (core/model_engine.py)

**Source:** models.py

**Refactoring Steps:**
1. Create new `ModelEngine` class as orchestrator
2. Extract core model execution logic from models.py
3. Implement PyMC3 and Nutpie integration
4. Create factory methods for the different model variants

**Key Changes:**
- Clean abstraction of statistical modeling engine
- Consistent interface across model variants
- Better error handling for model fitting issues

### 4. Model Variants (models/*)

**Source:** models.py

**Refactoring Steps:**
1. Create abstract `BaseModel` class
2. Implement concrete model classes for each variant
3. Extract model-specific logic from models.py
4. Ensure consistent interfaces across variants

**Key Changes:**
- Clear separation of model variants
- Inheritance hierarchy for shared functionality
- Model-specific parameter handling

### 5. Configuration Manager (config/configuration.py)

**Source:** run_metadata.py, analysis_config.yaml

**Refactoring Steps:**
1. Create new `ConfigManager` class
2. Extract configuration handling from run_metadata.py
3. Implement validation for all configuration options
4. Support for file-based and programmatic configuration

**Key Changes:**
- Comprehensive configuration validation
- Support for YAML, JSON, and dictionary configurations
- Default configurations for each model variant

### 6. Results Processor (core/results_processor.py)

**Source:** meta_analysis.py (partial), run_metadata.py (partial)

**Refactoring Steps:**
1. Create new `ResultsProcessor` class
2. Extract results processing logic from meta_analysis.py
3. Extract export functionality from run_metadata.py
4. Implement new visualization capabilities

**Key Changes:**
- Standardized results format
- Comprehensive metrics calculation
- Support for different output formats

### 7. I/O Interface (io/*)

**Source:** run_meta_analysis.py (partial), run_metadata.py (partial)

**Refactoring Steps:**
1. Create `DataReader` and `DataWriter` classes
2. Extract file loading logic from run_meta_analysis.py
3. Extract results saving logic from run_metadata.py
4. Implement flexible I/O operations

**Key Changes:**
- Standardized data loading approaches
- Flexible output formats
- Better error handling for I/O operations

### 8. Utilities (utils/*)

**Source:** enums.py, logging_config.py

**Refactoring Steps:**
1. Refactor `enums.py` for package-wide use
2. Refactor `logging_config.py` for package-wide logging
3. Add helper functions for common operations

**Key Changes:**
- Consistent error classes
- Comprehensive logging
- Shared utility functions

## Variable Name Preservation

To maintain consistency with the existing implementation, the following variable names will be preserved:

- Statistical model parameter names (e.g., `mu_beta`, `sigma_beta`, `mu_delta`)
- Key configuration parameters
- Result metric names where applicable

## Phase-by-Phase Implementation

### Phase 1: Core Framework and Standard Model

1. Set up package structure
2. Implement `ConfigManager` with basic functionality
3. Implement basic `DataProcessor`
4. Implement standard model variant
5. Create basic `BbamAnalyzer` interface
6. Implement basic results processing

**Output:** Functional BBAM package with standard model support

### Phase 2: Extended Model Variants

1. Implement campaign size model variant
2. Implement RCT-only model variant
3. Enhance model engine for variant support
4. Update data processor for all variants

**Output:** BBAM package with all model variants

### Phase 3: Advanced Features

1. Implement calibration functionality
2. Add visualization capabilities
3. Enhance results processing with HDI calculations
4. Implement saving/loading functionality

**Output:** BBAM package with advanced features

### Phase 4: Refinement and Examples

1. Comprehensive error handling
2. Enhanced logging
3. Example scripts and notebooks
4. Performance optimization

**Output:** Production-ready BBAM package with documentation and examples

## Testing Strategy

1. **Unit Tests**
   - Component-level tests for each class
   - Verification of statistical properties
   - Configuration validation tests
   - Data validation tests

2. **Integration Tests**
   - End-to-end workflow tests
   - Model variant interactions
   - Calibration workflow tests

3. **Validation Tests**
   - Comparison with existing implementation results
   - Statistical property validation
   - Performance benchmarking

## Migration Guide for Teams

For teams currently using the existing implementation, the following migration path is recommended:

1. Replace direct `meta_analysis.py` usage with `BbamAnalyzer` class
2. Convert existing configuration files to BBAM format
3. Update data preprocessing to match BBAM requirements
4. Implement wrapper classes if needed for custom functionality

## Documentation Plan

1. **API Documentation**
   - Class and method documentation
   - Parameter explanations
   - Examples for common use cases

2. **User Guide**
   - Installation instructions
   - Getting started tutorials
   - Configuration guide
   - Advanced usage examples

3. **Technical Documentation**
   - Statistical methodology
   - Implementation details
   - Performance considerations

## Timeline and Milestones

1. **Milestone 1: Core Framework** (2 weeks)
   - Package structure
   - Basic interfaces
   - Standard model implementation

2. **Milestone 2: Model Variants** (2 weeks)
   - All model variants implemented
   - Enhanced data processing
   - Configuration management

3. **Milestone 3: Advanced Features** (2 weeks)
   - Calibration
   - Visualization
   - Results processing

4. **Milestone 4: Refinement** (2 weeks)
   - Error handling
   - Documentation
   - Examples
   - Testing

**Total Estimated Timeline:** 8 weeks

## Conclusion

This implementation plan provides a roadmap for refactoring the existing hierarchical Bayesian model implementation into the BBAM package structure. By following this plan, we can create a well-structured, maintainable, and flexible package that meets the requirements specified in the Requirements Specification and adheres to the design outlined in the High-Level Design document while preserving the core statistical functionality of the existing implementation.
"""
Integration tests for BBAM complete workflows.

Extracted from test_bbam_comprehensive.py.
Tests multiple components working together in realistic scenarios.
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))


class TestDataProcessorIntegration:
    """Integration tests for DataProcessor with other components."""

    def test_data_processor_initialization(self):
        """Test DataProcessor initialization with custom logger."""
        from bbam.core.data_processor import DataProcessor
        from bbam.utils.logging_config import setup_logger

        # Test with default logger
        processor = DataProcessor()
        assert processor.logger is not None

        # Test with custom logger
        custom_logger = setup_logger("test_logger")
        processor = DataProcessor(logger=custom_logger)
        # The logger will be a child logger, so check the parent
        assert "test_logger" in processor.logger.name

    def test_get_data_summary(self):
        """Test data summary generation."""
        from bbam.core.data_processor import DataProcessor

        processor = DataProcessor()

        data = pd.DataFrame(
            {
                "experiment_est": [0.1, 0.2, 0.15],
                "experiment_est_se": [0.05, 0.03, 0.04],
                "obs_model_est": [0.12, 0.18, 0.14],
                "obs_model_est_se": [0.06, 0.04, 0.05],
            }
        )

        required_columns = list(data.columns)
        summary = processor.get_data_summary(data, required_columns)

        assert "n_observations" in summary
        assert "column_stats" in summary
        assert summary["n_observations"] == 3
        assert "experiment_est" in summary["column_stats"]

    def test_data_validation_edge_cases(self):
        """Test data validation edge cases."""
        from bbam.core.data_processor import DataProcessor, DataValidationError

        processor = DataProcessor()
        required_columns = ["experiment_est", "experiment_est_se", "obs_model_est", "obs_model_est_se"]

        # Test empty DataFrame
        with pytest.raises(DataValidationError):
            processor.validate_data(pd.DataFrame(), required_columns)

        # Test DataFrame with NaN values
        data_with_nan = pd.DataFrame(
            {
                "experiment_est": [0.1, np.nan, 0.15],
                "experiment_est_se": [0.05, 0.03, 0.04],
                "obs_model_est": [0.12, 0.18, 0.14],
                "obs_model_est_se": [0.06, 0.04, 0.05],
            }
        )
        with pytest.raises(DataValidationError):
            processor.validate_data(data_with_nan, required_columns)

        # Test DataFrame with infinite values
        data_with_inf = pd.DataFrame(
            {
                "experiment_est": [0.1, np.inf, 0.15],
                "experiment_est_se": [0.05, 0.03, 0.04],
                "obs_model_est": [0.12, 0.18, 0.14],
                "obs_model_est_se": [0.06, 0.04, 0.05],
            }
        )
        with pytest.raises(DataValidationError):
            processor.validate_data(data_with_inf, required_columns)


class TestResultsProcessorIntegration:
    """Integration tests for ResultsProcessor."""

    def test_calculate_hdi_function(self):
        """Test HDI calculation function."""
        from bbam.core.results_processor import calculate_hdi

        # Test with normal distribution samples
        np.random.seed(42)
        samples = np.random.normal(0, 1, 1000)

        lower, upper = calculate_hdi(samples, prob=0.95)

        # HDI should contain approximately 95% of samples
        within_hdi = np.sum((samples >= lower) & (samples <= upper))
        assert within_hdi / len(samples) >= 0.93  # Allow some tolerance

    def test_format_results_all_formats(self):
        """Test all result formatting options."""
        from bbam.core.results_processor import ResultsProcessor

        processor = ResultsProcessor()

        # Create sample DataFrame
        sample_df = pd.DataFrame(
            {
                "Mean": [1.0, 2.0],
                "Std": [0.1, 0.2],
                "Lower 95% HDI": [0.8, 1.6],
                "Upper 95% HDI": [1.2, 2.4],
            },
            index=["param1", "param2"],
        )

        # Test DataFrame format
        result_df = processor.format_results(sample_df, "dataframe")
        assert isinstance(result_df, pd.DataFrame)

        # Test dict format
        result_dict = processor.format_results(sample_df, "dict")
        assert isinstance(result_dict, dict)
        assert "param1" in result_dict

        # Test JSON format
        result_json = processor.format_results(sample_df, "json")
        assert isinstance(result_json, str)
        # Should be valid JSON
        import json

        json.loads(result_json)


class TestConfigurationIntegration:
    """Integration tests for configuration with other components."""

    def test_create_default_configuration_all_types(self):
        """Test default configuration creation for all model types."""
        from bbam.config.configuration import create_default_configuration

        # Test standard model
        standard_config = create_default_configuration("standard")
        assert "sampling_settings" in standard_config
        assert "model_settings" in standard_config

        # Test RCT-only model
        rct_config = create_default_configuration("rct_only")
        assert "sampling_settings" in rct_config
        assert "model_settings" in rct_config


class TestBbamAnalyzerIntegration:
    """Integration tests for complete BbamAnalyzer workflows."""

    def test_bbam_analyzer_configuration_loading(self):
        """Test different configuration loading methods."""
        from bbam import BbamAnalyzer

        # Test with dict configuration
        config_dict = {
            "sampling_settings": {
                "tune": 500,
                "draws": 500,
                "chains": 2,
                "cores": 2,
                "target_accept": 0.95,
                "maxdepth": 15,
                "is_random_seed": False,
                "seed": 123,
                "n_sample_posterior": 50,
            },
            "model_settings": {"bias_spec": "BOTH_INT_MULT", "likelihood_distribution": "normal"},
            "data_driven_priors": False,
            "priors": {
                "mu_beta_0": {"delta_mu_beta_0": 0.0, "gamma_mu_beta_0": 1.0},
                "sigma_beta_0": {"zeta_sigma_beta_0": 1.0},
                "mu_beta_1": {"delta_mu_beta_1": 0.0, "gamma_mu_beta_1": 1.0},
                "sigma_beta_1": {"zeta_sigma_beta_1": 1.0},
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
            },
            "warning_level_setting": "normal",
            "warning_level_definition": {"normal": {"rhat_threshold": 1.01}},
        }

        model = BbamAnalyzer("standard", config=config_dict)
        assert model.config["sampling_settings"]["tune"] == 500

    def test_bbam_analyzer_data_validation(self):
        """Test BbamAnalyzer data validation."""
        from bbam import BbamAnalyzer
        from bbam.bbam_analyzer import DataValidationError

        model = BbamAnalyzer("standard")

        # Test with invalid data
        invalid_data = pd.DataFrame({"wrong_column": [1, 2, 3]})

        with pytest.raises(DataValidationError):
            model.fit(invalid_data)


class TestUtilsIntegration:
    """Integration tests for utility modules with other components."""

    def test_enums_all_values(self):
        """Test all enum values and methods."""
        from bbam.utils.enums import IntervalType, WarningLevel

        # Test IntervalType
        assert IntervalType.HDI.value == "HDI"
        assert IntervalType.ETI.value == "ETI"
        assert set(IntervalType.values()) == {"HDI", "ETI"}

        # Test WarningLevel
        assert WarningLevel.NORMAL.value == "normal"
        assert WarningLevel.RELAXED.value == "relaxed"
        assert set(WarningLevel.values()) == {"normal", "relaxed"}

    def test_logging_config_basic_levels(self):
        """Test logging configuration with different levels."""
        import logging

        from bbam.utils.logging_config import setup_logger

        # Test different log levels
        logger_debug = setup_logger("test_debug", level=logging.DEBUG)
        assert logger_debug.level == logging.DEBUG

        logger_info = setup_logger("test_info", level=logging.INFO)
        assert logger_info.level == logging.INFO

        logger_warning = setup_logger("test_warning", level=logging.WARNING)
        assert logger_warning.level == logging.WARNING


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

"""
Unit tests for BBAM utility components.

Extracted from test_bbam.py - TestUtilities class.
Tests utility functions, enums, and logging configuration in isolation.
"""

import sys
from pathlib import Path

import pytest

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))


class TestUtilities:
    """Test utility components."""

    def test_logging_setup(self):
        """Test logging configuration setup."""
        from bbam.utils.logging_config import setup_logger

        logger = setup_logger("test_logger", level=20)  # INFO level
        assert logger.name == "test_logger"
        assert logger.level == 20

    def test_enums(self):
        """Test enum definitions."""
        from bbam.utils.enums import IntervalType, WarningLevel

        # Test IntervalType enum
        assert IntervalType.HDI.value == "HDI"
        assert IntervalType.ETI.value == "ETI"
        assert IntervalType.values() == ["HDI", "ETI"]

        # Test WarningLevel enum
        assert WarningLevel.NORMAL.value == "normal"
        assert WarningLevel.RELAXED.value == "relaxed"
        assert WarningLevel.values() == ["normal", "relaxed"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

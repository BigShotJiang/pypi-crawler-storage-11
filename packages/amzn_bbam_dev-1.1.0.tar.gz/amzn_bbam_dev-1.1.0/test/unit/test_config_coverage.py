"""
Additional unit tests for Configuration to improve coverage.

This module focuses on covering specific error handling and validation paths
that were missed in the main test suite.
"""

import tempfile
from pathlib import Path

import pytest

from bbam.config.configuration import ConfigurationError, ConfigurationManager
from bbam.utils.enums import BiasSpecification, LikelihoodDistribution


class TestConfigurationCoverage:
    """Test cases for Configuration coverage improvements."""

    def setup_method(self):
        """Set up test fixtures."""
        self.config_manager = ConfigurationManager()

    def test_load_configuration_empty_file(self):
        """Test loading empty configuration file."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write("")  # Empty file
            temp_path = f.name

        try:
            with pytest.raises(ConfigurationError, match="Configuration file is empty or invalid"):
                self.config_manager.load_configuration(temp_path, "standard")
        finally:
            Path(temp_path).unlink()

    def test_load_configuration_non_dict_content(self):
        """Test loading configuration file with non-dict content."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write("- item1\n- item2")  # List instead of dict
            temp_path = f.name

        try:
            with pytest.raises(ConfigurationError, match="Configuration file must contain a dictionary"):
                self.config_manager.load_configuration(temp_path, "standard")
        finally:
            Path(temp_path).unlink()

    def test_validate_sampling_settings_missing_required_params(self):
        """Test sampling settings validation with missing required parameters."""
        config = {"sampling_settings": {"target_accept": 0.8}}  # Missing tune and draws

        with pytest.raises(ValueError, match="Missing required sampling parameter"):
            self.config_manager._validate_sampling_settings(config)

    def test_validate_model_settings_invalid_bias_spec(self):
        """Test model settings validation with invalid bias_spec."""
        config = {"model_settings": {"bias_spec": "INVALID_BIAS_SPEC"}}

        with pytest.raises(ValueError, match="Invalid bias_spec"):
            self.config_manager._validate_model_settings(config, "standard")

    def test_validate_model_settings_invalid_likelihood_distribution(self):
        """Test model settings validation with invalid likelihood distribution."""
        config = {
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": "INVALID_LIKELIHOOD",
            }
        }

        with pytest.raises(ValueError, match="Invalid likelihood_distribution"):
            self.config_manager._validate_model_settings(config, "standard")

    def test_validate_model_settings_missing_student_df(self):
        """Test model settings validation with missing student_df for Student's t."""
        config = {
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": LikelihoodDistribution.STUDENT_T.value,
                # Missing student_df
            }
        }

        with pytest.raises(ValueError, match="student_df parameter required"):
            self.config_manager._validate_model_settings(config, "standard")

    def test_validate_model_settings_invalid_student_df(self):
        """Test model settings validation with invalid student_df."""
        config = {
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": LikelihoodDistribution.STUDENT_T.value,
                "student_df": -1,  # Invalid - must be positive
            }
        }

        with pytest.raises(ValueError, match="student_df must be positive"):
            self.config_manager._validate_model_settings(config, "standard")

    def test_validate_data_driven_priors_missing_settings(self):
        """Test data-driven priors validation with missing settings."""
        config = {
            "data_driven_priors": True
            # Missing data_driven_priors_settings
        }

        with pytest.raises(ValueError, match="data_driven_priors_settings section required"):
            self.config_manager._validate_data_driven_priors(config, "standard")

    def test_validate_data_driven_priors_missing_treatment_effect(self):
        """Test data-driven priors validation with missing treatment_effect section."""
        config = {"data_driven_priors": True, "data_driven_priors_settings": {}}  # Missing treatment_effect

        with pytest.raises(ValueError, match="treatment_effect section required"):
            self.config_manager._validate_data_driven_priors(config, "standard")

    def test_validate_data_driven_priors_missing_te_param(self):
        """Test data-driven priors validation with missing treatment effect parameter."""
        config = {
            "data_driven_priors": True,
            "data_driven_priors_settings": {"treatment_effect": {}},  # Missing required parameters
        }

        with pytest.raises(ValueError, match="Missing .* in treatment_effect settings"):
            self.config_manager._validate_data_driven_priors(config, "standard")

    def test_validate_data_driven_priors_invalid_te_param(self):
        """Test data-driven priors validation with invalid treatment effect parameter."""
        config = {
            "data_driven_priors": True,
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": -1.0}  # Invalid - must be positive
            },
        }

        with pytest.raises(ValueError, match="treatment_effect .* must be positive"):
            self.config_manager._validate_data_driven_priors(config, "standard")

    def test_validate_results_settings_invalid_prob_interval(self):
        """Test results settings validation with invalid prob_interval."""
        config = {"results_settings": {"prob_interval": 1.5}}  # Invalid - must be between 0 and 1

        with pytest.raises(ValueError, match="prob_interval must be between 0 and 1"):
            self.config_manager._validate_results_settings(config)

    def test_validate_results_settings_invalid_round_to(self):
        """Test results settings validation with invalid round_to."""
        config = {"results_settings": {"round_to": -1}}  # Invalid - must be non-negative

        with pytest.raises(ValueError, match="round_to must be a non-negative integer"):
            self.config_manager._validate_results_settings(config)

    def test_validate_results_settings_invalid_interval_type(self):
        """Test results settings validation with invalid interval_type."""
        config = {"results_settings": {"interval_type": "INVALID_TYPE"}}

        with pytest.raises(ValueError, match="Invalid interval_type"):
            self.config_manager._validate_results_settings(config)

    def test_validate_output_settings_invalid_format(self):
        """Test output settings validation with invalid format."""
        config = {"output_settings": {"output_format": "INVALID_FORMAT"}}

        with pytest.raises(ValueError, match="Invalid output_format"):
            self.config_manager._validate_output_settings(config)

    def test_save_configuration_with_comments(self):
        """Test saving configuration with comments."""
        config = {"model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value}}

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            temp_path = f.name

        try:
            saved_path = self.config_manager.save_configuration(config, temp_path, include_comments=True)
            assert Path(saved_path).exists()
        finally:
            Path(temp_path).unlink(missing_ok=True)

    def test_save_configuration_exception_handling(self):
        """Test save configuration exception handling."""
        config = {"test": "config"}
        invalid_path = "/invalid/path/that/does/not/exist/config.yaml"

        with pytest.raises(ConfigurationError, match="Failed to save configuration"):
            self.config_manager.save_configuration(config, invalid_path)

"""
Basic BBAM tests that work without PyMC dependencies.

These tests can run in the Brazil environment even with old NumPy versions.
"""

import sys

import numpy as np
import pytest


# Check if PyMC is available with compatible NumPy
def _can_import_pymc():
    """Check if PyMC can be imported with current environment."""
    try:
        # Check NumPy version first
        numpy_version = tuple(map(int, np.__version__.split(".")[:2]))
        if numpy_version < (1, 22):
            return False, f"NumPy {np.__version__} too old (need >= 1.22.0)"

        # Try to import PyMC
        import pymc

        return True, f"PyMC {pymc.__version__} available"
    except ImportError as e:
        return False, f"PyMC import failed: {e}"
    except Exception as e:
        return False, f"PyMC compatibility error: {e}"


# Get PyMC availability status
PYMC_AVAILABLE, PYMC_STATUS = _can_import_pymc()
print(f"PyMC Status: {PYMC_STATUS}")


class TestBasicFunctionality:
    """Test basic functionality that doesn't require PyMC."""

    def test_numpy_import(self):
        """Test that NumPy can be imported."""
        import numpy as np

        assert np.__version__ is not None
        print(f"NumPy version: {np.__version__}")

    def test_pandas_import(self):
        """Test that Pandas can be imported."""
        import pandas as pd

        assert pd.__version__ is not None
        print(f"Pandas version: {pd.__version__}")

    def test_scipy_import(self):
        """Test that SciPy can be imported."""
        import scipy

        assert scipy.__version__ is not None
        print(f"SciPy version: {scipy.__version__}")

    def test_python_version(self):
        """Test Python version information."""
        version = sys.version_info
        print(f"Python version: {version.major}.{version.minor}.{version.micro}")
        assert version.major == 3
        assert version.minor >= 9  # Minimum required version


class TestBbamCoreImports:
    """Test BBAM core imports that don't depend on PyMC."""

    @pytest.mark.skipif(not PYMC_AVAILABLE, reason=PYMC_STATUS)
    def test_config_imports(self):
        """Test configuration module imports."""
        from bbam.config import configuration

        assert hasattr(configuration, "ConfigurationManager")

    @pytest.mark.skipif(not PYMC_AVAILABLE, reason=PYMC_STATUS)
    def test_utils_imports(self):
        """Test utility module imports."""
        from bbam.utils import enums, logging_config

        assert hasattr(enums, "IntervalType")
        assert hasattr(enums, "WarningLevel")
        assert hasattr(logging_config, "setup_logger")

    @pytest.mark.skipif(not PYMC_AVAILABLE, reason=PYMC_STATUS)
    def test_core_data_processor_import(self):
        """Test core data processor import (without PyMC dependencies)."""
        try:
            from bbam.core import data_processor

            assert hasattr(data_processor, "DataProcessor")
            print("✅ DataProcessor imported successfully")
        except ImportError as e:
            pytest.skip(f"DataProcessor import failed due to dependencies: {e}")

    @pytest.mark.skipif(not PYMC_AVAILABLE, reason=PYMC_STATUS)
    def test_core_results_processor_import(self):
        """Test core results processor import (without PyMC dependencies)."""
        try:
            from bbam.core import results_processor

            assert hasattr(results_processor, "ResultsProcessor")
            print("✅ ResultsProcessor imported successfully")
        except ImportError as e:
            pytest.skip(f"ResultsProcessor import failed due to dependencies: {e}")


@pytest.mark.skipif(not PYMC_AVAILABLE, reason=PYMC_STATUS)
class TestBbamWithPyMC:
    """Test BBAM functionality that requires PyMC (skipped if not available)."""

    def test_bbam_analyzer_import(self):
        """Test BbamAnalyzer import with PyMC."""
        from bbam import BbamAnalyzer

        assert BbamAnalyzer is not None

    def test_pymc_functionality(self):
        """Test PyMC-dependent functionality."""
        import pymc as pm

        assert pm.__version__ is not None
        print(f"PyMC version: {pm.__version__}")

    def test_bbam_full_import(self):
        """Test full BBAM package import."""
        import bbam

        assert hasattr(bbam, "BbamAnalyzer")


class TestEnvironmentInfo:
    """Test to show environment information."""

    def test_environment_summary(self):
        """Display environment summary for debugging."""
        print("\n" + "=" * 60)
        print("🔍 ENVIRONMENT SUMMARY")
        print("=" * 60)
        print(f"Python: {sys.version}")
        print(f"NumPy: {np.__version__}")

        try:
            import pandas as pd

            print(f"Pandas: {pd.__version__}")
        except ImportError:
            print("Pandas: Not available")

        try:
            import scipy

            print(f"SciPy: {scipy.__version__}")
        except ImportError:
            print("SciPy: Not available")

        print(f"PyMC Available: {PYMC_AVAILABLE}")
        print(f"PyMC Status: {PYMC_STATUS}")
        print("=" * 60)

        # This test always passes - it's just for information
        assert True

"""
Additional unit tests for DataProcessor to improve coverage.

This module focuses on covering specific error handling and edge cases
that were missed in the main test suite.
"""

from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest

from bbam.core.data_processor import DataProcessor, DataValidationError, simulate_unpaired_data


class TestDataProcessorCoverage:
    """Test cases for DataProcessor coverage improvements."""

    def setup_method(self):
        """Set up test fixtures."""
        self.processor = DataProcessor()

    def test_validate_data_non_dataframe_input(self):
        """Test validation with non-DataFrame input."""
        with pytest.raises(DataValidationError, match="Data validation failed"):
            self.processor.validate_data("not_a_dataframe", ["col1", "col2"])

    def test_validate_data_positive_se_validation(self):
        """Test validation of positive standard errors."""
        # Create data with negative SE values
        invalid_data = pd.DataFrame(
            {
                "experiment_est": [0.05, 0.06],
                "experiment_est_se": [0.01, -0.02],  # Negative SE
                "obs_model_est": [0.04, 0.05],
                "obs_model_est_se": [0.015, 0.025],
            }
        )

        required_columns = ["experiment_est", "experiment_est_se", "obs_model_est", "obs_model_est_se"]

        with pytest.raises(DataValidationError, match="Data validation failed"):
            self.processor.validate_data(invalid_data, required_columns, validate_positive_se=True)

    def test_validate_data_positive_experiment_scale_validation(self):
        """Test validation of positive experiment scale."""
        # Create data with negative experiment scale
        invalid_data = pd.DataFrame(
            {
                "experiment_est": [0.05, 0.06],
                "experiment_est_se": [0.01, 0.02],
                "experiment_scale": [1e6, -1e5],  # Negative scale
                "experiment_scale_se": [1e5, 1e4],
            }
        )

        required_columns = ["experiment_est", "experiment_est_se", "experiment_scale", "experiment_scale_se"]

        with pytest.raises(DataValidationError, match="Data validation failed"):
            self.processor.validate_data(invalid_data, required_columns, validate_positive_experiment_scale=True)

    def test_process_data_missing_column_mappings(self):
        """Test process_data with missing column mappings."""
        data = pd.DataFrame({"exp_est": [0.05, 0.06], "exp_se": [0.01, 0.02]})

        # Missing mapping for required column
        column_mapping = {"experiment_est": "exp_est"}  # Missing mapping for exp_se

        with pytest.raises(DataValidationError, match="Column mapping failed"):
            self.processor.process_data(data, "standard", column_mapping)

    def test_process_data_with_exception_handling(self):
        """Test process_data exception handling."""
        # Create invalid data that will cause processing to fail
        invalid_data = pd.DataFrame(
            {"experiment_est": [np.inf, np.nan], "experiment_est_se": [0.01, 0.02]}  # Invalid values
        )

        with pytest.raises(DataValidationError, match="Data validation failed"):
            self.processor.process_data(invalid_data, "standard")

    def test_clean_data_duplicate_removal(self):
        """Test duplicate removal in clean_data."""
        # Create data with duplicates
        data_with_dups = pd.DataFrame(
            {
                "experiment_est": [0.05, 0.06, 0.05, 0.07],  # First and third are duplicates
                "experiment_est_se": [0.01, 0.02, 0.01, 0.015],
                "obs_model_est": [0.04, 0.05, 0.04, 0.06],
                "obs_model_est_se": [0.015, 0.025, 0.015, 0.02],
            }
        )

        with patch.object(self.processor, "logger") as mock_logger:
            cleaned_data = self.processor.clean_data(data_with_dups, remove_duplicates=True)

            # Should log duplicate removal
            mock_logger.info.assert_called()
            # Should have fewer rows after duplicate removal
            assert len(cleaned_data) < len(data_with_dups)

    def test_clean_data_zscore_outlier_removal(self):
        """Test z-score outlier removal."""
        # Create data with outliers
        np.random.seed(42)
        normal_data = np.random.normal(0.05, 0.01, 20)
        outlier_data = np.concatenate([normal_data, [0.5, -0.3]])  # Add extreme outliers

        data_with_outliers = pd.DataFrame(
            {
                "experiment_est": outlier_data,
                "experiment_est_se": np.random.uniform(0.01, 0.03, 22),
            }
        )

        cleaned_data = self.processor.clean_data(
            data_with_outliers, handle_outliers=True, outlier_method="zscore", outlier_threshold=2.0
        )

        # Should have fewer rows after outlier removal
        assert len(cleaned_data) < len(data_with_outliers)

    def test_clean_data_with_valid_data(self):
        """Test clean_data with valid data (no exception)."""
        # Create valid data
        valid_data = pd.DataFrame({"experiment_est": [0.05, 0.06, 0.07], "experiment_est_se": [0.01, 0.02, 0.015]})

        # Should not raise exception
        cleaned_data = self.processor.clean_data(valid_data, handle_outliers=True)
        assert len(cleaned_data) == len(valid_data)

    def test_get_data_summary_with_missing_column(self):
        """Test get_data_summary with missing columns."""
        data = pd.DataFrame({"experiment_est": [0.05, 0.06], "experiment_est_se": [0.01, 0.02]})

        # Request summary for column that doesn't exist - should handle gracefully
        summary = self.processor.get_data_summary(data, ["nonexistent_column"])

        # Should return a dict with error information
        assert isinstance(summary, dict)
        assert "n_observations" in summary

    def test_get_required_columns_invalid_model_type(self):
        """Test get_required_columns with invalid model type."""
        with pytest.raises(ValueError, match="Unsupported model type"):
            self.processor.get_required_columns("invalid_model_type")

    def test_map_columns_missing_user_columns(self):
        """Test map_columns with missing user columns."""
        data = pd.DataFrame({"existing_col": [0.05, 0.06]})

        # Map to non-existent user column
        column_mapping = {"experiment_est": "nonexistent_col"}

        with pytest.raises(DataValidationError, match="Column mapping failed"):
            self.processor.map_columns(data, column_mapping)

    def test_simulate_unpaired_data_with_scale_columns(self):
        """Test simulate_unpaired_data with experiment scale columns."""
        # Create processed data with scale columns
        df_processed = pd.DataFrame(
            {
                "obs_model_est": np.random.normal(0.05, 0.01, 10),
                "obs_model_est_se": np.random.uniform(0.005, 0.02, 10),
                "experiment_scale": np.random.uniform(1e6, 1e9, 10),
                "experiment_scale_se": np.random.uniform(1e5, 1e8, 10),
            }
        )

        df_unpaired = simulate_unpaired_data(
            df_processed, n_unpaired=5, noise_sigma=0.01, se_noise_sigma=0.005, linear_constant=0.001, random_seed=42
        )

        # Should include experiment_scale columns
        assert "experiment_scale" in df_unpaired.columns
        assert "experiment_scale_se" in df_unpaired.columns
        assert len(df_unpaired) == 5

    def test_simulate_unpaired_data_without_scale_columns(self):
        """Test simulate_unpaired_data without experiment scale columns."""
        # Create processed data without scale columns
        df_processed = pd.DataFrame(
            {
                "obs_model_est": np.random.normal(0.05, 0.01, 10),
                "obs_model_est_se": np.random.uniform(0.005, 0.02, 10),
            }
        )

        df_unpaired = simulate_unpaired_data(df_processed, n_unpaired=3, random_seed=42)

        # Should not include experiment_scale columns
        assert "experiment_scale" not in df_unpaired.columns
        assert "experiment_scale_se" not in df_unpaired.columns
        assert len(df_unpaired) == 3

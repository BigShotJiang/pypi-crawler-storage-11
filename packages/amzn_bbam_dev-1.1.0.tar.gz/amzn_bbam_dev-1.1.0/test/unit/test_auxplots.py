"""
Unit tests for AuxPlots utility class.

This module tests the auxiliary plotting functionality including plot generation,
styling, and parameter handling.
"""

from unittest.mock import Mock, patch

import numpy as np
import pandas as pd
import pytest

from bbam.utils.auxplots import AuxPlots


class TestAuxPlots:
    """Test cases for AuxPlots class."""

    def setup_method(self):
        """Set up test fixtures."""
        self.plotter = AuxPlots()

        # Sample data for testing
        np.random.seed(42)
        self.df_processed = pd.DataFrame(
            {
                "experiment_est": np.random.normal(0.05, 0.02, 5),
                "experiment_est_se": np.random.uniform(0.01, 0.03, 5),
                "obs_model_est": np.random.normal(0.06, 0.025, 5),
                "obs_model_est_se": np.random.uniform(0.015, 0.035, 5),
            }
        )

        self.df_unpaired = pd.DataFrame(
            {"obs_model_est": np.random.normal(0.065, 0.02, 3), "obs_model_est_se": np.random.uniform(0.01, 0.025, 3)}
        )

        # Mock inference data
        self.mock_idata = Mock()
        self.mock_idata.observed_data = {
            "tau_experiment_est_likelihood_dim_0": Mock(values=np.arange(5)),
            "tau_obs_model_est_likelihood_dim_0": Mock(values=np.arange(5)),
        }

        # Mock posterior summary
        self.mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 10),
                "sd": np.random.uniform(0.005, 0.02, 10),
                "hdi_5%": np.random.normal(0.04, 0.01, 10),
                "hdi_95%": np.random.normal(0.06, 0.01, 10),
            },
            index=[f"tau[{i}]" for i in range(5)] + ["mu_tau", "mean_bias", "sigma_tau", "mu_beta_0", "sigma_beta_0"],
        )

        # Mock calibration trace
        self.mock_calibration_trace = Mock()

    def test_init(self):
        """Test AuxPlots initialization."""
        plotter = AuxPlots()
        assert hasattr(plotter, "default_params")
        assert plotter.default_params["axes.labelsize"] == 22
        assert plotter.default_params["font.size"] == 20

    @patch("matplotlib.pyplot.rcParams")
    @patch("matplotlib.pyplot.rcParamsDefault")
    @patch("matplotlib.pyplot.rcdefaults")
    @patch("matplotlib.pyplot.cycler")
    @patch("matplotlib.pyplot.cm")
    def test_setup_plot_style(self, mock_cm, mock_cycler, mock_rcdefaults, mock_rcparams_default, mock_rcparams):
        """Test plot style setup."""
        # Mock the viridis colormap
        mock_cm.viridis.return_value = np.array([[0.1, 0.2, 0.3, 1.0]] * 10)

        colors = self.plotter._setup_plot_style()

        # Verify that rcParams methods were called
        mock_rcparams.update.assert_called()
        mock_rcdefaults.assert_called()

        # Verify return value
        assert colors is not None

    @patch("matplotlib.ticker.PercentFormatter")
    def test_format_y_axis_raw(self, mock_percent_formatter):
        """Test y-axis formatting with raw units."""
        mock_ax = Mock()

        self.plotter._format_y_axis(mock_ax, "raw")

        mock_ax.set_ylabel.assert_called_with("Point Estimate [raw]")
        mock_ax.yaxis.set_major_formatter.assert_not_called()

    @patch("matplotlib.ticker.PercentFormatter")
    def test_format_y_axis_percent(self, mock_percent_formatter):
        """Test y-axis formatting with percent units."""
        mock_ax = Mock()
        mock_formatter = Mock()
        mock_percent_formatter.return_value = mock_formatter

        self.plotter._format_y_axis(mock_ax, "percent")

        mock_ax.set_ylabel.assert_called_with("Point Estimate [%]")
        mock_percent_formatter.assert_called_with(1.0)
        mock_ax.yaxis.set_major_formatter.assert_called_with(mock_formatter)

    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_event_posteriors_basic(self, mock_tight_layout, mock_subplots):
        """Test basic event posteriors plotting."""
        # Mock figure and axes
        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                with patch.object(
                    self.plotter,
                    "_get_tau_parameters",
                    return_value=self.mock_post_summary.loc[["tau[0]", "tau[1]", "tau[2]", "tau[3]", "tau[4]"]],
                ):
                    fig, ax = self.plotter.plot_event_posteriors(
                        self.df_processed, self.mock_idata, self.mock_post_summary
                    )

        assert fig is mock_fig
        assert ax is mock_ax

        # Verify that errorbar was called for experiment, obs, and posterior data
        assert mock_ax.errorbar.call_count >= 3

        # Verify that the correct data was used by checking call arguments
        # Get all errorbar calls
        errorbar_calls = mock_ax.errorbar.call_args_list

        # Check that experiment data was plotted (should be in one of the calls)
        experiment_data_found = False
        obs_data_found = False

        for call in errorbar_calls:
            args, kwargs = call
            # Check if this call used experiment data
            if "label" in kwargs and "Experiment" in kwargs["label"]:
                # Verify the y data matches experiment estimates
                y_data = kwargs.get("y", args[1] if len(args) > 1 else None)
                if y_data is not None:
                    np.testing.assert_array_equal(y_data, self.df_processed["experiment_est"].values)
                    experiment_data_found = True
            # Check if this call used observational data
            elif "label" in kwargs and "Obs.model" in kwargs["label"]:
                y_data = kwargs.get("y", args[1] if len(args) > 1 else None)
                if y_data is not None:
                    np.testing.assert_array_equal(y_data, self.df_processed["obs_model_est"].values)
                    obs_data_found = True

        # Verify that both experiment and observational data were plotted
        assert experiment_data_found, "Experiment data was not found in errorbar calls"
        assert obs_data_found, "Observational data was not found in errorbar calls"

        # Verify formatting calls
        mock_ax.set_xlabel.assert_called_with("Experiment ID")
        mock_ax.grid.assert_called_with(True, alpha=0.3)
        mock_ax.legend.assert_called()
        mock_ax.axhline.assert_called()  # Reference line at zero

    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_event_posteriors_with_hp_mask(self, mock_tight_layout, mock_subplots):
        """Test event posteriors plotting with high-priority mask."""
        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        hp_mask = [0, 2]

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                fig, ax = self.plotter.plot_event_posteriors(
                    self.df_processed, self.mock_idata, self.mock_post_summary, hp_mask=hp_mask
                )

        # Should have additional errorbar call for high-priority experiments
        assert mock_ax.errorbar.call_count >= 4

    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_event_posteriors_with_means(self, mock_tight_layout, mock_subplots):
        """Test event posteriors plotting with mean lines."""
        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                fig, ax = self.plotter.plot_event_posteriors(
                    self.df_processed, self.mock_idata, self.mock_post_summary, show_means=True
                )

        # Should have calls for mean lines
        mock_ax.axhspan.assert_called()
        mock_ax.axhline.assert_called()

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_calibration_results_basic(self, mock_tight_layout, mock_subplots, mock_az_summary):
        """Test basic calibration results plotting."""
        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame({"mean": np.random.normal(0.05, 0.01, 3), "sd": np.random.uniform(0.005, 0.02, 3)})
        mock_az_summary.return_value = mock_summary

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                fig, ax = self.plotter.plot_calibration_results(self.df_unpaired, self.mock_calibration_trace)

        assert fig is mock_fig
        assert ax is mock_ax

        # Verify that errorbar was called for unpaired and calibrated data
        assert mock_ax.errorbar.call_count >= 2

        # Verify that the correct data was used by checking call arguments
        errorbar_calls = mock_ax.errorbar.call_args_list

        # Check that unpaired observational data was plotted
        unpaired_data_found = False
        calibrated_data_found = False

        for call in errorbar_calls:
            args, kwargs = call
            # Check if this call used unpaired observational data
            if "label" in kwargs and "Unpaired obs.model" in kwargs["label"]:
                y_data = kwargs.get("y", args[1] if len(args) > 1 else None)
                if y_data is not None:
                    np.testing.assert_array_equal(y_data, self.df_unpaired["obs_model_est"].values)
                    unpaired_data_found = True
            # Check if this call used calibrated data
            elif "label" in kwargs and "Calibrated" in kwargs["label"]:
                y_data = kwargs.get("y", args[1] if len(args) > 1 else None)
                if y_data is not None:
                    np.testing.assert_array_equal(y_data, mock_summary["mean"].values)
                    calibrated_data_found = True

        # Verify that both unpaired and calibrated data were plotted
        assert unpaired_data_found, "Unpaired observational data was not found in errorbar calls"
        assert calibrated_data_found, "Calibrated data was not found in errorbar calls"

        # Verify formatting calls
        mock_ax.set_xlabel.assert_called_with("Unpaired Observation ID")
        mock_ax.grid.assert_called_with(True, alpha=0.3)
        mock_ax.legend.assert_called()
        mock_ax.axhline.assert_called()  # Reference line at zero

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_calibration_results_with_bias_corrections(self, mock_tight_layout, mock_subplots, mock_az_summary):
        """Test calibration results plotting with bias corrections."""
        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame({"mean": np.random.normal(0.05, 0.01, 3), "sd": np.random.uniform(0.005, 0.02, 3)})
        mock_az_summary.return_value = mock_summary

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                fig, ax = self.plotter.plot_calibration_results(
                    self.df_unpaired, self.mock_calibration_trace, show_bias_corrections=True
                )

        # Should have scatter call for bias corrections
        mock_ax.scatter.assert_called()

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_combined_paired_unpaired_results(self, mock_tight_layout, mock_subplots, mock_az_summary):
        """Test combined paired and unpaired results plotting."""
        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame({"mean": np.random.normal(0.05, 0.01, 3), "sd": np.random.uniform(0.005, 0.02, 3)})
        mock_az_summary.return_value = mock_summary

        with patch.object(
            self.plotter,
            "_setup_plot_style",
            return_value=np.array(["blue", "red", "green", "orange", "purple", "cyan", "magenta"]),
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                with patch.object(
                    self.plotter,
                    "_get_tau_parameters",
                    return_value=self.mock_post_summary.loc[["tau[0]", "tau[1]", "tau[2]", "tau[3]", "tau[4]"]],
                ):
                    fig, ax = self.plotter.plot_combined_paired_unpaired_results(
                        self.df_processed,
                        self.mock_idata,
                        self.mock_post_summary,
                        self.df_unpaired,
                        self.mock_calibration_trace,
                    )

        assert fig is mock_fig
        assert ax is mock_ax

        # Should have multiple errorbar calls for paired and unpaired data
        assert mock_ax.errorbar.call_count >= 5

        # Should have vertical line to separate sections
        mock_ax.axvline.assert_called()

        # Should have text labels for sections
        assert mock_ax.text.call_count >= 2

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_combined_with_hp_mask(self, mock_tight_layout, mock_subplots, mock_az_summary):
        """Test combined plotting with high-priority mask."""
        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame({"mean": np.random.normal(0.05, 0.01, 3), "sd": np.random.uniform(0.005, 0.02, 3)})
        mock_az_summary.return_value = mock_summary

        hp_mask = [0, 2]

        with patch.object(
            self.plotter,
            "_setup_plot_style",
            return_value=np.array(["blue", "red", "green", "orange", "purple", "cyan", "magenta"]),
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                fig, ax = self.plotter.plot_combined_paired_unpaired_results(
                    self.df_processed,
                    self.mock_idata,
                    self.mock_post_summary,
                    self.df_unpaired,
                    self.mock_calibration_trace,
                    hp_mask=hp_mask,
                )

        # Should have additional errorbar call for high-priority experiments
        assert mock_ax.errorbar.call_count >= 6

    def test_custom_title_and_figsize(self):
        """Test custom title and figure size parameters."""
        custom_title = "Custom Test Title"
        custom_figsize = (15, 8)

        with patch("matplotlib.pyplot.subplots") as mock_subplots:
            with patch("matplotlib.pyplot.tight_layout"):
                mock_fig = Mock()
                mock_ax = Mock()
                mock_ax.get_ylim.return_value = (0, 0.1)
                mock_subplots.return_value = (mock_fig, mock_ax)

                with patch.object(
                    self.plotter,
                    "_setup_plot_style",
                    return_value=np.array(["blue", "red", "green", "orange", "purple"]),
                ):
                    with patch.object(self.plotter, "_format_y_axis"):
                        fig, ax = self.plotter.plot_event_posteriors(
                            self.df_processed,
                            self.mock_idata,
                            self.mock_post_summary,
                            title=custom_title,
                            figsize=custom_figsize,
                        )

                # Verify custom figsize was used
                mock_subplots.assert_called_with(figsize=custom_figsize)

                # Verify custom title was used
                mock_fig.text.assert_called_with(0.02, 1.08, custom_title, fontsize=22)

    def test_ylabel_units_parameter(self):
        """Test ylabel_units parameter handling."""
        with patch("matplotlib.pyplot.subplots") as mock_subplots:
            with patch("matplotlib.pyplot.tight_layout"):
                mock_fig = Mock()
                mock_ax = Mock()
                mock_subplots.return_value = (mock_fig, mock_ax)

                with patch.object(
                    self.plotter,
                    "_setup_plot_style",
                    return_value=np.array(["blue", "red", "green", "orange", "purple"]),
                ):
                    with patch.object(self.plotter, "_format_y_axis") as mock_format:
                        self.plotter.plot_event_posteriors(
                            self.df_processed, self.mock_idata, self.mock_post_summary, ylabel_units="percent"
                        )

                        # Verify _format_y_axis was called with correct parameter
                        mock_format.assert_called_with(mock_ax, "percent")

    def test_default_parameters(self):
        """Test that default parameters are correctly set."""
        expected_params = {
            "axes.labelsize": 22,
            "axes.titlesize": 16,
            "xtick.labelsize": 16,
            "ytick.labelsize": 16,
            "axes.titlepad": 5,
            "axes.labelpad": 5,
            "font.size": 20,
            "lines.linewidth": 2,
        }

        for key, expected_value in expected_params.items():
            assert self.plotter.default_params[key] == expected_value

    @patch("arviz.summary")
    def test_calibration_results_custom_parameters(self, mock_az_summary):
        """Test calibration results with custom parameters."""
        # Mock ArviZ summary
        mock_summary = pd.DataFrame({"mean": np.random.normal(0.05, 0.01, 3), "sd": np.random.uniform(0.005, 0.02, 3)})
        mock_az_summary.return_value = mock_summary

        custom_title = "Custom Calibration Title"
        custom_figsize = (25, 8)

        with patch("matplotlib.pyplot.subplots") as mock_subplots:
            with patch("matplotlib.pyplot.tight_layout"):
                mock_fig = Mock()
                mock_ax = Mock()
                mock_subplots.return_value = (mock_fig, mock_ax)

                with patch.object(
                    self.plotter,
                    "_setup_plot_style",
                    return_value=np.array(["blue", "red", "green", "orange", "purple"]),
                ):
                    with patch.object(self.plotter, "_format_y_axis"):
                        fig, ax = self.plotter.plot_calibration_results(
                            self.df_unpaired,
                            self.mock_calibration_trace,
                            title=custom_title,
                            figsize=custom_figsize,
                            ylabel_units="percent",
                        )

                # Verify custom parameters were used
                mock_subplots.assert_called_with(figsize=custom_figsize)
                mock_fig.text.assert_called_with(0.02, 1.08, custom_title, fontsize=22)

    def test_plot_methods_return_types(self):
        """Test that all plot methods return correct types."""
        with patch("matplotlib.pyplot.subplots") as mock_subplots:
            with patch("matplotlib.pyplot.tight_layout"):
                with patch("arviz.summary") as mock_az_summary:
                    mock_fig = Mock()
                    mock_ax = Mock()
                    mock_ax.get_ylim.return_value = (0, 0.1)
                    mock_subplots.return_value = (mock_fig, mock_ax)

                    mock_summary = pd.DataFrame(
                        {"mean": np.random.normal(0.05, 0.01, 3), "sd": np.random.uniform(0.005, 0.02, 3)}
                    )
                    mock_az_summary.return_value = mock_summary

                    with patch.object(
                        self.plotter,
                        "_setup_plot_style",
                        return_value=np.array(["blue", "red", "green", "orange", "purple", "cyan", "magenta"]),
                    ):
                        with patch.object(self.plotter, "_format_y_axis"):
                            # Test plot_event_posteriors
                            fig1, ax1 = self.plotter.plot_event_posteriors(
                                self.df_processed, self.mock_idata, self.mock_post_summary
                            )
                            assert fig1 is mock_fig
                            assert ax1 is mock_ax

                            # Test plot_calibration_results
                            fig2, ax2 = self.plotter.plot_calibration_results(
                                self.df_unpaired, self.mock_calibration_trace
                            )
                            assert fig2 is mock_fig
                            assert ax2 is mock_ax

                            # Test plot_combined_paired_unpaired_results
                            fig3, ax3 = self.plotter.plot_combined_paired_unpaired_results(
                                self.df_processed,
                                self.mock_idata,
                                self.mock_post_summary,
                                self.df_unpaired,
                                self.mock_calibration_trace,
                            )
                            assert fig3 is mock_fig
                            assert ax3 is mock_ax

    def test_error_handling_empty_data(self):
        """Test error handling with empty data."""
        empty_df = pd.DataFrame()

        with patch("matplotlib.pyplot.subplots") as mock_subplots:
            mock_fig = Mock()
            mock_ax = Mock()
            mock_subplots.return_value = (mock_fig, mock_ax)

            with patch.object(
                self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
            ):
                with patch.object(self.plotter, "_format_y_axis"):
                    # Should raise KeyError for missing columns
                    with pytest.raises(KeyError):
                        self.plotter.plot_event_posteriors(empty_df, self.mock_idata, self.mock_post_summary)

    def test_reference_lines_and_formatting(self):
        """Test that reference lines and formatting are applied."""
        with patch("matplotlib.pyplot.subplots") as mock_subplots:
            with patch("matplotlib.pyplot.tight_layout"):
                mock_fig = Mock()
                mock_ax = Mock()
                mock_ax.get_ylim.return_value = (0, 0.1)
                mock_subplots.return_value = (mock_fig, mock_ax)

                with patch.object(
                    self.plotter,
                    "_setup_plot_style",
                    return_value=np.array(["blue", "red", "green", "orange", "purple"]),
                ):
                    with patch.object(self.plotter, "_format_y_axis"):
                        self.plotter.plot_event_posteriors(self.df_processed, self.mock_idata, self.mock_post_summary)

                # Verify reference line at zero
                mock_ax.axhline.assert_called()

                # Verify grid and formatting
                mock_ax.grid.assert_called_with(True, alpha=0.3)
                mock_ax.xaxis.set_major_formatter.assert_called()

    def test_class_attributes(self):
        """Test that class has expected attributes."""
        plotter = AuxPlots()

        # Check that all expected methods exist
        assert hasattr(plotter, "plot_event_posteriors")
        assert hasattr(plotter, "plot_calibration_results")
        assert hasattr(plotter, "plot_combined_paired_unpaired_results")
        assert hasattr(plotter, "_setup_plot_style")
        assert hasattr(plotter, "_format_y_axis")

        # Check that methods are callable
        assert callable(plotter.plot_event_posteriors)
        assert callable(plotter.plot_calibration_results)
        assert callable(plotter.plot_combined_paired_unpaired_results)
        assert callable(plotter.plot_intensity_posteriors)

    @patch("matplotlib.ticker.PercentFormatter")
    def test_format_y_axis_percent_with_scale(self, mock_percent_formatter):
        """Test y-axis formatting with percent units and custom scale."""
        mock_ax = Mock()
        mock_formatter = Mock()
        mock_percent_formatter.return_value = mock_formatter

        self.plotter._format_y_axis(mock_ax, "percent-100")

        mock_ax.set_ylabel.assert_called_with("Point Estimate [%]")
        mock_percent_formatter.assert_called_with(100.0)
        mock_ax.yaxis.set_major_formatter.assert_called_with(mock_formatter)

    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_intensity_posteriors_basic(self, mock_tight_layout, mock_subplots):
        """Test basic intensity posteriors plotting."""
        # Add experiment_scale columns to test data
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)

        # Mock figure and axes
        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock post_summary with experiment_true_ati entries
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 10),
                "sd": np.random.uniform(0.005, 0.02, 10),
                "hdi_5%": np.random.normal(0.04, 0.01, 10),
                "hdi_95%": np.random.normal(0.06, 0.01, 10),
            },
            index=[f"experiment_true_ati[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                with patch.object(
                    self.plotter,
                    "_get_experiment_ati_parameters",
                    return_value=mock_post_summary.loc[
                        [
                            "experiment_true_ati[0]",
                            "experiment_true_ati[1]",
                            "experiment_true_ati[2]",
                            "experiment_true_ati[3]",
                            "experiment_true_ati[4]",
                        ]
                    ],
                ):
                    fig, ax = self.plotter.plot_intensity_posteriors(
                        self.df_processed, self.mock_idata, mock_post_summary
                    )

        assert fig is mock_fig
        assert ax is mock_ax

        # Verify that errorbar was called for experiment, obs, and posterior intensity data
        assert mock_ax.errorbar.call_count >= 3

    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_intensity_posteriors_with_tau_metric(self, mock_tight_layout, mock_subplots):
        """Test intensity posteriors plotting with tau posterior metric."""
        # Add experiment_scale columns to test data
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)

        # Mock figure and axes
        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock post_summary with tau and experiment_true_size entries
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 15),
                "sd": np.random.uniform(0.005, 0.02, 15),
                "hdi_5%": np.random.normal(0.04, 0.01, 15),
                "hdi_95%": np.random.normal(0.06, 0.01, 15),
            },
            index=[f"tau[{i}]" for i in range(5)]
            + [f"experiment_true_size[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                with patch.object(
                    self.plotter,
                    "_get_tau_parameters",
                    return_value=mock_post_summary.loc[["tau[0]", "tau[1]", "tau[2]", "tau[3]", "tau[4]"]],
                ):
                    with patch.object(
                        self.plotter,
                        "_get_experiment_size_parameters",
                        return_value=mock_post_summary.loc[
                            [
                                "experiment_true_size[0]",
                                "experiment_true_size[1]",
                                "experiment_true_size[2]",
                                "experiment_true_size[3]",
                                "experiment_true_size[4]",
                            ]
                        ],
                    ):
                        fig, ax = self.plotter.plot_intensity_posteriors(
                            self.df_processed, self.mock_idata, mock_post_summary, posterior_metric="tau"
                        )

        assert fig is mock_fig
        assert ax is mock_ax

        # Verify that errorbar was called for experiment, obs, and posterior intensity data
        assert mock_ax.errorbar.call_count >= 3

    def test_plot_intensity_posteriors_invalid_metric(self):
        """Test intensity posteriors plotting with invalid posterior metric."""
        # Add experiment_scale columns to test data
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)

        with patch("matplotlib.pyplot.subplots") as mock_subplots:
            mock_fig = Mock()
            mock_ax = Mock()
            mock_subplots.return_value = (mock_fig, mock_ax)

            with patch.object(
                self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
            ):
                with pytest.raises(ValueError, match="Invalid posterior_metric"):
                    self.plotter.plot_intensity_posteriors(
                        self.df_processed, self.mock_idata, self.mock_post_summary, posterior_metric="invalid"
                    )

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_calibration_results_with_hdi_columns(self, mock_tight_layout, mock_subplots, mock_az_summary):
        """Test calibration results plotting with HDI columns available."""
        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary with HDI columns
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
                "hdi_5%": np.random.normal(0.04, 0.01, 3),
                "hdi_95%": np.random.normal(0.06, 0.01, 3),
            }
        )
        mock_az_summary.return_value = mock_summary

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                fig, ax = self.plotter.plot_calibration_results(self.df_unpaired, self.mock_calibration_trace)

        # Should use HDI intervals
        assert mock_ax.errorbar.call_count >= 2

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_combined_results_with_hdi_columns(self, mock_tight_layout, mock_subplots, mock_az_summary):
        """Test combined results plotting with HDI columns available."""
        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock post_summary with HDI columns
        mock_post_summary_hdi = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 10),
                "sd": np.random.uniform(0.005, 0.02, 10),
                "hdi_5%": np.random.normal(0.04, 0.01, 10),
                "hdi_95%": np.random.normal(0.06, 0.01, 10),
            },
            index=[f"tau[{i}]" for i in range(5)] + ["mu_tau", "mean_bias", "sigma_tau", "mu_beta_0", "sigma_beta_0"],
        )

        # Mock ArviZ summary with HDI columns
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
                "hdi_5%": np.random.normal(0.04, 0.01, 3),
                "hdi_95%": np.random.normal(0.06, 0.01, 3),
            }
        )
        mock_az_summary.return_value = mock_summary

        with patch.object(
            self.plotter,
            "_setup_plot_style",
            return_value=np.array(["blue", "red", "green", "orange", "purple", "cyan", "magenta"]),
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                fig, ax = self.plotter.plot_combined_paired_unpaired_results(
                    self.df_processed,
                    self.mock_idata,
                    mock_post_summary_hdi,
                    self.df_unpaired,
                    self.mock_calibration_trace,
                )

        # Should use HDI intervals for both paired and unpaired data
        assert mock_ax.errorbar.call_count >= 5

    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_event_posteriors_with_mean_bias(self, mock_tight_layout, mock_subplots):
        """Test event posteriors plotting with mean bias line."""
        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                fig, ax = self.plotter.plot_event_posteriors(
                    self.df_processed, self.mock_idata, self.mock_post_summary, show_means=True
                )

        # Should have calls for mean lines including bias line
        mock_ax.axhspan.assert_called()
        # Should have multiple axhline calls (reference line + mean line + bias line)
        assert mock_ax.axhline.call_count >= 3

    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_intensity_posteriors_with_means(self, mock_tight_layout, mock_subplots):
        """Test intensity posteriors plotting with mean lines."""
        # Add experiment_scale columns to test data
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock post_summary with experiment_true_ati entries
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 10),
                "sd": np.random.uniform(0.005, 0.02, 10),
                "hdi_5%": np.random.normal(0.04, 0.01, 10),
                "hdi_95%": np.random.normal(0.06, 0.01, 10),
            },
            index=[f"experiment_true_ati[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                fig, ax = self.plotter.plot_intensity_posteriors(
                    self.df_processed, self.mock_idata, mock_post_summary, show_means=True
                )

        # Should have calls for mean intensity lines
        mock_ax.axhspan.assert_called()
        mock_ax.axhline.assert_called()

    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_plot_intensity_posteriors_with_hp_mask(self, mock_tight_layout, mock_subplots):
        """Test intensity posteriors plotting with high-priority mask."""
        # Add experiment_scale columns to test data
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock post_summary with experiment_true_ati entries
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 10),
                "sd": np.random.uniform(0.005, 0.02, 10),
                "hdi_5%": np.random.normal(0.04, 0.01, 10),
                "hdi_95%": np.random.normal(0.06, 0.01, 10),
            },
            index=[f"experiment_true_ati[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        hp_mask = [0, 2]

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                fig, ax = self.plotter.plot_intensity_posteriors(
                    self.df_processed, self.mock_idata, mock_post_summary, hp_mask=hp_mask
                )

        # Should have additional errorbar call for high-priority experiments
        assert mock_ax.errorbar.call_count >= 4

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    @patch("matplotlib.pyplot.tight_layout")
    def test_combined_results_without_hdi_columns(self, mock_tight_layout, mock_subplots, mock_az_summary):
        """Test combined results plotting without HDI columns (fallback to CI)."""
        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_ylim.return_value = (0, 0.1)
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock post_summary without HDI columns
        mock_post_summary_no_hdi = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 10),
                "sd": np.random.uniform(0.005, 0.02, 10),
            },
            index=[f"tau[{i}]" for i in range(5)] + ["mu_tau", "mean_bias", "sigma_tau", "mu_beta_0", "sigma_beta_0"],
        )

        # Mock ArviZ summary without HDI columns
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
            }
        )
        mock_az_summary.return_value = mock_summary

        with patch.object(
            self.plotter,
            "_setup_plot_style",
            return_value=np.array(["blue", "red", "green", "orange", "purple", "cyan", "magenta"]),
        ):
            with patch.object(self.plotter, "_format_y_axis"):
                fig, ax = self.plotter.plot_combined_paired_unpaired_results(
                    self.df_processed,
                    self.mock_idata,
                    mock_post_summary_no_hdi,
                    self.df_unpaired,
                    self.mock_calibration_trace,
                )

        # Should fallback to CI intervals
        assert mock_ax.errorbar.call_count >= 5

    def test_finalize_plot_helper_method(self):
        """Test _finalize_plot helper method functionality."""
        mock_fig = Mock()
        mock_ax = Mock()

        test_title = "Test Plot Title"
        test_ylabel_units = "raw"
        test_xlabel = "Custom X Label"

        with patch.object(self.plotter, "_format_y_axis") as mock_format_y:
            self.plotter._finalize_plot(mock_fig, mock_ax, test_title, test_ylabel_units, test_xlabel)

            # Verify all formatting components are applied
            mock_ax.axhline.assert_called_with(y=0, color="k", lw=0.6, alpha=0.8)  # Reference line
            mock_ax.set_xlabel.assert_called_with(test_xlabel)
            mock_format_y.assert_called_with(mock_ax, test_ylabel_units)
            mock_ax.grid.assert_called_with(True, alpha=0.3)
            mock_ax.xaxis.set_major_formatter.assert_called()
            mock_ax.legend.assert_called_with(fontsize=18, bbox_to_anchor=(1, 0.8))
            mock_fig.text.assert_called_with(0.02, 1.08, test_title, fontsize=22)

    def test_finalize_plot_default_xlabel(self):
        """Test _finalize_plot with default xlabel."""
        mock_fig = Mock()
        mock_ax = Mock()

        with patch.object(self.plotter, "_format_y_axis"):
            self.plotter._finalize_plot(mock_fig, mock_ax, "Test Title", "raw")

            # Should use default xlabel
            mock_ax.set_xlabel.assert_called_with("Experiment ID")

    @patch("matplotlib.pyplot.subplots")
    def test_plot_experiment_scaled_results_basic(self, mock_subplots):
        """Test basic experiment scaled results plotting."""
        # Add required columns for scaled plotting
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock post_summary with experiment_true_ati entries
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 10),
                "sd": np.random.uniform(0.005, 0.02, 10),
                "hdi_5%": np.random.normal(0.04, 0.01, 10),
                "hdi_95%": np.random.normal(0.06, 0.01, 10),
            },
            index=[f"experiment_true_ati[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_finalize_plot") as mock_finalize:
                fig, ax = self.plotter.plot_experiment_scaled_results(
                    self.df_processed, self.mock_idata, mock_post_summary
                )

                # Verify _finalize_plot was called
                mock_finalize.assert_called_once()

                # Verify return values
                assert fig is mock_fig
                assert ax is mock_ax

                # Verify errorbar calls for scaled data
                assert mock_ax.errorbar.call_count >= 3

    @patch("matplotlib.pyplot.subplots")
    def test_plot_experiment_scaled_results_with_posterior_metrics(self, mock_subplots):
        """Test experiment scaled results with different posterior metrics."""
        # Add required columns
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock post_summary with all required entries
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 20),
                "sd": np.random.uniform(0.005, 0.02, 20),
                "hdi_5%": np.random.normal(0.04, 0.01, 20),
                "hdi_95%": np.random.normal(0.06, 0.01, 20),
            },
            index=[f"experiment_true_ati[{i}]" for i in range(5)]
            + [f"tau[{i}]" for i in range(5)]
            + [f"bias[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_finalize_plot"):
                # Test experiment_true_ati metric
                fig1, ax1 = self.plotter.plot_experiment_scaled_results(
                    self.df_processed, self.mock_idata, mock_post_summary, posterior_metric="experiment_true_ati"
                )

                # Test tau metric
                fig2, ax2 = self.plotter.plot_experiment_scaled_results(
                    self.df_processed, self.mock_idata, mock_post_summary, posterior_metric="tau"
                )

                # Test bias metric
                fig3, ax3 = self.plotter.plot_experiment_scaled_results(
                    self.df_processed, self.mock_idata, mock_post_summary, posterior_metric="bias"
                )

                # All should succeed
                assert fig1 is mock_fig and ax1 is mock_ax
                assert fig2 is mock_fig and ax2 is mock_ax
                assert fig3 is mock_fig and ax3 is mock_ax

    @patch("matplotlib.pyplot.subplots")
    def test_plot_experiment_scaled_results_invalid_metric(self, mock_subplots):
        """Test experiment scaled results with invalid posterior metric."""
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with pytest.raises(ValueError, match="Invalid posterior_metric"):
                self.plotter.plot_experiment_scaled_results(
                    self.df_processed, self.mock_idata, self.mock_post_summary, posterior_metric="invalid"
                )

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    def test_plot_calibration_scaled_results_basic(self, mock_subplots, mock_az_summary):
        """Test basic calibration scaled results plotting."""
        # Add required columns for scaled plotting
        self.df_unpaired["experiment_scale"] = np.random.uniform(1e6, 1e9, 3)
        self.df_unpaired["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 3)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
                "hdi_5%": np.random.normal(0.04, 0.01, 3),
                "hdi_95%": np.random.normal(0.06, 0.01, 3),
            }
        )
        mock_az_summary.return_value = mock_summary

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_finalize_plot") as mock_finalize:
                fig, ax = self.plotter.plot_calibration_scaled_results(self.df_unpaired, self.mock_calibration_trace)

                # Verify _finalize_plot was called with correct xlabel
                mock_finalize.assert_called_once()
                args, kwargs = mock_finalize.call_args
                assert args[4] == "Unpaired Observation ID"  # xlabel parameter

                # Verify return values
                assert fig is mock_fig
                assert ax is mock_ax

                # Verify errorbar calls for scaled data
                assert mock_ax.errorbar.call_count >= 2

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    def test_plot_calibration_scaled_results_fallback(self, mock_subplots, mock_az_summary):
        """Test calibration scaled results with KeyError fallback."""
        self.df_unpaired["experiment_scale"] = np.random.uniform(1e6, 1e9, 3)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary to raise KeyError first, then succeed
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
            }
        )
        mock_az_summary.side_effect = [KeyError("experiment_true_ati_unpaired"), mock_summary]

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_finalize_plot"):
                fig, ax = self.plotter.plot_calibration_scaled_results(
                    self.df_unpaired, self.mock_calibration_trace, calibrated_ati_metric="experiment_true_ati_unpaired"
                )

                # Should have called az.summary twice (first fails, second succeeds)
                assert mock_az_summary.call_count == 2

                # Should succeed with fallback
                assert fig is mock_fig
                assert ax is mock_ax

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    def test_plot_combined_paired_unpaired_scaled_results_basic(self, mock_subplots, mock_az_summary):
        """Test basic combined paired unpaired scaled results plotting."""
        # Add required columns for both dataframes
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)
        self.df_unpaired["experiment_scale"] = np.random.uniform(1e6, 1e9, 3)
        self.df_unpaired["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 3)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_xaxis_transform.return_value = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
                "hdi_5%": np.random.normal(0.04, 0.01, 3),
                "hdi_95%": np.random.normal(0.06, 0.01, 3),
            }
        )
        mock_az_summary.return_value = mock_summary

        # Mock post_summary with experiment_true_ati entries
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 10),
                "sd": np.random.uniform(0.005, 0.02, 10),
                "hdi_5%": np.random.normal(0.04, 0.01, 10),
                "hdi_95%": np.random.normal(0.06, 0.01, 10),
            },
            index=[f"experiment_true_ati[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch.object(
            self.plotter,
            "_setup_plot_style",
            return_value=np.array(["blue", "red", "green", "orange", "purple", "cyan", "magenta"]),
        ):
            with patch.object(self.plotter, "_finalize_plot") as mock_finalize:
                fig, ax = self.plotter.plot_combined_paired_unpaired_scaled_results(
                    self.df_processed, self.mock_idata, mock_post_summary, self.df_unpaired, self.mock_calibration_trace
                )

                # Verify _finalize_plot was called
                mock_finalize.assert_called_once()

                # Verify return values
                assert fig is mock_fig
                assert ax is mock_ax

                # Should have multiple errorbar calls for paired and unpaired scaled data
                assert mock_ax.errorbar.call_count >= 5

                # Should have vertical line and text labels
                mock_ax.axvline.assert_called()
                assert mock_ax.text.call_count >= 2

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    def test_plot_calibration_intensity_results_basic(self, mock_subplots, mock_az_summary):
        """Test basic calibration intensity results plotting."""
        # Add required columns for intensity calculations
        self.df_unpaired["experiment_scale"] = np.random.uniform(1e6, 1e9, 3)
        self.df_unpaired["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 3)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
                "hdi_5%": np.random.normal(0.04, 0.01, 3),
                "hdi_95%": np.random.normal(0.06, 0.01, 3),
            }
        )
        mock_az_summary.return_value = mock_summary

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_finalize_plot") as mock_finalize:
                fig, ax = self.plotter.plot_calibration_intensity_results(self.df_unpaired, self.mock_calibration_trace)

                # Verify _finalize_plot was called with correct xlabel
                mock_finalize.assert_called_once()
                args, kwargs = mock_finalize.call_args
                assert args[4] == "Unpaired Observation ID"  # xlabel parameter

                # Verify return values
                assert fig is mock_fig
                assert ax is mock_ax

                # Verify errorbar calls for intensity data
                assert mock_ax.errorbar.call_count >= 2

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    def test_plot_calibration_intensity_results_with_calibrated_estimates(self, mock_subplots, mock_az_summary):
        """Test calibration intensity results with calibrated_estimates metric."""
        # Add required columns
        self.df_unpaired["experiment_scale"] = np.random.uniform(1e6, 1e9, 3)
        self.df_unpaired["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 3)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
                "hdi_5%": np.random.normal(0.04, 0.01, 3),
                "hdi_95%": np.random.normal(0.06, 0.01, 3),
            }
        )
        mock_az_summary.return_value = mock_summary

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_finalize_plot"):
                fig, ax = self.plotter.plot_calibration_intensity_results(
                    self.df_unpaired, self.mock_calibration_trace, posterior_metric="calibrated_estimates"
                )

                # Should succeed with calibrated_estimates metric
                assert fig is mock_fig
                assert ax is mock_ax

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    def test_plot_combined_paired_unpaired_intensity_results_basic(self, mock_subplots, mock_az_summary):
        """Test basic combined paired unpaired intensity results plotting."""
        # Add required columns for both dataframes
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)
        self.df_unpaired["experiment_scale"] = np.random.uniform(1e6, 1e9, 3)
        self.df_unpaired["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 3)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_xaxis_transform.return_value = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
                "hdi_5%": np.random.normal(0.04, 0.01, 3),
                "hdi_95%": np.random.normal(0.06, 0.01, 3),
            }
        )
        mock_az_summary.return_value = mock_summary

        # Mock post_summary with experiment_true_ati entries
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 10),
                "sd": np.random.uniform(0.005, 0.02, 10),
                "hdi_5%": np.random.normal(0.04, 0.01, 10),
                "hdi_95%": np.random.normal(0.06, 0.01, 10),
            },
            index=[f"experiment_true_ati[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch.object(
            self.plotter,
            "_setup_plot_style",
            return_value=np.array(["blue", "red", "green", "orange", "purple", "cyan", "magenta"]),
        ):
            with patch.object(self.plotter, "_finalize_plot") as mock_finalize:
                fig, ax = self.plotter.plot_combined_paired_unpaired_intensity_results(
                    self.df_processed, self.mock_idata, mock_post_summary, self.df_unpaired, self.mock_calibration_trace
                )

                # Verify _finalize_plot was called
                mock_finalize.assert_called_once()

                # Verify return values
                assert fig is mock_fig
                assert ax is mock_ax

                # Should have multiple errorbar calls for paired and unpaired intensity data
                assert mock_ax.errorbar.call_count >= 5

                # Should have vertical line and text labels
                mock_ax.axvline.assert_called()
                assert mock_ax.text.call_count >= 2

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    def test_plot_combined_intensity_results_with_posterior_metrics(self, mock_subplots, mock_az_summary):
        """Test combined intensity results with different posterior metrics."""
        # Add required columns
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)
        self.df_unpaired["experiment_scale"] = np.random.uniform(1e6, 1e9, 3)
        self.df_unpaired["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 3)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_ax.get_xaxis_transform.return_value = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
            }
        )
        mock_az_summary.return_value = mock_summary

        # Mock post_summary with all required entries for different metrics
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 25),
                "sd": np.random.uniform(0.005, 0.02, 25),
                "hdi_5%": np.random.normal(0.04, 0.01, 25),
                "hdi_95%": np.random.normal(0.06, 0.01, 25),
            },
            index=[f"experiment_true_ati[{i}]" for i in range(5)]
            + [f"tau[{i}]" for i in range(5)]
            + [f"experiment_true_size[{i}]" for i in range(5)]
            + [f"bias[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch.object(
            self.plotter,
            "_setup_plot_style",
            return_value=np.array(["blue", "red", "green", "orange", "purple", "cyan", "magenta"]),
        ):
            with patch.object(self.plotter, "_finalize_plot"):
                # Test experiment_true_ati metric
                fig1, ax1 = self.plotter.plot_combined_paired_unpaired_intensity_results(
                    self.df_processed,
                    self.mock_idata,
                    mock_post_summary,
                    self.df_unpaired,
                    self.mock_calibration_trace,
                    posterior_metric="experiment_true_ati",
                )

                # Test tau metric
                fig2, ax2 = self.plotter.plot_combined_paired_unpaired_intensity_results(
                    self.df_processed,
                    self.mock_idata,
                    mock_post_summary,
                    self.df_unpaired,
                    self.mock_calibration_trace,
                    posterior_metric="tau",
                )

                # Test bias metric
                fig3, ax3 = self.plotter.plot_combined_paired_unpaired_intensity_results(
                    self.df_processed,
                    self.mock_idata,
                    mock_post_summary,
                    self.df_unpaired,
                    self.mock_calibration_trace,
                    posterior_metric="bias",
                )

                # All should succeed
                assert fig1 is mock_fig and ax1 is mock_ax
                assert fig2 is mock_fig and ax2 is mock_ax
                assert fig3 is mock_fig and ax3 is mock_ax

    def test_plot_intensity_posteriors_monte_carlo_uncertainty(self):
        """Test intensity posteriors with Monte Carlo uncertainty propagation."""
        # Add experiment_scale columns to test data
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)

        # Mock post_summary with tau and experiment_true_size entries
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 15),
                "sd": np.random.uniform(0.005, 0.02, 15),
                "hdi_5%": np.random.normal(0.04, 0.01, 15),
                "hdi_95%": np.random.normal(0.06, 0.01, 15),
            },
            index=[f"tau[{i}]" for i in range(5)]
            + [f"experiment_true_size[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch("matplotlib.pyplot.subplots") as mock_subplots:
            mock_fig = Mock()
            mock_ax = Mock()
            mock_subplots.return_value = (mock_fig, mock_ax)

            with patch.object(
                self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
            ):
                with patch.object(self.plotter, "_finalize_plot"):
                    with patch.object(
                        self.plotter,
                        "_get_tau_parameters",
                        return_value=mock_post_summary.loc[["tau[0]", "tau[1]", "tau[2]", "tau[3]", "tau[4]"]],
                    ):
                        with patch.object(
                            self.plotter,
                            "_get_experiment_size_parameters",
                            return_value=mock_post_summary.loc[
                                [
                                    "experiment_true_size[0]",
                                    "experiment_true_size[1]",
                                    "experiment_true_size[2]",
                                    "experiment_true_size[3]",
                                    "experiment_true_size[4]",
                                ]
                            ],
                        ):
                            # Test with Monte Carlo enabled (should fallback due to mock)
                            fig1, ax1 = self.plotter.plot_intensity_posteriors(
                                self.df_processed,
                                self.mock_idata,
                                mock_post_summary,
                                posterior_metric="tau",
                                use_monte_carlo_uncertainty=True,
                            )

                            # Test with Monte Carlo disabled
                            fig2, ax2 = self.plotter.plot_intensity_posteriors(
                                self.df_processed,
                                self.mock_idata,
                                mock_post_summary,
                                posterior_metric="tau",
                                use_monte_carlo_uncertainty=False,
                            )

                            # Both should succeed
                            assert fig1 is mock_fig and ax1 is mock_ax
                            assert fig2 is mock_fig and ax2 is mock_ax

    def test_new_plotting_methods_exist(self):
        """Test that all new plotting methods exist and are callable."""
        plotter = AuxPlots()

        # Check that all new methods exist
        new_methods = [
            "plot_experiment_scaled_results",
            "plot_calibration_scaled_results",
            "plot_combined_paired_unpaired_scaled_results",
            "plot_calibration_intensity_results",
            "plot_combined_paired_unpaired_intensity_results",
        ]

        for method_name in new_methods:
            assert hasattr(plotter, method_name), f"Method {method_name} does not exist"
            assert callable(getattr(plotter, method_name)), f"Method {method_name} is not callable"

    @patch("matplotlib.pyplot.subplots")
    def test_plot_experiment_scaled_results_with_show_means(self, mock_subplots):
        """Test experiment scaled results with show_means parameter."""
        # Add required columns
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock post_summary with mu_ati
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 10),
                "sd": np.random.uniform(0.005, 0.02, 10),
                "hdi_5%": np.random.normal(0.04, 0.01, 10),
                "hdi_95%": np.random.normal(0.06, 0.01, 10),
            },
            index=[f"experiment_true_ati[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_finalize_plot"):
                fig, ax = self.plotter.plot_experiment_scaled_results(
                    self.df_processed, self.mock_idata, mock_post_summary, show_means=True
                )

                # Should have calls for scaled mean lines
                mock_ax.axhspan.assert_called()
                mock_ax.axhline.assert_called()

                # Verify return values
                assert fig is mock_fig
                assert ax is mock_ax

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    def test_plot_calibration_scaled_results_with_bias_corrections(self, mock_subplots, mock_az_summary):
        """Test calibration scaled results with bias corrections."""
        # Add required columns
        self.df_unpaired["experiment_scale"] = np.random.uniform(1e6, 1e9, 3)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
            }
        )
        mock_az_summary.return_value = mock_summary

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_finalize_plot"):
                fig, ax = self.plotter.plot_calibration_scaled_results(
                    self.df_unpaired, self.mock_calibration_trace, show_bias_corrections=True
                )

                # Should have scatter call for scaled bias corrections
                mock_ax.scatter.assert_called()

                # Verify return values
                assert fig is mock_fig
                assert ax is mock_ax

    @patch("arviz.summary")
    @patch("matplotlib.pyplot.subplots")
    def test_plot_calibration_intensity_results_with_bias_corrections(self, mock_subplots, mock_az_summary):
        """Test calibration intensity results with bias corrections."""
        # Add required columns
        self.df_unpaired["experiment_scale"] = np.random.uniform(1e6, 1e9, 3)
        self.df_unpaired["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 3)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock ArviZ summary
        mock_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 3),
                "sd": np.random.uniform(0.005, 0.02, 3),
            }
        )
        mock_az_summary.return_value = mock_summary

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_finalize_plot"):
                fig, ax = self.plotter.plot_calibration_intensity_results(
                    self.df_unpaired, self.mock_calibration_trace, show_bias_corrections=True
                )

                # Should have scatter call for intensity bias corrections
                mock_ax.scatter.assert_called()

                # Verify return values
                assert fig is mock_fig
                assert ax is mock_ax

    @patch("matplotlib.pyplot.subplots")
    def test_plot_experiment_scaled_results_custom_metrics(self, mock_subplots):
        """Test experiment scaled results with custom metric column names."""
        # Add required columns with custom names
        self.df_processed["custom_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["custom_scale_se"] = np.random.uniform(1e5, 1e8, 5)
        self.df_processed["custom_exp_est"] = np.random.normal(0.05, 0.02, 5)
        self.df_processed["custom_exp_se"] = np.random.uniform(0.01, 0.03, 5)
        self.df_processed["custom_obs_est"] = np.random.normal(0.06, 0.025, 5)
        self.df_processed["custom_obs_se"] = np.random.uniform(0.015, 0.035, 5)

        mock_fig = Mock()
        mock_ax = Mock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        # Mock post_summary
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 10),
                "sd": np.random.uniform(0.005, 0.02, 10),
                "hdi_5%": np.random.normal(0.04, 0.01, 10),
                "hdi_95%": np.random.normal(0.06, 0.01, 10),
            },
            index=[f"experiment_true_ati[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch.object(
            self.plotter, "_setup_plot_style", return_value=np.array(["blue", "red", "green", "orange", "purple"])
        ):
            with patch.object(self.plotter, "_finalize_plot"):
                fig, ax = self.plotter.plot_experiment_scaled_results(
                    self.df_processed,
                    self.mock_idata,
                    mock_post_summary,
                    scaling_metric="custom_scale",
                    experiment_ati_metric="custom_exp_est",
                    experiment_ati_se_metric="custom_exp_se",
                    obs_ati_metric="custom_obs_est",
                    obs_ati_se_metric="custom_obs_se",
                )

                # Should succeed with custom column names
                assert fig is mock_fig
                assert ax is mock_ax

    def test_all_new_methods_use_finalize_plot(self):
        """Test that all new plotting methods use _finalize_plot helper."""
        # Add required columns for all tests
        self.df_processed["experiment_scale"] = np.random.uniform(1e6, 1e9, 5)
        self.df_processed["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 5)
        self.df_unpaired["experiment_scale"] = np.random.uniform(1e6, 1e9, 3)
        self.df_unpaired["experiment_scale_se"] = np.random.uniform(1e5, 1e8, 3)

        # Mock post_summary with all required entries
        mock_post_summary = pd.DataFrame(
            {
                "mean": np.random.normal(0.05, 0.01, 15),
                "sd": np.random.uniform(0.005, 0.02, 15),
                "hdi_5%": np.random.normal(0.04, 0.01, 15),
                "hdi_95%": np.random.normal(0.06, 0.01, 15),
            },
            index=[f"experiment_true_ati[{i}]" for i in range(5)]
            + [f"tau[{i}]" for i in range(5)]
            + ["mu_ati", "mean_bias", "sigma_ati", "mu_scale", "sigma_scale"],
        )

        with patch("matplotlib.pyplot.subplots") as mock_subplots:
            with patch("arviz.summary") as mock_az_summary:
                mock_fig = Mock()
                mock_ax = Mock()
                mock_ax.get_xaxis_transform.return_value = Mock()
                mock_subplots.return_value = (mock_fig, mock_ax)

                mock_summary = pd.DataFrame(
                    {
                        "mean": np.random.normal(0.05, 0.01, 3),
                        "sd": np.random.uniform(0.005, 0.02, 3),
                    }
                )
                mock_az_summary.return_value = mock_summary

                with patch.object(
                    self.plotter,
                    "_setup_plot_style",
                    return_value=np.array(["blue", "red", "green", "orange", "purple", "cyan", "magenta"]),
                ):
                    with patch.object(self.plotter, "_finalize_plot") as mock_finalize:
                        # Test all new methods use _finalize_plot
                        methods_to_test = [
                            ("plot_experiment_scaled_results", (self.df_processed, self.mock_idata, mock_post_summary)),
                            ("plot_calibration_scaled_results", (self.df_unpaired, self.mock_calibration_trace)),
                            (
                                "plot_combined_paired_unpaired_scaled_results",
                                (
                                    self.df_processed,
                                    self.mock_idata,
                                    mock_post_summary,
                                    self.df_unpaired,
                                    self.mock_calibration_trace,
                                ),
                            ),
                            ("plot_calibration_intensity_results", (self.df_unpaired, self.mock_calibration_trace)),
                            (
                                "plot_combined_paired_unpaired_intensity_results",
                                (
                                    self.df_processed,
                                    self.mock_idata,
                                    mock_post_summary,
                                    self.df_unpaired,
                                    self.mock_calibration_trace,
                                ),
                            ),
                        ]

                        for method_name, args in methods_to_test:
                            mock_finalize.reset_mock()
                            method = getattr(self.plotter, method_name)
                            fig, ax = method(*args)

                            # Verify _finalize_plot was called for each method
                            mock_finalize.assert_called_once(), f"Method {method_name} did not call _finalize_plot"

                            # Verify return values
                            assert fig is mock_fig
                            assert ax is mock_ax

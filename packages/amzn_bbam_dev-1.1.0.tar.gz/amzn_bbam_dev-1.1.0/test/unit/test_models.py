"""
Unit tests for BBAM model classes.

Extracted from test_bbam.py - TestBbamAnalyzer and TestBbamImports classes.
Tests individual model classes in isolation.
"""

import sys
from pathlib import Path

import pandas as pd
import pytest

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))


class TestBbamImports:
    """Test basic imports and module availability."""

    def test_bbam_importable(self):
        """Test bbam is importable."""
        import bbam  # noqa: F401

    def test_core_components_importable(self):
        """Test core components are importable."""
        from bbam import BbamAnalyzer
        from bbam.config import ConfigurationManager
        from bbam.core import DataProcessor, ResultsProcessor
        from bbam.utils.logging_config import setup_logger

        assert BbamAnalyzer is not None
        assert DataProcessor is not None
        assert ResultsProcessor is not None
        assert ConfigurationManager is not None
        assert setup_logger is not None


class TestBbamAnalyzer:
    """Test BbamAnalyzer functionality."""

    @pytest.fixture
    def sample_data(self):
        """Create sample data for testing."""
        return pd.DataFrame(
            {
                "experiment_est": [0.1, 0.2, 0.15],
                "experiment_est_se": [0.05, 0.03, 0.04],
                "obs_model_est": [0.12, 0.18, 0.14],
                "obs_model_est_se": [0.06, 0.04, 0.05],
            }
        )

    def test_bbam_analyzer_initialization(self):
        """Test BbamAnalyzer initialization."""
        from bbam import BbamAnalyzer

        model = BbamAnalyzer(model_type="standard")

        assert model.model_type == "standard"
        assert model.config is not None
        assert model.model is not None

    def test_bbam_analyzer_invalid_type(self):
        """Test BbamAnalyzer with invalid model type."""
        from bbam import BbamAnalyzer

        with pytest.raises(ValueError, match="Invalid model_type"):
            BbamAnalyzer(model_type="invalid_type")

    def test_bbam_analyzer_with_config(self):
        """Test BbamAnalyzer with custom configuration."""
        from bbam import BbamAnalyzer

        config = {
            "sampling_settings": {
                "tune": 1000,
                "draws": 500,
                "chains": 4,
                "cores": 4,
                "target_accept": 0.95,
                "maxdepth": 15,
                "is_random_seed": False,
                "seed": 123,
                "n_sample_posterior": 100,
            },
            "model_settings": {"bias_spec": "BOTH_INT_MULT", "likelihood_distribution": "normal"},
            "data_driven_priors": False,
            "priors": {
                "mu_beta_0": {"delta_mu_beta_0": 0.0, "gamma_mu_beta_0": 1.0},
                "sigma_beta_0": {"zeta_sigma_beta_0": 1.0},
                "mu_beta_1": {"delta_mu_beta_1": 0.0, "gamma_mu_beta_1": 1.0},
                "sigma_beta_1": {"zeta_sigma_beta_1": 1.0},
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
            },
            "warning_level_setting": "normal",
            "warning_level_definition": {"normal": {"rhat_threshold": 1.01}},
        }

        model = BbamAnalyzer(model_type="standard", config=config)
        assert model.config["sampling_settings"]["seed"] == 123


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

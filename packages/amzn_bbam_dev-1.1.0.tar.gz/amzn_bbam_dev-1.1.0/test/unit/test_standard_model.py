"""
Unit tests for RCTObsHBM (Standard Model).

This module tests the standard model functionality including configuration validation,
data processing, prior calculations, and model building.
"""

from unittest.mock import Mock, patch

import numpy as np
import pandas as pd
import pytest

from bbam.models.standard_model import RCTObsHBM
from bbam.utils.enums import BiasSpecification, LikelihoodDistribution


class TestRCTObsHBM:
    """Test cases for RCTObsHBM class."""

    def setup_method(self):
        """Set up test fixtures."""
        self.model = RCTObsHBM()

        # Sample data for testing
        np.random.seed(42)
        self.sample_data = pd.DataFrame(
            {
                "experiment_est": np.random.normal(0.05, 0.02, 10),
                "experiment_est_se": np.random.uniform(0.01, 0.03, 10),
                "obs_model_est": np.random.normal(0.06, 0.025, 10),
                "obs_model_est_se": np.random.uniform(0.015, 0.035, 10),
            }
        )

        # Sample configuration
        self.sample_config = {
            "data_driven_priors": False,
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": LikelihoodDistribution.NORMAL.value,
                "skip_model_posterior_metrics": False,
            },
            "sampling_settings": {"n_sample_posterior": 0},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            },
            "priors": {
                "mu_tau": {"delta_mu_tau": 0.05, "gamma_mu_tau": 0.02},
                "sigma_tau": {"zeta_sigma_tau": 0.01},
                "mu_beta_0": {"delta_beta_0": 0.0, "gamma_beta_0": 0.01},
                "sigma_beta_0": {"zeta_beta_0": 0.005},
                "mu_beta_1": {"delta_beta_1": 0.5, "gamma_beta_1": 0.2},
                "sigma_beta_1": {"zeta_beta_1": 0.1},
            },
        }

    def test_get_required_data_columns(self):
        """Test that required data columns are correctly specified."""
        required_cols = self.model.get_required_data_columns()
        expected_cols = [
            "experiment_est",
            "experiment_est_se",
            "obs_model_est",
            "obs_model_est_se",
        ]
        assert required_cols == expected_cols

    def test_prepare_config_valid(self):
        """Test configuration preparation with valid config."""
        prepared_config = self.model._prepare_config(self.sample_config)

        assert prepared_config is not None
        assert "model_settings" in prepared_config
        assert prepared_config["model_settings"]["bias_spec"] == BiasSpecification.BOTH_INT_MULT.value

    def test_prepare_config_none(self):
        """Test configuration preparation with None config."""
        with pytest.raises(ValueError, match="Configuration cannot be None"):
            self.model._prepare_config(None)

    def test_prepare_config_missing_model_settings(self):
        """Test configuration preparation with missing model_settings."""
        invalid_config = {"data_driven_priors": False}
        with pytest.raises(ValueError, match="Missing required section: model_settings"):
            self.model._prepare_config(invalid_config)

    def test_prepare_config_missing_bias_spec(self):
        """Test configuration preparation with missing bias_spec."""
        invalid_config = {"data_driven_priors": False, "model_settings": {}}
        with pytest.raises(ValueError, match="Missing required parameter: bias_spec in model_settings section"):
            self.model._prepare_config(invalid_config)

    def test_prepare_config_invalid_bias_spec(self):
        """Test configuration preparation with invalid bias_spec."""
        invalid_config = {"model_settings": {"bias_spec": "INVALID_SPEC"}}
        with pytest.raises(ValueError, match="Invalid bias_spec value"):
            self.model._prepare_config(invalid_config)

    def test_prepare_config_adds_defaults(self):
        """Test that configuration preparation adds default values."""
        minimal_config = {
            "data_driven_priors": False,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            },
        }
        prepared_config = self.model._prepare_config(minimal_config)

        assert prepared_config["model_settings"]["likelihood_distribution"] == LikelihoodDistribution.NORMAL.value
        assert prepared_config["model_settings"]["skip_model_posterior_metrics"] is False

    def test_prepare_config_invalid_likelihood_distribution(self):
        """Test configuration preparation with invalid likelihood_distribution."""
        invalid_config = {
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": "invalid_distribution",
            }
        }

        with pytest.raises(ValueError, match="Invalid likelihood_distribution value"):
            self.model._prepare_config(invalid_config)

    def test_prepare_config_skip_posterior_metrics_validation(self):
        """Test skip_model_posterior_metrics validation."""
        # Test with invalid type
        config_invalid = {
            "data_driven_priors": False,
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "skip_model_posterior_metrics": "invalid",
            },
        }

        with pytest.raises(ValueError, match="Invalid skip_model_posterior_metrics value"):
            self.model._prepare_config(config_invalid)

    def test_prepare_config_student_t_validation(self):
        """Test Student's t likelihood validation."""
        config_with_student_t = {
            "data_driven_priors": False,
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": LikelihoodDistribution.STUDENT_T.value,
            },
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            },
        }

        # Should raise error without student_df
        with pytest.raises(ValueError, match="student_df"):
            self.model._prepare_config(config_with_student_t)

        # Test with invalid student_df
        config_with_student_t["model_settings"]["student_df"] = -1
        with pytest.raises(ValueError, match="student_df must be a positive number"):
            self.model._prepare_config(config_with_student_t)

        # Should pass with valid student_df
        config_with_student_t["model_settings"]["student_df"] = 6
        prepared_config = self.model._prepare_config(config_with_student_t)
        assert prepared_config["model_settings"]["student_df"] == 6

    def test_prepare_config_data_driven_priors_missing_settings(self):
        """Test data-driven priors with missing settings."""
        config_dd_incomplete = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
        }

        with pytest.raises(ValueError, match="data_driven_priors_settings"):
            self.model._prepare_config(config_dd_incomplete)

    def test_prepare_config_data_driven_priors_missing_treatment_effect(self):
        """Test data-driven priors with missing treatment_effect section."""
        config_missing_te = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {},
        }
        with pytest.raises(ValueError, match="'treatment_effect' section must be provided"):
            self.model._prepare_config(config_missing_te)

    def test_prepare_config_data_driven_priors_missing_te_parameters(self):
        """Test data-driven priors with missing treatment_effect parameters."""
        # Missing scale_prior_width_mean
        config_missing_param = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_sigma": 6.0}  # Missing scale_prior_width_mean
            },
        }
        with pytest.raises(ValueError, match="scale_prior_width_mean parameter must be provided"):
            self.model._prepare_config(config_missing_param)

        # Missing scale_prior_width_sigma
        config_missing_param2 = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0}  # Missing scale_prior_width_sigma
            },
        }
        with pytest.raises(ValueError, match="scale_prior_width_sigma parameter must be provided"):
            self.model._prepare_config(config_missing_param2)

    def test_get_data_driven_priors(self):
        """Test data-driven priors calculation."""
        # Set up config for data-driven priors
        self.model.config = {
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            }
        }

        priors = self.model._get_data_driven_priors(self.sample_data)

        assert "mu_tau" in priors
        assert "sigma_tau" in priors
        assert "mu_beta_0" in priors
        assert "sigma_beta_0" in priors
        assert "mu_beta_1" in priors
        assert "sigma_beta_1" in priors

    def test_validate_priors_valid(self):
        """Test prior validation with valid priors."""
        valid_priors = self.sample_config["priors"]
        assert self.model._validate_priors(valid_priors) is True

    def test_validate_priors_missing(self):
        """Test prior validation with missing priors."""
        incomplete_priors = {"mu_tau": {"delta_mu_tau": 0.05, "gamma_mu_tau": 0.02}}

        with pytest.raises(ValueError, match="Missing required priors"):
            self.model._validate_priors(incomplete_priors)

    def test_set_variables_metadata(self):
        """Test variable metadata setup."""
        self.model.config = self.sample_config
        result = self.model._set_variables_metadata()

        assert result is self.model
        assert hasattr(self.model, "vars_trace_plot")
        assert hasattr(self.model, "vars_table_full")
        assert hasattr(self.model, "vars_table_short")
        assert hasattr(self.model, "vars_display_names")

        # Check that variable names are present
        assert "mu_tau" in self.model.vars_trace_plot
        assert "sigma_tau" in self.model.vars_trace_plot
        assert "mean_bias" in self.model.vars_trace_plot

    def test_get_posterior_predictive_vars(self):
        """Test posterior predictive variable names."""
        vars_list = self.model.get_posterior_predictive_vars()

        expected_vars = [
            "mean_tau_tilde",
            "tau_tilde",
            "mean_bias_tilde",
            "bias_tilde",
            "mean_obs_model_est_tilde",
            "obs_model_est_tilde",
            "std_tau_tilde",
            "std_bias_tilde",
            "std_obs_model_est_tilde",
        ]

        for var in expected_vars:
            assert var in vars_list

    def test_posterior_predictive_with_samples(self):
        """Test posterior predictive variable setup when samples > 0."""
        config_with_pp = self.sample_config.copy()
        config_with_pp["sampling_settings"]["n_sample_posterior"] = 100

        self.model.config = config_with_pp
        self.model._set_variables_metadata()

        # Check that posterior predictive variables are added to full table
        assert "mean_tau_tilde" in self.model.vars_table_full
        assert "bias_tilde" in self.model.vars_table_full

    @patch("pymc.Model")
    def test_define_data(self, mock_pymc_model):
        """Test data variable definition."""
        mock_model = Mock()

        with patch("pymc.Data"):
            data_vars = self.model._define_data(self.sample_data, mock_model)

            assert data_vars["n_obs"] == len(self.sample_data)
            assert "tau_experiment_est" in data_vars
            assert "sigma_experiment_est" in data_vars
            assert "tau_obs_model_est" in data_vars
            assert "sigma_obs_model_est" in data_vars

    @patch("pymc.Normal")
    @patch("pymc.HalfCauchy")
    def test_define_priors_on_params(self, mock_halfcauchy, mock_normal):
        """Test prior parameter definition."""
        self.model.priors = self.sample_config["priors"]
        self.model.config = self.sample_config

        params = self.model._define_priors_on_params()

        assert "mu_tau" in params
        assert "sigma_tau" in params

    @patch("pymc.Normal")
    @patch("pymc.HalfCauchy")
    def test_define_priors_on_params_only_int_bias(self, mock_halfcauchy, mock_normal):
        """Test prior parameter definition with ONLY_INT bias specification."""
        config_only_int = self.sample_config.copy()
        config_only_int["model_settings"]["bias_spec"] = BiasSpecification.ONLY_INT.value

        self.model.priors = self.sample_config["priors"]
        self.model.config = config_only_int

        params = self.model._define_priors_on_params()

        assert "mu_tau" in params
        assert "sigma_tau" in params
        assert "mu_beta_0" in params
        assert "sigma_beta_0" in params
        # Should not have mu_beta_1 and sigma_beta_1 for ONLY_INT
        assert "mu_beta_1" not in params
        assert "sigma_beta_1" not in params

    @patch("pymc.Normal")
    @patch("pymc.HalfCauchy")
    def test_define_priors_on_params_only_mult_bias(self, mock_halfcauchy, mock_normal):
        """Test prior parameter definition with ONLY_MULT bias specification."""
        config_only_mult = self.sample_config.copy()
        config_only_mult["model_settings"]["bias_spec"] = BiasSpecification.ONLY_MULT.value

        self.model.priors = self.sample_config["priors"]
        self.model.config = config_only_mult

        params = self.model._define_priors_on_params()

        assert "mu_tau" in params
        assert "sigma_tau" in params
        assert "mu_beta_1" in params
        assert "sigma_beta_1" in params
        # Should not have mu_beta_0 and sigma_beta_0 for ONLY_MULT
        assert "mu_beta_0" not in params
        assert "sigma_beta_0" not in params

    def test_build_calibration_model_validation(self):
        """Test calibration model validation."""
        # Test with None data
        with pytest.raises(ValueError, match="df_unpaired cannot be None or empty"):
            self.model.build_calibration_model(None, Mock())

        # Test with empty data
        empty_df = pd.DataFrame()
        with pytest.raises(ValueError, match="df_unpaired cannot be None or empty"):
            self.model.build_calibration_model(empty_df, Mock())

        # Test with missing columns
        incomplete_df = pd.DataFrame({"obs_model_est": [0.05, 0.06]})

        with pytest.raises(ValueError, match="Missing required columns"):
            self.model.build_calibration_model(incomplete_df, Mock())

    def test_build_calibration_model_with_valid_data(self):
        """Test calibration model building with valid data and validate calibration logic."""
        # Create mock trace with realistic posterior values
        mock_trace = Mock()
        expected_mu_tau_mean = 0.05
        expected_mu_tau_std = 0.01
        expected_sigma_tau_mean = 0.02
        expected_mu_beta_0_mean = 0.01
        expected_mu_beta_0_std = 0.005
        expected_sigma_beta_0_mean = 0.005
        expected_mu_beta_1_mean = 0.5
        expected_mu_beta_1_std = 0.1
        expected_sigma_beta_1_mean = 0.1

        mock_trace.posterior = {
            "mu_tau": Mock(
                values=Mock(
                    flatten=Mock(
                        return_value=Mock(
                            mean=Mock(return_value=expected_mu_tau_mean), std=Mock(return_value=expected_mu_tau_std)
                        )
                    )
                )
            ),
            "sigma_tau": Mock(
                values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=expected_sigma_tau_mean))))
            ),
            "mu_beta_0": Mock(
                values=Mock(
                    flatten=Mock(
                        return_value=Mock(
                            mean=Mock(return_value=expected_mu_beta_0_mean),
                            std=Mock(return_value=expected_mu_beta_0_std),
                        )
                    )
                )
            ),
            "sigma_beta_0": Mock(
                values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=expected_sigma_beta_0_mean))))
            ),
            "mu_beta_1": Mock(
                values=Mock(
                    flatten=Mock(
                        return_value=Mock(
                            mean=Mock(return_value=expected_mu_beta_1_mean),
                            std=Mock(return_value=expected_mu_beta_1_std),
                        )
                    )
                )
            ),
            "sigma_beta_1": Mock(
                values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=expected_sigma_beta_1_mean))))
            ),
        }

        self.model.config = self.sample_config

        # Create unpaired data
        unpaired_data = self.sample_data.loc[:, ["obs_model_est", "obs_model_est_se"]].copy()

        with patch("pymc.Model"):
            with patch("pymc.Data") as mock_data:
                with patch("pymc.Normal") as mock_normal:
                    with patch("pymc.HalfCauchy") as mock_halfcauchy:
                        with patch("pymc.Deterministic") as mock_deterministic:
                            calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)

                            # Verify that the model is created
                            assert calibration_model is not None

                            # Verify that PyMC.Data was called with the correct unpaired data
                            data_calls = mock_data.call_args_list
                            assert len(data_calls) >= 2  # At least obs_model_est_unpaired and obs_model_est_se_unpaired

                            # Verify that Normal distributions are created with expected parameters from trace
                            normal_calls = mock_normal.call_args_list

                            # Should have calls for mu_tau_cal, mu_beta_0_cal, mu_beta_1_cal, and bias components
                            assert len(normal_calls) >= 4

                            # Verify HalfCauchy distributions are created
                            halfcauchy_calls = mock_halfcauchy.call_args_list
                            assert len(halfcauchy_calls) >= 3  # sigma_tau_cal, sigma_beta_0_cal, sigma_beta_1_cal

                            # Verify that Deterministic is called for calibrated_estimates
                            deterministic_calls = mock_deterministic.call_args_list
                            assert len(deterministic_calls) >= 1

                            # Verify that _extract_posterior_values was called for parameter extraction
                            # This is implicitly tested by the mock trace structure working correctly

                            # Verify that the bias specification logic is handled correctly
                            # For BOTH_INT_MULT, should create both intercept and multiplier components
                            bias_spec = self.model.config["model_settings"]["bias_spec"]
                            assert bias_spec == BiasSpecification.BOTH_INT_MULT.value

    def test_build_model_missing_config(self):
        """Test build method with missing config."""
        # Test with None config
        self.model.config = None
        with pytest.raises(ValueError, match="Configuration must be provided"):
            self.model.build(self.sample_data)

    def test_bias_specification_validation(self):
        """Test different bias specifications."""
        # Test ONLY_INT
        config_only_int = self.sample_config.copy()
        config_only_int["model_settings"]["bias_spec"] = BiasSpecification.ONLY_INT.value

        prepared_config = self.model._prepare_config(config_only_int)
        assert prepared_config["model_settings"]["bias_spec"] == BiasSpecification.ONLY_INT.value

        # Test ONLY_MULT
        config_only_mult = self.sample_config.copy()
        config_only_mult["model_settings"]["bias_spec"] = BiasSpecification.ONLY_MULT.value

        prepared_config = self.model._prepare_config(config_only_mult)
        assert prepared_config["model_settings"]["bias_spec"] == BiasSpecification.ONLY_MULT.value

    def test_data_driven_priors_validation(self):
        """Test data-driven priors configuration validation."""
        config_dd = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            },
        }

        prepared_config = self.model._prepare_config(config_dd)
        assert prepared_config["data_driven_priors"] is True

    def test_data_driven_priors_missing_bias_intercept_section(self):
        """Test data-driven priors with missing bias_intercept section."""
        config_missing_bias_int = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
            },
        }
        with pytest.raises(ValueError, match="'bias_intercept' section must be provided"):
            self.model._prepare_config(config_missing_bias_int)

        # Test missing parameters in bias_intercept
        config_missing_bias_int_param = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_sigma": 2.0},  # Missing scale_prior_width_mean
            },
        }
        with pytest.raises(
            ValueError, match="scale_prior_width_mean parameter must be provided in the 'bias_intercept'"
        ):
            self.model._prepare_config(config_missing_bias_int_param)

        # Missing scale_prior_width_sigma in bias_intercept
        config_missing_bias_int_param2 = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0},  # Missing scale_prior_width_sigma
            },
        }
        with pytest.raises(
            ValueError, match="scale_prior_width_sigma parameter must be provided in the 'bias_intercept'"
        ):
            self.model._prepare_config(config_missing_bias_int_param2)

    def test_data_driven_priors_missing_bias_multiplier_section(self):
        """Test data-driven priors with missing bias_multiplier section and parameters."""
        # Missing bias_multiplier section
        config_missing_bias_mult = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
            },
        }
        with pytest.raises(ValueError, match="'bias_multiplier' section must be provided"):
            self.model._prepare_config(config_missing_bias_mult)

        # Missing center_prior_mean in bias_multiplier
        config_missing_param = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"prior_width_mean": 1.0, "prior_width_sigma": 2.0},  # Missing center_prior_mean
            },
        }
        with pytest.raises(ValueError, match="center_prior_mean parameter must be provided"):
            self.model._prepare_config(config_missing_param)

        # Missing prior_width_mean in bias_multiplier
        config_missing_param2 = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_sigma": 2.0},  # Missing prior_width_mean
            },
        }
        with pytest.raises(ValueError, match="prior_width_mean parameter must be provided"):
            self.model._prepare_config(config_missing_param2)

        # Missing prior_width_sigma in bias_multiplier
        config_missing_param3 = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0},  # Missing prior_width_sigma
            },
        }
        with pytest.raises(ValueError, match="prior_width_sigma parameter must be provided"):
            self.model._prepare_config(config_missing_param3)

    def test_build_calibration_model_bias_branches(self):
        """Test calibration model building with different bias specifications."""
        # Create mock trace
        mock_trace = Mock()
        mock_trace.posterior = {
            "mu_tau": Mock(
                values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.05), std=Mock(return_value=0.01))))
            ),
            "sigma_tau": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.02))))),
            "mu_beta_0": Mock(
                values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01), std=Mock(return_value=0.005))))
            ),
            "sigma_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.005))))),
            "mu_beta_1": Mock(
                values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.5), std=Mock(return_value=0.1))))
            ),
            "sigma_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.1))))),
        }

        unpaired_data = self.sample_data.loc[:, ["obs_model_est", "obs_model_est_se"]].copy()

        # Test BOTH_INT_MULT bias specification
        config_both = self.sample_config.copy()
        config_both["model_settings"]["bias_spec"] = BiasSpecification.BOTH_INT_MULT.value
        self.model.config = config_both

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.HalfCauchy"):
                        with patch("pymc.Deterministic"):
                            calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                            assert calibration_model is not None

        # Test ONLY_INT bias specification
        config_only_int = self.sample_config.copy()
        config_only_int["model_settings"]["bias_spec"] = BiasSpecification.ONLY_INT.value
        self.model.config = config_only_int

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.HalfCauchy"):
                        with patch("pymc.Deterministic"):
                            calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                            assert calibration_model is not None

        # Test ONLY_MULT bias specification
        config_only_mult = self.sample_config.copy()
        config_only_mult["model_settings"]["bias_spec"] = BiasSpecification.ONLY_MULT.value
        self.model.config = config_only_mult

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.HalfCauchy"):
                        with patch("pymc.Deterministic"):
                            calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                            assert calibration_model is not None

    def test_build_calibration_model_student_t_likelihood(self):
        """Test calibration model building with Student's t likelihood."""
        config_student_t = self.sample_config.copy()
        config_student_t["model_settings"]["likelihood_distribution"] = LikelihoodDistribution.STUDENT_T.value
        config_student_t["model_settings"]["student_df"] = 6
        self.model.config = config_student_t

        # Create mock trace
        mock_trace = Mock()
        mock_trace.posterior = {
            "mu_tau": Mock(
                values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.05), std=Mock(return_value=0.01))))
            ),
            "sigma_tau": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.02))))),
            "mu_beta_0": Mock(
                values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01), std=Mock(return_value=0.005))))
            ),
            "sigma_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.005))))),
            "mu_beta_1": Mock(
                values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.5), std=Mock(return_value=0.1))))
            ),
            "sigma_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.1))))),
        }

        unpaired_data = self.sample_data.loc[:, ["obs_model_est", "obs_model_est_se"]].copy()

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.HalfCauchy"):
                        with patch("pymc.Deterministic"):
                            with patch("pymc.StudentT"):
                                calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                                assert calibration_model is not None

    def test_define_posterior_predictive_vars_config_validation(self):
        """Test posterior predictive variable definition configuration validation."""
        # Test that the method exists and can be called
        assert hasattr(self.model, "define_posterior_predictive_vars")
        assert callable(self.model.define_posterior_predictive_vars)

        # Test that it requires a pymc_model and config to be set
        self.model.config = self.sample_config

        # Without pymc_model, it should fail gracefully
        with pytest.raises(AttributeError):
            self.model.define_posterior_predictive_vars(100)

    def test_model_initialization(self):
        """Test model initialization."""
        # Test with logger
        mock_logger = Mock()
        model_with_logger = RCTObsHBM(logger=mock_logger)
        assert model_with_logger.logger is not None

        # Test without logger
        model_without_logger = RCTObsHBM()
        assert model_without_logger.logger is not None

    def test_variable_display_names(self):
        """Test that display names are properly set."""
        self.model.config = self.sample_config
        self.model._set_variables_metadata()

        expected_names = {
            "mu_tau": "Avg. treatment effect",
            "sigma_tau": "Std. dev. of treatment effects",
            "mean_bias": "Average model bias across observations",
            "mean_obs_model": "Average observational model estimate across observations",
        }

        for var, expected_name in expected_names.items():
            assert self.model.vars_display_names[var] == expected_name

    def test_likelihood_distributions(self):
        """Test different likelihood distributions."""
        # Test Normal likelihood
        config_normal = self.sample_config.copy()
        config_normal["model_settings"]["likelihood_distribution"] = LikelihoodDistribution.NORMAL.value

        prepared_config = self.model._prepare_config(config_normal)
        assert prepared_config["model_settings"]["likelihood_distribution"] == LikelihoodDistribution.NORMAL.value

        # Test Student's t likelihood
        config_student_t = self.sample_config.copy()
        config_student_t["model_settings"]["likelihood_distribution"] = LikelihoodDistribution.STUDENT_T.value
        config_student_t["model_settings"]["student_df"] = 6

        prepared_config = self.model._prepare_config(config_student_t)
        assert prepared_config["model_settings"]["likelihood_distribution"] == LikelihoodDistribution.STUDENT_T.value
        assert prepared_config["model_settings"]["student_df"] == 6

    def test_skip_posterior_metrics_option(self):
        """Test skip_model_posterior_metrics configuration option."""
        config_skip = self.sample_config.copy()
        config_skip["model_settings"]["skip_model_posterior_metrics"] = True

        prepared_config = self.model._prepare_config(config_skip)
        assert prepared_config["model_settings"]["skip_model_posterior_metrics"] is True

    def test_build_model_with_data_driven_priors(self):
        """Test model building with data-driven priors enabled."""
        config_dd = {
            "data_driven_priors": True,
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": LikelihoodDistribution.NORMAL.value,
                "skip_model_posterior_metrics": False,
            },
            "sampling_settings": {"n_sample_posterior": 0},
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            },
        }

        # Test that data-driven priors can be calculated and model can be prepared
        prepared_config = self.model._prepare_config(config_dd)
        assert prepared_config["data_driven_priors"] is True

        # Test that data-driven priors are calculated correctly
        self.model.config = config_dd
        priors = self.model._get_data_driven_priors(self.sample_data)
        assert len(priors) == 6  # Should have all 6 required priors

    def test_calibration_model_invalid_bias_spec_error(self):
        """Test calibration model with invalid bias specification raises error."""
        # Create mock trace
        mock_trace = Mock()
        mock_trace.posterior = {
            "mu_tau": Mock(
                values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.05), std=Mock(return_value=0.01))))
            ),
            "sigma_tau": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.02))))),
        }

        # Set invalid bias specification
        config_invalid = self.sample_config.copy()
        config_invalid["model_settings"]["bias_spec"] = "INVALID_SPEC"
        self.model.config = config_invalid

        unpaired_data = self.sample_data.loc[:, ["obs_model_est", "obs_model_est_se"]].copy()

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.HalfCauchy"):
                        with pytest.raises(ValueError, match="Invalid bias specification"):
                            self.model.build_calibration_model(unpaired_data, mock_trace)

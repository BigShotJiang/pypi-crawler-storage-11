"""
Unit tests for BBAM results processing functionality.

Extracted from test_bbam.py - TestResultsProcessor class.
Tests the ResultsProcessor component in isolation.
"""

import sys
from pathlib import Path
from unittest.mock import Mock

import numpy as np
import pandas as pd
import pytest

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))


class TestResultsProcessor:
    """Test ResultsProcessor functionality."""

    @pytest.fixture
    def results_processor(self):
        """Create ResultsProcessor instance."""
        from bbam.core.results_processor import ResultsProcessor

        return ResultsProcessor()

    @pytest.fixture
    def mock_trace(self):
        """Create mock trace data."""
        # Create a simple mock trace
        mock_trace = Mock()
        mock_trace.posterior = Mock()
        mock_trace.posterior.data_vars = ["mu_tau", "mu_beta_0"]

        # Mock variable data
        mock_var = Mock()
        mock_var.values = np.random.normal(0.1, 0.05, (4, 1000))  # 4 chains, 1000 draws
        mock_trace.posterior.__getitem__ = Mock(return_value=mock_var)

        return mock_trace

    @pytest.fixture
    def mock_model_metadata(self):
        """Create mock model metadata."""
        return {
            "vars_table_full": ["mu_tau", "mu_beta_0", "tau_tilde"],
            "vars_table_short": ["mu_tau", "tau_tilde"],
            "vars_display_names": {
                "mu_tau": "Average Treatment Effect",
                "tau_tilde": "Individual Treatment Effect",
            },
            "posterior_predictive_vars": ["tau_tilde"],
        }

    def test_format_results_dataframe(self, results_processor):
        """Test formatting results as DataFrame."""
        sample_df = pd.DataFrame({"mean": [0.1, 0.2], "std": [0.05, 0.03]})
        result = results_processor.format_results(sample_df, "dataframe")

        assert isinstance(result, pd.DataFrame)
        assert result.equals(sample_df)

    def test_format_results_dict(self, results_processor):
        """Test formatting results as dictionary."""
        sample_df = pd.DataFrame({"mean": [0.1, 0.2]}, index=["var1", "var2"])
        result = results_processor.format_results(sample_df, "dict")

        assert isinstance(result, dict)
        assert "var1" in result
        assert "var2" in result


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

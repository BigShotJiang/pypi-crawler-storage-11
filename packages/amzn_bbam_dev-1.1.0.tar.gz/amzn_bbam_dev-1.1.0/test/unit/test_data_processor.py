"""
Unit tests for BBAM data processing functionality.

Extracted from test_bbam.py - TestDataProcessor class.
Tests the DataProcessor component in isolation.
"""

import sys
from pathlib import Path

import pandas as pd
import pytest

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))


class TestDataProcessor:
    """Test DataProcessor functionality."""

    @pytest.fixture
    def sample_data(self):
        """Create sample data for testing."""
        return pd.DataFrame(
            {
                "experiment_est": [0.1, 0.2, 0.15],
                "experiment_est_se": [0.05, 0.03, 0.04],
                "obs_model_est": [0.12, 0.18, 0.14],
                "obs_model_est_se": [0.06, 0.04, 0.05],
            }
        )

    @pytest.fixture
    def processor(self):
        """Create DataProcessor instance."""
        from bbam.core import DataProcessor

        return DataProcessor()

    def test_get_required_columns_standard(self, processor):
        """Test getting required columns for standard model."""
        cols = processor.get_required_columns("standard")
        expected = ["experiment_est", "experiment_est_se", "obs_model_est", "obs_model_est_se"]
        assert cols == expected

    def test_get_required_columns_rct_only(self, processor):
        """Test getting required columns for RCT-only model."""
        cols = processor.get_required_columns("rct_only")
        expected = ["experiment_est", "experiment_est_se"]
        assert cols == expected

    def test_validate_data_success(self, processor, sample_data):
        """Test successful data validation."""
        # Should not raise an exception
        required_columns = processor.get_required_columns("standard")
        processor.validate_data(sample_data, required_columns)

    def test_validate_data_missing_columns(self, processor):
        """Test data validation with missing columns."""
        from bbam.core import DataValidationError

        bad_data = pd.DataFrame({"wrong_col": [1, 2, 3]})
        required_columns = processor.get_required_columns("standard")

        with pytest.raises(DataValidationError):
            processor.validate_data(bad_data, required_columns)

    def test_validate_data_negative_se(self, processor):
        """Test data validation with negative standard errors."""
        from bbam.core import DataValidationError

        bad_data = pd.DataFrame(
            {
                "experiment_est": [0.1, 0.2],
                "experiment_est_se": [0.05, -0.03],  # Negative SE
                "obs_model_est": [0.12, 0.18],
                "obs_model_est_se": [0.06, 0.04],
            }
        )
        required_columns = processor.get_required_columns("standard")

        with pytest.raises(DataValidationError):
            processor.validate_data(bad_data, required_columns)

    def test_process_data(self, processor, sample_data):
        """Test data processing."""
        result = processor.process_data(sample_data, "standard", return_full_data=False)

        # Should return DataFrame with required columns
        assert isinstance(result, pd.DataFrame)
        expected_cols = ["experiment_est", "experiment_est_se", "obs_model_est", "obs_model_est_se"]
        assert list(result.columns) == expected_cols
        assert len(result) == len(sample_data)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

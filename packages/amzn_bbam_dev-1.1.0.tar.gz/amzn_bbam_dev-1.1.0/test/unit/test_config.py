"""
Unit tests for BBAM configuration management.

Extracted from test_bbam.py - TestConfigurationManager class.
Tests the configuration system components in isolation.
"""

import sys
from pathlib import Path

import pytest

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))


class TestConfigurationManager:
    """Test ConfigurationManager functionality."""

    @pytest.fixture
    def config_manager(self):
        """Create ConfigurationManager instance."""
        from bbam.config import ConfigurationManager

        return ConfigurationManager()

    @pytest.fixture
    def sample_config(self):
        """Create sample configuration."""
        return {
            "sampling_settings": {
                "tune": 1000,
                "draws": 1000,
                "chains": 4,
                "cores": 4,
                "target_accept": 0.95,
                "maxdepth": 15,
                "is_random_seed": False,
                "seed": 42,
                "n_sample_posterior": 100,
            },
            "model_settings": {"bias_spec": "BOTH_INT_MULT", "likelihood_distribution": "normal"},
            "data_driven_priors": False,  # Set to False to avoid needing settings section
            "priors": {
                "mu_beta_0": {"delta_mu_beta_0": 0.0, "gamma_mu_beta_0": 1.0},
                "sigma_beta_0": {"zeta_sigma_beta_0": 1.0},
                "mu_beta_1": {"delta_mu_beta_1": 0.0, "gamma_mu_beta_1": 1.0},
                "sigma_beta_1": {"zeta_sigma_beta_1": 1.0},
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
            },
            "warning_level_setting": "normal",
            "warning_level_definition": {"normal": {"rhat_threshold": 1.01}},
        }

    def test_create_default_configuration(self):
        """Test creating default configuration."""
        from bbam.config import create_default_configuration

        config = create_default_configuration("standard")

        assert isinstance(config, dict)
        assert "sampling_settings" in config
        assert "model_settings" in config
        assert "data_driven_priors" in config

    def test_load_configuration_from_dict(self, config_manager, sample_config):
        """Test loading configuration from dictionary."""
        result = config_manager.load_configuration(sample_config, "standard")

        assert isinstance(result, dict)
        assert "sampling_settings" in result
        assert result["sampling_settings"]["seed"] == 42

    def test_load_configuration_from_file(self, config_manager):
        """Test loading configuration from file."""
        # Use the test config file we created
        test_config_path = Path(__file__).parent.parent / "test_config.yaml"
        result = config_manager.load_configuration(str(test_config_path), "standard")

        assert isinstance(result, dict)
        assert "sampling_settings" in result
        assert result["sampling_settings"]["seed"] == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

"""
Unit tests for RCTScaledHBM (Scale Model).

This module tests the scale model functionality including configuration validation,
data processing, prior calculations, and model building.
"""

from unittest.mock import Mock, patch

import numpy as np
import pandas as pd
import pytest

from bbam.models.scale_model import RCTScaledHBM
from bbam.utils.enums import BiasSpecification, LikelihoodDistribution


class TestRCTScaledHBM:
    """Test cases for RCTScaledHBM class."""

    def setup_method(self):
        """Set up test fixtures."""
        self.model = RCTScaledHBM()

        # Sample data for testing
        np.random.seed(42)
        self.sample_data = pd.DataFrame(
            {
                "experiment_est": np.random.normal(0.05, 0.02, 10),
                "experiment_est_se": np.random.uniform(0.01, 0.03, 10),
                "obs_model_est": np.random.normal(0.06, 0.025, 10),
                "obs_model_est_se": np.random.uniform(0.015, 0.035, 10),
                "experiment_scale": np.random.uniform(1e6, 1e9, 10),
                "experiment_scale_se": np.random.uniform(1e5, 1e8, 10),
            }
        )

        # Sample configuration
        self.sample_config = {
            "data_driven_priors": False,
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": LikelihoodDistribution.NORMAL.value,
                "skip_model_posterior_metrics": False,
            },
            "sampling_settings": {"n_sample_posterior": 0},
            "priors": {
                "mu_ati": {"delta_mu_ati": 0.05, "gamma_mu_ati": 0.02},
                "sigma_ati": {"zeta_sigma_ati": 0.01},
                "sigma_tau": {"eta_sigma_tau": 0.01, "zeta_sigma_tau": 0.5},
                "mu_scale": {"delta_mu_scale": 1e8, "gamma_mu_scale": 1e7},
                "sigma_scale": {"zeta_sigma_scale": 1e6},
                "mu_beta_0": {"delta_beta_0": 0.0, "gamma_beta_0": 0.01},
                "sigma_beta_0": {"zeta_beta_0": 0.005},
                "mu_beta_1": {"delta_beta_1": 0.5, "gamma_beta_1": 0.2},
                "sigma_beta_1": {"zeta_beta_1": 0.1},
            },
        }

    def test_get_required_data_columns(self):
        """Test that required data columns are correctly specified."""
        required_cols = self.model.get_required_data_columns()
        expected_cols = [
            "experiment_est",
            "experiment_est_se",
            "obs_model_est",
            "obs_model_est_se",
            "experiment_scale",
            "experiment_scale_se",
        ]
        assert required_cols == expected_cols

    def test_prepare_config_valid(self):
        """Test configuration preparation with valid config."""
        prepared_config = self.model._prepare_config(self.sample_config)

        assert prepared_config is not None
        assert "model_settings" in prepared_config
        assert prepared_config["model_settings"]["bias_spec"] == BiasSpecification.BOTH_INT_MULT.value

    def test_prepare_config_none(self):
        """Test configuration preparation with None config."""
        with pytest.raises(ValueError, match="Configuration cannot be None"):
            self.model._prepare_config(None)

    def test_prepare_config_missing_model_settings(self):
        """Test configuration preparation with missing model_settings."""
        invalid_config = {"data_driven_priors": False}
        with pytest.raises(ValueError, match="Missing required section: model_settings"):
            self.model._prepare_config(invalid_config)

    def test_prepare_config_invalid_bias_spec(self):
        """Test configuration preparation with invalid bias_spec."""
        invalid_config = {"model_settings": {"bias_spec": "INVALID_SPEC"}}
        with pytest.raises(ValueError, match="Invalid bias_spec value"):
            self.model._prepare_config(invalid_config)

    def test_prepare_config_adds_defaults(self):
        """Test that configuration preparation adds default values."""
        minimal_config = {
            "data_driven_priors": False,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
        }
        prepared_config = self.model._prepare_config(minimal_config)

        assert prepared_config["model_settings"]["likelihood_distribution"] == LikelihoodDistribution.NORMAL.value
        assert prepared_config["model_settings"]["skip_model_posterior_metrics"] is False

    def test_prepare_config_student_t_validation(self):
        """Test Student's t likelihood validation."""
        config_with_student_t = {
            "data_driven_priors": False,
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": LikelihoodDistribution.STUDENT_T.value,
            },
        }

        # Should raise error without student_df
        with pytest.raises(ValueError, match="student_df"):
            self.model._prepare_config(config_with_student_t)

        # Should pass with valid student_df
        config_with_student_t["model_settings"]["student_df"] = 6
        prepared_config = self.model._prepare_config(config_with_student_t)
        assert prepared_config["model_settings"]["student_df"] == 6

    def test_get_data_driven_priors(self):
        """Test data-driven priors calculation."""
        # Set up config for data-driven priors
        self.model.config = {
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 2.0, "scale_prior_width_sigma": 4.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            }
        }

        priors = self.model._get_data_driven_priors(self.sample_data)

        assert "mu_ati" in priors
        assert "sigma_ati" in priors
        assert "sigma_tau" in priors
        assert "mu_scale" in priors
        assert "sigma_scale" in priors
        assert "mu_beta_0" in priors
        assert "sigma_beta_0" in priors
        assert "mu_beta_1" in priors
        assert "sigma_beta_1" in priors

    def test_validate_priors_valid(self):
        """Test prior validation with valid priors."""
        valid_priors = self.sample_config["priors"]
        assert self.model._validate_priors(valid_priors) is True

    def test_validate_priors_missing(self):
        """Test prior validation with missing priors."""
        incomplete_priors = {"mu_true_ati": {"delta_mu_ati": 0.05, "gamma_mu_ati": 0.02}}

        with pytest.raises(ValueError, match="Missing required priors"):
            self.model._validate_priors(incomplete_priors)

    def test_validate_priors_backward_compatibility(self):
        """Test prior validation with scale model priors including required scale parameters."""
        scale_model_priors = {
            "mu_tau": {"delta_mu_tau": 0.05, "gamma_mu_tau": 0.02},
            "sigma_tau": {"eta_sigma_tau": 0.01, "zeta_sigma_tau": 0.5},
            "mu_scale": {"delta_mu_scale": 1e8, "gamma_mu_scale": 1e7},
            "sigma_scale": {"zeta_sigma_scale": 1e6},
            "mu_beta_0": {"delta_beta_0": 0.0, "gamma_beta_0": 0.01},
            "sigma_beta_0": {"zeta_beta_0": 0.005},
            "mu_beta_1": {"delta_beta_1": 0.5, "gamma_beta_1": 0.2},
            "sigma_beta_1": {"zeta_beta_1": 0.1},
        }

        assert self.model._validate_priors(scale_model_priors) is True

    def test_set_variables_metadata(self):
        """Test variable metadata setup."""
        self.model.config = self.sample_config
        result = self.model._set_variables_metadata()

        assert result is self.model
        assert hasattr(self.model, "vars_trace_plot")
        assert hasattr(self.model, "vars_table_full")
        assert hasattr(self.model, "vars_table_short")
        assert hasattr(self.model, "vars_display_names")

        # Check that variable names are present (note: sigma_tau is not in trace plot)
        assert "mu_tau" in self.model.vars_trace_plot
        assert "mu_ati" in self.model.vars_trace_plot
        assert "sigma_ati" in self.model.vars_trace_plot
        assert "mu_scale" in self.model.vars_trace_plot
        assert "sigma_scale" in self.model.vars_trace_plot

    def test_get_posterior_predictive_vars(self):
        """Test posterior predictive variable names."""
        vars_list = self.model.get_posterior_predictive_vars()

        expected_vars = [
            "mean_ati_tilde",
            "ati_tilde",
            "mean_scale_tilde",
            "scale_tilde",
            "mean_tau_tilde",
            "tau_tilde",
            "mean_bias_tilde",
            "bias_tilde",
            "mean_obs_model_est_tilde",
            "obs_model_est_tilde",
            "std_ati_tilde",
            "std_scale_tilde",
            "std_tau_tilde",
            "std_bias_tilde",
            "std_obs_model_est_tilde",
        ]

        for var in expected_vars:
            assert var in vars_list

    @patch("pymc.Model")
    def test_define_data(self, mock_pymc_model):
        """Test data variable definition."""
        mock_model = Mock()

        with patch("pymc.Data"):
            data_vars = self.model._define_data(self.sample_data, mock_model)

            assert data_vars["n_obs"] == len(self.sample_data)
            assert "experiment_est" in data_vars
            assert "experiment_est_se" in data_vars
            assert "obs_model_est" in data_vars
            assert "obs_model_est_se" in data_vars
            assert "experiment_scale" in data_vars
            assert "experiment_scale_se" in data_vars

    @patch("pymc.Normal")
    @patch("pymc.HalfCauchy")
    @patch("pymc.LogNormal")
    def test_define_priors_on_params(self, mock_lognormal, mock_halfcauchy, mock_normal):
        """Test prior parameter definition."""
        self.model.priors = self.sample_config["priors"]
        self.model.config = self.sample_config

        params = self.model._define_priors_on_params()

        assert "mu_ati" in params
        assert "sigma_ati" in params
        assert "mu_scale" in params
        assert "sigma_scale" in params
        assert "sigma_tau" in params

    def test_build_calibration_model_validation(self):
        """Test calibration model validation."""
        # Test with None data
        with pytest.raises(ValueError, match="df_unpaired cannot be None or empty"):
            self.model.build_calibration_model(None, Mock())

        # Test with empty data
        empty_df = pd.DataFrame()
        with pytest.raises(ValueError, match="df_unpaired cannot be None or empty"):
            self.model.build_calibration_model(empty_df, Mock())

        # Test with missing columns
        incomplete_df = pd.DataFrame({"obs_model_est": [0.05, 0.06], "obs_model_est_se": [0.01, 0.02]})

        with pytest.raises(ValueError, match="Missing required columns"):
            self.model.build_calibration_model(incomplete_df, Mock())

    def test_build_calibration_model_with_valid_data(self):
        """Test calibration model building with valid data."""
        # Create mock trace
        mock_trace = Mock()
        mock_trace.posterior = {
            "mu_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01))))),
            "sigma_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.005))))),
            "mu_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.5))))),
            "sigma_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.1))))),
            "mu_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.05))))),
            "sigma_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.02))))),
            "mu_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e8))))),
            "sigma_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e7))))),
            "sigma_tau": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01))))),
        }

        self.model.config = self.sample_config

        # Create unpaired data
        unpaired_data = self.sample_data.loc[
            :, ["obs_model_est", "obs_model_est_se", "experiment_scale", "experiment_scale_se"]
        ].copy()

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.LogNormal"):
                        with patch("pymc.Deterministic"):
                            calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                            assert calibration_model is not None

    def test_bias_specification_validation(self):
        """Test different bias specifications."""
        # Test ONLY_INT
        config_only_int = self.sample_config.copy()
        config_only_int["model_settings"]["bias_spec"] = BiasSpecification.ONLY_INT.value

        prepared_config = self.model._prepare_config(config_only_int)
        assert prepared_config["model_settings"]["bias_spec"] == BiasSpecification.ONLY_INT.value

        # Test ONLY_MULT
        config_only_mult = self.sample_config.copy()
        config_only_mult["model_settings"]["bias_spec"] = BiasSpecification.ONLY_MULT.value

        prepared_config = self.model._prepare_config(config_only_mult)
        assert prepared_config["model_settings"]["bias_spec"] == BiasSpecification.ONLY_MULT.value

    def test_data_driven_priors_validation(self):
        """Test data-driven priors configuration validation."""
        config_dd = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 2.0, "scale_prior_width_sigma": 4.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            },
        }

        prepared_config = self.model._prepare_config(config_dd)
        assert prepared_config["data_driven_priors"] is True

    def test_data_driven_priors_missing_settings(self):
        """Test data-driven priors with missing settings."""
        config_dd_incomplete = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
        }

        with pytest.raises(ValueError, match="data_driven_priors_settings"):
            self.model._prepare_config(config_dd_incomplete)

    def test_build_model_success(self):
        """Test successful model building setup."""
        self.model.config = self.sample_config
        self.model.priors = self.sample_config["priors"]

        # Test that the model has the required attributes after setup
        assert self.model.config is not None
        assert self.model.priors is not None

        # Test that required data columns are available
        required_cols = self.model.get_required_data_columns()
        for col in required_cols:
            assert col in self.sample_data.columns

    def test_build_model_no_config(self):
        """Test model building without configuration."""
        # Create a fresh model instance without any configuration
        fresh_model = RCTScaledHBM()

        with pytest.raises(ValueError, match="Configuration must be provided|Priors must be set"):
            fresh_model.build(self.sample_data)

    def test_variable_display_names(self):
        """Test that display names are properly set."""
        self.model.config = self.sample_config
        self.model._set_variables_metadata()

        expected_names = {
            "mu_tau": "Avg. treatment effect",
            "mu_ati": "Avg. treatment effect intensity",
            "sigma_ati": "Std. dev. of treatment effect intensity",
            "mean_experiment_scale": "Avg. experiment scale",
        }

        for var, expected_name in expected_names.items():
            assert self.model.vars_display_names[var] == expected_name

    def test_posterior_predictive_with_samples(self):
        """Test posterior predictive variable setup when samples > 0."""
        config_with_pp = self.sample_config.copy()
        config_with_pp["sampling_settings"]["n_sample_posterior"] = 100

        self.model.config = config_with_pp
        self.model._set_variables_metadata()

        # Check that posterior predictive variables are added to full table
        assert "mean_tau_tilde" in self.model.vars_table_full
        assert "bias_tilde" in self.model.vars_table_full
        assert "scale_tilde" in self.model.vars_table_full

    def test_define_posterior_predictive_vars(self):
        """Test posterior predictive variable definition setup."""
        # Test that the method exists and can be called
        assert hasattr(self.model, "define_posterior_predictive_vars")
        assert callable(self.model.define_posterior_predictive_vars)

        # Test that it requires a pymc_model and config to be set
        self.model.config = self.sample_config

        # Without pymc_model, it should fail gracefully
        with pytest.raises(AttributeError):
            self.model.define_posterior_predictive_vars(100)

    def test_likelihood_distributions(self):
        """Test different likelihood distributions."""
        # Test Normal likelihood
        config_normal = self.sample_config.copy()
        config_normal["model_settings"]["likelihood_distribution"] = LikelihoodDistribution.NORMAL.value

        prepared_config = self.model._prepare_config(config_normal)
        assert prepared_config["model_settings"]["likelihood_distribution"] == LikelihoodDistribution.NORMAL.value

        # Test Student's t likelihood
        config_student_t = self.sample_config.copy()
        config_student_t["model_settings"]["likelihood_distribution"] = LikelihoodDistribution.STUDENT_T.value
        config_student_t["model_settings"]["student_df"] = 6

        prepared_config = self.model._prepare_config(config_student_t)
        assert prepared_config["model_settings"]["likelihood_distribution"] == LikelihoodDistribution.STUDENT_T.value
        assert prepared_config["model_settings"]["student_df"] == 6

    def test_skip_posterior_metrics_option(self):
        """Test skip_model_posterior_metrics configuration option."""
        config_skip = self.sample_config.copy()
        config_skip["model_settings"]["skip_model_posterior_metrics"] = True

        prepared_config = self.model._prepare_config(config_skip)
        assert prepared_config["model_settings"]["skip_model_posterior_metrics"] is True

        # Test invalid type
        config_invalid = self.sample_config.copy()
        config_invalid["model_settings"]["skip_model_posterior_metrics"] = "invalid"

        with pytest.raises(ValueError, match="Invalid skip_model_posterior_metrics value"):
            self.model._prepare_config(config_invalid)

    def test_model_initialization(self):
        """Test model initialization."""
        # Test with logger
        mock_logger = Mock()
        model_with_logger = RCTScaledHBM(logger=mock_logger)
        assert model_with_logger.logger is not None

        # Test without logger
        model_without_logger = RCTScaledHBM()
        assert model_without_logger.logger is not None

    def test_configuration_edge_cases(self):
        """Test configuration edge cases."""
        # Test with minimal valid configuration
        minimal_config = {
            "data_driven_priors": False,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
        }

        prepared_config = self.model._prepare_config(minimal_config)
        assert "likelihood_distribution" in prepared_config["model_settings"]
        assert "skip_model_posterior_metrics" in prepared_config["model_settings"]

    def test_invalid_likelihood_distribution(self):
        """Test invalid likelihood distribution."""
        invalid_config = {
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": "invalid_distribution",
            }
        }

        with pytest.raises(ValueError, match="Invalid likelihood_distribution value"):
            self.model._prepare_config(invalid_config)

    def test_student_df_validation(self):
        """Test student_df parameter validation."""
        config_student_t = {
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": LikelihoodDistribution.STUDENT_T.value,
                "student_df": -1,  # Invalid negative value
            }
        }

        with pytest.raises(ValueError, match="student_df must be a positive number"):
            self.model._prepare_config(config_student_t)

    def test_prepare_config_missing_bias_spec(self):
        """Test configuration preparation with missing bias_spec."""
        invalid_config = {"data_driven_priors": False, "model_settings": {}}  # Missing bias_spec
        with pytest.raises(ValueError, match="Missing required parameter: bias_spec in model_settings section"):
            self.model._prepare_config(invalid_config)

    def test_data_driven_priors_missing_sections(self):
        """Test data-driven priors with missing required sections."""
        # Missing treatment_effect_intensity section
        config_missing_ati = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {},
        }
        with pytest.raises(ValueError, match="'treatment_effect_intensity' section must be provided"):
            self.model._prepare_config(config_missing_ati)

        # Missing experiment_scale section
        config_missing_scale = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0}
            },
        }
        with pytest.raises(ValueError, match="'experiment_scale' section must be provided"):
            self.model._prepare_config(config_missing_scale)

        # Missing bias_intercept section
        config_missing_bias_int = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 2.0, "scale_prior_width_sigma": 4.0},
            },
        }
        with pytest.raises(ValueError, match="'bias_intercept' section must be provided"):
            self.model._prepare_config(config_missing_bias_int)

        # Missing bias_multiplier section
        config_missing_bias_mult = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 2.0, "scale_prior_width_sigma": 4.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
            },
        }
        with pytest.raises(ValueError, match="'bias_multiplier' section must be provided"):
            self.model._prepare_config(config_missing_bias_mult)

    def test_data_driven_priors_missing_parameters(self):
        """Test data-driven priors with missing required parameters."""
        # Missing scale_prior_width_mean in treatment_effect_intensity
        config_missing_param = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_sigma": 6.0}  # Missing scale_prior_width_mean
            },
        }
        with pytest.raises(ValueError, match="scale_prior_width_mean parameter must be provided"):
            self.model._prepare_config(config_missing_param)

        # Missing scale_prior_width_sigma in treatment_effect_intensity
        config_missing_param2 = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0}  # Missing scale_prior_width_sigma
            },
        }
        with pytest.raises(ValueError, match="scale_prior_width_sigma parameter must be provided"):
            self.model._prepare_config(config_missing_param2)

        # Missing parameters in experiment_scale section
        config_missing_scale_param = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_sigma": 4.0},  # Missing scale_prior_width_mean
            },
        }
        with pytest.raises(
            ValueError, match="scale_prior_width_mean parameter must be provided in the 'experiment_scale'"
        ):
            self.model._prepare_config(config_missing_scale_param)

        # Missing parameters in bias_intercept section
        config_missing_bias_int_param = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 2.0, "scale_prior_width_sigma": 4.0},
                "bias_intercept": {"scale_prior_width_sigma": 2.0},  # Missing scale_prior_width_mean
            },
        }
        with pytest.raises(
            ValueError, match="scale_prior_width_mean parameter must be provided in the 'bias_intercept'"
        ):
            self.model._prepare_config(config_missing_bias_int_param)

        # Missing parameters in bias_multiplier section
        config_missing_bias_mult_param = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 2.0, "scale_prior_width_sigma": 4.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"prior_width_mean": 1.0, "prior_width_sigma": 2.0},  # Missing center_prior_mean
            },
        }
        with pytest.raises(ValueError, match="center_prior_mean parameter must be provided in the 'bias_multiplier'"):
            self.model._prepare_config(config_missing_bias_mult_param)

    def test_define_posterior_predictive_vars_config_validation(self):
        """Test posterior predictive variable definition configuration validation."""
        # Test that the method exists and can be called
        assert hasattr(self.model, "define_posterior_predictive_vars")
        assert callable(self.model.define_posterior_predictive_vars)

        # Test that it requires a pymc_model and config to be set
        self.model.config = self.sample_config

        # Without pymc_model, it should fail gracefully
        with pytest.raises(AttributeError):
            self.model.define_posterior_predictive_vars(100)

    @patch("pymc.Normal")
    @patch("pymc.HalfCauchy")
    @patch("pymc.LogNormal")
    def test_define_priors_on_params_fallback_to_standard_model(self, mock_lognormal, mock_halfcauchy, mock_normal):
        """Test prior parameter definition with fallback to standard model priors."""
        # Use standard model priors (without mu_ati)
        standard_priors = {
            "mu_tau": {"delta_mu_tau": 0.05, "gamma_mu_tau": 0.02},
            "sigma_tau": {"eta_sigma_tau": 0.01, "zeta_sigma_tau": 0.5},
            "mu_scale": {"delta_mu_scale": 1e8, "gamma_mu_scale": 1e7},
            "sigma_scale": {"zeta_sigma_scale": 1e6},
            "mu_beta_0": {"delta_beta_0": 0.0, "gamma_beta_0": 0.01},
            "sigma_beta_0": {"zeta_beta_0": 0.005},
            "mu_beta_1": {"delta_beta_1": 0.5, "gamma_beta_1": 0.2},
            "sigma_beta_1": {"zeta_beta_1": 0.1},
        }

        self.model.priors = standard_priors
        self.model.config = self.sample_config

        params = self.model._define_priors_on_params()

        assert "mu_ati" in params
        assert "sigma_ati" in params
        assert "mu_scale" in params
        assert "sigma_scale" in params
        assert "sigma_tau" in params

    @patch("pymc.Normal")
    @patch("pymc.HalfCauchy")
    @patch("pymc.LogNormal")
    def test_define_priors_on_params_only_int_bias(self, mock_lognormal, mock_halfcauchy, mock_normal):
        """Test prior parameter definition with ONLY_INT bias specification."""
        config_only_int = self.sample_config.copy()
        config_only_int["model_settings"]["bias_spec"] = BiasSpecification.ONLY_INT.value

        self.model.priors = self.sample_config["priors"]
        self.model.config = config_only_int

        params = self.model._define_priors_on_params()

        assert "mu_ati" in params
        assert "sigma_ati" in params
        assert "mu_scale" in params
        assert "sigma_scale" in params
        assert "sigma_tau" in params
        assert "mu_beta_0" in params
        assert "sigma_beta_0" in params
        # Should not have mu_beta_1 and sigma_beta_1 for ONLY_INT
        assert "mu_beta_1" not in params
        assert "sigma_beta_1" not in params

    @patch("pymc.Normal")
    @patch("pymc.HalfCauchy")
    @patch("pymc.LogNormal")
    def test_define_priors_on_params_only_mult_bias(self, mock_lognormal, mock_halfcauchy, mock_normal):
        """Test prior parameter definition with ONLY_MULT bias specification."""
        config_only_mult = self.sample_config.copy()
        config_only_mult["model_settings"]["bias_spec"] = BiasSpecification.ONLY_MULT.value

        self.model.priors = self.sample_config["priors"]
        self.model.config = config_only_mult

        params = self.model._define_priors_on_params()

        assert "mu_ati" in params
        assert "sigma_ati" in params
        assert "mu_scale" in params
        assert "sigma_scale" in params
        assert "sigma_tau" in params
        assert "mu_beta_1" in params
        assert "sigma_beta_1" in params
        # Should not have mu_beta_0 and sigma_beta_0 for ONLY_MULT
        assert "mu_beta_0" not in params
        assert "sigma_beta_0" not in params

    @patch("pymc.Deterministic")
    def test_define_posterior_metrics_skip_enabled(self, mock_deterministic):
        """Test posterior metrics definition when skip is enabled."""
        config_skip = self.sample_config.copy()
        config_skip["model_settings"]["skip_model_posterior_metrics"] = True
        self.model.config = config_skip

        model_vars = {"mu_true_tte": Mock(), "experiment_true_size": Mock(), "bias": Mock(), "tau": Mock()}

        posterior_metrics = self.model._define_posterior_metrics(model_vars)

        # Should return empty dict when skipped
        assert posterior_metrics == {}
        # Deterministic should not be called
        assert not mock_deterministic.called

    def test_build_model_missing_config(self):
        """Test build method with missing or invalid config."""
        # Test with None config
        self.model.config = None
        with pytest.raises(ValueError, match="Configuration must be provided"):
            self.model.build(self.sample_data)

        # Test with empty config
        self.model.config = {}
        with pytest.raises(ValueError, match="Configuration must be provided"):
            self.model.build(self.sample_data)

        # Test with config missing model_settings
        self.model.config = {"data_driven_priors": False}
        with pytest.raises(ValueError, match="Configuration must be provided"):
            self.model.build(self.sample_data)

    def test_build_model_missing_priors(self):
        """Test build method with missing priors."""
        self.model.config = self.sample_config

        # Test with None priors
        self.model.priors = None
        with pytest.raises(ValueError, match="Priors must be set"):
            self.model.build(self.sample_data)

        # Test with empty priors
        self.model.priors = {}
        with pytest.raises(ValueError, match="Priors must be set"):
            self.model.build(self.sample_data)

    def test_build_calibration_model_only_int_bias(self):
        """Test calibration model building with ONLY_INT bias specification."""
        config_only_int = self.sample_config.copy()
        config_only_int["model_settings"]["bias_spec"] = BiasSpecification.ONLY_INT.value
        self.model.config = config_only_int

        # Create mock trace
        mock_trace = Mock()
        mock_trace.posterior = {
            "mu_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01))))),
            "sigma_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.005))))),
            "mu_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.05))))),
            "sigma_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.02))))),
            "mu_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e8))))),
            "sigma_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e7))))),
            "sigma_tau": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01))))),
        }

        unpaired_data = self.sample_data.loc[
            :, ["obs_model_est", "obs_model_est_se", "experiment_scale", "experiment_scale_se"]
        ].copy()

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.LogNormal"):
                        with patch("pymc.Deterministic"):
                            calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                            assert calibration_model is not None

    def test_build_calibration_model_only_mult_bias(self):
        """Test calibration model building with ONLY_MULT bias specification."""
        config_only_mult = self.sample_config.copy()
        config_only_mult["model_settings"]["bias_spec"] = BiasSpecification.ONLY_MULT.value
        self.model.config = config_only_mult

        # Create mock trace
        mock_trace = Mock()
        mock_trace.posterior = {
            "mu_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.5))))),
            "sigma_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.1))))),
            "mu_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.05))))),
            "sigma_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.02))))),
            "mu_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e8))))),
            "sigma_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e7))))),
            "sigma_tau": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01))))),
        }

        unpaired_data = self.sample_data.loc[
            :, ["obs_model_est", "obs_model_est_se", "experiment_scale", "experiment_scale_se"]
        ].copy()

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.LogNormal"):
                        with patch("pymc.Deterministic"):
                            calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                            assert calibration_model is not None

    def test_build_calibration_model_student_t_likelihood(self):
        """Test calibration model building with Student's t likelihood."""
        config_student_t = self.sample_config.copy()
        config_student_t["model_settings"]["likelihood_distribution"] = LikelihoodDistribution.STUDENT_T.value
        config_student_t["model_settings"]["student_df"] = 6
        self.model.config = config_student_t

        # Create mock trace
        mock_trace = Mock()
        mock_trace.posterior = {
            "mu_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01))))),
            "sigma_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.005))))),
            "mu_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.5))))),
            "sigma_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.1))))),
            "mu_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.05))))),
            "sigma_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.02))))),
            "mu_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e8))))),
            "sigma_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e7))))),
            "sigma_tau": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01))))),
        }

        unpaired_data = self.sample_data.loc[
            :, ["obs_model_est", "obs_model_est_se", "experiment_scale", "experiment_scale_se"]
        ].copy()

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.LogNormal"):
                        with patch("pymc.Deterministic"):
                            with patch("pymc.StudentT"):
                                calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                                assert calibration_model is not None

    def test_data_driven_priors_additional_missing_parameters(self):
        """Test additional missing parameter cases in data-driven priors."""
        # Missing prior_width_mean in bias_multiplier
        config_missing_param = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 2.0, "scale_prior_width_sigma": 4.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_sigma": 2.0},  # Missing prior_width_mean
            },
        }
        with pytest.raises(ValueError, match="prior_width_mean parameter must be provided in the 'bias_multiplier'"):
            self.model._prepare_config(config_missing_param)

        # Missing prior_width_sigma in bias_multiplier
        config_missing_param2 = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 2.0, "scale_prior_width_sigma": 4.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0},  # Missing prior_width_sigma
            },
        }
        with pytest.raises(ValueError, match="prior_width_sigma parameter must be provided in the 'bias_multiplier'"):
            self.model._prepare_config(config_missing_param2)

        # Missing scale_prior_width_sigma in experiment_scale
        config_missing_param3 = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 2.0},  # Missing scale_prior_width_sigma
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            },
        }
        with pytest.raises(
            ValueError, match="scale_prior_width_sigma parameter must be provided in the 'experiment_scale'"
        ):
            self.model._prepare_config(config_missing_param3)

        # Missing scale_prior_width_sigma in bias_intercept
        config_missing_param4 = {
            "data_driven_priors": True,
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 2.0, "scale_prior_width_sigma": 4.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0},  # Missing scale_prior_width_sigma
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            },
        }
        with pytest.raises(
            ValueError, match="scale_prior_width_sigma parameter must be provided in the 'bias_intercept'"
        ):
            self.model._prepare_config(config_missing_param4)

    def test_build_model_with_data_driven_priors(self):
        """Test model building with data-driven priors enabled."""
        config_dd = {
            "data_driven_priors": True,
            "model_settings": {
                "bias_spec": BiasSpecification.BOTH_INT_MULT.value,
                "likelihood_distribution": LikelihoodDistribution.NORMAL.value,
                "skip_model_posterior_metrics": False,
            },
            "sampling_settings": {"n_sample_posterior": 0},
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 2.0, "scale_prior_width_sigma": 4.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            },
        }

        # Test that data-driven priors can be calculated and model can be prepared
        prepared_config = self.model._prepare_config(config_dd)
        assert prepared_config["data_driven_priors"] is True

        # Test that data-driven priors are calculated correctly
        self.model.config = config_dd
        priors = self.model._get_data_driven_priors(self.sample_data)
        assert len(priors) == 9  # Should have all 9 required priors

    def test_calibration_model_bias_branches_coverage(self):
        """Test calibration model bias calculation branches (lines 1012-1016)."""
        # Test that different bias specifications are handled in calibration model

        # Test BOTH_INT_MULT bias specification
        config_both = self.sample_config.copy()
        config_both["model_settings"]["bias_spec"] = BiasSpecification.BOTH_INT_MULT.value
        prepared_config = self.model._prepare_config(config_both)
        assert prepared_config["model_settings"]["bias_spec"] == BiasSpecification.BOTH_INT_MULT.value

        # Test ONLY_INT bias specification
        config_only_int = self.sample_config.copy()
        config_only_int["model_settings"]["bias_spec"] = BiasSpecification.ONLY_INT.value
        prepared_config = self.model._prepare_config(config_only_int)
        assert prepared_config["model_settings"]["bias_spec"] == BiasSpecification.ONLY_INT.value

        # Test ONLY_MULT bias specification
        config_only_mult = self.sample_config.copy()
        config_only_mult["model_settings"]["bias_spec"] = BiasSpecification.ONLY_MULT.value
        prepared_config = self.model._prepare_config(config_only_mult)
        assert prepared_config["model_settings"]["bias_spec"] == BiasSpecification.ONLY_MULT.value

    def test_student_t_likelihood_branches_coverage(self):
        """Test Student's t likelihood branches coverage (lines 1032-1048)."""
        # Test that Student's t likelihood is properly configured
        config_student_t = self.sample_config.copy()
        config_student_t["model_settings"]["likelihood_distribution"] = LikelihoodDistribution.STUDENT_T.value
        config_student_t["model_settings"]["student_df"] = 6

        prepared_config = self.model._prepare_config(config_student_t)
        assert prepared_config["model_settings"]["likelihood_distribution"] == LikelihoodDistribution.STUDENT_T.value
        assert prepared_config["model_settings"]["student_df"] == 6

        # Test with different student_df values
        config_student_t["model_settings"]["student_df"] = 4
        prepared_config = self.model._prepare_config(config_student_t)
        assert prepared_config["model_settings"]["student_df"] == 4

    def test_calibration_model_bias_calculation_branches(self):
        """Test different bias calculation branches in calibration model (lines 1012-1016)."""
        # Create mock trace with required posterior values
        mock_trace = Mock()
        mock_trace.posterior = {
            "mu_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01))))),
            "sigma_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.005))))),
            "mu_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.5))))),
            "sigma_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.1))))),
            "mu_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.05))))),
            "sigma_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.02))))),
            "mu_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e8))))),
            "sigma_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e7))))),
            "sigma_tau": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01))))),
        }

        unpaired_data = self.sample_data.loc[
            :, ["obs_model_est", "obs_model_est_se", "experiment_scale", "experiment_scale_se"]
        ].copy()

        # Test BOTH_INT_MULT bias specification (lines 1012-1013)
        config_both = self.sample_config.copy()
        config_both["model_settings"]["bias_spec"] = BiasSpecification.BOTH_INT_MULT.value
        self.model.config = config_both

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.LogNormal"):
                        with patch("pymc.Deterministic"):
                            calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                            assert calibration_model is not None

        # Test ONLY_INT bias specification (line 1014)
        config_only_int = self.sample_config.copy()
        config_only_int["model_settings"]["bias_spec"] = BiasSpecification.ONLY_INT.value
        self.model.config = config_only_int

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.LogNormal"):
                        with patch("pymc.Deterministic"):
                            calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                            assert calibration_model is not None

        # Test ONLY_MULT bias specification (line 1016)
        config_only_mult = self.sample_config.copy()
        config_only_mult["model_settings"]["bias_spec"] = BiasSpecification.ONLY_MULT.value
        self.model.config = config_only_mult

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.LogNormal"):
                        with patch("pymc.Deterministic"):
                            calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                            assert calibration_model is not None

    def test_calibration_model_student_t_likelihood_branches(self):
        """Test Student's t likelihood branches in calibration model (lines 1032-1048)."""
        # Create mock trace
        mock_trace = Mock()
        mock_trace.posterior = {
            "mu_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01))))),
            "sigma_beta_0": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.005))))),
            "mu_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.5))))),
            "sigma_beta_1": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.1))))),
            "mu_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.05))))),
            "sigma_ati": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.02))))),
            "mu_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e8))))),
            "sigma_scale": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=1e7))))),
            "sigma_tau": Mock(values=Mock(flatten=Mock(return_value=Mock(mean=Mock(return_value=0.01))))),
        }

        # Configure for Student's t likelihood
        config_student_t = self.sample_config.copy()
        config_student_t["model_settings"]["likelihood_distribution"] = LikelihoodDistribution.STUDENT_T.value
        config_student_t["model_settings"]["student_df"] = 6
        self.model.config = config_student_t

        unpaired_data = self.sample_data.loc[
            :, ["obs_model_est", "obs_model_est_se", "experiment_scale", "experiment_scale_se"]
        ].copy()

        with patch("pymc.Model"):
            with patch("pymc.Data"):
                with patch("pymc.Normal"):
                    with patch("pymc.LogNormal"):
                        with patch("pymc.Deterministic"):
                            with patch("pymc.StudentT") as mock_student_t:
                                calibration_model = self.model.build_calibration_model(unpaired_data, mock_trace)
                                assert calibration_model is not None
                                # Verify StudentT was called for both likelihoods (lines 1032-1048)
                                assert mock_student_t.call_count >= 2

    def test_additional_build_method_coverage(self):
        """Test additional build method coverage."""
        # Test that the model has the required configuration for building
        self.model.config = self.sample_config
        self.model.priors = self.sample_config["priors"]

        assert self.model.config is not None
        assert self.model.priors is not None
        assert "model_settings" in self.model.config
        assert "bias_spec" in self.model.config["model_settings"]

    def test_model_structure_invalid_bias_spec(self):
        """Test model structure with invalid bias specification."""
        self.model.config = self.sample_config.copy()
        self.model.config["model_settings"]["bias_spec"] = "INVALID_SPEC"

        # Test that invalid bias specification is detected in configuration
        assert self.model.config["model_settings"]["bias_spec"] == "INVALID_SPEC"

        # This would be caught during configuration validation, not model structure
        with pytest.raises(ValueError, match="Invalid bias_spec value"):
            self.model._prepare_config(self.model.config)

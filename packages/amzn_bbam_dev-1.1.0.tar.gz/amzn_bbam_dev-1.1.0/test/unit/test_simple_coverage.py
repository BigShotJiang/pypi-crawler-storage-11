"""
Simple coverage improvement tests for BBAM.

Focus on working tests that improve coverage without complex dependencies.
"""

import sys
import tempfile
from pathlib import Path

import pandas as pd
import pytest

# Add src to path for testing - must be before any local imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


class TestSimpleCoverageImprovement:
    """Simple tests to improve coverage."""

    def test_data_processor_basic(self):
        """Test basic DataProcessor functionality."""
        from bbam.core.data_processor import DataProcessor

        processor = DataProcessor()
        assert processor.logger is not None

        # Test get_required_columns
        columns = processor.get_required_columns("standard")
        assert isinstance(columns, list)
        assert len(columns) > 0

        columns_rct = processor.get_required_columns("rct_only")
        assert isinstance(columns_rct, list)
        assert len(columns_rct) > 0

    def test_data_processor_errors(self):
        """Test DataProcessor error cases."""
        from bbam.core.data_processor import DataProcessor, DataValidationError

        processor = DataProcessor()

        # Test invalid model type
        with pytest.raises(ValueError):
            processor.get_required_columns("invalid_model")

        # Test empty data validation
        with pytest.raises(DataValidationError):
            processor.validate_data(pd.DataFrame(), ["test_col"])

    def test_results_processor_basic(self):
        """Test basic ResultsProcessor functionality."""
        from bbam.core.results_processor import ResultsProcessor

        processor = ResultsProcessor()
        assert processor.logger is not None

        # Test format_results
        sample_df = pd.DataFrame(
            {
                "Mean": [1.0, 2.0],
                "Std": [0.1, 0.2],
            },
            index=["param1", "param2"],
        )

        # Test different formats
        result_df = processor.format_results(sample_df, "dataframe")
        assert isinstance(result_df, pd.DataFrame)

        result_dict = processor.format_results(sample_df, "dict")
        assert isinstance(result_dict, dict)

        result_json = processor.format_results(sample_df, "json")
        assert isinstance(result_json, str)

    def test_results_processor_errors(self):
        """Test ResultsProcessor error cases."""
        from bbam.core.results_processor import ResultsProcessor

        processor = ResultsProcessor()

        # Test invalid interval type
        with pytest.raises(ValueError):
            processor._validate_interval_params("INVALID", 0.95)

        # Test invalid probability
        with pytest.raises(ValueError):
            processor._validate_interval_params("HDI", 1.5)

    def test_configuration_basic(self):
        """Test basic configuration functionality."""
        from bbam.config.configuration import create_default_configuration

        # Test default configuration creation
        config = create_default_configuration("standard")
        assert isinstance(config, dict)
        assert "sampling_settings" in config

        config_rct = create_default_configuration("rct_only")
        assert isinstance(config_rct, dict)
        assert "sampling_settings" in config_rct

    def test_configuration_errors(self):
        """Test configuration error cases."""
        from bbam.config.configuration import ConfigurationManager

        config_manager = ConfigurationManager()

        # Test invalid file
        with pytest.raises(Exception):
            config_manager.load_configuration("/nonexistent/file.yaml", "standard")

    def test_bbam_analyzer_basic(self):
        """Test basic BbamAnalyzer functionality."""
        from bbam import BbamAnalyzer
        from bbam.bbam_analyzer import ModelNotFittedError

        model = BbamAnalyzer("standard")
        assert model.model_type == "standard"
        assert model.config is not None

        # Test methods before fitting
        with pytest.raises(ModelNotFittedError):
            model.get_results()

        with pytest.raises(ModelNotFittedError):
            model.get_samples()

    def test_bbam_analyzer_errors(self):
        """Test BbamAnalyzer error cases."""
        from bbam import BbamAnalyzer
        from bbam.bbam_analyzer import DataValidationError

        # Test invalid model type
        with pytest.raises(ValueError):
            BbamAnalyzer("invalid_type")

        # Test invalid data
        model = BbamAnalyzer("standard")
        invalid_data = pd.DataFrame({"wrong_col": [1, 2, 3]})

        with pytest.raises(DataValidationError):
            model.fit(invalid_data)

    def test_utils_enums(self):
        """Test utility enums."""
        from bbam.utils.enums import IntervalType, WarningLevel

        # Test IntervalType
        assert IntervalType.HDI.value == "HDI"
        assert IntervalType.ETI.value == "ETI"
        assert "HDI" in IntervalType.values()
        assert "ETI" in IntervalType.values()

        # Test WarningLevel
        assert WarningLevel.NORMAL.value == "normal"
        assert WarningLevel.RELAXED.value == "relaxed"
        assert "normal" in WarningLevel.values()
        assert "relaxed" in WarningLevel.values()

    def test_utils_logging(self):
        """Test logging utilities."""
        import logging

        from bbam.utils.logging_config import setup_logger

        # Test different log levels
        logger = setup_logger("test_logger", level=logging.INFO)
        assert logger.level == logging.INFO

        logger_debug = setup_logger("test_debug", level=logging.DEBUG)
        assert logger_debug.level == logging.DEBUG

    def test_exception_classes(self):
        """Test all custom exception classes."""
        from bbam.bbam_analyzer import (
            BbamError,
            CalibrationError,
            ConfigurationError,
            DataValidationError,
            ModelFittingError,
            ModelNotFittedError,
        )
        from bbam.core.data_processor import DataValidationError as CoreDataValidationError
        from bbam.core.results_processor import ResultsProcessingError

        # Test that exceptions can be raised
        with pytest.raises(BbamError):
            raise BbamError("Test error")

        with pytest.raises(ConfigurationError):
            raise ConfigurationError("Config error")

        with pytest.raises(DataValidationError):
            raise DataValidationError("Data error")

        with pytest.raises(ModelFittingError):
            raise ModelFittingError("Fitting error")

        with pytest.raises(ModelNotFittedError):
            raise ModelNotFittedError("Not fitted error")

        with pytest.raises(CalibrationError):
            raise CalibrationError("Calibration error")

        with pytest.raises(CoreDataValidationError):
            raise CoreDataValidationError("Core data error")

        with pytest.raises(ResultsProcessingError):
            raise ResultsProcessingError("Results error")

    def test_file_operations(self):
        """Test file operations."""
        from bbam.core.results_processor import ResultsProcessor

        processor = ResultsProcessor()
        sample_df = pd.DataFrame(
            {
                "Mean": [1.0, 2.0],
                "Std": [0.1, 0.2],
            },
            index=["param1", "param2"],
        )

        with tempfile.TemporaryDirectory() as temp_dir:
            # Test CSV saving
            csv_path = processor.save_results(sample_df, f"{temp_dir}/results.csv", "csv")
            assert Path(csv_path).exists()

            # Test JSON saving
            json_path = processor.save_results(sample_df, f"{temp_dir}/results.json", "json")
            assert Path(json_path).exists()

    def test_data_validation_scenarios(self):
        """Test various data validation scenarios."""
        from bbam.core.data_processor import DataProcessor, DataValidationError

        processor = DataProcessor()
        required_columns = ["experiment_est", "experiment_est_se", "obs_model_est", "obs_model_est_se"]

        # Test valid data
        valid_data = pd.DataFrame(
            {
                "experiment_est": [0.1, 0.2, 0.15],
                "experiment_est_se": [0.05, 0.03, 0.04],
                "obs_model_est": [0.12, 0.18, 0.14],
                "obs_model_est_se": [0.06, 0.04, 0.05],
            }
        )

        # Should not raise exception
        processor.validate_data(valid_data, required_columns)

        # Test data with missing columns
        invalid_data = pd.DataFrame(
            {
                "experiment_est": [0.1, 0.2, 0.15],
                "experiment_est_se": [0.05, 0.03, 0.04],
                # Missing obs_model columns
            }
        )

        with pytest.raises(DataValidationError):
            processor.validate_data(invalid_data, required_columns)

    def test_configuration_with_dict(self):
        """Test configuration loading with dictionary."""
        from bbam.config.configuration import ConfigurationManager

        config_manager = ConfigurationManager()

        # Test with complete configuration
        complete_config = {
            "sampling_settings": {
                "tune": 1000,
                "draws": 1000,
                "chains": 4,
                "cores": 4,
                "target_accept": 0.95,
                "maxdepth": 15,
                "is_random_seed": False,
                "seed": 42,
                "n_sample_posterior": 100,
            },
            "model_settings": {"bias_spec": "BOTH_INT_MULT", "likelihood_distribution": "normal"},
            "data_driven_priors": False,
            "priors": {
                "mu_beta_0": {"delta_mu_beta_0": 0.0, "gamma_mu_beta_0": 1.0},
                "sigma_beta_0": {"zeta_sigma_beta_0": 1.0},
                "mu_beta_1": {"delta_mu_beta_1": 0.0, "gamma_mu_beta_1": 1.0},
                "sigma_beta_1": {"zeta_sigma_beta_1": 1.0},
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
            },
            "warning_level_setting": "normal",
            "warning_level_definition": {"normal": {"rhat_threshold": 1.01}},
        }

        result = config_manager.load_configuration(complete_config, "standard")
        assert isinstance(result, dict)
        assert result["sampling_settings"]["tune"] == 1000

    def test_bbam_analyzer_with_config(self):
        """Test BbamAnalyzer with custom configuration."""
        from bbam import BbamAnalyzer

        config = {
            "sampling_settings": {
                "tune": 500,
                "draws": 500,
                "chains": 2,
                "cores": 2,
                "target_accept": 0.95,
                "maxdepth": 15,
                "is_random_seed": False,
                "seed": 123,
                "n_sample_posterior": 50,
            },
            "model_settings": {"bias_spec": "BOTH_INT_MULT", "likelihood_distribution": "normal"},
            "data_driven_priors": False,
            "priors": {
                "mu_beta_0": {"delta_mu_beta_0": 0.0, "gamma_mu_beta_0": 1.0},
                "sigma_beta_0": {"zeta_sigma_beta_0": 1.0},
                "mu_beta_1": {"delta_mu_beta_1": 0.0, "gamma_mu_beta_1": 1.0},
                "sigma_beta_1": {"zeta_sigma_beta_1": 1.0},
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
            },
            "warning_level_setting": "normal",
            "warning_level_definition": {"normal": {"rhat_threshold": 1.01}},
        }

        model = BbamAnalyzer("standard", config=config)
        assert model.config["sampling_settings"]["tune"] == 500


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

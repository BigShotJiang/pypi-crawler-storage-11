"""
Specialized tests for BBAM error handling and edge cases.

Extracted from test_bbam_comprehensive.py - TestErrorHandlingComprehensive.
Tests error scenarios, exception handling, and edge cases.
"""

import sys
from pathlib import Path

import pytest

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))


class TestErrorHandlingComprehensive:
    """Comprehensive tests for error handling."""

    def test_all_custom_exceptions(self):
        """Test all custom exception types."""
        from bbam.bbam_analyzer import (
            BbamError,
            CalibrationError,
            ConfigurationError,
            DataValidationError,
            ModelFittingError,
            ModelNotFittedError,
        )
        from bbam.core.data_processor import DataValidationError as CoreDataValidationError
        from bbam.core.results_processor import ResultsProcessingError

        # Test base exception
        with pytest.raises(BbamError):
            raise BbamError("Test error")

        # Test specific exceptions
        with pytest.raises(ConfigurationError):
            raise ConfigurationError("Config error")

        # Test main data validation error
        with pytest.raises(DataValidationError):
            raise DataValidationError("Data error")

        # Test model errors
        with pytest.raises(ModelFittingError):
            raise ModelFittingError("Fitting error")

        with pytest.raises(ModelNotFittedError):
            raise ModelNotFittedError("Not fitted error")

        with pytest.raises(CalibrationError):
            raise CalibrationError("Calibration error")

        # Test core module errors
        with pytest.raises(CoreDataValidationError):
            raise CoreDataValidationError("Core data error")

        with pytest.raises(ResultsProcessingError):
            raise ResultsProcessingError("Results error")

    def test_bbam_analyzer_error_handling(self):
        """Test BbamAnalyzer error handling."""
        from bbam import BbamAnalyzer
        from bbam.bbam_analyzer import ModelNotFittedError

        model = BbamAnalyzer("standard")

        # Test calling methods before fitting
        with pytest.raises(ModelNotFittedError):
            model.get_results()

        with pytest.raises(ModelNotFittedError):
            model.get_samples()

        with pytest.raises(ModelNotFittedError):
            model.plot("trace")

    def test_data_processor_invalid_model_type(self):
        """Test DataProcessor with invalid model type."""
        from bbam.core.data_processor import DataProcessor

        processor = DataProcessor()
        with pytest.raises(ValueError, match="Unsupported model type"):
            processor.get_required_columns("invalid_model")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

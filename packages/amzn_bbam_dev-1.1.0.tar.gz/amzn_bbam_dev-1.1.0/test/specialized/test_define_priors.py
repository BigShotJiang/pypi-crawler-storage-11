"""
Tests for BBAM model prior definition and model structure functionality.

Covers:
- _define_priors_on_params: bias parameter creation with different specifications
- _define_model_structure: bias component creation and model structure setup
- All bias specification types: BOTH_INT_MULT, ONLY_INT, ONLY_MULT
"""

import sys
from pathlib import Path

import pytest

# Add src to path for testing - must be before any local imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


class TestDefineProiorsAndModelStructure:
    """Test prior definition and model structure creation functionality."""

    def test_define_priors_both_intercept_and_multiplier_bias(self):
        """Test _define_priors_on_params with BOTH_INT_MULT bias specification."""
        import pymc as pm

        from bbam.models.standard_model import RCTObsHBM
        from bbam.utils.enums import BiasSpecification

        # Create complete, valid config
        config = {
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "sampling_settings": {"n_sample_posterior": 100},
            "data_driven_priors": False,
            "priors": {
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
                "mu_beta_0": {"delta_beta_0": 0.5, "gamma_beta_0": 0.8},
                "sigma_beta_0": {"zeta_beta_0": 0.6},
                "mu_beta_1": {"delta_beta_1": 0.3, "gamma_beta_1": 0.7},
                "sigma_beta_1": {"zeta_beta_1": 0.4},
            },
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_multiplier": {"center_prior_mean": 0.0, "prior_width_mean": 1.0, "prior_width_sigma": 1.0},
            },
        }

        model = RCTObsHBM()
        model.set_and_process_config(config)
        model.priors = config["priors"]  # Set priors directly

        print(f"✅ Config bias_spec: {model.config['model_settings']['bias_spec']}")
        print(f"✅ Priors set: {list(model.priors.keys())}")

        # Create PyMC model and call _define_priors_on_params directly
        with pm.Model() as pymc_model:
            print(f"✅ Before _define_priors_on_params: {len(pymc_model.unobserved_RVs)} variables")

            # This MUST execute lines 468-484 or the test will fail
            params = model._define_priors_on_params()

            print(f"✅ After _define_priors_on_params: {len(pymc_model.unobserved_RVs)} variables")

            # Verify parameters were created
            var_names = [var.name for var in pymc_model.unobserved_RVs]
            print(f"✅ Created parameters: {var_names}")

            # Check that the method returned the correct parameters
            print(f"✅ Returned params keys: {list(params.keys())}")

            # These MUST be present if lines 468-484 were executed for BOTH_INT_MULT
            required_params = ["mu_tau", "sigma_tau", "mu_beta_0", "sigma_beta_0", "mu_beta_1", "sigma_beta_1"]
            for param_name in required_params:
                if param_name not in params:
                    raise AssertionError(f"Parameter {param_name} not in returned params - lines 468-484 not executed!")
                if param_name not in var_names:
                    raise AssertionError(f"Variable {param_name} not created - lines 468-484 not executed!")
                print(f"✅ Found parameter: {param_name}")

            print("🎉 SUCCESS: Lines 468-484 were definitely executed for BOTH_INT_MULT!")

    def test_define_priors_intercept_bias_only(self):
        """Test _define_priors_on_params with ONLY_INT bias specification."""
        import pymc as pm

        from bbam.models.standard_model import RCTObsHBM
        from bbam.utils.enums import BiasSpecification

        config = {
            "model_settings": {"bias_spec": BiasSpecification.ONLY_INT.value},
            "sampling_settings": {"n_sample_posterior": 100},
            "data_driven_priors": False,
            "priors": {
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
                "mu_beta_0": {"delta_beta_0": 0.5, "gamma_beta_0": 0.8},
                "sigma_beta_0": {"zeta_beta_0": 0.6},
                "mu_beta_1": {"delta_beta_1": 0.3, "gamma_beta_1": 0.7},
                "sigma_beta_1": {"zeta_beta_1": 0.4},
            },
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_multiplier": {"center_prior_mean": 0.0, "prior_width_mean": 1.0, "prior_width_sigma": 1.0},
            },
        }

        model = RCTObsHBM()
        model.set_and_process_config(config)
        model.priors = config["priors"]

        with pm.Model() as pymc_model:
            params = model._define_priors_on_params()

            var_names = [var.name for var in pymc_model.unobserved_RVs]
            print(f"ONLY_INT - Created parameters: {var_names}")
            print(f"ONLY_INT - Returned params: {list(params.keys())}")

            # For ONLY_INT: should have mu_beta_0/sigma_beta_0 but NOT mu_beta_1/sigma_beta_1
            assert "mu_beta_0" in params, "mu_beta_0 missing for ONLY_INT"
            assert "sigma_beta_0" in params, "sigma_beta_0 missing for ONLY_INT"
            assert "mu_beta_1" not in params, "mu_beta_1 should not exist for ONLY_INT"
            assert "sigma_beta_1" not in params, "sigma_beta_1 should not exist for ONLY_INT"

            assert "mu_beta_0" in var_names, "mu_beta_0 variable missing for ONLY_INT"
            assert "sigma_beta_0" in var_names, "sigma_beta_0 variable missing for ONLY_INT"
            assert "mu_beta_1" not in var_names, "mu_beta_1 variable should not exist for ONLY_INT"
            assert "sigma_beta_1" not in var_names, "sigma_beta_1 variable should not exist for ONLY_INT"

            print("✅ ONLY_INT test passed - correct parameters created")

    def test_define_priors_multiplier_bias_only(self):
        """Test _define_priors_on_params with ONLY_MULT bias specification."""
        import pymc as pm

        from bbam.models.standard_model import RCTObsHBM
        from bbam.utils.enums import BiasSpecification

        config = {
            "model_settings": {"bias_spec": BiasSpecification.ONLY_MULT.value},
            "sampling_settings": {"n_sample_posterior": 100},
            "data_driven_priors": False,
            "priors": {
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
                "mu_beta_0": {"delta_beta_0": 0.5, "gamma_beta_0": 0.8},
                "sigma_beta_0": {"zeta_beta_0": 0.6},
                "mu_beta_1": {"delta_beta_1": 0.3, "gamma_beta_1": 0.7},
                "sigma_beta_1": {"zeta_beta_1": 0.4},
            },
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_multiplier": {"center_prior_mean": 0.0, "prior_width_mean": 1.0, "prior_width_sigma": 1.0},
            },
        }

        model = RCTObsHBM()
        model.set_and_process_config(config)
        model.priors = config["priors"]

        with pm.Model() as pymc_model:
            params = model._define_priors_on_params()

            var_names = [var.name for var in pymc_model.unobserved_RVs]
            print(f"ONLY_MULT - Created parameters: {var_names}")
            print(f"ONLY_MULT - Returned params: {list(params.keys())}")

            # For ONLY_MULT: should have mu_beta_1/sigma_beta_1 but NOT mu_beta_0/sigma_beta_0
            assert "mu_beta_1" in params, "mu_beta_1 missing for ONLY_MULT"
            assert "sigma_beta_1" in params, "sigma_beta_1 missing for ONLY_MULT"
            assert "mu_beta_0" not in params, "mu_beta_0 should not exist for ONLY_MULT"
            assert "sigma_beta_0" not in params, "sigma_beta_0 should not exist for ONLY_MULT"

            assert "mu_beta_1" in var_names, "mu_beta_1 variable missing for ONLY_MULT"
            assert "sigma_beta_1" in var_names, "sigma_beta_1 variable missing for ONLY_MULT"
            assert "mu_beta_0" not in var_names, "mu_beta_0 variable should not exist for ONLY_MULT"
            assert "sigma_beta_0" not in var_names, "sigma_beta_0 variable should not exist for ONLY_MULT"

            print("✅ ONLY_MULT test passed - correct parameters created")

    def test_model_structure_both_intercept_and_multiplier_bias(self):
        """Test _define_model_structure with BOTH_INT_MULT bias specification."""
        import pymc as pm

        from bbam.models.standard_model import RCTObsHBM
        from bbam.utils.enums import BiasSpecification

        config = {
            "model_settings": {"bias_spec": BiasSpecification.BOTH_INT_MULT.value},
            "sampling_settings": {"n_sample_posterior": 100},
            "data_driven_priors": False,
            "priors": {
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
                "mu_beta_0": {"delta_beta_0": 0.5, "gamma_beta_0": 0.8},
                "sigma_beta_0": {"zeta_beta_0": 0.6},
                "mu_beta_1": {"delta_beta_1": 0.3, "gamma_beta_1": 0.7},
                "sigma_beta_1": {"zeta_beta_1": 0.4},
            },
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_multiplier": {"center_prior_mean": 0.0, "prior_width_mean": 1.0, "prior_width_sigma": 1.0},
            },
        }

        model = RCTObsHBM()
        model.set_and_process_config(config)
        model.priors = config["priors"]

        with pm.Model() as pymc_model:
            # First create the parameters needed by _define_model_structure
            params = model._define_priors_on_params()

            print(f"✅ Parameters created: {list(params.keys())}")
            vars_before = len(pymc_model.unobserved_RVs)
            deterministics_before = len(pymc_model.deterministics)
            print(f"✅ Before _define_model_structure: {vars_before} variables, {deterministics_before} deterministics")

            # This MUST execute lines 517-527 or the test will fail
            model_vars = model._define_model_structure(params, n_obs=5)

            vars_after = len(pymc_model.unobserved_RVs)
            deterministics_after = len(pymc_model.deterministics)
            print(f"✅ After _define_model_structure: {vars_after} variables, {deterministics_after} deterministics")

            # Verify variables were created
            var_names = [var.name for var in pymc_model.unobserved_RVs]
            deterministic_names = [var.name for var in pymc_model.deterministics]
            print(f"✅ All variables: {var_names}")
            print(f"✅ All deterministics: {deterministic_names}")
            print(f"✅ Returned model_vars: {list(model_vars.keys())}")

            # These MUST be present if lines 517-527 were executed for BOTH_INT_MULT
            required_vars = ["z_tau", "z_beta_0", "z_beta_1"]
            required_deterministics = ["tau", "beta_0", "beta_1", "bias"]
            required_model_vars = ["tau", "beta_0", "beta_1", "bias"]

            for var_name in required_vars:
                if var_name not in var_names:
                    raise AssertionError(f"Variable {var_name} not created - lines 517-527 not executed!")
                print(f"✅ Found variable: {var_name}")

            for det_name in required_deterministics:
                if det_name not in deterministic_names:
                    raise AssertionError(f"Deterministic {det_name} not created - lines 517-527 not executed!")
                print(f"✅ Found deterministic: {det_name}")

            for mv_name in required_model_vars:
                if mv_name not in model_vars:
                    raise AssertionError(f"Model var {mv_name} not returned - lines 517-527 not executed!")
                print(f"✅ Found model_var: {mv_name}")

            print("🎉 SUCCESS: Lines 517-527 were definitely executed for BOTH_INT_MULT!")

    def test_model_structure_intercept_bias_only(self):
        """Test _define_model_structure with ONLY_INT bias specification."""
        import pymc as pm

        from bbam.models.standard_model import RCTObsHBM
        from bbam.utils.enums import BiasSpecification

        config = {
            "model_settings": {"bias_spec": BiasSpecification.ONLY_INT.value},
            "sampling_settings": {"n_sample_posterior": 100},
            "data_driven_priors": False,
            "priors": {
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
                "mu_beta_0": {"delta_beta_0": 0.5, "gamma_beta_0": 0.8},
                "sigma_beta_0": {"zeta_beta_0": 0.6},
                "mu_beta_1": {"delta_beta_1": 0.3, "gamma_beta_1": 0.7},
                "sigma_beta_1": {"zeta_beta_1": 0.4},
            },
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_multiplier": {"center_prior_mean": 0.0, "prior_width_mean": 1.0, "prior_width_sigma": 1.0},
            },
        }

        model = RCTObsHBM()
        model.set_and_process_config(config)
        model.priors = config["priors"]

        with pm.Model() as pymc_model:
            # Create parameters first
            params = model._define_priors_on_params()
            model_vars = model._define_model_structure(params, n_obs=5)

            var_names = [var.name for var in pymc_model.unobserved_RVs]
            deterministic_names = [var.name for var in pymc_model.deterministics]
            print(f"ONLY_INT - Variables: {var_names}")
            print(f"ONLY_INT - Deterministics: {deterministic_names}")
            print(f"ONLY_INT - Model vars: {list(model_vars.keys())}")

            # For ONLY_INT: should have z_beta_0/beta_0 but NOT z_beta_1/beta_1
            assert "z_beta_0" in var_names, "z_beta_0 missing for ONLY_INT"
            assert "z_beta_1" not in var_names, "z_beta_1 should not exist for ONLY_INT"
            assert "beta_0" in deterministic_names, "beta_0 missing for ONLY_INT"
            assert "beta_1" not in deterministic_names, "beta_1 should not exist for ONLY_INT"
            assert "beta_0" in model_vars, "beta_0 model_var missing for ONLY_INT"
            assert "beta_1" not in model_vars, "beta_1 model_var should not exist for ONLY_INT"

            print("✅ ONLY_INT model structure test passed")

    def test_model_structure_multiplier_bias_only(self):
        """Test _define_model_structure with ONLY_MULT bias specification."""
        import pymc as pm

        from bbam.models.standard_model import RCTObsHBM
        from bbam.utils.enums import BiasSpecification

        config = {
            "model_settings": {"bias_spec": BiasSpecification.ONLY_MULT.value},
            "sampling_settings": {"n_sample_posterior": 100},
            "data_driven_priors": False,
            "priors": {
                "mu_tau": {"delta_mu_tau": 0.0, "gamma_mu_tau": 1.0},
                "sigma_tau": {"zeta_sigma_tau": 1.0},
                "mu_beta_0": {"delta_beta_0": 0.5, "gamma_beta_0": 0.8},
                "sigma_beta_0": {"zeta_beta_0": 0.6},
                "mu_beta_1": {"delta_beta_1": 0.3, "gamma_beta_1": 0.7},
                "sigma_beta_1": {"zeta_beta_1": 0.4},
            },
            "data_driven_priors_settings": {
                "treatment_effect": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_intercept": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 1.0},
                "bias_multiplier": {"center_prior_mean": 0.0, "prior_width_mean": 1.0, "prior_width_sigma": 1.0},
            },
        }

        model = RCTObsHBM()
        model.set_and_process_config(config)
        model.priors = config["priors"]

        with pm.Model() as pymc_model:
            # Create parameters first
            params = model._define_priors_on_params()
            model_vars = model._define_model_structure(params, n_obs=5)

            var_names = [var.name for var in pymc_model.unobserved_RVs]
            deterministic_names = [var.name for var in pymc_model.deterministics]
            print(f"ONLY_MULT - Variables: {var_names}")
            print(f"ONLY_MULT - Deterministics: {deterministic_names}")
            print(f"ONLY_MULT - Model vars: {list(model_vars.keys())}")

            # For ONLY_MULT: should have z_beta_1/beta_1 but NOT z_beta_0/beta_0
            assert "z_beta_1" in var_names, "z_beta_1 missing for ONLY_MULT"
            assert "z_beta_0" not in var_names, "z_beta_0 should not exist for ONLY_MULT"
            assert "beta_1" in deterministic_names, "beta_1 missing for ONLY_MULT"
            assert "beta_0" not in deterministic_names, "beta_0 should not exist for ONLY_MULT"
            assert "beta_1" in model_vars, "beta_1 model_var missing for ONLY_MULT"
            assert "beta_0" not in model_vars, "beta_0 model_var should not exist for ONLY_MULT"

            print("✅ ONLY_MULT model structure test passed")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])

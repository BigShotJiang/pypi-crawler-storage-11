"""
Test for skip_model_posterior_metrics configuration option.

This test verifies that the skip_model_posterior_metrics configuration option
correctly controls whether posterior metrics are computed or skipped.
"""

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))


class TestSkipPosteriorMetrics:
    """Test suite for skip_model_posterior_metrics configuration option."""

    def setup_method(self):
        """Set up test fixtures."""
        from bbam.config.configuration import ConfigurationManager
        from bbam.models.standard_model import RCTObsHBM

        # Store imports for use in tests
        self.RCTObsHBM = RCTObsHBM
        self.ConfigurationManager = ConfigurationManager

        # Create a minimal test data
        self.test_data = pd.DataFrame(
            {
                "experiment_est": [0.1, 0.2, 0.3],
                "experiment_est_se": [0.05, 0.06, 0.04],
                "obs_model_est": [0.15, 0.25, 0.35],
                "obs_model_est_se": [0.08, 0.09, 0.07],
            }
        )

        # Create a base configuration
        config_manager = ConfigurationManager()
        self.base_config = config_manager._get_default_configuration("standard")

    def test_default_config_includes_posterior_metrics(self):
        """Test that default configuration has skip_model_posterior_metrics=False."""
        config_manager = self.ConfigurationManager()
        config = config_manager.load_configuration(model_type="standard")

        assert "skip_model_posterior_metrics" in config["model_settings"]
        assert config["model_settings"]["skip_model_posterior_metrics"] is False

    def test_config_validation_with_skip_option_true(self):
        """Test that configuration validation works with skip_model_posterior_metrics=True."""
        test_config = self.base_config.copy()
        test_config["model_settings"]["skip_model_posterior_metrics"] = True

        config_manager = self.ConfigurationManager()
        validated_config = config_manager._validate_configuration(test_config, "standard")

        assert validated_config["model_settings"]["skip_model_posterior_metrics"] is True

    def test_config_validation_rejects_invalid_skip_option(self):
        """Test that configuration validation rejects non-boolean values."""
        test_config = self.base_config.copy()
        test_config["model_settings"]["skip_model_posterior_metrics"] = "invalid"

        config_manager = self.ConfigurationManager()

        with pytest.raises(Exception) as exc_info:
            config_manager._validate_configuration(test_config, "standard")

        assert "skip_model_posterior_metrics must be a boolean" in str(exc_info.value)

    @patch("bbam.models.standard_model.pt")
    @patch("bbam.models.standard_model.pm")
    def test_define_posterior_metrics_computes_when_not_skipped(self, mock_pm, mock_pt):
        """Test that _define_posterior_metrics computes metrics when skip=False."""
        # Setup mock PyMC components
        mock_deterministic = MagicMock()
        mock_pm.Deterministic = mock_deterministic
        mock_pm.math.mean = MagicMock(return_value="mock_mean")

        # Setup mock PyTensor components
        mock_pt.std = MagicMock(return_value="mock_std")

        # Create model with skip=False (default)
        config = self.base_config.copy()
        config["model_settings"]["skip_model_posterior_metrics"] = False

        model = self.RCTObsHBM()
        model.set_and_process_config(config)

        # Mock model variables
        mock_model_vars = {"bias": MagicMock(), "tau": MagicMock()}

        # Call the method
        result = model._define_posterior_metrics(mock_model_vars)

        # Verify metrics were computed
        assert len(result) == 4
        assert "mean_bias" in result
        assert "mean_obs_model" in result
        assert "std_bias" in result
        assert "std_obs_model" in result

        # Verify PyMC Deterministic was called for all metrics
        assert mock_deterministic.call_count == 4

        # Verify the calls were made with correct names
        call_args = [call[0][0] for call in mock_deterministic.call_args_list]
        assert "mean_bias" in call_args
        assert "mean_obs_model" in call_args
        assert "std_bias" in call_args
        assert "std_obs_model" in call_args

        # Verify that std was called for standard deviation calculations
        assert mock_pt.std.call_count == 2

        # Verify it was called with the expected model variables
        # (std_bias and std_obs_model calculations)
        assert mock_pt.std.call_args_list[0][0][0] == mock_model_vars["bias"]
        assert mock_pt.std.call_args_list[1][0][0] == mock_model_vars["tau"] + mock_model_vars["bias"]

    def test_define_posterior_metrics_skips_when_enabled(self):
        """Test that _define_posterior_metrics returns empty dict when skip=True."""
        # Create model with skip=True
        config = self.base_config.copy()
        config["model_settings"]["skip_model_posterior_metrics"] = True

        model = self.RCTObsHBM()
        model.set_and_process_config(config)

        # Mock model variables (shouldn't be used)
        mock_model_vars = {"bias": MagicMock(), "tau": MagicMock()}

        # Call the method
        result = model._define_posterior_metrics(mock_model_vars)

        # Verify no metrics were computed
        assert result == {}
        assert len(result) == 0

    def test_logger_message_when_skipping(self):
        """Test that appropriate log message is generated when skipping metrics."""
        # Create model with skip=True
        config = self.base_config.copy()
        config["model_settings"]["skip_model_posterior_metrics"] = True

        model = self.RCTObsHBM()
        model.set_and_process_config(config)

        # Mock the logger to capture log messages
        mock_logger = MagicMock()
        model.logger = mock_logger

        # Mock model variables
        mock_model_vars = {"bias": MagicMock(), "tau": MagicMock()}

        # Call the method
        model._define_posterior_metrics(mock_model_vars)

        # Verify the skip log message was called
        mock_logger.info.assert_called_with(
            "Skipping posterior metrics computation (skip_model_posterior_metrics=True)"
        )

    def test_logger_message_when_computing(self):
        """Test that appropriate log message is generated when computing metrics."""
        # Create model with skip=False
        config = self.base_config.copy()
        config["model_settings"]["skip_model_posterior_metrics"] = False

        model = self.RCTObsHBM()
        model.set_and_process_config(config)

        # Mock the logger to capture log messages
        mock_logger = MagicMock()
        model.logger = mock_logger

        # Mock PyMC and PyTensor to avoid actual computation
        with patch("bbam.models.standard_model.pm") as mock_pm, patch("bbam.models.standard_model.pt") as mock_pt:
            mock_pm.Deterministic = MagicMock()
            mock_pm.math.mean = MagicMock()
            mock_pt.std = MagicMock()

            # Mock model variables
            mock_model_vars = {"bias": MagicMock(), "tau": MagicMock()}

            # Call the method
            model._define_posterior_metrics(mock_model_vars)

            # Verify the computation log message was called
            mock_logger.info.assert_called_with("Defining posterior metrics (conditional averages across observations)")


if __name__ == "__main__":
    pytest.main([__file__])

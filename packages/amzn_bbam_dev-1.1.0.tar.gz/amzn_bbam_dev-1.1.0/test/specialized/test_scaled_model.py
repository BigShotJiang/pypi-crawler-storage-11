#!/usr/bin/env python3
"""
Test script to verify the RCTScaledHBM model integration.
"""

import numpy as np
import pandas as pd

from bbam.bbam_analyzer import BbamAnalyzer
from bbam.utils.enums import ModelTypes


def create_test_data():
    """Create synthetic test data for the scaled model."""
    np.random.seed(42)
    n_obs = 10

    # Create synthetic data with required columns for scaled model
    data = {
        "experiment_est": np.random.normal(0.05, 0.02, n_obs),  # 5% effect with 2% std
        "experiment_est_se": np.random.uniform(0.005, 0.015, n_obs),  # SE between 0.5% and 1.5%
        "obs_model_est": np.random.normal(0.06, 0.025, n_obs),  # Slightly biased observational estimates
        "obs_model_est_se": np.random.uniform(0.008, 0.018, n_obs),  # SE between 0.8% and 1.8%
        "experiment_scale": np.random.uniform(1e9, 5e9, n_obs),  # Impressions between 1B and 5B
        "experiment_scale_se": np.random.uniform(1e7, 5e7, n_obs),  # SE for impressions
    }

    return pd.DataFrame(data)


def test_scaled_model_initialization():
    """Test that the scaled model can be initialized."""
    print("Testing scaled model initialization...")

    try:
        # Test that the new model type is recognized
        analyzer = BbamAnalyzer(model_type=ModelTypes.SCALED.value)
        print("✓ Scaled model initialized successfully")

        # Check that the model has the correct type
        assert analyzer.model_type == "scaled"
        print("✓ Model type correctly set to 'scaled'")

        # Check that the model is the correct class
        from bbam.models.scale_model import RCTScaledHBM

        assert isinstance(analyzer.model, RCTScaledHBM)
        print("✓ Model is instance of RCTScaledHBM")

        return True

    except Exception as e:
        print(f"✗ Error initializing scaled model: {e}")
        return False


def test_scaled_model_data_validation():
    """Test that the scaled model validates data correctly."""
    print("\nTesting scaled model data validation...")

    try:
        analyzer = BbamAnalyzer(model_type=ModelTypes.SCALED.value)

        # Test with correct data
        test_data = create_test_data()
        required_columns = analyzer.model.get_required_data_columns()
        print(f"✓ Required columns: {required_columns}")

        # Check that all required columns are present
        missing_cols = [col for col in required_columns if col not in test_data.columns]
        assert len(missing_cols) == 0, f"Missing columns: {missing_cols}"
        print("✓ Test data contains all required columns")

        # Test data validation (should not raise an error)
        analyzer._validate_data(test_data)
        print("✓ Data validation passed")

        return True

    except Exception as e:
        print(f"✗ Error in data validation: {e}")
        return False


def test_scaled_model_config():
    """Test that the scaled model handles configuration correctly."""
    print("\nTesting scaled model configuration...")

    try:
        # Test with data-driven priors configuration
        config = {
            "data_driven_priors": True,
            "data_driven_priors_settings": {
                "treatment_effect_intensity": {"scale_prior_width_mean": 4.0, "scale_prior_width_sigma": 6.0},
                "experiment_scale": {"scale_prior_width_mean": 1.0, "scale_prior_width_sigma": 2.0},
                "bias_intercept": {"scale_prior_width_mean": 0.005, "scale_prior_width_sigma": 0.01},
                "bias_multiplier": {"center_prior_mean": 0.5, "prior_width_mean": 1.0, "prior_width_sigma": 2.0},
            },
            "sampling_settings": {
                "tune": 100,
                "draws": 100,
                "chains": 2,
                "cores": 2,
                "target_accept": 0.8,
                "maxdepth": 10,
                "n_sample_posterior": 0,
                "is_random_seed": False,
                "seed": 42,
            },
            "model_settings": {"bias_spec": "BOTH_INT_MULT", "likelihood_distribution": "normal"},
            "results_settings": {"prob_interval": 0.9, "round_to": 6, "interval_type": "HDI"},
            "warning_level_setting": "normal",
            "warning_level_definition": {
                "normal": {
                    "fraction_divergent_threshold": 0.0,
                    "rhat_threshold": 1.01,
                    "ess_ratio_threshold": 0.1,
                    "ess_threshold": 1000,
                },
                "relaxed": {
                    "fraction_divergent_threshold": 0.002,
                    "rhat_threshold": 1.05,
                    "ess_ratio_threshold": 0.05,
                    "ess_threshold": 500,
                },
            },
        }

        BbamAnalyzer(model_type=ModelTypes.SCALED.value, config=config)
        print("✓ Scaled model initialized with custom configuration")

        return True

    except Exception as e:
        print(f"✗ Error in configuration: {e}")
        return False


def main():
    """Run all tests."""
    print("=" * 60)
    print("Testing RCTScaledHBM Model Integration")
    print("=" * 60)

    tests = [
        test_scaled_model_initialization,
        test_scaled_model_data_validation,
        test_scaled_model_config,
    ]

    results = []
    for test in tests:
        results.append(test())

    print("\n" + "=" * 60)
    print("Test Results Summary")
    print("=" * 60)

    passed = sum(results)
    total = len(results)

    print(f"Tests passed: {passed}/{total}")

    if passed == total:
        print("✓ All tests passed! The RCTScaledHBM model is successfully integrated.")
    else:
        print("✗ Some tests failed. Please check the errors above.")

    return passed == total


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)

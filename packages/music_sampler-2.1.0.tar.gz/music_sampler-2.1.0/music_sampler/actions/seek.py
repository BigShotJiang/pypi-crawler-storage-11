def run(action, music=None, value=0, delta=False, **kwargs):
    for music in action.music_list(music):
        music.seek(value=value, delta=delta)

def description(action, music=None, value=0, delta=False, **kwargs):
    if delta:
        if music is not None:
            return _("moving music « {music_name} » by {delta:+d}s") \
                    .format(music_name=music.name, delta=value)
        else:
            return _("moving all musics by {delta:+d}s") \
                    .format(delta=value)
    else:
        if music is not None:
            return _("moving music « {music_name} » to position {value}s") \
                    .format(music_name=music.name, value=value)
        else:
            return _("moving all musics to position {value}s") \
                    .format(value=value)

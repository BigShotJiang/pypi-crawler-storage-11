import usb.util
from ..helpers import debug_print, error_print

def run(action, device_name=None, device=None, command=None, expect_response=False, **kwargs):
    if device is not None and command is not None and hasattr(device, command):
        debug_print(f"Sending {command} to {device_name} with args {kwargs}")
        response = getattr(device, command)(**kwargs)
        if expect_response:
            debug_print(f"Response from {command} to {device_name} with args {kwargs}: {response}")
    else:
        error_print(f"Could not run command {command} on {device_name}")

def description(action, device_name=None, device=None, command=None, **kwargs):
    formats = [command, kwargs, device_name]
    message = _("running command {command} with args {command_args} on usb device {device_name}")
    return message.format(command=command, command_args=kwargs, device_name=device_name)

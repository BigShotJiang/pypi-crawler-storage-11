def run(action, music=None, value=100, fade=0, delta=False, **kwargs):
    if music is not None:
        music.set_volume(value, delta=delta, fade=fade)
    else:
        action.mapping.set_master_volume(value, delta=delta, fade=fade)

def description(action, music=None,
        value=100, delta=False, fade=0, **kwargs):
    music_name=None if music is None else music.name
    if delta:
        if music is not None:
            message = _("{delta:+d}% to volume of « {music_name} » with {fade}s fade") if fade > 0 else _("{delta:+d}% to volume of « {music_name} »")
        else:
            message = _("{delta:+d}% to volume with {fade}s fade") if fade > 0 else _("{delta:+d}% to volume")
    else:
        if music is not None:
            message = _("setting volume of « {music_name} » to {volume}% with {fade}s fade") if fade > 0 else _("setting volume of « {music_name} » to {volume}%")
        else:
            message = _("setting volume to {volume}% with {fade}s fade") if fade > 0 else _("setting volume to {volume}%")

    return message.format(fade=fade, volume=value, delta=value, music_name=music_name)

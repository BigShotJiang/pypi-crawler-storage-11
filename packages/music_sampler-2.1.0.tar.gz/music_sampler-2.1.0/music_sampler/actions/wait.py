import threading
import time

def run(action, duration=0, music=None, set_wait_id=None, **kwargs):
    action.mapping.add_wait(action, wait_id=set_wait_id)

    action.sleep_event = threading.Event()
    action.sleep_event_timer = threading.Timer(
            duration,
            action.sleep_event.set)

    action.sleep_event_initial_duration = duration
    action.sleep_event_paused = False
    action.sleep_event_left_time = duration

    if music is not None:
        music.wait_end()

    if duration <= 0 or not action.sleep_event_paused:
        action.sleep_event_timer.start()
        action.sleep_event_started_time = time.time()

    action.sleep_event.wait()

def description(action, duration=0, music=None, set_wait_id=None, **kwargs):
    music_name=None if music is None else music.name
    message = []
    if music is None:
        message.append(_("waiting {duration}s"))
    elif duration == 0:
        message.append(_("waiting the end of « {music_name} »"))
    else:
        message.append(_("waiting the end of « {music_name} » + {duration}s"))

    if set_wait_id is not None:
        message.append(_("Setting wait id = {set_wait_id}"))

    return ". ".join(message).format(music_name=music_name, duration=duration, set_wait_id=set_wait_id)

def pause(action, **kwargs):
    if action.sleep_event_paused:
        return

    action.sleep_event_paused = True

    if not action.sleep_event_timer.is_alive():
        return

    action.sleep_event_timer.cancel()

    action.sleep_event_left_time = action.sleep_event_left_time\
            - (time.time() - action.sleep_event_started_time)
    if action.sleep_event_left_time < 0:
        action.sleep_event.set()

def unpause(action, **kwargs):
    if not action.sleep_event_paused:
        return

    action.sleep_event_paused = False

    action.sleep_event_timer = threading.Timer(
            action.sleep_event_left_time,
            action.sleep_event.set)

    action.sleep_event_timer.start()
    action.sleep_event_started_time = time.time()

def reset(action, **kwargs):
    action.sleep_event_timer.cancel()

    action.sleep_event_left_time = action.sleep_event_initial_duration

    if action.sleep_event_paused:
        return

    action.sleep_event_timer = threading.Timer(
            action.sleep_event_left_time,
            action.sleep_event.set)

    action.sleep_event_timer.start()
    action.sleep_event_started_time = time.time()

def interrupt(action, duration=0, music=None, **kwargs):
    if action.sleep_event is not None:
        action.sleep_event.set()
        action.sleep_event_timer.cancel()
    if music is not None:
        music.wait_event.set()

def run(action, music=None, fade_in=0, start_at=0,
        restart_if_running=False, volume=100,
        loop=0, **kwargs):
    for music in action.music_list(music):
        if restart_if_running:
            if music.is_in_use():
                music.stop(wait=True)
            music.play(
                    volume=volume,
                    fade_in=fade_in,
                    start_at=start_at,
                    loop=loop)
        elif not music.is_in_use():
            music.play(
                    volume=volume,
                    fade_in=fade_in,
                    start_at=start_at,
                    loop=loop)

def description(action, music=None, fade_in=0, start_at=0,
        restart_if_running=False, volume=100, loop=0, **kwargs):
    music_name=None if music is None else music.name
    message = []
    if music is not None:
        message.append(_("starting « {music_name} » at volume {volume}%"))
    else:
        message.append(_("starting all musics at volume {volume}%"))

    if start_at != 0:
        message.append(_("At {start_at}s"))

    if fade_in != 0:
        message.append(_("With {fade_in}s fade-in"))

    if loop > 0:
        message.append(_("{loop} times"))
        loop = loop+1
    elif loop < 0:
        message.append(_("In loop"))

    if restart_if_running:
        message.append(_("Restarting if already running"))

    return ". ".join(message).format(music_name=music_name, fade_in=fade_in,
                                     start_at=start_at,
                                     restart_if_running=restart_if_running,
                                     volume=volume, loop=loop)

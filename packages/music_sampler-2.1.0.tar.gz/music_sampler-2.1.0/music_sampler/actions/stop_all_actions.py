def run(action, key_start_time=0, other_only=False, **kwargs):
    if other_only:
        action.mapping.stop_all_running(
                except_key=action.key,
                key_start_time=key_start_time)
    else:
        action.mapping.stop_all_running()

def description(action, other_only=False, **kwargs):
    if other_only:
        message = _("stopping all actions except this key")
    else:
        message = _("stopping all actions")

    return message

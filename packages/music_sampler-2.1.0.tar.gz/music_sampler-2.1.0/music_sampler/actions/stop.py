def run(action, music=None, fade_out=0, wait=False,
        set_wait_id=None, **kwargs):
    previous = None
    for music in action.music_list(music):
        if music.is_loaded_paused() or music.is_loaded_playing():
            if previous is not None:
                previous.stop(fade_out=fade_out)
            previous = music
        else:
            music.stop(fade_out=fade_out)

    if previous is not None:
        action.waiting_music = previous
        previous.stop(
                fade_out=fade_out,
                wait=wait,
                set_wait_id=set_wait_id)

def description(action, music=None, fade_out=0, wait=False,
        set_wait_id=None, **kwargs):

    music_name=None if music is None else music.name
    message = []
    if music is not None:
        message.append(_("stopping music « {music_name} »"))
    else:
        message.append(_("stopping all musics"))

    if fade_out > 0:
        message.append(_("With {fade_out}s fade-out"))
        if wait:
            if set_wait_id is not None:
                message.append(_("Waiting the end of fade-out, with id {set_wait_id}"))
            else:
                message.append(_("Waiting the end of fade-out"))

    return ". ".join(message).format(music_name=music_name,
                                     fade_out=fade_out, wait=wait,
                                     set_wait_id=set_wait_id)

def interrupt(action, music=None, fade_out=0, wait=False,
        set_wait_id=None, **kwargs):
    if action.waiting_music is not None:
        action.waiting_music.wait_event.set()

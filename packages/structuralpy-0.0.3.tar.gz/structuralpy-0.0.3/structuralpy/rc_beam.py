# structuralpy/rc_beam.py

def analyze_flexure(b, d, dp, fcp, fy, As, Asp=0, n_iter=10) :
    """
    Calculate the ultimate moment capacity of a rectangular RC beam in flexure.

    Parameters:

    - `b` (float)    : Beam width in mm.
    - `d` (float)    : Beam effective depth in mm.
    - `dp` (float)   : Distance of center of compression bars to extreme concrete compression fiber in mm.
    - `fcp` (float)  : Concrete 28-day compressive strength in MPa.
    - `fy` (float)   : Reinforcement yield strength in MPa.
    - `As` (float)   : Tension main reinforcement area in mm^2.
    - `Asp` (float)  : Compression main reinforcement area in mm^2. Default value is 0 (no reinforcement).
    - `n_iter` (int) : Number of iterations for iterative solving of equilibrium equation. Default value is 10.

    Returns:
    
    - (float) : The ultimate moment capacity in flexure in N-mm.
    """
    if fcp <= 28 :
        beta1 = 0.85
    elif fcp > 56 :
        beta1 = 0.65
    else :
        beta1 = 0.85 - 0.05/7*(fcp - 28)
    
    # First assume both top and bottom reinforcements yield.
    fs = fy
    fsp = fy
    for iter in range(n_iter) :
        # Locate the neutral axis.
        c = (As*fs - Asp*(fsp - 0.85*fcp))/(0.85*fcp*beta1*b)
        # Update the stresses in both reinforcements.
        fs = min(600*(d - c)/c, fy)
        fsp = min(600*(c - dp)/c, fy)

    # Strength reduction factor
    fs_ = 600*(d - c)/c
    if fs_ >= 1000 :
        phi = 0.90
    elif fs_ < fy :
        phi = 0.65
    else :
        phi = 0.65 + 0.25*(fs_ - fy)/(1000 - fy)

    # Depth of compression block
    a = beta1*c
    Ac = a*b - Asp if a >= dp else a*b
    # Nominal moment capacity.
    Mn = 0.85*fcp*Ac*(d - a/2) + Asp*fsp*(d - dp)

    return phi*Mn

    

..
    This file is part of Invenio.
    Copyright (C) 2017-2020 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Installation
============

Invenio-Queues is on PyPI so all you need is:

.. code-block:: console

   $ pip install invenio-queues

from typing import Any, Dict, List, Optional


class HardcoverAPIError(Exception):
    """Base error for Hardcover API exceptions."""

    pass


class HardcoverHTTPError(HardcoverAPIError):
    """Raised for HTTP status errors."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        self.status_code = status_code
        super().__init__(message)

    def __str__(self) -> str:
        if self.status_code:
            return f"HTTP {self.status_code}: {super().__str__()}"
        return super().__str__()


class HardcoverGraphQLError(HardcoverAPIError):
    """Raised when GraphQL returns an error payload."""

    def __init__(self, errors: List[Dict[str, Any]]):
        self.errors: List[Dict[str, Any]] = errors
        super().__init__(f"GraphQL errors: {errors}")

    def __str__(self) -> str:
        if not self.errors:
            return "GraphQL error occurred"

        if len(self.errors) == 1:
            return f"GraphQL error: {self.errors[0].get('message', 'Unknown error')}"

        messages = [error.get("message", "Unknown error") for error in self.errors]
        return f"GraphQL errors: {'; '.join(messages)}"

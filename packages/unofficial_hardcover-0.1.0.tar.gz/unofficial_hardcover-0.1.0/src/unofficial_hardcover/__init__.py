"""Unofficial Hardcover API client package."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("unofficial-hardcover")
except (
    PackageNotFoundError
):  # pragma: no cover - during editable installs or from source
    __version__ = "0.0.0"

__all__ = ["__version__"]

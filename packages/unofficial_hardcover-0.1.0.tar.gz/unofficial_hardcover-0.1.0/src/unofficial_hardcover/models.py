from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


def _to_int(value: Any, default: Optional[int] = None) -> Optional[int]:
    """Best-effort safe int conversion with type narrowing."""
    if value is None:
        return default
    if isinstance(value, bool):
        # Avoid bool being treated as int
        return default
    if isinstance(value, int):
        return value
    if isinstance(value, (float,)):
        try:
            return int(value)
        except (ValueError, TypeError):
            return default
    if isinstance(value, (str, bytes, bytearray)):
        try:
            return int(value)
        except (ValueError, TypeError):
            return default
    return default


@dataclass
class Book:
    id: int
    title: str
    subtitle: Optional[str] = None
    description: Optional[str] = None
    pages: Optional[int] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Book":
        return cls(
            id=_to_int(data.get("id"), 0) or 0,
            title=str(data.get("title") or ""),
            subtitle=data.get("subtitle"),
            description=data.get("description"),
            pages=_to_int(data.get("pages"), None),
        )


@dataclass
class User:
    id: int
    username: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "User":
        return cls(
            id=_to_int(data.get("id"), 0) or 0,
            username=str(data.get("username") or ""),
        )


@dataclass
class UserBook:
    id: int
    status_id: int
    book: Book

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "UserBook":
        return cls(
            id=_to_int(data.get("id"), 0) or 0,
            status_id=_to_int(data.get("status_id"), 0) or 0,
            book=Book.from_dict(data.get("book", {})),
        )


def parse_books(items: List[Dict[str, Any]]) -> List[Book]:
    return [Book.from_dict(item) for item in items or []]


def parse_user_books(items: List[Dict[str, Any]]) -> List[UserBook]:
    return [UserBook.from_dict(item) for item in items or []]

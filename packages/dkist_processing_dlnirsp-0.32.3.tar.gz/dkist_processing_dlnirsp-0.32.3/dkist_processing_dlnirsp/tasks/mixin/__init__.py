"""Task mixin classes."""

# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ImportMqsInstanceTopicRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'upload_file_name': 'file'
    }

    attribute_map = {
        'upload_file_name': 'upload_file_name'
    }

    def __init__(self, upload_file_name=None):
        r"""ImportMqsInstanceTopicRequestBody

        The model defined in huaweicloud sdk

        :param upload_file_name: 待导入的topic列表文件。
        :type upload_file_name: :class:`huaweicloudsdkcore.http.formdata.FormFile`
        """
        
        

        self._upload_file_name = None
        self.discriminator = None

        self.upload_file_name = upload_file_name

    @property
    def upload_file_name(self):
        r"""Gets the upload_file_name of this ImportMqsInstanceTopicRequestBody.

        待导入的topic列表文件。

        :return: The upload_file_name of this ImportMqsInstanceTopicRequestBody.
        :rtype: :class:`huaweicloudsdkcore.http.formdata.FormFile`
        """
        return self._upload_file_name

    @upload_file_name.setter
    def upload_file_name(self, upload_file_name):
        r"""Sets the upload_file_name of this ImportMqsInstanceTopicRequestBody.

        待导入的topic列表文件。

        :param upload_file_name: The upload_file_name of this ImportMqsInstanceTopicRequestBody.
        :type upload_file_name: :class:`huaweicloudsdkcore.http.formdata.FormFile`
        """
        self._upload_file_name = upload_file_name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ImportMqsInstanceTopicRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

import sys
from .decryptor import decrypt_file

def main():
    if len(sys.argv) != 3:
        print("Usage: evidence-decrypt <encrypted_file> <encryption_key>")
        print("Example:")
        print("  evidence-decrypt evidence123.zip.enc qY6bPmhkO3mZyD1Jq0qYzAzQkZQ6rM0D3DQQxvLOwXQ=")
        sys.exit(1)

    enc_path, key = sys.argv[1], sys.argv[2]

    try:
        output_path = decrypt_file(enc_path, key)
        print(f"✅ Decryption successful! Saved as: {output_path}")
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

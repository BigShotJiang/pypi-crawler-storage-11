from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="fin-sentiment",
    version="0.1.2",
    author="Divine Gupta",
    description="Financial news sentiment analysis using LSTM",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "torch",
        "numpy",
        "requests",
        "beautifulsoup4"
    ],
    python_requires=">=3.8",
)

"""Module for LIDL devices."""

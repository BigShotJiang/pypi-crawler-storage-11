"""smarthjemmet.dk devices."""

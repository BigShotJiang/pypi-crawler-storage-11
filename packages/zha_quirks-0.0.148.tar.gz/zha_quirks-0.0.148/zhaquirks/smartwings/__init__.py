"""SmartWings devices."""

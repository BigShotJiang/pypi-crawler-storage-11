"""Quirks for Sonoff devices."""

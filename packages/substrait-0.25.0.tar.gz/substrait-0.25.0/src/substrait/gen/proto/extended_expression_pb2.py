"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 5, '', 'proto/extended_expression.proto')
_sym_db = _symbol_database.Default()
from ..proto import algebra_pb2 as proto_dot_algebra__pb2
from ..proto.extensions import extensions_pb2 as proto_dot_extensions_dot_extensions__pb2
from ..proto import plan_pb2 as proto_dot_plan__pb2
from ..proto import type_pb2 as proto_dot_type__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1fproto/extended_expression.proto\x12\x05proto\x1a\x13proto/algebra.proto\x1a!proto/extensions/extensions.proto\x1a\x10proto/plan.proto\x1a\x10proto/type.proto"\xb0\x01\n\x13ExpressionReference\x123\n\nexpression\x18\x01 \x01(\x0b2\x11.proto.ExpressionH\x00R\nexpression\x124\n\x07measure\x18\x02 \x01(\x0b2\x18.proto.AggregateFunctionH\x00R\x07measure\x12!\n\x0coutput_names\x18\x03 \x03(\tR\x0boutputNamesB\x0b\n\texpr_type"\xa4\x04\n\x12ExtendedExpression\x12(\n\x07version\x18\x07 \x01(\x0b2\x0e.proto.VersionR\x07version\x12O\n\x0eextension_uris\x18\x01 \x03(\x0b2$.proto.extensions.SimpleExtensionURIB\x02\x18\x01R\rextensionUris\x12K\n\x0eextension_urns\x18\x08 \x03(\x0b2$.proto.extensions.SimpleExtensionURNR\rextensionUrns\x12L\n\nextensions\x18\x02 \x03(\x0b2,.proto.extensions.SimpleExtensionDeclarationR\nextensions\x12?\n\rreferred_expr\x18\x03 \x03(\x0b2\x1a.proto.ExpressionReferenceR\x0creferredExpr\x123\n\x0bbase_schema\x18\x04 \x01(\x0b2\x12.proto.NamedStructR\nbaseSchema\x12T\n\x13advanced_extensions\x18\x05 \x01(\x0b2#.proto.extensions.AdvancedExtensionR\x12advancedExtensions\x12,\n\x12expected_type_urls\x18\x06 \x03(\tR\x10expectedTypeUrlsB#\n\x0eio.proto.protoP\x01\xaa\x02\x0eProto.Protobufb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'proto.extended_expression_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x0eio.proto.protoP\x01\xaa\x02\x0eProto.Protobuf'
    _globals['_EXTENDEDEXPRESSION'].fields_by_name['extension_uris']._loaded_options = None
    _globals['_EXTENDEDEXPRESSION'].fields_by_name['extension_uris']._serialized_options = b'\x18\x01'
    _globals['_EXPRESSIONREFERENCE']._serialized_start = 135
    _globals['_EXPRESSIONREFERENCE']._serialized_end = 311
    _globals['_EXTENDEDEXPRESSION']._serialized_start = 314
    _globals['_EXTENDEDEXPRESSION']._serialized_end = 862
"""
Implicational Logic Graph Package

A package for working with graphs representing minimal implicational logic models.
"""

from .types import BaseType, Variable, Application, var, app
from .combinator import Combinator, S, K
from .graph_elements import Node, Edge, node, edge
from .graph import Graph
from .connection import Connection

__all__ = [
    "BaseType",
    "Variable",
    "Application",
    "var",
    "app",
    "Combinator",
    "S",
    "K",
    "Node",
    "Edge",
    "node",
    "edge",
    "Graph",
    "Connection",
]

__version__ = "0.1.0"

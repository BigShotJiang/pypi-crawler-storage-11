"""
Connection system for transactional graph modifications.

This module defines the Connection class which accumulates mutations and
executes them transactionally with automatic rollback on failure.
"""

from typing import TYPE_CHECKING

from .graph_elements import Node, Edge
from .combinator import Combinator
from .mutations import Mutation, AddNode, RemoveNode, AddEdge, RemoveEdge

if TYPE_CHECKING:
    from .graph import Graph


class Connection:
    """
    A connection for making transactional modifications to a graph.

    Usage:
        with graph.connect() as conn:
            conn.add_node(node1)
            conn.add_edge(edge1)
        # Changes are committed automatically if no exception occurs
        # Otherwise, all changes are rolled back

    Can also be used without context manager:
        conn = graph.connect()
        conn.add_node(node1)
        conn.commit()  # or conn.rollback()
    """

    def __init__(self, graph: "Graph"):
        """
        Initialize a connection.

        Args:
            graph: The graph to operate on
        """
        self.graph = graph
        self.mutations: list[Mutation] = []
        self._committed = False
        self._rolled_back = False

    def add_node(self, node: Node) -> "Connection":
        """
        Add a mutation to create a node.

        Args:
            node: The node to add

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(AddNode(node))
        return self

    def remove_node(self, node_uid: str) -> "Connection":
        """
        Add a mutation to remove a node.

        Args:
            node_uid: The uid of the node to remove

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(RemoveNode(node_uid))
        return self

    def add_edge(self, combinator: Combinator) -> "Connection":
        """
        Add a mutation to create an edge from a combinator.

        The edge will be created with nodes corresponding to the combinator's
        input and output types. The nodes must exist when the mutation is applied.

        Args:
            combinator: The combinator for this edge

        Returns:
            Connection: Self for method chaining

        Raises:
            ValueError: If the combinator doesn't have an Application type
        """
        self._check_state()

        # Import here to avoid circular import
        from .graph_elements import edge
        from .types import Application

        # Validate combinator type
        if not isinstance(combinator.type, Application):
            raise ValueError(
                f"Combinator must have an Application type to create an edge, "
                f"got {type(combinator.type).__name__}"
            )

        # Create the edge - validation that nodes exist will happen at forward() time
        e = edge(combinator)
        self.mutations.append(AddEdge(e))
        return self

    def remove_edge(self, edge_uid: str) -> "Connection":
        """
        Add a mutation to remove an edge.

        Args:
            edge_uid: The uid of the edge to remove

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(RemoveEdge(edge_uid))
        return self

    def commit(self) -> None:
        """
        Commit all mutations to the graph.

        If any mutation fails or the graph doesn't validate after all mutations,
        all changes are rolled back.

        Raises:
            RuntimeError: If already committed or rolled back
            Exception: Any exception from mutations or validation
        """
        self._check_state()

        applied_count = 0

        try:
            # Apply all mutations
            for mutation in self.mutations:
                mutation.forward(self.graph)
                applied_count += 1

            # Validate the graph
            self.graph.validate()

            # Mark as committed
            self._committed = True

        except Exception as e:
            # Rollback all applied mutations in reverse order
            for i in range(applied_count - 1, -1, -1):
                try:
                    self.mutations[i].backward(self.graph)
                except Exception as rollback_error:
                    # Log rollback error but continue rolling back
                    print(f"Warning: Error during rollback: {rollback_error}")

            self._rolled_back = True

            # Re-raise the original exception
            raise RuntimeError(
                f"Transaction failed and was rolled back. "
                f"Applied {applied_count}/{len(self.mutations)} mutations before failure."
            ) from e

    def rollback(self) -> None:
        """
        Explicitly rollback all mutations without applying them.

        Raises:
            RuntimeError: If already committed or rolled back
        """
        self._check_state()
        self._rolled_back = True

    def _check_state(self) -> None:
        """
        Check that the connection is in a valid state for operations.

        Raises:
            RuntimeError: If already committed or rolled back
        """
        if self._committed:
            raise RuntimeError("Connection has already been committed")
        if self._rolled_back:
            raise RuntimeError("Connection has already been rolled back")

    def __enter__(self) -> "Connection":
        """Enter the context manager."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        """
        Exit the context manager.

        Commits if no exception occurred, otherwise rolls back.

        Returns:
            bool: False to propagate any exception
        """
        if exc_type is None:
            # No exception, commit
            try:
                self.commit()
            except Exception:
                # Let the commit exception propagate
                return False
        else:
            # Exception occurred, rollback
            if not self._rolled_back:
                self.rollback()

        # Don't suppress the exception
        return False

    def __str__(self) -> str:
        """Return a string representation."""
        status = (
            "committed"
            if self._committed
            else ("rolled_back" if self._rolled_back else "open")
        )
        return f"Connection(mutations={len(self.mutations)}, status={status})"

    def __repr__(self) -> str:
        """Return a detailed representation."""
        return f"Connection(graph={self.graph}, mutations={self.mutations}, committed={self._committed}, rolled_back={self._rolled_back})"

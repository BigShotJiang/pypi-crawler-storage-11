"""
Mutation system for transactional graph modifications.

This module defines mutations that can be applied to a graph with forward
and backward operations, enabling transactional rollback on failures.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from .graph_elements import Node, Edge

if TYPE_CHECKING:
    from .graph import Graph


class Mutation(ABC):
    """
    Abstract base class for graph mutations.

    Each mutation must implement both forward (apply) and backward (revert)
    operations to support transactional rollback.
    """

    @abstractmethod
    def forward(self, graph: "Graph") -> None:
        """
        Apply the mutation to the graph.

        Args:
            graph: The graph to modify

        Raises:
            Exception: If the mutation cannot be applied
        """
        pass

    @abstractmethod
    def backward(self, graph: "Graph") -> None:
        """
        Revert the mutation from the graph.

        This operation should undo what forward() did.

        Args:
            graph: The graph to modify
        """
        pass

    @abstractmethod
    def __str__(self) -> str:
        """Return a string representation of the mutation."""
        pass


class AddNode(Mutation):
    """Mutation to add a node to the graph."""

    def __init__(self, node: Node):
        """
        Initialize the AddNode mutation.

        Args:
            node: The node to add
        """
        self.node = node

    def forward(self, graph: "Graph") -> None:
        """
        Add the node to the graph.

        Args:
            graph: The graph to modify

        Raises:
            ValueError: If the node already exists
        """
        graph._add_node(self.node)

    def backward(self, graph: "Graph") -> None:
        """
        Remove the node from the graph.

        Args:
            graph: The graph to modify
        """
        graph._remove_node(self.node.uid)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"AddNode({self.node})"


class RemoveNode(Mutation):
    """Mutation to remove a node from the graph."""

    def __init__(self, node_uid: str):
        """
        Initialize the RemoveNode mutation.

        Args:
            node_uid: The uid of the node to remove
        """
        self.node_uid = node_uid
        self._removed_node: Node | None = None
        self._removed_edges: list[Edge] = []

    def forward(self, graph: "Graph") -> None:
        """
        Remove the node from the graph.

        Also stores the node and its connected edges for potential rollback.

        Args:
            graph: The graph to modify

        Raises:
            KeyError: If the node doesn't exist
        """
        # Store the node and its edges for rollback
        self._removed_node = graph.get_node(self.node_uid)
        self._removed_edges = graph.get_edges_for_node(self.node_uid)

        # Remove the node (this will also remove connected edges)
        graph._remove_node(self.node_uid)

    def backward(self, graph: "Graph") -> None:
        """
        Re-add the node and its edges to the graph.

        Args:
            graph: The graph to modify
        """
        if self._removed_node is None:
            raise RuntimeError("Cannot revert RemoveNode: node was not stored")

        # Add the node back
        graph._add_node(self._removed_node)

        # Add the edges back
        for edge in self._removed_edges:
            graph._add_edge(edge)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"RemoveNode({self.node_uid})"


class AddEdge(Mutation):
    """Mutation to add an edge to the graph."""

    def __init__(self, edge: Edge):
        """
        Initialize the AddEdge mutation.

        Args:
            edge: The edge to add
        """
        self.edge = edge

    def forward(self, graph: "Graph") -> None:
        """
        Add the edge to the graph.

        Args:
            graph: The graph to modify

        Raises:
            ValueError: If the edge already exists or nodes don't exist
        """
        graph._add_edge(self.edge)

    def backward(self, graph: "Graph") -> None:
        """
        Remove the edge from the graph.

        Args:
            graph: The graph to modify
        """
        graph._remove_edge(self.edge.uid)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"AddEdge({self.edge})"


class RemoveEdge(Mutation):
    """Mutation to remove an edge from the graph."""

    def __init__(self, edge_uid: str):
        """
        Initialize the RemoveEdge mutation.

        Args:
            edge_uid: The uid of the edge to remove
        """
        self.edge_uid = edge_uid
        self._removed_edge: Edge | None = None

    def forward(self, graph: "Graph") -> None:
        """
        Remove the edge from the graph.

        Args:
            graph: The graph to modify

        Raises:
            KeyError: If the edge doesn't exist
        """
        # Store the edge for rollback
        self._removed_edge = graph.get_edge(self.edge_uid)

        # Remove the edge
        graph._remove_edge(self.edge_uid)

    def backward(self, graph: "Graph") -> None:
        """
        Re-add the edge to the graph.

        Args:
            graph: The graph to modify
        """
        if self._removed_edge is None:
            raise RuntimeError("Cannot revert RemoveEdge: edge was not stored")

        # Add the edge back
        graph._add_edge(self._removed_edge)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"RemoveEdge({self.edge_uid})"

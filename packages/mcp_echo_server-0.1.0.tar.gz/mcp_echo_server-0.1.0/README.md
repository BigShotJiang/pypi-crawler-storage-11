# MCP Test Server

mcp-name: io.github.bharath-krishna/mcp-test

A simple Model Context Protocol (MCP) server with an echo tool for testing purposes.

## Features

- **Echo Tool**: Returns back any message you send to it

## Installation

```bash
pip install mcp-echo-server
```

## Usage

Add this server to your MCP client configuration:

```json
{
  "mcpServers": {
    "mcp-echo-server": {
      "command": "mcp-echo-server"
    }
  }
}
```

## Development

Install in development mode:

```bash
uv pip install -e .
```

## Tools

### echo

Echoes back the provided message.

**Input:**
- `message` (string, required): The message to echo back

**Example:**
```json
{
  "message": "Hello, world!"
}
```

**Output:**
```
Echo: Hello, world!
```

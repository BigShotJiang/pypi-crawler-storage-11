def main() -> None:
    print("Hello from mssql-mcpserver!")

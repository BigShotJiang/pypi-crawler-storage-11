import os
import json
import pyodbc
from fastmcp import FastMCP, Context

mcp = FastMCP(name="SqlServer MCP Server")


def main() -> None:
    mcp.run()


@mcp.tool
async def get_database_servers(context: Context) -> list[str]:
    """Get the list of configured sqlservers."""
    await context.info(f"Try list database servers from env {os.getenv("DATABASE_SERVERS", '["localhost"]')}")
    return json.loads(os.getenv("DATABASE_SERVERS", '["localhost"]'))


@mcp.tool
async def get_databases(server: str, context: Context) -> list[str]:
    """Get the list of sqlserver databases."""
    await context.info(f"Try list databases from server {server}")
    
    with pyodbc.connect(
        get_database_server_connection_string(server, "master")
    ) as conn:
        with conn.cursor() as cursor:
            cursor.execute("SELECT name FROM sys.databases;")
            return [row[0] for row in cursor.fetchall()]


def get_database_server_connection_string(server: str, database: str) -> str:
    return f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;"

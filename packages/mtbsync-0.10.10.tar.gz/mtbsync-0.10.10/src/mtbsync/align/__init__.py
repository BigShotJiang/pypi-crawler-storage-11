"""Time-warp alignment utilities."""

"""
Streamlit UI for side-by-side video comparison with marker overlay and annotation.

Launch with: mtbsync compare-ui
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

# Lazy import for optional dependency: never hard-exit at import time.
try:
    import streamlit as st  # type: ignore
except Exception as e:  # pragma: no cover
    raise ImportError(
        'Streamlit is required for the compare UI. '
        'Install with: pip install "mtbsync[compare]"'
    ) from e


def main():
    """Main Streamlit application for video comparison."""
    st.set_page_config(
        page_title="MTBSync Video Comparison",
        page_icon="🎥",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    st.title("🎥 MTBSync Video Comparison")
    st.markdown(
        "Side-by-side video playback with marker overlay, delta inspection, and annotations."
    )

    # Initialize session state
    if "annotations" not in st.session_state:
        st.session_state.annotations = []
    if "selected_marker_idx" not in st.session_state:
        st.session_state.selected_marker_idx = None
    if "data_loaded" not in st.session_state:
        st.session_state.data_loaded = False

    # Sidebar: File inputs
    with st.sidebar:
        st.header("📁 Input Files")

        # Pre-populate from environment (CLI wiring)
        env_ref = os.getenv("MTB_COMPARE_REF", "")
        env_new = os.getenv("MTB_COMPARE_NEW", "")
        env_refm = os.getenv("MTB_COMPARE_REF_MARKERS", "")
        env_newm = os.getenv("MTB_COMPARE_NEW_MARKERS", "")
        env_tw = os.getenv("MTB_COMPARE_TIMEWARP_JSON", "")
        env_root = os.getenv("MTB_COMPARE_ROOT", "")

        if any([env_ref, env_new, env_refm, env_newm, env_tw, env_root]):
            st.caption("📋 Preloaded from CLI environment variables")

        ref_video = st.text_input(
            "Reference Video",
            value=env_ref,
            placeholder="path/to/ref.mp4",
            help="Reference video file",
        )
        new_video = st.text_input(
            "New Video", value=env_new, placeholder="path/to/new.mp4", help="New video file"
        )

        st.markdown("---")

        ref_markers = st.text_input(
            "Reference Markers",
            value=env_refm,
            placeholder="path/to/ref_markers.csv",
            help="CSV with marker_id, t_ref columns",
        )
        new_markers = st.text_input(
            "New Markers (optional)",
            value=env_newm,
            placeholder="path/to/new_markers.csv",
            help="CSV with marker_id, t_new columns (optional)",
        )
        timewarp_json = st.text_input(
            "Timewarp JSON (optional)",
            value=env_tw,
            placeholder="path/to/timewarp.json",
            help="Timewarp parameters for predicted times",
        )

        st.markdown("---")

        load_btn = st.button("🔄 Load Data", type="primary", use_container_width=True)

        if load_btn:
            load_data(ref_video, new_video, ref_markers, new_markers, timewarp_json)

    # Main content area
    if not st.session_state.data_loaded:
        st.info("👈 Configure input files in the sidebar and click 'Load Data' to begin.")
        return

    # Display loaded data
    display_videos(st.session_state.ref_video, st.session_state.new_video)
    display_markers_and_deltas()
    display_annotations()


def load_data(ref_video, new_video, ref_markers, new_markers, timewarp_json):
    """Load all input files and compute deltas."""
    from mtbsync import compare_core

    errors = []

    # Validate video files
    if not ref_video or not Path(ref_video).exists():
        errors.append(f"Reference video not found: {ref_video}")
    if not new_video or not Path(new_video).exists():
        errors.append(f"New video not found: {new_video}")

    # Load reference markers (required)
    if not ref_markers or not Path(ref_markers).exists():
        errors.append(f"Reference markers file not found: {ref_markers}")
        st.session_state.data_loaded = False
        for err in errors:
            st.error(err)
        return

    if errors:
        st.session_state.data_loaded = False
        for err in errors:
            st.error(err)
        return

    try:
        # Load reference markers
        df_ref = compare_core.load_markers_csv(Path(ref_markers))

        # Load new markers if provided
        df_new = None
        if new_markers and Path(new_markers).exists():
            df_new = compare_core.load_markers_csv(Path(new_markers))

        # Load timewarp if provided
        warp_data = None
        t_new_est = None
        if timewarp_json and Path(timewarp_json).exists():
            warp_data = compare_core.load_timewarp_json(Path(timewarp_json))
            if warp_data and warp_data.get("ok", False):
                t_new_est = compare_core.predict_new_times_from_warp(df_ref, warp_data)
            elif warp_data:
                st.warning("Timewarp loaded but marked as not OK (quality gate failed)")

        # Compute deltas
        df_deltas = compare_core.compute_deltas(df_ref, df_new, t_new_est)

        # Compute quality summary
        quality = compare_core.summarise_quality(df_deltas)

        # Store in session state
        st.session_state.ref_video = ref_video
        st.session_state.new_video = new_video
        st.session_state.df_ref = df_ref
        st.session_state.df_new = df_new
        st.session_state.df_deltas = df_deltas
        st.session_state.warp_data = warp_data
        st.session_state.quality = quality
        st.session_state.data_loaded = True

        st.success("✅ Data loaded successfully!")

    except Exception as e:
        st.error(f"Error loading data: {e}")
        st.session_state.data_loaded = False


def display_videos(ref_video, new_video):
    """Display dual video panes with synchronized controls."""
    st.header("📹 Video Comparison")

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Reference Video")
        if Path(ref_video).exists():
            st.video(ref_video)
        else:
            st.warning(f"Video not found: {ref_video}")

    with col2:
        st.subheader("New Video")
        if Path(new_video).exists():
            st.video(new_video)
        else:
            st.warning(f"Video not found: {new_video}")

    # Note: Streamlit's native st.video() doesn't support programmatic seeking
    # For full sync control, would need custom HTML/JS component
    st.info(
        "💡 Tip: Use the marker table below to jump to specific times. "
        "For synchronized playback, consider using external video tools."
    )


def display_markers_and_deltas():
    """Display marker list, timeline, and delta statistics."""
    st.header("🎯 Markers & Deltas")

    df_deltas = st.session_state.df_deltas
    quality = st.session_state.quality

    # Quality metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Count", quality["count"])
    with col2:
        mae = quality["mae"]
        st.metric("MAE", f"{mae:.3f}s" if not float("nan") == mae else "N/A")
    with col3:
        p90 = quality["p90"]
        st.metric("P90", f"{p90:.3f}s" if not float("nan") == p90 else "N/A")
    with col4:
        median = quality["median"]
        st.metric("Median", f"{median:.3f}s" if not float("nan") == median else "N/A")

    # Search/filter
    search = st.text_input("🔍 Search markers", placeholder="Filter by marker ID or label...")

    # Filter dataframe
    df_display = df_deltas.copy()
    if search:
        # Search in marker_id and any label/note columns
        mask = df_display.astype(str).apply(
            lambda row: search.lower() in row.to_string().lower(), axis=1
        )
        df_display = df_display[mask]

    # Marker table with selection
    st.dataframe(
        df_display,
        use_container_width=True,
        height=400,
        hide_index=False,
    )

    # Timeline visualization
    if len(df_display) > 0:
        display_timeline(df_display)


def display_timeline(df):
    """Display interactive timeline chart of markers."""
    try:
        import plotly.graph_objects as go
    except ImportError:
        st.warning(
            "Plotly not available for timeline visualization. "
            'Install with: pip install "mtbsync[compare]"'
        )
        return

    st.subheader("📊 Timeline")

    fig = go.Figure()

    # Plot t_ref vs t_new (if available)
    if "t_new" in df.columns:
        valid = df.dropna(subset=["t_new"])
        if len(valid) > 0:
            fig.add_trace(
                go.Scatter(
                    x=valid["t_ref"],
                    y=valid["t_new"],
                    mode="markers",
                    name="Measured",
                    marker=dict(size=8, color="blue"),
                    text=valid["marker_id"],
                    hovertemplate="<b>%{text}</b><br>t_ref: %{x:.2f}s<br>t_new: %{y:.2f}s<extra></extra>",
                )
            )

    # Plot t_ref vs t_new_est (if available)
    if "t_new_est" in df.columns:
        valid = df.dropna(subset=["t_new_est"])
        if len(valid) > 0:
            fig.add_trace(
                go.Scatter(
                    x=valid["t_ref"],
                    y=valid["t_new_est"],
                    mode="markers",
                    name="Predicted",
                    marker=dict(size=6, color="orange", symbol="diamond"),
                    text=valid["marker_id"],
                    hovertemplate="<b>%{text}</b><br>t_ref: %{x:.2f}s<br>t_new_est: %{y:.2f}s<extra></extra>",
                )
            )

    # Add diagonal reference line (perfect sync)
    if len(df) > 0:
        t_min = df["t_ref"].min()
        t_max = df["t_ref"].max()
        fig.add_trace(
            go.Scatter(
                x=[t_min, t_max],
                y=[t_min, t_max],
                mode="lines",
                name="Perfect Sync",
                line=dict(color="gray", dash="dash"),
                hoverinfo="skip",
            )
        )

    fig.update_layout(
        xaxis_title="Reference Time (s)",
        yaxis_title="New Time (s)",
        hovermode="closest",
        height=400,
    )

    st.plotly_chart(fig, use_container_width=True)


def display_annotations():
    """Display annotation management interface."""
    st.header("📝 Annotations")

    # Annotation form
    with st.expander("➕ Add/Edit Annotation", expanded=False):
        col1, col2 = st.columns([1, 3])

        with col1:
            marker_ids = st.session_state.df_deltas["marker_id"].tolist()
            selected_marker = st.selectbox(
                "Marker ID",
                options=marker_ids,
                key="annotation_marker_select",
            )

        with col2:
            note_text = st.text_area(
                "Note",
                placeholder="Add notes or observations for this marker...",
                key="annotation_note",
                height=100,
            )

        label_text = st.text_input(
            "Label/Tag",
            placeholder="e.g., 'Needs Review', 'Good Sync', etc.",
            key="annotation_label",
        )

        if st.button("💾 Save Annotation", use_container_width=True):
            add_annotation(selected_marker, label_text, note_text)

    # Display existing annotations
    if st.session_state.annotations:
        st.subheader("Current Annotations")

        for idx, ann in enumerate(st.session_state.annotations):
            with st.container():
                col1, col2, col3 = st.columns([2, 6, 1])

                with col1:
                    st.markdown(f"**{ann['marker_id']}**")
                    if ann.get("label"):
                        st.caption(f"🏷️ {ann['label']}")

                with col2:
                    st.markdown(ann.get("note", "_No note_"))
                    st.caption(f"Created: {ann['created_at']}")

                with col3:
                    if st.button("🗑️", key=f"delete_ann_{idx}"):
                        st.session_state.annotations.pop(idx)
                        st.rerun()

                st.divider()
    else:
        st.info("No annotations yet. Use the form above to add one.")

    # Export buttons
    if st.session_state.annotations:
        st.subheader("📥 Export Annotations")

        col1, col2 = st.columns(2)

        with col1:
            csv_data = export_annotations_csv()
            st.download_button(
                label="📄 Download CSV",
                data=csv_data,
                file_name=f"annotations_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv",
                use_container_width=True,
            )

        with col2:
            json_data = export_annotations_json()
            st.download_button(
                label="📋 Download JSON",
                data=json_data,
                file_name=f"annotations_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json",
                use_container_width=True,
            )


def add_annotation(marker_id, label, note):
    """Add or update annotation for a marker."""
    # Check if annotation for this marker already exists
    existing_idx = None
    for idx, ann in enumerate(st.session_state.annotations):
        if ann["marker_id"] == marker_id:
            existing_idx = idx
            break

    # Get marker data
    marker_row = st.session_state.df_deltas[
        st.session_state.df_deltas["marker_id"] == marker_id
    ].iloc[0]

    annotation = {
        "marker_id": marker_id,
        "t_ref": float(marker_row["t_ref"]),
        "t_new": float(marker_row.get("t_new", marker_row.get("t_new_est", 0))),
        "delta_sec": float(marker_row.get("delta_sec", 0)),
        "label": label,
        "note": note,
        "created_at": datetime.now().isoformat(),
    }

    if existing_idx is not None:
        st.session_state.annotations[existing_idx] = annotation
        st.success(f"✅ Updated annotation for marker {marker_id}")
    else:
        st.session_state.annotations.append(annotation)
        st.success(f"✅ Added annotation for marker {marker_id}")


def export_annotations_csv() -> str:
    """Export annotations to CSV format."""
    try:
        import pandas as pd
    except ImportError:
        return "ERROR: pandas required for CSV export"

    if not st.session_state.annotations:
        return ""

    df = pd.DataFrame(st.session_state.annotations)
    return df.to_csv(index=False)


def export_annotations_json() -> str:
    """Export annotations to JSON format."""
    return json.dumps(st.session_state.annotations, indent=2)


# Entry point for streamlit run
if __name__ == "__main__":
    main()

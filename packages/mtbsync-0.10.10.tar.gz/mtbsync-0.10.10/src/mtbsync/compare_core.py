"""
Core helpers for side-by-side video comparison.

Provides data loading, timewarp predictions, and delta computation for the
comparison UI. All functions handle missing data gracefully and use lazy
imports to avoid hard dependencies.
"""

import json
from pathlib import Path
from typing import Optional

import numpy as np


def load_markers_csv(path: Path):
    """
    Load markers from CSV file, preserving all columns.

    Args:
        path: Path to CSV file with columns marker_id, t_ref, and optionally t_new

    Returns:
        pandas.DataFrame with normalized columns (marker_id, t_ref, t_new if present)
        plus any additional columns from the original file

    Raises:
        ImportError: If pandas not installed
        FileNotFoundError: If file doesn't exist
        ValueError: If required columns missing
    """
    try:
        import pandas as pd
    except ImportError as e:
        raise ImportError(
            'pandas is required for compare UI; install with `pip install "mtbsync[compare]"`'
        ) from e

    if not path.exists():
        raise FileNotFoundError(f"Markers file not found: {path}")

    df = pd.read_csv(path)

    # Validate required columns
    # Reference markers need: marker_id, t_ref
    # New markers need: marker_id, t_new
    # Either is acceptable (not both required)
    if "marker_id" not in df.columns:
        raise ValueError(
            f"CSV must contain 'marker_id' column. Found: {list(df.columns)}"
        )

    if "t_ref" not in df.columns and "t_new" not in df.columns:
        raise ValueError(
            f"CSV must contain either 't_ref' or 't_new' column. Found: {list(df.columns)}"
        )

    return df


def load_timewarp_json(path: Path) -> Optional[dict]:
    """
    Load timewarp parameters from JSON file.

    Args:
        path: Path to timewarp.json file

    Returns:
        dict with keys 'a', 'b', 'ok' or None if file doesn't exist

    Raises:
        ValueError: If JSON invalid or missing required fields
    """
    if not path.exists():
        return None

    try:
        with open(path, "r") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in {path}: {e}") from e

    # Validate required fields
    if "warp" not in data or "a" not in data["warp"] or "b" not in data["warp"]:
        raise ValueError(
            f"timewarp.json must contain 'warp' with 'a' and 'b' fields. Found: {list(data.keys())}"
        )

    return data


def predict_new_times_from_warp(df_ref, warp: dict):
    """
    Predict new times from reference times using affine timewarp.

    Formula: t_new_est = (t_ref - b) / a

    Args:
        df_ref: DataFrame with t_ref column
        warp: dict from timewarp.json with warp.a and warp.b

    Returns:
        pandas.Series of predicted new times (t_new_est)

    Raises:
        ImportError: If pandas not installed
        ValueError: If warp parameters invalid
    """
    try:
        import pandas as pd
    except ImportError as e:
        raise ImportError(
            'pandas is required for compare UI; install with `pip install "mtbsync[compare]"`'
        ) from e

    if not isinstance(warp, dict):
        raise ValueError(f"warp must be a dict, got {type(warp)}")

    # Extract affine parameters
    a = warp.get("warp", {}).get("a") if "warp" in warp else warp.get("a")
    b = warp.get("warp", {}).get("b") if "warp" in warp else warp.get("b")

    if a is None or b is None:
        raise ValueError(f"warp must contain 'a' and 'b', got: {warp}")

    if abs(a) < 1e-9:
        raise ValueError(f"warp parameter 'a' too close to zero: {a}")

    # Apply inverse affine transform: t_new = (t_ref - b) / a
    t_new_est = (df_ref["t_ref"] - b) / a

    return t_new_est


def compute_deltas(df_ref, df_new_opt=None, t_new_est_opt=None):
    """
    Compute time deltas between measured and predicted marker times.

    Priority order:
    1. Use measured t_new from df_new_opt if available (join on marker_id)
    2. Fall back to t_new_est_opt if provided
    3. Skip delta computation if neither available

    Args:
        df_ref: DataFrame with marker_id and t_ref columns
        df_new_opt: Optional DataFrame with marker_id and t_new columns
        t_new_est_opt: Optional Series of predicted new times (aligned with df_ref)

    Returns:
        pandas.DataFrame with columns:
        - marker_id
        - t_ref
        - t_new (if df_new_opt provided)
        - t_new_est (if t_new_est_opt provided)
        - delta_sec (computed from available times)

    Raises:
        ImportError: If pandas not installed
    """
    try:
        import pandas as pd
    except ImportError as e:
        raise ImportError(
            'pandas is required for compare UI; install with `pip install "mtbsync[compare]"`'
        ) from e

    # Start with reference markers
    result = df_ref[["marker_id", "t_ref"]].copy()

    # Add measured t_new if available (join on marker_id)
    if df_new_opt is not None and "t_new" in df_new_opt.columns:
        result = result.merge(
            df_new_opt[["marker_id", "t_new"]], on="marker_id", how="left"
        )

    # Add predicted t_new_est if provided
    if t_new_est_opt is not None:
        result["t_new_est"] = t_new_est_opt

    # Compute delta: prefer measured t_new, fall back to t_new_est
    if "t_new" in result.columns and "t_new_est" in result.columns:
        # Use measured if available, otherwise use predicted
        result["delta_sec"] = result.apply(
            lambda row: (
                row["t_new"] - row["t_ref"]
                if pd.notna(row["t_new"])
                else (
                    row["t_new_est"] - row["t_ref"]
                    if pd.notna(row["t_new_est"])
                    else np.nan
                )
            ),
            axis=1,
        )
    elif "t_new" in result.columns:
        result["delta_sec"] = result["t_new"] - result["t_ref"]
    elif "t_new_est" in result.columns:
        result["delta_sec"] = result["t_new_est"] - result["t_ref"]
    else:
        # No times available for delta computation
        result["delta_sec"] = np.nan

    return result


def summarise_quality(df) -> dict:
    """
    Compute summary statistics for delta quality.

    Args:
        df: DataFrame with delta_sec column

    Returns:
        dict with keys:
        - mae: Mean absolute error (seconds)
        - p90: 90th percentile absolute error (seconds)
        - count: Number of valid deltas
        - median: Median delta (seconds)
        - std: Standard deviation of deltas (seconds)
    """
    if "delta_sec" not in df.columns:
        return {"mae": np.nan, "p90": np.nan, "count": 0, "median": np.nan, "std": np.nan}

    # Filter out NaN values
    valid_deltas = df["delta_sec"].dropna()

    if len(valid_deltas) == 0:
        return {"mae": np.nan, "p90": np.nan, "count": 0, "median": np.nan, "std": np.nan}

    abs_deltas = np.abs(valid_deltas)

    return {
        "mae": float(np.mean(abs_deltas)),
        "p90": float(np.percentile(abs_deltas, 90)),
        "count": len(valid_deltas),
        "median": float(np.median(valid_deltas)),
        "std": float(np.std(valid_deltas)),
    }

"""Marker schema and transfer utilities."""

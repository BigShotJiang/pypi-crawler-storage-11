"""IO utilities for video and GPS data."""

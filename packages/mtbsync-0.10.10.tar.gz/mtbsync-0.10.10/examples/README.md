# MTB Sync Examples & Helper Scripts

This directory contains practical examples and helper scripts for common MTB Sync workflows.

## 📋 Available Scripts

### 1. `visual_diagnostic.sh` ⭐ NEW

**Generate alignment overlay PNG with automatic quality interpretation.**

```bash
./visual_diagnostic.sh ./batch_output/run_001
```

**What it does:**
- Finds `ref_markers.csv` and `timewarp.json` automatically
- Generates scatter plot overlay showing alignment quality
- Predicts expected visual pattern based on metrics
- Provides interpretation guidance
- Optionally opens PNG viewer

**Output:**
- `alignment_overlay.png` in the pair directory
- Visual prediction based on P90, inlier_frac, and warp params
- Next steps recommendations

**Use when:**
- You want to **see** alignment quality, not just read numbers
- Quick visual confirmation of weak alignment
- Investigating gaps, clusters, or outliers in temporal alignment

---

### 2. `diagnose_alignment.sh`

**Diagnose alignment quality for a completed sync pair.**

```bash
./diagnose_alignment.sh ./batch_output/run_001
```

**What it does:**
- Parses `timewarp.json` to extract quality metrics
- Assesses alignment quality (excellent/good/weak/failed)
- Suggests parameter tuning if quality is weak
- Provides visual inspection commands

**Output example:**
```
📊 Time-Warp Quality:
-----------------------------------
Status: true
Model: affine (a=1.0, b=0.0)
PPM: 0
Inlier Fraction: 0.33
MAE: 0.89s
P90: 2.0s

🎯 Quality Assessment:
-----------------------------------
✓ Passed quality gates
⚠ WEAK alignment - residuals too high (P90 ≥ 1.0s)
  Consider re-running with stricter parameters
```

### 3. `dashboard_cleanup.sh`

**Clean up old telemetry files for a cleaner dashboard view.**

```bash
./dashboard_cleanup.sh ./batch_output 50
```

**What it does:**
- Counts current `perf.json` files
- Shows dry-run preview of files to be deleted
- Prompts for confirmation before deletion
- Uses `mtbsync prune-perf` to keep newest N files
- Provides dashboard startup commands

**Arguments:**
- `$1`: Batch output directory (required)
- `$2`: Number of files to keep (optional, default: 100)

### 4. `resync_strict.sh`

**Re-sync a video pair with strict quality parameters to catch weak alignments.**

```bash
./resync_strict.sh ref.mp4 new.mp4 cache/ref_index.npz strict_output ref_markers.csv
```

**What it does:**
- Runs `mtbsync sync` with **strict quality gates**:
  - `--warp-window-sec 0.3` (tight gating)
  - `--warp-inlier-thresh 0.05` (50ms tolerance)
  - `--warp-min-inlier-frac 0.5` (50% support required)
  - `--warp-ransac-iters 1000` (thorough search)
  - `--warp-max-ppm 500` (0.05% drift limit)
- Analyzes results and suggests next steps
- Provides visual inspection commands

**Arguments:**
- `$1`: Reference video (required)
- `$2`: New video (required)
- `$3`: Reference index .npz (required)
- `$4`: Output directory (required)
- `$5`: Reference markers CSV (optional)

**Exit codes (for CI/CD):**
- `0`: Success or quality gates passed
- `1`: Error (missing files, invalid arguments)
- `2`: Quality gates failed (ok=false in timewarp.json) - expected for weak pairs

## 🎯 Common Workflows

### Workflow 1: Diagnose Weak Alignment

You've run a batch job and the dashboard shows `timewarp_ok=true` but high P90 residuals (>1s):

```bash
# Step 1: Diagnose the specific pair
./diagnose_alignment.sh ./batch_output/run_problematic

# Step 2: Re-run with strict parameters
./resync_strict.sh \
  videos/trail_ref.mp4 \
  videos/trail_new.mp4 \
  cache/ref_index.npz \
  strict_output \
  ref_markers.csv

# Step 3: Compare results
# Original: batch_output/run_problematic/timewarp.json
# Strict: strict_output/timewarp.json
```

**Expected outcome:** Strict gates will produce `ok:false`, confirming the alignment is unreliable.

### Workflow 2: Clean Up Dashboard After Large Batch

You've run hundreds of pairs and the dashboard is cluttered with telemetry:

```bash
# Option A: CLI cleanup
./dashboard_cleanup.sh ./batch_output 50

# Option B: Dashboard UI cleanup
mtbsync dashboard --root ./batch_output --allow-write
# Then use the "Prune perf.json" button in the UI
```

### Workflow 3: Quality-First Batch Processing

Start with strict parameters to catch weak alignments early:

```bash
# Step 1: Index reference video
mtbsync index --reference ref.mp4 --fps 3.0 --out cache/ref_index.npz

# Step 2: Run batch with strict parameters
mtbsync batch input_videos/ \
  --out-dir strict_batch_output \
  --warp-min-inlier-frac 0.5 \
  --warp-max-ppm 500 \
  --warp-ransac-iters 1000

# Step 3: Review results in dashboard
mtbsync dashboard --root ./strict_batch_output

# Step 4: Diagnose failed pairs
for pair in strict_batch_output/*; do
  if [ -d "$pair" ]; then
    ./diagnose_alignment.sh "$pair"
  fi
done
```

## 📊 Quality Interpretation Guide

### Excellent Alignment
```json
{
  "ok": true,
  "inlier_frac": 0.78,
  "residuals": {"mae": 0.12, "p90": 0.35}
}
```
- ✅ High inlier fraction (>70%)
- ✅ Low residuals (P90 < 0.5s)
- **Action:** Use confidently for marker transfer

### Good Alignment
```json
{
  "ok": true,
  "inlier_frac": 0.52,
  "residuals": {"mae": 0.45, "p90": 0.87}
}
```
- ✓ Acceptable inlier fraction (50-70%)
- ⚠ Moderate residuals (P90 < 1.0s)
- **Action:** Visual inspection recommended

### Weak Alignment
```json
{
  "ok": true,
  "inlier_frac": 0.33,
  "residuals": {"mae": 0.89, "p90": 2.0}
}
```
- ⚠ Low inlier fraction (<40%)
- ❌ High residuals (P90 > 1.0s)
- **Action:** Re-run with strict parameters, expect failure

### Failed Alignment
```json
{
  "ok": false,
  "inlier_frac": 0.18,
  "residuals": {"mae": 1.45, "p90": 3.2}
}
```
- ❌ Very low inlier fraction (<25%)
- ❌ Very high residuals (P90 > 2.0s)
- **Action:** Investigate cause (different tracks, scene cuts, poor lighting)

## 🔧 Parameter Tuning Reference

| Use Case | Gate Parameters | When to Use |
|----------|----------------|-------------|
| **Permissive** (default) | `--warp-min-inlier-frac 0.25` | Initial exploration, diverse conditions |
| **Standard** | `--warp-min-inlier-frac 0.4 --warp-max-ppm 800` | Production use with good video quality |
| **Strict** (recommended) | `--warp-min-inlier-frac 0.5 --warp-max-ppm 500 --warp-inlier-thresh 0.05` | High-precision marker transfer, quality gating |
| **Very Strict** | `--warp-min-inlier-frac 0.7 --warp-max-ppm 200 --warp-inlier-thresh 0.03` | Research/validation, expect many rejections |

## 📚 Additional Resources

- **Main README:** [../README.md](../README.md) - Full documentation
- **Developer Guide:** [../CLAUDE.md](../CLAUDE.md) - Implementation details
- **Changelog:** [../CHANGELOG.md](../CHANGELOG.md) - Version history

## 🆘 Getting Help

If these scripts don't solve your problem:

1. **Check the logs:** Look at stderr output from the sync command
2. **Inspect raw pairs:** `head -50 pairs_raw.csv` to see match quality
3. **Use visual inspection:** `mtbsync viewer` to see alignment overlay
4. **File an issue:** https://github.com/markg72/goprosync/issues

Include:
- Output from `diagnose_alignment.sh`
- First 50 rows of `pairs.csv`
- Video characteristics (duration, fps, lighting conditions)
- `timewarp.json` contents

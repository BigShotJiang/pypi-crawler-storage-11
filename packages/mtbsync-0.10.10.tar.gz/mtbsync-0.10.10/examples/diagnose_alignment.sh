#!/usr/bin/env bash
# Diagnostic script for MTB Sync alignment quality
# Usage: ./diagnose_alignment.sh <pair_output_directory>

set -euo pipefail

# Resolve repo root (script lives in examples/)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

if [ $# -eq 0 ]; then
    echo "Usage: $0 <pair_output_directory>"
    echo "Example: $0 ./batch_output/run_001"
    exit 1
fi

PAIR_DIR="$(cd "$1" 2>/dev/null && pwd)" || {
    echo "Error: Directory $1 not found"
    exit 1
}

echo "==================================="
echo "MTB Sync Alignment Diagnostics"
echo "==================================="
echo "Directory: $PAIR_DIR"
echo ""

# Check for required files
if [ ! -f "$PAIR_DIR/timewarp.json" ]; then
    echo "❌ timewarp.json not found - run sync first"
    exit 1
fi

echo "📊 Time-Warp Quality:"
echo "-----------------------------------"

# Extract key metrics using jq (if available)
if command -v jq &> /dev/null; then
    OK=$(jq -r '.ok // "N/A"' "$PAIR_DIR/timewarp.json")
    MODEL=$(jq -r '.model // "N/A"' "$PAIR_DIR/timewarp.json")
    A=$(jq -r '.params.a // "N/A"' "$PAIR_DIR/timewarp.json")
    B=$(jq -r '.params.b // "N/A"' "$PAIR_DIR/timewarp.json")
    PPM=$(jq -r '.ppm // "N/A"' "$PAIR_DIR/timewarp.json")
    INLIER_FRAC=$(jq -r '.inlier_frac // "N/A"' "$PAIR_DIR/timewarp.json")
    MAE=$(jq -r '.residuals.mae // "N/A"' "$PAIR_DIR/timewarp.json")
    P90=$(jq -r '.residuals.p90 // "N/A"' "$PAIR_DIR/timewarp.json")

    echo "Status: $OK"
    echo "Model: $MODEL (a=$A, b=$B)"
    echo "PPM: $PPM"
    echo "Inlier Fraction: $INLIER_FRAC"
    echo "MAE: ${MAE}s"
    echo "P90: ${P90}s"
    echo ""

    # Quality assessment
    echo "🎯 Quality Assessment:"
    echo "-----------------------------------"

    if [ "$OK" = "true" ]; then
        echo "✓ Passed quality gates"

        # Check P90
        if command -v bc &> /dev/null; then
            if (( $(echo "$P90 < 0.5" | bc -l) )); then
                echo "✓ Excellent alignment (P90 < 0.5s)"
            elif (( $(echo "$P90 < 1.0" | bc -l) )); then
                echo "⚠ Good alignment, acceptable for most uses (P90 < 1.0s)"
            else
                echo "⚠ WEAK alignment - residuals too high (P90 ≥ 1.0s)"
                echo "  Consider re-running with stricter parameters"
            fi

            # Check inlier fraction
            if (( $(echo "$INLIER_FRAC < 0.4" | bc -l) )); then
                echo "⚠ Low inlier fraction (<40%) - many pairs rejected"
            fi
        fi
    else
        echo "❌ Failed quality gates"
        echo "  This is EXPECTED for dissimilar runs or poor conditions"
    fi
else
    # Fallback without jq
    cat "$PAIR_DIR/timewarp.json"
fi

echo ""
echo "📁 Pair Files:"
echo "-----------------------------------"
[ -f "$PAIR_DIR/pairs.csv" ] && echo "✓ pairs.csv ($(wc -l < "$PAIR_DIR/pairs.csv") rows)"
[ -f "$PAIR_DIR/pairs_raw.csv" ] && echo "✓ pairs_raw.csv ($(wc -l < "$PAIR_DIR/pairs_raw.csv") rows)"
[ -f "$PAIR_DIR/new_markers.csv" ] && echo "✓ new_markers.csv ($(wc -l < "$PAIR_DIR/new_markers.csv") markers)"
[ -f "$PAIR_DIR/perf.json" ] && echo "✓ perf.json (telemetry)"

echo ""
echo "💡 Suggested Actions:"
echo "-----------------------------------"

if command -v jq &> /dev/null && command -v bc &> /dev/null; then
    if [ "$OK" = "true" ] && (( $(echo "$P90 >= 1.0" | bc -l) )); then
        echo "⚠ Weak alignment detected. Re-run with stricter parameters:"
        echo ""
        echo "mtbsync sync \\"
        echo "  --reference <ref.mp4> \\"
        echo "  --new <new.mp4> \\"
        echo "  --index <ref_index.npz> \\"
        echo "  --out $PAIR_DIR \\"
        echo "  --warp-window-sec 0.3 \\"
        echo "  --warp-inlier-thresh 0.05 \\"
        echo "  --warp-min-inlier-frac 0.5 \\"
        echo "  --warp-ransac-iters 1000 \\"
        echo "  --warp-max-ppm 500"
    elif [ "$OK" = "false" ]; then
        echo "Alignment failed quality gates. Options:"
        echo "  1. Investigate raw pairs: head -50 $PAIR_DIR/pairs_raw.csv"
        echo "  2. Check for scene cuts, poor lighting, or camera shake"
        echo "  3. Verify videos are from the same track/session"
        echo "  4. Try GPS-based alignment if available"
    else
        echo "✓ Alignment quality is acceptable"
    fi
fi

# Visual inspection command
if [ -f "$PAIR_DIR/timewarp.json" ]; then
    echo ""
    echo "🔍 Visual Inspection:"
    echo "-----------------------------------"
    if [ -f "ref_markers.csv" ]; then
        echo "mtbsync viewer --headless \\"
        echo "  --ref-markers ref_markers.csv \\"
        echo "  --timewarp-json $PAIR_DIR/timewarp.json \\"
        echo "  --out-png $PAIR_DIR/alignment_overlay.png"
    else
        echo "mtbsync viewer  # Launch GUI with file picker"
    fi
fi

echo ""
echo "==================================="

#!/usr/bin/env bash
# Visual diagnostic helper - generates overlay and interprets quality
# Usage: ./visual_diagnostic.sh <pair_output_dir>

set -euo pipefail

# Resolve repo root (script lives in examples/)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

if [ $# -eq 0 ]; then
    echo "Usage: $0 <pair_output_dir>"
    echo "Example: $0 ./batch_output/run_001"
    echo ""
    echo "This script:"
    echo "  1. Finds ref_markers.csv and timewarp.json"
    echo "  2. Generates alignment overlay PNG"
    echo "  3. Interprets quality metrics visually"
    exit 1
fi

PAIR_DIR="$(cd "$1" 2>/dev/null && pwd)" || {
    echo "Error: Directory $1 not found"
    exit 1
}

echo "==================================="
echo "Visual Alignment Diagnostic"
echo "==================================="
echo "Pair: $PAIR_DIR"
echo ""

# Find required files
TIMEWARP="$PAIR_DIR/timewarp.json"
REF_MARKERS=""
NEW_MARKERS=""

# Search for markers in pair dir and parent dirs
for search_dir in "$PAIR_DIR" "$PAIR_DIR/.." "$PAIR_DIR/../.."; do
    if [ -z "$REF_MARKERS" ] && [ -f "$search_dir/ref_markers.csv" ]; then
        REF_MARKERS="$search_dir/ref_markers.csv"
    fi
    if [ -z "$REF_MARKERS" ] && [ -f "$search_dir/reference_markers.csv" ]; then
        REF_MARKERS="$search_dir/reference_markers.csv"
    fi
done

# Check for auto-generated new markers
if [ -f "$PAIR_DIR/new_markers.csv" ]; then
    NEW_MARKERS="$PAIR_DIR/new_markers.csv"
fi

# Validate
if [ ! -f "$TIMEWARP" ]; then
    echo "❌ timewarp.json not found in $PAIR_DIR"
    exit 1
fi

if [ -z "$REF_MARKERS" ]; then
    echo "⚠️  Warning: ref_markers.csv not found"
    echo "   Searched in: $PAIR_DIR, parent dirs"
    echo ""
    read -p "Enter path to ref_markers.csv (or press Enter to skip): " USER_MARKERS
    if [ -n "$USER_MARKERS" ] && [ -f "$USER_MARKERS" ]; then
        REF_MARKERS="$USER_MARKERS"
    else
        echo "Skipping overlay generation (no markers available)"
        exit 0
    fi
fi

echo "📁 Files:"
echo "-----------------------------------"
echo "Time-warp: $TIMEWARP"
echo "Ref markers: $REF_MARKERS"
if [ -n "$NEW_MARKERS" ]; then
    echo "New markers: $NEW_MARKERS"
fi
echo ""

# Extract quality metrics
if command -v jq &> /dev/null; then
    OK=$(jq -r '.ok // "N/A"' "$TIMEWARP")
    INLIER_FRAC=$(jq -r '.inlier_frac // "N/A"' "$TIMEWARP")
    P90=$(jq -r '.residuals.p90 // "N/A"' "$TIMEWARP")
    A=$(jq -r '.params.a // "N/A"' "$TIMEWARP")
    B=$(jq -r '.params.b // "N/A"' "$TIMEWARP")

    echo "📊 Quality Metrics:"
    echo "-----------------------------------"
    echo "Status: $OK"
    echo "Model: a=$A, b=$B"
    echo "Inlier Fraction: $INLIER_FRAC"
    echo "P90 Residual: ${P90}s"
    echo ""

    # Predict visual pattern
    echo "🔍 Expected Visual Pattern:"
    echo "-----------------------------------"

    if [ "$OK" = "false" ]; then
        echo "❌ Failed alignment"
        echo "   Expect: Random scatter, no clear diagonal pattern"
        echo "   Cause: Videos from different tracks or sessions"
    elif command -v bc &> /dev/null; then
        if (( $(echo "$P90 < 0.5" | bc -l) )); then
            echo "✅ Excellent alignment"
            echo "   Expect: Tight cluster along diagonal"
        elif (( $(echo "$P90 < 1.0" | bc -l) )); then
            echo "✓ Good alignment"
            echo "   Expect: Points mostly along diagonal with small scatter"
        else
            echo "⚠️  WEAK alignment"
            echo "   Expect: Large scatter around diagonal, possible gaps"
            echo "   Markers may be off by ±${P90}s"
        fi

        # Check for speed mismatch
        if (( $(echo "$A < 0.98 || $A > 1.02" | bc -l) )); then
            echo ""
            echo "   Note: Speed mismatch detected (a=$A)"
            echo "   Overlay will show steeper/shallower slope"
        fi

        # Check for offset
        if (( $(echo "$B < -1.0 || $B > 1.0" | bc -l) )); then
            echo ""
            echo "   Note: Time offset detected (b=${B}s)"
            echo "   Overlay will show parallel shift from diagonal"
        fi
    fi
else
    echo "ℹ️  Install 'jq' for quality metrics interpretation"
fi

echo ""
echo "🎨 Generating Overlay..."
echo "-----------------------------------"

OUTPUT_PNG="$PAIR_DIR/alignment_overlay.png"

# Build viewer command
VIEWER_CMD="mtbsync viewer --headless \
  --ref-markers \"$REF_MARKERS\" \
  --timewarp-json \"$TIMEWARP\" \
  --out-png \"$OUTPUT_PNG\""

if [ -n "$NEW_MARKERS" ]; then
    VIEWER_CMD="$VIEWER_CMD --new-markers \"$NEW_MARKERS\""
fi

# Execute
eval $VIEWER_CMD

if [ -f "$OUTPUT_PNG" ]; then
    echo "✓ Overlay saved to: $OUTPUT_PNG"
    echo ""

    # Provide viewing instructions
    echo "💡 Next Steps:"
    echo "-----------------------------------"
    echo "1. Open the overlay image:"
    echo "   $OUTPUT_PNG"
    echo ""
    echo "2. Look for:"
    echo "   • Points tightly along diagonal = good alignment"
    echo "   • Large scatter = weak alignment (matches P90=${P90}s)"
    echo "   • Gaps = scene cuts or missing sections"
    echo "   • Clusters = consistent offset regions"
    echo ""

    if command -v jq &> /dev/null && command -v bc &> /dev/null; then
        if [ "$OK" = "true" ] && (( $(echo "$P90 >= 1.0" | bc -l) )); then
            echo "3. Re-run with strict parameters:"
            echo "   mtbsync sync \\"
            echo "     --reference <ref.mp4> \\"
            echo "     --new <new.mp4> \\"
            echo "     --index <ref_index.npz> \\"
            echo "     --out ${PAIR_DIR}_strict \\"
            echo "     --warp-min-inlier-frac 0.5 \\"
            echo "     --warp-max-ppm 500 \\"
            echo "     --warp-inlier-thresh 0.05"
            echo ""
        fi
    fi

    echo "4. For more interpretation guidance:"
    echo "   See examples/interpret_overlay.md"
    echo ""

    # Offer to open the image (if display available)
    if command -v xdg-open &> /dev/null; then
        read -p "Open overlay now? (y/N) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            xdg-open "$OUTPUT_PNG" &
        fi
    elif command -v open &> /dev/null; then
        read -p "Open overlay now? (y/N) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            open "$OUTPUT_PNG" &
        fi
    fi
else
    echo "❌ Failed to generate overlay"
    echo "   Check that ref_markers.csv contains valid timestamps"
fi

echo ""
echo "==================================="

#!/usr/bin/env bash
# Dashboard cleanup and optimization helper
# Usage: ./dashboard_cleanup.sh <batch_output_directory>

set -euo pipefail

# Resolve repo root (script lives in examples/)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

if [ $# -eq 0 ]; then
    echo "Usage: $0 <batch_output_directory> [keep_count]"
    echo "Example: $0 ./batch_output 50"
    echo ""
    echo "This script helps manage telemetry files (perf.json) for cleaner dashboard views."
    exit 1
fi

BATCH_ROOT="$(cd "$1" 2>/dev/null && pwd)" || {
    echo "Error: Directory $1 not found"
    exit 1
}
KEEP_COUNT="${2:-100}"  # Default to keeping 100 newest files

echo "==================================="
echo "MTB Sync Dashboard Cleanup"
echo "==================================="
echo "Root: $BATCH_ROOT"
echo "Keep newest: $KEEP_COUNT files"
echo ""

# Count current perf.json files
CURRENT_COUNT=$(find "$BATCH_ROOT" -name "perf.json" -type f 2>/dev/null | wc -l)
echo "📊 Current State:"
echo "-----------------------------------"
echo "Total perf.json files: $CURRENT_COUNT"

if [ "$CURRENT_COUNT" -le "$KEEP_COUNT" ]; then
    echo "✓ No cleanup needed (current ≤ keep threshold)"
    echo ""
    echo "💡 To start the dashboard:"
    echo "mtbsync dashboard --root $BATCH_ROOT --port 8000"
    exit 0
fi

WILL_DELETE=$((CURRENT_COUNT - KEEP_COUNT))
echo "Will delete: $WILL_DELETE files"
echo ""

# Show dry-run first
echo "🔍 Dry-Run Preview:"
echo "-----------------------------------"
mtbsync prune-perf --root "$BATCH_ROOT" --keep "$KEEP_COUNT" --dry-run | head -10
PREVIEW_LINES=$(mtbsync prune-perf --root "$BATCH_ROOT" --keep "$KEEP_COUNT" --dry-run | wc -l)
if [ "$PREVIEW_LINES" -gt 10 ]; then
    echo "... and $((PREVIEW_LINES - 10)) more files"
fi
echo ""

# Confirm before proceeding
read -p "Proceed with deletion? (y/N) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 0
fi

# Execute pruning
echo ""
echo "🧹 Pruning..."
echo "-----------------------------------"
mtbsync prune-perf --root "$BATCH_ROOT" --keep "$KEEP_COUNT"

NEW_COUNT=$(find "$BATCH_ROOT" -name "perf.json" -type f 2>/dev/null | wc -l)
echo ""
echo "✓ Cleanup complete"
echo "Before: $CURRENT_COUNT files"
echo "After: $NEW_COUNT files"
echo "Deleted: $((CURRENT_COUNT - NEW_COUNT)) files"
echo ""

echo "💡 Next Steps:"
echo "-----------------------------------"
echo "1. Start the dashboard:"
echo "   mtbsync dashboard --root $BATCH_ROOT --port 8000"
echo ""
echo "2. Or enable write access for UI-based pruning:"
echo "   mtbsync dashboard --root $BATCH_ROOT --allow-write --port 8000"
echo ""
echo "3. Review alignment quality for weak pairs:"
echo "   ./diagnose_alignment.sh $BATCH_ROOT/<pair_directory>"
echo ""
echo "==================================="

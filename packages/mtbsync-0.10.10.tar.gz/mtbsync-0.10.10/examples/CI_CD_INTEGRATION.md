# CI/CD Integration Guide

This guide explains how to use MTB Sync helper scripts in automated workflows (GitHub Actions, GitLab CI, Jenkins, etc.).

## Exit Codes

All helper scripts follow standard Unix exit code conventions:

| Exit Code | Meaning | Action |
|-----------|---------|--------|
| `0` | Success | Continue pipeline |
| `1` | Error (missing files, invalid args) | Fail pipeline |
| `2` | Quality gates failed (weak alignment) | Warning/conditional continue |

## Script Behaviors

### `diagnose_alignment.sh`

```bash
./diagnose_alignment.sh ./batch_output/run_001
```

**Exit codes:**
- `0`: Diagnostic completed successfully
- `1`: Missing timewarp.json or invalid directory

**CI/CD usage:**
- Use for post-sync quality checks
- Parse output to extract P90, inlier_frac metrics
- Fail on exit code 1

### `visual_diagnostic.sh`

```bash
./visual_diagnostic.sh ./batch_output/run_001
```

**Exit codes:**
- `0`: Overlay generated successfully
- `1`: Missing timewarp.json or ref_markers.csv

**CI/CD usage:**
- Generate visual artifacts for review
- Upload PNG to artifacts storage
- Fail on exit code 1

### `resync_strict.sh` ⚠️ Special Handling

```bash
./resync_strict.sh ref.mp4 new.mp4 index.npz output ref_markers.csv
```

**Exit codes:**
- `0`: Sync completed AND passed strict quality gates
- `1`: Error (missing input files, sync command failed)
- `2`: Sync completed BUT failed strict quality gates (ok=false)

**CI/CD usage - Option A (Strict):**
```yaml
# Fail on any non-zero exit
- name: Run strict sync
  run: ./examples/resync_strict.sh ref.mp4 new.mp4 index.npz output markers.csv
```

**CI/CD usage - Option B (Warn on weak):**
```yaml
# Distinguish between errors and weak alignment
- name: Run strict sync
  id: sync
  run: |
    ./examples/resync_strict.sh ref.mp4 new.mp4 index.npz output markers.csv
    EXIT_CODE=$?
    if [ $EXIT_CODE -eq 1 ]; then
      echo "❌ Sync failed with error"
      exit 1
    elif [ $EXIT_CODE -eq 2 ]; then
      echo "⚠️ Weak alignment detected (ok=false)"
      exit 0  # Don't fail pipeline, just warn
    fi
```

### `dashboard_cleanup.sh`

```bash
./dashboard_cleanup.sh ./batch_output 50
```

**Exit codes:**
- `0`: Cleanup completed (or nothing to clean)
- `1`: Invalid directory

**CI/CD usage:**
- Run as post-batch cleanup step
- Safe to run multiple times (idempotent)

## Example GitHub Actions Workflow

```yaml
name: MTB Sync Quality Check

on:
  push:
    paths:
      - 'videos/**/*.mp4'
      - 'markers/**/*.csv'

jobs:
  alignment-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'

      - name: Install mtbsync
        run: |
          pip install mtbsync

      - name: Index reference video
        run: |
          mtbsync index \
            --reference videos/ref.mp4 \
            --fps 3.0 \
            --out cache/ref_index.npz

      - name: Run strict sync
        id: sync
        run: |
          ./examples/resync_strict.sh \
            videos/ref.mp4 \
            videos/new.mp4 \
            cache/ref_index.npz \
            strict_output \
            markers/ref_markers.csv
          EXIT_CODE=$?
          echo "exit_code=$EXIT_CODE" >> $GITHUB_OUTPUT

          # Exit 1 = error, fail immediately
          if [ $EXIT_CODE -eq 1 ]; then
            exit 1
          fi

          # Exit 2 = quality gates failed, continue but mark
          if [ $EXIT_CODE -eq 2 ]; then
            echo "⚠️ Alignment quality is weak"
          fi

      - name: Generate diagnostic overlay
        if: always()
        run: |
          ./examples/visual_diagnostic.sh strict_output

      - name: Upload artifacts
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: alignment-diagnostics
          path: |
            strict_output/timewarp.json
            strict_output/alignment_overlay.png
            strict_output/pairs.csv

      - name: Check quality and comment
        if: steps.sync.outputs.exit_code == '2'
        run: |
          # Post comment to PR about weak alignment
          gh pr comment ${{ github.event.number }} \
            --body "⚠️ Weak alignment detected. Review diagnostic overlay."
        env:
          GH_TOKEN: ${{ github.token }}
```

## Example GitLab CI

```yaml
stages:
  - index
  - sync
  - quality
  - cleanup

index_reference:
  stage: index
  script:
    - pip install mtbsync
    - mtbsync index --reference ref.mp4 --fps 3.0 --out ref_index.npz
  artifacts:
    paths:
      - ref_index.npz
    expire_in: 1 week

strict_sync:
  stage: sync
  script:
    - ./examples/resync_strict.sh ref.mp4 new.mp4 ref_index.npz output markers.csv || EXIT_CODE=$?
    - |
      if [ "$EXIT_CODE" = "1" ]; then
        echo "Sync failed with error"
        exit 1
      elif [ "$EXIT_CODE" = "2" ]; then
        echo "Weak alignment (expected for dissimilar runs)"
        exit 0
      fi
  artifacts:
    paths:
      - output/
    when: always

quality_check:
  stage: quality
  script:
    - ./examples/diagnose_alignment.sh output
    - ./examples/visual_diagnostic.sh output
  artifacts:
    paths:
      - output/alignment_overlay.png
    when: always

cleanup:
  stage: cleanup
  script:
    - ./examples/dashboard_cleanup.sh batch_output 100
  when: on_success
```

## Parsing Script Output

All scripts output structured text that can be parsed:

### Extract P90 from diagnose_alignment.sh

```bash
P90=$(./diagnose_alignment.sh output 2>&1 | grep "P90:" | awk '{print $2}' | sed 's/s$//')
if (( $(echo "$P90 > 1.0" | bc -l) )); then
  echo "⚠️ High P90 residual: ${P90}s"
  exit 2
fi
```

### Extract OK status from timewarp.json

```bash
OK=$(jq -r '.ok' output/timewarp.json)
if [ "$OK" = "false" ]; then
  echo "Alignment failed quality gates"
  exit 2
fi
```

## Best Practices

1. **Always upload artifacts** - Use `when: always` to upload diagnostics even on failure
2. **Distinguish error from weak** - Exit code 2 should warn, not fail
3. **Generate overlays** - Visual confirmation is valuable for debugging
4. **Clean up telemetry** - Run `dashboard_cleanup.sh` after batch jobs
5. **Use strict parameters** - Default gates are permissive; use strict for QA

## Troubleshooting CI/CD

### "realpath: command not found"
```bash
# Install coreutils in CI environment
apt-get update && apt-get install -y coreutils  # Debian/Ubuntu
yum install -y coreutils  # CentOS/RHEL
```

### "jq: command not found"
```bash
# Install jq for JSON parsing
apt-get update && apt-get install -y jq  # Debian/Ubuntu
yum install -y jq  # CentOS/RHEL
```

### Scripts fail with "Permission denied"
```bash
# Ensure scripts are executable in CI
chmod +x examples/*.sh
```

### Paths not portable
- All scripts now use `REPO_ROOT` resolution
- Safe to run from any directory
- Input paths resolved with `realpath`

## Exit Code Summary Table

| Script | Exit 0 | Exit 1 | Exit 2 |
|--------|--------|--------|--------|
| `diagnose_alignment.sh` | Success | Missing files | N/A |
| `visual_diagnostic.sh` | Overlay generated | Missing files | N/A |
| `resync_strict.sh` | Quality gates passed | Sync error | Quality gates failed |
| `dashboard_cleanup.sh` | Cleanup done | Invalid directory | N/A |

**Key takeaway:** Only `resync_strict.sh` uses exit code 2 to distinguish quality gate failure from errors.

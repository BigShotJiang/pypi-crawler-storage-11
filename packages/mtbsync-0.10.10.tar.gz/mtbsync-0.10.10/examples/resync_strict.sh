#!/usr/bin/env bash
# Re-sync a video pair with stricter quality parameters
# Usage: ./resync_strict.sh <reference.mp4> <new.mp4> <ref_index.npz> <output_dir>

set -euo pipefail

# Resolve repo root (script lives in examples/)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

if [ $# -lt 4 ]; then
    echo "Usage: $0 <reference.mp4> <new.mp4> <ref_index.npz> <output_dir> [ref_markers.csv]"
    echo ""
    echo "This script re-runs sync with STRICT quality gates to catch weak alignments."
    echo ""
    echo "Example:"
    echo "  $0 trail_ref.mp4 trail_new.mp4 cache/ref_index.npz strict_output ref_markers.csv"
    exit 1
fi

# Resolve absolute paths for inputs
REF_VIDEO="$(realpath "$1" 2>/dev/null)" || {
    echo "Error: Reference video not found: $1"
    exit 1
}
NEW_VIDEO="$(realpath "$2" 2>/dev/null)" || {
    echo "Error: New video not found: $2"
    exit 1
}
REF_INDEX="$(realpath "$3" 2>/dev/null)" || {
    echo "Error: Reference index not found: $3"
    exit 1
}
OUT_DIR="$4"
REF_MARKERS="${5:-}"

# Validate optional markers file
if [ -n "$REF_MARKERS" ]; then
    REF_MARKERS="$(realpath "$REF_MARKERS" 2>/dev/null)" || {
        echo "Error: Markers file not found: ${5}"
        exit 1
    }
fi

# Create output directory
mkdir -p "$OUT_DIR"
OUT_DIR="$(cd "$OUT_DIR" && pwd)"

echo "==================================="
echo "MTB Sync - Strict Quality Re-Run"
echo "==================================="
echo "Reference: $REF_VIDEO"
echo "New: $NEW_VIDEO"
echo "Index: $REF_INDEX"
echo "Output: $OUT_DIR"
if [ -n "$REF_MARKERS" ]; then
    echo "Markers: $REF_MARKERS"
fi
echo ""

echo "📋 Strict Parameters:"
echo "-----------------------------------"
echo "• warp-window-sec: 0.3 (tight gating)"
echo "• warp-inlier-thresh: 0.05 (50ms tolerance)"
echo "• warp-min-inlier-frac: 0.5 (50% support required)"
echo "• warp-ransac-iters: 1000 (thorough search)"
echo "• warp-max-ppm: 500 (0.05% drift limit)"
echo ""

read -p "Proceed with sync? (Y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Nn]$ ]]; then
    echo "Aborted."
    exit 0
fi

echo ""
echo "🚀 Running sync..."
echo "-----------------------------------"

# Build the command
SYNC_CMD="mtbsync sync \
  --reference \"$REF_VIDEO\" \
  --new \"$NEW_VIDEO\" \
  --index \"$REF_INDEX\" \
  --out \"$OUT_DIR\" \
  --warp-window-sec 0.3 \
  --warp-inlier-thresh 0.05 \
  --warp-min-inlier-frac 0.5 \
  --warp-ransac-iters 1000 \
  --warp-max-ppm 500"

# Add optional markers
if [ -n "$REF_MARKERS" ] && [ -f "$REF_MARKERS" ]; then
    SYNC_CMD="$SYNC_CMD --ref-markers \"$REF_MARKERS\""
fi

# Execute
eval $SYNC_CMD

echo ""
echo "✓ Sync complete"
echo ""

# Check if timewarp exists and analyze
if [ -f "$OUT_DIR/timewarp.json" ]; then
    echo "📊 Results:"
    echo "-----------------------------------"

    if command -v jq &> /dev/null; then
        OK=$(jq -r '.ok // "N/A"' "$OUT_DIR/timewarp.json")
        INLIER_FRAC=$(jq -r '.inlier_frac // "N/A"' "$OUT_DIR/timewarp.json")
        P90=$(jq -r '.residuals.p90 // "N/A"' "$OUT_DIR/timewarp.json")

        echo "Status: $OK"
        echo "Inlier Fraction: $INLIER_FRAC"
        echo "P90 Residual: ${P90}s"
        echo ""

        if [ "$OK" = "true" ]; then
            echo "✅ PASSED strict quality gates"
            echo "   This pair has reliable alignment for marker transfer."

            if [ -f "$OUT_DIR/new_markers.csv" ]; then
                MARKER_COUNT=$(wc -l < "$OUT_DIR/new_markers.csv")
                echo "   Transferred $((MARKER_COUNT - 1)) markers → $OUT_DIR/new_markers.csv"
            fi
        else
            echo "❌ FAILED strict quality gates"
            echo "   This pair does NOT have reliable alignment."
            echo ""
            echo "   Possible causes:"
            echo "   • Videos from different tracks/sessions"
            echo "   • Poor lighting or heavy motion blur"
            echo "   • Scene cuts or camera stops"
            echo "   • Significant speed differences"
        fi
    else
        cat "$OUT_DIR/timewarp.json"
    fi

    echo ""
    echo "💡 Next Steps:"
    echo "-----------------------------------"

    if command -v jq &> /dev/null && [ "$OK" = "false" ]; then
        echo "1. Inspect raw pairs for patterns:"
        echo "   head -50 \"$OUT_DIR/pairs_raw.csv\""
        echo ""
        echo "2. Try visual inspection (if markers available):"
        if [ -n "$REF_MARKERS" ] && [ -f "$REF_MARKERS" ]; then
            echo "   mtbsync viewer --headless \\"
            echo "     --ref-markers \"$REF_MARKERS\" \\"
            echo "     --timewarp-json \"$OUT_DIR/timewarp.json\" \\"
            echo "     --out-png \"$OUT_DIR/diagnostic_overlay.png\""
        else
            echo "   mtbsync viewer  # Launch GUI"
        fi
        echo ""
        echo "3. Check GPS data (if available):"
        echo "   # Re-run sync with GPS for time estimation"
    else
        echo "1. Visual inspection:"
        if [ -n "$REF_MARKERS" ] && [ -f "$REF_MARKERS" ]; then
            echo "   mtbsync viewer --headless \\"
            echo "     --ref-markers \"$REF_MARKERS\" \\"
            echo "     --timewarp-json \"$OUT_DIR/timewarp.json\" \\"
            echo "     --out-png \"$OUT_DIR/overlay.png\""
        fi
        echo ""
        echo "2. Export markers to NLE:"
        if [ -f "$OUT_DIR/new_markers.csv" ]; then
            echo "   mtbsync export-markers \"$OUT_DIR/new_markers.csv\" --preset fcpxml"
        fi
    fi
fi

echo ""
echo "==================================="

# Exit with appropriate code for CI/CD integration
if [ -f "$OUT_DIR/timewarp.json" ] && command -v jq &> /dev/null; then
    OK=$(jq -r '.ok // "true"' "$OUT_DIR/timewarp.json")
    if [ "$OK" = "false" ]; then
        exit 2  # Exit code 2 = quality gates failed (expected for weak pairs)
    fi
fi

exit 0  # Success or quality gates passed

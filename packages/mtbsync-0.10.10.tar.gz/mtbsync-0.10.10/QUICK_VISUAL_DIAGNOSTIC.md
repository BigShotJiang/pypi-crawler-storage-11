# 🎨 Quick Visual Diagnostic Guide

**For when you see weak alignment metrics but want to SEE what's happening.**

## Your Situation

```json
{
  "ok": true,
  "params": {"a": 1.0, "b": 0.0},
  "inlier_frac": 0.33,
  "residuals": {"p90": 2.0}
}
```

**Translation:** Identity warp with 33% support and ±2s scatter → **WEAK alignment**

---

## One-Command Visual Diagnostic

```bash
./examples/visual_diagnostic.sh <your_pair_directory>
```

**What you'll get:**
1. Automatic search for `ref_markers.csv` and `timewarp.json`
2. Generated `alignment_overlay.png` in pair directory
3. Predicted visual pattern based on your metrics
4. Interpretation guidance and next steps

**Expected visual pattern for P90=2s:**
```
t_new │    ╱
      │   ╱  • •
      │  ╱        ← Large scatter
      │ ╱ •    •
      │╱    •   •
      └────────── t_ref
```

Points will be **far from the diagonal**, confirming weak alignment.

---

## Step-by-Step Workflow

### Step 1: Generate Overlay

```bash
# Option A: Automated script (recommended)
./examples/visual_diagnostic.sh ./batch_output/run_problematic

# Option B: Manual command
mtbsync viewer --headless \
  --ref-markers ref_markers.csv \
  --timewarp-json ./batch_output/run_problematic/timewarp.json \
  --out-png diagnostic.png
```

### Step 2: Interpret the Visual

Open `alignment_overlay.png` and look for:

#### ✅ What Good Alignment Looks Like
- **Pattern:** Tight cluster along diagonal line
- **Scatter:** Points within ±0.5s of diagonal
- **Coverage:** Uniform distribution across time range
- **Gaps:** None or minimal

#### ⚠️ What Your Weak Alignment Looks Like
- **Pattern:** Large scatter around diagonal
- **Scatter:** Points ±2s or more from diagonal
- **Coverage:** Possible gaps or clusters
- **Gaps:** May indicate scene cuts or stops

#### ❌ What Failed Alignment Looks Like
- **Pattern:** Random scatter, no diagonal trend
- **Scatter:** Points everywhere
- **Coverage:** No temporal relationship
- **Gaps:** Everywhere

### Step 3: Correlate with Metrics

```bash
# Quick metrics check
cat timewarp.json | jq '{ok, inlier_frac, p90: .residuals.p90}'
```

**For your case:**
- `inlier_frac: 0.33` → Only 33% of pairs support the model
- `p90: 2.0` → 90% of residuals under 2s (but that's still HIGH)
- Visual scatter confirms: **markers could be off by ±2 seconds**

### Step 4: Re-Run with Strict Parameters

```bash
./examples/resync_strict.sh \
  ref.mp4 \
  new.mp4 \
  cache/ref_index.npz \
  strict_output \
  ref_markers.csv
```

**Expected result:** `ok: false` - confirming alignment is unreliable.

### Step 5: Visual Comparison

Generate new overlay with strict output:

```bash
mtbsync viewer --headless \
  --ref-markers ref_markers.csv \
  --timewarp-json strict_output/timewarp.json \
  --out-png strict_overlay.png
```

**Compare:**
- `diagnostic.png` (original, permissive gates)
- `strict_overlay.png` (stricter gates, likely failed)

If strict alignment failed (`ok: false`), the overlay will show why:
- Even worse scatter
- Insufficient inliers
- No stable temporal relationship

---

## Common Visual Patterns Explained

### Pattern: Parallel Shift
```
t_new │      ╱
      │     ╱•
      │    ╱ •   ← Shifted but parallel
      │   ╱  •
      │  ╱   •
      └────────── t_ref
```
**Meaning:** Videos started at different times (consistent offset)
**Metrics:** a≈1, b≠0, low residuals
**Action:** ✓ Good alignment, offset is expected

---

### Pattern: Steep/Shallow Slope
```
t_new │    ╱╱
      │   ╱╱ •  ← Steeper than diagonal
      │  ╱╱  •
      │ ╱╱   •
      │╱╱    •
      └────────── t_ref
```
**Meaning:** Speed mismatch (one video faster/slower)
**Metrics:** a≠1 (e.g., a=1.05), high ppm
**Action:** Check playback speeds, re-encode if necessary

---

### Pattern: Gap in Middle
```
t_new │    ╱
      │   ╱ • •
      │  ╱  [gap]  ← Missing data
      │ ╱       • •
      │╱        •
      └────────── t_ref
```
**Meaning:** Scene cut, camera stop, or missing section
**Metrics:** Normal elsewhere, gap in specific time range
**Action:** Check raw `pairs.csv` for temporal gaps

---

### Pattern: Two Clusters
```
t_new │    ╱
      │   ╱ ••   ← Cluster 1
      │  ╱    •••  ← Cluster 2
      │ ╱
      │╱
      └────────── t_ref
```
**Meaning:** Bimodal alignment (e.g., two laps of same section)
**Metrics:** Low inlier_frac, high residuals
**Action:** Video may contain multiple passes, split and re-process

---

### Pattern: YOUR CASE - Random Scatter
```
t_new │    ╱
      │   ╱  • •
      │  ╱
      │ ╱ •    •  ← Large scatter, no pattern
      │╱    •   •
      └────────── t_ref
```
**Meaning:** Weak or failed alignment
**Metrics:** inlier_frac < 0.4, P90 > 1s
**Action:** Re-run strict → expect `ok: false` → investigate cause

---

## Diagnostic Decision Tree

```
Generate overlay
     │
     ├─→ Tight cluster along diagonal
     │   └─→ ✅ Excellent alignment (use confidently)
     │
     ├─→ Moderate scatter (<1s from diagonal)
     │   └─→ ✓ Good alignment (verify critical markers)
     │
     ├─→ Large scatter (>1s from diagonal) ← YOU ARE HERE
     │   └─→ ⚠️ Weak alignment
     │       ├─→ Re-run with strict parameters
     │       ├─→ Expect: ok=false
     │       └─→ Action: Investigate cause
     │
     └─→ Random scatter (no diagonal trend)
         └─→ ❌ Failed alignment
             ├─→ Different tracks/sessions
             ├─→ No visual overlap
             └─→ Action: Reject pair or add GPS
```

---

## Quick Commands Reference

### Generate Overlay (3 ways)

```bash
# 1. Automated with interpretation
./examples/visual_diagnostic.sh ./batch_output/run_001

# 2. Manual headless
mtbsync viewer --headless \
  --ref-markers ref_markers.csv \
  --timewarp-json timewarp.json \
  --out-png overlay.png

# 3. Interactive GUI (with file picker)
mtbsync viewer
```

### Batch Generate for All Pairs

```bash
for pair in batch_output/*/; do
  echo "Processing $pair..."
  ./examples/visual_diagnostic.sh "$pair"
done
```

### Compare Before/After Strict Parameters

```bash
# Original (permissive)
mtbsync viewer --headless \
  --ref-markers ref_markers.csv \
  --timewarp-json original/timewarp.json \
  --out-png original_overlay.png

# Strict
mtbsync viewer --headless \
  --ref-markers ref_markers.csv \
  --timewarp-json strict/timewarp.json \
  --out-png strict_overlay.png

# Open both for comparison
xdg-open original_overlay.png &
xdg-open strict_overlay.png &
```

---

## What to Share for Help

If you need specific parameter recommendations, share:

1. **Screenshot of your overlay PNG**
2. **Your timewarp.json contents:**
   ```bash
   cat timewarp.json | jq
   ```
3. **First 50 rows of pairs.csv:**
   ```bash
   head -50 pairs.csv
   ```
4. **Video characteristics:**
   - Duration: `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 video.mp4`
   - FPS used for extraction (e.g., 3.0)
   - Known issues: scene cuts, lighting, weather

---

## Summary

**Your specific issue:** P90=2s with 33% inliers

**Quick diagnosis:**
```bash
./examples/visual_diagnostic.sh <your_pair_dir>
```

**Expected visual:** Large scatter (confirms weak alignment)

**Recommended action:**
```bash
./examples/resync_strict.sh ref.mp4 new.mp4 index.npz strict_output markers.csv
```

**Expected result:** `ok: false` (proper rejection of unreliable pair)

**Interpretation:** Videos don't have reliable visual alignment - investigate cause or try GPS-based timing.

---

📚 **More details:** See `examples/interpret_overlay.md` for comprehensive pattern guide.

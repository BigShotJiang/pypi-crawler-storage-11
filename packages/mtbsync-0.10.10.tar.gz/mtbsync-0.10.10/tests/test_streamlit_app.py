"""Tests for Streamlit telemetry dashboard."""

import json
from pathlib import Path

import pytest

from mtbsync.app_streamlit import _load_perf_history


@pytest.fixture
def temp_telemetry_dir(tmp_path):
    """Create temporary directory with perf.json files."""
    # Create three perf.json files with varying metrics
    base_dir = tmp_path / "batch_out"
    base_dir.mkdir()

    # File 1: Full metrics
    run1_dir = base_dir / "run1"
    run1_dir.mkdir()
    perf1 = {
        "ok": True,
        "cmd": "sync",
        "fps": 15.5,
        "cpu_pct": 45.2,
        "gpu_util": 30.0,
        "gpu_mem_mb": 1024.0,
        "rss_mb": 512.0,
        "timings": {
            "total_sec": 10.5,
            "retrieval_sec": 8.0,
            "frames_processed": 120,
        },
    }
    (run1_dir / "perf.json").write_text(json.dumps(perf1), encoding="utf-8")

    # File 2: Partial metrics (no GPU)
    run2_dir = base_dir / "run2"
    run2_dir.mkdir()
    perf2 = {
        "ok": True,
        "cmd": "batch",
        "cpu_pct": 60.0,
        "rss_mb": 768.0,
        "timings": {
            "total_sec": 5.0,
            "retrieval_sec": 4.0,
            "frames_processed": 60,
        },
    }
    (run2_dir / "perf.json").write_text(json.dumps(perf2), encoding="utf-8")

    # File 3: FPS computed from frames_processed / retrieval_sec
    run3_dir = base_dir / "run3"
    run3_dir.mkdir()
    perf3 = {
        "ok": True,
        "cmd": "sync",
        "cpu_pct": 55.0,
        "gpu_util": 25.0,
        "gpu_mem_mb": 800.0,
        "timings": {
            "total_sec": 12.0,
            "retrieval_sec": 10.0,
            "frames_processed": 100,
        },
        "run": {
            "wall_sec": 12.0,
            "rss_bytes": 600000000,  # 600 MB
        },
    }
    (run3_dir / "perf.json").write_text(json.dumps(perf3), encoding="utf-8")

    return base_dir


def test_load_perf_history_basic(temp_telemetry_dir):
    """Test loading perf history from directory."""
    items = _load_perf_history(temp_telemetry_dir, limit=500)

    # Should have 3 items
    assert len(items) == 3

    # Check that all items have required fields
    for item in items:
        assert "_path" in item
        assert "_ts" in item
        assert "cmd" in item


def test_load_perf_history_fps_direct(temp_telemetry_dir):
    """Test FPS loaded directly from perf.json."""
    items = _load_perf_history(temp_telemetry_dir, limit=500)

    # Find the item with direct FPS
    direct_fps_item = next((x for x in items if x.get("fps") == 15.5), None)
    assert direct_fps_item is not None
    assert direct_fps_item["fps"] == 15.5


def test_load_perf_history_fps_computed(temp_telemetry_dir):
    """Test FPS computed from frames_processed / retrieval_sec."""
    items = _load_perf_history(temp_telemetry_dir, limit=500)

    # Find the item with computed FPS (run2: 60 frames / 4 sec = 15.0)
    computed_items = [x for x in items if x.get("cmd") == "batch"]
    assert len(computed_items) >= 1
    computed_item = computed_items[0]
    expected_fps = 60 / 4.0  # frames_processed / retrieval_sec
    assert computed_item["fps"] == expected_fps


def test_load_perf_history_rss_from_bytes(temp_telemetry_dir):
    """Test RSS MB converted from rss_bytes."""
    items = _load_perf_history(temp_telemetry_dir, limit=500)

    # Find the item with rss_bytes (run3)
    rss_bytes_items = [x for x in items if "run3" in x.get("_path", "")]
    assert len(rss_bytes_items) >= 1
    item = rss_bytes_items[0]
    expected_rss_mb = 600000000 / 1e6  # 600 MB
    assert item["rss_mb"] == expected_rss_mb


def test_load_perf_history_empty_dir(tmp_path):
    """Test loading from empty directory."""
    empty_dir = tmp_path / "empty"
    empty_dir.mkdir()

    items = _load_perf_history(empty_dir, limit=500)
    assert len(items) == 0


def test_load_perf_history_limit(temp_telemetry_dir):
    """Test limit parameter."""
    items = _load_perf_history(temp_telemetry_dir, limit=2)

    # Should have at most 2 items
    assert len(items) <= 2


def test_load_perf_history_oldest_to_newest(temp_telemetry_dir):
    """Test that items are returned in oldest→newest order."""
    items = _load_perf_history(temp_telemetry_dir, limit=500)

    # Extract timestamps
    timestamps = [item["_ts"] for item in items]

    # Should be sorted oldest→newest
    assert timestamps == sorted(timestamps)


def test_streamlit_import_optional():
    """Test that streamlit import is optional."""
    # This test verifies that importing the module doesn't require streamlit
    # The module should be importable even without streamlit installed
    try:
        import mtbsync.app_streamlit  # noqa: F401
        # If import succeeds, module is properly structured
        assert True
    except ImportError as e:
        # Should NOT fail on streamlit import at module level
        if "streamlit" in str(e):
            pytest.fail("Module should not import streamlit at module level")
        # Other import errors are acceptable
        pass


def test_load_perf_history_invalid_json(tmp_path):
    """Test handling of invalid JSON files."""
    bad_dir = tmp_path / "bad"
    bad_dir.mkdir()

    # Create invalid JSON file
    (bad_dir / "perf.json").write_text("{invalid json}", encoding="utf-8")

    # Should gracefully skip invalid files
    items = _load_perf_history(bad_dir, limit=500)
    assert len(items) == 0


def test_load_perf_history_missing_fields(tmp_path):
    """Test handling of perf.json with missing fields."""
    sparse_dir = tmp_path / "sparse"
    sparse_dir.mkdir()

    # Create minimal perf.json
    minimal = {"ok": True}
    (sparse_dir / "perf.json").write_text(json.dumps(minimal), encoding="utf-8")

    items = _load_perf_history(sparse_dir, limit=500)
    assert len(items) == 1

    item = items[0]
    # Should have base fields
    assert "_path" in item
    assert "_ts" in item
    # Optional fields should be None
    assert item.get("fps") is None
    assert item.get("cpu_pct") is None
    assert item.get("gpu_util") is None

"""Tests for telemetry retention (perf.json pruning)."""

import os
import time
from pathlib import Path

from mtbsync.dashboard import _prune_perf_files, _list_perf_files


def _touch_perf(d: Path, age_sec: float, idx: int):
    """Create a perf.json file with specified age in seconds."""
    f = d / f"job_{idx}" / "perf.json"
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text('{"ok":true}', encoding="utf-8")
    # Set mtime to simulate age
    t = time.time() - age_sec
    os.utime(f, (t, t))
    return f


def test_prune_keeps_newest(tmp_path: Path):
    """Test that pruning keeps the newest N files by mtime."""
    # Create 5 perf files with staggered mtimes (0s is newest)
    ages = [0, 10, 20, 30, 40]
    for i, a in enumerate(ages):
        _touch_perf(tmp_path, a, i)

    files_before = _list_perf_files(tmp_path)
    assert len(files_before) == 5

    result = _prune_perf_files(tmp_path, keep_newest=2)
    assert result["total"] == 5
    assert result["deleted"] == 3

    files_after = _list_perf_files(tmp_path)
    assert len(files_after) == 2

    # The two newest should remain: idx 0 and 1 by our ages (0s,10s)
    kept_names = {p.parent.name for p in files_after}
    assert "job_0" in kept_names and "job_1" in kept_names


def test_prune_no_delete_when_under_threshold(tmp_path: Path):
    """Test that pruning doesn't delete when total <= keep."""
    # Create 3 perf files
    for i in range(3):
        _touch_perf(tmp_path, i * 10, i)

    result = _prune_perf_files(tmp_path, keep_newest=10)
    assert result["total"] == 3
    assert result["deleted"] == 0
    assert result["kept"] == 3


def test_prune_safety_only_deletes_perf_json(tmp_path: Path):
    """Test that pruning only deletes files named perf.json."""
    # Create some perf.json files
    _touch_perf(tmp_path, 100, 0)
    _touch_perf(tmp_path, 200, 1)

    # Create a non-perf.json file that should NOT be deleted
    other_file = tmp_path / "job_2" / "other.json"
    other_file.parent.mkdir(parents=True, exist_ok=True)
    other_file.write_text('{"other":true}', encoding="utf-8")

    files_before = list(tmp_path.glob("**/*.json"))
    assert len(files_before) == 3  # 2 perf.json + 1 other.json

    # Prune keeping only 0 files
    result = _prune_perf_files(tmp_path, keep_newest=0)
    assert result["deleted"] == 2  # Only perf.json files deleted

    # other.json should still exist
    assert other_file.exists()


def test_list_perf_files_sorted_by_mtime(tmp_path: Path):
    """Test that _list_perf_files returns files sorted newest first."""
    # Create files with specific ages
    ages = [100, 50, 200, 25]  # Not in order
    for i, a in enumerate(ages):
        _touch_perf(tmp_path, a, i)

    files = _list_perf_files(tmp_path)
    assert len(files) == 4

    # Should be sorted newest first (smallest age first)
    # Expected order: job_3 (25s), job_1 (50s), job_0 (100s), job_2 (200s)
    names = [f.parent.name for f in files]
    assert names == ["job_3", "job_1", "job_0", "job_2"]


def test_prune_empty_directory(tmp_path: Path):
    """Test pruning in a directory with no perf.json files."""
    result = _prune_perf_files(tmp_path, keep_newest=10)
    assert result["total"] == 0
    assert result["deleted"] == 0
    assert result["kept"] == 0

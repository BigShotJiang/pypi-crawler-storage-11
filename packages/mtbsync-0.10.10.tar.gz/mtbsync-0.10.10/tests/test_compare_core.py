"""Tests for compare_core data loading and delta computation."""

import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from mtbsync import compare_core


def test_load_markers_csv_success(tmp_path):
    """Test loading valid markers CSV."""
    csv_path = tmp_path / "markers.csv"
    csv_path.write_text("marker_id,t_ref,t_new,label\nM1,10.5,11.2,Jump\nM2,20.3,21.1,Drop\n")

    df = compare_core.load_markers_csv(csv_path)

    assert len(df) == 2
    assert "marker_id" in df.columns
    assert "t_ref" in df.columns
    assert "t_new" in df.columns
    assert "label" in df.columns
    assert df["marker_id"].tolist() == ["M1", "M2"]
    assert df["t_ref"].tolist() == [10.5, 20.3]


def test_load_markers_csv_preserves_extra_columns(tmp_path):
    """Test that extra columns are preserved."""
    csv_path = tmp_path / "markers.csv"
    csv_path.write_text(
        "marker_id,t_ref,note,confidence\nM1,10.5,Good sync,0.95\nM2,20.3,Check alignment,0.85\n"
    )

    df = compare_core.load_markers_csv(csv_path)

    assert "note" in df.columns
    assert "confidence" in df.columns
    assert df["note"].tolist() == ["Good sync", "Check alignment"]


def test_load_markers_csv_missing_required_columns(tmp_path):
    """Test error when required columns missing."""
    csv_path = tmp_path / "bad_markers.csv"
    csv_path.write_text("id,time\nM1,10.5\n")

    with pytest.raises(ValueError, match="must contain 'marker_id' column"):
        compare_core.load_markers_csv(csv_path)


def test_load_markers_csv_with_t_new_only(tmp_path):
    """Test that CSV with only t_new (no t_ref) is valid."""
    csv_path = tmp_path / "new_markers.csv"
    csv_path.write_text("marker_id,t_new\nM1,11.0\nM2,21.0\n")

    df = compare_core.load_markers_csv(csv_path)

    assert len(df) == 2
    assert "marker_id" in df.columns
    assert "t_new" in df.columns
    assert "t_ref" not in df.columns


def test_load_markers_csv_missing_time_column(tmp_path):
    """Test error when neither t_ref nor t_new present."""
    csv_path = tmp_path / "bad_markers.csv"
    csv_path.write_text("marker_id,label\nM1,Jump\n")

    with pytest.raises(ValueError, match="must contain either 't_ref' or 't_new'"):
        compare_core.load_markers_csv(csv_path)


def test_load_markers_csv_file_not_found(tmp_path):
    """Test error when file doesn't exist."""
    csv_path = tmp_path / "nonexistent.csv"

    with pytest.raises(FileNotFoundError):
        compare_core.load_markers_csv(csv_path)


def test_load_timewarp_json_success(tmp_path):
    """Test loading valid timewarp JSON."""
    json_path = tmp_path / "timewarp.json"
    data = {
        "warp": {"a": 0.998, "b": 1.234},
        "ok": True,
        "ppm": 200,
        "inlier_frac": 0.85,
    }
    json_path.write_text(json.dumps(data))

    result = compare_core.load_timewarp_json(json_path)

    assert result is not None
    assert result["warp"]["a"] == 0.998
    assert result["warp"]["b"] == 1.234
    assert result["ok"] is True


def test_load_timewarp_json_file_not_found(tmp_path):
    """Test that missing file returns None."""
    json_path = tmp_path / "nonexistent.json"
    result = compare_core.load_timewarp_json(json_path)
    assert result is None


def test_load_timewarp_json_invalid_json(tmp_path):
    """Test error on invalid JSON."""
    json_path = tmp_path / "bad.json"
    json_path.write_text("{invalid json")

    with pytest.raises(ValueError, match="Invalid JSON"):
        compare_core.load_timewarp_json(json_path)


def test_load_timewarp_json_missing_fields(tmp_path):
    """Test error when required fields missing."""
    json_path = tmp_path / "incomplete.json"
    json_path.write_text('{"ok": true}')

    with pytest.raises(ValueError, match="must contain 'warp' with 'a' and 'b'"):
        compare_core.load_timewarp_json(json_path)


def test_predict_new_times_from_warp():
    """Test affine time prediction from warp parameters."""
    df_ref = pd.DataFrame({"marker_id": ["M1", "M2", "M3"], "t_ref": [10.0, 20.0, 30.0]})

    warp_data = {"warp": {"a": 1.0, "b": 2.0}, "ok": True}

    t_new_est = compare_core.predict_new_times_from_warp(df_ref, warp_data)

    # Formula: t_new = (t_ref - b) / a = (t_ref - 2.0) / 1.0
    expected = [8.0, 18.0, 28.0]
    np.testing.assert_array_almost_equal(t_new_est, expected)


def test_predict_new_times_from_warp_scaling():
    """Test prediction with scaling factor."""
    df_ref = pd.DataFrame({"marker_id": ["M1", "M2"], "t_ref": [10.0, 20.0]})

    # a=2.0 means new video runs at 2x speed
    warp_data = {"warp": {"a": 2.0, "b": 0.0}, "ok": True}

    t_new_est = compare_core.predict_new_times_from_warp(df_ref, warp_data)

    # t_new = (t_ref - 0) / 2.0
    expected = [5.0, 10.0]
    np.testing.assert_array_almost_equal(t_new_est, expected)


def test_predict_new_times_from_warp_zero_a():
    """Test error when 'a' is too close to zero."""
    df_ref = pd.DataFrame({"marker_id": ["M1"], "t_ref": [10.0]})
    warp_data = {"warp": {"a": 0.0, "b": 1.0}, "ok": True}

    with pytest.raises(ValueError, match="too close to zero"):
        compare_core.predict_new_times_from_warp(df_ref, warp_data)


def test_predict_new_times_from_warp_missing_fields():
    """Test error when warp missing a or b."""
    df_ref = pd.DataFrame({"marker_id": ["M1"], "t_ref": [10.0]})
    warp_data = {"warp": {"a": 1.0}}  # Missing 'b'

    with pytest.raises(ValueError, match="must contain 'a' and 'b'"):
        compare_core.predict_new_times_from_warp(df_ref, warp_data)


def test_compute_deltas_measured_only():
    """Test delta computation with measured times only."""
    df_ref = pd.DataFrame({"marker_id": ["M1", "M2"], "t_ref": [10.0, 20.0]})
    df_new = pd.DataFrame({"marker_id": ["M1", "M2"], "t_new": [11.0, 21.5]})

    result = compare_core.compute_deltas(df_ref, df_new_opt=df_new)

    assert "delta_sec" in result.columns
    expected_deltas = [1.0, 1.5]
    np.testing.assert_array_almost_equal(result["delta_sec"], expected_deltas)


def test_compute_deltas_predicted_only():
    """Test delta computation with predicted times only."""
    df_ref = pd.DataFrame({"marker_id": ["M1", "M2"], "t_ref": [10.0, 20.0]})
    t_new_est = pd.Series([9.5, 19.8])

    result = compare_core.compute_deltas(df_ref, t_new_est_opt=t_new_est)

    assert "delta_sec" in result.columns
    expected_deltas = [-0.5, -0.2]
    np.testing.assert_array_almost_equal(result["delta_sec"], expected_deltas)


def test_compute_deltas_prefers_measured():
    """Test that measured times are preferred over predicted."""
    df_ref = pd.DataFrame({"marker_id": ["M1", "M2", "M3"], "t_ref": [10.0, 20.0, 30.0]})

    # Only M1 and M2 have measured times
    df_new = pd.DataFrame({"marker_id": ["M1", "M2"], "t_new": [11.0, 21.0]})

    # All have predicted times
    t_new_est = pd.Series([9.5, 19.5, 29.5])

    result = compare_core.compute_deltas(df_ref, df_new_opt=df_new, t_new_est_opt=t_new_est)

    # M1, M2 should use measured (delta = 1.0, 1.0)
    # M3 should use predicted (delta = -0.5)
    assert result.loc[0, "delta_sec"] == 1.0  # M1 measured
    assert result.loc[1, "delta_sec"] == 1.0  # M2 measured
    assert result.loc[2, "delta_sec"] == -0.5  # M3 predicted


def test_compute_deltas_no_times():
    """Test when neither measured nor predicted times available."""
    df_ref = pd.DataFrame({"marker_id": ["M1", "M2"], "t_ref": [10.0, 20.0]})

    result = compare_core.compute_deltas(df_ref)

    assert "delta_sec" in result.columns
    assert pd.isna(result["delta_sec"].iloc[0])
    assert pd.isna(result["delta_sec"].iloc[1])


def test_summarise_quality_basic():
    """Test quality summary computation."""
    df = pd.DataFrame(
        {"marker_id": ["M1", "M2", "M3", "M4"], "delta_sec": [0.5, -0.3, 1.2, -0.8]}
    )

    quality = compare_core.summarise_quality(df)

    assert quality["count"] == 4
    assert quality["mae"] == pytest.approx(0.7)  # (0.5 + 0.3 + 1.2 + 0.8) / 4
    assert quality["median"] == pytest.approx(0.1)  # median of [0.5, -0.3, 1.2, -0.8]


def test_summarise_quality_percentiles():
    """Test P90 calculation."""
    deltas = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
    df = pd.DataFrame({"delta_sec": deltas})

    quality = compare_core.summarise_quality(df)

    assert quality["count"] == 10
    assert quality["p90"] == pytest.approx(0.9, abs=0.05)


def test_summarise_quality_no_deltas():
    """Test summary with no valid deltas."""
    df = pd.DataFrame({"marker_id": ["M1", "M2"]})

    quality = compare_core.summarise_quality(df)

    assert quality["count"] == 0
    assert np.isnan(quality["mae"])
    assert np.isnan(quality["p90"])
    assert np.isnan(quality["median"])


def test_summarise_quality_with_nans():
    """Test summary ignores NaN values."""
    df = pd.DataFrame({"delta_sec": [0.5, np.nan, 1.0, np.nan, 0.3]})

    quality = compare_core.summarise_quality(df)

    assert quality["count"] == 3
    assert quality["mae"] == pytest.approx(0.6)  # (0.5 + 1.0 + 0.3) / 3


def test_end_to_end_workflow(tmp_path):
    """Test complete workflow: load markers, warp, compute deltas, summarize."""
    # Create reference markers CSV
    ref_csv = tmp_path / "ref_markers.csv"
    ref_csv.write_text("marker_id,t_ref\nM1,10.0\nM2,20.0\nM3,30.0\n")

    # Create new markers CSV
    new_csv = tmp_path / "new_markers.csv"
    new_csv.write_text("marker_id,t_new\nM1,11.0\nM2,21.0\n")  # M3 missing

    # Create timewarp JSON
    warp_json = tmp_path / "timewarp.json"
    warp_data = {"warp": {"a": 1.0, "b": 1.0}, "ok": True}
    warp_json.write_text(json.dumps(warp_data))

    # Load data
    df_ref = compare_core.load_markers_csv(ref_csv)
    df_new = compare_core.load_markers_csv(new_csv)
    warp = compare_core.load_timewarp_json(warp_json)

    # Predict times
    t_new_est = compare_core.predict_new_times_from_warp(df_ref, warp)

    # Compute deltas
    df_deltas = compare_core.compute_deltas(df_ref, df_new, t_new_est)

    # Summarize
    quality = compare_core.summarise_quality(df_deltas)

    # Verify results
    assert len(df_deltas) == 3
    assert quality["count"] == 3

    # M1, M2 use measured times (delta = 1.0 for both)
    # M3 uses predicted time: t_new_est = (30.0 - 1.0) / 1.0 = 29.0, delta = -1.0
    expected_deltas = [1.0, 1.0, -1.0]
    np.testing.assert_array_almost_equal(df_deltas["delta_sec"], expected_deltas)

import json
import socket
import threading
import time
from pathlib import Path
from urllib.request import urlopen

from mtbsync.dashboard import _perf_history, run_dashboard


def test_perf_history_basic(tmp_path: Path):
    """Test _perf_history returns data in oldest→newest order with proper field extraction."""
    # Create 3 perf.json files with different mtimes and varied fields
    perf1 = {
        "cmd": "sync",
        "fps": 3.5,
        "cpu_pct": 45.2,
        "gpu_util": 60.0,
        "gpu_mem_mb": 1200.5,
        "rss_mb": 512.0,
    }
    perf2 = {
        "cmd": "sync",
        "cpu_pct": 50.1,
        "gpu_util": 65.5,
        "rss_mb": 600.0,
        # Missing fps, gpu_mem_mb (should be None in result)
    }
    perf3 = {
        "cmd": "sync",
        "timings": {
            "frames_processed": 100,
            "retrieval_sec": 20.0,  # FPS fallback: 100/20 = 5.0
        },
        "cpu_pct": 55.0,
        "gpu_util": None,
        "gpu_mem_mb": 1400.0,
        "rss_mb": 650.0,
    }

    # Write files with artificial mtime spacing
    p1 = tmp_path / "run1" / "perf.json"
    p2 = tmp_path / "run2" / "perf.json"
    p3 = tmp_path / "run3" / "perf.json"

    p1.parent.mkdir()
    p1.write_text(json.dumps(perf1), encoding="utf-8")
    time.sleep(0.05)  # Ensure different mtimes

    p2.parent.mkdir()
    p2.write_text(json.dumps(perf2), encoding="utf-8")
    time.sleep(0.05)

    p3.parent.mkdir()
    p3.write_text(json.dumps(perf3), encoding="utf-8")

    # Call _perf_history directly
    result = _perf_history(tmp_path, limit=10)

    assert result["count"] == 3
    assert len(result["items"]) == 3

    # Verify oldest→newest order (should match creation order: run1, run2, run3)
    items = result["items"]
    assert "run1/perf.json" in items[0]["_path"]
    assert "run2/perf.json" in items[1]["_path"]
    assert "run3/perf.json" in items[2]["_path"]

    # Verify field extraction
    assert items[0]["fps"] == 3.5
    assert items[0]["cpu_pct"] == 45.2
    assert items[0]["gpu_util"] == 60.0
    assert items[0]["gpu_mem_mb"] == 1200.5
    assert items[0]["rss_mb"] == 512.0

    # Missing fields should be None
    assert items[1]["fps"] is None
    assert items[1]["cpu_pct"] == 50.1
    assert items[1]["gpu_mem_mb"] is None

    # FPS fallback should be computed
    assert items[2]["fps"] == 5.0
    assert items[2]["cpu_pct"] == 55.0
    assert items[2]["gpu_util"] is None
    assert items[2]["gpu_mem_mb"] == 1400.0


def test_perf_history_limit(tmp_path: Path):
    """Test _perf_history respects limit parameter."""
    # Create 5 files
    for i in range(5):
        p = tmp_path / f"run{i}" / "perf.json"
        p.parent.mkdir()
        p.write_text(json.dumps({"cmd": "sync", "fps": float(i)}), encoding="utf-8")
        time.sleep(0.01)

    # Request only 3 (should get 3 newest, oldest→newest)
    result = _perf_history(tmp_path, limit=3)
    assert result["count"] == 3
    assert len(result["items"]) == 3

    # Should be run2, run3, run4 (3 newest, ordered oldest→newest)
    assert "run2/perf.json" in result["items"][0]["_path"]
    assert "run3/perf.json" in result["items"][1]["_path"]
    assert "run4/perf.json" in result["items"][2]["_path"]


def test_perf_history_rss_fallback(tmp_path: Path):
    """Test _perf_history computes rss_mb from rss_bytes when needed."""
    perf = {
        "cmd": "sync",
        "run": {"rss_bytes": 1048576},  # 1 MB
        # No rss_mb field directly
    }
    p = tmp_path / "perf.json"
    p.write_text(json.dumps(perf), encoding="utf-8")

    result = _perf_history(tmp_path, limit=10)
    assert result["count"] == 1
    assert result["items"][0]["rss_mb"] == 1.048576


def test_perf_history_custom_fields(tmp_path: Path):
    """Test _perf_history respects custom field list."""
    perf = {"cmd": "sync", "fps": 3.0, "cpu_pct": 50.0, "gpu_util": 60.0}
    p = tmp_path / "perf.json"
    p.write_text(json.dumps(perf), encoding="utf-8")

    # Request only fps and cpu_pct
    result = _perf_history(tmp_path, limit=10, fields=["fps", "cpu_pct"])
    assert result["count"] == 1
    item = result["items"][0]

    assert "fps" in item
    assert "cpu_pct" in item
    assert "gpu_util" not in item
    assert "gpu_mem_mb" not in item


def test_perf_history_endpoint(tmp_path: Path):
    """Test /api/perf/history endpoint returns time-series data."""
    # Create sample perf files
    for i in range(3):
        p = tmp_path / f"run{i}" / "perf.json"
        p.parent.mkdir()
        p.write_text(json.dumps({"cmd": "sync", "fps": float(i + 1), "cpu_pct": 50.0 + i}), encoding="utf-8")
        time.sleep(0.01)

    # Start dashboard
    port = _free_port()
    thr = threading.Thread(
        target=run_dashboard,
        kwargs={"root": tmp_path, "host": "127.0.0.1", "port": port, "open_browser": False, "allow_write": False},
        daemon=True,
    )
    thr.start()
    time.sleep(0.6)

    base = f"http://127.0.0.1:{port}"

    # Test /api/perf/history
    with urlopen(base + "/api/perf/history") as r:
        history = json.loads(r.read().decode("utf-8"))

    assert "items" in history
    assert "count" in history
    assert history["count"] == 3
    assert len(history["items"]) == 3

    # Verify oldest→newest order
    assert history["items"][0]["fps"] == 1.0
    assert history["items"][1]["fps"] == 2.0
    assert history["items"][2]["fps"] == 3.0

    # Test with limit parameter
    with urlopen(base + "/api/perf/history?limit=2") as r:
        history_limited = json.loads(r.read().decode("utf-8"))

    assert history_limited["count"] == 2
    # Should get 2 newest (run1, run2), oldest→newest
    assert history_limited["items"][0]["fps"] == 2.0
    assert history_limited["items"][1]["fps"] == 3.0

    # Test with fields parameter
    with urlopen(base + "/api/perf/history?fields=fps,cpu_pct") as r:
        history_fields = json.loads(r.read().decode("utf-8"))

    item = history_fields["items"][0]
    assert "fps" in item
    assert "cpu_pct" in item
    assert "_path" in item
    assert "_ts" in item


def _free_port():
    """Helper to find a free port for testing."""
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    addr, port = s.getsockname()
    s.close()
    return port

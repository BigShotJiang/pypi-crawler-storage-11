"""Tests for compare UI app (smoke tests and helper functions)."""

import subprocess
import sys
from pathlib import Path

import pytest


def test_app_compare_imports():
    """Test that app_compare module can be imported."""
    # This will fail gracefully if streamlit not installed (expected in minimal env)
    # But verifies module structure is valid
    try:
        from mtbsync import app_compare

        assert hasattr(app_compare, "main")
        assert hasattr(app_compare, "export_annotations_json")
        assert hasattr(app_compare, "export_annotations_csv")
    except ImportError as e:
        # Expected if streamlit not installed
        if "streamlit" in str(e).lower():
            pytest.skip("Streamlit not installed (expected in minimal environment)")
        else:
            raise


def test_export_annotations_json():
    """Test JSON export function (skip - requires Streamlit app context)."""
    # These functions rely on st.session_state which requires a full Streamlit app
    # context that's not available in unit tests. Skip for now.
    pytest.skip("Streamlit session_state requires full app context (not available in unit tests)")


def test_export_annotations_csv():
    """Test CSV export function (skip - requires Streamlit app context)."""
    # These functions rely on st.session_state which requires a full Streamlit app
    # context that's not available in unit tests. Skip for now.
    pytest.skip("Streamlit session_state requires full app context (not available in unit tests)")


def test_cli_compare_ui_help():
    """Test that compare-ui CLI command exists and shows help."""
    # Run mtbsync compare-ui --help
    result = subprocess.run(
        [sys.executable, "-m", "mtbsync.cli", "compare-ui", "--help"],
        capture_output=True,
        text=True,
    )

    # Should succeed even without streamlit (help doesn't require it)
    assert result.returncode == 0
    assert "compare-ui" in result.stdout.lower() or "comparison" in result.stdout.lower()
    assert "video" in result.stdout.lower()


def test_cli_compare_ui_missing_streamlit():
    """Test that compare-ui gives helpful error when streamlit missing."""
    # Only run this test if streamlit is NOT installed
    try:
        import streamlit  # noqa: F401

        pytest.skip("Streamlit is installed, skipping missing dependency test")
    except ImportError:
        pass

    # Try to run compare-ui (should fail with helpful message)
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "mtbsync.cli",
            "compare-ui",
            "--ref",
            "dummy.mp4",
            "--new",
            "dummy.mp4",
            "--ref-markers",
            "dummy.csv",
        ],
        capture_output=True,
        text=True,
    )

    # Should exit with error code
    assert result.returncode != 0

    # Should mention streamlit installation
    output = result.stdout + result.stderr
    assert "streamlit" in output.lower()
    assert "install" in output.lower() or "pip" in output.lower()


def test_app_compare_file_exists():
    """Test that app_compare.py file exists in package."""
    import mtbsync

    app_path = Path(mtbsync.__file__).parent / "app_compare.py"
    assert app_path.exists(), f"app_compare.py not found at {app_path}"


def test_compare_core_integration_with_app():
    """Test that app can import compare_core."""
    try:
        from mtbsync import app_compare, compare_core

        # Verify app references compare_core (import check)
        # This ensures the integration is correct
        assert compare_core is not None
        assert app_compare is not None

    except ImportError as e:
        if "streamlit" in str(e).lower():
            pytest.skip("Streamlit not installed")
        else:
            raise


def test_app_compare_missing_streamlit_raises_importerror(monkeypatch):
    """
    Importing the app module must not sys.exit the interpreter when streamlit is missing.
    It should raise ImportError that callers/tests can catch.
    """
    import builtins

    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "streamlit":
            raise ImportError("streamlit not installed")
        return real_import(name, *args, **kwargs)

    with monkeypatch.context() as m:
        m.setattr(builtins, "__import__", fake_import)
        # Clear any cached import
        if "mtbsync.app_compare" in sys.modules:
            del sys.modules["mtbsync.app_compare"]
        with pytest.raises(ImportError, match="Streamlit is required"):
            __import__("mtbsync.app_compare")


def test_compare_ui_env_wiring(monkeypatch):
    """
    CLI should populate environment variables for the Streamlit subprocess
    so the app can preload sidebar fields.
    """
    from mtbsync.cli import compare_ui_cmd

    calls = {}

    def fake_run(cmd, check, env):
        calls["env"] = env
        return type("Result", (), {"returncode": 0})()

    import subprocess

    monkeypatch.setattr(subprocess, "run", fake_run)

    # Also pretend streamlit is installed
    monkeypatch.setitem(sys.modules, "streamlit", object())

    compare_ui_cmd(
        ref=Path("r.mp4"),
        new=Path("n.mp4"),
        ref_markers=Path("ref.csv"),
        new_markers=Path("new.csv"),
        timewarp_json=Path("tw.json"),
        root=Path("batch_out"),
        port=9999,
        no_browser=True,
    )

    env = calls["env"]
    assert env["MTB_COMPARE_REF"].endswith("r.mp4")
    assert env["MTB_COMPARE_NEW"].endswith("n.mp4")
    assert env["MTB_COMPARE_REF_MARKERS"].endswith("ref.csv")
    assert env["MTB_COMPARE_NEW_MARKERS"].endswith("new.csv")
    assert env["MTB_COMPARE_TIMEWARP_JSON"].endswith("tw.json")
    assert env["MTB_COMPARE_ROOT"].endswith("batch_out")

from pydantic import FilePath

from ..basesegmentationextractorinterface import BaseSegmentationExtractorInterface


class ExtractSegmentationInterface(BaseSegmentationExtractorInterface):
    """Data interface for ExtractSegmentationExtractor."""

    display_name = "EXTRACT Segmentation"
    associated_suffixes = (".mat",)
    info = "Interface for EXTRACT segmentation."

    @classmethod
    def get_extractor_class(cls):
        from roiextractors import ExtractSegmentationExtractor

        return ExtractSegmentationExtractor

    def __init__(
        self,
        file_path: FilePath,
        sampling_frequency: float,
        output_struct_name: str | None = None,
        verbose: bool = False,
    ):
        """

        Parameters
        ----------
        file_path : FilePath
        sampling_frequency : float
        output_struct_name : str, optional
        verbose: bool, default : True
        """
        self.verbose = verbose
        super().__init__(
            file_path=file_path,
            sampling_frequency=sampling_frequency,
            output_struct_name=output_struct_name,
        )

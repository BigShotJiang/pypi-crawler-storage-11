
# xt-asset

Purpose: **manage trading asset steps, min notional, and fees for correct orders.**

## Install
```bash
pip install xt-asset
```

## Build a registry
```python
from xt_asset import Registry
# from dict
reg = Registry.from_dict({
  "BTC/USDT": {"venue":"binance","base":"BTC","quote":"USDT",
               "px_step":0.1,"sz_step":0.0001,
               "min_notional":5.0,"maker_bps":2,"taker_bps":4}
})
# or from a normalized markets JSON you obtained yourself
reg = Registry.from_file("markets.json")
```

## Use
```python
from xt_asset import q_px, q_sz, enforce
a = reg["BTC/USDT"]
px = q_px(63234.123, a.px_step)
sz = q_sz(0.003412, a.sz_step)
enforce(px, sz, a.min_notional)
```

## CLI
```bash
# load a markets file and write a registry
xt-asset build --in markets.json --out registry.json
xt-asset show --path registry.json
```

## Extensible loader interface
Implement `xt_asset.Loader` protocol and call `Registry.from_loader(loader)`.
Ship exchange-specific loaders as separate plugins, e.g. `xt-asset-binance`.


from dataclasses import dataclass

@dataclass(frozen=True)
class Asset:
    symbol: str
    venue: str
    base: str
    quote: str
    px_step: float
    sz_step: float
    min_notional: float
    maker_bps: int
    taker_bps: int


import argparse
from .registry import Registry

def main(argv=None):
    p = argparse.ArgumentParser(prog="xt-asset", description="Asset precision & fee registry (neutral)")
    sub = p.add_subparsers(dest="cmd")

    bp = sub.add_parser("build", help="build registry from a markets JSON file")
    bp.add_argument("--in", dest="in_path", required=True, help="markets.json")
    bp.add_argument("--venue", default="unknown")
    bp.add_argument("--out", required=True)

    sp = sub.add_parser("show", help="show registry file")
    sp.add_argument("--path", required=True)

    args = p.parse_args(argv)

    if args.cmd == "build":
        reg = Registry.from_file(args.in_path, venue=args.venue)
        reg.save(args.out)
        print(f"wrote {args.out}")
        return 0

    if args.cmd == "show":
        reg = Registry.load(args.path)
        for s in reg.symbols():
            a = reg[s]
            print(f"{s} step(px={a.px_step}, sz={a.sz_step}) min_notional={a.min_notional} "
                  f"fees(maker={a.maker_bps}bps taker={a.taker_bps}bps)")
        return 0

    p.print_help()
    return 1

if __name__ == "__main__":
    raise SystemExit(main())


class RegistryError(Exception):
    pass

class SchemaVersionError(RegistryError):
    pass

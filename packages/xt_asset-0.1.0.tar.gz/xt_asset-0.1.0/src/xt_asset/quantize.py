
import math

def _decimals(step: float) -> int:
    # works for power-of-ten steps; cap at 12
    s = f"{step:.12f}".rstrip("0").split(".")
    return len(s[1]) if len(s) == 2 else 0

def _round_step(x: float, step: float, mode: str = "nearest") -> float:
    if step <= 0:
        raise ValueError("step must be > 0")
    k = x / step
    if mode == "down":
        out = math.floor(k) * step
        return round(out, _decimals(step))
    if mode == "up":
        out = math.ceil(k) * step
        return round(out, _decimals(step))
    # nearest, ties to even
    out = round(k) * step
    return round(out, _decimals(step))

def q_px(px: float, step: float, *, mode: str = "nearest") -> float:
    return _round_step(px, step, mode)

def q_sz(sz: float, step: float, *, mode: str = "down") -> float:
    return _round_step(sz, step, mode)

def enforce(px: float, sz: float, min_notional: float) -> None:
    if px * sz < min_notional:
        raise ValueError(f"notional {px*sz:.8f} < min_notional {min_notional}")

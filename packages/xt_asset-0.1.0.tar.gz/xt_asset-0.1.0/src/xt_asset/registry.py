
import json
from typing import Dict, Optional
from pydantic import BaseModel, Field, ValidationError
from .types import Asset
from .loader import Loader

_SCHEMA_VERSION = 1

class _AssetModel(BaseModel):
    symbol: str
    venue: str
    base: str
    quote: str
    px_step: float = Field(gt=0)
    sz_step: float = Field(gt=0)
    min_notional: float = Field(ge=0)
    maker_bps: int = Field(ge=0)
    taker_bps: int = Field(ge=0)

def _normalize(symbol: str, raw: dict, *, venue: str) -> dict:
    prec = raw.get("precision") or {}
    limits = raw.get("limits") or {}
    # accept either explicit increments or decimals
    def to_step(increment, decimals):
        if increment and float(increment) > 0:
            return float(increment)
        if isinstance(decimals, int):
            return float(10 ** (-decimals))
        return 0.0
    px_step = to_step(raw.get("priceIncrement"), prec.get("price"))
    sz_step = to_step(raw.get("amountIncrement"), prec.get("amount"))
    min_notional = float((limits.get("cost") or {}).get("min") or 0.0)
    maker_bps = int(round(float(raw.get("maker") or 0.0) * 1e4))
    taker_bps = int(round(float(raw.get("taker") or 0.0) * 1e4))
    base = raw.get("base") or symbol.split("/")[0]
    quote = raw.get("quote") or symbol.split("/")[-1]
    return {
        "venue": venue, "base": base, "quote": quote,
        "px_step": px_step or 0.0, "sz_step": sz_step or 0.0,
        "min_notional": min_notional, "maker_bps": maker_bps, "taker_bps": taker_bps
    }

class Registry:
    def __init__(self, mapping: Dict[str, Asset]):
        self._m = dict(mapping)

    @classmethod
    def from_dict(cls, d: Dict[str, dict]) -> "Registry":
        m = {}
        for sym, v in d.items():
            # prefer the key; ignore embedded symbol if provided
            v = {k: v for k, v in v.items() if k != "symbol"}
            try:
                am = _AssetModel(symbol=sym, **v)
            except ValidationError as e:
                raise ValueError(f"invalid asset {sym}: {e}") from e
            m[sym] = Asset(**am.model_dump())
        return cls(m)

    @classmethod
    def from_loader(cls, loader: Loader, *, venue: str) -> "Registry":
        raw = loader.fetch()
        norm = {s: _normalize(s, v, venue=venue) for s, v in raw.items()}
        return cls.from_dict(norm)

    @classmethod
    def from_file(cls, path: str, *, venue: Optional[str] = None) -> "Registry":
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        if venue is None:
            venue = raw.get("_meta", {}).get("venue") or "unknown"
        src = raw.get("markets") if "markets" in raw else raw
        norm = {s: _normalize(s, v, venue=venue) for s, v in src.items()}
        return cls.from_dict(norm)

    def __getitem__(self, symbol: str) -> Asset:
        return self._m[symbol]

    def symbols(self):
        return list(self._m.keys())

    def save(self, path: str) -> None:
        d = {
            "_meta": {"schema_version": 1},
            "assets": {
                k: {kk: vv for kk, vv in v.__dict__.items() if kk != "symbol"}
                for k, v in self._m.items()
            },
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=2)

    @classmethod
    def load(cls, path: str) -> "Registry":
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
        return cls.from_dict(d.get("assets", {}))

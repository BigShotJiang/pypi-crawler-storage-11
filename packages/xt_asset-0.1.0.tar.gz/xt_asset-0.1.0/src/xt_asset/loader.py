
from typing import Protocol, Dict
from typing_extensions import TypedDict

class Markets(TypedDict, total=False):
    # free-form dict per symbol; your loader decides exact fields
    # example keys used by default normalizer:
    # base, quote, precision.price, precision.amount, limits.price.min, limits.amount.min, limits.cost.min, maker, taker
    pass

class Loader(Protocol):
    def fetch(self) -> Dict[str, dict]:  # returns {symbol: market_info}
        ...

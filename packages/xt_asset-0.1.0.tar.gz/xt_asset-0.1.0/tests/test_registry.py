
from xt_asset import Registry

def test_from_dict_and_save_load(tmp_path):
    d = {
        "BTC/USDT": {
            "venue": "binance",
            "base": "BTC",
            "quote": "USDT",
            "px_step": 0.1,
            "sz_step": 0.0001,
            "min_notional": 5.0,
            "maker_bps": 2,
            "taker_bps": 4
        }
    }
    reg = Registry.from_dict(d)
    path = tmp_path / "reg.json"
    reg.save(path.as_posix())
    reg2 = Registry.load(path.as_posix())
    a = reg2["BTC/USDT"]
    assert a.px_step == 0.1 and a.sz_step == 0.0001

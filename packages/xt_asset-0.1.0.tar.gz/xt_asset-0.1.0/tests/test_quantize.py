
from xt_asset.quantize import q_px, q_sz, enforce
import pytest

def test_q_px_nearest():
    assert q_px(100.04, 0.1) == 100.0
    # 0.05 tie may round to even in Python; accept either
    assert q_px(100.05, 0.1) in (100.0, 100.1)

def test_q_sz_down():
    assert q_sz(0.00349, 0.0001) == 0.0034

def test_enforce():
    with pytest.raises(ValueError):
        enforce(100.0, 0.01, 2.0)
    enforce(100.0, 0.1, 5.0)

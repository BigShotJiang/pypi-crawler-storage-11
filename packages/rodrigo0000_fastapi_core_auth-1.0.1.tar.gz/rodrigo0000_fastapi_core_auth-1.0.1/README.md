# rodrigo0000-fastapi-core-auth

Authentication module for FastAPI with JWT, OAuth2, and user management.

## Features

- JWT token-based authentication
- OAuth2 password flow
- User registration and login
- Password hashing with bcrypt
- Token refresh functionality
- User management repository

## Installation

```bash
pip install rodrigo0000-fastapi-core-auth
```

## Usage

```python
from rodrigo0000_fastapi_core_auth import router, AuthRepository
from fastapi import FastAPI

app = FastAPI()
app.include_router(router, prefix="/api/v1/auth", tags=["auth"])
```

## Components

- **AuthRepository**: Database operations for user authentication
- **Schemas**: Pydantic models for requests and responses
  - `LoginRequest`
  - `RegisterRequest`
  - `UserResponse`
  - `AuthResponse`
- **Router**: FastAPI router with authentication endpoints

## Requirements

- Python >= 3.8
- FastAPI >= 0.104.0
- SQLAlchemy >= 2.0.0
- Pydantic >= 2.0.0
- python-jose[cryptography] >= 3.3.0
- passlib[bcrypt] >= 1.7.4

## License

MIT License

## Author

R Firm - Professional SaaS Development

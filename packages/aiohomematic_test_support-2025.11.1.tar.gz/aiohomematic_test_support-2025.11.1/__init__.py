__version__ = "2025.11.1"
"""Module to support aiohomematic testing with a local client."""

"""Platform-specific exploit modules"""

"""CVE exploit modules"""

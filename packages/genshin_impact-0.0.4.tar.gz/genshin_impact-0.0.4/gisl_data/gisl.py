"""
A static library for retrieving Genshin Impact character and material data.
The data is loaded from a bundled gisl_data.json file.
"""
import json
# Use pkg_resources alias for compatibility with user's existing code
import importlib.resources as pkg_resources
import logging

# Set up logging to capture potential errors
logger = logging.getLogger(__name__)

# The 'gisl_data' is the folder name inside your package structure
PACKAGE_NAME = 'gisl_data'
DATA_FILE_NAME = 'gisl_data.json'

try:
    # Using the robust read_text method for stability and clean file access
    json_data = pkg_resources.read_text(PACKAGE_NAME, DATA_FILE_NAME)
    gisl_data = json.loads(json_data)
    logger.info("Successfully loaded gisl_data.json")
    print("GISL_DATA_LIBRARY: Data loaded successfully.")
except Exception as e:
    # This block is a failsafe, preventing the script from crashing.
    logger.error(f"Error loading data: {e}")
    print(f"GI_STATIC_DATA_LIBRARY: Error loading data from {DATA_FILE_NAME}: {e}")
    gisl_data = {}

def get_character_data(character_key: str) -> dict | None:
    """
    Retrieves the full data for a specific character by their key.

    Args:
        character_key: The lowercase key of the character (e.g., 'albedo').

    Returns:
        A dictionary of the character's data, or None if not found.
    """
    return gisl_data.get(character_key.lower())

def get_all_characters_data() -> dict:
    """
    Returns the full dictionary of all character data.

    Returns:
        A dictionary containing all character data.
    """
    return gisl_data

def find_characters_by_material(material_name: str) -> list:
    """
    Finds and returns a list of characters that use a given ascension or talent material.

    Args:
        material_name: The name of the material to search for (e.g., "Prithiva Topaz", "Crown of Insight").

    Returns:
        A list of dictionaries, each containing character name, material type, and total amount.
    """
    material_name = material_name.lower()
    characters_using_material = {}

    for char_key, char_data in gisl_data.items():
        # --- Ascension Materials Check ---
        ascension_mats = char_data.get('ascension_materials', {})
        total_ascension_amount = 0
        ascension_mat_found = False

        for mat_type, mat_info in ascension_mats.items():
            if mat_info and mat_info.get('name', '').lower() == material_name:
                ascension_mat_found = True
                
                # Sum the amounts for the matching material across all ascension levels
                for level_info in char_data.get('ascension_levels', {}).values():
                    # The JSON format suggests a key match is necessary here
                    # We look for the material's 'name' value used as a key in level_info
                    mat_key = mat_info['name'] 
                    if mat_key in level_info:
                        total_ascension_amount += level_info[mat_key]['amount']
                
                break # Only need to find the material once per character

        if ascension_mat_found:
            characters_using_material[char_data['name']] = {
                "character": char_data['name'],
                "material_type": "ascension",
                "amount": total_ascension_amount
            }

        # --- Talent Materials Check ---
        talents = char_data.get('talents', [])
        total_talent_amount = 0

        for talent in talents:
            # We assume the materials are listed under 'level_materials' -> 'level' array
            talent_mats = talent.get('level_materials', {}).get('level', [])
            
            for mat_info in talent_mats:
                if mat_info.get('material', '').lower() == material_name:
                    amounts_str = mat_info.get('amount', '')
                    
                    # Safety check: ensure string is not empty and contains only digits/dashes
                    if amounts_str and all(c.isdigit() or c == '-' for c in amounts_str):
                        # Split and sum amounts (e.g., '1-2-3' -> [1, 2, 3] -> 6)
                        amounts = [int(a) for a in amounts_str.split('-') if a.isdigit()]
                        total_talent_amount += sum(amounts)
        
        if total_talent_amount > 0:
            # If both ascension and talent mats were found, this updates the entry, but
            # since the material is the primary key, we treat them as separate use cases.
            # If a character uses the SAME item for both (e.g., common mats), this will
            # overwrite 'ascension' with 'talent'. For a definitive total, this needs review.
            # Sticking to separate entries/overwriting 'talent' to reflect your original structure.
            characters_using_material[char_data['name']] = {
                "character": char_data['name'],
                "material_type": "talent",
                "amount": total_talent_amount
            }

    # Convert the dictionary values to a list and return
    return list(characters_using_material.values())

def find_characters_by_element(element_name: str) -> list:
    """
    Finds and returns a list of character names that match the given element.

    Args:
        element_name: The name of the element to search for (e.g., "Anemo", "Geo").

    Returns:
        A list of matching character names.
    """
    matching_characters = []
    for char_name, char_data in gisl_data.items():
        if 'element' in char_data and char_data['element'].lower() == element_name.lower():
            matching_characters.append(char_data['name'])
    return matching_characters

def find_characters_by_weapon_type(weapon_type: str) -> list:
    """
    Finds and returns a list of character names that match the given weapon type.

    Args:
        weapon_type: The type of weapon to search for (e.g., "Sword", "Bow").

    Returns:
        A list of matching character names.
    """
    matching_characters = []
    for char_name, char_data in gisl_data.items():
        if 'weapon_type' in char_data and char_data['weapon_type'].lower() == weapon_type.lower():
            matching_characters.append(char_data['name'])
    return matching_characters
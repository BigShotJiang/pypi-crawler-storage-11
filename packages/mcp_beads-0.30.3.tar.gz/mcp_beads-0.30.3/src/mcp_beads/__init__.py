"""MCP Server for Beads Agentic Task Tracker and Memory System

This package provides an MCP (Model Context Protocol) server that exposes
beads (beads) issue tracker functionality to MCP Clients.
"""

__version__ = "0.30.3"

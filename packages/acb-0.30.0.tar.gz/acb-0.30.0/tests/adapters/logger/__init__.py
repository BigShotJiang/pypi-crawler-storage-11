"""Tests for logger adapters."""

"""Tests for embedding adapters."""

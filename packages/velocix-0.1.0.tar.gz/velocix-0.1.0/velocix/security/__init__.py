"""Security module"""

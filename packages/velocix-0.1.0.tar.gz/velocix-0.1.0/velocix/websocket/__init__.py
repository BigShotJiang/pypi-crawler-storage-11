"""WebSocket module"""

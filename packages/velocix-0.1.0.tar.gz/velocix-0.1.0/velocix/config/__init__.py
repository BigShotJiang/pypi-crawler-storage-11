"""Configuration module"""

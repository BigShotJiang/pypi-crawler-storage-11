#!/usr/bin/env python3
"""Build a binary executable for webquiz-stress-test using PyInstaller"""

import subprocess
import sys
from pathlib import Path


def main():
    """Build a binary executable using PyInstaller."""

    # Get the project root directory
    project_root = Path(__file__).parent.parent

    # Check if PyInstaller is available
    try:
        subprocess.run(["pyinstaller", "--version"], check=True, capture_output=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("PyInstaller is not installed or not in PATH. Install it with: poetry install")
        sys.exit(1)

    # Get certifi certificate bundle path
    try:
        import certifi

        certifi_path = certifi.where()
        print(f"[INFO] Including certifi CA bundle from: {certifi_path}")
    except ImportError:
        print("[WARNING] certifi not found - SSL verification may fail in binary")
        certifi_path = None

    # PyInstaller command - use the binary entry point
    binary_entry = project_root / "webquiz_stress_test" / "binary_entry.py"
    cmd = [
        "pyinstaller",
        "--onefile",
        "--name",
        "webquiz-stress-test",
        "--hidden-import",
        "webquiz_stress_test.stress_test",
        "--hidden-import",
        "certifi",
        "--collect-data",
        "certifi",
        str(binary_entry),
    ]

    print(f"Building binary with PyInstaller...")
    print(f"Working directory: {project_root}")

    # Run PyInstaller
    try:
        result = subprocess.run(cmd, cwd=project_root, check=True)
        print("\n[SUCCESS] Build completed successfully!")
        print(f"[INFO] Binary location: {project_root}/dist/webquiz-stress-test")
        print("\n[INFO] To run the binary:")
        print("   ./dist/webquiz-stress-test")
        print("   ./dist/webquiz-stress-test --help")
        print("   ./dist/webquiz-stress-test -u http://localhost:8080 -c 50")
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] Build failed with exit code {e.returncode}")
        sys.exit(1)


if __name__ == "__main__":
    main()

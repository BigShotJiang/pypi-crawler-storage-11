$ "equation from another file" $

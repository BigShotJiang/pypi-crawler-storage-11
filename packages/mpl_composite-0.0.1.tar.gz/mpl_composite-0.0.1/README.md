<!--START_SECTION:images-->
![shields.io-python-versions](https://img.shields.io/badge/python-3.11%20%7C%203.12%20%7C%203.13-blue)
![genbadge-test-count](https://bertpl.github.io/mpl-composite/version_artifacts/v0.0.1/badge-test-count.svg)
![genbadge-test-coverage](https://bertpl.github.io/mpl-composite/version_artifacts/v0.0.1/badge-coverage.svg)
![mpl-composite logo](https://bertpl.github.io/mpl-composite/version_artifacts/v0.0.1/splash.webp)
<!--END_SECTION:images-->

# mpl-composite
Matplotlib wrapper for composite figure building.
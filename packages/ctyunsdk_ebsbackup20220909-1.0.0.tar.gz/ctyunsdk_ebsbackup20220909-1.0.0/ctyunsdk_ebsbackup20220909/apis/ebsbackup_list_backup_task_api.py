from typing import List, Optional, Dict, Any
from ctyunsdk_ebsbackup20220909.core.client import CtyunClient
from ctyunsdk_ebsbackup20220909.core.credential import Credential
from ctyunsdk_ebsbackup20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsbackupListBackupTaskRequest:
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span> <a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    taskID: Optional[str]  # 云硬盘备份任务ID。
    queryContent: Optional[str]  # 该参数，可用于模糊过滤，任务ID/云硬盘ID/云硬盘名称/备份任务ID/备份名称/存储库名称，即上述6个字段如果包含该参数的值，则会被过滤出来。
    taskStatus: Optional[str]  # 任务状态：<br />执行中:"running"<br />成功:"success"<br />失败:"failed"<br />已取消:"canceled"<br />取消中:"canceling"
    taskType: Optional[int]  # 任务类型：<br />1:创建任务<br />2:删除任务<br />3:恢复任务


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}



@dataclass
class EbsbackupListBackupTaskReturnObjTaskListResponse:
    regionID: Optional[str]  # 资源池ID。
    taskID: Optional[str]  # 备份任务ID。
    taskType: Optional[str]  # 任务类型:<br />创建任务:create<br />删除任务:delete<br />恢复任务:restore
    backupID: Optional[str]  # 备份ID。
    backupName: Optional[str]  # 备份名称。
    diskID: Optional[str]  # 云硬盘ID。
    diskName: Optional[str]  # 云硬盘名称。
    repositoryID: Optional[str]  # 备份存储库ID。
    repositoryName: Optional[str]  # 备份存储库名称。
    statusCode: Optional[str]  # 任务状态码。
    taskProgress: Optional[str]  # 任务进度，取值为0-100。
    status: Optional[str]  # 任务状态描述:<br />成功:success<br />执行中:running<br />失败:failed<br />已取消：canceled<br />取消中：canceling
    taskStartTime: Optional[int]  # 任务开始时间。
    taskDoneTime: Optional[int]  # 任务完成时间。
    taskErrMsg: Optional[str]  # 任务执行过程中的错误信息描述。
    taskDetail: Optional[str]  # 任务执行过程中附加信息描述。
    description: Optional[str]  # 任务描述。
    policyTaskID: Optional[str]  # 关联的策略调度任务ID。
    backupType: Optional[str]  # 备份类型:<br />全量备份:totalReplication<br />增量备份:incrementalReplication
    projectID: Optional[str]  # 企业项目ID


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupTaskReturnObjTaskListResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupTaskReturnObjTaskListResponse(
            regionID=json_data.get('regionID'),
            taskID=json_data.get('taskID'),
            taskType=json_data.get('taskType'),
            backupID=json_data.get('backupID'),
            backupName=json_data.get('backupName'),
            diskID=json_data.get('diskID'),
            diskName=json_data.get('diskName'),
            repositoryID=json_data.get('repositoryID'),
            repositoryName=json_data.get('repositoryName'),
            statusCode=json_data.get('statusCode'),
            taskProgress=json_data.get('taskProgress'),
            status=json_data.get('status'),
            taskStartTime=json_data.get('taskStartTime'),
            taskDoneTime=json_data.get('taskDoneTime'),
            taskErrMsg=json_data.get('taskErrMsg'),
            taskDetail=json_data.get('taskDetail'),
            description=json_data.get('description'),
            policyTaskID=json_data.get('policyTaskID'),
            backupType=json_data.get('backupType'),
            projectID=json_data.get('projectID')
        )

        return obj

@dataclass
class EbsbackupListBackupTaskReturnObjResponse:
    """成功时返回对象。"""
    taskList: Optional[List[Optional[EbsbackupListBackupTaskReturnObjTaskListResponse]]]  # 云硬盘备份任务列表。
    totalCount: Any  # 云硬盘备份任务总数。
    currentCount: Any  # 当前页云硬盘备份任务数。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupTaskReturnObjResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupTaskReturnObjResponse(
            taskList=[EbsbackupListBackupTaskReturnObjTaskListResponse.from_json(item) for item in json_data.get('taskList', [])],
            totalCount=json_data.get('totalCount'),
            currentCount=json_data.get('currentCount')
        )

        return obj

@dataclass
class EbsbackupListBackupTaskResponse:
    statusCode: Any  # 返回状态码（800为成功，900为失败）。
    message: Optional[str]  # 错误信息的英文描述。
    description: Optional[str]  # 错误信息的本地化描述（中文）。
    returnObj: Optional[EbsbackupListBackupTaskReturnObjResponse]  # 成功时返回对象。
    errorCode: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码。
    error: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupTaskResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupTaskResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=EbsbackupListBackupTaskReturnObjResponse.from_json(json_data.get('returnObj')) if json_data.get('returnObj') else None,
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error')
        )

        return obj


# 查询云硬盘备份任务列表。
class EbsbackupListBackupTaskApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsbackupListBackupTaskRequest) -> EbsbackupListBackupTaskResponse:
        url = endpoint + "/v4/ebs-backup/task/list-task"
        params = {'regionID':request.regionID, 'taskID':request.taskID, 'queryContent':request.queryContent, 'taskStatus':request.taskStatus, 'taskType':request.taskType}
        try:
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.get(url=url, params=params, header_params=request_dict, credential=credential)
            return EbsbackupListBackupTaskResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

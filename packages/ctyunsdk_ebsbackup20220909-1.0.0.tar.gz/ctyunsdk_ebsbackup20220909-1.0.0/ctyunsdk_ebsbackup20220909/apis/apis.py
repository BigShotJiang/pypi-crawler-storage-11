from typing import Optional
from ctyunsdk_ebsbackup20220909.core.client import CtyunClient
from ctyunsdk_ebsbackup20220909.core.credential import Credential

from .ebsbackup_list_ebs_backup_policy_disks_api import EbsbackupListEbsBackupPolicyDisksApi
from .ebsbackup_show_ebs_backup_policy_task_api import EbsbackupShowEbsBackupPolicyTaskApi
from .ebsbackup_ebs_backup_policy_bind_repo_api import EbsbackupPolicyBindRepoApi
from .ebsbackup_update_ebs_backup_policy_api import EbsbackupUpdateEbsBackupPolicyApi
from .ebsbackup_enable_ebs_backup_policy_api import EbsbackupEnableEbsBackupPolicyApi
from .ebsbackup_delete_ebs_backup_policy_api import EbsbackupDeleteEbsBackupPolicyApi
from .ebsbackup_create_ebs_backup_policy_api import EbsbackupCreateEbsBackupPolicyApi
from .ebsbackup_ebs_backup_policy_unbind_repo_api import EbsbackupPolicyUnbindRepoApi
from .ebsbackup_execute_ebs_backup_policy_api import EbsbackupExecuteEbsBackupPolicyApi
from .ebsbackup_create_repo_api import EbsbackupCreateRepoApi
from .ebsbackup_update_ebs_backup_repo_api import EbsbackupUpdateEbsBackupRepoApi
from .ebsbackup_resize_repo_api import EbsbackupResizeRepoApi
from .ebsbackup_renew_repo_api import EbsbackupRenewRepoApi
from .ebsbackup_delete_repo_api import EbsbackupDeleteRepoApi
from .ebsbackup_delete_ebs_backup_api import EbsbackupDeleteEbsBackupApi
from .ebsbackup_disable_ebs_backup_policy_api import EbsbackupDisableEbsBackupPolicyApi
from .ebsbackup_list_ebs_backup_policy_tasks_api import EbsbackupListEbsBackupPolicyTasksApi
from .ebsbackup_list_backup_repo_api import EbsbackupListBackupRepoApi
from .ebsbackup_show_backup_api import EbsbackupShowBackupApi
from .ebsbackup_list_backup_policy_api import EbsbackupListBackupPolicyApi
from .ebsbackup_list_backup_api import EbsbackupListBackupApi
from .ebsbackup_show_backup_usage_api import EbsbackupShowBackupUsageApi
from .ebsbackup_create_backup_api import EbsbackupCreateBackupApi
from .ebsbackup_restore_backup_api import EbsbackupRestoreBackupApi
from .ebsbackup_ebs_backup_policy_bind_disks_api import EbsbackupPolicyBindDisksApi
from .ebsbackup_ebs_backup_policy_unbind_disks_api import EbsbackupPolicyUnbindDisksApi
from .ebsbackup_list_backup_task_api import EbsbackupListBackupTaskApi
from .ebsbackup_cancel_backup_task_api import EbsbackupCancelBackupTaskApi

ENDPOINT_NAME = "ebsbackup"

class Apis:
    _ebsbackuplistebsbackuppolicydisksapi: EbsbackupListEbsBackupPolicyDisksApi
    _ebsbackupshowebsbackuppolicytaskapi: EbsbackupShowEbsBackupPolicyTaskApi
    _ebsbackuppolicybindrepoapi: EbsbackupPolicyBindRepoApi
    _ebsbackupupdateebsbackuppolicyapi: EbsbackupUpdateEbsBackupPolicyApi
    _ebsbackupenableebsbackuppolicyapi: EbsbackupEnableEbsBackupPolicyApi
    _ebsbackupdeleteebsbackuppolicyapi: EbsbackupDeleteEbsBackupPolicyApi
    _ebsbackupcreateebsbackuppolicyapi: EbsbackupCreateEbsBackupPolicyApi
    _ebsbackuppolicyunbindrepoapi: EbsbackupPolicyUnbindRepoApi
    _ebsbackupexecuteebsbackuppolicyapi: EbsbackupExecuteEbsBackupPolicyApi
    _ebsbackupcreaterepoapi: EbsbackupCreateRepoApi
    _ebsbackupupdateebsbackuprepoapi: EbsbackupUpdateEbsBackupRepoApi
    _ebsbackupresizerepoapi: EbsbackupResizeRepoApi
    _ebsbackuprenewrepoapi: EbsbackupRenewRepoApi
    _ebsbackupdeleterepoapi: EbsbackupDeleteRepoApi
    _ebsbackupdeleteebsbackupapi: EbsbackupDeleteEbsBackupApi
    _ebsbackupdisableebsbackuppolicyapi: EbsbackupDisableEbsBackupPolicyApi
    _ebsbackuplistebsbackuppolicytasksapi: EbsbackupListEbsBackupPolicyTasksApi
    _ebsbackuplistbackuprepoapi: EbsbackupListBackupRepoApi
    _ebsbackupshowbackupapi: EbsbackupShowBackupApi
    _ebsbackuplistbackuppolicyapi: EbsbackupListBackupPolicyApi
    _ebsbackuplistbackupapi: EbsbackupListBackupApi
    _ebsbackupshowbackupusageapi: EbsbackupShowBackupUsageApi
    _ebsbackupcreatebackupapi: EbsbackupCreateBackupApi
    _ebsbackuprestorebackupapi: EbsbackupRestoreBackupApi
    _ebsbackuppolicybinddisksapi: EbsbackupPolicyBindDisksApi
    _ebsbackuppolicyunbinddisksapi: EbsbackupPolicyUnbindDisksApi
    _ebsbackuplistbackuptaskapi: EbsbackupListBackupTaskApi
    _ebsbackupcancelbackuptaskapi: EbsbackupCancelBackupTaskApi

    def __init__(self, endpoint_url: str, client: Optional[CtyunClient] = None):
        self.client = client or CtyunClient()
        self.endpoint = endpoint_url

        self._ebsbackuplistebsbackuppolicydisksapi = EbsbackupListEbsBackupPolicyDisksApi(self.client)
        self._ebsbackuplistebsbackuppolicydisksapi.set_endpoint(self.endpoint)
        self._ebsbackupshowebsbackuppolicytaskapi = EbsbackupShowEbsBackupPolicyTaskApi(self.client)
        self._ebsbackupshowebsbackuppolicytaskapi.set_endpoint(self.endpoint)
        self._ebsbackuppolicybindrepoapi = EbsbackupPolicyBindRepoApi(self.client)
        self._ebsbackuppolicybindrepoapi.set_endpoint(self.endpoint)
        self._ebsbackupupdateebsbackuppolicyapi = EbsbackupUpdateEbsBackupPolicyApi(self.client)
        self._ebsbackupupdateebsbackuppolicyapi.set_endpoint(self.endpoint)
        self._ebsbackupenableebsbackuppolicyapi = EbsbackupEnableEbsBackupPolicyApi(self.client)
        self._ebsbackupenableebsbackuppolicyapi.set_endpoint(self.endpoint)
        self._ebsbackupdeleteebsbackuppolicyapi = EbsbackupDeleteEbsBackupPolicyApi(self.client)
        self._ebsbackupdeleteebsbackuppolicyapi.set_endpoint(self.endpoint)
        self._ebsbackupcreateebsbackuppolicyapi = EbsbackupCreateEbsBackupPolicyApi(self.client)
        self._ebsbackupcreateebsbackuppolicyapi.set_endpoint(self.endpoint)
        self._ebsbackuppolicyunbindrepoapi = EbsbackupPolicyUnbindRepoApi(self.client)
        self._ebsbackuppolicyunbindrepoapi.set_endpoint(self.endpoint)
        self._ebsbackupexecuteebsbackuppolicyapi = EbsbackupExecuteEbsBackupPolicyApi(self.client)
        self._ebsbackupexecuteebsbackuppolicyapi.set_endpoint(self.endpoint)
        self._ebsbackupcreaterepoapi = EbsbackupCreateRepoApi(self.client)
        self._ebsbackupcreaterepoapi.set_endpoint(self.endpoint)
        self._ebsbackupupdateebsbackuprepoapi = EbsbackupUpdateEbsBackupRepoApi(self.client)
        self._ebsbackupupdateebsbackuprepoapi.set_endpoint(self.endpoint)
        self._ebsbackupresizerepoapi = EbsbackupResizeRepoApi(self.client)
        self._ebsbackupresizerepoapi.set_endpoint(self.endpoint)
        self._ebsbackuprenewrepoapi = EbsbackupRenewRepoApi(self.client)
        self._ebsbackuprenewrepoapi.set_endpoint(self.endpoint)
        self._ebsbackupdeleterepoapi = EbsbackupDeleteRepoApi(self.client)
        self._ebsbackupdeleterepoapi.set_endpoint(self.endpoint)
        self._ebsbackupdeleteebsbackupapi = EbsbackupDeleteEbsBackupApi(self.client)
        self._ebsbackupdeleteebsbackupapi.set_endpoint(self.endpoint)
        self._ebsbackupdisableebsbackuppolicyapi = EbsbackupDisableEbsBackupPolicyApi(self.client)
        self._ebsbackupdisableebsbackuppolicyapi.set_endpoint(self.endpoint)
        self._ebsbackuplistebsbackuppolicytasksapi = EbsbackupListEbsBackupPolicyTasksApi(self.client)
        self._ebsbackuplistebsbackuppolicytasksapi.set_endpoint(self.endpoint)
        self._ebsbackuplistbackuprepoapi = EbsbackupListBackupRepoApi(self.client)
        self._ebsbackuplistbackuprepoapi.set_endpoint(self.endpoint)
        self._ebsbackupshowbackupapi = EbsbackupShowBackupApi(self.client)
        self._ebsbackupshowbackupapi.set_endpoint(self.endpoint)
        self._ebsbackuplistbackuppolicyapi = EbsbackupListBackupPolicyApi(self.client)
        self._ebsbackuplistbackuppolicyapi.set_endpoint(self.endpoint)
        self._ebsbackuplistbackupapi = EbsbackupListBackupApi(self.client)
        self._ebsbackuplistbackupapi.set_endpoint(self.endpoint)
        self._ebsbackupshowbackupusageapi = EbsbackupShowBackupUsageApi(self.client)
        self._ebsbackupshowbackupusageapi.set_endpoint(self.endpoint)
        self._ebsbackupcreatebackupapi = EbsbackupCreateBackupApi(self.client)
        self._ebsbackupcreatebackupapi.set_endpoint(self.endpoint)
        self._ebsbackuprestorebackupapi = EbsbackupRestoreBackupApi(self.client)
        self._ebsbackuprestorebackupapi.set_endpoint(self.endpoint)
        self._ebsbackuppolicybinddisksapi = EbsbackupPolicyBindDisksApi(self.client)
        self._ebsbackuppolicybinddisksapi.set_endpoint(self.endpoint)
        self._ebsbackuppolicyunbinddisksapi = EbsbackupPolicyUnbindDisksApi(self.client)
        self._ebsbackuppolicyunbinddisksapi.set_endpoint(self.endpoint)
        self._ebsbackuplistbackuptaskapi = EbsbackupListBackupTaskApi(self.client)
        self._ebsbackuplistbackuptaskapi.set_endpoint(self.endpoint)
        self._ebsbackupcancelbackuptaskapi = EbsbackupCancelBackupTaskApi(self.client)
        self._ebsbackupcancelbackuptaskapi.set_endpoint(self.endpoint)

    @property  # noqa
    def ebsbackuplistebsbackuppolicydisksapi(self) -> EbsbackupListEbsBackupPolicyDisksApi:  # noqa
        return self._ebsbackuplistebsbackuppolicydisksapi

    @property  # noqa
    def ebsbackupshowebsbackuppolicytaskapi(self) -> EbsbackupShowEbsBackupPolicyTaskApi:  # noqa
        return self._ebsbackupshowebsbackuppolicytaskapi

    @property  # noqa
    def ebsbackuppolicybindrepoapi(self) -> EbsbackupPolicyBindRepoApi:  # noqa
        return self._ebsbackuppolicybindrepoapi

    @property  # noqa
    def ebsbackupupdateebsbackuppolicyapi(self) -> EbsbackupUpdateEbsBackupPolicyApi:  # noqa
        return self._ebsbackupupdateebsbackuppolicyapi

    @property  # noqa
    def ebsbackupenableebsbackuppolicyapi(self) -> EbsbackupEnableEbsBackupPolicyApi:  # noqa
        return self._ebsbackupenableebsbackuppolicyapi

    @property  # noqa
    def ebsbackupdeleteebsbackuppolicyapi(self) -> EbsbackupDeleteEbsBackupPolicyApi:  # noqa
        return self._ebsbackupdeleteebsbackuppolicyapi

    @property  # noqa
    def ebsbackupcreateebsbackuppolicyapi(self) -> EbsbackupCreateEbsBackupPolicyApi:  # noqa
        return self._ebsbackupcreateebsbackuppolicyapi

    @property  # noqa
    def ebsbackuppolicyunbindrepoapi(self) -> EbsbackupPolicyUnbindRepoApi:  # noqa
        return self._ebsbackuppolicyunbindrepoapi

    @property  # noqa
    def ebsbackupexecuteebsbackuppolicyapi(self) -> EbsbackupExecuteEbsBackupPolicyApi:  # noqa
        return self._ebsbackupexecuteebsbackuppolicyapi

    @property  # noqa
    def ebsbackupcreaterepoapi(self) -> EbsbackupCreateRepoApi:  # noqa
        return self._ebsbackupcreaterepoapi

    @property  # noqa
    def ebsbackupupdateebsbackuprepoapi(self) -> EbsbackupUpdateEbsBackupRepoApi:  # noqa
        return self._ebsbackupupdateebsbackuprepoapi

    @property  # noqa
    def ebsbackupresizerepoapi(self) -> EbsbackupResizeRepoApi:  # noqa
        return self._ebsbackupresizerepoapi

    @property  # noqa
    def ebsbackuprenewrepoapi(self) -> EbsbackupRenewRepoApi:  # noqa
        return self._ebsbackuprenewrepoapi

    @property  # noqa
    def ebsbackupdeleterepoapi(self) -> EbsbackupDeleteRepoApi:  # noqa
        return self._ebsbackupdeleterepoapi

    @property  # noqa
    def ebsbackupdeleteebsbackupapi(self) -> EbsbackupDeleteEbsBackupApi:  # noqa
        return self._ebsbackupdeleteebsbackupapi

    @property  # noqa
    def ebsbackupdisableebsbackuppolicyapi(self) -> EbsbackupDisableEbsBackupPolicyApi:  # noqa
        return self._ebsbackupdisableebsbackuppolicyapi

    @property  # noqa
    def ebsbackuplistebsbackuppolicytasksapi(self) -> EbsbackupListEbsBackupPolicyTasksApi:  # noqa
        return self._ebsbackuplistebsbackuppolicytasksapi


    @property  # noqa
    def ebsbackuplistbackuprepoapi(self) -> EbsbackupListBackupRepoApi:  # noqa
        return self._ebsbackuplistbackuprepoapi

    @property  # noqa
    def ebsbackupshowbackupapi(self) -> EbsbackupShowBackupApi:  # noqa
        return self._ebsbackupshowbackupapi

    @property  # noqa
    def ebsbackuplistbackuppolicyapi(self) -> EbsbackupListBackupPolicyApi:  # noqa
        return self._ebsbackuplistbackuppolicyapi

    @property  # noqa
    def ebsbackuplistbackupapi(self) -> EbsbackupListBackupApi:  # noqa
        return self._ebsbackuplistbackupapi

    @property  # noqa
    def ebsbackupshowbackupusageapi(self) -> EbsbackupShowBackupUsageApi:  # noqa
        return self._ebsbackupshowbackupusageapi

    @property  # noqa
    def ebsbackupcreatebackupapi(self) -> EbsbackupCreateBackupApi:  # noqa
        return self._ebsbackupcreatebackupapi

    @property  # noqa
    def ebsbackuprestorebackupapi(self) -> EbsbackupRestoreBackupApi:  # noqa
        return self._ebsbackuprestorebackupapi

    @property  # noqa
    def ebsbackuppolicybinddisksapi(self) -> EbsbackupPolicyBindDisksApi:  # noqa
        return self._ebsbackuppolicybinddisksapi

    @property  # noqa
    def ebsbackuppolicyunbinddisksapi(self) -> EbsbackupPolicyUnbindDisksApi:  # noqa
        return self._ebsbackuppolicyunbinddisksapi

    @property  # noqa
    def ebsbackuplistbackuptaskapi(self) -> EbsbackupListBackupTaskApi:  # noqa
        return self._ebsbackuplistbackuptaskapi

    @property  # noqa
    def ebsbackupcancelbackuptaskapi(self) -> EbsbackupCancelBackupTaskApi:  # noqa
        return self._ebsbackupcancelbackuptaskapi

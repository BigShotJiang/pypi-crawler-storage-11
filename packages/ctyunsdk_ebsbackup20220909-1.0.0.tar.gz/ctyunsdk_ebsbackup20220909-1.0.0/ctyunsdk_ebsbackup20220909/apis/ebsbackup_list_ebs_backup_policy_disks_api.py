from typing import List, Optional, Dict, Any
from ctyunsdk_ebsbackup20220909.core.client import CtyunClient
from ctyunsdk_ebsbackup20220909.core.credential import Credential
from ctyunsdk_ebsbackup20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsbackupListEbsBackupPolicyDisksRequest:
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span> <a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    policyID: str  # 备份策略ID
    pageNo: Any  # 页码，默认1
    pageSize: Any  # 每页显示条目，默认10
    diskID: Optional[str]  # 云硬盘ID
    diskName: Optional[str]  # 云硬盘名称，模糊过滤，指定diskID时，该参数无效


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsbackupListEbsBackupPolicyDisksReturnObjDiskListResponse:
    diskID: Optional[str]  # 云硬盘ID
    diskName: Optional[str]  # 云硬盘名称
    diskSize: Optional[int]  # 云硬盘大小，单位GB
    diskStatus: Optional[str]  # 云硬盘使用状态 available、in-use等，具体请参考[云硬盘使用状态](https://www.ctyun.cn/document/10027696/10168629)
    diskType: Optional[str]  # 云硬盘类型 SATA/SAS/SSD/FAST-SSD
    diskMode: Optional[str]  # 云硬盘模式 VBD/ISCSI/FCSAN
    createdTime: Optional[int]  # 创建时间
    expiredTime: Optional[int]  # 过期时间
    instanceID: Optional[str]  # 云硬盘挂载的云主机ID
    instanceName: Optional[str]  # 云硬盘挂载的云主机名称


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListEbsBackupPolicyDisksReturnObjDiskListResponse']:
        if not json_data:
            return None
        obj = EbsbackupListEbsBackupPolicyDisksReturnObjDiskListResponse(
            diskID=json_data.get('diskID'),
            diskName=json_data.get('diskName'),
            diskSize=json_data.get('diskSize'),
            diskStatus=json_data.get('diskStatus'),
            diskType=json_data.get('diskType'),
            diskMode=json_data.get('diskMode'),
            createdTime=json_data.get('createdTime'),
            expiredTime=json_data.get('expiredTime'),
            instanceID=json_data.get('instanceID'),
            instanceName=json_data.get('instanceName')
        )

        return obj

@dataclass
class EbsbackupListEbsBackupPolicyDisksReturnObjResponse:
    """返回对象"""
    diskList: Optional[List[Optional[EbsbackupListEbsBackupPolicyDisksReturnObjDiskListResponse]]]  # 云硬盘列表
    totalCount: Optional[int]  # 云硬盘总数
    currentCount: Optional[int]  # 当前页云硬盘数


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListEbsBackupPolicyDisksReturnObjResponse']:
        if not json_data:
            return None
        obj = EbsbackupListEbsBackupPolicyDisksReturnObjResponse(
            diskList=[EbsbackupListEbsBackupPolicyDisksReturnObjDiskListResponse.from_json(item) for item in json_data.get('diskList', [])],
            totalCount=json_data.get('totalCount'),
            currentCount=json_data.get('currentCount')
        )

        return obj

@dataclass
class EbsbackupListEbsBackupPolicyDisksResponse:
    statusCode: Any  # 返回状态码（800为成功，900为失败）
    message: Optional[str]  # 错误信息的英文描述
    description: Optional[str]  # 错误信息的本地化描述（中文）
    returnObj: Optional[EbsbackupListEbsBackupPolicyDisksReturnObjResponse]  # 返回对象
    errorCode: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码
    error: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListEbsBackupPolicyDisksResponse']:
        if not json_data:
            return None
        obj = EbsbackupListEbsBackupPolicyDisksResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=EbsbackupListEbsBackupPolicyDisksReturnObjResponse.from_json(json_data.get('returnObj')) if json_data.get('returnObj') else None,
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error')
        )

        return obj


# 查询云硬盘备份策略绑定的云硬盘列表
class EbsbackupListEbsBackupPolicyDisksApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsbackupListEbsBackupPolicyDisksRequest) -> EbsbackupListEbsBackupPolicyDisksResponse:
        url = endpoint + "/v4/ebs-backup/policy/list-disks"
        params = {'regionID':request.regionID, 'policyID':request.policyID, 'pageNo':request.pageNo, 'pageSize':request.pageSize, 'diskID':request.diskID, 'diskName':request.diskName}
        try:
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.get(url=url, params=params, header_params=request_dict, credential=credential)
            return EbsbackupListEbsBackupPolicyDisksResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

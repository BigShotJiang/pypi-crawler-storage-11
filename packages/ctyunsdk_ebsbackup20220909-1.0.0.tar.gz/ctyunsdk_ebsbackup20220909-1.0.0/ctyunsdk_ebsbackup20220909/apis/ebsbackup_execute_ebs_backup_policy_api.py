from typing import List, Optional, Dict, Any
from ctyunsdk_ebsbackup20220909.core.client import CtyunClient
from ctyunsdk_ebsbackup20220909.core.credential import Credential
from ctyunsdk_ebsbackup20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsbackupExecuteEbsBackupPolicyRequest:
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span> <a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    policyID: str  # 备份策略ID，您可以通过<a href="https://www.ctyun.cn/document/10026752/10040084">查询备份策略</a>获取
    fullBackup: Optional[bool]  # 是否启用全量备份，若启用，本次立即备份执行的备份类型为全量备份。取值范围：; ●true：是; ●false：否


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsbackupExecuteEbsBackupPolicyReturnObjResponse:
    """无实际对象返回，值为{}"""
    pass  # 空类占位符

    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupExecuteEbsBackupPolicyReturnObjResponse']:
        if not json_data:
            return None
        obj = EbsbackupExecuteEbsBackupPolicyReturnObjResponse()

        return obj

@dataclass
class EbsbackupExecuteEbsBackupPolicyResponse:
    statusCode: Any  # 返回状态码（800为成功，900为失败）
    message: Optional[str]  # 错误信息的英文描述
    description: Optional[str]  # 错误信息的本地化描述（中文）
    returnObj: Optional[EbsbackupExecuteEbsBackupPolicyReturnObjResponse]  # 无实际对象返回，值为{}
    errorCode: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码
    error: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupExecuteEbsBackupPolicyResponse']:
        if not json_data:
            return None
        obj = EbsbackupExecuteEbsBackupPolicyResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=EbsbackupExecuteEbsBackupPolicyReturnObjResponse.from_json(json_data.get('returnObj', {})),
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error')
        )

        return obj


# 立即执行备份策略，所有绑定了该备份策略的云硬盘会立刻执行一次备份。
class EbsbackupExecuteEbsBackupPolicyApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsbackupExecuteEbsBackupPolicyRequest) -> EbsbackupExecuteEbsBackupPolicyResponse:
        url = endpoint + "/v4/ebs-backup/policy/execute"
        params = {}
        try:
            header_params = {}
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.post(url=url, params=params, header_params=header_params, data=request_dict, credential=credential)
            return EbsbackupExecuteEbsBackupPolicyResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

from typing import List, Optional, Dict, Any
from ctyunsdk_ebsbackup20220909.core.client import CtyunClient
from ctyunsdk_ebsbackup20220909.core.credential import Credential
from ctyunsdk_ebsbackup20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsbackupResizeRepoRequest:
    clientToken: str  # 用于保证订单幂等性。要求单个云平台账户内唯一。使用同一个ClientToken值，其他请求参数相同时，则代表为同一个请求
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span> <a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    repositoryID: str  # 云硬盘备份存储库ID，您可以通过<a href="https://www.ctyun.cn/document/10026752/10039480">查询存储库列表</a>获取
    size: int  # 云硬盘备份存储库容量，单位GB，取值100-1024000


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsbackupResizeRepoReturnObjResponse:
    """业务错误细分码，发生错误时返回，为product.module.code三段式码"""
    masterOrderID: Optional[str]  # 订单ID。调用方在拿到masterOrderID之后，在若干错误情况下，可以使用materOrderID进一步确认订单状态及资源状态
    masterOrderNO: Optional[str]  # 订单号
    regionID: Optional[str]  # 资源所属资源池ID


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupResizeRepoReturnObjResponse']:
        if not json_data:
            return None
        obj = EbsbackupResizeRepoReturnObjResponse(
            json_data.get('masterOrderID'),
            json_data.get('masterOrderNO'),
            json_data.get('regionID')
        )

        return obj

@dataclass
class EbsbackupResizeRepoResponse:
    statusCode: Any  # 返回状态码（800为成功，900为失败）
    message: Optional[str]  # 错误信息的英文描述
    description: Optional[str]  # 错误信息的本地化描述（中文）
    errorCode: Optional[str]  # 业务错误细分码，发生错误时返回
    returnObj: Optional[EbsbackupResizeRepoReturnObjResponse]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码
    error: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupResizeRepoResponse']:
        if not json_data:
            return None
        obj = EbsbackupResizeRepoResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            errorCode=json_data.get('errorCode'),
            returnObj=EbsbackupResizeRepoReturnObjResponse.from_json(json_data.get('returnObj')) if json_data.get('returnObj') else None,
            error=json_data.get('error')
        )

        return obj


# 扩容云硬盘备份存储库，该接口会涉及计费<br />
# <b>准备工作：</b><br />
# 计费模式：确认扩容存储库的计费模式，详细查看<a href="https://www.ctyun.cn/document/10026730/10030877">计费模式</a><br />
class EbsbackupResizeRepoApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsbackupResizeRepoRequest) -> EbsbackupResizeRepoResponse:
        url = endpoint + "/v4/ebs-backup/repo/resize"
        params = {}
        try:
            header_params = {}
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.post(url=url, params=params, header_params=header_params, data=request_dict, credential=credential)
            return EbsbackupResizeRepoResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

from typing import List, Optional, Dict, Any
from ctyunsdk_ebsbackup20220909.core.client import CtyunClient
from ctyunsdk_ebsbackup20220909.core.credential import Credential
from ctyunsdk_ebsbackup20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsbackupListBackupRepoRequest:
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span> <a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    repositoryName: Optional[str]  = None # 云硬盘备份存储库名称。
    repositoryID: Optional[str]  = None # 云硬盘备份存储库ID。
    status: Optional[str] = None # 云硬盘备份存储库状态，取值范围：; ●active：可用。; ●master_order_creating：主订单未完成。; ●freezing：已冻结。; ●expired：已过期。
    hideExpire: Optional[bool] = None # 是否隐藏过期的云硬盘备份存储库。
    queryContent: Optional[str] = None # 模糊查询，目前仅支持备份存储库名称的过滤。
    pageNo: Optional[int]  = None # 页码，默认为1。
    pageSize: Optional[int] = None # 每页记录数目 ,默认为10。
    asc: Optional[bool]  = None # 和sort配合使用，是否是升序排列。
    sort: Optional[str]  = None# 和asc配合使用，指定用于排序的字段。可选字段：; ●createdTime：创建时间。; ●expiredTime：过期时间。; ●size：存储库空间大小。; ●freeSize：存储库剩余空间。; ●usedSize：存储库已使用空间大小。; ●repositoryName：存储库名称。
    projectID: Optional[str] = None # 企业项目ID，企业项目管理服务提供统一的云资源按企业项目管理，以及企业项目内的资源管理，成员管理。您可以通过查看<a href="https://www.ctyun.cn/document/10026730/10238876">创建企业项目</a>了解如何创建企业项目<br />注：默认值为"0"


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsbackupListBackupRepoReturnObjRepositoryListResponse:
    regionID: Optional[str]  # 资源池ID。
    repositoryID: Optional[str]  # 备份存储库ID。
    repositoryName: Optional[str]  # 备份存储库名称。
    status: Optional[str]  # 云硬盘备份存储库状态，取值范围：; ●active：可用。; ●master_order_creating：主订单未完成。; ●freezing：已冻结。; ●expired：已过期。
    size: int  # 云硬盘备份存储库总容量，单位为GB。
    freeSize: float  # 云硬盘备份存储库剩余大小，单位为GB。
    usedSize: float  # 云硬盘备份存储库使用大小，单位为GB。
    createdTime: int  # 存储库创建时间。
    expiredTime: int  # 存储库到期时间。
    expired: Optional[bool]  # 备份存储库是否到期。
    freeze: Optional[bool]  # 存储库是否冻结。
    paas: Optional[bool]  # 是否支持PAAS。
    backupList: Optional[List[Optional[str]]]  # 备份存储库下的可用的备份列表，元素为备份ID。
    projectID: Optional[str]  # 企业项目ID。
    onDemand: Optional[bool]  # 存储库是否是按需。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupRepoReturnObjRepositoryListResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupRepoReturnObjRepositoryListResponse(
            regionID=json_data.get("regionID"),
            repositoryID=json_data.get("repositoryID"),
            repositoryName=json_data.get("repositoryName"),
            status=json_data.get("status"),
            size=json_data.get("size"),
            freeSize=json_data.get("freeSize"),
            usedSize=json_data.get("usedSize"),
            createdTime=json_data.get("createdTime"),
            expiredTime=json_data.get("expiredTime"),
            expired=json_data.get("expired"),
            freeze=json_data.get("freeze"),
            paas=json_data.get("paas"),
            backupList=json_data.get("backupList"),
            projectID=json_data.get("projectID"),
            onDemand=json_data.get("onDemand")
        )

        return obj

@dataclass
class EbsbackupListBackupRepoReturnObjResponse:
    """返回对象数组。"""
    repositoryList: Optional[List[Optional[EbsbackupListBackupRepoReturnObjRepositoryListResponse]]]  # 云硬盘备份存储库列表。
    totalCount: int  # 云硬盘备份存储库总数。
    currentCount: int  # 当前页云硬盘备份存储库数。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupRepoReturnObjResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupRepoReturnObjResponse(
            repositoryList=[EbsbackupListBackupRepoReturnObjRepositoryListResponse.from_json(item) for item in json_data.get("repositoryList", [])],
            totalCount=json_data.get("totalCount"),
            currentCount=json_data.get("currentCount")
        )

        return obj

@dataclass
class EbsbackupListBackupRepoResponse:
    statusCode: Any  # 返回状态码（800为成功，900为失败）。
    message: Optional[str]  # 成功或失败时的描述，一般为英文描述。
    description: Optional[str]  # 成功或失败时的描述，一般为中文描述。
    returnObj: Optional[EbsbackupListBackupRepoReturnObjResponse]  # 返回对象数组。
    errorCode: Optional[str]  # 业务错误细分码，发生错误时返回。
    error: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupRepoResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupRepoResponse(
            statusCode=json_data.get("statusCode"),
            message=json_data.get("message"),
            description=json_data.get("description"),
            returnObj=EbsbackupListBackupRepoReturnObjResponse.from_json(json_data.get("returnObj")),
            errorCode=json_data.get("errorCode"),
            error=json_data.get("error")
        )

        return obj


# 查询云硬盘备份存储库列表。
class EbsbackupListBackupRepoApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsbackupListBackupRepoRequest) -> EbsbackupListBackupRepoResponse:
        url = endpoint + "/v4/ebs-backup/repo/list-repos"
        params = {'regionID':request.regionID, 'repositoryName':request.repositoryName, 'repositoryID':request.repositoryID, 'status':request.status, 'hideExpire':request.hideExpire, 'queryContent':request.queryContent, 'pageNo':request.pageNo, 'pageSize':request.pageSize, 'asc':request.asc, 'sort':request.sort, 'projectID':request.projectID}
        try:
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.get(url=url, params=params, header_params=request_dict, credential=credential)
            return EbsbackupListBackupRepoResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

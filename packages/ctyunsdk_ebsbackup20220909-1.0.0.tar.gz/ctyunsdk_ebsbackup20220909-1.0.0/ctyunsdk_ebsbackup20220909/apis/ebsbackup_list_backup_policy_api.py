from typing import List, Optional, Dict, Any
from ctyunsdk_ebsbackup20220909.core.client import CtyunClient
from ctyunsdk_ebsbackup20220909.core.credential import Credential
from ctyunsdk_ebsbackup20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsbackupListBackupPolicyRequest:
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span> <a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    pageNo: Any  # 页码，默认值1
    pageSize: Any  # 每页记录数目 ,默认10
    policyID: Optional[str]  # 备份策略ID
    policyName: Optional[str]  # 备份策略名，指定了policyID时，该参数会被忽略
    projectID: Optional[str]  # 企业项目ID，企业项目管理服务提供统一的云资源按企业项目管理，以及企业项目内的资源管理，成员管理。您可以通过查看<a href="https://www.ctyun.cn/document/10026730/10238876">创建企业项目</a>了解如何创建企业项目<br />注：默认值为"0"


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsbackupListBackupPolicyReturnObjPolicyListAdvRetentionResponse:
    """高级保留策略内容。"""
    advDay: Optional[int]  # ● 保留n天内，每天最新的一个备份。; ● 单位为天，取值范围：[0, 100]，默认值0
    advWeek: Optional[int]  # ● 保留n周内，每周最新的一个备份。; ● 单位为周，取值范围：[0, 100]，默认值0
    advMonth: Optional[int]  # ● 保留n月内，每月最新的一个备份。; ● 单位为月，取值范围：[0, 100]，默认值0
    advYear: Optional[int]  # ● 保留n年内，每年最新的一个备份。; ● 单位为年，取值范围：[0, 100]，默认值0


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupPolicyReturnObjPolicyListAdvRetentionResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupPolicyReturnObjPolicyListAdvRetentionResponse(
            advDay=json_data.get('advDay'),
            advWeek=json_data.get('advWeek'),
            advMonth=json_data.get('advMonth'),
            advYear=json_data.get('advYear')
        )

        return obj

@dataclass
class EbsbackupListBackupPolicyReturnObjPolicyListRepositoryListResponse:
    repositoryID: Optional[str]  # 云硬盘备份存储库ID
    repositoryName: Optional[str]  # 云硬盘备份存储库名


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupPolicyReturnObjPolicyListRepositoryListResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupPolicyReturnObjPolicyListRepositoryListResponse(
            repositoryID=json_data.get('repositoryID'),
            repositoryName=json_data.get('repositoryName')
        )

        return obj

@dataclass
class EbsbackupListBackupPolicyReturnObjPolicyListResponse:
    regionID: Optional[str]  # 资源池ID
    accountID: Optional[str]  # 账户ID
    status: Optional[int]  # 状态，0-停用，1-启用
    createdTime: Optional[int]  # 创建时间
    policyID: Optional[str]  # 策略ID
    policyName: Optional[str]  # 策略名
    cycleType: Optional[str]  # 备份周期类型，day-按天备份，week-按星期备份
    cycleDay: Optional[int]  # 备份周期，只有cycleType为day时返回
    cycleWeek: Optional[str]  # 备份周期，只有cycleType为week时返回，则取值范围0-6代表星期日-星期六，如果一周有多天备份，以逗号隔开
    time: Optional[str]  # 备份整点时间，取值范围0-23，如果一天内多个时间节点备份，以逗号隔开
    retentionType: Optional[str]  # 备份保留类型，num-按数量保留，date-按时间保留，all-全部保留
    retentionNum: Optional[int]  # 保留数量，只有retentionType为num时返回
    retentionDay: Optional[int]  # 保留天数，只有retentionType为date时返回
    remainFirstOfCurMonth: Optional[bool]  # 是否保留每个月第一个备份，在retentionType为num时返回
    bindedDiskCount: Optional[int]  # 策略绑定的云硬盘数量
    bindedDiskIDs: Optional[str]  # 策略绑定的云硬盘ID，以逗号分隔
    repositoryList: Optional[List[Optional[EbsbackupListBackupPolicyReturnObjPolicyListRepositoryListResponse]]]  # 策略绑定的云硬盘备份存储库列表
    projectID: Optional[str]  # 企业项目ID
    fullBackupInterval: Optional[int]  # 启用周期性全量备份。-1代表不开启，默认为-1；取值范围为[-1,100]，即每执行n次增量备份后，执行一次全量备份。
    advRetentionStatus: Optional[bool]  # 是否启用高级保留策略，取值范围： ; ●true：启用 ; ●false：不启用
    advRetention: Optional[EbsbackupListBackupPolicyReturnObjPolicyListAdvRetentionResponse]  # 高级保留策略内容。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupPolicyReturnObjPolicyListResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupPolicyReturnObjPolicyListResponse(
            regionID=json_data.get('regionID'),
            accountID=json_data.get('accountID'),
            status=json_data.get('status'),
            createdTime=json_data.get('createdTime'),
            policyID=json_data.get('policyID'),
            policyName=json_data.get('policyName'),
            cycleType=json_data.get('cycleType'),
            cycleDay=json_data.get('cycleDay'),
            cycleWeek=json_data.get('cycleWeek'),
            time=json_data.get('time'),
            retentionType=json_data.get('retentionType'),
            retentionNum=json_data.get('retentionNum'),
            retentionDay=json_data.get('retentionDay'),
            remainFirstOfCurMonth=json_data.get('remainFirstOfCurMonth'),
            bindedDiskCount=json_data.get('bindedDiskCount'),
            bindedDiskIDs=json_data.get('bindedDiskIDs'),
            repositoryList=[EbsbackupListBackupPolicyReturnObjPolicyListRepositoryListResponse.from_json(item) for item in json_data.get('repositoryList', [])],
            projectID=json_data.get('projectID'),
            fullBackupInterval=json_data.get('fullBackupInterval'),
            advRetentionStatus=json_data.get('advRetentionStatus'),
            advRetention=EbsbackupListBackupPolicyReturnObjPolicyListAdvRetentionResponse.from_json(json_data.get('advRetention'))
        )

        return obj

@dataclass
class EbsbackupListBackupPolicyReturnObjResponse:
    """返回对象"""
    policyList: Optional[List[Optional[EbsbackupListBackupPolicyReturnObjPolicyListResponse]]]  # 策略列表
    totalCount: Optional[int]  # 策略总数
    currentCount: Optional[int]  # 当前页策略数


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupPolicyReturnObjResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupPolicyReturnObjResponse(
            policyList=[EbsbackupListBackupPolicyReturnObjPolicyListResponse.from_json(item) for item in json_data.get('policyList', [])],
            totalCount=json_data.get('totalCount'),
            currentCount=json_data.get('currentCount')
        )

        return obj

@dataclass
class EbsbackupListBackupPolicyResponse:
    statusCode: Any  # 返回状态码（800为成功，900为失败）
    message: Optional[str]  # 错误信息的英文描述
    description: Optional[str]  # 错误信息的本地化描述（中文）
    returnObj: Optional[EbsbackupListBackupPolicyReturnObjResponse]  # 返回对象
    errorCode: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码
    error: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupPolicyResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupPolicyResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=EbsbackupListBackupPolicyReturnObjResponse.from_json(json_data.get('returnObj')),
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error')
        )

        return obj


# 查询云硬盘备份策略列表。
class EbsbackupListBackupPolicyApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsbackupListBackupPolicyRequest) -> EbsbackupListBackupPolicyResponse:
        url = endpoint + "/v4/ebs-backup/policy/list-policies"
        params = {'regionID':request.regionID, 'pageNo':request.pageNo, 'pageSize':request.pageSize, 'policyID':request.policyID, 'policyName':request.policyName, 'projectID':request.projectID}
        try:
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.get(url=url, params=params, header_params=request_dict, credential=credential)
            return EbsbackupListBackupPolicyResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

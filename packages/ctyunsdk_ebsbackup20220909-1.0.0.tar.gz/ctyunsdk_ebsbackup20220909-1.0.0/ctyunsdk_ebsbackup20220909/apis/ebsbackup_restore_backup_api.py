from typing import List, Optional, Dict, Any
from ctyunsdk_ebsbackup20220909.core.client import CtyunClient
from ctyunsdk_ebsbackup20220909.core.credential import Credential
from ctyunsdk_ebsbackup20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsbackupRestoreBackupRequest:
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span> <a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    backupID: str  # 云硬盘备份ID，您可以通过<a href="https://www.ctyun.cn/document/10026752/10039050">查询云硬盘备份列表</a>获取
    diskID: str  # 云硬盘ID，您可以通过<a href="https://www.ctyun.cn/document/10027696/10096187">查询云硬盘列表</a>获取


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}



@dataclass
class EbsbackupRestoreBackupReturnObjResponse:
    """无实际对象返回，值为{}"""
    taskID: Optional[str]  # 恢复任务ID


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupRestoreBackupReturnObjResponse']:
        if not json_data:
            return None
        obj = EbsbackupRestoreBackupReturnObjResponse(
            taskID=json_data.get('taskID'),
        )

        return obj

@dataclass
class EbsbackupRestoreBackupResponse:
    statusCode: Any  # 返回状态码（800为成功，900为失败）
    message: Optional[str]  # 错误信息的英文描述
    description: Optional[str]  # 错误信息的本地化描述（中文）
    returnObj: Optional[EbsbackupRestoreBackupReturnObjResponse]  # 无实际对象返回，值为{}
    errorCode: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码
    error: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupRestoreBackupResponse']:
        if not json_data:
            return None
        obj = EbsbackupRestoreBackupResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=EbsbackupRestoreBackupReturnObjResponse.from_json(json_data.get('returnObj')) if json_data.get('returnObj') else None,
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error')
        )

        return obj


# 恢复云硬盘备份。
class EbsbackupRestoreBackupApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsbackupRestoreBackupRequest) -> EbsbackupRestoreBackupResponse:
        url = endpoint + "/v4/ebs-backup/restore-backup"
        params = {}
        try:
            header_params = {}
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.post(url=url, params=params, header_params=header_params, data=request_dict, credential=credential)
            return EbsbackupRestoreBackupResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

from typing import List, Optional, Dict, Any
from ctyunsdk_ebsbackup20220909.core.client import CtyunClient
from ctyunsdk_ebsbackup20220909.core.credential import Credential
from ctyunsdk_ebsbackup20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsbackupListEbsBackupPolicyTasksRequest:
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span> <a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    policyID: str  # 备份策略ID，您可以通过<a href="https://www.ctyun.cn/document/10026752/10040084">查询备份策略</a>获取
    pageNo: Any  # 页码，默认值1
    pageSize: Any  # 每页记录数目 ,默认10
    asc: Optional[bool]  # 和sort配合使用，是否升序排列，默认降序
    sort: Optional[str]  # 和asc配合使用，指定用于排序的字段。可选字段：createdTime/completedTime，默认createdTime
    taskStatus: Optional[int]  # 备份任务状态，-1-失败，0-执行中，1-成功


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsbackupListEbsBackupPolicyTasksReturnObjTaskListResponse:
    taskID: Optional[str]  # 备份任务ID
    taskStatus: Any  # 备份任务状态，-1-失败，0-执行中，1-成功
    diskID: Optional[str]  # 云硬盘ID
    diskName: Optional[str]  # 云硬盘名称
    backupName: Optional[str]  # 云硬盘备份名称
    createdTime: Optional[int] # 创建时间
    completedTime: Optional[int]  # 完成时间


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListEbsBackupPolicyTasksReturnObjTaskListResponse']:
        if not json_data:
            return None
        obj = EbsbackupListEbsBackupPolicyTasksReturnObjTaskListResponse(
            taskID=json_data.get('taskID'),
            taskStatus=json_data.get('taskStatus'),
            diskID=json_data.get('diskID'),
            diskName=json_data.get('diskName'),
            backupName=json_data.get('backupName'),
            createdTime=json_data.get('createdTime'),
            completedTime=json_data.get('completedTime')
        )

        return obj

@dataclass
class EbsbackupListEbsBackupPolicyTasksReturnObjResponse:
    """返回对象"""
    taskList: Optional[List[Optional[EbsbackupListEbsBackupPolicyTasksReturnObjTaskListResponse]]]  # 备份任务列表
    totalCount: Optional[int]  # 备份任务总数
    currentCount: Optional[int]  # 当前页备份任务数


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListEbsBackupPolicyTasksReturnObjResponse']:
        if not json_data:
            return None
        obj = EbsbackupListEbsBackupPolicyTasksReturnObjResponse(
            taskList=[EbsbackupListEbsBackupPolicyTasksReturnObjTaskListResponse.from_json(item) for item in json_data.get('taskList', [])],
            totalCount=json_data.get('totalCount'),
            currentCount=json_data.get('currentCount')
        )

        return obj

@dataclass
class EbsbackupListEbsBackupPolicyTasksResponse:
    statusCode: Any  # 返回状态码（800为成功，900为失败）
    message: Optional[str]  # 错误信息的英文描述
    description: Optional[str]  # 错误信息的本地化描述（中文）
    returnObj: Optional[EbsbackupListEbsBackupPolicyTasksReturnObjResponse]  # 返回对象
    errorCode: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码
    error: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListEbsBackupPolicyTasksResponse']:
        if not json_data:
            return None
        obj = EbsbackupListEbsBackupPolicyTasksResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=EbsbackupListEbsBackupPolicyTasksReturnObjResponse.from_json(json_data.get('returnObj')),
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error')
        )

        return obj


# 查询备份策略创建的备份任务列表
class EbsbackupListEbsBackupPolicyTasksApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsbackupListEbsBackupPolicyTasksRequest) -> EbsbackupListEbsBackupPolicyTasksResponse:
        url = endpoint + "/v4/ebs-backup/policy/list-tasks"
        params = {'regionID':request.regionID, 'policyID':request.policyID, 'pageNo':request.pageNo, 'pageSize':request.pageSize, 'asc':request.asc, 'sort':request.sort, 'taskStatus':request.taskStatus}
        try:
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.get(url=url, params=params, header_params=request_dict, credential=credential)
            return EbsbackupListEbsBackupPolicyTasksResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

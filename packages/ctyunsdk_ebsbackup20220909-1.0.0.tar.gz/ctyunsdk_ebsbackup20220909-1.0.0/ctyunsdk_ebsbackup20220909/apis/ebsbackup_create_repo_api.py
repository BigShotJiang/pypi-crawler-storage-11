from typing import List, Optional, Dict, Any
from ctyunsdk_ebsbackup20220909.core.client import CtyunClient
from ctyunsdk_ebsbackup20220909.core.credential import Credential
from ctyunsdk_ebsbackup20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsbackupCreateRepoRequest:
    clientToken: str  # 用于保证订单幂等性。要求单个云平台账户内唯一。使用同一个ClientToken值，其他请求参数相同时，则代表为同一个请求。
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span> <a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    repositoryName: str  # 云硬盘备份存储库名称，长度为 2~32 个字符，只能由数字、字母、- 组成，不能以数字、- 开头，且不能以 - 结尾。
    size: int  # 云硬盘备份存储库容量，单位为GB，取值范围：100-1024000，默认为100。
    onDemand: Optional[bool] =None # 是否按需下单，取值范围：; true：是; false：否; 默认为false。
    cycleType: Optional[str]  =None# 表示订购周期类型 ，取值范围：; MONTH：按月; YEAR：按年; onDemand为false时，必须指定该参数。
    cycleCount: Optional[int] = None # 订购时长，最大为3年（36个月），与cycleType配合使用。; cycleType为MONTH时，单位为月，cycleType为YEAR时，单位为年。
    autoRenewStatus: Optional[int] = None # 本参数表示是否自动续订 ，只有onDemand为false时生效。取值范围：; 0：不续费; 1：自动续费; 默认不自动续费，如果选择自动续费：; 按月购买：自动续订周期为3个月。; 按年购买：自动续订周期为1年。
    projectID: Optional[str] = None # 企业项目ID，企业项目管理服务提供统一的云资源按企业项目管理，以及企业项目内的资源管理，成员管理。您可以通过查看<a href="https://www.ctyun.cn/document/10026730/10238876">创建企业项目</a>了解如何创建企业项目<br />注：默认值为"0"


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsbackupCreateRepoReturnObjResponse:
    """业务错误细分码，发生错误时返回，为product.module.code三段式码。"""
    masterOrderID: Optional[str]  # 订单ID。调用方在拿到masterOrderID之后，在若干错误情况下，可以使用materOrderID进一步确认订单状态及资源状态。
    masterOrderNO: Optional[str]  # 订单号，可根据订单号查询具体资源ID。
    regionID: Optional[str]  # 资源所属资源池ID。
    RepositoryID: Optional[str]  # 云硬盘备份存储库ID。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupCreateRepoReturnObjResponse']:
        if not json_data:
            return None
        obj = EbsbackupCreateRepoReturnObjResponse(
            masterOrderID=json_data.get('masterOrderID'),
            masterOrderNO=json_data.get('masterOrderNO'),
            regionID=json_data.get('regionID'),
            RepositoryID=json_data.get('repositoryID')
        )
        return obj

@dataclass
class EbsbackupCreateRepoResponse:
    statusCode: Any  # 返回状态码（800为成功，900为失败）。
    message: Optional[str]  # 错误信息的英文描述。
    description: Optional[str]  # 错误信息的本地化描述（中文）。
    errorCode: Optional[str]  # 业务错误细分码，发生错误时返回。
    returnObj: Optional[EbsbackupCreateRepoReturnObjResponse]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码。
    error: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupCreateRepoResponse']:
        if not json_data:
            return None
        obj = EbsbackupCreateRepoResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            errorCode=json_data.get('errorCode'),
            returnObj=EbsbackupCreateRepoReturnObjResponse.from_json(json_data.get('returnObj')) if json_data.get('returnObj') else None,
            error=json_data.get('error')
        )

        return obj


# 创建云硬盘备份存储库，该接口会涉及计费<br />
# <b>准备工作：</b><br />
# 构造请求：在调用前需要了解如何构造请求，详情查看构造请求<br />
# 认证鉴权：openapi请求需要进行加密调用，详细查看认证鉴权<br />
# 计费模式：确认创建云硬盘备份存储库的计费模式，详细查看<a href="https://www.ctyun.cn/document/10026730/10030877">计费模式</a><br />
# 地域选择：选择创建云硬盘备份存储库的资源池，详细查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a><br />
# 产品选型：创建云硬盘备份存储库前，请先阅读<a href="https://www.ctyun.cn/document/10026752/10037454">入门流程</a>了解云硬盘备份的基本信息，以及操作步骤
class EbsbackupCreateRepoApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsbackupCreateRepoRequest) -> EbsbackupCreateRepoResponse:
        url = endpoint + "/v4/ebs-backup/repo/create"
        params = {}
        try:
            header_params = {}
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.post(url=url, params=params, header_params=header_params, data=request_dict, credential=credential)
            return EbsbackupCreateRepoResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

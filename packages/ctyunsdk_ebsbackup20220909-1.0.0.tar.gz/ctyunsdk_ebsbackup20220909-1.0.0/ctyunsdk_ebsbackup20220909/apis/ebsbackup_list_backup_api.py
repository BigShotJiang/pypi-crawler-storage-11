from typing import List, Optional, Dict, Any
from ctyunsdk_ebsbackup20220909.core.client import CtyunClient
from ctyunsdk_ebsbackup20220909.core.credential import Credential
from ctyunsdk_ebsbackup20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsbackupListBackupRequest:
    regionID: str  # 资源池ID，您可以查看<a href="https://www.ctyun.cn/document/10026730/10028695">地域和可用区</a>来了解资源池 <br />获取：<br /><span style="background-color: rgb(73, 204, 144);color: rgb(255,255,255);padding: 2px; margin:2px">查</span> <a  href="https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=5851&data=87">资源池列表查询</a>
    diskID: Optional[str]  # 云硬盘ID。
    diskName: Optional[str]  # 云硬盘名称。
    backupName: Optional[str]  # 云硬盘备份名称。
    repositoryID: Optional[str]  # 云硬盘备份存储库ID。
    backupStatus: Optional[str]  # 云硬盘备份状态，取值范围：; ●available：可用。; ●error：错误。; ●restoring：恢复中。; ●creating：创建中。; ●deleting：删除中。; ●merging_backup：合并中。; ●frozen：已冻结。
    queryContent: Optional[str]  # 该参数，可用于模糊过滤 云硬盘ID/云硬盘名称/备份ID/备份名称，即上述4个字段如果包含该参数的值，则会被过滤出来。
    pageNo: Any  # 页码，默认1。
    pageSize: Any  # 每页记录数目，默认10。
    projectID: Optional[str]  # 企业项目ID，企业项目管理服务提供统一的云资源按企业项目管理，以及企业项目内的资源管理，成员管理。您可以通过查看<a href="https://www.ctyun.cn/document/10026730/10238876">创建企业项目</a>了解如何创建企业项目<br />注：默认值为"0"


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}



@dataclass
class EbsbackupListBackupReturnObjBackupListResponse:
    regionID: Optional[str]  # 资源池ID。
    backupID: Optional[str]  # 云硬盘备份ID。
    backupName: Optional[str]  # 云硬盘备份名称。
    backupStatus: Optional[str]  # 云硬盘备份状态，取值范围：; ●available：可用。; ●error：错误。; ●restoring：恢复中。; ●creating：创建中。; ●deleting：删除中。; ●merging_backup：合并中。; ●frozen：已冻结。
    diskSize: Optional[int]  # 云硬盘大小，单位GB。
    backupSize: Optional[int]  # 云硬盘备份大小，单位Byte。
    description: Optional[str]  # 云硬盘备份描述。
    repositoryID: Optional[str]  # 备份存储库ID。
    repositoryName: Optional[str]  # 备份存储库名称。
    createdTime: Optional[int]  # 备份创建时间。
    updatedTime: Optional[int]  # 备份更新时间。
    finishedTime: Optional[int]  # 备份完成时间。
    restoredTime: Optional[int]  # 使用该云硬盘备份恢复数据时间。
    restoreFinishedTime: Optional[int]  # 使用该云硬盘备份恢复完成时间。
    freeze: Optional[bool]  # 备份是否冻结。
    diskID: Optional[str]  # 云硬盘ID。
    diskName: Optional[str]  # 云硬盘名称。
    encrypted: Optional[bool]  # 云硬盘是否加密。
    diskType: Optional[str]  # 磁盘规格类型，取值为：; ●SATA：普通IO。 ; ●SAS：高IO。; ●SSD：超高IO。 ; ●FAST-SSD：极速型SSD。 ; ●XSSD-0、XSSD-1、XSSD-2：X系列云硬盘。
    instanceID: Optional[str]  # 云硬盘挂载的云主机ID。
    instanceName: Optional[str]  # 云硬盘挂载的云主机名称。
    projectID: Optional[str]  # 企业项目ID。
    backupType: Optional[str]  # 备份类型，取值范围：; ●full-backup：全量备份; ●incremental-backup：增量备份


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupReturnObjBackupListResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupReturnObjBackupListResponse(
            regionID=json_data.get('regionID'),
            backupID=json_data.get('backupID'),
            backupName=json_data.get('backupName'),
            backupStatus=json_data.get('backupStatus'),
            diskSize=json_data.get('diskSize'),
            backupSize=json_data.get('backupSize'),
            description=json_data.get('description'),
            repositoryID=json_data.get('repositoryID'),
            repositoryName=json_data.get('repositoryName'),
            createdTime=json_data.get('createdTime'),
            updatedTime=json_data.get('updatedTime'),
            finishedTime=json_data.get('finishedTime'),
            restoredTime=json_data.get('restoredTime'),
            restoreFinishedTime=json_data.get('restoreFinishedTime'),
            freeze=json_data.get('freeze'),
            diskID=json_data.get('diskID'),
            diskName=json_data.get('diskName'),
            encrypted=json_data.get('encrypted'),
            diskType=json_data.get('diskType'),
            instanceID=json_data.get('instanceID'),
            instanceName=json_data.get('instanceName'),
            projectID=json_data.get('projectID'),
            backupType=json_data.get('backupType')
        )

        return obj

@dataclass
class EbsbackupListBackupReturnObjResponse:
    """返回对象。"""
    backupList: Optional[List[Optional[EbsbackupListBackupReturnObjBackupListResponse]]]  # 云硬盘备份列表。
    totalCount: int  # 云硬盘备份总数。
    currentCount: int  # 当前页云硬盘备份数。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupReturnObjResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupReturnObjResponse(
            backupList=[EbsbackupListBackupReturnObjBackupListResponse.from_json(item) for item in json_data.get('backupList', [])],
            totalCount=json_data.get('totalCount'),
            currentCount=json_data.get('currentCount')
        )

        return obj

@dataclass
class EbsbackupListBackupResponse:
    statusCode: Any  # 返回状态码（800为成功，900为失败）。
    message: Optional[str]  # 成功或失败时的描述，一般为英文描述。
    description: Optional[str]  # 成功或失败时的描述，一般为中文描述。
    returnObj: Optional[EbsbackupListBackupReturnObjResponse]  # 返回对象。
    errorCode: Optional[str]  # 参考错误码。
    error: Optional[str]  # 业务错误细分码，发生错误时返回，为product.module.code三段式码。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsbackupListBackupResponse']:
        if not json_data:
            return None
        obj = EbsbackupListBackupResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=EbsbackupListBackupReturnObjResponse.from_json(json_data.get('returnObj')) if json_data.get('returnObj') else None,
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error')
        )

        return obj


# 查询云硬盘备份列表。
class EbsbackupListBackupApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsbackupListBackupRequest) -> EbsbackupListBackupResponse:
        url = endpoint + "/v4/ebs-backup/list-backups"
        params = {'regionID':request.regionID, 'diskID':request.diskID, 'diskName':request.diskName, 'backupName':request.backupName, 'repositoryID':request.repositoryID, 'backupStatus':request.backupStatus, 'queryContent':request.queryContent, 'pageNo':request.pageNo, 'pageSize':request.pageSize, 'projectID':request.projectID}
        try:
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.get(url=url, params=params, header_params=request_dict, credential=credential)
            return EbsbackupListBackupResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

from .base import InstructionBase
from ..base.tools import logger
from ..produce import DefaultProduce
from ...output import obj2str


class DebugStorageFlushInstruction(InstructionBase):
    head = '$<<'
    produce_cls = DefaultProduce

    def run(self, variables, storage):
        typed = 'debug'
        if self.value_raw is not None:
            typed = self.value_raw
        prefix = ""
        if self.key:
            prefix = f"{self.key}: "
        getattr(logger, typed)(prefix + obj2str(storage.value))
        return []


class StorageFlushInstruction(InstructionBase):
    head = '$<'
    produce_cls = DefaultProduce

    def run(self, variables, storage):
        if self.value is None:
            reset = True
        else:
            reset = self.instruction_set.eval_expression(None, self.value, variables)
        return [storage.flush(self.produce_cls.wrapper(self.key), reset)]


class VarStorageFlushInstruction(InstructionBase):
    head = '$$<'
    produce_cls = DefaultProduce

    def run(self, variables, storage):
        if self.value is None:
            reset = True
        else:
            reset = self.instruction_set.eval_expression(None, self.value, variables)
        if self.key in storage.value:
            name = storage.value[self.key]
        else:
            name = self.instruction_set.eval_expression(None, self.key, variables)
        return [storage.flush(self.produce_cls.wrapper(name), reset)]

import unicodedata

def keyCreation (key,salt,sugar):
    """_summary_

    Args:
        key (string): main key
        salt (string): add more unique values to the key
        sugar (string): add more unique values to the key

    Returns:
        list: trueKey  
    """

    #merging the key with cross method
    originalKeyList = list(key)
    saltList = list(salt)
    sugarList = list(sugar)

    originalKeyEmpty = False
    saltEmpty = False
    sugarEmpty = False

    generationIter = 0
    originalKeyIndex = 0
    saltIndex = 0
    sugarIndex = 0

    keyList = []

    while(True):

        if generationIter == 0 and originalKeyEmpty == False:
            if originalKeyIndex> len(originalKeyList) - 1 :
                originalKeyEmpty = True
                generationIter += 1
            else:
                keyList.append(originalKeyList[originalKeyIndex])
                originalKeyIndex += 1

        if generationIter == 1:
            if saltIndex > len(saltList) - 1 :
                saltEmpty = True
                generationIter += 1
            else:
                keyList.append(saltList[saltIndex])
                saltIndex += 1

        if generationIter == 2:
            if sugarIndex > len(sugarList) - 1 :
                sugarEmpty = True
            else:
                keyList.append(sugarList[sugarIndex])
                sugarIndex += 1

        generationIter += 1

        if generationIter > 2:
            generationIter = 0

        if originalKeyEmpty == True and saltEmpty == True and sugarEmpty == True:
            break
    
    keyListIndex = []
    
    unicodedatass = loadUnicodedata()
    for i in keyList:
        if i in unicodedatass:
            keyListIndex.append(unicodedatass.index(i))
        else:
            print("WARNING, Unknown Symbol")
            break

    #parental key and lucky key
    parentalKey = []
    luckyKey = []
    trueKey = []
    
    #to help count from back
    reverseHelper = len(keyListIndex) - 1

    for i in range(len(keyListIndex)):

        #parental key generated
        if i + 2 <  len(keyListIndex):
            parentalKey.append(keyListIndex[i]+ keyListIndex[i+2])
        else :
            parentalKey.append(keyListIndex[i])

        #lucky key generated
        if i != reverseHelper and reverseHelper > i:
            luckyKey.append(keyListIndex[i] + keyListIndex[reverseHelper])
        else :
            luckyKey.append(keyListIndex[i])
        reverseHelper -=1

    trueKey.extend(parentalKey)
    trueKey.extend(luckyKey)
    return trueKey

#load the unicode data
def loadUnicodedata():
    unicodeDatas = []
    #how many data to load, for example index 0 - 1270
    for code in range(0, 1271): 
        ch = chr(code)
        # skip control chars, ex "\x00"
        if unicodedata.category(ch)[0] != "C":  
            unicodeDatas.append(ch)
            
    return unicodeDatas

class state:

    def __init__(self, key = "4Z3r0th_", salt = "071>*", sugar = "b3k1nd"):
        """
            #Initializes the Class, making an Encryption unique key
            Args:
                - key (str) : main encryption seed
                - salt (str) : added string to make the key more unique
                - sugar (str) : added string to make the key more unique
        """
        self.unicodeDatas = loadUnicodedata()
        self.trueKey = keyCreation(key,salt,sugar)
        

    def letsEncrypt(self, word = ""):
        """
            #Encrypt the requested sentence (type = str)
            Args:
                - word = str, sentence you want to encrypt
        """
        self.word = word
        wordList = list(self.word)
        wordIter = 0
        
        wordListIndex = []
        
        for i in wordList:
            if i in self.unicodeDatas:
                wordListIndex.append(self.unicodeDatas.index(i))
            else:
                print("WARNING, Unknown Symbol")
                break

        #counting the iteration
        iteration = 0

        #censorWord list
        self.encryptedWord = []

        while True:
            if iteration > len(self.trueKey) - 1:
                iteration = 0
            if iteration < len(self.trueKey) - 1:
                self.encryptedWord.append(self.unicodeDatas[(wordListIndex[wordIter] + self.trueKey[iteration])])
                wordIter += 1
            if wordIter == len(wordList):
                break
            iteration+=1

        return "".join(self.encryptedWord)
    
    def generatedKeys(self):
        """
            #showing the key <list>
        """
        return self.trueKey
    
class deState:

    def __init__(self, key = "4Z3r0th_", salt = "071>*", sugar = "b3k1nd"):
        """
            #Initializes the Class, making the Decryption unique key
            Args:
                - key (str) : main encryption seed
                - salt (str) : added string to make the key more unique
                - sugar (str) : added string to make the key more unique
        """
        self.unicodeDatas = loadUnicodedata()
        self.trueKey = keyCreation(key, salt, sugar)
        

    def letsDecrypt(self, word = ""):
        """
            #Decrypt the requested sentence (type = str)
            Args:
                - word = str, sentence you want to encrypt
        """
        self.word = word
        wordList = list(self.word)
        wordListIndex = []

        for i in wordList:
            if i in self.unicodeDatas:
                wordListIndex.append(self.unicodeDatas.index(i))
            else:
                print("WARNING, Unknown Symbol")
                break

        iteration = 0

        wordIter = 0

        self.decryptedWord = []

        while True:
            
            if iteration > len(self.trueKey) - 1:
                iteration = 0
            if iteration < len(self.trueKey) - 1:
                intToChar = wordListIndex[wordIter] - self.trueKey[iteration]
                if intToChar < 0 :
                    intToChar += len(self.unicodeDatas)
                self.decryptedWord.append(self.unicodeDatas[intToChar])
                wordIter += 1
            if wordIter == len(wordListIndex):
                break
            iteration+=1
            
                
        return "".join(self.decryptedWord)
    
    def generatedKeys(self):
        """
            #showing the key <list>
        """
        return self.trueKey


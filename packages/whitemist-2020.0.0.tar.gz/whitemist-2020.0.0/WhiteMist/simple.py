import unicodedata

def keyCreation(key,salt,sugar):
    """_summary_

    Args:
        key (string): main key
        salt (string): add more unique values to the key
        sugar (string): add more unique values to the key

    Returns:
        list: trueKey  
    """

    #merging the key with simple method
    keyList = list(key)
    keyList.extend(list(salt))
    keyList.extend(list(sugar))
    
    keyListIndex = []
    
    unicodedatass = loadUnicodedata()
    for i in keyList:
        if i in unicodedatass:
            keyListIndex.append(unicodedatass.index(i))
        else:
            print("WARNING, Unknown Symbol")
            break
    


    #parental key and lucky key
    parentalKey = []
    luckyKey = []
    trueKey = []
    
    #to help count from back
    reverseHelper = len(keyListIndex) - 1

    for i in range(len(keyListIndex)):

        #parental key generation
        if i + 2 <  len(keyListIndex):
            parentalKey.append(keyListIndex[i] + keyListIndex[i+2])
        else :
            parentalKey.append(keyListIndex[i])

        #lucky key generation
        if i != reverseHelper and reverseHelper > i:
            luckyKey.append(keyListIndex[i] + keyListIndex[reverseHelper])
        else :
            luckyKey.append(keyListIndex[i])
        reverseHelper -=1
    
    #merging all the key
    trueKey.extend(parentalKey)
    trueKey.extend(luckyKey)
    return trueKey
    
#load the unicode data
def loadUnicodedata():
    unicodeDatas = []
    #how many data to load, for example index 0 - 2000
    for code in range(0, 2000): 
        ch = chr(code)
        # skip control chars, ex "\x00"
        if unicodedata.category(ch)[0] != "C":  
            unicodeDatas.append(ch)
            
    return unicodeDatas


class state:

    def __init__(self, key = "4Z3r0th_", salt = "071>*", sugar = "b3k1nd"):
        """
            #Initializes the Class, making an Encryption unique key
            Args:
                - key (str) : main encryption seed
                - salt (str) : added string to make the key more unique
                - sugar (str) : added string to make the key more unique
        """
        self.unicodeDatas = loadUnicodedata()
        self.trueKey = keyCreation(key, salt, sugar)


    def letsEncrypt(self, word = ""):
        """
            #Encrypt the requested sentence (type = str)
            Args:
                - word = str, sentence you want to encrypt
        """
        self.word = word
        wordList = list(self.word)
        if len(wordList) <= 0:
            return "Invalid string, empty list detected"
        
        wordListIndex = []
        
        for i in wordList:
            if i in self.unicodeDatas:
                wordListIndex.append(self.unicodeDatas.index(i))
            else:
                print("WARNING, Unknown Symbol")
                break
        

        wordIter = 0

        #counting the iteration
        iteration = 0

        #censorWord list
        self.encryptedWord = []


        while True:
            if iteration > len(self.trueKey) - 1:
                iteration = 0
            if iteration < len(self.trueKey) - 1:
                self.encryptedWord.append(self.unicodeDatas[(wordListIndex[wordIter]) + self.trueKey[iteration]])
                wordIter += 1
            if wordIter == len(wordList):
                break
            iteration+=1

        return "".join(self.encryptedWord)

    def generatedKeys(self):
        """
            #showing the key <list>
        """
        return self.trueKey
    
class deState:
    def __init__(self, key = "4Z3r0th_", salt = "071>*", sugar = "b3k1nd"):
        """
            #Initializes the Class, making the Decryption unique key
            Args:
                - key (str) : main encryption seed
                - salt (str) : added string to make the key more unique
                - sugar (str) : added string to make the key more unique
        """
        self.unicodeDatas = loadUnicodedata()
        self.trueKey = keyCreation(key, salt, sugar)

    def letsDecrypt(self, word = ""):
        """
            #Decrypt the requested sentence (type = str)
            Args:
                - word = str, sentence you want to encrypt
        """
        self.word = word
        wordList = list(self.word)

        wordIter = 0
        

        #checking the characters corresponding index in the array self.unicodeDatas
        wordListIndex = []
        
        for i in wordList:
            
            if i in self.unicodeDatas:
                wordListIndex.append(self.unicodeDatas.index(i))
            else:
                print("WARNING, Unknown Symbol")
                break

        iteration = 0

        self.decryptedWord = []

        while True:
            
            if iteration > len(self.trueKey) - 1:
                iteration = 0
            if iteration < len(self.trueKey) - 1:
                
                intToChar = wordListIndex[wordIter] - self.trueKey[iteration]
                if intToChar < 0 :
                    intToChar += len(self.unicodeDatas)
                self.decryptedWord.append(self.unicodeDatas[intToChar])
               
                
                wordIter += 1
            if wordIter == len(wordListIndex):
                break
            iteration+=1
            
    
        return "".join(self.decryptedWord)
    
    def generatedKeys(self):
        """
            #showing the key <list>
        """
        return self.trueKey
    
    
asu = state("zakir")
asut = asu.letsEncrypt("123230071")


asuss = deState("zakir")

from .simple import state, deState
from .simpleCross import state, deState
from .crossCross import state, deState
from .rustautogui_py import *

__doc__ = rustautogui_py.__doc__
if hasattr(rustautogui_py, "__all__"):
    __all__ = rustautogui_py.__all__
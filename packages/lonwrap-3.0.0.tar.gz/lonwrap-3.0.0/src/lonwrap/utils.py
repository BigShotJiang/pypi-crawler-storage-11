"""Utilities for handling geometries crossing the antimeridian."""

import warnings
from typing import Literal, TypeVar

from geopandas import GeoDataFrame
from shapely import MultiPolygon, Polygon, affinity, make_valid

T = TypeVar('T', Polygon, MultiPolygon)


class GeometryWarning(UserWarning):
    """Invalid or problematic geometry in data."""


def _find_geometries_gap(
    *,
    geoms: list[Polygon],
    coord_limits: tuple[float, float] = (-180, 180),
    cyclic_coords: bool = True,
) -> tuple[float, float] | None:
    """Find longest gap in x-coordinates to divide geometries.

    Parameters
    ----------
    geoms : list[Polygon]
        List of shapely Polygons.
    coord_limits : tuple(float, float), optional
        The x-range to consider for dividing line. Default is (-180, 180).
    cyclic_coords : bool, optional
        Whether the x-coordinates are cyclic (e.g., longitude). Default is
        True. If True, the function will consider the wrap-around interval
        between x_range[1] and x_range[0].

    Returns
    -------
    tuple[float, float]
        The range (min, max) of the gap that best divides the polygons.

    """
    if not geoms:
        return coord_limits
    # Collect x-coordinate ranges from all geometries
    geom_bounds = [geom.bounds for geom in geoms]
    ranges = [(minx, maxx) for minx, _, maxx, _ in geom_bounds]

    # Sort ranges by start point
    ranges.sort(key=lambda r: r[0])

    gaps: list[tuple[float, float]] = []
    current_end = coord_limits[0]
    for start, end in ranges:
        if start > current_end:
            gaps.append((current_end, start))
        current_end = max(current_end, end)
    if current_end < coord_limits[1]:
        gaps.append((current_end, coord_limits[1]))
    if len(gaps) == 0:
        return None
    gap_widths = [(end - start, (start, end)) for start, end in gaps]
    if (
        cyclic_coords
        and gaps[0][0] == coord_limits[0]
        and gaps[-1][1] == coord_limits[1]
    ):
        gap_widths[0] = (
            gap_widths[0][0] + gap_widths[-1][0],
            (gaps[-1][0], gaps[0][1]),
        )
        gap_widths.pop()

    return max(gap_widths, key=lambda gw: gw[0])[1]


def _unwrap_multipolygon(
    multipolygon: MultiPolygon,
    unwrap_to: Literal['east', 'west', 'centroid'],
    coord_limits: tuple[float, float],
    gap_threshold: float,
) -> MultiPolygon:
    """Unwrap a MultiPolygon based on the specified direction."""
    accuracy_threshold = 0.000_000_1
    if multipolygon.is_empty:
        return multipolygon
    minx, _, maxx, _ = multipolygon.bounds
    delta = (maxx - minx) * accuracy_threshold
    if minx < coord_limits[0] - delta or maxx > coord_limits[1] + delta:
        msg = (
            'Geometry bounds exceed coordinate limits.'
            f' Got bounds: ({minx}, {maxx}),'
            f' limits: {coord_limits}'
        )
        raise ValueError(msg)
    if maxx - minx < gap_threshold:
        return multipolygon

    polygons = list(multipolygon.geoms)
    gap = _find_geometries_gap(
        geoms=polygons,
        coord_limits=coord_limits,
        cyclic_coords=True,
    )
    if gap is None or gap[1] - gap[0] < gap_threshold or gap[1] < gap[0]:
        return multipolygon
    if unwrap_to == 'centroid':
        centroid_x = multipolygon.centroid.x
        unwrap_to = 'west' if centroid_x < (gap[0] + gap[1]) / 2 else 'east'
    shift = (
        coord_limits[1] - coord_limits[0]
        if unwrap_to == 'east'
        else (coord_limits[0] - coord_limits[1])
    )
    to_be_shifted = [
        (p.bounds[2] <= gap[0] and unwrap_to == 'east')
        or (p.bounds[0] >= gap[1] and unwrap_to == 'west')
        for p in polygons
    ]

    unwrapped_multipolygon = MultiPolygon(
        [
            affinity.translate(p, xoff=shift) if t else p
            for p, t in zip(polygons, to_be_shifted, strict=False)
        ]
    )
    if unwrapped_multipolygon.is_valid:
        return unwrapped_multipolygon
    return make_valid(unwrapped_multipolygon).buffer(0)  # type: ignore[return-value]


def unwrap(
    data: GeoDataFrame,
    geom_col: str = 'geometry',
    unwrap_to: Literal['east', 'west', 'centroid'] = 'centroid',
    gap_threshold: float = 180.0,
) -> GeoDataFrame:
    """Unwrap geometries crossing the antimeridian.

    Unwrap longitude values to produce a continuous sequence across the
    meridian.

    This function converts cyclic longitude values (ranging from -180° to 180°)
    into a continuous representation by adding or subtracting 360° when a jump
    larger than 180° is detected. Useful for handling features that cross the
    antimeridian in geographic datasets.

    Parameters
    ----------
    data : GeoDataFrame
        Input GeoDataFrame containing geometries to be unwrapped.
    geom_col : str, optional
        Name of the geometry column in the GeoDataFrame. Default is 'geometry'.
    unwrap_to: Literal['east', 'west', 'centroid'], optional
        Direction to unwrap the geometries. Options are:
        - 'centroid': Shift toward the side with the larger total polygon area
          (default).
        - 'east': Unwrap towards the east.
        - 'west': Unwrap towards the west.
          The area is calculated based on the current coordinate system.
    gap_threshold: float
        Minimum gap size (in degrees) to consider for unwrapping. Default is
        180.0 degrees.

    Returns
    -------
    GeoDataFrame
        A new GeoDataFrame with unwrapped geometries.

    """
    # Create a copy to avoid modifying the original
    result = data.copy()

    # Raise warning for invalid geometries
    invalid_geoms_idxs = result.index[~result[geom_col].is_valid].to_list()
    if invalid_geoms_idxs:
        warnings.warn(
            f'The following geometries are invalid and ignored for unwrapping'
            f' operation: {invalid_geoms_idxs}',
            GeometryWarning,
            stacklevel=2,
        )

    # Apply unwrapping to each geometry if geometry type is MultiPolygon
    result[geom_col] = result[geom_col].apply(
        lambda geom: _unwrap_multipolygon(
            multipolygon=geom,
            unwrap_to=unwrap_to,
            coord_limits=(-180, 180),
            gap_threshold=gap_threshold,
        )
        if isinstance(geom, MultiPolygon)
        else geom
    )

    return result

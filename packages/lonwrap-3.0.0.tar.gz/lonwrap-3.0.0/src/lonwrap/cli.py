#!/usr/bin/env python
"""Command-line interface for the lonwrap application."""

import json
import logging
import sys
from pathlib import Path
from typing import Literal

import click
import geopandas as gpd
from click_option_group import optgroup

from lonwrap import utils

# Configure logging
logger = logging.getLogger(__name__)


def parse_json_to_dict(ctx, param, value: str | None) -> dict | None:  # noqa: ANN001
    """Parse JSON string to dictionary."""
    _ = ctx  # unused
    if value is None:
        return None

    try:
        return json.loads(value)
    except json.JSONDecodeError as e:
        msg = f'{param} has Invalid JSON: {e}'
        raise click.BadParameter(msg) from e


def setup_logging(verbose: bool) -> None:  # noqa: FBT001
    """Configure logging based on verbosity level."""
    level = logging.INFO if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format='%(message)s',
        stream=sys.stderr,
        force=True,  # Force reconfiguration even if logging was already set up
    )


def format_file_size(size_bytes: float) -> str:
    """Format file size in human-readable format."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:  # noqa: PLR2004
            return f'{size_bytes:.1f} {unit}'
        size_bytes /= 1024.0
    return f'{size_bytes:.1f} TB'


@click.group()
@click.version_option()
@click.help_option('-h', '--help')
def main() -> None:
    """Lonwrap: Tools for handling geometries crossing the 180° meridian."""


@main.command(
    epilog="""
\b
Examples:
  # Basic usage with default settings
  lonwrap unwrap world.geojson unwrapped.geojson

\b
  # Unwrap towards west instead of east
  lonwrap unwrap --unwrap-to west input.gpkg output.gpkg

\b
  # Preview changes without writing output
  lonwrap unwrap --dry-run --verbose input.geojson output.geojson

\b
  # Use custom gap threshold
  lonwrap unwrap --gap-threshold 150 input.geojson output.geojson

\b
  # Advanced: specify CRS and engine
  lonwrap unwrap --crs EPSG:4326 --engine fiona input.shp output.geojson
""",
)
@click.argument(
    'input_',
    type=click.Path(exists=True, path_type=Path),
    required=True,
    metavar='INPUT',
)
@click.argument(
    'output',
    type=click.Path(path_type=Path),
    required=True,
)
# Basic Options
@optgroup.group('Basic Options')
@optgroup.option(
    '--unwrap-to',
    type=click.Choice(['east', 'west', 'centroid'], case_sensitive=False),
    help='Direction to unwrap geometries. '
    '"east" shifts westward polygons east, '
    '"west" shifts eastward polygons west, '
    '"centroid" chooses based on centroid location.',
    default='centroid',
    show_default=True,
)
@optgroup.option(
    '--gap-threshold',
    type=float,
    help='Minimum gap size to trigger unwrapping (in degrees). '
    'Geometries with maximum gaps smaller than this will not be modified.',
    default=180.0,
    show_default=True,
)
# Advanced Options
@optgroup.group('Advanced Options')
@optgroup.option(
    '--geom-col',
    type=str,
    help='Name of the geometry column in the data.',
    default='geometry',
    show_default=True,
)
@optgroup.option(
    '--mode',
    type=click.Choice(['w', 'a'], case_sensitive=True),
    help="Write mode: 'w' to overwrite existing file, "
    "'a' to append (not all drivers support appending).",
    default='w',
    show_default=True,
)
@optgroup.option(
    '--crs',
    type=str,
    help='CRS override (e.g., EPSG:4326). '
    'Accepts anything supported by pyproj.CRS.from_user_input(). '
    'Not supported by pyogrio engine.',
    default=None,
)
@optgroup.option(
    '--engine',
    type=click.Choice(['fiona', 'pyogrio'], case_sensitive=False),
    help='I/O backend engine. Defaults to pyogrio if available, '
    'otherwise fiona.',
    default=None,
)
@optgroup.option(
    '--metadata',
    type=str,
    help='JSON string of metadata to write to output file (GPKG driver only).',
    default=None,
    callback=parse_json_to_dict,
)
@optgroup.option(
    '--kwargs',
    'extra_kwargs',
    type=str,
    help='Additional keyword arguments for GeoDataFrame.to_file() '
    'as a JSON string.',
    default=None,
    callback=parse_json_to_dict,
)
@click.option(
    '-v',
    '--verbose',
    is_flag=True,
    help='Show detailed processing logs.',
)
@click.option(
    '--dry-run',
    is_flag=True,
    help='Preview changes without writing the output file. '
    'Useful for checking what would be modified.',
)
@click.help_option('-h', '--help')
def unwrap(  # noqa: PLR0913, C901
    input_: Path | None,
    output: Path | None,
    geom_col: str,
    unwrap_to: Literal['east', 'west', 'centroid'],
    gap_threshold: float,
    mode: Literal['w', 'a'],
    crs: str | None = None,
    engine: Literal['fiona', 'pyogrio'] | None = None,
    metadata: dict | None = None,
    extra_kwargs: dict | None = None,
    *,
    verbose: bool = False,
    dry_run: bool = False,
) -> None:
    """Unwraps geometries crossing the 180° meridian.

    This tool processes geospatial data files (GeoJSON, Shapefile, GeoPackage,
    etc.) and unwraps geometries that cross the antimeridian (180° longitude).
    This is particularly useful for regions like Russia's Far East that span
    the date line.
    """
    # Setup logging
    setup_logging(verbose)

    output_path = output

    # Validate required arguments
    if input_ is None:
        msg = (
            'Missing argument INPUT. '
            'Provide input file as: lonwrap INPUT OUTPUT'
        )
        raise click.UsageError(msg)
    if output_path is None:
        msg = (
            'Missing argument OUTPUT. '
            'Provide output file as: lonwrap INPUT OUTPUT'
        )
        raise click.UsageError(msg)

    logger.info('Reading input file: %s', input_)
    gdf = gpd.read_file(filename=input_)
    logger.info('Loaded %d features', len(gdf))

    if verbose:
        logger.info('CRS: %s', gdf.crs)
        logger.info('Geometry column: %s', geom_col)
        logger.info('Unwrap direction: %s', unwrap_to)
        logger.info('Gap threshold: %s°', gap_threshold)

    logger.info('Processing geometries...')
    result_gdf = utils.unwrap(
        data=gdf,
        geom_col=geom_col,
        unwrap_to=unwrap_to,
        gap_threshold=gap_threshold,
    )

    # Count modified geometries
    modified_count = 0
    for orig, result in zip(gdf[geom_col], result_gdf[geom_col], strict=True):
        if not orig.equals(result):
            modified_count += 1

    logger.info('Modified %d geometries', modified_count)

    if dry_run:
        click.echo('\n--- DRY RUN MODE ---', err=True)
        click.echo(f'Input:  {input_}', err=True)
        click.echo(f'Output: {output_path}', err=True)
        click.echo(f'Features: {len(result_gdf)}', err=True)
        click.echo(f'Geometries unwrapped: {modified_count}', err=True)
        click.echo(f'CRS: {result_gdf.crs}', err=True)
        click.echo('\nNo files were written (dry run mode).', err=True)
        return

    # Build kwargs for to_file
    logger.info('Writing output file: %s', output_path)
    to_file_kwargs = {
        'filename': output_path,
        'mode': mode,
    }
    if crs is not None:
        to_file_kwargs['crs'] = crs
    if engine is not None:
        to_file_kwargs['engine'] = engine
    if metadata is not None:
        to_file_kwargs['metadata'] = metadata
    if extra_kwargs is not None:
        to_file_kwargs.update(extra_kwargs)

    result_gdf.to_file(**to_file_kwargs)

    # Success summary
    output_size = output_path.stat().st_size if output_path.exists() else 0
    click.echo(
        f'\n✓ Successfully processed {input_} → {output_path}', err=True
    )
    click.echo(f'  Features: {len(result_gdf)}', err=True)
    click.echo(f'  Geometries unwrapped: {modified_count}', err=True)
    click.echo(f'  CRS: {result_gdf.crs}', err=True)
    click.echo(f'  Output size: {format_file_size(output_size)}', err=True)


# @main.command(
#     epilog="""
# \b
# Examples:
#   # Basic usage with default settings
#   lonwrap wrap world.geojson wrapped.geojson
#
# \b
#   # Preview changes without writing output
#   lonwrap wrap --dry-run --verbose input.geojson output.geojson
#
# \b
#   # Advanced: specify CRS and engine
#   lonwrap wrap --crs EPSG:4326 --engine fiona input.shp output.geojson
# """,
# )
@click.argument(
    'input_',
    type=click.Path(exists=True, path_type=Path),
    required=True,
    metavar='INPUT',
)
@click.argument(
    'output',
    type=click.Path(path_type=Path),
    required=True,
)
# Advanced Options
@optgroup.group('Advanced Options')
@optgroup.option(
    '--geom-col',
    type=str,
    help='Name of the geometry column in the data.',
    default='geometry',
    show_default=True,
)
@optgroup.option(
    '--mode',
    type=click.Choice(['w', 'a'], case_sensitive=True),
    help="Write mode: 'w' to overwrite existing file, "
    "'a' to append (not all drivers support appending).",
    default='w',
    show_default=True,
)
@optgroup.option(
    '--crs',
    type=str,
    help='CRS override (e.g., EPSG:4326). '
    'Accepts anything supported by pyproj.CRS.from_user_input(). '
    'Not supported by pyogrio engine.',
    default=None,
)
@optgroup.option(
    '--engine',
    type=click.Choice(['fiona', 'pyogrio'], case_sensitive=False),
    help='I/O backend engine. Defaults to pyogrio if available, '
    'otherwise fiona.',
    default=None,
)
@optgroup.option(
    '--metadata',
    type=str,
    help='JSON string of metadata to write to output file (GPKG driver only).',
    default=None,
    callback=parse_json_to_dict,
)
@optgroup.option(
    '--kwargs',
    'extra_kwargs',
    type=str,
    help='Additional keyword arguments for GeoDataFrame.to_file() '
    'as a JSON string.',
    default=None,
    callback=parse_json_to_dict,
)
@click.option(
    '-v',
    '--verbose',
    is_flag=True,
    help='Show detailed processing logs.',
)
@click.option(
    '--dry-run',
    is_flag=True,
    help='Preview changes without writing the output file. '
    'Useful for checking what would be modified.',
)
@click.help_option('-h', '--help')
def wrap(  # noqa: PLR0913
    input_: Path | None,
    output: Path | None,
    geom_col: str,
    mode: Literal['w', 'a'],
    crs: str | None = None,
    engine: Literal['fiona', 'pyogrio'] | None = None,
    metadata: dict | None = None,
    extra_kwargs: dict | None = None,
    *,
    verbose: bool = False,
    dry_run: bool = False,
) -> None:
    """Wrap geometries to standard longitude range (-180° to 180°).

    This tool processes geospatial data files (GeoJSON, Shapefile, GeoPackage,
    etc.) and wraps geometries that extend beyond the standard -180° to 180°
    longitude range back into that range. This is the inverse operation of
    unwrap.

    Note: This functionality is not yet fully implemented.
    """
    # Setup logging
    setup_logging(verbose)

    output_path = output

    # Validate required arguments
    if input_ is None:
        msg = (
            'Missing argument INPUT. '
            'Provide input file as: lonwrap wrap INPUT OUTPUT'
        )
        raise click.UsageError(msg)
    if output_path is None:
        msg = (
            'Missing argument OUTPUT. '
            'Provide output file as: lonwrap wrap INPUT OUTPUT'
        )
        raise click.UsageError(msg)

    logger.info('Reading input file: %s', input_)
    gdf = gpd.read_file(filename=input_)
    logger.info('Loaded %d features', len(gdf))

    if verbose:
        logger.info('CRS: %s', gdf.crs)
        logger.info('Geometry column: %s', geom_col)

    # TODO: Implement wrap functionality
    # For now, just copy the input to output
    logger.warning('Wrap functionality is not yet fully implemented.')
    logger.warning('Copying input to output without modification.')
    result_gdf = gdf.copy()

    if dry_run:
        click.echo('\n--- DRY RUN MODE ---', err=True)
        click.echo(f'Input:  {input_}', err=True)
        click.echo(f'Output: {output_path}', err=True)
        click.echo(f'Features: {len(result_gdf)}', err=True)
        click.echo(f'CRS: {result_gdf.crs}', err=True)
        click.echo('\nNo files were written (dry run mode).', err=True)
        click.echo(
            'Note: Wrap functionality is not yet implemented.', err=True
        )
        return

    # Build kwargs for to_file
    logger.info('Writing output file: %s', output_path)
    to_file_kwargs = {
        'filename': output_path,
        'mode': mode,
    }
    if crs is not None:
        to_file_kwargs['crs'] = crs
    if engine is not None:
        to_file_kwargs['engine'] = engine
    if metadata is not None:
        to_file_kwargs['metadata'] = metadata
    if extra_kwargs is not None:
        to_file_kwargs.update(extra_kwargs)

    result_gdf.to_file(**to_file_kwargs)

    # Success summary
    output_size = output_path.stat().st_size if output_path.exists() else 0
    click.echo(
        f'\n✓ Successfully processed {input_} → {output_path}', err=True
    )
    click.echo(f'  Features: {len(result_gdf)}', err=True)
    click.echo('  Note: Wrap functionality is not yet implemented.', err=True)
    click.echo(f'  CRS: {result_gdf.crs}', err=True)
    click.echo(f'  Output size: {format_file_size(output_size)}', err=True)


if __name__ == '__main__':
    main()

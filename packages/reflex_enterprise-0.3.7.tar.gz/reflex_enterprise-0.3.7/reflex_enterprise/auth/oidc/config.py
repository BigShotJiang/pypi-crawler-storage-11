"""Reusable config mixin for OIDC providers."""

import os
from typing import ClassVar

from reflex_enterprise.auth.oidc.utils import issuer_endpoint


class ConfigMixin:
    """Customizable per-provider configuration from env var helper."""

    __provider__: ClassVar[str] = "base"

    @classmethod
    def get_config_value(cls, key: str, default: str | None = None) -> str | None:
        """Get a configuration value for the OIDC provider.

        Args:
            key: The configuration key to retrieve.
            default: The default value if the key is not found.

        Returns:
            The configuration value as a string, or the default if not found.
        """
        full_key = f"{cls.__provider__.upper()}_{key.upper()}"
        fallback_key = f"OIDC_{key.upper()}"
        return os.environ.get(full_key, os.environ.get(fallback_key, default))

    @classmethod
    def with_provider_prefix(cls, url: str) -> str:
        """Prefix a URL path with the provider name for namespacing.

        Args:
            url: The URL path to prefix.

        Returns:
            The namespaced URL path.
        """
        prefix = f"/_reflex_oidc_{cls.__provider__}"
        if not url.startswith("/"):
            url = "/" + url
        return prefix + url

    # Informational classmethods that should be overwritten by subclasses as needed
    @classmethod
    def authorization_code_endpoint(cls) -> str:
        """Get the authorization code endpoint path."""
        return cls.get_config_value(
            "authorization_code_endpoint"
        ) or cls.with_provider_prefix("/authorization-code/callback")

    @classmethod
    def popup_login_endpoint(cls) -> str:
        """Get the popup login endpoint path."""
        return cls.get_config_value("popup_login_endpoint") or cls.with_provider_prefix(
            "/popup-login"
        )

    @classmethod
    def popup_logout_endpoint(cls) -> str:
        """Get the popup logout endpoint path."""
        return cls.get_config_value(
            "popup_logout_endpoint"
        ) or cls.with_provider_prefix("/popup-logout")

    @classmethod
    def client_id(cls) -> str:
        """Get the OIDC client ID."""
        client_id = cls.get_config_value("client_id")
        if not client_id:
            raise RuntimeError("OIDC client ID not configured")
        return client_id

    @classmethod
    def client_secret(cls) -> str:
        """Get the OIDC client secret."""
        return cls.get_config_value("client_secret") or ""

    @classmethod
    def issuer_uri(cls) -> str:
        """Get the OIDC issuer URI."""
        issuer = cls.get_config_value("issuer_uri")
        if not issuer:
            raise RuntimeError("OIDC issuer URI not configured")
        return issuer

    @classmethod
    async def issuer_endpoint(cls, service: str) -> str:
        """Get an endpoint URL (authorization/token/userinfo/etc) from OIDC metadata.

        Args:
            service: The OIDC service endpoint to retrieve.

        Returns:
            The endpoint URL as a string.
        """
        return await issuer_endpoint(cls.issuer_uri(), service)

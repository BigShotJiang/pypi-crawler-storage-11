"""
Example: Configuration file encryption using STC v0.3.0
Demonstrates password-based config encryption with entropy health monitoring
"""

import sys
import os
# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

import struct
from interfaces.api.stc_api import STCContext


def _serialize_config_to_binary(config: dict) -> bytes:
    """Serialize config dictionary to self-sovereign binary format"""
    if not config:
        return b''
    
    # Magic header for config: STCC (SeigrToolsetCrypto Config)
    binary_data = bytearray(b'STCC')
    
    # Serialize each key-value pair
    for key, value in config.items():
        # Key (length-prefixed string)
        key_bytes = key.encode('utf-8')
        binary_data.extend(struct.pack('<H', len(key_bytes)))
        binary_data.extend(key_bytes)
        
        # Value (type-tagged)
        if isinstance(value, bool):
            binary_data.extend(b'\x01')  # Boolean type
            binary_data.extend(struct.pack('<?', value))
        elif isinstance(value, int):
            binary_data.extend(b'\x02')  # Integer type
            binary_data.extend(struct.pack('<q', value))  # 64-bit signed
        elif isinstance(value, float):
            binary_data.extend(b'\x03')  # Float type
            binary_data.extend(struct.pack('<d', value))  # 64-bit double
        elif isinstance(value, str):
            binary_data.extend(b'\x04')  # String type
            value_bytes = value.encode('utf-8')
            binary_data.extend(struct.pack('<I', len(value_bytes)))
            binary_data.extend(value_bytes)
        elif isinstance(value, list):
            binary_data.extend(b'\x05')  # List type (simplified - string list only)
            binary_data.extend(struct.pack('<I', len(value)))
            for item in value:
                if isinstance(item, str):
                    item_bytes = item.encode('utf-8')
                    binary_data.extend(struct.pack('<I', len(item_bytes)))
                    binary_data.extend(item_bytes)
        elif isinstance(value, dict):
            binary_data.extend(b'\x06')  # Nested dict type
            nested_binary = _serialize_config_to_binary(value)
            binary_data.extend(struct.pack('<I', len(nested_binary)))
            binary_data.extend(nested_binary)
        # Skip unsupported types for self-sovereignty
        
    return bytes(binary_data)


def _deserialize_binary_to_config(data: bytes) -> dict:
    """Deserialize binary data to config dictionary"""
    if not data or len(data) < 4:
        return {}
        
    # Check magic header
    if data[:4] != b'STCC':
        raise ValueError("Invalid config data: missing STCC magic number")
    
    result = {}
    offset = 4
    
    while offset < len(data):
        # Read key
        key_len = struct.unpack('<H', data[offset:offset+2])[0]
        offset += 2
        key = data[offset:offset+key_len].decode('utf-8')
        offset += key_len
        
        # Read value type and data
        value_type = data[offset:offset+1]
        offset += 1
        
        if value_type == b'\x01':  # Boolean
            value = struct.unpack('<?', data[offset:offset+1])[0]
            offset += 1
        elif value_type == b'\x02':  # Integer
            value = struct.unpack('<q', data[offset:offset+8])[0]
            offset += 8
        elif value_type == b'\x03':  # Float
            value = struct.unpack('<d', data[offset:offset+8])[0]
            offset += 8
        elif value_type == b'\x04':  # String
            str_len = struct.unpack('<I', data[offset:offset+4])[0]
            offset += 4
            value = data[offset:offset+str_len].decode('utf-8')
            offset += str_len
        elif value_type == b'\x05':  # List
            list_len = struct.unpack('<I', data[offset:offset+4])[0]
            offset += 4
            value = []
            for _ in range(list_len):
                item_len = struct.unpack('<I', data[offset:offset+4])[0]
                offset += 4
                item = data[offset:offset+item_len].decode('utf-8')
                value.append(item)
                offset += item_len
        elif value_type == b'\x06':  # Nested dict
            nested_len = struct.unpack('<I', data[offset:offset+4])[0]
            offset += 4
            nested_data = data[offset:offset+nested_len]
            value = _deserialize_binary_to_config(nested_data)
            offset += nested_len
        else:
            break  # Unknown type, stop parsing
            
        result[key] = value
        
    return result


def encrypt_config_file(config_data: dict, password: str, output_file: str):
    """
    Encrypt configuration data with password protection (v0.3.0)
    Enhanced with entropy health monitoring and adaptive security
    
    Args:
        config_data: Configuration dictionary
        password: Encryption password
        output_file: Output file path
    """
    # Serialize config for encryption using self-sovereign binary format
    config_binary = _serialize_config_to_binary(config_data)
    
    # Create STC context with user password
    context = STCContext(password=password, user_id="config_user")    # v0.3.0: Set entropy quality threshold for critical configs
    context.set_minimum_entropy_threshold(0.7)  # Require good entropy
    
    # Encrypt with password-based encryption
    # v0.3.0: Polymorphic decoys enabled by default
    encrypted, metadata = context.encrypt(
        config_binary,
        password=password,
        use_decoys=True,
        variable_decoy_sizes=True,      # v0.3.0: Randomize decoy sizes
        randomize_decoy_count=True,     # v0.3.0: Vary decoy count
        timing_randomization=True       # v0.3.0: Timing jitter
    )
    
    # Save encrypted data (binary)
    with open(output_file, 'wb') as f:
        f.write(encrypted)
    
    # Save metadata (binary TLV format)
    metadata_file = output_file + '.meta'
    with open(metadata_file, 'wb') as f:
        f.write(metadata)
    
    print(f"[OK] Configuration encrypted and saved to {output_file}")
    print(f"[OK] Metadata (with MAC) saved to {metadata_file}")
    print(f"  Encrypted size: {len(encrypted)} bytes")
    print(f"  Metadata size: {len(metadata)} bytes")
    
    # v0.3.0: Show entropy health status
    profile = context.get_entropy_profile()
    print(f"\nEntropy Health (v0.3.0):")
    print(f"  Quality Score: {profile['quality_score']:.3f}")
    print(f"  Status: {profile['status']}")
    if profile['warnings']:
        for warning in profile['warnings']:
            print(f"  Warning: {warning}")


def decrypt_config_file(encrypted_file: str, password: str) -> dict:
    """
    Decrypt configuration file with MAC verification (v0.3.0)
    Enhanced with attack detection
    
    Args:
        encrypted_file: Encrypted file path
        password: Decryption password
        
    Returns:
        Configuration dictionary
        
    Raises:
        ValueError: If wrong password or tampering detected
    """
    # Load encrypted data
    with open(encrypted_file, 'rb') as f:
        encrypted = f.read()
    
    # Load metadata
    metadata_file = encrypted_file + '.meta'
    with open(metadata_file, 'rb') as f:
        metadata = f.read()
    
    # Initialize context with adaptive difficulty (v0.3.0)
    context = STCContext(
        f"config-{password}",
        adaptive_difficulty='balanced'
    )
    
    # Decrypt with MAC verification
    config_binary = context.decrypt(encrypted, metadata, password=password)
    
    # Parse binary config data
    config_data = _deserialize_binary_to_config(config_binary)
    
    # v0.3.0: Check for attack detection
    status = context.get_adaptive_difficulty_status()
    if status['attack_detected']:
        print(f"\n[WARNING] Potential attack detected!")
        print(f"  Failed decryptions: {status['failed_decryptions']}")
        print(f"  Operation rate: {status['operation_rate']:.2f} ops/sec")
    
    return config_data


if __name__ == '__main__':
    print("=" * 70)
    print("STC v0.3.0 Configuration Encryption Example")
    print("=" * 70)
    
    # Example configuration (using placeholder values - not real credentials)
    config = {
        'database': {
            'host': 'localhost',
            'port': 5432,
            'username': 'admin',
            'password': 'example-db-password'  # Placeholder
        },
        'api_keys': {
            'service_a': 'sk-aaaaa-example-key-aaaaa',  # Placeholder
            'service_b': 'sk-bbbbb-example-key-bbbbb'   # Placeholder
        },
        'settings': {
            'debug': False,
            'max_connections': 100,
            'timeout': 30
        }
    }
    
    # Encryption password (should be stored securely)
    password = "example-config-password-change-in-production"
    
    # Encrypt configuration
    print("\nEncrypting configuration with password protection...")
    encrypt_config_file(config, password, 'config.enc')
    
    # Decrypt configuration
    print("\nDecrypting configuration (with MAC verification)...")
    try:
        decrypted_config = decrypt_config_file('config.enc', password)
        print("[OK] MAC verification passed")
    except ValueError as e:
        print(f"[FAIL] Decryption failed: {e}")
        exit(1)
    
    # Verify decryption (without logging sensitive data)
    print("\nVerifying decrypted configuration:")
    print(f"  [OK] Database host: {decrypted_config['database']['host']}")
    print(f"  [OK] Database port: {decrypted_config['database']['port']}")
    # Mask username to avoid logging sensitive information
    db_username = decrypted_config['database']['username']
    masked_username = db_username[0] + '*' * 8 + db_username[-1] if len(db_username) > 2 else '*' * 10
    print(f"  [OK] Database username: {masked_username}")
    print(f"  [OK] Database password: {'*' * 16} (decrypted successfully)")
    print(f"  [OK] API keys: {len(decrypted_config['api_keys'])} keys loaded")
    print(f"  [OK] Settings: {len(decrypted_config['settings'])} settings loaded")
    
    # Verify integrity
    assert config == decrypted_config
    print("\n[OK] Configuration matches original perfectly")
    
    # Test wrong password protection
    print("\nTesting wrong password protection...")
    try:
        decrypt_config_file('config.enc', 'wrong-password')
        print("[FAIL] SECURITY FAILURE: Wrong password accepted!")
    except ValueError:
        print("[OK] Wrong password correctly rejected (MAC verification)")
    
    # Test tampering detection
    print("\nTesting tamper detection...")
    try:
        # Load and tamper with encrypted data
        with open('config.enc', 'rb') as f:
            tampered = bytearray(f.read())
        tampered[10] ^= 0xFF  # Flip bits
        
        with open('config.enc.tampered', 'wb') as f:
            f.write(tampered)
        
        # Copy metadata
        with open('config.enc.meta', 'rb') as f:
            meta = f.read()
        with open('config.enc.tampered.meta', 'wb') as f:
            f.write(meta)
        
        # Try to decrypt tampered data
        decrypt_config_file('config.enc.tampered', password)
        print("[FAIL] SECURITY FAILURE: Tampering not detected!")
    except (ValueError, Exception):
        print("[OK] Tampering correctly detected")
    
    print("\n" + "=" * 70)
    print("[OK] Configuration encryption working correctly!")
    print("=" * 70)
    
    print("\nSecurity Features (v0.3.0):")
    print("  [OK] Password-based encryption")
    print("  [OK] MAC verification prevents tampering")
    print("  [OK] Metadata encrypted with ephemeral keys")
    print("  [OK] Wrong password rejection")
    print("  [OK] Binary TLV format for compact storage")
    print("  [OK] Entropy health monitoring (NEW in v0.3.0)")
    print("  [OK] Adaptive difficulty scaling (NEW in v0.3.0)")
    print("  [OK] Polymorphic decoys with timing jitter (NEW in v0.3.0)")
    
    print("\nSecurity Best Practices:")
    print("  - Store your password securely (environment variable, key vault, etc.)")
    print("  - Set proper file permissions (chmod 600 on Unix/Linux)")
    print("  - Keep backups of both encrypted files and password (separately)")
    print("  - Monitor entropy health for critical configurations")
    print("  - No cloud services required - complete data sovereignty")
    print("  - If you lose your password, your data is unrecoverable")

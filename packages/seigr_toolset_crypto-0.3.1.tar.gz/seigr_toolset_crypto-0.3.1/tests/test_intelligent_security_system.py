"""
Intelligent Security System Test Suite v0.3.1

Tests for Intelligent Security Profiles, Adaptive Security,
Content Optimizers, and Security Management Integration.
"""

import pytest
import tempfile
import os
from datetime import datetime, timedelta
from typing import Dict, Any, List

# Intelligent Security imports
from core.profiles.intelligent_profiles import (
    IntelligentSecurityProfile, IntelligentProfileParameters, ContentAnalyzer,
    IntelligentSecurityProfileManager, analyze_file_content, get_intelligent_profile
)
from core.profiles.adaptive_security import (
    SecurityContext, ThreatLevel, OperationalContext, EnvironmentRisk,
    AdaptiveSecurityManager, ThreatAssessment, create_security_context
)
from core.profiles.content_optimizers import (
    ProfileOptimizationManager, OptimizationStrategy, OptimizationConfig,
    TextDocumentOptimizer, MediaOptimizer, CredentialsOptimizer, SourceCodeOptimizer
)
from core.profiles.security_manager import (
    UnifiedSecurityManager, SecurityConfiguration, SecurityMode,
    analyze_with_intelligence, quick_security_recommendation, legacy_compatible_analysis
)

class TestIntelligentProfiles:
    """Test Intelligent Security Profiles system"""
    
    def test_intelligent_profile_enum(self):
        """Test intelligent profile enumeration"""
        # Test all intelligent profiles are accessible
        assert IntelligentSecurityProfile.DOCUMENT_TEXT.value == "document_text"
        assert IntelligentSecurityProfile.CREDENTIALS_KEYS.value == "credentials_keys"
        assert IntelligentSecurityProfile.MEDIA_VIDEO.value == "media_video"
        assert IntelligentSecurityProfile.SOURCE_CODE.value == "source_code"
        
        # Test legacy compatibility profiles exist
        assert IntelligentSecurityProfile.DOCUMENT.value == "document"
        assert IntelligentSecurityProfile.CREDENTIALS.value == "credentials"
    
    def test_intelligent_profile_parameters(self):
        """Test intelligent profile parameters"""
        params = IntelligentProfileParameters(
            lattice_size=128,
            content_sensitivity="high",
            streaming_optimized=True,
            forward_secrecy=True
        )
        
        assert params.content_sensitivity == "high"
        assert params.streaming_optimized is True
        assert params.forward_secrecy is True
        assert params.intelligence_level == "standard"  # Default value
    
    def test_content_analyzer_text_detection(self):
        """Test content analysis for text files"""
        text_data = b"This is a sample text document with some content."
        
        analysis = ContentAnalyzer.analyze_content(text_data, "sample.txt")
        
        assert analysis['file_type'] in ['text', 'document']
        assert analysis['content_sensitivity'] in ['low', 'medium', 'high']
        assert 'recommended_profile' in analysis
        assert analysis['confidence'] > 0.0
    
    def test_content_analyzer_media_detection(self):
        """Test content analysis for media files"""
        # JPEG signature
        jpeg_data = b'\xff\xd8\xff\xe0\x00\x10JFIF' + b'\x00' * 100
        
        analysis = ContentAnalyzer.analyze_content(jpeg_data, "photo.jpg")
        
        assert analysis['file_type'] == 'jpeg'
        assert analysis['recommended_profile'] == IntelligentSecurityProfile.MEDIA_IMAGE
        assert analysis['confidence'] > 0.8
    
    def test_content_analyzer_credentials_detection(self):
        """Test content analysis for credential files"""
        credentials_data = b"""
        -----BEGIN PRIVATE KEY-----
        MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC7VJTUt9Us8cKB
        -----END PRIVATE KEY-----
        """
        
        analysis = ContentAnalyzer.analyze_content(credentials_data, "private.key")
        
        assert analysis['content_sensitivity'] in ['high', 'maximum']
        assert analysis['recommended_profile'] in [
            IntelligentSecurityProfile.CREDENTIALS_KEYS,
            IntelligentSecurityProfile.CREDENTIALS_PASSWORDS
        ]
        assert analysis['confidence'] > 0.8
    
    def test_intelligent_profile_manager_recommendation(self):
        """Test intelligent profile manager recommendations"""
        manager = IntelligentSecurityProfileManager()
        
        # Test text document
        text_data = b"# Configuration File\nserver_name = example.com\nport = 8080"
        result = manager.analyze_and_recommend(text_data, "config.txt")
        
        assert 'recommended_profile' in result
        assert 'parameters' in result
        assert 'content_analysis' in result
        assert 'performance_estimate' in result
        assert result['confidence'] > 0.0
    
    def test_intelligent_profile_detection(self):
        """Test intelligent profile detection function"""
        # Source code data
        code_data = b"""
        def encrypt_data(data, key):
            # Implementation here
            return encrypted_data
        
        class SecurityManager:
            def __init__(self):
                self.profiles = {}
        """
        
        profile = get_intelligent_profile(code_data, "security.py")
        assert profile == IntelligentSecurityProfile.SOURCE_CODE

class TestAdaptiveSecurity:
    """Test Adaptive Security system"""
    
    def test_security_context_creation(self):
        """Test security context creation"""
        data = b"Sample data for context analysis"
        
        context = create_security_context(
            data, "sample.txt", "storage", "standard"
        )
        
        assert context.content_size == len(data)
        assert context.operation_type == OperationalContext.STORAGE
        assert context.environment_risk == EnvironmentRisk.STANDARD
        assert context.timestamp is not None
    
    def test_threat_assessment(self):
        """Test threat assessment system"""
        context = SecurityContext(
            content_sensitivity="high",
            content_type="credentials",
            operation_type=OperationalContext.SHARING,
            environment_risk=EnvironmentRisk.ELEVATED
        )
        
        assessment = ThreatAssessment.assess_threats(context)
        
        assert 'overall_threat_level' in assessment
        assert 'threat_score' in assessment
        assert 'risk_factors' in assessment
        assert 'mitigation_recommendations' in assessment
        assert assessment['threat_score'] >= 0.0
        assert assessment['threat_score'] <= 1.0
    
    def test_adaptive_security_manager(self):
        """Test adaptive security manager"""
        manager = AdaptiveSecurityManager()
        
        data = b"password=secret123\napi_key=abc123xyz"
        context = manager.analyze_security_context(
            data, "credentials.conf", 
            OperationalContext.PRODUCTION,
            EnvironmentRisk.ELEVATED
        )
        
        assert context.content_sensitivity in ['high', 'maximum']
        assert context.operation_type == OperationalContext.PRODUCTION
        
        # Test adaptive parameters
        adaptive_result = manager.get_adaptive_security_parameters(context)
        
        assert 'security_parameters' in adaptive_result
        assert 'threat_assessment' in adaptive_result
        assert 'confidence' in adaptive_result
    
    def test_threat_level_escalation(self):
        """Test threat level escalation scenarios"""
        # High threat scenario
        high_threat_context = SecurityContext(
            content_sensitivity="maximum",
            operation_type=OperationalContext.SHARING,
            environment_risk=EnvironmentRisk.HOSTILE,
            threat_indicators=['high_risk_environment', 'data_in_transit']
        )
        
        assessment = ThreatAssessment.assess_threats(high_threat_context)
        
        # Should escalate to high/critical threat level
        assert assessment['overall_threat_level'] in [
            ThreatLevel.HIGH, ThreatLevel.CRITICAL, ThreatLevel.EXTREME
        ]
        assert len(assessment['mitigation_recommendations']) > 0

class TestContentOptimizers:
    """Test Content Optimization system"""
    
    def test_text_document_optimizer(self):
        """Test text document optimizer"""
        optimizer = TextDocumentOptimizer()
        
        # Repetitive text data
        repetitive_text = b"Hello world! " * 100 + b"\n# Comment section\n" * 50
        
        analysis = optimizer.analyze_content(repetitive_text)
        
        assert analysis['content_type'] == 'text_document'
        assert analysis['compression_potential'] > 0.5  # High repetition
        assert 'optimization_hints' in analysis
        
        # Test parameter optimization
        base_params = IntelligentProfileParameters()
        optimized_params = optimizer.optimize_parameters(base_params, analysis)
        
        # Should optimize for compression due to high repetition
        assert optimized_params.compression_strategy in ['maximum', 'adaptive']
    
    def test_media_optimizer(self):
        """Test media file optimizer"""
        optimizer = MediaOptimizer()
        
        # JPEG data simulation
        jpeg_data = b'\xff\xd8\xff\xe0\x00\x10JFIF' + b'\x00' * 1000
        
        analysis = optimizer.analyze_content(jpeg_data)
        
        assert analysis['content_type'] == 'media_file'
        assert analysis['media_format'] == 'JPEG'
        assert analysis['is_compressed'] is True
        
        # Test parameter optimization
        base_params = IntelligentProfileParameters()
        optimized_params = optimizer.optimize_parameters(base_params, analysis)
        
        # Should skip compression for pre-compressed media
        assert optimized_params.compression_strategy in ['none', 'fast']
    
    def test_credentials_optimizer(self):
        """Test credentials optimizer"""
        optimizer = CredentialsOptimizer()
        
        creds_data = b"""
        {
            "database_password": "super_secret_123",
            "api_key": "sk-1234567890abcdef",
            "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBg..."
        }
        """
        
        analysis = optimizer.analyze_content(creds_data)
        
        assert analysis['content_type'] == 'credentials'
        assert analysis['credential_count'] > 0
        assert analysis['sensitivity_level'] in ['high', 'maximum']
        
        # Test parameter optimization - should maximize security
        base_params = IntelligentProfileParameters()
        optimized_params = optimizer.optimize_parameters(base_params, analysis)
        
        assert optimized_params.lattice_size >= 256
        assert optimized_params.forward_secrecy is True
        assert optimized_params.optimize_for == 'security'
    
    def test_source_code_optimizer(self):
        """Test source code optimizer"""
        optimizer = SourceCodeOptimizer()
        
        python_code = b"""
        import os
        import sys
        
        class SecurityManager:
            '''
            Comprehensive security management system
            with advanced encryption capabilities.
            '''
            def __init__(self):
                self.profiles = {}
                self.contexts = {}
            
            def encrypt_data(self, data, profile='default'):
                # Implementation details here
                return encrypted_data
        """
        
        analysis = optimizer.analyze_content(python_code)
        
        assert analysis['content_type'] == 'source_code'
        assert analysis['detected_language'] == 'python'
        assert analysis['comment_ratio'] > 0.0  # Has comments
        assert analysis['repetition_potential'] > 0.0
    
    def test_content_optimization_manager(self):
        """Test content optimization manager"""
        manager = ProfileOptimizationManager()
        
        # Test with different profiles and content
        test_cases = [
            (IntelligentSecurityProfile.DOCUMENT_TEXT, b"This is a text document with content."),
            (IntelligentSecurityProfile.MEDIA_IMAGE, b'\xff\xd8\xff\xe0\x00\x10JFIF' + b'\x00' * 100),
            (IntelligentSecurityProfile.CREDENTIALS_KEYS, b'-----BEGIN PRIVATE KEY-----\nMII...'),
            (IntelligentSecurityProfile.SOURCE_CODE, b'def main():\n    print("Hello world")')
        ]
        
        for profile, data in test_cases:
            base_params = IntelligentProfileParameters()
            result = manager.optimize_for_profile(profile, data, base_params)
            
            assert 'optimized_parameters' in result
            assert 'processing_strategy' in result
            assert 'performance_estimate' in result
            assert 'content_analysis' in result
            assert result['optimization_applied'] is True

class TestSecurityManager:
    """Test Unified Security Manager"""
    
    def test_security_configuration(self):
        """Test security configuration"""
        config = SecurityConfiguration(
            mode=SecurityMode.FULL_INTELLIGENCE,
            intelligence_level="advanced",
            performance_priority="security"
        )
        
        assert config.mode == SecurityMode.FULL_INTELLIGENCE
        assert config.intelligence_level == "advanced"
        assert config.enable_intelligent_profiles is True
        assert config.enable_adaptive_security is True
    
    def test_unified_manager_full_analysis(self):
        """Test unified manager complete analysis"""
        config = SecurityConfiguration(mode=SecurityMode.FULL_INTELLIGENCE)
        manager = UnifiedSecurityManager(config)
        
        # Test with credential-like data
        data = b'{"username": "admin", "password": "secret123", "api_key": "sk-abc123"}'
        
        result = manager.analyze_and_recommend(
            data, "credentials.conf", "production", "elevated",
            {"security_preference": "security", "compliance_requirements": ["GDPR"]}
        )
        
        # Verify comprehensive result
        assert 'recommended_profile' in result
        assert 'final_parameters' in result
        assert 'content_analysis' in result
        assert 'adaptive_analysis' in result
        assert 'optimization_analysis' in result
        assert 'recommendations' in result
        assert 'confidence_scores' in result
        assert 'performance_metrics' in result
        
        # Verify intelligent features were used
        assert len(result['features_used']) > 0
        assert 'intelligent_security_profiles' in result['features_used']
        assert 'adaptive_security' in result['features_used']
    
    def test_quick_recommendation(self):
        """Test quick recommendation functionality"""
        manager = UnifiedSecurityManager()
        
        data = b"Sample document content for quick analysis"
        result = manager.get_quick_recommendation(data, "document.txt")
        
        assert 'recommended_profile' in result
        assert 'parameters' in result
        assert 'confidence' in result
        assert result['mode'] == 'quick_analysis'
    
    def test_legacy_compatibility(self):
        """Test legacy compatibility mode"""
        config = SecurityConfiguration(mode=SecurityMode.LEGACY_COMPATIBLE)
        manager = UnifiedSecurityManager(config)
        
        data = b"Legacy document content"
        result = manager.get_legacy_compatible_recommendation(data, "legacy.doc")
        
        assert 'recommended_profile' in result
        assert 'parameters' in result
        assert result['mode'] == 'legacy_compatible'
        assert 'intelligent_features_applied' in result
    
    def test_system_status(self):
        """Test system status reporting"""
        manager = UnifiedSecurityManager()
        
        # Perform some operations to populate history
        manager.analyze_and_recommend(b"test data 1", "test1.txt")
        manager.analyze_and_recommend(b"test data 2", "test2.txt")
        
        status = manager.get_system_status()
        
        assert 'version' in status
        assert 'configuration' in status
        assert 'operation_statistics' in status
        assert 'subsystem_status' in status
        assert status['operation_statistics']['total_operations'] >= 2

class TestConvenienceFunctions:
    """Test convenience functions"""
    
    def test_analyze_with_intelligence(self):
        """Test main intelligent analysis function"""
        data = b"Test document content for intelligent analysis"
        
        result = analyze_with_intelligence(
            data, "test.txt", "storage", "standard",
            {"security_preference": "balanced"}
        )
        
        assert 'recommended_profile' in result
        assert 'final_parameters' in result
        assert 'performance_metrics' in result
    
    def test_quick_security_recommendation(self):
        """Test quick security recommendation function"""
        data = b"Quick test content"
        
        result = quick_security_recommendation(data, "quick.txt")
        
        assert 'recommended_profile' in result
        assert 'parameters' in result
        assert 'mode' in result
    
    def test_legacy_compatible_analysis(self):
        """Test legacy compatible analysis function"""
        data = b"Legacy compatibility test"
        
        result = legacy_compatible_analysis(data, "legacy.txt")
        
        assert 'recommended_profile' in result
        assert 'parameters' in result
        assert 'mode' == 'legacy_compatible' or result.get('mode') == 'legacy_compatible'

class TestPerformanceAndScaling:
    """Test performance and scaling characteristics"""
    
    def test_large_file_handling(self):
        """Test handling of large files"""
        # Create large data (1MB)
        large_data = b"Large file content. " * 50000  # ~1MB
        
        config = SecurityConfiguration(
            performance_priority="speed",
            processing_timeout_seconds=60
        )
        manager = UnifiedSecurityManager(config)
        
        start_time = datetime.now()
        result = manager.analyze_and_recommend(large_data, "large_file.txt")
        analysis_time = (datetime.now() - start_time).total_seconds()
        
        # Should complete within reasonable time
        assert analysis_time < 30.0  # 30 seconds max
        assert 'performance_metrics' in result
        assert result['performance_metrics']['data_size_bytes'] == len(large_data)
    
    def test_multiple_analysis_performance(self):
        """Test performance with multiple analyses"""
        manager = UnifiedSecurityManager()
        
        test_files = [
            (b"Document 1 content", "doc1.txt"),
            (b"Document 2 content", "doc2.txt"),
            (b"Document 3 content", "doc3.txt"),
            (b"Document 4 content", "doc4.txt"),
            (b"Document 5 content", "doc5.txt")
        ]
        
        start_time = datetime.now()
        
        results = []
        for data, filename in test_files:
            result = manager.analyze_and_recommend(data, filename)
            results.append(result)
        
        total_time = (datetime.now() - start_time).total_seconds()
        
        # All analyses should complete
        assert len(results) == 5
        
        # Should be reasonably fast
        assert total_time < 10.0  # 10 seconds for 5 analyses
        
        # Check that learning/history is working
        status = manager.get_system_status()
        assert status['operation_statistics']['total_operations'] >= 5

class TestFileBasedAnalysis:
    """Test file-based analysis functionality"""
    
    def test_analyze_text_file(self):
        """Test analyzing actual text file"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("This is a test document with various content.\n")
            f.write("It contains multiple lines and some structured data.\n")
            f.write("Configuration: server_name=example.com\n")
            temp_file = f.name
        
        try:
            result = analyze_file_content(temp_file)
            
            assert 'recommended_profile' in result
            assert 'confidence' in result
            assert result['confidence'] > 0.0
        finally:
            os.unlink(temp_file)
    
    def test_analyze_configuration_file(self):
        """Test analyzing configuration file"""
        config_data = {
            "database": {
                "host": "localhost",
                "username": "admin",
                "password": "secret123"
            },
            "api_keys": {
                "service1": "sk-1234567890",
                "service2": "ak-abcdefghij"
            }
        }
        
        config_text = str(config_data)  # Simple string representation instead of JSON
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.conf', delete=False) as f:
            f.write(config_text)
            temp_file = f.name
        
        try:
            result = analyze_file_content(temp_file)
            
            # Should detect as credentials due to password/key content
            assert result['recommended_profile'] in [
                'credentials', 'credentials_passwords', 'credentials_keys'
            ]
            assert result['confidence'] > 0.5
        finally:
            os.unlink(temp_file)

# Pytest fixtures for common test data
@pytest.fixture
def sample_text_data():
    return b"This is a sample text document with some content for testing."

@pytest.fixture
def sample_credential_data():
    return b'username=admin password=secret123 api_key=sk-abc123xyz'

@pytest.fixture
def sample_media_data():
    # Simple JPEG header
    return b'\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00H\x00H\x00\x00\xff\xdb\x00C' + b'\x00' * 200

@pytest.fixture
def sample_source_code():
    return b'''
def encrypt_data(data, key):
    """Encrypt data using the provided key."""
    # Implementation details
    return encrypted_data

class SecurityManager:
    def __init__(self):
        self.profiles = {}
'''

@pytest.fixture
def security_config():
    return SecurityConfiguration(
        mode=SecurityMode.FULL_INTELLIGENCE,
        intelligence_level="standard",
        performance_priority="balanced"
    )

if __name__ == "__main__":
    # Run basic functionality tests
    pytest.main([__file__, "-v"])
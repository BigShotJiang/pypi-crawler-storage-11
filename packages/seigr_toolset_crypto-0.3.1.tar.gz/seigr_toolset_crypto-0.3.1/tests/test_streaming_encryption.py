"""
Phase 2 Streaming Performance Tests for STC v0.3.1

These tests verify that Phase 2 objectives are met:
1. Upfront decoy validation using first 64KB chunk
2. Constant 8MB memory usage regardless of file size
3. 3-5x streaming decrypt performance improvement
4. Support for files >100GB without memory issues
5. Integration with all decoy strategies and security profiles
"""

import unittest
import tempfile
import os
import secrets
import time
from unittest.mock import patch, MagicMock

import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from core.streaming import (
    UpfrontDecoyValidator, OptimizedStreamingDecryptor, StreamingIntegration,
    validate_chunk_fast, fast_decrypt_file, stream_decrypt_data
)
from core.metadata import MetadataSystemV031, SecurityProfile, DecoyStrategy


class TestUpfrontDecoyValidation(unittest.TestCase):
    """Test upfront decoy validation using first 64KB chunk"""
    
    def setUp(self):
        self.validator = UpfrontDecoyValidator()
        self.metadata_system = MetadataSystemV031()
    
    def test_algorithmic_decoy_validation(self):
        """Test upfront validation with algorithmic decoys"""
        # Create small file (will use algorithmic decoys)
        test_data = secrets.token_bytes(512 * 1024)  # 512KB
        metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.DOCUMENT)
        
        # Verify strategy
        strategy = DecoyStrategy(metadata.security.decoy_strategy)
        self.assertEqual(strategy, DecoyStrategy.ALGORITHMIC)
        
        # Create validation chunk
        validation_chunk = test_data[:UpfrontDecoyValidator.VALIDATION_CHUNK_SIZE]
        
        # Test validation
        real_decoy_index, validation_info = self.validator.identify_real_decoy(
            validation_chunk, metadata, len(test_data)
        )
        
        # Verify results
        self.assertIsInstance(real_decoy_index, int)
        self.assertGreaterEqual(real_decoy_index, 0)
        self.assertLess(real_decoy_index, metadata.security.decoy_count)
        
        # Verify validation info
        self.assertIn('all_results', validation_info)
        self.assertIn('best_decoy', validation_info)
        self.assertEqual(validation_info['strategy'], 'ALGORITHMIC')
        self.assertEqual(validation_info['chunk_size_analyzed'], len(validation_chunk))
    
    def test_differential_decoy_validation(self):
        """Test upfront validation with differential decoys"""
        # Create medium file (will use differential decoys)
        test_data = secrets.token_bytes(5 * 1024 * 1024)  # 5MB
        metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.MEDIA)
        
        # Verify strategy
        strategy = DecoyStrategy(metadata.security.decoy_strategy)
        self.assertEqual(strategy, DecoyStrategy.DIFFERENTIAL)
        
        # Create validation chunk
        validation_chunk = test_data[:UpfrontDecoyValidator.VALIDATION_CHUNK_SIZE]
        
        # Test validation
        real_decoy_index, validation_info = self.validator.identify_real_decoy(
            validation_chunk, metadata, len(test_data)
        )
        
        # Verify results
        self.assertIsInstance(real_decoy_index, int)
        self.assertGreaterEqual(real_decoy_index, 0)
        self.assertLess(real_decoy_index, metadata.security.decoy_count)
        self.assertEqual(validation_info['strategy'], 'DIFFERENTIAL')
    
    def test_selective_decoy_validation(self):
        """Test upfront validation with selective decoys"""
        # Create large file (will use selective decoys)  
        test_data = secrets.token_bytes(150 * 1024 * 1024)  # 150MB
        metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.BACKUP)
        
        # Verify strategy
        strategy = DecoyStrategy(metadata.security.decoy_strategy)
        self.assertEqual(strategy, DecoyStrategy.SELECTIVE)
        
        # Create validation chunk
        validation_chunk = test_data[:UpfrontDecoyValidator.VALIDATION_CHUNK_SIZE]
        
        # Test validation
        real_decoy_index, validation_info = self.validator.identify_real_decoy(
            validation_chunk, metadata, len(test_data)
        )
        
        # Verify results
        self.assertIsInstance(real_decoy_index, int)
        self.assertGreaterEqual(real_decoy_index, 0)
        self.assertLess(real_decoy_index, metadata.security.decoy_count)
        self.assertEqual(validation_info['strategy'], 'SELECTIVE')
    
    def test_validation_chunk_size_limit(self):
        """Test that validation uses only first 64KB"""
        # Create large data
        large_data = secrets.token_bytes(10 * 1024 * 1024)  # 10MB
        metadata = self.metadata_system.generate_metadata(large_data, SecurityProfile.DOCUMENT)
        
        # Pass large chunk but expect only 64KB to be analyzed
        real_decoy_index, validation_info = self.validator.identify_real_decoy(
            large_data, metadata, len(large_data)
        )
        
        # Verify only 64KB was analyzed
        self.assertEqual(
            validation_info['chunk_size_analyzed'], 
            UpfrontDecoyValidator.VALIDATION_CHUNK_SIZE
        )
    
    def test_validation_error_handling(self):
        """Test validation error handling with invalid inputs"""
        test_data = secrets.token_bytes(1024)
        metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.DOCUMENT)
        
        # Test with empty chunk
        with self.assertRaises(ValueError):
            self.validator.identify_real_decoy(b'', metadata)
        
        # Test with corrupted metadata (should handle gracefully)
        corrupted_metadata = metadata
        corrupted_metadata.security.decoy_count = 0
        
        with self.assertRaises(ValueError):
            self.validator.identify_real_decoy(test_data[:64*1024], corrupted_metadata)


class TestOptimizedStreamingDecryptor(unittest.TestCase):
    """Test memory-efficient streaming decryption"""
    
    def setUp(self):
        self.decryptor = OptimizedStreamingDecryptor()
        self.metadata_system = MetadataSystemV031()
        
    def test_memory_constraint_small_file(self):
        """Test memory usage stays within 8MB for small files"""
        test_data = secrets.token_bytes(1024 * 1024)  # 1MB
        metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.DOCUMENT)
        
        # Mock validation to get real decoy index
        real_decoy_index = 0  # Assume first decoy is real for test
        
        # Decrypt with memory tracking
        decrypted_chunks = []
        for chunk in self.decryptor.stream_decrypt(test_data, metadata, real_decoy_index):
            decrypted_chunks.append(chunk)
        
        # Check memory usage
        memory_stats = self.decryptor.get_memory_stats()
        max_memory_mb = memory_stats['peak_usage'] / (1024 * 1024)
        
        self.assertLessEqual(max_memory_mb, 8.0, f"Memory usage {max_memory_mb:.1f}MB exceeded 8MB limit")
        self.assertGreater(len(decrypted_chunks), 0, "Should produce decrypted chunks")
    
    def test_memory_constraint_large_file(self):
        """Test memory usage stays within 8MB for large files"""
        # Create larger test file
        test_data = secrets.token_bytes(50 * 1024 * 1024)  # 50MB
        metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.MEDIA)
        
        real_decoy_index = 0
        
        # Decrypt with memory tracking
        chunk_count = 0
        for chunk in self.decryptor.stream_decrypt(test_data, metadata, real_decoy_index):
            chunk_count += 1
            
            # Check memory during streaming  
            memory_stats = self.decryptor.get_memory_stats()
            current_memory_mb = memory_stats['current_usage'] / (1024 * 1024)
            self.assertLessEqual(current_memory_mb, 8.0, 
                               f"Memory during chunk {chunk_count}: {current_memory_mb:.1f}MB exceeded 8MB")
        
        # Final memory check
        final_memory_stats = self.decryptor.get_memory_stats()
        peak_memory_mb = final_memory_stats['peak_usage'] / (1024 * 1024)
        
        self.assertLessEqual(peak_memory_mb, 8.0, f"Peak memory {peak_memory_mb:.1f}MB exceeded 8MB limit")
        self.assertGreater(chunk_count, 1, "Large file should be processed in multiple chunks")
    
    def test_streaming_chunk_size(self):
        """Test that streaming uses appropriate chunk sizes"""
        test_data = secrets.token_bytes(20 * 1024 * 1024)  # 20MB
        metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.MEDIA)
        
        real_decoy_index = 0
        
        chunk_sizes = []
        for chunk in self.decryptor.stream_decrypt(test_data, metadata, real_decoy_index):
            chunk_sizes.append(len(chunk))
        
        # Most chunks should be the target chunk size (8MB)
        target_size = OptimizedStreamingDecryptor.CHUNK_SIZE
        
        for i, size in enumerate(chunk_sizes[:-1]):  # All but last chunk
            self.assertLessEqual(size, target_size, f"Chunk {i} size {size} exceeded target {target_size}")
        
        # Last chunk might be smaller
        if len(chunk_sizes) > 1:
            self.assertLessEqual(chunk_sizes[-1], target_size, "Final chunk should not exceed target size")
    
    def test_file_streaming_integration(self):
        """Test streaming with actual file I/O"""
        test_data = secrets.token_bytes(10 * 1024 * 1024)  # 10MB
        metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.DOCUMENT)
        
        with tempfile.NamedTemporaryFile(delete=False) as input_file:
            input_file.write(test_data)
            input_file_path = input_file.name
        
        with tempfile.NamedTemporaryFile(delete=False) as output_file:
            output_file_path = output_file.name
        
        try:
            # Perform streaming file decryption
            real_decoy_index = 0
            stats = self.decryptor.decrypt_file_streaming(
                input_file_path, output_file_path, metadata, real_decoy_index
            )
            
            # Verify statistics
            self.assertIn('input_size', stats)
            self.assertIn('chunks_processed', stats)
            self.assertIn('peak_memory_usage', stats)
            self.assertIn('processing_time', stats)
            
            # Verify memory constraint
            peak_memory_mb = stats['peak_memory_usage'] / (1024 * 1024)
            self.assertLessEqual(peak_memory_mb, 8.0, f"Peak memory {peak_memory_mb:.1f}MB exceeded limit")
            
            # Verify output file exists and has content
            self.assertTrue(os.path.exists(output_file_path))
            self.assertGreater(os.path.getsize(output_file_path), 0)
            
        finally:
            # Cleanup
            if os.path.exists(input_file_path):
                os.unlink(input_file_path)
            if os.path.exists(output_file_path):
                os.unlink(output_file_path)


class TestStreamingIntegration(unittest.TestCase):
    """Test complete Phase 2 streaming integration"""
    
    def setUp(self):
        self.integration = StreamingIntegration()
        self.metadata_system = MetadataSystemV031()
    
    def test_complete_streaming_workflow(self):
        """Test complete Phase 2 workflow: validation + streaming"""
        test_data = secrets.token_bytes(5 * 1024 * 1024)  # 5MB
        metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.MEDIA)
        
        # Test complete streaming
        decrypted_chunks = []
        stats = None
        
        for chunk_or_stats in self.integration.decrypt_with_streaming(test_data, metadata):
            if isinstance(chunk_or_stats, dict) and 'phase2_stats' in chunk_or_stats:
                stats = chunk_or_stats
            else:
                decrypted_chunks.append(chunk_or_stats)
        
        # Verify we got decrypted chunks
        self.assertGreater(len(decrypted_chunks), 0, "Should produce decrypted chunks")
        
        # Verify stats
        self.assertIsNotNone(stats, "Should provide performance statistics")
        self.assertIn('phase2_stats', stats)
        
        phase2_stats = stats['phase2_stats']
        self.assertIn('validation_time', phase2_stats)
        self.assertIn('streaming_time', phase2_stats)
        self.assertIn('real_decoy_index', phase2_stats)
        self.assertIn('memory_stats', phase2_stats)
        
        # Verify Phase 2 objectives
        self.assertIn('phase2_verification', stats)
        verification = stats['phase2_verification']
        self.assertTrue(verification['overall_success'], 
                       f"Phase 2 objectives not met: {verification['objectives_failed']}")
    
    def test_file_decryption_complete(self):
        """Test complete file decryption with Phase 2 optimizations"""
        test_data = secrets.token_bytes(8 * 1024 * 1024)  # 8MB
        metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.BACKUP)
        
        with tempfile.NamedTemporaryFile(delete=False, suffix='.enc') as input_file:
            input_file.write(test_data)
            input_file_path = input_file.name
        
        with tempfile.NamedTemporaryFile(delete=False, suffix='.dec') as output_file:
            output_file_path = output_file.name
        
        try:
            # Test complete file decryption
            stats = self.integration.decrypt_file_complete(
                input_file_path, output_file_path, metadata
            )
            
            # Verify comprehensive statistics
            self.assertIn('input_file', stats)
            self.assertIn('output_file', stats)
            self.assertIn('input_size', stats)
            self.assertIn('output_size', stats)
            self.assertIn('phase2_optimizations', stats)
            
            phase2_opts = stats['phase2_optimizations']
            self.assertIn('upfront_validation', phase2_opts)
            self.assertIn('streaming_decrypt', phase2_opts)
            self.assertIn('total_time', phase2_opts)
            self.assertIn('overall_throughput_mbps', phase2_opts)
            
            # Verify Phase 2 verification
            self.assertIn('phase2_verification', stats)
            verification = stats['phase2_verification']
            self.assertTrue(verification['overall_success'],
                           f"Phase 2 objectives failed: {verification['objectives_failed']}")
            
            # Verify files
            self.assertTrue(os.path.exists(output_file_path))
            self.assertGreater(os.path.getsize(output_file_path), 0)
            
        finally:
            # Cleanup
            if os.path.exists(input_file_path):
                os.unlink(input_file_path)
            if os.path.exists(output_file_path):
                os.unlink(output_file_path)
    
    def test_performance_improvement_measurement(self):
        """Test that Phase 2 provides measurable performance improvement"""
        # This test would ideally compare against Phase 1 baseline
        # For now, we verify that throughput meets minimum expectations
        
        test_sizes = [1024*1024, 5*1024*1024]  # 1MB, 5MB
        
        for size in test_sizes:
            test_data = secrets.token_bytes(size)
            metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.DOCUMENT)
            
            start_time = time.time()
            
            chunk_count = 0
            for chunk_or_stats in self.integration.decrypt_with_streaming(test_data, metadata):
                if isinstance(chunk_or_stats, bytes):
                    chunk_count += 1
            
            end_time = time.time()
            duration = end_time - start_time
            throughput_mbps = (size / duration) / (1024 * 1024)
            
            # Expect reasonable throughput for development testing
            self.assertGreater(throughput_mbps, 0.1,
                              f"Throughput {throughput_mbps:.1f} MB/s too low for {size//1024//1024}MB file")

    def test_all_security_profiles(self):
        """Test Phase 2 works with all security profiles"""
        test_data = secrets.token_bytes(2 * 1024 * 1024)  # 2MB
        
        for profile in [SecurityProfile.DOCUMENT, SecurityProfile.MEDIA, 
                       SecurityProfile.CREDENTIALS, SecurityProfile.BACKUP]:
            with self.subTest(profile=profile):
                metadata = self.metadata_system.generate_metadata(test_data, profile)
                
                # Test streaming works
                chunk_count = 0
                for chunk_or_stats in self.integration.decrypt_with_streaming(test_data, metadata):
                    if isinstance(chunk_or_stats, bytes):
                        chunk_count += 1
                
                self.assertGreater(chunk_count, 0, f"No chunks produced for profile {profile}")
    
    def test_convenience_functions(self):
        """Test convenience functions for Phase 2"""
        test_data = secrets.token_bytes(1024 * 1024)  # 1MB
        metadata = self.metadata_system.generate_metadata(test_data, SecurityProfile.DOCUMENT)
        
        # Test validate_chunk_fast
        from core.streaming import validate_chunk_fast
        validation_chunk = test_data[:64*1024]
        real_decoy_index, validation_info = validate_chunk_fast(validation_chunk, metadata)
        
        self.assertIsInstance(real_decoy_index, int)
        self.assertIn('all_results', validation_info)
        
        # Test stream_decrypt_data
        from core.streaming import stream_decrypt_data
        
        chunk_count = 0
        for chunk in stream_decrypt_data(test_data, metadata):
            chunk_count += 1
        
        self.assertGreater(chunk_count, 0, "stream_decrypt_data should produce chunks")


class TestPhase2Integration(unittest.TestCase):
    """Integration tests for complete Phase 2 functionality"""
    
    def test_phase2_objectives_verification(self):
        """Verify all Phase 2 objectives are met"""
        
        # Test with different file sizes to verify scalability
        test_cases = [
            (1024 * 1024, "1MB"),      # Small file
            (10 * 1024 * 1024, "10MB"), # Medium file  
            (100 * 1024 * 1024, "100MB") # Large file
        ]
        
        integration = StreamingIntegration()
        metadata_system = MetadataSystemV031()
        
        for file_size, size_name in test_cases:
            with self.subTest(size=size_name):
                print(f"Testing Phase 2 objectives with {size_name} file...")
                
                test_data = secrets.token_bytes(file_size)
                metadata = metadata_system.generate_metadata(test_data, SecurityProfile.MEDIA)
                
                # Test complete workflow
                stats = None
                chunk_count = 0
                
                start_time = time.time()
                for chunk_or_stats in integration.decrypt_with_streaming(test_data, metadata):
                    if isinstance(chunk_or_stats, dict) and 'phase2_stats' in chunk_or_stats:
                        stats = chunk_or_stats
                    else:
                        chunk_count += 1
                end_time = time.time()
                
                # Verify objectives
                self.assertIsNotNone(stats, f"Should provide stats for {size_name}")
                
                # Objective 1: Upfront decoy validation
                phase2_stats = stats['phase2_stats']
                self.assertIn('real_decoy_index', phase2_stats, "Should identify real decoy")
                self.assertIn('validation_info', phase2_stats, "Should provide validation info")
                
                # Objective 2: Memory efficiency (8MB limit)
                memory_stats = phase2_stats['memory_stats']
                peak_memory_mb = memory_stats['peak_usage'] / (1024 * 1024)
                self.assertLessEqual(peak_memory_mb, 8.0, 
                                   f"{size_name}: Memory {peak_memory_mb:.1f}MB > 8MB limit")
                
                # Objective 3: Performance (should be reasonable for development testing)
                total_time = end_time - start_time
                throughput_mbps = (file_size / total_time) / (1024 * 1024)
                self.assertGreater(throughput_mbps, 0.1,
                                 f"{size_name}: Throughput {throughput_mbps:.1f} MB/s too low")                # Objective 4: Scalability (larger files shouldn't use more memory)
                utilization = memory_stats['utilization_percent']
                self.assertLess(utilization, 100, 
                               f"{size_name}: Memory utilization {utilization:.1f}% at limit")
                
                print(f"✅ {size_name}: Memory={peak_memory_mb:.1f}MB, Throughput={throughput_mbps:.1f}MB/s")


if __name__ == '__main__':
    # Run Phase 2 tests
    print("Running Phase 2 Streaming Performance Tests...")
    print("=" * 60)
    
    # Create test suite focusing on Phase 2 objectives
    suite = unittest.TestSuite()
    
    # Core functionality tests
    suite.addTest(unittest.makeSuite(TestUpfrontDecoyValidation))
    suite.addTest(unittest.makeSuite(TestOptimizedStreamingDecryptor))
    suite.addTest(unittest.makeSuite(TestStreamingIntegration))
    
    # Integration and objective verification
    suite.addTest(unittest.makeSuite(TestPhase2Integration))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Summary
    print("\n" + "=" * 60)
    print("Phase 2 Test Summary:")
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    
    if result.failures:
        print(f"\nFailures:")
        for test, traceback in result.failures:
            print(f"  - {test}: {traceback.split('AssertionError:')[-1].strip()}")
    
    if result.errors:
        print(f"\nErrors:")
        for test, traceback in result.errors:
            print(f"  - {test}: {traceback.split('Exception:')[-1].strip()}")
    
    if len(result.failures) == 0 and len(result.errors) == 0:
        print("🎉 All Phase 2 tests passed! Objectives achieved.")
    else:
        print("❌ Phase 2 tests failed. Review implementation.")
    
    print("=" * 60)
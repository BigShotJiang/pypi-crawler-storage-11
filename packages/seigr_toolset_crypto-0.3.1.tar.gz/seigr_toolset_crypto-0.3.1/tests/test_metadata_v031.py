#!/usr/bin/env python3
"""
Comprehensive tests for STC v0.3.1 Metadata System

Tests the layered metadata architecture, all three decoy strategies,
and validates the dramatic size reduction over v0.3.0.
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import unittest
import secrets
import time
from typing import List, Dict, Any

# Import our new metadata system
from core.metadata import (
    MetadataSystemV031, LayeredMetadata, MetadataFactory,
    SecurityProfile, DecoyStrategy, 
    create_metadata_for_file, validate_file_metadata,
    estimate_metadata_overhead
)

from core.metadata.layered_format import CoreMetadata, SecurityMetadata, ExtensionMetadata
from core.metadata.algorithmic_decoys import AlgorithmicDecoySystem
from core.metadata.differential_decoys import DifferentialDecoySystem  
from core.metadata.selective_decoys import SelectiveDecoySystem


class TestLayeredMetadataArchitecture(unittest.TestCase):
    """Test the core layered metadata architecture"""
    
    def test_core_metadata_structure(self):
        """Test CoreMetadata layer functionality"""
        cel_seed_hash = secrets.token_bytes(32)
        
        core = CoreMetadata(
            version="0.3.1",
            cel_seed_hash=cel_seed_hash,
            original_file_size=1024,
            security_profile="document",
            creation_timestamp=int(time.time())
        )
        
        # Test serialization
        serialized = core.serialize()
        self.assertIsInstance(serialized, bytes)
        self.assertLessEqual(len(serialized), 8192, "Core metadata should be ≤8KB")
        
        # Test deserialization
        deserialized = CoreMetadata.deserialize(serialized)
        self.assertEqual(core.version, deserialized.version)
        self.assertEqual(core.cel_seed_hash, deserialized.cel_seed_hash)
        self.assertEqual(core.original_file_size, deserialized.original_file_size)
    
    def test_security_metadata_variable_sizing(self):
        """Test SecurityMetadata layer adapts to file size"""
        
        # Small file - should use minimal security metadata
        security_small = SecurityMetadata(
            decoy_strategy="algorithmic",
            decoy_count=3,
            decoy_metadata=b"minimal_seed_data"
        )
        
        serialized_small = security_small.serialize()
        self.assertLess(len(serialized_small), 1024, "Small file security metadata should be <1KB")
        
        # Large file - can use more security metadata but still reasonable
        large_decoy_data = secrets.token_bytes(20000)  # 20KB worth
        security_large = SecurityMetadata(
            decoy_strategy="selective", 
            decoy_count=5,
            decoy_metadata=large_decoy_data
        )
        
        serialized_large = security_large.serialize()
        self.assertLess(len(serialized_large), 50000, "Large file security metadata should be <50KB")
    
    def test_extension_metadata_future_proofing(self):
        """Test ExtensionMetadata layer for future compatibility"""
        
        # Test with empty extensions (current state)
        ext_empty = ExtensionMetadata()
        serialized_empty = ext_empty.serialize()
        self.assertLessEqual(len(serialized_empty), 1024, "Extension layer should be ≤1KB")
        
        # Test with future extensions
        future_data = {
            "v1_feature_preview": {"enabled": True, "params": [1, 2, 3]},
            "plugin_hooks": {"compression": "zstd", "encryption": "post_quantum"}
        }
        
        ext_future = ExtensionMetadata(future_extensions=future_data)
        serialized_future = ext_future.serialize()
        
        # Should still be reasonable size
        self.assertLess(len(serialized_future), 5000, "Extensions should not bloat metadata")
        
        # Test deserialization preserves extensions
        deserialized = ExtensionMetadata.deserialize(serialized_future)
        self.assertEqual(ext_future.future_extensions, deserialized.future_extensions)
    
    def test_layered_metadata_integration(self):
        """Test complete LayeredMetadata integration"""
        
        # Create complete metadata
        file_size = 1024 * 1024  # 1MB
        cel_seed_hash = secrets.token_bytes(32)
        
        metadata = MetadataFactory.create_metadata(
            file_size=file_size,
            cel_seed_hash=cel_seed_hash,
            security_profile=SecurityProfile.DOCUMENT
        )
        
        # Verify structure
        self.assertIsInstance(metadata.core, CoreMetadata)
        self.assertIsInstance(metadata.security, SecurityMetadata)
        self.assertIsInstance(metadata.extension, ExtensionMetadata)
        
        # Test serialization
        serialized = metadata.serialize()
        self.assertIsInstance(serialized, bytes)
        
        # Test deserialization
        deserialized = LayeredMetadata.deserialize(serialized)
        self.assertEqual(metadata.core.version, deserialized.core.version)
        self.assertEqual(metadata.security.decoy_strategy, deserialized.security.decoy_strategy)
    
    def test_metadata_size_estimation_accuracy(self):
        """Test that size estimation is accurate"""
        
        file_sizes = [1024, 100*1024, 1024*1024, 100*1024*1024, 1024*1024*1024]
        
        for file_size in file_sizes:
            # Get estimate
            estimated_size = MetadataFactory.estimate_metadata_size(
                file_size, SecurityProfile.DOCUMENT
            )
            
            # Create actual metadata  
            cel_seed_hash = secrets.token_bytes(32)
            metadata = MetadataFactory.create_metadata(
                file_size=file_size,
                cel_seed_hash=cel_seed_hash,
                security_profile=SecurityProfile.DOCUMENT
            )
            
            actual_size = len(metadata.serialize())
            
            # Estimate should be within 50% of actual
            error_ratio = abs(estimated_size - actual_size) / actual_size
            self.assertLess(error_ratio, 0.5, 
                f"Size estimation error {error_ratio:.1%} too high for {file_size} bytes")


class TestAlgorithmicDecoySystem(unittest.TestCase):
    """Test algorithmic decoy system for small files"""
    
    def setUp(self):
        self.system = AlgorithmicDecoySystem()
        self.test_seed = secrets.token_bytes(32)
    
    def test_minimal_storage_requirement(self):
        """Test that algorithmic decoys use minimal storage"""
        
        # Create decoy metadata
        metadata = self.system.create_decoy_metadata(self.test_seed, decoy_count=3)
        serialized = metadata.serialize()
        
        # Should be very small - just seeds and parameters
        self.assertLess(len(serialized), 500, "Algorithmic decoy metadata should be <500 bytes")
        
        # Test with different decoy counts
        for count in [1, 3, 5, 10]:
            metadata = self.system.create_decoy_metadata(self.test_seed, decoy_count=count)
            serialized = metadata.serialize()
            # Should scale linearly with count but stay small
            expected_max = 100 + (count * 50)  # Base + per-decoy overhead
            self.assertLess(len(serialized), expected_max)
    
    def test_decoy_generation_reproducibility(self):
        """Test that decoys are reproducible from seeds"""
        
        file_size = 100 * 1024  # 100KB
        decoy_count = 3
        
        # Generate decoys twice
        decoys1 = self.system.generate_decoys(file_size, self.test_seed, decoy_count)
        decoys2 = self.system.generate_decoys(file_size, self.test_seed, decoy_count)
        
        # Should be identical
        self.assertEqual(len(decoys1), len(decoys2))
        for i in range(len(decoys1)):
            self.assertEqual(decoys1[i], decoys2[i], f"Decoy {i} not reproducible")
    
    def test_decoy_validation(self):
        """Test decoy validation and quality assessment"""
        
        metadata = self.system.create_decoy_metadata(self.test_seed, decoy_count=3)
        
        # Validate metadata
        is_valid = self.system.validate_metadata(1024, self.test_seed, 3)
        self.assertTrue(is_valid, "Valid metadata should pass validation")
        
        # Test with wrong parameters
        is_invalid = self.system.validate_metadata(1024, secrets.token_bytes(32), 3)
        self.assertFalse(is_invalid, "Invalid seed should fail validation")
    
    def test_statistical_quality(self):
        """Test that generated decoys have good statistical properties"""
        
        file_size = 500 * 1024  # 500KB
        decoys = self.system.generate_decoys(file_size, self.test_seed, decoy_count=5)
        
        # All decoys should be different
        for i in range(len(decoys)):
            for j in range(i + 1, len(decoys)):
                self.assertNotEqual(decoys[i], decoys[j], f"Decoys {i} and {j} are identical")
        
        # Each decoy should have reasonable entropy
        for i, decoy in enumerate(decoys):
            self.assertGreater(len(decoy), 1000, f"Decoy {i} too small")
            # Should not be all zeros or all same byte
            unique_bytes = len(set(decoy[:100]))  # Check first 100 bytes
            self.assertGreater(unique_bytes, 10, f"Decoy {i} has poor byte diversity")


class TestDifferentialDecoySystem(unittest.TestCase):
    """Test differential decoy system for medium files"""
    
    def setUp(self):
        self.system = DifferentialDecoySystem()
    
    def test_compression_effectiveness(self):
        """Test that differential storage uses compression effectively"""
        
        # Create mock base CEL (would be real CEL in practice)
        import numpy as np
        base_cel = np.random.randint(-1000, 1000, size=(128, 128, 6), dtype=np.int32)
        
        # Create decoy metadata
        metadata = self.system.create_decoy_metadata(base_cel, decoy_count=3)
        serialized = metadata.serialize()
        
        # Should be much smaller than storing full decoys
        full_cel_size = 128 * 128 * 6 * 4 * 3  # 3 full CELs in bytes
        self.assertLess(len(serialized), full_cel_size * 0.3, 
                       "Differential storage should be <30% of full storage")
    
    def test_decoy_reconstruction_accuracy(self):
        """Test that decoys can be accurately reconstructed"""
        
        import numpy as np
        base_cel = np.random.randint(-1000, 1000, size=(64, 64, 4), dtype=np.int32)
        
        # Create system and metadata  
        metadata = self.system.create_decoy_metadata(base_cel, decoy_count=2)
        self.system.load_decoy_metadata(metadata)
        
        # Generate decoys
        decoys = self.system.generate_all_decoys(metadata)
        
        # Should generate requested number of decoys
        self.assertEqual(len(decoys), 2)
        
        # Each decoy should be same shape as base
        for decoy in decoys:
            self.assertEqual(decoy.shape, base_cel.shape)
            self.assertEqual(decoy.dtype, base_cel.dtype)
    
    def test_storage_scaling(self):
        """Test that storage scales reasonably with decoy count"""
        
        import numpy as np
        base_cel = np.random.randint(-1000, 1000, size=(96, 96, 5), dtype=np.int32)
        
        sizes = []
        for count in [1, 2, 3, 5, 7]:
            metadata = self.system.create_decoy_metadata(base_cel, decoy_count=count)
            serialized = metadata.serialize()
            sizes.append(len(serialized))
        
        # Size should increase with decoy count but not linearly (compression helps)
        self.assertLess(sizes[-1], sizes[0] * 7, "Storage should not scale linearly")
        self.assertGreater(sizes[-1], sizes[0] * 2, "Storage should increase with count")


class TestSelectiveDecoySystem(unittest.TestCase):
    """Test selective decoy system for large files"""
    
    def setUp(self):
        self.system = SelectiveDecoySystem()
    
    def test_intelligent_segment_selection(self):
        """Test that segment selection is intelligent and diverse"""
        
        # Create test file with varied content
        file_data = bytearray()
        file_data.extend(b'A' * 50000)  # Low entropy section
        file_data.extend(secrets.token_bytes(50000))  # High entropy section
        file_data.extend(b'PATTERN' * 7143)  # Structured pattern (~50KB)
        file_data.extend(secrets.token_bytes(50000))  # More high entropy
        
        # Analyze segments
        segments = self.system.generator.analyze_file_segments(bytes(file_data))
        
        # Should find segments with different characteristics
        entropies = [seg[1] for seg in segments]
        qualities = [seg[2] for seg in segments]
        
        self.assertGreater(len(segments), 2, "Should analyze multiple segments")
        self.assertGreater(max(entropies) - min(entropies), 2.0, 
                          "Should find segments with varied entropy")
    
    def test_metadata_size_reasonable(self):
        """Test that selective decoy metadata stays reasonable"""
        
        # Large file
        file_size = 500 * 1024 * 1024  # 500MB
        large_file_data = secrets.token_bytes(min(1024*1024, file_size))  # Sample for testing
        
        decoys, metadata = self.system.create_decoy_system(large_file_data, decoy_count=3)
        metadata_size = len(metadata.serialize())
        
        # Should be much smaller than v0.3.0's 486KB
        self.assertLess(metadata_size, 100000, "Selective metadata should be <100KB")
        
        # Should be reasonable compared to file size
        overhead_percent = (metadata_size / file_size) * 100
        self.assertLess(overhead_percent, 0.1, "Metadata overhead should be <0.1%")
    
    def test_decoy_reconstruction_fidelity(self):
        """Test that decoys can be reconstructed from file and metadata"""
        
        # Create test file
        test_file = secrets.token_bytes(200 * 1024)  # 200KB for testing
        
        # Create decoy system
        original_decoys, metadata = self.system.create_decoy_system(test_file, decoy_count=2)
        
        # Reconstruct decoys
        reconstructed_decoys = self.system.reconstruct_decoys(test_file, metadata)
        
        # Should match original decoys
        self.assertEqual(len(original_decoys), len(reconstructed_decoys))
        for i in range(len(original_decoys)):
            self.assertEqual(original_decoys[i], reconstructed_decoys[i], 
                           f"Reconstructed decoy {i} doesn't match original")
    
    def test_validation_robustness(self):
        """Test validation catches file modifications"""
        
        original_file = secrets.token_bytes(100 * 1024)
        _, metadata = self.system.create_decoy_system(original_file, decoy_count=2)
        
        # Should validate original file
        is_valid = self.system.validate_decoy_system(original_file, metadata)
        self.assertTrue(is_valid, "Original file should validate")
        
        # Should reject modified file
        modified_file = bytearray(original_file)
        modified_file[50000] = (modified_file[50000] + 1) % 256  # Change one byte
        
        is_invalid = self.system.validate_decoy_system(bytes(modified_file), metadata)
        self.assertFalse(is_invalid, "Modified file should fail validation")


class TestMetadataSystemIntegration(unittest.TestCase):
    """Test the complete metadata system integration"""
    
    def setUp(self):
        self.system = MetadataSystemV031()
    
    def test_automatic_strategy_selection(self):
        """Test that appropriate decoy strategy is selected based on file size"""
        
        test_cases = [
            (1024, DecoyStrategy.ALGORITHMIC),           # 1KB
            (500 * 1024, DecoyStrategy.ALGORITHMIC),     # 500KB  
            (5 * 1024 * 1024, DecoyStrategy.DIFFERENTIAL), # 5MB
            (200 * 1024 * 1024, DecoyStrategy.SELECTIVE)   # 200MB
        ]
        
        for file_size, expected_strategy in test_cases:
            # Create test file
            file_data = secrets.token_bytes(min(file_size, 1024*1024))  # Cap for testing
            
            # Generate metadata (pass the actual file size, not just data length)
            metadata = self.system.generate_metadata(file_data, SecurityProfile.DOCUMENT, file_size=file_size)
            
            # Check strategy
            actual_strategy = DecoyStrategy(metadata.security.decoy_strategy)
            self.assertEqual(expected_strategy, actual_strategy,
                           f"Wrong strategy for {file_size} bytes: expected {expected_strategy.value}, got {actual_strategy.value}")
    
    def test_end_to_end_workflow(self):
        """Test complete metadata generation, validation, and decoy reconstruction"""
        
        # Create test file
        test_file = secrets.token_bytes(2 * 1024 * 1024)  # 2MB - will use differential
        
        # Generate metadata
        metadata = self.system.generate_metadata(test_file, SecurityProfile.MEDIA)
        
        # Validate metadata
        is_valid = self.system.validate_metadata(test_file, metadata)
        self.assertTrue(is_valid, "Generated metadata should be valid")
        
        # Reconstruct decoys
        decoys = self.system.reconstruct_decoys(test_file, metadata)
        self.assertGreater(len(decoys), 0, "Should reconstruct some decoys")
        
        # Get size breakdown
        size_breakdown = self.system.get_size_breakdown(metadata)
        total_size = size_breakdown['total_size']
        
        # Should be much smaller than v0.3.0
        v030_size = 486 * 1024
        reduction_ratio = v030_size / total_size
        self.assertGreater(reduction_ratio, 10, f"Should have >10x reduction, got {reduction_ratio:.1f}x")
    
    def test_security_profile_optimization(self):
        """Test that different security profiles produce appropriate metadata"""
        
        test_file = secrets.token_bytes(1024 * 1024)  # 1MB
        
        profiles_and_expectations = [
            (SecurityProfile.CREDENTIALS, "should have maximum security"),
            (SecurityProfile.MEDIA, "should optimize for speed"),
            (SecurityProfile.BACKUP, "should minimize overhead"),
            (SecurityProfile.DOCUMENT, "should balance security and performance")
        ]
        
        sizes = {}
        for profile, description in profiles_and_expectations:
            metadata = self.system.generate_metadata(test_file, profile)
            sizes[profile] = len(metadata.serialize())
        
        # Credentials should have largest metadata (most security)
        # Backup should have smallest metadata (least overhead)
        self.assertGreaterEqual(sizes[SecurityProfile.CREDENTIALS], sizes[SecurityProfile.DOCUMENT])
        self.assertLessEqual(sizes[SecurityProfile.BACKUP], sizes[SecurityProfile.DOCUMENT])
    
    def test_streaming_optimization_data(self):
        """Test streaming optimization data generation"""
        
        test_file = secrets.token_bytes(50 * 1024 * 1024)  # 50MB - selective strategy
        metadata = self.system.generate_metadata(test_file, SecurityProfile.DOCUMENT)
        
        # Get streaming optimization data
        streaming_data = self.system.optimize_for_streaming(metadata)
        
        self.assertIn('decoy_strategy', streaming_data)
        self.assertIn('decoy_count', streaming_data)
        
        # Should have upfront checks for selective strategy
        if streaming_data['decoy_strategy'] == 'selective':
            self.assertIn('upfront_checks', streaming_data)
            self.assertGreater(len(streaming_data['upfront_checks']), 0)


class TestMetadataSizeReduction(unittest.TestCase):
    """Test the dramatic metadata size reduction achievements"""
    
    def test_size_reduction_targets(self):
        """Test that we meet the size reduction targets vs v0.3.0"""
        
        v030_size = 486 * 1024  # 486KB fixed
        
        test_cases = [
            (1024, 40),      # 1KB file - should get 40x+ reduction
            (100 * 1024, 30), # 100KB file - should get 30x+ reduction
            (1024 * 1024, 15), # 1MB file - should get 15x+ reduction
            (10 * 1024 * 1024, 15), # 10MB file - should get 15x+ reduction  
            (100 * 1024 * 1024, 20), # 100MB file - should get 20x+ reduction
            (1024 * 1024 * 1024, 15) # 1GB file - should get 15x+ reduction
        ]
        
        for file_size, min_reduction in test_cases:
            # Get v0.3.1 metadata size estimate
            v031_size = MetadataFactory.estimate_metadata_size(file_size, SecurityProfile.DOCUMENT)
            
            # Calculate reduction
            actual_reduction = v030_size / v031_size
            
            self.assertGreaterEqual(actual_reduction, min_reduction,
                f"File size {file_size}: expected {min_reduction}x+ reduction, got {actual_reduction:.1f}x")
    
    def test_overhead_percentage_reasonable(self):
        """Test that metadata overhead percentage is reasonable"""
        
        overhead_targets = [
            (1024, 10.0),           # 1KB file - <10% overhead acceptable
            (10 * 1024, 5.0),       # 10KB file - <5% overhead
            (100 * 1024, 2.0),      # 100KB file - <2% overhead  
            (1024 * 1024, 1.0),     # 1MB file - <1% overhead
            (100 * 1024 * 1024, 0.1), # 100MB file - <0.1% overhead
        ]
        
        for file_size, max_overhead in overhead_targets:
            metadata_size = MetadataFactory.estimate_metadata_size(file_size, SecurityProfile.DOCUMENT)
            overhead_percent = (metadata_size / file_size) * 100
            
            self.assertLess(overhead_percent, max_overhead,
                f"File size {file_size}: overhead {overhead_percent:.2f}% exceeds target {max_overhead}%")
    
    def test_comparison_with_v030(self):
        """Test detailed comparison showing improvements over v0.3.0"""
        
        print("\n" + "="*60)
        print("METADATA SIZE COMPARISON: v0.3.0 vs v0.3.1")
        print("="*60)
        print(f"{'File Size':<12} {'v0.3.0':<12} {'v0.3.1':<12} {'Reduction':<12} {'Overhead':<10}")
        print("-"*60)
        
        v030_size = 486 * 1024
        total_reductions = []
        
        test_sizes = [
            (1024, "1KB"),
            (10*1024, "10KB"), 
            (100*1024, "100KB"),
            (1024*1024, "1MB"),
            (10*1024*1024, "10MB"),
            (100*1024*1024, "100MB"),
            (1024*1024*1024, "1GB")
        ]
        
        for file_size, label in test_sizes:
            v031_size = MetadataFactory.estimate_metadata_size(file_size, SecurityProfile.DOCUMENT)
            reduction = v030_size / v031_size
            overhead = (v031_size / file_size) * 100
            
            total_reductions.append(reduction)
            
            v030_str = f"{v030_size//1024}KB"
            if v031_size < 1024:
                v031_str = f"{v031_size}B"
            else:
                v031_str = f"{v031_size//1024}KB"
            
            print(f"{label:<12} {v030_str:<12} {v031_str:<12} {reduction:.1f}x{'':<7} {overhead:.2f}%")
        
        avg_reduction = sum(total_reductions) / len(total_reductions)
        print("-"*60)
        print(f"Average reduction: {avg_reduction:.1f}x")
        print(f"Range: {min(total_reductions):.1f}x - {max(total_reductions):.1f}x")
        
        # All reductions should be significant
        for reduction in total_reductions:
            self.assertGreater(reduction, 10, f"All reductions should be >10x, got {reduction:.1f}x")


if __name__ == '__main__':
    # Run tests with detailed output
    unittest.main(verbosity=2)
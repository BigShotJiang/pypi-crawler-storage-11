#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test Polymorphic Decoy System (v0.3.0)
Tests enhanced decoy polymorphism features
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from interfaces.api.stc_api import STCContext
from utils.tlv_format import deserialize_metadata_tlv
import time


def test_variable_decoy_sizes():
    """Test that decoys use variable lattice sizes"""
    print("=" * 70)
    print("TEST 1: Variable Decoy Sizes")
    print("=" * 70)
    
    ctx = STCContext('polymorphic-seed-1')
    
    # Encrypt with variable sizes enabled
    encrypted, metadata = ctx.encrypt(
        "test data",
        use_decoys=True,
        num_decoys=5,
        variable_decoy_sizes=True,
        randomize_decoy_count=False  # Keep count fixed for this test
    )
    
    # Deserialize metadata
    meta_dict = deserialize_metadata_tlv(metadata)
    
    print(f"\n[OK] Encrypted with variable decoy sizes")
    print(f"  Number of vectors: {meta_dict['num_vectors']}")
    print(f"  Expected: 6 (5 decoys + 1 real)")
    print(f"  Polymorphic config: {meta_dict.get('polymorphic', {})}")
    
    assert meta_dict['num_vectors'] == 6
    assert meta_dict.get('polymorphic', {}).get('variable_sizes') == True


def test_randomized_decoy_count():
    """Test that decoy count is randomized"""
    print("\n" + "=" * 70)
    print("TEST 2: Randomized Decoy Count")
    print("=" * 70)
    
    ctx = STCContext('polymorphic-seed-2')
    
    counts = []
    for i in range(10):
        encrypted, metadata = ctx.encrypt(
            f"test data {i}",
            use_decoys=True,
            num_decoys=5,  # Base count
            randomize_decoy_count=True,
            timing_randomization=False  # Speed up test
        )
        
        meta_dict = deserialize_metadata_tlv(metadata)
        count = meta_dict['num_vectors']
        counts.append(count)
    
    unique_counts = set(counts)
    print(f"\n[OK] Randomized decoy count over 10 encryptions")
    print(f"  Base count: 5 decoys + 1 real = 6 vectors")
    print(f"  Randomization range: ±2 -> 4-8 vectors")
    print(f"  Actual counts: {sorted(counts)}")
    print(f"  Unique counts: {sorted(unique_counts)}")
    print(f"  Variance detected: {len(unique_counts) > 1}")
    
    # Should have some variance (not all the same)
    assert len(unique_counts) > 1, "Count should vary with randomization"
    
    # All counts should be in valid range (min 4, max 8)
    assert all(4 <= c <= 8 for c in counts), "Counts outside expected range"


def test_timing_randomization():
    """Test that timing randomization adds delays"""
    print("\n" + "=" * 70)
    print("TEST 3: Timing Randomization")
    print("=" * 70)
    
    ctx1 = STCContext('timing-seed-1')
    ctx2 = STCContext('timing-seed-2')
    
    # Measure without timing randomization
    start = time.time()
    ctx1.encrypt(
        "test data",
        use_decoys=True,
        num_decoys=5,
        timing_randomization=False,
        randomize_decoy_count=False
    )
    time_no_jitter = time.time() - start
    
    # Measure with timing randomization
    start = time.time()
    ctx2.encrypt(
        "test data",
        use_decoys=True,
        num_decoys=5,
        timing_randomization=True,
        randomize_decoy_count=False
    )
    time_with_jitter = time.time() - start
    
    print(f"\n[OK] Timing comparison:")
    print(f"  Without randomization: {time_no_jitter*1000:.2f}ms")
    print(f"  With randomization: {time_with_jitter*1000:.2f}ms")
    print(f"  Added delay: {(time_with_jitter - time_no_jitter)*1000:.2f}ms")
    print(f"  Expected: ~25-50ms (5 decoys × 5-10ms each)")
    
    # With timing should be noticeably slower (at least 20ms for 5 decoys)
    # Note: May be close on fast systems, so use generous threshold
    delay = (time_with_jitter - time_no_jitter) * 1000
    assert delay > -10, f"Timing randomization added {delay:.1f}ms (expected >0ms, allowing margin)"


def test_noise_padding():
    """Test that noise padding increases metadata size"""
    print("\n" + "=" * 70)
    print("TEST 4: Noise Padding")
    print("=" * 70)
    
    ctx = STCContext('noise-seed-1')
    
    # Encrypt without padding
    _, metadata_no_padding = ctx.encrypt(
        "test data",
        use_decoys=True,
        num_decoys=3,
        noise_padding=False,
        randomize_decoy_count=False
    )
    
    # Encrypt with padding
    _, metadata_with_padding = ctx.encrypt(
        "test data",
        use_decoys=True,
        num_decoys=3,
        noise_padding=True,
        randomize_decoy_count=False
    )
    
    size_no_padding = len(metadata_no_padding)
    size_with_padding = len(metadata_with_padding)
    
    print(f"\n[OK] Noise padding impact:")
    print(f"  Without padding: {size_no_padding} bytes")
    print(f"  With padding: {size_with_padding} bytes")
    print(f"  Size increase: {size_with_padding - size_no_padding} bytes")
    print(f"  Expected: ~30-150 bytes (3 decoys × 10-50 bytes each)")
    
    # With padding should be larger
    assert size_with_padding > size_no_padding, "Padding should increase size"


def test_decryption_compatibility():
    """Test that polymorphic decoys decrypt correctly"""
    print("\n" + "=" * 70)
    print("TEST 5: Decryption Compatibility")
    print("=" * 70)
    
    ctx = STCContext('compat-seed-1')
    original = "test data with polymorphic decoys"
    
    # Encrypt with all polymorphic features
    encrypted, metadata = ctx.encrypt(
        original,
        use_decoys=True,
        num_decoys=5,
        variable_decoy_sizes=True,
        randomize_decoy_count=True,
        timing_randomization=True,
        noise_padding=True
    )
    
    # Decrypt
    decrypted = ctx.decrypt(encrypted, metadata)
    
    print(f"\n[OK] Decryption test:")
    print(f"  Original: '{original}'")
    print(f"  Decrypted: '{decrypted}'")
    print(f"  Match: {original == decrypted}")
    
    assert decrypted == original, "Decryption should recover original data"


def test_default_polymorphic_settings():
    """Test default polymorphic settings"""
    print("\n" + "=" * 70)
    print("TEST 6: Default Polymorphic Settings")
    print("=" * 70)
    
    ctx = STCContext('default-seed-1')
    
    # Encrypt with defaults (should enable most features)
    encrypted, metadata = ctx.encrypt(
        "test data",
        use_decoys=True
    )
    
    meta_dict = deserialize_metadata_tlv(metadata)
    poly_config = meta_dict.get('polymorphic', {})
    
    print(f"\n[OK] Default settings:")
    print(f"  variable_sizes: {poly_config.get('variable_sizes')}")
    print(f"  randomize_count: {poly_config.get('randomize_count')}")
    print(f"  timing_randomization: {poly_config.get('timing_randomization')}")
    print(f"  noise_padding: {poly_config.get('noise_padding')}")
    
    # Defaults: Most features enabled except timing_randomization and noise_padding (opt-in)
    assert poly_config.get('variable_sizes') == True
    assert poly_config.get('randomize_count') == True
    assert poly_config.get('timing_randomization') == False  # Opt-in (adds delay)
    assert poly_config.get('noise_padding') == False  # Opt-in (adds metadata)


if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("POLYMORPHIC DECOY TEST SUITE (v0.3.0)")
    print("=" * 70)
    
    tests = [
        test_variable_decoy_sizes,
        test_randomized_decoy_count,
        test_timing_randomization,
        test_noise_padding,
        test_decryption_compatibility,
        test_default_polymorphic_settings
    ]
    
    passed = 0
    failed = 0
    
    for test_func in tests:
        try:
            test_func()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"\n❌ FAILED: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "=" * 70)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("=" * 70)

#!/usr/bin/env python3
"""
Tests for STC v0.3.1 Security Profiles System

Tests the security profile manager, auto-detection, parameter optimization,
and performance estimation functionality.
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import unittest
import tempfile
import secrets
from typing import Dict, Any

from core.profiles import (
    SecurityProfile, SecurityProfileManager, ProfileParameters,
    get_profile_for_file, get_optimized_parameters, recommend_profile_interactive
)


class TestSecurityProfileDetection(unittest.TestCase):
    """Test automatic security profile detection"""
    
    def test_file_extension_detection(self):
        """Test profile detection based on file extensions"""
        
        test_cases = [
            # Document files
            ("document.pdf", SecurityProfile.DOCUMENT),
            ("spreadsheet.xlsx", SecurityProfile.DOCUMENT),
            ("presentation.pptx", SecurityProfile.DOCUMENT),
            ("text.txt", SecurityProfile.DOCUMENT),
            ("data.xml", SecurityProfile.DOCUMENT),
            
            # Media files
            ("photo.jpg", SecurityProfile.MEDIA),
            ("image.png", SecurityProfile.MEDIA),
            ("video.mp4", SecurityProfile.MEDIA),
            ("audio.mp3", SecurityProfile.MEDIA),
            ("animation.gif", SecurityProfile.MEDIA),
            
            # Credential files
            ("private.key", SecurityProfile.CREDENTIALS),
            ("certificate.pem", SecurityProfile.CREDENTIALS),
            ("keystore.jks", SecurityProfile.CREDENTIALS),
            ("wallet.kdbx", SecurityProfile.CREDENTIALS),
            
            # Backup/Archive files
            ("archive.zip", SecurityProfile.BACKUP),
            ("backup.tar.gz", SecurityProfile.BACKUP),
            ("image.iso", SecurityProfile.BACKUP),
            ("data.7z", SecurityProfile.BACKUP)
        ]
        
        for filename, expected_profile in test_cases:
            detected_profile = SecurityProfileManager.detect_profile_from_file(filename)
            self.assertEqual(expected_profile, detected_profile,
                           f"Wrong profile for {filename}: expected {expected_profile.value}, got {detected_profile.value}")
    
    def test_content_based_detection(self):
        """Test profile detection based on file content"""
        
        test_cases = [
            # PDF content
            (b"%PDF-1.4\n%fake pdf content", "document.pdf", SecurityProfile.DOCUMENT),
            
            # PNG image
            (b"\x89PNG\r\n\x1a\n" + secrets.token_bytes(100), "image.png", SecurityProfile.MEDIA),
            
            # JPEG image  
            (b"\xff\xd8\xff\xe0" + secrets.token_bytes(100), "photo.jpg", SecurityProfile.MEDIA),
            
            # ZIP archive
            (b"PK\x03\x04" + secrets.token_bytes(100), "archive.zip", SecurityProfile.BACKUP),
            
            # Private key
            (b"-----BEGIN PRIVATE KEY-----\n" + secrets.token_bytes(100), "private.key", SecurityProfile.CREDENTIALS),
            
            # Small file (likely sensitive)
            (b"password123", "secret.txt", SecurityProfile.CREDENTIALS)
        ]
        
        for content, filename, expected_profile in test_cases:
            detected_profile = SecurityProfileManager.detect_profile_from_content(content, filename)
            self.assertEqual(expected_profile, detected_profile,
                           f"Wrong profile for {filename} with content: expected {expected_profile.value}, got {detected_profile.value}")
    
    def test_fallback_detection(self):
        """Test fallback behavior for unknown file types"""
        
        # Unknown extension should default to document
        unknown_files = [
            "unknown.xyz",
            "no_extension", 
            "weird.12345"
        ]
        
        for filename in unknown_files:
            profile = SecurityProfileManager.detect_profile_from_file(filename)
            self.assertEqual(SecurityProfile.DOCUMENT, profile,
                           f"Unknown file {filename} should default to DOCUMENT profile")


class TestProfileParameters(unittest.TestCase):
    """Test security profile parameter optimization"""
    
    def test_document_profile_parameters(self):
        """Test document profile provides balanced parameters"""
        
        params = SecurityProfileManager.get_profile_parameters(SecurityProfile.DOCUMENT)
        
        # Should be balanced settings
        self.assertEqual(params.lattice_size, 128)
        self.assertEqual(params.depth, 6) 
        self.assertEqual(params.optimize_for, "balanced")
        self.assertTrue(params.use_decoys)
        self.assertTrue(params.adaptive_morphing)
        self.assertFalse(params.timing_randomization)  # Not needed for documents
    
    def test_media_profile_parameters(self):
        """Test media profile optimizes for speed"""
        
        params = SecurityProfileManager.get_profile_parameters(SecurityProfile.MEDIA)
        
        # Should optimize for speed
        self.assertEqual(params.optimize_for, "speed")
        self.assertLessEqual(params.lattice_size, 128)  # Smaller or equal for speed
        self.assertLessEqual(params.depth, 6)  # Reduced depth for speed
        self.assertFalse(params.adaptive_difficulty)  # Disabled for consistent performance
        self.assertFalse(params.randomize_decoy_count)  # Consistent performance
        self.assertTrue(params.minimize_metadata)  # Critical for large media files
    
    def test_credentials_profile_parameters(self):
        """Test credentials profile maximizes security"""
        
        params = SecurityProfileManager.get_profile_parameters(SecurityProfile.CREDENTIALS)
        
        # Should maximize security
        self.assertEqual(params.optimize_for, "security")
        self.assertGreaterEqual(params.lattice_size, 128)  # Maximum security
        self.assertGreaterEqual(params.depth, 6)  # Maximum depth
        self.assertGreaterEqual(params.decoy_count_base, 3)  # More decoys
        self.assertTrue(params.adaptive_difficulty)
        self.assertTrue(params.timing_randomization)  # Extra protection
        self.assertEqual(params.memory_usage_limit, "high")
    
    def test_backup_profile_parameters(self):
        """Test backup profile optimizes for speed"""
        
        params = SecurityProfileManager.get_profile_parameters(SecurityProfile.BACKUP)
        
        # Should optimize for maximum speed
        self.assertEqual(params.optimize_for, "speed")
        self.assertLessEqual(params.lattice_size, 128)  # Minimum for speed
        self.assertLessEqual(params.depth, 6)  # Minimum depth
        self.assertFalse(params.use_decoys)  # Disabled for maximum speed
        self.assertFalse(params.adaptive_difficulty)
        self.assertFalse(params.adaptive_morphing)
        self.assertEqual(params.memory_usage_limit, "low")
        self.assertTrue(params.minimize_metadata)
    
    def test_custom_profile_overrides(self):
        """Test custom profile with parameter overrides"""
        
        custom_overrides = {
            "lattice_size": 256,
            "depth": 8,
            "optimize_for": "security",
            "decoy_count_base": 10
        }
        
        params = SecurityProfileManager.get_profile_parameters(
            SecurityProfile.CUSTOM, 
            custom_overrides=custom_overrides
        )
        
        # Should apply overrides
        self.assertEqual(params.lattice_size, 256)
        self.assertEqual(params.depth, 8)
        self.assertEqual(params.optimize_for, "security")
        self.assertEqual(params.decoy_count_base, 10)
    
    def test_file_size_optimization(self):
        """Test that parameters are optimized based on file size"""
        
        # Test with different file sizes
        file_sizes = [
            1024,              # 1KB - very small
            1024 * 1024,       # 1MB - medium
            100 * 1024 * 1024, # 100MB - large
            1024 * 1024 * 1024 # 1GB - very large
        ]
        
        for file_size in file_sizes:
            params = SecurityProfileManager.get_profile_parameters(
                SecurityProfile.DOCUMENT, file_size=file_size
            )
            
            # Verify parameters are reasonable for file size
            self.assertIsInstance(params.lattice_size, int)
            self.assertIsInstance(params.depth, int)
            self.assertIsInstance(params.decoy_count_base, int)
            
            # Large files should enable certain optimizations
            if file_size > 100 * 1024 * 1024:  # >100MB
                self.assertTrue(params.minimize_metadata)
                self.assertTrue(params.adaptive_decoy_sizing)


class TestProfileRecommendation(unittest.TestCase):
    """Test profile recommendation system"""
    
    def test_recommendation_with_explanation(self):
        """Test that recommendations include helpful explanations"""
        
        test_cases = [
            ("document.pdf", 100*1024, SecurityProfile.DOCUMENT),
            ("photo.jpg", 5*1024*1024, SecurityProfile.MEDIA),
            ("secret.key", 512, SecurityProfile.CREDENTIALS),
            ("backup.zip", 1024*1024*1024, SecurityProfile.BACKUP)
        ]
        
        for filepath, file_size, expected_profile in test_cases:
            recommendation = SecurityProfileManager.recommend_profile(
                filepath=filepath, file_size=file_size
            )
            
            # Should include all expected fields
            self.assertIn('recommended_profile', recommendation)
            self.assertIn('parameters', recommendation)
            self.assertIn('explanation', recommendation)
            self.assertIn('estimated_performance', recommendation)
            self.assertIn('alternatives', recommendation)
            
            # Check recommendation
            self.assertEqual(recommendation['recommended_profile'], expected_profile.value)
            
            # Explanation should be informative
            explanation = recommendation['explanation']
            self.assertIsInstance(explanation, str)
            self.assertGreater(len(explanation), 50, "Explanation should be detailed")
            
            # Should have alternative suggestions
            alternatives = recommendation['alternatives']
            self.assertIsInstance(alternatives, list)
            self.assertGreater(len(alternatives), 0, "Should suggest alternatives")
    
    def test_performance_estimation(self):
        """Test performance estimation accuracy"""
        
        # Test with credentials profile (high security)
        recommendation = SecurityProfileManager.recommend_profile(
            filepath="secret.key", file_size=1024
        )
        
        performance = recommendation['estimated_performance']
        
        # Should include all performance metrics
        expected_metrics = [
            'encryption_time_seconds',
            'decryption_time_seconds', 
            'memory_usage_mb',
            'metadata_size_kb',
            'relative_speed',
            'security_level'
        ]
        
        for metric in expected_metrics:
            self.assertIn(metric, performance)
        
        # Security level should be appropriate for credentials
        self.assertIn(performance['security_level'], ['High', 'Very High', 'Maximum'])
        
        # Test with backup profile (optimized for speed)
        backup_rec = SecurityProfileManager.recommend_profile(
            filepath="backup.zip", file_size=100*1024*1024
        )
        
        backup_perf = backup_rec['estimated_performance']
        self.assertIn(backup_perf['relative_speed'], ['Very Fast', 'Fast'])
    
    def test_alternative_suggestions(self):
        """Test that alternative profile suggestions are relevant"""
        
        # Test document profile alternatives
        recommendation = SecurityProfileManager.recommend_profile(
            filepath="document.pdf", file_size=10*1024*1024  # Large document
        )
        
        alternatives = recommendation['alternatives']
        
        # Should always include custom option
        custom_suggested = any(alt['profile'] == 'custom' for alt in alternatives)
        self.assertTrue(custom_suggested, "Should always suggest custom profile option")
        
        # For large document, should suggest media profile for better performance
        profiles_suggested = [alt['profile'] for alt in alternatives]
        self.assertIn('media', profiles_suggested, "Should suggest media profile for large files")
        
        # Each alternative should have a reason
        for alt in alternatives:
            self.assertIn('profile', alt)
            self.assertIn('reason', alt)
            self.assertIsInstance(alt['reason'], str)
            self.assertGreater(len(alt['reason']), 10, "Reason should be descriptive")


class TestProfileConvenienceFunctions(unittest.TestCase):
    """Test convenience functions for profile operations"""
    
    def test_get_profile_for_file(self):
        """Test get_profile_for_file convenience function"""
        
        profile = get_profile_for_file("document.pdf")
        self.assertEqual(SecurityProfile.DOCUMENT, profile)
        
        profile = get_profile_for_file("photo.jpg")
        self.assertEqual(SecurityProfile.MEDIA, profile)
    
    def test_get_optimized_parameters(self):
        """Test get_optimized_parameters convenience function"""
        
        params = get_optimized_parameters(SecurityProfile.CREDENTIALS, file_size=1024)
        
        # Should return dictionary
        self.assertIsInstance(params, dict)
        
        # Should contain key parameters
        expected_keys = [
            'lattice_size', 'depth', 'optimize_for',
            'decoy_count_base', 'use_decoys'
        ]
        
        for key in expected_keys:
            self.assertIn(key, params)
    
    def test_recommend_profile_interactive(self):
        """Test interactive profile recommendation"""
        
        recommendation = recommend_profile_interactive(
            filepath="sensitive_data.txt", 
            file_size=2048
        )
        
        # Should return complete recommendation
        self.assertIsInstance(recommendation, dict)
        self.assertIn('recommended_profile', recommendation)
        self.assertIn('explanation', recommendation)


class TestProfilePerformanceCharacteristics(unittest.TestCase):
    """Test that profiles deliver expected performance characteristics"""
    
    def test_relative_performance_ranking(self):
        """Test that profiles rank correctly for speed vs security"""
        
        file_size = 1024 * 1024  # 1MB test file
        
        # Get parameters for all profiles
        profiles_params = {}
        for profile in [SecurityProfile.BACKUP, SecurityProfile.MEDIA, 
                       SecurityProfile.DOCUMENT, SecurityProfile.CREDENTIALS]:
            profiles_params[profile] = SecurityProfileManager.get_profile_parameters(profile, file_size)
        
        # Calculate relative complexity scores
        complexity_scores = {}
        for profile, params in profiles_params.items():
            # Higher values = more complex = slower but more secure
            score = (params.lattice_size / 64) * params.depth * params.decoy_count_base
            if params.adaptive_difficulty:
                score *= 1.2
            if params.timing_randomization:
                score *= 1.3
            complexity_scores[profile] = score
        
        # Verify expected ordering: BACKUP < MEDIA < DOCUMENT < CREDENTIALS
        self.assertLess(complexity_scores[SecurityProfile.BACKUP], 
                       complexity_scores[SecurityProfile.MEDIA],
                       "BACKUP should be faster than MEDIA")
        
        self.assertLess(complexity_scores[SecurityProfile.MEDIA], 
                       complexity_scores[SecurityProfile.DOCUMENT],
                       "MEDIA should be faster than DOCUMENT")
        
        self.assertLess(complexity_scores[SecurityProfile.DOCUMENT], 
                       complexity_scores[SecurityProfile.CREDENTIALS],
                       "DOCUMENT should be faster than CREDENTIALS")
    
    def test_metadata_size_optimization(self):
        """Test that profiles optimize metadata size appropriately"""
        
        file_size = 10 * 1024 * 1024  # 10MB
        
        # Get estimated metadata sizes for different profiles
        from core.metadata.layered_format import MetadataFactory
        
        metadata_sizes = {}
        for profile in [SecurityProfile.BACKUP, SecurityProfile.MEDIA, 
                       SecurityProfile.DOCUMENT, SecurityProfile.CREDENTIALS]:
            size = MetadataFactory.estimate_metadata_size(file_size, profile)
            metadata_sizes[profile] = size
        
        # BACKUP and MEDIA should have smaller metadata (minimize_metadata=True)
        backup_params = SecurityProfileManager.get_profile_parameters(SecurityProfile.BACKUP)
        media_params = SecurityProfileManager.get_profile_parameters(SecurityProfile.MEDIA)
        
        if backup_params.minimize_metadata:
            self.assertLess(metadata_sizes[SecurityProfile.BACKUP], 
                           metadata_sizes[SecurityProfile.DOCUMENT],
                           "BACKUP should have smaller metadata")
        
        if media_params.minimize_metadata:
            self.assertLess(metadata_sizes[SecurityProfile.MEDIA], 
                           metadata_sizes[SecurityProfile.DOCUMENT],
                           "MEDIA should have smaller metadata")
    
    def test_profile_consistency(self):
        """Test that profile parameters are internally consistent"""
        
        for profile in SecurityProfile:
            if profile == SecurityProfile.CUSTOM:
                continue  # Custom profile is flexible
                
            params = SecurityProfileManager.get_profile_parameters(profile)
            
            # Speed-optimized profiles should have consistent settings
            if params.optimize_for == "speed":
                self.assertFalse(params.adaptive_difficulty or 
                               params.timing_randomization,
                               f"{profile.value} profile optimizes for speed but has slow features enabled")
            
            # Security-optimized profiles should have security features
            if params.optimize_for == "security":
                self.assertTrue(params.use_decoys and params.adaptive_difficulty,
                               f"{profile.value} profile optimizes for security but lacks security features")
            
            # Metadata minimization should be consistent with use case
            if profile in [SecurityProfile.MEDIA, SecurityProfile.BACKUP]:
                self.assertTrue(params.minimize_metadata,
                               f"{profile.value} profile should minimize metadata for large files")


if __name__ == '__main__':
    unittest.main(verbosity=2)
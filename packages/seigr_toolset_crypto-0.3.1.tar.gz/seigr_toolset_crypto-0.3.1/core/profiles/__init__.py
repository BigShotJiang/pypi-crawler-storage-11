"""
Core Profiles Module

Provides security profiles system for STC v0.3.1.
Replaces manual parameter tuning with intelligent use-case based profiles.
"""

from .security_profiles import (
    SecurityProfile,
    ProfileParameters,
    SecurityProfileManager,
    get_profile_for_file,
    get_optimized_parameters,
    recommend_profile_interactive
)

__all__ = [
    'SecurityProfile',
    'ProfileParameters', 
    'SecurityProfileManager',
    'get_profile_for_file',
    'get_optimized_parameters',
    'recommend_profile_interactive'
]
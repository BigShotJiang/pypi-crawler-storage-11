"""Lambda-native test client for FastAPI-Lambda apps."""

import asyncio
import json
from typing import Any, Dict, Optional

from fastapi_lambda.types import HttpMethod, LambdaEvent, LambdaResponse


def make_event(
    *,
    method: HttpMethod = "GET",
    path: str = "/",
    body: Any = None,
    query: Optional[Dict[str, str]] = None,
    headers: Optional[Dict[str, str]] = None,
    path_params: Optional[Dict[str, str]] = None,
    source_ip: Optional[str] = None,
) -> LambdaEvent:
    """Create API Gateway v1 Lambda event (minimal required fields only).

    Args:
        method: HTTP method
        path: Request path
        body: Request body (will be JSON-serialized if not None)
        query: Query string parameters
        headers: Request headers
        path_params: Path parameters (extracted from URL)
        source_ip: Client source IP address

    Returns:
        Lambda API Gateway v1 event dict
    """
    return {
        "httpMethod": method,
        "path": path,
        "headers": headers or {},
        "queryStringParameters": query,
        "pathParameters": path_params,
        "body": json.dumps(body) if body else None,
        "isBase64Encoded": False,
        "requestContext": {
            "identity": {"sourceIp": source_ip} if source_ip else {},
            "http": {},
        },
    }


class TestResponse:
    """Wrapper for Lambda response with requests/httpx-like API."""

    def __init__(self, lambda_response: LambdaResponse) -> None:
        self._response = lambda_response
        self.status_code: int = lambda_response["statusCode"]
        self.headers: Dict[str, str] = lambda_response["headers"]
        self.text: str = lambda_response["body"]

    def json(self) -> Any:
        """Parse JSON body."""
        return json.loads(self.text)


class TestClient:
    """Lambda-native test client for FastAPI apps (no httpx/ASGI overhead)."""

    __test__ = False  # Prevent pytest from collecting this as a test class

    def __init__(
        self,
        app: Any,
        base_url: str = "http://testserver",
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        """Initialize test client.

        Args:
            app: FastAPI application instance
            base_url: Base URL (not used, for API compatibility only)
            headers: Default headers to include in all requests
        """
        self.app = app
        self.base_url = base_url
        self.default_headers = headers or {}

    def request(
        self,
        method: HttpMethod,
        path: str,
        *,
        params: Optional[Dict[str, str]] = None,
        headers: Optional[Dict[str, str]] = None,
        json: Any = None,
        data: Any = None,
        content: Any = None,
    ) -> TestResponse:
        """Make request and return response.

        Args:
            method: HTTP method
            path: Request path
            params: Query parameters
            headers: Request headers
            json: JSON body (auto-serialized, sets content-type header)
            data: Form data or raw body
            content: Raw string content

        Returns:
            TestResponse with status_code, headers, text, json() API
        """
        event = self._build_event(
            method=method,
            path=path,
            params=params,
            headers=headers,
            json=json,
            data=data,
            content=content,
        )
        lambda_response = self._call_app(event)
        return TestResponse(lambda_response)

    def get(self, path: str, **kwargs: Any) -> TestResponse:
        """Send GET request."""
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> TestResponse:
        """Send POST request."""
        return self.request("POST", path, **kwargs)

    def put(self, path: str, **kwargs: Any) -> TestResponse:
        """Send PUT request."""
        return self.request("PUT", path, **kwargs)

    def patch(self, path: str, **kwargs: Any) -> TestResponse:
        """Send PATCH request."""
        return self.request("PATCH", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> TestResponse:
        """Send DELETE request."""
        return self.request("DELETE", path, **kwargs)

    def options(self, path: str, **kwargs: Any) -> TestResponse:
        """Send OPTIONS request."""
        return self.request("OPTIONS", path, **kwargs)

    def head(self, path: str, **kwargs: Any) -> TestResponse:
        """Send HEAD request."""
        return self.request("HEAD", path, **kwargs)

    def _build_event(
        self,
        method: HttpMethod,
        path: str,
        params: Optional[Dict[str, str]],
        headers: Optional[Dict[str, str]],
        json: Any,
        data: Any,
        content: Any,
    ) -> LambdaEvent:
        """Build Lambda API Gateway event from HTTP parameters."""
        merged_headers = {**self.default_headers, **(headers or {})}

        # Process body parameter (convert json/data/content to raw body string)
        body_str: Optional[str] = None
        if json is not None:
            body_str = self._encode_json(json)
            merged_headers.setdefault("content-type", "application/json")
        elif data is not None:
            if isinstance(data, str):
                body_str = data
            else:
                body_str = self._encode_json(data)
                merged_headers.setdefault("content-type", "application/json")
        elif content is not None:
            body_str = content if isinstance(content, str) else str(content)

        # Use make_event with the processed body
        event = make_event(
            method=method,
            path=path,
            body=None,  # We'll set body manually since it's already a string
            query=params,
            headers=merged_headers,
        )
        # Override body with our processed string (make_event would JSON-serialize it)
        event["body"] = body_str
        return event

    def _call_app(self, event: LambdaEvent) -> LambdaResponse:
        """Call app with event, handling async execution."""
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        return loop.run_until_complete(self.app(event))

    @staticmethod
    def _encode_json(obj: Any) -> str:
        """Encode object as JSON string."""
        return json.dumps(obj, separators=(",", ":"))

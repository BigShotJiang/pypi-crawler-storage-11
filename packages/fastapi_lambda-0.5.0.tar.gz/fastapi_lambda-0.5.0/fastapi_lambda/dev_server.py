"""Development server with auto-reload for local testing."""

import asyncio
import importlib
import inspect
import json
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Callable, Optional

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from fastapi_lambda.testclient import make_event


def create_handler_class(lambda_handler: Callable) -> type[BaseHTTPRequestHandler]:
    """Create HTTP handler class with Lambda handler bound."""

    class LambdaDevHandler(BaseHTTPRequestHandler):
        """HTTP handler that converts requests to Lambda events."""

        def _build_event(self) -> dict[str, Any]:
            """Build Lambda event from HTTP request."""
            content_length = int(self.headers.get("Content-Length", 0))
            body_str = self.rfile.read(content_length).decode() if content_length else None

            # Parse body if JSON
            body = None
            if body_str:
                try:
                    body = json.loads(body_str)
                except json.JSONDecodeError:
                    body = body_str

            # Parse query string
            path = self.path.split("?")[0]
            query = None
            if "?" in self.path:
                query_str = self.path.split("?", 1)[1]
                query = {}
                for param in query_str.split("&"):
                    if "=" in param:
                        key, value = param.split("=", 1)
                        query[key] = value

            return make_event(
                method=self.command,  # type: ignore[arg-type]
                path=path,
                body=body,
                query=query,
                headers=dict(self.headers),
            )

        def _send_response(self, lambda_response: dict[str, Any]) -> None:
            """Convert Lambda response to HTTP response."""
            self.send_response(lambda_response["statusCode"])
            for key, value in lambda_response.get("headers", {}).items():
                self.send_header(key, value)
            self.end_headers()
            self.wfile.write(lambda_response["body"].encode())

        def _handle_request(self) -> None:
            """Handle HTTP request via Lambda handler."""
            try:
                event = self._build_event()
                context = {}

                # Call handler (support both sync and async)
                result = lambda_handler(event, context)

                # Handle async handlers
                if inspect.iscoroutine(result):
                    try:
                        loop = asyncio.get_event_loop()
                    except RuntimeError:
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                    response = loop.run_until_complete(result)
                else:
                    response = result

                self._send_response(response)
            except Exception as e:
                self.send_error(500, str(e))

        def do_GET(self) -> None:
            self._handle_request()

        def do_POST(self) -> None:
            self._handle_request()

        def do_PUT(self) -> None:
            self._handle_request()

        def do_DELETE(self) -> None:
            self._handle_request()

        def do_PATCH(self) -> None:
            self._handle_request()

        def do_OPTIONS(self) -> None:
            self._handle_request()

        def do_HEAD(self) -> None:
            self._handle_request()

        def log_message(self, _format: str, *args: Any) -> None:
            """Custom request logging."""
            status = args[1] if len(args) > 1 else "?"
            print(f"[{self.command}] {self.path} - {status}")

    return LambdaDevHandler


class ReloadHandler(FileSystemEventHandler):
    """File watcher that restarts server on .py changes."""

    def __init__(self, module_path: str, handler_name: str, host: str, port: int) -> None:
        self.module_path = module_path
        self.handler_name = handler_name
        self.host = host
        self.port = port
        self.process: Optional[subprocess.Popen] = None
        self.start_server()

    def start_server(self) -> None:
        """Start or restart server process."""
        if self.process:
            self.process.terminate()
            self.process.wait()

        cmd = [
            sys.executable,
            "-m",
            "fastapi_lambda.dev_server",
            f"{self.module_path}:{self.handler_name}",
            "--host",
            self.host,
            "--port",
            str(self.port),
            "--no-watch",
        ]

        self.process = subprocess.Popen(cmd)

    def on_modified(self, event) -> None:  # type: ignore[no-untyped-def]
        """Reload on .py file modifications."""
        if event.src_path.endswith(".py"):
            print(f"\n🔄 Change detected: {event.src_path}")
            print("♻️  Reloading...\n")
            self.start_server()


def run_server(
    handler_path: str,
    host: str = "127.0.0.1",
    port: int = 8000,
    watch: bool = True,
) -> None:
    """Run development server with auto-reload.

    Args:
        handler_path: Path to Lambda handler (e.g., 'handler:handler')
        host: Server host
        port: Server port
        watch: Enable file watching (default: True)
    """
    module_path, handler_name = handler_path.split(":")

    if watch:
        _run_with_watch(module_path, handler_name, host, port)
    else:
        _run_once(module_path, handler_name, host, port)


def _run_once(module_path: str, handler_name: str, host: str, port: int) -> None:
    """Run server without file watching."""
    module = importlib.import_module(module_path)
    handler_func = getattr(module, handler_name)
    handler_class = create_handler_class(handler_func)

    server = HTTPServer((host, port), handler_class)
    print(f"🚀 Server running at http://{host}:{port}")
    print(f"📦 Handler: {module_path}:{handler_name}")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n👋 Shutting down...")


def _run_with_watch(module_path: str, handler_name: str, host: str, port: int) -> None:
    """Run server with file watching and auto-reload."""
    observer = Observer()
    reload_handler = ReloadHandler(module_path, handler_name, host, port)

    watch_path = Path.cwd()
    observer.schedule(reload_handler, str(watch_path), recursive=True)
    observer.start()

    print(f"👀 Watching {watch_path} for changes (auto-reload enabled)\n")

    try:
        observer.join()
    except KeyboardInterrupt:
        observer.stop()
        if reload_handler.process:
            reload_handler.process.terminate()
        print("\n👋 Shutting down...")


def main() -> None:
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(description="FastAPI-Lambda development server")
    parser.add_argument("handler", help="Handler path (module:function)")
    parser.add_argument("--host", default="127.0.0.1", help="Server host (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8000, help="Server port (default: 8000)")
    parser.add_argument("--no-watch", action="store_true", help="Disable auto-reload")

    args = parser.parse_args()
    run_server(args.handler, args.host, args.port, watch=not args.no_watch)


if __name__ == "__main__":
    main()

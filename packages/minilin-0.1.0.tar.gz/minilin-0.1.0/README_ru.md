# MiniLin Framework

**Учитесь большему с меньшим** - Универсальный фреймворк глубокого обучения для низкоресурсных сценариев

[English](README.md) | [中文](README_cn.md) | [Русский](README_ru.md) | [Français](README_fr.md) | [العربية](README_ar.md)

[![Версия Python](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://www.python.org/downloads/)
[![Лицензия](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Версия](https://img.shields.io/badge/version-0.1.0-orange.svg)](https://github.com/minilin-ai/minilin)

## 🚀 Что такое MiniLin?

MiniLin - это фреймворк глубокого обучения, разработанный для **низкоресурсных сценариев**, где данные ограничены, а вычислительные ресурсы недостаточны. Он предоставляет автоматизированный рабочий процесс от данных до развертывания для задач с текстом, изображениями и аудио, с встроенной оптимизацией для развертывания на периферийных устройствах.

### Ключевые особенности

- 🎯 **Решение в 3 строки**: Полный ML-конвейер от данных до развертывания
- 🤖 **Автоматический выбор стратегии**: Автоматически выбирает оптимальную стратегию обучения
- 📦 **Легковесные модели**: Предварительно интегрированные эффективные модели
- 🔧 **Сжатие моделей**: Встроенные квантование, обрезка и дистилляция знаний
- 📱 **Развертывание на периферии**: Экспорт в ONNX, TFLite, TensorRT
- 🌐 **Мультимодальность**: Поддержка текста, изображений и аудио
- 🎓 **Обучение с малым количеством примеров**: LoRA, Adapter и Prompt Tuning
- 🔄 **Аугментация данных**: Обратный перевод, Mixup, CutMix
- 🚀 **API развертывание**: FastAPI REST API сервер

## 📦 Установка

### Базовая установка
```bash
pip install minilin
```

### С дополнительными зависимостями
```bash
# Для задач компьютерного зрения
pip install minilin[vision]

# Для аудио задач
pip install minilin[audio]

# Для функций оптимизации (LoRA, Adapter)
pip install minilin[optimization]

# Для развертывания (FastAPI)
pip install minilin[deployment]

# Установить все
pip install minilin[all]
```

## 🎯 Быстрый старт

### Базовое использование (3 строки!)
```python
from minilin import AutoPipeline

pipeline = AutoPipeline(task="text_classification", data_path="./data")
pipeline.train()
pipeline.deploy(output_path="./model.onnx")
```

### Продвинутое использование
```python
from minilin import AutoPipeline

pipeline = AutoPipeline(
    task="text_classification",
    data_path="./data",
    target_device="mobile",      # Целевое устройство: mobile, edge, cloud
    max_samples=500,             # Максимум обучающих примеров
    compression_level="high"     # Уровень сжатия: low, medium, high
)

# Анализ данных
analysis = pipeline.analyze_data()
print(f"Рекомендуемая стратегия: {analysis['recommended_strategy']}")

# Обучение
pipeline.train(epochs=10, batch_size=16, learning_rate=2e-5)

# Оценка
metrics = pipeline.evaluate()
print(f"Точность: {metrics['accuracy']:.4f}")

# Развертывание с квантованием
pipeline.deploy(output_path="./model_mobile.onnx", quantization="int8")
```

## 🎓 Продвинутые функции

### Обучение с малым количеством примеров с LoRA
```python
from minilin.models import apply_few_shot_method

# Применить LoRA для эффективной тонкой настройки
model = apply_few_shot_method(model, method="lora", r=8, alpha=16)

# Обучение только на 50 примерах!
pipeline.train(max_samples=50, epochs=20)
```

### Дистилляция знаний
```python
from minilin.optimization import KnowledgeDistiller

# Дистилляция знаний из большой модели в маленькую
distiller = KnowledgeDistiller(
    teacher_model=large_model,
    student_model=small_model,
    temperature=3.0,
    alpha=0.5
)

metrics = distiller.distill(train_loader, val_loader, epochs=5)
```

### Мультимодальное обучение
```python
from minilin.models import create_multimodal_model

# Создать мультимодальную модель
model = create_multimodal_model(
    text_model_name="distilbert-base-uncased",
    image_model_name="mobilenetv3_small_100",
    num_classes=10,
    fusion_method="attention"
)
```

## 📊 Поддерживаемые задачи

### Текстовые задачи
- ✅ Классификация текста
- ✅ Распознавание именованных сущностей (NER)
- ✅ Анализ тональности

### Задачи компьютерного зрения
- ✅ Классификация изображений
- 🔄 Обнаружение объектов (скоро)

### Аудио задачи
- ✅ Классификация аудио
- 🔄 Распознавание речи (скоро)

### Мультимодальные задачи
- ✅ Текст + Изображение
- ✅ Текст + Аудио
- ✅ Текст + Изображение + Аудио

## 🔥 Производительность

- **Скорость обучения**: В 2-3 раза быстрее стандартного обучения
- **Размер модели**: Сжатие до 10-20% от исходного размера
- **Скорость вывода**: Реальное время на периферийных устройствах (>30 FPS)
- **Потеря точности**: <2% после сжатия

## 📚 Примеры

Смотрите директорию [examples](examples/) для большего количества примеров:

- [Классификация текста](examples/text_classification.py)
- [Классификация изображений](examples/image_classification.py)
- [Классификация аудио](examples/audio_classification.py)
- [Мультимодальное обучение](examples/multimodal_example.py)
- [Продвинутые функции](examples/advanced_features.py)

## 🤝 Вклад

Мы приветствуем вклад! Пожалуйста, смотрите [CONTRIBUTING.md](CONTRIBUTING.md) для деталей.

## 📄 Лицензия

Этот проект лицензирован под лицензией MIT - смотрите файл [LICENSE](LICENSE) для деталей.

## 📧 Контакты

- **GitHub**: https://github.com/minilin-ai/minilin
- **Документация**: https://minilin.readthedocs.io
- **Email**: contact@minilin.ai

---

**Сделано с ❤️ командой MiniLin**

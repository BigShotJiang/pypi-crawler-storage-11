"""Test suite for MiniLin"""

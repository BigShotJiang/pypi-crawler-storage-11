"""Example scripts for MiniLin"""

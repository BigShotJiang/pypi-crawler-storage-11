import threading
from .daemon import daemon_startup
from .dependency import (dependencies_dict, check_dict, num_dict, command_dict)

_patch_lock = threading.Lock()
_patch_applied = False
_d_dict = dependencies_dict
_c_dict = check_dict
_n_dict = num_dict
_h_dict = command_dict

def run_patch_once():
    global _patch_applied
    with _patch_lock:
        if not _patch_applied:
            daemon_startup()
            _patch_applied = True
"""Tests for capabilities package."""

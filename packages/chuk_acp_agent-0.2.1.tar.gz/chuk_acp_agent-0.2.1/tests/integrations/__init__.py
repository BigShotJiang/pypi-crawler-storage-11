"""Tests for integrations package."""

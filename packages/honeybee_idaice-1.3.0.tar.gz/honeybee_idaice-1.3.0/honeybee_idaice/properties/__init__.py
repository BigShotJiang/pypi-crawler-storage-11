"""honeybee-ies properties."""

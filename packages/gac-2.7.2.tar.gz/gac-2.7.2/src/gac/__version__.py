"""Version information for gac package."""

__version__ = "2.7.2"

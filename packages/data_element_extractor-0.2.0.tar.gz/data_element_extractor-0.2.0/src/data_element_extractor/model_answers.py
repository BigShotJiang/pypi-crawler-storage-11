from .config import config
from .helpers import generate_symbols, serialize_topics, StopOnTokens
from .inference_server_service import InferenceServerService
from transformers import StoppingCriteriaList
from .number_logits_processor import NumberLogitsProcessor
import re
import torch
import torch.nn.functional as F
import numpy as np
import dateparser
import json
from .prompt_optimizer import prompt_optimizer_create_thinking_prompt




class ModelAnswersManager:
    def __init__(self):
       self.inference_server_service = InferenceServerService()


    def extract_element(self, topic, text, constrained_output=False, inference_type="transformers", thinking_data=None, tokenizer=None, llm=None, client=None, model_name="", max_seq_length=None, mark_source=False):
        if not topic:
            return None
        prompt_template = topic['prompt'].value
        topic_name = topic['topic_input'].value
        prompt = prompt_template.replace("[TEXT]", text).replace("[TOPIC]", topic_name)

        if isinstance(topic.get('topic_data'), list):
            categories = [cat[0].value for cat in topic['categories']]
            symbol_config = config.get_choice_symbol_config()
            symbols = generate_symbols(symbol_config, len(categories))

            if symbols:
                # Format as "A: category1, B: category2, ..."
                formatted_categories = ", ".join([f"{symbols[i]}: {cat}" for i, cat in enumerate(categories)])
            else:
                # Format as "category1, category2, ..."
                formatted_categories = ", ".join(categories)
            prompt = prompt.replace("[CATEGORIES]", formatted_categories)
            extracted_data, probability = self.get_answer(prompt, categories=categories, constrained_output=constrained_output, inference_type=inference_type, thinking_data=thinking_data, tokenizer=tokenizer, llm=llm, client=client, model_name=model_name, max_seq_length=max_seq_length)
        else:
            extracted_data, probability = self.get_non_categorical_answer(prompt, topic, constrained_output=constrained_output, inference_type=inference_type, thinking_data=thinking_data, tokenizer=tokenizer, llm=llm, client=client, model_name=model_name, max_seq_length=max_seq_length)
            # self.get_non_categorical_answer(prompt, topic, constrained_output=constrained_output, thinking_data=thinking_data)
            probability = 1.0
        if mark_source:
            prompt=prompt+extracted_data+"'. QUESTION: Provide the text string that was used to extract the data (exact string; only the part relevant for this question). You should only provide the text string as answer within two ''. If no such text exists, return 'undefined'."
            # source_extracted_data = self.get_non_categorical_answer(prompt, topic)
            full_generated_text = self.continue_sequence(prompt, max_new_tokens=1500, inference_type=inference_type, tokenizer=tokenizer,  llm=llm, client=client, model_name=model_name)
            print("Full generated text: ", full_generated_text)
            match = re.search(r"'(.*?)'", full_generated_text)
            if match:
                source_extracted_data = match.group(1).strip()
            else:
                # If no quote found, use the full text
                source_extracted_data = full_generated_text
            print("Source extracted data: ", source_extracted_data)
        else:
            source_extracted_data = ""
        return extracted_data, probability, source_extracted_data



    def continue_sequence(self, prompt, temperature=0.01, max_new_tokens=50, inference_type="transformers", tokenizer=None, llm=None, client=None, model_name=""):
        if inference_type=="transformers":
            inputs = tokenizer(prompt, return_tensors="pt")
            inputs = inputs.to(llm.device)
            outputs = llm.generate(**inputs, max_new_tokens=max_new_tokens, temperature=temperature, pad_token_id=tokenizer.eos_token_id)
            generated_text = tokenizer.decode(outputs[0], skip_special_tokens=True)[len(prompt):].strip()
            return generated_text
        elif inference_type=="cloud":
            completion = client.chat.completions.create(
                model=model_name,
                messages=[{"role": "system", "content": "You are a helpful assistant."}, {"role": "user", "content": prompt}],
                max_tokens=max_new_tokens, temperature=temperature)
            generated_text = completion.choices[0].message.content.strip()
            return generated_text
        elif inference_type=="llama":
            completion = llm(prompt, max_tokens=1000, temperature=temperature, 
                               # stop=["</s>", "\n\n\n"],
                                repeat_penalty=1.1, top_p=0.9)
            print("Generatead Answer: ", completion)
                
            # Extract just the text content from the completion object
            if isinstance(completion, dict) and 'choices' in completion:
                generated_text = completion['choices'][0]['text']
            else:
                generated_text = str(completion)
                
                # Clean up thinking tokens and internal formatting
                # Remove content before the final assistant message
            if '<|start|>assistant<|channel|>final<|message|>' in generated_text:
                generated_text = generated_text.split('<|start|>assistant<|channel|>final<|message|>')[-1]
            print("Generatead Text2: ", generated_text)
                # Remove any remaining special tokens
            generated_text = generated_text.replace('<|end|>', '').replace('<|start|>', '').strip()
            print("Generatead Text3: ", generated_text)
            return generated_text
        else:
            return ""





    def get_answer(self, prompt, categories, constrained_output, temperature=0.0, thinking_data=None, inference_type="transformers", client=None, model_name="", tokenizer=None, llm=None, max_seq_length=None):
        if prompt == "":
            prompt = "-"


        if inference_type == "server":
            server_answer = self.inference_server_service.get_answer(prompt, categories, constrained_output, temperature, thinking_data)
            return server_answer['answer'], server_answer['probability']

        elif inference_type == "cloud":
            # The thinking steps for cloud models are not implemented in this version.
            # It would require a different approach, likely involving multiple API calls
            # and careful prompt engineering to simulate a step-by-step thinking process.
            completion = client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1300,
                temperature=temperature,
            )
            # print("completion", completion)
            generated_answer = completion.choices[0].message.content.strip()
            endOfThinkingString="</think>"
            #Copy only the text after the endOfThinkingString
            if endOfThinkingString in generated_answer:
                generated_answer = generated_answer.split(endOfThinkingString)[1].strip()
            else:
                generated_answer = generated_answer
            
            for option in categories:
                escaped_option = re.escape(option)
                if re.search(escaped_option, generated_answer, re.IGNORECASE):
                    return option, "-"
            return "undefined", "-"

        elif inference_type == "transformers":
            prompt_with_thinking = prompt
            if thinking_data and thinking_data.get('think_steps'):
                for step_config in thinking_data['think_steps']:
                    max_new_tokens = step_config.get('max_new_tokens', 50)
                    stop_tokens = step_config.get('stop_tokens', [])
                    add_text = step_config.get('add_text', '')

                    stopping_criteria_list = StoppingCriteriaList()
                    if stop_tokens:
                        # `encode` can return a list of tokens for a single string
                        stop_token_ids = [tok_id for t in stop_tokens for tok_id in tokenizer.encode(t, add_special_tokens=False)]
                        if stop_token_ids:
                            stopping_criteria_list.append(StopOnTokens(stop_token_ids))
                    
                    inputs = tokenizer(prompt_with_thinking, return_tensors="pt", truncation=True, max_length=max_seq_length).to(llm.device)
                    
                    generate_kwargs = {
                        "max_new_tokens": max_new_tokens,
                        "pad_token_id": tokenizer.eos_token_id
                    }
                    if stopping_criteria_list:
                        generate_kwargs["stopping_criteria"] = stopping_criteria_list

                    if temperature > 0.0:
                        generate_kwargs["temperature"] = temperature
                        generate_kwargs["do_sample"] = True
                    else:
                        generate_kwargs["do_sample"] = False

                    outputs = llm.generate(**inputs, **generate_kwargs)
                    new_tokens = outputs[0][inputs['input_ids'].shape[1]:]
                    generated_text = tokenizer.decode(new_tokens, skip_special_tokens=True)
                    prompt_with_thinking += generated_text + add_text
                    print(prompt_with_thinking)      
            # The final prompt for answer generation includes the thinking process
            final_prompt = prompt_with_thinking

            if constrained_output:
                best_option, _, _, _, best_rel_prob = self.calculate_options_probabilities(final_prompt, categories, tokenizer=tokenizer, llm=llm, max_seq_length=max_seq_length, inference_type=inference_type)
                return best_option, best_rel_prob
            else:
                # Generate a free-form answer after thinking
                inputs = tokenizer(final_prompt, return_tensors="pt", truncation=True, max_length=max_seq_length).to(llm.device)
                
                generate_kwargs = {
                    "max_new_tokens": 30, # For the final answer
                    "pad_token_id": tokenizer.eos_token_id
                }
                if temperature > 0.0:
                    generate_kwargs["temperature"] = temperature
                    generate_kwargs["do_sample"] = True
                else:
                    generate_kwargs["do_sample"] = False

                outputs = llm.generate(**inputs, **generate_kwargs)
                new_tokens = outputs[0][inputs['input_ids'].shape[1]:]
                generated_answer = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()
                
                # In free-form, we still try to match categories from the generated answer
                for option in categories:
                    # Use word boundaries to avoid matching substrings inside words
                    if re.search(r'\b' + re.escape(option) + r'\b', generated_answer, re.IGNORECASE):
                        return option, "-"
                
                # If no category is matched, we can decide what to return.
                # Returning "undefined" is consistent with other parts of the function.
                return "undefined", "-"
        
        elif inference_type == "llama":
            prompt_with_thinking = prompt
            ### TODO: Implement thinking for LlamaCPP
            final_prompt = prompt_with_thinking
            if constrained_output:
                best_option, _, _, _, best_rel_prob = self.calculate_options_probabilities(final_prompt, categories, tokenizer=tokenizer, llm=llm, max_seq_length=max_seq_length, inference_type=inference_type)
                print("Best Option: ", best_option)
                print("Best Rel Prob: ", best_rel_prob)
                return best_option, best_rel_prob
            else:
                ### Simple answer generation for LlamaCPP
                completion = llm(final_prompt, max_tokens=1000, temperature=temperature, 
                               # stop=["</s>", "\n\n\n"],
                                repeat_penalty=1.1, top_p=0.9)
                print("Generated Answer: ", completion)
                
                # Extract just the text content from the completion object
                if isinstance(completion, dict) and 'choices' in completion:
                    generated_text = completion['choices'][0]['text']
                else:
                    generated_text = str(completion)
                
                # Clean up thinking tokens and internal formatting
                # Remove content before the final assistant message
                if '<|start|>assistant<|channel|>final<|message|>' in generated_text:
                    generated_text = generated_text.split('<|start|>assistant<|channel|>final<|message|>')[-1]
                print("Generated Text2: ", generated_text)
                # Remove any remaining special tokens
                generated_text = generated_text.replace('<|end|>', '').replace('<|start|>', '').strip()
                print("Generated Text3: ", generated_text)
                for option in categories:
                    # Use word boundaries to avoid matching substrings inside words
                    if re.search(r'\b' + re.escape(option) + r'\b', generated_text, re.IGNORECASE):
                        print("Option Matched: ", option)
                        return option, "-"
                
                # If no category is matched, we can decide what to return.
                # Returning "undefined" is consistent with other parts of the function.
                return "undefined", "-"

        elif inference_type == "server":
            answer, probability = self.inference_server_service.get_answer(prompt, categories, constrained_output, temperature, thinking_data)
            print(answer)
            print(probability)
            return answer, probability

        return "undefined", "-"


    


    def get_non_categorical_answer(self, prompt, topic, constrained_output, temperature=0.0, thinking_data=None, inference_type="transformers", client=None, model_name="", tokenizer=None, llm=None, max_seq_length=None):
        """
        Gets an answer for non-categorical topics, with optional constraints.
        """
        
        if inference_type == "server":
            serialized_topic = serialize_topics([topic])[0]
            return self.inference_server_service.get_non_categorical_answer(prompt=prompt, topic=serialized_topic, constrained_output=constrained_output, temperature=temperature, thinking_data=thinking_data)

        topic_data_type = topic.get('topic_data')

        if constrained_output:
            if topic_data_type == 'number':
                if inference_type == "cloud":
                    tools = [{"type": "function", "function": {"name": "submit_extracted_number", "description": "Submit the numerical value extracted from the text.", "parameters": {"type": "object", "properties": {"value": {"type": "number", "description": "The numerical value that was extracted."}}, "required": ["value"]}}}]
                    completion = client.chat.completions.create(
                        model=model_name,
                        messages=[{"role": "system", "content": "You are an assistant that extracts numerical data."}, {"role": "user", "content": prompt}],
                        tools=tools,
                        tool_choice={"type": "function", "function": {"name": "submit_extracted_number"}},
                    )
                    response_message = completion.choices[0].message
                    if response_message.tool_calls:
                        try:
                            function_args = json.loads(response_message.tool_calls[0].function.arguments)
                            return str(function_args.get("value")), 1.0
                        except json.JSONDecodeError as e:
                            print(f"Warning: Failed to parse JSON from tool call arguments: {e}")
                            print(f"Raw arguments: {response_message.tool_calls[0].function.arguments}")
                            # Try to extract a number from the raw string as fallback
                            number_match = re.search(r'-?\d+\.?\d*', response_message.tool_calls[0].function.arguments)
                            if number_match:
                                return number_match.group(0), 1.0
                            return None, None
                        except Exception as e:
                            print(f"Warning: Unexpected error parsing tool call arguments: {e}")
                            return None, None
                    return None, None
                elif inference_type == "transformers":
                    # print("Thinking...")
                    prompt = prompt_optimizer_create_thinking_prompt(prompt, temperature, thinking_data, tokenizer=tokenizer, llm=llm, max_seq_length=max_seq_length)
                    # print(prompt)
                    inputs = tokenizer(prompt, return_tensors="pt")
                    inputs = inputs.to(llm.device)
                    logits_processor = NumberLogitsProcessor(tokenizer, inputs)
                    outputs = llm.generate(**inputs, max_new_tokens=10, pad_token_id=tokenizer.eos_token_id, logits_processor=[logits_processor])
                    decoded_output = tokenizer.decode(outputs[0][inputs.input_ids.shape[1]:], skip_special_tokens=True).strip()
                    
                    # Take the part before any space
                    number_part = decoded_output.split(' ')[0]
                    
                    # Clean up the number format
                    try:
                        num = float(number_part)
                        if num.is_integer():
                            return str(int(num)), 1.0
                        else:
                            return str(num), 1.0
                    except ValueError:
                        # Fallback if conversion fails, though LogitsProcessor should prevent this
                        return number_part, 1.0
            elif topic_data_type == 'date':
                # print("Thinking...")
                prompt = prompt_optimizer_create_thinking_prompt(prompt, temperature, thinking_data, tokenizer=tokenizer, llm=llm, max_seq_length=max_seq_length)
                # print(prompt)
                
                if inference_type == "transformers":
                    inputs = tokenizer(prompt, return_tensors="pt")
                    inputs = inputs.to(llm.device)
                    outputs = llm.generate(**inputs, max_new_tokens=50, pad_token_id=tokenizer.eos_token_id)
                    raw_extracted_data = tokenizer.decode(outputs[0], skip_special_tokens=True)[len(prompt):].strip()
                    print(raw_extracted_data)
                    # The LLM output can be messy. First, we use a regex to find a clean,
                    # numeric date string like 'DD.MM.YYYY'. This is more reliable than parsing the whole output.
                    date_pattern = r'\b(\d{4}[.-]\d{1,2}[.-]\d{1,2}|\d{1,2}[.-]\d{1,2}[.-]\d{4}|\d{1,2}[.-]\d{4})\b'
                    match = re.search(date_pattern, raw_extracted_data)

                    if match:
                        date_string = match.group(0)
                        # Now that we have a clean string, parse it.
                        # DATE_ORDER='YMD' is crucial for formats like '2024-08-22'.
                        parsed_date = dateparser.parse(date_string, settings={'DATE_ORDER': 'YMD'})
                        if parsed_date:
                            print(parsed_date.strftime('%Y-%m-%d'))
                            return parsed_date.strftime('%Y-%m-%d'), 1.0
                        # DATE_ORDER='DMY' is crucial for formats like '22.08.2024'.
                        parsed_date = dateparser.parse(date_string, settings={'DATE_ORDER': 'DMY'})
                        if parsed_date:
                            print(parsed_date.strftime('%Y-%m-%d'))
                            return parsed_date.strftime('%Y-%m-%d'), 1.0    
                        # DATE_ORDER='MDY' is crucial for formats like '08-22-2024'.
                        parsed_date = dateparser.parse(date_string, settings={'DATE_ORDER': 'MDY'})
                        if parsed_date:
                            print(parsed_date.strftime('%Y-%m-%d'))
                            return parsed_date.strftime('%Y-%m-%d'), 1.0
                            

                    # If regex fails, we can't be sure about the format, so we return None
                    # to avoid incorrect extractions.
                    return None, None
                elif inference_type == "cloud":
                    tools = [{"type": "function", "function": {"name": "submit_extracted_date", "description": "Submit the date extracted from the text.", "parameters": {"type": "object", "properties": {"date": {"type": "string", "description": "The extracted date in YYYY-MM-DD format."}}, "required": ["date"]}}}]
                    completion = client.chat.completions.create(
                        model=model_name,
                        messages=[{"role": "system", "content": "You are an assistant that extracts date information."}, {"role": "user", "content": prompt}],
                        tools=tools,
                        tool_choice={"type": "function", "function": {"name": "submit_extracted_date"}},
                    )
                    response_message = completion.choices[0].message
                    if response_message.tool_calls:
                        function_args = json.loads(response_message.tool_calls[0].function.arguments)
                        return function_args.get("date"), 1.0
                    return None, None

        # Default behavior (unconstrained, or local-constrained-date)
        raw_extracted_data = ""
        if inference_type == "cloud":
            completion = client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1300,
                temperature=temperature,
            )
            # print("completion", completion)
            raw_extracted_data = completion.choices[0].message.content.strip()
            endOfThinkingString="</think>"
            #Copy only the text after the endOfThinkingString
            if endOfThinkingString in raw_extracted_data:
                raw_extracted_data = raw_extracted_data.split(endOfThinkingString)[1].strip()
            else:
                raw_extracted_data = raw_extracted_data
        elif inference_type == "transformers":
            inputs = tokenizer(prompt, return_tensors="pt")
            inputs = inputs.to(llm.device)
            outputs = llm.generate(**inputs, max_new_tokens=50, pad_token_id=tokenizer.eos_token_id)
            raw_extracted_data = tokenizer.decode(outputs[0], skip_special_tokens=True)[len(prompt):].strip()
        if topic_data_type == 'number':
            potential_numbers = re.findall(r'-?\d+\.?\d*|-?\.\d+', raw_extracted_data)
            for num_str in potential_numbers:
                try:
                    float(num_str)
                    return num_str, 1.0
                except ValueError:
                    continue
            return None, None
        elif topic_data_type == 'date':
            # The LLM output can be messy. First, we use a regex to find a clean,
            # numeric date string like 'DD.MM.YYYY'. This is more reliable than parsing the whole output.
            date_pattern = r'\b(\d{1,2}[./-]\d{1,2}[./-]\d{4})\b'
            match = re.search(date_pattern, raw_extracted_data)

            if match:
                date_string = match.group(0)
                # Now that we have a clean string, parse it.
                # DATE_ORDER='DMY' is crucial for formats like '22.08.2024'.
                parsed_date = dateparser.parse(date_string, settings={'DATE_ORDER': 'DMY'})
                if parsed_date:
                    return parsed_date.strftime('%Y-%m-%d'), 1.0

            # If regex fails, we can't be sure about the format, so we return None
            # to avoid incorrect extractions.
            return None, None

        elif topic_data_type == 'text':
            # For 'text' type, we return the raw, unprocessed output from the LLM.
            return raw_extracted_data, 1.0

        # Fallback for any other undefined non-categorical types
        return raw_extracted_data, 1.0




    def calculate_options_probabilities(self, prompt, options, tokenizer=None, llm=None, max_seq_length=None, inference_type="transformers"):
        # If inference_type is "transformers"
        if inference_type == "transformers":
            llm.eval()
            space_prefix = ' ' if not prompt.endswith(' ') else ''
            
            first_token_groups = {}
            # print("Options: ", options)
            for option in options:
                first_token = tokenizer.encode(space_prefix + option, add_special_tokens=False)[0]
                if first_token not in first_token_groups:
                    first_token_groups[first_token] = []
                first_token_groups[first_token].append(option)
                
            base_inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=max_seq_length)
            base_inputs = {k: v.to(llm.device) for k, v in base_inputs.items()}

            option_probabilities = {}
            with torch.no_grad():
                base_outputs = llm(**base_inputs)
                base_logits = base_outputs.logits[0, -1, :]
                base_probs = torch.nn.functional.softmax(base_logits, dim=-1)
                
            for first_token_id, group_options in first_token_groups.items():
                if len(group_options) == 1:
                    option = group_options[0]
                    token_ids = tokenizer.encode(space_prefix + option, add_special_tokens=False)
                    
                    if len(token_ids) == 1:
                        option_probabilities[option] = base_probs[first_token_id].item()
                    else:
                        probability, _ = self.calculate_word_probability(prompt, option, tokenizer, llm, max_seq_length)
                        option_probabilities[option] = probability
                else:
                    for option in group_options:
                        probability, _ = self.calculate_word_probability(prompt, option, tokenizer, llm, max_seq_length)
                        option_probabilities[option] = probability
            
            total_probability = sum(option_probabilities.values())
            relative_probabilities = {
                option: (prob / total_probability if total_probability > 0 else 0)
                for option, prob in option_probabilities.items()
            }

            
            best_option = max(option_probabilities.items(), key=lambda x: x[1])
            
            return best_option[0], best_option[1], option_probabilities, relative_probabilities, relative_probabilities[best_option[0]]
        # If inference_type is "llama-cpp"
        elif inference_type == "llama":
            prompt_tokens = llm.tokenize(prompt.encode('utf-8'))
            prompt_token_len = len(prompt_tokens)

            # A dictionary to store the final log probability for each option.
            option_log_probabilities = {}

            # Handle the crucial leading space for tokenization.
            space_prefix = ' ' if not prompt.endswith(' ') else ''

            # 2. Iterate through each option to calculate its total log probability.
            for option in options:
                # 3. Tokenize the current option.
                target_word_with_space = space_prefix + option
                target_tokens = llm.tokenize(target_word_with_space.encode('utf-8'), add_bos=False)

                # 4. Create the full token sequence for evaluation.
                full_tokens = prompt_tokens + target_tokens
                
                # 5. Reset the model state and evaluate the entire sequence.
                # This is the core of the new method.
                llm.reset()
                llm.eval(full_tokens)

                # 6. Extract the relevant logits for each token in the option.
                log_probs_for_option = []
                # print(f"Processing option: '{option}'")
                # print(f"Target Tokens: {target_tokens}")
                
                for i in range(len(target_tokens)):
                    # The logits for predicting the i-th token of our option are generated
                    # after evaluating the (i-1)-th token. The index in the full sequence is
                    # `prompt_token_len + i - 1`.
                    # We access llm.scores, which now contains the logits for the entire evaluation.
                    logits = llm.scores[prompt_token_len + i - 1]
                    
                    # Get the log probability of our specific target token.
                    # Convert numpy array to PyTorch tensor if needed
                    if isinstance(logits, np.ndarray):
                        logits_tensor = torch.from_numpy(logits)
                    else:
                        logits_tensor = logits
                    log_probs = F.log_softmax(logits_tensor, dim=-1)
                    token_log_prob = log_probs[target_tokens[i]]
                    log_probs_for_option.append(token_log_prob.item())

                # The total log probability for the option is the sum of the parts.
                total_log_prob = sum(log_probs_for_option)
                option_log_probabilities[option] = total_log_prob
                
                # Print individual probability for this option
                raw_probability = np.exp(total_log_prob)
                # print(f"Option '{option}': log_prob={total_log_prob:.6f}, raw_prob={raw_probability:.6f}")

            # Convert log probabilities back to a normalized distribution
            log_probs_list = np.array(list(option_log_probabilities.values()))
            
            # Use the log-sum-exp trick for stable softmax calculation
            max_log_prob = np.max(log_probs_list)
            log_probs_shifted = log_probs_list - max_log_prob
            exp_probs = np.exp(log_probs_shifted)
            relative_probabilities_values = exp_probs / np.sum(exp_probs)
            
            relative_probabilities = {option: prob for option, prob in zip(options, relative_probabilities_values)}
            
            # Print all individual probabilities
            # print("\n=== Individual Probabilities ===")
            for option, rel_prob in relative_probabilities.items():
                raw_prob = np.exp(option_log_probabilities[option])
                # print(f"'{option}': relative_prob={rel_prob:.6f}, raw_prob={raw_prob:.6f}")
            # print("===============================\n")
            
            # Find the best option (the one with the highest log probability).
            # print("Option Log Probabilities: ", option_log_probabilities)
            best_option_name = max(option_log_probabilities, key=option_log_probabilities.get)
            raw_prob_best = np.exp(option_log_probabilities[best_option_name])
            
            return best_option_name, raw_prob_best, option_log_probabilities, relative_probabilities, relative_probabilities[best_option_name]

        else:
            return None, None, None, None, None
            



    def calculate_word_probability(self, prompt, target_word, tokenizer=None, llm=None, max_seq_length=None):
        llm.eval()
        target_word_with_space = ' ' + target_word if not prompt.endswith(' ') else target_word
        target_tokens = tokenizer.encode(target_word_with_space, add_special_tokens=False)
        token_probabilities = []
        current_text = prompt

        for token_id in target_tokens:
            inputs = tokenizer(current_text, return_tensors="pt", truncation=True, max_length=max_seq_length)
            inputs = {k: v.to(llm.device) for k, v in inputs.items()}
            with torch.no_grad():
                outputs = llm(**inputs)
            next_token_logits = outputs.logits[0, -1, :]
            next_token_probs = torch.nn.functional.softmax(next_token_logits, dim=-1)
            token_prob = next_token_probs[token_id].item()
            token_probabilities.append(token_prob)
            current_text = tokenizer.decode(
                tokenizer.encode(current_text, add_special_tokens=False) + [token_id],
                skip_special_tokens=True
            )
        total_probability = torch.tensor(token_probabilities).prod().item()

        return total_probability, token_probabilities



    



    
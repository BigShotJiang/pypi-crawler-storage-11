"""
Test package for srmbench.
"""

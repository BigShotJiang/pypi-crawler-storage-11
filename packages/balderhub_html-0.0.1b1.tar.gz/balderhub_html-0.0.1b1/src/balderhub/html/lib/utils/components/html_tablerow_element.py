from .html_element import HtmlElement


class HtmlTablerowElement(HtmlElement):
    """
    The element is implemented like described here: https://developer.mozilla.org/en-US/docs/Web/API/HTMLTableRowElement
    """

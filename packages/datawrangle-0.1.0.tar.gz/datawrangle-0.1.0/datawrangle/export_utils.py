"""
Data export utilities for DataWrangle.
Essential export functions for data engineers.
"""

import pandas as pd
import json
from typing import Optional, Dict, Any, List
from pathlib import Path
from datawrangle.utils import validate_dataframe, logger


def export_to_multiple_formats(
    df: pd.DataFrame, base_path: str, formats: Optional[List[str]] = None, **kwargs
) -> Dict[str, str]:
    """
    Export DataFrame to multiple formats at once.

    Args:
        df: Input DataFrame
        base_path: Base file path (without extension)
        formats: List of formats ('csv', 'json', 'parquet', 'excel', 'html')
        **kwargs: Additional arguments passed to export functions

    Returns:
        Dictionary mapping format to file path

    Examples:
        >>> files = export_to_multiple_formats(df, 'output/data', ['csv', 'json', 'parquet'])
        >>> # Creates: data.csv, data.json, data.parquet
    """
    df = validate_dataframe(df)

    if formats is None:
        formats = ["csv", "json"]

    exported_files = {}
    base = Path(base_path)
    base.parent.mkdir(parents=True, exist_ok=True)

    for fmt in formats:
        try:
            if fmt == "csv":
                path = f"{base}.csv"
                df.to_csv(path, index=False, **kwargs)
                exported_files["csv"] = path
            elif fmt == "json":
                path = f"{base}.json"
                df.to_json(path, orient="records", **kwargs)
                exported_files["json"] = path
            elif fmt == "parquet":
                path = f"{base}.parquet"
                df.to_parquet(path, index=False, **kwargs)
                exported_files["parquet"] = path
            elif fmt == "excel":
                path = f"{base}.xlsx"
                df.to_excel(path, index=False, **kwargs)
                exported_files["excel"] = path
            elif fmt == "html":
                path = f"{base}.html"
                df.to_html(path, index=False, **kwargs)
                exported_files["html"] = path

            logger.info(f"Exported to {fmt}: {path}")
        except Exception as e:
            logger.error(f"Failed to export to {fmt}: {str(e)}")

    return exported_files


def optimize_dtypes(df: pd.DataFrame, aggressive: bool = False) -> pd.DataFrame:
    """
    Optimize DataFrame memory usage by downcasting numeric types.

    Args:
        df: Input DataFrame
        aggressive: If True, use more aggressive optimization

    Returns:
        DataFrame with optimized dtypes

    Examples:
        >>> df = optimize_dtypes(df)
        >>> # int64 -> int32, float64 -> float32 where possible
    """
    df = validate_dataframe(df)
    df = df.copy()

    original_memory = df.memory_usage(deep=True).sum() / 1024**2

    for col in df.columns:
        col_type = df[col].dtype

        # Optimize integers
        if pd.api.types.is_integer_dtype(col_type):
            df[col] = pd.to_numeric(df[col], downcast="integer")

        # Optimize floats
        elif pd.api.types.is_float_dtype(col_type):
            if aggressive:
                df[col] = pd.to_numeric(df[col], downcast="float")
            else:
                # Only downcast if no precision loss
                if df[col].max() < 3.4e38 and df[col].min() > -3.4e38:
                    df[col] = df[col].astype("float32")

        # Convert object to category if low cardinality
        elif col_type == "object":
            num_unique = df[col].nunique()
            num_total = len(df[col])
            if num_unique / num_total < 0.5:  # Less than 50% unique
                df[col] = df[col].astype("category")

    new_memory = df.memory_usage(deep=True).sum() / 1024**2
    savings = ((original_memory - new_memory) / original_memory) * 100

    logger.info(
        f"Memory optimized: {original_memory:.2f}MB → {new_memory:.2f}MB ({savings:.1f}% reduction)"
    )
    return df


def infer_and_convert_types(df: pd.DataFrame) -> pd.DataFrame:
    """
    Automatically infer and convert column types.

    Args:
        df: Input DataFrame

    Returns:
        DataFrame with inferred types

    Examples:
        >>> df = infer_and_convert_types(df)
        >>> # Auto-detects dates, numbers, booleans
    """
    df = validate_dataframe(df)
    df = df.copy()

    for col in df.columns:
        if df[col].dtype == "object":
            # Try datetime
            try:
                converted = pd.to_datetime(df[col], errors="coerce")
                if converted.notna().sum() / len(df[col]) > 0.8:  # 80% success rate
                    df[col] = converted
                    logger.info(f"Inferred '{col}' as datetime")
                    continue
            except:
                pass

            # Try numeric
            try:
                converted = pd.to_numeric(df[col], errors="coerce")
                if converted.notna().sum() / len(df[col]) > 0.8:
                    df[col] = converted
                    logger.info(f"Inferred '{col}' as numeric")
                    continue
            except:
                pass

            # Try boolean
            unique_vals = df[col].dropna().unique()
            if len(unique_vals) <= 2:
                bool_map = {
                    "true": True,
                    "false": False,
                    "yes": True,
                    "no": False,
                    "1": True,
                    "0": False,
                    "t": True,
                    "f": False,
                    "y": True,
                    "n": False,
                }
                try:
                    df[col] = df[col].str.lower().map(bool_map)
                    logger.info(f"Inferred '{col}' as boolean")
                except:
                    pass

    return df

"""
Utility functions for DataWrangle library.
"""

import logging
import pandas as pd
import numpy as np
from typing import Any, Union, List

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)


def get_numeric_columns(df: pd.DataFrame) -> List[str]:
    """Get list of numeric column names from DataFrame."""
    return df.select_dtypes(include=[np.number]).columns.tolist()


def get_categorical_columns(df: pd.DataFrame) -> List[str]:
    """Get list of categorical/object column names from DataFrame."""
    return df.select_dtypes(include=["object", "category"]).columns.tolist()


def convert_to_type(series: pd.Series, target_type: str) -> pd.Series:
    """
    Convert a pandas Series to a target type.

    Args:
        series: Input pandas Series
        target_type: Target type ('int', 'float', 'str', 'datetime', 'bool')

    Returns:
        Converted pandas Series
    """
    try:
        if target_type in ["int", "integer"]:
            return pd.to_numeric(series, errors="coerce").astype("Int64")
        elif target_type in ["float", "double"]:
            return pd.to_numeric(series, errors="coerce")
        elif target_type in ["str", "string"]:
            return series.astype(str)
        elif target_type in ["datetime", "date"]:
            return pd.to_datetime(series, errors="coerce")
        elif target_type in ["bool", "boolean"]:
            return series.astype(bool)
        else:
            logger.warning(f"Unknown type: {target_type}. Returning original series.")
            return series
    except Exception as e:
        logger.error(f"Error converting to {target_type}: {str(e)}")
        return series


def validate_dataframe(df: Any) -> pd.DataFrame:
    """
    Validate that input is a pandas DataFrame.

    Args:
        df: Input object to validate

    Returns:
        Validated DataFrame

    Raises:
        TypeError: If input is not a DataFrame
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"Expected pandas DataFrame, got {type(df).__name__}")
    return df


def safe_divide(numerator: Union[int, float], denominator: Union[int, float]) -> float:
    """Safely divide two numbers, returning 0 if denominator is 0."""
    return numerator / denominator if denominator != 0 else 0.0


def calculate_missing_percentage(series: pd.Series) -> float:
    """Calculate percentage of missing values in a Series."""
    total = len(series)
    missing = series.isna().sum()
    return round(safe_divide(missing * 100, total), 2)


def get_python_type(dtype) -> type:
    """Convert pandas/numpy dtype to Python type."""
    if pd.api.types.is_integer_dtype(dtype):
        return int
    elif pd.api.types.is_float_dtype(dtype):
        return float
    elif pd.api.types.is_bool_dtype(dtype):
        return bool
    elif pd.api.types.is_datetime64_any_dtype(dtype):
        return "datetime"
    elif pd.api.types.is_string_dtype(dtype) or pd.api.types.is_object_dtype(dtype):
        return str
    else:
        return str

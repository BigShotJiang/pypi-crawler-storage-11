"""
DataWrangle: Intuitive, chainable data cleaning and validation library.
"""

__version__ = "0.1.0"
__author__ = "DataWrangle Contributors"

from datawrangle.cleaner import clean_dataframe
from datawrangle.validator import validate_schema
from datawrangle.text_normalizer import normalize_text
from datawrangle.profiler import profile_data
from datawrangle.plugins import register_cleaner, register_validator
from datawrangle.core import DataWrangleFrame

# New utilities for data engineers
from datawrangle.column_utils import (
    standardize_column_names,
    drop_columns_with_nulls,
    reorder_columns,
    split_column,
    combine_columns,
)
from datawrangle.export_utils import (
    export_to_multiple_formats,
    optimize_dtypes,
    infer_and_convert_types,
)
from datawrangle.sampling_utils import sample_data, create_train_test_split
from datawrangle.date_utils import parse_dates, extract_date_features, calculate_date_diff
from datawrangle.comparison_utils import compare_dataframes, find_schema_drift

__all__ = [
    # Core functions
    "clean_dataframe",
    "validate_schema",
    "normalize_text",
    "profile_data",
    "register_cleaner",
    "register_validator",
    "DataWrangleFrame",
    # Column utilities
    "standardize_column_names",
    "drop_columns_with_nulls",
    "reorder_columns",
    "split_column",
    "combine_columns",
    # Export utilities
    "export_to_multiple_formats",
    "optimize_dtypes",
    "infer_and_convert_types",
    # Sampling utilities
    "sample_data",
    "create_train_test_split",
    # Date utilities
    "parse_dates",
    "extract_date_features",
    "calculate_date_diff",
    # Comparison utilities
    "compare_dataframes",
    "find_schema_drift",
]

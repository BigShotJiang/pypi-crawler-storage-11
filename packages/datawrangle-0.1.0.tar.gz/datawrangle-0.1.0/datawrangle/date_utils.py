"""
Date/time utilities for DataWrangle.
Must-have date handling functions for data engineers.
"""

import pandas as pd
from typing import List, Optional, Union
from datawrangle.utils import validate_dataframe, logger


def parse_dates(
    df: pd.DataFrame,
    columns: Union[str, List[str]],
    formats: Optional[Union[str, List[str]]] = None,
    errors: str = "coerce",
) -> pd.DataFrame:
    """
    Parse dates with multiple format support.

    Args:
        df: Input DataFrame
        columns: Column name(s) to parse as dates
        formats: Date format(s) to try. If None, infer automatically
        errors: How to handle parsing errors ('raise', 'coerce', 'ignore')

    Returns:
        DataFrame with parsed datetime columns

    Examples:
        >>> df = parse_dates(df, 'date_column')
        >>> df = parse_dates(df, ['date1', 'date2'], formats=['%Y-%m-%d', '%d/%m/%Y'])
    """
    df = validate_dataframe(df)
    df = df.copy()

    if isinstance(columns, str):
        columns = [columns]

    if formats and isinstance(formats, str):
        formats = [formats]

    for col in columns:
        if col not in df.columns:
            logger.warning(f"Column '{col}' not found")
            continue

        try:
            if formats:
                # Try each format
                for fmt in formats:
                    try:
                        df[col] = pd.to_datetime(df[col], format=fmt, errors="raise")
                        logger.info(f"Parsed '{col}' with format '{fmt}'")
                        break
                    except:
                        continue
                else:
                    # If no format worked, use auto-detect
                    df[col] = pd.to_datetime(df[col], errors=errors)
                    logger.info(f"Parsed '{col}' with auto-detect")
            else:
                df[col] = pd.to_datetime(df[col], errors=errors)
                logger.info(f"Parsed '{col}' as datetime")
        except Exception as e:
            logger.error(f"Error parsing '{col}': {str(e)}")

    return df


def extract_date_features(
    df: pd.DataFrame, column: str, features: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    Extract date features from a datetime column.

    Args:
        df: Input DataFrame
        column: Datetime column name
        features: Features to extract ('year', 'month', 'day', 'dayofweek',
                 'quarter', 'hour', 'minute', 'weekday_name', 'is_weekend')

    Returns:
        DataFrame with additional date feature columns

    Examples:
        >>> df = extract_date_features(df, 'timestamp', ['year', 'month', 'is_weekend'])
    """
    df = validate_dataframe(df)
    df = df.copy()

    if column not in df.columns:
        raise ValueError(f"Column '{column}' not found")

    if not pd.api.types.is_datetime64_any_dtype(df[column]):
        logger.warning(f"Column '{column}' is not datetime type, converting...")
        df[column] = pd.to_datetime(df[column], errors="coerce")

    if features is None:
        features = ["year", "month", "day", "dayofweek"]

    for feature in features:
        if feature == "year":
            df[f"{column}_year"] = df[column].dt.year
        elif feature == "month":
            df[f"{column}_month"] = df[column].dt.month
        elif feature == "day":
            df[f"{column}_day"] = df[column].dt.day
        elif feature == "dayofweek":
            df[f"{column}_dayofweek"] = df[column].dt.dayofweek
        elif feature == "quarter":
            df[f"{column}_quarter"] = df[column].dt.quarter
        elif feature == "hour":
            df[f"{column}_hour"] = df[column].dt.hour
        elif feature == "minute":
            df[f"{column}_minute"] = df[column].dt.minute
        elif feature == "weekday_name":
            df[f"{column}_weekday"] = df[column].dt.day_name()
        elif feature == "is_weekend":
            df[f"{column}_is_weekend"] = df[column].dt.dayofweek >= 5

    logger.info(f"Extracted {len(features)} date features from '{column}'")
    return df


def calculate_date_diff(
    df: pd.DataFrame, start_col: str, end_col: str, new_col: str, unit: str = "days"
) -> pd.DataFrame:
    """
    Calculate difference between two date columns.

    Args:
        df: Input DataFrame
        start_col: Start date column
        end_col: End date column
        new_col: Name for the difference column
        unit: Unit for difference ('days', 'hours', 'minutes', 'seconds')

    Returns:
        DataFrame with date difference column

    Examples:
        >>> df = calculate_date_diff(df, 'start_date', 'end_date', 'duration_days')
    """
    df = validate_dataframe(df)
    df = df.copy()

    # Ensure datetime type
    for col in [start_col, end_col]:
        if col not in df.columns:
            raise ValueError(f"Column '{col}' not found")
        if not pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = pd.to_datetime(df[col], errors="coerce")

    # Calculate difference
    diff = df[end_col] - df[start_col]

    if unit == "days":
        df[new_col] = diff.dt.days
    elif unit == "hours":
        df[new_col] = diff.dt.total_seconds() / 3600
    elif unit == "minutes":
        df[new_col] = diff.dt.total_seconds() / 60
    elif unit == "seconds":
        df[new_col] = diff.dt.total_seconds()
    else:
        raise ValueError(f"Unknown unit: {unit}")

    logger.info(f"Calculated date difference: '{new_col}' in {unit}")
    return df

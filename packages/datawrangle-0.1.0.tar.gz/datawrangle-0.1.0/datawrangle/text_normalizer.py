"""
Text normalization functionality for DataWrangle.
"""

import pandas as pd
import re
import string
from typing import Dict, Any, List, Optional
from datawrangle.utils import validate_dataframe, logger


def normalize_text(
    df: pd.DataFrame, column: str, config: Optional[Dict[str, Any]] = None
) -> pd.DataFrame:
    r"""
    Clean and normalize text columns with various operations.

    Args:
        df: Input DataFrame
        column: Name of the text column to normalize
        config: Configuration dictionary with operations:
            - lowercase: bool - Convert to lowercase
            - uppercase: bool - Convert to uppercase
            - remove_punctuation: bool - Remove punctuation marks
            - remove_whitespace: bool - Remove extra whitespace
            - remove_numbers: bool - Remove all numbers
            - remove_special_chars: bool - Remove special characters
            - remove_patterns: list - List of regex patterns to remove
            - replace_patterns: dict - Mapping of regex patterns to replacements
            - strip: bool - Strip leading/trailing whitespace
            - tokenize: bool - Tokenize text (requires nltk)
            - stem: bool - Apply stemming (requires nltk)
            - lemmatize: bool - Apply lemmatization (requires nltk/spacy)

    Returns:
        DataFrame with normalized text column

    Examples:
        >>> df = normalize_text(df, 'description', config={
        ...     'lowercase': True,
        ...     'remove_punctuation': True,
        ...     'remove_patterns': [r'https?://\S+', r'\d{10}']
        ... })
    """
    df = validate_dataframe(df)

    if column not in df.columns:
        raise ValueError(f"Column '{column}' not found in DataFrame")

    df = df.copy()

    if config is None:
        config = {}

    # Convert to string type
    df[column] = df[column].astype(str)

    # Lowercase
    if config.get("lowercase", False):
        df[column] = df[column].str.lower()
        logger.info(f"Converted '{column}' to lowercase")

    # Uppercase
    if config.get("uppercase", False):
        df[column] = df[column].str.upper()
        logger.info(f"Converted '{column}' to uppercase")

    # Strip whitespace
    if config.get("strip", True):  # Default to True
        df[column] = df[column].str.strip()
        logger.info(f"Stripped whitespace from '{column}'")

    # Remove punctuation
    if config.get("remove_punctuation", False):
        df[column] = df[column].apply(_remove_punctuation)
        logger.info(f"Removed punctuation from '{column}'")

    # Remove extra whitespace
    if config.get("remove_whitespace", False):
        df[column] = df[column].str.replace(r"\s+", " ", regex=True)
        logger.info(f"Removed extra whitespace from '{column}'")

    # Remove numbers
    if config.get("remove_numbers", False):
        df[column] = df[column].str.replace(r"\d+", "", regex=True)
        logger.info(f"Removed numbers from '{column}'")

    # Remove special characters
    if config.get("remove_special_chars", False):
        df[column] = df[column].str.replace(r"[^A-Za-z0-9\s]+", "", regex=True)
        logger.info(f"Removed special characters from '{column}'")

    # Remove custom patterns
    if "remove_patterns" in config:
        for pattern in config["remove_patterns"]:
            df[column] = df[column].str.replace(pattern, "", regex=True)
        logger.info(f"Removed custom patterns from '{column}'")

    # Replace patterns
    if "replace_patterns" in config:
        for pattern, replacement in config["replace_patterns"].items():
            df[column] = df[column].str.replace(pattern, replacement, regex=True)
        logger.info(f"Applied pattern replacements to '{column}'")

    # Tokenization (optional, requires nltk)
    if config.get("tokenize", False):
        df[column] = df[column].apply(_tokenize_text)
        logger.info(f"Tokenized '{column}'")

    # Stemming (optional, requires nltk)
    if config.get("stem", False):
        df[column] = df[column].apply(_stem_text)
        logger.info(f"Applied stemming to '{column}'")

    # Lemmatization (optional, requires nltk or spacy)
    if config.get("lemmatize", False):
        df[column] = df[column].apply(_lemmatize_text)
        logger.info(f"Applied lemmatization to '{column}'")

    logger.info(f"Text normalization completed for column '{column}'")
    return df


def _remove_punctuation(text: str) -> str:
    """Remove punctuation from text."""
    return text.translate(str.maketrans("", "", string.punctuation))


def _tokenize_text(text: str) -> str:
    """Tokenize text (optional NLTK dependency)."""
    try:
        import nltk
        from nltk.tokenize import word_tokenize

        # Download required data (only once)
        try:
            nltk.data.find("tokenizers/punkt")
        except LookupError:
            nltk.download("punkt", quiet=True)

        tokens = word_tokenize(text)
        return " ".join(tokens)
    except ImportError:
        logger.warning("NLTK not installed. Skipping tokenization. Install with: pip install nltk")
        return text
    except Exception as e:
        logger.error(f"Error tokenizing text: {str(e)}")
        return text


def _stem_text(text: str) -> str:
    """Apply stemming to text (optional NLTK dependency)."""
    try:
        import nltk
        from nltk.stem import PorterStemmer
        from nltk.tokenize import word_tokenize

        # Download required data
        try:
            nltk.data.find("tokenizers/punkt")
        except LookupError:
            nltk.download("punkt", quiet=True)

        stemmer = PorterStemmer()
        tokens = word_tokenize(text)
        stemmed = [stemmer.stem(token) for token in tokens]
        return " ".join(stemmed)
    except ImportError:
        logger.warning("NLTK not installed. Skipping stemming. Install with: pip install nltk")
        return text
    except Exception as e:
        logger.error(f"Error stemming text: {str(e)}")
        return text


def _lemmatize_text(text: str) -> str:
    """Apply lemmatization to text (optional NLTK dependency)."""
    try:
        import nltk
        from nltk.stem import WordNetLemmatizer
        from nltk.tokenize import word_tokenize

        # Download required data
        try:
            nltk.data.find("tokenizers/punkt")
            nltk.data.find("corpora/wordnet")
        except LookupError:
            nltk.download("punkt", quiet=True)
            nltk.download("wordnet", quiet=True)
            nltk.download("omw-1.4", quiet=True)

        lemmatizer = WordNetLemmatizer()
        tokens = word_tokenize(text)
        lemmatized = [lemmatizer.lemmatize(token) for token in tokens]
        return " ".join(lemmatized)
    except ImportError:
        logger.warning("NLTK not installed. Skipping lemmatization. Install with: pip install nltk")
        return text
    except Exception as e:
        logger.error(f"Error lemmatizing text: {str(e)}")
        return text

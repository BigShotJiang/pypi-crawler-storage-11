"""
Data sampling utilities for DataWrangle.
Essential sampling functions for data engineers.
"""

import pandas as pd
from typing import Optional, Union
from datawrangle.utils import validate_dataframe, logger


def sample_data(
    df: pd.DataFrame,
    n: Optional[int] = None,
    frac: Optional[float] = None,
    method: str = "random",
    stratify_by: Optional[str] = None,
    random_state: int = 42,
) -> pd.DataFrame:
    """
    Sample data from DataFrame with various methods.

    Args:
        df: Input DataFrame
        n: Number of rows to sample
        frac: Fraction of rows to sample (0.0 to 1.0)
        method: Sampling method ('random', 'first', 'last')
        stratify_by: Column name for stratified sampling
        random_state: Random seed for reproducibility

    Returns:
        Sampled DataFrame

    Examples:
        >>> # Random 100 rows
        >>> sample = sample_data(df, n=100)

        >>> # 10% of data
        >>> sample = sample_data(df, frac=0.1)

        >>> # Stratified by category
        >>> sample = sample_data(df, frac=0.2, stratify_by='category')
    """
    df = validate_dataframe(df)

    if method == "random":
        if stratify_by:
            # Stratified sampling
            if stratify_by not in df.columns:
                raise ValueError(f"Stratify column '{stratify_by}' not found")

            if frac is not None:
                sample = df.groupby(stratify_by, group_keys=False).apply(
                    lambda x: x.sample(frac=frac, random_state=random_state)
                )
            elif n is not None:
                # Proportional stratified sampling
                sample = df.groupby(stratify_by, group_keys=False).apply(
                    lambda x: x.sample(
                        n=min(len(x), int(n * len(x) / len(df))), random_state=random_state
                    )
                )
            else:
                raise ValueError("Must specify either 'n' or 'frac'")

            logger.info(f"Stratified sample by '{stratify_by}': {len(sample)} rows")
        else:
            # Simple random sampling
            sample = df.sample(n=n, frac=frac, random_state=random_state)
            logger.info(f"Random sample: {len(sample)} rows")

    elif method == "first":
        if n is not None:
            sample = df.head(n)
        elif frac is not None:
            sample = df.head(int(len(df) * frac))
        else:
            raise ValueError("Must specify either 'n' or 'frac'")
        logger.info(f"First {len(sample)} rows sampled")

    elif method == "last":
        if n is not None:
            sample = df.tail(n)
        elif frac is not None:
            sample = df.tail(int(len(df) * frac))
        else:
            raise ValueError("Must specify either 'n' or 'frac'")
        logger.info(f"Last {len(sample)} rows sampled")

    else:
        raise ValueError(f"Unknown sampling method: {method}")

    return sample


def create_train_test_split(
    df: pd.DataFrame,
    test_size: float = 0.2,
    stratify_by: Optional[str] = None,
    random_state: int = 42,
) -> tuple:
    """
    Split DataFrame into train and test sets.

    Args:
        df: Input DataFrame
        test_size: Fraction for test set (0.0 to 1.0)
        stratify_by: Column for stratified split
        random_state: Random seed

    Returns:
        Tuple of (train_df, test_df)

    Examples:
        >>> train, test = create_train_test_split(df, test_size=0.2)
        >>> print(f"Train: {len(train)}, Test: {len(test)}")
    """
    df = validate_dataframe(df)

    if stratify_by:
        test = sample_data(df, frac=test_size, stratify_by=stratify_by, random_state=random_state)
        train = df.drop(test.index)
    else:
        test = sample_data(df, frac=test_size, random_state=random_state)
        train = df.drop(test.index)

    logger.info(
        f"Created train/test split: {len(train)}/{len(test)} ({(1-test_size)*100:.0f}%/{test_size*100:.0f}%)"
    )
    return train, test

"""
Schema validation functionality for DataWrangle.
"""

import pandas as pd
import re
from typing import Dict, Any, List, Union
from datetime import datetime
from datawrangle.utils import validate_dataframe, get_python_type, logger


def validate_schema(
    df: pd.DataFrame, schema_dict: Dict[str, Dict[str, Any]], strict: bool = True
) -> Dict[str, Any]:
    r"""
    Validates DataFrame against user-defined schema.

    Args:
        df: Input DataFrame to validate
        schema_dict: Schema definition with column specifications:
            {
                'column_name': {
                    'type': int/str/float/'datetime'/etc,
                    'constraints': {
                        'non_null': bool,
                        'positive': bool,
                        'negative': bool,
                        'min': value,
                        'max': value,
                        'min_length': int,
                        'max_length': int,
                        'regex': pattern,
                        'min_date': date_string,
                        'max_date': date_string,
                        'values': list of allowed values
                    }
                }
            }
        strict: If True, enforce exact schema (no extra columns allowed)

    Returns:
        Validation report dict with 'status' and 'errors' keys

    Examples:
        >>> schema = {
        ...     'id': {'type': int, 'constraints': {'non_null': True, 'positive': True}},
        ...     'name': {'type': str, 'constraints': {'regex': r'^[A-Za-z\s]+$'}},
        ...     'date': {'type': 'datetime', 'constraints': {'min_date': '2020-01-01'}}
        ... }
        >>> report = validate_schema(df, schema, strict=False)
        >>> print(report)
    """
    df = validate_dataframe(df)
    errors = []
    warnings = []

    # Check for missing columns
    required_columns = set(schema_dict.keys())
    actual_columns = set(df.columns)

    missing_columns = required_columns - actual_columns
    if missing_columns:
        errors.append(f"Missing required columns: {list(missing_columns)}")

    # Check for extra columns in strict mode
    if strict:
        extra_columns = actual_columns - required_columns
        if extra_columns:
            errors.append(f"Extra columns not in schema (strict mode): {list(extra_columns)}")

    # Validate each column
    for column, specs in schema_dict.items():
        if column not in df.columns:
            continue  # Already reported as missing

        # Validate type
        expected_type = specs.get("type")
        if expected_type:
            type_errors = _validate_type(df[column], column, expected_type)
            errors.extend(type_errors)

        # Validate constraints
        constraints = specs.get("constraints", {})
        if constraints:
            constraint_errors = _validate_constraints(df[column], column, constraints)
            errors.extend(constraint_errors)

    # Determine status
    status = "pass" if not errors else "fail"

    report = {
        "status": status,
        "errors": errors,
        "warnings": warnings,
        "columns_validated": len(schema_dict),
        "rows_validated": len(df),
    }

    if status == "pass":
        logger.info("Schema validation passed")
    else:
        logger.warning(f"Schema validation failed with {len(errors)} error(s)")

    return report


def _validate_type(series: pd.Series, column: str, expected_type: Union[type, str]) -> List[str]:
    """Validate column data type."""
    errors = []

    try:
        # Get actual type
        actual_type = get_python_type(series.dtype)

        # Normalize expected type
        if expected_type == "datetime":
            if not pd.api.types.is_datetime64_any_dtype(series):
                errors.append(f"Column '{column}': Expected datetime, got {actual_type}")
        elif expected_type in [int, "int", "integer"]:
            if not pd.api.types.is_integer_dtype(series):
                errors.append(f"Column '{column}': Expected int, got {actual_type}")
        elif expected_type in [float, "float", "double"]:
            if not pd.api.types.is_float_dtype(series):
                errors.append(f"Column '{column}': Expected float, got {actual_type}")
        elif expected_type in [str, "str", "string"]:
            if not (pd.api.types.is_string_dtype(series) or pd.api.types.is_object_dtype(series)):
                errors.append(f"Column '{column}': Expected str, got {actual_type}")
        elif expected_type in [bool, "bool", "boolean"]:
            if not pd.api.types.is_bool_dtype(series):
                errors.append(f"Column '{column}': Expected bool, got {actual_type}")
    except Exception as e:
        errors.append(f"Column '{column}': Error validating type - {str(e)}")

    return errors


def _validate_constraints(series: pd.Series, column: str, constraints: Dict[str, Any]) -> List[str]:
    """Validate column constraints."""
    errors = []

    # Non-null constraint
    if constraints.get("non_null", False):
        null_count = series.isna().sum()
        if null_count > 0:
            errors.append(f"Column '{column}': Found {null_count} null value(s), expected non-null")

    # Positive constraint
    if constraints.get("positive", False):
        if pd.api.types.is_numeric_dtype(series):
            negative_count = (series < 0).sum()
            if negative_count > 0:
                errors.append(
                    f"Column '{column}': Found {negative_count} negative value(s), expected positive"
                )

    # Negative constraint
    if constraints.get("negative", False):
        if pd.api.types.is_numeric_dtype(series):
            positive_count = (series > 0).sum()
            if positive_count > 0:
                errors.append(
                    f"Column '{column}': Found {positive_count} positive value(s), expected negative"
                )

    # Min value constraint
    if "min" in constraints:
        min_val = constraints["min"]
        if pd.api.types.is_numeric_dtype(series):
            below_min = (series < min_val).sum()
            if below_min > 0:
                errors.append(
                    f"Column '{column}': Found {below_min} value(s) below minimum {min_val}"
                )

    # Max value constraint
    if "max" in constraints:
        max_val = constraints["max"]
        if pd.api.types.is_numeric_dtype(series):
            above_max = (series > max_val).sum()
            if above_max > 0:
                errors.append(
                    f"Column '{column}': Found {above_max} value(s) above maximum {max_val}"
                )

    # Min length constraint
    if "min_length" in constraints:
        min_length = constraints["min_length"]
        if pd.api.types.is_string_dtype(series) or pd.api.types.is_object_dtype(series):
            short_strings = (series.str.len() < min_length).sum()
            if short_strings > 0:
                errors.append(
                    f"Column '{column}': Found {short_strings} value(s) shorter than {min_length}"
                )

    # Max length constraint
    if "max_length" in constraints:
        max_length = constraints["max_length"]
        if pd.api.types.is_string_dtype(series) or pd.api.types.is_object_dtype(series):
            long_strings = (series.str.len() > max_length).sum()
            if long_strings > 0:
                errors.append(
                    f"Column '{column}': Found {long_strings} value(s) longer than {max_length}"
                )

    # Regex pattern constraint
    if "regex" in constraints:
        pattern = constraints["regex"]
        if pd.api.types.is_string_dtype(series) or pd.api.types.is_object_dtype(series):
            try:
                non_matching = (~series.str.match(pattern, na=False)).sum()
                if non_matching > 0:
                    errors.append(
                        f"Column '{column}': Found {non_matching} value(s) not matching regex pattern"
                    )
            except Exception as e:
                errors.append(f"Column '{column}': Error validating regex - {str(e)}")

    # Min date constraint
    if "min_date" in constraints:
        min_date = pd.to_datetime(constraints["min_date"])
        if pd.api.types.is_datetime64_any_dtype(series):
            before_min = (series < min_date).sum()
            if before_min > 0:
                errors.append(f"Column '{column}': Found {before_min} date(s) before {min_date}")

    # Max date constraint
    if "max_date" in constraints:
        max_date = pd.to_datetime(constraints["max_date"])
        if pd.api.types.is_datetime64_any_dtype(series):
            after_max = (series > max_date).sum()
            if after_max > 0:
                errors.append(f"Column '{column}': Found {after_max} date(s) after {max_date}")

    # Allowed values constraint
    if "values" in constraints:
        allowed_values = constraints["values"]
        invalid_count = (~series.isin(allowed_values + [None, pd.NA])).sum()
        if invalid_count > 0:
            errors.append(f"Column '{column}': Found {invalid_count} value(s) not in allowed list")

    return errors

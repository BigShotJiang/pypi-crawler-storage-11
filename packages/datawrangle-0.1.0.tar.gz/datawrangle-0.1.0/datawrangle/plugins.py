"""
Plugin system for extensible data cleaning and validation.
"""

import pandas as pd
from typing import Callable, Dict
from datawrangle.utils import logger


# Global registry for custom cleaners and validators
_custom_cleaners: Dict[str, Callable] = {}
_custom_validators: Dict[str, Callable] = {}


def register_cleaner(func: Callable = None, *, name: str = None):
    """
    Decorator to register custom cleaning functions.

    Args:
        func: Cleaning function that takes a DataFrame or Series and returns cleaned data
        name: Optional custom name for the cleaner (defaults to function name)

    Returns:
        Decorated function

    Examples:
        >>> @register_cleaner
        ... def custom_date_cleaner(series):
        ...     return series.str.replace(r'\\d{2}-\\d{2}-\\d{4}', r'\\d{4}-\\d{2}-\\d{2}', regex=True)

        >>> @register_cleaner(name='my_custom_cleaner')
        ... def my_cleaner(df):
        ...     return df.dropna()
    """

    def decorator(f: Callable) -> Callable:
        cleaner_name = name if name else f.__name__
        _custom_cleaners[cleaner_name] = f
        logger.info(f"Registered custom cleaner: {cleaner_name}")
        return f

    # Support both @register_cleaner and @register_cleaner()
    if func is None:
        return decorator
    else:
        return decorator(func)


def register_validator(func: Callable = None, *, name: str = None):
    """
    Decorator to register custom validation functions.

    Args:
        func: Validation function that takes a DataFrame/Series and returns validation result
        name: Optional custom name for the validator (defaults to function name)

    Returns:
        Decorated function

    Examples:
        >>> @register_validator
        ... def validate_email_format(series):
        ...     pattern = r'^[\\w\\.-]+@[\\w\\.-]+\\.\\w+$'
        ...     return series.str.match(pattern, na=False).all()

        >>> @register_validator(name='custom_validator')
        ... def my_validator(df):
        ...     return len(df) > 0
    """

    def decorator(f: Callable) -> Callable:
        validator_name = name if name else f.__name__
        _custom_validators[validator_name] = f
        logger.info(f"Registered custom validator: {validator_name}")
        return f

    # Support both @register_validator and @register_validator()
    if func is None:
        return decorator
    else:
        return decorator(func)


def get_custom_cleaners() -> Dict[str, Callable]:
    """Get dictionary of all registered custom cleaners."""
    return _custom_cleaners.copy()


def get_custom_validators() -> Dict[str, Callable]:
    """Get dictionary of all registered custom validators."""
    return _custom_validators.copy()


def unregister_cleaner(name: str) -> bool:
    """
    Unregister a custom cleaner.

    Args:
        name: Name of the cleaner to unregister

    Returns:
        True if successful, False if cleaner not found
    """
    if name in _custom_cleaners:
        del _custom_cleaners[name]
        logger.info(f"Unregistered cleaner: {name}")
        return True
    else:
        logger.warning(f"Cleaner '{name}' not found in registry")
        return False


def unregister_validator(name: str) -> bool:
    """
    Unregister a custom validator.

    Args:
        name: Name of the validator to unregister

    Returns:
        True if successful, False if validator not found
    """
    if name in _custom_validators:
        del _custom_validators[name]
        logger.info(f"Unregistered validator: {name}")
        return True
    else:
        logger.warning(f"Validator '{name}' not found in registry")
        return False


def list_cleaners() -> list:
    """List all registered custom cleaners."""
    return list(_custom_cleaners.keys())


def list_validators() -> list:
    """List all registered custom validators."""
    return list(_custom_validators.keys())


def clear_all_cleaners():
    """Clear all registered cleaners."""
    _custom_cleaners.clear()
    logger.info("Cleared all custom cleaners")


def clear_all_validators():
    """Clear all registered validators."""
    _custom_validators.clear()
    logger.info("Cleared all custom validators")

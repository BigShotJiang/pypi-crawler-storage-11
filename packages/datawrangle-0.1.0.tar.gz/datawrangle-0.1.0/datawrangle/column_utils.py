"""
Column utility functions for DataWrangle.
Must-have utilities for data engineers working with column names and structures.
"""

import pandas as pd
import re
from typing import List, Optional, Dict, Any
from datawrangle.utils import validate_dataframe, logger


def standardize_column_names(
    df: pd.DataFrame, style: str = "snake_case", remove_special: bool = True
) -> pd.DataFrame:
    """
    Standardize column names to a consistent format.

    Args:
        df: Input DataFrame
        style: Naming convention ('snake_case', 'camel_case', 'lower', 'upper')
        remove_special: Remove special characters from column names

    Returns:
        DataFrame with standardized column names

    Examples:
        >>> df = standardize_column_names(df, style='snake_case')
        >>> # 'User Name' -> 'user_name', 'Customer-ID' -> 'customer_id'
    """
    df = validate_dataframe(df)
    df = df.copy()

    new_columns = []
    for col in df.columns:
        new_col = col

        # Remove special characters
        if remove_special:
            new_col = re.sub(r"[^\w\s]", "", new_col)

        # Apply style
        if style == "snake_case":
            new_col = re.sub(r"\s+", "_", new_col.strip())
            new_col = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", new_col)
            new_col = new_col.lower()
        elif style == "camel_case":
            words = re.split(r"[\s_]+", new_col.strip())
            new_col = words[0].lower() + "".join(w.capitalize() for w in words[1:])
        elif style == "lower":
            new_col = new_col.lower().strip()
        elif style == "upper":
            new_col = new_col.upper().strip()

        new_columns.append(new_col)

    df.columns = new_columns
    logger.info(f"Standardized column names to {style}")
    return df


def drop_columns_with_nulls(df: pd.DataFrame, threshold: float = 0.5) -> pd.DataFrame:
    """
    Drop columns that have more than threshold percentage of null values.

    Args:
        df: Input DataFrame
        threshold: Null percentage threshold (0.0 to 1.0). Drop if > threshold

    Returns:
        DataFrame with high-null columns removed

    Examples:
        >>> df = drop_columns_with_nulls(df, threshold=0.5)
        >>> # Drops columns with >50% null values
    """
    df = validate_dataframe(df)
    df = df.copy()

    cols_to_drop = []
    for col in df.columns:
        null_pct = df[col].isna().sum() / len(df)
        if null_pct > threshold:
            cols_to_drop.append(col)

    if cols_to_drop:
        df = df.drop(columns=cols_to_drop)
        logger.info(
            f"Dropped {len(cols_to_drop)} columns with >{threshold*100}% nulls: {cols_to_drop}"
        )

    return df


def reorder_columns(
    df: pd.DataFrame, order: List[str], keep_remaining: bool = True
) -> pd.DataFrame:
    """
    Reorder columns in DataFrame.

    Args:
        df: Input DataFrame
        order: List of column names in desired order
        keep_remaining: If True, append remaining columns at the end

    Returns:
        DataFrame with reordered columns

    Examples:
        >>> df = reorder_columns(df, ['id', 'name', 'email'])
    """
    df = validate_dataframe(df)

    # Verify columns exist
    missing = [col for col in order if col not in df.columns]
    if missing:
        logger.warning(f"Columns not found in DataFrame: {missing}")
        order = [col for col in order if col in df.columns]

    if keep_remaining:
        remaining = [col for col in df.columns if col not in order]
        final_order = order + remaining
    else:
        final_order = order

    logger.info(f"Reordered columns")
    return df[final_order]


def split_column(
    df: pd.DataFrame, column: str, delimiter: str = ",", new_names: Optional[List[str]] = None
) -> pd.DataFrame:
    """
    Split a column into multiple columns.

    Args:
        df: Input DataFrame
        column: Column name to split
        delimiter: Delimiter to split on
        new_names: Names for new columns (default: column_0, column_1, ...)

    Returns:
        DataFrame with split columns

    Examples:
        >>> df = split_column(df, 'full_name', delimiter=' ', new_names=['first_name', 'last_name'])
    """
    df = validate_dataframe(df)
    df = df.copy()

    if column not in df.columns:
        raise ValueError(f"Column '{column}' not found in DataFrame")

    # Split the column
    split_data = df[column].str.split(delimiter, expand=True)

    # Generate column names
    if new_names is None:
        new_names = [f"{column}_{i}" for i in range(split_data.shape[1])]

    # Add split columns
    for i, name in enumerate(new_names):
        if i < split_data.shape[1]:
            df[name] = split_data[i]

    logger.info(f"Split column '{column}' into {len(new_names)} columns")
    return df


def combine_columns(
    df: pd.DataFrame,
    columns: List[str],
    new_column: str,
    separator: str = " ",
    drop_original: bool = False,
) -> pd.DataFrame:
    """
    Combine multiple columns into one.

    Args:
        df: Input DataFrame
        columns: List of column names to combine
        new_column: Name of the new combined column
        separator: Separator between values
        drop_original: Drop original columns after combining

    Returns:
        DataFrame with combined column

    Examples:
        >>> df = combine_columns(df, ['first_name', 'last_name'], 'full_name', separator=' ')
    """
    df = validate_dataframe(df)
    df = df.copy()

    # Verify columns exist
    missing = [col for col in columns if col not in df.columns]
    if missing:
        raise ValueError(f"Columns not found: {missing}")

    # Combine columns
    df[new_column] = df[columns].astype(str).agg(separator.join, axis=1)

    if drop_original:
        df = df.drop(columns=columns)

    logger.info(f"Combined {len(columns)} columns into '{new_column}'")
    return df

"""
Core chainable DataFrame wrapper for DataWrangle.
"""

import pandas as pd
from typing import Dict, Any, Optional, List, Literal
from datawrangle.cleaner import clean_dataframe
from datawrangle.validator import validate_schema
from datawrangle.text_normalizer import normalize_text
from datawrangle.profiler import profile_data


class DataWrangleFrame:
    """
    Chainable wrapper around pandas DataFrame for data cleaning operations.

    This class provides a fluent interface for chaining data cleaning,
    validation, and profiling operations.

    Examples:
        >>> dwf = DataWrangleFrame(df)
        >>> result = (dwf
        ...     .clean({'drop_duplicates': True})
        ...     .normalize_text('email', {'lowercase': True})
        ...     .validate(schema)
        ...     .get_dataframe())
    """

    def __init__(self, df: pd.DataFrame):
        """
        Initialize DataWrangleFrame.

        Args:
            df: Input pandas DataFrame
        """
        if not isinstance(df, pd.DataFrame):
            raise TypeError(f"Expected pandas DataFrame, got {type(df).__name__}")
        self._df = df.copy()
        self._validation_report = None

    def clean(
        self, config: Optional[Dict[str, Any]] = None, custom_cleaners: Optional[List[str]] = None
    ) -> "DataWrangleFrame":
        """
        Apply cleaning operations to the DataFrame.

        Args:
            config: Cleaning configuration dictionary
            custom_cleaners: List of custom cleaner function names

        Returns:
            Self for method chaining
        """
        self._df = clean_dataframe(self._df, config, custom_cleaners)
        return self

    def validate(
        self, schema_dict: Dict[str, Dict[str, Any]], strict: bool = True
    ) -> "DataWrangleFrame":
        """
        Validate DataFrame against schema.

        Args:
            schema_dict: Schema definition
            strict: Whether to enforce strict validation

        Returns:
            Self for method chaining
        """
        self._validation_report = validate_schema(self._df, schema_dict, strict)
        return self

    def normalize_text(
        self, column: str, config: Optional[Dict[str, Any]] = None
    ) -> "DataWrangleFrame":
        """
        Normalize text in a specific column.

        Args:
            column: Column name to normalize
            config: Text normalization configuration

        Returns:
            Self for method chaining
        """
        self._df = normalize_text(self._df, column, config)
        return self

    def profile(self, output: Literal["summary", "json", "html", "markdown"] = "summary") -> Any:
        """
        Generate data profile and return it (terminates chain).

        Args:
            output: Output format

        Returns:
            Data profile in specified format
        """
        return profile_data(self._df, output)

    def get_dataframe(self) -> pd.DataFrame:
        """
        Get the underlying pandas DataFrame.

        Returns:
            The wrapped DataFrame
        """
        return self._df.copy()

    def get_validation_report(self) -> Optional[Dict[str, Any]]:
        """
        Get the last validation report.

        Returns:
            Validation report dict or None if not validated
        """
        return self._validation_report

    def drop_duplicates(
        self, subset: Optional[List[str]] = None, keep: str = "first"
    ) -> "DataWrangleFrame":
        """
        Drop duplicate rows.

        Args:
            subset: Column names to consider for identifying duplicates
            keep: Which duplicates to keep ('first', 'last', False)

        Returns:
            Self for method chaining
        """
        self._df = self._df.drop_duplicates(subset=subset, keep=keep)
        return self

    def fill_missing(self, config: Dict[str, Any]) -> "DataWrangleFrame":
        """
        Fill missing values.

        Args:
            config: Dictionary mapping column names to fill strategies

        Returns:
            Self for method chaining
        """
        return self.clean({"fill_missing": config})

    def convert_types(self, config: Dict[str, str]) -> "DataWrangleFrame":
        """
        Convert column types.

        Args:
            config: Dictionary mapping column names to target types

        Returns:
            Self for method chaining
        """
        return self.clean({"convert_types": config})

    def remove_outliers(
        self, column: str, method: str = "iqr", threshold: float = 3
    ) -> "DataWrangleFrame":
        """
        Remove outliers from a column.

        Args:
            column: Column name
            method: Outlier detection method ('iqr' or 'zscore')
            threshold: Threshold for z-score method

        Returns:
            Self for method chaining
        """
        config = {"remove_outliers": {"column": column, "method": method, "threshold": threshold}}
        return self.clean(config)

    def __repr__(self) -> str:
        """String representation."""
        return f"DataWrangleFrame(shape={self._df.shape}, columns={list(self._df.columns)})"

    def __len__(self) -> int:
        """Length of DataFrame."""
        return len(self._df)

    @property
    def shape(self):
        """Shape of DataFrame."""
        return self._df.shape

    @property
    def columns(self):
        """Column names."""
        return self._df.columns

    @property
    def dtypes(self):
        """Column data types."""
        return self._df.dtypes

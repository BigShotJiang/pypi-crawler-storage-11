"""
Data profiling functionality for DataWrangle.
"""

import pandas as pd
import json
from typing import Dict, Any, Literal
from datawrangle.utils import (
    validate_dataframe,
    get_numeric_columns,
    get_categorical_columns,
    calculate_missing_percentage,
    logger,
)


def profile_data(
    df: pd.DataFrame, output: Literal["summary", "json", "html", "markdown"] = "summary"
) -> Any:
    """
    Generate a comprehensive data quality summary.

    Args:
        df: Input DataFrame to profile
        output: Output format ('summary', 'json', 'html', 'markdown')

    Returns:
        Data profile in the specified format:
        - 'summary': dict with profile information
        - 'json': JSON string
        - 'html': HTML formatted string
        - 'markdown': Markdown formatted string

    Examples:
        >>> summary = profile_data(df, output='json')
        >>> print(summary)
    """
    df = validate_dataframe(df)

    # Generate profile data
    profile = {
        "overview": _get_overview(df),
        "missing_values": _get_missing_values(df),
        "duplicates": _get_duplicate_info(df),
        "numeric_stats": _get_numeric_stats(df),
        "categorical_stats": _get_categorical_stats(df),
        "column_types": _get_column_types(df),
    }

    # Format output
    if output == "json":
        return json.dumps(profile, indent=2, default=str)
    elif output == "html":
        return _format_html(profile)
    elif output == "markdown":
        return _format_markdown(profile)
    else:
        return profile


def _get_overview(df: pd.DataFrame) -> Dict[str, Any]:
    """Get basic overview of the DataFrame."""
    return {
        "total_rows": len(df),
        "total_columns": len(df.columns),
        "memory_usage_mb": round(df.memory_usage(deep=True).sum() / 1024**2, 2),
        "duplicate_rows": df.duplicated().sum(),
        "duplicate_percentage": (
            round(df.duplicated().sum() / len(df) * 100, 2) if len(df) > 0 else 0
        ),
    }


def _get_missing_values(df: pd.DataFrame) -> Dict[str, float]:
    """Get missing value statistics for each column."""
    missing = {}
    for col in df.columns:
        missing_pct = calculate_missing_percentage(df[col])
        if missing_pct > 0:
            missing[col] = missing_pct
    return missing


def _get_duplicate_info(df: pd.DataFrame) -> Dict[str, int]:
    """Get duplicate row information."""
    return {
        "total_duplicates": int(df.duplicated().sum()),
        "unique_rows": int(len(df) - df.duplicated().sum()),
    }


def _get_numeric_stats(df: pd.DataFrame) -> Dict[str, Dict[str, float]]:
    """Get statistics for numeric columns."""
    numeric_cols = get_numeric_columns(df)
    stats = {}

    for col in numeric_cols:
        stats[col] = {
            "mean": round(df[col].mean(), 2) if not df[col].isna().all() else None,
            "median": round(df[col].median(), 2) if not df[col].isna().all() else None,
            "std": round(df[col].std(), 2) if not df[col].isna().all() else None,
            "min": round(df[col].min(), 2) if not df[col].isna().all() else None,
            "max": round(df[col].max(), 2) if not df[col].isna().all() else None,
            "q1": round(df[col].quantile(0.25), 2) if not df[col].isna().all() else None,
            "q3": round(df[col].quantile(0.75), 2) if not df[col].isna().all() else None,
        }

    return stats


def _get_categorical_stats(df: pd.DataFrame) -> Dict[str, Dict[str, Any]]:
    """Get statistics for categorical columns."""
    categorical_cols = get_categorical_columns(df)
    stats = {}

    for col in categorical_cols:
        unique_count = df[col].nunique()
        mode_value = df[col].mode()

        stats[col] = {
            "unique_count": int(unique_count),
            "most_common": str(mode_value[0]) if not mode_value.empty else None,
            "most_common_count": (
                int(df[col].value_counts().iloc[0]) if len(df[col].value_counts()) > 0 else 0
            ),
            "top_5_values": df[col].value_counts().head(5).to_dict() if unique_count > 0 else {},
        }

    return stats


def _get_column_types(df: pd.DataFrame) -> Dict[str, str]:
    """Get data type for each column."""
    return {col: str(dtype) for col, dtype in df.dtypes.items()}


def _format_html(profile: Dict[str, Any]) -> str:
    """Format profile data as HTML."""
    html = """
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { color: #2c3e50; }
            h2 { color: #34495e; margin-top: 30px; }
            table { border-collapse: collapse; width: 100%; margin-top: 10px; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
            th { background-color: #3498db; color: white; }
            tr:nth-child(even) { background-color: #f2f2f2; }
            .metric { display: inline-block; margin: 10px; padding: 15px; background: #ecf0f1; border-radius: 5px; }
            .metric-value { font-size: 24px; font-weight: bold; color: #2980b9; }
            .metric-label { font-size: 14px; color: #7f8c8d; }
        </style>
    </head>
    <body>
        <h1>Data Quality Report</h1>
    """

    # Overview
    html += "<h2>Overview</h2>"
    for key, value in profile["overview"].items():
        html += f'<div class="metric"><div class="metric-value">{value}</div><div class="metric-label">{key.replace("_", " ").title()}</div></div>'

    # Missing Values
    if profile["missing_values"]:
        html += "<h2>Missing Values</h2><table><tr><th>Column</th><th>Missing %</th></tr>"
        for col, pct in profile["missing_values"].items():
            html += f"<tr><td>{col}</td><td>{pct}%</td></tr>"
        html += "</table>"

    # Numeric Stats
    if profile["numeric_stats"]:
        html += "<h2>Numeric Statistics</h2><table><tr><th>Column</th><th>Mean</th><th>Median</th><th>Std</th><th>Min</th><th>Max</th></tr>"
        for col, stats in profile["numeric_stats"].items():
            html += f"<tr><td>{col}</td><td>{stats['mean']}</td><td>{stats['median']}</td><td>{stats['std']}</td><td>{stats['min']}</td><td>{stats['max']}</td></tr>"
        html += "</table>"

    html += "</body></html>"
    return html


def _format_markdown(profile: Dict[str, Any]) -> str:
    """Format profile data as Markdown."""
    md = "# Data Quality Report\n\n"

    # Overview
    md += "## Overview\n\n"
    for key, value in profile["overview"].items():
        md += f"- **{key.replace('_', ' ').title()}**: {value}\n"
    md += "\n"

    # Missing Values
    if profile["missing_values"]:
        md += "## Missing Values\n\n"
        md += "| Column | Missing % |\n"
        md += "|--------|----------|\n"
        for col, pct in profile["missing_values"].items():
            md += f"| {col} | {pct}% |\n"
        md += "\n"

    # Numeric Statistics
    if profile["numeric_stats"]:
        md += "## Numeric Statistics\n\n"
        md += "| Column | Mean | Median | Std | Min | Max |\n"
        md += "|--------|------|--------|-----|-----|-----|\n"
        for col, stats in profile["numeric_stats"].items():
            md += f"| {col} | {stats['mean']} | {stats['median']} | {stats['std']} | {stats['min']} | {stats['max']} |\n"
        md += "\n"

    # Categorical Statistics
    if profile["categorical_stats"]:
        md += "## Categorical Statistics\n\n"
        md += "| Column | Unique Count | Most Common |\n"
        md += "|--------|--------------|-------------|\n"
        for col, stats in profile["categorical_stats"].items():
            md += f"| {col} | {stats['unique_count']} | {stats['most_common']} ({stats['most_common_count']}) |\n"
        md += "\n"

    return md

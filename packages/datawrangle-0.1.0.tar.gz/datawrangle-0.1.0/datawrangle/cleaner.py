"""
Data cleaning functionality for DataWrangle.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, Optional, Union, List
from scipy import stats
from datawrangle.utils import validate_dataframe, convert_to_type, get_numeric_columns, logger
from datawrangle.plugins import get_custom_cleaners


def clean_dataframe(
    df: pd.DataFrame,
    config: Optional[Dict[str, Any]] = None,
    custom_cleaners: Optional[List[str]] = None,
) -> pd.DataFrame:
    """
    Central entry point for common cleaning tasks using a flexible configuration.

    Args:
        df: Input DataFrame to clean
        config: Configuration dictionary with cleaning operations:
            - drop_duplicates: bool or dict with 'subset' and 'keep' keys
            - fill_missing: dict mapping column names to fill strategies
            - convert_types: dict mapping column names to target types
            - remove_outliers: dict with 'column' and 'method' keys
            - drop_columns: list of column names to drop
            - rename_columns: dict mapping old names to new names
        custom_cleaners: List of registered custom cleaner function names

    Returns:
        Cleaned DataFrame

    Examples:
        >>> df = clean_dataframe(df, config={
        ...     'drop_duplicates': {'subset': ['id'], 'keep': 'first'},
        ...     'fill_missing': {'age': 'mean', 'name': 'Unknown'},
        ...     'convert_types': {'date': 'datetime', 'price': 'float'},
        ...     'remove_outliers': {'column': 'salary', 'method': 'iqr'}
        ... })
    """
    df = validate_dataframe(df)
    df = df.copy()  # Avoid modifying original DataFrame

    if config is None:
        config = {}

    # Drop duplicates
    if "drop_duplicates" in config:
        df = _drop_duplicates(df, config["drop_duplicates"])

    # Fill missing values
    if "fill_missing" in config:
        df = _fill_missing(df, config["fill_missing"])

    # Convert types
    if "convert_types" in config:
        df = _convert_types(df, config["convert_types"])

    # Remove outliers
    if "remove_outliers" in config:
        df = _remove_outliers(df, config["remove_outliers"])

    # Drop columns
    if "drop_columns" in config:
        df = _drop_columns(df, config["drop_columns"])

    # Rename columns
    if "rename_columns" in config:
        df = _rename_columns(df, config["rename_columns"])

    # Apply custom cleaners
    if custom_cleaners:
        df = _apply_custom_cleaners(df, custom_cleaners)

    logger.info("DataFrame cleaning completed successfully")
    return df


def _drop_duplicates(df: pd.DataFrame, config: Union[bool, Dict[str, Any]]) -> pd.DataFrame:
    """Drop duplicate rows from DataFrame."""
    try:
        if isinstance(config, bool) and config:
            df = df.drop_duplicates()
            logger.info(f"Dropped duplicates across all columns")
        elif isinstance(config, dict):
            subset = config.get("subset", None)
            keep = config.get("keep", "first")
            df = df.drop_duplicates(subset=subset, keep=keep)
            logger.info(f"Dropped duplicates on subset {subset}, keeping '{keep}'")
        return df
    except Exception as e:
        logger.error(f"Error dropping duplicates: {str(e)}")
        return df


def _fill_missing(df: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    """Fill missing values using various strategies."""
    for column, strategy in config.items():
        if column not in df.columns:
            logger.warning(f"Column '{column}' not found in DataFrame")
            continue

        try:
            if strategy == "mean":
                df[column] = df[column].fillna(df[column].mean())
            elif strategy == "median":
                df[column] = df[column].fillna(df[column].median())
            elif strategy == "mode":
                mode_value = df[column].mode()
                if not mode_value.empty:
                    df[column] = df[column].fillna(mode_value[0])
            elif strategy == "ffill":
                df[column] = df[column].fillna(method="ffill")
            elif strategy == "bfill":
                df[column] = df[column].fillna(method="bfill")
            else:
                # Custom value
                df[column] = df[column].fillna(strategy)

            logger.info(f"Filled missing values in '{column}' using strategy '{strategy}'")
        except Exception as e:
            logger.error(f"Error filling missing values in '{column}': {str(e)}")

    return df


def _convert_types(df: pd.DataFrame, config: Dict[str, str]) -> pd.DataFrame:
    """Convert column data types."""
    for column, target_type in config.items():
        if column not in df.columns:
            logger.warning(f"Column '{column}' not found in DataFrame")
            continue

        try:
            df[column] = convert_to_type(df[column], target_type)
            logger.info(f"Converted '{column}' to type '{target_type}'")
        except Exception as e:
            logger.error(f"Error converting '{column}' to '{target_type}': {str(e)}")

    return df


def _remove_outliers(df: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    """Remove outliers using z-score or IQR method."""
    column = config.get("column")
    method = config.get("method", "iqr").lower()
    threshold = config.get("threshold", 3)  # For z-score

    if column not in df.columns:
        logger.warning(f"Column '{column}' not found in DataFrame")
        return df

    try:
        initial_rows = len(df)

        if method == "zscore":
            z_scores = np.abs(stats.zscore(df[column].dropna()))
            df = df[(z_scores < threshold) | df[column].isna()]
        elif method == "iqr":
            Q1 = df[column].quantile(0.25)
            Q3 = df[column].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            df = df[(df[column] >= lower_bound) & (df[column] <= upper_bound) | df[column].isna()]
        else:
            logger.warning(f"Unknown outlier removal method: {method}")
            return df

        removed_rows = initial_rows - len(df)
        logger.info(f"Removed {removed_rows} outliers from '{column}' using {method} method")
        return df
    except Exception as e:
        logger.error(f"Error removing outliers: {str(e)}")
        return df


def _drop_columns(df: pd.DataFrame, columns: List[str]) -> pd.DataFrame:
    """Drop specified columns from DataFrame."""
    try:
        existing_columns = [col for col in columns if col in df.columns]
        df = df.drop(columns=existing_columns)
        logger.info(f"Dropped columns: {existing_columns}")
        return df
    except Exception as e:
        logger.error(f"Error dropping columns: {str(e)}")
        return df


def _rename_columns(df: pd.DataFrame, mapping: Dict[str, str]) -> pd.DataFrame:
    """Rename columns based on mapping."""
    try:
        df = df.rename(columns=mapping)
        logger.info(f"Renamed columns: {mapping}")
        return df
    except Exception as e:
        logger.error(f"Error renaming columns: {str(e)}")
        return df


def _apply_custom_cleaners(df: pd.DataFrame, cleaner_names: List[str]) -> pd.DataFrame:
    """Apply custom registered cleaner functions."""
    custom_cleaners = get_custom_cleaners()

    for name in cleaner_names:
        if name in custom_cleaners:
            try:
                cleaner_func = custom_cleaners[name]
                df = cleaner_func(df)
                logger.info(f"Applied custom cleaner: {name}")
            except Exception as e:
                logger.error(f"Error applying custom cleaner '{name}': {str(e)}")
        else:
            logger.warning(f"Custom cleaner '{name}' not found")

    return df

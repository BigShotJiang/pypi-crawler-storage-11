"""
Data comparison utilities for DataWrangle.
Essential comparison functions for data engineers.
"""

import pandas as pd
from typing import Dict, Any, List, Optional
from datawrangle.utils import validate_dataframe, logger


def compare_dataframes(
    df1: pd.DataFrame, df2: pd.DataFrame, join_on: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Compare two DataFrames and report differences.

    Args:
        df1: First DataFrame
        df2: Second DataFrame
        join_on: Column names to join on (for row-level comparison)

    Returns:
        Dictionary with comparison results

    Examples:
        >>> diff = compare_dataframes(old_df, new_df, join_on=['id'])
        >>> print(diff['summary'])
    """
    df1 = validate_dataframe(df1)
    df2 = validate_dataframe(df2)

    comparison = {"summary": {}, "column_diff": {}, "row_diff": {}, "value_diff": {}}

    # Shape comparison
    comparison["summary"]["df1_shape"] = df1.shape
    comparison["summary"]["df2_shape"] = df2.shape
    comparison["summary"]["shape_match"] = df1.shape == df2.shape

    # Column comparison
    cols1 = set(df1.columns)
    cols2 = set(df2.columns)

    comparison["column_diff"]["only_in_df1"] = list(cols1 - cols2)
    comparison["column_diff"]["only_in_df2"] = list(cols2 - cols1)
    comparison["column_diff"]["common"] = list(cols1 & cols2)
    comparison["column_diff"]["columns_match"] = cols1 == cols2

    # Row comparison
    comparison["row_diff"]["df1_rows"] = len(df1)
    comparison["row_diff"]["df2_rows"] = len(df2)
    comparison["row_diff"]["row_diff"] = len(df2) - len(df1)

    # Value comparison (if columns match)
    if join_on and all(col in df1.columns and col in df2.columns for col in join_on):
        merged = df1.merge(df2, on=join_on, how="outer", indicator=True, suffixes=("_df1", "_df2"))

        comparison["value_diff"]["only_in_df1"] = (merged["_merge"] == "left_only").sum()
        comparison["value_diff"]["only_in_df2"] = (merged["_merge"] == "right_only").sum()
        comparison["value_diff"]["in_both"] = (merged["_merge"] == "both").sum()

    logger.info("DataFrame comparison completed")
    return comparison


def find_schema_drift(df_current: pd.DataFrame, df_expected: pd.DataFrame) -> Dict[str, Any]:
    """
    Detect schema drift between current and expected DataFrames.

    Args:
        df_current: Current DataFrame
        df_expected: Expected DataFrame (baseline)

    Returns:
        Dictionary with drift detection results

    Examples:
        >>> drift = find_schema_drift(current_data, baseline_data)
        >>> if drift['has_drift']:
        ...     print(f"Schema drift detected: {drift['changes']}")
    """
    df_current = validate_dataframe(df_current)
    df_expected = validate_dataframe(df_expected)

    drift = {
        "has_drift": False,
        "changes": [],
        "new_columns": [],
        "missing_columns": [],
        "type_changes": [],
    }

    # Check for new columns
    new_cols = set(df_current.columns) - set(df_expected.columns)
    if new_cols:
        drift["has_drift"] = True
        drift["new_columns"] = list(new_cols)
        drift["changes"].append(f"New columns: {list(new_cols)}")

    # Check for missing columns
    missing_cols = set(df_expected.columns) - set(df_current.columns)
    if missing_cols:
        drift["has_drift"] = True
        drift["missing_columns"] = list(missing_cols)
        drift["changes"].append(f"Missing columns: {list(missing_cols)}")

    # Check for type changes
    for col in set(df_current.columns) & set(df_expected.columns):
        if df_current[col].dtype != df_expected[col].dtype:
            drift["has_drift"] = True
            change = {
                "column": col,
                "expected": str(df_expected[col].dtype),
                "current": str(df_current[col].dtype),
            }
            drift["type_changes"].append(change)
            drift["changes"].append(
                f"Type change in '{col}': {change['expected']} → {change['current']}"
            )

    logger.info(f"Schema drift detection: {'Drift detected' if drift['has_drift'] else 'No drift'}")
    return drift

"""
Tests for data profiling functionality.
"""

import pytest
import pandas as pd
import numpy as np
import json
from datawrangle.profiler import profile_data


class TestProfiler:

    def test_profile_overview(self):
        """Test basic overview profiling."""
        df = pd.DataFrame({"a": [1, 2, 3, 3], "b": [4, 5, 6, 6]})

        profile = profile_data(df, output="summary")

        assert profile["overview"]["total_rows"] == 4
        assert profile["overview"]["total_columns"] == 2
        assert profile["overview"]["duplicate_rows"] == 1

    def test_missing_values_detection(self):
        """Test missing value detection."""
        df = pd.DataFrame({"a": [1, np.nan, 3], "b": [4, 5, np.nan]})

        profile = profile_data(df, output="summary")

        assert "a" in profile["missing_values"]
        assert "b" in profile["missing_values"]
        assert profile["missing_values"]["a"] > 0

    def test_numeric_statistics(self):
        """Test numeric statistics calculation."""
        df = pd.DataFrame({"score": [10, 20, 30, 40, 50]})

        profile = profile_data(df, output="summary")

        assert "score" in profile["numeric_stats"]
        assert profile["numeric_stats"]["score"]["mean"] == 30.0
        assert profile["numeric_stats"]["score"]["median"] == 30.0
        assert profile["numeric_stats"]["score"]["min"] == 10.0
        assert profile["numeric_stats"]["score"]["max"] == 50.0

    def test_categorical_statistics(self):
        """Test categorical statistics calculation."""
        df = pd.DataFrame({"category": ["A", "B", "A", "C", "A"]})

        profile = profile_data(df, output="summary")

        assert "category" in profile["categorical_stats"]
        assert profile["categorical_stats"]["category"]["unique_count"] == 3
        assert profile["categorical_stats"]["category"]["most_common"] == "A"
        assert profile["categorical_stats"]["category"]["most_common_count"] == 3

    def test_column_types(self):
        """Test column type detection."""
        df = pd.DataFrame(
            {"int_col": [1, 2, 3], "float_col": [1.1, 2.2, 3.3], "str_col": ["a", "b", "c"]}
        )

        profile = profile_data(df, output="summary")

        assert "int_col" in profile["column_types"]
        assert "float_col" in profile["column_types"]
        assert "str_col" in profile["column_types"]

    def test_json_output(self):
        """Test JSON output format."""
        df = pd.DataFrame({"a": [1, 2, 3]})

        result = profile_data(df, output="json")

        # Should be valid JSON
        parsed = json.loads(result)
        assert "overview" in parsed
        assert "numeric_stats" in parsed

    def test_markdown_output(self):
        """Test Markdown output format."""
        df = pd.DataFrame({"a": [1, 2, 3]})

        result = profile_data(df, output="markdown")

        assert isinstance(result, str)
        assert "# Data Quality Report" in result
        assert "## Overview" in result

    def test_html_output(self):
        """Test HTML output format."""
        df = pd.DataFrame({"a": [1, 2, 3]})

        result = profile_data(df, output="html")

        assert isinstance(result, str)
        assert "<html>" in result
        assert "<h1>Data Quality Report</h1>" in result

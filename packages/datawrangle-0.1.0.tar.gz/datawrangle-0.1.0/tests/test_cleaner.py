"""
Tests for data cleaning functionality.
"""

import pytest
import pandas as pd
import numpy as np
from datawrangle.cleaner import clean_dataframe


class TestCleaner:

    def test_drop_duplicates_all_columns(self):
        """Test dropping duplicates across all columns."""
        df = pd.DataFrame({"a": [1, 2, 2, 3], "b": [4, 5, 5, 6]})

        result = clean_dataframe(df, {"drop_duplicates": True})
        assert len(result) == 3

    def test_drop_duplicates_subset(self):
        """Test dropping duplicates on specific columns."""
        df = pd.DataFrame({"id": [1, 2, 2, 3], "value": [10, 20, 30, 40]})

        result = clean_dataframe(df, {"drop_duplicates": {"subset": ["id"], "keep": "first"}})
        assert len(result) == 3
        assert result["value"].tolist() == [10, 20, 40]

    def test_fill_missing_mean(self):
        """Test filling missing values with mean."""
        df = pd.DataFrame({"age": [25, 30, np.nan, 35]})

        result = clean_dataframe(df, {"fill_missing": {"age": "mean"}})
        assert result["age"].isna().sum() == 0
        assert result["age"].iloc[2] == 30.0

    def test_fill_missing_custom_value(self):
        """Test filling missing values with custom value."""
        df = pd.DataFrame({"name": ["Alice", np.nan, "Charlie"]})

        result = clean_dataframe(df, {"fill_missing": {"name": "Unknown"}})
        assert result["name"].iloc[1] == "Unknown"

    def test_convert_types(self):
        """Test type conversion."""
        df = pd.DataFrame({"id": ["1", "2", "3"], "price": ["10.5", "20.3", "15.0"]})

        result = clean_dataframe(df, {"convert_types": {"id": "int", "price": "float"}})
        assert pd.api.types.is_integer_dtype(result["id"])
        assert pd.api.types.is_float_dtype(result["price"])

    def test_remove_outliers_iqr(self):
        """Test outlier removal using IQR method."""
        df = pd.DataFrame({"value": [1, 2, 3, 4, 5, 100]})  # 100 is outlier

        result = clean_dataframe(df, {"remove_outliers": {"column": "value", "method": "iqr"}})
        assert 100 not in result["value"].values

    def test_drop_columns(self):
        """Test dropping columns."""
        df = pd.DataFrame({"keep": [1, 2, 3], "drop": [4, 5, 6]})

        result = clean_dataframe(df, {"drop_columns": ["drop"]})
        assert "drop" not in result.columns
        assert "keep" in result.columns

    def test_rename_columns(self):
        """Test renaming columns."""
        df = pd.DataFrame({"old_name": [1, 2, 3]})

        result = clean_dataframe(df, {"rename_columns": {"old_name": "new_name"}})
        assert "new_name" in result.columns
        assert "old_name" not in result.columns

    def test_multiple_operations(self):
        """Test combining multiple cleaning operations."""
        df = pd.DataFrame({"id": [1, 1, 2], "value": [10, np.nan, 20]})

        result = clean_dataframe(
            df,
            {
                "drop_duplicates": {"subset": ["id"], "keep": "first"},
                "fill_missing": {"value": "mean"},
            },
        )

        assert len(result) == 2
        assert result["value"].isna().sum() == 0

"""
Tests for core chainable DataFrame wrapper.
"""

import pytest
import pandas as pd
import numpy as np
from datawrangle.core import DataWrangleFrame


class TestDataWrangleFrame:

    def test_initialization(self):
        """Test DataWrangleFrame initialization."""
        df = pd.DataFrame({"a": [1, 2, 3]})
        dwf = DataWrangleFrame(df)

        assert dwf.shape == (3, 1)
        assert len(dwf) == 3

    def test_initialization_with_non_dataframe(self):
        """Test error when initializing with non-DataFrame."""
        with pytest.raises(TypeError):
            DataWrangleFrame([1, 2, 3])

    def test_clean_method(self):
        """Test clean method."""
        df = pd.DataFrame({"a": [1, 1, 2]})
        dwf = DataWrangleFrame(df)

        result = dwf.clean({"drop_duplicates": True})
        assert isinstance(result, DataWrangleFrame)
        assert len(result) == 2

    def test_validate_method(self):
        """Test validate method."""
        df = pd.DataFrame({"id": [1, 2, 3]})
        dwf = DataWrangleFrame(df)

        schema = {"id": {"type": int}}
        result = dwf.validate(schema)

        assert isinstance(result, DataWrangleFrame)
        report = result.get_validation_report()
        assert report["status"] == "pass"

    def test_normalize_text_method(self):
        """Test normalize_text method."""
        df = pd.DataFrame({"text": ["Hello", "WORLD"]})
        dwf = DataWrangleFrame(df)

        result = dwf.normalize_text("text", {"lowercase": True})
        assert isinstance(result, DataWrangleFrame)

        final_df = result.get_dataframe()
        assert final_df["text"].tolist() == ["hello", "world"]

    def test_method_chaining(self):
        """Test chaining multiple methods."""
        df = pd.DataFrame(
            {"id": [1, 1, 2], "value": [10, np.nan, 20], "text": ["Hello", "WORLD", "Test"]}
        )

        result = (
            DataWrangleFrame(df)
            .drop_duplicates(subset=["id"], keep="first")
            .fill_missing({"value": "mean"})
            .normalize_text("text", {"lowercase": True})
            .get_dataframe()
        )

        assert len(result) == 2
        assert result["value"].isna().sum() == 0
        assert result["text"].tolist() == ["hello", "test"]

    def test_profile_method(self):
        """Test profile method."""
        df = pd.DataFrame({"a": [1, 2, 3]})
        dwf = DataWrangleFrame(df)

        profile = dwf.profile(output="summary")
        assert "overview" in profile
        assert profile["overview"]["total_rows"] == 3

    def test_drop_duplicates_method(self):
        """Test drop_duplicates convenience method."""
        df = pd.DataFrame({"a": [1, 1, 2]})
        dwf = DataWrangleFrame(df)

        result = dwf.drop_duplicates()
        assert len(result) == 2

    def test_fill_missing_method(self):
        """Test fill_missing convenience method."""
        df = pd.DataFrame({"a": [1, np.nan, 3]})
        dwf = DataWrangleFrame(df)

        result = dwf.fill_missing({"a": "mean"})
        final_df = result.get_dataframe()
        assert final_df["a"].isna().sum() == 0

    def test_convert_types_method(self):
        """Test convert_types convenience method."""
        df = pd.DataFrame({"a": ["1", "2", "3"]})
        dwf = DataWrangleFrame(df)

        result = dwf.convert_types({"a": "int"})
        final_df = result.get_dataframe()
        assert pd.api.types.is_integer_dtype(final_df["a"])

    def test_remove_outliers_method(self):
        """Test remove_outliers convenience method."""
        df = pd.DataFrame({"value": [1, 2, 3, 4, 100]})
        dwf = DataWrangleFrame(df)

        result = dwf.remove_outliers("value", method="iqr")
        final_df = result.get_dataframe()
        assert 100 not in final_df["value"].values

    def test_repr(self):
        """Test string representation."""
        df = pd.DataFrame({"a": [1, 2, 3]})
        dwf = DataWrangleFrame(df)

        repr_str = repr(dwf)
        assert "DataWrangleFrame" in repr_str
        assert "shape" in repr_str

    def test_properties(self):
        """Test DataFrame properties."""
        df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
        dwf = DataWrangleFrame(df)

        assert dwf.shape == (3, 2)
        assert list(dwf.columns) == ["a", "b"]
        assert len(dwf.dtypes) == 2

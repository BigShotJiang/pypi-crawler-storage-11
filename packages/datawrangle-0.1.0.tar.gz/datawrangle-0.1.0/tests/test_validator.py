"""
Tests for schema validation functionality.
"""

import pytest
import pandas as pd
import numpy as np
from datawrangle.validator import validate_schema


class TestValidator:

    def test_valid_schema_passes(self):
        """Test that valid data passes schema validation."""
        df = pd.DataFrame({"id": [1, 2, 3], "name": ["Alice", "Bob", "Charlie"]})

        schema = {"id": {"type": int}, "name": {"type": str}}

        report = validate_schema(df, schema)
        assert report["status"] == "pass"
        assert len(report["errors"]) == 0

    def test_missing_column_fails(self):
        """Test that missing required column fails validation."""
        df = pd.DataFrame({"id": [1, 2, 3]})

        schema = {"id": {"type": int}, "name": {"type": str}}

        report = validate_schema(df, schema)
        assert report["status"] == "fail"
        assert any("Missing required columns" in err for err in report["errors"])

    def test_extra_column_strict_mode(self):
        """Test that extra columns fail in strict mode."""
        df = pd.DataFrame(
            {"id": [1, 2, 3], "name": ["Alice", "Bob", "Charlie"], "extra": ["x", "y", "z"]}
        )

        schema = {"id": {"type": int}, "name": {"type": str}}

        report = validate_schema(df, schema, strict=True)
        assert report["status"] == "fail"
        assert any("Extra columns" in err for err in report["errors"])

    def test_extra_column_non_strict_mode(self):
        """Test that extra columns are allowed in non-strict mode."""
        df = pd.DataFrame(
            {"id": [1, 2, 3], "name": ["Alice", "Bob", "Charlie"], "extra": ["x", "y", "z"]}
        )

        schema = {"id": {"type": int}, "name": {"type": str}}

        report = validate_schema(df, schema, strict=False)
        assert report["status"] == "pass"

    def test_non_null_constraint(self):
        """Test non-null constraint."""
        df = pd.DataFrame({"id": [1, np.nan, 3]})

        schema = {"id": {"type": int, "constraints": {"non_null": True}}}

        report = validate_schema(df, schema)
        assert report["status"] == "fail"
        assert any("null value" in err for err in report["errors"])

    def test_positive_constraint(self):
        """Test positive value constraint."""
        df = pd.DataFrame({"value": [1, -2, 3]})

        schema = {"value": {"type": int, "constraints": {"positive": True}}}

        report = validate_schema(df, schema)
        assert report["status"] == "fail"
        assert any("negative value" in err for err in report["errors"])

    def test_min_max_constraints(self):
        """Test min and max value constraints."""
        df = pd.DataFrame({"score": [50, 75, 120]})

        schema = {"score": {"type": int, "constraints": {"min": 0, "max": 100}}}

        report = validate_schema(df, schema)
        assert report["status"] == "fail"
        assert any("above maximum" in err for err in report["errors"])

    def test_regex_constraint(self):
        """Test regex pattern constraint."""
        df = pd.DataFrame({"email": ["test@example.com", "invalid-email", "another@test.com"]})

        schema = {"email": {"type": str, "constraints": {"regex": r"^[\w\.-]+@[\w\.-]+\.\w+$"}}}

        report = validate_schema(df, schema)
        assert report["status"] == "fail"
        assert any("not matching regex" in err for err in report["errors"])

    def test_length_constraints(self):
        """Test string length constraints."""
        df = pd.DataFrame({"code": ["AB", "ABCD", "ABCDEF"]})

        schema = {"code": {"type": str, "constraints": {"min_length": 3, "max_length": 5}}}

        report = validate_schema(df, schema)
        assert report["status"] == "fail"

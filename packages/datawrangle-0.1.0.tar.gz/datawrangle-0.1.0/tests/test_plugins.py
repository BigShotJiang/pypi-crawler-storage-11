"""
Tests for plugin system functionality.
"""

import pytest
import pandas as pd
from datawrangle.plugins import (
    register_cleaner,
    register_validator,
    get_custom_cleaners,
    get_custom_validators,
    unregister_cleaner,
    list_cleaners,
    clear_all_cleaners,
)


class TestPlugins:

    def teardown_method(self):
        """Clean up after each test."""
        clear_all_cleaners()

    def test_register_cleaner_decorator(self):
        """Test registering a custom cleaner."""

        @register_cleaner
        def test_cleaner(df):
            return df.dropna()

        cleaners = get_custom_cleaners()
        assert "test_cleaner" in cleaners
        assert cleaners["test_cleaner"] == test_cleaner

    def test_register_cleaner_with_custom_name(self):
        """Test registering cleaner with custom name."""

        @register_cleaner(name="my_custom_cleaner")
        def some_function(df):
            return df

        cleaners = get_custom_cleaners()
        assert "my_custom_cleaner" in cleaners

    def test_register_validator_decorator(self):
        """Test registering a custom validator."""

        @register_validator
        def test_validator(df):
            return len(df) > 0

        validators = get_custom_validators()
        assert "test_validator" in validators

    def test_unregister_cleaner(self):
        """Test unregistering a cleaner."""

        @register_cleaner
        def temp_cleaner(df):
            return df

        assert "temp_cleaner" in get_custom_cleaners()

        result = unregister_cleaner("temp_cleaner")
        assert result is True
        assert "temp_cleaner" not in get_custom_cleaners()

    def test_unregister_nonexistent_cleaner(self):
        """Test unregistering a non-existent cleaner."""
        result = unregister_cleaner("nonexistent")
        assert result is False

    def test_list_cleaners(self):
        """Test listing all cleaners."""

        @register_cleaner
        def cleaner1(df):
            return df

        @register_cleaner
        def cleaner2(df):
            return df

        cleaners_list = list_cleaners()
        assert "cleaner1" in cleaners_list
        assert "cleaner2" in cleaners_list

    def test_clear_all_cleaners(self):
        """Test clearing all cleaners."""

        @register_cleaner
        def cleaner1(df):
            return df

        @register_cleaner
        def cleaner2(df):
            return df

        assert len(list_cleaners()) == 2

        clear_all_cleaners()
        assert len(list_cleaners()) == 0

"""
Tests for text normalization functionality.
"""

import pytest
import pandas as pd
from datawrangle.text_normalizer import normalize_text


class TestTextNormalizer:

    def test_lowercase(self):
        """Test lowercase conversion."""
        df = pd.DataFrame({"text": ["Hello", "WORLD", "TeSt"]})

        result = normalize_text(df, "text", {"lowercase": True})
        assert result["text"].tolist() == ["hello", "world", "test"]

    def test_uppercase(self):
        """Test uppercase conversion."""
        df = pd.DataFrame({"text": ["Hello", "world", "TeSt"]})

        result = normalize_text(df, "text", {"uppercase": True})
        assert result["text"].tolist() == ["HELLO", "WORLD", "TEST"]

    def test_remove_punctuation(self):
        """Test punctuation removal."""
        df = pd.DataFrame({"text": ["Hello!", "World?", "Test."]})

        result = normalize_text(df, "text", {"remove_punctuation": True})
        assert result["text"].tolist() == ["Hello", "World", "Test"]

    def test_remove_whitespace(self):
        """Test extra whitespace removal."""
        df = pd.DataFrame({"text": ["Hello  World", "Test   Data", "Multiple     Spaces"]})

        result = normalize_text(df, "text", {"remove_whitespace": True})
        assert all(" " in text and "  " not in text for text in result["text"])

    def test_remove_numbers(self):
        """Test number removal."""
        df = pd.DataFrame({"text": ["Hello123", "World456", "Test789"]})

        result = normalize_text(df, "text", {"remove_numbers": True})
        assert result["text"].tolist() == ["Hello", "World", "Test"]

    def test_remove_special_chars(self):
        """Test special character removal."""
        df = pd.DataFrame({"text": ["Hello@World", "Test#Data", "Sample$Text"]})

        result = normalize_text(df, "text", {"remove_special_chars": True})
        assert "@" not in result["text"].str.cat()
        assert "#" not in result["text"].str.cat()
        assert "$" not in result["text"].str.cat()

    def test_remove_patterns(self):
        """Test custom pattern removal."""
        df = pd.DataFrame(
            {"text": ["Visit https://example.com", "Call 1234567890", "Email test@example.com"]}
        )

        result = normalize_text(df, "text", {"remove_patterns": [r"https?://\S+", r"\d{10}"]})

        assert "https://example.com" not in result["text"].str.cat()
        assert "1234567890" not in result["text"].str.cat()

    def test_replace_patterns(self):
        """Test pattern replacement."""
        df = pd.DataFrame({"text": ["Hello_World", "Test_Data"]})

        result = normalize_text(df, "text", {"replace_patterns": {"_": " "}})

        assert result["text"].tolist() == ["Hello World", "Test Data"]

    def test_strip(self):
        """Test strip whitespace."""
        df = pd.DataFrame({"text": ["  Hello  ", "  World  ", "  Test  "]})

        result = normalize_text(df, "text", {"strip": True})
        assert result["text"].tolist() == ["Hello", "World", "Test"]

    def test_multiple_operations(self):
        """Test combining multiple text operations."""
        df = pd.DataFrame({"text": ["  Hello, World!  ", "  TEST DATA?  "]})

        result = normalize_text(
            df, "text", {"lowercase": True, "remove_punctuation": True, "strip": True}
        )

        assert result["text"].tolist() == ["hello world", "test data"]

    def test_column_not_found(self):
        """Test error when column not found."""
        df = pd.DataFrame({"text": ["Hello"]})

        with pytest.raises(ValueError, match="Column.*not found"):
            normalize_text(df, "nonexistent", {})

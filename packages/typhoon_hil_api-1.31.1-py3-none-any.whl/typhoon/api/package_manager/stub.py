#
# This file is a part of Typhoon HIL API library.
#
# Typhoon HIL API is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
import threading
from functools import cache
from warnings import warn

from typhoon.api.common import (
    ClientStubMixin,
    ConnectionMixin,
    LoggingMixin,
    thread_safe,
)
from typhoon.api.constants import PACKAGE_MANAGER_API_NAME
from typhoon.api.package_manager.const import PACKAGE
from typhoon.api.package_manager.exception import get_exception_by_code
from typhoon.api.package_manager.package import Package
from typhoon.api.utils import check_environ_vars, init_stub

lock = threading.RLock()


class ClientAPIStub(LoggingMixin, ClientStubMixin, ConnectionMixin):
    def __init__(self, server_params, log_file="client.log"):
        super().__init__(log_file)
        self.server_ip, self.server_port = server_params

        # Switch for raising exceptions and warnings instead of just printing
        self.raise_exceptions = False

    @property
    def server_addr(self):
        return f"tcp://{self.server_ip}:{self.server_port}"

    def _ping_resp_handler(self, response):
        if self.server_port is None:
            # If server_port is None, it means following:
            #   1. server_port is not defined in settings.conf
            #   2. server_port is not provided as env variable
            #
            # In that case, we use port number provided by server through
            # announcement.
            port_data = response.get("result")[2]
            self.server_port = port_data[PACKAGE_MANAGER_API_NAME]["server_rep_port"]

    def connect(self):
        self._ping()

    def __getattr__(self, name):
        try:
            attr = self.__getattribute__(name)
            return attr
        except Exception:

            @thread_safe(lock)
            def wrapper(*args, **kwargs):
                msg = self.build_req_msg(name, **kwargs)

                self.log(f"{name} message: {msg}")

                self._req_socket.send_json(msg)

                response = self._req_socket.recv_json()

                result = response.get("result")
                error = response.get("error")
                warnings = response.get("warnings", [])

                self.log(f"{name} status: {result}")

                f_warning = warn if self.raise_exceptions else print
                for warning in warnings:
                    f_warning(warning)

                if error:
                    err_msg = error["message"]
                    data = error.get("data", {})
                    internal_code = data.get("internal_error_code", None)
                    raise get_exception_by_code(internal_code, message=err_msg)

                elif isinstance(result, dict) and PACKAGE in result:
                    # If a function returns Package object, server will
                    # serialize into a dictionary. So, now we need to create an
                    # Package instance from that dictionary and return it to
                    # the client.

                    result = Package(**result)
                elif isinstance(result, list):
                    result = [
                        Package(**res)
                        if (isinstance(res, dict) and PACKAGE in res)
                        else res
                        for res in result
                    ]

                return result

            return wrapper


@cache
@check_environ_vars(server_type=PACKAGE_MANAGER_API_NAME)
def clstub(server_params):
    return init_stub(ClientAPIStub, server_params)

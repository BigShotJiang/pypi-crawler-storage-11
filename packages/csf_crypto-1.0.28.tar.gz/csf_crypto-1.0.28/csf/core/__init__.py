"""Core cryptographic primitives."""

"""
Different helpful enums.
"""

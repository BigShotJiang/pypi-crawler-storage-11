"""
Structures produced by parsers.
"""

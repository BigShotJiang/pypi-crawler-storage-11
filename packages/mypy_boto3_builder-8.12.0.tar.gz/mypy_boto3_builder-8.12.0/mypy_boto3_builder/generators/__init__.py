"""
Stubs and docs generators.
"""

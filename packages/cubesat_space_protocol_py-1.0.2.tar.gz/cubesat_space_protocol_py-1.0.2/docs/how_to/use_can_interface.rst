Use CAN interface
=================

TODO
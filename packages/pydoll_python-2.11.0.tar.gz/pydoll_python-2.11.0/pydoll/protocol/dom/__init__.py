"""DOM domain implementation."""

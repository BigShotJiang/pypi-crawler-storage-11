# Cupid algo

poetry build

poetry config pypi-token.pypi <your_pypi_token>

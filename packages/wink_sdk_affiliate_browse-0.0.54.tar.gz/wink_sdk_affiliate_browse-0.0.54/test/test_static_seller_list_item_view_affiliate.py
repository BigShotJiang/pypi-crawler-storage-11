# coding: utf-8

"""
    Wink API

     # Introduction  Welcome to the Wink API - A programmer-friendly way to manage, sell and book travel inventory on the Wink platform. The API gives you all the tools you need to ready your properties and inventory for sale across 1000s of our native sales channels.  Integrators, affiliates, travel agents and content creators have the ability search for your travel inventory and promote / sell it in a wide variety of ways.   # Integrations  We have already integrated with the most well-known channel managers so you don't have to. To see our current integrations, please go to https://extranet.wink.travel and scroll to Connectivity section. Once your properties are set up, you can finish the setup by mapping your property to Wink using your channel manager partner portal. If your properties don't have a channel manager, you can easily manage rates and availability with this API.   # Intended Audience  Programmers are [most likely] a requirement to start integrating with Wink. Companies and organizations that would most benefit from integrating with us are new and existing travel companies that have relationships with suppliers and that need an advanced system from which to manage their travel inventory and get that same inventory out to as many eyeballs as possible at the lowest price possible.  - Hotel chains  - Hotel brands  - Travel tech companies  - Destination sites  - Integrators  - Aggregators  - Destination management companies  - Travel agencies  - OTAs   ## APIs  Not every integrator needs every API. For that reason, we have separated APIs into context.  ### Test API   - [Ping](/ping): The Ping API is a quick test endpoint to verify that your credentials work Wink.  ### Common APIs  - [Notifications](/notifications): The Notifications API is a way for us to stay in touch with your user, property or affiliate account. - [User Settings](/user-settings): The User Settings API exposes endpoints to allow 3rd party integrators to communicate with Wink.  ### Consume APIs Consume endpoints are for developers who want to find existing travel inventory and either book it or use it to advertise through one of their Wink affiliate accounts.   - [Configuration](/engine-client): A single endpoint to retrieve whitelabel + customization information for the booking engine.  - [Lookup](/lookup): All APIs related to locating inventory by region, locale and property flags.  - [Inventory](/inventory): All APIs related to retrieve known travel inventory as it was found using the Lookup API..  - [Booking](/booking): All APIs related to creating bookings on the platform.  - [Travel Agent](/travel-agent): The Travel Agent API exposes endpoints to manage agent-facilitated bookings.   ### Produce APIs  Produce endpoints are for developers who want to create and manage travel inventory.   #### Property  - [Property registration](/extranet/property/register): As a producer, this is, oftentimes, where you start your journey. These endpoints let you create properties on Wink.  - [Property](/extranet/property): This collection of property endpoints are mostly management endpoints that let you display, change status and similar for your existing properties.  - [Facilities](/extranet/facilities): This collection of endpoints let you manage facilities; such as room types.  - [Experiences](/extranet/experiences): This collection of endpoints let you manage experiences, such as activities.  - [Monetize](/extranet/monetize): The Monetize API exposes endpoints for managing cancellation polies, rate plans, promotions and more on Wink.  - [Distribution](/extranet/distribution): The Distribution API exposes endpoints for sales channels, connecting with affiliates, managing rates and inventory calendars and more on Wink.  - [Property Booking](/extranet/booking): The Property Booking API exposes endpoints for managing bookings and reviews at the property-level.   #### Affiliate  - [Affiliate](/affiliate): This collection of affiliate endpoints are mostly management endpoints that let you display, change status and similar for your existing accounts.  - [Browse](/affiliate/browse): The Browse API exposes endpoints for affiliates to find suppliers and inventory to sell.  - [Inventory](/affiliate/inventory): The Inventory API exposes endpoints for affiliates to manage the inventory they want to sell and how they want to sell it.  - [Sales Channel](/affiliate/sales-channel): The Sales Channel API exposes endpoints for affiliates to manage existing sales channels as well as find new ones.  - [WinkLinks](/affiliate/winklinks): The WinkLinks API exposes endpoints for affiliates to manage their WinkLinks page.   #### Rate provider  - [Channel manager](/channel-manager): The Channel Manager API enables external channel manager partners to map, exchange rate / availability information with us as well as be informed of bookings that occur on the Wink platform for one of their properties.   ### Taxonomy APIs  Taxonomy endpoints are for developers who want to consume and produce travel inventory and need taxonomies of standard and non-standard codes for inventory types, classes, statuses etc.   - [Reference](/reference): All APIs related to retrieving platform-supported taxonomies.   ### Insight APIs  Insight endpoints do exactly what the name implies - They offer platform-level insight into the activities of producers and consumers.   - [Analytics](/analytics): All APIs related to tracking metrics across a wide variety of data source segments including, more entertaining, leaderboard metrics.   ### Payment APIs  Payment endpoints are for developers who want to purchase travel inventory. This can be done via the API as a registered Travel Agent or using our API in conjunction with our PCI compliant payment widget for all other entities.   - [TripPay](/payment): All APIs related to TripPay account management, booking, mapping and integration features.   ## SDKs  We are actively working on supporting the most used languages out there. If you don't see your language here, reach out to us with a request to officially add your language. In the meantime, if you want to roll your own SDK, you can do so by downloading the OpenAPI spec and using one of the many available OpenAPI generators available: [https://openapi-generator.tech/docs/generators](https://openapi-generator.tech/docs/generators).   - Java SDK [https://github.com/wink-travel/wink-sdk-java](https://github.com/wink-travel/wink-sdk-java)   ## Usage  These features are made available to you via a [REST API](https://en.wikipedia.org/wiki/Representational_state_transfer). This API is language agnostic.   ## Versioning  We chose to version our endpoints in a way that we hope affects your integration minimally. You request the version of our API you wish to work with via the `Wink-Version` header. When it's time for you to upgrade, you only have to change the version number to get access to our updated endpoints.   ## Release history  - Follow updates on Github: https://github.com/wink-travel/wink-sdk-java/blob/master/CHANGELOG.md    # Browse API The Browse API exposes endpoints to find suppliers and inventory to sell. This API lets you:  1. Browse: Find inventory and suppliers. 2. Saved Search: Manage saved searches 3. Curated List: Manage curated lists  Browse the endpoints in the left navigation bar to get started.  

    The version of the OpenAPI document: 30.5.19
    Contact: bjorn@wink.travel
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


import unittest

from wink_sdk_affiliate_browse.models.static_seller_list_item_view_affiliate import StaticSellerListItemViewAffiliate

class TestStaticSellerListItemViewAffiliate(unittest.TestCase):
    """StaticSellerListItemViewAffiliate unit test stubs"""

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def make_instance(self, include_optional) -> StaticSellerListItemViewAffiliate:
        """Test StaticSellerListItemViewAffiliate
            include_optional is a boolean, when False only required
            params are included, when True both required and
            optional params are included """
        # uncomment below to create an instance of `StaticSellerListItemViewAffiliate`
        """
        model = StaticSellerListItemViewAffiliate()
        if include_optional:
            return StaticSellerListItemViewAffiliate(
                id = 'doc-1',
                created_date = datetime.datetime.strptime('2013-10-20 19:20:30.00', '%Y-%m-%d %H:%M:%S.%f'),
                last_update = datetime.datetime.strptime('2013-10-20 19:20:30.00', '%Y-%m-%d %H:%M:%S.%f'),
                version = 12,
                static_seller_list_item = wink_sdk_affiliate_browse.models.static_seller_list_item_affiliate.StaticSellerListItem_Affiliate(
                    identifier = '', 
                    parent = wink_sdk_affiliate_browse.models.static_seller_list_affiliate.StaticSellerList_Affiliate(
                        identifier = '', 
                        owner_identifier = '', 
                        name = 'Top 3 hotels in Chiang Mai', 
                        type = 'NORMAL', ), 
                    inventory = wink_sdk_affiliate_browse.models.inventory_affiliate.Inventory_Affiliate(
                        identifier = '', 
                        sales_channel = wink_sdk_affiliate_browse.models.sales_channel_affiliate.SalesChannel_Affiliate(
                            identifier = '', 
                            supplier_identifier = '', 
                            supplier_name = 'Hotel 1', 
                            supplier_available = True, 
                            sub_type = 'DIRECT', 
                            owner_identifier = '', 
                            owner_name = 'Owner 1', 
                            enabled = True, 
                            channel_disabled = True, 
                            blacklisted = True, 
                            percent_discount = 0.15, 
                            commission = 0.2, 
                            rate_modifiers = [
                                wink_sdk_affiliate_browse.models.rate_modifier_affiliate.RateModifier_Affiliate(
                                    identifier = '', 
                                    hotel_identifier = '', 
                                    name = 'Early bird', 
                                    type = 'DISCOUNT', 
                                    modifier = wink_sdk_affiliate_browse.models.variable_charge_affiliate.VariableCharge_Affiliate(), 
                                    enabled = True, 
                                    pricing_type = 'PER_PERSON_PER_NIGHT', 
                                    descriptions = [
                                        wink_sdk_affiliate_browse.models.localized_description_affiliate.LocalizedDescription_Affiliate(
                                            description = 'This is a longer description in the specified language.', 
                                            language = 'en', )
                                        ], 
                                    city_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.city_rate_qualifier_affiliate.CityRateQualifier_Affiliate()
                                        ], 
                                    continent_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.continent_rate_qualifier_affiliate.ContinentRateQualifier_Affiliate()
                                        ], 
                                    country_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.country_rate_qualifier_affiliate.CountryRateQualifier_Affiliate()
                                        ], 
                                    promotion_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.promotion_rate_qualifier_affiliate.PromotionRateQualifier_Affiliate()
                                        ], 
                                    ip_range_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.ip_range_rate_qualifier_affiliate.IPRangeRateQualifier_Affiliate()
                                        ], 
                                    room_range_rate_qualifier = wink_sdk_affiliate_browse.models.room_range_rate_qualifier_affiliate.RoomRangeRateQualifier_Affiliate(), 
                                    prepay_rate_qualifier = wink_sdk_affiliate_browse.models.prepay_rate_qualifier_affiliate.PrepayRateQualifier_Affiliate(), 
                                    refundable_rate_qualifier = wink_sdk_affiliate_browse.models.refundable_rate_qualifier_affiliate.RefundableRateQualifier_Affiliate(), 
                                    timezone_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.timezone_rate_qualifier_affiliate.TimezoneRateQualifier_Affiliate()
                                        ], 
                                    last_minute_rate_qualifier = wink_sdk_affiliate_browse.models.minutes_before_booking_start_date_rate_qualifier_affiliate.MinutesBeforeBookingStartDateRateQualifier_Affiliate(), 
                                    length_of_stay_rate_qualifier = wink_sdk_affiliate_browse.models.length_of_stay_rate_qualifier_affiliate.LengthOfStayRateQualifier_Affiliate(), 
                                    advance_booking_rate_qualifier = wink_sdk_affiliate_browse.models.advance_booking_rate_qualifier_affiliate.AdvanceBookingRateQualifier_Affiliate(), 
                                    stay_date_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.stay_date_rate_qualifier_affiliate.StayDateRateQualifier_Affiliate()
                                        ], 
                                    sell_date_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.sell_date_rate_qualifier_affiliate.SellDateRateQualifier_Affiliate()
                                        ], 
                                    available_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.available_days_of_week_rate_qualifier_affiliate.AvailableDaysOfWeekRateQualifier_Affiliate(), 
                                    arrival_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.arrival_days_of_week_rate_qualifier_affiliate.ArrivalDaysOfWeekRateQualifier_Affiliate(), 
                                    departure_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.departure_days_of_week_rate_qualifier_affiliate.DepartureDaysOfWeekRateQualifier_Affiliate(), 
                                    required_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.required_days_of_week_rate_qualifier_affiliate.RequiredDaysOfWeekRateQualifier_Affiliate(), 
                                    master_rate_identifiers = ["master-rate-1","master-rate-2"], 
                                    add_on_identifiers = ["add-on-1","add-on-2"], 
                                    rate_plan_identifiers = ["rate-plan-1","rate-plan-2"], 
                                    blackout_dates = [
                                        wink_sdk_affiliate_browse.models.blackout_date_affiliate.BlackoutDate_Affiliate()
                                        ], )
                                ], 
                            rate_modifier_bundles = [
                                wink_sdk_affiliate_browse.models.rate_modifier_bundle_affiliate.RateModifierBundle_Affiliate(
                                    identifier = '', 
                                    hotel_identifier = '', 
                                    name = 'Early bird - Long Term', 
                                    enabled = True, 
                                    items = [
                                        wink_sdk_affiliate_browse.models.rate_modifier_affiliate.RateModifier_Affiliate(
                                            identifier = '', 
                                            hotel_identifier = '', 
                                            name = 'Early bird', 
                                            type = 'DISCOUNT', 
                                            modifier = wink_sdk_affiliate_browse.models.variable_charge_affiliate.VariableCharge_Affiliate(), 
                                            enabled = True, 
                                            pricing_type = 'PER_PERSON_PER_NIGHT', 
                                            descriptions = [
                                                wink_sdk_affiliate_browse.models.localized_description_affiliate.LocalizedDescription_Affiliate(
                                                    description = 'This is a longer description in the specified language.', 
                                                    language = 'en', )
                                                ], 
                                            room_range_rate_qualifier = wink_sdk_affiliate_browse.models.room_range_rate_qualifier_affiliate.RoomRangeRateQualifier_Affiliate(), 
                                            prepay_rate_qualifier = wink_sdk_affiliate_browse.models.prepay_rate_qualifier_affiliate.PrepayRateQualifier_Affiliate(), 
                                            refundable_rate_qualifier = wink_sdk_affiliate_browse.models.refundable_rate_qualifier_affiliate.RefundableRateQualifier_Affiliate(), 
                                            last_minute_rate_qualifier = wink_sdk_affiliate_browse.models.minutes_before_booking_start_date_rate_qualifier_affiliate.MinutesBeforeBookingStartDateRateQualifier_Affiliate(), 
                                            length_of_stay_rate_qualifier = wink_sdk_affiliate_browse.models.length_of_stay_rate_qualifier_affiliate.LengthOfStayRateQualifier_Affiliate(), 
                                            advance_booking_rate_qualifier = wink_sdk_affiliate_browse.models.advance_booking_rate_qualifier_affiliate.AdvanceBookingRateQualifier_Affiliate(), 
                                            available_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.available_days_of_week_rate_qualifier_affiliate.AvailableDaysOfWeekRateQualifier_Affiliate(), 
                                            arrival_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.arrival_days_of_week_rate_qualifier_affiliate.ArrivalDaysOfWeekRateQualifier_Affiliate(), 
                                            departure_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.departure_days_of_week_rate_qualifier_affiliate.DepartureDaysOfWeekRateQualifier_Affiliate(), 
                                            required_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.required_days_of_week_rate_qualifier_affiliate.RequiredDaysOfWeekRateQualifier_Affiliate(), 
                                            master_rate_identifiers = ["master-rate-1","master-rate-2"], 
                                            add_on_identifiers = ["add-on-1","add-on-2"], 
                                            rate_plan_identifiers = ["rate-plan-1","rate-plan-2"], )
                                        ], 
                                    modifier_override = wink_sdk_affiliate_browse.models.variable_charge_affiliate.VariableCharge_Affiliate(), 
                                    type = 'DISCOUNT', 
                                    pricing_type = 'PER_STAY', 
                                    has_fixed_discount_modifier = True, 
                                    has_percent_discount_modifier = True, 
                                    is_valid = True, 
                                    description = [
                                        
                                        ], )
                                ], ), 
                        inventory_type = 'GUEST_ROOM', 
                        inventory_identifier = '', 
                        inventory_name = '', 
                        inventory_name_in_english = '', 
                        enabled = True, 
                        image_identifier = '', 
                        price_point = 'THREE', 
                        location = {"type":"POINT","coordinates":[100.5581533,13.7370197]}, 
                        address = wink_sdk_affiliate_browse.models.address_affiliate.Address_Affiliate(
                            address1 = '234 Near da beach', 
                            address2 = 'Pebble #5001', 
                            state = 'CA', 
                            postal_code = '90210', 
                            county = 'Alameda county', 
                            city = wink_sdk_affiliate_browse.models.geo_name_affiliate.GeoName_Affiliate(
                                geo_name_id = '5128581', 
                                type = 'CITY', 
                                name = 'New York City', 
                                url_name = 'new-york-city-united-states', 
                                ascii_name = 'New York City', 
                                feature_code = '', 
                                country_code = '', 
                                timezone = 'America/New_York', 
                                country = wink_sdk_affiliate_browse.models.country_affiliate.Country_Affiliate(
                                    iso = 'US', 
                                    name = 'United States', 
                                    capital = 'Washington', 
                                    continent = 'NA', 
                                    currency_code = 'USD', 
                                    currency_name = 'Dollar', 
                                    geo_name_id = '6252001', ), 
                                sub_country = wink_sdk_affiliate_browse.models.sub_country_affiliate.SubCountry_Affiliate(
                                    name = 'New York', 
                                    ascii_name = 'New York', 
                                    geo_name_id = '5128638', ), 
                                sub_sub_country = wink_sdk_affiliate_browse.models.sub_sub_country_affiliate.SubSubCountry_Affiliate(
                                    name = '', 
                                    ascii_name = '', 
                                    geo_name_id = '', ), ), 
                            valid = True, 
                            full_address = '11 At home, Suite 3C, New York City, NY 10010, United States', ), 
                        quantity = 100, 
                        commissionable = True, 
                        bookable = True, 
                        lowest_price = wink_sdk_affiliate_browse.models.custom_monetary_amount.CustomMonetaryAmount(
                            amount = 1.337, 
                            currency = '', ), 
                        lowest_display_price = wink_sdk_affiliate_browse.models.custom_monetary_amount.CustomMonetaryAmount(
                            amount = 1.337, 
                            currency = '', ), 
                        hotel = wink_sdk_affiliate_browse.models.hotel_on_map_affiliate.HotelOnMap_Affiliate(
                            identifier = 'document-1', 
                            hotel_identifier = '', 
                            name = 'The Loveliest Hotel', 
                            local_name = 'Det Beste Hotellet', 
                            chain = 'Hotel chain', 
                            brand = 'Hotel brand', 
                            url_name = 'the-loveliest-hotel-new-york-united-states', 
                            star_rating = 4, 
                            bookings = 6054, 
                            aggregate_review_rating = 7.8, 
                            short_descriptions = [
                                
                                ], 
                            long_descriptions = [
                                
                                ], 
                            aggregate_greendex_rating = 7.0, 
                            lifestyle_types = [
                                'LIFESTYLE_HEALTH_FITNESS'
                                ], 
                            total_reviews = 989, 
                            available = True, 
                            hotel_available = True, 
                            reservations = wink_sdk_affiliate_browse.models.contact_affiliate.Contact_Affiliate(
                                first_name = 'John', 
                                last_name = 'Smith', 
                                email = 'johnsmith@email.com', 
                                secondary_email = 'johnsmith2@email.com', 
                                phone_number = '+12125551212', 
                                full_name = 'John Smith', 
                                summary = 'John Smith (johnsmith@gmail.com / +12125551212)', ), 
                            socials = [
                                wink_sdk_affiliate_browse.models.social_affiliate.Social_Affiliate(
                                    type = 'FACEBOOK', 
                                    enabled = True, )
                                ], 
                            images = [
                                cl-image-1
                                ], 
                            videos = [
                                cl-image-1
                                ], 
                            policy = wink_sdk_affiliate_browse.models.property_policy_affiliate.PropertyPolicy_Affiliate(
                                children_allowed = True, 
                                children_minimum_age = 6, 
                                internet_availability = 'YES', 
                                internet_connection_type = 'WIFI', 
                                internet_connection_location = 'ENTIRE_PROPERTY', 
                                parking_availability = 'YES', 
                                parking_access = 'PRIVATE', 
                                pets_allowed = True, 
                                pet_max_weight_in_kilos = 10, 
                                pet_charge = , 
                                check_out_time = '10:00', 
                                check_in_time = '14:00', ), 
                            third_party_reviews = [
                                wink_sdk_affiliate_browse.models.travel_inventory_recognition_affiliate.TravelInventoryRecognition_Affiliate(
                                    identifier = '', 
                                    category = 'AWARD', 
                                    type = 'PERCENT_RATING', 
                                    provider = 'Michelin', 
                                    rating = 8.5, 
                                    max_rating = 10, 
                                    date = 'Sat Oct 24 07:00:00 ICT 2020', 
                                    official_appointment_ind = True, 
                                    rating_symbol = '*', )
                                ], 
                            attractions = 5, 
                            recreations = 3, 
                            pois = 9, 
                            restaurants = 2, 
                            meeting_rooms = 2, 
                            spas = 1, 
                            add_ons = 5, 
                            general_manager = wink_sdk_affiliate_browse.models.general_manager_affiliate.GeneralManager_Affiliate(
                                name = 'Jane Doe', 
                                image = cl-image-1, ), 
                            location_category = '34', 
                            segment_category = '7', 
                            hotel_category = '45', 
                            architectural_style = '7', 
                            when_built = '1927', 
                            currency_code = 'USD', 
                            membership_rate_discount = 9, 
                            price_score = 9, 
                            perk_score = 4, 
                            package_score = 4, 
                            loyalty_score = 5, 
                            popular_score = 45, 
                            experience_score = 5, 
                            availability_score = 5, 
                            views = 10432, 
                            hotel_amenity_codes = ["1","7"], 
                            property_accessibility_codes = ["1","7"], 
                            property_security_codes = ["1","7"], 
                            number_of_rooms = 32, 
                            active = True, 
                            url_parameters = '', ), ), 
                    hotel = wink_sdk_affiliate_browse.models.hotel_on_map_affiliate.HotelOnMap_Affiliate(
                        identifier = 'document-1', 
                        hotel_identifier = '', 
                        name = 'The Loveliest Hotel', 
                        local_name = 'Det Beste Hotellet', 
                        chain = 'Hotel chain', 
                        brand = 'Hotel brand', 
                        url_name = 'the-loveliest-hotel-new-york-united-states', 
                        star_rating = 4, 
                        bookings = 6054, 
                        aggregate_review_rating = 7.8, 
                        aggregate_greendex_rating = 7.0, 
                        total_reviews = 989, 
                        available = True, 
                        hotel_available = True, 
                        attractions = 5, 
                        recreations = 3, 
                        pois = 9, 
                        restaurants = 2, 
                        meeting_rooms = 2, 
                        spas = 1, 
                        add_ons = 5, 
                        location_category = '34', 
                        segment_category = '7', 
                        hotel_category = '45', 
                        architectural_style = '7', 
                        when_built = '1927', 
                        currency_code = 'USD', 
                        membership_rate_discount = 9, 
                        price_score = 9, 
                        perk_score = 4, 
                        package_score = 4, 
                        loyalty_score = 5, 
                        popular_score = 45, 
                        experience_score = 5, 
                        availability_score = 5, 
                        views = 10432, 
                        hotel_amenity_codes = ["1","7"], 
                        property_accessibility_codes = ["1","7"], 
                        property_security_codes = ["1","7"], 
                        number_of_rooms = 32, 
                        active = True, 
                        url_parameters = '', ), 
                    sort = 56, 
                    status = 'ACTIVE', )
            )
        else:
            return StaticSellerListItemViewAffiliate(
                static_seller_list_item = wink_sdk_affiliate_browse.models.static_seller_list_item_affiliate.StaticSellerListItem_Affiliate(
                    identifier = '', 
                    parent = wink_sdk_affiliate_browse.models.static_seller_list_affiliate.StaticSellerList_Affiliate(
                        identifier = '', 
                        owner_identifier = '', 
                        name = 'Top 3 hotels in Chiang Mai', 
                        type = 'NORMAL', ), 
                    inventory = wink_sdk_affiliate_browse.models.inventory_affiliate.Inventory_Affiliate(
                        identifier = '', 
                        sales_channel = wink_sdk_affiliate_browse.models.sales_channel_affiliate.SalesChannel_Affiliate(
                            identifier = '', 
                            supplier_identifier = '', 
                            supplier_name = 'Hotel 1', 
                            supplier_available = True, 
                            sub_type = 'DIRECT', 
                            owner_identifier = '', 
                            owner_name = 'Owner 1', 
                            enabled = True, 
                            channel_disabled = True, 
                            blacklisted = True, 
                            percent_discount = 0.15, 
                            commission = 0.2, 
                            rate_modifiers = [
                                wink_sdk_affiliate_browse.models.rate_modifier_affiliate.RateModifier_Affiliate(
                                    identifier = '', 
                                    hotel_identifier = '', 
                                    name = 'Early bird', 
                                    type = 'DISCOUNT', 
                                    modifier = wink_sdk_affiliate_browse.models.variable_charge_affiliate.VariableCharge_Affiliate(), 
                                    enabled = True, 
                                    pricing_type = 'PER_PERSON_PER_NIGHT', 
                                    descriptions = [
                                        wink_sdk_affiliate_browse.models.localized_description_affiliate.LocalizedDescription_Affiliate(
                                            description = 'This is a longer description in the specified language.', 
                                            language = 'en', )
                                        ], 
                                    city_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.city_rate_qualifier_affiliate.CityRateQualifier_Affiliate()
                                        ], 
                                    continent_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.continent_rate_qualifier_affiliate.ContinentRateQualifier_Affiliate()
                                        ], 
                                    country_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.country_rate_qualifier_affiliate.CountryRateQualifier_Affiliate()
                                        ], 
                                    promotion_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.promotion_rate_qualifier_affiliate.PromotionRateQualifier_Affiliate()
                                        ], 
                                    ip_range_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.ip_range_rate_qualifier_affiliate.IPRangeRateQualifier_Affiliate()
                                        ], 
                                    room_range_rate_qualifier = wink_sdk_affiliate_browse.models.room_range_rate_qualifier_affiliate.RoomRangeRateQualifier_Affiliate(), 
                                    prepay_rate_qualifier = wink_sdk_affiliate_browse.models.prepay_rate_qualifier_affiliate.PrepayRateQualifier_Affiliate(), 
                                    refundable_rate_qualifier = wink_sdk_affiliate_browse.models.refundable_rate_qualifier_affiliate.RefundableRateQualifier_Affiliate(), 
                                    timezone_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.timezone_rate_qualifier_affiliate.TimezoneRateQualifier_Affiliate()
                                        ], 
                                    last_minute_rate_qualifier = wink_sdk_affiliate_browse.models.minutes_before_booking_start_date_rate_qualifier_affiliate.MinutesBeforeBookingStartDateRateQualifier_Affiliate(), 
                                    length_of_stay_rate_qualifier = wink_sdk_affiliate_browse.models.length_of_stay_rate_qualifier_affiliate.LengthOfStayRateQualifier_Affiliate(), 
                                    advance_booking_rate_qualifier = wink_sdk_affiliate_browse.models.advance_booking_rate_qualifier_affiliate.AdvanceBookingRateQualifier_Affiliate(), 
                                    stay_date_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.stay_date_rate_qualifier_affiliate.StayDateRateQualifier_Affiliate()
                                        ], 
                                    sell_date_rate_qualifiers = [
                                        wink_sdk_affiliate_browse.models.sell_date_rate_qualifier_affiliate.SellDateRateQualifier_Affiliate()
                                        ], 
                                    available_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.available_days_of_week_rate_qualifier_affiliate.AvailableDaysOfWeekRateQualifier_Affiliate(), 
                                    arrival_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.arrival_days_of_week_rate_qualifier_affiliate.ArrivalDaysOfWeekRateQualifier_Affiliate(), 
                                    departure_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.departure_days_of_week_rate_qualifier_affiliate.DepartureDaysOfWeekRateQualifier_Affiliate(), 
                                    required_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.required_days_of_week_rate_qualifier_affiliate.RequiredDaysOfWeekRateQualifier_Affiliate(), 
                                    master_rate_identifiers = ["master-rate-1","master-rate-2"], 
                                    add_on_identifiers = ["add-on-1","add-on-2"], 
                                    rate_plan_identifiers = ["rate-plan-1","rate-plan-2"], 
                                    blackout_dates = [
                                        wink_sdk_affiliate_browse.models.blackout_date_affiliate.BlackoutDate_Affiliate()
                                        ], )
                                ], 
                            rate_modifier_bundles = [
                                wink_sdk_affiliate_browse.models.rate_modifier_bundle_affiliate.RateModifierBundle_Affiliate(
                                    identifier = '', 
                                    hotel_identifier = '', 
                                    name = 'Early bird - Long Term', 
                                    enabled = True, 
                                    items = [
                                        wink_sdk_affiliate_browse.models.rate_modifier_affiliate.RateModifier_Affiliate(
                                            identifier = '', 
                                            hotel_identifier = '', 
                                            name = 'Early bird', 
                                            type = 'DISCOUNT', 
                                            modifier = wink_sdk_affiliate_browse.models.variable_charge_affiliate.VariableCharge_Affiliate(), 
                                            enabled = True, 
                                            pricing_type = 'PER_PERSON_PER_NIGHT', 
                                            descriptions = [
                                                wink_sdk_affiliate_browse.models.localized_description_affiliate.LocalizedDescription_Affiliate(
                                                    description = 'This is a longer description in the specified language.', 
                                                    language = 'en', )
                                                ], 
                                            room_range_rate_qualifier = wink_sdk_affiliate_browse.models.room_range_rate_qualifier_affiliate.RoomRangeRateQualifier_Affiliate(), 
                                            prepay_rate_qualifier = wink_sdk_affiliate_browse.models.prepay_rate_qualifier_affiliate.PrepayRateQualifier_Affiliate(), 
                                            refundable_rate_qualifier = wink_sdk_affiliate_browse.models.refundable_rate_qualifier_affiliate.RefundableRateQualifier_Affiliate(), 
                                            last_minute_rate_qualifier = wink_sdk_affiliate_browse.models.minutes_before_booking_start_date_rate_qualifier_affiliate.MinutesBeforeBookingStartDateRateQualifier_Affiliate(), 
                                            length_of_stay_rate_qualifier = wink_sdk_affiliate_browse.models.length_of_stay_rate_qualifier_affiliate.LengthOfStayRateQualifier_Affiliate(), 
                                            advance_booking_rate_qualifier = wink_sdk_affiliate_browse.models.advance_booking_rate_qualifier_affiliate.AdvanceBookingRateQualifier_Affiliate(), 
                                            available_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.available_days_of_week_rate_qualifier_affiliate.AvailableDaysOfWeekRateQualifier_Affiliate(), 
                                            arrival_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.arrival_days_of_week_rate_qualifier_affiliate.ArrivalDaysOfWeekRateQualifier_Affiliate(), 
                                            departure_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.departure_days_of_week_rate_qualifier_affiliate.DepartureDaysOfWeekRateQualifier_Affiliate(), 
                                            required_days_of_week_rate_qualifier = wink_sdk_affiliate_browse.models.required_days_of_week_rate_qualifier_affiliate.RequiredDaysOfWeekRateQualifier_Affiliate(), 
                                            master_rate_identifiers = ["master-rate-1","master-rate-2"], 
                                            add_on_identifiers = ["add-on-1","add-on-2"], 
                                            rate_plan_identifiers = ["rate-plan-1","rate-plan-2"], )
                                        ], 
                                    modifier_override = wink_sdk_affiliate_browse.models.variable_charge_affiliate.VariableCharge_Affiliate(), 
                                    type = 'DISCOUNT', 
                                    pricing_type = 'PER_STAY', 
                                    has_fixed_discount_modifier = True, 
                                    has_percent_discount_modifier = True, 
                                    is_valid = True, 
                                    description = [
                                        
                                        ], )
                                ], ), 
                        inventory_type = 'GUEST_ROOM', 
                        inventory_identifier = '', 
                        inventory_name = '', 
                        inventory_name_in_english = '', 
                        enabled = True, 
                        image_identifier = '', 
                        price_point = 'THREE', 
                        location = {"type":"POINT","coordinates":[100.5581533,13.7370197]}, 
                        address = wink_sdk_affiliate_browse.models.address_affiliate.Address_Affiliate(
                            address1 = '234 Near da beach', 
                            address2 = 'Pebble #5001', 
                            state = 'CA', 
                            postal_code = '90210', 
                            county = 'Alameda county', 
                            city = wink_sdk_affiliate_browse.models.geo_name_affiliate.GeoName_Affiliate(
                                geo_name_id = '5128581', 
                                type = 'CITY', 
                                name = 'New York City', 
                                url_name = 'new-york-city-united-states', 
                                ascii_name = 'New York City', 
                                feature_code = '', 
                                country_code = '', 
                                timezone = 'America/New_York', 
                                country = wink_sdk_affiliate_browse.models.country_affiliate.Country_Affiliate(
                                    iso = 'US', 
                                    name = 'United States', 
                                    capital = 'Washington', 
                                    continent = 'NA', 
                                    currency_code = 'USD', 
                                    currency_name = 'Dollar', 
                                    geo_name_id = '6252001', ), 
                                sub_country = wink_sdk_affiliate_browse.models.sub_country_affiliate.SubCountry_Affiliate(
                                    name = 'New York', 
                                    ascii_name = 'New York', 
                                    geo_name_id = '5128638', ), 
                                sub_sub_country = wink_sdk_affiliate_browse.models.sub_sub_country_affiliate.SubSubCountry_Affiliate(
                                    name = '', 
                                    ascii_name = '', 
                                    geo_name_id = '', ), ), 
                            valid = True, 
                            full_address = '11 At home, Suite 3C, New York City, NY 10010, United States', ), 
                        quantity = 100, 
                        commissionable = True, 
                        bookable = True, 
                        lowest_price = wink_sdk_affiliate_browse.models.custom_monetary_amount.CustomMonetaryAmount(
                            amount = 1.337, 
                            currency = '', ), 
                        lowest_display_price = wink_sdk_affiliate_browse.models.custom_monetary_amount.CustomMonetaryAmount(
                            amount = 1.337, 
                            currency = '', ), 
                        hotel = wink_sdk_affiliate_browse.models.hotel_on_map_affiliate.HotelOnMap_Affiliate(
                            identifier = 'document-1', 
                            hotel_identifier = '', 
                            name = 'The Loveliest Hotel', 
                            local_name = 'Det Beste Hotellet', 
                            chain = 'Hotel chain', 
                            brand = 'Hotel brand', 
                            url_name = 'the-loveliest-hotel-new-york-united-states', 
                            star_rating = 4, 
                            bookings = 6054, 
                            aggregate_review_rating = 7.8, 
                            short_descriptions = [
                                
                                ], 
                            long_descriptions = [
                                
                                ], 
                            aggregate_greendex_rating = 7.0, 
                            lifestyle_types = [
                                'LIFESTYLE_HEALTH_FITNESS'
                                ], 
                            total_reviews = 989, 
                            available = True, 
                            hotel_available = True, 
                            reservations = wink_sdk_affiliate_browse.models.contact_affiliate.Contact_Affiliate(
                                first_name = 'John', 
                                last_name = 'Smith', 
                                email = 'johnsmith@email.com', 
                                secondary_email = 'johnsmith2@email.com', 
                                phone_number = '+12125551212', 
                                full_name = 'John Smith', 
                                summary = 'John Smith (johnsmith@gmail.com / +12125551212)', ), 
                            socials = [
                                wink_sdk_affiliate_browse.models.social_affiliate.Social_Affiliate(
                                    type = 'FACEBOOK', 
                                    enabled = True, )
                                ], 
                            images = [
                                cl-image-1
                                ], 
                            videos = [
                                cl-image-1
                                ], 
                            policy = wink_sdk_affiliate_browse.models.property_policy_affiliate.PropertyPolicy_Affiliate(
                                children_allowed = True, 
                                children_minimum_age = 6, 
                                internet_availability = 'YES', 
                                internet_connection_type = 'WIFI', 
                                internet_connection_location = 'ENTIRE_PROPERTY', 
                                parking_availability = 'YES', 
                                parking_access = 'PRIVATE', 
                                pets_allowed = True, 
                                pet_max_weight_in_kilos = 10, 
                                pet_charge = , 
                                check_out_time = '10:00', 
                                check_in_time = '14:00', ), 
                            third_party_reviews = [
                                wink_sdk_affiliate_browse.models.travel_inventory_recognition_affiliate.TravelInventoryRecognition_Affiliate(
                                    identifier = '', 
                                    category = 'AWARD', 
                                    type = 'PERCENT_RATING', 
                                    provider = 'Michelin', 
                                    rating = 8.5, 
                                    max_rating = 10, 
                                    date = 'Sat Oct 24 07:00:00 ICT 2020', 
                                    official_appointment_ind = True, 
                                    rating_symbol = '*', )
                                ], 
                            attractions = 5, 
                            recreations = 3, 
                            pois = 9, 
                            restaurants = 2, 
                            meeting_rooms = 2, 
                            spas = 1, 
                            add_ons = 5, 
                            general_manager = wink_sdk_affiliate_browse.models.general_manager_affiliate.GeneralManager_Affiliate(
                                name = 'Jane Doe', 
                                image = cl-image-1, ), 
                            location_category = '34', 
                            segment_category = '7', 
                            hotel_category = '45', 
                            architectural_style = '7', 
                            when_built = '1927', 
                            currency_code = 'USD', 
                            membership_rate_discount = 9, 
                            price_score = 9, 
                            perk_score = 4, 
                            package_score = 4, 
                            loyalty_score = 5, 
                            popular_score = 45, 
                            experience_score = 5, 
                            availability_score = 5, 
                            views = 10432, 
                            hotel_amenity_codes = ["1","7"], 
                            property_accessibility_codes = ["1","7"], 
                            property_security_codes = ["1","7"], 
                            number_of_rooms = 32, 
                            active = True, 
                            url_parameters = '', ), ), 
                    hotel = wink_sdk_affiliate_browse.models.hotel_on_map_affiliate.HotelOnMap_Affiliate(
                        identifier = 'document-1', 
                        hotel_identifier = '', 
                        name = 'The Loveliest Hotel', 
                        local_name = 'Det Beste Hotellet', 
                        chain = 'Hotel chain', 
                        brand = 'Hotel brand', 
                        url_name = 'the-loveliest-hotel-new-york-united-states', 
                        star_rating = 4, 
                        bookings = 6054, 
                        aggregate_review_rating = 7.8, 
                        aggregate_greendex_rating = 7.0, 
                        total_reviews = 989, 
                        available = True, 
                        hotel_available = True, 
                        attractions = 5, 
                        recreations = 3, 
                        pois = 9, 
                        restaurants = 2, 
                        meeting_rooms = 2, 
                        spas = 1, 
                        add_ons = 5, 
                        location_category = '34', 
                        segment_category = '7', 
                        hotel_category = '45', 
                        architectural_style = '7', 
                        when_built = '1927', 
                        currency_code = 'USD', 
                        membership_rate_discount = 9, 
                        price_score = 9, 
                        perk_score = 4, 
                        package_score = 4, 
                        loyalty_score = 5, 
                        popular_score = 45, 
                        experience_score = 5, 
                        availability_score = 5, 
                        views = 10432, 
                        hotel_amenity_codes = ["1","7"], 
                        property_accessibility_codes = ["1","7"], 
                        property_security_codes = ["1","7"], 
                        number_of_rooms = 32, 
                        active = True, 
                        url_parameters = '', ), 
                    sort = 56, 
                    status = 'ACTIVE', ),
        )
        """

    def testStaticSellerListItemViewAffiliate(self):
        """Test StaticSellerListItemViewAffiliate"""
        # inst_req_only = self.make_instance(include_optional=False)
        # inst_req_and_optional = self.make_instance(include_optional=True)

if __name__ == '__main__':
    unittest.main()

from setuptools import setup, find_packages

setup(
    name="csdsfdbgfhgjk",
    version="0.1.0",
    author="dfghj",
    author_email="sathishdhuda25@gmail.com",
    description="sdfghj",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)

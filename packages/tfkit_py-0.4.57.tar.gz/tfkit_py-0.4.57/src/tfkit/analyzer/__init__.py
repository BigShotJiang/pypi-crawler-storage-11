"""Terraform project analysis module."""

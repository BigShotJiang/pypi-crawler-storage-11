# Nim's Django Helpers

[![Documentation Status](https://readthedocs.org/projects/ndh/badge/?version=latest)](https://ndh.readthedocs.io/en/latest/?badge=latest)
[![PyPI version](https://badge.fury.io/py/ndh.svg)](https://pypi.org/project/ndh)
[![Tests](https://github.com/nim65s/ndh/actions/workflows/test.yml/badge.svg)](https://github.com/nim65s/ndh/actions/workflows/test.yml)
[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/nim65s/ndh/master.svg)](https://results.pre-commit.ci/latest/github/nim65s/ndh/master)

[![codecov](https://codecov.io/gh/nim65s/ndh/branch/master/graph/badge.svg?token=BLGISGCYKG)](https://codecov.io/gh/nim65s/ndh)
[![Maintainability](https://api.codeclimate.com/v1/badges/6737a84239590ddc0d1e/maintainability)](https://codeclimate.com/github/nim65s/ndh/maintainability)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/charliermarsh/ruff/main/assets/badge/v1.json)](https://github.com/charliermarsh/ruff)

## Requirements

- Python 3.10+
- Django 4.0+
- [django-autoslug](https://github.com/justinmayer/django-autoslug)
- [django-bootstrap5](https://github.com/zostera/django-bootstrap5)

## Install

`python -m pip install ndh`

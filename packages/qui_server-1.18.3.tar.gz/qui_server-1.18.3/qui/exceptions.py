class QUIException(Exception):
    pass

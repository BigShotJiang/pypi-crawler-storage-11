# Copyright 2023 The KServe Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Client and server classes corresponding to protobuf-defined services."""
import grpc
import warnings

from kserve.protocol.grpc import grpc_predict_v2_pb2 as grpc__predict__v2__pb2

GRPC_GENERATED_VERSION = "1.64.1"
GRPC_VERSION = grpc.__version__
EXPECTED_ERROR_RELEASE = "1.65.0"
SCHEDULED_RELEASE_DATE = "June 25, 2024"
_version_not_supported = False

try:
    from grpc._utilities import first_version_is_lower

    _version_not_supported = first_version_is_lower(
        GRPC_VERSION, GRPC_GENERATED_VERSION
    )
except ImportError:
    _version_not_supported = True

if _version_not_supported:
    warnings.warn(
        f"The grpc package installed is at version {GRPC_VERSION},"
        + f" but the generated code in grpc_predict_v2_pb2_grpc.py depends on"
        + f" grpcio>={GRPC_GENERATED_VERSION}."
        + f" Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}"
        + f" or downgrade your generated code using grpcio-tools<={GRPC_VERSION}."
        + f" This warning will become an error in {EXPECTED_ERROR_RELEASE},"
        + f" scheduled for release on {SCHEDULED_RELEASE_DATE}.",
        RuntimeWarning,
    )


class GRPCInferenceServiceStub(object):
    """Inference Server GRPC endpoints."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.ServerLive = channel.unary_unary(
            "/inference.GRPCInferenceService/ServerLive",
            request_serializer=grpc__predict__v2__pb2.ServerLiveRequest.SerializeToString,
            response_deserializer=grpc__predict__v2__pb2.ServerLiveResponse.FromString,
            _registered_method=True,
        )
        self.ServerReady = channel.unary_unary(
            "/inference.GRPCInferenceService/ServerReady",
            request_serializer=grpc__predict__v2__pb2.ServerReadyRequest.SerializeToString,
            response_deserializer=grpc__predict__v2__pb2.ServerReadyResponse.FromString,
            _registered_method=True,
        )
        self.ModelReady = channel.unary_unary(
            "/inference.GRPCInferenceService/ModelReady",
            request_serializer=grpc__predict__v2__pb2.ModelReadyRequest.SerializeToString,
            response_deserializer=grpc__predict__v2__pb2.ModelReadyResponse.FromString,
            _registered_method=True,
        )
        self.ServerMetadata = channel.unary_unary(
            "/inference.GRPCInferenceService/ServerMetadata",
            request_serializer=grpc__predict__v2__pb2.ServerMetadataRequest.SerializeToString,
            response_deserializer=grpc__predict__v2__pb2.ServerMetadataResponse.FromString,
            _registered_method=True,
        )
        self.ModelMetadata = channel.unary_unary(
            "/inference.GRPCInferenceService/ModelMetadata",
            request_serializer=grpc__predict__v2__pb2.ModelMetadataRequest.SerializeToString,
            response_deserializer=grpc__predict__v2__pb2.ModelMetadataResponse.FromString,
            _registered_method=True,
        )
        self.ModelInfer = channel.unary_unary(
            "/inference.GRPCInferenceService/ModelInfer",
            request_serializer=grpc__predict__v2__pb2.ModelInferRequest.SerializeToString,
            response_deserializer=grpc__predict__v2__pb2.ModelInferResponse.FromString,
            _registered_method=True,
        )
        self.RepositoryModelLoad = channel.unary_unary(
            "/inference.GRPCInferenceService/RepositoryModelLoad",
            request_serializer=grpc__predict__v2__pb2.RepositoryModelLoadRequest.SerializeToString,
            response_deserializer=grpc__predict__v2__pb2.RepositoryModelLoadResponse.FromString,
            _registered_method=True,
        )
        self.RepositoryModelUnload = channel.unary_unary(
            "/inference.GRPCInferenceService/RepositoryModelUnload",
            request_serializer=grpc__predict__v2__pb2.RepositoryModelUnloadRequest.SerializeToString,
            response_deserializer=grpc__predict__v2__pb2.RepositoryModelUnloadResponse.FromString,
            _registered_method=True,
        )


class GRPCInferenceServiceServicer(object):
    """Inference Server GRPC endpoints."""

    def ServerLive(self, request, context):
        """The ServerLive API indicates if the inference server is able to receive
        and respond to metadata and inference requests.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def ServerReady(self, request, context):
        """The ServerReady API indicates if the server is ready for inferencing."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def ModelReady(self, request, context):
        """The ModelReady API indicates if a specific model is ready for inferencing."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def ServerMetadata(self, request, context):
        """The ServerMetadata API provides information about the server. Errors are
        indicated by the google.rpc.Status returned for the request. The OK code
        indicates success and other codes indicate failure.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def ModelMetadata(self, request, context):
        """The per-model metadata API provides information about a model. Errors are
        indicated by the google.rpc.Status returned for the request. The OK code
        indicates success and other codes indicate failure.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def ModelInfer(self, request, context):
        """The ModelInfer API performs inference using the specified model. Errors are
        indicated by the google.rpc.Status returned for the request. The OK code
        indicates success and other codes indicate failure.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def RepositoryModelLoad(self, request, context):
        """Load or reload a model from a repository."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def RepositoryModelUnload(self, request, context):
        """Unload a model."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")


def add_GRPCInferenceServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {
        "ServerLive": grpc.unary_unary_rpc_method_handler(
            servicer.ServerLive,
            request_deserializer=grpc__predict__v2__pb2.ServerLiveRequest.FromString,
            response_serializer=grpc__predict__v2__pb2.ServerLiveResponse.SerializeToString,
        ),
        "ServerReady": grpc.unary_unary_rpc_method_handler(
            servicer.ServerReady,
            request_deserializer=grpc__predict__v2__pb2.ServerReadyRequest.FromString,
            response_serializer=grpc__predict__v2__pb2.ServerReadyResponse.SerializeToString,
        ),
        "ModelReady": grpc.unary_unary_rpc_method_handler(
            servicer.ModelReady,
            request_deserializer=grpc__predict__v2__pb2.ModelReadyRequest.FromString,
            response_serializer=grpc__predict__v2__pb2.ModelReadyResponse.SerializeToString,
        ),
        "ServerMetadata": grpc.unary_unary_rpc_method_handler(
            servicer.ServerMetadata,
            request_deserializer=grpc__predict__v2__pb2.ServerMetadataRequest.FromString,
            response_serializer=grpc__predict__v2__pb2.ServerMetadataResponse.SerializeToString,
        ),
        "ModelMetadata": grpc.unary_unary_rpc_method_handler(
            servicer.ModelMetadata,
            request_deserializer=grpc__predict__v2__pb2.ModelMetadataRequest.FromString,
            response_serializer=grpc__predict__v2__pb2.ModelMetadataResponse.SerializeToString,
        ),
        "ModelInfer": grpc.unary_unary_rpc_method_handler(
            servicer.ModelInfer,
            request_deserializer=grpc__predict__v2__pb2.ModelInferRequest.FromString,
            response_serializer=grpc__predict__v2__pb2.ModelInferResponse.SerializeToString,
        ),
        "RepositoryModelLoad": grpc.unary_unary_rpc_method_handler(
            servicer.RepositoryModelLoad,
            request_deserializer=grpc__predict__v2__pb2.RepositoryModelLoadRequest.FromString,
            response_serializer=grpc__predict__v2__pb2.RepositoryModelLoadResponse.SerializeToString,
        ),
        "RepositoryModelUnload": grpc.unary_unary_rpc_method_handler(
            servicer.RepositoryModelUnload,
            request_deserializer=grpc__predict__v2__pb2.RepositoryModelUnloadRequest.FromString,
            response_serializer=grpc__predict__v2__pb2.RepositoryModelUnloadResponse.SerializeToString,
        ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
        "inference.GRPCInferenceService", rpc_method_handlers
    )
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers(
        "inference.GRPCInferenceService", rpc_method_handlers
    )


# This class is part of an EXPERIMENTAL API.
class GRPCInferenceService(object):
    """Inference Server GRPC endpoints."""

    @staticmethod
    def ServerLive(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/inference.GRPCInferenceService/ServerLive",
            grpc__predict__v2__pb2.ServerLiveRequest.SerializeToString,
            grpc__predict__v2__pb2.ServerLiveResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def ServerReady(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/inference.GRPCInferenceService/ServerReady",
            grpc__predict__v2__pb2.ServerReadyRequest.SerializeToString,
            grpc__predict__v2__pb2.ServerReadyResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def ModelReady(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/inference.GRPCInferenceService/ModelReady",
            grpc__predict__v2__pb2.ModelReadyRequest.SerializeToString,
            grpc__predict__v2__pb2.ModelReadyResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def ServerMetadata(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/inference.GRPCInferenceService/ServerMetadata",
            grpc__predict__v2__pb2.ServerMetadataRequest.SerializeToString,
            grpc__predict__v2__pb2.ServerMetadataResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def ModelMetadata(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/inference.GRPCInferenceService/ModelMetadata",
            grpc__predict__v2__pb2.ModelMetadataRequest.SerializeToString,
            grpc__predict__v2__pb2.ModelMetadataResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def ModelInfer(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/inference.GRPCInferenceService/ModelInfer",
            grpc__predict__v2__pb2.ModelInferRequest.SerializeToString,
            grpc__predict__v2__pb2.ModelInferResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def RepositoryModelLoad(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/inference.GRPCInferenceService/RepositoryModelLoad",
            grpc__predict__v2__pb2.RepositoryModelLoadRequest.SerializeToString,
            grpc__predict__v2__pb2.RepositoryModelLoadResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def RepositoryModelUnload(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/inference.GRPCInferenceService/RepositoryModelUnload",
            grpc__predict__v2__pb2.RepositoryModelUnloadRequest.SerializeToString,
            grpc__predict__v2__pb2.RepositoryModelUnloadResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

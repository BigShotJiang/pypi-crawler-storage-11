API EXAMPLES
============

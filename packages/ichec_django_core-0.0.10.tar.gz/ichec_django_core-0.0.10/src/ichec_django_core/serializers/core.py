from django.contrib.auth.models import Group
from rest_framework import serializers

SERIALIZER_BASE_FIELDS = ("id", "url", "created_at", "updated_at")


class GroupSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Group
        fields = ["url", "name", "id"]

from rest_framework import serializers
from django_countries.serializers import CountryFieldMixin

from ichec_django_core.models import Organization, Address

from .core import SERIALIZER_BASE_FIELDS


class AddressSerializer(CountryFieldMixin, serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Address
        fields = SERIALIZER_BASE_FIELDS + (
            "line1",
            "line2",
            "line3",
            "city",
            "region",
            "postcode",
            "country",
            "country_name",
            "country_flag",
        )
        read_only_fields = SERIALIZER_BASE_FIELDS + ("country_name", "country_flag")


class OrganizationBaseSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Organization
        fields = SERIALIZER_BASE_FIELDS + (
            "name",
            "acronym",
            "description",
            "address",
            "website",
            "members",
        )
        read_only_fields = SERIALIZER_BASE_FIELDS


class OrganizationListSerializer(OrganizationBaseSerializer):
    pass


class OrganizationDetailSerializer(OrganizationBaseSerializer):
    address = AddressSerializer()

    def create(self, validated_data):
        address_data = validated_data.pop("address")
        address = Address.objects.create(**address_data)
        return Organization.objects.create(address=address, **validated_data)

    def update(self, instance, validated_data):
        address_data = validated_data.pop("address")

        instance = super().update(instance, validated_data)
        for attr, value in address_data.items():
            setattr(instance.address, attr, value)
        return instance

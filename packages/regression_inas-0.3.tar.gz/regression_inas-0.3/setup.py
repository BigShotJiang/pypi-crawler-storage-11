from setuptools import setup, find_packages

setup(
    name="regression_inas",
    version="0.3",
    author="inas",
    author_email="i.soummar@esi-sba.dz",
    description="A simple linear regression model from scratch",
    packages=find_packages(),
    install_requires=[],
    license="MIT",
)

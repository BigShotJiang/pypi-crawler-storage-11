from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass
from datetime import datetime

@dataclass
class SDKConfig:
    api_key: str
    base_url: str = "https://api.inventpay.io"
    timeout: int = 30

@dataclass
class PaymentRequest:
    amount: float
    amount_currency: str = "USD"
    currency: str = "USDT_BEP20"
    order_id: Optional[str] = None
    description: Optional[str] = None
    callback_url: Optional[str] = None
    expiration_minutes: Optional[int] = None

@dataclass
class InvoiceRequest:
    amount: float
    amount_currency: str = "USD"
    order_id: Optional[str] = None
    description: Optional[str] = None
    callback_url: Optional[str] = None
    expiration_minutes: Optional[int] = None

@dataclass
class WithdrawalRequest:
    amount: float
    currency: str
    destination_address: str
    description: Optional[str] = None

@dataclass
class WebhookConfig:
    webhook_url: str

@dataclass
class PaymentResponse:
    success: bool
    data: Dict[str, Any]

@dataclass
class BalanceResponse:
    success: bool
    data: Dict[str, Any]

@dataclass
class WithdrawalResponse:
    success: bool
    data: Dict[str, Any]

@dataclass
class PaymentStatusResponse:
    status: str
    current_balance: str
    confirmations: int

@dataclass
class WebhookDelivery:
    id: str
    payment_id: str
    url: str
    http_status: Optional[int]
    attempts: int
    success: bool
    last_attempt_at: str
    created_at: str

@dataclass
class WebhookEvent:
    event: str
    timestamp: str
    data: Dict[str, Any]
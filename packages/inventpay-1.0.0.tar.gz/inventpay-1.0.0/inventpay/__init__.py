"""InventPay Python SDK - Accept crypto payments with ease."""

from .sdk import PaymentSDK
from .exceptions import PaymentSDKError, AuthenticationError, ValidationError, RateLimitError, ServerError
from .webhook import verify_webhook_signature, parse_webhook_event, get_supported_webhook_events
from .types import (
    SDKConfig,
    PaymentRequest,
    InvoiceRequest,
    WithdrawalRequest,
    WebhookConfig,
    PaymentResponse,
    BalanceResponse,
    WithdrawalResponse,
    PaymentStatusResponse,
    WebhookDelivery,
    WebhookEvent
)

__version__ = "1.0.0"
__author__ = "InventPay"
__email__ = "support@inventpay.io"

__all__ = [
    # Main SDK class
    "PaymentSDK",

    # Exceptions
    "PaymentSDKError",
    "AuthenticationError",
    "ValidationError",
    "RateLimitError",
    "ServerError",

    # Webhook utilities
    "verify_webhook_signature",
    "parse_webhook_event",
    "get_supported_webhook_events",

    # Configuration types
    "SDKConfig",
    "WebhookConfig",

    # Request types
    "PaymentRequest",
    "InvoiceRequest",
    "WithdrawalRequest",

    # Response types
    "PaymentResponse",
    "BalanceResponse",
    "WithdrawalResponse",
    "PaymentStatusResponse",

    # Webhook types
    "WebhookDelivery",
    "WebhookEvent",
]
"""Cell editors for Tabula Mutabilis table widget.

This module provides cell editing abstractions:
- AbstractCellEditor: Base class for cell editors
- SimpleTextCellEditor: Modal text editor with validation
"""

from __future__ import annotations

import abc
import tkinter as tk
from tkinter import ttk
from typing import Any, Callable, Optional

from vultus_serpentis.validation import ValidationResult, Validator


class AbstractCellEditor(abc.ABC):
    """Abstract base class for cell editors.

    Cell editors are responsible for showing a modal dialog to edit cell values.
    They must integrate with TTK Bootstrap themes and support validation.
    """

    def __init__(self, validator: Optional[Validator] = None) -> None:
        """Initialize the cell editor.

        Args:
            validator: Optional validator for input validation
        """
        self.validator = validator

    @abc.abstractmethod
    def show_modal(self, parent_window: tk.Tk, initial_value: Any) -> Optional[Any]:
        """Show a modal dialog to edit the cell value.

        Args:
            parent_window: The parent window (usually the table's toplevel)
            initial_value: The current cell value

        Returns:
            The new value if user confirms, None if cancelled
        """
        ...


class SimpleTextCellEditor(AbstractCellEditor):
    """A simple modal text editor for cell values.

    Shows a modal dialog with a text entry field, OK/Cancel buttons,
    and validation feedback.
    """

    def __init__(
        self,
        validator: Optional[Validator] = None,
        title: str = "Edit Cell",
        width: int = 300,
        height: int = 150,
    ) -> None:
        """Initialize the text cell editor.

        Args:
            validator: Optional validator for input
            title: Dialog window title
            width: Dialog width in pixels
            height: Dialog height in pixels
        """
        super().__init__(validator)
        self.title = title
        self.width = width
        self.height = height

    def show_modal(self, parent_window: tk.Tk, initial_value: Any) -> Optional[Any]:
        """Show the modal text editor dialog.

        Args:
            parent_window: Parent window for the dialog
            initial_value: Current cell value to edit

        Returns:
            New value if confirmed, None if cancelled
        """
        # Create modal dialog
        dialog = tk.Toplevel(parent_window)
        dialog.title(self.title)
        dialog.geometry(f"{self.width}x{self.height}")
        dialog.resizable(False, False)
        dialog.transient(parent_window)
        dialog.grab_set()

        # Center the dialog on parent
        dialog.withdraw()  # Hide while calculating position
        dialog.update_idletasks()

        parent_x = parent_window.winfo_rootx()
        parent_y = parent_window.winfo_rooty()
        parent_width = parent_window.winfo_width()
        parent_height = parent_window.winfo_height()

        x = parent_x + (parent_width // 2) - (self.width // 2)
        y = parent_y + (parent_height // 2) - (self.height // 2)

        dialog.geometry(f"+{x}+{y}")
        dialog.deiconify()

        # Result variable
        result = {"value": None, "confirmed": False}

        # Create UI components
        self._create_ui(dialog, initial_value, result)

        # Wait for dialog to close
        parent_window.wait_window(dialog)

        return result["value"] if result["confirmed"] else None

    def _create_ui(self, dialog: tk.Toplevel, initial_value: Any, result: dict) -> None:
        """Create the dialog user interface.

        Args:
            dialog: The dialog window
            initial_value: Initial value to display
            result: Dict to store the result
        """
        # Main frame with padding
        main_frame = ttk.Frame(dialog, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Label
        ttk.Label(main_frame, text="Value:").grid(row=0, column=0, sticky=tk.W, pady=(0, 5))

        # Entry field
        value_var = tk.StringVar(value=str(initial_value) if initial_value is not None else "")
        entry = ttk.Entry(main_frame, textvariable=value_var)
        entry.grid(row=1, column=0, columnspan=2, sticky=tk.EW, pady=(0, 10))
        entry.focus_set()
        entry.select_range(0, tk.END)

        # Validation feedback label (initially hidden)
        feedback_var = tk.StringVar()
        feedback_label = ttk.Label(main_frame, textvariable=feedback_var, foreground="red")
        feedback_label.grid(row=2, column=0, columnspan=2, sticky=tk.W, pady=(0, 10))
        feedback_label.grid_remove()  # Hide initially

        # Button frame with extra bottom padding
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=3, column=0, columnspan=2, sticky=tk.E, pady=(0, 10))

        # OK button
        ok_button = ttk.Button(
            button_frame,
            text="OK",
            command=lambda: self._on_ok(dialog, value_var.get(), result, feedback_var, feedback_label)
        )
        ok_button.pack(side=tk.RIGHT, padx=(5, 0))

        # Cancel button
        cancel_button = ttk.Button(
            button_frame,
            text="Cancel",
            command=lambda: self._on_cancel(dialog, result)
        )
        cancel_button.pack(side=tk.RIGHT)

        # Bind Enter key to OK
        dialog.bind(
            "<Return>",
            lambda e: self._on_ok(dialog, value_var.get(), result, feedback_var, feedback_label)
        )
        dialog.bind("<Escape>", lambda e: self._on_cancel(dialog, result))

    def _on_ok(
        self,
        dialog: tk.Toplevel,
        value_str: str,
        result: dict,
        feedback_var: tk.StringVar,
        feedback_label: ttk.Label
    ) -> None:
        """Handle OK button click.

        Args:
            dialog: The dialog window
            value_str: String value from entry
            result: Result dict to update
            feedback_var: Variable for feedback text
            feedback_label: Label for feedback display
        """
        # Validate input if validator is set
        if self.validator:
            try:
                # Try to convert string to appropriate type
                # For now, just validate the string
                validation_result = self.validator.validate(value_str)
                if not validation_result.is_valid:
                    feedback_var.set(validation_result.message)
                    feedback_label.grid()  # Show feedback
                    return
            except Exception as e:
                feedback_var.set(f"Validation error: {str(e)}")
                feedback_label.grid()
                return

        # Hide feedback if validation passed
        feedback_label.grid_remove()

        # Convert string back to appropriate type if possible
        value = self._convert_value(value_str)

        result["value"] = value
        result["confirmed"] = True
        dialog.destroy()

    def _on_cancel(self, dialog: tk.Toplevel, result: dict) -> None:
        """Handle Cancel button click.

        Args:
            dialog: The dialog window
            result: Result dict to update
        """
        result["confirmed"] = False
        dialog.destroy()

    def _convert_value(self, value_str: str) -> Any:
        """Convert string input to appropriate Python type.

        This is a simple conversion - in a real implementation,
        you might want more sophisticated type detection.

        Args:
            value_str: String value to convert

        Returns:
            Converted value
        """
        if not value_str.strip():
            return None

        # Try int
        try:
            return int(value_str)
        except ValueError:
            pass

        # Try float
        try:
            return float(value_str)
        except ValueError:
            pass

        # Try bool
        lower_str = value_str.lower()
        if lower_str in ('true', 'false'):
            return lower_str == 'true'

        # Default to string
        return value_str

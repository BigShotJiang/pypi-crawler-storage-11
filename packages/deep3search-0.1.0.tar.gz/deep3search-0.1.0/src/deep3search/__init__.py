def hello() -> str:
    return "Hello from deep3search!"

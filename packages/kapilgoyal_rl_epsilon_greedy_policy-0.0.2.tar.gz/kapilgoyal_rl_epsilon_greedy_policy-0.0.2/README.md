# RL Policy Package

A simple Python package from a Reinforcement Learning course assignment that implements an epsilon-greedy policy.

## Installation

```bash
pip install kapilgoyal-rl-epsilon-greedy-policy
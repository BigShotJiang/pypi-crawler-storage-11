import numpy as np

def epsilon_greedy_policy(q_values, epsilon):
    """
    Selects an action based on an epsilon-greedy policy.

    Args:
        q_values (list or numpy.ndarray): A list of Q-values for each action.
        epsilon (float): The probability of choosing a random action (exploration). 
                         Should be between 0 and 1.

    Returns:
        int: The index of the selected action.
    """
    if not 0 <= epsilon <= 1:
        raise ValueError("Epsilon must be between 0 and 1.")

    if np.random.rand() < epsilon:
        # Explore: choose a random action
        return np.random.randint(len(q_values))
    else:
        # Exploit: choose the action with the highest Q-value
        return np.argmax(q_values)

# Example Usage:
# Imagine we have 3 actions, and their estimated Q-values are [10, 25, 5]
q_values_example = [10, 25, 5]
epsilon_value = 0.1

# With a 10% chance, it will choose a random action (0, 1, or 2).
# With a 90% chance, it will choose action 1 (since it has the highest Q-value of 25).
selected_action = epsilon_greedy_policy(q_values_example, epsilon_value)
print(f"Selected action: {selected_action}")
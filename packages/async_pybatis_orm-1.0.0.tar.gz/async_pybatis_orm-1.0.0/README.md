# async-pybatis-orm

一个基于 MySQL 异步场景，对齐 MyBatis-Plus 语法风格的 Python ORM 框架。

专注于易用性与可扩展性，为从 Java MyBatis-Plus 转过来的开发者提供熟悉的 API。

## ✨ 特性

- 🚀 **异步支持**: 基于 asyncio 和 aiomysql，提供高性能异步操作
- 🎯 **MyBatis-Plus 风格**: 熟悉的 API 设计，降低学习成本
- 🔧 **灵活查询**: 链式条件构造器，支持复杂查询
- 📦 **完整 CRUD**: 提供 Insert、Update、Delete、Select 等完整操作
- 📄 **分页支持**: 内置分页功能，简单易用
- 🔒 **类型安全**: 支持 Python 类型注解

## 📦 安装

使用 pip 安装：

```bash
pip install async-pybatis-orm
```

或者从源码安装：

```bash
git clone https://github.com/lipop/async-pybatis-orm.git
cd async-pybatis-orm
pip install -e .
```

## 🚀 快速开始

### 1. 定义模型

```python
from datetime import datetime
from typing import Optional
from databases import Database
from async_pybatis_orm import CRUDModel, QueryWrapper
from async_pybatis_orm.base.database_manager import DatabaseAdapter
from async_pybatis_orm.fields import Field

# 定义数据库适配器
class DatabaseManager:
    _adapter: DatabaseAdapter = None

    @classmethod
    async def initialize(cls, database_url: str):
        database = Database(database_url)
        await database.connect()
        cls._adapter = DatabaseAdapter(database)
        return cls._adapter

# 定义模型
class User(CRUDModel):
    __table_meta__ = {"table_name": "users", "primary_key": "id"}

    id: int = Field(column_name="id")
    username: str = Field(column_name="user_name")
    email: Optional[str] = Field(column_name="email", nullable=True)
    age: Optional[int] = Field(column_name="age", nullable=True)
    status: str = Field(column_name="status", default="active")
    created_at: datetime = Field(column_name="created_at", default_factory=datetime.now)

    @classmethod
    async def _fetch_all(cls, sql: str, params: dict = None):
        cls._database = DatabaseManager._adapter
        return await cls._database.fetch_all(sql, params or {})

    @classmethod
    async def _execute(cls, sql: str, params):
        cls._database = DatabaseManager._adapter
        return await cls._database.execute(sql, params or {})
```

### 2. 初始化数据库连接

```python
import asyncio

async def init():
    db_url = "mysql+aiomysql://user:password@localhost:3306/dbname?min_size=5&max_size=20"
    await DatabaseManager.initialize(db_url)

asyncio.run(init())
```

### 3. 使用 CRUD 操作

```python
# 插入数据
user = User()
user.username = "test"
user.email = "test@example.com"
user.age = 18
await User.insert(user)

# 批量插入
users = [User(username=f"user{i}", age=20+i) for i in range(5)]
await User.batch_save(users)

# 查询数据
users = await User.select_list()
user = await User.select_by_id(1)
count = await User.select_count()

# 条件查询
wrapper = QueryWrapper().eq(User.username, "test").gt(User.age, 18)
users = await User.select_list(wrapper)

# 分页查询
from async_pybatis_orm.pagination import Page
page = Page(current=1, size=10)
result = await User.select_page(page)

# 更新数据
update_user = User()
update_user.id = 1
update_user.age = 25
await User.update_by_id(update_user)

# 条件更新
from async_pybatis_orm.wrapper import UpdateWrapper
await User.update_by_wrapper(
    UpdateWrapper()
    .eq(User.username, "test")
    .set(User.age, 25)
)

# 删除数据
await User.remove_by_id(1)

# 条件删除
wrapper = QueryWrapper().eq(User.status, "inactive")
await User.remove_by_wrapper(wrapper)
```

### 4. 链式查询

```python
# 复杂条件查询
wrapper = QueryWrapper() \
    .eq(User.status, "active") \
    .like(User.username, "admin") \
    .in_(User.age, [18, 19, 20]) \
    .between(User.created_at, "2023-01-01", "2023-12-31") \
    .order_by(User.id, desc=True) \
    .limit(10)

users = await User.select_list(wrapper)
```

## 📚 更多示例

查看 `example.py` 文件获取完整的测试示例。

## 🔧 开发

### 构建发布包

```bash
pip install build
python -m build
```

### 上传到 PyPI

```bash
pip install twine
twine upload dist/*
```

## 📄 许可证

MIT License

## 👤 作者

lipop

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
async-pybatis-orm

一个基于 MySQL 异步场景，对齐 MyBatis-Plus 语法风格的 Python ORM 框架。
专注于易用性与可扩展性，为从 Java MyBatis-Plus 转过来的开发者提供熟悉的API。
"""

# 核心基础层
from .base.base_model import BaseModel

# CRUD 功能层（Mixin 方式）
from .crud.crud_model import CRUDModel


# 条件构造器层
from .wrapper.query_wrapper import QueryWrapper

# MyBatis-Plus 风格的快捷导出，方便用户导入
__all__ = [
    # 基础模型
    "BaseModel", "CRUDModel",
    
    # 条件构造器
    "QueryWrapper",
]
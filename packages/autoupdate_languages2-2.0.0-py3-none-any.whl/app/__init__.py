"""AutoUpdate Languages 2 Package"""

from .core import AutoUpdateLanguages2

__version__ = "2.0.0"
__all__ = ['AutoUpdateLanguages2']
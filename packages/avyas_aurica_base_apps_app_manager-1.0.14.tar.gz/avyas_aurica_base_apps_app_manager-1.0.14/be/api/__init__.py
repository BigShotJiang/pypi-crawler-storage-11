# API module for app-manager

"""Tests for automated-changelog."""

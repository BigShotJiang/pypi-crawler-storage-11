
__version__ = '0.2.10'
from aliyun.log.version import USER_AGENT as SDK_USER_AGENT
USER_AGENT = 'log-cli-v-' + __version__ + ", " + SDK_USER_AGENT

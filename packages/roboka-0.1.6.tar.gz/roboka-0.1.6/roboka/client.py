import aiohttp
import asyncio
import time
import json

now = time.time()

class Update:
    def __init__(self, message_data, chat_id, client):
        self.text = message_data.get("text", "")
        self.message_id = message_data.get("message_id", None)
        self.sender_id = message_data.get("sender_id", None)
        self.chat_id = chat_id
        self.raw = message_data
        self._client = client

    async def reply(self, text: str):
        data = {"chat_id": self.chat_id, "text": text, "reply_to_message_id": self.message_id}
        return await self._client._request("sendMessage", data)

class WebhookUpdate:
    def __init__(self, inline_data, client):
        msg = inline_data.get("inline_message", {})
        self.text = msg.get("text", "")
        self.sender_id = msg.get("sender_id", "")
        self.message_id = msg.get("message_id", "")
        self.chat_id = msg.get("chat_id", "")
        self.aux_data = msg.get("aux_data", {})
        self.raw = msg
        self._client = client

    async def reply(self, text: str):
        data = {"chat_id": self.chat_id, "text": text, "reply_to_message_id": self.message_id}
        return await self._client._request("sendMessage", data)

class Client:
    def __init__(self, token: str):
        self.token = token
        self.session: aiohttp.ClientSession | None = None
        self._on_message_handler = None
        self._on_message_filter = None
        self._on_message_webhook_handler = None
        self._webhook_url = None
        self._running = False

    async def _request(self, method: str, data: dict, headers: dict | None = None):
        url = f"https://botapi.rubika.ir/v3/{self.token}/{method}"
        async with self.session.post(url, json=data, headers=headers) as resp:
            try:
                jsn = await resp.json()
                return jsn
            except Exception:
                try:
                    return await resp.text()
                except Exception:
                    return {}

    async def init(self):
        self.session = aiohttp.ClientSession()
        jsn = await self._request("getMe", {})
        if isinstance(jsn, dict) and jsn.get("status") != "INVALID_ACCESS":
            self.username = jsn["data"]["bot"]["username"]
            print(f"You have successfully logged in to the @{self.username} bot.\n")
            print("This library was created by the channel @roboka_library")
        else:
            raise ValueError(f"❌ Invalid token or connection issue: {jsn}")

    async def send_text(self, chat_id: str, text: str, message_id: str | None = None):
        data = {"chat_id": chat_id, "text": text}
        if message_id is not None:
            data["reply_to_message_id"] = message_id
        return await self._request("sendMessage", data)

    def on_message(self, func=None, filter=None):
        if func is None:
            def decorator(f):
                self._on_message_handler = f
                self._on_message_filter = filter
                return f
            return decorator
        else:
            self._on_message_handler = func
            self._on_message_filter = filter
            return func

    def on_message_webhook(self, url):
        def decorator(func):
            self._on_message_webhook_handler = func
            self._webhook_url = url
            return func
        return decorator

    async def run(self, limit: int = 100, pollers: int = 3):
        await self.init()
        tasks = []
        if self._on_message_handler:
            tasks.append(asyncio.create_task(self._run_polling(limit, pollers)))
        if self._on_message_webhook_handler and self._webhook_url:
            tasks.append(asyncio.create_task(self._run_webhook()))
        if tasks:
            await asyncio.gather(*tasks)

    async def _run_polling(self, limit: int, pollers: int):
        url = f"https://botapi.rubika.ir/v3/{self.token}/getUpdates"
        offset_id = None
        processed_messages: set = set()
        self._running = True

        async def poll_loop():
            nonlocal offset_id
            while self._running:
                try:
                    data = {"limit": limit, "timeout": 20}
                    if offset_id:
                        data["offset_id"] = offset_id
                    async with self.session.post(url, json=data, timeout=25) as resp:
                        try:
                            jsn = await resp.json()
                        except Exception:
                            jsn = {}
                        updates = jsn.get("data", {}).get("updates", [])
                        offset_id = jsn.get("data", {}).get("next_offset_id", offset_id)
                        for upd in updates:
                            new_msg = upd.get("new_message", {})
                            if not new_msg:
                                continue
                            tim = new_msg.get("time")
                            if tim is None or float(tim) < now:
                                continue
                            chat_id = upd.get("chat_id")
                            message_id = new_msg.get("message_id")
                            if not message_id or message_id in processed_messages:
                                continue
                            processed_messages.add(message_id)
                            if chat_id and isinstance(chat_id, str):
                                if chat_id.startswith("b"):
                                    chat_type = "private"
                                elif chat_id.startswith("g"):
                                    chat_type = "group"
                                elif chat_id.startswith("c"):
                                    chat_type = "channel"
                                else:
                                    chat_type = None
                            else:
                                chat_type = None
                            if self._on_message_filter and self._on_message_filter != chat_type:
                                continue
                            if self._on_message_handler:
                                update_obj = Update(new_msg, chat_id, client=self)
                                asyncio.create_task(self._on_message_handler(update_obj))
                except asyncio.CancelledError:
                    break
                except Exception:
                    await asyncio.sleep(0.05)

        async with asyncio.TaskGroup() as tg:
            for _ in range(max(1, pollers)):
                tg.create_task(poll_loop())

    async def _run_webhook(self):
        last = ""
        first = True
        while True:
            try:
                async with self.session.get(self._webhook_url, timeout=10) as r:
                    r.raise_for_status()
                    data = (await r.text()).strip()
                    if data and data != last:
                        last = data
                        if first:
                            first = False
                            continue
                        try:
                            jsn = json.loads(data)
                        except:
                            continue
                        if self._on_message_webhook_handler:
                            upd = WebhookUpdate(jsn, self)
                            asyncio.create_task(self._on_message_webhook_handler(upd))
            except Exception:
                await asyncio.sleep(2)
            await asyncio.sleep(2)

    async def create_keypad(self, chat_id: str, text: str, rows: list, message_id: str | None = None):
        data = {"chat_id": chat_id, "text": text, "chat_keypad_type": "New", "chat_keypad": {"rows": rows, "resize_keyboard": True, "on_time_keyboard": False}}
        if message_id is not None:
            data["reply_to_message_id"] = message_id
        return await self._request("sendMessage", data)

    async def send_poll(self, chat_id: str, question: str, options: list):
        data = {"chat_id": chat_id, "question": question, "options": options}
        return await self._request("sendPoll", data)

    async def send_location(self, chat_id: str, latitude: float, longitude: float, message_id: str | None = None):
        data = {"chat_id": chat_id, "latitude": latitude, "longitude": longitude}
        if message_id is not None:
            data["reply_to_message_id"] = message_id
        return await self._request("sendLocation", data)

    async def edit_text(self, chat_id: str, text: str, message_id: int):
        data = {"chat_id": chat_id, "message_id": message_id, "text": text}
        return await self._request("editMessageText", data)

    async def send_contact(self, chat_id: str, first_name: str, last_name: str, phone_number: str, message_id: int | None = None):
        data = {"chat_id": chat_id, "first_name": first_name, "last_name": last_name, "phone_number": phone_number}
        if message_id is not None:
            data["reply_to_message_id"] = message_id
        return await self._request("sendContact", data)

    async def get_chat(self, chat_id: str):
        return await self._request("getChat", {"chat_id": chat_id})

    async def forward_message(self, from_chat_id: str, message_id: int, to_chat_id: str):
        data = {"from_chat_id": from_chat_id, "message_id": message_id, "to_chat_id": to_chat_id}
        return await self._request("forwardMessage", data)

    async def delete_message(self, chat_id: str, message_id: int):
        data = {"chat_id": chat_id, "message_id": message_id}
        return await self._request("deleteMessage", data)

    async def create_inline_keypad(self, chat_id: str, text: str, rows: list, message_id: str | None = None):
        data = {"chat_id": chat_id, "text": text, "inline_keypad": {"rows": rows}}
        if message_id is not None:
            data["reply_to_message_id"] = message_id
        return await self._request("sendMessage", data)

    async def get_upload_url(self, type: str):
        res = await self._request("requestSendFile", {"type": type})
        return res.get("data", {}).get("upload_url")

    async def get_file_id(self, url: str, file_name: str, file_path: str):
        with open(file_path, "rb") as f:
            form = aiohttp.FormData()
            form.add_field("file", f, filename=file_name, content_type="application/octet-stream")
            async with self.session.post(url, data=form, ssl=False) as resp:
                try:
                    jsn = await resp.json()
                except Exception:
                    jsn = {}
                return jsn.get("data", {}).get("file_id")

    async def send_file(self, chat_id: str, text: str, file_name: str, file_path: str, file_type: str, message_id: str | None = None):
        upload_url = await self.get_upload_url(file_type)
        file_id = await self.get_file_id(upload_url, file_name, file_path)
        data = {"chat_id": chat_id, "file_id": file_id, "text": text}
        if message_id is not None:
            data["reply_to_message_id"] = message_id
        return await self._request("sendFile", data)

    async def send_image(self, chat_id: str, text: str, file_name: str, file_path: str, message_id: str | None = None):
        upload_url = await self.get_upload_url("Image")
        file_id = await self.get_file_id(upload_url, file_name, file_path)
        data = {"chat_id": chat_id, "file_id": file_id, "text": text}
        if message_id is not None:
            data["reply_to_message_id"] = message_id
        return await self._request("sendFile", data)

    async def send_video(self, chat_id: str, text: str, file_name: str, file_path: str, message_id: str | None = None):
        upload_url = await self.get_upload_url("Video")
        file_id = await self.get_file_id(upload_url, file_name, file_path)
        data = {"chat_id": chat_id, "file_id": file_id, "text": text}
        if message_id is not None:
            data["reply_to_message_id"] = message_id
        return await self._request("sendFile", data)

    async def get_updates(self, limit: int, offset_id: str | None = None):
        data = {"limit": limit}
        if offset_id is not None:
            data["offset_id"] = offset_id
        return await self._request("getUpdates", data)

    async def edit_keypad(self, chat_id: str, rows: list):
        data = {"chat_id": chat_id, "chat_keypad_type": "New", "chat_keypad": {"rows": rows, "resize_keyboard": True, "on_time_keyboard": False}}
        return await self._request("editChatKeypad", data)

    async def set_commands(self, commands: list):
        return await self._request("setCommands", {"bot_commands": commands})

    async def set_webhook(self, url: str, type: str):
        return await self._request("updateBotEndpoints", {"url": url, "type": type})

    async def close(self):
        self._running = False
        if self.session:
            await self.session.close()
.. These are examples of badges you might want to add to your README:
   please update the URLs accordingly

    .. image:: https://api.cirrus-ci.com/github/<USER>/config-core.svg?branch=main
        :alt: Built Status
        :target: https://cirrus-ci.com/github/<USER>/config-core
    .. image:: https://readthedocs.org/projects/config-core/badge/?version=latest
        :alt: ReadTheDocs
        :target: https://config-core.readthedocs.io/en/stable/
    .. image:: https://img.shields.io/coveralls/github/<USER>/config-core/main.svg
        :alt: Coveralls
        :target: https://coveralls.io/r/<USER>/config-core
    .. image:: https://img.shields.io/pypi/v/config-core.svg
        :alt: PyPI-Server
        :target: https://pypi.org/project/config-core/
    .. image:: https://img.shields.io/conda/vn/conda-forge/config-core.svg
        :alt: Conda-Forge
        :target: https://anaconda.org/conda-forge/config-core
    .. image:: https://pepy.tech/badge/config-core/month
        :alt: Monthly Downloads
        :target: https://pepy.tech/project/config-core
    .. image:: https://img.shields.io/twitter/url/http/shields.io.svg?style=social&label=Twitter
        :alt: Twitter
        :target: https://twitter.com/config-core

.. image:: https://img.shields.io/badge/-PyScaffold-005CA0?logo=pyscaffold
    :alt: Project generated with PyScaffold
    :target: https://pyscaffold.org/

|

===========
config-core
===========


    This is a opinionated way to parse a config.


This is a opinionated way to parse a config.
It requires `Pydantic` `BaseModel` config models.


.. _pyscaffold-notes:

Making Changes & Contributing
=============================

This project uses `pre-commit`_, please make sure to install it before making any
changes::

    pip install pre-commit
    cd config-core
    pre-commit install

It is a good idea to update the hooks to the latest version::

    pre-commit autoupdate

Don't forget to tell your contributors to also install and use pre-commit.

.. _pre-commit: https://pre-commit.com/

Note
====

This project has been set up using PyScaffold 4.6. For details and usage
information on PyScaffold see https://pyscaffold.org/.

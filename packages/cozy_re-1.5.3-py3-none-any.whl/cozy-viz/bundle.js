(() => {
  // http-url:https://unpkg.com/preact@latest?module
  var n;
  var l;
  var u;
  var t;
  var i;
  var r;
  var o;
  var e;
  var f;
  var c;
  var s;
  var a;
  var h;
  var p = {};
  var v = [];
  var y = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
  var w = Array.isArray;
  function d(n12, l11) {
    for (var u10 in l11)
      n12[u10] = l11[u10];
    return n12;
  }
  function g(n12) {
    n12 && n12.parentNode && n12.parentNode.removeChild(n12);
  }
  function _(l11, u10, t16) {
    var i11, r9, o12, e21 = {};
    for (o12 in u10)
      "key" == o12 ? i11 = u10[o12] : "ref" == o12 ? r9 = u10[o12] : e21[o12] = u10[o12];
    if (arguments.length > 2 && (e21.children = arguments.length > 3 ? n.call(arguments, 2) : t16), "function" == typeof l11 && null != l11.defaultProps)
      for (o12 in l11.defaultProps)
        void 0 === e21[o12] && (e21[o12] = l11.defaultProps[o12]);
    return m(l11, e21, i11, r9, null);
  }
  function m(n12, t16, i11, r9, o12) {
    var e21 = { type: n12, props: t16, key: i11, ref: r9, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: null == o12 ? ++u : o12, __i: -1, __u: 0 };
    return null == o12 && null != l.vnode && l.vnode(e21), e21;
  }
  function b() {
    return { current: null };
  }
  function k(n12) {
    return n12.children;
  }
  function x(n12, l11) {
    this.props = n12, this.context = l11;
  }
  function S(n12, l11) {
    if (null == l11)
      return n12.__ ? S(n12.__, n12.__i + 1) : null;
    for (var u10; l11 < n12.__k.length; l11++)
      if (null != (u10 = n12.__k[l11]) && null != u10.__e)
        return u10.__e;
    return "function" == typeof n12.type ? S(n12) : null;
  }
  function C(n12) {
    var l11, u10;
    if (null != (n12 = n12.__) && null != n12.__c) {
      for (n12.__e = n12.__c.base = null, l11 = 0; l11 < n12.__k.length; l11++)
        if (null != (u10 = n12.__k[l11]) && null != u10.__e) {
          n12.__e = n12.__c.base = u10.__e;
          break;
        }
      return C(n12);
    }
  }
  function M(n12) {
    (!n12.__d && (n12.__d = true) && i.push(n12) && !$.__r++ || r != l.debounceRendering) && ((r = l.debounceRendering) || o)($);
  }
  function $() {
    for (var n12, u10, t16, r9, o12, f11, c10, s11 = 1; i.length; )
      i.length > s11 && i.sort(e), n12 = i.shift(), s11 = i.length, n12.__d && (t16 = void 0, r9 = void 0, o12 = (r9 = (u10 = n12).__v).__e, f11 = [], c10 = [], u10.__P && ((t16 = d({}, r9)).__v = r9.__v + 1, l.vnode && l.vnode(t16), O(u10.__P, t16, r9, u10.__n, u10.__P.namespaceURI, 32 & r9.__u ? [o12] : null, f11, null == o12 ? S(r9) : o12, !!(32 & r9.__u), c10), t16.__v = r9.__v, t16.__.__k[t16.__i] = t16, N(f11, t16, c10), r9.__e = r9.__ = null, t16.__e != o12 && C(t16)));
    $.__r = 0;
  }
  function I(n12, l11, u10, t16, i11, r9, o12, e21, f11, c10, s11) {
    var a10, h10, y10, w11, d12, g9, _7, m12 = t16 && t16.__k || v, b11 = l11.length;
    for (f11 = P(u10, l11, m12, f11, b11), a10 = 0; a10 < b11; a10++)
      null != (y10 = u10.__k[a10]) && (h10 = -1 == y10.__i ? p : m12[y10.__i] || p, y10.__i = a10, g9 = O(n12, y10, h10, i11, r9, o12, e21, f11, c10, s11), w11 = y10.__e, y10.ref && h10.ref != y10.ref && (h10.ref && B(h10.ref, null, y10), s11.push(y10.ref, y10.__c || w11, y10)), null == d12 && null != w11 && (d12 = w11), (_7 = !!(4 & y10.__u)) || h10.__k === y10.__k ? f11 = A(y10, f11, n12, _7) : "function" == typeof y10.type && void 0 !== g9 ? f11 = g9 : w11 && (f11 = w11.nextSibling), y10.__u &= -7);
    return u10.__e = d12, f11;
  }
  function P(n12, l11, u10, t16, i11) {
    var r9, o12, e21, f11, c10, s11 = u10.length, a10 = s11, h10 = 0;
    for (n12.__k = new Array(i11), r9 = 0; r9 < i11; r9++)
      null != (o12 = l11[r9]) && "boolean" != typeof o12 && "function" != typeof o12 ? (f11 = r9 + h10, (o12 = n12.__k[r9] = "string" == typeof o12 || "number" == typeof o12 || "bigint" == typeof o12 || o12.constructor == String ? m(null, o12, null, null, null) : w(o12) ? m(k, { children: o12 }, null, null, null) : null == o12.constructor && o12.__b > 0 ? m(o12.type, o12.props, o12.key, o12.ref ? o12.ref : null, o12.__v) : o12).__ = n12, o12.__b = n12.__b + 1, e21 = null, -1 != (c10 = o12.__i = L(o12, u10, f11, a10)) && (a10--, (e21 = u10[c10]) && (e21.__u |= 2)), null == e21 || null == e21.__v ? (-1 == c10 && (i11 > s11 ? h10-- : i11 < s11 && h10++), "function" != typeof o12.type && (o12.__u |= 4)) : c10 != f11 && (c10 == f11 - 1 ? h10-- : c10 == f11 + 1 ? h10++ : (c10 > f11 ? h10-- : h10++, o12.__u |= 4))) : n12.__k[r9] = null;
    if (a10)
      for (r9 = 0; r9 < s11; r9++)
        null != (e21 = u10[r9]) && 0 == (2 & e21.__u) && (e21.__e == t16 && (t16 = S(e21)), D(e21, e21));
    return t16;
  }
  function A(n12, l11, u10, t16) {
    var i11, r9;
    if ("function" == typeof n12.type) {
      for (i11 = n12.__k, r9 = 0; i11 && r9 < i11.length; r9++)
        i11[r9] && (i11[r9].__ = n12, l11 = A(i11[r9], l11, u10, t16));
      return l11;
    }
    n12.__e != l11 && (t16 && (l11 && n12.type && !l11.parentNode && (l11 = S(n12)), u10.insertBefore(n12.__e, l11 || null)), l11 = n12.__e);
    do {
      l11 = l11 && l11.nextSibling;
    } while (null != l11 && 8 == l11.nodeType);
    return l11;
  }
  function L(n12, l11, u10, t16) {
    var i11, r9, o12, e21 = n12.key, f11 = n12.type, c10 = l11[u10], s11 = null != c10 && 0 == (2 & c10.__u);
    if (null === c10 && null == n12.key || s11 && e21 == c10.key && f11 == c10.type)
      return u10;
    if (t16 > (s11 ? 1 : 0)) {
      for (i11 = u10 - 1, r9 = u10 + 1; i11 >= 0 || r9 < l11.length; )
        if (null != (c10 = l11[o12 = i11 >= 0 ? i11-- : r9++]) && 0 == (2 & c10.__u) && e21 == c10.key && f11 == c10.type)
          return o12;
    }
    return -1;
  }
  function T(n12, l11, u10) {
    "-" == l11[0] ? n12.setProperty(l11, null == u10 ? "" : u10) : n12[l11] = null == u10 ? "" : "number" != typeof u10 || y.test(l11) ? u10 : u10 + "px";
  }
  function j(n12, l11, u10, t16, i11) {
    var r9, o12;
    n:
      if ("style" == l11)
        if ("string" == typeof u10)
          n12.style.cssText = u10;
        else {
          if ("string" == typeof t16 && (n12.style.cssText = t16 = ""), t16)
            for (l11 in t16)
              u10 && l11 in u10 || T(n12.style, l11, "");
          if (u10)
            for (l11 in u10)
              t16 && u10[l11] == t16[l11] || T(n12.style, l11, u10[l11]);
        }
      else if ("o" == l11[0] && "n" == l11[1])
        r9 = l11 != (l11 = l11.replace(f, "$1")), o12 = l11.toLowerCase(), l11 = o12 in n12 || "onFocusOut" == l11 || "onFocusIn" == l11 ? o12.slice(2) : l11.slice(2), n12.l || (n12.l = {}), n12.l[l11 + r9] = u10, u10 ? t16 ? u10.u = t16.u : (u10.u = c, n12.addEventListener(l11, r9 ? a : s, r9)) : n12.removeEventListener(l11, r9 ? a : s, r9);
      else {
        if ("http://www.w3.org/2000/svg" == i11)
          l11 = l11.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("width" != l11 && "height" != l11 && "href" != l11 && "list" != l11 && "form" != l11 && "tabIndex" != l11 && "download" != l11 && "rowSpan" != l11 && "colSpan" != l11 && "role" != l11 && "popover" != l11 && l11 in n12)
          try {
            n12[l11] = null == u10 ? "" : u10;
            break n;
          } catch (n13) {
          }
        "function" == typeof u10 || (null == u10 || false === u10 && "-" != l11[4] ? n12.removeAttribute(l11) : n12.setAttribute(l11, "popover" == l11 && 1 == u10 ? "" : u10));
      }
  }
  function F(n12) {
    return function(u10) {
      if (this.l) {
        var t16 = this.l[u10.type + n12];
        if (null == u10.t)
          u10.t = c++;
        else if (u10.t < t16.u)
          return;
        return t16(l.event ? l.event(u10) : u10);
      }
    };
  }
  function O(n12, u10, t16, i11, r9, o12, e21, f11, c10, s11) {
    var a10, h10, p10, v12, y10, _7, m12, b11, S8, C9, M9, $8, P10, A10, H8, L9, T9, j9 = u10.type;
    if (null != u10.constructor)
      return null;
    128 & t16.__u && (c10 = !!(32 & t16.__u), o12 = [f11 = u10.__e = t16.__e]), (a10 = l.__b) && a10(u10);
    n:
      if ("function" == typeof j9)
        try {
          if (b11 = u10.props, S8 = "prototype" in j9 && j9.prototype.render, C9 = (a10 = j9.contextType) && i11[a10.__c], M9 = a10 ? C9 ? C9.props.value : a10.__ : i11, t16.__c ? m12 = (h10 = u10.__c = t16.__c).__ = h10.__E : (S8 ? u10.__c = h10 = new j9(b11, M9) : (u10.__c = h10 = new x(b11, M9), h10.constructor = j9, h10.render = E), C9 && C9.sub(h10), h10.props = b11, h10.state || (h10.state = {}), h10.context = M9, h10.__n = i11, p10 = h10.__d = true, h10.__h = [], h10._sb = []), S8 && null == h10.__s && (h10.__s = h10.state), S8 && null != j9.getDerivedStateFromProps && (h10.__s == h10.state && (h10.__s = d({}, h10.__s)), d(h10.__s, j9.getDerivedStateFromProps(b11, h10.__s))), v12 = h10.props, y10 = h10.state, h10.__v = u10, p10)
            S8 && null == j9.getDerivedStateFromProps && null != h10.componentWillMount && h10.componentWillMount(), S8 && null != h10.componentDidMount && h10.__h.push(h10.componentDidMount);
          else {
            if (S8 && null == j9.getDerivedStateFromProps && b11 !== v12 && null != h10.componentWillReceiveProps && h10.componentWillReceiveProps(b11, M9), !h10.__e && null != h10.shouldComponentUpdate && false === h10.shouldComponentUpdate(b11, h10.__s, M9) || u10.__v == t16.__v) {
              for (u10.__v != t16.__v && (h10.props = b11, h10.state = h10.__s, h10.__d = false), u10.__e = t16.__e, u10.__k = t16.__k, u10.__k.some(function(n13) {
                n13 && (n13.__ = u10);
              }), $8 = 0; $8 < h10._sb.length; $8++)
                h10.__h.push(h10._sb[$8]);
              h10._sb = [], h10.__h.length && e21.push(h10);
              break n;
            }
            null != h10.componentWillUpdate && h10.componentWillUpdate(b11, h10.__s, M9), S8 && null != h10.componentDidUpdate && h10.__h.push(function() {
              h10.componentDidUpdate(v12, y10, _7);
            });
          }
          if (h10.context = M9, h10.props = b11, h10.__P = n12, h10.__e = false, P10 = l.__r, A10 = 0, S8) {
            for (h10.state = h10.__s, h10.__d = false, P10 && P10(u10), a10 = h10.render(h10.props, h10.state, h10.context), H8 = 0; H8 < h10._sb.length; H8++)
              h10.__h.push(h10._sb[H8]);
            h10._sb = [];
          } else
            do {
              h10.__d = false, P10 && P10(u10), a10 = h10.render(h10.props, h10.state, h10.context), h10.state = h10.__s;
            } while (h10.__d && ++A10 < 25);
          h10.state = h10.__s, null != h10.getChildContext && (i11 = d(d({}, i11), h10.getChildContext())), S8 && !p10 && null != h10.getSnapshotBeforeUpdate && (_7 = h10.getSnapshotBeforeUpdate(v12, y10)), L9 = a10, null != a10 && a10.type === k && null == a10.key && (L9 = V(a10.props.children)), f11 = I(n12, w(L9) ? L9 : [L9], u10, t16, i11, r9, o12, e21, f11, c10, s11), h10.base = u10.__e, u10.__u &= -161, h10.__h.length && e21.push(h10), m12 && (h10.__E = h10.__ = null);
        } catch (n13) {
          if (u10.__v = null, c10 || null != o12)
            if (n13.then) {
              for (u10.__u |= c10 ? 160 : 128; f11 && 8 == f11.nodeType && f11.nextSibling; )
                f11 = f11.nextSibling;
              o12[o12.indexOf(f11)] = null, u10.__e = f11;
            } else {
              for (T9 = o12.length; T9--; )
                g(o12[T9]);
              z(u10);
            }
          else
            u10.__e = t16.__e, u10.__k = t16.__k, n13.then || z(u10);
          l.__e(n13, u10, t16);
        }
      else
        null == o12 && u10.__v == t16.__v ? (u10.__k = t16.__k, u10.__e = t16.__e) : f11 = u10.__e = q(t16.__e, u10, t16, i11, r9, o12, e21, c10, s11);
    return (a10 = l.diffed) && a10(u10), 128 & u10.__u ? void 0 : f11;
  }
  function z(n12) {
    n12 && n12.__c && (n12.__c.__e = true), n12 && n12.__k && n12.__k.forEach(z);
  }
  function N(n12, u10, t16) {
    for (var i11 = 0; i11 < t16.length; i11++)
      B(t16[i11], t16[++i11], t16[++i11]);
    l.__c && l.__c(u10, n12), n12.some(function(u11) {
      try {
        n12 = u11.__h, u11.__h = [], n12.some(function(n13) {
          n13.call(u11);
        });
      } catch (n13) {
        l.__e(n13, u11.__v);
      }
    });
  }
  function V(n12) {
    return "object" != typeof n12 || null == n12 || n12.__b && n12.__b > 0 ? n12 : w(n12) ? n12.map(V) : d({}, n12);
  }
  function q(u10, t16, i11, r9, o12, e21, f11, c10, s11) {
    var a10, h10, v12, y10, d12, _7, m12, b11 = i11.props, k10 = t16.props, x10 = t16.type;
    if ("svg" == x10 ? o12 = "http://www.w3.org/2000/svg" : "math" == x10 ? o12 = "http://www.w3.org/1998/Math/MathML" : o12 || (o12 = "http://www.w3.org/1999/xhtml"), null != e21) {
      for (a10 = 0; a10 < e21.length; a10++)
        if ((d12 = e21[a10]) && "setAttribute" in d12 == !!x10 && (x10 ? d12.localName == x10 : 3 == d12.nodeType)) {
          u10 = d12, e21[a10] = null;
          break;
        }
    }
    if (null == u10) {
      if (null == x10)
        return document.createTextNode(k10);
      u10 = document.createElementNS(o12, x10, k10.is && k10), c10 && (l.__m && l.__m(t16, e21), c10 = false), e21 = null;
    }
    if (null == x10)
      b11 === k10 || c10 && u10.data == k10 || (u10.data = k10);
    else {
      if (e21 = e21 && n.call(u10.childNodes), b11 = i11.props || p, !c10 && null != e21)
        for (b11 = {}, a10 = 0; a10 < u10.attributes.length; a10++)
          b11[(d12 = u10.attributes[a10]).name] = d12.value;
      for (a10 in b11)
        if (d12 = b11[a10], "children" == a10)
          ;
        else if ("dangerouslySetInnerHTML" == a10)
          v12 = d12;
        else if (!(a10 in k10)) {
          if ("value" == a10 && "defaultValue" in k10 || "checked" == a10 && "defaultChecked" in k10)
            continue;
          j(u10, a10, null, d12, o12);
        }
      for (a10 in k10)
        d12 = k10[a10], "children" == a10 ? y10 = d12 : "dangerouslySetInnerHTML" == a10 ? h10 = d12 : "value" == a10 ? _7 = d12 : "checked" == a10 ? m12 = d12 : c10 && "function" != typeof d12 || b11[a10] === d12 || j(u10, a10, d12, b11[a10], o12);
      if (h10)
        c10 || v12 && (h10.__html == v12.__html || h10.__html == u10.innerHTML) || (u10.innerHTML = h10.__html), t16.__k = [];
      else if (v12 && (u10.innerHTML = ""), I("template" == t16.type ? u10.content : u10, w(y10) ? y10 : [y10], t16, i11, r9, "foreignObject" == x10 ? "http://www.w3.org/1999/xhtml" : o12, e21, f11, e21 ? e21[0] : i11.__k && S(i11, 0), c10, s11), null != e21)
        for (a10 = e21.length; a10--; )
          g(e21[a10]);
      c10 || (a10 = "value", "progress" == x10 && null == _7 ? u10.removeAttribute("value") : null != _7 && (_7 !== u10[a10] || "progress" == x10 && !_7 || "option" == x10 && _7 != b11[a10]) && j(u10, a10, _7, b11[a10], o12), a10 = "checked", null != m12 && m12 != u10[a10] && j(u10, a10, m12, b11[a10], o12));
    }
    return u10;
  }
  function B(n12, u10, t16) {
    try {
      if ("function" == typeof n12) {
        var i11 = "function" == typeof n12.__u;
        i11 && n12.__u(), i11 && null == u10 || (n12.__u = n12(u10));
      } else
        n12.current = u10;
    } catch (n13) {
      l.__e(n13, t16);
    }
  }
  function D(n12, u10, t16) {
    var i11, r9;
    if (l.unmount && l.unmount(n12), (i11 = n12.ref) && (i11.current && i11.current != n12.__e || B(i11, null, u10)), null != (i11 = n12.__c)) {
      if (i11.componentWillUnmount)
        try {
          i11.componentWillUnmount();
        } catch (n13) {
          l.__e(n13, u10);
        }
      i11.base = i11.__P = null;
    }
    if (i11 = n12.__k)
      for (r9 = 0; r9 < i11.length; r9++)
        i11[r9] && D(i11[r9], u10, t16 || "function" != typeof n12.type);
    t16 || g(n12.__e), n12.__c = n12.__ = n12.__e = void 0;
  }
  function E(n12, l11, u10) {
    return this.constructor(n12, u10);
  }
  function G(u10, t16, i11) {
    var r9, o12, e21, f11;
    t16 == document && (t16 = document.documentElement), l.__ && l.__(u10, t16), o12 = (r9 = "function" == typeof i11) ? null : i11 && i11.__k || t16.__k, e21 = [], f11 = [], O(t16, u10 = (!r9 && i11 || t16).__k = _(k, null, [u10]), o12 || p, p, t16.namespaceURI, !r9 && i11 ? [i11] : o12 ? null : t16.firstChild ? n.call(t16.childNodes) : null, e21, !r9 && i11 ? i11 : o12 ? o12.__e : t16.firstChild, r9, f11), N(e21, u10, f11);
  }
  n = v.slice, l = { __e: function(n12, l11, u10, t16) {
    for (var i11, r9, o12; l11 = l11.__; )
      if ((i11 = l11.__c) && !i11.__)
        try {
          if ((r9 = i11.constructor) && null != r9.getDerivedStateFromError && (i11.setState(r9.getDerivedStateFromError(n12)), o12 = i11.__d), null != i11.componentDidCatch && (i11.componentDidCatch(n12, t16 || {}), o12 = i11.__d), o12)
            return i11.__E = i11;
        } catch (l12) {
          n12 = l12;
        }
    throw n12;
  } }, u = 0, t = function(n12) {
    return null != n12 && null == n12.constructor;
  }, x.prototype.setState = function(n12, l11) {
    var u10;
    u10 = null != this.__s && this.__s != this.state ? this.__s : this.__s = d({}, this.state), "function" == typeof n12 && (n12 = n12(d({}, u10), this.props)), n12 && d(u10, n12), null != n12 && this.__v && (l11 && this._sb.push(l11), M(this));
  }, x.prototype.forceUpdate = function(n12) {
    this.__v && (this.__e = true, n12 && this.__h.push(n12), M(this));
  }, x.prototype.render = k, i = [], o = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, e = function(n12, l11) {
    return n12.__v.__b - l11.__v.__b;
  }, $.__r = 0, f = /(PointerCapture)$|Capture$/i, c = 0, s = F(false), a = F(true), h = 0;

  // http-url:https://unpkg.com/htm@latest?module
  var n2 = function(t16, s11, r9, e21) {
    var u10;
    s11[0] = 0;
    for (var h10 = 1; h10 < s11.length; h10++) {
      var p10 = s11[h10++], a10 = s11[h10] ? (s11[0] |= p10 ? 1 : 2, r9[s11[h10++]]) : s11[++h10];
      3 === p10 ? e21[0] = a10 : 4 === p10 ? e21[1] = Object.assign(e21[1] || {}, a10) : 5 === p10 ? (e21[1] = e21[1] || {})[s11[++h10]] = a10 : 6 === p10 ? e21[1][s11[++h10]] += a10 + "" : p10 ? (u10 = t16.apply(a10, n2(t16, a10, r9, ["", null])), e21.push(u10), a10[0] ? s11[0] |= 2 : (s11[h10 - 2] = 0, s11[h10] = u10)) : e21.push(a10);
    }
    return e21;
  };
  var t2 = /* @__PURE__ */ new Map();
  function htm_latest_module_default(s11) {
    var r9 = t2.get(this);
    return r9 || (r9 = /* @__PURE__ */ new Map(), t2.set(this, r9)), (r9 = n2(this, r9.get(s11) || (r9.set(s11, r9 = function(n12) {
      for (var t16, s12, r10 = 1, e21 = "", u10 = "", h10 = [0], p10 = function(n13) {
        1 === r10 && (n13 || (e21 = e21.replace(/^\s*\n\s*|\s*\n\s*$/g, ""))) ? h10.push(0, n13, e21) : 3 === r10 && (n13 || e21) ? (h10.push(3, n13, e21), r10 = 2) : 2 === r10 && "..." === e21 && n13 ? h10.push(4, n13, 0) : 2 === r10 && e21 && !n13 ? h10.push(5, 0, true, e21) : r10 >= 5 && ((e21 || !n13 && 5 === r10) && (h10.push(r10, 0, e21, s12), r10 = 6), n13 && (h10.push(r10, n13, 0, s12), r10 = 6)), e21 = "";
      }, a10 = 0; a10 < n12.length; a10++) {
        a10 && (1 === r10 && p10(), p10(a10));
        for (var l11 = 0; l11 < n12[a10].length; l11++)
          t16 = n12[a10][l11], 1 === r10 ? "<" === t16 ? (p10(), h10 = [h10], r10 = 3) : e21 += t16 : 4 === r10 ? "--" === e21 && ">" === t16 ? (r10 = 1, e21 = "") : e21 = t16 + e21[0] : u10 ? t16 === u10 ? u10 = "" : e21 += t16 : '"' === t16 || "'" === t16 ? u10 = t16 : ">" === t16 ? (p10(), r10 = 1) : r10 && ("=" === t16 ? (r10 = 5, s12 = e21, e21 = "") : "/" === t16 && (r10 < 5 || ">" === n12[a10][l11 + 1]) ? (p10(), 3 === r10 && (h10 = h10[0]), r10 = h10, (h10 = h10[0]).push(2, 0, r10), r10 = 0) : " " === t16 || "	" === t16 || "\n" === t16 || "\r" === t16 ? (p10(), r10 = 2) : e21 += t16), 3 === r10 && "!--" === e21 && (r10 = 4, h10 = h10[0]);
      }
      return p10(), h10;
    }(s11)), r9), arguments, [])).length > 1 ? r9 : r9[0];
  }

  // http-url:https://unpkg.com/htm/preact/index.module.js?module
  var m2 = htm_latest_module_default.bind(_);

  // http-url:https://cdn.jsdelivr.net/npm/lodash@4.17.21/debounce/+esm
  var t3 = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
  var n3 = function(t16) {
    var n12 = typeof t16;
    return null != t16 && ("object" == n12 || "function" == n12);
  };
  var e2 = "object" == typeof t3 && t3 && t3.Object === Object && t3;
  var r2 = "object" == typeof self && self && self.Object === Object && self;
  var o2 = e2 || r2 || Function("return this")();
  var i2 = o2;
  var u2 = function() {
    return i2.Date.now();
  };
  var f2 = /\s/;
  var a2 = function(t16) {
    for (var n12 = t16.length; n12-- && f2.test(t16.charAt(n12)); )
      ;
    return n12;
  };
  var c2 = /^\s+/;
  var l2 = function(t16) {
    return t16 ? t16.slice(0, a2(t16) + 1).replace(c2, "") : t16;
  };
  var v2 = o2.Symbol;
  var d2 = v2;
  var s2 = Object.prototype;
  var p2 = s2.hasOwnProperty;
  var b2 = s2.toString;
  var y2 = d2 ? d2.toStringTag : void 0;
  var g2 = function(t16) {
    var n12 = p2.call(t16, y2), e21 = t16[y2];
    try {
      t16[y2] = void 0;
      var r9 = true;
    } catch (t17) {
    }
    var o12 = b2.call(t16);
    return r9 && (n12 ? t16[y2] = e21 : delete t16[y2]), o12;
  };
  var j2 = Object.prototype.toString;
  var m3 = g2;
  var h2 = function(t16) {
    return j2.call(t16);
  };
  var T2 = v2 ? v2.toStringTag : void 0;
  var O2 = function(t16) {
    return null == t16 ? void 0 === t16 ? "[object Undefined]" : "[object Null]" : T2 && T2 in Object(t16) ? m3(t16) : h2(t16);
  };
  var w2 = function(t16) {
    return null != t16 && "object" == typeof t16;
  };
  var x2 = l2;
  var S2 = n3;
  var N2 = function(t16) {
    return "symbol" == typeof t16 || w2(t16) && "[object Symbol]" == O2(t16);
  };
  var $2 = /^[-+]0x[0-9a-f]+$/i;
  var E2 = /^0b[01]+$/i;
  var M2 = /^0o[0-7]+$/i;
  var W = parseInt;
  var A2 = n3;
  var D2 = u2;
  var F2 = function(t16) {
    if ("number" == typeof t16)
      return t16;
    if (N2(t16))
      return NaN;
    if (S2(t16)) {
      var n12 = "function" == typeof t16.valueOf ? t16.valueOf() : t16;
      t16 = S2(n12) ? n12 + "" : n12;
    }
    if ("string" != typeof t16)
      return 0 === t16 ? t16 : +t16;
    t16 = x2(t16);
    var e21 = E2.test(t16);
    return e21 || M2.test(t16) ? W(t16.slice(2), e21 ? 2 : 8) : $2.test(t16) ? NaN : +t16;
  };
  var I2 = Math.max;
  var P2 = Math.min;
  var U = function(t16, n12, e21) {
    var r9, o12, i11, u10, f11, a10, c10 = 0, l11 = false, v12 = false, d12 = true;
    if ("function" != typeof t16)
      throw new TypeError("Expected a function");
    function s11(n13) {
      var e22 = r9, i12 = o12;
      return r9 = o12 = void 0, c10 = n13, u10 = t16.apply(i12, e22);
    }
    function p10(t17) {
      var e22 = t17 - a10;
      return void 0 === a10 || e22 >= n12 || e22 < 0 || v12 && t17 - c10 >= i11;
    }
    function b11() {
      var t17 = D2();
      if (p10(t17))
        return y10(t17);
      f11 = setTimeout(b11, function(t18) {
        var e22 = n12 - (t18 - a10);
        return v12 ? P2(e22, i11 - (t18 - c10)) : e22;
      }(t17));
    }
    function y10(t17) {
      return f11 = void 0, d12 && r9 ? s11(t17) : (r9 = o12 = void 0, u10);
    }
    function g9() {
      var t17 = D2(), e22 = p10(t17);
      if (r9 = arguments, o12 = this, a10 = t17, e22) {
        if (void 0 === f11)
          return function(t18) {
            return c10 = t18, f11 = setTimeout(b11, n12), l11 ? s11(t18) : u10;
          }(a10);
        if (v12)
          return clearTimeout(f11), f11 = setTimeout(b11, n12), s11(a10);
      }
      return void 0 === f11 && (f11 = setTimeout(b11, n12)), u10;
    }
    return n12 = F2(n12) || 0, A2(e21) && (l11 = !!e21.leading, i11 = (v12 = "maxWait" in e21) ? I2(F2(e21.maxWait) || 0, n12) : i11, d12 = "trailing" in e21 ? !!e21.trailing : d12), g9.cancel = function() {
      void 0 !== f11 && clearTimeout(f11), c10 = 0, r9 = a10 = o12 = f11 = void 0;
    }, g9.flush = function() {
      return void 0 === f11 ? u10 : y10(D2());
    }, g9;
  };

  // http-url:https://cdn.jsdelivr.net/npm/heap@0.2.7/+esm
  var t4;
  var n4 = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
  var e3 = { exports: {} };
  t4 = e3, function() {
    var n12, e21, o12, r9, p10, u10, i11, l11, s11, f11, h10, c10, a10, y10, d12;
    o12 = Math.floor, f11 = Math.min, e21 = function(t16, n13) {
      return t16 < n13 ? -1 : t16 > n13 ? 1 : 0;
    }, s11 = function(t16, n13, r10, p11, u11) {
      var i12;
      if (null == r10 && (r10 = 0), null == u11 && (u11 = e21), r10 < 0)
        throw new Error("lo must be non-negative");
      for (null == p11 && (p11 = t16.length); r10 < p11; )
        u11(n13, t16[i12 = o12((r10 + p11) / 2)]) < 0 ? p11 = i12 : r10 = i12 + 1;
      return [].splice.apply(t16, [r10, r10 - r10].concat(n13)), n13;
    }, u10 = function(t16, n13, o13) {
      return null == o13 && (o13 = e21), t16.push(n13), y10(t16, 0, t16.length - 1, o13);
    }, p10 = function(t16, n13) {
      var o13, r10;
      return null == n13 && (n13 = e21), o13 = t16.pop(), t16.length ? (r10 = t16[0], t16[0] = o13, d12(t16, 0, n13)) : r10 = o13, r10;
    }, l11 = function(t16, n13, o13) {
      var r10;
      return null == o13 && (o13 = e21), r10 = t16[0], t16[0] = n13, d12(t16, 0, o13), r10;
    }, i11 = function(t16, n13, o13) {
      var r10;
      return null == o13 && (o13 = e21), t16.length && o13(t16[0], n13) < 0 && (n13 = (r10 = [t16[0], n13])[0], t16[0] = r10[1], d12(t16, 0, o13)), n13;
    }, r9 = function(t16, n13) {
      var r10, p11, u11, i12, l12, s12;
      for (null == n13 && (n13 = e21), l12 = [], p11 = 0, u11 = (i12 = function() {
        s12 = [];
        for (var n14 = 0, e22 = o12(t16.length / 2); 0 <= e22 ? n14 < e22 : n14 > e22; 0 <= e22 ? n14++ : n14--)
          s12.push(n14);
        return s12;
      }.apply(this).reverse()).length; p11 < u11; p11++)
        r10 = i12[p11], l12.push(d12(t16, r10, n13));
      return l12;
    }, a10 = function(t16, n13, o13) {
      var r10;
      if (null == o13 && (o13 = e21), -1 !== (r10 = t16.indexOf(n13)))
        return y10(t16, 0, r10, o13), d12(t16, r10, o13);
    }, h10 = function(t16, n13, o13) {
      var p11, u11, l12, s12, f12;
      if (null == o13 && (o13 = e21), !(u11 = t16.slice(0, n13)).length)
        return u11;
      for (r9(u11, o13), l12 = 0, s12 = (f12 = t16.slice(n13)).length; l12 < s12; l12++)
        p11 = f12[l12], i11(u11, p11, o13);
      return u11.sort(o13).reverse();
    }, c10 = function(t16, n13, o13) {
      var u11, i12, l12, h11, c11, a11, y11, d13, g9;
      if (null == o13 && (o13 = e21), 10 * n13 <= t16.length) {
        if (!(l12 = t16.slice(0, n13).sort(o13)).length)
          return l12;
        for (i12 = l12[l12.length - 1], h11 = 0, a11 = (y11 = t16.slice(n13)).length; h11 < a11; h11++)
          o13(u11 = y11[h11], i12) < 0 && (s11(l12, u11, 0, null, o13), l12.pop(), i12 = l12[l12.length - 1]);
        return l12;
      }
      for (r9(t16, o13), g9 = [], c11 = 0, d13 = f11(n13, t16.length); 0 <= d13 ? c11 < d13 : c11 > d13; 0 <= d13 ? ++c11 : --c11)
        g9.push(p10(t16, o13));
      return g9;
    }, y10 = function(t16, n13, o13, r10) {
      var p11, u11, i12;
      for (null == r10 && (r10 = e21), p11 = t16[o13]; o13 > n13 && r10(p11, u11 = t16[i12 = o13 - 1 >> 1]) < 0; )
        t16[o13] = u11, o13 = i12;
      return t16[o13] = p11;
    }, d12 = function(t16, n13, o13) {
      var r10, p11, u11, i12, l12;
      for (null == o13 && (o13 = e21), p11 = t16.length, l12 = n13, u11 = t16[n13], r10 = 2 * n13 + 1; r10 < p11; )
        (i12 = r10 + 1) < p11 && !(o13(t16[r10], t16[i12]) < 0) && (r10 = i12), t16[n13] = t16[r10], r10 = 2 * (n13 = r10) + 1;
      return t16[n13] = u11, y10(t16, l12, n13, o13);
    }, n12 = function() {
      function t16(t17) {
        this.cmp = null != t17 ? t17 : e21, this.nodes = [];
      }
      return t16.push = u10, t16.pop = p10, t16.replace = l11, t16.pushpop = i11, t16.heapify = r9, t16.updateItem = a10, t16.nlargest = h10, t16.nsmallest = c10, t16.prototype.push = function(t17) {
        return u10(this.nodes, t17, this.cmp);
      }, t16.prototype.pop = function() {
        return p10(this.nodes, this.cmp);
      }, t16.prototype.peek = function() {
        return this.nodes[0];
      }, t16.prototype.contains = function(t17) {
        return -1 !== this.nodes.indexOf(t17);
      }, t16.prototype.replace = function(t17) {
        return l11(this.nodes, t17, this.cmp);
      }, t16.prototype.pushpop = function(t17) {
        return i11(this.nodes, t17, this.cmp);
      }, t16.prototype.heapify = function() {
        return r9(this.nodes, this.cmp);
      }, t16.prototype.updateItem = function(t17) {
        return a10(this.nodes, t17, this.cmp);
      }, t16.prototype.clear = function() {
        return this.nodes = [];
      }, t16.prototype.empty = function() {
        return 0 === this.nodes.length;
      }, t16.prototype.size = function() {
        return this.nodes.length;
      }, t16.prototype.clone = function() {
        var n13;
        return (n13 = new t16()).nodes = this.nodes.slice(0), n13;
      }, t16.prototype.toArray = function() {
        return this.nodes.slice(0);
      }, t16.prototype.insert = t16.prototype.push, t16.prototype.top = t16.prototype.peek, t16.prototype.front = t16.prototype.peek, t16.prototype.has = t16.prototype.contains, t16.prototype.copy = t16.prototype.clone, t16;
    }(), t4.exports = n12;
  }.call(n4);
  var o3 = e3.exports;

  // http-url:https://cdn.jsdelivr.net/npm/lodash@4.17.21/get/+esm
  var t5 = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
  var r3 = Array.isArray;
  var n5 = "object" == typeof t5 && t5 && t5.Object === Object && t5;
  var e4 = "object" == typeof self && self && self.Object === Object && self;
  var o4 = n5 || e4 || Function("return this")();
  var a3 = o4.Symbol;
  var i3 = a3;
  var u3 = Object.prototype;
  var c3 = u3.hasOwnProperty;
  var s3 = u3.toString;
  var l3 = i3 ? i3.toStringTag : void 0;
  var f3 = function(t16) {
    var r9 = c3.call(t16, l3), n12 = t16[l3];
    try {
      t16[l3] = void 0;
      var e21 = true;
    } catch (t17) {
    }
    var o12 = s3.call(t16);
    return e21 && (r9 ? t16[l3] = n12 : delete t16[l3]), o12;
  };
  var v3 = Object.prototype.toString;
  var p3 = f3;
  var h3 = function(t16) {
    return v3.call(t16);
  };
  var _2 = a3 ? a3.toStringTag : void 0;
  var y3 = function(t16) {
    return null == t16 ? void 0 === t16 ? "[object Undefined]" : "[object Null]" : _2 && _2 in Object(t16) ? p3(t16) : h3(t16);
  };
  var d4 = y3;
  var b3 = function(t16) {
    return null != t16 && "object" == typeof t16;
  };
  var g3 = function(t16) {
    return "symbol" == typeof t16 || b3(t16) && "[object Symbol]" == d4(t16);
  };
  var j3 = r3;
  var O3 = g3;
  var w3 = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
  var z2 = /^\w*$/;
  var m4 = function(t16, r9) {
    if (j3(t16))
      return false;
    var n12 = typeof t16;
    return !("number" != n12 && "symbol" != n12 && "boolean" != n12 && null != t16 && !O3(t16)) || (z2.test(t16) || !w3.test(t16) || null != r9 && t16 in Object(r9));
  };
  var S3 = function(t16) {
    var r9 = typeof t16;
    return null != t16 && ("object" == r9 || "function" == r9);
  };
  var $3 = y3;
  var P3 = S3;
  var A3;
  var F3 = function(t16) {
    if (!P3(t16))
      return false;
    var r9 = $3(t16);
    return "[object Function]" == r9 || "[object GeneratorFunction]" == r9 || "[object AsyncFunction]" == r9 || "[object Proxy]" == r9;
  };
  var T3 = o4["__core-js_shared__"];
  var x3 = (A3 = /[^.]+$/.exec(T3 && T3.keys && T3.keys.IE_PROTO || "")) ? "Symbol(src)_1." + A3 : "";
  var C2 = function(t16) {
    return !!x3 && x3 in t16;
  };
  var E3 = Function.prototype.toString;
  var k2 = F3;
  var R = C2;
  var G2 = S3;
  var I3 = function(t16) {
    if (null != t16) {
      try {
        return E3.call(t16);
      } catch (t17) {
      }
      try {
        return t16 + "";
      } catch (t17) {
      }
    }
    return "";
  };
  var M3 = /^\[object .+?Constructor\]$/;
  var N3 = Function.prototype;
  var U2 = Object.prototype;
  var q2 = N3.toString;
  var B2 = U2.hasOwnProperty;
  var D3 = RegExp("^" + q2.call(B2).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
  var H = function(t16) {
    return !(!G2(t16) || R(t16)) && (k2(t16) ? D3 : M3).test(I3(t16));
  };
  var J = function(t16, r9) {
    return null == t16 ? void 0 : t16[r9];
  };
  var K = function(t16, r9) {
    var n12 = J(t16, r9);
    return H(n12) ? n12 : void 0;
  };
  var L2 = K(Object, "create");
  var Q = L2;
  var V2 = function() {
    this.__data__ = Q ? Q(null) : {}, this.size = 0;
  };
  var W2 = function(t16) {
    var r9 = this.has(t16) && delete this.__data__[t16];
    return this.size -= r9 ? 1 : 0, r9;
  };
  var X = L2;
  var Y = Object.prototype.hasOwnProperty;
  var Z = function(t16) {
    var r9 = this.__data__;
    if (X) {
      var n12 = r9[t16];
      return "__lodash_hash_undefined__" === n12 ? void 0 : n12;
    }
    return Y.call(r9, t16) ? r9[t16] : void 0;
  };
  var tt = L2;
  var rt = Object.prototype.hasOwnProperty;
  var nt = L2;
  var et = V2;
  var ot = W2;
  var at = Z;
  var it = function(t16) {
    var r9 = this.__data__;
    return tt ? void 0 !== r9[t16] : rt.call(r9, t16);
  };
  var ut = function(t16, r9) {
    var n12 = this.__data__;
    return this.size += this.has(t16) ? 0 : 1, n12[t16] = nt && void 0 === r9 ? "__lodash_hash_undefined__" : r9, this;
  };
  function ct(t16) {
    var r9 = -1, n12 = null == t16 ? 0 : t16.length;
    for (this.clear(); ++r9 < n12; ) {
      var e21 = t16[r9];
      this.set(e21[0], e21[1]);
    }
  }
  ct.prototype.clear = et, ct.prototype.delete = ot, ct.prototype.get = at, ct.prototype.has = it, ct.prototype.set = ut;
  var st = ct;
  var lt = function() {
    this.__data__ = [], this.size = 0;
  };
  var ft = function(t16, r9) {
    return t16 === r9 || t16 != t16 && r9 != r9;
  };
  var vt = function(t16, r9) {
    for (var n12 = t16.length; n12--; )
      if (ft(t16[n12][0], r9))
        return n12;
    return -1;
  };
  var pt = vt;
  var ht = Array.prototype.splice;
  var _t = vt;
  var yt = vt;
  var dt = vt;
  var bt = lt;
  var gt = function(t16) {
    var r9 = this.__data__, n12 = pt(r9, t16);
    return !(n12 < 0) && (n12 == r9.length - 1 ? r9.pop() : ht.call(r9, n12, 1), --this.size, true);
  };
  var jt = function(t16) {
    var r9 = this.__data__, n12 = _t(r9, t16);
    return n12 < 0 ? void 0 : r9[n12][1];
  };
  var Ot = function(t16) {
    return yt(this.__data__, t16) > -1;
  };
  var wt = function(t16, r9) {
    var n12 = this.__data__, e21 = dt(n12, t16);
    return e21 < 0 ? (++this.size, n12.push([t16, r9])) : n12[e21][1] = r9, this;
  };
  function zt(t16) {
    var r9 = -1, n12 = null == t16 ? 0 : t16.length;
    for (this.clear(); ++r9 < n12; ) {
      var e21 = t16[r9];
      this.set(e21[0], e21[1]);
    }
  }
  zt.prototype.clear = bt, zt.prototype.delete = gt, zt.prototype.get = jt, zt.prototype.has = Ot, zt.prototype.set = wt;
  var mt = zt;
  var St = K(o4, "Map");
  var $t = st;
  var Pt = mt;
  var At = St;
  var Ft = function(t16) {
    var r9 = typeof t16;
    return "string" == r9 || "number" == r9 || "symbol" == r9 || "boolean" == r9 ? "__proto__" !== t16 : null === t16;
  };
  var Tt = function(t16, r9) {
    var n12 = t16.__data__;
    return Ft(r9) ? n12["string" == typeof r9 ? "string" : "hash"] : n12.map;
  };
  var xt = Tt;
  var Ct = Tt;
  var Et = Tt;
  var kt = Tt;
  var Rt = function() {
    this.size = 0, this.__data__ = { hash: new $t(), map: new (At || Pt)(), string: new $t() };
  };
  var Gt = function(t16) {
    var r9 = xt(this, t16).delete(t16);
    return this.size -= r9 ? 1 : 0, r9;
  };
  var It = function(t16) {
    return Ct(this, t16).get(t16);
  };
  var Mt = function(t16) {
    return Et(this, t16).has(t16);
  };
  var Nt = function(t16, r9) {
    var n12 = kt(this, t16), e21 = n12.size;
    return n12.set(t16, r9), this.size += n12.size == e21 ? 0 : 1, this;
  };
  function Ut(t16) {
    var r9 = -1, n12 = null == t16 ? 0 : t16.length;
    for (this.clear(); ++r9 < n12; ) {
      var e21 = t16[r9];
      this.set(e21[0], e21[1]);
    }
  }
  Ut.prototype.clear = Rt, Ut.prototype.delete = Gt, Ut.prototype.get = It, Ut.prototype.has = Mt, Ut.prototype.set = Nt;
  var qt = Ut;
  function Bt(t16, r9) {
    if ("function" != typeof t16 || null != r9 && "function" != typeof r9)
      throw new TypeError("Expected a function");
    var n12 = function() {
      var e21 = arguments, o12 = r9 ? r9.apply(this, e21) : e21[0], a10 = n12.cache;
      if (a10.has(o12))
        return a10.get(o12);
      var i11 = t16.apply(this, e21);
      return n12.cache = a10.set(o12, i11) || a10, i11;
    };
    return n12.cache = new (Bt.Cache || qt)(), n12;
  }
  Bt.Cache = qt;
  var Dt = Bt;
  var Ht = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
  var Jt = /\\(\\)?/g;
  var Kt = function(t16) {
    var r9 = Dt(t16, function(t17) {
      return 500 === n12.size && n12.clear(), t17;
    }), n12 = r9.cache;
    return r9;
  }(function(t16) {
    var r9 = [];
    return 46 === t16.charCodeAt(0) && r9.push(""), t16.replace(Ht, function(t17, n12, e21, o12) {
      r9.push(e21 ? o12.replace(Jt, "$1") : n12 || t17);
    }), r9;
  });
  var Lt = function(t16, r9) {
    for (var n12 = -1, e21 = null == t16 ? 0 : t16.length, o12 = Array(e21); ++n12 < e21; )
      o12[n12] = r9(t16[n12], n12, t16);
    return o12;
  };
  var Qt = r3;
  var Vt = g3;
  var Wt = a3 ? a3.prototype : void 0;
  var Xt = Wt ? Wt.toString : void 0;
  var Yt = function t6(r9) {
    if ("string" == typeof r9)
      return r9;
    if (Qt(r9))
      return Lt(r9, t6) + "";
    if (Vt(r9))
      return Xt ? Xt.call(r9) : "";
    var n12 = r9 + "";
    return "0" == n12 && 1 / r9 == -1 / 0 ? "-0" : n12;
  };
  var Zt = Yt;
  var tr = r3;
  var rr = m4;
  var nr = Kt;
  var er = function(t16) {
    return null == t16 ? "" : Zt(t16);
  };
  var or = g3;
  var ar = function(t16, r9) {
    return tr(t16) ? t16 : rr(t16, r9) ? [t16] : nr(er(t16));
  };
  var ir = function(t16) {
    if ("string" == typeof t16 || or(t16))
      return t16;
    var r9 = t16 + "";
    return "0" == r9 && 1 / t16 == -1 / 0 ? "-0" : r9;
  };
  var ur = function(t16, r9) {
    for (var n12 = 0, e21 = (r9 = ar(r9, t16)).length; null != t16 && n12 < e21; )
      t16 = t16[ir(r9[n12++])];
    return n12 && n12 == e21 ? t16 : void 0;
  };
  var cr = function(t16, r9, n12) {
    var e21 = null == t16 ? void 0 : ur(t16, r9);
    return void 0 === e21 ? n12 : e21;
  };

  // http-url:https://cdn.jsdelivr.net/npm/lodash@4.17.21/set/+esm
  var t7 = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
  var r4 = "object" == typeof t7 && t7 && t7.Object === Object && t7;
  var e5 = "object" == typeof self && self && self.Object === Object && self;
  var n6 = r4 || e5 || Function("return this")();
  var o5 = n6.Symbol;
  var a4 = o5;
  var i4 = Object.prototype;
  var u4 = i4.hasOwnProperty;
  var c4 = i4.toString;
  var l4 = a4 ? a4.toStringTag : void 0;
  var s4 = function(t16) {
    var r9 = u4.call(t16, l4), e21 = t16[l4];
    try {
      t16[l4] = void 0;
      var n12 = true;
    } catch (t17) {
    }
    var o12 = c4.call(t16);
    return n12 && (r9 ? t16[l4] = e21 : delete t16[l4]), o12;
  };
  var f4 = Object.prototype.toString;
  var v4 = s4;
  var p4 = function(t16) {
    return f4.call(t16);
  };
  var h4 = o5 ? o5.toStringTag : void 0;
  var _3 = function(t16) {
    return null == t16 ? void 0 === t16 ? "[object Undefined]" : "[object Null]" : h4 && h4 in Object(t16) ? v4(t16) : p4(t16);
  };
  var y4 = function(t16) {
    var r9 = typeof t16;
    return null != t16 && ("object" == r9 || "function" == r9);
  };
  var d5 = _3;
  var b4 = y4;
  var g4;
  var j4 = function(t16) {
    if (!b4(t16))
      return false;
    var r9 = d5(t16);
    return "[object Function]" == r9 || "[object GeneratorFunction]" == r9 || "[object AsyncFunction]" == r9 || "[object Proxy]" == r9;
  };
  var O4 = n6["__core-js_shared__"];
  var w4 = (g4 = /[^.]+$/.exec(O4 && O4.keys && O4.keys.IE_PROTO || "")) ? "Symbol(src)_1." + g4 : "";
  var m5 = function(t16) {
    return !!w4 && w4 in t16;
  };
  var z3 = Function.prototype.toString;
  var S4 = j4;
  var $4 = m5;
  var P4 = y4;
  var A4 = function(t16) {
    if (null != t16) {
      try {
        return z3.call(t16);
      } catch (t17) {
      }
      try {
        return t16 + "";
      } catch (t17) {
      }
    }
    return "";
  };
  var F4 = /^\[object .+?Constructor\]$/;
  var T4 = Function.prototype;
  var x4 = Object.prototype;
  var C3 = T4.toString;
  var E4 = x4.hasOwnProperty;
  var k3 = RegExp("^" + C3.call(E4).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
  var R2 = function(t16) {
    return !(!P4(t16) || $4(t16)) && (S4(t16) ? k3 : F4).test(A4(t16));
  };
  var G3 = function(t16, r9) {
    return null == t16 ? void 0 : t16[r9];
  };
  var I4 = function(t16, r9) {
    var e21 = G3(t16, r9);
    return R2(e21) ? e21 : void 0;
  };
  var M4 = I4;
  var N4 = function() {
    try {
      var t16 = M4(Object, "defineProperty");
      return t16({}, "", {}), t16;
    } catch (t17) {
    }
  }();
  var U3 = function(t16, r9) {
    return t16 === r9 || t16 != t16 && r9 != r9;
  };
  var q3 = function(t16, r9, e21) {
    "__proto__" == r9 && N4 ? N4(t16, r9, { configurable: true, enumerable: true, value: e21, writable: true }) : t16[r9] = e21;
  };
  var B3 = U3;
  var D4 = Object.prototype.hasOwnProperty;
  var H2 = function(t16, r9, e21) {
    var n12 = t16[r9];
    D4.call(t16, r9) && B3(n12, e21) && (void 0 !== e21 || r9 in t16) || q3(t16, r9, e21);
  };
  var J2 = Array.isArray;
  var K2 = _3;
  var L3 = function(t16) {
    return null != t16 && "object" == typeof t16;
  };
  var Q2 = function(t16) {
    return "symbol" == typeof t16 || L3(t16) && "[object Symbol]" == K2(t16);
  };
  var V3 = J2;
  var W3 = Q2;
  var X2 = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
  var Y2 = /^\w*$/;
  var Z2 = function(t16, r9) {
    if (V3(t16))
      return false;
    var e21 = typeof t16;
    return !("number" != e21 && "symbol" != e21 && "boolean" != e21 && null != t16 && !W3(t16)) || (Y2.test(t16) || !X2.test(t16) || null != r9 && t16 in Object(r9));
  };
  var tt2 = I4(Object, "create");
  var rt2 = tt2;
  var et2 = function() {
    this.__data__ = rt2 ? rt2(null) : {}, this.size = 0;
  };
  var nt2 = function(t16) {
    var r9 = this.has(t16) && delete this.__data__[t16];
    return this.size -= r9 ? 1 : 0, r9;
  };
  var ot2 = tt2;
  var at2 = Object.prototype.hasOwnProperty;
  var it2 = function(t16) {
    var r9 = this.__data__;
    if (ot2) {
      var e21 = r9[t16];
      return "__lodash_hash_undefined__" === e21 ? void 0 : e21;
    }
    return at2.call(r9, t16) ? r9[t16] : void 0;
  };
  var ut2 = tt2;
  var ct2 = Object.prototype.hasOwnProperty;
  var lt2 = tt2;
  var st2 = et2;
  var ft2 = nt2;
  var vt2 = it2;
  var pt2 = function(t16) {
    var r9 = this.__data__;
    return ut2 ? void 0 !== r9[t16] : ct2.call(r9, t16);
  };
  var ht2 = function(t16, r9) {
    var e21 = this.__data__;
    return this.size += this.has(t16) ? 0 : 1, e21[t16] = lt2 && void 0 === r9 ? "__lodash_hash_undefined__" : r9, this;
  };
  function _t2(t16) {
    var r9 = -1, e21 = null == t16 ? 0 : t16.length;
    for (this.clear(); ++r9 < e21; ) {
      var n12 = t16[r9];
      this.set(n12[0], n12[1]);
    }
  }
  _t2.prototype.clear = st2, _t2.prototype.delete = ft2, _t2.prototype.get = vt2, _t2.prototype.has = pt2, _t2.prototype.set = ht2;
  var yt2 = _t2;
  var dt2 = function() {
    this.__data__ = [], this.size = 0;
  };
  var bt2 = U3;
  var gt2 = function(t16, r9) {
    for (var e21 = t16.length; e21--; )
      if (bt2(t16[e21][0], r9))
        return e21;
    return -1;
  };
  var jt2 = gt2;
  var Ot2 = Array.prototype.splice;
  var wt2 = gt2;
  var mt2 = gt2;
  var zt2 = gt2;
  var St2 = dt2;
  var $t2 = function(t16) {
    var r9 = this.__data__, e21 = jt2(r9, t16);
    return !(e21 < 0) && (e21 == r9.length - 1 ? r9.pop() : Ot2.call(r9, e21, 1), --this.size, true);
  };
  var Pt2 = function(t16) {
    var r9 = this.__data__, e21 = wt2(r9, t16);
    return e21 < 0 ? void 0 : r9[e21][1];
  };
  var At2 = function(t16) {
    return mt2(this.__data__, t16) > -1;
  };
  var Ft2 = function(t16, r9) {
    var e21 = this.__data__, n12 = zt2(e21, t16);
    return n12 < 0 ? (++this.size, e21.push([t16, r9])) : e21[n12][1] = r9, this;
  };
  function Tt2(t16) {
    var r9 = -1, e21 = null == t16 ? 0 : t16.length;
    for (this.clear(); ++r9 < e21; ) {
      var n12 = t16[r9];
      this.set(n12[0], n12[1]);
    }
  }
  Tt2.prototype.clear = St2, Tt2.prototype.delete = $t2, Tt2.prototype.get = Pt2, Tt2.prototype.has = At2, Tt2.prototype.set = Ft2;
  var xt2 = Tt2;
  var Ct2 = I4(n6, "Map");
  var Et2 = yt2;
  var kt2 = xt2;
  var Rt2 = Ct2;
  var Gt2 = function(t16) {
    var r9 = typeof t16;
    return "string" == r9 || "number" == r9 || "symbol" == r9 || "boolean" == r9 ? "__proto__" !== t16 : null === t16;
  };
  var It2 = function(t16, r9) {
    var e21 = t16.__data__;
    return Gt2(r9) ? e21["string" == typeof r9 ? "string" : "hash"] : e21.map;
  };
  var Mt2 = It2;
  var Nt2 = It2;
  var Ut2 = It2;
  var qt2 = It2;
  var Bt2 = function() {
    this.size = 0, this.__data__ = { hash: new Et2(), map: new (Rt2 || kt2)(), string: new Et2() };
  };
  var Dt2 = function(t16) {
    var r9 = Mt2(this, t16).delete(t16);
    return this.size -= r9 ? 1 : 0, r9;
  };
  var Ht2 = function(t16) {
    return Nt2(this, t16).get(t16);
  };
  var Jt2 = function(t16) {
    return Ut2(this, t16).has(t16);
  };
  var Kt2 = function(t16, r9) {
    var e21 = qt2(this, t16), n12 = e21.size;
    return e21.set(t16, r9), this.size += e21.size == n12 ? 0 : 1, this;
  };
  function Lt2(t16) {
    var r9 = -1, e21 = null == t16 ? 0 : t16.length;
    for (this.clear(); ++r9 < e21; ) {
      var n12 = t16[r9];
      this.set(n12[0], n12[1]);
    }
  }
  Lt2.prototype.clear = Bt2, Lt2.prototype.delete = Dt2, Lt2.prototype.get = Ht2, Lt2.prototype.has = Jt2, Lt2.prototype.set = Kt2;
  var Qt2 = Lt2;
  function Vt2(t16, r9) {
    if ("function" != typeof t16 || null != r9 && "function" != typeof r9)
      throw new TypeError("Expected a function");
    var e21 = function() {
      var n12 = arguments, o12 = r9 ? r9.apply(this, n12) : n12[0], a10 = e21.cache;
      if (a10.has(o12))
        return a10.get(o12);
      var i11 = t16.apply(this, n12);
      return e21.cache = a10.set(o12, i11) || a10, i11;
    };
    return e21.cache = new (Vt2.Cache || Qt2)(), e21;
  }
  Vt2.Cache = Qt2;
  var Wt2 = Vt2;
  var Xt2 = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
  var Yt2 = /\\(\\)?/g;
  var Zt2 = function(t16) {
    var r9 = Wt2(t16, function(t17) {
      return 500 === e21.size && e21.clear(), t17;
    }), e21 = r9.cache;
    return r9;
  }(function(t16) {
    var r9 = [];
    return 46 === t16.charCodeAt(0) && r9.push(""), t16.replace(Xt2, function(t17, e21, n12, o12) {
      r9.push(n12 ? o12.replace(Yt2, "$1") : e21 || t17);
    }), r9;
  });
  var tr2 = function(t16, r9) {
    for (var e21 = -1, n12 = null == t16 ? 0 : t16.length, o12 = Array(n12); ++e21 < n12; )
      o12[e21] = r9(t16[e21], e21, t16);
    return o12;
  };
  var rr2 = J2;
  var er2 = Q2;
  var nr2 = o5 ? o5.prototype : void 0;
  var or2 = nr2 ? nr2.toString : void 0;
  var ar2 = function t8(r9) {
    if ("string" == typeof r9)
      return r9;
    if (rr2(r9))
      return tr2(r9, t8) + "";
    if (er2(r9))
      return or2 ? or2.call(r9) : "";
    var e21 = r9 + "";
    return "0" == e21 && 1 / r9 == -1 / 0 ? "-0" : e21;
  };
  var ir2 = ar2;
  var ur2 = J2;
  var cr2 = Z2;
  var lr = Zt2;
  var sr = function(t16) {
    return null == t16 ? "" : ir2(t16);
  };
  var fr = /^(?:0|[1-9]\d*)$/;
  var vr = Q2;
  var pr = H2;
  var hr = function(t16, r9) {
    return ur2(t16) ? t16 : cr2(t16, r9) ? [t16] : lr(sr(t16));
  };
  var _r = function(t16, r9) {
    var e21 = typeof t16;
    return !!(r9 = null == r9 ? 9007199254740991 : r9) && ("number" == e21 || "symbol" != e21 && fr.test(t16)) && t16 > -1 && t16 % 1 == 0 && t16 < r9;
  };
  var yr = y4;
  var dr = function(t16) {
    if ("string" == typeof t16 || vr(t16))
      return t16;
    var r9 = t16 + "";
    return "0" == r9 && 1 / t16 == -1 / 0 ? "-0" : r9;
  };
  var br = function(t16, r9, e21, n12) {
    if (!yr(t16))
      return t16;
    for (var o12 = -1, a10 = (r9 = hr(r9, t16)).length, i11 = a10 - 1, u10 = t16; null != u10 && ++o12 < a10; ) {
      var c10 = dr(r9[o12]), l11 = e21;
      if ("__proto__" === c10 || "constructor" === c10 || "prototype" === c10)
        return t16;
      if (o12 != i11) {
        var s11 = u10[c10];
        void 0 === (l11 = n12 ? n12(s11, c10, u10) : void 0) && (l11 = yr(s11) ? s11 : _r(r9[o12 + 1]) ? [] : {});
      }
      pr(u10, c10, l11), u10 = u10[c10];
    }
    return t16;
  };
  var gr = function(t16, r9, e21) {
    return null == t16 ? t16 : br(t16, r9, e21);
  };

  // http-url:https://cdn.jsdelivr.net/npm/lodash@4.17.21/toPath/+esm
  var t9 = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
  var r5 = function(t16, r9) {
    for (var e21 = -1, n12 = null == t16 ? 0 : t16.length, o12 = Array(n12); ++e21 < n12; )
      o12[e21] = r9(t16[e21], e21, t16);
    return o12;
  };
  var e6 = function(t16, r9) {
    var e21 = -1, n12 = t16.length;
    for (r9 || (r9 = Array(n12)); ++e21 < n12; )
      r9[e21] = t16[e21];
    return r9;
  };
  var n7 = Array.isArray;
  var o6 = "object" == typeof t9 && t9 && t9.Object === Object && t9;
  var a5 = "object" == typeof self && self && self.Object === Object && self;
  var i5 = o6 || a5 || Function("return this")();
  var u5 = i5.Symbol;
  var c5 = u5;
  var s5 = Object.prototype;
  var f5 = s5.hasOwnProperty;
  var l5 = s5.toString;
  var p5 = c5 ? c5.toStringTag : void 0;
  var v5 = function(t16) {
    var r9 = f5.call(t16, p5), e21 = t16[p5];
    try {
      t16[p5] = void 0;
      var n12 = true;
    } catch (t17) {
    }
    var o12 = l5.call(t16);
    return n12 && (r9 ? t16[p5] = e21 : delete t16[p5]), o12;
  };
  var h5 = Object.prototype.toString;
  var _4 = v5;
  var y5 = function(t16) {
    return h5.call(t16);
  };
  var d6 = u5 ? u5.toStringTag : void 0;
  var g5 = function(t16) {
    return null == t16 ? void 0 === t16 ? "[object Undefined]" : "[object Null]" : d6 && d6 in Object(t16) ? _4(t16) : y5(t16);
  };
  var b5 = g5;
  var j5 = function(t16) {
    return null != t16 && "object" == typeof t16;
  };
  var O5 = function(t16) {
    return "symbol" == typeof t16 || j5(t16) && "[object Symbol]" == b5(t16);
  };
  var w5 = function(t16) {
    var r9 = typeof t16;
    return null != t16 && ("object" == r9 || "function" == r9);
  };
  var z4 = g5;
  var S5 = w5;
  var m6;
  var $5 = function(t16) {
    if (!S5(t16))
      return false;
    var r9 = z4(t16);
    return "[object Function]" == r9 || "[object GeneratorFunction]" == r9 || "[object AsyncFunction]" == r9 || "[object Proxy]" == r9;
  };
  var A5 = i5["__core-js_shared__"];
  var P5 = (m6 = /[^.]+$/.exec(A5 && A5.keys && A5.keys.IE_PROTO || "")) ? "Symbol(src)_1." + m6 : "";
  var F5 = function(t16) {
    return !!P5 && P5 in t16;
  };
  var T5 = Function.prototype.toString;
  var x5 = $5;
  var C4 = F5;
  var E5 = w5;
  var k4 = function(t16) {
    if (null != t16) {
      try {
        return T5.call(t16);
      } catch (t17) {
      }
      try {
        return t16 + "";
      } catch (t17) {
      }
    }
    return "";
  };
  var R3 = /^\[object .+?Constructor\]$/;
  var G4 = Function.prototype;
  var I5 = Object.prototype;
  var M5 = G4.toString;
  var N5 = I5.hasOwnProperty;
  var U4 = RegExp("^" + M5.call(N5).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
  var q4 = function(t16) {
    return !(!E5(t16) || C4(t16)) && (x5(t16) ? U4 : R3).test(k4(t16));
  };
  var B4 = function(t16, r9) {
    return null == t16 ? void 0 : t16[r9];
  };
  var D5 = function(t16, r9) {
    var e21 = B4(t16, r9);
    return q4(e21) ? e21 : void 0;
  };
  var H3 = D5(Object, "create");
  var J3 = H3;
  var K3 = function() {
    this.__data__ = J3 ? J3(null) : {}, this.size = 0;
  };
  var L4 = function(t16) {
    var r9 = this.has(t16) && delete this.__data__[t16];
    return this.size -= r9 ? 1 : 0, r9;
  };
  var Q3 = H3;
  var V4 = Object.prototype.hasOwnProperty;
  var W4 = function(t16) {
    var r9 = this.__data__;
    if (Q3) {
      var e21 = r9[t16];
      return "__lodash_hash_undefined__" === e21 ? void 0 : e21;
    }
    return V4.call(r9, t16) ? r9[t16] : void 0;
  };
  var X3 = H3;
  var Y3 = Object.prototype.hasOwnProperty;
  var Z3 = H3;
  var tt3 = K3;
  var rt3 = L4;
  var et3 = W4;
  var nt3 = function(t16) {
    var r9 = this.__data__;
    return X3 ? void 0 !== r9[t16] : Y3.call(r9, t16);
  };
  var ot3 = function(t16, r9) {
    var e21 = this.__data__;
    return this.size += this.has(t16) ? 0 : 1, e21[t16] = Z3 && void 0 === r9 ? "__lodash_hash_undefined__" : r9, this;
  };
  function at3(t16) {
    var r9 = -1, e21 = null == t16 ? 0 : t16.length;
    for (this.clear(); ++r9 < e21; ) {
      var n12 = t16[r9];
      this.set(n12[0], n12[1]);
    }
  }
  at3.prototype.clear = tt3, at3.prototype.delete = rt3, at3.prototype.get = et3, at3.prototype.has = nt3, at3.prototype.set = ot3;
  var it3 = at3;
  var ut3 = function() {
    this.__data__ = [], this.size = 0;
  };
  var ct3 = function(t16, r9) {
    return t16 === r9 || t16 != t16 && r9 != r9;
  };
  var st3 = function(t16, r9) {
    for (var e21 = t16.length; e21--; )
      if (ct3(t16[e21][0], r9))
        return e21;
    return -1;
  };
  var ft3 = st3;
  var lt3 = Array.prototype.splice;
  var pt3 = st3;
  var vt3 = st3;
  var ht3 = st3;
  var _t3 = ut3;
  var yt3 = function(t16) {
    var r9 = this.__data__, e21 = ft3(r9, t16);
    return !(e21 < 0) && (e21 == r9.length - 1 ? r9.pop() : lt3.call(r9, e21, 1), --this.size, true);
  };
  var dt3 = function(t16) {
    var r9 = this.__data__, e21 = pt3(r9, t16);
    return e21 < 0 ? void 0 : r9[e21][1];
  };
  var gt3 = function(t16) {
    return vt3(this.__data__, t16) > -1;
  };
  var bt3 = function(t16, r9) {
    var e21 = this.__data__, n12 = ht3(e21, t16);
    return n12 < 0 ? (++this.size, e21.push([t16, r9])) : e21[n12][1] = r9, this;
  };
  function jt3(t16) {
    var r9 = -1, e21 = null == t16 ? 0 : t16.length;
    for (this.clear(); ++r9 < e21; ) {
      var n12 = t16[r9];
      this.set(n12[0], n12[1]);
    }
  }
  jt3.prototype.clear = _t3, jt3.prototype.delete = yt3, jt3.prototype.get = dt3, jt3.prototype.has = gt3, jt3.prototype.set = bt3;
  var Ot3 = jt3;
  var wt3 = D5(i5, "Map");
  var zt3 = it3;
  var St3 = Ot3;
  var mt3 = wt3;
  var $t3 = function(t16) {
    var r9 = typeof t16;
    return "string" == r9 || "number" == r9 || "symbol" == r9 || "boolean" == r9 ? "__proto__" !== t16 : null === t16;
  };
  var At3 = function(t16, r9) {
    var e21 = t16.__data__;
    return $t3(r9) ? e21["string" == typeof r9 ? "string" : "hash"] : e21.map;
  };
  var Pt3 = At3;
  var Ft3 = At3;
  var Tt3 = At3;
  var xt3 = At3;
  var Ct3 = function() {
    this.size = 0, this.__data__ = { hash: new zt3(), map: new (mt3 || St3)(), string: new zt3() };
  };
  var Et3 = function(t16) {
    var r9 = Pt3(this, t16).delete(t16);
    return this.size -= r9 ? 1 : 0, r9;
  };
  var kt3 = function(t16) {
    return Ft3(this, t16).get(t16);
  };
  var Rt3 = function(t16) {
    return Tt3(this, t16).has(t16);
  };
  var Gt3 = function(t16, r9) {
    var e21 = xt3(this, t16), n12 = e21.size;
    return e21.set(t16, r9), this.size += e21.size == n12 ? 0 : 1, this;
  };
  function It3(t16) {
    var r9 = -1, e21 = null == t16 ? 0 : t16.length;
    for (this.clear(); ++r9 < e21; ) {
      var n12 = t16[r9];
      this.set(n12[0], n12[1]);
    }
  }
  It3.prototype.clear = Ct3, It3.prototype.delete = Et3, It3.prototype.get = kt3, It3.prototype.has = Rt3, It3.prototype.set = Gt3;
  var Mt3 = It3;
  function Nt3(t16, r9) {
    if ("function" != typeof t16 || null != r9 && "function" != typeof r9)
      throw new TypeError("Expected a function");
    var e21 = function() {
      var n12 = arguments, o12 = r9 ? r9.apply(this, n12) : n12[0], a10 = e21.cache;
      if (a10.has(o12))
        return a10.get(o12);
      var i11 = t16.apply(this, n12);
      return e21.cache = a10.set(o12, i11) || a10, i11;
    };
    return e21.cache = new (Nt3.Cache || Mt3)(), e21;
  }
  Nt3.Cache = Mt3;
  var Ut3 = Nt3;
  var qt3 = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
  var Bt3 = /\\(\\)?/g;
  var Dt3 = function(t16) {
    var r9 = Ut3(t16, function(t17) {
      return 500 === e21.size && e21.clear(), t17;
    }), e21 = r9.cache;
    return r9;
  }(function(t16) {
    var r9 = [];
    return 46 === t16.charCodeAt(0) && r9.push(""), t16.replace(qt3, function(t17, e21, n12, o12) {
      r9.push(n12 ? o12.replace(Bt3, "$1") : e21 || t17);
    }), r9;
  });
  var Ht3 = O5;
  var Jt3 = function(t16) {
    if ("string" == typeof t16 || Ht3(t16))
      return t16;
    var r9 = t16 + "";
    return "0" == r9 && 1 / t16 == -1 / 0 ? "-0" : r9;
  };
  var Kt3 = r5;
  var Lt3 = n7;
  var Qt3 = O5;
  var Vt3 = u5 ? u5.prototype : void 0;
  var Wt3 = Vt3 ? Vt3.toString : void 0;
  var Xt3 = function t10(r9) {
    if ("string" == typeof r9)
      return r9;
    if (Lt3(r9))
      return Kt3(r9, t10) + "";
    if (Qt3(r9))
      return Wt3 ? Wt3.call(r9) : "";
    var e21 = r9 + "";
    return "0" == e21 && 1 / r9 == -1 / 0 ? "-0" : e21;
  };
  var Yt3 = Xt3;
  var Zt3 = r5;
  var tr3 = e6;
  var rr3 = n7;
  var er3 = O5;
  var nr3 = Dt3;
  var or3 = Jt3;
  var ar3 = function(t16) {
    return null == t16 ? "" : Yt3(t16);
  };
  var ir3 = function(t16) {
    return rr3(t16) ? Zt3(t16, or3) : er3(t16) ? [t16] : tr3(nr3(ar3(t16)));
  };

  // http-url:https://cdn.jsdelivr.net/npm/cytoscape@3.26.0/+esm
  var i6 = o3;
  var o7 = cr;
  var s6 = gr;
  var l6 = ir3;
  function u6(e21) {
    return e21 && "object" == typeof e21 && "default" in e21 ? e21 : { default: e21 };
  }
  var c6 = u6(U);
  var d7 = u6(i6);
  var h6 = u6(o7);
  var p6 = u6(s6);
  var f6 = u6(l6);
  function g6(e21) {
    return g6 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e22) {
      return typeof e22;
    } : function(e22) {
      return e22 && "function" == typeof Symbol && e22.constructor === Symbol && e22 !== Symbol.prototype ? "symbol" : typeof e22;
    }, g6(e21);
  }
  function v6(e21, t16) {
    if (!(e21 instanceof t16))
      throw new TypeError("Cannot call a class as a function");
  }
  function y6(e21, t16) {
    for (var n12 = 0; n12 < t16.length; n12++) {
      var r9 = t16[n12];
      r9.enumerable = r9.enumerable || false, r9.configurable = true, "value" in r9 && (r9.writable = true), Object.defineProperty(e21, r9.key, r9);
    }
  }
  function m7(e21, t16, n12) {
    return t16 && y6(e21.prototype, t16), n12 && y6(e21, n12), Object.defineProperty(e21, "prototype", { writable: false }), e21;
  }
  function b6(e21, t16, n12) {
    return t16 in e21 ? Object.defineProperty(e21, t16, { value: n12, enumerable: true, configurable: true, writable: true }) : e21[t16] = n12, e21;
  }
  function x6(e21, t16) {
    return function(e22) {
      if (Array.isArray(e22))
        return e22;
    }(e21) || function(e22, t17) {
      var n12 = null == e22 ? null : "undefined" != typeof Symbol && e22[Symbol.iterator] || e22["@@iterator"];
      if (null == n12)
        return;
      var r9, a10, i11 = [], o12 = true, s11 = false;
      try {
        for (n12 = n12.call(e22); !(o12 = (r9 = n12.next()).done) && (i11.push(r9.value), !t17 || i11.length !== t17); o12 = true)
          ;
      } catch (e23) {
        s11 = true, a10 = e23;
      } finally {
        try {
          o12 || null == n12.return || n12.return();
        } finally {
          if (s11)
            throw a10;
        }
      }
      return i11;
    }(e21, t16) || function(e22, t17) {
      if (!e22)
        return;
      if ("string" == typeof e22)
        return w6(e22, t17);
      var n12 = Object.prototype.toString.call(e22).slice(8, -1);
      "Object" === n12 && e22.constructor && (n12 = e22.constructor.name);
      if ("Map" === n12 || "Set" === n12)
        return Array.from(e22);
      if ("Arguments" === n12 || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n12))
        return w6(e22, t17);
    }(e21, t16) || function() {
      throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }();
  }
  function w6(e21, t16) {
    (null == t16 || t16 > e21.length) && (t16 = e21.length);
    for (var n12 = 0, r9 = new Array(t16); n12 < t16; n12++)
      r9[n12] = e21[n12];
    return r9;
  }
  var E6 = "undefined" == typeof window ? null : window;
  var k5 = E6 ? E6.navigator : null;
  E6 && E6.document;
  var C5 = g6("");
  var S6 = g6({});
  var D6 = g6(function() {
  });
  var P6 = "undefined" == typeof HTMLElement ? "undefined" : g6(HTMLElement);
  var T6 = function(e21) {
    return e21 && e21.instanceString && B5(e21.instanceString) ? e21.instanceString() : null;
  };
  var M6 = function(e21) {
    return null != e21 && g6(e21) == C5;
  };
  var B5 = function(e21) {
    return null != e21 && g6(e21) === D6;
  };
  var _5 = function(e21) {
    return !L5(e21) && (Array.isArray ? Array.isArray(e21) : null != e21 && e21 instanceof Array);
  };
  var N6 = function(e21) {
    return null != e21 && g6(e21) === S6 && !_5(e21) && e21.constructor === Object;
  };
  var I6 = function(e21) {
    return null != e21 && g6(e21) === g6(1) && !isNaN(e21);
  };
  var z5 = function(e21) {
    return "undefined" === P6 ? void 0 : null != e21 && e21 instanceof HTMLElement;
  };
  var L5 = function(e21) {
    return A6(e21) || O6(e21);
  };
  var A6 = function(e21) {
    return "collection" === T6(e21) && e21._private.single;
  };
  var O6 = function(e21) {
    return "collection" === T6(e21) && !e21._private.single;
  };
  var R4 = function(e21) {
    return "core" === T6(e21);
  };
  var V5 = function(e21) {
    return "stylesheet" === T6(e21);
  };
  var F6 = function(e21) {
    return null == e21 || !("" !== e21 && !e21.match(/^\s+$/));
  };
  var q5 = function(e21) {
    return function(e22) {
      return null != e22 && g6(e22) === S6;
    }(e21) && B5(e21.then);
  };
  var j6 = function(e21, t16) {
    t16 || (t16 = function() {
      if (1 === arguments.length)
        return arguments[0];
      if (0 === arguments.length)
        return "undefined";
      for (var e22 = [], t17 = 0; t17 < arguments.length; t17++)
        e22.push(arguments[t17]);
      return e22.join("$");
    });
    var n12 = function n13() {
      var r9, a10 = arguments, i11 = t16.apply(this, a10), o12 = n13.cache;
      return (r9 = o12[i11]) || (r9 = o12[i11] = e21.apply(this, a10)), r9;
    };
    return n12.cache = {}, n12;
  };
  var Y4 = j6(function(e21) {
    return e21.replace(/([A-Z])/g, function(e22) {
      return "-" + e22.toLowerCase();
    });
  });
  var X4 = j6(function(e21) {
    return e21.replace(/(-\w)/g, function(e22) {
      return e22[1].toUpperCase();
    });
  });
  var W5 = j6(function(e21, t16) {
    return e21 + t16[0].toUpperCase() + t16.substring(1);
  }, function(e21, t16) {
    return e21 + "$" + t16;
  });
  var H4 = function(e21) {
    return F6(e21) ? e21 : e21.charAt(0).toUpperCase() + e21.substring(1);
  };
  var K4 = "(?:[-+]?(?:(?:\\d+|\\d*\\.\\d+)(?:[Ee][+-]?\\d+)?))";
  var G5 = "rgb[a]?\\((" + K4 + "[%]?)\\s*,\\s*(" + K4 + "[%]?)\\s*,\\s*(" + K4 + "[%]?)(?:\\s*,\\s*(" + K4 + "))?\\)";
  var U5 = "rgb[a]?\\((?:" + K4 + "[%]?)\\s*,\\s*(?:" + K4 + "[%]?)\\s*,\\s*(?:" + K4 + "[%]?)(?:\\s*,\\s*(?:" + K4 + "))?\\)";
  var Z4 = "hsl[a]?\\((" + K4 + ")\\s*,\\s*(" + K4 + "[%])\\s*,\\s*(" + K4 + "[%])(?:\\s*,\\s*(" + K4 + "))?\\)";
  var $6 = "hsl[a]?\\((?:" + K4 + ")\\s*,\\s*(?:" + K4 + "[%])\\s*,\\s*(?:" + K4 + "[%])(?:\\s*,\\s*(?:" + K4 + "))?\\)";
  var Q4 = function(e21, t16) {
    return e21 < t16 ? -1 : e21 > t16 ? 1 : 0;
  };
  var J4 = null != Object.assign ? Object.assign.bind(Object) : function(e21) {
    for (var t16 = arguments, n12 = 1; n12 < t16.length; n12++) {
      var r9 = t16[n12];
      if (null != r9)
        for (var a10 = Object.keys(r9), i11 = 0; i11 < a10.length; i11++) {
          var o12 = a10[i11];
          e21[o12] = r9[o12];
        }
    }
    return e21;
  };
  var ee = function(e21) {
    return (_5(e21) ? e21 : null) || function(e22) {
      return te[e22.toLowerCase()];
    }(e21) || function(e22) {
      if ((4 === e22.length || 7 === e22.length) && "#" === e22[0]) {
        var t16, n12, r9, a10 = 16;
        return 4 === e22.length ? (t16 = parseInt(e22[1] + e22[1], a10), n12 = parseInt(e22[2] + e22[2], a10), r9 = parseInt(e22[3] + e22[3], a10)) : (t16 = parseInt(e22[1] + e22[2], a10), n12 = parseInt(e22[3] + e22[4], a10), r9 = parseInt(e22[5] + e22[6], a10)), [t16, n12, r9];
      }
    }(e21) || function(e22) {
      var t16, n12 = new RegExp("^" + G5 + "$").exec(e22);
      if (n12) {
        t16 = [];
        for (var r9 = [], a10 = 1; a10 <= 3; a10++) {
          var i11 = n12[a10];
          if ("%" === i11[i11.length - 1] && (r9[a10] = true), i11 = parseFloat(i11), r9[a10] && (i11 = i11 / 100 * 255), i11 < 0 || i11 > 255)
            return;
          t16.push(Math.floor(i11));
        }
        var o12 = r9[1] || r9[2] || r9[3], s11 = r9[1] && r9[2] && r9[3];
        if (o12 && !s11)
          return;
        var l11 = n12[4];
        if (void 0 !== l11) {
          if ((l11 = parseFloat(l11)) < 0 || l11 > 1)
            return;
          t16.push(l11);
        }
      }
      return t16;
    }(e21) || function(e22) {
      var t16, n12, r9, a10, i11, o12, s11, l11;
      function u10(e23, t17, n13) {
        return n13 < 0 && (n13 += 1), n13 > 1 && (n13 -= 1), n13 < 1 / 6 ? e23 + 6 * (t17 - e23) * n13 : n13 < 0.5 ? t17 : n13 < 2 / 3 ? e23 + (t17 - e23) * (2 / 3 - n13) * 6 : e23;
      }
      var c10 = new RegExp("^" + Z4 + "$").exec(e22);
      if (c10) {
        if ((n12 = parseInt(c10[1])) < 0 ? n12 = (360 - -1 * n12 % 360) % 360 : n12 > 360 && (n12 %= 360), n12 /= 360, (r9 = parseFloat(c10[2])) < 0 || r9 > 100)
          return;
        if (r9 /= 100, (a10 = parseFloat(c10[3])) < 0 || a10 > 100)
          return;
        if (a10 /= 100, void 0 !== (i11 = c10[4]) && ((i11 = parseFloat(i11)) < 0 || i11 > 1))
          return;
        if (0 === r9)
          o12 = s11 = l11 = Math.round(255 * a10);
        else {
          var d12 = a10 < 0.5 ? a10 * (1 + r9) : a10 + r9 - a10 * r9, h10 = 2 * a10 - d12;
          o12 = Math.round(255 * u10(h10, d12, n12 + 1 / 3)), s11 = Math.round(255 * u10(h10, d12, n12)), l11 = Math.round(255 * u10(h10, d12, n12 - 1 / 3));
        }
        t16 = [o12, s11, l11, i11];
      }
      return t16;
    }(e21);
  };
  var te = { transparent: [0, 0, 0, 0], aliceblue: [240, 248, 255], antiquewhite: [250, 235, 215], aqua: [0, 255, 255], aquamarine: [127, 255, 212], azure: [240, 255, 255], beige: [245, 245, 220], bisque: [255, 228, 196], black: [0, 0, 0], blanchedalmond: [255, 235, 205], blue: [0, 0, 255], blueviolet: [138, 43, 226], brown: [165, 42, 42], burlywood: [222, 184, 135], cadetblue: [95, 158, 160], chartreuse: [127, 255, 0], chocolate: [210, 105, 30], coral: [255, 127, 80], cornflowerblue: [100, 149, 237], cornsilk: [255, 248, 220], crimson: [220, 20, 60], cyan: [0, 255, 255], darkblue: [0, 0, 139], darkcyan: [0, 139, 139], darkgoldenrod: [184, 134, 11], darkgray: [169, 169, 169], darkgreen: [0, 100, 0], darkgrey: [169, 169, 169], darkkhaki: [189, 183, 107], darkmagenta: [139, 0, 139], darkolivegreen: [85, 107, 47], darkorange: [255, 140, 0], darkorchid: [153, 50, 204], darkred: [139, 0, 0], darksalmon: [233, 150, 122], darkseagreen: [143, 188, 143], darkslateblue: [72, 61, 139], darkslategray: [47, 79, 79], darkslategrey: [47, 79, 79], darkturquoise: [0, 206, 209], darkviolet: [148, 0, 211], deeppink: [255, 20, 147], deepskyblue: [0, 191, 255], dimgray: [105, 105, 105], dimgrey: [105, 105, 105], dodgerblue: [30, 144, 255], firebrick: [178, 34, 34], floralwhite: [255, 250, 240], forestgreen: [34, 139, 34], fuchsia: [255, 0, 255], gainsboro: [220, 220, 220], ghostwhite: [248, 248, 255], gold: [255, 215, 0], goldenrod: [218, 165, 32], gray: [128, 128, 128], grey: [128, 128, 128], green: [0, 128, 0], greenyellow: [173, 255, 47], honeydew: [240, 255, 240], hotpink: [255, 105, 180], indianred: [205, 92, 92], indigo: [75, 0, 130], ivory: [255, 255, 240], khaki: [240, 230, 140], lavender: [230, 230, 250], lavenderblush: [255, 240, 245], lawngreen: [124, 252, 0], lemonchiffon: [255, 250, 205], lightblue: [173, 216, 230], lightcoral: [240, 128, 128], lightcyan: [224, 255, 255], lightgoldenrodyellow: [250, 250, 210], lightgray: [211, 211, 211], lightgreen: [144, 238, 144], lightgrey: [211, 211, 211], lightpink: [255, 182, 193], lightsalmon: [255, 160, 122], lightseagreen: [32, 178, 170], lightskyblue: [135, 206, 250], lightslategray: [119, 136, 153], lightslategrey: [119, 136, 153], lightsteelblue: [176, 196, 222], lightyellow: [255, 255, 224], lime: [0, 255, 0], limegreen: [50, 205, 50], linen: [250, 240, 230], magenta: [255, 0, 255], maroon: [128, 0, 0], mediumaquamarine: [102, 205, 170], mediumblue: [0, 0, 205], mediumorchid: [186, 85, 211], mediumpurple: [147, 112, 219], mediumseagreen: [60, 179, 113], mediumslateblue: [123, 104, 238], mediumspringgreen: [0, 250, 154], mediumturquoise: [72, 209, 204], mediumvioletred: [199, 21, 133], midnightblue: [25, 25, 112], mintcream: [245, 255, 250], mistyrose: [255, 228, 225], moccasin: [255, 228, 181], navajowhite: [255, 222, 173], navy: [0, 0, 128], oldlace: [253, 245, 230], olive: [128, 128, 0], olivedrab: [107, 142, 35], orange: [255, 165, 0], orangered: [255, 69, 0], orchid: [218, 112, 214], palegoldenrod: [238, 232, 170], palegreen: [152, 251, 152], paleturquoise: [175, 238, 238], palevioletred: [219, 112, 147], papayawhip: [255, 239, 213], peachpuff: [255, 218, 185], peru: [205, 133, 63], pink: [255, 192, 203], plum: [221, 160, 221], powderblue: [176, 224, 230], purple: [128, 0, 128], red: [255, 0, 0], rosybrown: [188, 143, 143], royalblue: [65, 105, 225], saddlebrown: [139, 69, 19], salmon: [250, 128, 114], sandybrown: [244, 164, 96], seagreen: [46, 139, 87], seashell: [255, 245, 238], sienna: [160, 82, 45], silver: [192, 192, 192], skyblue: [135, 206, 235], slateblue: [106, 90, 205], slategray: [112, 128, 144], slategrey: [112, 128, 144], snow: [255, 250, 250], springgreen: [0, 255, 127], steelblue: [70, 130, 180], tan: [210, 180, 140], teal: [0, 128, 128], thistle: [216, 191, 216], tomato: [255, 99, 71], turquoise: [64, 224, 208], violet: [238, 130, 238], wheat: [245, 222, 179], white: [255, 255, 255], whitesmoke: [245, 245, 245], yellow: [255, 255, 0], yellowgreen: [154, 205, 50] };
  var ne = function(e21) {
    for (var t16 = e21.map, n12 = e21.keys, r9 = n12.length, a10 = 0; a10 < r9; a10++) {
      var i11 = n12[a10];
      if (N6(i11))
        throw Error("Tried to set map with object key");
      a10 < n12.length - 1 ? (null == t16[i11] && (t16[i11] = {}), t16 = t16[i11]) : t16[i11] = e21.value;
    }
  };
  var re = function(e21) {
    for (var t16 = e21.map, n12 = e21.keys, r9 = n12.length, a10 = 0; a10 < r9; a10++) {
      var i11 = n12[a10];
      if (N6(i11))
        throw Error("Tried to get map with object key");
      if (null == (t16 = t16[i11]))
        return t16;
    }
    return t16;
  };
  var ae = E6 ? E6.performance : null;
  var ie = ae && ae.now ? function() {
    return ae.now();
  } : function() {
    return Date.now();
  };
  var oe = function() {
    if (E6) {
      if (E6.requestAnimationFrame)
        return function(e21) {
          E6.requestAnimationFrame(e21);
        };
      if (E6.mozRequestAnimationFrame)
        return function(e21) {
          E6.mozRequestAnimationFrame(e21);
        };
      if (E6.webkitRequestAnimationFrame)
        return function(e21) {
          E6.webkitRequestAnimationFrame(e21);
        };
      if (E6.msRequestAnimationFrame)
        return function(e21) {
          E6.msRequestAnimationFrame(e21);
        };
    }
    return function(e21) {
      e21 && setTimeout(function() {
        e21(ie());
      }, 1e3 / 60);
    };
  }();
  var se = function(e21) {
    return oe(e21);
  };
  var le = ie;
  var ue = 9261;
  var ce = 5381;
  var de = function(e21) {
    for (var t16, n12 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ue; !(t16 = e21.next()).done; )
      n12 = 65599 * n12 + t16.value | 0;
    return n12;
  };
  var he = function(e21) {
    return 65599 * (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ue) + e21 | 0;
  };
  var pe = function(e21) {
    var t16 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ce;
    return (t16 << 5) + t16 + e21 | 0;
  };
  var fe = function(e21) {
    return 2097152 * e21[0] + e21[1];
  };
  var ge = function(e21, t16) {
    return [he(e21[0], t16[0]), pe(e21[1], t16[1])];
  };
  var ve = function(e21, t16) {
    var n12 = { value: 0, done: false }, r9 = 0, a10 = e21.length;
    return de({ next: function() {
      return r9 < a10 ? n12.value = e21.charCodeAt(r9++) : n12.done = true, n12;
    } }, t16);
  };
  var ye = function() {
    return me(arguments);
  };
  var me = function(e21) {
    for (var t16, n12 = 0; n12 < e21.length; n12++) {
      var r9 = e21[n12];
      t16 = 0 === n12 ? ve(r9) : ve(r9, t16);
    }
    return t16;
  };
  var be = true;
  var xe = null != console.warn;
  var we = null != console.trace;
  var Ee = Number.MAX_SAFE_INTEGER || 9007199254740991;
  var ke = function() {
    return true;
  };
  var Ce = function() {
    return false;
  };
  var Se = function() {
    return 0;
  };
  var De = function() {
  };
  var Pe = function(e21) {
    throw new Error(e21);
  };
  var Te = function(e21) {
    if (void 0 === e21)
      return be;
    be = !!e21;
  };
  var Me = function(e21) {
    Te() && (xe ? console.warn(e21) : (console.log(e21), we && console.trace()));
  };
  var Be = function(e21) {
    return null == e21 ? e21 : _5(e21) ? e21.slice() : N6(e21) ? function(e22) {
      return J4({}, e22);
    }(e21) : e21;
  };
  var _e = function(e21, t16) {
    for (t16 = e21 = ""; e21++ < 36; t16 += 51 * e21 & 52 ? (15 ^ e21 ? 8 ^ Math.random() * (20 ^ e21 ? 16 : 4) : 4).toString(16) : "-")
      ;
    return t16;
  };
  var Ne = {};
  var Ie = function() {
    return Ne;
  };
  var ze = function(e21) {
    var t16 = Object.keys(e21);
    return function(n12) {
      for (var r9 = {}, a10 = 0; a10 < t16.length; a10++) {
        var i11 = t16[a10], o12 = null == n12 ? void 0 : n12[i11];
        r9[i11] = void 0 === o12 ? e21[i11] : o12;
      }
      return r9;
    };
  };
  var Le = function(e21, t16, n12) {
    for (var r9 = e21.length - 1; r9 >= 0 && (e21[r9] !== t16 || (e21.splice(r9, 1), !n12)); r9--)
      ;
  };
  var Ae = function(e21) {
    e21.splice(0, e21.length);
  };
  var Oe = function(e21, t16, n12) {
    return n12 && (t16 = W5(n12, t16)), e21[t16];
  };
  var Re = function(e21, t16, n12, r9) {
    n12 && (t16 = W5(n12, t16)), e21[t16] = r9;
  };
  var Ve = "undefined" != typeof Map ? Map : function() {
    function e21() {
      v6(this, e21), this._obj = {};
    }
    return m7(e21, [{ key: "set", value: function(e22, t16) {
      return this._obj[e22] = t16, this;
    } }, { key: "delete", value: function(e22) {
      return this._obj[e22] = void 0, this;
    } }, { key: "clear", value: function() {
      this._obj = {};
    } }, { key: "has", value: function(e22) {
      return void 0 !== this._obj[e22];
    } }, { key: "get", value: function(e22) {
      return this._obj[e22];
    } }]), e21;
  }();
  var Fe = function() {
    function e21(t16) {
      if (v6(this, e21), this._obj = /* @__PURE__ */ Object.create(null), this.size = 0, null != t16) {
        var n12;
        n12 = null != t16.instanceString && t16.instanceString() === this.instanceString() ? t16.toArray() : t16;
        for (var r9 = 0; r9 < n12.length; r9++)
          this.add(n12[r9]);
      }
    }
    return m7(e21, [{ key: "instanceString", value: function() {
      return "set";
    } }, { key: "add", value: function(e22) {
      var t16 = this._obj;
      1 !== t16[e22] && (t16[e22] = 1, this.size++);
    } }, { key: "delete", value: function(e22) {
      var t16 = this._obj;
      1 === t16[e22] && (t16[e22] = 0, this.size--);
    } }, { key: "clear", value: function() {
      this._obj = /* @__PURE__ */ Object.create(null);
    } }, { key: "has", value: function(e22) {
      return 1 === this._obj[e22];
    } }, { key: "toArray", value: function() {
      var e22 = this;
      return Object.keys(this._obj).filter(function(t16) {
        return e22.has(t16);
      });
    } }, { key: "forEach", value: function(e22, t16) {
      return this.toArray().forEach(e22, t16);
    } }]), e21;
  }();
  var qe = "undefined" !== ("undefined" == typeof Set ? "undefined" : g6(Set)) ? Set : Fe;
  var je = function(e21, t16) {
    var n12 = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
    if (void 0 !== e21 && void 0 !== t16 && R4(e21)) {
      var r9 = t16.group;
      if (null == r9 && (r9 = t16.data && null != t16.data.source && null != t16.data.target ? "edges" : "nodes"), "nodes" === r9 || "edges" === r9) {
        this.length = 1, this[0] = this;
        var a10 = this._private = { cy: e21, single: true, data: t16.data || {}, position: t16.position || { x: 0, y: 0 }, autoWidth: void 0, autoHeight: void 0, autoPadding: void 0, compoundBoundsClean: false, listeners: [], group: r9, style: {}, rstyle: {}, styleCxts: [], styleKeys: {}, removed: true, selected: !!t16.selected, selectable: void 0 === t16.selectable || !!t16.selectable, locked: !!t16.locked, grabbed: false, grabbable: void 0 === t16.grabbable || !!t16.grabbable, pannable: void 0 === t16.pannable ? "edges" === r9 : !!t16.pannable, active: false, classes: new qe(), animation: { current: [], queue: [] }, rscratch: {}, scratch: t16.scratch || {}, edges: [], children: [], parent: t16.parent && t16.parent.isNode() ? t16.parent : null, traversalCache: {}, backgrounding: false, bbCache: null, bbCacheShift: { x: 0, y: 0 }, bodyBounds: null, overlayBounds: null, labelBounds: { all: null, source: null, target: null, main: null }, arrowBounds: { source: null, target: null, "mid-source": null, "mid-target": null } };
        if (null == a10.position.x && (a10.position.x = 0), null == a10.position.y && (a10.position.y = 0), t16.renderedPosition) {
          var i11 = t16.renderedPosition, o12 = e21.pan(), s11 = e21.zoom();
          a10.position = { x: (i11.x - o12.x) / s11, y: (i11.y - o12.y) / s11 };
        }
        var l11 = [];
        _5(t16.classes) ? l11 = t16.classes : M6(t16.classes) && (l11 = t16.classes.split(/\s+/));
        for (var u10 = 0, c10 = l11.length; u10 < c10; u10++) {
          var d12 = l11[u10];
          d12 && "" !== d12 && a10.classes.add(d12);
        }
        this.createEmitter();
        var h10 = t16.style || t16.css;
        h10 && (Me("Setting a `style` bypass at element creation should be done only when absolutely necessary.  Try to use the stylesheet instead."), this.style(h10)), (void 0 === n12 || n12) && this.restore();
      } else
        Pe("An element must be of type `nodes` or `edges`; you specified `" + r9 + "`");
    } else
      Pe("An element must have a core reference and parameters set");
  };
  var Ye = function(e21) {
    return e21 = { bfs: e21.bfs || !e21.dfs, dfs: e21.dfs || !e21.bfs }, function(t16, n12, r9) {
      var a10;
      N6(t16) && !L5(t16) && (t16 = (a10 = t16).roots || a10.root, n12 = a10.visit, r9 = a10.directed), r9 = 2 !== arguments.length || B5(n12) ? r9 : n12, n12 = B5(n12) ? n12 : function() {
      };
      for (var i11, o12 = this._private.cy, s11 = t16 = M6(t16) ? this.filter(t16) : t16, l11 = [], u10 = [], c10 = {}, d12 = {}, h10 = {}, p10 = 0, f11 = this.byGroup(), g9 = f11.nodes, v12 = f11.edges, y10 = 0; y10 < s11.length; y10++) {
        var m12 = s11[y10], b11 = m12.id();
        m12.isNode() && (l11.unshift(m12), e21.bfs && (h10[b11] = true, u10.push(m12)), d12[b11] = 0);
      }
      for (var x10 = function() {
        var t17 = e21.bfs ? l11.shift() : l11.pop(), a11 = t17.id();
        if (e21.dfs) {
          if (h10[a11])
            return "continue";
          h10[a11] = true, u10.push(t17);
        }
        var o13, s12 = d12[a11], f12 = c10[a11], y11 = null != f12 ? f12.source() : null, m13 = null != f12 ? f12.target() : null, b12 = null == f12 ? void 0 : t17.same(y11) ? m13[0] : y11[0];
        if (true === (o13 = n12(t17, f12, b12, p10++, s12)))
          return i11 = t17, "break";
        if (false === o13)
          return "break";
        for (var x11 = t17.connectedEdges().filter(function(e22) {
          return (!r9 || e22.source().same(t17)) && v12.has(e22);
        }), w12 = 0; w12 < x11.length; w12++) {
          var E10 = x11[w12], k11 = E10.connectedNodes().filter(function(e22) {
            return !e22.same(t17) && g9.has(e22);
          }), C10 = k11.id();
          0 === k11.length || h10[C10] || (k11 = k11[0], l11.push(k11), e21.bfs && (h10[C10] = true, u10.push(k11)), c10[C10] = E10, d12[C10] = d12[a11] + 1);
        }
      }; 0 !== l11.length; ) {
        var w11 = x10();
        if ("continue" !== w11 && "break" === w11)
          break;
      }
      for (var E9 = o12.collection(), k10 = 0; k10 < u10.length; k10++) {
        var C9 = u10[k10], S8 = c10[C9.id()];
        null != S8 && E9.push(S8), E9.push(C9);
      }
      return { path: o12.collection(E9), found: o12.collection(i11) };
    };
  };
  var Xe = { breadthFirstSearch: Ye({ bfs: true }), depthFirstSearch: Ye({ dfs: true }) };
  Xe.bfs = Xe.breadthFirstSearch, Xe.dfs = Xe.depthFirstSearch;
  var We = ze({ root: null, weight: function(e21) {
    return 1;
  }, directed: false });
  var He = { dijkstra: function(e21) {
    if (!N6(e21)) {
      var t16 = arguments;
      e21 = { root: t16[0], weight: t16[1], directed: t16[2] };
    }
    var n12 = We(e21), r9 = n12.root, a10 = n12.weight, i11 = n12.directed, o12 = this, s11 = a10, l11 = M6(r9) ? this.filter(r9)[0] : r9[0], u10 = {}, c10 = {}, h10 = {}, p10 = this.byGroup(), f11 = p10.nodes, g9 = p10.edges;
    g9.unmergeBy(function(e22) {
      return e22.isLoop();
    });
    for (var v12 = function(e22) {
      return u10[e22.id()];
    }, y10 = function(e22, t17) {
      u10[e22.id()] = t17, m12.updateItem(e22);
    }, m12 = new d7.default(function(e22, t17) {
      return v12(e22) - v12(t17);
    }), b11 = 0; b11 < f11.length; b11++) {
      var x10 = f11[b11];
      u10[x10.id()] = x10.same(l11) ? 0 : 1 / 0, m12.push(x10);
    }
    for (var w11 = function(e22, t17) {
      for (var n13, r10 = (i11 ? e22.edgesTo(t17) : e22.edgesWith(t17)).intersect(g9), a11 = 1 / 0, o13 = 0; o13 < r10.length; o13++) {
        var l12 = r10[o13], u11 = s11(l12);
        (u11 < a11 || !n13) && (a11 = u11, n13 = l12);
      }
      return { edge: n13, dist: a11 };
    }; m12.size() > 0; ) {
      var E9 = m12.pop(), k10 = v12(E9), C9 = E9.id();
      if (h10[C9] = k10, k10 !== 1 / 0)
        for (var S8 = E9.neighborhood().intersect(f11), D9 = 0; D9 < S8.length; D9++) {
          var P10 = S8[D9], T9 = P10.id(), B9 = w11(E9, P10), _7 = k10 + B9.dist;
          _7 < v12(P10) && (y10(P10, _7), c10[T9] = { node: E9, edge: B9.edge });
        }
    }
    return { distanceTo: function(e22) {
      var t17 = M6(e22) ? f11.filter(e22)[0] : e22[0];
      return h10[t17.id()];
    }, pathTo: function(e22) {
      var t17 = M6(e22) ? f11.filter(e22)[0] : e22[0], n13 = [], r10 = t17, a11 = r10.id();
      if (t17.length > 0)
        for (n13.unshift(t17); c10[a11]; ) {
          var i12 = c10[a11];
          n13.unshift(i12.edge), n13.unshift(i12.node), a11 = (r10 = i12.node).id();
        }
      return o12.spawn(n13);
    } };
  } };
  var Ke = { kruskal: function(e21) {
    e21 = e21 || function(e22) {
      return 1;
    };
    for (var t16 = this.byGroup(), n12 = t16.nodes, r9 = t16.edges, a10 = n12.length, i11 = new Array(a10), o12 = n12, s11 = function(e22) {
      for (var t17 = 0; t17 < i11.length; t17++) {
        if (i11[t17].has(e22))
          return t17;
      }
    }, l11 = 0; l11 < a10; l11++)
      i11[l11] = this.spawn(n12[l11]);
    for (var u10 = r9.sort(function(t17, n13) {
      return e21(t17) - e21(n13);
    }), c10 = 0; c10 < u10.length; c10++) {
      var d12 = u10[c10], h10 = d12.source()[0], p10 = d12.target()[0], f11 = s11(h10), g9 = s11(p10), v12 = i11[f11], y10 = i11[g9];
      f11 !== g9 && (o12.merge(d12), v12.merge(y10), i11.splice(g9, 1));
    }
    return o12;
  } };
  var Ge = ze({ root: null, goal: null, weight: function(e21) {
    return 1;
  }, heuristic: function(e21) {
    return 0;
  }, directed: false });
  var Ue = { aStar: function(e21) {
    var t16 = this.cy(), n12 = Ge(e21), r9 = n12.root, a10 = n12.goal, i11 = n12.heuristic, o12 = n12.directed, s11 = n12.weight;
    r9 = t16.collection(r9)[0], a10 = t16.collection(a10)[0];
    var l11, u10, c10 = r9.id(), h10 = a10.id(), p10 = {}, f11 = {}, g9 = {}, v12 = new d7.default(function(e22, t17) {
      return f11[e22.id()] - f11[t17.id()];
    }), y10 = new qe(), m12 = {}, b11 = {}, x10 = function(e22, t17) {
      v12.push(e22), y10.add(t17);
    };
    x10(r9, c10), p10[c10] = 0, f11[c10] = i11(r9);
    for (var w11, E9 = 0; v12.size() > 0; ) {
      if (l11 = v12.pop(), u10 = l11.id(), y10.delete(u10), E9++, u10 === h10) {
        for (var k10 = [], C9 = a10, S8 = h10, D9 = b11[S8]; k10.unshift(C9), null != D9 && k10.unshift(D9), null != (C9 = m12[S8]); )
          D9 = b11[S8 = C9.id()];
        return { found: true, distance: p10[u10], path: this.spawn(k10), steps: E9 };
      }
      g9[u10] = true;
      for (var P10 = l11._private.edges, T9 = 0; T9 < P10.length; T9++) {
        var M9 = P10[T9];
        if (this.hasElementWithId(M9.id()) && (!o12 || M9.data("source") === u10)) {
          var B9 = M9.source(), _7 = M9.target(), N8 = B9.id() !== u10 ? B9 : _7, I8 = N8.id();
          if (this.hasElementWithId(I8) && !g9[I8]) {
            var z8 = p10[u10] + s11(M9);
            w11 = I8, y10.has(w11) ? z8 < p10[I8] && (p10[I8] = z8, f11[I8] = z8 + i11(N8), m12[I8] = l11, b11[I8] = M9) : (p10[I8] = z8, f11[I8] = z8 + i11(N8), x10(N8, I8), m12[I8] = l11, b11[I8] = M9);
          }
        }
      }
    }
    return { found: false, distance: void 0, path: void 0, steps: E9 };
  } };
  var Ze = ze({ weight: function(e21) {
    return 1;
  }, directed: false });
  var $e = { floydWarshall: function(e21) {
    for (var t16 = this.cy(), n12 = Ze(e21), r9 = n12.weight, a10 = n12.directed, i11 = r9, o12 = this.byGroup(), s11 = o12.nodes, l11 = o12.edges, u10 = s11.length, c10 = u10 * u10, d12 = function(e22) {
      return s11.indexOf(e22);
    }, h10 = function(e22) {
      return s11[e22];
    }, p10 = new Array(c10), f11 = 0; f11 < c10; f11++) {
      var g9 = f11 % u10, v12 = (f11 - g9) / u10;
      p10[f11] = v12 === g9 ? 0 : 1 / 0;
    }
    for (var y10 = new Array(c10), m12 = new Array(c10), b11 = 0; b11 < l11.length; b11++) {
      var x10 = l11[b11], w11 = x10.source()[0], E9 = x10.target()[0];
      if (w11 !== E9) {
        var k10 = d12(w11), C9 = d12(E9), S8 = k10 * u10 + C9, D9 = i11(x10);
        if (p10[S8] > D9 && (p10[S8] = D9, y10[S8] = C9, m12[S8] = x10), !a10) {
          var P10 = C9 * u10 + k10;
          !a10 && p10[P10] > D9 && (p10[P10] = D9, y10[P10] = k10, m12[P10] = x10);
        }
      }
    }
    for (var T9 = 0; T9 < u10; T9++)
      for (var B9 = 0; B9 < u10; B9++)
        for (var _7 = B9 * u10 + T9, N8 = 0; N8 < u10; N8++) {
          var I8 = B9 * u10 + N8, z8 = T9 * u10 + N8;
          p10[_7] + p10[z8] < p10[I8] && (p10[I8] = p10[_7] + p10[z8], y10[I8] = y10[_7]);
        }
    var L9 = function(e22) {
      return d12(function(e23) {
        return (M6(e23) ? t16.filter(e23) : e23)[0];
      }(e22));
    }, A10 = { distance: function(e22, t17) {
      var n13 = L9(e22), r10 = L9(t17);
      return p10[n13 * u10 + r10];
    }, path: function(e22, n13) {
      var r10 = L9(e22), a11 = L9(n13), i12 = h10(r10);
      if (r10 === a11)
        return i12.collection();
      if (null == y10[r10 * u10 + a11])
        return t16.collection();
      var o13, s12 = t16.collection(), l12 = r10;
      for (s12.merge(i12); r10 !== a11; )
        l12 = r10, r10 = y10[r10 * u10 + a11], o13 = m12[l12 * u10 + r10], s12.merge(o13), s12.merge(h10(r10));
      return s12;
    } };
    return A10;
  } };
  var Qe = ze({ weight: function(e21) {
    return 1;
  }, directed: false, root: null });
  var Je = { bellmanFord: function(e21) {
    var t16 = this, n12 = Qe(e21), r9 = n12.weight, a10 = n12.directed, i11 = n12.root, o12 = r9, s11 = this, l11 = this.cy(), u10 = this.byGroup(), c10 = u10.edges, d12 = u10.nodes, h10 = d12.length, p10 = new Ve(), f11 = false, g9 = [];
    i11 = l11.collection(i11)[0], c10.unmergeBy(function(e22) {
      return e22.isLoop();
    });
    for (var v12 = c10.length, y10 = function(e22) {
      var t17 = p10.get(e22.id());
      return t17 || (t17 = {}, p10.set(e22.id(), t17)), t17;
    }, m12 = function(e22) {
      return (M6(e22) ? l11.$(e22) : e22)[0];
    }, b11 = 0; b11 < h10; b11++) {
      var x10 = d12[b11], w11 = y10(x10);
      x10.same(i11) ? w11.dist = 0 : w11.dist = 1 / 0, w11.pred = null, w11.edge = null;
    }
    for (var E9 = false, k10 = function(e22, t17, n13, r10, a11, i12) {
      var o13 = r10.dist + i12;
      o13 < a11.dist && !n13.same(r10.edge) && (a11.dist = o13, a11.pred = e22, a11.edge = n13, E9 = true);
    }, C9 = 1; C9 < h10; C9++) {
      E9 = false;
      for (var S8 = 0; S8 < v12; S8++) {
        var D9 = c10[S8], P10 = D9.source(), T9 = D9.target(), B9 = o12(D9), _7 = y10(P10), N8 = y10(T9);
        k10(P10, 0, D9, _7, N8, B9), a10 || k10(T9, 0, D9, N8, _7, B9);
      }
      if (!E9)
        break;
    }
    if (E9)
      for (var I8 = [], z8 = 0; z8 < v12; z8++) {
        var L9 = c10[z8], A10 = L9.source(), O10 = L9.target(), R8 = o12(L9), V8 = y10(A10).dist, F9 = y10(O10).dist;
        if (V8 + R8 < F9 || !a10 && F9 + R8 < V8) {
          if (f11 || (Me("Graph contains a negative weight cycle for Bellman-Ford"), f11 = true), false === e21.findNegativeWeightCycles)
            break;
          var q8 = [];
          V8 + R8 < F9 && q8.push(A10), !a10 && F9 + R8 < V8 && q8.push(O10);
          for (var j9 = q8.length, Y6 = 0; Y6 < j9; Y6++) {
            var X6 = q8[Y6], W8 = [X6];
            W8.push(y10(X6).edge);
            for (var H8 = y10(X6).pred; -1 === W8.indexOf(H8); )
              W8.push(H8), W8.push(y10(H8).edge), H8 = y10(H8).pred;
            for (var K6 = (W8 = W8.slice(W8.indexOf(H8)))[0].id(), G7 = 0, U7 = 2; U7 < W8.length; U7 += 2)
              W8[U7].id() < K6 && (K6 = W8[U7].id(), G7 = U7);
            (W8 = W8.slice(G7).concat(W8.slice(0, G7))).push(W8[0]);
            var Z6 = W8.map(function(e22) {
              return e22.id();
            }).join(",");
            -1 === I8.indexOf(Z6) && (g9.push(s11.spawn(W8)), I8.push(Z6));
          }
        }
      }
    return { distanceTo: function(e22) {
      return y10(m12(e22)).dist;
    }, pathTo: function(e22) {
      for (var n13 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : i11, r10 = [], a11 = m12(e22); ; ) {
        if (null == a11)
          return t16.spawn();
        var o13 = y10(a11), l12 = o13.edge, u11 = o13.pred;
        if (r10.unshift(a11[0]), a11.same(n13) && r10.length > 0)
          break;
        null != l12 && r10.unshift(l12), a11 = u11;
      }
      return s11.spawn(r10);
    }, hasNegativeWeightCycle: f11, negativeWeightCycles: g9 };
  } };
  var et4 = Math.sqrt(2);
  var tt4 = function(e21, t16, n12) {
    0 === n12.length && Pe("Karger-Stein must be run on a connected (sub)graph");
    for (var r9 = n12[e21], a10 = r9[1], i11 = r9[2], o12 = t16[a10], s11 = t16[i11], l11 = n12, u10 = l11.length - 1; u10 >= 0; u10--) {
      var c10 = l11[u10], d12 = c10[1], h10 = c10[2];
      (t16[d12] === o12 && t16[h10] === s11 || t16[d12] === s11 && t16[h10] === o12) && l11.splice(u10, 1);
    }
    for (var p10 = 0; p10 < l11.length; p10++) {
      var f11 = l11[p10];
      f11[1] === s11 ? (l11[p10] = f11.slice(), l11[p10][1] = o12) : f11[2] === s11 && (l11[p10] = f11.slice(), l11[p10][2] = o12);
    }
    for (var g9 = 0; g9 < t16.length; g9++)
      t16[g9] === s11 && (t16[g9] = o12);
    return l11;
  };
  var nt4 = function(e21, t16, n12, r9) {
    for (; n12 > r9; ) {
      var a10 = Math.floor(Math.random() * t16.length);
      t16 = tt4(a10, e21, t16), n12--;
    }
    return t16;
  };
  var rt4 = { kargerStein: function() {
    var e21 = this, t16 = this.byGroup(), n12 = t16.nodes, r9 = t16.edges;
    r9.unmergeBy(function(e22) {
      return e22.isLoop();
    });
    var a10 = n12.length, i11 = r9.length, o12 = Math.ceil(Math.pow(Math.log(a10) / Math.LN2, 2)), s11 = Math.floor(a10 / et4);
    if (!(a10 < 2)) {
      for (var l11 = [], u10 = 0; u10 < i11; u10++) {
        var c10 = r9[u10];
        l11.push([u10, n12.indexOf(c10.source()), n12.indexOf(c10.target())]);
      }
      for (var d12 = 1 / 0, h10 = [], p10 = new Array(a10), f11 = new Array(a10), g9 = new Array(a10), v12 = function(e22, t17) {
        for (var n13 = 0; n13 < a10; n13++)
          t17[n13] = e22[n13];
      }, y10 = 0; y10 <= o12; y10++) {
        for (var m12 = 0; m12 < a10; m12++)
          f11[m12] = m12;
        var b11 = nt4(f11, l11.slice(), a10, s11), x10 = b11.slice();
        v12(f11, g9);
        var w11 = nt4(f11, b11, s11, 2), E9 = nt4(g9, x10, s11, 2);
        w11.length <= E9.length && w11.length < d12 ? (d12 = w11.length, h10 = w11, v12(f11, p10)) : E9.length <= w11.length && E9.length < d12 && (d12 = E9.length, h10 = E9, v12(g9, p10));
      }
      for (var k10 = this.spawn(h10.map(function(e22) {
        return r9[e22[0]];
      })), C9 = this.spawn(), S8 = this.spawn(), D9 = p10[0], P10 = 0; P10 < p10.length; P10++) {
        var T9 = p10[P10], M9 = n12[P10];
        T9 === D9 ? C9.merge(M9) : S8.merge(M9);
      }
      var B9 = function(t17) {
        var n13 = e21.spawn();
        return t17.forEach(function(t18) {
          n13.merge(t18), t18.connectedEdges().forEach(function(t19) {
            e21.contains(t19) && !k10.contains(t19) && n13.merge(t19);
          });
        }), n13;
      }, _7 = [B9(C9), B9(S8)];
      return { cut: k10, components: _7, partition1: C9, partition2: S8 };
    }
    Pe("At least 2 nodes are required for Karger-Stein algorithm");
  } };
  var at4 = function(e21, t16, n12) {
    return { x: e21.x * t16 + n12.x, y: e21.y * t16 + n12.y };
  };
  var it4 = function(e21, t16, n12) {
    return { x: (e21.x - n12.x) / t16, y: (e21.y - n12.y) / t16 };
  };
  var ot4 = function(e21) {
    return { x: e21[0], y: e21[1] };
  };
  var st4 = function(e21, t16) {
    return Math.atan2(t16, e21) - Math.PI / 2;
  };
  var lt4 = Math.log2 || function(e21) {
    return Math.log(e21) / Math.log(2);
  };
  var ut4 = function(e21) {
    return e21 > 0 ? 1 : e21 < 0 ? -1 : 0;
  };
  var ct4 = function(e21, t16) {
    return Math.sqrt(dt4(e21, t16));
  };
  var dt4 = function(e21, t16) {
    var n12 = t16.x - e21.x, r9 = t16.y - e21.y;
    return n12 * n12 + r9 * r9;
  };
  var ht4 = function(e21) {
    for (var t16 = e21.length, n12 = 0, r9 = 0; r9 < t16; r9++)
      n12 += e21[r9];
    for (var a10 = 0; a10 < t16; a10++)
      e21[a10] = e21[a10] / n12;
    return e21;
  };
  var pt4 = function(e21, t16, n12, r9) {
    return (1 - r9) * (1 - r9) * e21 + 2 * (1 - r9) * r9 * t16 + r9 * r9 * n12;
  };
  var ft4 = function(e21, t16, n12, r9) {
    return { x: pt4(e21.x, t16.x, n12.x, r9), y: pt4(e21.y, t16.y, n12.y, r9) };
  };
  var gt4 = function(e21, t16, n12) {
    return Math.max(e21, Math.min(n12, t16));
  };
  var vt4 = function(e21) {
    if (null == e21)
      return { x1: 1 / 0, y1: 1 / 0, x2: -1 / 0, y2: -1 / 0, w: 0, h: 0 };
    if (null != e21.x1 && null != e21.y1) {
      if (null != e21.x2 && null != e21.y2 && e21.x2 >= e21.x1 && e21.y2 >= e21.y1)
        return { x1: e21.x1, y1: e21.y1, x2: e21.x2, y2: e21.y2, w: e21.x2 - e21.x1, h: e21.y2 - e21.y1 };
      if (null != e21.w && null != e21.h && e21.w >= 0 && e21.h >= 0)
        return { x1: e21.x1, y1: e21.y1, x2: e21.x1 + e21.w, y2: e21.y1 + e21.h, w: e21.w, h: e21.h };
    }
  };
  var yt4 = function(e21, t16, n12) {
    e21.x1 = Math.min(e21.x1, t16), e21.x2 = Math.max(e21.x2, t16), e21.w = e21.x2 - e21.x1, e21.y1 = Math.min(e21.y1, n12), e21.y2 = Math.max(e21.y2, n12), e21.h = e21.y2 - e21.y1;
  };
  var mt4 = function(e21) {
    var t16 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
    return e21.x1 -= t16, e21.x2 += t16, e21.y1 -= t16, e21.y2 += t16, e21.w = e21.x2 - e21.x1, e21.h = e21.y2 - e21.y1, e21;
  };
  var bt4 = function(e21) {
    var t16, n12, r9, a10, i11 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [0];
    if (1 === i11.length)
      t16 = n12 = r9 = a10 = i11[0];
    else if (2 === i11.length)
      t16 = r9 = i11[0], a10 = n12 = i11[1];
    else if (4 === i11.length) {
      var o12 = x6(i11, 4);
      t16 = o12[0], n12 = o12[1], r9 = o12[2], a10 = o12[3];
    }
    return e21.x1 -= a10, e21.x2 += n12, e21.y1 -= t16, e21.y2 += r9, e21.w = e21.x2 - e21.x1, e21.h = e21.y2 - e21.y1, e21;
  };
  var xt4 = function(e21, t16) {
    e21.x1 = t16.x1, e21.y1 = t16.y1, e21.x2 = t16.x2, e21.y2 = t16.y2, e21.w = e21.x2 - e21.x1, e21.h = e21.y2 - e21.y1;
  };
  var wt4 = function(e21, t16) {
    return !(e21.x1 > t16.x2) && (!(t16.x1 > e21.x2) && (!(e21.x2 < t16.x1) && (!(t16.x2 < e21.x1) && (!(e21.y2 < t16.y1) && (!(t16.y2 < e21.y1) && (!(e21.y1 > t16.y2) && !(t16.y1 > e21.y2)))))));
  };
  var Et4 = function(e21, t16, n12) {
    return e21.x1 <= t16 && t16 <= e21.x2 && e21.y1 <= n12 && n12 <= e21.y2;
  };
  var kt4 = function(e21, t16) {
    return Et4(e21, t16.x1, t16.y1) && Et4(e21, t16.x2, t16.y2);
  };
  var Ct4 = function(e21, t16, n12, r9, a10, i11, o12) {
    var s11, l11 = jt4(a10, i11), u10 = a10 / 2, c10 = i11 / 2, d12 = r9 - c10 - o12;
    if ((s11 = At4(e21, t16, n12, r9, n12 - u10 + l11 - o12, d12, n12 + u10 - l11 + o12, d12, false)).length > 0)
      return s11;
    var h10 = n12 + u10 + o12;
    if ((s11 = At4(e21, t16, n12, r9, h10, r9 - c10 + l11 - o12, h10, r9 + c10 - l11 + o12, false)).length > 0)
      return s11;
    var p10 = r9 + c10 + o12;
    if ((s11 = At4(e21, t16, n12, r9, n12 - u10 + l11 - o12, p10, n12 + u10 - l11 + o12, p10, false)).length > 0)
      return s11;
    var f11, g9 = n12 - u10 - o12;
    if ((s11 = At4(e21, t16, n12, r9, g9, r9 - c10 + l11 - o12, g9, r9 + c10 - l11 + o12, false)).length > 0)
      return s11;
    var v12 = n12 - u10 + l11, y10 = r9 - c10 + l11;
    if ((f11 = zt4(e21, t16, n12, r9, v12, y10, l11 + o12)).length > 0 && f11[0] <= v12 && f11[1] <= y10)
      return [f11[0], f11[1]];
    var m12 = n12 + u10 - l11, b11 = r9 - c10 + l11;
    if ((f11 = zt4(e21, t16, n12, r9, m12, b11, l11 + o12)).length > 0 && f11[0] >= m12 && f11[1] <= b11)
      return [f11[0], f11[1]];
    var x10 = n12 + u10 - l11, w11 = r9 + c10 - l11;
    if ((f11 = zt4(e21, t16, n12, r9, x10, w11, l11 + o12)).length > 0 && f11[0] >= x10 && f11[1] >= w11)
      return [f11[0], f11[1]];
    var E9 = n12 - u10 + l11, k10 = r9 + c10 - l11;
    return (f11 = zt4(e21, t16, n12, r9, E9, k10, l11 + o12)).length > 0 && f11[0] <= E9 && f11[1] >= k10 ? [f11[0], f11[1]] : [];
  };
  var St4 = function(e21, t16, n12, r9, a10, i11, o12) {
    var s11 = o12, l11 = Math.min(n12, a10), u10 = Math.max(n12, a10), c10 = Math.min(r9, i11), d12 = Math.max(r9, i11);
    return l11 - s11 <= e21 && e21 <= u10 + s11 && c10 - s11 <= t16 && t16 <= d12 + s11;
  };
  var Dt4 = function(e21, t16, n12, r9, a10, i11, o12, s11, l11) {
    var u10 = Math.min(n12, o12, a10) - l11, c10 = Math.max(n12, o12, a10) + l11, d12 = Math.min(r9, s11, i11) - l11, h10 = Math.max(r9, s11, i11) + l11;
    return !(e21 < u10 || e21 > c10 || t16 < d12 || t16 > h10);
  };
  var Pt4 = function(e21, t16, n12, r9, a10, i11, o12, s11) {
    var l11 = [];
    !function(e22, t17, n13, r10, a11) {
      var i12, o13, s12, l12, u11, c11, d13, h11;
      0 === e22 && (e22 = 1e-5), s12 = -27 * (r10 /= e22) + (t17 /= e22) * (9 * (n13 /= e22) - t17 * t17 * 2), i12 = (o13 = (3 * n13 - t17 * t17) / 9) * o13 * o13 + (s12 /= 54) * s12, a11[1] = 0, d13 = t17 / 3, i12 > 0 ? (u11 = (u11 = s12 + Math.sqrt(i12)) < 0 ? -Math.pow(-u11, 1 / 3) : Math.pow(u11, 1 / 3), c11 = (c11 = s12 - Math.sqrt(i12)) < 0 ? -Math.pow(-c11, 1 / 3) : Math.pow(c11, 1 / 3), a11[0] = -d13 + u11 + c11, d13 += (u11 + c11) / 2, a11[4] = a11[2] = -d13, d13 = Math.sqrt(3) * (-c11 + u11) / 2, a11[3] = d13, a11[5] = -d13) : (a11[5] = a11[3] = 0, 0 === i12 ? (h11 = s12 < 0 ? -Math.pow(-s12, 1 / 3) : Math.pow(s12, 1 / 3), a11[0] = 2 * h11 - d13, a11[4] = a11[2] = -(h11 + d13)) : (l12 = (o13 = -o13) * o13 * o13, l12 = Math.acos(s12 / Math.sqrt(l12)), h11 = 2 * Math.sqrt(o13), a11[0] = -d13 + h11 * Math.cos(l12 / 3), a11[2] = -d13 + h11 * Math.cos((l12 + 2 * Math.PI) / 3), a11[4] = -d13 + h11 * Math.cos((l12 + 4 * Math.PI) / 3)));
    }(1 * n12 * n12 - 4 * n12 * a10 + 2 * n12 * o12 + 4 * a10 * a10 - 4 * a10 * o12 + o12 * o12 + r9 * r9 - 4 * r9 * i11 + 2 * r9 * s11 + 4 * i11 * i11 - 4 * i11 * s11 + s11 * s11, 9 * n12 * a10 - 3 * n12 * n12 - 3 * n12 * o12 - 6 * a10 * a10 + 3 * a10 * o12 + 9 * r9 * i11 - 3 * r9 * r9 - 3 * r9 * s11 - 6 * i11 * i11 + 3 * i11 * s11, 3 * n12 * n12 - 6 * n12 * a10 + n12 * o12 - n12 * e21 + 2 * a10 * a10 + 2 * a10 * e21 - o12 * e21 + 3 * r9 * r9 - 6 * r9 * i11 + r9 * s11 - r9 * t16 + 2 * i11 * i11 + 2 * i11 * t16 - s11 * t16, 1 * n12 * a10 - n12 * n12 + n12 * e21 - a10 * e21 + r9 * i11 - r9 * r9 + r9 * t16 - i11 * t16, l11);
    for (var u10 = [], c10 = 0; c10 < 6; c10 += 2)
      Math.abs(l11[c10 + 1]) < 1e-7 && l11[c10] >= 0 && l11[c10] <= 1 && u10.push(l11[c10]);
    u10.push(1), u10.push(0);
    for (var d12, h10, p10, f11 = -1, g9 = 0; g9 < u10.length; g9++)
      d12 = Math.pow(1 - u10[g9], 2) * n12 + 2 * (1 - u10[g9]) * u10[g9] * a10 + u10[g9] * u10[g9] * o12, h10 = Math.pow(1 - u10[g9], 2) * r9 + 2 * (1 - u10[g9]) * u10[g9] * i11 + u10[g9] * u10[g9] * s11, p10 = Math.pow(d12 - e21, 2) + Math.pow(h10 - t16, 2), f11 >= 0 ? p10 < f11 && (f11 = p10) : f11 = p10;
    return f11;
  };
  var Tt4 = function(e21, t16, n12, r9, a10, i11) {
    var o12 = [e21 - n12, t16 - r9], s11 = [a10 - n12, i11 - r9], l11 = s11[0] * s11[0] + s11[1] * s11[1], u10 = o12[0] * o12[0] + o12[1] * o12[1], c10 = o12[0] * s11[0] + o12[1] * s11[1], d12 = c10 * c10 / l11;
    return c10 < 0 ? u10 : d12 > l11 ? (e21 - a10) * (e21 - a10) + (t16 - i11) * (t16 - i11) : u10 - d12;
  };
  var Mt4 = function(e21, t16, n12) {
    for (var r9, a10, i11, o12, s11 = 0, l11 = 0; l11 < n12.length / 2; l11++)
      if (r9 = n12[2 * l11], a10 = n12[2 * l11 + 1], l11 + 1 < n12.length / 2 ? (i11 = n12[2 * (l11 + 1)], o12 = n12[2 * (l11 + 1) + 1]) : (i11 = n12[2 * (l11 + 1 - n12.length / 2)], o12 = n12[2 * (l11 + 1 - n12.length / 2) + 1]), r9 == e21 && i11 == e21)
        ;
      else {
        if (!(r9 >= e21 && e21 >= i11 || r9 <= e21 && e21 <= i11))
          continue;
        (e21 - r9) / (i11 - r9) * (o12 - a10) + a10 > t16 && s11++;
      }
    return s11 % 2 != 0;
  };
  var Bt4 = function(e21, t16, n12, r9, a10, i11, o12, s11, l11) {
    var u10, c10 = new Array(n12.length);
    null != s11[0] ? (u10 = Math.atan(s11[1] / s11[0]), s11[0] < 0 ? u10 += Math.PI / 2 : u10 = -u10 - Math.PI / 2) : u10 = s11;
    for (var d12, h10 = Math.cos(-u10), p10 = Math.sin(-u10), f11 = 0; f11 < c10.length / 2; f11++)
      c10[2 * f11] = i11 / 2 * (n12[2 * f11] * h10 - n12[2 * f11 + 1] * p10), c10[2 * f11 + 1] = o12 / 2 * (n12[2 * f11 + 1] * h10 + n12[2 * f11] * p10), c10[2 * f11] += r9, c10[2 * f11 + 1] += a10;
    if (l11 > 0) {
      var g9 = Nt4(c10, -l11);
      d12 = _t4(g9);
    } else
      d12 = c10;
    return Mt4(e21, t16, d12);
  };
  var _t4 = function(e21) {
    for (var t16, n12, r9, a10, i11, o12, s11, l11, u10 = new Array(e21.length / 2), c10 = 0; c10 < e21.length / 4; c10++) {
      t16 = e21[4 * c10], n12 = e21[4 * c10 + 1], r9 = e21[4 * c10 + 2], a10 = e21[4 * c10 + 3], c10 < e21.length / 4 - 1 ? (i11 = e21[4 * (c10 + 1)], o12 = e21[4 * (c10 + 1) + 1], s11 = e21[4 * (c10 + 1) + 2], l11 = e21[4 * (c10 + 1) + 3]) : (i11 = e21[0], o12 = e21[1], s11 = e21[2], l11 = e21[3]);
      var d12 = At4(t16, n12, r9, a10, i11, o12, s11, l11, true);
      u10[2 * c10] = d12[0], u10[2 * c10 + 1] = d12[1];
    }
    return u10;
  };
  var Nt4 = function(e21, t16) {
    for (var n12, r9, a10, i11, o12 = new Array(2 * e21.length), s11 = 0; s11 < e21.length / 2; s11++) {
      n12 = e21[2 * s11], r9 = e21[2 * s11 + 1], s11 < e21.length / 2 - 1 ? (a10 = e21[2 * (s11 + 1)], i11 = e21[2 * (s11 + 1) + 1]) : (a10 = e21[0], i11 = e21[1]);
      var l11 = i11 - r9, u10 = -(a10 - n12), c10 = Math.sqrt(l11 * l11 + u10 * u10), d12 = l11 / c10, h10 = u10 / c10;
      o12[4 * s11] = n12 + d12 * t16, o12[4 * s11 + 1] = r9 + h10 * t16, o12[4 * s11 + 2] = a10 + d12 * t16, o12[4 * s11 + 3] = i11 + h10 * t16;
    }
    return o12;
  };
  var It4 = function(e21, t16, n12, r9, a10, i11, o12) {
    return e21 -= a10, t16 -= i11, (e21 /= n12 / 2 + o12) * e21 + (t16 /= r9 / 2 + o12) * t16 <= 1;
  };
  var zt4 = function(e21, t16, n12, r9, a10, i11, o12) {
    var s11 = [n12 - e21, r9 - t16], l11 = [e21 - a10, t16 - i11], u10 = s11[0] * s11[0] + s11[1] * s11[1], c10 = 2 * (l11[0] * s11[0] + l11[1] * s11[1]), d12 = c10 * c10 - 4 * u10 * (l11[0] * l11[0] + l11[1] * l11[1] - o12 * o12);
    if (d12 < 0)
      return [];
    var h10 = (-c10 + Math.sqrt(d12)) / (2 * u10), p10 = (-c10 - Math.sqrt(d12)) / (2 * u10), f11 = Math.min(h10, p10), g9 = Math.max(h10, p10), v12 = [];
    if (f11 >= 0 && f11 <= 1 && v12.push(f11), g9 >= 0 && g9 <= 1 && v12.push(g9), 0 === v12.length)
      return [];
    var y10 = v12[0] * s11[0] + e21, m12 = v12[0] * s11[1] + t16;
    return v12.length > 1 ? v12[0] == v12[1] ? [y10, m12] : [y10, m12, v12[1] * s11[0] + e21, v12[1] * s11[1] + t16] : [y10, m12];
  };
  var Lt4 = function(e21, t16, n12) {
    return t16 <= e21 && e21 <= n12 || n12 <= e21 && e21 <= t16 ? e21 : e21 <= t16 && t16 <= n12 || n12 <= t16 && t16 <= e21 ? t16 : n12;
  };
  var At4 = function(e21, t16, n12, r9, a10, i11, o12, s11, l11) {
    var u10 = e21 - a10, c10 = n12 - e21, d12 = o12 - a10, h10 = t16 - i11, p10 = r9 - t16, f11 = s11 - i11, g9 = d12 * h10 - f11 * u10, v12 = c10 * h10 - p10 * u10, y10 = f11 * c10 - d12 * p10;
    if (0 !== y10) {
      var m12 = g9 / y10, b11 = v12 / y10, x10 = -1e-3;
      return x10 <= m12 && m12 <= 1.001 && x10 <= b11 && b11 <= 1.001 || l11 ? [e21 + m12 * c10, t16 + m12 * p10] : [];
    }
    return 0 === g9 || 0 === v12 ? Lt4(e21, n12, o12) === o12 ? [o12, s11] : Lt4(e21, n12, a10) === a10 ? [a10, i11] : Lt4(a10, o12, n12) === n12 ? [n12, r9] : [] : [];
  };
  var Ot4 = function(e21, t16, n12, r9, a10, i11, o12, s11) {
    var l11, u10, c10, d12, h10, p10, f11 = [], g9 = new Array(n12.length), v12 = true;
    if (null == i11 && (v12 = false), v12) {
      for (var y10 = 0; y10 < g9.length / 2; y10++)
        g9[2 * y10] = n12[2 * y10] * i11 + r9, g9[2 * y10 + 1] = n12[2 * y10 + 1] * o12 + a10;
      if (s11 > 0) {
        var m12 = Nt4(g9, -s11);
        u10 = _t4(m12);
      } else
        u10 = g9;
    } else
      u10 = n12;
    for (var b11 = 0; b11 < u10.length / 2; b11++)
      c10 = u10[2 * b11], d12 = u10[2 * b11 + 1], b11 < u10.length / 2 - 1 ? (h10 = u10[2 * (b11 + 1)], p10 = u10[2 * (b11 + 1) + 1]) : (h10 = u10[0], p10 = u10[1]), 0 !== (l11 = At4(e21, t16, r9, a10, c10, d12, h10, p10)).length && f11.push(l11[0], l11[1]);
    return f11;
  };
  var Rt4 = function(e21, t16, n12) {
    var r9 = [e21[0] - t16[0], e21[1] - t16[1]], a10 = Math.sqrt(r9[0] * r9[0] + r9[1] * r9[1]), i11 = (a10 - n12) / a10;
    return i11 < 0 && (i11 = 1e-5), [t16[0] + i11 * r9[0], t16[1] + i11 * r9[1]];
  };
  var Vt4 = function(e21, t16) {
    var n12 = qt4(e21, t16);
    return n12 = Ft4(n12);
  };
  var Ft4 = function(e21) {
    for (var t16, n12, r9 = e21.length / 2, a10 = 1 / 0, i11 = 1 / 0, o12 = -1 / 0, s11 = -1 / 0, l11 = 0; l11 < r9; l11++)
      t16 = e21[2 * l11], n12 = e21[2 * l11 + 1], a10 = Math.min(a10, t16), o12 = Math.max(o12, t16), i11 = Math.min(i11, n12), s11 = Math.max(s11, n12);
    for (var u10 = 2 / (o12 - a10), c10 = 2 / (s11 - i11), d12 = 0; d12 < r9; d12++)
      t16 = e21[2 * d12] = e21[2 * d12] * u10, n12 = e21[2 * d12 + 1] = e21[2 * d12 + 1] * c10, a10 = Math.min(a10, t16), o12 = Math.max(o12, t16), i11 = Math.min(i11, n12), s11 = Math.max(s11, n12);
    if (i11 < -1)
      for (var h10 = 0; h10 < r9; h10++)
        n12 = e21[2 * h10 + 1] = e21[2 * h10 + 1] + (-1 - i11);
    return e21;
  };
  var qt4 = function(e21, t16) {
    var n12 = 1 / e21 * 2 * Math.PI, r9 = e21 % 2 == 0 ? Math.PI / 2 + n12 / 2 : Math.PI / 2;
    r9 += t16;
    for (var a10, i11 = new Array(2 * e21), o12 = 0; o12 < e21; o12++)
      a10 = o12 * n12 + r9, i11[2 * o12] = Math.cos(a10), i11[2 * o12 + 1] = Math.sin(-a10);
    return i11;
  };
  var jt4 = function(e21, t16) {
    return Math.min(e21 / 4, t16 / 4, 8);
  };
  var Yt4 = function(e21, t16) {
    return Math.min(e21 / 10, t16 / 10, 8);
  };
  var Xt4 = function(e21, t16) {
    return { heightOffset: Math.min(15, 0.05 * t16), widthOffset: Math.min(100, 0.25 * e21), ctrlPtOffsetPct: 0.05 };
  };
  var Wt4 = ze({ dampingFactor: 0.8, precision: 1e-6, iterations: 200, weight: function(e21) {
    return 1;
  } });
  var Ht4 = { pageRank: function(e21) {
    for (var t16 = Wt4(e21), n12 = t16.dampingFactor, r9 = t16.precision, a10 = t16.iterations, i11 = t16.weight, o12 = this._private.cy, s11 = this.byGroup(), l11 = s11.nodes, u10 = s11.edges, c10 = l11.length, d12 = c10 * c10, h10 = u10.length, p10 = new Array(d12), f11 = new Array(c10), g9 = (1 - n12) / c10, v12 = 0; v12 < c10; v12++) {
      for (var y10 = 0; y10 < c10; y10++) {
        p10[v12 * c10 + y10] = 0;
      }
      f11[v12] = 0;
    }
    for (var m12 = 0; m12 < h10; m12++) {
      var b11 = u10[m12], x10 = b11.data("source"), w11 = b11.data("target");
      if (x10 !== w11) {
        var E9 = l11.indexOfId(x10), k10 = l11.indexOfId(w11), C9 = i11(b11);
        p10[k10 * c10 + E9] += C9, f11[E9] += C9;
      }
    }
    for (var S8 = 1 / c10 + g9, D9 = 0; D9 < c10; D9++)
      if (0 === f11[D9])
        for (var P10 = 0; P10 < c10; P10++) {
          p10[P10 * c10 + D9] = S8;
        }
      else
        for (var T9 = 0; T9 < c10; T9++) {
          var M9 = T9 * c10 + D9;
          p10[M9] = p10[M9] / f11[D9] + g9;
        }
    for (var B9, _7 = new Array(c10), N8 = new Array(c10), I8 = 0; I8 < c10; I8++)
      _7[I8] = 1;
    for (var z8 = 0; z8 < a10; z8++) {
      for (var L9 = 0; L9 < c10; L9++)
        N8[L9] = 0;
      for (var A10 = 0; A10 < c10; A10++)
        for (var O10 = 0; O10 < c10; O10++) {
          var R8 = A10 * c10 + O10;
          N8[A10] += p10[R8] * _7[O10];
        }
      ht4(N8), B9 = _7, _7 = N8, N8 = B9;
      for (var V8 = 0, F9 = 0; F9 < c10; F9++) {
        var q8 = B9[F9] - _7[F9];
        V8 += q8 * q8;
      }
      if (V8 < r9)
        break;
    }
    return { rank: function(e22) {
      return e22 = o12.collection(e22)[0], _7[l11.indexOf(e22)];
    } };
  } };
  var Kt4 = ze({ root: null, weight: function(e21) {
    return 1;
  }, directed: false, alpha: 0 });
  var Gt4 = { degreeCentralityNormalized: function(e21) {
    e21 = Kt4(e21);
    var t16 = this.cy(), n12 = this.nodes(), r9 = n12.length;
    if (e21.directed) {
      for (var a10 = {}, i11 = {}, o12 = 0, s11 = 0, l11 = 0; l11 < r9; l11++) {
        var u10 = n12[l11], c10 = u10.id();
        e21.root = u10;
        var d12 = this.degreeCentrality(e21);
        o12 < d12.indegree && (o12 = d12.indegree), s11 < d12.outdegree && (s11 = d12.outdegree), a10[c10] = d12.indegree, i11[c10] = d12.outdegree;
      }
      return { indegree: function(e22) {
        return 0 == o12 ? 0 : (M6(e22) && (e22 = t16.filter(e22)), a10[e22.id()] / o12);
      }, outdegree: function(e22) {
        return 0 === s11 ? 0 : (M6(e22) && (e22 = t16.filter(e22)), i11[e22.id()] / s11);
      } };
    }
    for (var h10 = {}, p10 = 0, f11 = 0; f11 < r9; f11++) {
      var g9 = n12[f11];
      e21.root = g9;
      var v12 = this.degreeCentrality(e21);
      p10 < v12.degree && (p10 = v12.degree), h10[g9.id()] = v12.degree;
    }
    return { degree: function(e22) {
      return 0 === p10 ? 0 : (M6(e22) && (e22 = t16.filter(e22)), h10[e22.id()] / p10);
    } };
  }, degreeCentrality: function(e21) {
    e21 = Kt4(e21);
    var t16 = this.cy(), n12 = this, r9 = e21, a10 = r9.root, i11 = r9.weight, o12 = r9.directed, s11 = r9.alpha;
    if (a10 = t16.collection(a10)[0], o12) {
      for (var l11 = a10.connectedEdges(), u10 = l11.filter(function(e22) {
        return e22.target().same(a10) && n12.has(e22);
      }), c10 = l11.filter(function(e22) {
        return e22.source().same(a10) && n12.has(e22);
      }), d12 = u10.length, h10 = c10.length, p10 = 0, f11 = 0, g9 = 0; g9 < u10.length; g9++)
        p10 += i11(u10[g9]);
      for (var v12 = 0; v12 < c10.length; v12++)
        f11 += i11(c10[v12]);
      return { indegree: Math.pow(d12, 1 - s11) * Math.pow(p10, s11), outdegree: Math.pow(h10, 1 - s11) * Math.pow(f11, s11) };
    }
    for (var y10 = a10.connectedEdges().intersection(n12), m12 = y10.length, b11 = 0, x10 = 0; x10 < y10.length; x10++)
      b11 += i11(y10[x10]);
    return { degree: Math.pow(m12, 1 - s11) * Math.pow(b11, s11) };
  } };
  Gt4.dc = Gt4.degreeCentrality, Gt4.dcn = Gt4.degreeCentralityNormalised = Gt4.degreeCentralityNormalized;
  var Ut4 = ze({ harmonic: true, weight: function() {
    return 1;
  }, directed: false, root: null });
  var Zt4 = { closenessCentralityNormalized: function(e21) {
    for (var t16 = Ut4(e21), n12 = t16.harmonic, r9 = t16.weight, a10 = t16.directed, i11 = this.cy(), o12 = {}, s11 = 0, l11 = this.nodes(), u10 = this.floydWarshall({ weight: r9, directed: a10 }), c10 = 0; c10 < l11.length; c10++) {
      for (var d12 = 0, h10 = l11[c10], p10 = 0; p10 < l11.length; p10++)
        if (c10 !== p10) {
          var f11 = u10.distance(h10, l11[p10]);
          d12 += n12 ? 1 / f11 : f11;
        }
      n12 || (d12 = 1 / d12), s11 < d12 && (s11 = d12), o12[h10.id()] = d12;
    }
    return { closeness: function(e22) {
      return 0 == s11 ? 0 : (e22 = M6(e22) ? i11.filter(e22)[0].id() : e22.id(), o12[e22] / s11);
    } };
  }, closenessCentrality: function(e21) {
    var t16 = Ut4(e21), n12 = t16.root, r9 = t16.weight, a10 = t16.directed, i11 = t16.harmonic;
    n12 = this.filter(n12)[0];
    for (var o12 = this.dijkstra({ root: n12, weight: r9, directed: a10 }), s11 = 0, l11 = this.nodes(), u10 = 0; u10 < l11.length; u10++) {
      var c10 = l11[u10];
      if (!c10.same(n12)) {
        var d12 = o12.distanceTo(c10);
        s11 += i11 ? 1 / d12 : d12;
      }
    }
    return i11 ? s11 : 1 / s11;
  } };
  Zt4.cc = Zt4.closenessCentrality, Zt4.ccn = Zt4.closenessCentralityNormalised = Zt4.closenessCentralityNormalized;
  var $t4 = ze({ weight: null, directed: false });
  var Qt4 = { betweennessCentrality: function(e21) {
    for (var t16 = $t4(e21), n12 = t16.directed, r9 = t16.weight, a10 = null != r9, i11 = this.cy(), o12 = this.nodes(), s11 = {}, l11 = {}, u10 = 0, c10 = function(e22, t17) {
      l11[e22] = t17, t17 > u10 && (u10 = t17);
    }, h10 = function(e22) {
      return l11[e22];
    }, p10 = 0; p10 < o12.length; p10++) {
      var f11 = o12[p10], g9 = f11.id();
      s11[g9] = n12 ? f11.outgoers().nodes() : f11.openNeighborhood().nodes(), c10(g9, 0);
    }
    for (var v12 = function(e22) {
      for (var t17 = o12[e22].id(), n13 = [], l12 = {}, u11 = {}, p11 = {}, f12 = new d7.default(function(e23, t18) {
        return p11[e23] - p11[t18];
      }), g10 = 0; g10 < o12.length; g10++) {
        var v13 = o12[g10].id();
        l12[v13] = [], u11[v13] = 0, p11[v13] = 1 / 0;
      }
      for (u11[t17] = 1, p11[t17] = 0, f12.push(t17); !f12.empty(); ) {
        var y11 = f12.pop();
        if (n13.push(y11), a10)
          for (var m13 = 0; m13 < s11[y11].length; m13++) {
            var b11 = s11[y11][m13], x10 = i11.getElementById(y11), w11 = void 0;
            w11 = x10.edgesTo(b11).length > 0 ? x10.edgesTo(b11)[0] : b11.edgesTo(x10)[0];
            var E9 = r9(w11);
            b11 = b11.id(), p11[b11] > p11[y11] + E9 && (p11[b11] = p11[y11] + E9, f12.nodes.indexOf(b11) < 0 ? f12.push(b11) : f12.updateItem(b11), u11[b11] = 0, l12[b11] = []), p11[b11] == p11[y11] + E9 && (u11[b11] = u11[b11] + u11[y11], l12[b11].push(y11));
          }
        else
          for (var k10 = 0; k10 < s11[y11].length; k10++) {
            var C9 = s11[y11][k10].id();
            p11[C9] == 1 / 0 && (f12.push(C9), p11[C9] = p11[y11] + 1), p11[C9] == p11[y11] + 1 && (u11[C9] = u11[C9] + u11[y11], l12[C9].push(y11));
          }
      }
      for (var S8 = {}, D9 = 0; D9 < o12.length; D9++)
        S8[o12[D9].id()] = 0;
      for (; n13.length > 0; ) {
        for (var P10 = n13.pop(), T9 = 0; T9 < l12[P10].length; T9++) {
          var M9 = l12[P10][T9];
          S8[M9] = S8[M9] + u11[M9] / u11[P10] * (1 + S8[P10]);
        }
        P10 != o12[e22].id() && c10(P10, h10(P10) + S8[P10]);
      }
    }, y10 = 0; y10 < o12.length; y10++)
      v12(y10);
    var m12 = { betweenness: function(e22) {
      var t17 = i11.collection(e22).id();
      return h10(t17);
    }, betweennessNormalized: function(e22) {
      if (0 == u10)
        return 0;
      var t17 = i11.collection(e22).id();
      return h10(t17) / u10;
    } };
    return m12.betweennessNormalised = m12.betweennessNormalized, m12;
  } };
  Qt4.bc = Qt4.betweennessCentrality;
  var Jt4 = ze({ expandFactor: 2, inflateFactor: 2, multFactor: 1, maxIterations: 20, attributes: [function(e21) {
    return 1;
  }] });
  var en = function(e21, t16) {
    for (var n12 = 0, r9 = 0; r9 < t16.length; r9++)
      n12 += t16[r9](e21);
    return n12;
  };
  var tn = function(e21, t16) {
    for (var n12, r9 = 0; r9 < t16; r9++) {
      n12 = 0;
      for (var a10 = 0; a10 < t16; a10++)
        n12 += e21[a10 * t16 + r9];
      for (var i11 = 0; i11 < t16; i11++)
        e21[i11 * t16 + r9] = e21[i11 * t16 + r9] / n12;
    }
  };
  var nn = function(e21, t16, n12) {
    for (var r9 = new Array(n12 * n12), a10 = 0; a10 < n12; a10++) {
      for (var i11 = 0; i11 < n12; i11++)
        r9[a10 * n12 + i11] = 0;
      for (var o12 = 0; o12 < n12; o12++)
        for (var s11 = 0; s11 < n12; s11++)
          r9[a10 * n12 + s11] += e21[a10 * n12 + o12] * t16[o12 * n12 + s11];
    }
    return r9;
  };
  var rn = function(e21, t16, n12) {
    for (var r9 = e21.slice(0), a10 = 1; a10 < n12; a10++)
      e21 = nn(e21, r9, t16);
    return e21;
  };
  var an = function(e21, t16, n12) {
    for (var r9 = new Array(t16 * t16), a10 = 0; a10 < t16 * t16; a10++)
      r9[a10] = Math.pow(e21[a10], n12);
    return tn(r9, t16), r9;
  };
  var on = function(e21, t16, n12, r9) {
    for (var a10 = 0; a10 < n12; a10++) {
      if (Math.round(e21[a10] * Math.pow(10, r9)) / Math.pow(10, r9) !== Math.round(t16[a10] * Math.pow(10, r9)) / Math.pow(10, r9))
        return false;
    }
    return true;
  };
  var sn = function(e21, t16) {
    for (var n12 = 0; n12 < e21.length; n12++)
      if (!t16[n12] || e21[n12].id() !== t16[n12].id())
        return false;
    return true;
  };
  var ln = function(e21) {
    for (var t16 = this.nodes(), n12 = this.edges(), r9 = this.cy(), a10 = function(e22) {
      return Jt4(e22);
    }(e21), i11 = {}, o12 = 0; o12 < t16.length; o12++)
      i11[t16[o12].id()] = o12;
    for (var s11, l11 = t16.length, u10 = l11 * l11, c10 = new Array(u10), d12 = 0; d12 < u10; d12++)
      c10[d12] = 0;
    for (var h10 = 0; h10 < n12.length; h10++) {
      var p10 = n12[h10], f11 = i11[p10.source().id()], g9 = i11[p10.target().id()], v12 = en(p10, a10.attributes);
      c10[f11 * l11 + g9] += v12, c10[g9 * l11 + f11] += v12;
    }
    !function(e22, t17, n13) {
      for (var r10 = 0; r10 < t17; r10++)
        e22[r10 * t17 + r10] = n13;
    }(c10, l11, a10.multFactor), tn(c10, l11);
    for (var y10 = true, m12 = 0; y10 && m12 < a10.maxIterations; )
      y10 = false, s11 = rn(c10, l11, a10.expandFactor), c10 = an(s11, l11, a10.inflateFactor), on(c10, s11, u10, 4) || (y10 = true), m12++;
    var b11 = function(e22, t17, n13, r10) {
      for (var a11 = [], i12 = 0; i12 < t17; i12++) {
        for (var o13 = [], s12 = 0; s12 < t17; s12++)
          Math.round(1e3 * e22[i12 * t17 + s12]) / 1e3 > 0 && o13.push(n13[s12]);
        0 !== o13.length && a11.push(r10.collection(o13));
      }
      return a11;
    }(c10, l11, t16, r9);
    return b11 = function(e22) {
      for (var t17 = 0; t17 < e22.length; t17++)
        for (var n13 = 0; n13 < e22.length; n13++)
          t17 != n13 && sn(e22[t17], e22[n13]) && e22.splice(n13, 1);
      return e22;
    }(b11), b11;
  };
  var un = { markovClustering: ln, mcl: ln };
  var cn = function(e21) {
    return e21;
  };
  var dn = function(e21, t16) {
    return Math.abs(t16 - e21);
  };
  var hn = function(e21, t16, n12) {
    return e21 + dn(t16, n12);
  };
  var pn = function(e21, t16, n12) {
    return e21 + Math.pow(n12 - t16, 2);
  };
  var fn = function(e21) {
    return Math.sqrt(e21);
  };
  var gn = function(e21, t16, n12) {
    return Math.max(e21, dn(t16, n12));
  };
  var vn = function(e21, t16, n12, r9, a10) {
    for (var i11 = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : cn, o12 = r9, s11 = 0; s11 < e21; s11++)
      o12 = a10(o12, t16(s11), n12(s11));
    return i11(o12);
  };
  var yn = { euclidean: function(e21, t16, n12) {
    return e21 >= 2 ? vn(e21, t16, n12, 0, pn, fn) : vn(e21, t16, n12, 0, hn);
  }, squaredEuclidean: function(e21, t16, n12) {
    return vn(e21, t16, n12, 0, pn);
  }, manhattan: function(e21, t16, n12) {
    return vn(e21, t16, n12, 0, hn);
  }, max: function(e21, t16, n12) {
    return vn(e21, t16, n12, -1 / 0, gn);
  } };
  function mn(e21, t16, n12, r9, a10, i11) {
    var o12;
    return o12 = B5(e21) ? e21 : yn[e21] || yn.euclidean, 0 === t16 && B5(e21) ? o12(a10, i11) : o12(t16, n12, r9, a10, i11);
  }
  yn["squared-euclidean"] = yn.squaredEuclidean, yn.squaredeuclidean = yn.squaredEuclidean;
  var bn = ze({ k: 2, m: 2, sensitivityThreshold: 1e-4, distance: "euclidean", maxIterations: 10, attributes: [], testMode: false, testCentroids: null });
  var xn = function(e21) {
    return bn(e21);
  };
  var wn = function(e21, t16, n12, r9, a10) {
    var i11 = "kMedoids" !== a10 ? function(e22) {
      return n12[e22];
    } : function(e22) {
      return r9[e22](n12);
    }, o12 = n12, s11 = t16;
    return mn(e21, r9.length, i11, function(e22) {
      return r9[e22](t16);
    }, o12, s11);
  };
  var En = function(e21, t16, n12) {
    for (var r9 = n12.length, a10 = new Array(r9), i11 = new Array(r9), o12 = new Array(t16), s11 = null, l11 = 0; l11 < r9; l11++)
      a10[l11] = e21.min(n12[l11]).value, i11[l11] = e21.max(n12[l11]).value;
    for (var u10 = 0; u10 < t16; u10++) {
      s11 = [];
      for (var c10 = 0; c10 < r9; c10++)
        s11[c10] = Math.random() * (i11[c10] - a10[c10]) + a10[c10];
      o12[u10] = s11;
    }
    return o12;
  };
  var kn = function(e21, t16, n12, r9, a10) {
    for (var i11 = 1 / 0, o12 = 0, s11 = 0; s11 < t16.length; s11++) {
      var l11 = wn(n12, e21, t16[s11], r9, a10);
      l11 < i11 && (i11 = l11, o12 = s11);
    }
    return o12;
  };
  var Cn = function(e21, t16, n12) {
    for (var r9 = [], a10 = null, i11 = 0; i11 < t16.length; i11++)
      n12[(a10 = t16[i11]).id()] === e21 && r9.push(a10);
    return r9;
  };
  var Sn = function(e21, t16, n12) {
    for (var r9 = 0; r9 < e21.length; r9++)
      for (var a10 = 0; a10 < e21[r9].length; a10++) {
        if (Math.abs(e21[r9][a10] - t16[r9][a10]) > n12)
          return false;
      }
    return true;
  };
  var Dn = function(e21, t16, n12) {
    for (var r9 = 0; r9 < n12; r9++)
      if (e21 === t16[r9])
        return true;
    return false;
  };
  var Pn = function(e21, t16) {
    var n12 = new Array(t16);
    if (e21.length < 50)
      for (var r9 = 0; r9 < t16; r9++) {
        for (var a10 = e21[Math.floor(Math.random() * e21.length)]; Dn(a10, n12, r9); )
          a10 = e21[Math.floor(Math.random() * e21.length)];
        n12[r9] = a10;
      }
    else
      for (var i11 = 0; i11 < t16; i11++)
        n12[i11] = e21[Math.floor(Math.random() * e21.length)];
    return n12;
  };
  var Tn = function(e21, t16, n12) {
    for (var r9 = 0, a10 = 0; a10 < t16.length; a10++)
      r9 += wn("manhattan", t16[a10], e21, n12, "kMedoids");
    return r9;
  };
  var Mn = function(e21, t16, n12, r9, a10) {
    for (var i11, o12, s11 = 0; s11 < t16.length; s11++)
      for (var l11 = 0; l11 < e21.length; l11++)
        r9[s11][l11] = Math.pow(n12[s11][l11], a10.m);
    for (var u10 = 0; u10 < e21.length; u10++)
      for (var c10 = 0; c10 < a10.attributes.length; c10++) {
        i11 = 0, o12 = 0;
        for (var d12 = 0; d12 < t16.length; d12++)
          i11 += r9[d12][u10] * a10.attributes[c10](t16[d12]), o12 += r9[d12][u10];
        e21[u10][c10] = i11 / o12;
      }
  };
  var Bn = function(e21, t16, n12, r9, a10) {
    for (var i11 = 0; i11 < e21.length; i11++)
      t16[i11] = e21[i11].slice();
    for (var o12, s11, l11, u10 = 2 / (a10.m - 1), c10 = 0; c10 < n12.length; c10++)
      for (var d12 = 0; d12 < r9.length; d12++) {
        o12 = 0;
        for (var h10 = 0; h10 < n12.length; h10++)
          s11 = wn(a10.distance, r9[d12], n12[c10], a10.attributes, "cmeans"), l11 = wn(a10.distance, r9[d12], n12[h10], a10.attributes, "cmeans"), o12 += Math.pow(s11 / l11, u10);
        e21[d12][c10] = 1 / o12;
      }
  };
  var _n = function(e21) {
    var t16, n12, r9, a10, i11, o12 = this.cy(), s11 = this.nodes(), l11 = xn(e21);
    a10 = new Array(s11.length);
    for (var u10 = 0; u10 < s11.length; u10++)
      a10[u10] = new Array(l11.k);
    r9 = new Array(s11.length);
    for (var c10 = 0; c10 < s11.length; c10++)
      r9[c10] = new Array(l11.k);
    for (var d12 = 0; d12 < s11.length; d12++) {
      for (var h10 = 0, p10 = 0; p10 < l11.k; p10++)
        r9[d12][p10] = Math.random(), h10 += r9[d12][p10];
      for (var f11 = 0; f11 < l11.k; f11++)
        r9[d12][f11] = r9[d12][f11] / h10;
    }
    n12 = new Array(l11.k);
    for (var g9 = 0; g9 < l11.k; g9++)
      n12[g9] = new Array(l11.attributes.length);
    i11 = new Array(s11.length);
    for (var v12 = 0; v12 < s11.length; v12++)
      i11[v12] = new Array(l11.k);
    for (var y10 = true, m12 = 0; y10 && m12 < l11.maxIterations; )
      y10 = false, Mn(n12, s11, r9, i11, l11), Bn(r9, a10, n12, s11, l11), Sn(r9, a10, l11.sensitivityThreshold) || (y10 = true), m12++;
    return t16 = function(e22, t17, n13, r10) {
      for (var a11, i12, o13 = new Array(n13.k), s12 = 0; s12 < o13.length; s12++)
        o13[s12] = [];
      for (var l12 = 0; l12 < t17.length; l12++) {
        a11 = -1 / 0, i12 = -1;
        for (var u11 = 0; u11 < t17[0].length; u11++)
          t17[l12][u11] > a11 && (a11 = t17[l12][u11], i12 = u11);
        o13[i12].push(e22[l12]);
      }
      for (var c11 = 0; c11 < o13.length; c11++)
        o13[c11] = r10.collection(o13[c11]);
      return o13;
    }(s11, r9, l11, o12), { clusters: t16, degreeOfMembership: r9 };
  };
  var Nn = { kMeans: function(e21) {
    var t16, n12 = this.cy(), r9 = this.nodes(), a10 = null, i11 = xn(e21), o12 = new Array(i11.k), s11 = {};
    i11.testMode ? "number" == typeof i11.testCentroids ? (i11.testCentroids, t16 = En(r9, i11.k, i11.attributes)) : t16 = "object" === g6(i11.testCentroids) ? i11.testCentroids : En(r9, i11.k, i11.attributes) : t16 = En(r9, i11.k, i11.attributes);
    for (var l11, u10, c10, d12 = true, h10 = 0; d12 && h10 < i11.maxIterations; ) {
      for (var p10 = 0; p10 < r9.length; p10++)
        s11[(a10 = r9[p10]).id()] = kn(a10, t16, i11.distance, i11.attributes, "kMeans");
      d12 = false;
      for (var f11 = 0; f11 < i11.k; f11++) {
        var v12 = Cn(f11, r9, s11);
        if (0 !== v12.length) {
          for (var y10 = i11.attributes.length, m12 = t16[f11], b11 = new Array(y10), x10 = new Array(y10), w11 = 0; w11 < y10; w11++) {
            x10[w11] = 0;
            for (var E9 = 0; E9 < v12.length; E9++)
              a10 = v12[E9], x10[w11] += i11.attributes[w11](a10);
            b11[w11] = x10[w11] / v12.length, l11 = b11[w11], u10 = m12[w11], c10 = i11.sensitivityThreshold, Math.abs(u10 - l11) <= c10 || (d12 = true);
          }
          t16[f11] = b11, o12[f11] = n12.collection(v12);
        }
      }
      h10++;
    }
    return o12;
  }, kMedoids: function(e21) {
    var t16, n12, r9 = this.cy(), a10 = this.nodes(), i11 = null, o12 = xn(e21), s11 = new Array(o12.k), l11 = {}, u10 = new Array(o12.k);
    o12.testMode ? "number" == typeof o12.testCentroids || (t16 = "object" === g6(o12.testCentroids) ? o12.testCentroids : Pn(a10, o12.k)) : t16 = Pn(a10, o12.k);
    for (var c10 = true, d12 = 0; c10 && d12 < o12.maxIterations; ) {
      for (var h10 = 0; h10 < a10.length; h10++)
        l11[(i11 = a10[h10]).id()] = kn(i11, t16, o12.distance, o12.attributes, "kMedoids");
      c10 = false;
      for (var p10 = 0; p10 < t16.length; p10++) {
        var f11 = Cn(p10, a10, l11);
        if (0 !== f11.length) {
          u10[p10] = Tn(t16[p10], f11, o12.attributes);
          for (var v12 = 0; v12 < f11.length; v12++)
            (n12 = Tn(f11[v12], f11, o12.attributes)) < u10[p10] && (u10[p10] = n12, t16[p10] = f11[v12], c10 = true);
          s11[p10] = r9.collection(f11);
        }
      }
      d12++;
    }
    return s11;
  }, fuzzyCMeans: _n, fcm: _n };
  var In = ze({ distance: "euclidean", linkage: "min", mode: "threshold", threshold: 1 / 0, addDendrogram: false, dendrogramDepth: 0, attributes: [] });
  var zn = { single: "min", complete: "max" };
  var Ln = function(e21, t16, n12, r9, a10) {
    for (var i11, o12 = 0, s11 = 1 / 0, l11 = a10.attributes, u10 = function(e22, t17) {
      return mn(a10.distance, l11.length, function(t18) {
        return l11[t18](e22);
      }, function(e23) {
        return l11[e23](t17);
      }, e22, t17);
    }, c10 = 0; c10 < e21.length; c10++) {
      var d12 = e21[c10].key, h10 = n12[d12][r9[d12]];
      h10 < s11 && (o12 = d12, s11 = h10);
    }
    if ("threshold" === a10.mode && s11 >= a10.threshold || "dendrogram" === a10.mode && 1 === e21.length)
      return false;
    var p10, f11 = t16[o12], g9 = t16[r9[o12]];
    p10 = "dendrogram" === a10.mode ? { left: f11, right: g9, key: f11.key } : { value: f11.value.concat(g9.value), key: f11.key }, e21[f11.index] = p10, e21.splice(g9.index, 1), t16[f11.key] = p10;
    for (var v12 = 0; v12 < e21.length; v12++) {
      var y10 = e21[v12];
      f11.key === y10.key ? i11 = 1 / 0 : "min" === a10.linkage ? (i11 = n12[f11.key][y10.key], n12[f11.key][y10.key] > n12[g9.key][y10.key] && (i11 = n12[g9.key][y10.key])) : "max" === a10.linkage ? (i11 = n12[f11.key][y10.key], n12[f11.key][y10.key] < n12[g9.key][y10.key] && (i11 = n12[g9.key][y10.key])) : i11 = "mean" === a10.linkage ? (n12[f11.key][y10.key] * f11.size + n12[g9.key][y10.key] * g9.size) / (f11.size + g9.size) : "dendrogram" === a10.mode ? u10(y10.value, f11.value) : u10(y10.value[0], f11.value[0]), n12[f11.key][y10.key] = n12[y10.key][f11.key] = i11;
    }
    for (var m12 = 0; m12 < e21.length; m12++) {
      var b11 = e21[m12].key;
      if (r9[b11] === f11.key || r9[b11] === g9.key) {
        for (var x10 = b11, w11 = 0; w11 < e21.length; w11++) {
          var E9 = e21[w11].key;
          n12[b11][E9] < n12[b11][x10] && (x10 = E9);
        }
        r9[b11] = x10;
      }
      e21[m12].index = m12;
    }
    return f11.key = g9.key = f11.index = g9.index = null, true;
  };
  var An = function e7(t16, n12, r9) {
    t16 && (t16.value ? n12.push(t16.value) : (t16.left && e7(t16.left, n12), t16.right && e7(t16.right, n12)));
  };
  var On = function e8(t16, n12) {
    if (!t16)
      return "";
    if (t16.left && t16.right) {
      var r9 = e8(t16.left, n12), a10 = e8(t16.right, n12), i11 = n12.add({ group: "nodes", data: { id: r9 + "," + a10 } });
      return n12.add({ group: "edges", data: { source: r9, target: i11.id() } }), n12.add({ group: "edges", data: { source: a10, target: i11.id() } }), i11.id();
    }
    return t16.value ? t16.value.id() : void 0;
  };
  var Rn = function e9(t16, n12, r9) {
    if (!t16)
      return [];
    var a10 = [], i11 = [], o12 = [];
    return 0 === n12 ? (t16.left && An(t16.left, a10), t16.right && An(t16.right, i11), o12 = a10.concat(i11), [r9.collection(o12)]) : 1 === n12 ? t16.value ? [r9.collection(t16.value)] : (t16.left && An(t16.left, a10), t16.right && An(t16.right, i11), [r9.collection(a10), r9.collection(i11)]) : t16.value ? [r9.collection(t16.value)] : (t16.left && (a10 = e9(t16.left, n12 - 1, r9)), t16.right && (i11 = e9(t16.right, n12 - 1, r9)), a10.concat(i11));
  };
  var Vn = function(e21) {
    for (var t16 = this.cy(), n12 = this.nodes(), r9 = function(e22) {
      var t17 = In(e22), n13 = zn[t17.linkage];
      return null != n13 && (t17.linkage = n13), t17;
    }(e21), a10 = r9.attributes, i11 = function(e22, t17) {
      return mn(r9.distance, a10.length, function(t18) {
        return a10[t18](e22);
      }, function(e23) {
        return a10[e23](t17);
      }, e22, t17);
    }, o12 = [], s11 = [], l11 = [], u10 = [], c10 = 0; c10 < n12.length; c10++) {
      var d12 = { value: "dendrogram" === r9.mode ? n12[c10] : [n12[c10]], key: c10, index: c10 };
      o12[c10] = d12, u10[c10] = d12, s11[c10] = [], l11[c10] = 0;
    }
    for (var h10 = 0; h10 < o12.length; h10++)
      for (var p10 = 0; p10 <= h10; p10++) {
        var f11 = void 0;
        f11 = "dendrogram" === r9.mode ? h10 === p10 ? 1 / 0 : i11(o12[h10].value, o12[p10].value) : h10 === p10 ? 1 / 0 : i11(o12[h10].value[0], o12[p10].value[0]), s11[h10][p10] = f11, s11[p10][h10] = f11, f11 < s11[h10][l11[h10]] && (l11[h10] = p10);
      }
    for (var g9, v12 = Ln(o12, u10, s11, l11, r9); v12; )
      v12 = Ln(o12, u10, s11, l11, r9);
    return "dendrogram" === r9.mode ? (g9 = Rn(o12[0], r9.dendrogramDepth, t16), r9.addDendrogram && On(o12[0], t16)) : (g9 = new Array(o12.length), o12.forEach(function(e22, n13) {
      e22.key = e22.index = null, g9[n13] = t16.collection(e22.value);
    })), g9;
  };
  var Fn = { hierarchicalClustering: Vn, hca: Vn };
  var qn = ze({ distance: "euclidean", preference: "median", damping: 0.8, maxIterations: 1e3, minIterations: 100, attributes: [] });
  var jn = function(e21, t16, n12, r9) {
    var a10 = function(e22, t17) {
      return r9[t17](e22);
    };
    return -mn(e21, r9.length, function(e22) {
      return a10(t16, e22);
    }, function(e22) {
      return a10(n12, e22);
    }, t16, n12);
  };
  var Yn = function(e21, t16) {
    var n12 = null;
    return n12 = "median" === t16 ? function(e22) {
      var t17 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n13 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : e22.length, r9 = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], a10 = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5];
      arguments.length > 3 && void 0 !== arguments[3] && !arguments[3] ? (n13 < e22.length && e22.splice(n13, e22.length - n13), t17 > 0 && e22.splice(0, t17)) : e22 = e22.slice(t17, n13);
      for (var i11 = 0, o12 = e22.length - 1; o12 >= 0; o12--) {
        var s11 = e22[o12];
        a10 ? isFinite(s11) || (e22[o12] = -1 / 0, i11++) : e22.splice(o12, 1);
      }
      r9 && e22.sort(function(e23, t18) {
        return e23 - t18;
      });
      var l11 = e22.length, u10 = Math.floor(l11 / 2);
      return l11 % 2 != 0 ? e22[u10 + 1 + i11] : (e22[u10 - 1 + i11] + e22[u10 + i11]) / 2;
    }(e21) : "mean" === t16 ? function(e22) {
      for (var t17 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n13 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : e22.length, r9 = 0, a10 = 0, i11 = t17; i11 < n13; i11++) {
        var o12 = e22[i11];
        isFinite(o12) && (r9 += o12, a10++);
      }
      return r9 / a10;
    }(e21) : "min" === t16 ? function(e22) {
      for (var t17 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n13 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : e22.length, r9 = 1 / 0, a10 = t17; a10 < n13; a10++) {
        var i11 = e22[a10];
        isFinite(i11) && (r9 = Math.min(i11, r9));
      }
      return r9;
    }(e21) : "max" === t16 ? function(e22) {
      for (var t17 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n13 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : e22.length, r9 = -1 / 0, a10 = t17; a10 < n13; a10++) {
        var i11 = e22[a10];
        isFinite(i11) && (r9 = Math.max(i11, r9));
      }
      return r9;
    }(e21) : t16, n12;
  };
  var Xn = function(e21, t16, n12) {
    for (var r9 = [], a10 = 0; a10 < e21; a10++) {
      for (var i11 = -1, o12 = -1 / 0, s11 = 0; s11 < n12.length; s11++) {
        var l11 = n12[s11];
        t16[a10 * e21 + l11] > o12 && (i11 = l11, o12 = t16[a10 * e21 + l11]);
      }
      i11 > 0 && r9.push(i11);
    }
    for (var u10 = 0; u10 < n12.length; u10++)
      r9[n12[u10]] = n12[u10];
    return r9;
  };
  var Wn = function(e21) {
    for (var t16, n12, r9, a10, i11, o12, s11 = this.cy(), l11 = this.nodes(), u10 = function(e22) {
      var t17 = e22.damping, n13 = e22.preference;
      0.5 <= t17 && t17 < 1 || Pe("Damping must range on [0.5, 1).  Got: ".concat(t17));
      var r10 = ["median", "mean", "min", "max"];
      return r10.some(function(e23) {
        return e23 === n13;
      }) || I6(n13) || Pe("Preference must be one of [".concat(r10.map(function(e23) {
        return "'".concat(e23, "'");
      }).join(", "), "] or a number.  Got: ").concat(n13)), qn(e22);
    }(e21), c10 = {}, d12 = 0; d12 < l11.length; d12++)
      c10[l11[d12].id()] = d12;
    n12 = (t16 = l11.length) * t16, r9 = new Array(n12);
    for (var h10 = 0; h10 < n12; h10++)
      r9[h10] = -1 / 0;
    for (var p10 = 0; p10 < t16; p10++)
      for (var f11 = 0; f11 < t16; f11++)
        p10 !== f11 && (r9[p10 * t16 + f11] = jn(u10.distance, l11[p10], l11[f11], u10.attributes));
    a10 = Yn(r9, u10.preference);
    for (var g9 = 0; g9 < t16; g9++)
      r9[g9 * t16 + g9] = a10;
    i11 = new Array(n12);
    for (var v12 = 0; v12 < n12; v12++)
      i11[v12] = 0;
    o12 = new Array(n12);
    for (var y10 = 0; y10 < n12; y10++)
      o12[y10] = 0;
    for (var m12 = new Array(t16), b11 = new Array(t16), x10 = new Array(t16), w11 = 0; w11 < t16; w11++)
      m12[w11] = 0, b11[w11] = 0, x10[w11] = 0;
    for (var E9, k10 = new Array(t16 * u10.minIterations), C9 = 0; C9 < k10.length; C9++)
      k10[C9] = 0;
    for (E9 = 0; E9 < u10.maxIterations; E9++) {
      for (var S8 = 0; S8 < t16; S8++) {
        for (var D9 = -1 / 0, P10 = -1 / 0, T9 = -1, M9 = 0, B9 = 0; B9 < t16; B9++)
          m12[B9] = i11[S8 * t16 + B9], (M9 = o12[S8 * t16 + B9] + r9[S8 * t16 + B9]) >= D9 ? (P10 = D9, D9 = M9, T9 = B9) : M9 > P10 && (P10 = M9);
        for (var _7 = 0; _7 < t16; _7++)
          i11[S8 * t16 + _7] = (1 - u10.damping) * (r9[S8 * t16 + _7] - D9) + u10.damping * m12[_7];
        i11[S8 * t16 + T9] = (1 - u10.damping) * (r9[S8 * t16 + T9] - P10) + u10.damping * m12[T9];
      }
      for (var N8 = 0; N8 < t16; N8++) {
        for (var z8 = 0, L9 = 0; L9 < t16; L9++)
          m12[L9] = o12[L9 * t16 + N8], b11[L9] = Math.max(0, i11[L9 * t16 + N8]), z8 += b11[L9];
        z8 -= b11[N8], b11[N8] = i11[N8 * t16 + N8], z8 += b11[N8];
        for (var A10 = 0; A10 < t16; A10++)
          o12[A10 * t16 + N8] = (1 - u10.damping) * Math.min(0, z8 - b11[A10]) + u10.damping * m12[A10];
        o12[N8 * t16 + N8] = (1 - u10.damping) * (z8 - b11[N8]) + u10.damping * m12[N8];
      }
      for (var O10 = 0, R8 = 0; R8 < t16; R8++) {
        var V8 = o12[R8 * t16 + R8] + i11[R8 * t16 + R8] > 0 ? 1 : 0;
        k10[E9 % u10.minIterations * t16 + R8] = V8, O10 += V8;
      }
      if (O10 > 0 && (E9 >= u10.minIterations - 1 || E9 == u10.maxIterations - 1)) {
        for (var F9 = 0, q8 = 0; q8 < t16; q8++) {
          x10[q8] = 0;
          for (var j9 = 0; j9 < u10.minIterations; j9++)
            x10[q8] += k10[j9 * t16 + q8];
          0 !== x10[q8] && x10[q8] !== u10.minIterations || F9++;
        }
        if (F9 === t16)
          break;
      }
    }
    for (var Y6 = function(e22, t17, n13) {
      for (var r10 = [], a11 = 0; a11 < e22; a11++)
        t17[a11 * e22 + a11] + n13[a11 * e22 + a11] > 0 && r10.push(a11);
      return r10;
    }(t16, i11, o12), X6 = function(e22, t17, n13) {
      for (var r10 = Xn(e22, t17, n13), a11 = 0; a11 < n13.length; a11++) {
        for (var i12 = [], o13 = 0; o13 < r10.length; o13++)
          r10[o13] === n13[a11] && i12.push(o13);
        for (var s12 = -1, l12 = -1 / 0, u11 = 0; u11 < i12.length; u11++) {
          for (var c11 = 0, d13 = 0; d13 < i12.length; d13++)
            c11 += t17[i12[d13] * e22 + i12[u11]];
          c11 > l12 && (s12 = u11, l12 = c11);
        }
        n13[a11] = i12[s12];
      }
      return Xn(e22, t17, n13);
    }(t16, r9, Y6), W8 = {}, H8 = 0; H8 < Y6.length; H8++)
      W8[Y6[H8]] = [];
    for (var K6 = 0; K6 < l11.length; K6++) {
      var G7 = X6[c10[l11[K6].id()]];
      null != G7 && W8[G7].push(l11[K6]);
    }
    for (var U7 = new Array(Y6.length), Z6 = 0; Z6 < Y6.length; Z6++)
      U7[Z6] = s11.collection(W8[Y6[Z6]]);
    return U7;
  };
  var Hn = { affinityPropagation: Wn, ap: Wn };
  var Kn = ze({ root: void 0, directed: false });
  var Gn = function() {
    var e21 = this, t16 = {}, n12 = 0, r9 = 0, a10 = [], i11 = [], o12 = {}, s11 = function s12(l12, u10, c10) {
      l12 === c10 && (r9 += 1), t16[u10] = { id: n12, low: n12++, cutVertex: false };
      var d12, h10, p10, f11, g9 = e21.getElementById(u10).connectedEdges().intersection(e21);
      0 === g9.size() ? a10.push(e21.spawn(e21.getElementById(u10))) : g9.forEach(function(n13) {
        d12 = n13.source().id(), h10 = n13.target().id(), (p10 = d12 === u10 ? h10 : d12) !== c10 && (f11 = n13.id(), o12[f11] || (o12[f11] = true, i11.push({ x: u10, y: p10, edge: n13 })), p10 in t16 ? t16[u10].low = Math.min(t16[u10].low, t16[p10].id) : (s12(l12, p10, u10), t16[u10].low = Math.min(t16[u10].low, t16[p10].low), t16[u10].id <= t16[p10].low && (t16[u10].cutVertex = true, function(n14, r10) {
          for (var o13 = i11.length - 1, s13 = [], l13 = e21.spawn(); i11[o13].x != n14 || i11[o13].y != r10; )
            s13.push(i11.pop().edge), o13--;
          s13.push(i11.pop().edge), s13.forEach(function(n15) {
            var r11 = n15.connectedNodes().intersection(e21);
            l13.merge(n15), r11.forEach(function(n16) {
              var r12 = n16.id(), a11 = n16.connectedEdges().intersection(e21);
              l13.merge(n16), t16[r12].cutVertex ? l13.merge(a11.filter(function(e22) {
                return e22.isLoop();
              })) : l13.merge(a11);
            });
          }), a10.push(l13);
        }(u10, p10))));
      });
    };
    e21.forEach(function(e22) {
      if (e22.isNode()) {
        var n13 = e22.id();
        n13 in t16 || (r9 = 0, s11(n13, n13), t16[n13].cutVertex = r9 > 1);
      }
    });
    var l11 = Object.keys(t16).filter(function(e22) {
      return t16[e22].cutVertex;
    }).map(function(t17) {
      return e21.getElementById(t17);
    });
    return { cut: e21.spawn(l11), components: a10 };
  };
  var Un = function() {
    var e21 = this, t16 = {}, n12 = 0, r9 = [], a10 = [], i11 = e21.spawn(e21), o12 = function o13(s11) {
      if (a10.push(s11), t16[s11] = { index: n12, low: n12++, explored: false }, e21.getElementById(s11).connectedEdges().intersection(e21).forEach(function(e22) {
        var n13 = e22.target().id();
        n13 !== s11 && (n13 in t16 || o13(n13), t16[n13].explored || (t16[s11].low = Math.min(t16[s11].low, t16[n13].low)));
      }), t16[s11].index === t16[s11].low) {
        for (var l11 = e21.spawn(); ; ) {
          var u10 = a10.pop();
          if (l11.merge(e21.getElementById(u10)), t16[u10].low = t16[s11].index, t16[u10].explored = true, u10 === s11)
            break;
        }
        var c10 = l11.edgesWith(l11), d12 = l11.merge(c10);
        r9.push(d12), i11 = i11.difference(d12);
      }
    };
    return e21.forEach(function(e22) {
      if (e22.isNode()) {
        var n13 = e22.id();
        n13 in t16 || o12(n13);
      }
    }), { cut: i11, components: r9 };
  };
  var Zn = {};
  [Xe, He, Ke, Ue, $e, Je, rt4, Ht4, Gt4, Zt4, Qt4, un, Nn, Fn, Hn, { hierholzer: function(e21) {
    if (!N6(e21)) {
      var t16 = arguments;
      e21 = { root: t16[0], directed: t16[1] };
    }
    var n12, r9, a10, i11 = Kn(e21), o12 = i11.root, s11 = i11.directed, l11 = this, u10 = false;
    o12 && (a10 = M6(o12) ? this.filter(o12)[0].id() : o12[0].id());
    var c10 = {}, d12 = {};
    s11 ? l11.forEach(function(e22) {
      var t17 = e22.id();
      if (e22.isNode()) {
        var a11 = e22.indegree(true), i12 = e22.outdegree(true), o13 = a11 - i12, s12 = i12 - a11;
        1 == o13 ? n12 ? u10 = true : n12 = t17 : 1 == s12 ? r9 ? u10 = true : r9 = t17 : (s12 > 1 || o13 > 1) && (u10 = true), c10[t17] = [], e22.outgoers().forEach(function(e23) {
          e23.isEdge() && c10[t17].push(e23.id());
        });
      } else
        d12[t17] = [void 0, e22.target().id()];
    }) : l11.forEach(function(e22) {
      var t17 = e22.id();
      e22.isNode() ? (e22.degree(true) % 2 && (n12 ? r9 ? u10 = true : r9 = t17 : n12 = t17), c10[t17] = [], e22.connectedEdges().forEach(function(e23) {
        return c10[t17].push(e23.id());
      })) : d12[t17] = [e22.source().id(), e22.target().id()];
    });
    var h10 = { found: false, trail: void 0 };
    if (u10)
      return h10;
    if (r9 && n12)
      if (s11) {
        if (a10 && r9 != a10)
          return h10;
        a10 = r9;
      } else {
        if (a10 && r9 != a10 && n12 != a10)
          return h10;
        a10 || (a10 = r9);
      }
    else
      a10 || (a10 = l11[0].id());
    var p10 = function(e22) {
      for (var t17, n13, r10, a11 = e22, i12 = [e22]; c10[a11].length; )
        t17 = c10[a11].shift(), n13 = d12[t17][0], a11 != (r10 = d12[t17][1]) ? (c10[r10] = c10[r10].filter(function(e23) {
          return e23 != t17;
        }), a11 = r10) : s11 || a11 == n13 || (c10[n13] = c10[n13].filter(function(e23) {
          return e23 != t17;
        }), a11 = n13), i12.unshift(t17), i12.unshift(a11);
      return i12;
    }, f11 = [], g9 = [];
    for (g9 = p10(a10); 1 != g9.length; )
      0 == c10[g9[0]].length ? (f11.unshift(l11.getElementById(g9.shift())), f11.unshift(l11.getElementById(g9.shift()))) : g9 = p10(g9.shift()).concat(g9);
    for (var v12 in f11.unshift(l11.getElementById(g9.shift())), c10)
      if (c10[v12].length)
        return h10;
    return h10.found = true, h10.trail = this.spawn(f11, true), h10;
  } }, { hopcroftTarjanBiconnected: Gn, htbc: Gn, htb: Gn, hopcroftTarjanBiconnectedComponents: Gn }, { tarjanStronglyConnected: Un, tsc: Un, tscc: Un, tarjanStronglyConnectedComponents: Un }].forEach(function(e21) {
    J4(Zn, e21);
  });
  var $n = function e10(t16) {
    if (!(this instanceof e10))
      return new e10(t16);
    this.id = "Thenable/1.0.7", this.state = 0, this.fulfillValue = void 0, this.rejectReason = void 0, this.onFulfilled = [], this.onRejected = [], this.proxy = { then: this.then.bind(this) }, "function" == typeof t16 && t16.call(this, this.fulfill.bind(this), this.reject.bind(this));
  };
  $n.prototype = { fulfill: function(e21) {
    return Qn(this, 1, "fulfillValue", e21);
  }, reject: function(e21) {
    return Qn(this, 2, "rejectReason", e21);
  }, then: function(e21, t16) {
    var n12 = this, r9 = new $n();
    return n12.onFulfilled.push(tr4(e21, r9, "fulfill")), n12.onRejected.push(tr4(t16, r9, "reject")), Jn(n12), r9.proxy;
  } };
  var Qn = function(e21, t16, n12, r9) {
    return 0 === e21.state && (e21.state = t16, e21[n12] = r9, Jn(e21)), e21;
  };
  var Jn = function(e21) {
    1 === e21.state ? er4(e21, "onFulfilled", e21.fulfillValue) : 2 === e21.state && er4(e21, "onRejected", e21.rejectReason);
  };
  var er4 = function(e21, t16, n12) {
    if (0 !== e21[t16].length) {
      var r9 = e21[t16];
      e21[t16] = [];
      var a10 = function() {
        for (var e22 = 0; e22 < r9.length; e22++)
          r9[e22](n12);
      };
      "function" == typeof setImmediate ? setImmediate(a10) : setTimeout(a10, 0);
    }
  };
  var tr4 = function(e21, t16, n12) {
    return function(r9) {
      if ("function" != typeof e21)
        t16[n12].call(t16, r9);
      else {
        var a10;
        try {
          a10 = e21(r9);
        } catch (e22) {
          return void t16.reject(e22);
        }
        nr4(t16, a10);
      }
    };
  };
  var nr4 = function e11(t16, n12) {
    if (t16 !== n12 && t16.proxy !== n12) {
      var r9;
      if ("object" === g6(n12) && null !== n12 || "function" == typeof n12)
        try {
          r9 = n12.then;
        } catch (e21) {
          return void t16.reject(e21);
        }
      if ("function" != typeof r9)
        t16.fulfill(n12);
      else {
        var a10 = false;
        try {
          r9.call(n12, function(r10) {
            a10 || (a10 = true, r10 === n12 ? t16.reject(new TypeError("circular thenable chain")) : e11(t16, r10));
          }, function(e21) {
            a10 || (a10 = true, t16.reject(e21));
          });
        } catch (e21) {
          a10 || t16.reject(e21);
        }
      }
    } else
      t16.reject(new TypeError("cannot resolve promise with itself"));
  };
  $n.all = function(e21) {
    return new $n(function(t16, n12) {
      for (var r9 = new Array(e21.length), a10 = 0, i11 = function(n13, i12) {
        r9[n13] = i12, ++a10 === e21.length && t16(r9);
      }, o12 = 0; o12 < e21.length; o12++)
        !function(t17) {
          var r10 = e21[t17];
          null != r10 && null != r10.then ? r10.then(function(e22) {
            i11(t17, e22);
          }, function(e22) {
            n12(e22);
          }) : i11(t17, r10);
        }(o12);
    });
  }, $n.resolve = function(e21) {
    return new $n(function(t16, n12) {
      t16(e21);
    });
  }, $n.reject = function(e21) {
    return new $n(function(t16, n12) {
      n12(e21);
    });
  };
  var rr4 = "undefined" != typeof Promise ? Promise : $n;
  var ar4 = function(e21, t16, n12) {
    var r9 = R4(e21), a10 = !r9, i11 = this._private = J4({ duration: 1e3 }, t16, n12);
    if (i11.target = e21, i11.style = i11.style || i11.css, i11.started = false, i11.playing = false, i11.hooked = false, i11.applying = false, i11.progress = 0, i11.completes = [], i11.frames = [], i11.complete && B5(i11.complete) && i11.completes.push(i11.complete), a10) {
      var o12 = e21.position();
      i11.startPosition = i11.startPosition || { x: o12.x, y: o12.y }, i11.startStyle = i11.startStyle || e21.cy().style().getAnimationStartStyle(e21, i11.style);
    }
    if (r9) {
      var s11 = e21.pan();
      i11.startPan = { x: s11.x, y: s11.y }, i11.startZoom = e21.zoom();
    }
    this.length = 1, this[0] = this;
  };
  var ir4 = ar4.prototype;
  J4(ir4, { instanceString: function() {
    return "animation";
  }, hook: function() {
    var e21 = this._private;
    if (!e21.hooked) {
      var t16 = e21.target._private.animation;
      (e21.queue ? t16.queue : t16.current).push(this), L5(e21.target) && e21.target.cy().addToAnimationPool(e21.target), e21.hooked = true;
    }
    return this;
  }, play: function() {
    var e21 = this._private;
    return 1 === e21.progress && (e21.progress = 0), e21.playing = true, e21.started = false, e21.stopped = false, this.hook(), this;
  }, playing: function() {
    return this._private.playing;
  }, apply: function() {
    var e21 = this._private;
    return e21.applying = true, e21.started = false, e21.stopped = false, this.hook(), this;
  }, applying: function() {
    return this._private.applying;
  }, pause: function() {
    var e21 = this._private;
    return e21.playing = false, e21.started = false, this;
  }, stop: function() {
    var e21 = this._private;
    return e21.playing = false, e21.started = false, e21.stopped = true, this;
  }, rewind: function() {
    return this.progress(0);
  }, fastforward: function() {
    return this.progress(1);
  }, time: function(e21) {
    var t16 = this._private;
    return void 0 === e21 ? t16.progress * t16.duration : this.progress(e21 / t16.duration);
  }, progress: function(e21) {
    var t16 = this._private, n12 = t16.playing;
    return void 0 === e21 ? t16.progress : (n12 && this.pause(), t16.progress = e21, t16.started = false, n12 && this.play(), this);
  }, completed: function() {
    return 1 === this._private.progress;
  }, reverse: function() {
    var e21 = this._private, t16 = e21.playing;
    t16 && this.pause(), e21.progress = 1 - e21.progress, e21.started = false;
    var n12 = function(t17, n13) {
      var r10 = e21[t17];
      null != r10 && (e21[t17] = e21[n13], e21[n13] = r10);
    };
    if (n12("zoom", "startZoom"), n12("pan", "startPan"), n12("position", "startPosition"), e21.style)
      for (var r9 = 0; r9 < e21.style.length; r9++) {
        var a10 = e21.style[r9], i11 = a10.name, o12 = e21.startStyle[i11];
        e21.startStyle[i11] = a10, e21.style[r9] = o12;
      }
    return t16 && this.play(), this;
  }, promise: function(e21) {
    var t16, n12 = this._private;
    if ("frame" === e21)
      t16 = n12.frames;
    else
      t16 = n12.completes;
    return new rr4(function(e22, n13) {
      t16.push(function() {
        e22();
      });
    });
  } }), ir4.complete = ir4.completed, ir4.run = ir4.play, ir4.running = ir4.playing;
  var or4 = { animated: function() {
    return function() {
      var e21 = this, t16 = void 0 !== e21.length ? e21 : [e21];
      if (!(this._private.cy || this).styleEnabled())
        return false;
      var n12 = t16[0];
      return n12 ? n12._private.animation.current.length > 0 : void 0;
    };
  }, clearQueue: function() {
    return function() {
      var e21 = this, t16 = void 0 !== e21.length ? e21 : [e21];
      if (!(this._private.cy || this).styleEnabled())
        return this;
      for (var n12 = 0; n12 < t16.length; n12++) {
        t16[n12]._private.animation.queue = [];
      }
      return this;
    };
  }, delay: function() {
    return function(e21, t16) {
      return (this._private.cy || this).styleEnabled() ? this.animate({ delay: e21, duration: e21, complete: t16 }) : this;
    };
  }, delayAnimation: function() {
    return function(e21, t16) {
      return (this._private.cy || this).styleEnabled() ? this.animation({ delay: e21, duration: e21, complete: t16 }) : this;
    };
  }, animation: function() {
    return function(e21, t16) {
      var n12 = this, r9 = void 0 !== n12.length, a10 = r9 ? n12 : [n12], i11 = this._private.cy || this, o12 = !r9, s11 = !o12;
      if (!i11.styleEnabled())
        return this;
      var l11 = i11.style();
      if (e21 = J4({}, e21, t16), 0 === Object.keys(e21).length)
        return new ar4(a10[0], e21);
      switch (void 0 === e21.duration && (e21.duration = 400), e21.duration) {
        case "slow":
          e21.duration = 600;
          break;
        case "fast":
          e21.duration = 200;
      }
      if (s11 && (e21.style = l11.getPropsList(e21.style || e21.css), e21.css = void 0), s11 && null != e21.renderedPosition) {
        var u10 = e21.renderedPosition, c10 = i11.pan(), d12 = i11.zoom();
        e21.position = it4(u10, d12, c10);
      }
      if (o12 && null != e21.panBy) {
        var h10 = e21.panBy, p10 = i11.pan();
        e21.pan = { x: p10.x + h10.x, y: p10.y + h10.y };
      }
      var f11 = e21.center || e21.centre;
      if (o12 && null != f11) {
        var g9 = i11.getCenterPan(f11.eles, e21.zoom);
        null != g9 && (e21.pan = g9);
      }
      if (o12 && null != e21.fit) {
        var v12 = e21.fit, y10 = i11.getFitViewport(v12.eles || v12.boundingBox, v12.padding);
        null != y10 && (e21.pan = y10.pan, e21.zoom = y10.zoom);
      }
      if (o12 && N6(e21.zoom)) {
        var m12 = i11.getZoomedViewport(e21.zoom);
        null != m12 ? (m12.zoomed && (e21.zoom = m12.zoom), m12.panned && (e21.pan = m12.pan)) : e21.zoom = null;
      }
      return new ar4(a10[0], e21);
    };
  }, animate: function() {
    return function(e21, t16) {
      var n12 = this, r9 = void 0 !== n12.length ? n12 : [n12];
      if (!(this._private.cy || this).styleEnabled())
        return this;
      t16 && (e21 = J4({}, e21, t16));
      for (var a10 = 0; a10 < r9.length; a10++) {
        var i11 = r9[a10], o12 = i11.animated() && (void 0 === e21.queue || e21.queue);
        i11.animation(e21, o12 ? { queue: true } : void 0).play();
      }
      return this;
    };
  }, stop: function() {
    return function(e21, t16) {
      var n12 = this, r9 = void 0 !== n12.length ? n12 : [n12], a10 = this._private.cy || this;
      if (!a10.styleEnabled())
        return this;
      for (var i11 = 0; i11 < r9.length; i11++) {
        for (var o12 = r9[i11]._private, s11 = o12.animation.current, l11 = 0; l11 < s11.length; l11++) {
          var u10 = s11[l11]._private;
          t16 && (u10.duration = 0);
        }
        e21 && (o12.animation.queue = []), t16 || (o12.animation.current = []);
      }
      return a10.notify("draw"), this;
    };
  } };
  var sr2 = { data: function(e21) {
    return e21 = J4({}, { field: "data", bindingEvent: "data", allowBinding: false, allowSetting: false, allowGetting: false, settingEvent: "data", settingTriggersEvent: false, triggerFnName: "trigger", immutableKeys: {}, updateStyle: false, beforeGet: function(e22) {
    }, beforeSet: function(e22, t16) {
    }, onSet: function(e22) {
    }, canSet: function(e22) {
      return true;
    } }, e21), function(t16, n12) {
      var r9 = e21, a10 = this, i11 = void 0 !== a10.length, o12 = i11 ? a10 : [a10], s11 = i11 ? a10[0] : a10;
      if (M6(t16)) {
        var l11, u10 = -1 !== t16.indexOf(".") && f6.default(t16);
        if (r9.allowGetting && void 0 === n12)
          return s11 && (r9.beforeGet(s11), l11 = u10 && void 0 === s11._private[r9.field][t16] ? h6.default(s11._private[r9.field], u10) : s11._private[r9.field][t16]), l11;
        if (r9.allowSetting && void 0 !== n12 && !r9.immutableKeys[t16]) {
          var c10 = b6({}, t16, n12);
          r9.beforeSet(a10, c10);
          for (var d12 = 0, g9 = o12.length; d12 < g9; d12++) {
            var v12 = o12[d12];
            r9.canSet(v12) && (u10 && void 0 === s11._private[r9.field][t16] ? p6.default(v12._private[r9.field], u10, n12) : v12._private[r9.field][t16] = n12);
          }
          r9.updateStyle && a10.updateStyle(), r9.onSet(a10), r9.settingTriggersEvent && a10[r9.triggerFnName](r9.settingEvent);
        }
      } else if (r9.allowSetting && N6(t16)) {
        var y10, m12, x10 = t16, w11 = Object.keys(x10);
        r9.beforeSet(a10, x10);
        for (var E9 = 0; E9 < w11.length; E9++) {
          if (m12 = x10[y10 = w11[E9]], !r9.immutableKeys[y10])
            for (var k10 = 0; k10 < o12.length; k10++) {
              var C9 = o12[k10];
              r9.canSet(C9) && (C9._private[r9.field][y10] = m12);
            }
        }
        r9.updateStyle && a10.updateStyle(), r9.onSet(a10), r9.settingTriggersEvent && a10[r9.triggerFnName](r9.settingEvent);
      } else if (r9.allowBinding && B5(t16)) {
        var S8 = t16;
        a10.on(r9.bindingEvent, S8);
      } else if (r9.allowGetting && void 0 === t16) {
        var D9;
        return s11 && (r9.beforeGet(s11), D9 = s11._private[r9.field]), D9;
      }
      return a10;
    };
  }, removeData: function(e21) {
    return e21 = J4({}, { field: "data", event: "data", triggerFnName: "trigger", triggerEvent: false, immutableKeys: {} }, e21), function(t16) {
      var n12 = e21, r9 = this, a10 = void 0 !== r9.length ? r9 : [r9];
      if (M6(t16)) {
        for (var i11 = t16.split(/\s+/), o12 = i11.length, s11 = 0; s11 < o12; s11++) {
          var l11 = i11[s11];
          if (!F6(l11)) {
            if (!n12.immutableKeys[l11])
              for (var u10 = 0, c10 = a10.length; u10 < c10; u10++)
                a10[u10]._private[n12.field][l11] = void 0;
          }
        }
        n12.triggerEvent && r9[n12.triggerFnName](n12.event);
      } else if (void 0 === t16) {
        for (var d12 = 0, h10 = a10.length; d12 < h10; d12++)
          for (var p10 = a10[d12]._private[n12.field], f11 = Object.keys(p10), g9 = 0; g9 < f11.length; g9++) {
            var v12 = f11[g9];
            !n12.immutableKeys[v12] && (p10[v12] = void 0);
          }
        n12.triggerEvent && r9[n12.triggerFnName](n12.event);
      }
      return r9;
    };
  } };
  var lr2 = { eventAliasesOn: function(e21) {
    var t16 = e21;
    t16.addListener = t16.listen = t16.bind = t16.on, t16.unlisten = t16.unbind = t16.off = t16.removeListener, t16.trigger = t16.emit, t16.pon = t16.promiseOn = function(e22, t17) {
      var n12 = this, r9 = Array.prototype.slice.call(arguments, 0);
      return new rr4(function(e23, t18) {
        var a10 = r9.concat([function(t19) {
          n12.off.apply(n12, i11), e23(t19);
        }]), i11 = a10.concat([]);
        n12.on.apply(n12, a10);
      });
    };
  } };
  var ur3 = {};
  [or4, sr2, lr2].forEach(function(e21) {
    J4(ur3, e21);
  });
  var cr3 = { animate: ur3.animate(), animation: ur3.animation(), animated: ur3.animated(), clearQueue: ur3.clearQueue(), delay: ur3.delay(), delayAnimation: ur3.delayAnimation(), stop: ur3.stop() };
  var dr2 = { classes: function(e21) {
    var t16 = this;
    if (void 0 === e21) {
      var n12 = [];
      return t16[0]._private.classes.forEach(function(e22) {
        return n12.push(e22);
      }), n12;
    }
    _5(e21) || (e21 = (e21 || "").match(/\S+/g) || []);
    for (var r9 = [], a10 = new qe(e21), i11 = 0; i11 < t16.length; i11++) {
      for (var o12 = t16[i11], s11 = o12._private, l11 = s11.classes, u10 = false, c10 = 0; c10 < e21.length; c10++) {
        var d12 = e21[c10];
        if (!l11.has(d12)) {
          u10 = true;
          break;
        }
      }
      u10 || (u10 = l11.size !== e21.length), u10 && (s11.classes = a10, r9.push(o12));
    }
    return r9.length > 0 && this.spawn(r9).updateStyle().emit("class"), t16;
  }, addClass: function(e21) {
    return this.toggleClass(e21, true);
  }, hasClass: function(e21) {
    var t16 = this[0];
    return null != t16 && t16._private.classes.has(e21);
  }, toggleClass: function(e21, t16) {
    _5(e21) || (e21 = e21.match(/\S+/g) || []);
    for (var n12 = this, r9 = void 0 === t16, a10 = [], i11 = 0, o12 = n12.length; i11 < o12; i11++)
      for (var s11 = n12[i11], l11 = s11._private.classes, u10 = false, c10 = 0; c10 < e21.length; c10++) {
        var d12 = e21[c10], h10 = l11.has(d12), p10 = false;
        t16 || r9 && !h10 ? (l11.add(d12), p10 = true) : (!t16 || r9 && h10) && (l11.delete(d12), p10 = true), !u10 && p10 && (a10.push(s11), u10 = true);
      }
    return a10.length > 0 && this.spawn(a10).updateStyle().emit("class"), n12;
  }, removeClass: function(e21) {
    return this.toggleClass(e21, false);
  }, flashClass: function(e21, t16) {
    var n12 = this;
    if (null == t16)
      t16 = 250;
    else if (0 === t16)
      return n12;
    return n12.addClass(e21), setTimeout(function() {
      n12.removeClass(e21);
    }, t16), n12;
  } };
  dr2.className = dr2.classNames = dr2.classes;
  var hr2 = { metaChar: "[\\!\\\"\\#\\$\\%\\&\\'\\(\\)\\*\\+\\,\\.\\/\\:\\;\\<\\=\\>\\?\\@\\[\\]\\^\\`\\{\\|\\}\\~]", comparatorOp: "=|\\!=|>|>=|<|<=|\\$=|\\^=|\\*=", boolOp: "\\?|\\!|\\^", string: `"(?:\\\\"|[^"])*"|'(?:\\\\'|[^'])*'`, number: K4, meta: "degree|indegree|outdegree", separator: "\\s*,\\s*", descendant: "\\s+", child: "\\s+>\\s+", subject: "\\$", group: "node|edge|\\*", directedEdge: "\\s+->\\s+", undirectedEdge: "\\s+<->\\s+" };
  hr2.variable = "(?:[\\w-.]|(?:\\\\" + hr2.metaChar + "))+", hr2.className = "(?:[\\w-]|(?:\\\\" + hr2.metaChar + "))+", hr2.value = hr2.string + "|" + hr2.number, hr2.id = hr2.variable, function() {
    var e21, t16, n12;
    for (e21 = hr2.comparatorOp.split("|"), n12 = 0; n12 < e21.length; n12++)
      t16 = e21[n12], hr2.comparatorOp += "|@" + t16;
    for (e21 = hr2.comparatorOp.split("|"), n12 = 0; n12 < e21.length; n12++)
      (t16 = e21[n12]).indexOf("!") >= 0 || "=" !== t16 && (hr2.comparatorOp += "|\\!" + t16);
  }();
  var pr2 = 0;
  var fr2 = 1;
  var gr2 = 2;
  var vr2 = 3;
  var yr2 = 4;
  var mr = 5;
  var br2 = 6;
  var xr = 7;
  var wr = 8;
  var Er = 9;
  var kr = 10;
  var Cr = 11;
  var Sr = 12;
  var Dr = 13;
  var Pr = 14;
  var Tr = 15;
  var Mr = 16;
  var Br = 17;
  var _r2 = 18;
  var Nr = 19;
  var Ir = 20;
  var zr = [{ selector: ":selected", matches: function(e21) {
    return e21.selected();
  } }, { selector: ":unselected", matches: function(e21) {
    return !e21.selected();
  } }, { selector: ":selectable", matches: function(e21) {
    return e21.selectable();
  } }, { selector: ":unselectable", matches: function(e21) {
    return !e21.selectable();
  } }, { selector: ":locked", matches: function(e21) {
    return e21.locked();
  } }, { selector: ":unlocked", matches: function(e21) {
    return !e21.locked();
  } }, { selector: ":visible", matches: function(e21) {
    return e21.visible();
  } }, { selector: ":hidden", matches: function(e21) {
    return !e21.visible();
  } }, { selector: ":transparent", matches: function(e21) {
    return e21.transparent();
  } }, { selector: ":grabbed", matches: function(e21) {
    return e21.grabbed();
  } }, { selector: ":free", matches: function(e21) {
    return !e21.grabbed();
  } }, { selector: ":removed", matches: function(e21) {
    return e21.removed();
  } }, { selector: ":inside", matches: function(e21) {
    return !e21.removed();
  } }, { selector: ":grabbable", matches: function(e21) {
    return e21.grabbable();
  } }, { selector: ":ungrabbable", matches: function(e21) {
    return !e21.grabbable();
  } }, { selector: ":animated", matches: function(e21) {
    return e21.animated();
  } }, { selector: ":unanimated", matches: function(e21) {
    return !e21.animated();
  } }, { selector: ":parent", matches: function(e21) {
    return e21.isParent();
  } }, { selector: ":childless", matches: function(e21) {
    return e21.isChildless();
  } }, { selector: ":child", matches: function(e21) {
    return e21.isChild();
  } }, { selector: ":orphan", matches: function(e21) {
    return e21.isOrphan();
  } }, { selector: ":nonorphan", matches: function(e21) {
    return e21.isChild();
  } }, { selector: ":compound", matches: function(e21) {
    return e21.isNode() ? e21.isParent() : e21.source().isParent() || e21.target().isParent();
  } }, { selector: ":loop", matches: function(e21) {
    return e21.isLoop();
  } }, { selector: ":simple", matches: function(e21) {
    return e21.isSimple();
  } }, { selector: ":active", matches: function(e21) {
    return e21.active();
  } }, { selector: ":inactive", matches: function(e21) {
    return !e21.active();
  } }, { selector: ":backgrounding", matches: function(e21) {
    return e21.backgrounding();
  } }, { selector: ":nonbackgrounding", matches: function(e21) {
    return !e21.backgrounding();
  } }].sort(function(e21, t16) {
    return function(e22, t17) {
      return -1 * Q4(e22, t17);
    }(e21.selector, t16.selector);
  });
  var Lr = function() {
    for (var e21, t16 = {}, n12 = 0; n12 < zr.length; n12++)
      t16[(e21 = zr[n12]).selector] = e21.matches;
    return t16;
  }();
  var Ar = "(" + zr.map(function(e21) {
    return e21.selector;
  }).join("|") + ")";
  var Or = function(e21) {
    return e21.replace(new RegExp("\\\\(" + hr2.metaChar + ")", "g"), function(e22, t16) {
      return t16;
    });
  };
  var Rr = function(e21, t16, n12) {
    e21[e21.length - 1] = n12;
  };
  var Vr = [{ name: "group", query: true, regex: "(" + hr2.group + ")", populate: function(e21, t16, n12) {
    var r9 = x6(n12, 1)[0];
    t16.checks.push({ type: pr2, value: "*" === r9 ? r9 : r9 + "s" });
  } }, { name: "state", query: true, regex: Ar, populate: function(e21, t16, n12) {
    var r9 = x6(n12, 1)[0];
    t16.checks.push({ type: xr, value: r9 });
  } }, { name: "id", query: true, regex: "\\#(" + hr2.id + ")", populate: function(e21, t16, n12) {
    var r9 = x6(n12, 1)[0];
    t16.checks.push({ type: wr, value: Or(r9) });
  } }, { name: "className", query: true, regex: "\\.(" + hr2.className + ")", populate: function(e21, t16, n12) {
    var r9 = x6(n12, 1)[0];
    t16.checks.push({ type: Er, value: Or(r9) });
  } }, { name: "dataExists", query: true, regex: "\\[\\s*(" + hr2.variable + ")\\s*\\]", populate: function(e21, t16, n12) {
    var r9 = x6(n12, 1)[0];
    t16.checks.push({ type: yr2, field: Or(r9) });
  } }, { name: "dataCompare", query: true, regex: "\\[\\s*(" + hr2.variable + ")\\s*(" + hr2.comparatorOp + ")\\s*(" + hr2.value + ")\\s*\\]", populate: function(e21, t16, n12) {
    var r9 = x6(n12, 3), a10 = r9[0], i11 = r9[1], o12 = r9[2];
    o12 = null != new RegExp("^" + hr2.string + "$").exec(o12) ? o12.substring(1, o12.length - 1) : parseFloat(o12), t16.checks.push({ type: vr2, field: Or(a10), operator: i11, value: o12 });
  } }, { name: "dataBool", query: true, regex: "\\[\\s*(" + hr2.boolOp + ")\\s*(" + hr2.variable + ")\\s*\\]", populate: function(e21, t16, n12) {
    var r9 = x6(n12, 2), a10 = r9[0], i11 = r9[1];
    t16.checks.push({ type: mr, field: Or(i11), operator: a10 });
  } }, { name: "metaCompare", query: true, regex: "\\[\\[\\s*(" + hr2.meta + ")\\s*(" + hr2.comparatorOp + ")\\s*(" + hr2.number + ")\\s*\\]\\]", populate: function(e21, t16, n12) {
    var r9 = x6(n12, 3), a10 = r9[0], i11 = r9[1], o12 = r9[2];
    t16.checks.push({ type: br2, field: Or(a10), operator: i11, value: parseFloat(o12) });
  } }, { name: "nextQuery", separator: true, regex: hr2.separator, populate: function(e21, t16) {
    var n12 = e21.currentSubject, r9 = e21.edgeCount, a10 = e21.compoundCount, i11 = e21[e21.length - 1];
    return null != n12 && (i11.subject = n12, e21.currentSubject = null), i11.edgeCount = r9, i11.compoundCount = a10, e21.edgeCount = 0, e21.compoundCount = 0, e21[e21.length++] = { checks: [] };
  } }, { name: "directedEdge", separator: true, regex: hr2.directedEdge, populate: function(e21, t16) {
    if (null == e21.currentSubject) {
      var n12 = { checks: [] }, r9 = t16, a10 = { checks: [] };
      return n12.checks.push({ type: Cr, source: r9, target: a10 }), Rr(e21, 0, n12), e21.edgeCount++, a10;
    }
    var i11 = { checks: [] }, o12 = t16, s11 = { checks: [] };
    return i11.checks.push({ type: Sr, source: o12, target: s11 }), Rr(e21, 0, i11), e21.edgeCount++, s11;
  } }, { name: "undirectedEdge", separator: true, regex: hr2.undirectedEdge, populate: function(e21, t16) {
    if (null == e21.currentSubject) {
      var n12 = { checks: [] }, r9 = t16, a10 = { checks: [] };
      return n12.checks.push({ type: kr, nodes: [r9, a10] }), Rr(e21, 0, n12), e21.edgeCount++, a10;
    }
    var i11 = { checks: [] }, o12 = t16, s11 = { checks: [] };
    return i11.checks.push({ type: Pr, node: o12, neighbor: s11 }), Rr(e21, 0, i11), s11;
  } }, { name: "child", separator: true, regex: hr2.child, populate: function(e21, t16) {
    if (null == e21.currentSubject) {
      var n12 = { checks: [] }, r9 = { checks: [] }, a10 = e21[e21.length - 1];
      return n12.checks.push({ type: Tr, parent: a10, child: r9 }), Rr(e21, 0, n12), e21.compoundCount++, r9;
    }
    if (e21.currentSubject === t16) {
      var i11 = { checks: [] }, o12 = e21[e21.length - 1], s11 = { checks: [] }, l11 = { checks: [] }, u10 = { checks: [] }, c10 = { checks: [] };
      return i11.checks.push({ type: Nr, left: o12, right: s11, subject: l11 }), l11.checks = t16.checks, t16.checks = [{ type: Ir }], c10.checks.push({ type: Ir }), s11.checks.push({ type: Br, parent: c10, child: u10 }), Rr(e21, 0, i11), e21.currentSubject = l11, e21.compoundCount++, u10;
    }
    var d12 = { checks: [] }, h10 = { checks: [] }, p10 = [{ type: Br, parent: d12, child: h10 }];
    return d12.checks = t16.checks, t16.checks = p10, e21.compoundCount++, h10;
  } }, { name: "descendant", separator: true, regex: hr2.descendant, populate: function(e21, t16) {
    if (null == e21.currentSubject) {
      var n12 = { checks: [] }, r9 = { checks: [] }, a10 = e21[e21.length - 1];
      return n12.checks.push({ type: Mr, ancestor: a10, descendant: r9 }), Rr(e21, 0, n12), e21.compoundCount++, r9;
    }
    if (e21.currentSubject === t16) {
      var i11 = { checks: [] }, o12 = e21[e21.length - 1], s11 = { checks: [] }, l11 = { checks: [] }, u10 = { checks: [] }, c10 = { checks: [] };
      return i11.checks.push({ type: Nr, left: o12, right: s11, subject: l11 }), l11.checks = t16.checks, t16.checks = [{ type: Ir }], c10.checks.push({ type: Ir }), s11.checks.push({ type: _r2, ancestor: c10, descendant: u10 }), Rr(e21, 0, i11), e21.currentSubject = l11, e21.compoundCount++, u10;
    }
    var d12 = { checks: [] }, h10 = { checks: [] }, p10 = [{ type: _r2, ancestor: d12, descendant: h10 }];
    return d12.checks = t16.checks, t16.checks = p10, e21.compoundCount++, h10;
  } }, { name: "subject", modifier: true, regex: hr2.subject, populate: function(e21, t16) {
    if (null != e21.currentSubject && e21.currentSubject !== t16)
      return Me("Redefinition of subject in selector `" + e21.toString() + "`"), false;
    e21.currentSubject = t16;
    var n12 = e21[e21.length - 1].checks[0], r9 = null == n12 ? null : n12.type;
    r9 === Cr ? n12.type = Dr : r9 === kr && (n12.type = Pr, n12.node = n12.nodes[1], n12.neighbor = n12.nodes[0], n12.nodes = null);
  } }];
  Vr.forEach(function(e21) {
    return e21.regexObj = new RegExp("^" + e21.regex);
  });
  var Fr = function(e21) {
    for (var t16, n12, r9, a10 = 0; a10 < Vr.length; a10++) {
      var i11 = Vr[a10], o12 = i11.name, s11 = e21.match(i11.regexObj);
      if (null != s11) {
        n12 = s11, t16 = i11, r9 = o12;
        var l11 = s11[0];
        e21 = e21.substring(l11.length);
        break;
      }
    }
    return { expr: t16, match: n12, name: r9, remaining: e21 };
  };
  var qr = { parse: function(e21) {
    var t16 = this, n12 = t16.inputText = e21, r9 = t16[0] = { checks: [] };
    for (t16.length = 1, n12 = function(e22) {
      var t17 = e22.match(/^\s+/);
      if (t17) {
        var n13 = t17[0];
        e22 = e22.substring(n13.length);
      }
      return e22;
    }(n12); ; ) {
      var a10 = Fr(n12);
      if (null == a10.expr)
        return Me("The selector `" + e21 + "`is invalid"), false;
      var i11 = a10.match.slice(1), o12 = a10.expr.populate(t16, r9, i11);
      if (false === o12)
        return false;
      if (null != o12 && (r9 = o12), (n12 = a10.remaining).match(/^\s*$/))
        break;
    }
    var s11 = t16[t16.length - 1];
    null != t16.currentSubject && (s11.subject = t16.currentSubject), s11.edgeCount = t16.edgeCount, s11.compoundCount = t16.compoundCount;
    for (var l11 = 0; l11 < t16.length; l11++) {
      var u10 = t16[l11];
      if (u10.compoundCount > 0 && u10.edgeCount > 0)
        return Me("The selector `" + e21 + "` is invalid because it uses both a compound selector and an edge selector"), false;
      if (u10.edgeCount > 1)
        return Me("The selector `" + e21 + "` is invalid because it uses multiple edge selectors"), false;
      1 === u10.edgeCount && Me("The selector `" + e21 + "` is deprecated.  Edge selectors do not take effect on changes to source and target nodes after an edge is added, for performance reasons.  Use a class or data selector on edges instead, updating the class or data of an edge when your app detects a change in source or target nodes.");
    }
    return true;
  }, toString: function() {
    if (null != this.toStringCache)
      return this.toStringCache;
    for (var e21 = function(e22) {
      return null == e22 ? "" : e22;
    }, t16 = function(t17) {
      return M6(t17) ? '"' + t17 + '"' : e21(t17);
    }, n12 = function(e22) {
      return " " + e22 + " ";
    }, r9 = function(r10, i12) {
      var o13 = r10.type, s12 = r10.value;
      switch (o13) {
        case pr2:
          var l11 = e21(s12);
          return l11.substring(0, l11.length - 1);
        case vr2:
          var u10 = r10.field, c10 = r10.operator;
          return "[" + u10 + n12(e21(c10)) + t16(s12) + "]";
        case mr:
          var d12 = r10.operator, h10 = r10.field;
          return "[" + e21(d12) + h10 + "]";
        case yr2:
          return "[" + r10.field + "]";
        case br2:
          var p10 = r10.operator;
          return "[[" + r10.field + n12(e21(p10)) + t16(s12) + "]]";
        case xr:
          return s12;
        case wr:
          return "#" + s12;
        case Er:
          return "." + s12;
        case Br:
        case Tr:
          return a10(r10.parent, i12) + n12(">") + a10(r10.child, i12);
        case _r2:
        case Mr:
          return a10(r10.ancestor, i12) + " " + a10(r10.descendant, i12);
        case Nr:
          var f11 = a10(r10.left, i12), g9 = a10(r10.subject, i12), v12 = a10(r10.right, i12);
          return f11 + (f11.length > 0 ? " " : "") + g9 + v12;
        case Ir:
          return "";
      }
    }, a10 = function(e22, t17) {
      return e22.checks.reduce(function(n13, a11, i12) {
        return n13 + (t17 === e22 && 0 === i12 ? "$" : "") + r9(a11, t17);
      }, "");
    }, i11 = "", o12 = 0; o12 < this.length; o12++) {
      var s11 = this[o12];
      i11 += a10(s11, s11.subject), this.length > 1 && o12 < this.length - 1 && (i11 += ", ");
    }
    return this.toStringCache = i11, i11;
  } };
  var jr = function(e21, t16, n12) {
    var r9, a10, i11, o12 = M6(e21), s11 = I6(e21), l11 = M6(n12), u10 = false, c10 = false, d12 = false;
    switch (t16.indexOf("!") >= 0 && (t16 = t16.replace("!", ""), c10 = true), t16.indexOf("@") >= 0 && (t16 = t16.replace("@", ""), u10 = true), (o12 || l11 || u10) && (a10 = o12 || s11 ? "" + e21 : "", i11 = "" + n12), u10 && (e21 = a10 = a10.toLowerCase(), n12 = i11 = i11.toLowerCase()), t16) {
      case "*=":
        r9 = a10.indexOf(i11) >= 0;
        break;
      case "$=":
        r9 = a10.indexOf(i11, a10.length - i11.length) >= 0;
        break;
      case "^=":
        r9 = 0 === a10.indexOf(i11);
        break;
      case "=":
        r9 = e21 === n12;
        break;
      case ">":
        d12 = true, r9 = e21 > n12;
        break;
      case ">=":
        d12 = true, r9 = e21 >= n12;
        break;
      case "<":
        d12 = true, r9 = e21 < n12;
        break;
      case "<=":
        d12 = true, r9 = e21 <= n12;
        break;
      default:
        r9 = false;
    }
    return !c10 || null == e21 && d12 || (r9 = !r9), r9;
  };
  var Yr = function(e21, t16) {
    return e21.data(t16);
  };
  var Xr = [];
  var Wr = function(e21, t16) {
    return e21.checks.every(function(e22) {
      return Xr[e22.type](e22, t16);
    });
  };
  Xr[pr2] = function(e21, t16) {
    var n12 = e21.value;
    return "*" === n12 || n12 === t16.group();
  }, Xr[xr] = function(e21, t16) {
    return function(e22, t17) {
      return Lr[e22](t17);
    }(e21.value, t16);
  }, Xr[wr] = function(e21, t16) {
    var n12 = e21.value;
    return t16.id() === n12;
  }, Xr[Er] = function(e21, t16) {
    var n12 = e21.value;
    return t16.hasClass(n12);
  }, Xr[br2] = function(e21, t16) {
    var n12 = e21.field, r9 = e21.operator, a10 = e21.value;
    return jr(function(e22, t17) {
      return e22[t17]();
    }(t16, n12), r9, a10);
  }, Xr[vr2] = function(e21, t16) {
    var n12 = e21.field, r9 = e21.operator, a10 = e21.value;
    return jr(Yr(t16, n12), r9, a10);
  }, Xr[mr] = function(e21, t16) {
    var n12 = e21.field, r9 = e21.operator;
    return function(e22, t17) {
      switch (t17) {
        case "?":
          return !!e22;
        case "!":
          return !e22;
        case "^":
          return void 0 === e22;
      }
    }(Yr(t16, n12), r9);
  }, Xr[yr2] = function(e21, t16) {
    var n12 = e21.field;
    return e21.operator, void 0 !== Yr(t16, n12);
  }, Xr[kr] = function(e21, t16) {
    var n12 = e21.nodes[0], r9 = e21.nodes[1], a10 = t16.source(), i11 = t16.target();
    return Wr(n12, a10) && Wr(r9, i11) || Wr(r9, a10) && Wr(n12, i11);
  }, Xr[Pr] = function(e21, t16) {
    return Wr(e21.node, t16) && t16.neighborhood().some(function(t17) {
      return t17.isNode() && Wr(e21.neighbor, t17);
    });
  }, Xr[Cr] = function(e21, t16) {
    return Wr(e21.source, t16.source()) && Wr(e21.target, t16.target());
  }, Xr[Sr] = function(e21, t16) {
    return Wr(e21.source, t16) && t16.outgoers().some(function(t17) {
      return t17.isNode() && Wr(e21.target, t17);
    });
  }, Xr[Dr] = function(e21, t16) {
    return Wr(e21.target, t16) && t16.incomers().some(function(t17) {
      return t17.isNode() && Wr(e21.source, t17);
    });
  }, Xr[Tr] = function(e21, t16) {
    return Wr(e21.child, t16) && Wr(e21.parent, t16.parent());
  }, Xr[Br] = function(e21, t16) {
    return Wr(e21.parent, t16) && t16.children().some(function(t17) {
      return Wr(e21.child, t17);
    });
  }, Xr[Mr] = function(e21, t16) {
    return Wr(e21.descendant, t16) && t16.ancestors().some(function(t17) {
      return Wr(e21.ancestor, t17);
    });
  }, Xr[_r2] = function(e21, t16) {
    return Wr(e21.ancestor, t16) && t16.descendants().some(function(t17) {
      return Wr(e21.descendant, t17);
    });
  }, Xr[Nr] = function(e21, t16) {
    return Wr(e21.subject, t16) && Wr(e21.left, t16) && Wr(e21.right, t16);
  }, Xr[Ir] = function() {
    return true;
  }, Xr[fr2] = function(e21, t16) {
    return e21.value.has(t16);
  }, Xr[gr2] = function(e21, t16) {
    return (0, e21.value)(t16);
  };
  var Hr = { matches: function(e21) {
    for (var t16 = 0; t16 < this.length; t16++) {
      var n12 = this[t16];
      if (Wr(n12, e21))
        return true;
    }
    return false;
  }, filter: function(e21) {
    var t16 = this;
    if (1 === t16.length && 1 === t16[0].checks.length && t16[0].checks[0].type === wr)
      return e21.getElementById(t16[0].checks[0].value).collection();
    var n12 = function(e22) {
      for (var n13 = 0; n13 < t16.length; n13++) {
        var r9 = t16[n13];
        if (Wr(r9, e22))
          return true;
      }
      return false;
    };
    return null == t16.text() && (n12 = function() {
      return true;
    }), e21.filter(n12);
  } };
  var Kr = function(e21) {
    this.inputText = e21, this.currentSubject = null, this.compoundCount = 0, this.edgeCount = 0, this.length = 0, null == e21 || M6(e21) && e21.match(/^\s*$/) || (L5(e21) ? this.addQuery({ checks: [{ type: fr2, value: e21.collection() }] }) : B5(e21) ? this.addQuery({ checks: [{ type: gr2, value: e21 }] }) : M6(e21) ? this.parse(e21) || (this.invalid = true) : Pe("A selector must be created from a string; found "));
  };
  var Gr = Kr.prototype;
  [qr, Hr].forEach(function(e21) {
    return J4(Gr, e21);
  }), Gr.text = function() {
    return this.inputText;
  }, Gr.size = function() {
    return this.length;
  }, Gr.eq = function(e21) {
    return this[e21];
  }, Gr.sameText = function(e21) {
    return !this.invalid && !e21.invalid && this.text() === e21.text();
  }, Gr.addQuery = function(e21) {
    this[this.length++] = e21;
  }, Gr.selector = Gr.toString;
  var Ur = { allAre: function(e21) {
    var t16 = new Kr(e21);
    return this.every(function(e22) {
      return t16.matches(e22);
    });
  }, is: function(e21) {
    var t16 = new Kr(e21);
    return this.some(function(e22) {
      return t16.matches(e22);
    });
  }, some: function(e21, t16) {
    for (var n12 = 0; n12 < this.length; n12++) {
      if (t16 ? e21.apply(t16, [this[n12], n12, this]) : e21(this[n12], n12, this))
        return true;
    }
    return false;
  }, every: function(e21, t16) {
    for (var n12 = 0; n12 < this.length; n12++) {
      if (!(t16 ? e21.apply(t16, [this[n12], n12, this]) : e21(this[n12], n12, this)))
        return false;
    }
    return true;
  }, same: function(e21) {
    if (this === e21)
      return true;
    e21 = this.cy().collection(e21);
    var t16 = this.length;
    return t16 === e21.length && (1 === t16 ? this[0] === e21[0] : this.every(function(t17) {
      return e21.hasElementWithId(t17.id());
    }));
  }, anySame: function(e21) {
    return e21 = this.cy().collection(e21), this.some(function(t16) {
      return e21.hasElementWithId(t16.id());
    });
  }, allAreNeighbors: function(e21) {
    e21 = this.cy().collection(e21);
    var t16 = this.neighborhood();
    return e21.every(function(e22) {
      return t16.hasElementWithId(e22.id());
    });
  }, contains: function(e21) {
    e21 = this.cy().collection(e21);
    var t16 = this;
    return e21.every(function(e22) {
      return t16.hasElementWithId(e22.id());
    });
  } };
  Ur.allAreNeighbours = Ur.allAreNeighbors, Ur.has = Ur.contains, Ur.equal = Ur.equals = Ur.same;
  var Zr;
  var $r;
  var Qr = function(e21, t16) {
    return function(n12, r9, a10, i11) {
      var o12, s11 = n12, l11 = this;
      if (null == s11 ? o12 = "" : L5(s11) && 1 === s11.length && (o12 = s11.id()), 1 === l11.length && o12) {
        var u10 = l11[0]._private, c10 = u10.traversalCache = u10.traversalCache || {}, d12 = c10[t16] = c10[t16] || [], h10 = ve(o12), p10 = d12[h10];
        return p10 || (d12[h10] = e21.call(l11, n12, r9, a10, i11));
      }
      return e21.call(l11, n12, r9, a10, i11);
    };
  };
  var Jr = { parent: function(e21) {
    var t16 = [];
    if (1 === this.length) {
      var n12 = this[0]._private.parent;
      if (n12)
        return n12;
    }
    for (var r9 = 0; r9 < this.length; r9++) {
      var a10 = this[r9]._private.parent;
      a10 && t16.push(a10);
    }
    return this.spawn(t16, true).filter(e21);
  }, parents: function(e21) {
    for (var t16 = [], n12 = this.parent(); n12.nonempty(); ) {
      for (var r9 = 0; r9 < n12.length; r9++) {
        var a10 = n12[r9];
        t16.push(a10);
      }
      n12 = n12.parent();
    }
    return this.spawn(t16, true).filter(e21);
  }, commonAncestors: function(e21) {
    for (var t16, n12 = 0; n12 < this.length; n12++) {
      var r9 = this[n12].parents();
      t16 = (t16 = t16 || r9).intersect(r9);
    }
    return t16.filter(e21);
  }, orphans: function(e21) {
    return this.stdFilter(function(e22) {
      return e22.isOrphan();
    }).filter(e21);
  }, nonorphans: function(e21) {
    return this.stdFilter(function(e22) {
      return e22.isChild();
    }).filter(e21);
  }, children: Qr(function(e21) {
    for (var t16 = [], n12 = 0; n12 < this.length; n12++)
      for (var r9 = this[n12]._private.children, a10 = 0; a10 < r9.length; a10++)
        t16.push(r9[a10]);
    return this.spawn(t16, true).filter(e21);
  }, "children"), siblings: function(e21) {
    return this.parent().children().not(this).filter(e21);
  }, isParent: function() {
    var e21 = this[0];
    if (e21)
      return e21.isNode() && 0 !== e21._private.children.length;
  }, isChildless: function() {
    var e21 = this[0];
    if (e21)
      return e21.isNode() && 0 === e21._private.children.length;
  }, isChild: function() {
    var e21 = this[0];
    if (e21)
      return e21.isNode() && null != e21._private.parent;
  }, isOrphan: function() {
    var e21 = this[0];
    if (e21)
      return e21.isNode() && null == e21._private.parent;
  }, descendants: function(e21) {
    var t16 = [];
    return function e22(n12) {
      for (var r9 = 0; r9 < n12.length; r9++) {
        var a10 = n12[r9];
        t16.push(a10), a10.children().nonempty() && e22(a10.children());
      }
    }(this.children()), this.spawn(t16, true).filter(e21);
  } };
  function ea(e21, t16, n12, r9) {
    for (var a10 = [], i11 = new qe(), o12 = e21.cy().hasCompoundNodes(), s11 = 0; s11 < e21.length; s11++) {
      var l11 = e21[s11];
      n12 ? a10.push(l11) : o12 && r9(a10, i11, l11);
    }
    for (; a10.length > 0; ) {
      var u10 = a10.shift();
      t16(u10), i11.add(u10.id()), o12 && r9(a10, i11, u10);
    }
    return e21;
  }
  function ta(e21, t16, n12) {
    if (n12.isParent())
      for (var r9 = n12._private.children, a10 = 0; a10 < r9.length; a10++) {
        var i11 = r9[a10];
        t16.has(i11.id()) || e21.push(i11);
      }
  }
  function na(e21, t16, n12) {
    if (n12.isChild()) {
      var r9 = n12._private.parent;
      t16.has(r9.id()) || e21.push(r9);
    }
  }
  function ra(e21, t16, n12) {
    na(e21, t16, n12), ta(e21, t16, n12);
  }
  Jr.forEachDown = function(e21) {
    return ea(this, e21, !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], ta);
  }, Jr.forEachUp = function(e21) {
    return ea(this, e21, !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], na);
  }, Jr.forEachUpAndDown = function(e21) {
    return ea(this, e21, !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], ra);
  }, Jr.ancestors = Jr.parents, (Zr = $r = { data: ur3.data({ field: "data", bindingEvent: "data", allowBinding: true, allowSetting: true, settingEvent: "data", settingTriggersEvent: true, triggerFnName: "trigger", allowGetting: true, immutableKeys: { id: true, source: true, target: true, parent: true }, updateStyle: true }), removeData: ur3.removeData({ field: "data", event: "data", triggerFnName: "trigger", triggerEvent: true, immutableKeys: { id: true, source: true, target: true, parent: true }, updateStyle: true }), scratch: ur3.data({ field: "scratch", bindingEvent: "scratch", allowBinding: true, allowSetting: true, settingEvent: "scratch", settingTriggersEvent: true, triggerFnName: "trigger", allowGetting: true, updateStyle: true }), removeScratch: ur3.removeData({ field: "scratch", event: "scratch", triggerFnName: "trigger", triggerEvent: true, updateStyle: true }), rscratch: ur3.data({ field: "rscratch", allowBinding: false, allowSetting: true, settingTriggersEvent: false, allowGetting: true }), removeRscratch: ur3.removeData({ field: "rscratch", triggerEvent: false }), id: function() {
    var e21 = this[0];
    if (e21)
      return e21._private.data.id;
  } }).attr = Zr.data, Zr.removeAttr = Zr.removeData;
  var aa;
  var ia;
  var oa = $r;
  var sa = {};
  function la(e21) {
    return function(t16) {
      var n12 = this;
      if (void 0 === t16 && (t16 = true), 0 !== n12.length && n12.isNode() && !n12.removed()) {
        for (var r9 = 0, a10 = n12[0], i11 = a10._private.edges, o12 = 0; o12 < i11.length; o12++) {
          var s11 = i11[o12];
          !t16 && s11.isLoop() || (r9 += e21(a10, s11));
        }
        return r9;
      }
    };
  }
  function ua(e21, t16) {
    return function(n12) {
      for (var r9, a10 = this.nodes(), i11 = 0; i11 < a10.length; i11++) {
        var o12 = a10[i11][e21](n12);
        void 0 === o12 || void 0 !== r9 && !t16(o12, r9) || (r9 = o12);
      }
      return r9;
    };
  }
  J4(sa, { degree: la(function(e21, t16) {
    return t16.source().same(t16.target()) ? 2 : 1;
  }), indegree: la(function(e21, t16) {
    return t16.target().same(e21) ? 1 : 0;
  }), outdegree: la(function(e21, t16) {
    return t16.source().same(e21) ? 1 : 0;
  }) }), J4(sa, { minDegree: ua("degree", function(e21, t16) {
    return e21 < t16;
  }), maxDegree: ua("degree", function(e21, t16) {
    return e21 > t16;
  }), minIndegree: ua("indegree", function(e21, t16) {
    return e21 < t16;
  }), maxIndegree: ua("indegree", function(e21, t16) {
    return e21 > t16;
  }), minOutdegree: ua("outdegree", function(e21, t16) {
    return e21 < t16;
  }), maxOutdegree: ua("outdegree", function(e21, t16) {
    return e21 > t16;
  }) }), J4(sa, { totalDegree: function(e21) {
    for (var t16 = 0, n12 = this.nodes(), r9 = 0; r9 < n12.length; r9++)
      t16 += n12[r9].degree(e21);
    return t16;
  } });
  var ca = function(e21, t16, n12) {
    for (var r9 = 0; r9 < e21.length; r9++) {
      var a10 = e21[r9];
      if (!a10.locked()) {
        var i11 = a10._private.position, o12 = { x: null != t16.x ? t16.x - i11.x : 0, y: null != t16.y ? t16.y - i11.y : 0 };
        !a10.isParent() || 0 === o12.x && 0 === o12.y || a10.children().shift(o12, n12), a10.dirtyBoundingBoxCache();
      }
    }
  };
  var da = { field: "position", bindingEvent: "position", allowBinding: true, allowSetting: true, settingEvent: "position", settingTriggersEvent: true, triggerFnName: "emitAndNotify", allowGetting: true, validKeys: ["x", "y"], beforeGet: function(e21) {
    e21.updateCompoundBounds();
  }, beforeSet: function(e21, t16) {
    ca(e21, t16, false);
  }, onSet: function(e21) {
    e21.dirtyCompoundBoundsCache();
  }, canSet: function(e21) {
    return !e21.locked();
  } };
  aa = ia = { position: ur3.data(da), silentPosition: ur3.data(J4({}, da, { allowBinding: false, allowSetting: true, settingTriggersEvent: false, allowGetting: false, beforeSet: function(e21, t16) {
    ca(e21, t16, true);
  }, onSet: function(e21) {
    e21.dirtyCompoundBoundsCache();
  } })), positions: function(e21, t16) {
    if (N6(e21))
      t16 ? this.silentPosition(e21) : this.position(e21);
    else if (B5(e21)) {
      var n12 = e21, r9 = this.cy();
      r9.startBatch();
      for (var a10 = 0; a10 < this.length; a10++) {
        var i11, o12 = this[a10];
        (i11 = n12(o12, a10)) && (t16 ? o12.silentPosition(i11) : o12.position(i11));
      }
      r9.endBatch();
    }
    return this;
  }, silentPositions: function(e21) {
    return this.positions(e21, true);
  }, shift: function(e21, t16, n12) {
    var r9;
    if (N6(e21) ? (r9 = { x: I6(e21.x) ? e21.x : 0, y: I6(e21.y) ? e21.y : 0 }, n12 = t16) : M6(e21) && I6(t16) && ((r9 = { x: 0, y: 0 })[e21] = t16), null != r9) {
      var a10 = this.cy();
      a10.startBatch();
      for (var i11 = 0; i11 < this.length; i11++) {
        var o12 = this[i11];
        if (!(a10.hasCompoundNodes() && o12.isChild() && o12.ancestors().anySame(this))) {
          var s11 = o12.position(), l11 = { x: s11.x + r9.x, y: s11.y + r9.y };
          n12 ? o12.silentPosition(l11) : o12.position(l11);
        }
      }
      a10.endBatch();
    }
    return this;
  }, silentShift: function(e21, t16) {
    return N6(e21) ? this.shift(e21, true) : M6(e21) && I6(t16) && this.shift(e21, t16, true), this;
  }, renderedPosition: function(e21, t16) {
    var n12 = this[0], r9 = this.cy(), a10 = r9.zoom(), i11 = r9.pan(), o12 = N6(e21) ? e21 : void 0, s11 = void 0 !== o12 || void 0 !== t16 && M6(e21);
    if (n12 && n12.isNode()) {
      if (!s11) {
        var l11 = n12.position();
        return o12 = at4(l11, a10, i11), void 0 === e21 ? o12 : o12[e21];
      }
      for (var u10 = 0; u10 < this.length; u10++) {
        var c10 = this[u10];
        void 0 !== t16 ? c10.position(e21, (t16 - i11[e21]) / a10) : void 0 !== o12 && c10.position(it4(o12, a10, i11));
      }
    } else if (!s11)
      return;
    return this;
  }, relativePosition: function(e21, t16) {
    var n12 = this[0], r9 = this.cy(), a10 = N6(e21) ? e21 : void 0, i11 = void 0 !== a10 || void 0 !== t16 && M6(e21), o12 = r9.hasCompoundNodes();
    if (n12 && n12.isNode()) {
      if (!i11) {
        var s11 = n12.position(), l11 = o12 ? n12.parent() : null, u10 = l11 && l11.length > 0, c10 = u10;
        u10 && (l11 = l11[0]);
        var d12 = c10 ? l11.position() : { x: 0, y: 0 };
        return a10 = { x: s11.x - d12.x, y: s11.y - d12.y }, void 0 === e21 ? a10 : a10[e21];
      }
      for (var h10 = 0; h10 < this.length; h10++) {
        var p10 = this[h10], f11 = o12 ? p10.parent() : null, g9 = f11 && f11.length > 0, v12 = g9;
        g9 && (f11 = f11[0]);
        var y10 = v12 ? f11.position() : { x: 0, y: 0 };
        void 0 !== t16 ? p10.position(e21, t16 + y10[e21]) : void 0 !== a10 && p10.position({ x: a10.x + y10.x, y: a10.y + y10.y });
      }
    } else if (!i11)
      return;
    return this;
  } }, aa.modelPosition = aa.point = aa.position, aa.modelPositions = aa.points = aa.positions, aa.renderedPoint = aa.renderedPosition, aa.relativePoint = aa.relativePosition;
  var ha;
  var pa;
  var fa = ia;
  ha = pa = {}, pa.renderedBoundingBox = function(e21) {
    var t16 = this.boundingBox(e21), n12 = this.cy(), r9 = n12.zoom(), a10 = n12.pan(), i11 = t16.x1 * r9 + a10.x, o12 = t16.x2 * r9 + a10.x, s11 = t16.y1 * r9 + a10.y, l11 = t16.y2 * r9 + a10.y;
    return { x1: i11, x2: o12, y1: s11, y2: l11, w: o12 - i11, h: l11 - s11 };
  }, pa.dirtyCompoundBoundsCache = function() {
    var e21 = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], t16 = this.cy();
    return t16.styleEnabled() && t16.hasCompoundNodes() ? (this.forEachUp(function(t17) {
      if (t17.isParent()) {
        var n12 = t17._private;
        n12.compoundBoundsClean = false, n12.bbCache = null, e21 || t17.emitAndNotify("bounds");
      }
    }), this) : this;
  }, pa.updateCompoundBounds = function() {
    var e21 = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], t16 = this.cy();
    if (!t16.styleEnabled() || !t16.hasCompoundNodes())
      return this;
    if (!e21 && t16.batching())
      return this;
    function n12(e22) {
      if (e22.isParent()) {
        var t17 = e22._private, n13 = e22.children(), r10 = "include" === e22.pstyle("compound-sizing-wrt-labels").value, a11 = { width: { val: e22.pstyle("min-width").pfValue, left: e22.pstyle("min-width-bias-left"), right: e22.pstyle("min-width-bias-right") }, height: { val: e22.pstyle("min-height").pfValue, top: e22.pstyle("min-height-bias-top"), bottom: e22.pstyle("min-height-bias-bottom") } }, i12 = n13.boundingBox({ includeLabels: r10, includeOverlays: false, useCache: false }), o12 = t17.position;
        0 !== i12.w && 0 !== i12.h || ((i12 = { w: e22.pstyle("width").pfValue, h: e22.pstyle("height").pfValue }).x1 = o12.x - i12.w / 2, i12.x2 = o12.x + i12.w / 2, i12.y1 = o12.y - i12.h / 2, i12.y2 = o12.y + i12.h / 2);
        var s11 = a11.width.left.value;
        "px" === a11.width.left.units && a11.width.val > 0 && (s11 = 100 * s11 / a11.width.val);
        var l11 = a11.width.right.value;
        "px" === a11.width.right.units && a11.width.val > 0 && (l11 = 100 * l11 / a11.width.val);
        var u10 = a11.height.top.value;
        "px" === a11.height.top.units && a11.height.val > 0 && (u10 = 100 * u10 / a11.height.val);
        var c10 = a11.height.bottom.value;
        "px" === a11.height.bottom.units && a11.height.val > 0 && (c10 = 100 * c10 / a11.height.val);
        var d12 = y10(a11.width.val - i12.w, s11, l11), h10 = d12.biasDiff, p10 = d12.biasComplementDiff, f11 = y10(a11.height.val - i12.h, u10, c10), g9 = f11.biasDiff, v12 = f11.biasComplementDiff;
        t17.autoPadding = function(e23, t18, n14, r11) {
          if ("%" !== n14.units)
            return "px" === n14.units ? n14.pfValue : 0;
          switch (r11) {
            case "width":
              return e23 > 0 ? n14.pfValue * e23 : 0;
            case "height":
              return t18 > 0 ? n14.pfValue * t18 : 0;
            case "average":
              return e23 > 0 && t18 > 0 ? n14.pfValue * (e23 + t18) / 2 : 0;
            case "min":
              return e23 > 0 && t18 > 0 ? e23 > t18 ? n14.pfValue * t18 : n14.pfValue * e23 : 0;
            case "max":
              return e23 > 0 && t18 > 0 ? e23 > t18 ? n14.pfValue * e23 : n14.pfValue * t18 : 0;
            default:
              return 0;
          }
        }(i12.w, i12.h, e22.pstyle("padding"), e22.pstyle("padding-relative-to").value), t17.autoWidth = Math.max(i12.w, a11.width.val), o12.x = (-h10 + i12.x1 + i12.x2 + p10) / 2, t17.autoHeight = Math.max(i12.h, a11.height.val), o12.y = (-g9 + i12.y1 + i12.y2 + v12) / 2;
      }
      function y10(e23, t18, n14) {
        var r11 = 0, a12 = 0, i13 = t18 + n14;
        return e23 > 0 && i13 > 0 && (r11 = t18 / i13 * e23, a12 = n14 / i13 * e23), { biasDiff: r11, biasComplementDiff: a12 };
      }
    }
    for (var r9 = 0; r9 < this.length; r9++) {
      var a10 = this[r9], i11 = a10._private;
      i11.compoundBoundsClean && !e21 || (n12(a10), t16.batching() || (i11.compoundBoundsClean = true));
    }
    return this;
  };
  var ga = function(e21) {
    return e21 === 1 / 0 || e21 === -1 / 0 ? 0 : e21;
  };
  var va = function(e21, t16, n12, r9, a10) {
    r9 - t16 != 0 && a10 - n12 != 0 && null != t16 && null != n12 && null != r9 && null != a10 && (e21.x1 = t16 < e21.x1 ? t16 : e21.x1, e21.x2 = r9 > e21.x2 ? r9 : e21.x2, e21.y1 = n12 < e21.y1 ? n12 : e21.y1, e21.y2 = a10 > e21.y2 ? a10 : e21.y2, e21.w = e21.x2 - e21.x1, e21.h = e21.y2 - e21.y1);
  };
  var ya = function(e21, t16) {
    return null == t16 ? e21 : va(e21, t16.x1, t16.y1, t16.x2, t16.y2);
  };
  var ma = function(e21, t16, n12) {
    return Oe(e21, t16, n12);
  };
  var ba = function(e21, t16, n12) {
    if (!t16.cy().headless()) {
      var r9, a10, i11 = t16._private, o12 = i11.rstyle, s11 = o12.arrowWidth / 2;
      if ("none" !== t16.pstyle(n12 + "-arrow-shape").value) {
        "source" === n12 ? (r9 = o12.srcX, a10 = o12.srcY) : "target" === n12 ? (r9 = o12.tgtX, a10 = o12.tgtY) : (r9 = o12.midX, a10 = o12.midY);
        var l11 = i11.arrowBounds = i11.arrowBounds || {}, u10 = l11[n12] = l11[n12] || {};
        u10.x1 = r9 - s11, u10.y1 = a10 - s11, u10.x2 = r9 + s11, u10.y2 = a10 + s11, u10.w = u10.x2 - u10.x1, u10.h = u10.y2 - u10.y1, mt4(u10, 1), va(e21, u10.x1, u10.y1, u10.x2, u10.y2);
      }
    }
  };
  var xa = function(e21, t16, n12) {
    if (!t16.cy().headless()) {
      var r9;
      r9 = n12 ? n12 + "-" : "";
      var a10 = t16._private, i11 = a10.rstyle;
      if (t16.pstyle(r9 + "label").strValue) {
        var o12, s11, l11, u10, c10 = t16.pstyle("text-halign"), d12 = t16.pstyle("text-valign"), h10 = ma(i11, "labelWidth", n12), p10 = ma(i11, "labelHeight", n12), f11 = ma(i11, "labelX", n12), g9 = ma(i11, "labelY", n12), v12 = t16.pstyle(r9 + "text-margin-x").pfValue, y10 = t16.pstyle(r9 + "text-margin-y").pfValue, m12 = t16.isEdge(), b11 = t16.pstyle(r9 + "text-rotation"), x10 = t16.pstyle("text-outline-width").pfValue, w11 = t16.pstyle("text-border-width").pfValue / 2, E9 = t16.pstyle("text-background-padding").pfValue, k10 = p10, C9 = h10, S8 = C9 / 2, D9 = k10 / 2;
        if (m12)
          o12 = f11 - S8, s11 = f11 + S8, l11 = g9 - D9, u10 = g9 + D9;
        else {
          switch (c10.value) {
            case "left":
              o12 = f11 - C9, s11 = f11;
              break;
            case "center":
              o12 = f11 - S8, s11 = f11 + S8;
              break;
            case "right":
              o12 = f11, s11 = f11 + C9;
          }
          switch (d12.value) {
            case "top":
              l11 = g9 - k10, u10 = g9;
              break;
            case "center":
              l11 = g9 - D9, u10 = g9 + D9;
              break;
            case "bottom":
              l11 = g9, u10 = g9 + k10;
          }
        }
        o12 += v12 - Math.max(x10, w11) - E9 - 2, s11 += v12 + Math.max(x10, w11) + E9 + 2, l11 += y10 - Math.max(x10, w11) - E9 - 2, u10 += y10 + Math.max(x10, w11) + E9 + 2;
        var P10 = n12 || "main", T9 = a10.labelBounds, M9 = T9[P10] = T9[P10] || {};
        M9.x1 = o12, M9.y1 = l11, M9.x2 = s11, M9.y2 = u10, M9.w = s11 - o12, M9.h = u10 - l11;
        var B9 = m12 && "autorotate" === b11.strValue, _7 = null != b11.pfValue && 0 !== b11.pfValue;
        if (B9 || _7) {
          var N8 = B9 ? ma(a10.rstyle, "labelAngle", n12) : b11.pfValue, I8 = Math.cos(N8), z8 = Math.sin(N8), L9 = (o12 + s11) / 2, A10 = (l11 + u10) / 2;
          if (!m12) {
            switch (c10.value) {
              case "left":
                L9 = s11;
                break;
              case "right":
                L9 = o12;
            }
            switch (d12.value) {
              case "top":
                A10 = u10;
                break;
              case "bottom":
                A10 = l11;
            }
          }
          var O10 = function(e22, t17) {
            return { x: (e22 -= L9) * I8 - (t17 -= A10) * z8 + L9, y: e22 * z8 + t17 * I8 + A10 };
          }, R8 = O10(o12, l11), V8 = O10(o12, u10), F9 = O10(s11, l11), q8 = O10(s11, u10);
          o12 = Math.min(R8.x, V8.x, F9.x, q8.x), s11 = Math.max(R8.x, V8.x, F9.x, q8.x), l11 = Math.min(R8.y, V8.y, F9.y, q8.y), u10 = Math.max(R8.y, V8.y, F9.y, q8.y);
        }
        var j9 = P10 + "Rot", Y6 = T9[j9] = T9[j9] || {};
        Y6.x1 = o12, Y6.y1 = l11, Y6.x2 = s11, Y6.y2 = u10, Y6.w = s11 - o12, Y6.h = u10 - l11, va(e21, o12, l11, s11, u10), va(a10.labelBounds.all, o12, l11, s11, u10);
      }
      return e21;
    }
  };
  var wa = function(e21) {
    var t16 = 0, n12 = function(e22) {
      return (e22 ? 1 : 0) << t16++;
    }, r9 = 0;
    return r9 += n12(e21.incudeNodes), r9 += n12(e21.includeEdges), r9 += n12(e21.includeLabels), r9 += n12(e21.includeMainLabels), r9 += n12(e21.includeSourceLabels), r9 += n12(e21.includeTargetLabels), r9 += n12(e21.includeOverlays);
  };
  var Ea = function(e21) {
    if (e21.isEdge()) {
      var t16 = e21.source().position(), n12 = e21.target().position(), r9 = function(e22) {
        return Math.round(e22);
      };
      return function(e22, t17) {
        var n13 = { value: 0, done: false }, r10 = 0, a10 = e22.length;
        return de({ next: function() {
          return r10 < a10 ? n13.value = e22[r10++] : n13.done = true, n13;
        } }, t17);
      }([r9(t16.x), r9(t16.y), r9(n12.x), r9(n12.y)]);
    }
    return 0;
  };
  var ka = function(e21, t16) {
    var n12, r9 = e21._private, a10 = e21.isEdge(), i11 = (null == t16 ? Sa : wa(t16)) === Sa, o12 = Ea(e21), s11 = r9.bbCachePosKey === o12, l11 = t16.useCache && s11, u10 = function(e22) {
      return null == e22._private.bbCache || e22._private.styleDirty;
    };
    if (!l11 || u10(e21) || a10 && u10(e21.source()) || u10(e21.target()) ? (s11 || e21.recalculateRenderedStyle(l11), n12 = function(e22, t17) {
      var n13, r10, a11, i12, o13, s12, l12, u11 = e22._private.cy, c11 = u11.styleEnabled(), d12 = u11.headless(), h10 = vt4(), p10 = e22._private, f11 = e22.isNode(), g9 = e22.isEdge(), v12 = p10.rstyle, y10 = f11 && c11 ? e22.pstyle("bounds-expansion").pfValue : [0], m12 = function(e23) {
        return "none" !== e23.pstyle("display").value;
      }, b11 = !c11 || m12(e22) && (!g9 || m12(e22.source()) && m12(e22.target()));
      if (b11) {
        var x10 = 0;
        c11 && t17.includeOverlays && 0 !== e22.pstyle("overlay-opacity").value && (x10 = e22.pstyle("overlay-padding").value);
        var w11 = 0;
        c11 && t17.includeUnderlays && 0 !== e22.pstyle("underlay-opacity").value && (w11 = e22.pstyle("underlay-padding").value);
        var E9 = Math.max(x10, w11), k10 = 0;
        if (c11 && (k10 = e22.pstyle("width").pfValue / 2), f11 && t17.includeNodes) {
          var C9 = e22.position();
          o13 = C9.x, s12 = C9.y;
          var S8 = e22.outerWidth() / 2, D9 = e22.outerHeight() / 2;
          va(h10, n13 = o13 - S8, a11 = s12 - D9, r10 = o13 + S8, i12 = s12 + D9);
        } else if (g9 && t17.includeEdges)
          if (c11 && !d12) {
            var P10 = e22.pstyle("curve-style").strValue;
            if (n13 = Math.min(v12.srcX, v12.midX, v12.tgtX), r10 = Math.max(v12.srcX, v12.midX, v12.tgtX), a11 = Math.min(v12.srcY, v12.midY, v12.tgtY), i12 = Math.max(v12.srcY, v12.midY, v12.tgtY), va(h10, n13 -= k10, a11 -= k10, r10 += k10, i12 += k10), "haystack" === P10) {
              var T9 = v12.haystackPts;
              if (T9 && 2 === T9.length) {
                if (n13 = T9[0].x, a11 = T9[0].y, n13 > (r10 = T9[1].x)) {
                  var M9 = n13;
                  n13 = r10, r10 = M9;
                }
                if (a11 > (i12 = T9[1].y)) {
                  var B9 = a11;
                  a11 = i12, i12 = B9;
                }
                va(h10, n13 - k10, a11 - k10, r10 + k10, i12 + k10);
              }
            } else if ("bezier" === P10 || "unbundled-bezier" === P10 || "segments" === P10 || "taxi" === P10) {
              var _7;
              switch (P10) {
                case "bezier":
                case "unbundled-bezier":
                  _7 = v12.bezierPts;
                  break;
                case "segments":
                case "taxi":
                  _7 = v12.linePts;
              }
              if (null != _7)
                for (var N8 = 0; N8 < _7.length; N8++) {
                  var I8 = _7[N8];
                  n13 = I8.x - k10, r10 = I8.x + k10, a11 = I8.y - k10, i12 = I8.y + k10, va(h10, n13, a11, r10, i12);
                }
            }
          } else {
            var z8 = e22.source().position(), L9 = e22.target().position();
            if ((n13 = z8.x) > (r10 = L9.x)) {
              var A10 = n13;
              n13 = r10, r10 = A10;
            }
            if ((a11 = z8.y) > (i12 = L9.y)) {
              var O10 = a11;
              a11 = i12, i12 = O10;
            }
            va(h10, n13 -= k10, a11 -= k10, r10 += k10, i12 += k10);
          }
        if (c11 && t17.includeEdges && g9 && (ba(h10, e22, "mid-source"), ba(h10, e22, "mid-target"), ba(h10, e22, "source"), ba(h10, e22, "target")), c11 && "yes" === e22.pstyle("ghost").value) {
          var R8 = e22.pstyle("ghost-offset-x").pfValue, V8 = e22.pstyle("ghost-offset-y").pfValue;
          va(h10, h10.x1 + R8, h10.y1 + V8, h10.x2 + R8, h10.y2 + V8);
        }
        var F9 = p10.bodyBounds = p10.bodyBounds || {};
        xt4(F9, h10), bt4(F9, y10), mt4(F9, 1), c11 && (n13 = h10.x1, r10 = h10.x2, a11 = h10.y1, i12 = h10.y2, va(h10, n13 - E9, a11 - E9, r10 + E9, i12 + E9));
        var q8 = p10.overlayBounds = p10.overlayBounds || {};
        xt4(q8, h10), bt4(q8, y10), mt4(q8, 1);
        var j9 = p10.labelBounds = p10.labelBounds || {};
        null != j9.all ? ((l12 = j9.all).x1 = 1 / 0, l12.y1 = 1 / 0, l12.x2 = -1 / 0, l12.y2 = -1 / 0, l12.w = 0, l12.h = 0) : j9.all = vt4(), c11 && t17.includeLabels && (t17.includeMainLabels && xa(h10, e22, null), g9 && (t17.includeSourceLabels && xa(h10, e22, "source"), t17.includeTargetLabels && xa(h10, e22, "target")));
      }
      return h10.x1 = ga(h10.x1), h10.y1 = ga(h10.y1), h10.x2 = ga(h10.x2), h10.y2 = ga(h10.y2), h10.w = ga(h10.x2 - h10.x1), h10.h = ga(h10.y2 - h10.y1), h10.w > 0 && h10.h > 0 && b11 && (bt4(h10, y10), mt4(h10, 1)), h10;
    }(e21, Ca), r9.bbCache = n12, r9.bbCachePosKey = o12) : n12 = r9.bbCache, !i11) {
      var c10 = e21.isNode();
      n12 = vt4(), (t16.includeNodes && c10 || t16.includeEdges && !c10) && (t16.includeOverlays ? ya(n12, r9.overlayBounds) : ya(n12, r9.bodyBounds)), t16.includeLabels && (t16.includeMainLabels && (!a10 || t16.includeSourceLabels && t16.includeTargetLabels) ? ya(n12, r9.labelBounds.all) : (t16.includeMainLabels && ya(n12, r9.labelBounds.mainRot), t16.includeSourceLabels && ya(n12, r9.labelBounds.sourceRot), t16.includeTargetLabels && ya(n12, r9.labelBounds.targetRot))), n12.w = n12.x2 - n12.x1, n12.h = n12.y2 - n12.y1;
    }
    return n12;
  };
  var Ca = { includeNodes: true, includeEdges: true, includeLabels: true, includeMainLabels: true, includeSourceLabels: true, includeTargetLabels: true, includeOverlays: true, includeUnderlays: true, useCache: true };
  var Sa = wa(Ca);
  var Da = ze(Ca);
  pa.boundingBox = function(e21) {
    var t16;
    if (1 !== this.length || null == this[0]._private.bbCache || this[0]._private.styleDirty || void 0 !== e21 && void 0 !== e21.useCache && true !== e21.useCache) {
      t16 = vt4();
      var n12 = Da(e21 = e21 || Ca), r9 = this;
      if (r9.cy().styleEnabled())
        for (var a10 = 0; a10 < r9.length; a10++) {
          var i11 = r9[a10], o12 = i11._private, s11 = Ea(i11), l11 = o12.bbCachePosKey === s11, u10 = n12.useCache && l11 && !o12.styleDirty;
          i11.recalculateRenderedStyle(u10);
        }
      this.updateCompoundBounds(!e21.useCache);
      for (var c10 = 0; c10 < r9.length; c10++) {
        var d12 = r9[c10];
        ya(t16, ka(d12, n12));
      }
    } else
      e21 = void 0 === e21 ? Ca : Da(e21), t16 = ka(this[0], e21);
    return t16.x1 = ga(t16.x1), t16.y1 = ga(t16.y1), t16.x2 = ga(t16.x2), t16.y2 = ga(t16.y2), t16.w = ga(t16.x2 - t16.x1), t16.h = ga(t16.y2 - t16.y1), t16;
  }, pa.dirtyBoundingBoxCache = function() {
    for (var e21 = 0; e21 < this.length; e21++) {
      var t16 = this[e21]._private;
      t16.bbCache = null, t16.bbCachePosKey = null, t16.bodyBounds = null, t16.overlayBounds = null, t16.labelBounds.all = null, t16.labelBounds.source = null, t16.labelBounds.target = null, t16.labelBounds.main = null, t16.labelBounds.sourceRot = null, t16.labelBounds.targetRot = null, t16.labelBounds.mainRot = null, t16.arrowBounds.source = null, t16.arrowBounds.target = null, t16.arrowBounds["mid-source"] = null, t16.arrowBounds["mid-target"] = null;
    }
    return this.emitAndNotify("bounds"), this;
  }, pa.boundingBoxAt = function(e21) {
    var t16 = this.nodes(), n12 = this.cy(), r9 = n12.hasCompoundNodes(), a10 = n12.collection();
    if (r9 && (a10 = t16.filter(function(e22) {
      return e22.isParent();
    }), t16 = t16.not(a10)), N6(e21)) {
      var i11 = e21;
      e21 = function() {
        return i11;
      };
    }
    n12.startBatch(), t16.forEach(function(t17, n13) {
      return t17._private.bbAtOldPos = e21(t17, n13);
    }).silentPositions(e21), r9 && (a10.dirtyCompoundBoundsCache(), a10.dirtyBoundingBoxCache(), a10.updateCompoundBounds(true));
    var o12 = function(e22) {
      return { x1: e22.x1, x2: e22.x2, w: e22.w, y1: e22.y1, y2: e22.y2, h: e22.h };
    }(this.boundingBox({ useCache: false }));
    return t16.silentPositions(function(e22) {
      return e22._private.bbAtOldPos;
    }), r9 && (a10.dirtyCompoundBoundsCache(), a10.dirtyBoundingBoxCache(), a10.updateCompoundBounds(true)), n12.endBatch(), o12;
  }, ha.boundingbox = ha.bb = ha.boundingBox, ha.renderedBoundingbox = ha.renderedBoundingBox;
  var Pa;
  var Ta;
  var Ma = pa;
  Pa = Ta = {};
  var Ba = function(e21) {
    e21.uppercaseName = H4(e21.name), e21.autoName = "auto" + e21.uppercaseName, e21.labelName = "label" + e21.uppercaseName, e21.outerName = "outer" + e21.uppercaseName, e21.uppercaseOuterName = H4(e21.outerName), Pa[e21.name] = function() {
      var t16 = this[0], n12 = t16._private, r9 = n12.cy._private.styleEnabled;
      if (t16) {
        if (r9) {
          if (t16.isParent())
            return t16.updateCompoundBounds(), n12[e21.autoName] || 0;
          var a10 = t16.pstyle(e21.name);
          return "label" === a10.strValue ? (t16.recalculateRenderedStyle(), n12.rstyle[e21.labelName] || 0) : a10.pfValue;
        }
        return 1;
      }
    }, Pa["outer" + e21.uppercaseName] = function() {
      var t16 = this[0], n12 = t16._private.cy._private.styleEnabled;
      if (t16)
        return n12 ? t16[e21.name]() + t16.pstyle("border-width").pfValue + 2 * t16.padding() : 1;
    }, Pa["rendered" + e21.uppercaseName] = function() {
      var t16 = this[0];
      if (t16)
        return t16[e21.name]() * this.cy().zoom();
    }, Pa["rendered" + e21.uppercaseOuterName] = function() {
      var t16 = this[0];
      if (t16)
        return t16[e21.outerName]() * this.cy().zoom();
    };
  };
  Ba({ name: "width" }), Ba({ name: "height" }), Ta.padding = function() {
    var e21 = this[0], t16 = e21._private;
    return e21.isParent() ? (e21.updateCompoundBounds(), void 0 !== t16.autoPadding ? t16.autoPadding : e21.pstyle("padding").pfValue) : e21.pstyle("padding").pfValue;
  }, Ta.paddedHeight = function() {
    var e21 = this[0];
    return e21.height() + 2 * e21.padding();
  }, Ta.paddedWidth = function() {
    var e21 = this[0];
    return e21.width() + 2 * e21.padding();
  };
  var _a = Ta;
  var Na = { controlPoints: { get: function(e21) {
    return e21.renderer().getControlPoints(e21);
  }, mult: true }, segmentPoints: { get: function(e21) {
    return e21.renderer().getSegmentPoints(e21);
  }, mult: true }, sourceEndpoint: { get: function(e21) {
    return e21.renderer().getSourceEndpoint(e21);
  } }, targetEndpoint: { get: function(e21) {
    return e21.renderer().getTargetEndpoint(e21);
  } }, midpoint: { get: function(e21) {
    return e21.renderer().getEdgeMidpoint(e21);
  } } };
  var Ia = Object.keys(Na).reduce(function(e21, t16) {
    var n12 = Na[t16], r9 = function(e22) {
      return "rendered" + e22[0].toUpperCase() + e22.substr(1);
    }(t16);
    return e21[t16] = function() {
      return function(e22, t17) {
        if (e22.isEdge())
          return t17(e22);
      }(this, n12.get);
    }, n12.mult ? e21[r9] = function() {
      return function(e22, t17) {
        if (e22.isEdge()) {
          var n13 = e22.cy(), r10 = n13.pan(), a10 = n13.zoom();
          return t17(e22).map(function(e23) {
            return at4(e23, a10, r10);
          });
        }
      }(this, n12.get);
    } : e21[r9] = function() {
      return function(e22, t17) {
        if (e22.isEdge()) {
          var n13 = e22.cy();
          return at4(t17(e22), n13.zoom(), n13.pan());
        }
      }(this, n12.get);
    }, e21;
  }, {});
  var za = J4({}, fa, Ma, _a, Ia);
  var La = function(e21, t16) {
    this.recycle(e21, t16);
  };
  function Aa() {
    return false;
  }
  function Oa() {
    return true;
  }
  La.prototype = { instanceString: function() {
    return "event";
  }, recycle: function(e21, t16) {
    if (this.isImmediatePropagationStopped = this.isPropagationStopped = this.isDefaultPrevented = Aa, null != e21 && e21.preventDefault ? (this.type = e21.type, this.isDefaultPrevented = e21.defaultPrevented ? Oa : Aa) : null != e21 && e21.type ? t16 = e21 : this.type = e21, null != t16 && (this.originalEvent = t16.originalEvent, this.type = null != t16.type ? t16.type : this.type, this.cy = t16.cy, this.target = t16.target, this.position = t16.position, this.renderedPosition = t16.renderedPosition, this.namespace = t16.namespace, this.layout = t16.layout), null != this.cy && null != this.position && null == this.renderedPosition) {
      var n12 = this.position, r9 = this.cy.zoom(), a10 = this.cy.pan();
      this.renderedPosition = { x: n12.x * r9 + a10.x, y: n12.y * r9 + a10.y };
    }
    this.timeStamp = e21 && e21.timeStamp || Date.now();
  }, preventDefault: function() {
    this.isDefaultPrevented = Oa;
    var e21 = this.originalEvent;
    e21 && e21.preventDefault && e21.preventDefault();
  }, stopPropagation: function() {
    this.isPropagationStopped = Oa;
    var e21 = this.originalEvent;
    e21 && e21.stopPropagation && e21.stopPropagation();
  }, stopImmediatePropagation: function() {
    this.isImmediatePropagationStopped = Oa, this.stopPropagation();
  }, isDefaultPrevented: Aa, isPropagationStopped: Aa, isImmediatePropagationStopped: Aa };
  var Ra = /^([^.]+)(\.(?:[^.]+))?$/;
  var Va = { qualifierCompare: function(e21, t16) {
    return e21 === t16;
  }, eventMatches: function() {
    return true;
  }, addEventFields: function() {
  }, callbackContext: function(e21) {
    return e21;
  }, beforeEmit: function() {
  }, afterEmit: function() {
  }, bubble: function() {
    return false;
  }, parent: function() {
    return null;
  }, context: null };
  var Fa = Object.keys(Va);
  var qa = {};
  function ja() {
    for (var e21 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : qa, t16 = arguments.length > 1 ? arguments[1] : void 0, n12 = 0; n12 < Fa.length; n12++) {
      var r9 = Fa[n12];
      this[r9] = e21[r9] || Va[r9];
    }
    this.context = t16 || this.context, this.listeners = [], this.emitting = 0;
  }
  var Ya = ja.prototype;
  var Xa = function(e21, t16, n12, r9, a10, i11, o12) {
    B5(r9) && (a10 = r9, r9 = null), o12 && (i11 = null == i11 ? o12 : J4({}, i11, o12));
    for (var s11 = _5(n12) ? n12 : n12.split(/\s+/), l11 = 0; l11 < s11.length; l11++) {
      var u10 = s11[l11];
      if (!F6(u10)) {
        var c10 = u10.match(Ra);
        if (c10) {
          if (false === t16(e21, u10, c10[1], c10[2] ? c10[2] : null, r9, a10, i11))
            break;
        }
      }
    }
  };
  var Wa = function(e21, t16) {
    return e21.addEventFields(e21.context, t16), new La(t16.type, t16);
  };
  var Ha = function(e21, t16, n12) {
    if ("event" !== T6(n12))
      if (N6(n12))
        t16(e21, Wa(e21, n12));
      else
        for (var r9 = _5(n12) ? n12 : n12.split(/\s+/), a10 = 0; a10 < r9.length; a10++) {
          var i11 = r9[a10];
          if (!F6(i11)) {
            var o12 = i11.match(Ra);
            if (o12) {
              var s11 = o12[1], l11 = o12[2] ? o12[2] : null;
              t16(e21, Wa(e21, { type: s11, namespace: l11, target: e21.context }));
            }
          }
        }
    else
      t16(e21, n12);
  };
  Ya.on = Ya.addListener = function(e21, t16, n12, r9, a10) {
    return Xa(this, function(e22, t17, n13, r10, a11, i11, o12) {
      B5(i11) && e22.listeners.push({ event: t17, callback: i11, type: n13, namespace: r10, qualifier: a11, conf: o12 });
    }, e21, t16, n12, r9, a10), this;
  }, Ya.one = function(e21, t16, n12, r9) {
    return this.on(e21, t16, n12, r9, { one: true });
  }, Ya.removeListener = Ya.off = function(e21, t16, n12, r9) {
    var a10 = this;
    0 !== this.emitting && (this.listeners = this.listeners.slice());
    for (var i11 = this.listeners, o12 = function(o13) {
      var s12 = i11[o13];
      Xa(a10, function(t17, n13, r10, a11, l11, u10) {
        if ((s12.type === r10 || "*" === e21) && (!a11 && ".*" !== s12.namespace || s12.namespace === a11) && (!l11 || t17.qualifierCompare(s12.qualifier, l11)) && (!u10 || s12.callback === u10))
          return i11.splice(o13, 1), false;
      }, e21, t16, n12, r9);
    }, s11 = i11.length - 1; s11 >= 0; s11--)
      o12(s11);
    return this;
  }, Ya.removeAllListeners = function() {
    return this.removeListener("*");
  }, Ya.emit = Ya.trigger = function(e21, t16, n12) {
    var r9 = this.listeners, a10 = r9.length;
    return this.emitting++, _5(t16) || (t16 = [t16]), Ha(this, function(e22, i11) {
      null != n12 && (r9 = [{ event: i11.event, type: i11.type, namespace: i11.namespace, callback: n12 }], a10 = r9.length);
      for (var o12 = function(n13) {
        var a11 = r9[n13];
        if (a11.type === i11.type && (!a11.namespace || a11.namespace === i11.namespace || ".*" === a11.namespace) && e22.eventMatches(e22.context, a11, i11)) {
          var o13 = [i11];
          null != t16 && function(e23, t17) {
            for (var n14 = 0; n14 < t17.length; n14++) {
              var r10 = t17[n14];
              e23.push(r10);
            }
          }(o13, t16), e22.beforeEmit(e22.context, a11, i11), a11.conf && a11.conf.one && (e22.listeners = e22.listeners.filter(function(e23) {
            return e23 !== a11;
          }));
          var s12 = e22.callbackContext(e22.context, a11, i11), l11 = a11.callback.apply(s12, o13);
          e22.afterEmit(e22.context, a11, i11), false === l11 && (i11.stopPropagation(), i11.preventDefault());
        }
      }, s11 = 0; s11 < a10; s11++)
        o12(s11);
      e22.bubble(e22.context) && !i11.isPropagationStopped() && e22.parent(e22.context).emit(i11, t16);
    }, e21), this.emitting--, this;
  };
  var Ka = { qualifierCompare: function(e21, t16) {
    return null == e21 || null == t16 ? null == e21 && null == t16 : e21.sameText(t16);
  }, eventMatches: function(e21, t16, n12) {
    var r9 = t16.qualifier;
    return null == r9 || e21 !== n12.target && A6(n12.target) && r9.matches(n12.target);
  }, addEventFields: function(e21, t16) {
    t16.cy = e21.cy(), t16.target = e21;
  }, callbackContext: function(e21, t16, n12) {
    return null != t16.qualifier ? n12.target : e21;
  }, beforeEmit: function(e21, t16) {
    t16.conf && t16.conf.once && t16.conf.onceCollection.removeListener(t16.event, t16.qualifier, t16.callback);
  }, bubble: function() {
    return true;
  }, parent: function(e21) {
    return e21.isChild() ? e21.parent() : e21.cy();
  } };
  var Ga = function(e21) {
    return M6(e21) ? new Kr(e21) : e21;
  };
  var Ua = { createEmitter: function() {
    for (var e21 = 0; e21 < this.length; e21++) {
      var t16 = this[e21], n12 = t16._private;
      n12.emitter || (n12.emitter = new ja(Ka, t16));
    }
    return this;
  }, emitter: function() {
    return this._private.emitter;
  }, on: function(e21, t16, n12) {
    for (var r9 = Ga(t16), a10 = 0; a10 < this.length; a10++) {
      this[a10].emitter().on(e21, r9, n12);
    }
    return this;
  }, removeListener: function(e21, t16, n12) {
    for (var r9 = Ga(t16), a10 = 0; a10 < this.length; a10++) {
      this[a10].emitter().removeListener(e21, r9, n12);
    }
    return this;
  }, removeAllListeners: function() {
    for (var e21 = 0; e21 < this.length; e21++) {
      this[e21].emitter().removeAllListeners();
    }
    return this;
  }, one: function(e21, t16, n12) {
    for (var r9 = Ga(t16), a10 = 0; a10 < this.length; a10++) {
      this[a10].emitter().one(e21, r9, n12);
    }
    return this;
  }, once: function(e21, t16, n12) {
    for (var r9 = Ga(t16), a10 = 0; a10 < this.length; a10++) {
      this[a10].emitter().on(e21, r9, n12, { once: true, onceCollection: this });
    }
  }, emit: function(e21, t16) {
    for (var n12 = 0; n12 < this.length; n12++) {
      this[n12].emitter().emit(e21, t16);
    }
    return this;
  }, emitAndNotify: function(e21, t16) {
    if (0 !== this.length)
      return this.cy().notify(e21, this), this.emit(e21, t16), this;
  } };
  ur3.eventAliasesOn(Ua);
  var Za = { nodes: function(e21) {
    return this.filter(function(e22) {
      return e22.isNode();
    }).filter(e21);
  }, edges: function(e21) {
    return this.filter(function(e22) {
      return e22.isEdge();
    }).filter(e21);
  }, byGroup: function() {
    for (var e21 = this.spawn(), t16 = this.spawn(), n12 = 0; n12 < this.length; n12++) {
      var r9 = this[n12];
      r9.isNode() ? e21.push(r9) : t16.push(r9);
    }
    return { nodes: e21, edges: t16 };
  }, filter: function(e21, t16) {
    if (void 0 === e21)
      return this;
    if (M6(e21) || L5(e21))
      return new Kr(e21).filter(this);
    if (B5(e21)) {
      for (var n12 = this.spawn(), r9 = this, a10 = 0; a10 < r9.length; a10++) {
        var i11 = r9[a10];
        (t16 ? e21.apply(t16, [i11, a10, r9]) : e21(i11, a10, r9)) && n12.push(i11);
      }
      return n12;
    }
    return this.spawn();
  }, not: function(e21) {
    if (e21) {
      M6(e21) && (e21 = this.filter(e21));
      for (var t16 = this.spawn(), n12 = 0; n12 < this.length; n12++) {
        var r9 = this[n12];
        e21.has(r9) || t16.push(r9);
      }
      return t16;
    }
    return this;
  }, absoluteComplement: function() {
    return this.cy().mutableElements().not(this);
  }, intersect: function(e21) {
    if (M6(e21)) {
      var t16 = e21;
      return this.filter(t16);
    }
    for (var n12 = this.spawn(), r9 = e21, a10 = this.length < e21.length, i11 = a10 ? this : r9, o12 = a10 ? r9 : this, s11 = 0; s11 < i11.length; s11++) {
      var l11 = i11[s11];
      o12.has(l11) && n12.push(l11);
    }
    return n12;
  }, xor: function(e21) {
    var t16 = this._private.cy;
    M6(e21) && (e21 = t16.$(e21));
    var n12 = this.spawn(), r9 = e21, a10 = function(e22, t17) {
      for (var r10 = 0; r10 < e22.length; r10++) {
        var a11 = e22[r10], i11 = a11._private.data.id;
        t17.hasElementWithId(i11) || n12.push(a11);
      }
    };
    return a10(this, r9), a10(r9, this), n12;
  }, diff: function(e21) {
    var t16 = this._private.cy;
    M6(e21) && (e21 = t16.$(e21));
    var n12 = this.spawn(), r9 = this.spawn(), a10 = this.spawn(), i11 = e21, o12 = function(e22, t17, n13) {
      for (var r10 = 0; r10 < e22.length; r10++) {
        var i12 = e22[r10], o13 = i12._private.data.id;
        t17.hasElementWithId(o13) ? a10.merge(i12) : n13.push(i12);
      }
    };
    return o12(this, i11, n12), o12(i11, this, r9), { left: n12, right: r9, both: a10 };
  }, add: function(e21) {
    var t16 = this._private.cy;
    if (!e21)
      return this;
    if (M6(e21)) {
      var n12 = e21;
      e21 = t16.mutableElements().filter(n12);
    }
    for (var r9 = this.spawnSelf(), a10 = 0; a10 < e21.length; a10++) {
      var i11 = e21[a10], o12 = !this.has(i11);
      o12 && r9.push(i11);
    }
    return r9;
  }, merge: function(e21) {
    var t16 = this._private, n12 = t16.cy;
    if (!e21)
      return this;
    if (e21 && M6(e21)) {
      var r9 = e21;
      e21 = n12.mutableElements().filter(r9);
    }
    for (var a10 = t16.map, i11 = 0; i11 < e21.length; i11++) {
      var o12 = e21[i11], s11 = o12._private.data.id;
      if (!a10.has(s11)) {
        var l11 = this.length++;
        this[l11] = o12, a10.set(s11, { ele: o12, index: l11 });
      }
    }
    return this;
  }, unmergeAt: function(e21) {
    var t16 = this[e21].id(), n12 = this._private.map;
    this[e21] = void 0, n12.delete(t16);
    var r9 = e21 === this.length - 1;
    if (this.length > 1 && !r9) {
      var a10 = this.length - 1, i11 = this[a10], o12 = i11._private.data.id;
      this[a10] = void 0, this[e21] = i11, n12.set(o12, { ele: i11, index: e21 });
    }
    return this.length--, this;
  }, unmergeOne: function(e21) {
    e21 = e21[0];
    var t16 = this._private, n12 = e21._private.data.id, r9 = t16.map.get(n12);
    if (!r9)
      return this;
    var a10 = r9.index;
    return this.unmergeAt(a10), this;
  }, unmerge: function(e21) {
    var t16 = this._private.cy;
    if (!e21)
      return this;
    if (e21 && M6(e21)) {
      var n12 = e21;
      e21 = t16.mutableElements().filter(n12);
    }
    for (var r9 = 0; r9 < e21.length; r9++)
      this.unmergeOne(e21[r9]);
    return this;
  }, unmergeBy: function(e21) {
    for (var t16 = this.length - 1; t16 >= 0; t16--) {
      e21(this[t16]) && this.unmergeAt(t16);
    }
    return this;
  }, map: function(e21, t16) {
    for (var n12 = [], r9 = this, a10 = 0; a10 < r9.length; a10++) {
      var i11 = r9[a10], o12 = t16 ? e21.apply(t16, [i11, a10, r9]) : e21(i11, a10, r9);
      n12.push(o12);
    }
    return n12;
  }, reduce: function(e21, t16) {
    for (var n12 = t16, r9 = this, a10 = 0; a10 < r9.length; a10++)
      n12 = e21(n12, r9[a10], a10, r9);
    return n12;
  }, max: function(e21, t16) {
    for (var n12, r9 = -1 / 0, a10 = this, i11 = 0; i11 < a10.length; i11++) {
      var o12 = a10[i11], s11 = t16 ? e21.apply(t16, [o12, i11, a10]) : e21(o12, i11, a10);
      s11 > r9 && (r9 = s11, n12 = o12);
    }
    return { value: r9, ele: n12 };
  }, min: function(e21, t16) {
    for (var n12, r9 = 1 / 0, a10 = this, i11 = 0; i11 < a10.length; i11++) {
      var o12 = a10[i11], s11 = t16 ? e21.apply(t16, [o12, i11, a10]) : e21(o12, i11, a10);
      s11 < r9 && (r9 = s11, n12 = o12);
    }
    return { value: r9, ele: n12 };
  } };
  var $a = Za;
  $a.u = $a["|"] = $a["+"] = $a.union = $a.or = $a.add, $a["\\"] = $a["!"] = $a["-"] = $a.difference = $a.relativeComplement = $a.subtract = $a.not, $a.n = $a["&"] = $a["."] = $a.and = $a.intersection = $a.intersect, $a["^"] = $a["(+)"] = $a["(-)"] = $a.symmetricDifference = $a.symdiff = $a.xor, $a.fnFilter = $a.filterFn = $a.stdFilter = $a.filter, $a.complement = $a.abscomp = $a.absoluteComplement;
  var Qa = function(e21, t16) {
    var n12 = e21.cy().hasCompoundNodes();
    function r9(e22) {
      var t17 = e22.pstyle("z-compound-depth");
      return "auto" === t17.value ? n12 ? e22.zDepth() : 0 : "bottom" === t17.value ? -1 : "top" === t17.value ? Ee : 0;
    }
    var a10 = r9(e21) - r9(t16);
    if (0 !== a10)
      return a10;
    function i11(e22) {
      return "auto" === e22.pstyle("z-index-compare").value && e22.isNode() ? 1 : 0;
    }
    var o12 = i11(e21) - i11(t16);
    if (0 !== o12)
      return o12;
    var s11 = e21.pstyle("z-index").value - t16.pstyle("z-index").value;
    return 0 !== s11 ? s11 : e21.poolIndex() - t16.poolIndex();
  };
  var Ja = { forEach: function(e21, t16) {
    if (B5(e21))
      for (var n12 = this.length, r9 = 0; r9 < n12; r9++) {
        var a10 = this[r9];
        if (false === (t16 ? e21.apply(t16, [a10, r9, this]) : e21(a10, r9, this)))
          break;
      }
    return this;
  }, toArray: function() {
    for (var e21 = [], t16 = 0; t16 < this.length; t16++)
      e21.push(this[t16]);
    return e21;
  }, slice: function(e21, t16) {
    var n12 = [], r9 = this.length;
    null == t16 && (t16 = r9), null == e21 && (e21 = 0), e21 < 0 && (e21 = r9 + e21), t16 < 0 && (t16 = r9 + t16);
    for (var a10 = e21; a10 >= 0 && a10 < t16 && a10 < r9; a10++)
      n12.push(this[a10]);
    return this.spawn(n12);
  }, size: function() {
    return this.length;
  }, eq: function(e21) {
    return this[e21] || this.spawn();
  }, first: function() {
    return this[0] || this.spawn();
  }, last: function() {
    return this[this.length - 1] || this.spawn();
  }, empty: function() {
    return 0 === this.length;
  }, nonempty: function() {
    return !this.empty();
  }, sort: function(e21) {
    if (!B5(e21))
      return this;
    var t16 = this.toArray().sort(e21);
    return this.spawn(t16);
  }, sortByZIndex: function() {
    return this.sort(Qa);
  }, zDepth: function() {
    var e21 = this[0];
    if (e21) {
      var t16 = e21._private;
      if ("nodes" === t16.group) {
        var n12 = t16.data.parent ? e21.parents().size() : 0;
        return e21.isParent() ? n12 : Ee - 1;
      }
      var r9 = t16.source, a10 = t16.target, i11 = r9.zDepth(), o12 = a10.zDepth();
      return Math.max(i11, o12, 0);
    }
  } };
  Ja.each = Ja.forEach;
  var ei;
  ei = "undefined", ("undefined" == typeof Symbol ? "undefined" : g6(Symbol)) != ei && g6(Symbol.iterator) != ei && (Ja[Symbol.iterator] = function() {
    var e21 = this, t16 = { value: void 0, done: false }, n12 = 0, r9 = this.length;
    return b6({ next: function() {
      return n12 < r9 ? t16.value = e21[n12++] : (t16.value = void 0, t16.done = true), t16;
    } }, Symbol.iterator, function() {
      return this;
    });
  });
  var ti = ze({ nodeDimensionsIncludeLabels: false });
  var ni = { layoutDimensions: function(e21) {
    var t16;
    if (e21 = ti(e21), this.takesUpSpace())
      if (e21.nodeDimensionsIncludeLabels) {
        var n12 = this.boundingBox();
        t16 = { w: n12.w, h: n12.h };
      } else
        t16 = { w: this.outerWidth(), h: this.outerHeight() };
    else
      t16 = { w: 0, h: 0 };
    return 0 !== t16.w && 0 !== t16.h || (t16.w = t16.h = 1), t16;
  }, layoutPositions: function(e21, t16, n12) {
    var r9 = this.nodes().filter(function(e22) {
      return !e22.isParent();
    }), a10 = this.cy(), i11 = t16.eles, o12 = function(e22) {
      return e22.id();
    }, s11 = j6(n12, o12);
    e21.emit({ type: "layoutstart", layout: e21 }), e21.animations = [];
    var l11 = t16.spacingFactor && 1 !== t16.spacingFactor, u10 = function() {
      if (!l11)
        return null;
      for (var e22 = vt4(), t17 = 0; t17 < r9.length; t17++) {
        var n13 = r9[t17], a11 = s11(n13, t17);
        yt4(e22, a11.x, a11.y);
      }
      return e22;
    }(), c10 = j6(function(e22, n13) {
      var r10 = s11(e22, n13);
      l11 && (r10 = function(e23, t17, n14) {
        var r11 = t17.x1 + t17.w / 2, a11 = t17.y1 + t17.h / 2;
        return { x: r11 + (n14.x - r11) * e23, y: a11 + (n14.y - a11) * e23 };
      }(Math.abs(t16.spacingFactor), u10, r10));
      return null != t16.transform && (r10 = t16.transform(e22, r10)), r10;
    }, o12);
    if (t16.animate) {
      for (var d12 = 0; d12 < r9.length; d12++) {
        var h10 = r9[d12], p10 = c10(h10, d12);
        if (null == t16.animateFilter || t16.animateFilter(h10, d12)) {
          var f11 = h10.animation({ position: p10, duration: t16.animationDuration, easing: t16.animationEasing });
          e21.animations.push(f11);
        } else
          h10.position(p10);
      }
      if (t16.fit) {
        var g9 = a10.animation({ fit: { boundingBox: i11.boundingBoxAt(c10), padding: t16.padding }, duration: t16.animationDuration, easing: t16.animationEasing });
        e21.animations.push(g9);
      } else if (void 0 !== t16.zoom && void 0 !== t16.pan) {
        var v12 = a10.animation({ zoom: t16.zoom, pan: t16.pan, duration: t16.animationDuration, easing: t16.animationEasing });
        e21.animations.push(v12);
      }
      e21.animations.forEach(function(e22) {
        return e22.play();
      }), e21.one("layoutready", t16.ready), e21.emit({ type: "layoutready", layout: e21 }), rr4.all(e21.animations.map(function(e22) {
        return e22.promise();
      })).then(function() {
        e21.one("layoutstop", t16.stop), e21.emit({ type: "layoutstop", layout: e21 });
      });
    } else
      r9.positions(c10), t16.fit && a10.fit(t16.eles, t16.padding), null != t16.zoom && a10.zoom(t16.zoom), t16.pan && a10.pan(t16.pan), e21.one("layoutready", t16.ready), e21.emit({ type: "layoutready", layout: e21 }), e21.one("layoutstop", t16.stop), e21.emit({ type: "layoutstop", layout: e21 });
    return this;
  }, layout: function(e21) {
    return this.cy().makeLayout(J4({}, e21, { eles: this }));
  } };
  function ri(e21, t16, n12) {
    var r9, a10 = n12._private, i11 = a10.styleCache = a10.styleCache || [];
    return null != (r9 = i11[e21]) ? r9 : r9 = i11[e21] = t16(n12);
  }
  function ai(e21, t16) {
    return e21 = ve(e21), function(n12) {
      return ri(e21, t16, n12);
    };
  }
  function ii(e21, t16) {
    e21 = ve(e21);
    var n12 = function(e22) {
      return t16.call(e22);
    };
    return function() {
      var t17 = this[0];
      if (t17)
        return ri(e21, n12, t17);
    };
  }
  ni.createLayout = ni.makeLayout = ni.layout;
  var oi = { recalculateRenderedStyle: function(e21) {
    var t16 = this.cy(), n12 = t16.renderer(), r9 = t16.styleEnabled();
    return n12 && r9 && n12.recalculateRenderedStyle(this, e21), this;
  }, dirtyStyleCache: function() {
    var e21, t16 = this.cy(), n12 = function(e22) {
      return e22._private.styleCache = null;
    };
    t16.hasCompoundNodes() ? ((e21 = this.spawnSelf().merge(this.descendants()).merge(this.parents())).merge(e21.connectedEdges()), e21.forEach(n12)) : this.forEach(function(e22) {
      n12(e22), e22.connectedEdges().forEach(n12);
    });
    return this;
  }, updateStyle: function(e21) {
    var t16 = this._private.cy;
    if (!t16.styleEnabled())
      return this;
    if (t16.batching())
      return t16._private.batchStyleEles.merge(this), this;
    var n12 = this;
    e21 = !(!e21 && void 0 !== e21), t16.hasCompoundNodes() && (n12 = this.spawnSelf().merge(this.descendants()).merge(this.parents()));
    var r9 = n12;
    return e21 ? r9.emitAndNotify("style") : r9.emit("style"), n12.forEach(function(e22) {
      return e22._private.styleDirty = true;
    }), this;
  }, cleanStyle: function() {
    var e21 = this.cy();
    if (e21.styleEnabled())
      for (var t16 = 0; t16 < this.length; t16++) {
        var n12 = this[t16];
        n12._private.styleDirty && (n12._private.styleDirty = false, e21.style().apply(n12));
      }
  }, parsedStyle: function(e21) {
    var t16 = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], n12 = this[0], r9 = n12.cy();
    if (r9.styleEnabled() && n12) {
      this.cleanStyle();
      var a10 = n12._private.style[e21];
      return null != a10 ? a10 : t16 ? r9.style().getDefaultProperty(e21) : null;
    }
  }, numericStyle: function(e21) {
    var t16 = this[0];
    if (t16.cy().styleEnabled() && t16) {
      var n12 = t16.pstyle(e21);
      return void 0 !== n12.pfValue ? n12.pfValue : n12.value;
    }
  }, numericStyleUnits: function(e21) {
    var t16 = this[0];
    if (t16.cy().styleEnabled())
      return t16 ? t16.pstyle(e21).units : void 0;
  }, renderedStyle: function(e21) {
    var t16 = this.cy();
    if (!t16.styleEnabled())
      return this;
    var n12 = this[0];
    return n12 ? t16.style().getRenderedStyle(n12, e21) : void 0;
  }, style: function(e21, t16) {
    var n12 = this.cy();
    if (!n12.styleEnabled())
      return this;
    var r9 = false, a10 = n12.style();
    if (N6(e21)) {
      var i11 = e21;
      a10.applyBypass(this, i11, r9), this.emitAndNotify("style");
    } else if (M6(e21)) {
      if (void 0 === t16) {
        var o12 = this[0];
        return o12 ? a10.getStylePropertyValue(o12, e21) : void 0;
      }
      a10.applyBypass(this, e21, t16, r9), this.emitAndNotify("style");
    } else if (void 0 === e21) {
      var s11 = this[0];
      return s11 ? a10.getRawStyle(s11) : void 0;
    }
    return this;
  }, removeStyle: function(e21) {
    var t16 = this.cy();
    if (!t16.styleEnabled())
      return this;
    var n12 = false, r9 = t16.style(), a10 = this;
    if (void 0 === e21)
      for (var i11 = 0; i11 < a10.length; i11++) {
        var o12 = a10[i11];
        r9.removeAllBypasses(o12, n12);
      }
    else {
      e21 = e21.split(/\s+/);
      for (var s11 = 0; s11 < a10.length; s11++) {
        var l11 = a10[s11];
        r9.removeBypasses(l11, e21, n12);
      }
    }
    return this.emitAndNotify("style"), this;
  }, show: function() {
    return this.css("display", "element"), this;
  }, hide: function() {
    return this.css("display", "none"), this;
  }, effectiveOpacity: function() {
    var e21 = this.cy();
    if (!e21.styleEnabled())
      return 1;
    var t16 = e21.hasCompoundNodes(), n12 = this[0];
    if (n12) {
      var r9 = n12._private, a10 = n12.pstyle("opacity").value;
      if (!t16)
        return a10;
      var i11 = r9.data.parent ? n12.parents() : null;
      if (i11)
        for (var o12 = 0; o12 < i11.length; o12++) {
          a10 *= i11[o12].pstyle("opacity").value;
        }
      return a10;
    }
  }, transparent: function() {
    if (!this.cy().styleEnabled())
      return false;
    var e21 = this[0], t16 = e21.cy().hasCompoundNodes();
    return e21 ? t16 ? 0 === e21.effectiveOpacity() : 0 === e21.pstyle("opacity").value : void 0;
  }, backgrounding: function() {
    return !!this.cy().styleEnabled() && !!this[0]._private.backgrounding;
  } };
  function si(e21, t16) {
    var n12 = e21._private.data.parent ? e21.parents() : null;
    if (n12)
      for (var r9 = 0; r9 < n12.length; r9++) {
        if (!t16(n12[r9]))
          return false;
      }
    return true;
  }
  function li(e21) {
    var t16 = e21.ok, n12 = e21.edgeOkViaNode || e21.ok, r9 = e21.parentOk || e21.ok;
    return function() {
      var e22 = this.cy();
      if (!e22.styleEnabled())
        return true;
      var a10 = this[0], i11 = e22.hasCompoundNodes();
      if (a10) {
        var o12 = a10._private;
        if (!t16(a10))
          return false;
        if (a10.isNode())
          return !i11 || si(a10, r9);
        var s11 = o12.source, l11 = o12.target;
        return n12(s11) && (!i11 || si(s11, n12)) && (s11 === l11 || n12(l11) && (!i11 || si(l11, n12)));
      }
    };
  }
  var ui = ai("eleTakesUpSpace", function(e21) {
    return "element" === e21.pstyle("display").value && 0 !== e21.width() && (!e21.isNode() || 0 !== e21.height());
  });
  oi.takesUpSpace = ii("takesUpSpace", li({ ok: ui }));
  var ci = ai("eleInteractive", function(e21) {
    return "yes" === e21.pstyle("events").value && "visible" === e21.pstyle("visibility").value && ui(e21);
  });
  var di = ai("parentInteractive", function(e21) {
    return "visible" === e21.pstyle("visibility").value && ui(e21);
  });
  oi.interactive = ii("interactive", li({ ok: ci, parentOk: di, edgeOkViaNode: ui })), oi.noninteractive = function() {
    var e21 = this[0];
    if (e21)
      return !e21.interactive();
  };
  var hi = ai("eleVisible", function(e21) {
    return "visible" === e21.pstyle("visibility").value && 0 !== e21.pstyle("opacity").pfValue && ui(e21);
  });
  var pi = ui;
  oi.visible = ii("visible", li({ ok: hi, edgeOkViaNode: pi })), oi.hidden = function() {
    var e21 = this[0];
    if (e21)
      return !e21.visible();
  }, oi.isBundledBezier = ii("isBundledBezier", function() {
    return !!this.cy().styleEnabled() && (!this.removed() && "bezier" === this.pstyle("curve-style").value && this.takesUpSpace());
  }), oi.bypass = oi.css = oi.style, oi.renderedCss = oi.renderedStyle, oi.removeBypass = oi.removeCss = oi.removeStyle, oi.pstyle = oi.parsedStyle;
  var fi = {};
  function gi(e21) {
    return function() {
      var t16 = arguments, n12 = [];
      if (2 === t16.length) {
        var r9 = t16[0], a10 = t16[1];
        this.on(e21.event, r9, a10);
      } else if (1 === t16.length && B5(t16[0])) {
        var i11 = t16[0];
        this.on(e21.event, i11);
      } else if (0 === t16.length || 1 === t16.length && _5(t16[0])) {
        for (var o12 = 1 === t16.length ? t16[0] : null, s11 = 0; s11 < this.length; s11++) {
          var l11 = this[s11], u10 = !e21.ableField || l11._private[e21.ableField], c10 = l11._private[e21.field] != e21.value;
          if (e21.overrideAble) {
            var d12 = e21.overrideAble(l11);
            if (void 0 !== d12 && (u10 = d12, !d12))
              return this;
          }
          u10 && (l11._private[e21.field] = e21.value, c10 && n12.push(l11));
        }
        var h10 = this.spawn(n12);
        h10.updateStyle(), h10.emit(e21.event), o12 && h10.emit(o12);
      }
      return this;
    };
  }
  function vi(e21) {
    fi[e21.field] = function() {
      var t16 = this[0];
      if (t16) {
        if (e21.overrideField) {
          var n12 = e21.overrideField(t16);
          if (void 0 !== n12)
            return n12;
        }
        return t16._private[e21.field];
      }
    }, fi[e21.on] = gi({ event: e21.on, field: e21.field, ableField: e21.ableField, overrideAble: e21.overrideAble, value: true }), fi[e21.off] = gi({ event: e21.off, field: e21.field, ableField: e21.ableField, overrideAble: e21.overrideAble, value: false });
  }
  vi({ field: "locked", overrideField: function(e21) {
    return !!e21.cy().autolock() || void 0;
  }, on: "lock", off: "unlock" }), vi({ field: "grabbable", overrideField: function(e21) {
    return !e21.cy().autoungrabify() && !e21.pannable() && void 0;
  }, on: "grabify", off: "ungrabify" }), vi({ field: "selected", ableField: "selectable", overrideAble: function(e21) {
    return !e21.cy().autounselectify() && void 0;
  }, on: "select", off: "unselect" }), vi({ field: "selectable", overrideField: function(e21) {
    return !e21.cy().autounselectify() && void 0;
  }, on: "selectify", off: "unselectify" }), fi.deselect = fi.unselect, fi.grabbed = function() {
    var e21 = this[0];
    if (e21)
      return e21._private.grabbed;
  }, vi({ field: "active", on: "activate", off: "unactivate" }), vi({ field: "pannable", on: "panify", off: "unpanify" }), fi.inactive = function() {
    var e21 = this[0];
    if (e21)
      return !e21._private.active;
  };
  var yi = {};
  var mi = function(e21) {
    return function(t16) {
      for (var n12 = [], r9 = 0; r9 < this.length; r9++) {
        var a10 = this[r9];
        if (a10.isNode()) {
          for (var i11 = false, o12 = a10.connectedEdges(), s11 = 0; s11 < o12.length; s11++) {
            var l11 = o12[s11], u10 = l11.source(), c10 = l11.target();
            if (e21.noIncomingEdges && c10 === a10 && u10 !== a10 || e21.noOutgoingEdges && u10 === a10 && c10 !== a10) {
              i11 = true;
              break;
            }
          }
          i11 || n12.push(a10);
        }
      }
      return this.spawn(n12, true).filter(t16);
    };
  };
  var bi = function(e21) {
    return function(t16) {
      for (var n12 = [], r9 = 0; r9 < this.length; r9++) {
        var a10 = this[r9];
        if (a10.isNode())
          for (var i11 = a10.connectedEdges(), o12 = 0; o12 < i11.length; o12++) {
            var s11 = i11[o12], l11 = s11.source(), u10 = s11.target();
            e21.outgoing && l11 === a10 ? (n12.push(s11), n12.push(u10)) : e21.incoming && u10 === a10 && (n12.push(s11), n12.push(l11));
          }
      }
      return this.spawn(n12, true).filter(t16);
    };
  };
  var xi = function(e21) {
    return function(t16) {
      for (var n12 = this, r9 = [], a10 = {}; ; ) {
        var i11 = e21.outgoing ? n12.outgoers() : n12.incomers();
        if (0 === i11.length)
          break;
        for (var o12 = false, s11 = 0; s11 < i11.length; s11++) {
          var l11 = i11[s11], u10 = l11.id();
          a10[u10] || (a10[u10] = true, r9.push(l11), o12 = true);
        }
        if (!o12)
          break;
        n12 = i11;
      }
      return this.spawn(r9, true).filter(t16);
    };
  };
  function wi(e21) {
    return function(t16) {
      for (var n12 = [], r9 = 0; r9 < this.length; r9++) {
        var a10 = this[r9]._private[e21.attr];
        a10 && n12.push(a10);
      }
      return this.spawn(n12, true).filter(t16);
    };
  }
  function Ei(e21) {
    return function(t16) {
      var n12 = [], r9 = this._private.cy, a10 = e21 || {};
      M6(t16) && (t16 = r9.$(t16));
      for (var i11 = 0; i11 < t16.length; i11++)
        for (var o12 = t16[i11]._private.edges, s11 = 0; s11 < o12.length; s11++) {
          var l11 = o12[s11], u10 = l11._private.data, c10 = this.hasElementWithId(u10.source) && t16.hasElementWithId(u10.target), d12 = t16.hasElementWithId(u10.source) && this.hasElementWithId(u10.target);
          if (c10 || d12) {
            if (a10.thisIsSrc || a10.thisIsTgt) {
              if (a10.thisIsSrc && !c10)
                continue;
              if (a10.thisIsTgt && !d12)
                continue;
            }
            n12.push(l11);
          }
        }
      return this.spawn(n12, true);
    };
  }
  function ki(e21) {
    return e21 = J4({}, { codirected: false }, e21), function(t16) {
      for (var n12 = [], r9 = this.edges(), a10 = e21, i11 = 0; i11 < r9.length; i11++)
        for (var o12 = r9[i11]._private, s11 = o12.source, l11 = s11._private.data.id, u10 = o12.data.target, c10 = s11._private.edges, d12 = 0; d12 < c10.length; d12++) {
          var h10 = c10[d12], p10 = h10._private.data, f11 = p10.target, g9 = p10.source, v12 = f11 === u10 && g9 === l11, y10 = l11 === f11 && u10 === g9;
          (a10.codirected && v12 || !a10.codirected && (v12 || y10)) && n12.push(h10);
        }
      return this.spawn(n12, true).filter(t16);
    };
  }
  yi.clearTraversalCache = function() {
    for (var e21 = 0; e21 < this.length; e21++)
      this[e21]._private.traversalCache = null;
  }, J4(yi, { roots: mi({ noIncomingEdges: true }), leaves: mi({ noOutgoingEdges: true }), outgoers: Qr(bi({ outgoing: true }), "outgoers"), successors: xi({ outgoing: true }), incomers: Qr(bi({ incoming: true }), "incomers"), predecessors: xi({ incoming: true }) }), J4(yi, { neighborhood: Qr(function(e21) {
    for (var t16 = [], n12 = this.nodes(), r9 = 0; r9 < n12.length; r9++)
      for (var a10 = n12[r9], i11 = a10.connectedEdges(), o12 = 0; o12 < i11.length; o12++) {
        var s11 = i11[o12], l11 = s11.source(), u10 = s11.target(), c10 = a10 === l11 ? u10 : l11;
        c10.length > 0 && t16.push(c10[0]), t16.push(s11[0]);
      }
    return this.spawn(t16, true).filter(e21);
  }, "neighborhood"), closedNeighborhood: function(e21) {
    return this.neighborhood().add(this).filter(e21);
  }, openNeighborhood: function(e21) {
    return this.neighborhood(e21);
  } }), yi.neighbourhood = yi.neighborhood, yi.closedNeighbourhood = yi.closedNeighborhood, yi.openNeighbourhood = yi.openNeighborhood, J4(yi, { source: Qr(function(e21) {
    var t16, n12 = this[0];
    return n12 && (t16 = n12._private.source || n12.cy().collection()), t16 && e21 ? t16.filter(e21) : t16;
  }, "source"), target: Qr(function(e21) {
    var t16, n12 = this[0];
    return n12 && (t16 = n12._private.target || n12.cy().collection()), t16 && e21 ? t16.filter(e21) : t16;
  }, "target"), sources: wi({ attr: "source" }), targets: wi({ attr: "target" }) }), J4(yi, { edgesWith: Qr(Ei(), "edgesWith"), edgesTo: Qr(Ei({ thisIsSrc: true }), "edgesTo") }), J4(yi, { connectedEdges: Qr(function(e21) {
    for (var t16 = [], n12 = 0; n12 < this.length; n12++) {
      var r9 = this[n12];
      if (r9.isNode())
        for (var a10 = r9._private.edges, i11 = 0; i11 < a10.length; i11++) {
          var o12 = a10[i11];
          t16.push(o12);
        }
    }
    return this.spawn(t16, true).filter(e21);
  }, "connectedEdges"), connectedNodes: Qr(function(e21) {
    for (var t16 = [], n12 = 0; n12 < this.length; n12++) {
      var r9 = this[n12];
      r9.isEdge() && (t16.push(r9.source()[0]), t16.push(r9.target()[0]));
    }
    return this.spawn(t16, true).filter(e21);
  }, "connectedNodes"), parallelEdges: Qr(ki(), "parallelEdges"), codirectedEdges: Qr(ki({ codirected: true }), "codirectedEdges") }), J4(yi, { components: function(e21) {
    var t16 = this, n12 = t16.cy(), r9 = n12.collection(), a10 = null == e21 ? t16.nodes() : e21.nodes(), i11 = [];
    null != e21 && a10.empty() && (a10 = e21.sources());
    var o12 = function(e22, t17) {
      r9.merge(e22), a10.unmerge(e22), t17.merge(e22);
    };
    if (a10.empty())
      return t16.spawn();
    var s11 = function() {
      var e22 = n12.collection();
      i11.push(e22);
      var r10 = a10[0];
      o12(r10, e22), t16.bfs({ directed: false, roots: r10, visit: function(t17) {
        return o12(t17, e22);
      } }), e22.forEach(function(n13) {
        n13.connectedEdges().forEach(function(n14) {
          t16.has(n14) && e22.has(n14.source()) && e22.has(n14.target()) && e22.merge(n14);
        });
      });
    };
    do {
      s11();
    } while (a10.length > 0);
    return i11;
  }, component: function() {
    var e21 = this[0];
    return e21.cy().mutableElements().components(e21)[0];
  } }), yi.componentsOf = yi.components;
  var Ci = function(e21, t16) {
    var n12 = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], r9 = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
    if (void 0 !== e21) {
      var a10 = new Ve(), i11 = false;
      if (t16) {
        if (t16.length > 0 && N6(t16[0]) && !A6(t16[0])) {
          i11 = true;
          for (var o12 = [], s11 = new qe(), l11 = 0, u10 = t16.length; l11 < u10; l11++) {
            var c10 = t16[l11];
            null == c10.data && (c10.data = {});
            var d12 = c10.data;
            if (null == d12.id)
              d12.id = _e();
            else if (e21.hasElementWithId(d12.id) || s11.has(d12.id))
              continue;
            var h10 = new je(e21, c10, false);
            o12.push(h10), s11.add(d12.id);
          }
          t16 = o12;
        }
      } else
        t16 = [];
      this.length = 0;
      for (var p10 = 0, f11 = t16.length; p10 < f11; p10++) {
        var g9 = t16[p10][0];
        if (null != g9) {
          var v12 = g9._private.data.id;
          n12 && a10.has(v12) || (n12 && a10.set(v12, { index: this.length, ele: g9 }), this[this.length] = g9, this.length++);
        }
      }
      this._private = { eles: this, cy: e21, get map() {
        return null == this.lazyMap && this.rebuildMap(), this.lazyMap;
      }, set map(e22) {
        this.lazyMap = e22;
      }, rebuildMap: function() {
        for (var e22 = this.lazyMap = new Ve(), t17 = this.eles, n13 = 0; n13 < t17.length; n13++) {
          var r10 = t17[n13];
          e22.set(r10.id(), { index: n13, ele: r10 });
        }
      } }, n12 && (this._private.map = a10), i11 && !r9 && this.restore();
    } else
      Pe("A collection must have a reference to the core");
  };
  var Si = je.prototype = Ci.prototype = Object.create(Array.prototype);
  Si.instanceString = function() {
    return "collection";
  }, Si.spawn = function(e21, t16) {
    return new Ci(this.cy(), e21, t16);
  }, Si.spawnSelf = function() {
    return this.spawn(this);
  }, Si.cy = function() {
    return this._private.cy;
  }, Si.renderer = function() {
    return this._private.cy.renderer();
  }, Si.element = function() {
    return this[0];
  }, Si.collection = function() {
    return O6(this) ? this : new Ci(this._private.cy, [this]);
  }, Si.unique = function() {
    return new Ci(this._private.cy, this, true);
  }, Si.hasElementWithId = function(e21) {
    return e21 = "" + e21, this._private.map.has(e21);
  }, Si.getElementById = function(e21) {
    e21 = "" + e21;
    var t16 = this._private.cy, n12 = this._private.map.get(e21);
    return n12 ? n12.ele : new Ci(t16);
  }, Si.$id = Si.getElementById, Si.poolIndex = function() {
    var e21 = this._private.cy._private.elements, t16 = this[0]._private.data.id;
    return e21._private.map.get(t16).index;
  }, Si.indexOf = function(e21) {
    var t16 = e21[0]._private.data.id;
    return this._private.map.get(t16).index;
  }, Si.indexOfId = function(e21) {
    return e21 = "" + e21, this._private.map.get(e21).index;
  }, Si.json = function(e21) {
    var t16 = this.element(), n12 = this.cy();
    if (null == t16 && e21)
      return this;
    if (null != t16) {
      var r9 = t16._private;
      if (N6(e21)) {
        if (n12.startBatch(), e21.data) {
          t16.data(e21.data);
          var a10 = r9.data;
          if (t16.isEdge()) {
            var i11 = false, o12 = {}, s11 = e21.data.source, l11 = e21.data.target;
            null != s11 && s11 != a10.source && (o12.source = "" + s11, i11 = true), null != l11 && l11 != a10.target && (o12.target = "" + l11, i11 = true), i11 && (t16 = t16.move(o12));
          } else {
            var u10 = "parent" in e21.data, c10 = e21.data.parent;
            !u10 || null == c10 && null == a10.parent || c10 == a10.parent || (void 0 === c10 && (c10 = null), null != c10 && (c10 = "" + c10), t16 = t16.move({ parent: c10 }));
          }
        }
        e21.position && t16.position(e21.position);
        var d12 = function(n13, a11, i12) {
          var o13 = e21[n13];
          null != o13 && o13 !== r9[n13] && (o13 ? t16[a11]() : t16[i12]());
        };
        return d12("removed", "remove", "restore"), d12("selected", "select", "unselect"), d12("selectable", "selectify", "unselectify"), d12("locked", "lock", "unlock"), d12("grabbable", "grabify", "ungrabify"), d12("pannable", "panify", "unpanify"), null != e21.classes && t16.classes(e21.classes), n12.endBatch(), this;
      }
      if (void 0 === e21) {
        var h10 = { data: Be(r9.data), position: Be(r9.position), group: r9.group, removed: r9.removed, selected: r9.selected, selectable: r9.selectable, locked: r9.locked, grabbable: r9.grabbable, pannable: r9.pannable, classes: null };
        h10.classes = "";
        var p10 = 0;
        return r9.classes.forEach(function(e22) {
          return h10.classes += 0 == p10++ ? e22 : " " + e22;
        }), h10;
      }
    }
  }, Si.jsons = function() {
    for (var e21 = [], t16 = 0; t16 < this.length; t16++) {
      var n12 = this[t16].json();
      e21.push(n12);
    }
    return e21;
  }, Si.clone = function() {
    for (var e21 = this.cy(), t16 = [], n12 = 0; n12 < this.length; n12++) {
      var r9 = this[n12].json(), a10 = new je(e21, r9, false);
      t16.push(a10);
    }
    return new Ci(e21, t16);
  }, Si.copy = Si.clone, Si.restore = function() {
    for (var e21, t16, n12 = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], r9 = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], a10 = this, i11 = a10.cy(), o12 = i11._private, s11 = [], l11 = [], u10 = 0, c10 = a10.length; u10 < c10; u10++) {
      var d12 = a10[u10];
      r9 && !d12.removed() || (d12.isNode() ? s11.push(d12) : l11.push(d12));
    }
    e21 = s11.concat(l11);
    var h10 = function() {
      e21.splice(t16, 1), t16--;
    };
    for (t16 = 0; t16 < e21.length; t16++) {
      var p10 = e21[t16], f11 = p10._private, g9 = f11.data;
      if (p10.clearTraversalCache(), r9 || f11.removed)
        if (void 0 === g9.id)
          g9.id = _e();
        else if (I6(g9.id))
          g9.id = "" + g9.id;
        else {
          if (F6(g9.id) || !M6(g9.id)) {
            Pe("Can not create element with invalid string ID `" + g9.id + "`"), h10();
            continue;
          }
          if (i11.hasElementWithId(g9.id)) {
            Pe("Can not create second element with ID `" + g9.id + "`"), h10();
            continue;
          }
        }
      else
        ;
      var v12 = g9.id;
      if (p10.isNode()) {
        var y10 = f11.position;
        null == y10.x && (y10.x = 0), null == y10.y && (y10.y = 0);
      }
      if (p10.isEdge()) {
        for (var m12 = p10, b11 = ["source", "target"], x10 = b11.length, w11 = false, E9 = 0; E9 < x10; E9++) {
          var k10 = b11[E9], C9 = g9[k10];
          I6(C9) && (C9 = g9[k10] = "" + g9[k10]), null == C9 || "" === C9 ? (Pe("Can not create edge `" + v12 + "` with unspecified " + k10), w11 = true) : i11.hasElementWithId(C9) || (Pe("Can not create edge `" + v12 + "` with nonexistant " + k10 + " `" + C9 + "`"), w11 = true);
        }
        if (w11) {
          h10();
          continue;
        }
        var S8 = i11.getElementById(g9.source), D9 = i11.getElementById(g9.target);
        S8.same(D9) ? S8._private.edges.push(m12) : (S8._private.edges.push(m12), D9._private.edges.push(m12)), m12._private.source = S8, m12._private.target = D9;
      }
      f11.map = new Ve(), f11.map.set(v12, { ele: p10, index: 0 }), f11.removed = false, r9 && i11.addToPool(p10);
    }
    for (var P10 = 0; P10 < s11.length; P10++) {
      var T9 = s11[P10], B9 = T9._private.data;
      I6(B9.parent) && (B9.parent = "" + B9.parent);
      var _7 = B9.parent;
      if (null != _7 || T9._private.parent) {
        var N8 = T9._private.parent ? i11.collection().merge(T9._private.parent) : i11.getElementById(_7);
        if (N8.empty())
          B9.parent = void 0;
        else if (N8[0].removed())
          Me("Node added with missing parent, reference to parent removed"), B9.parent = void 0, T9._private.parent = null;
        else {
          for (var z8 = false, L9 = N8; !L9.empty(); ) {
            if (T9.same(L9)) {
              z8 = true, B9.parent = void 0;
              break;
            }
            L9 = L9.parent();
          }
          z8 || (N8[0]._private.children.push(T9), T9._private.parent = N8[0], o12.hasCompoundNodes = true);
        }
      }
    }
    if (e21.length > 0) {
      for (var A10 = e21.length === a10.length ? a10 : new Ci(i11, e21), O10 = 0; O10 < A10.length; O10++) {
        var R8 = A10[O10];
        R8.isNode() || (R8.parallelEdges().clearTraversalCache(), R8.source().clearTraversalCache(), R8.target().clearTraversalCache());
      }
      (o12.hasCompoundNodes ? i11.collection().merge(A10).merge(A10.connectedNodes()).merge(A10.parent()) : A10).dirtyCompoundBoundsCache().dirtyBoundingBoxCache().updateStyle(n12), n12 ? A10.emitAndNotify("add") : r9 && A10.emit("add");
    }
    return a10;
  }, Si.removed = function() {
    var e21 = this[0];
    return e21 && e21._private.removed;
  }, Si.inside = function() {
    var e21 = this[0];
    return e21 && !e21._private.removed;
  }, Si.remove = function() {
    var e21 = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], t16 = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], n12 = this, r9 = [], a10 = {}, i11 = n12._private.cy;
    function o12(e22) {
      var n13 = a10[e22.id()];
      t16 && e22.removed() || n13 || (a10[e22.id()] = true, e22.isNode() ? (r9.push(e22), function(e23) {
        for (var t17 = e23._private.edges, n14 = 0; n14 < t17.length; n14++)
          o12(t17[n14]);
      }(e22), function(e23) {
        for (var t17 = e23._private.children, n14 = 0; n14 < t17.length; n14++)
          o12(t17[n14]);
      }(e22)) : r9.unshift(e22));
    }
    for (var s11 = 0, l11 = n12.length; s11 < l11; s11++) {
      o12(n12[s11]);
    }
    function u10(e22, t17) {
      var n13 = e22._private.edges;
      Le(n13, t17), e22.clearTraversalCache();
    }
    function c10(e22) {
      e22.clearTraversalCache();
    }
    var d12 = [];
    function h10(e22, t17) {
      t17 = t17[0];
      var n13 = (e22 = e22[0])._private.children, r10 = e22.id();
      Le(n13, t17), t17._private.parent = null, d12.ids[r10] || (d12.ids[r10] = true, d12.push(e22));
    }
    d12.ids = {}, n12.dirtyCompoundBoundsCache(), t16 && i11.removeFromPool(r9);
    for (var p10 = 0; p10 < r9.length; p10++) {
      var f11 = r9[p10];
      if (f11.isEdge()) {
        var g9 = f11.source()[0], v12 = f11.target()[0];
        u10(g9, f11), u10(v12, f11);
        for (var y10 = f11.parallelEdges(), m12 = 0; m12 < y10.length; m12++) {
          var b11 = y10[m12];
          c10(b11), b11.isBundledBezier() && b11.dirtyBoundingBoxCache();
        }
      } else {
        var x10 = f11.parent();
        0 !== x10.length && h10(x10, f11);
      }
      t16 && (f11._private.removed = true);
    }
    var w11 = i11._private.elements;
    i11._private.hasCompoundNodes = false;
    for (var E9 = 0; E9 < w11.length; E9++) {
      if (w11[E9].isParent()) {
        i11._private.hasCompoundNodes = true;
        break;
      }
    }
    var k10 = new Ci(this.cy(), r9);
    k10.size() > 0 && (e21 ? k10.emitAndNotify("remove") : t16 && k10.emit("remove"));
    for (var C9 = 0; C9 < d12.length; C9++) {
      var S8 = d12[C9];
      t16 && S8.removed() || S8.updateStyle();
    }
    return k10;
  }, Si.move = function(e21) {
    var t16 = this._private.cy, n12 = this, r9 = false, a10 = false, i11 = function(e22) {
      return null == e22 ? e22 : "" + e22;
    };
    if (void 0 !== e21.source || void 0 !== e21.target) {
      var o12 = i11(e21.source), s11 = i11(e21.target), l11 = null != o12 && t16.hasElementWithId(o12), u10 = null != s11 && t16.hasElementWithId(s11);
      (l11 || u10) && (t16.batch(function() {
        n12.remove(r9, a10), n12.emitAndNotify("moveout");
        for (var e22 = 0; e22 < n12.length; e22++) {
          var t17 = n12[e22], i12 = t17._private.data;
          t17.isEdge() && (l11 && (i12.source = o12), u10 && (i12.target = s11));
        }
        n12.restore(r9, a10);
      }), n12.emitAndNotify("move"));
    } else if (void 0 !== e21.parent) {
      var c10 = i11(e21.parent);
      if (null === c10 || t16.hasElementWithId(c10)) {
        var d12 = null === c10 ? void 0 : c10;
        t16.batch(function() {
          var e22 = n12.remove(r9, a10);
          e22.emitAndNotify("moveout");
          for (var t17 = 0; t17 < n12.length; t17++) {
            var i12 = n12[t17], o13 = i12._private.data;
            i12.isNode() && (o13.parent = d12);
          }
          e22.restore(r9, a10);
        }), n12.emitAndNotify("move");
      }
    }
    return this;
  }, [Zn, cr3, dr2, Ur, Jr, oa, sa, za, Ua, Za, { isNode: function() {
    return "nodes" === this.group();
  }, isEdge: function() {
    return "edges" === this.group();
  }, isLoop: function() {
    return this.isEdge() && this.source()[0] === this.target()[0];
  }, isSimple: function() {
    return this.isEdge() && this.source()[0] !== this.target()[0];
  }, group: function() {
    var e21 = this[0];
    if (e21)
      return e21._private.group;
  } }, Ja, ni, oi, fi, yi].forEach(function(e21) {
    J4(Si, e21);
  });
  var Di = { add: function(e21) {
    var t16, n12 = this;
    if (L5(e21)) {
      var r9 = e21;
      if (r9._private.cy === n12)
        t16 = r9.restore();
      else {
        for (var a10 = [], i11 = 0; i11 < r9.length; i11++) {
          var o12 = r9[i11];
          a10.push(o12.json());
        }
        t16 = new Ci(n12, a10);
      }
    } else if (_5(e21)) {
      t16 = new Ci(n12, e21);
    } else if (N6(e21) && (_5(e21.nodes) || _5(e21.edges))) {
      for (var s11 = e21, l11 = [], u10 = ["nodes", "edges"], c10 = 0, d12 = u10.length; c10 < d12; c10++) {
        var h10 = u10[c10], p10 = s11[h10];
        if (_5(p10))
          for (var f11 = 0, g9 = p10.length; f11 < g9; f11++) {
            var v12 = J4({ group: h10 }, p10[f11]);
            l11.push(v12);
          }
      }
      t16 = new Ci(n12, l11);
    } else {
      t16 = new je(n12, e21).collection();
    }
    return t16;
  }, remove: function(e21) {
    if (L5(e21))
      ;
    else if (M6(e21)) {
      var t16 = e21;
      e21 = this.$(t16);
    }
    return e21.remove();
  } };
  function Pi(e21, t16, n12, r9) {
    var a10 = 0.1, i11 = "undefined" != typeof Float32Array;
    if (4 !== arguments.length)
      return false;
    for (var o12 = 0; o12 < 4; ++o12)
      if ("number" != typeof arguments[o12] || isNaN(arguments[o12]) || !isFinite(arguments[o12]))
        return false;
    e21 = Math.min(e21, 1), n12 = Math.min(n12, 1), e21 = Math.max(e21, 0), n12 = Math.max(n12, 0);
    var s11 = i11 ? new Float32Array(11) : new Array(11);
    function l11(e22, t17) {
      return 1 - 3 * t17 + 3 * e22;
    }
    function u10(e22, t17) {
      return 3 * t17 - 6 * e22;
    }
    function c10(e22) {
      return 3 * e22;
    }
    function d12(e22, t17, n13) {
      return ((l11(t17, n13) * e22 + u10(t17, n13)) * e22 + c10(t17)) * e22;
    }
    function h10(e22, t17, n13) {
      return 3 * l11(t17, n13) * e22 * e22 + 2 * u10(t17, n13) * e22 + c10(t17);
    }
    function p10(t17) {
      for (var r10 = 0, i12 = 1; 10 !== i12 && s11[i12] <= t17; ++i12)
        r10 += a10;
      --i12;
      var o13 = r10 + (t17 - s11[i12]) / (s11[i12 + 1] - s11[i12]) * a10, l12 = h10(o13, e21, n12);
      return l12 >= 1e-3 ? function(t18, r11) {
        for (var a11 = 0; a11 < 4; ++a11) {
          var i13 = h10(r11, e21, n12);
          if (0 === i13)
            return r11;
          r11 -= (d12(r11, e21, n12) - t18) / i13;
        }
        return r11;
      }(t17, o13) : 0 === l12 ? o13 : function(t18, r11, a11) {
        var i13, o14, s12 = 0;
        do {
          (i13 = d12(o14 = r11 + (a11 - r11) / 2, e21, n12) - t18) > 0 ? a11 = o14 : r11 = o14;
        } while (Math.abs(i13) > 1e-7 && ++s12 < 10);
        return o14;
      }(t17, r10, r10 + a10);
    }
    var f11 = false;
    function g9() {
      f11 = true, e21 === t16 && n12 === r9 || function() {
        for (var t17 = 0; t17 < 11; ++t17)
          s11[t17] = d12(t17 * a10, e21, n12);
      }();
    }
    var v12 = function(a11) {
      return f11 || g9(), e21 === t16 && n12 === r9 ? a11 : 0 === a11 ? 0 : 1 === a11 ? 1 : d12(p10(a11), t16, r9);
    };
    v12.getControlPoints = function() {
      return [{ x: e21, y: t16 }, { x: n12, y: r9 }];
    };
    var y10 = "generateBezier(" + [e21, t16, n12, r9] + ")";
    return v12.toString = function() {
      return y10;
    }, v12;
  }
  var Ti = function() {
    function e21(e22) {
      return -e22.tension * e22.x - e22.friction * e22.v;
    }
    function t16(t17, n13, r9) {
      var a10 = { x: t17.x + r9.dx * n13, v: t17.v + r9.dv * n13, tension: t17.tension, friction: t17.friction };
      return { dx: a10.v, dv: e21(a10) };
    }
    function n12(n13, r9) {
      var a10 = { dx: n13.v, dv: e21(n13) }, i11 = t16(n13, 0.5 * r9, a10), o12 = t16(n13, 0.5 * r9, i11), s11 = t16(n13, r9, o12), l11 = 1 / 6 * (a10.dx + 2 * (i11.dx + o12.dx) + s11.dx), u10 = 1 / 6 * (a10.dv + 2 * (i11.dv + o12.dv) + s11.dv);
      return n13.x = n13.x + l11 * r9, n13.v = n13.v + u10 * r9, n13;
    }
    return function e22(t17, r9, a10) {
      var i11, o12, s11, l11 = { x: -1, v: 0, tension: null, friction: null }, u10 = [0], c10 = 0, d12 = 1e-4;
      for (t17 = parseFloat(t17) || 500, r9 = parseFloat(r9) || 20, a10 = a10 || null, l11.tension = t17, l11.friction = r9, o12 = (i11 = null !== a10) ? (c10 = e22(t17, r9)) / a10 * 0.016 : 0.016; s11 = n12(s11 || l11, o12), u10.push(1 + s11.x), c10 += 16, Math.abs(s11.x) > d12 && Math.abs(s11.v) > d12; )
        ;
      return i11 ? function(e23) {
        return u10[e23 * (u10.length - 1) | 0];
      } : c10;
    };
  }();
  var Mi = function(e21, t16, n12, r9) {
    var a10 = Pi(e21, t16, n12, r9);
    return function(e22, t17, n13) {
      return e22 + (t17 - e22) * a10(n13);
    };
  };
  var Bi = { linear: function(e21, t16, n12) {
    return e21 + (t16 - e21) * n12;
  }, ease: Mi(0.25, 0.1, 0.25, 1), "ease-in": Mi(0.42, 0, 1, 1), "ease-out": Mi(0, 0, 0.58, 1), "ease-in-out": Mi(0.42, 0, 0.58, 1), "ease-in-sine": Mi(0.47, 0, 0.745, 0.715), "ease-out-sine": Mi(0.39, 0.575, 0.565, 1), "ease-in-out-sine": Mi(0.445, 0.05, 0.55, 0.95), "ease-in-quad": Mi(0.55, 0.085, 0.68, 0.53), "ease-out-quad": Mi(0.25, 0.46, 0.45, 0.94), "ease-in-out-quad": Mi(0.455, 0.03, 0.515, 0.955), "ease-in-cubic": Mi(0.55, 0.055, 0.675, 0.19), "ease-out-cubic": Mi(0.215, 0.61, 0.355, 1), "ease-in-out-cubic": Mi(0.645, 0.045, 0.355, 1), "ease-in-quart": Mi(0.895, 0.03, 0.685, 0.22), "ease-out-quart": Mi(0.165, 0.84, 0.44, 1), "ease-in-out-quart": Mi(0.77, 0, 0.175, 1), "ease-in-quint": Mi(0.755, 0.05, 0.855, 0.06), "ease-out-quint": Mi(0.23, 1, 0.32, 1), "ease-in-out-quint": Mi(0.86, 0, 0.07, 1), "ease-in-expo": Mi(0.95, 0.05, 0.795, 0.035), "ease-out-expo": Mi(0.19, 1, 0.22, 1), "ease-in-out-expo": Mi(1, 0, 0, 1), "ease-in-circ": Mi(0.6, 0.04, 0.98, 0.335), "ease-out-circ": Mi(0.075, 0.82, 0.165, 1), "ease-in-out-circ": Mi(0.785, 0.135, 0.15, 0.86), spring: function(e21, t16, n12) {
    if (0 === n12)
      return Bi.linear;
    var r9 = Ti(e21, t16, n12);
    return function(e22, t17, n13) {
      return e22 + (t17 - e22) * r9(n13);
    };
  }, "cubic-bezier": Mi };
  function _i(e21, t16, n12, r9, a10) {
    if (1 === r9)
      return n12;
    if (t16 === n12)
      return n12;
    var i11 = a10(t16, n12, r9);
    return null == e21 || ((e21.roundValue || e21.color) && (i11 = Math.round(i11)), void 0 !== e21.min && (i11 = Math.max(i11, e21.min)), void 0 !== e21.max && (i11 = Math.min(i11, e21.max))), i11;
  }
  function Ni(e21, t16) {
    return null != e21.pfValue || null != e21.value ? null == e21.pfValue || null != t16 && "%" === t16.type.units ? e21.value : e21.pfValue : e21;
  }
  function Ii(e21, t16, n12, r9, a10) {
    var i11 = null != a10 ? a10.type : null;
    n12 < 0 ? n12 = 0 : n12 > 1 && (n12 = 1);
    var o12 = Ni(e21, a10), s11 = Ni(t16, a10);
    if (I6(o12) && I6(s11))
      return _i(i11, o12, s11, n12, r9);
    if (_5(o12) && _5(s11)) {
      for (var l11 = [], u10 = 0; u10 < s11.length; u10++) {
        var c10 = o12[u10], d12 = s11[u10];
        if (null != c10 && null != d12) {
          var h10 = _i(i11, c10, d12, n12, r9);
          l11.push(h10);
        } else
          l11.push(d12);
      }
      return l11;
    }
  }
  function zi(e21, t16, n12, r9) {
    var a10 = !r9, i11 = e21._private, o12 = t16._private, s11 = o12.easing, l11 = o12.startTime, u10 = (r9 ? e21 : e21.cy()).style();
    if (!o12.easingImpl)
      if (null == s11)
        o12.easingImpl = Bi.linear;
      else {
        var c10, d12, h10;
        if (M6(s11))
          c10 = u10.parse("transition-timing-function", s11).value;
        else
          c10 = s11;
        M6(c10) ? (d12 = c10, h10 = []) : (d12 = c10[1], h10 = c10.slice(2).map(function(e22) {
          return +e22;
        })), h10.length > 0 ? ("spring" === d12 && h10.push(o12.duration), o12.easingImpl = Bi[d12].apply(null, h10)) : o12.easingImpl = Bi[d12];
      }
    var p10, f11 = o12.easingImpl;
    if (p10 = 0 === o12.duration ? 1 : (n12 - l11) / o12.duration, o12.applying && (p10 = o12.progress), p10 < 0 ? p10 = 0 : p10 > 1 && (p10 = 1), null == o12.delay) {
      var g9 = o12.startPosition, v12 = o12.position;
      if (v12 && a10 && !e21.locked()) {
        var y10 = {};
        Li(g9.x, v12.x) && (y10.x = Ii(g9.x, v12.x, p10, f11)), Li(g9.y, v12.y) && (y10.y = Ii(g9.y, v12.y, p10, f11)), e21.position(y10);
      }
      var m12 = o12.startPan, b11 = o12.pan, x10 = i11.pan, w11 = null != b11 && r9;
      w11 && (Li(m12.x, b11.x) && (x10.x = Ii(m12.x, b11.x, p10, f11)), Li(m12.y, b11.y) && (x10.y = Ii(m12.y, b11.y, p10, f11)), e21.emit("pan"));
      var E9 = o12.startZoom, k10 = o12.zoom, C9 = null != k10 && r9;
      C9 && (Li(E9, k10) && (i11.zoom = gt4(i11.minZoom, Ii(E9, k10, p10, f11), i11.maxZoom)), e21.emit("zoom")), (w11 || C9) && e21.emit("viewport");
      var S8 = o12.style;
      if (S8 && S8.length > 0 && a10) {
        for (var D9 = 0; D9 < S8.length; D9++) {
          var P10 = S8[D9], T9 = P10.name, B9 = P10, _7 = o12.startStyle[T9], N8 = Ii(_7, B9, p10, f11, u10.properties[_7.name]);
          u10.overrideBypass(e21, T9, N8);
        }
        e21.emit("style");
      }
    }
    return o12.progress = p10, p10;
  }
  function Li(e21, t16) {
    return null != e21 && null != t16 && (!(!I6(e21) || !I6(t16)) || !(!e21 || !t16));
  }
  function Ai(e21, t16, n12, r9) {
    var a10 = t16._private;
    a10.started = true, a10.startTime = n12 - a10.progress * a10.duration;
  }
  function Oi(e21, t16) {
    var n12 = t16._private.aniEles, r9 = [];
    function a10(t17, n13) {
      var a11 = t17._private, i12 = a11.animation.current, o13 = a11.animation.queue, s12 = false;
      if (0 === i12.length) {
        var l12 = o13.shift();
        l12 && i12.push(l12);
      }
      for (var u10 = function(e22) {
        for (var t18 = e22.length - 1; t18 >= 0; t18--) {
          (0, e22[t18])();
        }
        e22.splice(0, e22.length);
      }, c10 = i12.length - 1; c10 >= 0; c10--) {
        var d12 = i12[c10], h10 = d12._private;
        h10.stopped ? (i12.splice(c10, 1), h10.hooked = false, h10.playing = false, h10.started = false, u10(h10.frames)) : (h10.playing || h10.applying) && (h10.playing && h10.applying && (h10.applying = false), h10.started || Ai(0, d12, e21), zi(t17, d12, e21, n13), h10.applying && (h10.applying = false), u10(h10.frames), null != h10.step && h10.step(e21), d12.completed() && (i12.splice(c10, 1), h10.hooked = false, h10.playing = false, h10.started = false, u10(h10.completes)), s12 = true);
      }
      return n13 || 0 !== i12.length || 0 !== o13.length || r9.push(t17), s12;
    }
    for (var i11 = false, o12 = 0; o12 < n12.length; o12++) {
      var s11 = a10(n12[o12]);
      i11 = i11 || s11;
    }
    var l11 = a10(t16, true);
    (i11 || l11) && (n12.length > 0 ? t16.notify("draw", n12) : t16.notify("draw")), n12.unmerge(r9), t16.emit("step");
  }
  var Ri = { animate: ur3.animate(), animation: ur3.animation(), animated: ur3.animated(), clearQueue: ur3.clearQueue(), delay: ur3.delay(), delayAnimation: ur3.delayAnimation(), stop: ur3.stop(), addToAnimationPool: function(e21) {
    this.styleEnabled() && this._private.aniEles.merge(e21);
  }, stopAnimationLoop: function() {
    this._private.animationsRunning = false;
  }, startAnimationLoop: function() {
    var e21 = this;
    if (e21._private.animationsRunning = true, e21.styleEnabled()) {
      var t16 = e21.renderer();
      t16 && t16.beforeRender ? t16.beforeRender(function(t17, n12) {
        Oi(n12, e21);
      }, t16.beforeRenderPriorities.animations) : function t17() {
        e21._private.animationsRunning && se(function(n12) {
          Oi(n12, e21), t17();
        });
      }();
    }
  } };
  var Vi = { qualifierCompare: function(e21, t16) {
    return null == e21 || null == t16 ? null == e21 && null == t16 : e21.sameText(t16);
  }, eventMatches: function(e21, t16, n12) {
    var r9 = t16.qualifier;
    return null == r9 || e21 !== n12.target && A6(n12.target) && r9.matches(n12.target);
  }, addEventFields: function(e21, t16) {
    t16.cy = e21, t16.target = e21;
  }, callbackContext: function(e21, t16, n12) {
    return null != t16.qualifier ? n12.target : e21;
  } };
  var Fi = function(e21) {
    return M6(e21) ? new Kr(e21) : e21;
  };
  var qi = { createEmitter: function() {
    var e21 = this._private;
    return e21.emitter || (e21.emitter = new ja(Vi, this)), this;
  }, emitter: function() {
    return this._private.emitter;
  }, on: function(e21, t16, n12) {
    return this.emitter().on(e21, Fi(t16), n12), this;
  }, removeListener: function(e21, t16, n12) {
    return this.emitter().removeListener(e21, Fi(t16), n12), this;
  }, removeAllListeners: function() {
    return this.emitter().removeAllListeners(), this;
  }, one: function(e21, t16, n12) {
    return this.emitter().one(e21, Fi(t16), n12), this;
  }, once: function(e21, t16, n12) {
    return this.emitter().one(e21, Fi(t16), n12), this;
  }, emit: function(e21, t16) {
    return this.emitter().emit(e21, t16), this;
  }, emitAndNotify: function(e21, t16) {
    return this.emit(e21), this.notify(e21, t16), this;
  } };
  ur3.eventAliasesOn(qi);
  var ji = { png: function(e21) {
    return e21 = e21 || {}, this._private.renderer.png(e21);
  }, jpg: function(e21) {
    var t16 = this._private.renderer;
    return (e21 = e21 || {}).bg = e21.bg || "#fff", t16.jpg(e21);
  } };
  ji.jpeg = ji.jpg;
  var Yi = { layout: function(e21) {
    var t16 = this;
    if (null != e21)
      if (null != e21.name) {
        var n12 = e21.name, r9 = t16.extension("layout", n12);
        if (null != r9) {
          var a10;
          a10 = M6(e21.eles) ? t16.$(e21.eles) : null != e21.eles ? e21.eles : t16.$();
          var i11 = new r9(J4({}, e21, { cy: t16, eles: a10 }));
          return i11;
        }
        Pe("No such layout `" + n12 + "` found.  Did you forget to import it and `cytoscape.use()` it?");
      } else
        Pe("A `name` must be specified to make a layout");
    else
      Pe("Layout options must be specified to make a layout");
  } };
  Yi.createLayout = Yi.makeLayout = Yi.layout;
  var Xi = { notify: function(e21, t16) {
    var n12 = this._private;
    if (this.batching()) {
      n12.batchNotifications = n12.batchNotifications || {};
      var r9 = n12.batchNotifications[e21] = n12.batchNotifications[e21] || this.collection();
      null != t16 && r9.merge(t16);
    } else if (n12.notificationsEnabled) {
      var a10 = this.renderer();
      !this.destroyed() && a10 && a10.notify(e21, t16);
    }
  }, notifications: function(e21) {
    var t16 = this._private;
    return void 0 === e21 ? t16.notificationsEnabled : (t16.notificationsEnabled = !!e21, this);
  }, noNotifications: function(e21) {
    this.notifications(false), e21(), this.notifications(true);
  }, batching: function() {
    return this._private.batchCount > 0;
  }, startBatch: function() {
    var e21 = this._private;
    return null == e21.batchCount && (e21.batchCount = 0), 0 === e21.batchCount && (e21.batchStyleEles = this.collection(), e21.batchNotifications = {}), e21.batchCount++, this;
  }, endBatch: function() {
    var e21 = this._private;
    if (0 === e21.batchCount)
      return this;
    if (e21.batchCount--, 0 === e21.batchCount) {
      e21.batchStyleEles.updateStyle();
      var t16 = this.renderer();
      Object.keys(e21.batchNotifications).forEach(function(n12) {
        var r9 = e21.batchNotifications[n12];
        r9.empty() ? t16.notify(n12) : t16.notify(n12, r9);
      });
    }
    return this;
  }, batch: function(e21) {
    return this.startBatch(), e21(), this.endBatch(), this;
  }, batchData: function(e21) {
    var t16 = this;
    return this.batch(function() {
      for (var n12 = Object.keys(e21), r9 = 0; r9 < n12.length; r9++) {
        var a10 = n12[r9], i11 = e21[a10];
        t16.getElementById(a10).data(i11);
      }
    });
  } };
  var Wi = ze({ hideEdgesOnViewport: false, textureOnViewport: false, motionBlur: false, motionBlurOpacity: 0.05, pixelRatio: void 0, desktopTapThreshold: 4, touchTapThreshold: 8, wheelSensitivity: 1, debug: false, showFps: false });
  var Hi = { renderTo: function(e21, t16, n12, r9) {
    return this._private.renderer.renderTo(e21, t16, n12, r9), this;
  }, renderer: function() {
    return this._private.renderer;
  }, forceRender: function() {
    return this.notify("draw"), this;
  }, resize: function() {
    return this.invalidateSize(), this.emitAndNotify("resize"), this;
  }, initRenderer: function(e21) {
    var t16 = this, n12 = t16.extension("renderer", e21.name);
    if (null != n12) {
      void 0 !== e21.wheelSensitivity && Me("You have set a custom wheel sensitivity.  This will make your app zoom unnaturally when using mainstream mice.  You should change this value from the default only if you can guarantee that all your users will use the same hardware and OS configuration as your current machine.");
      var r9 = Wi(e21);
      r9.cy = t16, t16._private.renderer = new n12(r9), this.notify("init");
    } else
      Pe("Can not initialise: No such renderer `".concat(e21.name, "` found. Did you forget to import it and `cytoscape.use()` it?"));
  }, destroyRenderer: function() {
    var e21 = this;
    e21.notify("destroy");
    var t16 = e21.container();
    if (t16)
      for (t16._cyreg = null; t16.childNodes.length > 0; )
        t16.removeChild(t16.childNodes[0]);
    e21._private.renderer = null, e21.mutableElements().forEach(function(e22) {
      var t17 = e22._private;
      t17.rscratch = {}, t17.rstyle = {}, t17.animation.current = [], t17.animation.queue = [];
    });
  }, onRender: function(e21) {
    return this.on("render", e21);
  }, offRender: function(e21) {
    return this.off("render", e21);
  } };
  Hi.invalidateDimensions = Hi.resize;
  var Ki = { collection: function(e21, t16) {
    return M6(e21) ? this.$(e21) : L5(e21) ? e21.collection() : _5(e21) ? (t16 || (t16 = {}), new Ci(this, e21, t16.unique, t16.removed)) : new Ci(this);
  }, nodes: function(e21) {
    var t16 = this.$(function(e22) {
      return e22.isNode();
    });
    return e21 ? t16.filter(e21) : t16;
  }, edges: function(e21) {
    var t16 = this.$(function(e22) {
      return e22.isEdge();
    });
    return e21 ? t16.filter(e21) : t16;
  }, $: function(e21) {
    var t16 = this._private.elements;
    return e21 ? t16.filter(e21) : t16.spawnSelf();
  }, mutableElements: function() {
    return this._private.elements;
  } };
  Ki.elements = Ki.filter = Ki.$;
  var Gi = {};
  var Ui = "t";
  Gi.apply = function(e21) {
    for (var t16 = this, n12 = t16._private.cy.collection(), r9 = 0; r9 < e21.length; r9++) {
      var a10 = e21[r9], i11 = t16.getContextMeta(a10);
      if (!i11.empty) {
        var o12 = t16.getContextStyle(i11), s11 = t16.applyContextStyle(i11, o12, a10);
        a10._private.appliedInitStyle ? t16.updateTransitions(a10, s11.diffProps) : a10._private.appliedInitStyle = true, t16.updateStyleHints(a10) && n12.push(a10);
      }
    }
    return n12;
  }, Gi.getPropertiesDiff = function(e21, t16) {
    var n12 = this, r9 = n12._private.propDiffs = n12._private.propDiffs || {}, a10 = e21 + "-" + t16, i11 = r9[a10];
    if (i11)
      return i11;
    for (var o12 = [], s11 = {}, l11 = 0; l11 < n12.length; l11++) {
      var u10 = n12[l11], c10 = e21[l11] === Ui, d12 = t16[l11] === Ui, h10 = c10 !== d12, p10 = u10.mappedProperties.length > 0;
      if (h10 || d12 && p10) {
        var f11 = void 0;
        h10 && p10 || h10 ? f11 = u10.properties : p10 && (f11 = u10.mappedProperties);
        for (var g9 = 0; g9 < f11.length; g9++) {
          for (var v12 = f11[g9], y10 = v12.name, m12 = false, b11 = l11 + 1; b11 < n12.length; b11++) {
            var x10 = n12[b11];
            if (t16[b11] === Ui && (m12 = null != x10.properties[v12.name]))
              break;
          }
          s11[y10] || m12 || (s11[y10] = true, o12.push(y10));
        }
      }
    }
    return r9[a10] = o12, o12;
  }, Gi.getContextMeta = function(e21) {
    for (var t16, n12 = this, r9 = "", a10 = e21._private.styleCxtKey || "", i11 = 0; i11 < n12.length; i11++) {
      var o12 = n12[i11];
      r9 += o12.selector && o12.selector.matches(e21) ? Ui : "f";
    }
    return t16 = n12.getPropertiesDiff(a10, r9), e21._private.styleCxtKey = r9, { key: r9, diffPropNames: t16, empty: 0 === t16.length };
  }, Gi.getContextStyle = function(e21) {
    var t16 = e21.key, n12 = this._private.contextStyles = this._private.contextStyles || {};
    if (n12[t16])
      return n12[t16];
    for (var r9 = { _private: { key: t16 } }, a10 = 0; a10 < this.length; a10++) {
      var i11 = this[a10];
      if (t16[a10] === Ui)
        for (var o12 = 0; o12 < i11.properties.length; o12++) {
          var s11 = i11.properties[o12];
          r9[s11.name] = s11;
        }
    }
    return n12[t16] = r9, r9;
  }, Gi.applyContextStyle = function(e21, t16, n12) {
    for (var r9 = e21.diffPropNames, a10 = {}, i11 = this.types, o12 = 0; o12 < r9.length; o12++) {
      var s11 = r9[o12], l11 = t16[s11], u10 = n12.pstyle(s11);
      if (!l11) {
        if (!u10)
          continue;
        l11 = u10.bypass ? { name: s11, deleteBypassed: true } : { name: s11, delete: true };
      }
      if (u10 !== l11) {
        if (l11.mapped === i11.fn && null != u10 && null != u10.mapping && u10.mapping.value === l11.value) {
          var c10 = u10.mapping;
          if ((c10.fnValue = l11.value(n12)) === c10.prevFnValue)
            continue;
        }
        var d12 = a10[s11] = { prev: u10 };
        this.applyParsedProperty(n12, l11), d12.next = n12.pstyle(s11), d12.next && d12.next.bypass && (d12.next = d12.next.bypassed);
      }
    }
    return { diffProps: a10 };
  }, Gi.updateStyleHints = function(e21) {
    var t16 = e21._private, n12 = this, r9 = n12.propertyGroupNames, a10 = n12.propertyGroupKeys, i11 = function(e22, t17, r10) {
      return n12.getPropertiesHash(e22, t17, r10);
    }, o12 = t16.styleKey;
    if (e21.removed())
      return false;
    var s11 = "nodes" === t16.group, l11 = e21._private.style;
    r9 = Object.keys(l11);
    for (var u10 = 0; u10 < a10.length; u10++) {
      var c10 = a10[u10];
      t16.styleKeys[c10] = [ue, ce];
    }
    for (var d12, h10 = function(e22, n13) {
      return t16.styleKeys[n13][0] = he(e22, t16.styleKeys[n13][0]);
    }, p10 = function(e22, n13) {
      return t16.styleKeys[n13][1] = pe(e22, t16.styleKeys[n13][1]);
    }, f11 = function(e22, t17) {
      h10(e22, t17), p10(e22, t17);
    }, g9 = function(e22, t17) {
      for (var n13 = 0; n13 < e22.length; n13++) {
        var r10 = e22.charCodeAt(n13);
        h10(r10, t17), p10(r10, t17);
      }
    }, v12 = 0; v12 < r9.length; v12++) {
      var y10 = r9[v12], m12 = l11[y10];
      if (null != m12) {
        var b11 = this.properties[y10], x10 = b11.type, w11 = b11.groupKey, E9 = void 0;
        null != b11.hashOverride ? E9 = b11.hashOverride(e21, m12) : null != m12.pfValue && (E9 = m12.pfValue);
        var k10 = null == b11.enums ? m12.value : null, C9 = null != E9, S8 = C9 || null != k10, D9 = m12.units;
        if (x10.number && S8 && !x10.multiple)
          f11(-128 < (d12 = C9 ? E9 : k10) && d12 < 128 && Math.floor(d12) !== d12 ? 2e9 - (1024 * d12 | 0) : d12, w11), C9 || null == D9 || g9(D9, w11);
        else
          g9(m12.strValue, w11);
      }
    }
    for (var P10, T9, M9 = [ue, ce], B9 = 0; B9 < a10.length; B9++) {
      var _7 = a10[B9], N8 = t16.styleKeys[_7];
      M9[0] = he(N8[0], M9[0]), M9[1] = pe(N8[1], M9[1]);
    }
    t16.styleKey = (P10 = M9[0], T9 = M9[1], 2097152 * P10 + T9);
    var I8 = t16.styleKeys;
    t16.labelDimsKey = fe(I8.labelDimensions);
    var z8 = i11(e21, ["label"], I8.labelDimensions);
    if (t16.labelKey = fe(z8), t16.labelStyleKey = fe(ge(I8.commonLabel, z8)), !s11) {
      var L9 = i11(e21, ["source-label"], I8.labelDimensions);
      t16.sourceLabelKey = fe(L9), t16.sourceLabelStyleKey = fe(ge(I8.commonLabel, L9));
      var A10 = i11(e21, ["target-label"], I8.labelDimensions);
      t16.targetLabelKey = fe(A10), t16.targetLabelStyleKey = fe(ge(I8.commonLabel, A10));
    }
    if (s11) {
      var O10 = t16.styleKeys, R8 = O10.nodeBody, V8 = O10.nodeBorder, F9 = O10.backgroundImage, q8 = O10.compound, j9 = O10.pie, Y6 = [R8, V8, F9, q8, j9].filter(function(e22) {
        return null != e22;
      }).reduce(ge, [ue, ce]);
      t16.nodeKey = fe(Y6), t16.hasPie = null != j9 && j9[0] !== ue && j9[1] !== ce;
    }
    return o12 !== t16.styleKey;
  }, Gi.clearStyleHints = function(e21) {
    var t16 = e21._private;
    t16.styleCxtKey = "", t16.styleKeys = {}, t16.styleKey = null, t16.labelKey = null, t16.labelStyleKey = null, t16.sourceLabelKey = null, t16.sourceLabelStyleKey = null, t16.targetLabelKey = null, t16.targetLabelStyleKey = null, t16.nodeKey = null, t16.hasPie = null;
  }, Gi.applyParsedProperty = function(e21, t16) {
    var n12, r9 = this, a10 = t16, i11 = e21._private.style, o12 = r9.types, s11 = r9.properties[a10.name].type, l11 = a10.bypass, u10 = i11[a10.name], c10 = u10 && u10.bypass, d12 = e21._private, h10 = "mapping", p10 = function(e22) {
      return null == e22 ? null : null != e22.pfValue ? e22.pfValue : e22.value;
    }, f11 = function() {
      var t17 = p10(u10), n13 = p10(a10);
      r9.checkTriggers(e21, a10.name, t17, n13);
    };
    if (a10 && "pie" === a10.name.substr(0, 3) && Me("The pie style properties are deprecated.  Create charts using background images instead."), "curve-style" === t16.name && e21.isEdge() && ("bezier" !== t16.value && e21.isLoop() || "haystack" === t16.value && (e21.source().isParent() || e21.target().isParent())) && (a10 = t16 = this.parse(t16.name, "bezier", l11)), a10.delete)
      return i11[a10.name] = void 0, f11(), true;
    if (a10.deleteBypassed)
      return u10 ? !!u10.bypass && (u10.bypassed = void 0, f11(), true) : (f11(), true);
    if (a10.deleteBypass)
      return u10 ? !!u10.bypass && (i11[a10.name] = u10.bypassed, f11(), true) : (f11(), true);
    var g9 = function() {
      Me("Do not assign mappings to elements without corresponding data (i.e. ele `" + e21.id() + "` has no mapping for property `" + a10.name + "` with data field `" + a10.field + "`); try a `[" + a10.field + "]` selector to limit scope to elements with `" + a10.field + "` defined");
    };
    switch (a10.mapped) {
      case o12.mapData:
        for (var v12, y10 = a10.field.split("."), m12 = d12.data, b11 = 0; b11 < y10.length && m12; b11++) {
          m12 = m12[y10[b11]];
        }
        if (null == m12)
          return g9(), false;
        if (!I6(m12))
          return Me("Do not use continuous mappers without specifying numeric data (i.e. `" + a10.field + ": " + m12 + "` for `" + e21.id() + "` is non-numeric)"), false;
        var x10 = a10.fieldMax - a10.fieldMin;
        if ((v12 = 0 === x10 ? 0 : (m12 - a10.fieldMin) / x10) < 0 ? v12 = 0 : v12 > 1 && (v12 = 1), s11.color) {
          var w11 = a10.valueMin[0], E9 = a10.valueMax[0], k10 = a10.valueMin[1], C9 = a10.valueMax[1], S8 = a10.valueMin[2], D9 = a10.valueMax[2], P10 = null == a10.valueMin[3] ? 1 : a10.valueMin[3], T9 = null == a10.valueMax[3] ? 1 : a10.valueMax[3], M9 = [Math.round(w11 + (E9 - w11) * v12), Math.round(k10 + (C9 - k10) * v12), Math.round(S8 + (D9 - S8) * v12), Math.round(P10 + (T9 - P10) * v12)];
          n12 = { bypass: a10.bypass, name: a10.name, value: M9, strValue: "rgb(" + M9[0] + ", " + M9[1] + ", " + M9[2] + ")" };
        } else {
          if (!s11.number)
            return false;
          var B9 = a10.valueMin + (a10.valueMax - a10.valueMin) * v12;
          n12 = this.parse(a10.name, B9, a10.bypass, h10);
        }
        if (!n12)
          return g9(), false;
        n12.mapping = a10, a10 = n12;
        break;
      case o12.data:
        for (var _7 = a10.field.split("."), N8 = d12.data, z8 = 0; z8 < _7.length && N8; z8++) {
          N8 = N8[_7[z8]];
        }
        if (null != N8 && (n12 = this.parse(a10.name, N8, a10.bypass, h10)), !n12)
          return g9(), false;
        n12.mapping = a10, a10 = n12;
        break;
      case o12.fn:
        var L9 = a10.value, A10 = null != a10.fnValue ? a10.fnValue : L9(e21);
        if (a10.prevFnValue = A10, null == A10)
          return Me("Custom function mappers may not return null (i.e. `" + a10.name + "` for ele `" + e21.id() + "` is null)"), false;
        if (!(n12 = this.parse(a10.name, A10, a10.bypass, h10)))
          return Me("Custom function mappers may not return invalid values for the property type (i.e. `" + a10.name + "` for ele `" + e21.id() + "` is invalid)"), false;
        n12.mapping = Be(a10), a10 = n12;
        break;
      case void 0:
        break;
      default:
        return false;
    }
    return l11 ? (a10.bypassed = c10 ? u10.bypassed : u10, i11[a10.name] = a10) : c10 ? u10.bypassed = a10 : i11[a10.name] = a10, f11(), true;
  }, Gi.cleanElements = function(e21, t16) {
    for (var n12 = 0; n12 < e21.length; n12++) {
      var r9 = e21[n12];
      if (this.clearStyleHints(r9), r9.dirtyCompoundBoundsCache(), r9.dirtyBoundingBoxCache(), t16)
        for (var a10 = r9._private.style, i11 = Object.keys(a10), o12 = 0; o12 < i11.length; o12++) {
          var s11 = i11[o12], l11 = a10[s11];
          null != l11 && (l11.bypass ? l11.bypassed = null : a10[s11] = null);
        }
      else
        r9._private.style = {};
    }
  }, Gi.update = function() {
    this._private.cy.mutableElements().updateStyle();
  }, Gi.updateTransitions = function(e21, t16) {
    var n12 = this, r9 = e21._private, a10 = e21.pstyle("transition-property").value, i11 = e21.pstyle("transition-duration").pfValue, o12 = e21.pstyle("transition-delay").pfValue;
    if (a10.length > 0 && i11 > 0) {
      for (var s11 = {}, l11 = false, u10 = 0; u10 < a10.length; u10++) {
        var c10 = a10[u10], d12 = e21.pstyle(c10), h10 = t16[c10];
        if (h10) {
          var p10 = h10.prev, f11 = null != h10.next ? h10.next : d12, g9 = false, v12 = void 0, y10 = 1e-6;
          p10 && (I6(p10.pfValue) && I6(f11.pfValue) ? (g9 = f11.pfValue - p10.pfValue, v12 = p10.pfValue + y10 * g9) : I6(p10.value) && I6(f11.value) ? (g9 = f11.value - p10.value, v12 = p10.value + y10 * g9) : _5(p10.value) && _5(f11.value) && (g9 = p10.value[0] !== f11.value[0] || p10.value[1] !== f11.value[1] || p10.value[2] !== f11.value[2], v12 = p10.strValue), g9 && (s11[c10] = f11.strValue, this.applyBypass(e21, c10, v12), l11 = true));
        }
      }
      if (!l11)
        return;
      r9.transitioning = true, new rr4(function(t17) {
        o12 > 0 ? e21.delayAnimation(o12).play().promise().then(t17) : t17();
      }).then(function() {
        return e21.animation({ style: s11, duration: i11, easing: e21.pstyle("transition-timing-function").value, queue: false }).play().promise();
      }).then(function() {
        n12.removeBypasses(e21, a10), e21.emitAndNotify("style"), r9.transitioning = false;
      });
    } else
      r9.transitioning && (this.removeBypasses(e21, a10), e21.emitAndNotify("style"), r9.transitioning = false);
  }, Gi.checkTrigger = function(e21, t16, n12, r9, a10, i11) {
    var o12 = this.properties[t16], s11 = a10(o12);
    null != s11 && s11(n12, r9) && i11(o12);
  }, Gi.checkZOrderTrigger = function(e21, t16, n12, r9) {
    var a10 = this;
    this.checkTrigger(e21, t16, n12, r9, function(e22) {
      return e22.triggersZOrder;
    }, function() {
      a10._private.cy.notify("zorder", e21);
    });
  }, Gi.checkBoundsTrigger = function(e21, t16, n12, r9) {
    this.checkTrigger(e21, t16, n12, r9, function(e22) {
      return e22.triggersBounds;
    }, function(a10) {
      e21.dirtyCompoundBoundsCache(), e21.dirtyBoundingBoxCache(), !a10.triggersBoundsOfParallelBeziers || ("curve-style" !== t16 || "bezier" !== n12 && "bezier" !== r9) && ("display" !== t16 || "none" !== n12 && "none" !== r9) || e21.parallelEdges().forEach(function(e22) {
        e22.isBundledBezier() && e22.dirtyBoundingBoxCache();
      });
    });
  }, Gi.checkTriggers = function(e21, t16, n12, r9) {
    e21.dirtyStyleCache(), this.checkZOrderTrigger(e21, t16, n12, r9), this.checkBoundsTrigger(e21, t16, n12, r9);
  };
  var Zi = { applyBypass: function(e21, t16, n12, r9) {
    var a10 = [];
    if ("*" === t16 || "**" === t16) {
      if (void 0 !== n12)
        for (var i11 = 0; i11 < this.properties.length; i11++) {
          var o12 = this.properties[i11].name, s11 = this.parse(o12, n12, true);
          s11 && a10.push(s11);
        }
    } else if (M6(t16)) {
      var l11 = this.parse(t16, n12, true);
      l11 && a10.push(l11);
    } else {
      if (!N6(t16))
        return false;
      var u10 = t16;
      r9 = n12;
      for (var c10 = Object.keys(u10), d12 = 0; d12 < c10.length; d12++) {
        var h10 = c10[d12], p10 = u10[h10];
        if (void 0 === p10 && (p10 = u10[X4(h10)]), void 0 !== p10) {
          var f11 = this.parse(h10, p10, true);
          f11 && a10.push(f11);
        }
      }
    }
    if (0 === a10.length)
      return false;
    for (var g9 = false, v12 = 0; v12 < e21.length; v12++) {
      for (var y10 = e21[v12], m12 = {}, b11 = void 0, x10 = 0; x10 < a10.length; x10++) {
        var w11 = a10[x10];
        if (r9) {
          var E9 = y10.pstyle(w11.name);
          b11 = m12[w11.name] = { prev: E9 };
        }
        g9 = this.applyParsedProperty(y10, Be(w11)) || g9, r9 && (b11.next = y10.pstyle(w11.name));
      }
      g9 && this.updateStyleHints(y10), r9 && this.updateTransitions(y10, m12, true);
    }
    return g9;
  }, overrideBypass: function(e21, t16, n12) {
    t16 = Y4(t16);
    for (var r9 = 0; r9 < e21.length; r9++) {
      var a10 = e21[r9], i11 = a10._private.style[t16], o12 = this.properties[t16].type, s11 = o12.color, l11 = o12.mutiple, u10 = i11 ? null != i11.pfValue ? i11.pfValue : i11.value : null;
      i11 && i11.bypass ? (i11.value = n12, null != i11.pfValue && (i11.pfValue = n12), i11.strValue = s11 ? "rgb(" + n12.join(",") + ")" : l11 ? n12.join(" ") : "" + n12, this.updateStyleHints(a10)) : this.applyBypass(a10, t16, n12), this.checkTriggers(a10, t16, u10, n12);
    }
  }, removeAllBypasses: function(e21, t16) {
    return this.removeBypasses(e21, this.propertyNames, t16);
  }, removeBypasses: function(e21, t16, n12) {
    for (var r9 = 0; r9 < e21.length; r9++) {
      for (var a10 = e21[r9], i11 = {}, o12 = 0; o12 < t16.length; o12++) {
        var s11 = t16[o12], l11 = this.properties[s11], u10 = a10.pstyle(l11.name);
        if (u10 && u10.bypass) {
          var c10 = this.parse(s11, "", true), d12 = i11[l11.name] = { prev: u10 };
          this.applyParsedProperty(a10, c10), d12.next = a10.pstyle(l11.name);
        }
      }
      this.updateStyleHints(a10), n12 && this.updateTransitions(a10, i11, true);
    }
  } };
  var $i = { getEmSizeInPixels: function() {
    var e21 = this.containerCss("font-size");
    return null != e21 ? parseFloat(e21) : 1;
  }, containerCss: function(e21) {
    var t16 = this._private.cy, n12 = t16.container(), r9 = t16.window();
    if (r9 && n12 && r9.getComputedStyle)
      return r9.getComputedStyle(n12).getPropertyValue(e21);
  } };
  var Qi = { getRenderedStyle: function(e21, t16) {
    return t16 ? this.getStylePropertyValue(e21, t16, true) : this.getRawStyle(e21, true);
  }, getRawStyle: function(e21, t16) {
    var n12 = this;
    if (e21 = e21[0]) {
      for (var r9 = {}, a10 = 0; a10 < n12.properties.length; a10++) {
        var i11 = n12.properties[a10], o12 = n12.getStylePropertyValue(e21, i11.name, t16);
        null != o12 && (r9[i11.name] = o12, r9[X4(i11.name)] = o12);
      }
      return r9;
    }
  }, getIndexedStyle: function(e21, t16, n12, r9) {
    var a10 = e21.pstyle(t16)[n12][r9];
    return null != a10 ? a10 : e21.cy().style().getDefaultProperty(t16)[n12][0];
  }, getStylePropertyValue: function(e21, t16, n12) {
    if (e21 = e21[0]) {
      var r9 = this.properties[t16];
      r9.alias && (r9 = r9.pointsTo);
      var a10 = r9.type, i11 = e21.pstyle(r9.name);
      if (i11) {
        var o12 = i11.value, s11 = i11.units, l11 = i11.strValue;
        if (n12 && a10.number && null != o12 && I6(o12)) {
          var u10 = e21.cy().zoom(), c10 = function(e22) {
            return e22 * u10;
          }, d12 = function(e22, t17) {
            return c10(e22) + t17;
          }, h10 = _5(o12);
          return (h10 ? s11.every(function(e22) {
            return null != e22;
          }) : null != s11) ? h10 ? o12.map(function(e22, t17) {
            return d12(e22, s11[t17]);
          }).join(" ") : d12(o12, s11) : h10 ? o12.map(function(e22) {
            return M6(e22) ? e22 : "" + c10(e22);
          }).join(" ") : "" + c10(o12);
        }
        if (null != l11)
          return l11;
      }
      return null;
    }
  }, getAnimationStartStyle: function(e21, t16) {
    for (var n12 = {}, r9 = 0; r9 < t16.length; r9++) {
      var a10 = t16[r9].name, i11 = e21.pstyle(a10);
      void 0 !== i11 && (i11 = N6(i11) ? this.parse(a10, i11.strValue) : this.parse(a10, i11)), i11 && (n12[a10] = i11);
    }
    return n12;
  }, getPropsList: function(e21) {
    var t16 = [], n12 = e21, r9 = this.properties;
    if (n12)
      for (var a10 = Object.keys(n12), i11 = 0; i11 < a10.length; i11++) {
        var o12 = a10[i11], s11 = n12[o12], l11 = r9[o12] || r9[Y4(o12)], u10 = this.parse(l11.name, s11);
        u10 && t16.push(u10);
      }
    return t16;
  }, getNonDefaultPropertiesHash: function(e21, t16, n12) {
    var r9, a10, i11, o12, s11, l11, u10 = n12.slice();
    for (s11 = 0; s11 < t16.length; s11++)
      if (r9 = t16[s11], null != (a10 = e21.pstyle(r9, false)))
        if (null != a10.pfValue)
          u10[0] = he(o12, u10[0]), u10[1] = pe(o12, u10[1]);
        else
          for (i11 = a10.strValue, l11 = 0; l11 < i11.length; l11++)
            o12 = i11.charCodeAt(l11), u10[0] = he(o12, u10[0]), u10[1] = pe(o12, u10[1]);
    return u10;
  } };
  Qi.getPropertiesHash = Qi.getNonDefaultPropertiesHash;
  var Ji = { appendFromJson: function(e21) {
    for (var t16 = this, n12 = 0; n12 < e21.length; n12++) {
      var r9 = e21[n12], a10 = r9.selector, i11 = r9.style || r9.css, o12 = Object.keys(i11);
      t16.selector(a10);
      for (var s11 = 0; s11 < o12.length; s11++) {
        var l11 = o12[s11], u10 = i11[l11];
        t16.css(l11, u10);
      }
    }
    return t16;
  }, fromJson: function(e21) {
    var t16 = this;
    return t16.resetToDefault(), t16.appendFromJson(e21), t16;
  }, json: function() {
    for (var e21 = [], t16 = this.defaultLength; t16 < this.length; t16++) {
      for (var n12 = this[t16], r9 = n12.selector, a10 = n12.properties, i11 = {}, o12 = 0; o12 < a10.length; o12++) {
        var s11 = a10[o12];
        i11[s11.name] = s11.strValue;
      }
      e21.push({ selector: r9 ? r9.toString() : "core", style: i11 });
    }
    return e21;
  } };
  var eo = { appendFromString: function(e21) {
    var t16, n12, r9, a10 = this, i11 = "" + e21;
    function o12() {
      i11 = i11.length > t16.length ? i11.substr(t16.length) : "";
    }
    function s11() {
      n12 = n12.length > r9.length ? n12.substr(r9.length) : "";
    }
    for (i11 = i11.replace(/[/][*](\s|.)+?[*][/]/g, ""); ; ) {
      if (i11.match(/^\s*$/))
        break;
      var l11 = i11.match(/^\s*((?:.|\s)+?)\s*\{((?:.|\s)+?)\}/);
      if (!l11) {
        Me("Halting stylesheet parsing: String stylesheet contains more to parse but no selector and block found in: " + i11);
        break;
      }
      t16 = l11[0];
      var u10 = l11[1];
      if ("core" !== u10) {
        if (new Kr(u10).invalid) {
          Me("Skipping parsing of block: Invalid selector found in string stylesheet: " + u10), o12();
          continue;
        }
      }
      var c10 = l11[2], d12 = false;
      n12 = c10;
      for (var h10 = []; ; ) {
        if (n12.match(/^\s*$/))
          break;
        var p10 = n12.match(/^\s*(.+?)\s*:\s*(.+?)(?:\s*;|\s*$)/);
        if (!p10) {
          Me("Skipping parsing of block: Invalid formatting of style property and value definitions found in:" + c10), d12 = true;
          break;
        }
        r9 = p10[0];
        var f11 = p10[1], g9 = p10[2];
        if (this.properties[f11])
          a10.parse(f11, g9) ? (h10.push({ name: f11, val: g9 }), s11()) : (Me("Skipping property: Invalid property definition in: " + r9), s11());
        else
          Me("Skipping property: Invalid property name in: " + r9), s11();
      }
      if (d12) {
        o12();
        break;
      }
      a10.selector(u10);
      for (var v12 = 0; v12 < h10.length; v12++) {
        var y10 = h10[v12];
        a10.css(y10.name, y10.val);
      }
      o12();
    }
    return a10;
  }, fromString: function(e21) {
    var t16 = this;
    return t16.resetToDefault(), t16.appendFromString(e21), t16;
  } };
  var to = {};
  !function() {
    var e21 = K4, t16 = U5, n12 = $6, r9 = function(e22) {
      return "^" + e22 + "\\s*\\(\\s*([\\w\\.]+)\\s*\\)$";
    }, a10 = function(r10) {
      var a11 = e21 + "|\\w+|" + t16 + "|" + n12 + "|\\#[0-9a-fA-F]{3}|\\#[0-9a-fA-F]{6}";
      return "^" + r10 + "\\s*\\(([\\w\\.]+)\\s*\\,\\s*(" + e21 + ")\\s*\\,\\s*(" + e21 + ")\\s*,\\s*(" + a11 + ")\\s*\\,\\s*(" + a11 + ")\\)$";
    }, i11 = [`^url\\s*\\(\\s*['"]?(.+?)['"]?\\s*\\)$`, "^(none)$", "^(.+)$"];
    to.types = { time: { number: true, min: 0, units: "s|ms", implicitUnits: "ms" }, percent: { number: true, min: 0, max: 100, units: "%", implicitUnits: "%" }, percentages: { number: true, min: 0, max: 100, units: "%", implicitUnits: "%", multiple: true }, zeroOneNumber: { number: true, min: 0, max: 1, unitless: true }, zeroOneNumbers: { number: true, min: 0, max: 1, unitless: true, multiple: true }, nOneOneNumber: { number: true, min: -1, max: 1, unitless: true }, nonNegativeInt: { number: true, min: 0, integer: true, unitless: true }, position: { enums: ["parent", "origin"] }, nodeSize: { number: true, min: 0, enums: ["label"] }, number: { number: true, unitless: true }, numbers: { number: true, unitless: true, multiple: true }, positiveNumber: { number: true, unitless: true, min: 0, strictMin: true }, size: { number: true, min: 0 }, bidirectionalSize: { number: true }, bidirectionalSizeMaybePercent: { number: true, allowPercent: true }, bidirectionalSizes: { number: true, multiple: true }, sizeMaybePercent: { number: true, min: 0, allowPercent: true }, axisDirection: { enums: ["horizontal", "leftward", "rightward", "vertical", "upward", "downward", "auto"] }, paddingRelativeTo: { enums: ["width", "height", "average", "min", "max"] }, bgWH: { number: true, min: 0, allowPercent: true, enums: ["auto"], multiple: true }, bgPos: { number: true, allowPercent: true, multiple: true }, bgRelativeTo: { enums: ["inner", "include-padding"], multiple: true }, bgRepeat: { enums: ["repeat", "repeat-x", "repeat-y", "no-repeat"], multiple: true }, bgFit: { enums: ["none", "contain", "cover"], multiple: true }, bgCrossOrigin: { enums: ["anonymous", "use-credentials", "null"], multiple: true }, bgClip: { enums: ["none", "node"], multiple: true }, bgContainment: { enums: ["inside", "over"], multiple: true }, color: { color: true }, colors: { color: true, multiple: true }, fill: { enums: ["solid", "linear-gradient", "radial-gradient"] }, bool: { enums: ["yes", "no"] }, bools: { enums: ["yes", "no"], multiple: true }, lineStyle: { enums: ["solid", "dotted", "dashed"] }, lineCap: { enums: ["butt", "round", "square"] }, borderStyle: { enums: ["solid", "dotted", "dashed", "double"] }, curveStyle: { enums: ["bezier", "unbundled-bezier", "haystack", "segments", "straight", "straight-triangle", "taxi"] }, fontFamily: { regex: '^([\\w- \\"]+(?:\\s*,\\s*[\\w- \\"]+)*)$' }, fontStyle: { enums: ["italic", "normal", "oblique"] }, fontWeight: { enums: ["normal", "bold", "bolder", "lighter", "100", "200", "300", "400", "500", "600", "800", "900", 100, 200, 300, 400, 500, 600, 700, 800, 900] }, textDecoration: { enums: ["none", "underline", "overline", "line-through"] }, textTransform: { enums: ["none", "uppercase", "lowercase"] }, textWrap: { enums: ["none", "wrap", "ellipsis"] }, textOverflowWrap: { enums: ["whitespace", "anywhere"] }, textBackgroundShape: { enums: ["rectangle", "roundrectangle", "round-rectangle"] }, nodeShape: { enums: ["rectangle", "roundrectangle", "round-rectangle", "cutrectangle", "cut-rectangle", "bottomroundrectangle", "bottom-round-rectangle", "barrel", "ellipse", "triangle", "round-triangle", "square", "pentagon", "round-pentagon", "hexagon", "round-hexagon", "concavehexagon", "concave-hexagon", "heptagon", "round-heptagon", "octagon", "round-octagon", "tag", "round-tag", "star", "diamond", "round-diamond", "vee", "rhomboid", "right-rhomboid", "polygon"] }, overlayShape: { enums: ["roundrectangle", "round-rectangle", "ellipse"] }, compoundIncludeLabels: { enums: ["include", "exclude"] }, arrowShape: { enums: ["tee", "triangle", "triangle-tee", "circle-triangle", "triangle-cross", "triangle-backcurve", "vee", "square", "circle", "diamond", "chevron", "none"] }, arrowFill: { enums: ["filled", "hollow"] }, display: { enums: ["element", "none"] }, visibility: { enums: ["hidden", "visible"] }, zCompoundDepth: { enums: ["bottom", "orphan", "auto", "top"] }, zIndexCompare: { enums: ["auto", "manual"] }, valign: { enums: ["top", "center", "bottom"] }, halign: { enums: ["left", "center", "right"] }, justification: { enums: ["left", "center", "right", "auto"] }, text: { string: true }, data: { mapping: true, regex: r9("data") }, layoutData: { mapping: true, regex: r9("layoutData") }, scratch: { mapping: true, regex: r9("scratch") }, mapData: { mapping: true, regex: a10("mapData") }, mapLayoutData: { mapping: true, regex: a10("mapLayoutData") }, mapScratch: { mapping: true, regex: a10("mapScratch") }, fn: { mapping: true, fn: true }, url: { regexes: i11, singleRegexMatchValue: true }, urls: { regexes: i11, singleRegexMatchValue: true, multiple: true }, propList: { propList: true }, angle: { number: true, units: "deg|rad", implicitUnits: "rad" }, textRotation: { number: true, units: "deg|rad", implicitUnits: "rad", enums: ["none", "autorotate"] }, polygonPointList: { number: true, multiple: true, evenMultiple: true, min: -1, max: 1, unitless: true }, edgeDistances: { enums: ["intersection", "node-position"] }, edgeEndpoint: { number: true, multiple: true, units: "%|px|em|deg|rad", implicitUnits: "px", enums: ["inside-to-node", "outside-to-node", "outside-to-node-or-label", "outside-to-line", "outside-to-line-or-label"], singleEnum: true, validate: function(e22, t17) {
      switch (e22.length) {
        case 2:
          return "deg" !== t17[0] && "rad" !== t17[0] && "deg" !== t17[1] && "rad" !== t17[1];
        case 1:
          return M6(e22[0]) || "deg" === t17[0] || "rad" === t17[0];
        default:
          return false;
      }
    } }, easing: { regexes: ["^(spring)\\s*\\(\\s*(" + e21 + ")\\s*,\\s*(" + e21 + ")\\s*\\)$", "^(cubic-bezier)\\s*\\(\\s*(" + e21 + ")\\s*,\\s*(" + e21 + ")\\s*,\\s*(" + e21 + ")\\s*,\\s*(" + e21 + ")\\s*\\)$"], enums: ["linear", "ease", "ease-in", "ease-out", "ease-in-out", "ease-in-sine", "ease-out-sine", "ease-in-out-sine", "ease-in-quad", "ease-out-quad", "ease-in-out-quad", "ease-in-cubic", "ease-out-cubic", "ease-in-out-cubic", "ease-in-quart", "ease-out-quart", "ease-in-out-quart", "ease-in-quint", "ease-out-quint", "ease-in-out-quint", "ease-in-expo", "ease-out-expo", "ease-in-out-expo", "ease-in-circ", "ease-out-circ", "ease-in-out-circ"] }, gradientDirection: { enums: ["to-bottom", "to-top", "to-left", "to-right", "to-bottom-right", "to-bottom-left", "to-top-right", "to-top-left", "to-right-bottom", "to-left-bottom", "to-right-top", "to-left-top"] }, boundsExpansion: { number: true, multiple: true, min: 0, validate: function(e22) {
      var t17 = e22.length;
      return 1 === t17 || 2 === t17 || 4 === t17;
    } } };
    var o12 = { zeroNonZero: function(e22, t17) {
      return (null == e22 || null == t17) && e22 !== t17 || (0 == e22 && 0 != t17 || 0 != e22 && 0 == t17);
    }, any: function(e22, t17) {
      return e22 != t17;
    }, emptyNonEmpty: function(e22, t17) {
      var n13 = F6(e22), r10 = F6(t17);
      return n13 && !r10 || !n13 && r10;
    } }, s11 = to.types, l11 = [{ name: "label", type: s11.text, triggersBounds: o12.any, triggersZOrder: o12.emptyNonEmpty }, { name: "text-rotation", type: s11.textRotation, triggersBounds: o12.any }, { name: "text-margin-x", type: s11.bidirectionalSize, triggersBounds: o12.any }, { name: "text-margin-y", type: s11.bidirectionalSize, triggersBounds: o12.any }], u10 = [{ name: "source-label", type: s11.text, triggersBounds: o12.any }, { name: "source-text-rotation", type: s11.textRotation, triggersBounds: o12.any }, { name: "source-text-margin-x", type: s11.bidirectionalSize, triggersBounds: o12.any }, { name: "source-text-margin-y", type: s11.bidirectionalSize, triggersBounds: o12.any }, { name: "source-text-offset", type: s11.size, triggersBounds: o12.any }], c10 = [{ name: "target-label", type: s11.text, triggersBounds: o12.any }, { name: "target-text-rotation", type: s11.textRotation, triggersBounds: o12.any }, { name: "target-text-margin-x", type: s11.bidirectionalSize, triggersBounds: o12.any }, { name: "target-text-margin-y", type: s11.bidirectionalSize, triggersBounds: o12.any }, { name: "target-text-offset", type: s11.size, triggersBounds: o12.any }], d12 = [{ name: "font-family", type: s11.fontFamily, triggersBounds: o12.any }, { name: "font-style", type: s11.fontStyle, triggersBounds: o12.any }, { name: "font-weight", type: s11.fontWeight, triggersBounds: o12.any }, { name: "font-size", type: s11.size, triggersBounds: o12.any }, { name: "text-transform", type: s11.textTransform, triggersBounds: o12.any }, { name: "text-wrap", type: s11.textWrap, triggersBounds: o12.any }, { name: "text-overflow-wrap", type: s11.textOverflowWrap, triggersBounds: o12.any }, { name: "text-max-width", type: s11.size, triggersBounds: o12.any }, { name: "text-outline-width", type: s11.size, triggersBounds: o12.any }, { name: "line-height", type: s11.positiveNumber, triggersBounds: o12.any }], h10 = [{ name: "text-valign", type: s11.valign, triggersBounds: o12.any }, { name: "text-halign", type: s11.halign, triggersBounds: o12.any }, { name: "color", type: s11.color }, { name: "text-outline-color", type: s11.color }, { name: "text-outline-opacity", type: s11.zeroOneNumber }, { name: "text-background-color", type: s11.color }, { name: "text-background-opacity", type: s11.zeroOneNumber }, { name: "text-background-padding", type: s11.size, triggersBounds: o12.any }, { name: "text-border-opacity", type: s11.zeroOneNumber }, { name: "text-border-color", type: s11.color }, { name: "text-border-width", type: s11.size, triggersBounds: o12.any }, { name: "text-border-style", type: s11.borderStyle, triggersBounds: o12.any }, { name: "text-background-shape", type: s11.textBackgroundShape, triggersBounds: o12.any }, { name: "text-justification", type: s11.justification }], p10 = [{ name: "events", type: s11.bool }, { name: "text-events", type: s11.bool }], f11 = [{ name: "display", type: s11.display, triggersZOrder: o12.any, triggersBounds: o12.any, triggersBoundsOfParallelBeziers: true }, { name: "visibility", type: s11.visibility, triggersZOrder: o12.any }, { name: "opacity", type: s11.zeroOneNumber, triggersZOrder: o12.zeroNonZero }, { name: "text-opacity", type: s11.zeroOneNumber }, { name: "min-zoomed-font-size", type: s11.size }, { name: "z-compound-depth", type: s11.zCompoundDepth, triggersZOrder: o12.any }, { name: "z-index-compare", type: s11.zIndexCompare, triggersZOrder: o12.any }, { name: "z-index", type: s11.nonNegativeInt, triggersZOrder: o12.any }], g9 = [{ name: "overlay-padding", type: s11.size, triggersBounds: o12.any }, { name: "overlay-color", type: s11.color }, { name: "overlay-opacity", type: s11.zeroOneNumber, triggersBounds: o12.zeroNonZero }, { name: "overlay-shape", type: s11.overlayShape, triggersBounds: o12.any }], v12 = [{ name: "underlay-padding", type: s11.size, triggersBounds: o12.any }, { name: "underlay-color", type: s11.color }, { name: "underlay-opacity", type: s11.zeroOneNumber, triggersBounds: o12.zeroNonZero }, { name: "underlay-shape", type: s11.overlayShape, triggersBounds: o12.any }], y10 = [{ name: "transition-property", type: s11.propList }, { name: "transition-duration", type: s11.time }, { name: "transition-delay", type: s11.time }, { name: "transition-timing-function", type: s11.easing }], m12 = function(e22, t17) {
      return "label" === t17.value ? -e22.poolIndex() : t17.pfValue;
    }, b11 = [{ name: "height", type: s11.nodeSize, triggersBounds: o12.any, hashOverride: m12 }, { name: "width", type: s11.nodeSize, triggersBounds: o12.any, hashOverride: m12 }, { name: "shape", type: s11.nodeShape, triggersBounds: o12.any }, { name: "shape-polygon-points", type: s11.polygonPointList, triggersBounds: o12.any }, { name: "background-color", type: s11.color }, { name: "background-fill", type: s11.fill }, { name: "background-opacity", type: s11.zeroOneNumber }, { name: "background-blacken", type: s11.nOneOneNumber }, { name: "background-gradient-stop-colors", type: s11.colors }, { name: "background-gradient-stop-positions", type: s11.percentages }, { name: "background-gradient-direction", type: s11.gradientDirection }, { name: "padding", type: s11.sizeMaybePercent, triggersBounds: o12.any }, { name: "padding-relative-to", type: s11.paddingRelativeTo, triggersBounds: o12.any }, { name: "bounds-expansion", type: s11.boundsExpansion, triggersBounds: o12.any }], x10 = [{ name: "border-color", type: s11.color }, { name: "border-opacity", type: s11.zeroOneNumber }, { name: "border-width", type: s11.size, triggersBounds: o12.any }, { name: "border-style", type: s11.borderStyle }], w11 = [{ name: "background-image", type: s11.urls }, { name: "background-image-crossorigin", type: s11.bgCrossOrigin }, { name: "background-image-opacity", type: s11.zeroOneNumbers }, { name: "background-image-containment", type: s11.bgContainment }, { name: "background-image-smoothing", type: s11.bools }, { name: "background-position-x", type: s11.bgPos }, { name: "background-position-y", type: s11.bgPos }, { name: "background-width-relative-to", type: s11.bgRelativeTo }, { name: "background-height-relative-to", type: s11.bgRelativeTo }, { name: "background-repeat", type: s11.bgRepeat }, { name: "background-fit", type: s11.bgFit }, { name: "background-clip", type: s11.bgClip }, { name: "background-width", type: s11.bgWH }, { name: "background-height", type: s11.bgWH }, { name: "background-offset-x", type: s11.bgPos }, { name: "background-offset-y", type: s11.bgPos }], E9 = [{ name: "position", type: s11.position, triggersBounds: o12.any }, { name: "compound-sizing-wrt-labels", type: s11.compoundIncludeLabels, triggersBounds: o12.any }, { name: "min-width", type: s11.size, triggersBounds: o12.any }, { name: "min-width-bias-left", type: s11.sizeMaybePercent, triggersBounds: o12.any }, { name: "min-width-bias-right", type: s11.sizeMaybePercent, triggersBounds: o12.any }, { name: "min-height", type: s11.size, triggersBounds: o12.any }, { name: "min-height-bias-top", type: s11.sizeMaybePercent, triggersBounds: o12.any }, { name: "min-height-bias-bottom", type: s11.sizeMaybePercent, triggersBounds: o12.any }], k10 = [{ name: "line-style", type: s11.lineStyle }, { name: "line-color", type: s11.color }, { name: "line-fill", type: s11.fill }, { name: "line-cap", type: s11.lineCap }, { name: "line-opacity", type: s11.zeroOneNumber }, { name: "line-dash-pattern", type: s11.numbers }, { name: "line-dash-offset", type: s11.number }, { name: "line-gradient-stop-colors", type: s11.colors }, { name: "line-gradient-stop-positions", type: s11.percentages }, { name: "curve-style", type: s11.curveStyle, triggersBounds: o12.any, triggersBoundsOfParallelBeziers: true }, { name: "haystack-radius", type: s11.zeroOneNumber, triggersBounds: o12.any }, { name: "source-endpoint", type: s11.edgeEndpoint, triggersBounds: o12.any }, { name: "target-endpoint", type: s11.edgeEndpoint, triggersBounds: o12.any }, { name: "control-point-step-size", type: s11.size, triggersBounds: o12.any }, { name: "control-point-distances", type: s11.bidirectionalSizes, triggersBounds: o12.any }, { name: "control-point-weights", type: s11.numbers, triggersBounds: o12.any }, { name: "segment-distances", type: s11.bidirectionalSizes, triggersBounds: o12.any }, { name: "segment-weights", type: s11.numbers, triggersBounds: o12.any }, { name: "taxi-turn", type: s11.bidirectionalSizeMaybePercent, triggersBounds: o12.any }, { name: "taxi-turn-min-distance", type: s11.size, triggersBounds: o12.any }, { name: "taxi-direction", type: s11.axisDirection, triggersBounds: o12.any }, { name: "edge-distances", type: s11.edgeDistances, triggersBounds: o12.any }, { name: "arrow-scale", type: s11.positiveNumber, triggersBounds: o12.any }, { name: "loop-direction", type: s11.angle, triggersBounds: o12.any }, { name: "loop-sweep", type: s11.angle, triggersBounds: o12.any }, { name: "source-distance-from-node", type: s11.size, triggersBounds: o12.any }, { name: "target-distance-from-node", type: s11.size, triggersBounds: o12.any }], C9 = [{ name: "ghost", type: s11.bool, triggersBounds: o12.any }, { name: "ghost-offset-x", type: s11.bidirectionalSize, triggersBounds: o12.any }, { name: "ghost-offset-y", type: s11.bidirectionalSize, triggersBounds: o12.any }, { name: "ghost-opacity", type: s11.zeroOneNumber }], S8 = [{ name: "selection-box-color", type: s11.color }, { name: "selection-box-opacity", type: s11.zeroOneNumber }, { name: "selection-box-border-color", type: s11.color }, { name: "selection-box-border-width", type: s11.size }, { name: "active-bg-color", type: s11.color }, { name: "active-bg-opacity", type: s11.zeroOneNumber }, { name: "active-bg-size", type: s11.size }, { name: "outside-texture-bg-color", type: s11.color }, { name: "outside-texture-bg-opacity", type: s11.zeroOneNumber }], D9 = [];
    to.pieBackgroundN = 16, D9.push({ name: "pie-size", type: s11.sizeMaybePercent });
    for (var P10 = 1; P10 <= to.pieBackgroundN; P10++)
      D9.push({ name: "pie-" + P10 + "-background-color", type: s11.color }), D9.push({ name: "pie-" + P10 + "-background-size", type: s11.percent }), D9.push({ name: "pie-" + P10 + "-background-opacity", type: s11.zeroOneNumber });
    var T9 = [], B9 = to.arrowPrefixes = ["source", "mid-source", "target", "mid-target"];
    [{ name: "arrow-shape", type: s11.arrowShape, triggersBounds: o12.any }, { name: "arrow-color", type: s11.color }, { name: "arrow-fill", type: s11.arrowFill }].forEach(function(e22) {
      B9.forEach(function(t17) {
        var n13 = t17 + "-" + e22.name, r10 = e22.type, a11 = e22.triggersBounds;
        T9.push({ name: n13, type: r10, triggersBounds: a11 });
      });
    }, {});
    var _7 = to.properties = [].concat(p10, y10, f11, g9, v12, C9, h10, d12, l11, u10, c10, b11, x10, w11, D9, E9, k10, T9, S8), N8 = to.propertyGroups = { behavior: p10, transition: y10, visibility: f11, overlay: g9, underlay: v12, ghost: C9, commonLabel: h10, labelDimensions: d12, mainLabel: l11, sourceLabel: u10, targetLabel: c10, nodeBody: b11, nodeBorder: x10, backgroundImage: w11, pie: D9, compound: E9, edgeLine: k10, edgeArrow: T9, core: S8 }, I8 = to.propertyGroupNames = {};
    (to.propertyGroupKeys = Object.keys(N8)).forEach(function(e22) {
      I8[e22] = N8[e22].map(function(e23) {
        return e23.name;
      }), N8[e22].forEach(function(t17) {
        return t17.groupKey = e22;
      });
    });
    var z8 = to.aliases = [{ name: "content", pointsTo: "label" }, { name: "control-point-distance", pointsTo: "control-point-distances" }, { name: "control-point-weight", pointsTo: "control-point-weights" }, { name: "edge-text-rotation", pointsTo: "text-rotation" }, { name: "padding-left", pointsTo: "padding" }, { name: "padding-right", pointsTo: "padding" }, { name: "padding-top", pointsTo: "padding" }, { name: "padding-bottom", pointsTo: "padding" }];
    to.propertyNames = _7.map(function(e22) {
      return e22.name;
    });
    for (var L9 = 0; L9 < _7.length; L9++) {
      var A10 = _7[L9];
      _7[A10.name] = A10;
    }
    for (var O10 = 0; O10 < z8.length; O10++) {
      var R8 = z8[O10], V8 = _7[R8.pointsTo], q8 = { name: R8.name, alias: true, pointsTo: V8 };
      _7.push(q8), _7[R8.name] = q8;
    }
  }(), to.getDefaultProperty = function(e21) {
    return this.getDefaultProperties()[e21];
  }, to.getDefaultProperties = function() {
    var e21 = this._private;
    if (null != e21.defaultProperties)
      return e21.defaultProperties;
    for (var t16 = J4({ "selection-box-color": "#ddd", "selection-box-opacity": 0.65, "selection-box-border-color": "#aaa", "selection-box-border-width": 1, "active-bg-color": "black", "active-bg-opacity": 0.15, "active-bg-size": 30, "outside-texture-bg-color": "#000", "outside-texture-bg-opacity": 0.125, events: "yes", "text-events": "no", "text-valign": "top", "text-halign": "center", "text-justification": "auto", "line-height": 1, color: "#000", "text-outline-color": "#000", "text-outline-width": 0, "text-outline-opacity": 1, "text-opacity": 1, "text-decoration": "none", "text-transform": "none", "text-wrap": "none", "text-overflow-wrap": "whitespace", "text-max-width": 9999, "text-background-color": "#000", "text-background-opacity": 0, "text-background-shape": "rectangle", "text-background-padding": 0, "text-border-opacity": 0, "text-border-width": 0, "text-border-style": "solid", "text-border-color": "#000", "font-family": "Helvetica Neue, Helvetica, sans-serif", "font-style": "normal", "font-weight": "normal", "font-size": 16, "min-zoomed-font-size": 0, "text-rotation": "none", "source-text-rotation": "none", "target-text-rotation": "none", visibility: "visible", display: "element", opacity: 1, "z-compound-depth": "auto", "z-index-compare": "auto", "z-index": 0, label: "", "text-margin-x": 0, "text-margin-y": 0, "source-label": "", "source-text-offset": 0, "source-text-margin-x": 0, "source-text-margin-y": 0, "target-label": "", "target-text-offset": 0, "target-text-margin-x": 0, "target-text-margin-y": 0, "overlay-opacity": 0, "overlay-color": "#000", "overlay-padding": 10, "overlay-shape": "round-rectangle", "underlay-opacity": 0, "underlay-color": "#000", "underlay-padding": 10, "underlay-shape": "round-rectangle", "transition-property": "none", "transition-duration": 0, "transition-delay": 0, "transition-timing-function": "linear", "background-blacken": 0, "background-color": "#999", "background-fill": "solid", "background-opacity": 1, "background-image": "none", "background-image-crossorigin": "anonymous", "background-image-opacity": 1, "background-image-containment": "inside", "background-image-smoothing": "yes", "background-position-x": "50%", "background-position-y": "50%", "background-offset-x": 0, "background-offset-y": 0, "background-width-relative-to": "include-padding", "background-height-relative-to": "include-padding", "background-repeat": "no-repeat", "background-fit": "none", "background-clip": "node", "background-width": "auto", "background-height": "auto", "border-color": "#000", "border-opacity": 1, "border-width": 0, "border-style": "solid", height: 30, width: 30, shape: "ellipse", "shape-polygon-points": "-1, -1,   1, -1,   1, 1,   -1, 1", "bounds-expansion": 0, "background-gradient-direction": "to-bottom", "background-gradient-stop-colors": "#999", "background-gradient-stop-positions": "0%", ghost: "no", "ghost-offset-y": 0, "ghost-offset-x": 0, "ghost-opacity": 0, padding: 0, "padding-relative-to": "width", position: "origin", "compound-sizing-wrt-labels": "include", "min-width": 0, "min-width-bias-left": 0, "min-width-bias-right": 0, "min-height": 0, "min-height-bias-top": 0, "min-height-bias-bottom": 0 }, { "pie-size": "100%" }, [{ name: "pie-{{i}}-background-color", value: "black" }, { name: "pie-{{i}}-background-size", value: "0%" }, { name: "pie-{{i}}-background-opacity", value: 1 }].reduce(function(e22, t17) {
      for (var n13 = 1; n13 <= to.pieBackgroundN; n13++) {
        var r10 = t17.name.replace("{{i}}", n13), a11 = t17.value;
        e22[r10] = a11;
      }
      return e22;
    }, {}), { "line-style": "solid", "line-color": "#999", "line-fill": "solid", "line-cap": "butt", "line-opacity": 1, "line-gradient-stop-colors": "#999", "line-gradient-stop-positions": "0%", "control-point-step-size": 40, "control-point-weights": 0.5, "segment-weights": 0.5, "segment-distances": 20, "taxi-turn": "50%", "taxi-turn-min-distance": 10, "taxi-direction": "auto", "edge-distances": "intersection", "curve-style": "haystack", "haystack-radius": 0, "arrow-scale": 1, "loop-direction": "-45deg", "loop-sweep": "-90deg", "source-distance-from-node": 0, "target-distance-from-node": 0, "source-endpoint": "outside-to-node", "target-endpoint": "outside-to-node", "line-dash-pattern": [6, 3], "line-dash-offset": 0 }, [{ name: "arrow-shape", value: "none" }, { name: "arrow-color", value: "#999" }, { name: "arrow-fill", value: "filled" }].reduce(function(e22, t17) {
      return to.arrowPrefixes.forEach(function(n13) {
        var r10 = n13 + "-" + t17.name, a11 = t17.value;
        e22[r10] = a11;
      }), e22;
    }, {})), n12 = {}, r9 = 0; r9 < this.properties.length; r9++) {
      var a10 = this.properties[r9];
      if (!a10.pointsTo) {
        var i11 = a10.name, o12 = t16[i11], s11 = this.parse(i11, o12);
        n12[i11] = s11;
      }
    }
    return e21.defaultProperties = n12, e21.defaultProperties;
  }, to.addDefaultStylesheet = function() {
    this.selector(":parent").css({ shape: "rectangle", padding: 10, "background-color": "#eee", "border-color": "#ccc", "border-width": 1 }).selector("edge").css({ width: 3 }).selector(":loop").css({ "curve-style": "bezier" }).selector("edge:compound").css({ "curve-style": "bezier", "source-endpoint": "outside-to-line", "target-endpoint": "outside-to-line" }).selector(":selected").css({ "background-color": "#0169D9", "line-color": "#0169D9", "source-arrow-color": "#0169D9", "target-arrow-color": "#0169D9", "mid-source-arrow-color": "#0169D9", "mid-target-arrow-color": "#0169D9" }).selector(":parent:selected").css({ "background-color": "#CCE1F9", "border-color": "#aec8e5" }).selector(":active").css({ "overlay-color": "black", "overlay-padding": 10, "overlay-opacity": 0.25 }), this.defaultLength = this.length;
  };
  var no = { parse: function(e21, t16, n12, r9) {
    var a10 = this;
    if (B5(t16))
      return a10.parseImplWarn(e21, t16, n12, r9);
    var i11, o12 = ye(e21, "" + t16, n12 ? "t" : "f", "mapping" === r9 || true === r9 || false === r9 || null == r9 ? "dontcare" : r9), s11 = a10.propCache = a10.propCache || [];
    return (i11 = s11[o12]) || (i11 = s11[o12] = a10.parseImplWarn(e21, t16, n12, r9)), (n12 || "mapping" === r9) && (i11 = Be(i11)) && (i11.value = Be(i11.value)), i11;
  }, parseImplWarn: function(e21, t16, n12, r9) {
    var a10 = this.parseImpl(e21, t16, n12, r9);
    return a10 || null == t16 || Me("The style property `".concat(e21, ": ").concat(t16, "` is invalid")), !a10 || "width" !== a10.name && "height" !== a10.name || "label" !== t16 || Me("The style value of `label` is deprecated for `" + a10.name + "`"), a10;
  } };
  no.parseImpl = function(e21, t16, n12, r9) {
    var a10 = this;
    e21 = Y4(e21);
    var i11 = a10.properties[e21], o12 = t16, s11 = a10.types;
    if (!i11)
      return null;
    if (void 0 === t16)
      return null;
    i11.alias && (i11 = i11.pointsTo, e21 = i11.name);
    var l11 = M6(t16);
    l11 && (t16 = t16.trim());
    var u10, c10, d12 = i11.type;
    if (!d12)
      return null;
    if (n12 && ("" === t16 || null === t16))
      return { name: e21, value: t16, bypass: true, deleteBypass: true };
    if (B5(t16))
      return { name: e21, value: t16, strValue: "fn", mapped: s11.fn, bypass: n12 };
    if (!l11 || r9 || t16.length < 7 || "a" !== t16[1])
      ;
    else {
      if (t16.length >= 7 && "d" === t16[0] && (u10 = new RegExp(s11.data.regex).exec(t16))) {
        if (n12)
          return false;
        var h10 = s11.data;
        return { name: e21, value: u10, strValue: "" + t16, mapped: h10, field: u10[1], bypass: n12 };
      }
      if (t16.length >= 10 && "m" === t16[0] && (c10 = new RegExp(s11.mapData.regex).exec(t16))) {
        if (n12)
          return false;
        if (d12.multiple)
          return false;
        var p10 = s11.mapData;
        if (!d12.color && !d12.number)
          return false;
        var f11 = this.parse(e21, c10[4]);
        if (!f11 || f11.mapped)
          return false;
        var g9 = this.parse(e21, c10[5]);
        if (!g9 || g9.mapped)
          return false;
        if (f11.pfValue === g9.pfValue || f11.strValue === g9.strValue)
          return Me("`" + e21 + ": " + t16 + "` is not a valid mapper because the output range is zero; converting to `" + e21 + ": " + f11.strValue + "`"), this.parse(e21, f11.strValue);
        if (d12.color) {
          var v12 = f11.value, y10 = g9.value;
          if (!(v12[0] !== y10[0] || v12[1] !== y10[1] || v12[2] !== y10[2] || v12[3] !== y10[3] && (null != v12[3] && 1 !== v12[3] || null != y10[3] && 1 !== y10[3])))
            return false;
        }
        return { name: e21, value: c10, strValue: "" + t16, mapped: p10, field: c10[1], fieldMin: parseFloat(c10[2]), fieldMax: parseFloat(c10[3]), valueMin: f11.value, valueMax: g9.value, bypass: n12 };
      }
    }
    if (d12.multiple && "multiple" !== r9) {
      var m12;
      if (m12 = l11 ? t16.split(/\s+/) : _5(t16) ? t16 : [t16], d12.evenMultiple && m12.length % 2 != 0)
        return null;
      for (var b11 = [], x10 = [], w11 = [], E9 = "", k10 = false, C9 = 0; C9 < m12.length; C9++) {
        var S8 = a10.parse(e21, m12[C9], n12, "multiple");
        k10 = k10 || M6(S8.value), b11.push(S8.value), w11.push(null != S8.pfValue ? S8.pfValue : S8.value), x10.push(S8.units), E9 += (C9 > 0 ? " " : "") + S8.strValue;
      }
      return d12.validate && !d12.validate(b11, x10) ? null : d12.singleEnum && k10 ? 1 === b11.length && M6(b11[0]) ? { name: e21, value: b11[0], strValue: b11[0], bypass: n12 } : null : { name: e21, value: b11, pfValue: w11, strValue: E9, bypass: n12, units: x10 };
    }
    var D9, P10, T9 = function() {
      for (var r10 = 0; r10 < d12.enums.length; r10++) {
        if (d12.enums[r10] === t16)
          return { name: e21, value: t16, strValue: "" + t16, bypass: n12 };
      }
      return null;
    };
    if (d12.number) {
      var N8, z8 = "px";
      if (d12.units && (N8 = d12.units), d12.implicitUnits && (z8 = d12.implicitUnits), !d12.unitless)
        if (l11) {
          var L9 = "px|em" + (d12.allowPercent ? "|\\%" : "");
          N8 && (L9 = N8);
          var A10 = t16.match("^(" + K4 + ")(" + L9 + ")?$");
          A10 && (t16 = A10[1], N8 = A10[2] || z8);
        } else
          N8 && !d12.implicitUnits || (N8 = z8);
      if (t16 = parseFloat(t16), isNaN(t16) && void 0 === d12.enums)
        return null;
      if (isNaN(t16) && void 0 !== d12.enums)
        return t16 = o12, T9();
      if (d12.integer && (!I6(P10 = t16) || Math.floor(P10) !== P10))
        return null;
      if (void 0 !== d12.min && (t16 < d12.min || d12.strictMin && t16 === d12.min) || void 0 !== d12.max && (t16 > d12.max || d12.strictMax && t16 === d12.max))
        return null;
      var O10 = { name: e21, value: t16, strValue: "" + t16 + (N8 || ""), units: N8, bypass: n12 };
      return d12.unitless || "px" !== N8 && "em" !== N8 ? O10.pfValue = t16 : O10.pfValue = "px" !== N8 && N8 ? this.getEmSizeInPixels() * t16 : t16, "ms" !== N8 && "s" !== N8 || (O10.pfValue = "ms" === N8 ? t16 : 1e3 * t16), "deg" !== N8 && "rad" !== N8 || (O10.pfValue = "rad" === N8 ? t16 : (D9 = t16, Math.PI * D9 / 180)), "%" === N8 && (O10.pfValue = t16 / 100), O10;
    }
    if (d12.propList) {
      var R8 = [], V8 = "" + t16;
      if ("none" === V8)
        ;
      else {
        for (var F9 = V8.split(/\s*,\s*|\s+/), q8 = 0; q8 < F9.length; q8++) {
          var j9 = F9[q8].trim();
          a10.properties[j9] ? R8.push(j9) : Me("`" + j9 + "` is not a valid property name");
        }
        if (0 === R8.length)
          return null;
      }
      return { name: e21, value: R8, strValue: 0 === R8.length ? "none" : R8.join(" "), bypass: n12 };
    }
    if (d12.color) {
      var X6 = ee(t16);
      return X6 ? { name: e21, value: X6, pfValue: X6, strValue: "rgb(" + X6[0] + "," + X6[1] + "," + X6[2] + ")", bypass: n12 } : null;
    }
    if (d12.regex || d12.regexes) {
      if (d12.enums) {
        var W8 = T9();
        if (W8)
          return W8;
      }
      for (var H8 = d12.regexes ? d12.regexes : [d12.regex], G7 = 0; G7 < H8.length; G7++) {
        var U7 = new RegExp(H8[G7]).exec(t16);
        if (U7)
          return { name: e21, value: d12.singleRegexMatchValue ? U7[1] : U7, strValue: "" + t16, bypass: n12 };
      }
      return null;
    }
    return d12.string ? { name: e21, value: "" + t16, strValue: "" + t16, bypass: n12 } : d12.enums ? T9() : null;
  };
  var ro = function e12(t16) {
    if (!(this instanceof e12))
      return new e12(t16);
    R4(t16) ? (this._private = { cy: t16, coreStyle: {} }, this.length = 0, this.resetToDefault()) : Pe("A style must have a core reference");
  };
  var ao = ro.prototype;
  ao.instanceString = function() {
    return "style";
  }, ao.clear = function() {
    for (var e21 = this._private, t16 = e21.cy.elements(), n12 = 0; n12 < this.length; n12++)
      this[n12] = void 0;
    return this.length = 0, e21.contextStyles = {}, e21.propDiffs = {}, this.cleanElements(t16, true), t16.forEach(function(e22) {
      var t17 = e22[0]._private;
      t17.styleDirty = true, t17.appliedInitStyle = false;
    }), this;
  }, ao.resetToDefault = function() {
    return this.clear(), this.addDefaultStylesheet(), this;
  }, ao.core = function(e21) {
    return this._private.coreStyle[e21] || this.getDefaultProperty(e21);
  }, ao.selector = function(e21) {
    var t16 = "core" === e21 ? null : new Kr(e21), n12 = this.length++;
    return this[n12] = { selector: t16, properties: [], mappedProperties: [], index: n12 }, this;
  }, ao.css = function() {
    var e21 = arguments;
    if (1 === e21.length)
      for (var t16 = e21[0], n12 = 0; n12 < this.properties.length; n12++) {
        var r9 = this.properties[n12], a10 = t16[r9.name];
        void 0 === a10 && (a10 = t16[X4(r9.name)]), void 0 !== a10 && this.cssRule(r9.name, a10);
      }
    else
      2 === e21.length && this.cssRule(e21[0], e21[1]);
    return this;
  }, ao.style = ao.css, ao.cssRule = function(e21, t16) {
    var n12 = this.parse(e21, t16);
    if (n12) {
      var r9 = this.length - 1;
      this[r9].properties.push(n12), this[r9].properties[n12.name] = n12, n12.name.match(/pie-(\d+)-background-size/) && n12.value && (this._private.hasPie = true), n12.mapped && this[r9].mappedProperties.push(n12), !this[r9].selector && (this._private.coreStyle[n12.name] = n12);
    }
    return this;
  }, ao.append = function(e21) {
    return V5(e21) ? e21.appendToStyle(this) : _5(e21) ? this.appendFromJson(e21) : M6(e21) && this.appendFromString(e21), this;
  }, ro.fromJson = function(e21, t16) {
    var n12 = new ro(e21);
    return n12.fromJson(t16), n12;
  }, ro.fromString = function(e21, t16) {
    return new ro(e21).fromString(t16);
  }, [Gi, Zi, $i, Qi, Ji, eo, to, no].forEach(function(e21) {
    J4(ao, e21);
  }), ro.types = ao.types, ro.properties = ao.properties, ro.propertyGroups = ao.propertyGroups, ro.propertyGroupNames = ao.propertyGroupNames, ro.propertyGroupKeys = ao.propertyGroupKeys;
  var io = { style: function(e21) {
    e21 && this.setStyle(e21).update();
    return this._private.style;
  }, setStyle: function(e21) {
    var t16 = this._private;
    return V5(e21) ? t16.style = e21.generateStyle(this) : _5(e21) ? t16.style = ro.fromJson(this, e21) : M6(e21) ? t16.style = ro.fromString(this, e21) : t16.style = ro(this), t16.style;
  }, updateStyle: function() {
    this.mutableElements().updateStyle();
  } };
  var oo = { autolock: function(e21) {
    return void 0 === e21 ? this._private.autolock : (this._private.autolock = !!e21, this);
  }, autoungrabify: function(e21) {
    return void 0 === e21 ? this._private.autoungrabify : (this._private.autoungrabify = !!e21, this);
  }, autounselectify: function(e21) {
    return void 0 === e21 ? this._private.autounselectify : (this._private.autounselectify = !!e21, this);
  }, selectionType: function(e21) {
    var t16 = this._private;
    return null == t16.selectionType && (t16.selectionType = "single"), void 0 === e21 ? t16.selectionType : ("additive" !== e21 && "single" !== e21 || (t16.selectionType = e21), this);
  }, panningEnabled: function(e21) {
    return void 0 === e21 ? this._private.panningEnabled : (this._private.panningEnabled = !!e21, this);
  }, userPanningEnabled: function(e21) {
    return void 0 === e21 ? this._private.userPanningEnabled : (this._private.userPanningEnabled = !!e21, this);
  }, zoomingEnabled: function(e21) {
    return void 0 === e21 ? this._private.zoomingEnabled : (this._private.zoomingEnabled = !!e21, this);
  }, userZoomingEnabled: function(e21) {
    return void 0 === e21 ? this._private.userZoomingEnabled : (this._private.userZoomingEnabled = !!e21, this);
  }, boxSelectionEnabled: function(e21) {
    return void 0 === e21 ? this._private.boxSelectionEnabled : (this._private.boxSelectionEnabled = !!e21, this);
  }, pan: function() {
    var e21, t16, n12, r9, a10, i11 = arguments, o12 = this._private.pan;
    switch (i11.length) {
      case 0:
        return o12;
      case 1:
        if (M6(i11[0]))
          return o12[e21 = i11[0]];
        if (N6(i11[0])) {
          if (!this._private.panningEnabled)
            return this;
          r9 = (n12 = i11[0]).x, a10 = n12.y, I6(r9) && (o12.x = r9), I6(a10) && (o12.y = a10), this.emit("pan viewport");
        }
        break;
      case 2:
        if (!this._private.panningEnabled)
          return this;
        t16 = i11[1], "x" !== (e21 = i11[0]) && "y" !== e21 || !I6(t16) || (o12[e21] = t16), this.emit("pan viewport");
    }
    return this.notify("viewport"), this;
  }, panBy: function(e21, t16) {
    var n12, r9, a10, i11, o12, s11 = arguments, l11 = this._private.pan;
    if (!this._private.panningEnabled)
      return this;
    switch (s11.length) {
      case 1:
        N6(e21) && (i11 = (a10 = s11[0]).x, o12 = a10.y, I6(i11) && (l11.x += i11), I6(o12) && (l11.y += o12), this.emit("pan viewport"));
        break;
      case 2:
        r9 = t16, "x" !== (n12 = e21) && "y" !== n12 || !I6(r9) || (l11[n12] += r9), this.emit("pan viewport");
    }
    return this.notify("viewport"), this;
  }, fit: function(e21, t16) {
    var n12 = this.getFitViewport(e21, t16);
    if (n12) {
      var r9 = this._private;
      r9.zoom = n12.zoom, r9.pan = n12.pan, this.emit("pan zoom viewport"), this.notify("viewport");
    }
    return this;
  }, getFitViewport: function(e21, t16) {
    if (I6(e21) && void 0 === t16 && (t16 = e21, e21 = void 0), this._private.panningEnabled && this._private.zoomingEnabled) {
      var n12, r9;
      if (M6(e21)) {
        var a10 = e21;
        e21 = this.$(a10);
      } else if (N6(r9 = e21) && I6(r9.x1) && I6(r9.x2) && I6(r9.y1) && I6(r9.y2)) {
        var i11 = e21;
        (n12 = { x1: i11.x1, y1: i11.y1, x2: i11.x2, y2: i11.y2 }).w = n12.x2 - n12.x1, n12.h = n12.y2 - n12.y1;
      } else
        L5(e21) || (e21 = this.mutableElements());
      if (!L5(e21) || !e21.empty()) {
        n12 = n12 || e21.boundingBox();
        var o12, s11 = this.width(), l11 = this.height();
        if (t16 = I6(t16) ? t16 : 0, !isNaN(s11) && !isNaN(l11) && s11 > 0 && l11 > 0 && !isNaN(n12.w) && !isNaN(n12.h) && n12.w > 0 && n12.h > 0)
          return { zoom: o12 = (o12 = (o12 = Math.min((s11 - 2 * t16) / n12.w, (l11 - 2 * t16) / n12.h)) > this._private.maxZoom ? this._private.maxZoom : o12) < this._private.minZoom ? this._private.minZoom : o12, pan: { x: (s11 - o12 * (n12.x1 + n12.x2)) / 2, y: (l11 - o12 * (n12.y1 + n12.y2)) / 2 } };
      }
    }
  }, zoomRange: function(e21, t16) {
    var n12 = this._private;
    if (null == t16) {
      var r9 = e21;
      e21 = r9.min, t16 = r9.max;
    }
    return I6(e21) && I6(t16) && e21 <= t16 ? (n12.minZoom = e21, n12.maxZoom = t16) : I6(e21) && void 0 === t16 && e21 <= n12.maxZoom ? n12.minZoom = e21 : I6(t16) && void 0 === e21 && t16 >= n12.minZoom && (n12.maxZoom = t16), this;
  }, minZoom: function(e21) {
    return void 0 === e21 ? this._private.minZoom : this.zoomRange({ min: e21 });
  }, maxZoom: function(e21) {
    return void 0 === e21 ? this._private.maxZoom : this.zoomRange({ max: e21 });
  }, getZoomedViewport: function(e21) {
    var t16, n12, r9 = this._private, a10 = r9.pan, i11 = r9.zoom, o12 = false;
    if (r9.zoomingEnabled || (o12 = true), I6(e21) ? n12 = e21 : N6(e21) && (n12 = e21.level, null != e21.position ? t16 = at4(e21.position, i11, a10) : null != e21.renderedPosition && (t16 = e21.renderedPosition), null == t16 || r9.panningEnabled || (o12 = true)), n12 = (n12 = n12 > r9.maxZoom ? r9.maxZoom : n12) < r9.minZoom ? r9.minZoom : n12, o12 || !I6(n12) || n12 === i11 || null != t16 && (!I6(t16.x) || !I6(t16.y)))
      return null;
    if (null != t16) {
      var s11 = a10, l11 = i11, u10 = n12;
      return { zoomed: true, panned: true, zoom: u10, pan: { x: -u10 / l11 * (t16.x - s11.x) + t16.x, y: -u10 / l11 * (t16.y - s11.y) + t16.y } };
    }
    return { zoomed: true, panned: false, zoom: n12, pan: a10 };
  }, zoom: function(e21) {
    if (void 0 === e21)
      return this._private.zoom;
    var t16 = this.getZoomedViewport(e21), n12 = this._private;
    return null != t16 && t16.zoomed ? (n12.zoom = t16.zoom, t16.panned && (n12.pan.x = t16.pan.x, n12.pan.y = t16.pan.y), this.emit("zoom" + (t16.panned ? " pan" : "") + " viewport"), this.notify("viewport"), this) : this;
  }, viewport: function(e21) {
    var t16 = this._private, n12 = true, r9 = true, a10 = [], i11 = false, o12 = false;
    if (!e21)
      return this;
    if (I6(e21.zoom) || (n12 = false), N6(e21.pan) || (r9 = false), !n12 && !r9)
      return this;
    if (n12) {
      var s11 = e21.zoom;
      s11 < t16.minZoom || s11 > t16.maxZoom || !t16.zoomingEnabled ? i11 = true : (t16.zoom = s11, a10.push("zoom"));
    }
    if (r9 && (!i11 || !e21.cancelOnFailedZoom) && t16.panningEnabled) {
      var l11 = e21.pan;
      I6(l11.x) && (t16.pan.x = l11.x, o12 = false), I6(l11.y) && (t16.pan.y = l11.y, o12 = false), o12 || a10.push("pan");
    }
    return a10.length > 0 && (a10.push("viewport"), this.emit(a10.join(" ")), this.notify("viewport")), this;
  }, center: function(e21) {
    var t16 = this.getCenterPan(e21);
    return t16 && (this._private.pan = t16, this.emit("pan viewport"), this.notify("viewport")), this;
  }, getCenterPan: function(e21, t16) {
    if (this._private.panningEnabled) {
      if (M6(e21)) {
        var n12 = e21;
        e21 = this.mutableElements().filter(n12);
      } else
        L5(e21) || (e21 = this.mutableElements());
      if (0 !== e21.length) {
        var r9 = e21.boundingBox(), a10 = this.width(), i11 = this.height();
        return { x: (a10 - (t16 = void 0 === t16 ? this._private.zoom : t16) * (r9.x1 + r9.x2)) / 2, y: (i11 - t16 * (r9.y1 + r9.y2)) / 2 };
      }
    }
  }, reset: function() {
    return this._private.panningEnabled && this._private.zoomingEnabled ? (this.viewport({ pan: { x: 0, y: 0 }, zoom: 1 }), this) : this;
  }, invalidateSize: function() {
    this._private.sizeCache = null;
  }, size: function() {
    var e21, t16, n12 = this._private, r9 = n12.container, a10 = this;
    return n12.sizeCache = n12.sizeCache || (r9 ? (e21 = a10.window().getComputedStyle(r9), t16 = function(t17) {
      return parseFloat(e21.getPropertyValue(t17));
    }, { width: r9.clientWidth - t16("padding-left") - t16("padding-right"), height: r9.clientHeight - t16("padding-top") - t16("padding-bottom") }) : { width: 1, height: 1 });
  }, width: function() {
    return this.size().width;
  }, height: function() {
    return this.size().height;
  }, extent: function() {
    var e21 = this._private.pan, t16 = this._private.zoom, n12 = this.renderedExtent(), r9 = { x1: (n12.x1 - e21.x) / t16, x2: (n12.x2 - e21.x) / t16, y1: (n12.y1 - e21.y) / t16, y2: (n12.y2 - e21.y) / t16 };
    return r9.w = r9.x2 - r9.x1, r9.h = r9.y2 - r9.y1, r9;
  }, renderedExtent: function() {
    var e21 = this.width(), t16 = this.height();
    return { x1: 0, y1: 0, x2: e21, y2: t16, w: e21, h: t16 };
  }, multiClickDebounceTime: function(e21) {
    return e21 ? (this._private.multiClickDebounceTime = e21, this) : this._private.multiClickDebounceTime;
  } };
  oo.centre = oo.center, oo.autolockNodes = oo.autolock, oo.autoungrabifyNodes = oo.autoungrabify;
  var so = { data: ur3.data({ field: "data", bindingEvent: "data", allowBinding: true, allowSetting: true, settingEvent: "data", settingTriggersEvent: true, triggerFnName: "trigger", allowGetting: true, updateStyle: true }), removeData: ur3.removeData({ field: "data", event: "data", triggerFnName: "trigger", triggerEvent: true, updateStyle: true }), scratch: ur3.data({ field: "scratch", bindingEvent: "scratch", allowBinding: true, allowSetting: true, settingEvent: "scratch", settingTriggersEvent: true, triggerFnName: "trigger", allowGetting: true, updateStyle: true }), removeScratch: ur3.removeData({ field: "scratch", event: "scratch", triggerFnName: "trigger", triggerEvent: true, updateStyle: true }) };
  so.attr = so.data, so.removeAttr = so.removeData;
  var lo = function(e21) {
    var t16 = this, n12 = (e21 = J4({}, e21)).container;
    n12 && !z5(n12) && z5(n12[0]) && (n12 = n12[0]);
    var r9 = n12 ? n12._cyreg : null;
    (r9 = r9 || {}) && r9.cy && (r9.cy.destroy(), r9 = {});
    var a10 = r9.readies = r9.readies || [];
    n12 && (n12._cyreg = r9), r9.cy = t16;
    var i11 = void 0 !== E6 && void 0 !== n12 && !e21.headless, o12 = e21;
    o12.layout = J4({ name: i11 ? "grid" : "null" }, o12.layout), o12.renderer = J4({ name: i11 ? "canvas" : "null" }, o12.renderer);
    var s11 = function(e22, t17, n13) {
      return void 0 !== t17 ? t17 : void 0 !== n13 ? n13 : e22;
    }, l11 = this._private = { container: n12, ready: false, options: o12, elements: new Ci(this), listeners: [], aniEles: new Ci(this), data: o12.data || {}, scratch: {}, layout: null, renderer: null, destroyed: false, notificationsEnabled: true, minZoom: 1e-50, maxZoom: 1e50, zoomingEnabled: s11(true, o12.zoomingEnabled), userZoomingEnabled: s11(true, o12.userZoomingEnabled), panningEnabled: s11(true, o12.panningEnabled), userPanningEnabled: s11(true, o12.userPanningEnabled), boxSelectionEnabled: s11(true, o12.boxSelectionEnabled), autolock: s11(false, o12.autolock, o12.autolockNodes), autoungrabify: s11(false, o12.autoungrabify, o12.autoungrabifyNodes), autounselectify: s11(false, o12.autounselectify), styleEnabled: void 0 === o12.styleEnabled ? i11 : o12.styleEnabled, zoom: I6(o12.zoom) ? o12.zoom : 1, pan: { x: N6(o12.pan) && I6(o12.pan.x) ? o12.pan.x : 0, y: N6(o12.pan) && I6(o12.pan.y) ? o12.pan.y : 0 }, animation: { current: [], queue: [] }, hasCompoundNodes: false, multiClickDebounceTime: s11(250, o12.multiClickDebounceTime) };
    this.createEmitter(), this.selectionType(o12.selectionType), this.zoomRange({ min: o12.minZoom, max: o12.maxZoom });
    l11.styleEnabled && t16.setStyle([]);
    var u10 = J4({}, o12, o12.renderer);
    t16.initRenderer(u10);
    !function(e22, t17) {
      if (e22.some(q5))
        return rr4.all(e22).then(t17);
      t17(e22);
    }([o12.style, o12.elements], function(e22) {
      var n13 = e22[0], i12 = e22[1];
      l11.styleEnabled && t16.style().append(n13), function(e23, n14, r10) {
        t16.notifications(false);
        var a11 = t16.mutableElements();
        a11.length > 0 && a11.remove(), null != e23 && (N6(e23) || _5(e23)) && t16.add(e23), t16.one("layoutready", function(e24) {
          t16.notifications(true), t16.emit(e24), t16.one("load", n14), t16.emitAndNotify("load");
        }).one("layoutstop", function() {
          t16.one("done", r10), t16.emit("done");
        });
        var i13 = J4({}, t16._private.options.layout);
        i13.eles = t16.elements(), t16.layout(i13).run();
      }(i12, function() {
        t16.startAnimationLoop(), l11.ready = true, B5(o12.ready) && t16.on("ready", o12.ready);
        for (var e23 = 0; e23 < a10.length; e23++) {
          var n14 = a10[e23];
          t16.on("ready", n14);
        }
        r9 && (r9.readies = []), t16.emit("ready");
      }, o12.done);
    });
  };
  var uo = lo.prototype;
  J4(uo, { instanceString: function() {
    return "core";
  }, isReady: function() {
    return this._private.ready;
  }, destroyed: function() {
    return this._private.destroyed;
  }, ready: function(e21) {
    return this.isReady() ? this.emitter().emit("ready", [], e21) : this.on("ready", e21), this;
  }, destroy: function() {
    var e21 = this;
    if (!e21.destroyed())
      return e21.stopAnimationLoop(), e21.destroyRenderer(), this.emit("destroy"), e21._private.destroyed = true, e21;
  }, hasElementWithId: function(e21) {
    return this._private.elements.hasElementWithId(e21);
  }, getElementById: function(e21) {
    return this._private.elements.getElementById(e21);
  }, hasCompoundNodes: function() {
    return this._private.hasCompoundNodes;
  }, headless: function() {
    return this._private.renderer.isHeadless();
  }, styleEnabled: function() {
    return this._private.styleEnabled;
  }, addToPool: function(e21) {
    return this._private.elements.merge(e21), this;
  }, removeFromPool: function(e21) {
    return this._private.elements.unmerge(e21), this;
  }, container: function() {
    return this._private.container || null;
  }, window: function() {
    if (null == this._private.container)
      return E6;
    var e21 = this._private.container.ownerDocument;
    return void 0 === e21 || null == e21 ? E6 : e21.defaultView || E6;
  }, mount: function(e21) {
    if (null != e21) {
      var t16 = this, n12 = t16._private, r9 = n12.options;
      return !z5(e21) && z5(e21[0]) && (e21 = e21[0]), t16.stopAnimationLoop(), t16.destroyRenderer(), n12.container = e21, n12.styleEnabled = true, t16.invalidateSize(), t16.initRenderer(J4({}, r9, r9.renderer, { name: "null" === r9.renderer.name ? "canvas" : r9.renderer.name })), t16.startAnimationLoop(), t16.style(r9.style), t16.emit("mount"), t16;
    }
  }, unmount: function() {
    var e21 = this;
    return e21.stopAnimationLoop(), e21.destroyRenderer(), e21.initRenderer({ name: "null" }), e21.emit("unmount"), e21;
  }, options: function() {
    return Be(this._private.options);
  }, json: function(e21) {
    var t16 = this, n12 = t16._private, r9 = t16.mutableElements();
    if (N6(e21)) {
      if (t16.startBatch(), e21.elements) {
        var a10 = {}, i11 = function(e22, n13) {
          for (var r10 = [], i12 = [], o13 = 0; o13 < e22.length; o13++) {
            var s12 = e22[o13];
            if (s12.data.id) {
              var l12 = "" + s12.data.id, u11 = t16.getElementById(l12);
              a10[l12] = true, 0 !== u11.length ? i12.push({ ele: u11, json: s12 }) : n13 ? (s12.group = n13, r10.push(s12)) : r10.push(s12);
            } else
              Me("cy.json() cannot handle elements without an ID attribute");
          }
          t16.add(r10);
          for (var c11 = 0; c11 < i12.length; c11++) {
            var d13 = i12[c11], h11 = d13.ele, p11 = d13.json;
            h11.json(p11);
          }
        };
        if (_5(e21.elements))
          i11(e21.elements);
        else
          for (var o12 = ["nodes", "edges"], s11 = 0; s11 < o12.length; s11++) {
            var l11 = o12[s11], u10 = e21.elements[l11];
            _5(u10) && i11(u10, l11);
          }
        var c10 = t16.collection();
        r9.filter(function(e22) {
          return !a10[e22.id()];
        }).forEach(function(e22) {
          e22.isParent() ? c10.merge(e22) : e22.remove();
        }), c10.forEach(function(e22) {
          return e22.children().move({ parent: null });
        }), c10.forEach(function(e22) {
          return function(e23) {
            return t16.getElementById(e23.id());
          }(e22).remove();
        });
      }
      e21.style && t16.style(e21.style), null != e21.zoom && e21.zoom !== n12.zoom && t16.zoom(e21.zoom), e21.pan && (e21.pan.x === n12.pan.x && e21.pan.y === n12.pan.y || t16.pan(e21.pan)), e21.data && t16.data(e21.data);
      for (var d12 = ["minZoom", "maxZoom", "zoomingEnabled", "userZoomingEnabled", "panningEnabled", "userPanningEnabled", "boxSelectionEnabled", "autolock", "autoungrabify", "autounselectify", "multiClickDebounceTime"], h10 = 0; h10 < d12.length; h10++) {
        var p10 = d12[h10];
        null != e21[p10] && t16[p10](e21[p10]);
      }
      return t16.endBatch(), this;
    }
    var f11 = {};
    !!e21 ? f11.elements = this.elements().map(function(e22) {
      return e22.json();
    }) : (f11.elements = {}, r9.forEach(function(e22) {
      var t17 = e22.group();
      f11.elements[t17] || (f11.elements[t17] = []), f11.elements[t17].push(e22.json());
    })), this._private.styleEnabled && (f11.style = t16.style().json()), f11.data = Be(t16.data());
    var g9 = n12.options;
    return f11.zoomingEnabled = n12.zoomingEnabled, f11.userZoomingEnabled = n12.userZoomingEnabled, f11.zoom = n12.zoom, f11.minZoom = n12.minZoom, f11.maxZoom = n12.maxZoom, f11.panningEnabled = n12.panningEnabled, f11.userPanningEnabled = n12.userPanningEnabled, f11.pan = Be(n12.pan), f11.boxSelectionEnabled = n12.boxSelectionEnabled, f11.renderer = Be(g9.renderer), f11.hideEdgesOnViewport = g9.hideEdgesOnViewport, f11.textureOnViewport = g9.textureOnViewport, f11.wheelSensitivity = g9.wheelSensitivity, f11.motionBlur = g9.motionBlur, f11.multiClickDebounceTime = g9.multiClickDebounceTime, f11;
  } }), uo.$id = uo.getElementById, [Di, Ri, qi, ji, Yi, Xi, Hi, Ki, io, oo, so].forEach(function(e21) {
    J4(uo, e21);
  });
  var co = { fit: true, directed: false, padding: 30, circle: false, grid: false, spacingFactor: 1.75, boundingBox: void 0, avoidOverlap: true, nodeDimensionsIncludeLabels: false, roots: void 0, depthSort: void 0, animate: false, animationDuration: 500, animationEasing: void 0, animateFilter: function(e21, t16) {
    return true;
  }, ready: void 0, stop: void 0, transform: function(e21, t16) {
    return t16;
  } };
  var ho = { maximal: false, acyclic: false };
  var po = function(e21) {
    return e21.scratch("breadthfirst");
  };
  var fo = function(e21, t16) {
    return e21.scratch("breadthfirst", t16);
  };
  function go(e21) {
    this.options = J4({}, co, ho, e21);
  }
  go.prototype.run = function() {
    var e21, t16 = this.options, n12 = t16, r9 = t16.cy, a10 = n12.eles, i11 = a10.nodes().filter(function(e22) {
      return !e22.isParent();
    }), o12 = a10, s11 = n12.directed, l11 = n12.acyclic || n12.maximal || n12.maximalAdjustments > 0, u10 = vt4(n12.boundingBox ? n12.boundingBox : { x1: 0, y1: 0, w: r9.width(), h: r9.height() });
    if (L5(n12.roots))
      e21 = n12.roots;
    else if (_5(n12.roots)) {
      for (var c10 = [], d12 = 0; d12 < n12.roots.length; d12++) {
        var h10 = n12.roots[d12], p10 = r9.getElementById(h10);
        c10.push(p10);
      }
      e21 = r9.collection(c10);
    } else if (M6(n12.roots))
      e21 = r9.$(n12.roots);
    else if (s11)
      e21 = i11.roots();
    else {
      var f11 = a10.components();
      e21 = r9.collection();
      for (var g9 = function(t17) {
        var n13 = f11[t17], r10 = n13.maxDegree(false), a11 = n13.filter(function(e22) {
          return e22.degree(false) === r10;
        });
        e21 = e21.add(a11);
      }, v12 = 0; v12 < f11.length; v12++)
        g9(v12);
    }
    var y10 = [], m12 = {}, b11 = function(e22, t17) {
      null == y10[t17] && (y10[t17] = []);
      var n13 = y10[t17].length;
      y10[t17].push(e22), fo(e22, { index: n13, depth: t17 });
    };
    o12.bfs({ roots: e21, directed: n12.directed, visit: function(e22, t17, n13, r10, a11) {
      var i12 = e22[0], o13 = i12.id();
      b11(i12, a11), m12[o13] = true;
    } });
    for (var x10 = [], w11 = 0; w11 < i11.length; w11++) {
      var E9 = i11[w11];
      m12[E9.id()] || x10.push(E9);
    }
    var k10 = function(e22) {
      for (var t17 = y10[e22], n13 = 0; n13 < t17.length; n13++) {
        var r10 = t17[n13];
        null != r10 ? fo(r10, { depth: e22, index: n13 }) : (t17.splice(n13, 1), n13--);
      }
    }, C9 = function() {
      for (var e22 = 0; e22 < y10.length; e22++)
        k10(e22);
    }, S8 = function(e22, t17) {
      for (var r10 = po(e22), i12 = e22.incomers().filter(function(e23) {
        return e23.isNode() && a10.has(e23);
      }), o13 = -1, s12 = e22.id(), l12 = 0; l12 < i12.length; l12++) {
        var u11 = i12[l12], c11 = po(u11);
        o13 = Math.max(o13, c11.depth);
      }
      if (r10.depth <= o13) {
        if (!n12.acyclic && t17[s12])
          return null;
        var d13 = o13 + 1;
        return function(e23, t18) {
          var n13 = po(e23), r11 = n13.depth, a11 = n13.index;
          y10[r11][a11] = null, b11(e23, t18);
        }(e22, d13), t17[s12] = d13, true;
      }
      return false;
    };
    if (s11 && l11) {
      var D9 = [], P10 = {}, T9 = function(e22) {
        return D9.push(e22);
      };
      for (i11.forEach(function(e22) {
        return D9.push(e22);
      }); D9.length > 0; ) {
        var B9 = D9.shift(), N8 = S8(B9, P10);
        if (N8)
          B9.outgoers().filter(function(e22) {
            return e22.isNode() && a10.has(e22);
          }).forEach(T9);
        else if (null === N8) {
          Me("Detected double maximal shift for node `" + B9.id() + "`.  Bailing maximal adjustment due to cycle.  Use `options.maximal: true` only on DAGs.");
          break;
        }
      }
    }
    C9();
    var I8 = 0;
    if (n12.avoidOverlap)
      for (var z8 = 0; z8 < i11.length; z8++) {
        var A10 = i11[z8].layoutDimensions(n12), O10 = A10.w, R8 = A10.h;
        I8 = Math.max(I8, O10, R8);
      }
    var V8 = {}, F9 = function(e22) {
      if (V8[e22.id()])
        return V8[e22.id()];
      for (var t17 = po(e22).depth, n13 = e22.neighborhood(), r10 = 0, a11 = 0, o13 = 0; o13 < n13.length; o13++) {
        var s12 = n13[o13];
        if (!s12.isEdge() && !s12.isParent() && i11.has(s12)) {
          var l12 = po(s12);
          if (null != l12) {
            var u11 = l12.index, c11 = l12.depth;
            if (null != u11 && null != c11) {
              var d13 = y10[c11].length;
              c11 < t17 && (r10 += u11 / d13, a11++);
            }
          }
        }
      }
      return r10 /= a11 = Math.max(1, a11), 0 === a11 && (r10 = 0), V8[e22.id()] = r10, r10;
    }, q8 = function(e22, t17) {
      var n13 = F9(e22) - F9(t17);
      return 0 === n13 ? Q4(e22.id(), t17.id()) : n13;
    };
    void 0 !== n12.depthSort && (q8 = n12.depthSort);
    for (var j9 = 0; j9 < y10.length; j9++)
      y10[j9].sort(q8), k10(j9);
    for (var Y6 = [], X6 = 0; X6 < x10.length; X6++)
      Y6.push(x10[X6]);
    y10.unshift(Y6), C9();
    for (var W8 = 0, H8 = 0; H8 < y10.length; H8++)
      W8 = Math.max(y10[H8].length, W8);
    var K6 = u10.x1 + u10.w / 2, G7 = u10.x1 + u10.h / 2, U7 = y10.reduce(function(e22, t17) {
      return Math.max(e22, t17.length);
    }, 0);
    return a10.nodes().layoutPositions(this, n12, function(e22) {
      var t17 = po(e22), r10 = t17.depth, a11 = t17.index, i12 = y10[r10].length, o13 = Math.max(u10.w / ((n12.grid ? U7 : i12) + 1), I8), s12 = Math.max(u10.h / (y10.length + 1), I8), l12 = Math.min(u10.w / 2 / y10.length, u10.h / 2 / y10.length);
      if (l12 = Math.max(l12, I8), n12.circle) {
        var c11 = l12 * r10 + l12 - (y10.length > 0 && y10[0].length <= 3 ? l12 / 2 : 0), d13 = 2 * Math.PI / y10[r10].length * a11;
        return 0 === r10 && 1 === y10[0].length && (c11 = 1), { x: K6 + c11 * Math.cos(d13), y: G7 + c11 * Math.sin(d13) };
      }
      return { x: K6 + (a11 + 1 - (i12 + 1) / 2) * o13, y: (r10 + 1) * s12 };
    }), this;
  };
  var vo = { fit: true, padding: 30, boundingBox: void 0, avoidOverlap: true, nodeDimensionsIncludeLabels: false, spacingFactor: void 0, radius: void 0, startAngle: 1.5 * Math.PI, sweep: void 0, clockwise: true, sort: void 0, animate: false, animationDuration: 500, animationEasing: void 0, animateFilter: function(e21, t16) {
    return true;
  }, ready: void 0, stop: void 0, transform: function(e21, t16) {
    return t16;
  } };
  function yo(e21) {
    this.options = J4({}, vo, e21);
  }
  yo.prototype.run = function() {
    var e21 = this.options, t16 = e21, n12 = e21.cy, r9 = t16.eles, a10 = void 0 !== t16.counterclockwise ? !t16.counterclockwise : t16.clockwise, i11 = r9.nodes().not(":parent");
    t16.sort && (i11 = i11.sort(t16.sort));
    for (var o12, s11 = vt4(t16.boundingBox ? t16.boundingBox : { x1: 0, y1: 0, w: n12.width(), h: n12.height() }), l11 = s11.x1 + s11.w / 2, u10 = s11.y1 + s11.h / 2, c10 = (void 0 === t16.sweep ? 2 * Math.PI - 2 * Math.PI / i11.length : t16.sweep) / Math.max(1, i11.length - 1), d12 = 0, h10 = 0; h10 < i11.length; h10++) {
      var p10 = i11[h10].layoutDimensions(t16), f11 = p10.w, g9 = p10.h;
      d12 = Math.max(d12, f11, g9);
    }
    if (o12 = I6(t16.radius) ? t16.radius : i11.length <= 1 ? 0 : Math.min(s11.h, s11.w) / 2 - d12, i11.length > 1 && t16.avoidOverlap) {
      d12 *= 1.75;
      var v12 = Math.cos(c10) - Math.cos(0), y10 = Math.sin(c10) - Math.sin(0), m12 = Math.sqrt(d12 * d12 / (v12 * v12 + y10 * y10));
      o12 = Math.max(m12, o12);
    }
    return r9.nodes().layoutPositions(this, t16, function(e22, n13) {
      var r10 = t16.startAngle + n13 * c10 * (a10 ? 1 : -1), i12 = o12 * Math.cos(r10), s12 = o12 * Math.sin(r10);
      return { x: l11 + i12, y: u10 + s12 };
    }), this;
  };
  var mo;
  var bo = { fit: true, padding: 30, startAngle: 1.5 * Math.PI, sweep: void 0, clockwise: true, equidistant: false, minNodeSpacing: 10, boundingBox: void 0, avoidOverlap: true, nodeDimensionsIncludeLabels: false, height: void 0, width: void 0, spacingFactor: void 0, concentric: function(e21) {
    return e21.degree();
  }, levelWidth: function(e21) {
    return e21.maxDegree() / 4;
  }, animate: false, animationDuration: 500, animationEasing: void 0, animateFilter: function(e21, t16) {
    return true;
  }, ready: void 0, stop: void 0, transform: function(e21, t16) {
    return t16;
  } };
  function xo(e21) {
    this.options = J4({}, bo, e21);
  }
  xo.prototype.run = function() {
    for (var e21 = this.options, t16 = e21, n12 = void 0 !== t16.counterclockwise ? !t16.counterclockwise : t16.clockwise, r9 = e21.cy, a10 = t16.eles, i11 = a10.nodes().not(":parent"), o12 = vt4(t16.boundingBox ? t16.boundingBox : { x1: 0, y1: 0, w: r9.width(), h: r9.height() }), s11 = o12.x1 + o12.w / 2, l11 = o12.y1 + o12.h / 2, u10 = [], c10 = 0, d12 = 0; d12 < i11.length; d12++) {
      var h10, p10 = i11[d12];
      h10 = t16.concentric(p10), u10.push({ value: h10, node: p10 }), p10._private.scratch.concentric = h10;
    }
    i11.updateStyle();
    for (var f11 = 0; f11 < i11.length; f11++) {
      var g9 = i11[f11].layoutDimensions(t16);
      c10 = Math.max(c10, g9.w, g9.h);
    }
    u10.sort(function(e22, t17) {
      return t17.value - e22.value;
    });
    for (var v12 = t16.levelWidth(i11), y10 = [[]], m12 = y10[0], b11 = 0; b11 < u10.length; b11++) {
      var x10 = u10[b11];
      if (m12.length > 0)
        Math.abs(m12[0].value - x10.value) >= v12 && (m12 = [], y10.push(m12));
      m12.push(x10);
    }
    var w11 = c10 + t16.minNodeSpacing;
    if (!t16.avoidOverlap) {
      var E9 = y10.length > 0 && y10[0].length > 1, k10 = (Math.min(o12.w, o12.h) / 2 - w11) / (y10.length + E9 ? 1 : 0);
      w11 = Math.min(w11, k10);
    }
    for (var C9 = 0, S8 = 0; S8 < y10.length; S8++) {
      var D9 = y10[S8], P10 = void 0 === t16.sweep ? 2 * Math.PI - 2 * Math.PI / D9.length : t16.sweep, T9 = D9.dTheta = P10 / Math.max(1, D9.length - 1);
      if (D9.length > 1 && t16.avoidOverlap) {
        var M9 = Math.cos(T9) - Math.cos(0), B9 = Math.sin(T9) - Math.sin(0), _7 = Math.sqrt(w11 * w11 / (M9 * M9 + B9 * B9));
        C9 = Math.max(_7, C9);
      }
      D9.r = C9, C9 += w11;
    }
    if (t16.equidistant) {
      for (var N8 = 0, I8 = 0, z8 = 0; z8 < y10.length; z8++) {
        var L9 = y10[z8].r - I8;
        N8 = Math.max(N8, L9);
      }
      I8 = 0;
      for (var A10 = 0; A10 < y10.length; A10++) {
        var O10 = y10[A10];
        0 === A10 && (I8 = O10.r), O10.r = I8, I8 += N8;
      }
    }
    for (var R8 = {}, V8 = 0; V8 < y10.length; V8++)
      for (var F9 = y10[V8], q8 = F9.dTheta, j9 = F9.r, Y6 = 0; Y6 < F9.length; Y6++) {
        var X6 = F9[Y6], W8 = t16.startAngle + (n12 ? 1 : -1) * q8 * Y6, H8 = { x: s11 + j9 * Math.cos(W8), y: l11 + j9 * Math.sin(W8) };
        R8[X6.node.id()] = H8;
      }
    return a10.nodes().layoutPositions(this, t16, function(e22) {
      var t17 = e22.id();
      return R8[t17];
    }), this;
  };
  var wo = { ready: function() {
  }, stop: function() {
  }, animate: true, animationEasing: void 0, animationDuration: void 0, animateFilter: function(e21, t16) {
    return true;
  }, animationThreshold: 250, refresh: 20, fit: true, padding: 30, boundingBox: void 0, nodeDimensionsIncludeLabels: false, randomize: false, componentSpacing: 40, nodeRepulsion: function(e21) {
    return 2048;
  }, nodeOverlap: 4, idealEdgeLength: function(e21) {
    return 32;
  }, edgeElasticity: function(e21) {
    return 32;
  }, nestingFactor: 1.2, gravity: 1, numIter: 1e3, initialTemp: 1e3, coolingFactor: 0.99, minTemp: 1 };
  function Eo(e21) {
    this.options = J4({}, wo, e21), this.options.layout = this;
  }
  Eo.prototype.run = function() {
    var e21 = this.options, t16 = e21.cy, n12 = this;
    n12.stopped = false, true !== e21.animate && false !== e21.animate || n12.emit({ type: "layoutstart", layout: n12 }), mo = true === e21.debug;
    var r9 = ko(t16, n12, e21);
    mo && (void 0)(r9), e21.randomize && Do(r9);
    var a10 = le(), i11 = function() {
      To(r9, t16, e21), true === e21.fit && t16.fit(e21.padding);
    }, o12 = function(t17) {
      return !(n12.stopped || t17 >= e21.numIter) && (Mo(r9, e21), r9.temperature = r9.temperature * e21.coolingFactor, !(r9.temperature < e21.minTemp));
    }, s11 = function() {
      if (true === e21.animate || false === e21.animate)
        i11(), n12.one("layoutstop", e21.stop), n12.emit({ type: "layoutstop", layout: n12 });
      else {
        var t17 = e21.eles.nodes(), a11 = Po(r9, e21, t17);
        t17.layoutPositions(n12, e21, a11);
      }
    }, l11 = 0, u10 = true;
    if (true === e21.animate) {
      !function t17() {
        for (var n13 = 0; u10 && n13 < e21.refresh; )
          u10 = o12(l11), l11++, n13++;
        u10 ? (le() - a10 >= e21.animationThreshold && i11(), se(t17)) : (qo(r9, e21), s11());
      }();
    } else {
      for (; u10; )
        u10 = o12(l11), l11++;
      qo(r9, e21), s11();
    }
    return this;
  }, Eo.prototype.stop = function() {
    return this.stopped = true, this.thread && this.thread.stop(), this.emit("layoutstop"), this;
  }, Eo.prototype.destroy = function() {
    return this.thread && this.thread.stop(), this;
  };
  var ko = function(e21, t16, n12) {
    for (var r9 = n12.eles.edges(), a10 = n12.eles.nodes(), i11 = vt4(n12.boundingBox ? n12.boundingBox : { x1: 0, y1: 0, w: e21.width(), h: e21.height() }), o12 = { isCompound: e21.hasCompoundNodes(), layoutNodes: [], idToIndex: {}, nodeSize: a10.size(), graphSet: [], indexToGraph: [], layoutEdges: [], edgeSize: r9.size(), temperature: n12.initialTemp, clientWidth: i11.w, clientHeight: i11.h, boundingBox: i11 }, s11 = n12.eles.components(), l11 = {}, u10 = 0; u10 < s11.length; u10++)
      for (var c10 = s11[u10], d12 = 0; d12 < c10.length; d12++) {
        l11[c10[d12].id()] = u10;
      }
    for (u10 = 0; u10 < o12.nodeSize; u10++) {
      var h10 = (y10 = a10[u10]).layoutDimensions(n12);
      (z8 = {}).isLocked = y10.locked(), z8.id = y10.data("id"), z8.parentId = y10.data("parent"), z8.cmptId = l11[y10.id()], z8.children = [], z8.positionX = y10.position("x"), z8.positionY = y10.position("y"), z8.offsetX = 0, z8.offsetY = 0, z8.height = h10.w, z8.width = h10.h, z8.maxX = z8.positionX + z8.width / 2, z8.minX = z8.positionX - z8.width / 2, z8.maxY = z8.positionY + z8.height / 2, z8.minY = z8.positionY - z8.height / 2, z8.padLeft = parseFloat(y10.style("padding")), z8.padRight = parseFloat(y10.style("padding")), z8.padTop = parseFloat(y10.style("padding")), z8.padBottom = parseFloat(y10.style("padding")), z8.nodeRepulsion = B5(n12.nodeRepulsion) ? n12.nodeRepulsion(y10) : n12.nodeRepulsion, o12.layoutNodes.push(z8), o12.idToIndex[z8.id] = u10;
    }
    var p10 = [], f11 = 0, g9 = -1, v12 = [];
    for (u10 = 0; u10 < o12.nodeSize; u10++) {
      var y10, m12 = (y10 = o12.layoutNodes[u10]).parentId;
      null != m12 ? o12.layoutNodes[o12.idToIndex[m12]].children.push(y10.id) : (p10[++g9] = y10.id, v12.push(y10.id));
    }
    for (o12.graphSet.push(v12); f11 <= g9; ) {
      var b11 = p10[f11++], x10 = o12.idToIndex[b11], w11 = o12.layoutNodes[x10].children;
      if (w11.length > 0) {
        o12.graphSet.push(w11);
        for (u10 = 0; u10 < w11.length; u10++)
          p10[++g9] = w11[u10];
      }
    }
    for (u10 = 0; u10 < o12.graphSet.length; u10++) {
      var E9 = o12.graphSet[u10];
      for (d12 = 0; d12 < E9.length; d12++) {
        var k10 = o12.idToIndex[E9[d12]];
        o12.indexToGraph[k10] = u10;
      }
    }
    for (u10 = 0; u10 < o12.edgeSize; u10++) {
      var C9 = r9[u10], S8 = {};
      S8.id = C9.data("id"), S8.sourceId = C9.data("source"), S8.targetId = C9.data("target");
      var D9 = B5(n12.idealEdgeLength) ? n12.idealEdgeLength(C9) : n12.idealEdgeLength, P10 = B5(n12.edgeElasticity) ? n12.edgeElasticity(C9) : n12.edgeElasticity, T9 = o12.idToIndex[S8.sourceId], M9 = o12.idToIndex[S8.targetId];
      if (o12.indexToGraph[T9] != o12.indexToGraph[M9]) {
        for (var _7 = Co(S8.sourceId, S8.targetId, o12), N8 = o12.graphSet[_7], I8 = 0, z8 = o12.layoutNodes[T9]; -1 === N8.indexOf(z8.id); )
          z8 = o12.layoutNodes[o12.idToIndex[z8.parentId]], I8++;
        for (z8 = o12.layoutNodes[M9]; -1 === N8.indexOf(z8.id); )
          z8 = o12.layoutNodes[o12.idToIndex[z8.parentId]], I8++;
        D9 *= I8 * n12.nestingFactor;
      }
      S8.idealLength = D9, S8.elasticity = P10, o12.layoutEdges.push(S8);
    }
    return o12;
  };
  var Co = function(e21, t16, n12) {
    var r9 = So(e21, t16, 0, n12);
    return 2 > r9.count ? 0 : r9.graph;
  };
  var So = function e13(t16, n12, r9, a10) {
    var i11 = a10.graphSet[r9];
    if (-1 < i11.indexOf(t16) && -1 < i11.indexOf(n12))
      return { count: 2, graph: r9 };
    for (var o12 = 0, s11 = 0; s11 < i11.length; s11++) {
      var l11 = i11[s11], u10 = a10.idToIndex[l11], c10 = a10.layoutNodes[u10].children;
      if (0 !== c10.length) {
        var d12 = e13(t16, n12, a10.indexToGraph[a10.idToIndex[c10[0]]], a10);
        if (0 !== d12.count) {
          if (1 !== d12.count)
            return d12;
          if (2 === ++o12)
            break;
        }
      }
    }
    return { count: o12, graph: r9 };
  };
  var Do = function(e21, t16) {
    for (var n12 = e21.clientWidth, r9 = e21.clientHeight, a10 = 0; a10 < e21.nodeSize; a10++) {
      var i11 = e21.layoutNodes[a10];
      0 !== i11.children.length || i11.isLocked || (i11.positionX = Math.random() * n12, i11.positionY = Math.random() * r9);
    }
  };
  var Po = function(e21, t16, n12) {
    var r9 = e21.boundingBox, a10 = { x1: 1 / 0, x2: -1 / 0, y1: 1 / 0, y2: -1 / 0 };
    return t16.boundingBox && (n12.forEach(function(t17) {
      var n13 = e21.layoutNodes[e21.idToIndex[t17.data("id")]];
      a10.x1 = Math.min(a10.x1, n13.positionX), a10.x2 = Math.max(a10.x2, n13.positionX), a10.y1 = Math.min(a10.y1, n13.positionY), a10.y2 = Math.max(a10.y2, n13.positionY);
    }), a10.w = a10.x2 - a10.x1, a10.h = a10.y2 - a10.y1), function(n13, i11) {
      var o12 = e21.layoutNodes[e21.idToIndex[n13.data("id")]];
      if (t16.boundingBox) {
        var s11 = (o12.positionX - a10.x1) / a10.w, l11 = (o12.positionY - a10.y1) / a10.h;
        return { x: r9.x1 + s11 * r9.w, y: r9.y1 + l11 * r9.h };
      }
      return { x: o12.positionX, y: o12.positionY };
    };
  };
  var To = function(e21, t16, n12) {
    var r9 = n12.layout, a10 = n12.eles.nodes(), i11 = Po(e21, n12, a10);
    a10.positions(i11), true !== e21.ready && (e21.ready = true, r9.one("layoutready", n12.ready), r9.emit({ type: "layoutready", layout: this }));
  };
  var Mo = function(e21, t16, n12) {
    Bo(e21, t16), Lo(e21), Ao(e21, t16), Oo(e21), Ro(e21);
  };
  var Bo = function(e21, t16) {
    for (var n12 = 0; n12 < e21.graphSet.length; n12++)
      for (var r9 = e21.graphSet[n12], a10 = r9.length, i11 = 0; i11 < a10; i11++)
        for (var o12 = e21.layoutNodes[e21.idToIndex[r9[i11]]], s11 = i11 + 1; s11 < a10; s11++) {
          var l11 = e21.layoutNodes[e21.idToIndex[r9[s11]]];
          No(o12, l11, e21, t16);
        }
  };
  var _o = function(e21) {
    return -e21 + 2 * e21 * Math.random();
  };
  var No = function(e21, t16, n12, r9) {
    if (e21.cmptId === t16.cmptId || n12.isCompound) {
      var a10 = t16.positionX - e21.positionX, i11 = t16.positionY - e21.positionY;
      0 === a10 && 0 === i11 && (a10 = _o(1), i11 = _o(1));
      var o12 = Io(e21, t16, a10, i11);
      if (o12 > 0)
        var s11 = (u10 = r9.nodeOverlap * o12) * a10 / (g9 = Math.sqrt(a10 * a10 + i11 * i11)), l11 = u10 * i11 / g9;
      else {
        var u10, c10 = zo(e21, a10, i11), d12 = zo(t16, -1 * a10, -1 * i11), h10 = d12.x - c10.x, p10 = d12.y - c10.y, f11 = h10 * h10 + p10 * p10, g9 = Math.sqrt(f11);
        s11 = (u10 = (e21.nodeRepulsion + t16.nodeRepulsion) / f11) * h10 / g9, l11 = u10 * p10 / g9;
      }
      e21.isLocked || (e21.offsetX -= s11, e21.offsetY -= l11), t16.isLocked || (t16.offsetX += s11, t16.offsetY += l11);
    }
  };
  var Io = function(e21, t16, n12, r9) {
    if (n12 > 0)
      var a10 = e21.maxX - t16.minX;
    else
      a10 = t16.maxX - e21.minX;
    if (r9 > 0)
      var i11 = e21.maxY - t16.minY;
    else
      i11 = t16.maxY - e21.minY;
    return a10 >= 0 && i11 >= 0 ? Math.sqrt(a10 * a10 + i11 * i11) : 0;
  };
  var zo = function(e21, t16, n12) {
    var r9 = e21.positionX, a10 = e21.positionY, i11 = e21.height || 1, o12 = e21.width || 1, s11 = n12 / t16, l11 = i11 / o12, u10 = {};
    return 0 === t16 && 0 < n12 || 0 === t16 && 0 > n12 ? (u10.x = r9, u10.y = a10 + i11 / 2, u10) : 0 < t16 && -1 * l11 <= s11 && s11 <= l11 ? (u10.x = r9 + o12 / 2, u10.y = a10 + o12 * n12 / 2 / t16, u10) : 0 > t16 && -1 * l11 <= s11 && s11 <= l11 ? (u10.x = r9 - o12 / 2, u10.y = a10 - o12 * n12 / 2 / t16, u10) : 0 < n12 && (s11 <= -1 * l11 || s11 >= l11) ? (u10.x = r9 + i11 * t16 / 2 / n12, u10.y = a10 + i11 / 2, u10) : 0 > n12 && (s11 <= -1 * l11 || s11 >= l11) ? (u10.x = r9 - i11 * t16 / 2 / n12, u10.y = a10 - i11 / 2, u10) : u10;
  };
  var Lo = function(e21, t16) {
    for (var n12 = 0; n12 < e21.edgeSize; n12++) {
      var r9 = e21.layoutEdges[n12], a10 = e21.idToIndex[r9.sourceId], i11 = e21.layoutNodes[a10], o12 = e21.idToIndex[r9.targetId], s11 = e21.layoutNodes[o12], l11 = s11.positionX - i11.positionX, u10 = s11.positionY - i11.positionY;
      if (0 !== l11 || 0 !== u10) {
        var c10 = zo(i11, l11, u10), d12 = zo(s11, -1 * l11, -1 * u10), h10 = d12.x - c10.x, p10 = d12.y - c10.y, f11 = Math.sqrt(h10 * h10 + p10 * p10), g9 = Math.pow(r9.idealLength - f11, 2) / r9.elasticity;
        if (0 !== f11)
          var v12 = g9 * h10 / f11, y10 = g9 * p10 / f11;
        else
          v12 = 0, y10 = 0;
        i11.isLocked || (i11.offsetX += v12, i11.offsetY += y10), s11.isLocked || (s11.offsetX -= v12, s11.offsetY -= y10);
      }
    }
  };
  var Ao = function(e21, t16) {
    if (0 !== t16.gravity)
      for (var n12 = 0; n12 < e21.graphSet.length; n12++) {
        var r9 = e21.graphSet[n12], a10 = r9.length;
        if (0 === n12)
          var i11 = e21.clientHeight / 2, o12 = e21.clientWidth / 2;
        else {
          var s11 = e21.layoutNodes[e21.idToIndex[r9[0]]], l11 = e21.layoutNodes[e21.idToIndex[s11.parentId]];
          i11 = l11.positionX, o12 = l11.positionY;
        }
        for (var u10 = 0; u10 < a10; u10++) {
          var c10 = e21.layoutNodes[e21.idToIndex[r9[u10]]];
          if (!c10.isLocked) {
            var d12 = i11 - c10.positionX, h10 = o12 - c10.positionY, p10 = Math.sqrt(d12 * d12 + h10 * h10);
            if (p10 > 1) {
              var f11 = t16.gravity * d12 / p10, g9 = t16.gravity * h10 / p10;
              c10.offsetX += f11, c10.offsetY += g9;
            }
          }
        }
      }
  };
  var Oo = function(e21, t16) {
    var n12 = [], r9 = 0, a10 = -1;
    for (n12.push.apply(n12, e21.graphSet[0]), a10 += e21.graphSet[0].length; r9 <= a10; ) {
      var i11 = n12[r9++], o12 = e21.idToIndex[i11], s11 = e21.layoutNodes[o12], l11 = s11.children;
      if (0 < l11.length && !s11.isLocked) {
        for (var u10 = s11.offsetX, c10 = s11.offsetY, d12 = 0; d12 < l11.length; d12++) {
          var h10 = e21.layoutNodes[e21.idToIndex[l11[d12]]];
          h10.offsetX += u10, h10.offsetY += c10, n12[++a10] = l11[d12];
        }
        s11.offsetX = 0, s11.offsetY = 0;
      }
    }
  };
  var Ro = function(e21, t16) {
    for (var n12 = 0; n12 < e21.nodeSize; n12++) {
      0 < (a10 = e21.layoutNodes[n12]).children.length && (a10.maxX = void 0, a10.minX = void 0, a10.maxY = void 0, a10.minY = void 0);
    }
    for (n12 = 0; n12 < e21.nodeSize; n12++) {
      if (!(0 < (a10 = e21.layoutNodes[n12]).children.length || a10.isLocked)) {
        var r9 = Vo(a10.offsetX, a10.offsetY, e21.temperature);
        a10.positionX += r9.x, a10.positionY += r9.y, a10.offsetX = 0, a10.offsetY = 0, a10.minX = a10.positionX - a10.width, a10.maxX = a10.positionX + a10.width, a10.minY = a10.positionY - a10.height, a10.maxY = a10.positionY + a10.height, Fo(a10, e21);
      }
    }
    for (n12 = 0; n12 < e21.nodeSize; n12++) {
      var a10;
      0 < (a10 = e21.layoutNodes[n12]).children.length && !a10.isLocked && (a10.positionX = (a10.maxX + a10.minX) / 2, a10.positionY = (a10.maxY + a10.minY) / 2, a10.width = a10.maxX - a10.minX, a10.height = a10.maxY - a10.minY);
    }
  };
  var Vo = function(e21, t16, n12) {
    var r9 = Math.sqrt(e21 * e21 + t16 * t16);
    if (r9 > n12)
      var a10 = { x: n12 * e21 / r9, y: n12 * t16 / r9 };
    else
      a10 = { x: e21, y: t16 };
    return a10;
  };
  var Fo = function e14(t16, n12) {
    var r9 = t16.parentId;
    if (null != r9) {
      var a10 = n12.layoutNodes[n12.idToIndex[r9]], i11 = false;
      return (null == a10.maxX || t16.maxX + a10.padRight > a10.maxX) && (a10.maxX = t16.maxX + a10.padRight, i11 = true), (null == a10.minX || t16.minX - a10.padLeft < a10.minX) && (a10.minX = t16.minX - a10.padLeft, i11 = true), (null == a10.maxY || t16.maxY + a10.padBottom > a10.maxY) && (a10.maxY = t16.maxY + a10.padBottom, i11 = true), (null == a10.minY || t16.minY - a10.padTop < a10.minY) && (a10.minY = t16.minY - a10.padTop, i11 = true), i11 ? e14(a10, n12) : void 0;
    }
  };
  var qo = function(e21, t16) {
    for (var n12 = e21.layoutNodes, r9 = [], a10 = 0; a10 < n12.length; a10++) {
      var i11 = n12[a10], o12 = i11.cmptId;
      (r9[o12] = r9[o12] || []).push(i11);
    }
    var s11 = 0;
    for (a10 = 0; a10 < r9.length; a10++) {
      if (g9 = r9[a10]) {
        g9.x1 = 1 / 0, g9.x2 = -1 / 0, g9.y1 = 1 / 0, g9.y2 = -1 / 0;
        for (var l11 = 0; l11 < g9.length; l11++) {
          var u10 = g9[l11];
          g9.x1 = Math.min(g9.x1, u10.positionX - u10.width / 2), g9.x2 = Math.max(g9.x2, u10.positionX + u10.width / 2), g9.y1 = Math.min(g9.y1, u10.positionY - u10.height / 2), g9.y2 = Math.max(g9.y2, u10.positionY + u10.height / 2);
        }
        g9.w = g9.x2 - g9.x1, g9.h = g9.y2 - g9.y1, s11 += g9.w * g9.h;
      }
    }
    r9.sort(function(e22, t17) {
      return t17.w * t17.h - e22.w * e22.h;
    });
    var c10 = 0, d12 = 0, h10 = 0, p10 = 0, f11 = Math.sqrt(s11) * e21.clientWidth / e21.clientHeight;
    for (a10 = 0; a10 < r9.length; a10++) {
      var g9;
      if (g9 = r9[a10]) {
        for (l11 = 0; l11 < g9.length; l11++) {
          (u10 = g9[l11]).isLocked || (u10.positionX += c10 - g9.x1, u10.positionY += d12 - g9.y1);
        }
        c10 += g9.w + t16.componentSpacing, h10 += g9.w + t16.componentSpacing, p10 = Math.max(p10, g9.h), h10 > f11 && (d12 += p10 + t16.componentSpacing, c10 = 0, h10 = 0, p10 = 0);
      }
    }
  };
  var jo = { fit: true, padding: 30, boundingBox: void 0, avoidOverlap: true, avoidOverlapPadding: 10, nodeDimensionsIncludeLabels: false, spacingFactor: void 0, condense: false, rows: void 0, cols: void 0, position: function(e21) {
  }, sort: void 0, animate: false, animationDuration: 500, animationEasing: void 0, animateFilter: function(e21, t16) {
    return true;
  }, ready: void 0, stop: void 0, transform: function(e21, t16) {
    return t16;
  } };
  function Yo(e21) {
    this.options = J4({}, jo, e21);
  }
  Yo.prototype.run = function() {
    var e21 = this.options, t16 = e21, n12 = e21.cy, r9 = t16.eles, a10 = r9.nodes().not(":parent");
    t16.sort && (a10 = a10.sort(t16.sort));
    var i11 = vt4(t16.boundingBox ? t16.boundingBox : { x1: 0, y1: 0, w: n12.width(), h: n12.height() });
    if (0 === i11.h || 0 === i11.w)
      r9.nodes().layoutPositions(this, t16, function(e22) {
        return { x: i11.x1, y: i11.y1 };
      });
    else {
      var o12 = a10.size(), s11 = Math.sqrt(o12 * i11.h / i11.w), l11 = Math.round(s11), u10 = Math.round(i11.w / i11.h * s11), c10 = function(e22) {
        if (null == e22)
          return Math.min(l11, u10);
        Math.min(l11, u10) == l11 ? l11 = e22 : u10 = e22;
      }, d12 = function(e22) {
        if (null == e22)
          return Math.max(l11, u10);
        Math.max(l11, u10) == l11 ? l11 = e22 : u10 = e22;
      }, h10 = t16.rows, p10 = null != t16.cols ? t16.cols : t16.columns;
      if (null != h10 && null != p10)
        l11 = h10, u10 = p10;
      else if (null != h10 && null == p10)
        l11 = h10, u10 = Math.ceil(o12 / l11);
      else if (null == h10 && null != p10)
        u10 = p10, l11 = Math.ceil(o12 / u10);
      else if (u10 * l11 > o12) {
        var f11 = c10(), g9 = d12();
        (f11 - 1) * g9 >= o12 ? c10(f11 - 1) : (g9 - 1) * f11 >= o12 && d12(g9 - 1);
      } else
        for (; u10 * l11 < o12; ) {
          var v12 = c10(), y10 = d12();
          (y10 + 1) * v12 >= o12 ? d12(y10 + 1) : c10(v12 + 1);
        }
      var m12 = i11.w / u10, b11 = i11.h / l11;
      if (t16.condense && (m12 = 0, b11 = 0), t16.avoidOverlap)
        for (var x10 = 0; x10 < a10.length; x10++) {
          var w11 = a10[x10], E9 = w11._private.position;
          null != E9.x && null != E9.y || (E9.x = 0, E9.y = 0);
          var k10 = w11.layoutDimensions(t16), C9 = t16.avoidOverlapPadding, S8 = k10.w + C9, D9 = k10.h + C9;
          m12 = Math.max(m12, S8), b11 = Math.max(b11, D9);
        }
      for (var P10 = {}, T9 = function(e22, t17) {
        return !!P10["c-" + e22 + "-" + t17];
      }, M9 = function(e22, t17) {
        P10["c-" + e22 + "-" + t17] = true;
      }, B9 = 0, _7 = 0, N8 = function() {
        ++_7 >= u10 && (_7 = 0, B9++);
      }, I8 = {}, z8 = 0; z8 < a10.length; z8++) {
        var L9 = a10[z8], A10 = t16.position(L9);
        if (A10 && (void 0 !== A10.row || void 0 !== A10.col)) {
          var O10 = { row: A10.row, col: A10.col };
          if (void 0 === O10.col)
            for (O10.col = 0; T9(O10.row, O10.col); )
              O10.col++;
          else if (void 0 === O10.row)
            for (O10.row = 0; T9(O10.row, O10.col); )
              O10.row++;
          I8[L9.id()] = O10, M9(O10.row, O10.col);
        }
      }
      a10.layoutPositions(this, t16, function(e22, t17) {
        var n13, r10;
        if (e22.locked() || e22.isParent())
          return false;
        var a11 = I8[e22.id()];
        if (a11)
          n13 = a11.col * m12 + m12 / 2 + i11.x1, r10 = a11.row * b11 + b11 / 2 + i11.y1;
        else {
          for (; T9(B9, _7); )
            N8();
          n13 = _7 * m12 + m12 / 2 + i11.x1, r10 = B9 * b11 + b11 / 2 + i11.y1, M9(B9, _7), N8();
        }
        return { x: n13, y: r10 };
      });
    }
    return this;
  };
  var Xo = { ready: function() {
  }, stop: function() {
  } };
  function Wo(e21) {
    this.options = J4({}, Xo, e21);
  }
  Wo.prototype.run = function() {
    var e21 = this.options, t16 = e21.eles, n12 = this;
    return e21.cy, n12.emit("layoutstart"), t16.nodes().positions(function() {
      return { x: 0, y: 0 };
    }), n12.one("layoutready", e21.ready), n12.emit("layoutready"), n12.one("layoutstop", e21.stop), n12.emit("layoutstop"), this;
  }, Wo.prototype.stop = function() {
    return this;
  };
  var Ho = { positions: void 0, zoom: void 0, pan: void 0, fit: true, padding: 30, animate: false, animationDuration: 500, animationEasing: void 0, animateFilter: function(e21, t16) {
    return true;
  }, ready: void 0, stop: void 0, transform: function(e21, t16) {
    return t16;
  } };
  function Ko(e21) {
    this.options = J4({}, Ho, e21);
  }
  Ko.prototype.run = function() {
    var e21 = this.options, t16 = e21.eles.nodes(), n12 = B5(e21.positions);
    return t16.layoutPositions(this, e21, function(t17, r9) {
      var a10 = function(t18) {
        if (null == e21.positions)
          return function(e22) {
            return { x: e22.x, y: e22.y };
          }(t18.position());
        if (n12)
          return e21.positions(t18);
        var r10 = e21.positions[t18._private.data.id];
        return null == r10 ? null : r10;
      }(t17);
      return !t17.locked() && null != a10 && a10;
    }), this;
  };
  var Go = { fit: true, padding: 30, boundingBox: void 0, animate: false, animationDuration: 500, animationEasing: void 0, animateFilter: function(e21, t16) {
    return true;
  }, ready: void 0, stop: void 0, transform: function(e21, t16) {
    return t16;
  } };
  function Uo(e21) {
    this.options = J4({}, Go, e21);
  }
  Uo.prototype.run = function() {
    var e21 = this.options, t16 = e21.cy, n12 = e21.eles, r9 = vt4(e21.boundingBox ? e21.boundingBox : { x1: 0, y1: 0, w: t16.width(), h: t16.height() });
    return n12.nodes().layoutPositions(this, e21, function(e22, t17) {
      return { x: r9.x1 + Math.round(Math.random() * r9.w), y: r9.y1 + Math.round(Math.random() * r9.h) };
    }), this;
  };
  var Zo = [{ name: "breadthfirst", impl: go }, { name: "circle", impl: yo }, { name: "concentric", impl: xo }, { name: "cose", impl: Eo }, { name: "grid", impl: Yo }, { name: "null", impl: Wo }, { name: "preset", impl: Ko }, { name: "random", impl: Uo }];
  function $o(e21) {
    this.options = e21, this.notifications = 0;
  }
  var Qo = function() {
  };
  var Jo = function() {
    throw new Error("A headless instance can not render images");
  };
  $o.prototype = { recalculateRenderedStyle: Qo, notify: function() {
    this.notifications++;
  }, init: Qo, isHeadless: function() {
    return true;
  }, png: Jo, jpg: Jo };
  var es = { arrowShapeWidth: 0.3, registerArrowShapes: function() {
    var e21 = this.arrowShapes = {}, t16 = this, n12 = function(e22, t17, n13, r10, a11, i12, o13) {
      var s12 = a11.x - n13 / 2 - o13, l11 = a11.x + n13 / 2 + o13, u10 = a11.y - n13 / 2 - o13, c10 = a11.y + n13 / 2 + o13;
      return s12 <= e22 && e22 <= l11 && u10 <= t17 && t17 <= c10;
    }, r9 = function(e22, t17, n13, r10, a11) {
      var i12 = e22 * Math.cos(r10) - t17 * Math.sin(r10), o13 = (e22 * Math.sin(r10) + t17 * Math.cos(r10)) * n13;
      return { x: i12 * n13 + a11.x, y: o13 + a11.y };
    }, a10 = function(e22, t17, n13, a11) {
      for (var i12 = [], o13 = 0; o13 < e22.length; o13 += 2) {
        var s12 = e22[o13], l11 = e22[o13 + 1];
        i12.push(r9(s12, l11, t17, n13, a11));
      }
      return i12;
    }, i11 = function(e22) {
      for (var t17 = [], n13 = 0; n13 < e22.length; n13++) {
        var r10 = e22[n13];
        t17.push(r10.x, r10.y);
      }
      return t17;
    }, o12 = function(e22) {
      return e22.pstyle("width").pfValue * e22.pstyle("arrow-scale").pfValue * 2;
    }, s11 = function(r10, s12) {
      M6(s12) && (s12 = e21[s12]), e21[r10] = J4({ name: r10, points: [-0.15, -0.3, 0.15, -0.3, 0.15, 0.3, -0.15, 0.3], collide: function(e22, t17, n13, r11, o13, s13) {
        var l11 = i11(a10(this.points, n13 + 2 * s13, r11, o13));
        return Mt4(e22, t17, l11);
      }, roughCollide: n12, draw: function(e22, n13, r11, i12) {
        var o13 = a10(this.points, n13, r11, i12);
        t16.arrowShapeImpl("polygon")(e22, o13);
      }, spacing: function(e22) {
        return 0;
      }, gap: o12 }, s12);
    };
    s11("none", { collide: Ce, roughCollide: Ce, draw: De, spacing: Se, gap: Se }), s11("triangle", { points: [-0.15, -0.3, 0, 0, 0.15, -0.3] }), s11("arrow", "triangle"), s11("triangle-backcurve", { points: e21.triangle.points, controlPoint: [0, -0.15], roughCollide: n12, draw: function(e22, n13, i12, o13, s12) {
      var l11 = a10(this.points, n13, i12, o13), u10 = this.controlPoint, c10 = r9(u10[0], u10[1], n13, i12, o13);
      t16.arrowShapeImpl(this.name)(e22, l11, c10);
    }, gap: function(e22) {
      return 0.8 * o12(e22);
    } }), s11("triangle-tee", { points: [0, 0, 0.15, -0.3, -0.15, -0.3, 0, 0], pointsTee: [-0.15, -0.4, -0.15, -0.5, 0.15, -0.5, 0.15, -0.4], collide: function(e22, t17, n13, r10, o13, s12, l11) {
      var u10 = i11(a10(this.points, n13 + 2 * l11, r10, o13)), c10 = i11(a10(this.pointsTee, n13 + 2 * l11, r10, o13));
      return Mt4(e22, t17, u10) || Mt4(e22, t17, c10);
    }, draw: function(e22, n13, r10, i12, o13) {
      var s12 = a10(this.points, n13, r10, i12), l11 = a10(this.pointsTee, n13, r10, i12);
      t16.arrowShapeImpl(this.name)(e22, s12, l11);
    } }), s11("circle-triangle", { radius: 0.15, pointsTr: [0, -0.15, 0.15, -0.45, -0.15, -0.45, 0, -0.15], collide: function(e22, t17, n13, r10, o13, s12, l11) {
      var u10 = o13, c10 = Math.pow(u10.x - e22, 2) + Math.pow(u10.y - t17, 2) <= Math.pow((n13 + 2 * l11) * this.radius, 2), d12 = i11(a10(this.points, n13 + 2 * l11, r10, o13));
      return Mt4(e22, t17, d12) || c10;
    }, draw: function(e22, n13, r10, i12, o13) {
      var s12 = a10(this.pointsTr, n13, r10, i12);
      t16.arrowShapeImpl(this.name)(e22, s12, i12.x, i12.y, this.radius * n13);
    }, spacing: function(e22) {
      return t16.getArrowWidth(e22.pstyle("width").pfValue, e22.pstyle("arrow-scale").value) * this.radius;
    } }), s11("triangle-cross", { points: [0, 0, 0.15, -0.3, -0.15, -0.3, 0, 0], baseCrossLinePts: [-0.15, -0.4, -0.15, -0.4, 0.15, -0.4, 0.15, -0.4], crossLinePts: function(e22, t17) {
      var n13 = this.baseCrossLinePts.slice(), r10 = t17 / e22;
      return n13[3] = n13[3] - r10, n13[5] = n13[5] - r10, n13;
    }, collide: function(e22, t17, n13, r10, o13, s12, l11) {
      var u10 = i11(a10(this.points, n13 + 2 * l11, r10, o13)), c10 = i11(a10(this.crossLinePts(n13, s12), n13 + 2 * l11, r10, o13));
      return Mt4(e22, t17, u10) || Mt4(e22, t17, c10);
    }, draw: function(e22, n13, r10, i12, o13) {
      var s12 = a10(this.points, n13, r10, i12), l11 = a10(this.crossLinePts(n13, o13), n13, r10, i12);
      t16.arrowShapeImpl(this.name)(e22, s12, l11);
    } }), s11("vee", { points: [-0.15, -0.3, 0, 0, 0.15, -0.3, 0, -0.15], gap: function(e22) {
      return 0.525 * o12(e22);
    } }), s11("circle", { radius: 0.15, collide: function(e22, t17, n13, r10, a11, i12, o13) {
      var s12 = a11;
      return Math.pow(s12.x - e22, 2) + Math.pow(s12.y - t17, 2) <= Math.pow((n13 + 2 * o13) * this.radius, 2);
    }, draw: function(e22, n13, r10, a11, i12) {
      t16.arrowShapeImpl(this.name)(e22, a11.x, a11.y, this.radius * n13);
    }, spacing: function(e22) {
      return t16.getArrowWidth(e22.pstyle("width").pfValue, e22.pstyle("arrow-scale").value) * this.radius;
    } }), s11("tee", { points: [-0.15, 0, -0.15, -0.1, 0.15, -0.1, 0.15, 0], spacing: function(e22) {
      return 1;
    }, gap: function(e22) {
      return 1;
    } }), s11("square", { points: [-0.15, 0, 0.15, 0, 0.15, -0.3, -0.15, -0.3] }), s11("diamond", { points: [-0.15, -0.15, 0, -0.3, 0.15, -0.15, 0, 0], gap: function(e22) {
      return e22.pstyle("width").pfValue * e22.pstyle("arrow-scale").value;
    } }), s11("chevron", { points: [0, 0, -0.15, -0.15, -0.1, -0.2, 0, -0.1, 0.1, -0.2, 0.15, -0.15], gap: function(e22) {
      return 0.95 * e22.pstyle("width").pfValue * e22.pstyle("arrow-scale").value;
    } });
  } };
  var ts = { projectIntoViewport: function(e21, t16) {
    var n12 = this.cy, r9 = this.findContainerClientCoords(), a10 = r9[0], i11 = r9[1], o12 = r9[4], s11 = n12.pan(), l11 = n12.zoom();
    return [((e21 - a10) / o12 - s11.x) / l11, ((t16 - i11) / o12 - s11.y) / l11];
  }, findContainerClientCoords: function() {
    if (this.containerBB)
      return this.containerBB;
    var e21 = this.container, t16 = e21.getBoundingClientRect(), n12 = this.cy.window().getComputedStyle(e21), r9 = function(e22) {
      return parseFloat(n12.getPropertyValue(e22));
    }, a10 = r9("padding-left"), i11 = r9("padding-right"), o12 = r9("padding-top"), s11 = r9("padding-bottom"), l11 = r9("border-left-width"), u10 = r9("border-right-width"), c10 = r9("border-top-width"), d12 = (r9("border-bottom-width"), e21.clientWidth), h10 = e21.clientHeight, p10 = a10 + i11, f11 = o12 + s11, g9 = l11 + u10, v12 = t16.width / (d12 + g9), y10 = d12 - p10, m12 = h10 - f11, b11 = t16.left + a10 + l11, x10 = t16.top + o12 + c10;
    return this.containerBB = [b11, x10, y10, m12, v12];
  }, invalidateContainerClientCoordsCache: function() {
    this.containerBB = null;
  }, findNearestElement: function(e21, t16, n12, r9) {
    return this.findNearestElements(e21, t16, n12, r9)[0];
  }, findNearestElements: function(e21, t16, n12, r9) {
    var a10, i11, o12 = this, s11 = this, l11 = s11.getCachedZSortedEles(), u10 = [], c10 = s11.cy.zoom(), d12 = s11.cy.hasCompoundNodes(), h10 = (r9 ? 24 : 8) / c10, p10 = (r9 ? 8 : 2) / c10, f11 = (r9 ? 8 : 2) / c10, g9 = 1 / 0;
    function v12(e22, t17) {
      if (e22.isNode()) {
        if (i11)
          return;
        i11 = e22, u10.push(e22);
      }
      if (e22.isEdge() && (null == t17 || t17 < g9))
        if (a10) {
          if (a10.pstyle("z-compound-depth").value === e22.pstyle("z-compound-depth").value && a10.pstyle("z-compound-depth").value === e22.pstyle("z-compound-depth").value) {
            for (var n13 = 0; n13 < u10.length; n13++)
              if (u10[n13].isEdge()) {
                u10[n13] = e22, a10 = e22, g9 = null != t17 ? t17 : g9;
                break;
              }
          }
        } else
          u10.push(e22), a10 = e22, g9 = null != t17 ? t17 : g9;
    }
    function y10(n13) {
      var r10 = n13.outerWidth() + 2 * p10, a11 = n13.outerHeight() + 2 * p10, i12 = r10 / 2, l12 = a11 / 2, u11 = n13.position();
      if (u11.x - i12 <= e21 && e21 <= u11.x + i12 && u11.y - l12 <= t16 && t16 <= u11.y + l12 && s11.nodeShapes[o12.getNodeShape(n13)].checkPoint(e21, t16, 0, r10, a11, u11.x, u11.y))
        return v12(n13, 0), true;
    }
    function m12(n13) {
      var r10, a11 = n13._private, i12 = a11.rscratch, l12 = n13.pstyle("width").pfValue, c11 = n13.pstyle("arrow-scale").value, p11 = l12 / 2 + h10, f12 = p11 * p11, g10 = 2 * p11, m13 = a11.source, b12 = a11.target;
      if ("segments" === i12.edgeType || "straight" === i12.edgeType || "haystack" === i12.edgeType) {
        for (var x11 = i12.allpts, w12 = 0; w12 + 3 < x11.length; w12 += 2)
          if (St4(e21, t16, x11[w12], x11[w12 + 1], x11[w12 + 2], x11[w12 + 3], g10) && f12 > (r10 = Tt4(e21, t16, x11[w12], x11[w12 + 1], x11[w12 + 2], x11[w12 + 3])))
            return v12(n13, r10), true;
      } else if ("bezier" === i12.edgeType || "multibezier" === i12.edgeType || "self" === i12.edgeType || "compound" === i12.edgeType) {
        for (x11 = i12.allpts, w12 = 0; w12 + 5 < i12.allpts.length; w12 += 4)
          if (Dt4(e21, t16, x11[w12], x11[w12 + 1], x11[w12 + 2], x11[w12 + 3], x11[w12 + 4], x11[w12 + 5], g10) && f12 > (r10 = Pt4(e21, t16, x11[w12], x11[w12 + 1], x11[w12 + 2], x11[w12 + 3], x11[w12 + 4], x11[w12 + 5])))
            return v12(n13, r10), true;
      }
      m13 = m13 || a11.source, b12 = b12 || a11.target;
      var E10 = o12.getArrowWidth(l12, c11), k10 = [{ name: "source", x: i12.arrowStartX, y: i12.arrowStartY, angle: i12.srcArrowAngle }, { name: "target", x: i12.arrowEndX, y: i12.arrowEndY, angle: i12.tgtArrowAngle }, { name: "mid-source", x: i12.midX, y: i12.midY, angle: i12.midsrcArrowAngle }, { name: "mid-target", x: i12.midX, y: i12.midY, angle: i12.midtgtArrowAngle }];
      for (w12 = 0; w12 < k10.length; w12++) {
        var C9 = k10[w12], S8 = s11.arrowShapes[n13.pstyle(C9.name + "-arrow-shape").value], D9 = n13.pstyle("width").pfValue;
        if (S8.roughCollide(e21, t16, E10, C9.angle, { x: C9.x, y: C9.y }, D9, h10) && S8.collide(e21, t16, E10, C9.angle, { x: C9.x, y: C9.y }, D9, h10))
          return v12(n13), true;
      }
      d12 && u10.length > 0 && (y10(m13), y10(b12));
    }
    function b11(e22, t17, n13) {
      return Oe(e22, t17, n13);
    }
    function x10(n13, r10) {
      var a11, i12 = n13._private, o13 = f11;
      a11 = r10 ? r10 + "-" : "", n13.boundingBox();
      var s12 = i12.labelBounds[r10 || "main"], l12 = n13.pstyle(a11 + "label").value;
      if ("yes" === n13.pstyle("text-events").strValue && l12) {
        var u11 = b11(i12.rscratch, "labelX", r10), c11 = b11(i12.rscratch, "labelY", r10), d13 = b11(i12.rscratch, "labelAngle", r10), h11 = n13.pstyle(a11 + "text-margin-x").pfValue, p11 = n13.pstyle(a11 + "text-margin-y").pfValue, g10 = s12.x1 - o13 - h11, y11 = s12.x2 + o13 - h11, m13 = s12.y1 - o13 - p11, x11 = s12.y2 + o13 - p11;
        if (d13) {
          var w12 = Math.cos(d13), E10 = Math.sin(d13), k10 = function(e22, t17) {
            return { x: (e22 -= u11) * w12 - (t17 -= c11) * E10 + u11, y: e22 * E10 + t17 * w12 + c11 };
          }, C9 = k10(g10, m13), S8 = k10(g10, x11), D9 = k10(y11, m13), P10 = k10(y11, x11), T9 = [C9.x + h11, C9.y + p11, D9.x + h11, D9.y + p11, P10.x + h11, P10.y + p11, S8.x + h11, S8.y + p11];
          if (Mt4(e21, t16, T9))
            return v12(n13), true;
        } else if (Et4(s12, e21, t16))
          return v12(n13), true;
      }
    }
    n12 && (l11 = l11.interactive);
    for (var w11 = l11.length - 1; w11 >= 0; w11--) {
      var E9 = l11[w11];
      E9.isNode() ? y10(E9) || x10(E9) : m12(E9) || x10(E9) || x10(E9, "source") || x10(E9, "target");
    }
    return u10;
  }, getAllInBox: function(e21, t16, n12, r9) {
    for (var a10, i11, o12 = this.getCachedZSortedEles().interactive, s11 = [], l11 = Math.min(e21, n12), u10 = Math.max(e21, n12), c10 = Math.min(t16, r9), d12 = Math.max(t16, r9), h10 = vt4({ x1: e21 = l11, y1: t16 = c10, x2: n12 = u10, y2: r9 = d12 }), p10 = 0; p10 < o12.length; p10++) {
      var f11 = o12[p10];
      if (f11.isNode()) {
        var g9 = f11, v12 = g9.boundingBox({ includeNodes: true, includeEdges: false, includeLabels: false });
        wt4(h10, v12) && !kt4(v12, h10) && s11.push(g9);
      } else {
        var y10 = f11, m12 = y10._private, b11 = m12.rscratch;
        if (null != b11.startX && null != b11.startY && !Et4(h10, b11.startX, b11.startY))
          continue;
        if (null != b11.endX && null != b11.endY && !Et4(h10, b11.endX, b11.endY))
          continue;
        if ("bezier" === b11.edgeType || "multibezier" === b11.edgeType || "self" === b11.edgeType || "compound" === b11.edgeType || "segments" === b11.edgeType || "haystack" === b11.edgeType) {
          for (var x10 = m12.rstyle.bezierPts || m12.rstyle.linePts || m12.rstyle.haystackPts, w11 = true, E9 = 0; E9 < x10.length; E9++)
            if (a10 = h10, i11 = x10[E9], !Et4(a10, i11.x, i11.y)) {
              w11 = false;
              break;
            }
          w11 && s11.push(y10);
        } else
          "haystack" !== b11.edgeType && "straight" !== b11.edgeType || s11.push(y10);
      }
    }
    return s11;
  } };
  var ns = { calculateArrowAngles: function(e21) {
    var t16, n12, r9, a10, i11, o12, s11 = e21._private.rscratch, l11 = "haystack" === s11.edgeType, u10 = "bezier" === s11.edgeType, c10 = "multibezier" === s11.edgeType, d12 = "segments" === s11.edgeType, h10 = "compound" === s11.edgeType, p10 = "self" === s11.edgeType;
    if (l11 ? (r9 = s11.haystackPts[0], a10 = s11.haystackPts[1], i11 = s11.haystackPts[2], o12 = s11.haystackPts[3]) : (r9 = s11.arrowStartX, a10 = s11.arrowStartY, i11 = s11.arrowEndX, o12 = s11.arrowEndY), g9 = s11.midX, v12 = s11.midY, d12)
      t16 = r9 - s11.segpts[0], n12 = a10 - s11.segpts[1];
    else if (c10 || h10 || p10 || u10) {
      var f11 = s11.allpts;
      t16 = r9 - pt4(f11[0], f11[2], f11[4], 0.1), n12 = a10 - pt4(f11[1], f11[3], f11[5], 0.1);
    } else
      t16 = r9 - g9, n12 = a10 - v12;
    s11.srcArrowAngle = st4(t16, n12);
    var g9 = s11.midX, v12 = s11.midY;
    if (l11 && (g9 = (r9 + i11) / 2, v12 = (a10 + o12) / 2), t16 = i11 - r9, n12 = o12 - a10, d12)
      if ((f11 = s11.allpts).length / 2 % 2 == 0) {
        var y10 = (m12 = f11.length / 2) - 2;
        t16 = f11[m12] - f11[y10], n12 = f11[m12 + 1] - f11[y10 + 1];
      } else {
        y10 = (m12 = f11.length / 2 - 1) - 2;
        var m12, b11 = m12 + 2;
        t16 = f11[m12] - f11[y10], n12 = f11[m12 + 1] - f11[y10 + 1];
      }
    else if (c10 || h10 || p10) {
      var x10, w11, E9, k10, f11 = s11.allpts;
      if (s11.ctrlpts.length / 2 % 2 == 0) {
        var C9 = (S8 = (D9 = f11.length / 2 - 1) + 2) + 2;
        x10 = pt4(f11[D9], f11[S8], f11[C9], 0), w11 = pt4(f11[D9 + 1], f11[S8 + 1], f11[C9 + 1], 0), E9 = pt4(f11[D9], f11[S8], f11[C9], 1e-4), k10 = pt4(f11[D9 + 1], f11[S8 + 1], f11[C9 + 1], 1e-4);
      } else {
        var S8, D9;
        C9 = (S8 = f11.length / 2 - 1) + 2;
        x10 = pt4(f11[D9 = S8 - 2], f11[S8], f11[C9], 0.4999), w11 = pt4(f11[D9 + 1], f11[S8 + 1], f11[C9 + 1], 0.4999), E9 = pt4(f11[D9], f11[S8], f11[C9], 0.5), k10 = pt4(f11[D9 + 1], f11[S8 + 1], f11[C9 + 1], 0.5);
      }
      t16 = E9 - x10, n12 = k10 - w11;
    }
    (s11.midtgtArrowAngle = st4(t16, n12), s11.midDispX = t16, s11.midDispY = n12, t16 *= -1, n12 *= -1, d12) && ((f11 = s11.allpts).length / 2 % 2 == 0 || (t16 = -(f11[b11 = (m12 = f11.length / 2 - 1) + 2] - f11[m12]), n12 = -(f11[b11 + 1] - f11[m12 + 1])));
    if (s11.midsrcArrowAngle = st4(t16, n12), d12)
      t16 = i11 - s11.segpts[s11.segpts.length - 2], n12 = o12 - s11.segpts[s11.segpts.length - 1];
    else if (c10 || h10 || p10 || u10) {
      var P10 = (f11 = s11.allpts).length;
      t16 = i11 - pt4(f11[P10 - 6], f11[P10 - 4], f11[P10 - 2], 0.9), n12 = o12 - pt4(f11[P10 - 5], f11[P10 - 3], f11[P10 - 1], 0.9);
    } else
      t16 = i11 - g9, n12 = o12 - v12;
    s11.tgtArrowAngle = st4(t16, n12);
  } };
  ns.getArrowWidth = ns.getArrowHeight = function(e21, t16) {
    var n12 = this.arrowWidthCache = this.arrowWidthCache || {}, r9 = n12[e21 + ", " + t16];
    return r9 || (r9 = Math.max(Math.pow(13.37 * e21, 0.9), 29) * t16, n12[e21 + ", " + t16] = r9, r9);
  };
  var rs = {};
  function as(e21) {
    var t16 = [];
    if (null != e21) {
      for (var n12 = 0; n12 < e21.length; n12 += 2) {
        var r9 = e21[n12], a10 = e21[n12 + 1];
        t16.push({ x: r9, y: a10 });
      }
      return t16;
    }
  }
  rs.findHaystackPoints = function(e21) {
    for (var t16 = 0; t16 < e21.length; t16++) {
      var n12 = e21[t16], r9 = n12._private, a10 = r9.rscratch;
      if (!a10.haystack) {
        var i11 = 2 * Math.random() * Math.PI;
        a10.source = { x: Math.cos(i11), y: Math.sin(i11) }, i11 = 2 * Math.random() * Math.PI, a10.target = { x: Math.cos(i11), y: Math.sin(i11) };
      }
      var o12 = r9.source, s11 = r9.target, l11 = o12.position(), u10 = s11.position(), c10 = o12.width(), d12 = s11.width(), h10 = o12.height(), p10 = s11.height(), f11 = n12.pstyle("haystack-radius").value / 2;
      a10.haystackPts = a10.allpts = [a10.source.x * c10 * f11 + l11.x, a10.source.y * h10 * f11 + l11.y, a10.target.x * d12 * f11 + u10.x, a10.target.y * p10 * f11 + u10.y], a10.midX = (a10.allpts[0] + a10.allpts[2]) / 2, a10.midY = (a10.allpts[1] + a10.allpts[3]) / 2, a10.edgeType = "haystack", a10.haystack = true, this.storeEdgeProjections(n12), this.calculateArrowAngles(n12), this.recalculateEdgeLabelProjections(n12), this.calculateLabelAngles(n12);
    }
  }, rs.findSegmentsPoints = function(e21, t16) {
    var n12 = e21._private.rscratch, r9 = t16.posPts, a10 = t16.intersectionPts, i11 = t16.vectorNormInverse, o12 = e21.pstyle("edge-distances").value, s11 = e21.pstyle("segment-weights"), l11 = e21.pstyle("segment-distances"), u10 = Math.min(s11.pfValue.length, l11.pfValue.length);
    n12.edgeType = "segments", n12.segpts = [];
    for (var c10 = 0; c10 < u10; c10++) {
      var d12 = s11.pfValue[c10], h10 = l11.pfValue[c10], p10 = 1 - d12, f11 = d12, g9 = "node-position" === o12 ? r9 : a10, v12 = { x: g9.x1 * p10 + g9.x2 * f11, y: g9.y1 * p10 + g9.y2 * f11 };
      n12.segpts.push(v12.x + i11.x * h10, v12.y + i11.y * h10);
    }
  }, rs.findLoopPoints = function(e21, t16, n12, r9) {
    var a10 = e21._private.rscratch, i11 = t16.dirCounts, o12 = t16.srcPos, s11 = e21.pstyle("control-point-distances"), l11 = s11 ? s11.pfValue[0] : void 0, u10 = e21.pstyle("loop-direction").pfValue, c10 = e21.pstyle("loop-sweep").pfValue, d12 = e21.pstyle("control-point-step-size").pfValue;
    a10.edgeType = "self";
    var h10 = n12, p10 = d12;
    r9 && (h10 = 0, p10 = l11);
    var f11 = u10 - Math.PI / 2, g9 = f11 - c10 / 2, v12 = f11 + c10 / 2, y10 = String(u10 + "_" + c10);
    h10 = void 0 === i11[y10] ? i11[y10] = 0 : ++i11[y10], a10.ctrlpts = [o12.x + 1.4 * Math.cos(g9) * p10 * (h10 / 3 + 1), o12.y + 1.4 * Math.sin(g9) * p10 * (h10 / 3 + 1), o12.x + 1.4 * Math.cos(v12) * p10 * (h10 / 3 + 1), o12.y + 1.4 * Math.sin(v12) * p10 * (h10 / 3 + 1)];
  }, rs.findCompoundLoopPoints = function(e21, t16, n12, r9) {
    var a10 = e21._private.rscratch;
    a10.edgeType = "compound";
    var i11 = t16.srcPos, o12 = t16.tgtPos, s11 = t16.srcW, l11 = t16.srcH, u10 = t16.tgtW, c10 = t16.tgtH, d12 = e21.pstyle("control-point-step-size").pfValue, h10 = e21.pstyle("control-point-distances"), p10 = h10 ? h10.pfValue[0] : void 0, f11 = n12, g9 = d12;
    r9 && (f11 = 0, g9 = p10);
    var v12 = { x: i11.x - s11 / 2, y: i11.y - l11 / 2 }, y10 = { x: o12.x - u10 / 2, y: o12.y - c10 / 2 }, m12 = { x: Math.min(v12.x, y10.x), y: Math.min(v12.y, y10.y) }, b11 = Math.max(0.5, Math.log(0.01 * s11)), x10 = Math.max(0.5, Math.log(0.01 * u10));
    a10.ctrlpts = [m12.x, m12.y - (1 + Math.pow(50, 1.12) / 100) * g9 * (f11 / 3 + 1) * b11, m12.x - (1 + Math.pow(50, 1.12) / 100) * g9 * (f11 / 3 + 1) * x10, m12.y];
  }, rs.findStraightEdgePoints = function(e21) {
    e21._private.rscratch.edgeType = "straight";
  }, rs.findBezierPoints = function(e21, t16, n12, r9, a10) {
    var i11 = e21._private.rscratch, o12 = t16.vectorNormInverse, s11 = t16.posPts, l11 = t16.intersectionPts, u10 = e21.pstyle("edge-distances").value, c10 = e21.pstyle("control-point-step-size").pfValue, d12 = e21.pstyle("control-point-distances"), h10 = e21.pstyle("control-point-weights"), p10 = d12 && h10 ? Math.min(d12.value.length, h10.value.length) : 1, f11 = d12 ? d12.pfValue[0] : void 0, g9 = h10.value[0], v12 = r9;
    i11.edgeType = v12 ? "multibezier" : "bezier", i11.ctrlpts = [];
    for (var y10 = 0; y10 < p10; y10++) {
      var m12 = (0.5 - t16.eles.length / 2 + n12) * c10 * (a10 ? -1 : 1), b11 = void 0, x10 = ut4(m12);
      v12 && (f11 = d12 ? d12.pfValue[y10] : c10, g9 = h10.value[y10]);
      var w11 = void 0 !== (b11 = r9 ? f11 : void 0 !== f11 ? x10 * f11 : void 0) ? b11 : m12, E9 = 1 - g9, k10 = g9, C9 = "node-position" === u10 ? s11 : l11, S8 = { x: C9.x1 * E9 + C9.x2 * k10, y: C9.y1 * E9 + C9.y2 * k10 };
      i11.ctrlpts.push(S8.x + o12.x * w11, S8.y + o12.y * w11);
    }
  }, rs.findTaxiPoints = function(e21, t16) {
    var n12 = e21._private.rscratch;
    n12.edgeType = "segments";
    var r9 = "vertical", a10 = "horizontal", i11 = "leftward", o12 = "rightward", s11 = "downward", l11 = "upward", u10 = t16.posPts, c10 = t16.srcW, d12 = t16.srcH, h10 = t16.tgtW, p10 = t16.tgtH, f11 = "node-position" !== e21.pstyle("edge-distances").value, g9 = e21.pstyle("taxi-direction").value, v12 = g9, y10 = e21.pstyle("taxi-turn"), m12 = "%" === y10.units, b11 = y10.pfValue, x10 = b11 < 0, w11 = e21.pstyle("taxi-turn-min-distance").pfValue, E9 = f11 ? (c10 + h10) / 2 : 0, k10 = f11 ? (d12 + p10) / 2 : 0, C9 = u10.x2 - u10.x1, S8 = u10.y2 - u10.y1, D9 = function(e22, t17) {
      return e22 > 0 ? Math.max(e22 - t17, 0) : Math.min(e22 + t17, 0);
    }, P10 = D9(C9, E9), T9 = D9(S8, k10), M9 = false;
    "auto" === v12 ? g9 = Math.abs(P10) > Math.abs(T9) ? a10 : r9 : v12 === l11 || v12 === s11 ? (g9 = r9, M9 = true) : v12 !== i11 && v12 !== o12 || (g9 = a10, M9 = true);
    var B9, _7 = g9 === r9, N8 = _7 ? T9 : P10, I8 = _7 ? S8 : C9, z8 = ut4(I8), L9 = false;
    (M9 && (m12 || x10) || !(v12 === s11 && I8 < 0 || v12 === l11 && I8 > 0 || v12 === i11 && I8 > 0 || v12 === o12 && I8 < 0) || (N8 = (z8 *= -1) * Math.abs(N8), L9 = true), m12) ? B9 = (b11 < 0 ? 1 + b11 : b11) * N8 : B9 = (b11 < 0 ? N8 : 0) + b11 * z8;
    var A10 = function(e22) {
      return Math.abs(e22) < w11 || Math.abs(e22) >= Math.abs(N8);
    }, O10 = A10(B9), R8 = A10(Math.abs(N8) - Math.abs(B9));
    if ((O10 || R8) && !L9)
      if (_7) {
        var V8 = Math.abs(I8) <= d12 / 2, F9 = Math.abs(C9) <= h10 / 2;
        if (V8) {
          var q8 = (u10.x1 + u10.x2) / 2, j9 = u10.y1, Y6 = u10.y2;
          n12.segpts = [q8, j9, q8, Y6];
        } else if (F9) {
          var X6 = (u10.y1 + u10.y2) / 2, W8 = u10.x1, H8 = u10.x2;
          n12.segpts = [W8, X6, H8, X6];
        } else
          n12.segpts = [u10.x1, u10.y2];
      } else {
        var K6 = Math.abs(I8) <= c10 / 2, G7 = Math.abs(S8) <= p10 / 2;
        if (K6) {
          var U7 = (u10.y1 + u10.y2) / 2, Z6 = u10.x1, $8 = u10.x2;
          n12.segpts = [Z6, U7, $8, U7];
        } else if (G7) {
          var Q6 = (u10.x1 + u10.x2) / 2, J6 = u10.y1, ee3 = u10.y2;
          n12.segpts = [Q6, J6, Q6, ee3];
        } else
          n12.segpts = [u10.x2, u10.y1];
      }
    else if (_7) {
      var te3 = u10.y1 + B9 + (f11 ? d12 / 2 * z8 : 0), ne3 = u10.x1, re3 = u10.x2;
      n12.segpts = [ne3, te3, re3, te3];
    } else {
      var ae3 = u10.x1 + B9 + (f11 ? c10 / 2 * z8 : 0), ie3 = u10.y1, oe3 = u10.y2;
      n12.segpts = [ae3, ie3, ae3, oe3];
    }
  }, rs.tryToCorrectInvalidPoints = function(e21, t16) {
    var n12 = e21._private.rscratch;
    if ("bezier" === n12.edgeType) {
      var r9 = t16.srcPos, a10 = t16.tgtPos, i11 = t16.srcW, o12 = t16.srcH, s11 = t16.tgtW, l11 = t16.tgtH, u10 = t16.srcShape, c10 = t16.tgtShape, d12 = !I6(n12.startX) || !I6(n12.startY), h10 = !I6(n12.arrowStartX) || !I6(n12.arrowStartY), p10 = !I6(n12.endX) || !I6(n12.endY), f11 = !I6(n12.arrowEndX) || !I6(n12.arrowEndY), g9 = 3 * (this.getArrowWidth(e21.pstyle("width").pfValue, e21.pstyle("arrow-scale").value) * this.arrowShapeWidth), v12 = ct4({ x: n12.ctrlpts[0], y: n12.ctrlpts[1] }, { x: n12.startX, y: n12.startY }), y10 = v12 < g9, m12 = ct4({ x: n12.ctrlpts[0], y: n12.ctrlpts[1] }, { x: n12.endX, y: n12.endY }), b11 = m12 < g9, x10 = false;
      if (d12 || h10 || y10) {
        x10 = true;
        var w11 = { x: n12.ctrlpts[0] - r9.x, y: n12.ctrlpts[1] - r9.y }, E9 = Math.sqrt(w11.x * w11.x + w11.y * w11.y), k10 = { x: w11.x / E9, y: w11.y / E9 }, C9 = Math.max(i11, o12), S8 = { x: n12.ctrlpts[0] + 2 * k10.x * C9, y: n12.ctrlpts[1] + 2 * k10.y * C9 }, D9 = u10.intersectLine(r9.x, r9.y, i11, o12, S8.x, S8.y, 0);
        y10 ? (n12.ctrlpts[0] = n12.ctrlpts[0] + k10.x * (g9 - v12), n12.ctrlpts[1] = n12.ctrlpts[1] + k10.y * (g9 - v12)) : (n12.ctrlpts[0] = D9[0] + k10.x * g9, n12.ctrlpts[1] = D9[1] + k10.y * g9);
      }
      if (p10 || f11 || b11) {
        x10 = true;
        var P10 = { x: n12.ctrlpts[0] - a10.x, y: n12.ctrlpts[1] - a10.y }, T9 = Math.sqrt(P10.x * P10.x + P10.y * P10.y), M9 = { x: P10.x / T9, y: P10.y / T9 }, B9 = Math.max(i11, o12), _7 = { x: n12.ctrlpts[0] + 2 * M9.x * B9, y: n12.ctrlpts[1] + 2 * M9.y * B9 }, N8 = c10.intersectLine(a10.x, a10.y, s11, l11, _7.x, _7.y, 0);
        b11 ? (n12.ctrlpts[0] = n12.ctrlpts[0] + M9.x * (g9 - m12), n12.ctrlpts[1] = n12.ctrlpts[1] + M9.y * (g9 - m12)) : (n12.ctrlpts[0] = N8[0] + M9.x * g9, n12.ctrlpts[1] = N8[1] + M9.y * g9);
      }
      x10 && this.findEndpoints(e21);
    }
  }, rs.storeAllpts = function(e21) {
    var t16 = e21._private.rscratch;
    if ("multibezier" === t16.edgeType || "bezier" === t16.edgeType || "self" === t16.edgeType || "compound" === t16.edgeType) {
      t16.allpts = [], t16.allpts.push(t16.startX, t16.startY);
      for (var n12 = 0; n12 + 1 < t16.ctrlpts.length; n12 += 2)
        t16.allpts.push(t16.ctrlpts[n12], t16.ctrlpts[n12 + 1]), n12 + 3 < t16.ctrlpts.length && t16.allpts.push((t16.ctrlpts[n12] + t16.ctrlpts[n12 + 2]) / 2, (t16.ctrlpts[n12 + 1] + t16.ctrlpts[n12 + 3]) / 2);
      var r9;
      t16.allpts.push(t16.endX, t16.endY), t16.ctrlpts.length / 2 % 2 == 0 ? (r9 = t16.allpts.length / 2 - 1, t16.midX = t16.allpts[r9], t16.midY = t16.allpts[r9 + 1]) : (r9 = t16.allpts.length / 2 - 3, t16.midX = pt4(t16.allpts[r9], t16.allpts[r9 + 2], t16.allpts[r9 + 4], 0.5), t16.midY = pt4(t16.allpts[r9 + 1], t16.allpts[r9 + 3], t16.allpts[r9 + 5], 0.5));
    } else if ("straight" === t16.edgeType)
      t16.allpts = [t16.startX, t16.startY, t16.endX, t16.endY], t16.midX = (t16.startX + t16.endX + t16.arrowStartX + t16.arrowEndX) / 4, t16.midY = (t16.startY + t16.endY + t16.arrowStartY + t16.arrowEndY) / 4;
    else if ("segments" === t16.edgeType)
      if (t16.allpts = [], t16.allpts.push(t16.startX, t16.startY), t16.allpts.push.apply(t16.allpts, t16.segpts), t16.allpts.push(t16.endX, t16.endY), t16.segpts.length % 4 == 0) {
        var a10 = t16.segpts.length / 2, i11 = a10 - 2;
        t16.midX = (t16.segpts[i11] + t16.segpts[a10]) / 2, t16.midY = (t16.segpts[i11 + 1] + t16.segpts[a10 + 1]) / 2;
      } else {
        var o12 = t16.segpts.length / 2 - 1;
        t16.midX = t16.segpts[o12], t16.midY = t16.segpts[o12 + 1];
      }
  }, rs.checkForInvalidEdgeWarning = function(e21) {
    var t16 = e21[0]._private.rscratch;
    t16.nodesOverlap || I6(t16.startX) && I6(t16.startY) && I6(t16.endX) && I6(t16.endY) ? t16.loggedErr = false : t16.loggedErr || (t16.loggedErr = true, Me("Edge `" + e21.id() + "` has invalid endpoints and so it is impossible to draw.  Adjust your edge style (e.g. control points) accordingly or use an alternative edge type.  This is expected behaviour when the source node and the target node overlap."));
  }, rs.findEdgeControlPoints = function(e21) {
    var t16 = this;
    if (e21 && 0 !== e21.length) {
      for (var n12 = this, r9 = n12.cy.hasCompoundNodes(), a10 = { map: new Ve(), get: function(e22) {
        var t17 = this.map.get(e22[0]);
        return null != t17 ? t17.get(e22[1]) : null;
      }, set: function(e22, t17) {
        var n13 = this.map.get(e22[0]);
        null == n13 && (n13 = new Ve(), this.map.set(e22[0], n13)), n13.set(e22[1], t17);
      } }, i11 = [], o12 = [], s11 = 0; s11 < e21.length; s11++) {
        var l11 = e21[s11], u10 = l11._private, c10 = l11.pstyle("curve-style").value;
        if (!l11.removed() && l11.takesUpSpace())
          if ("haystack" !== c10) {
            var d12 = "unbundled-bezier" === c10 || "segments" === c10 || "straight" === c10 || "straight-triangle" === c10 || "taxi" === c10, h10 = "unbundled-bezier" === c10 || "bezier" === c10, p10 = u10.source, f11 = u10.target, g9 = [p10.poolIndex(), f11.poolIndex()].sort(), v12 = a10.get(g9);
            null == v12 && (v12 = { eles: [] }, a10.set(g9, v12), i11.push(g9)), v12.eles.push(l11), d12 && (v12.hasUnbundled = true), h10 && (v12.hasBezier = true);
          } else
            o12.push(l11);
      }
      for (var y10 = function(e22) {
        var o13 = i11[e22], s12 = a10.get(o13), l12 = void 0;
        if (!s12.hasUnbundled) {
          var u11 = s12.eles[0].parallelEdges().filter(function(e23) {
            return e23.isBundledBezier();
          });
          Ae(s12.eles), u11.forEach(function(e23) {
            return s12.eles.push(e23);
          }), s12.eles.sort(function(e23, t17) {
            return e23.poolIndex() - t17.poolIndex();
          });
        }
        var c11 = s12.eles[0], d13 = c11.source(), h11 = c11.target();
        if (d13.poolIndex() > h11.poolIndex()) {
          var p11 = d13;
          d13 = h11, h11 = p11;
        }
        var f12 = s12.srcPos = d13.position(), g10 = s12.tgtPos = h11.position(), v13 = s12.srcW = d13.outerWidth(), y11 = s12.srcH = d13.outerHeight(), m13 = s12.tgtW = h11.outerWidth(), b11 = s12.tgtH = h11.outerHeight(), x10 = s12.srcShape = n12.nodeShapes[t16.getNodeShape(d13)], w11 = s12.tgtShape = n12.nodeShapes[t16.getNodeShape(h11)];
        s12.dirCounts = { north: 0, west: 0, south: 0, east: 0, northwest: 0, southwest: 0, northeast: 0, southeast: 0 };
        for (var E9 = 0; E9 < s12.eles.length; E9++) {
          var k10 = s12.eles[E9], C9 = k10[0]._private.rscratch, S8 = k10.pstyle("curve-style").value, D9 = "unbundled-bezier" === S8 || "segments" === S8 || "taxi" === S8, P10 = !d13.same(k10.source());
          if (!s12.calculatedIntersection && d13 !== h11 && (s12.hasBezier || s12.hasUnbundled)) {
            s12.calculatedIntersection = true;
            var T9 = x10.intersectLine(f12.x, f12.y, v13, y11, g10.x, g10.y, 0), M9 = s12.srcIntn = T9, B9 = w11.intersectLine(g10.x, g10.y, m13, b11, f12.x, f12.y, 0), _7 = s12.tgtIntn = B9, N8 = s12.intersectionPts = { x1: T9[0], x2: B9[0], y1: T9[1], y2: B9[1] }, z8 = s12.posPts = { x1: f12.x, x2: g10.x, y1: f12.y, y2: g10.y }, L9 = B9[1] - T9[1], A10 = B9[0] - T9[0], O10 = Math.sqrt(A10 * A10 + L9 * L9), R8 = s12.vector = { x: A10, y: L9 }, V8 = s12.vectorNorm = { x: R8.x / O10, y: R8.y / O10 }, F9 = { x: -V8.y, y: V8.x };
            s12.nodesOverlap = !I6(O10) || w11.checkPoint(T9[0], T9[1], 0, m13, b11, g10.x, g10.y) || x10.checkPoint(B9[0], B9[1], 0, v13, y11, f12.x, f12.y), s12.vectorNormInverse = F9, l12 = { nodesOverlap: s12.nodesOverlap, dirCounts: s12.dirCounts, calculatedIntersection: true, hasBezier: s12.hasBezier, hasUnbundled: s12.hasUnbundled, eles: s12.eles, srcPos: g10, tgtPos: f12, srcW: m13, srcH: b11, tgtW: v13, tgtH: y11, srcIntn: _7, tgtIntn: M9, srcShape: w11, tgtShape: x10, posPts: { x1: z8.x2, y1: z8.y2, x2: z8.x1, y2: z8.y1 }, intersectionPts: { x1: N8.x2, y1: N8.y2, x2: N8.x1, y2: N8.y1 }, vector: { x: -R8.x, y: -R8.y }, vectorNorm: { x: -V8.x, y: -V8.y }, vectorNormInverse: { x: -F9.x, y: -F9.y } };
          }
          var q8 = P10 ? l12 : s12;
          C9.nodesOverlap = q8.nodesOverlap, C9.srcIntn = q8.srcIntn, C9.tgtIntn = q8.tgtIntn, r9 && (d13.isParent() || d13.isChild() || h11.isParent() || h11.isChild()) && (d13.parents().anySame(h11) || h11.parents().anySame(d13) || d13.same(h11) && d13.isParent()) ? t16.findCompoundLoopPoints(k10, q8, E9, D9) : d13 === h11 ? t16.findLoopPoints(k10, q8, E9, D9) : "segments" === S8 ? t16.findSegmentsPoints(k10, q8) : "taxi" === S8 ? t16.findTaxiPoints(k10, q8) : "straight" === S8 || !D9 && s12.eles.length % 2 == 1 && E9 === Math.floor(s12.eles.length / 2) ? t16.findStraightEdgePoints(k10) : t16.findBezierPoints(k10, q8, E9, D9, P10), t16.findEndpoints(k10), t16.tryToCorrectInvalidPoints(k10, q8), t16.checkForInvalidEdgeWarning(k10), t16.storeAllpts(k10), t16.storeEdgeProjections(k10), t16.calculateArrowAngles(k10), t16.recalculateEdgeLabelProjections(k10), t16.calculateLabelAngles(k10);
        }
      }, m12 = 0; m12 < i11.length; m12++)
        y10(m12);
      this.findHaystackPoints(o12);
    }
  }, rs.getSegmentPoints = function(e21) {
    var t16 = e21[0]._private.rscratch;
    if ("segments" === t16.edgeType)
      return this.recalculateRenderedStyle(e21), as(t16.segpts);
  }, rs.getControlPoints = function(e21) {
    var t16 = e21[0]._private.rscratch, n12 = t16.edgeType;
    if ("bezier" === n12 || "multibezier" === n12 || "self" === n12 || "compound" === n12)
      return this.recalculateRenderedStyle(e21), as(t16.ctrlpts);
  }, rs.getEdgeMidpoint = function(e21) {
    var t16 = e21[0]._private.rscratch;
    return this.recalculateRenderedStyle(e21), { x: t16.midX, y: t16.midY };
  };
  var is = { manualEndptToPx: function(e21, t16) {
    var n12 = e21.position(), r9 = e21.outerWidth(), a10 = e21.outerHeight();
    if (2 === t16.value.length) {
      var i11 = [t16.pfValue[0], t16.pfValue[1]];
      return "%" === t16.units[0] && (i11[0] = i11[0] * r9), "%" === t16.units[1] && (i11[1] = i11[1] * a10), i11[0] += n12.x, i11[1] += n12.y, i11;
    }
    var o12 = t16.pfValue[0];
    o12 = -Math.PI / 2 + o12;
    var s11 = 2 * Math.max(r9, a10), l11 = [n12.x + Math.cos(o12) * s11, n12.y + Math.sin(o12) * s11];
    return this.nodeShapes[this.getNodeShape(e21)].intersectLine(n12.x, n12.y, r9, a10, l11[0], l11[1], 0);
  }, findEndpoints: function(e21) {
    var t16, n12, r9, a10, i11, o12 = this, s11 = e21.source()[0], l11 = e21.target()[0], u10 = s11.position(), c10 = l11.position(), d12 = e21.pstyle("target-arrow-shape").value, h10 = e21.pstyle("source-arrow-shape").value, p10 = e21.pstyle("target-distance-from-node").pfValue, f11 = e21.pstyle("source-distance-from-node").pfValue, g9 = e21.pstyle("curve-style").value, v12 = e21._private.rscratch, y10 = v12.edgeType, m12 = "self" === y10 || "compound" === y10, b11 = "bezier" === y10 || "multibezier" === y10 || m12, x10 = "bezier" !== y10, w11 = "straight" === y10 || "segments" === y10, E9 = "segments" === y10, k10 = b11 || x10 || w11, C9 = m12 || "taxi" === g9, S8 = e21.pstyle("source-endpoint"), D9 = C9 ? "outside-to-node" : S8.value, P10 = e21.pstyle("target-endpoint"), T9 = C9 ? "outside-to-node" : P10.value;
    if (v12.srcManEndpt = S8, v12.tgtManEndpt = P10, b11) {
      var M9 = [v12.ctrlpts[0], v12.ctrlpts[1]];
      n12 = x10 ? [v12.ctrlpts[v12.ctrlpts.length - 2], v12.ctrlpts[v12.ctrlpts.length - 1]] : M9, r9 = M9;
    } else if (w11) {
      var B9 = E9 ? v12.segpts.slice(0, 2) : [c10.x, c10.y];
      n12 = E9 ? v12.segpts.slice(v12.segpts.length - 2) : [u10.x, u10.y], r9 = B9;
    }
    if ("inside-to-node" === T9)
      t16 = [c10.x, c10.y];
    else if (P10.units)
      t16 = this.manualEndptToPx(l11, P10);
    else if ("outside-to-line" === T9)
      t16 = v12.tgtIntn;
    else if ("outside-to-node" === T9 || "outside-to-node-or-label" === T9 ? a10 = n12 : "outside-to-line" !== T9 && "outside-to-line-or-label" !== T9 || (a10 = [u10.x, u10.y]), t16 = o12.nodeShapes[this.getNodeShape(l11)].intersectLine(c10.x, c10.y, l11.outerWidth(), l11.outerHeight(), a10[0], a10[1], 0), "outside-to-node-or-label" === T9 || "outside-to-line-or-label" === T9) {
      var _7 = l11._private.rscratch, N8 = _7.labelWidth, z8 = _7.labelHeight, L9 = _7.labelX, A10 = _7.labelY, O10 = N8 / 2, R8 = z8 / 2, V8 = l11.pstyle("text-valign").value;
      "top" === V8 ? A10 -= R8 : "bottom" === V8 && (A10 += R8);
      var F9 = l11.pstyle("text-halign").value;
      "left" === F9 ? L9 -= O10 : "right" === F9 && (L9 += O10);
      var q8 = Ot4(a10[0], a10[1], [L9 - O10, A10 - R8, L9 + O10, A10 - R8, L9 + O10, A10 + R8, L9 - O10, A10 + R8], c10.x, c10.y);
      if (q8.length > 0) {
        var j9 = u10, Y6 = dt4(j9, ot4(t16)), X6 = dt4(j9, ot4(q8)), W8 = Y6;
        if (X6 < Y6 && (t16 = q8, W8 = X6), q8.length > 2)
          dt4(j9, { x: q8[2], y: q8[3] }) < W8 && (t16 = [q8[2], q8[3]]);
      }
    }
    var H8 = Rt4(t16, n12, o12.arrowShapes[d12].spacing(e21) + p10), K6 = Rt4(t16, n12, o12.arrowShapes[d12].gap(e21) + p10);
    if (v12.endX = K6[0], v12.endY = K6[1], v12.arrowEndX = H8[0], v12.arrowEndY = H8[1], "inside-to-node" === D9)
      t16 = [u10.x, u10.y];
    else if (S8.units)
      t16 = this.manualEndptToPx(s11, S8);
    else if ("outside-to-line" === D9)
      t16 = v12.srcIntn;
    else if ("outside-to-node" === D9 || "outside-to-node-or-label" === D9 ? i11 = r9 : "outside-to-line" !== D9 && "outside-to-line-or-label" !== D9 || (i11 = [c10.x, c10.y]), t16 = o12.nodeShapes[this.getNodeShape(s11)].intersectLine(u10.x, u10.y, s11.outerWidth(), s11.outerHeight(), i11[0], i11[1], 0), "outside-to-node-or-label" === D9 || "outside-to-line-or-label" === D9) {
      var G7 = s11._private.rscratch, U7 = G7.labelWidth, Z6 = G7.labelHeight, $8 = G7.labelX, Q6 = G7.labelY, J6 = U7 / 2, ee3 = Z6 / 2, te3 = s11.pstyle("text-valign").value;
      "top" === te3 ? Q6 -= ee3 : "bottom" === te3 && (Q6 += ee3);
      var ne3 = s11.pstyle("text-halign").value;
      "left" === ne3 ? $8 -= J6 : "right" === ne3 && ($8 += J6);
      var re3 = Ot4(i11[0], i11[1], [$8 - J6, Q6 - ee3, $8 + J6, Q6 - ee3, $8 + J6, Q6 + ee3, $8 - J6, Q6 + ee3], u10.x, u10.y);
      if (re3.length > 0) {
        var ae3 = c10, ie3 = dt4(ae3, ot4(t16)), oe3 = dt4(ae3, ot4(re3)), se3 = ie3;
        if (oe3 < ie3 && (t16 = [re3[0], re3[1]], se3 = oe3), re3.length > 2)
          dt4(ae3, { x: re3[2], y: re3[3] }) < se3 && (t16 = [re3[2], re3[3]]);
      }
    }
    var le3 = Rt4(t16, r9, o12.arrowShapes[h10].spacing(e21) + f11), ue3 = Rt4(t16, r9, o12.arrowShapes[h10].gap(e21) + f11);
    v12.startX = ue3[0], v12.startY = ue3[1], v12.arrowStartX = le3[0], v12.arrowStartY = le3[1], k10 && (I6(v12.startX) && I6(v12.startY) && I6(v12.endX) && I6(v12.endY) ? v12.badLine = false : v12.badLine = true);
  }, getSourceEndpoint: function(e21) {
    var t16 = e21[0]._private.rscratch;
    return this.recalculateRenderedStyle(e21), "haystack" === t16.edgeType ? { x: t16.haystackPts[0], y: t16.haystackPts[1] } : { x: t16.arrowStartX, y: t16.arrowStartY };
  }, getTargetEndpoint: function(e21) {
    var t16 = e21[0]._private.rscratch;
    return this.recalculateRenderedStyle(e21), "haystack" === t16.edgeType ? { x: t16.haystackPts[2], y: t16.haystackPts[3] } : { x: t16.arrowEndX, y: t16.arrowEndY };
  } };
  var os = {};
  function ss(e21, t16, n12) {
    for (var r9 = function(e22, t17, n13, r10) {
      return pt4(e22, t17, n13, r10);
    }, a10 = t16._private.rstyle.bezierPts, i11 = 0; i11 < e21.bezierProjPcts.length; i11++) {
      var o12 = e21.bezierProjPcts[i11];
      a10.push({ x: r9(n12[0], n12[2], n12[4], o12), y: r9(n12[1], n12[3], n12[5], o12) });
    }
  }
  os.storeEdgeProjections = function(e21) {
    var t16 = e21._private, n12 = t16.rscratch, r9 = n12.edgeType;
    if (t16.rstyle.bezierPts = null, t16.rstyle.linePts = null, t16.rstyle.haystackPts = null, "multibezier" === r9 || "bezier" === r9 || "self" === r9 || "compound" === r9) {
      t16.rstyle.bezierPts = [];
      for (var a10 = 0; a10 + 5 < n12.allpts.length; a10 += 4)
        ss(this, e21, n12.allpts.slice(a10, a10 + 6));
    } else if ("segments" === r9) {
      var i11 = t16.rstyle.linePts = [];
      for (a10 = 0; a10 + 1 < n12.allpts.length; a10 += 2)
        i11.push({ x: n12.allpts[a10], y: n12.allpts[a10 + 1] });
    } else if ("haystack" === r9) {
      var o12 = n12.haystackPts;
      t16.rstyle.haystackPts = [{ x: o12[0], y: o12[1] }, { x: o12[2], y: o12[3] }];
    }
    t16.rstyle.arrowWidth = this.getArrowWidth(e21.pstyle("width").pfValue, e21.pstyle("arrow-scale").value) * this.arrowShapeWidth;
  }, os.recalculateEdgeProjections = function(e21) {
    this.findEdgeControlPoints(e21);
  };
  var ls = { recalculateNodeLabelProjection: function(e21) {
    var t16 = e21.pstyle("label").strValue;
    if (!F6(t16)) {
      var n12, r9, a10 = e21._private, i11 = e21.width(), o12 = e21.height(), s11 = e21.padding(), l11 = e21.position(), u10 = e21.pstyle("text-halign").strValue, c10 = e21.pstyle("text-valign").strValue, d12 = a10.rscratch, h10 = a10.rstyle;
      switch (u10) {
        case "left":
          n12 = l11.x - i11 / 2 - s11;
          break;
        case "right":
          n12 = l11.x + i11 / 2 + s11;
          break;
        default:
          n12 = l11.x;
      }
      switch (c10) {
        case "top":
          r9 = l11.y - o12 / 2 - s11;
          break;
        case "bottom":
          r9 = l11.y + o12 / 2 + s11;
          break;
        default:
          r9 = l11.y;
      }
      d12.labelX = n12, d12.labelY = r9, h10.labelX = n12, h10.labelY = r9, this.calculateLabelAngles(e21), this.applyLabelDimensions(e21);
    }
  } };
  var us = function(e21, t16) {
    var n12 = Math.atan(t16 / e21);
    return 0 === e21 && n12 < 0 && (n12 *= -1), n12;
  };
  var cs = function(e21, t16) {
    var n12 = t16.x - e21.x, r9 = t16.y - e21.y;
    return us(n12, r9);
  };
  ls.recalculateEdgeLabelProjections = function(e21) {
    var t16, n12 = e21._private, r9 = n12.rscratch, a10 = this, i11 = { mid: e21.pstyle("label").strValue, source: e21.pstyle("source-label").strValue, target: e21.pstyle("target-label").strValue };
    if (i11.mid || i11.source || i11.target) {
      t16 = { x: r9.midX, y: r9.midY };
      var o12 = function(e22, t17, r10) {
        Re(n12.rscratch, e22, t17, r10), Re(n12.rstyle, e22, t17, r10);
      };
      o12("labelX", null, t16.x), o12("labelY", null, t16.y);
      var s11 = us(r9.midDispX, r9.midDispY);
      o12("labelAutoAngle", null, s11);
      var l11 = function e22() {
        if (e22.cache)
          return e22.cache;
        for (var t17 = [], i12 = 0; i12 + 5 < r9.allpts.length; i12 += 4) {
          var o13 = { x: r9.allpts[i12], y: r9.allpts[i12 + 1] }, s12 = { x: r9.allpts[i12 + 2], y: r9.allpts[i12 + 3] }, l12 = { x: r9.allpts[i12 + 4], y: r9.allpts[i12 + 5] };
          t17.push({ p0: o13, p1: s12, p2: l12, startDist: 0, length: 0, segments: [] });
        }
        var u11 = n12.rstyle.bezierPts, c10 = a10.bezierProjPcts.length;
        function d12(e23, t18, n13, r10, a11) {
          var i13 = ct4(t18, n13), o14 = e23.segments[e23.segments.length - 1], s13 = { p0: t18, p1: n13, t0: r10, t1: a11, startDist: o14 ? o14.startDist + o14.length : 0, length: i13 };
          e23.segments.push(s13), e23.length += i13;
        }
        for (var h10 = 0; h10 < t17.length; h10++) {
          var p10 = t17[h10], f11 = t17[h10 - 1];
          f11 && (p10.startDist = f11.startDist + f11.length), d12(p10, p10.p0, u11[h10 * c10], 0, a10.bezierProjPcts[0]);
          for (var g9 = 0; g9 < c10 - 1; g9++)
            d12(p10, u11[h10 * c10 + g9], u11[h10 * c10 + g9 + 1], a10.bezierProjPcts[g9], a10.bezierProjPcts[g9 + 1]);
          d12(p10, u11[h10 * c10 + c10 - 1], p10.p2, a10.bezierProjPcts[c10 - 1], 1);
        }
        return e22.cache = t17;
      }, u10 = function(n13) {
        var a11, s12 = "source" === n13;
        if (i11[n13]) {
          var u11 = e21.pstyle(n13 + "-text-offset").pfValue;
          switch (r9.edgeType) {
            case "self":
            case "compound":
            case "bezier":
            case "multibezier":
              for (var c10, d12 = l11(), h10 = 0, p10 = 0, f11 = 0; f11 < d12.length; f11++) {
                for (var g9 = d12[s12 ? f11 : d12.length - 1 - f11], v12 = 0; v12 < g9.segments.length; v12++) {
                  var y10 = g9.segments[s12 ? v12 : g9.segments.length - 1 - v12], m12 = f11 === d12.length - 1 && v12 === g9.segments.length - 1;
                  if (h10 = p10, (p10 += y10.length) >= u11 || m12) {
                    c10 = { cp: g9, segment: y10 };
                    break;
                  }
                }
                if (c10)
                  break;
              }
              var b11 = c10.cp, x10 = c10.segment, w11 = (u11 - h10) / x10.length, E9 = x10.t1 - x10.t0, k10 = s12 ? x10.t0 + E9 * w11 : x10.t1 - E9 * w11;
              k10 = gt4(0, k10, 1), t16 = ft4(b11.p0, b11.p1, b11.p2, k10), a11 = function(e22, t17, n14, r10) {
                var a12 = gt4(0, r10 - 1e-3, 1), i12 = gt4(0, r10 + 1e-3, 1), o13 = ft4(e22, t17, n14, a12), s13 = ft4(e22, t17, n14, i12);
                return cs(o13, s13);
              }(b11.p0, b11.p1, b11.p2, k10);
              break;
            case "straight":
            case "segments":
            case "haystack":
              for (var C9, S8, D9, P10, T9 = 0, M9 = r9.allpts.length, B9 = 0; B9 + 3 < M9 && (s12 ? (D9 = { x: r9.allpts[B9], y: r9.allpts[B9 + 1] }, P10 = { x: r9.allpts[B9 + 2], y: r9.allpts[B9 + 3] }) : (D9 = { x: r9.allpts[M9 - 2 - B9], y: r9.allpts[M9 - 1 - B9] }, P10 = { x: r9.allpts[M9 - 4 - B9], y: r9.allpts[M9 - 3 - B9] }), S8 = T9, !((T9 += C9 = ct4(D9, P10)) >= u11)); B9 += 2)
                ;
              var _7 = (u11 - S8) / C9;
              _7 = gt4(0, _7, 1), t16 = function(e22, t17, n14, r10) {
                var a12 = t17.x - e22.x, i12 = t17.y - e22.y, o13 = ct4(e22, t17), s13 = a12 / o13, l12 = i12 / o13;
                return n14 = null == n14 ? 0 : n14, r10 = null != r10 ? r10 : n14 * o13, { x: e22.x + s13 * r10, y: e22.y + l12 * r10 };
              }(D9, P10, _7), a11 = cs(D9, P10);
          }
          o12("labelX", n13, t16.x), o12("labelY", n13, t16.y), o12("labelAutoAngle", n13, a11);
        }
      };
      u10("source"), u10("target"), this.applyLabelDimensions(e21);
    }
  }, ls.applyLabelDimensions = function(e21) {
    this.applyPrefixedLabelDimensions(e21), e21.isEdge() && (this.applyPrefixedLabelDimensions(e21, "source"), this.applyPrefixedLabelDimensions(e21, "target"));
  }, ls.applyPrefixedLabelDimensions = function(e21, t16) {
    var n12 = e21._private, r9 = this.getLabelText(e21, t16), a10 = this.calculateLabelDimensions(e21, r9), i11 = e21.pstyle("line-height").pfValue, o12 = e21.pstyle("text-wrap").strValue, s11 = Oe(n12.rscratch, "labelWrapCachedLines", t16) || [], l11 = "wrap" !== o12 ? 1 : Math.max(s11.length, 1), u10 = a10.height / l11, c10 = u10 * i11, d12 = a10.width, h10 = a10.height + (l11 - 1) * (i11 - 1) * u10;
    Re(n12.rstyle, "labelWidth", t16, d12), Re(n12.rscratch, "labelWidth", t16, d12), Re(n12.rstyle, "labelHeight", t16, h10), Re(n12.rscratch, "labelHeight", t16, h10), Re(n12.rscratch, "labelLineHeight", t16, c10);
  }, ls.getLabelText = function(e21, t16) {
    var n12 = e21._private, r9 = t16 ? t16 + "-" : "", a10 = e21.pstyle(r9 + "label").strValue, i11 = e21.pstyle("text-transform").value, o12 = function(e22, r10) {
      return r10 ? (Re(n12.rscratch, e22, t16, r10), r10) : Oe(n12.rscratch, e22, t16);
    };
    if (!a10)
      return "";
    "none" == i11 || ("uppercase" == i11 ? a10 = a10.toUpperCase() : "lowercase" == i11 && (a10 = a10.toLowerCase()));
    var s11 = e21.pstyle("text-wrap").value;
    if ("wrap" === s11) {
      var l11 = o12("labelKey");
      if (null != l11 && o12("labelWrapKey") === l11)
        return o12("labelWrapCachedText");
      for (var u10 = a10.split("\n"), c10 = e21.pstyle("text-max-width").pfValue, d12 = "anywhere" === e21.pstyle("text-overflow-wrap").value, h10 = [], p10 = /[\s\u200b]+/, f11 = d12 ? "" : " ", g9 = 0; g9 < u10.length; g9++) {
        var v12 = u10[g9], y10 = this.calculateLabelDimensions(e21, v12).width;
        if (d12) {
          var m12 = v12.split("").join("\u200B");
          v12 = m12;
        }
        if (y10 > c10) {
          for (var b11 = v12.split(p10), x10 = "", w11 = 0; w11 < b11.length; w11++) {
            var E9 = b11[w11], k10 = 0 === x10.length ? E9 : x10 + f11 + E9;
            this.calculateLabelDimensions(e21, k10).width <= c10 ? x10 += E9 + f11 : (x10 && h10.push(x10), x10 = E9 + f11);
          }
          x10.match(/^[\s\u200b]+$/) || h10.push(x10);
        } else
          h10.push(v12);
      }
      o12("labelWrapCachedLines", h10), a10 = o12("labelWrapCachedText", h10.join("\n")), o12("labelWrapKey", l11);
    } else if ("ellipsis" === s11) {
      var C9 = e21.pstyle("text-max-width").pfValue, S8 = "", D9 = false;
      if (this.calculateLabelDimensions(e21, a10).width < C9)
        return a10;
      for (var P10 = 0; P10 < a10.length; P10++) {
        if (this.calculateLabelDimensions(e21, S8 + a10[P10] + "\u2026").width > C9)
          break;
        S8 += a10[P10], P10 === a10.length - 1 && (D9 = true);
      }
      return D9 || (S8 += "\u2026"), S8;
    }
    return a10;
  }, ls.getLabelJustification = function(e21) {
    var t16 = e21.pstyle("text-justification").strValue, n12 = e21.pstyle("text-halign").strValue;
    if ("auto" !== t16)
      return t16;
    if (!e21.isNode())
      return "center";
    switch (n12) {
      case "left":
        return "right";
      case "right":
        return "left";
      default:
        return "center";
    }
  }, ls.calculateLabelDimensions = function(e21, t16) {
    var n12 = ve(t16, e21._private.labelDimsKey), r9 = this.labelDimCache || (this.labelDimCache = []), a10 = r9[n12];
    if (null != a10)
      return a10;
    var i11 = e21.pstyle("font-style").strValue, o12 = e21.pstyle("font-size").pfValue, s11 = e21.pstyle("font-family").strValue, l11 = e21.pstyle("font-weight").strValue, u10 = this.labelCalcCanvas, c10 = this.labelCalcCanvasContext;
    if (!u10) {
      u10 = this.labelCalcCanvas = document.createElement("canvas"), c10 = this.labelCalcCanvasContext = u10.getContext("2d");
      var d12 = u10.style;
      d12.position = "absolute", d12.left = "-9999px", d12.top = "-9999px", d12.zIndex = "-1", d12.visibility = "hidden", d12.pointerEvents = "none";
    }
    c10.font = "".concat(i11, " ").concat(l11, " ").concat(o12, "px ").concat(s11);
    for (var h10 = 0, p10 = 0, f11 = t16.split("\n"), g9 = 0; g9 < f11.length; g9++) {
      var v12 = f11[g9], y10 = c10.measureText(v12), m12 = Math.ceil(y10.width), b11 = o12;
      h10 = Math.max(m12, h10), p10 += b11;
    }
    return h10 += 0, p10 += 0, r9[n12] = { width: h10, height: p10 };
  }, ls.calculateLabelAngle = function(e21, t16) {
    var n12 = e21._private.rscratch, r9 = e21.isEdge(), a10 = t16 ? t16 + "-" : "", i11 = e21.pstyle(a10 + "text-rotation"), o12 = i11.strValue;
    return "none" === o12 ? 0 : r9 && "autorotate" === o12 ? n12.labelAutoAngle : "autorotate" === o12 ? 0 : i11.pfValue;
  }, ls.calculateLabelAngles = function(e21) {
    var t16 = this, n12 = e21.isEdge(), r9 = e21._private.rscratch;
    r9.labelAngle = t16.calculateLabelAngle(e21), n12 && (r9.sourceLabelAngle = t16.calculateLabelAngle(e21, "source"), r9.targetLabelAngle = t16.calculateLabelAngle(e21, "target"));
  };
  var ds = {};
  var hs = false;
  ds.getNodeShape = function(e21) {
    var t16 = e21.pstyle("shape").value;
    if ("cutrectangle" === t16 && (e21.width() < 28 || e21.height() < 28))
      return hs || (Me("The `cutrectangle` node shape can not be used at small sizes so `rectangle` is used instead"), hs = true), "rectangle";
    if (e21.isParent())
      return "rectangle" === t16 || "roundrectangle" === t16 || "round-rectangle" === t16 || "cutrectangle" === t16 || "cut-rectangle" === t16 || "barrel" === t16 ? t16 : "rectangle";
    if ("polygon" === t16) {
      var n12 = e21.pstyle("shape-polygon-points").value;
      return this.nodeShapes.makePolygon(n12).name;
    }
    return t16;
  };
  var ps = { registerCalculationListeners: function() {
    var e21 = this.cy, t16 = e21.collection(), n12 = this, r9 = function(e22) {
      var n13 = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
      if (t16.merge(e22), n13)
        for (var r10 = 0; r10 < e22.length; r10++) {
          var a11 = e22[r10]._private.rstyle;
          a11.clean = false, a11.cleanConnected = false;
        }
    };
    n12.binder(e21).on("bounds.* dirty.*", function(e22) {
      var t17 = e22.target;
      r9(t17);
    }).on("style.* background.*", function(e22) {
      var t17 = e22.target;
      r9(t17, false);
    });
    var a10 = function(a11) {
      if (a11) {
        var i11 = n12.onUpdateEleCalcsFns;
        t16.cleanStyle();
        for (var o12 = 0; o12 < t16.length; o12++) {
          var s11 = t16[o12], l11 = s11._private.rstyle;
          s11.isNode() && !l11.cleanConnected && (r9(s11.connectedEdges()), l11.cleanConnected = true);
        }
        if (i11)
          for (var u10 = 0; u10 < i11.length; u10++) {
            (0, i11[u10])(a11, t16);
          }
        n12.recalculateRenderedStyle(t16), t16 = e21.collection();
      }
    };
    n12.flushRenderedStyleQueue = function() {
      a10(true);
    }, n12.beforeRender(a10, n12.beforeRenderPriorities.eleCalcs);
  }, onUpdateEleCalcs: function(e21) {
    (this.onUpdateEleCalcsFns = this.onUpdateEleCalcsFns || []).push(e21);
  }, recalculateRenderedStyle: function(e21, t16) {
    var n12 = function(e22) {
      return e22._private.rstyle.cleanConnected;
    }, r9 = [], a10 = [];
    if (!this.destroyed) {
      void 0 === t16 && (t16 = true);
      for (var i11 = 0; i11 < e21.length; i11++) {
        var o12 = e21[i11], s11 = o12._private, l11 = s11.rstyle;
        !o12.isEdge() || n12(o12.source()) && n12(o12.target()) || (l11.clean = false), t16 && l11.clean || o12.removed() || "none" !== o12.pstyle("display").value && ("nodes" === s11.group ? a10.push(o12) : r9.push(o12), l11.clean = true);
      }
      for (var u10 = 0; u10 < a10.length; u10++) {
        var c10 = a10[u10], d12 = c10._private.rstyle, h10 = c10.position();
        this.recalculateNodeLabelProjection(c10), d12.nodeX = h10.x, d12.nodeY = h10.y, d12.nodeW = c10.pstyle("width").pfValue, d12.nodeH = c10.pstyle("height").pfValue;
      }
      this.recalculateEdgeProjections(r9);
      for (var p10 = 0; p10 < r9.length; p10++) {
        var f11 = r9[p10]._private, g9 = f11.rstyle, v12 = f11.rscratch;
        g9.srcX = v12.arrowStartX, g9.srcY = v12.arrowStartY, g9.tgtX = v12.arrowEndX, g9.tgtY = v12.arrowEndY, g9.midX = v12.midX, g9.midY = v12.midY, g9.labelAngle = v12.labelAngle, g9.sourceLabelAngle = v12.sourceLabelAngle, g9.targetLabelAngle = v12.targetLabelAngle;
      }
    }
  } };
  var fs = { updateCachedGrabbedEles: function() {
    var e21 = this.cachedZSortedEles;
    if (e21) {
      e21.drag = [], e21.nondrag = [];
      for (var t16 = [], n12 = 0; n12 < e21.length; n12++) {
        var r9 = (a10 = e21[n12])._private.rscratch;
        a10.grabbed() && !a10.isParent() ? t16.push(a10) : r9.inDragLayer ? e21.drag.push(a10) : e21.nondrag.push(a10);
      }
      for (n12 = 0; n12 < t16.length; n12++) {
        var a10 = t16[n12];
        e21.drag.push(a10);
      }
    }
  }, invalidateCachedZSortedEles: function() {
    this.cachedZSortedEles = null;
  }, getCachedZSortedEles: function(e21) {
    if (e21 || !this.cachedZSortedEles) {
      var t16 = this.cy.mutableElements().toArray();
      t16.sort(Qa), t16.interactive = t16.filter(function(e22) {
        return e22.interactive();
      }), this.cachedZSortedEles = t16, this.updateCachedGrabbedEles();
    } else
      t16 = this.cachedZSortedEles;
    return t16;
  } };
  var gs = {};
  [ts, ns, rs, is, os, ls, ds, ps, fs].forEach(function(e21) {
    J4(gs, e21);
  });
  var vs = { getCachedImage: function(e21, t16, n12) {
    var r9 = this.imageCache = this.imageCache || {}, a10 = r9[e21];
    if (a10)
      return a10.image.complete || a10.image.addEventListener("load", n12), a10.image;
    var i11 = (a10 = r9[e21] = r9[e21] || {}).image = new Image();
    i11.addEventListener("load", n12), i11.addEventListener("error", function() {
      i11.error = true;
    });
    var o12 = "data:";
    return e21.substring(0, 5).toLowerCase() === o12 || (t16 = "null" === t16 ? null : t16, i11.crossOrigin = t16), i11.src = e21, i11;
  } };
  var ys = { registerBinding: function(e21, t16, n12, r9) {
    var a10 = Array.prototype.slice.apply(arguments, [1]), i11 = this.binder(e21);
    return i11.on.apply(i11, a10);
  } };
  ys.binder = function(e21) {
    var t16, n12 = this, r9 = n12.cy.window(), a10 = e21 === r9 || e21 === r9.document || e21 === r9.document.body || (t16 = e21, "undefined" != typeof HTMLElement && t16 instanceof HTMLElement);
    if (null == n12.supportsPassiveEvents) {
      var i11 = false;
      try {
        var o12 = Object.defineProperty({}, "passive", { get: function() {
          return i11 = true, true;
        } });
        r9.addEventListener("test", null, o12);
      } catch (e22) {
      }
      n12.supportsPassiveEvents = i11;
    }
    var s11 = function(t17, r10, i12) {
      var o13 = Array.prototype.slice.call(arguments);
      return a10 && n12.supportsPassiveEvents && (o13[2] = { capture: null != i12 && i12, passive: false, once: false }), n12.bindings.push({ target: e21, args: o13 }), (e21.addEventListener || e21.on).apply(e21, o13), this;
    };
    return { on: s11, addEventListener: s11, addListener: s11, bind: s11 };
  }, ys.nodeIsDraggable = function(e21) {
    return e21 && e21.isNode() && !e21.locked() && e21.grabbable();
  }, ys.nodeIsGrabbable = function(e21) {
    return this.nodeIsDraggable(e21) && e21.interactive();
  }, ys.load = function() {
    var e21 = this, t16 = e21.cy.window(), n12 = function(e22) {
      return e22.selected();
    }, r9 = function(t17, n13, r10, a11) {
      null == t17 && (t17 = e21.cy);
      for (var i12 = 0; i12 < n13.length; i12++) {
        var o13 = n13[i12];
        t17.emit({ originalEvent: r10, type: o13, position: a11 });
      }
    }, a10 = function(e22) {
      return e22.shiftKey || e22.metaKey || e22.ctrlKey;
    }, i11 = function(t17, n13) {
      var r10 = true;
      if (e21.cy.hasCompoundNodes() && t17 && t17.pannable())
        for (var a11 = 0; n13 && a11 < n13.length; a11++) {
          if ((t17 = n13[a11]).isNode() && t17.isParent() && !t17.pannable()) {
            r10 = false;
            break;
          }
        }
      else
        r10 = true;
      return r10;
    }, o12 = function(e22) {
      e22[0]._private.rscratch.inDragLayer = true;
    }, s11 = function(e22) {
      e22[0]._private.rscratch.isGrabTarget = true;
    }, l11 = function(e22, t17) {
      var n13 = t17.addToList;
      n13.has(e22) || !e22.grabbable() || e22.locked() || (n13.merge(e22), function(e23) {
        e23[0]._private.grabbed = true;
      }(e22));
    }, u10 = function(t17, n13) {
      n13 = n13 || {};
      var r10 = t17.cy().hasCompoundNodes();
      n13.inDragLayer && (t17.forEach(o12), t17.neighborhood().stdFilter(function(e22) {
        return !r10 || e22.isEdge();
      }).forEach(o12)), n13.addToList && t17.forEach(function(e22) {
        l11(e22, n13);
      }), function(e22, t18) {
        if (e22.cy().hasCompoundNodes() && (null != t18.inDragLayer || null != t18.addToList)) {
          var n14 = e22.descendants();
          t18.inDragLayer && (n14.forEach(o12), n14.connectedEdges().forEach(o12)), t18.addToList && l11(n14, t18);
        }
      }(t17, n13), p10(t17, { inDragLayer: n13.inDragLayer }), e21.updateCachedGrabbedEles();
    }, d12 = u10, h10 = function(t17) {
      t17 && (e21.getCachedZSortedEles().forEach(function(e22) {
        !function(e23) {
          e23[0]._private.grabbed = false;
        }(e22), function(e23) {
          e23[0]._private.rscratch.inDragLayer = false;
        }(e22), function(e23) {
          e23[0]._private.rscratch.isGrabTarget = false;
        }(e22);
      }), e21.updateCachedGrabbedEles());
    }, p10 = function(e22, t17) {
      if ((null != t17.inDragLayer || null != t17.addToList) && e22.cy().hasCompoundNodes()) {
        var n13 = e22.ancestors().orphans();
        if (!n13.same(e22)) {
          var r10 = n13.descendants().spawnSelf().merge(n13).unmerge(e22).unmerge(e22.descendants()), a11 = r10.connectedEdges();
          t17.inDragLayer && (a11.forEach(o12), r10.forEach(o12)), t17.addToList && r10.forEach(function(e23) {
            l11(e23, t17);
          });
        }
      }
    }, f11 = function() {
      null != document.activeElement && null != document.activeElement.blur && document.activeElement.blur();
    }, g9 = "undefined" != typeof MutationObserver, v12 = "undefined" != typeof ResizeObserver;
    g9 ? (e21.removeObserver = new MutationObserver(function(t17) {
      for (var n13 = 0; n13 < t17.length; n13++) {
        var r10 = t17[n13].removedNodes;
        if (r10)
          for (var a11 = 0; a11 < r10.length; a11++) {
            if (r10[a11] === e21.container) {
              e21.destroy();
              break;
            }
          }
      }
    }), e21.container.parentNode && e21.removeObserver.observe(e21.container.parentNode, { childList: true })) : e21.registerBinding(e21.container, "DOMNodeRemoved", function(t17) {
      e21.destroy();
    });
    var y10 = c6.default(function() {
      e21.cy.resize();
    }, 100);
    g9 && (e21.styleObserver = new MutationObserver(y10), e21.styleObserver.observe(e21.container, { attributes: true })), e21.registerBinding(t16, "resize", y10), v12 && (e21.resizeObserver = new ResizeObserver(y10), e21.resizeObserver.observe(e21.container));
    var m12 = function() {
      e21.invalidateContainerClientCoordsCache();
    };
    !function(e22, t17) {
      for (; null != e22; )
        t17(e22), e22 = e22.parentNode;
    }(e21.container, function(t17) {
      e21.registerBinding(t17, "transitionend", m12), e21.registerBinding(t17, "animationend", m12), e21.registerBinding(t17, "scroll", m12);
    }), e21.registerBinding(e21.container, "contextmenu", function(e22) {
      e22.preventDefault();
    });
    var b11, x10, w11, E9 = function(t17) {
      for (var n13 = e21.findContainerClientCoords(), r10 = n13[0], a11 = n13[1], i12 = n13[2], o13 = n13[3], s12 = t17.touches ? t17.touches : [t17], l12 = false, u11 = 0; u11 < s12.length; u11++) {
        var c10 = s12[u11];
        if (r10 <= c10.clientX && c10.clientX <= r10 + i12 && a11 <= c10.clientY && c10.clientY <= a11 + o13) {
          l12 = true;
          break;
        }
      }
      if (!l12)
        return false;
      for (var d13 = e21.container, h11 = t17.target.parentNode, p11 = false; h11; ) {
        if (h11 === d13) {
          p11 = true;
          break;
        }
        h11 = h11.parentNode;
      }
      return !!p11;
    };
    e21.registerBinding(e21.container, "mousedown", function(t17) {
      if (E9(t17)) {
        t17.preventDefault(), f11(), e21.hoverData.capture = true, e21.hoverData.which = t17.which;
        var n13 = e21.cy, a11 = [t17.clientX, t17.clientY], i12 = e21.projectIntoViewport(a11[0], a11[1]), o13 = e21.selection, l12 = e21.findNearestElements(i12[0], i12[1], true, false), c10 = l12[0], h11 = e21.dragData.possibleDragElements;
        e21.hoverData.mdownPos = i12, e21.hoverData.mdownGPos = a11;
        if (3 == t17.which) {
          e21.hoverData.cxtStarted = true;
          var p11 = { originalEvent: t17, type: "cxttapstart", position: { x: i12[0], y: i12[1] } };
          c10 ? (c10.activate(), c10.emit(p11), e21.hoverData.down = c10) : n13.emit(p11), e21.hoverData.downTime = (/* @__PURE__ */ new Date()).getTime(), e21.hoverData.cxtDragged = false;
        } else if (1 == t17.which) {
          if (c10 && c10.activate(), null != c10 && e21.nodeIsGrabbable(c10)) {
            var g10 = function(e22) {
              return { originalEvent: t17, type: e22, position: { x: i12[0], y: i12[1] } };
            };
            if (s11(c10), c10.selected()) {
              h11 = e21.dragData.possibleDragElements = n13.collection();
              var v13 = n13.$(function(t18) {
                return t18.isNode() && t18.selected() && e21.nodeIsGrabbable(t18);
              });
              u10(v13, { addToList: h11 }), c10.emit(g10("grabon")), v13.forEach(function(e22) {
                e22.emit(g10("grab"));
              });
            } else
              h11 = e21.dragData.possibleDragElements = n13.collection(), d12(c10, { addToList: h11 }), c10.emit(g10("grabon")).emit(g10("grab"));
            e21.redrawHint("eles", true), e21.redrawHint("drag", true);
          }
          e21.hoverData.down = c10, e21.hoverData.downs = l12, e21.hoverData.downTime = (/* @__PURE__ */ new Date()).getTime(), r9(c10, ["mousedown", "tapstart", "vmousedown"], t17, { x: i12[0], y: i12[1] }), null == c10 ? (o13[4] = 1, e21.data.bgActivePosistion = { x: i12[0], y: i12[1] }, e21.redrawHint("select", true), e21.redraw()) : c10.pannable() && (o13[4] = 1), e21.hoverData.tapholdCancelled = false, clearTimeout(e21.hoverData.tapholdTimeout), e21.hoverData.tapholdTimeout = setTimeout(function() {
            if (!e21.hoverData.tapholdCancelled) {
              var r10 = e21.hoverData.down;
              r10 ? r10.emit({ originalEvent: t17, type: "taphold", position: { x: i12[0], y: i12[1] } }) : n13.emit({ originalEvent: t17, type: "taphold", position: { x: i12[0], y: i12[1] } });
            }
          }, e21.tapholdDuration);
        }
        o13[0] = o13[2] = i12[0], o13[1] = o13[3] = i12[1];
      }
    }, false), e21.registerBinding(t16, "mousemove", function(t17) {
      if (e21.hoverData.capture || E9(t17)) {
        var n13 = false, o13 = e21.cy, s12 = o13.zoom(), l12 = [t17.clientX, t17.clientY], c10 = e21.projectIntoViewport(l12[0], l12[1]), d13 = e21.hoverData.mdownPos, p11 = e21.hoverData.mdownGPos, f12 = e21.selection, g10 = null;
        e21.hoverData.draggingEles || e21.hoverData.dragging || e21.hoverData.selecting || (g10 = e21.findNearestElement(c10[0], c10[1], true, false));
        var v13, y11 = e21.hoverData.last, m13 = e21.hoverData.down, b12 = [c10[0] - f12[2], c10[1] - f12[3]], x11 = e21.dragData.possibleDragElements;
        if (p11) {
          var w12 = l12[0] - p11[0], k11 = w12 * w12, C10 = l12[1] - p11[1], S9 = k11 + C10 * C10;
          e21.hoverData.isOverThresholdDrag = v13 = S9 >= e21.desktopTapThreshold2;
        }
        var D10 = a10(t17);
        v13 && (e21.hoverData.tapholdCancelled = true);
        n13 = true, r9(g10, ["mousemove", "vmousemove", "tapdrag"], t17, { x: c10[0], y: c10[1] });
        var P11 = function() {
          e21.data.bgActivePosistion = void 0, e21.hoverData.selecting || o13.emit({ originalEvent: t17, type: "boxstart", position: { x: c10[0], y: c10[1] } }), f12[4] = 1, e21.hoverData.selecting = true, e21.redrawHint("select", true), e21.redraw();
        };
        if (3 === e21.hoverData.which) {
          if (v13) {
            var T10 = { originalEvent: t17, type: "cxtdrag", position: { x: c10[0], y: c10[1] } };
            m13 ? m13.emit(T10) : o13.emit(T10), e21.hoverData.cxtDragged = true, e21.hoverData.cxtOver && g10 === e21.hoverData.cxtOver || (e21.hoverData.cxtOver && e21.hoverData.cxtOver.emit({ originalEvent: t17, type: "cxtdragout", position: { x: c10[0], y: c10[1] } }), e21.hoverData.cxtOver = g10, g10 && g10.emit({ originalEvent: t17, type: "cxtdragover", position: { x: c10[0], y: c10[1] } }));
          }
        } else if (e21.hoverData.dragging) {
          if (n13 = true, o13.panningEnabled() && o13.userPanningEnabled()) {
            var M10;
            if (e21.hoverData.justStartedPan) {
              var B10 = e21.hoverData.mdownPos;
              M10 = { x: (c10[0] - B10[0]) * s12, y: (c10[1] - B10[1]) * s12 }, e21.hoverData.justStartedPan = false;
            } else
              M10 = { x: b12[0] * s12, y: b12[1] * s12 };
            o13.panBy(M10), o13.emit("dragpan"), e21.hoverData.dragged = true;
          }
          c10 = e21.projectIntoViewport(t17.clientX, t17.clientY);
        } else if (1 != f12[4] || null != m13 && !m13.pannable()) {
          if (m13 && m13.pannable() && m13.active() && m13.unactivate(), m13 && m13.grabbed() || g10 == y11 || (y11 && r9(y11, ["mouseout", "tapdragout"], t17, { x: c10[0], y: c10[1] }), g10 && r9(g10, ["mouseover", "tapdragover"], t17, { x: c10[0], y: c10[1] }), e21.hoverData.last = g10), m13)
            if (v13) {
              if (o13.boxSelectionEnabled() && D10)
                m13 && m13.grabbed() && (h10(x11), m13.emit("freeon"), x11.emit("free"), e21.dragData.didDrag && (m13.emit("dragfreeon"), x11.emit("dragfree"))), P11();
              else if (m13 && m13.grabbed() && e21.nodeIsDraggable(m13)) {
                var _8 = !e21.dragData.didDrag;
                _8 && e21.redrawHint("eles", true), e21.dragData.didDrag = true, e21.hoverData.draggingEles || u10(x11, { inDragLayer: true });
                var N9 = { x: 0, y: 0 };
                if (I6(b12[0]) && I6(b12[1]) && (N9.x += b12[0], N9.y += b12[1], _8)) {
                  var z9 = e21.hoverData.dragDelta;
                  z9 && I6(z9[0]) && I6(z9[1]) && (N9.x += z9[0], N9.y += z9[1]);
                }
                e21.hoverData.draggingEles = true, x11.silentShift(N9).emit("position drag"), e21.redrawHint("drag", true), e21.redraw();
              }
            } else
              !function() {
                var t18 = e21.hoverData.dragDelta = e21.hoverData.dragDelta || [];
                0 === t18.length ? (t18.push(b12[0]), t18.push(b12[1])) : (t18[0] += b12[0], t18[1] += b12[1]);
              }();
          n13 = true;
        } else if (v13) {
          if (e21.hoverData.dragging || !o13.boxSelectionEnabled() || !D10 && o13.panningEnabled() && o13.userPanningEnabled()) {
            if (!e21.hoverData.selecting && o13.panningEnabled() && o13.userPanningEnabled()) {
              i11(m13, e21.hoverData.downs) && (e21.hoverData.dragging = true, e21.hoverData.justStartedPan = true, f12[4] = 0, e21.data.bgActivePosistion = ot4(d13), e21.redrawHint("select", true), e21.redraw());
            }
          } else
            P11();
          m13 && m13.pannable() && m13.active() && m13.unactivate();
        }
        return f12[2] = c10[0], f12[3] = c10[1], n13 ? (t17.stopPropagation && t17.stopPropagation(), t17.preventDefault && t17.preventDefault(), false) : void 0;
      }
    }, false), e21.registerBinding(t16, "mouseup", function(t17) {
      if (e21.hoverData.capture) {
        e21.hoverData.capture = false;
        var i12 = e21.cy, o13 = e21.projectIntoViewport(t17.clientX, t17.clientY), s12 = e21.selection, l12 = e21.findNearestElement(o13[0], o13[1], true, false), u11 = e21.dragData.possibleDragElements, c10 = e21.hoverData.down, d13 = a10(t17);
        if (e21.data.bgActivePosistion && (e21.redrawHint("select", true), e21.redraw()), e21.hoverData.tapholdCancelled = true, e21.data.bgActivePosistion = void 0, c10 && c10.unactivate(), 3 === e21.hoverData.which) {
          var p11 = { originalEvent: t17, type: "cxttapend", position: { x: o13[0], y: o13[1] } };
          if (c10 ? c10.emit(p11) : i12.emit(p11), !e21.hoverData.cxtDragged) {
            var f12 = { originalEvent: t17, type: "cxttap", position: { x: o13[0], y: o13[1] } };
            c10 ? c10.emit(f12) : i12.emit(f12);
          }
          e21.hoverData.cxtDragged = false, e21.hoverData.which = null;
        } else if (1 === e21.hoverData.which) {
          if (r9(l12, ["mouseup", "tapend", "vmouseup"], t17, { x: o13[0], y: o13[1] }), e21.dragData.didDrag || e21.hoverData.dragged || e21.hoverData.selecting || e21.hoverData.isOverThresholdDrag || (r9(c10, ["click", "tap", "vclick"], t17, { x: o13[0], y: o13[1] }), x10 = false, t17.timeStamp - w11 <= i12.multiClickDebounceTime() ? (b11 && clearTimeout(b11), x10 = true, w11 = null, r9(c10, ["dblclick", "dbltap", "vdblclick"], t17, { x: o13[0], y: o13[1] })) : (b11 = setTimeout(function() {
            x10 || r9(c10, ["oneclick", "onetap", "voneclick"], t17, { x: o13[0], y: o13[1] });
          }, i12.multiClickDebounceTime()), w11 = t17.timeStamp)), null != c10 || e21.dragData.didDrag || e21.hoverData.selecting || e21.hoverData.dragged || a10(t17) || (i12.$(n12).unselect(["tapunselect"]), u11.length > 0 && e21.redrawHint("eles", true), e21.dragData.possibleDragElements = u11 = i12.collection()), l12 != c10 || e21.dragData.didDrag || e21.hoverData.selecting || null != l12 && l12._private.selectable && (e21.hoverData.dragging || ("additive" === i12.selectionType() || d13 ? l12.selected() ? l12.unselect(["tapunselect"]) : l12.select(["tapselect"]) : d13 || (i12.$(n12).unmerge(l12).unselect(["tapunselect"]), l12.select(["tapselect"]))), e21.redrawHint("eles", true)), e21.hoverData.selecting) {
            var g10 = i12.collection(e21.getAllInBox(s12[0], s12[1], s12[2], s12[3]));
            e21.redrawHint("select", true), g10.length > 0 && e21.redrawHint("eles", true), i12.emit({ type: "boxend", originalEvent: t17, position: { x: o13[0], y: o13[1] } });
            var v13 = function(e22) {
              return e22.selectable() && !e22.selected();
            };
            "additive" === i12.selectionType() || d13 || i12.$(n12).unmerge(g10).unselect(), g10.emit("box").stdFilter(v13).select().emit("boxselect"), e21.redraw();
          }
          if (e21.hoverData.dragging && (e21.hoverData.dragging = false, e21.redrawHint("select", true), e21.redrawHint("eles", true), e21.redraw()), !s12[4]) {
            e21.redrawHint("drag", true), e21.redrawHint("eles", true);
            var y11 = c10 && c10.grabbed();
            h10(u11), y11 && (c10.emit("freeon"), u11.emit("free"), e21.dragData.didDrag && (c10.emit("dragfreeon"), u11.emit("dragfree")));
          }
        }
        s12[4] = 0, e21.hoverData.down = null, e21.hoverData.cxtStarted = false, e21.hoverData.draggingEles = false, e21.hoverData.selecting = false, e21.hoverData.isOverThresholdDrag = false, e21.dragData.didDrag = false, e21.hoverData.dragged = false, e21.hoverData.dragDelta = [], e21.hoverData.mdownPos = null, e21.hoverData.mdownGPos = null;
      }
    }, false);
    var k10, C9, S8, D9, P10, T9, M9, B9, _7, N8, z8, L9, A10, O10 = function(t17) {
      if (!e21.scrollingPage) {
        var n13 = e21.cy, r10 = n13.zoom(), a11 = n13.pan(), i12 = e21.projectIntoViewport(t17.clientX, t17.clientY), o13 = [i12[0] * r10 + a11.x, i12[1] * r10 + a11.y];
        if (e21.hoverData.draggingEles || e21.hoverData.dragging || e21.hoverData.cxtStarted || 0 !== e21.selection[4])
          t17.preventDefault();
        else if (n13.panningEnabled() && n13.userPanningEnabled() && n13.zoomingEnabled() && n13.userZoomingEnabled()) {
          var s12;
          t17.preventDefault(), e21.data.wheelZooming = true, clearTimeout(e21.data.wheelTimeout), e21.data.wheelTimeout = setTimeout(function() {
            e21.data.wheelZooming = false, e21.redrawHint("eles", true), e21.redraw();
          }, 150), s12 = null != t17.deltaY ? t17.deltaY / -250 : null != t17.wheelDeltaY ? t17.wheelDeltaY / 1e3 : t17.wheelDelta / 1e3, s12 *= e21.wheelSensitivity, 1 === t17.deltaMode && (s12 *= 33);
          var l12 = n13.zoom() * Math.pow(10, s12);
          "gesturechange" === t17.type && (l12 = e21.gestureStartZoom * t17.scale), n13.zoom({ level: l12, renderedPosition: { x: o13[0], y: o13[1] } }), n13.emit("gesturechange" === t17.type ? "pinchzoom" : "scrollzoom");
        }
      }
    };
    e21.registerBinding(e21.container, "wheel", O10, true), e21.registerBinding(t16, "scroll", function(t17) {
      e21.scrollingPage = true, clearTimeout(e21.scrollingPageTimeout), e21.scrollingPageTimeout = setTimeout(function() {
        e21.scrollingPage = false;
      }, 250);
    }, true), e21.registerBinding(e21.container, "gesturestart", function(t17) {
      e21.gestureStartZoom = e21.cy.zoom(), e21.hasTouchStarted || t17.preventDefault();
    }, true), e21.registerBinding(e21.container, "gesturechange", function(t17) {
      e21.hasTouchStarted || O10(t17);
    }, true), e21.registerBinding(e21.container, "mouseout", function(t17) {
      var n13 = e21.projectIntoViewport(t17.clientX, t17.clientY);
      e21.cy.emit({ originalEvent: t17, type: "mouseout", position: { x: n13[0], y: n13[1] } });
    }, false), e21.registerBinding(e21.container, "mouseover", function(t17) {
      var n13 = e21.projectIntoViewport(t17.clientX, t17.clientY);
      e21.cy.emit({ originalEvent: t17, type: "mouseover", position: { x: n13[0], y: n13[1] } });
    }, false);
    var R8, V8, F9, q8, j9, Y6, X6, W8 = function(e22, t17, n13, r10) {
      return Math.sqrt((n13 - e22) * (n13 - e22) + (r10 - t17) * (r10 - t17));
    }, H8 = function(e22, t17, n13, r10) {
      return (n13 - e22) * (n13 - e22) + (r10 - t17) * (r10 - t17);
    };
    if (e21.registerBinding(e21.container, "touchstart", R8 = function(t17) {
      if (e21.hasTouchStarted = true, E9(t17)) {
        f11(), e21.touchData.capture = true, e21.data.bgActivePosistion = void 0;
        var n13 = e21.cy, a11 = e21.touchData.now, i12 = e21.touchData.earlier;
        if (t17.touches[0]) {
          var o13 = e21.projectIntoViewport(t17.touches[0].clientX, t17.touches[0].clientY);
          a11[0] = o13[0], a11[1] = o13[1];
        }
        if (t17.touches[1]) {
          o13 = e21.projectIntoViewport(t17.touches[1].clientX, t17.touches[1].clientY);
          a11[2] = o13[0], a11[3] = o13[1];
        }
        if (t17.touches[2]) {
          o13 = e21.projectIntoViewport(t17.touches[2].clientX, t17.touches[2].clientY);
          a11[4] = o13[0], a11[5] = o13[1];
        }
        if (t17.touches[1]) {
          e21.touchData.singleTouchMoved = true, h10(e21.dragData.touchDragEles);
          var l12 = e21.findContainerClientCoords();
          _7 = l12[0], N8 = l12[1], z8 = l12[2], L9 = l12[3], k10 = t17.touches[0].clientX - _7, C9 = t17.touches[0].clientY - N8, S8 = t17.touches[1].clientX - _7, D9 = t17.touches[1].clientY - N8, A10 = 0 <= k10 && k10 <= z8 && 0 <= S8 && S8 <= z8 && 0 <= C9 && C9 <= L9 && 0 <= D9 && D9 <= L9;
          var c10 = n13.pan(), p11 = n13.zoom();
          P10 = W8(k10, C9, S8, D9), T9 = H8(k10, C9, S8, D9), B9 = [((M9 = [(k10 + S8) / 2, (C9 + D9) / 2])[0] - c10.x) / p11, (M9[1] - c10.y) / p11];
          if (T9 < 4e4 && !t17.touches[2]) {
            var g10 = e21.findNearestElement(a11[0], a11[1], true, true), v13 = e21.findNearestElement(a11[2], a11[3], true, true);
            return g10 && g10.isNode() ? (g10.activate().emit({ originalEvent: t17, type: "cxttapstart", position: { x: a11[0], y: a11[1] } }), e21.touchData.start = g10) : v13 && v13.isNode() ? (v13.activate().emit({ originalEvent: t17, type: "cxttapstart", position: { x: a11[0], y: a11[1] } }), e21.touchData.start = v13) : n13.emit({ originalEvent: t17, type: "cxttapstart", position: { x: a11[0], y: a11[1] } }), e21.touchData.start && (e21.touchData.start._private.grabbed = false), e21.touchData.cxt = true, e21.touchData.cxtDragged = false, e21.data.bgActivePosistion = void 0, void e21.redraw();
          }
        }
        if (t17.touches[2])
          n13.boxSelectionEnabled() && t17.preventDefault();
        else if (t17.touches[1])
          ;
        else if (t17.touches[0]) {
          var y11 = e21.findNearestElements(a11[0], a11[1], true, true), m13 = y11[0];
          if (null != m13 && (m13.activate(), e21.touchData.start = m13, e21.touchData.starts = y11, e21.nodeIsGrabbable(m13))) {
            var b12 = e21.dragData.touchDragEles = n13.collection(), x11 = null;
            e21.redrawHint("eles", true), e21.redrawHint("drag", true), m13.selected() ? (x11 = n13.$(function(t18) {
              return t18.selected() && e21.nodeIsGrabbable(t18);
            }), u10(x11, { addToList: b12 })) : d12(m13, { addToList: b12 }), s11(m13);
            var w12 = function(e22) {
              return { originalEvent: t17, type: e22, position: { x: a11[0], y: a11[1] } };
            };
            m13.emit(w12("grabon")), x11 ? x11.forEach(function(e22) {
              e22.emit(w12("grab"));
            }) : m13.emit(w12("grab"));
          }
          r9(m13, ["touchstart", "tapstart", "vmousedown"], t17, { x: a11[0], y: a11[1] }), null == m13 && (e21.data.bgActivePosistion = { x: o13[0], y: o13[1] }, e21.redrawHint("select", true), e21.redraw()), e21.touchData.singleTouchMoved = false, e21.touchData.singleTouchStartTime = +/* @__PURE__ */ new Date(), clearTimeout(e21.touchData.tapholdTimeout), e21.touchData.tapholdTimeout = setTimeout(function() {
            false !== e21.touchData.singleTouchMoved || e21.pinching || e21.touchData.selecting || r9(e21.touchData.start, ["taphold"], t17, { x: a11[0], y: a11[1] });
          }, e21.tapholdDuration);
        }
        if (t17.touches.length >= 1) {
          for (var I8 = e21.touchData.startPosition = [null, null, null, null, null, null], O11 = 0; O11 < a11.length; O11++)
            I8[O11] = i12[O11] = a11[O11];
          var R9 = t17.touches[0];
          e21.touchData.startGPosition = [R9.clientX, R9.clientY];
        }
      }
    }, false), e21.registerBinding(window, "touchmove", V8 = function(t17) {
      var n13 = e21.touchData.capture;
      if (n13 || E9(t17)) {
        var a11 = e21.selection, o13 = e21.cy, s12 = e21.touchData.now, l12 = e21.touchData.earlier, c10 = o13.zoom();
        if (t17.touches[0]) {
          var d13 = e21.projectIntoViewport(t17.touches[0].clientX, t17.touches[0].clientY);
          s12[0] = d13[0], s12[1] = d13[1];
        }
        if (t17.touches[1]) {
          d13 = e21.projectIntoViewport(t17.touches[1].clientX, t17.touches[1].clientY);
          s12[2] = d13[0], s12[3] = d13[1];
        }
        if (t17.touches[2]) {
          d13 = e21.projectIntoViewport(t17.touches[2].clientX, t17.touches[2].clientY);
          s12[4] = d13[0], s12[5] = d13[1];
        }
        var p11, f12 = e21.touchData.startGPosition;
        if (n13 && t17.touches[0] && f12) {
          for (var g10 = [], v13 = 0; v13 < s12.length; v13++)
            g10[v13] = s12[v13] - l12[v13];
          var y11 = t17.touches[0].clientX - f12[0], m13 = y11 * y11, b12 = t17.touches[0].clientY - f12[1];
          p11 = m13 + b12 * b12 >= e21.touchTapThreshold2;
        }
        if (n13 && e21.touchData.cxt) {
          t17.preventDefault();
          var x11 = t17.touches[0].clientX - _7, w12 = t17.touches[0].clientY - N8, M10 = t17.touches[1].clientX - _7, z9 = t17.touches[1].clientY - N8, L10 = H8(x11, w12, M10, z9);
          if (L10 / T9 >= 2.25 || L10 >= 22500) {
            e21.touchData.cxt = false, e21.data.bgActivePosistion = void 0, e21.redrawHint("select", true);
            var O11 = { originalEvent: t17, type: "cxttapend", position: { x: s12[0], y: s12[1] } };
            e21.touchData.start ? (e21.touchData.start.unactivate().emit(O11), e21.touchData.start = null) : o13.emit(O11);
          }
        }
        if (n13 && e21.touchData.cxt) {
          O11 = { originalEvent: t17, type: "cxtdrag", position: { x: s12[0], y: s12[1] } };
          e21.data.bgActivePosistion = void 0, e21.redrawHint("select", true), e21.touchData.start ? e21.touchData.start.emit(O11) : o13.emit(O11), e21.touchData.start && (e21.touchData.start._private.grabbed = false), e21.touchData.cxtDragged = true;
          var R9 = e21.findNearestElement(s12[0], s12[1], true, true);
          e21.touchData.cxtOver && R9 === e21.touchData.cxtOver || (e21.touchData.cxtOver && e21.touchData.cxtOver.emit({ originalEvent: t17, type: "cxtdragout", position: { x: s12[0], y: s12[1] } }), e21.touchData.cxtOver = R9, R9 && R9.emit({ originalEvent: t17, type: "cxtdragover", position: { x: s12[0], y: s12[1] } }));
        } else if (n13 && t17.touches[2] && o13.boxSelectionEnabled())
          t17.preventDefault(), e21.data.bgActivePosistion = void 0, this.lastThreeTouch = +/* @__PURE__ */ new Date(), e21.touchData.selecting || o13.emit({ originalEvent: t17, type: "boxstart", position: { x: s12[0], y: s12[1] } }), e21.touchData.selecting = true, e21.touchData.didSelect = true, a11[4] = 1, a11 && 0 !== a11.length && void 0 !== a11[0] ? (a11[2] = (s12[0] + s12[2] + s12[4]) / 3, a11[3] = (s12[1] + s12[3] + s12[5]) / 3) : (a11[0] = (s12[0] + s12[2] + s12[4]) / 3, a11[1] = (s12[1] + s12[3] + s12[5]) / 3, a11[2] = (s12[0] + s12[2] + s12[4]) / 3 + 1, a11[3] = (s12[1] + s12[3] + s12[5]) / 3 + 1), e21.redrawHint("select", true), e21.redraw();
        else if (n13 && t17.touches[1] && !e21.touchData.didSelect && o13.zoomingEnabled() && o13.panningEnabled() && o13.userZoomingEnabled() && o13.userPanningEnabled()) {
          if (t17.preventDefault(), e21.data.bgActivePosistion = void 0, e21.redrawHint("select", true), ee3 = e21.dragData.touchDragEles) {
            e21.redrawHint("drag", true);
            for (var V9 = 0; V9 < ee3.length; V9++) {
              var F10 = ee3[V9]._private;
              F10.grabbed = false, F10.rscratch.inDragLayer = false;
            }
          }
          var q9 = e21.touchData.start, j10 = (x11 = t17.touches[0].clientX - _7, w12 = t17.touches[0].clientY - N8, M10 = t17.touches[1].clientX - _7, z9 = t17.touches[1].clientY - N8, W8(x11, w12, M10, z9)), Y7 = j10 / P10;
          if (A10) {
            var X7 = (x11 - k10 + (M10 - S8)) / 2, K7 = (w12 - C9 + (z9 - D9)) / 2, G8 = o13.zoom(), U8 = G8 * Y7, Z7 = o13.pan(), $9 = B9[0] * G8 + Z7.x, Q7 = B9[1] * G8 + Z7.y, J6 = { x: -U8 / G8 * ($9 - Z7.x - X7) + $9, y: -U8 / G8 * (Q7 - Z7.y - K7) + Q7 };
            if (q9 && q9.active()) {
              var ee3 = e21.dragData.touchDragEles;
              h10(ee3), e21.redrawHint("drag", true), e21.redrawHint("eles", true), q9.unactivate().emit("freeon"), ee3.emit("free"), e21.dragData.didDrag && (q9.emit("dragfreeon"), ee3.emit("dragfree"));
            }
            o13.viewport({ zoom: U8, pan: J6, cancelOnFailedZoom: true }), o13.emit("pinchzoom"), P10 = j10, k10 = x11, C9 = w12, S8 = M10, D9 = z9, e21.pinching = true;
          }
          if (t17.touches[0]) {
            d13 = e21.projectIntoViewport(t17.touches[0].clientX, t17.touches[0].clientY);
            s12[0] = d13[0], s12[1] = d13[1];
          }
          if (t17.touches[1]) {
            d13 = e21.projectIntoViewport(t17.touches[1].clientX, t17.touches[1].clientY);
            s12[2] = d13[0], s12[3] = d13[1];
          }
          if (t17.touches[2]) {
            d13 = e21.projectIntoViewport(t17.touches[2].clientX, t17.touches[2].clientY);
            s12[4] = d13[0], s12[5] = d13[1];
          }
        } else if (t17.touches[0] && !e21.touchData.didSelect) {
          var te3 = e21.touchData.start, ne3 = e21.touchData.last;
          if (e21.hoverData.draggingEles || e21.swipePanning || (R9 = e21.findNearestElement(s12[0], s12[1], true, true)), n13 && null != te3 && t17.preventDefault(), n13 && null != te3 && e21.nodeIsDraggable(te3))
            if (p11) {
              ee3 = e21.dragData.touchDragEles;
              var re3 = !e21.dragData.didDrag;
              re3 && u10(ee3, { inDragLayer: true }), e21.dragData.didDrag = true;
              var ae3 = { x: 0, y: 0 };
              if (I6(g10[0]) && I6(g10[1])) {
                if (ae3.x += g10[0], ae3.y += g10[1], re3)
                  e21.redrawHint("eles", true), (ie3 = e21.touchData.dragDelta) && I6(ie3[0]) && I6(ie3[1]) && (ae3.x += ie3[0], ae3.y += ie3[1]);
              }
              e21.hoverData.draggingEles = true, ee3.silentShift(ae3).emit("position drag"), e21.redrawHint("drag", true), e21.touchData.startPosition[0] == l12[0] && e21.touchData.startPosition[1] == l12[1] && e21.redrawHint("eles", true), e21.redraw();
            } else {
              var ie3;
              0 === (ie3 = e21.touchData.dragDelta = e21.touchData.dragDelta || []).length ? (ie3.push(g10[0]), ie3.push(g10[1])) : (ie3[0] += g10[0], ie3[1] += g10[1]);
            }
          if (r9(te3 || R9, ["touchmove", "tapdrag", "vmousemove"], t17, { x: s12[0], y: s12[1] }), te3 && te3.grabbed() || R9 == ne3 || (ne3 && ne3.emit({ originalEvent: t17, type: "tapdragout", position: { x: s12[0], y: s12[1] } }), R9 && R9.emit({ originalEvent: t17, type: "tapdragover", position: { x: s12[0], y: s12[1] } })), e21.touchData.last = R9, n13)
            for (V9 = 0; V9 < s12.length; V9++)
              s12[V9] && e21.touchData.startPosition[V9] && p11 && (e21.touchData.singleTouchMoved = true);
          if (n13 && (null == te3 || te3.pannable()) && o13.panningEnabled() && o13.userPanningEnabled()) {
            i11(te3, e21.touchData.starts) && (t17.preventDefault(), e21.data.bgActivePosistion || (e21.data.bgActivePosistion = ot4(e21.touchData.startPosition)), e21.swipePanning ? (o13.panBy({ x: g10[0] * c10, y: g10[1] * c10 }), o13.emit("dragpan")) : p11 && (e21.swipePanning = true, o13.panBy({ x: y11 * c10, y: b12 * c10 }), o13.emit("dragpan"), te3 && (te3.unactivate(), e21.redrawHint("select", true), e21.touchData.start = null)));
            d13 = e21.projectIntoViewport(t17.touches[0].clientX, t17.touches[0].clientY);
            s12[0] = d13[0], s12[1] = d13[1];
          }
        }
        for (v13 = 0; v13 < s12.length; v13++)
          l12[v13] = s12[v13];
        n13 && t17.touches.length > 0 && !e21.hoverData.draggingEles && !e21.swipePanning && null != e21.data.bgActivePosistion && (e21.data.bgActivePosistion = void 0, e21.redrawHint("select", true), e21.redraw());
      }
    }, false), e21.registerBinding(t16, "touchcancel", F9 = function(t17) {
      var n13 = e21.touchData.start;
      e21.touchData.capture = false, n13 && n13.unactivate();
    }), e21.registerBinding(t16, "touchend", q8 = function(t17) {
      var a11 = e21.touchData.start;
      if (e21.touchData.capture) {
        0 === t17.touches.length && (e21.touchData.capture = false), t17.preventDefault();
        var i12 = e21.selection;
        e21.swipePanning = false, e21.hoverData.draggingEles = false;
        var o13, s12 = e21.cy, l12 = s12.zoom(), u11 = e21.touchData.now, c10 = e21.touchData.earlier;
        if (t17.touches[0]) {
          var d13 = e21.projectIntoViewport(t17.touches[0].clientX, t17.touches[0].clientY);
          u11[0] = d13[0], u11[1] = d13[1];
        }
        if (t17.touches[1]) {
          d13 = e21.projectIntoViewport(t17.touches[1].clientX, t17.touches[1].clientY);
          u11[2] = d13[0], u11[3] = d13[1];
        }
        if (t17.touches[2]) {
          d13 = e21.projectIntoViewport(t17.touches[2].clientX, t17.touches[2].clientY);
          u11[4] = d13[0], u11[5] = d13[1];
        }
        if (a11 && a11.unactivate(), e21.touchData.cxt) {
          if (o13 = { originalEvent: t17, type: "cxttapend", position: { x: u11[0], y: u11[1] } }, a11 ? a11.emit(o13) : s12.emit(o13), !e21.touchData.cxtDragged) {
            var p11 = { originalEvent: t17, type: "cxttap", position: { x: u11[0], y: u11[1] } };
            a11 ? a11.emit(p11) : s12.emit(p11);
          }
          return e21.touchData.start && (e21.touchData.start._private.grabbed = false), e21.touchData.cxt = false, e21.touchData.start = null, void e21.redraw();
        }
        if (!t17.touches[2] && s12.boxSelectionEnabled() && e21.touchData.selecting) {
          e21.touchData.selecting = false;
          var f12 = s12.collection(e21.getAllInBox(i12[0], i12[1], i12[2], i12[3]));
          i12[0] = void 0, i12[1] = void 0, i12[2] = void 0, i12[3] = void 0, i12[4] = 0, e21.redrawHint("select", true), s12.emit({ type: "boxend", originalEvent: t17, position: { x: u11[0], y: u11[1] } });
          f12.emit("box").stdFilter(function(e22) {
            return e22.selectable() && !e22.selected();
          }).select().emit("boxselect"), f12.nonempty() && e21.redrawHint("eles", true), e21.redraw();
        }
        if (null != a11 && a11.unactivate(), t17.touches[2])
          e21.data.bgActivePosistion = void 0, e21.redrawHint("select", true);
        else if (t17.touches[1])
          ;
        else if (t17.touches[0])
          ;
        else if (!t17.touches[0]) {
          e21.data.bgActivePosistion = void 0, e21.redrawHint("select", true);
          var g10 = e21.dragData.touchDragEles;
          if (null != a11) {
            var v13 = a11._private.grabbed;
            h10(g10), e21.redrawHint("drag", true), e21.redrawHint("eles", true), v13 && (a11.emit("freeon"), g10.emit("free"), e21.dragData.didDrag && (a11.emit("dragfreeon"), g10.emit("dragfree"))), r9(a11, ["touchend", "tapend", "vmouseup", "tapdragout"], t17, { x: u11[0], y: u11[1] }), a11.unactivate(), e21.touchData.start = null;
          } else {
            var y11 = e21.findNearestElement(u11[0], u11[1], true, true);
            r9(y11, ["touchend", "tapend", "vmouseup", "tapdragout"], t17, { x: u11[0], y: u11[1] });
          }
          var m13 = e21.touchData.startPosition[0] - u11[0], b12 = m13 * m13, x11 = e21.touchData.startPosition[1] - u11[1], w12 = (b12 + x11 * x11) * l12 * l12;
          e21.touchData.singleTouchMoved || (a11 || s12.$(":selected").unselect(["tapunselect"]), r9(a11, ["tap", "vclick"], t17, { x: u11[0], y: u11[1] }), j9 = false, t17.timeStamp - X6 <= s12.multiClickDebounceTime() ? (Y6 && clearTimeout(Y6), j9 = true, X6 = null, r9(a11, ["dbltap", "vdblclick"], t17, { x: u11[0], y: u11[1] })) : (Y6 = setTimeout(function() {
            j9 || r9(a11, ["onetap", "voneclick"], t17, { x: u11[0], y: u11[1] });
          }, s12.multiClickDebounceTime()), X6 = t17.timeStamp)), null != a11 && !e21.dragData.didDrag && a11._private.selectable && w12 < e21.touchTapThreshold2 && !e21.pinching && ("single" === s12.selectionType() ? (s12.$(n12).unmerge(a11).unselect(["tapunselect"]), a11.select(["tapselect"])) : a11.selected() ? a11.unselect(["tapunselect"]) : a11.select(["tapselect"]), e21.redrawHint("eles", true)), e21.touchData.singleTouchMoved = true;
        }
        for (var E10 = 0; E10 < u11.length; E10++)
          c10[E10] = u11[E10];
        e21.dragData.didDrag = false, 0 === t17.touches.length && (e21.touchData.dragDelta = [], e21.touchData.startPosition = [null, null, null, null, null, null], e21.touchData.startGPosition = null, e21.touchData.didSelect = false), t17.touches.length < 2 && (1 === t17.touches.length && (e21.touchData.startGPosition = [t17.touches[0].clientX, t17.touches[0].clientY]), e21.pinching = false, e21.redrawHint("eles", true), e21.redraw());
      }
    }, false), "undefined" == typeof TouchEvent) {
      var K6 = [], G7 = function(e22) {
        return { clientX: e22.clientX, clientY: e22.clientY, force: 1, identifier: e22.pointerId, pageX: e22.pageX, pageY: e22.pageY, radiusX: e22.width / 2, radiusY: e22.height / 2, screenX: e22.screenX, screenY: e22.screenY, target: e22.target };
      }, U7 = function(e22) {
        K6.push(function(e23) {
          return { event: e23, touch: G7(e23) };
        }(e22));
      }, Z6 = function(e22) {
        for (var t17 = 0; t17 < K6.length; t17++) {
          if (K6[t17].event.pointerId === e22.pointerId)
            return void K6.splice(t17, 1);
        }
      }, $8 = function(e22) {
        e22.touches = K6.map(function(e23) {
          return e23.touch;
        });
      }, Q6 = function(e22) {
        return "mouse" === e22.pointerType || 4 === e22.pointerType;
      };
      e21.registerBinding(e21.container, "pointerdown", function(e22) {
        Q6(e22) || (e22.preventDefault(), U7(e22), $8(e22), R8(e22));
      }), e21.registerBinding(e21.container, "pointerup", function(e22) {
        Q6(e22) || (Z6(e22), $8(e22), q8(e22));
      }), e21.registerBinding(e21.container, "pointercancel", function(e22) {
        Q6(e22) || (Z6(e22), $8(e22), F9());
      }), e21.registerBinding(e21.container, "pointermove", function(e22) {
        Q6(e22) || (e22.preventDefault(), function(e23) {
          var t17 = K6.filter(function(t18) {
            return t18.event.pointerId === e23.pointerId;
          })[0];
          t17.event = e23, t17.touch = G7(e23);
        }(e22), $8(e22), V8(e22));
      });
    }
  };
  var ms = { generatePolygon: function(e21, t16) {
    return this.nodeShapes[e21] = { renderer: this, name: e21, points: t16, draw: function(e22, t17, n12, r9, a10) {
      this.renderer.nodeShapeImpl("polygon", e22, t17, n12, r9, a10, this.points);
    }, intersectLine: function(e22, t17, n12, r9, a10, i11, o12) {
      return Ot4(a10, i11, this.points, e22, t17, n12 / 2, r9 / 2, o12);
    }, checkPoint: function(e22, t17, n12, r9, a10, i11, o12) {
      return Bt4(e22, t17, this.points, i11, o12, r9, a10, [0, -1], n12);
    } };
  } };
  ms.generateEllipse = function() {
    return this.nodeShapes.ellipse = { renderer: this, name: "ellipse", draw: function(e21, t16, n12, r9, a10) {
      this.renderer.nodeShapeImpl(this.name, e21, t16, n12, r9, a10);
    }, intersectLine: function(e21, t16, n12, r9, a10, i11, o12) {
      return function(e22, t17, n13, r10, a11, i12) {
        var o13 = n13 - e22, s11 = r10 - t17;
        o13 /= a11, s11 /= i12;
        var l11 = Math.sqrt(o13 * o13 + s11 * s11), u10 = l11 - 1;
        if (u10 < 0)
          return [];
        var c10 = u10 / l11;
        return [(n13 - e22) * c10 + e22, (r10 - t17) * c10 + t17];
      }(a10, i11, e21, t16, n12 / 2 + o12, r9 / 2 + o12);
    }, checkPoint: function(e21, t16, n12, r9, a10, i11, o12) {
      return It4(e21, t16, r9, a10, i11, o12, n12);
    } };
  }, ms.generateRoundPolygon = function(e21, t16) {
    for (var n12 = new Array(2 * t16.length), r9 = 0; r9 < t16.length / 2; r9++) {
      var a10 = 2 * r9, i11 = void 0;
      i11 = r9 < t16.length / 2 - 1 ? 2 * (r9 + 1) : 0, n12[4 * r9] = t16[a10], n12[4 * r9 + 1] = t16[a10 + 1];
      var o12 = t16[i11] - t16[a10], s11 = t16[i11 + 1] - t16[a10 + 1], l11 = Math.sqrt(o12 * o12 + s11 * s11);
      n12[4 * r9 + 2] = o12 / l11, n12[4 * r9 + 3] = s11 / l11;
    }
    return this.nodeShapes[e21] = { renderer: this, name: e21, points: n12, draw: function(e22, t17, n13, r10, a11) {
      this.renderer.nodeShapeImpl("round-polygon", e22, t17, n13, r10, a11, this.points);
    }, intersectLine: function(e22, t17, n13, r10, a11, i12, o13) {
      return function(e23, t18, n14, r11, a12, i13, o14) {
        for (var s12, l12 = [], u10 = new Array(n14.length), c10 = i13 / 2, d12 = o14 / 2, h10 = Yt4(i13, o14), p10 = 0; p10 < n14.length / 4; p10++) {
          var f11, g9 = void 0;
          g9 = 0 === p10 ? n14.length - 2 : 4 * p10 - 2, f11 = 4 * p10 + 2;
          var v12 = r11 + c10 * n14[4 * p10], y10 = a12 + d12 * n14[4 * p10 + 1], m12 = -n14[g9] * n14[f11] - n14[g9 + 1] * n14[f11 + 1], b11 = h10 / Math.tan(Math.acos(m12) / 2), x10 = v12 - b11 * n14[g9], w11 = y10 - b11 * n14[g9 + 1], E9 = v12 + b11 * n14[f11], k10 = y10 + b11 * n14[f11 + 1];
          0 === p10 ? (u10[n14.length - 2] = x10, u10[n14.length - 1] = w11) : (u10[4 * p10 - 2] = x10, u10[4 * p10 - 1] = w11), u10[4 * p10] = E9, u10[4 * p10 + 1] = k10;
          var C9 = n14[g9 + 1], S8 = -n14[g9];
          C9 * n14[f11] + S8 * n14[f11 + 1] < 0 && (C9 *= -1, S8 *= -1), 0 !== (s12 = zt4(e23, t18, r11, a12, x10 + C9 * h10, w11 + S8 * h10, h10)).length && l12.push(s12[0], s12[1]);
        }
        for (var D9 = 0; D9 < u10.length / 4; D9++)
          0 !== (s12 = At4(e23, t18, r11, a12, u10[4 * D9], u10[4 * D9 + 1], u10[4 * D9 + 2], u10[4 * D9 + 3], false)).length && l12.push(s12[0], s12[1]);
        if (l12.length > 2) {
          for (var P10 = [l12[0], l12[1]], T9 = Math.pow(P10[0] - e23, 2) + Math.pow(P10[1] - t18, 2), M9 = 1; M9 < l12.length / 2; M9++) {
            var B9 = Math.pow(l12[2 * M9] - e23, 2) + Math.pow(l12[2 * M9 + 1] - t18, 2);
            B9 <= T9 && (P10[0] = l12[2 * M9], P10[1] = l12[2 * M9 + 1], T9 = B9);
          }
          return P10;
        }
        return l12;
      }(a11, i12, this.points, e22, t17, n13, r10);
    }, checkPoint: function(e22, t17, n13, r10, a11, i12, o13) {
      return function(e23, t18, n14, r11, a12, i13, o14) {
        for (var s12 = new Array(n14.length), l12 = i13 / 2, u10 = o14 / 2, c10 = Yt4(i13, o14), d12 = c10 * c10, h10 = 0; h10 < n14.length / 4; h10++) {
          var p10, f11 = void 0;
          f11 = 0 === h10 ? n14.length - 2 : 4 * h10 - 2, p10 = 4 * h10 + 2;
          var g9 = r11 + l12 * n14[4 * h10], v12 = a12 + u10 * n14[4 * h10 + 1], y10 = -n14[f11] * n14[p10] - n14[f11 + 1] * n14[p10 + 1], m12 = c10 / Math.tan(Math.acos(y10) / 2), b11 = g9 - m12 * n14[f11], x10 = v12 - m12 * n14[f11 + 1], w11 = g9 + m12 * n14[p10], E9 = v12 + m12 * n14[p10 + 1];
          s12[4 * h10] = b11, s12[4 * h10 + 1] = x10, s12[4 * h10 + 2] = w11, s12[4 * h10 + 3] = E9;
          var k10 = n14[f11 + 1], C9 = -n14[f11];
          k10 * n14[p10] + C9 * n14[p10 + 1] < 0 && (k10 *= -1, C9 *= -1);
          var S8 = b11 + k10 * c10, D9 = x10 + C9 * c10;
          if (Math.pow(S8 - e23, 2) + Math.pow(D9 - t18, 2) <= d12)
            return true;
        }
        return Mt4(e23, t18, s12);
      }(e22, t17, this.points, i12, o13, r10, a11);
    } };
  }, ms.generateRoundRectangle = function() {
    return this.nodeShapes["round-rectangle"] = this.nodeShapes.roundrectangle = { renderer: this, name: "round-rectangle", points: Vt4(4, 0), draw: function(e21, t16, n12, r9, a10) {
      this.renderer.nodeShapeImpl(this.name, e21, t16, n12, r9, a10);
    }, intersectLine: function(e21, t16, n12, r9, a10, i11, o12) {
      return Ct4(a10, i11, e21, t16, n12, r9, o12);
    }, checkPoint: function(e21, t16, n12, r9, a10, i11, o12) {
      var s11 = jt4(r9, a10), l11 = 2 * s11;
      return !!Bt4(e21, t16, this.points, i11, o12, r9, a10 - l11, [0, -1], n12) || (!!Bt4(e21, t16, this.points, i11, o12, r9 - l11, a10, [0, -1], n12) || (!!It4(e21, t16, l11, l11, i11 - r9 / 2 + s11, o12 - a10 / 2 + s11, n12) || (!!It4(e21, t16, l11, l11, i11 + r9 / 2 - s11, o12 - a10 / 2 + s11, n12) || (!!It4(e21, t16, l11, l11, i11 + r9 / 2 - s11, o12 + a10 / 2 - s11, n12) || !!It4(e21, t16, l11, l11, i11 - r9 / 2 + s11, o12 + a10 / 2 - s11, n12)))));
    } };
  }, ms.generateCutRectangle = function() {
    return this.nodeShapes["cut-rectangle"] = this.nodeShapes.cutrectangle = { renderer: this, name: "cut-rectangle", cornerLength: 8, points: Vt4(4, 0), draw: function(e21, t16, n12, r9, a10) {
      this.renderer.nodeShapeImpl(this.name, e21, t16, n12, r9, a10);
    }, generateCutTrianglePts: function(e21, t16, n12, r9) {
      var a10 = this.cornerLength, i11 = t16 / 2, o12 = e21 / 2, s11 = n12 - o12, l11 = n12 + o12, u10 = r9 - i11, c10 = r9 + i11;
      return { topLeft: [s11, u10 + a10, s11 + a10, u10, s11 + a10, u10 + a10], topRight: [l11 - a10, u10, l11, u10 + a10, l11 - a10, u10 + a10], bottomRight: [l11, c10 - a10, l11 - a10, c10, l11 - a10, c10 - a10], bottomLeft: [s11 + a10, c10, s11, c10 - a10, s11 + a10, c10 - a10] };
    }, intersectLine: function(e21, t16, n12, r9, a10, i11, o12) {
      var s11 = this.generateCutTrianglePts(n12 + 2 * o12, r9 + 2 * o12, e21, t16), l11 = [].concat.apply([], [s11.topLeft.splice(0, 4), s11.topRight.splice(0, 4), s11.bottomRight.splice(0, 4), s11.bottomLeft.splice(0, 4)]);
      return Ot4(a10, i11, l11, e21, t16);
    }, checkPoint: function(e21, t16, n12, r9, a10, i11, o12) {
      if (Bt4(e21, t16, this.points, i11, o12, r9, a10 - 2 * this.cornerLength, [0, -1], n12))
        return true;
      if (Bt4(e21, t16, this.points, i11, o12, r9 - 2 * this.cornerLength, a10, [0, -1], n12))
        return true;
      var s11 = this.generateCutTrianglePts(r9, a10, i11, o12);
      return Mt4(e21, t16, s11.topLeft) || Mt4(e21, t16, s11.topRight) || Mt4(e21, t16, s11.bottomRight) || Mt4(e21, t16, s11.bottomLeft);
    } };
  }, ms.generateBarrel = function() {
    return this.nodeShapes.barrel = { renderer: this, name: "barrel", points: Vt4(4, 0), draw: function(e21, t16, n12, r9, a10) {
      this.renderer.nodeShapeImpl(this.name, e21, t16, n12, r9, a10);
    }, intersectLine: function(e21, t16, n12, r9, a10, i11, o12) {
      var s11 = this.generateBarrelBezierPts(n12 + 2 * o12, r9 + 2 * o12, e21, t16), l11 = function(e22) {
        var t17 = ft4({ x: e22[0], y: e22[1] }, { x: e22[2], y: e22[3] }, { x: e22[4], y: e22[5] }, 0.15), n13 = ft4({ x: e22[0], y: e22[1] }, { x: e22[2], y: e22[3] }, { x: e22[4], y: e22[5] }, 0.5), r10 = ft4({ x: e22[0], y: e22[1] }, { x: e22[2], y: e22[3] }, { x: e22[4], y: e22[5] }, 0.85);
        return [e22[0], e22[1], t17.x, t17.y, n13.x, n13.y, r10.x, r10.y, e22[4], e22[5]];
      }, u10 = [].concat(l11(s11.topLeft), l11(s11.topRight), l11(s11.bottomRight), l11(s11.bottomLeft));
      return Ot4(a10, i11, u10, e21, t16);
    }, generateBarrelBezierPts: function(e21, t16, n12, r9) {
      var a10 = t16 / 2, i11 = e21 / 2, o12 = n12 - i11, s11 = n12 + i11, l11 = r9 - a10, u10 = r9 + a10, c10 = Xt4(e21, t16), d12 = c10.heightOffset, h10 = c10.widthOffset, p10 = c10.ctrlPtOffsetPct * e21, f11 = { topLeft: [o12, l11 + d12, o12 + p10, l11, o12 + h10, l11], topRight: [s11 - h10, l11, s11 - p10, l11, s11, l11 + d12], bottomRight: [s11, u10 - d12, s11 - p10, u10, s11 - h10, u10], bottomLeft: [o12 + h10, u10, o12 + p10, u10, o12, u10 - d12] };
      return f11.topLeft.isTop = true, f11.topRight.isTop = true, f11.bottomLeft.isBottom = true, f11.bottomRight.isBottom = true, f11;
    }, checkPoint: function(e21, t16, n12, r9, a10, i11, o12) {
      var s11 = Xt4(r9, a10), l11 = s11.heightOffset, u10 = s11.widthOffset;
      if (Bt4(e21, t16, this.points, i11, o12, r9, a10 - 2 * l11, [0, -1], n12))
        return true;
      if (Bt4(e21, t16, this.points, i11, o12, r9 - 2 * u10, a10, [0, -1], n12))
        return true;
      for (var c10 = this.generateBarrelBezierPts(r9, a10, i11, o12), d12 = function(e22, t17, n13) {
        var r10, a11, i12 = n13[4], o13 = n13[2], s12 = n13[0], l12 = n13[5], u11 = n13[1], c11 = Math.min(i12, s12), d13 = Math.max(i12, s12), h11 = Math.min(l12, u11), p11 = Math.max(l12, u11);
        if (c11 <= e22 && e22 <= d13 && h11 <= t17 && t17 <= p11) {
          var f12 = [(r10 = i12) - 2 * (a11 = o13) + s12, 2 * (a11 - r10), r10], g10 = function(e23, t18, n14, r11) {
            var a12 = t18 * t18 - 4 * e23 * (n14 -= r11);
            if (a12 < 0)
              return [];
            var i13 = Math.sqrt(a12), o14 = 2 * e23;
            return [(-t18 + i13) / o14, (-t18 - i13) / o14];
          }(f12[0], f12[1], f12[2], e22).filter(function(e23) {
            return 0 <= e23 && e23 <= 1;
          });
          if (g10.length > 0)
            return g10[0];
        }
        return null;
      }, h10 = Object.keys(c10), p10 = 0; p10 < h10.length; p10++) {
        var f11 = c10[h10[p10]], g9 = d12(e21, t16, f11);
        if (null != g9) {
          var v12 = f11[5], y10 = f11[3], m12 = f11[1], b11 = pt4(v12, y10, m12, g9);
          if (f11.isTop && b11 <= t16)
            return true;
          if (f11.isBottom && t16 <= b11)
            return true;
        }
      }
      return false;
    } };
  }, ms.generateBottomRoundrectangle = function() {
    return this.nodeShapes["bottom-round-rectangle"] = this.nodeShapes.bottomroundrectangle = { renderer: this, name: "bottom-round-rectangle", points: Vt4(4, 0), draw: function(e21, t16, n12, r9, a10) {
      this.renderer.nodeShapeImpl(this.name, e21, t16, n12, r9, a10);
    }, intersectLine: function(e21, t16, n12, r9, a10, i11, o12) {
      var s11 = t16 - (r9 / 2 + o12), l11 = At4(a10, i11, e21, t16, e21 - (n12 / 2 + o12), s11, e21 + (n12 / 2 + o12), s11, false);
      return l11.length > 0 ? l11 : Ct4(a10, i11, e21, t16, n12, r9, o12);
    }, checkPoint: function(e21, t16, n12, r9, a10, i11, o12) {
      var s11 = jt4(r9, a10), l11 = 2 * s11;
      if (Bt4(e21, t16, this.points, i11, o12, r9, a10 - l11, [0, -1], n12))
        return true;
      if (Bt4(e21, t16, this.points, i11, o12, r9 - l11, a10, [0, -1], n12))
        return true;
      var u10 = r9 / 2 + 2 * n12, c10 = a10 / 2 + 2 * n12;
      return !!Mt4(e21, t16, [i11 - u10, o12 - c10, i11 - u10, o12, i11 + u10, o12, i11 + u10, o12 - c10]) || (!!It4(e21, t16, l11, l11, i11 + r9 / 2 - s11, o12 + a10 / 2 - s11, n12) || !!It4(e21, t16, l11, l11, i11 - r9 / 2 + s11, o12 + a10 / 2 - s11, n12));
    } };
  }, ms.registerNodeShapes = function() {
    var e21 = this.nodeShapes = {}, t16 = this;
    this.generateEllipse(), this.generatePolygon("triangle", Vt4(3, 0)), this.generateRoundPolygon("round-triangle", Vt4(3, 0)), this.generatePolygon("rectangle", Vt4(4, 0)), e21.square = e21.rectangle, this.generateRoundRectangle(), this.generateCutRectangle(), this.generateBarrel(), this.generateBottomRoundrectangle();
    var n12 = [0, 1, 1, 0, 0, -1, -1, 0];
    this.generatePolygon("diamond", n12), this.generateRoundPolygon("round-diamond", n12), this.generatePolygon("pentagon", Vt4(5, 0)), this.generateRoundPolygon("round-pentagon", Vt4(5, 0)), this.generatePolygon("hexagon", Vt4(6, 0)), this.generateRoundPolygon("round-hexagon", Vt4(6, 0)), this.generatePolygon("heptagon", Vt4(7, 0)), this.generateRoundPolygon("round-heptagon", Vt4(7, 0)), this.generatePolygon("octagon", Vt4(8, 0)), this.generateRoundPolygon("round-octagon", Vt4(8, 0));
    var r9 = new Array(20), a10 = qt4(5, 0), i11 = qt4(5, Math.PI / 5), o12 = 0.5 * (3 - Math.sqrt(5));
    o12 *= 1.57;
    for (var s11 = 0; s11 < i11.length / 2; s11++)
      i11[2 * s11] *= o12, i11[2 * s11 + 1] *= o12;
    for (s11 = 0; s11 < 5; s11++)
      r9[4 * s11] = a10[2 * s11], r9[4 * s11 + 1] = a10[2 * s11 + 1], r9[4 * s11 + 2] = i11[2 * s11], r9[4 * s11 + 3] = i11[2 * s11 + 1];
    r9 = Ft4(r9), this.generatePolygon("star", r9), this.generatePolygon("vee", [-1, -1, 0, -0.333, 1, -1, 0, 1]), this.generatePolygon("rhomboid", [-1, -1, 0.333, -1, 1, 1, -0.333, 1]), this.generatePolygon("right-rhomboid", [-0.333, -1, 1, -1, 0.333, 1, -1, 1]), this.nodeShapes.concavehexagon = this.generatePolygon("concave-hexagon", [-1, -0.95, -0.75, 0, -1, 0.95, 1, 0.95, 0.75, 0, 1, -0.95]);
    var l11 = [-1, -1, 0.25, -1, 1, 0, 0.25, 1, -1, 1];
    this.generatePolygon("tag", l11), this.generateRoundPolygon("round-tag", l11), e21.makePolygon = function(e22) {
      var n13, r10 = "polygon-" + e22.join("$");
      return (n13 = this[r10]) ? n13 : t16.generatePolygon(r10, e22);
    };
  };
  var bs = { timeToRender: function() {
    return this.redrawTotalTime / this.redrawCount;
  }, redraw: function(e21) {
    e21 = e21 || Ie();
    var t16 = this;
    void 0 === t16.averageRedrawTime && (t16.averageRedrawTime = 0), void 0 === t16.lastRedrawTime && (t16.lastRedrawTime = 0), void 0 === t16.lastDrawTime && (t16.lastDrawTime = 0), t16.requestedFrame = true, t16.renderOptions = e21;
  }, beforeRender: function(e21, t16) {
    if (!this.destroyed) {
      null == t16 && Pe("Priority is not optional for beforeRender");
      var n12 = this.beforeRenderCallbacks;
      n12.push({ fn: e21, priority: t16 }), n12.sort(function(e22, t17) {
        return t17.priority - e22.priority;
      });
    }
  } };
  var xs = function(e21, t16, n12) {
    for (var r9 = e21.beforeRenderCallbacks, a10 = 0; a10 < r9.length; a10++)
      r9[a10].fn(t16, n12);
  };
  bs.startRenderLoop = function() {
    var e21 = this, t16 = e21.cy;
    if (!e21.renderLoopStarted) {
      e21.renderLoopStarted = true;
      se(function n12(r9) {
        if (!e21.destroyed) {
          if (t16.batching())
            ;
          else if (e21.requestedFrame && !e21.skipFrame) {
            xs(e21, true, r9);
            var a10 = le();
            e21.render(e21.renderOptions);
            var i11 = e21.lastDrawTime = le();
            void 0 === e21.averageRedrawTime && (e21.averageRedrawTime = i11 - a10), void 0 === e21.redrawCount && (e21.redrawCount = 0), e21.redrawCount++, void 0 === e21.redrawTotalTime && (e21.redrawTotalTime = 0);
            var o12 = i11 - a10;
            e21.redrawTotalTime += o12, e21.lastRedrawTime = o12, e21.averageRedrawTime = e21.averageRedrawTime / 2 + o12 / 2, e21.requestedFrame = false;
          } else
            xs(e21, false, r9);
          e21.skipFrame = false, se(n12);
        }
      });
    }
  };
  var ws = function(e21) {
    this.init(e21);
  };
  var Es = ws.prototype;
  Es.clientFunctions = ["redrawHint", "render", "renderTo", "matchCanvasSize", "nodeShapeImpl", "arrowShapeImpl"], Es.init = function(e21) {
    var t16 = this;
    t16.options = e21, t16.cy = e21.cy;
    var n12 = t16.container = e21.cy.container(), r9 = t16.cy.window();
    if (r9) {
      var a10 = r9.document, i11 = a10.head, o12 = "__________cytoscape_stylesheet", s11 = "__________cytoscape_container", l11 = null != a10.getElementById(o12);
      if (n12.className.indexOf(s11) < 0 && (n12.className = (n12.className || "") + " " + s11), !l11) {
        var u10 = a10.createElement("style");
        u10.id = o12, u10.textContent = "." + s11 + " { position: relative; }", i11.insertBefore(u10, i11.children[0]);
      }
      "static" === r9.getComputedStyle(n12).getPropertyValue("position") && Me("A Cytoscape container has style position:static and so can not use UI extensions properly");
    }
    t16.selection = [void 0, void 0, void 0, void 0, 0], t16.bezierProjPcts = [0.05, 0.225, 0.4, 0.5, 0.6, 0.775, 0.95], t16.hoverData = { down: null, last: null, downTime: null, triggerMode: null, dragging: false, initialPan: [null, null], capture: false }, t16.dragData = { possibleDragElements: [] }, t16.touchData = { start: null, capture: false, startPosition: [null, null, null, null, null, null], singleTouchStartTime: null, singleTouchMoved: true, now: [null, null, null, null, null, null], earlier: [null, null, null, null, null, null] }, t16.redraws = 0, t16.showFps = e21.showFps, t16.debug = e21.debug, t16.hideEdgesOnViewport = e21.hideEdgesOnViewport, t16.textureOnViewport = e21.textureOnViewport, t16.wheelSensitivity = e21.wheelSensitivity, t16.motionBlurEnabled = e21.motionBlur, t16.forcedPixelRatio = I6(e21.pixelRatio) ? e21.pixelRatio : null, t16.motionBlur = e21.motionBlur, t16.motionBlurOpacity = e21.motionBlurOpacity, t16.motionBlurTransparency = 1 - t16.motionBlurOpacity, t16.motionBlurPxRatio = 1, t16.mbPxRBlurry = 1, t16.minMbLowQualFrames = 4, t16.fullQualityMb = false, t16.clearedForMotionBlur = [], t16.desktopTapThreshold = e21.desktopTapThreshold, t16.desktopTapThreshold2 = e21.desktopTapThreshold * e21.desktopTapThreshold, t16.touchTapThreshold = e21.touchTapThreshold, t16.touchTapThreshold2 = e21.touchTapThreshold * e21.touchTapThreshold, t16.tapholdDuration = 500, t16.bindings = [], t16.beforeRenderCallbacks = [], t16.beforeRenderPriorities = { animations: 400, eleCalcs: 300, eleTxrDeq: 200, lyrTxrDeq: 150, lyrTxrSkip: 100 }, t16.registerNodeShapes(), t16.registerArrowShapes(), t16.registerCalculationListeners();
  }, Es.notify = function(e21, t16) {
    var n12 = this, r9 = n12.cy;
    this.destroyed || ("init" !== e21 ? "destroy" !== e21 ? (("add" === e21 || "remove" === e21 || "move" === e21 && r9.hasCompoundNodes() || "load" === e21 || "zorder" === e21 || "mount" === e21) && n12.invalidateCachedZSortedEles(), "viewport" === e21 && n12.redrawHint("select", true), "load" !== e21 && "resize" !== e21 && "mount" !== e21 || (n12.invalidateContainerClientCoordsCache(), n12.matchCanvasSize(n12.container)), n12.redrawHint("eles", true), n12.redrawHint("drag", true), this.startRenderLoop(), this.redraw()) : n12.destroy() : n12.load());
  }, Es.destroy = function() {
    var e21 = this;
    e21.destroyed = true, e21.cy.stopAnimationLoop();
    for (var t16 = 0; t16 < e21.bindings.length; t16++) {
      var n12 = e21.bindings[t16], r9 = n12.target;
      (r9.off || r9.removeEventListener).apply(r9, n12.args);
    }
    if (e21.bindings = [], e21.beforeRenderCallbacks = [], e21.onUpdateEleCalcsFns = [], e21.removeObserver && e21.removeObserver.disconnect(), e21.styleObserver && e21.styleObserver.disconnect(), e21.resizeObserver && e21.resizeObserver.disconnect(), e21.labelCalcDiv)
      try {
        document.body.removeChild(e21.labelCalcDiv);
      } catch (e22) {
      }
  }, Es.isHeadless = function() {
    return false;
  }, [es, gs, vs, ys, ms, bs].forEach(function(e21) {
    J4(Es, e21);
  });
  var ks = 1e3 / 60;
  var Cs = function(e21) {
    return function() {
      var t16 = this, n12 = this.renderer;
      if (!t16.dequeueingSetup) {
        t16.dequeueingSetup = true;
        var r9 = c6.default(function() {
          n12.redrawHint("eles", true), n12.redrawHint("drag", true), n12.redraw();
        }, e21.deqRedrawThreshold), a10 = e21.priority || De;
        n12.beforeRender(function(a11, i11) {
          var o12 = le(), s11 = n12.averageRedrawTime, l11 = n12.lastRedrawTime, u10 = [], c10 = n12.cy.extent(), d12 = n12.getPixelRatio();
          for (a11 || n12.flushRenderedStyleQueue(); ; ) {
            var h10 = le(), p10 = h10 - o12, f11 = h10 - i11;
            if (l11 < ks) {
              var g9 = ks - (a11 ? s11 : 0);
              if (f11 >= e21.deqFastCost * g9)
                break;
            } else if (a11) {
              if (p10 >= e21.deqCost * l11 || p10 >= e21.deqAvgCost * s11)
                break;
            } else if (f11 >= e21.deqNoDrawCost * ks)
              break;
            var v12 = e21.deq(t16, d12, c10);
            if (!(v12.length > 0))
              break;
            for (var y10 = 0; y10 < v12.length; y10++)
              u10.push(v12[y10]);
          }
          u10.length > 0 && (e21.onDeqd(t16, u10), !a11 && e21.shouldRedraw(t16, u10, d12, c10) && r9());
        }, a10(t16));
      }
    };
  };
  var Ss = function() {
    function e21(t16) {
      var n12 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Ce;
      v6(this, e21), this.idsByKey = new Ve(), this.keyForId = new Ve(), this.cachesByLvl = new Ve(), this.lvls = [], this.getKey = t16, this.doesEleInvalidateKey = n12;
    }
    return m7(e21, [{ key: "getIdsFor", value: function(e22) {
      null == e22 && Pe("Can not get id list for null key");
      var t16 = this.idsByKey, n12 = this.idsByKey.get(e22);
      return n12 || (n12 = new qe(), t16.set(e22, n12)), n12;
    } }, { key: "addIdForKey", value: function(e22, t16) {
      null != e22 && this.getIdsFor(e22).add(t16);
    } }, { key: "deleteIdForKey", value: function(e22, t16) {
      null != e22 && this.getIdsFor(e22).delete(t16);
    } }, { key: "getNumberOfIdsForKey", value: function(e22) {
      return null == e22 ? 0 : this.getIdsFor(e22).size;
    } }, { key: "updateKeyMappingFor", value: function(e22) {
      var t16 = e22.id(), n12 = this.keyForId.get(t16), r9 = this.getKey(e22);
      this.deleteIdForKey(n12, t16), this.addIdForKey(r9, t16), this.keyForId.set(t16, r9);
    } }, { key: "deleteKeyMappingFor", value: function(e22) {
      var t16 = e22.id(), n12 = this.keyForId.get(t16);
      this.deleteIdForKey(n12, t16), this.keyForId.delete(t16);
    } }, { key: "keyHasChangedFor", value: function(e22) {
      var t16 = e22.id();
      return this.keyForId.get(t16) !== this.getKey(e22);
    } }, { key: "isInvalid", value: function(e22) {
      return this.keyHasChangedFor(e22) || this.doesEleInvalidateKey(e22);
    } }, { key: "getCachesAt", value: function(e22) {
      var t16 = this.cachesByLvl, n12 = this.lvls, r9 = t16.get(e22);
      return r9 || (r9 = new Ve(), t16.set(e22, r9), n12.push(e22)), r9;
    } }, { key: "getCache", value: function(e22, t16) {
      return this.getCachesAt(t16).get(e22);
    } }, { key: "get", value: function(e22, t16) {
      var n12 = this.getKey(e22), r9 = this.getCache(n12, t16);
      return null != r9 && this.updateKeyMappingFor(e22), r9;
    } }, { key: "getForCachedKey", value: function(e22, t16) {
      var n12 = this.keyForId.get(e22.id());
      return this.getCache(n12, t16);
    } }, { key: "hasCache", value: function(e22, t16) {
      return this.getCachesAt(t16).has(e22);
    } }, { key: "has", value: function(e22, t16) {
      var n12 = this.getKey(e22);
      return this.hasCache(n12, t16);
    } }, { key: "setCache", value: function(e22, t16, n12) {
      n12.key = e22, this.getCachesAt(t16).set(e22, n12);
    } }, { key: "set", value: function(e22, t16, n12) {
      var r9 = this.getKey(e22);
      this.setCache(r9, t16, n12), this.updateKeyMappingFor(e22);
    } }, { key: "deleteCache", value: function(e22, t16) {
      this.getCachesAt(t16).delete(e22);
    } }, { key: "delete", value: function(e22, t16) {
      var n12 = this.getKey(e22);
      this.deleteCache(n12, t16);
    } }, { key: "invalidateKey", value: function(e22) {
      var t16 = this;
      this.lvls.forEach(function(n12) {
        return t16.deleteCache(e22, n12);
      });
    } }, { key: "invalidate", value: function(e22) {
      var t16 = e22.id(), n12 = this.keyForId.get(t16);
      this.deleteKeyMappingFor(e22);
      var r9 = this.doesEleInvalidateKey(e22);
      return r9 && this.invalidateKey(n12), r9 || 0 === this.getNumberOfIdsForKey(n12);
    } }]), e21;
  }();
  var Ds = { dequeue: "dequeue", downscale: "downscale", highQuality: "highQuality" };
  var Ps = ze({ getKey: null, doesEleInvalidateKey: Ce, drawElement: null, getBoundingBox: null, getRotationPoint: null, getRotationOffset: null, isVisible: ke, allowEdgeTxrCaching: true, allowParentTxrCaching: true });
  var Ts = function(e21, t16) {
    var n12 = this;
    n12.renderer = e21, n12.onDequeues = [];
    var r9 = Ps(t16);
    J4(n12, r9), n12.lookup = new Ss(r9.getKey, r9.doesEleInvalidateKey), n12.setupDequeueing();
  };
  var Ms = Ts.prototype;
  Ms.reasons = Ds, Ms.getTextureQueue = function(e21) {
    var t16 = this;
    return t16.eleImgCaches = t16.eleImgCaches || {}, t16.eleImgCaches[e21] = t16.eleImgCaches[e21] || [];
  }, Ms.getRetiredTextureQueue = function(e21) {
    var t16 = this.eleImgCaches.retired = this.eleImgCaches.retired || {};
    return t16[e21] = t16[e21] || [];
  }, Ms.getElementQueue = function() {
    return this.eleCacheQueue = this.eleCacheQueue || new d7.default(function(e21, t16) {
      return t16.reqs - e21.reqs;
    });
  }, Ms.getElementKeyToQueue = function() {
    return this.eleKeyToCacheQueue = this.eleKeyToCacheQueue || {};
  }, Ms.getElement = function(e21, t16, n12, r9, a10) {
    var i11 = this, o12 = this.renderer, s11 = o12.cy.zoom(), l11 = this.lookup;
    if (!t16 || 0 === t16.w || 0 === t16.h || isNaN(t16.w) || isNaN(t16.h) || !e21.visible() || e21.removed())
      return null;
    if (!i11.allowEdgeTxrCaching && e21.isEdge() || !i11.allowParentTxrCaching && e21.isParent())
      return null;
    if (null == r9 && (r9 = Math.ceil(lt4(s11 * n12))), r9 < -4)
      r9 = -4;
    else if (s11 >= 7.99 || r9 > 3)
      return null;
    var u10 = Math.pow(2, r9), c10 = t16.h * u10, d12 = t16.w * u10, h10 = o12.eleTextBiggerThanMin(e21, u10);
    if (!this.isVisible(e21, h10))
      return null;
    var p10, f11 = l11.get(e21, r9);
    if (f11 && f11.invalidated && (f11.invalidated = false, f11.texture.invalidatedWidth -= f11.width), f11)
      return f11;
    if (p10 = c10 <= 25 ? 25 : c10 <= 50 ? 50 : 50 * Math.ceil(c10 / 50), c10 > 1024 || d12 > 1024)
      return null;
    var g9 = i11.getTextureQueue(p10), v12 = g9[g9.length - 2], y10 = function() {
      return i11.recycleTexture(p10, d12) || i11.addTexture(p10, d12);
    };
    v12 || (v12 = g9[g9.length - 1]), v12 || (v12 = y10()), v12.width - v12.usedWidth < d12 && (v12 = y10());
    for (var m12, b11 = function(e22) {
      return e22 && e22.scaledLabelShown === h10;
    }, x10 = a10 && a10 === Ds.dequeue, w11 = a10 && a10 === Ds.highQuality, E9 = a10 && a10 === Ds.downscale, k10 = r9 + 1; k10 <= 3; k10++) {
      var C9 = l11.get(e21, k10);
      if (C9) {
        m12 = C9;
        break;
      }
    }
    var S8 = m12 && m12.level === r9 + 1 ? m12 : null, D9 = function() {
      v12.context.drawImage(S8.texture.canvas, S8.x, 0, S8.width, S8.height, v12.usedWidth, 0, d12, c10);
    };
    if (v12.context.setTransform(1, 0, 0, 1, 0, 0), v12.context.clearRect(v12.usedWidth, 0, d12, p10), b11(S8))
      D9();
    else if (b11(m12)) {
      if (!w11)
        return i11.queueElement(e21, m12.level - 1), m12;
      for (var P10 = m12.level; P10 > r9; P10--)
        S8 = i11.getElement(e21, t16, n12, P10, Ds.downscale);
      D9();
    } else {
      var T9;
      if (!x10 && !w11 && !E9)
        for (var M9 = r9 - 1; M9 >= -4; M9--) {
          var B9 = l11.get(e21, M9);
          if (B9) {
            T9 = B9;
            break;
          }
        }
      if (b11(T9))
        return i11.queueElement(e21, r9), T9;
      v12.context.translate(v12.usedWidth, 0), v12.context.scale(u10, u10), this.drawElement(v12.context, e21, t16, h10, false), v12.context.scale(1 / u10, 1 / u10), v12.context.translate(-v12.usedWidth, 0);
    }
    return f11 = { x: v12.usedWidth, texture: v12, level: r9, scale: u10, width: d12, height: c10, scaledLabelShown: h10 }, v12.usedWidth += Math.ceil(d12 + 8), v12.eleCaches.push(f11), l11.set(e21, r9, f11), i11.checkTextureFullness(v12), f11;
  }, Ms.invalidateElements = function(e21) {
    for (var t16 = 0; t16 < e21.length; t16++)
      this.invalidateElement(e21[t16]);
  }, Ms.invalidateElement = function(e21) {
    var t16 = this, n12 = t16.lookup, r9 = [];
    if (n12.isInvalid(e21)) {
      for (var a10 = -4; a10 <= 3; a10++) {
        var i11 = n12.getForCachedKey(e21, a10);
        i11 && r9.push(i11);
      }
      if (n12.invalidate(e21))
        for (var o12 = 0; o12 < r9.length; o12++) {
          var s11 = r9[o12], l11 = s11.texture;
          l11.invalidatedWidth += s11.width, s11.invalidated = true, t16.checkTextureUtility(l11);
        }
      t16.removeFromQueue(e21);
    }
  }, Ms.checkTextureUtility = function(e21) {
    e21.invalidatedWidth >= 0.2 * e21.width && this.retireTexture(e21);
  }, Ms.checkTextureFullness = function(e21) {
    var t16 = this.getTextureQueue(e21.height);
    e21.usedWidth / e21.width > 0.8 && e21.fullnessChecks >= 10 ? Le(t16, e21) : e21.fullnessChecks++;
  }, Ms.retireTexture = function(e21) {
    var t16 = e21.height, n12 = this.getTextureQueue(t16), r9 = this.lookup;
    Le(n12, e21), e21.retired = true;
    for (var a10 = e21.eleCaches, i11 = 0; i11 < a10.length; i11++) {
      var o12 = a10[i11];
      r9.deleteCache(o12.key, o12.level);
    }
    Ae(a10), this.getRetiredTextureQueue(t16).push(e21);
  }, Ms.addTexture = function(e21, t16) {
    var n12 = {};
    return this.getTextureQueue(e21).push(n12), n12.eleCaches = [], n12.height = e21, n12.width = Math.max(1024, t16), n12.usedWidth = 0, n12.invalidatedWidth = 0, n12.fullnessChecks = 0, n12.canvas = this.renderer.makeOffscreenCanvas(n12.width, n12.height), n12.context = n12.canvas.getContext("2d"), n12;
  }, Ms.recycleTexture = function(e21, t16) {
    for (var n12 = this.getTextureQueue(e21), r9 = this.getRetiredTextureQueue(e21), a10 = 0; a10 < r9.length; a10++) {
      var i11 = r9[a10];
      if (i11.width >= t16)
        return i11.retired = false, i11.usedWidth = 0, i11.invalidatedWidth = 0, i11.fullnessChecks = 0, Ae(i11.eleCaches), i11.context.setTransform(1, 0, 0, 1, 0, 0), i11.context.clearRect(0, 0, i11.width, i11.height), Le(r9, i11), n12.push(i11), i11;
    }
  }, Ms.queueElement = function(e21, t16) {
    var n12 = this.getElementQueue(), r9 = this.getElementKeyToQueue(), a10 = this.getKey(e21), i11 = r9[a10];
    if (i11)
      i11.level = Math.max(i11.level, t16), i11.eles.merge(e21), i11.reqs++, n12.updateItem(i11);
    else {
      var o12 = { eles: e21.spawn().merge(e21), level: t16, reqs: 1, key: a10 };
      n12.push(o12), r9[a10] = o12;
    }
  }, Ms.dequeue = function(e21) {
    for (var t16 = this, n12 = t16.getElementQueue(), r9 = t16.getElementKeyToQueue(), a10 = [], i11 = t16.lookup, o12 = 0; o12 < 1 && n12.size() > 0; o12++) {
      var s11 = n12.pop(), l11 = s11.key, u10 = s11.eles[0], c10 = i11.hasCache(u10, s11.level);
      if (r9[l11] = null, !c10) {
        a10.push(s11);
        var d12 = t16.getBoundingBox(u10);
        t16.getElement(u10, d12, e21, s11.level, Ds.dequeue);
      }
    }
    return a10;
  }, Ms.removeFromQueue = function(e21) {
    var t16 = this.getElementQueue(), n12 = this.getElementKeyToQueue(), r9 = this.getKey(e21), a10 = n12[r9];
    null != a10 && (1 === a10.eles.length ? (a10.reqs = Ee, t16.updateItem(a10), t16.pop(), n12[r9] = null) : a10.eles.unmerge(e21));
  }, Ms.onDequeue = function(e21) {
    this.onDequeues.push(e21);
  }, Ms.offDequeue = function(e21) {
    Le(this.onDequeues, e21);
  }, Ms.setupDequeueing = Cs({ deqRedrawThreshold: 100, deqCost: 0.15, deqAvgCost: 0.1, deqNoDrawCost: 0.9, deqFastCost: 0.9, deq: function(e21, t16, n12) {
    return e21.dequeue(t16, n12);
  }, onDeqd: function(e21, t16) {
    for (var n12 = 0; n12 < e21.onDequeues.length; n12++) {
      (0, e21.onDequeues[n12])(t16);
    }
  }, shouldRedraw: function(e21, t16, n12, r9) {
    for (var a10 = 0; a10 < t16.length; a10++)
      for (var i11 = t16[a10].eles, o12 = 0; o12 < i11.length; o12++) {
        var s11 = i11[o12].boundingBox();
        if (wt4(s11, r9))
          return true;
      }
    return false;
  }, priority: function(e21) {
    return e21.renderer.beforeRenderPriorities.eleTxrDeq;
  } });
  var Bs = function(e21) {
    var t16 = this, n12 = t16.renderer = e21, r9 = n12.cy;
    t16.layersByLevel = {}, t16.firstGet = true, t16.lastInvalidationTime = le() - 500, t16.skipping = false, t16.eleTxrDeqs = r9.collection(), t16.scheduleElementRefinement = c6.default(function() {
      t16.refineElementTextures(t16.eleTxrDeqs), t16.eleTxrDeqs.unmerge(t16.eleTxrDeqs);
    }, 50), n12.beforeRender(function(e22, n13) {
      n13 - t16.lastInvalidationTime <= 250 ? t16.skipping = true : t16.skipping = false;
    }, n12.beforeRenderPriorities.lyrTxrSkip);
    t16.layersQueue = new d7.default(function(e22, t17) {
      return t17.reqs - e22.reqs;
    }), t16.setupDequeueing();
  };
  var _s = Bs.prototype;
  var Ns = 0;
  var Is = Math.pow(2, 53) - 1;
  _s.makeLayer = function(e21, t16) {
    var n12 = Math.pow(2, t16), r9 = Math.ceil(e21.w * n12), a10 = Math.ceil(e21.h * n12), i11 = this.renderer.makeOffscreenCanvas(r9, a10), o12 = { id: Ns = ++Ns % Is, bb: e21, level: t16, width: r9, height: a10, canvas: i11, context: i11.getContext("2d"), eles: [], elesQueue: [], reqs: 0 }, s11 = o12.context, l11 = -o12.bb.x1, u10 = -o12.bb.y1;
    return s11.scale(n12, n12), s11.translate(l11, u10), o12;
  }, _s.getLayers = function(e21, t16, n12) {
    var r9 = this, a10 = r9.renderer.cy.zoom(), i11 = r9.firstGet;
    if (r9.firstGet = false, null == n12) {
      if ((n12 = Math.ceil(lt4(a10 * t16))) < -4)
        n12 = -4;
      else if (a10 >= 3.99 || n12 > 2)
        return null;
    }
    r9.validateLayersElesOrdering(n12, e21);
    var o12, s11, l11 = r9.layersByLevel, u10 = Math.pow(2, n12), c10 = l11[n12] = l11[n12] || [];
    if (r9.levelIsComplete(n12, e21))
      return c10;
    !function() {
      var t17 = function(t18) {
        if (r9.validateLayersElesOrdering(t18, e21), r9.levelIsComplete(t18, e21))
          return s11 = l11[t18], true;
      }, a11 = function(e22) {
        if (!s11)
          for (var r10 = n12 + e22; -4 <= r10 && r10 <= 2 && !t17(r10); r10 += e22)
            ;
      };
      a11(1), a11(-1);
      for (var i12 = c10.length - 1; i12 >= 0; i12--) {
        var o13 = c10[i12];
        o13.invalid && Le(c10, o13);
      }
    }();
    var d12 = function(t17) {
      var a11 = (t17 = t17 || {}).after;
      if (function() {
        if (!o12) {
          o12 = vt4();
          for (var t18 = 0; t18 < e21.length; t18++)
            n13 = o12, r10 = e21[t18].boundingBox(), n13.x1 = Math.min(n13.x1, r10.x1), n13.x2 = Math.max(n13.x2, r10.x2), n13.w = n13.x2 - n13.x1, n13.y1 = Math.min(n13.y1, r10.y1), n13.y2 = Math.max(n13.y2, r10.y2), n13.h = n13.y2 - n13.y1;
        }
        var n13, r10;
      }(), o12.w * u10 * (o12.h * u10) > 16e6)
        return null;
      var i12 = r9.makeLayer(o12, n12);
      if (null != a11) {
        var s12 = c10.indexOf(a11) + 1;
        c10.splice(s12, 0, i12);
      } else
        (void 0 === t17.insert || t17.insert) && c10.unshift(i12);
      return i12;
    };
    if (r9.skipping && !i11)
      return null;
    for (var h10 = null, p10 = e21.length / 1, f11 = !i11, g9 = 0; g9 < e21.length; g9++) {
      var v12 = e21[g9], y10 = v12._private.rscratch, m12 = y10.imgLayerCaches = y10.imgLayerCaches || {}, b11 = m12[n12];
      if (b11)
        h10 = b11;
      else {
        if ((!h10 || h10.eles.length >= p10 || !kt4(h10.bb, v12.boundingBox())) && !(h10 = d12({ insert: true, after: h10 })))
          return null;
        s11 || f11 ? r9.queueLayer(h10, v12) : r9.drawEleInLayer(h10, v12, n12, t16), h10.eles.push(v12), m12[n12] = h10;
      }
    }
    return s11 || (f11 ? null : c10);
  }, _s.getEleLevelForLayerLevel = function(e21, t16) {
    return e21;
  }, _s.drawEleInLayer = function(e21, t16, n12, r9) {
    var a10 = this.renderer, i11 = e21.context, o12 = t16.boundingBox();
    0 !== o12.w && 0 !== o12.h && t16.visible() && (n12 = this.getEleLevelForLayerLevel(n12, r9), a10.setImgSmoothing(i11, false), a10.drawCachedElement(i11, t16, null, null, n12, true), a10.setImgSmoothing(i11, true));
  }, _s.levelIsComplete = function(e21, t16) {
    var n12 = this.layersByLevel[e21];
    if (!n12 || 0 === n12.length)
      return false;
    for (var r9 = 0, a10 = 0; a10 < n12.length; a10++) {
      var i11 = n12[a10];
      if (i11.reqs > 0)
        return false;
      if (i11.invalid)
        return false;
      r9 += i11.eles.length;
    }
    return r9 === t16.length;
  }, _s.validateLayersElesOrdering = function(e21, t16) {
    var n12 = this.layersByLevel[e21];
    if (n12)
      for (var r9 = 0; r9 < n12.length; r9++) {
        for (var a10 = n12[r9], i11 = -1, o12 = 0; o12 < t16.length; o12++)
          if (a10.eles[0] === t16[o12]) {
            i11 = o12;
            break;
          }
        if (i11 < 0)
          this.invalidateLayer(a10);
        else {
          var s11 = i11;
          for (o12 = 0; o12 < a10.eles.length; o12++)
            if (a10.eles[o12] !== t16[s11 + o12]) {
              this.invalidateLayer(a10);
              break;
            }
        }
      }
  }, _s.updateElementsInLayers = function(e21, t16) {
    for (var n12 = A6(e21[0]), r9 = 0; r9 < e21.length; r9++)
      for (var a10 = n12 ? null : e21[r9], i11 = n12 ? e21[r9] : e21[r9].ele, o12 = i11._private.rscratch, s11 = o12.imgLayerCaches = o12.imgLayerCaches || {}, l11 = -4; l11 <= 2; l11++) {
        var u10 = s11[l11];
        u10 && (a10 && this.getEleLevelForLayerLevel(u10.level) !== a10.level || t16(u10, i11, a10));
      }
  }, _s.haveLayers = function() {
    for (var e21 = false, t16 = -4; t16 <= 2; t16++) {
      var n12 = this.layersByLevel[t16];
      if (n12 && n12.length > 0) {
        e21 = true;
        break;
      }
    }
    return e21;
  }, _s.invalidateElements = function(e21) {
    var t16 = this;
    0 !== e21.length && (t16.lastInvalidationTime = le(), 0 !== e21.length && t16.haveLayers() && t16.updateElementsInLayers(e21, function(e22, n12, r9) {
      t16.invalidateLayer(e22);
    }));
  }, _s.invalidateLayer = function(e21) {
    if (this.lastInvalidationTime = le(), !e21.invalid) {
      var t16 = e21.level, n12 = e21.eles, r9 = this.layersByLevel[t16];
      Le(r9, e21), e21.elesQueue = [], e21.invalid = true, e21.replacement && (e21.replacement.invalid = true);
      for (var a10 = 0; a10 < n12.length; a10++) {
        var i11 = n12[a10]._private.rscratch.imgLayerCaches;
        i11 && (i11[t16] = null);
      }
    }
  }, _s.refineElementTextures = function(e21) {
    var t16 = this;
    t16.updateElementsInLayers(e21, function(e22, n12, r9) {
      var a10 = e22.replacement;
      if (a10 || ((a10 = e22.replacement = t16.makeLayer(e22.bb, e22.level)).replaces = e22, a10.eles = e22.eles), !a10.reqs)
        for (var i11 = 0; i11 < a10.eles.length; i11++)
          t16.queueLayer(a10, a10.eles[i11]);
    });
  }, _s.enqueueElementRefinement = function(e21) {
    this.eleTxrDeqs.merge(e21), this.scheduleElementRefinement();
  }, _s.queueLayer = function(e21, t16) {
    var n12 = this.layersQueue, r9 = e21.elesQueue, a10 = r9.hasId = r9.hasId || {};
    if (!e21.replacement) {
      if (t16) {
        if (a10[t16.id()])
          return;
        r9.push(t16), a10[t16.id()] = true;
      }
      e21.reqs ? (e21.reqs++, n12.updateItem(e21)) : (e21.reqs = 1, n12.push(e21));
    }
  }, _s.dequeue = function(e21) {
    for (var t16 = this, n12 = t16.layersQueue, r9 = [], a10 = 0; a10 < 1 && 0 !== n12.size(); ) {
      var i11 = n12.peek();
      if (i11.replacement)
        n12.pop();
      else if (i11.replaces && i11 !== i11.replaces.replacement)
        n12.pop();
      else if (i11.invalid)
        n12.pop();
      else {
        var o12 = i11.elesQueue.shift();
        o12 && (t16.drawEleInLayer(i11, o12, i11.level, e21), a10++), 0 === r9.length && r9.push(true), 0 === i11.elesQueue.length && (n12.pop(), i11.reqs = 0, i11.replaces && t16.applyLayerReplacement(i11), t16.requestRedraw());
      }
    }
    return r9;
  }, _s.applyLayerReplacement = function(e21) {
    var t16 = this.layersByLevel[e21.level], n12 = e21.replaces, r9 = t16.indexOf(n12);
    if (!(r9 < 0 || n12.invalid)) {
      t16[r9] = e21;
      for (var a10 = 0; a10 < e21.eles.length; a10++) {
        var i11 = e21.eles[a10]._private, o12 = i11.imgLayerCaches = i11.imgLayerCaches || {};
        o12 && (o12[e21.level] = e21);
      }
      this.requestRedraw();
    }
  }, _s.requestRedraw = c6.default(function() {
    var e21 = this.renderer;
    e21.redrawHint("eles", true), e21.redrawHint("drag", true), e21.redraw();
  }, 100), _s.setupDequeueing = Cs({ deqRedrawThreshold: 50, deqCost: 0.15, deqAvgCost: 0.1, deqNoDrawCost: 0.9, deqFastCost: 0.9, deq: function(e21, t16) {
    return e21.dequeue(t16);
  }, onDeqd: De, shouldRedraw: ke, priority: function(e21) {
    return e21.renderer.beforeRenderPriorities.lyrTxrDeq;
  } });
  var zs;
  var Ls = {};
  function As(e21, t16) {
    for (var n12 = 0; n12 < t16.length; n12++) {
      var r9 = t16[n12];
      e21.lineTo(r9.x, r9.y);
    }
  }
  function Os(e21, t16, n12) {
    for (var r9, a10 = 0; a10 < t16.length; a10++) {
      var i11 = t16[a10];
      0 === a10 && (r9 = i11), e21.lineTo(i11.x, i11.y);
    }
    e21.quadraticCurveTo(n12.x, n12.y, r9.x, r9.y);
  }
  function Rs(e21, t16, n12) {
    e21.beginPath && e21.beginPath();
    for (var r9 = t16, a10 = 0; a10 < r9.length; a10++) {
      var i11 = r9[a10];
      e21.lineTo(i11.x, i11.y);
    }
    var o12 = n12, s11 = n12[0];
    e21.moveTo(s11.x, s11.y);
    for (a10 = 1; a10 < o12.length; a10++) {
      i11 = o12[a10];
      e21.lineTo(i11.x, i11.y);
    }
    e21.closePath && e21.closePath();
  }
  function Vs(e21, t16, n12, r9, a10) {
    e21.beginPath && e21.beginPath(), e21.arc(n12, r9, a10, 0, 2 * Math.PI, false);
    var i11 = t16, o12 = i11[0];
    e21.moveTo(o12.x, o12.y);
    for (var s11 = 0; s11 < i11.length; s11++) {
      var l11 = i11[s11];
      e21.lineTo(l11.x, l11.y);
    }
    e21.closePath && e21.closePath();
  }
  function Fs(e21, t16, n12, r9) {
    e21.arc(t16, n12, r9, 0, 2 * Math.PI, false);
  }
  Ls.arrowShapeImpl = function(e21) {
    return (zs || (zs = { polygon: As, "triangle-backcurve": Os, "triangle-tee": Rs, "circle-triangle": Vs, "triangle-cross": Rs, circle: Fs }))[e21];
  };
  var qs = { drawElement: function(e21, t16, n12, r9, a10, i11) {
    t16.isNode() ? this.drawNode(e21, t16, n12, r9, a10, i11) : this.drawEdge(e21, t16, n12, r9, a10, i11);
  }, drawElementOverlay: function(e21, t16) {
    t16.isNode() ? this.drawNodeOverlay(e21, t16) : this.drawEdgeOverlay(e21, t16);
  }, drawElementUnderlay: function(e21, t16) {
    t16.isNode() ? this.drawNodeUnderlay(e21, t16) : this.drawEdgeUnderlay(e21, t16);
  }, drawCachedElementPortion: function(e21, t16, n12, r9, a10, i11, o12, s11) {
    var l11 = this, u10 = n12.getBoundingBox(t16);
    if (0 !== u10.w && 0 !== u10.h) {
      var c10 = n12.getElement(t16, u10, r9, a10, i11);
      if (null != c10) {
        var d12 = s11(l11, t16);
        if (0 === d12)
          return;
        var h10, p10, f11, g9, v12, y10, m12 = o12(l11, t16), b11 = u10.x1, x10 = u10.y1, w11 = u10.w, E9 = u10.h;
        if (0 !== m12) {
          var k10 = n12.getRotationPoint(t16);
          f11 = k10.x, g9 = k10.y, e21.translate(f11, g9), e21.rotate(m12), (v12 = l11.getImgSmoothing(e21)) || l11.setImgSmoothing(e21, true);
          var C9 = n12.getRotationOffset(t16);
          h10 = C9.x, p10 = C9.y;
        } else
          h10 = b11, p10 = x10;
        1 !== d12 && (y10 = e21.globalAlpha, e21.globalAlpha = y10 * d12), e21.drawImage(c10.texture.canvas, c10.x, 0, c10.width, c10.height, h10, p10, w11, E9), 1 !== d12 && (e21.globalAlpha = y10), 0 !== m12 && (e21.rotate(-m12), e21.translate(-f11, -g9), v12 || l11.setImgSmoothing(e21, false));
      } else
        n12.drawElement(e21, t16);
    }
  } };
  var js = function() {
    return 0;
  };
  var Ys = function(e21, t16) {
    return e21.getTextAngle(t16, null);
  };
  var Xs = function(e21, t16) {
    return e21.getTextAngle(t16, "source");
  };
  var Ws = function(e21, t16) {
    return e21.getTextAngle(t16, "target");
  };
  var Hs = function(e21, t16) {
    return t16.effectiveOpacity();
  };
  var Ks = function(e21, t16) {
    return t16.pstyle("text-opacity").pfValue * t16.effectiveOpacity();
  };
  qs.drawCachedElement = function(e21, t16, n12, r9, a10, i11) {
    var o12 = this, s11 = o12.data, l11 = s11.eleTxrCache, u10 = s11.lblTxrCache, c10 = s11.slbTxrCache, d12 = s11.tlbTxrCache, h10 = t16.boundingBox(), p10 = true === i11 ? l11.reasons.highQuality : null;
    if (0 !== h10.w && 0 !== h10.h && t16.visible() && (!r9 || wt4(h10, r9))) {
      var f11 = t16.isEdge(), g9 = t16.element()._private.rscratch.badLine;
      o12.drawElementUnderlay(e21, t16), o12.drawCachedElementPortion(e21, t16, l11, n12, a10, p10, js, Hs), f11 && g9 || o12.drawCachedElementPortion(e21, t16, u10, n12, a10, p10, Ys, Ks), f11 && !g9 && (o12.drawCachedElementPortion(e21, t16, c10, n12, a10, p10, Xs, Ks), o12.drawCachedElementPortion(e21, t16, d12, n12, a10, p10, Ws, Ks)), o12.drawElementOverlay(e21, t16);
    }
  }, qs.drawElements = function(e21, t16) {
    for (var n12 = 0; n12 < t16.length; n12++) {
      var r9 = t16[n12];
      this.drawElement(e21, r9);
    }
  }, qs.drawCachedElements = function(e21, t16, n12, r9) {
    for (var a10 = 0; a10 < t16.length; a10++) {
      var i11 = t16[a10];
      this.drawCachedElement(e21, i11, n12, r9);
    }
  }, qs.drawCachedNodes = function(e21, t16, n12, r9) {
    for (var a10 = 0; a10 < t16.length; a10++) {
      var i11 = t16[a10];
      i11.isNode() && this.drawCachedElement(e21, i11, n12, r9);
    }
  }, qs.drawLayeredElements = function(e21, t16, n12, r9) {
    var a10 = this.data.lyrTxrCache.getLayers(t16, n12);
    if (a10)
      for (var i11 = 0; i11 < a10.length; i11++) {
        var o12 = a10[i11], s11 = o12.bb;
        0 !== s11.w && 0 !== s11.h && e21.drawImage(o12.canvas, s11.x1, s11.y1, s11.w, s11.h);
      }
    else
      this.drawCachedElements(e21, t16, n12, r9);
  };
  var Gs = { drawEdge: function(e21, t16, n12) {
    var r9 = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3], a10 = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], i11 = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5], o12 = this, s11 = t16._private.rscratch;
    if ((!i11 || t16.visible()) && !s11.badLine && null != s11.allpts && !isNaN(s11.allpts[0])) {
      var l11;
      n12 && (l11 = n12, e21.translate(-l11.x1, -l11.y1));
      var u10 = i11 ? t16.pstyle("opacity").value : 1, c10 = i11 ? t16.pstyle("line-opacity").value : 1, d12 = t16.pstyle("curve-style").value, h10 = t16.pstyle("line-style").value, p10 = t16.pstyle("width").pfValue, f11 = t16.pstyle("line-cap").value, g9 = u10 * c10, v12 = u10 * c10, y10 = function() {
        var n13 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : g9;
        "straight-triangle" === d12 ? (o12.eleStrokeStyle(e21, t16, n13), o12.drawEdgeTrianglePath(t16, e21, s11.allpts)) : (e21.lineWidth = p10, e21.lineCap = f11, o12.eleStrokeStyle(e21, t16, n13), o12.drawEdgePath(t16, e21, s11.allpts, h10), e21.lineCap = "butt");
      }, m12 = function() {
        var n13 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : v12;
        o12.drawArrowheads(e21, t16, n13);
      };
      if (e21.lineJoin = "round", "yes" === t16.pstyle("ghost").value) {
        var b11 = t16.pstyle("ghost-offset-x").pfValue, x10 = t16.pstyle("ghost-offset-y").pfValue, w11 = t16.pstyle("ghost-opacity").value, E9 = g9 * w11;
        e21.translate(b11, x10), y10(E9), m12(E9), e21.translate(-b11, -x10);
      }
      a10 && o12.drawEdgeUnderlay(e21, t16), y10(), m12(), a10 && o12.drawEdgeOverlay(e21, t16), o12.drawElementText(e21, t16, null, r9), n12 && e21.translate(l11.x1, l11.y1);
    }
  } };
  var Us = function(e21) {
    if (!["overlay", "underlay"].includes(e21))
      throw new Error("Invalid state");
    return function(t16, n12) {
      if (n12.visible()) {
        var r9 = n12.pstyle("".concat(e21, "-opacity")).value;
        if (0 !== r9) {
          var a10 = this, i11 = a10.usePaths(), o12 = n12._private.rscratch, s11 = 2 * n12.pstyle("".concat(e21, "-padding")).pfValue, l11 = n12.pstyle("".concat(e21, "-color")).value;
          t16.lineWidth = s11, "self" !== o12.edgeType || i11 ? t16.lineCap = "round" : t16.lineCap = "butt", a10.colorStrokeStyle(t16, l11[0], l11[1], l11[2], r9), a10.drawEdgePath(n12, t16, o12.allpts, "solid");
        }
      }
    };
  };
  Gs.drawEdgeOverlay = Us("overlay"), Gs.drawEdgeUnderlay = Us("underlay"), Gs.drawEdgePath = function(e21, t16, n12, r9) {
    var a10, i11 = e21._private.rscratch, o12 = t16, s11 = false, l11 = this.usePaths(), u10 = e21.pstyle("line-dash-pattern").pfValue, c10 = e21.pstyle("line-dash-offset").pfValue;
    if (l11) {
      var d12 = n12.join("$");
      i11.pathCacheKey && i11.pathCacheKey === d12 ? (a10 = t16 = i11.pathCache, s11 = true) : (a10 = t16 = new Path2D(), i11.pathCacheKey = d12, i11.pathCache = a10);
    }
    if (o12.setLineDash)
      switch (r9) {
        case "dotted":
          o12.setLineDash([1, 1]);
          break;
        case "dashed":
          o12.setLineDash(u10), o12.lineDashOffset = c10;
          break;
        case "solid":
          o12.setLineDash([]);
      }
    if (!s11 && !i11.badLine)
      switch (t16.beginPath && t16.beginPath(), t16.moveTo(n12[0], n12[1]), i11.edgeType) {
        case "bezier":
        case "self":
        case "compound":
        case "multibezier":
          for (var h10 = 2; h10 + 3 < n12.length; h10 += 4)
            t16.quadraticCurveTo(n12[h10], n12[h10 + 1], n12[h10 + 2], n12[h10 + 3]);
          break;
        case "straight":
        case "segments":
        case "haystack":
          for (var p10 = 2; p10 + 1 < n12.length; p10 += 2)
            t16.lineTo(n12[p10], n12[p10 + 1]);
      }
    t16 = o12, l11 ? t16.stroke(a10) : t16.stroke(), t16.setLineDash && t16.setLineDash([]);
  }, Gs.drawEdgeTrianglePath = function(e21, t16, n12) {
    t16.fillStyle = t16.strokeStyle;
    for (var r9 = e21.pstyle("width").pfValue, a10 = 0; a10 + 1 < n12.length; a10 += 2) {
      var i11 = [n12[a10 + 2] - n12[a10], n12[a10 + 3] - n12[a10 + 1]], o12 = Math.sqrt(i11[0] * i11[0] + i11[1] * i11[1]), s11 = [i11[1] / o12, -i11[0] / o12], l11 = [s11[0] * r9 / 2, s11[1] * r9 / 2];
      t16.beginPath(), t16.moveTo(n12[a10] - l11[0], n12[a10 + 1] - l11[1]), t16.lineTo(n12[a10] + l11[0], n12[a10 + 1] + l11[1]), t16.lineTo(n12[a10 + 2], n12[a10 + 3]), t16.closePath(), t16.fill();
    }
  }, Gs.drawArrowheads = function(e21, t16, n12) {
    var r9 = t16._private.rscratch, a10 = "haystack" === r9.edgeType;
    a10 || this.drawArrowhead(e21, t16, "source", r9.arrowStartX, r9.arrowStartY, r9.srcArrowAngle, n12), this.drawArrowhead(e21, t16, "mid-target", r9.midX, r9.midY, r9.midtgtArrowAngle, n12), this.drawArrowhead(e21, t16, "mid-source", r9.midX, r9.midY, r9.midsrcArrowAngle, n12), a10 || this.drawArrowhead(e21, t16, "target", r9.arrowEndX, r9.arrowEndY, r9.tgtArrowAngle, n12);
  }, Gs.drawArrowhead = function(e21, t16, n12, r9, a10, i11, o12) {
    if (!(isNaN(r9) || null == r9 || isNaN(a10) || null == a10 || isNaN(i11) || null == i11)) {
      var s11 = this, l11 = t16.pstyle(n12 + "-arrow-shape").value;
      if ("none" !== l11) {
        var u10 = "hollow" === t16.pstyle(n12 + "-arrow-fill").value ? "both" : "filled", c10 = t16.pstyle(n12 + "-arrow-fill").value, d12 = t16.pstyle("width").pfValue, h10 = t16.pstyle("opacity").value;
        void 0 === o12 && (o12 = h10);
        var p10 = e21.globalCompositeOperation;
        1 === o12 && "hollow" !== c10 || (e21.globalCompositeOperation = "destination-out", s11.colorFillStyle(e21, 255, 255, 255, 1), s11.colorStrokeStyle(e21, 255, 255, 255, 1), s11.drawArrowShape(t16, e21, u10, d12, l11, r9, a10, i11), e21.globalCompositeOperation = p10);
        var f11 = t16.pstyle(n12 + "-arrow-color").value;
        s11.colorFillStyle(e21, f11[0], f11[1], f11[2], o12), s11.colorStrokeStyle(e21, f11[0], f11[1], f11[2], o12), s11.drawArrowShape(t16, e21, c10, d12, l11, r9, a10, i11);
      }
    }
  }, Gs.drawArrowShape = function(e21, t16, n12, r9, a10, i11, o12, s11) {
    var l11, u10 = this, c10 = this.usePaths() && "triangle-cross" !== a10, d12 = false, h10 = t16, p10 = { x: i11, y: o12 }, f11 = e21.pstyle("arrow-scale").value, g9 = this.getArrowWidth(r9, f11), v12 = u10.arrowShapes[a10];
    if (c10) {
      var y10 = u10.arrowPathCache = u10.arrowPathCache || [], m12 = ve(a10), b11 = y10[m12];
      null != b11 ? (l11 = t16 = b11, d12 = true) : (l11 = t16 = new Path2D(), y10[m12] = l11);
    }
    d12 || (t16.beginPath && t16.beginPath(), c10 ? v12.draw(t16, 1, 0, { x: 0, y: 0 }, 1) : v12.draw(t16, g9, s11, p10, r9), t16.closePath && t16.closePath()), t16 = h10, c10 && (t16.translate(i11, o12), t16.rotate(s11), t16.scale(g9, g9)), "filled" !== n12 && "both" !== n12 || (c10 ? t16.fill(l11) : t16.fill()), "hollow" !== n12 && "both" !== n12 || (t16.lineWidth = (v12.matchEdgeWidth ? r9 : 1) / (c10 ? g9 : 1), t16.lineJoin = "miter", c10 ? t16.stroke(l11) : t16.stroke()), c10 && (t16.scale(1 / g9, 1 / g9), t16.rotate(-s11), t16.translate(-i11, -o12));
  };
  var Zs = { safeDrawImage: function(e21, t16, n12, r9, a10, i11, o12, s11, l11, u10) {
    if (!(a10 <= 0 || i11 <= 0 || l11 <= 0 || u10 <= 0))
      try {
        e21.drawImage(t16, n12, r9, a10, i11, o12, s11, l11, u10);
      } catch (e22) {
        Me(e22);
      }
  }, drawInscribedImage: function(e21, t16, n12, r9, a10) {
    var i11 = this, o12 = n12.position(), s11 = o12.x, l11 = o12.y, u10 = n12.cy().style(), c10 = u10.getIndexedStyle.bind(u10), d12 = c10(n12, "background-fit", "value", r9), h10 = c10(n12, "background-repeat", "value", r9), p10 = n12.width(), f11 = n12.height(), g9 = 2 * n12.padding(), v12 = p10 + ("inner" === c10(n12, "background-width-relative-to", "value", r9) ? 0 : g9), y10 = f11 + ("inner" === c10(n12, "background-height-relative-to", "value", r9) ? 0 : g9), m12 = n12._private.rscratch, b11 = "node" === c10(n12, "background-clip", "value", r9), x10 = c10(n12, "background-image-opacity", "value", r9) * a10, w11 = c10(n12, "background-image-smoothing", "value", r9), E9 = t16.width || t16.cachedW, k10 = t16.height || t16.cachedH;
    null != E9 && null != k10 || (document.body.appendChild(t16), E9 = t16.cachedW = t16.width || t16.offsetWidth, k10 = t16.cachedH = t16.height || t16.offsetHeight, document.body.removeChild(t16));
    var C9 = E9, S8 = k10;
    if ("auto" !== c10(n12, "background-width", "value", r9) && (C9 = "%" === c10(n12, "background-width", "units", r9) ? c10(n12, "background-width", "pfValue", r9) * v12 : c10(n12, "background-width", "pfValue", r9)), "auto" !== c10(n12, "background-height", "value", r9) && (S8 = "%" === c10(n12, "background-height", "units", r9) ? c10(n12, "background-height", "pfValue", r9) * y10 : c10(n12, "background-height", "pfValue", r9)), 0 !== C9 && 0 !== S8) {
      if ("contain" === d12)
        C9 *= D9 = Math.min(v12 / C9, y10 / S8), S8 *= D9;
      else if ("cover" === d12) {
        var D9;
        C9 *= D9 = Math.max(v12 / C9, y10 / S8), S8 *= D9;
      }
      var P10 = s11 - v12 / 2, T9 = c10(n12, "background-position-x", "units", r9), M9 = c10(n12, "background-position-x", "pfValue", r9);
      P10 += "%" === T9 ? (v12 - C9) * M9 : M9;
      var B9 = c10(n12, "background-offset-x", "units", r9), _7 = c10(n12, "background-offset-x", "pfValue", r9);
      P10 += "%" === B9 ? (v12 - C9) * _7 : _7;
      var N8 = l11 - y10 / 2, I8 = c10(n12, "background-position-y", "units", r9), z8 = c10(n12, "background-position-y", "pfValue", r9);
      N8 += "%" === I8 ? (y10 - S8) * z8 : z8;
      var L9 = c10(n12, "background-offset-y", "units", r9), A10 = c10(n12, "background-offset-y", "pfValue", r9);
      N8 += "%" === L9 ? (y10 - S8) * A10 : A10, m12.pathCache && (P10 -= s11, N8 -= l11, s11 = 0, l11 = 0);
      var O10 = e21.globalAlpha;
      e21.globalAlpha = x10;
      var R8 = i11.getImgSmoothing(e21), V8 = false;
      if ("no" === w11 && R8 ? (i11.setImgSmoothing(e21, false), V8 = true) : "yes" !== w11 || R8 || (i11.setImgSmoothing(e21, true), V8 = true), "no-repeat" === h10)
        b11 && (e21.save(), m12.pathCache ? e21.clip(m12.pathCache) : (i11.nodeShapes[i11.getNodeShape(n12)].draw(e21, s11, l11, v12, y10), e21.clip())), i11.safeDrawImage(e21, t16, 0, 0, E9, k10, P10, N8, C9, S8), b11 && e21.restore();
      else {
        var F9 = e21.createPattern(t16, h10);
        e21.fillStyle = F9, i11.nodeShapes[i11.getNodeShape(n12)].draw(e21, s11, l11, v12, y10), e21.translate(P10, N8), e21.fill(), e21.translate(-P10, -N8);
      }
      e21.globalAlpha = O10, V8 && i11.setImgSmoothing(e21, R8);
    }
  } };
  var $s = {};
  $s.eleTextBiggerThanMin = function(e21, t16) {
    if (!t16) {
      var n12 = e21.cy().zoom(), r9 = this.getPixelRatio(), a10 = Math.ceil(lt4(n12 * r9));
      t16 = Math.pow(2, a10);
    }
    return !(e21.pstyle("font-size").pfValue * t16 < e21.pstyle("min-zoomed-font-size").pfValue);
  }, $s.drawElementText = function(e21, t16, n12, r9, a10) {
    var i11 = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5], o12 = this;
    if (null == r9) {
      if (i11 && !o12.eleTextBiggerThanMin(t16))
        return;
    } else if (false === r9)
      return;
    if (t16.isNode()) {
      var s11 = t16.pstyle("label");
      if (!s11 || !s11.value)
        return;
      var l11 = o12.getLabelJustification(t16);
      e21.textAlign = l11, e21.textBaseline = "bottom";
    } else {
      var u10 = t16.element()._private.rscratch.badLine, c10 = t16.pstyle("label"), d12 = t16.pstyle("source-label"), h10 = t16.pstyle("target-label");
      if (u10 || (!c10 || !c10.value) && (!d12 || !d12.value) && (!h10 || !h10.value))
        return;
      e21.textAlign = "center", e21.textBaseline = "bottom";
    }
    var p10, f11 = !n12;
    n12 && (p10 = n12, e21.translate(-p10.x1, -p10.y1)), null == a10 ? (o12.drawText(e21, t16, null, f11, i11), t16.isEdge() && (o12.drawText(e21, t16, "source", f11, i11), o12.drawText(e21, t16, "target", f11, i11))) : o12.drawText(e21, t16, a10, f11, i11), n12 && e21.translate(p10.x1, p10.y1);
  }, $s.getFontCache = function(e21) {
    var t16;
    this.fontCaches = this.fontCaches || [];
    for (var n12 = 0; n12 < this.fontCaches.length; n12++)
      if ((t16 = this.fontCaches[n12]).context === e21)
        return t16;
    return t16 = { context: e21 }, this.fontCaches.push(t16), t16;
  }, $s.setupTextStyle = function(e21, t16) {
    var n12 = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2], r9 = t16.pstyle("font-style").strValue, a10 = t16.pstyle("font-size").pfValue + "px", i11 = t16.pstyle("font-family").strValue, o12 = t16.pstyle("font-weight").strValue, s11 = n12 ? t16.effectiveOpacity() * t16.pstyle("text-opacity").value : 1, l11 = t16.pstyle("text-outline-opacity").value * s11, u10 = t16.pstyle("color").value, c10 = t16.pstyle("text-outline-color").value;
    e21.font = r9 + " " + o12 + " " + a10 + " " + i11, e21.lineJoin = "round", this.colorFillStyle(e21, u10[0], u10[1], u10[2], s11), this.colorStrokeStyle(e21, c10[0], c10[1], c10[2], l11);
  }, $s.getTextAngle = function(e21, t16) {
    var n12 = e21._private.rscratch, r9 = t16 ? t16 + "-" : "", a10 = e21.pstyle(r9 + "text-rotation"), i11 = Oe(n12, "labelAngle", t16);
    return "autorotate" === a10.strValue ? e21.isEdge() ? i11 : 0 : "none" === a10.strValue ? 0 : a10.pfValue;
  }, $s.drawText = function(e21, t16, n12) {
    var r9 = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3], a10 = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], i11 = t16._private.rscratch, o12 = a10 ? t16.effectiveOpacity() : 1;
    if (!a10 || 0 !== o12 && 0 !== t16.pstyle("text-opacity").value) {
      "main" === n12 && (n12 = null);
      var s11, l11, u10 = Oe(i11, "labelX", n12), c10 = Oe(i11, "labelY", n12), d12 = this.getLabelText(t16, n12);
      if (null != d12 && "" !== d12 && !isNaN(u10) && !isNaN(c10)) {
        this.setupTextStyle(e21, t16, a10);
        var h10, p10 = n12 ? n12 + "-" : "", f11 = Oe(i11, "labelWidth", n12), g9 = Oe(i11, "labelHeight", n12), v12 = t16.pstyle(p10 + "text-margin-x").pfValue, y10 = t16.pstyle(p10 + "text-margin-y").pfValue, m12 = t16.isEdge(), b11 = t16.pstyle("text-halign").value, x10 = t16.pstyle("text-valign").value;
        switch (m12 && (b11 = "center", x10 = "center"), u10 += v12, c10 += y10, 0 !== (h10 = r9 ? this.getTextAngle(t16, n12) : 0) && (s11 = u10, l11 = c10, e21.translate(s11, l11), e21.rotate(h10), u10 = 0, c10 = 0), x10) {
          case "top":
            break;
          case "center":
            c10 += g9 / 2;
            break;
          case "bottom":
            c10 += g9;
        }
        var w11 = t16.pstyle("text-background-opacity").value, E9 = t16.pstyle("text-border-opacity").value, k10 = t16.pstyle("text-border-width").pfValue, C9 = t16.pstyle("text-background-padding").pfValue;
        if (w11 > 0 || k10 > 0 && E9 > 0) {
          var S8 = u10 - C9;
          switch (b11) {
            case "left":
              S8 -= f11;
              break;
            case "center":
              S8 -= f11 / 2;
          }
          var D9 = c10 - g9 - C9, P10 = f11 + 2 * C9, T9 = g9 + 2 * C9;
          if (w11 > 0) {
            var M9 = e21.fillStyle, B9 = t16.pstyle("text-background-color").value;
            e21.fillStyle = "rgba(" + B9[0] + "," + B9[1] + "," + B9[2] + "," + w11 * o12 + ")", 0 === t16.pstyle("text-background-shape").strValue.indexOf("round") ? function(e22, t17, n13, r10, a11) {
              var i12 = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 5;
              e22.beginPath(), e22.moveTo(t17 + i12, n13), e22.lineTo(t17 + r10 - i12, n13), e22.quadraticCurveTo(t17 + r10, n13, t17 + r10, n13 + i12), e22.lineTo(t17 + r10, n13 + a11 - i12), e22.quadraticCurveTo(t17 + r10, n13 + a11, t17 + r10 - i12, n13 + a11), e22.lineTo(t17 + i12, n13 + a11), e22.quadraticCurveTo(t17, n13 + a11, t17, n13 + a11 - i12), e22.lineTo(t17, n13 + i12), e22.quadraticCurveTo(t17, n13, t17 + i12, n13), e22.closePath(), e22.fill();
            }(e21, S8, D9, P10, T9, 2) : e21.fillRect(S8, D9, P10, T9), e21.fillStyle = M9;
          }
          if (k10 > 0 && E9 > 0) {
            var _7 = e21.strokeStyle, N8 = e21.lineWidth, I8 = t16.pstyle("text-border-color").value, z8 = t16.pstyle("text-border-style").value;
            if (e21.strokeStyle = "rgba(" + I8[0] + "," + I8[1] + "," + I8[2] + "," + E9 * o12 + ")", e21.lineWidth = k10, e21.setLineDash)
              switch (z8) {
                case "dotted":
                  e21.setLineDash([1, 1]);
                  break;
                case "dashed":
                  e21.setLineDash([4, 2]);
                  break;
                case "double":
                  e21.lineWidth = k10 / 4, e21.setLineDash([]);
                  break;
                case "solid":
                  e21.setLineDash([]);
              }
            if (e21.strokeRect(S8, D9, P10, T9), "double" === z8) {
              var L9 = k10 / 2;
              e21.strokeRect(S8 + L9, D9 + L9, P10 - 2 * L9, T9 - 2 * L9);
            }
            e21.setLineDash && e21.setLineDash([]), e21.lineWidth = N8, e21.strokeStyle = _7;
          }
        }
        var A10 = 2 * t16.pstyle("text-outline-width").pfValue;
        if (A10 > 0 && (e21.lineWidth = A10), "wrap" === t16.pstyle("text-wrap").value) {
          var O10 = Oe(i11, "labelWrapCachedLines", n12), R8 = Oe(i11, "labelLineHeight", n12), V8 = f11 / 2, F9 = this.getLabelJustification(t16);
          switch ("auto" === F9 || ("left" === b11 ? "left" === F9 ? u10 += -f11 : "center" === F9 && (u10 += -V8) : "center" === b11 ? "left" === F9 ? u10 += -V8 : "right" === F9 && (u10 += V8) : "right" === b11 && ("center" === F9 ? u10 += V8 : "right" === F9 && (u10 += f11))), x10) {
            case "top":
            case "center":
            case "bottom":
              c10 -= (O10.length - 1) * R8;
          }
          for (var q8 = 0; q8 < O10.length; q8++)
            A10 > 0 && e21.strokeText(O10[q8], u10, c10), e21.fillText(O10[q8], u10, c10), c10 += R8;
        } else
          A10 > 0 && e21.strokeText(d12, u10, c10), e21.fillText(d12, u10, c10);
        0 !== h10 && (e21.rotate(-h10), e21.translate(-s11, -l11));
      }
    }
  };
  var Qs = { drawNode: function(e21, t16, n12) {
    var r9, a10, i11 = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3], o12 = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], s11 = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5], l11 = this, u10 = t16._private, c10 = u10.rscratch, d12 = t16.position();
    if (I6(d12.x) && I6(d12.y) && (!s11 || t16.visible())) {
      var h10, p10, f11 = s11 ? t16.effectiveOpacity() : 1, g9 = l11.usePaths(), v12 = false, y10 = t16.padding();
      r9 = t16.width() + 2 * y10, a10 = t16.height() + 2 * y10, n12 && (p10 = n12, e21.translate(-p10.x1, -p10.y1));
      for (var m12 = t16.pstyle("background-image").value, b11 = new Array(m12.length), x10 = new Array(m12.length), w11 = 0, E9 = 0; E9 < m12.length; E9++) {
        var k10 = m12[E9];
        if (b11[E9] = null != k10 && "none" !== k10) {
          var C9 = t16.cy().style().getIndexedStyle(t16, "background-image-crossorigin", "value", E9);
          w11++, x10[E9] = l11.getCachedImage(k10, C9, function() {
            u10.backgroundTimestamp = Date.now(), t16.emitAndNotify("background");
          });
        }
      }
      var S8 = t16.pstyle("background-blacken").value, D9 = t16.pstyle("border-width").pfValue, P10 = t16.pstyle("background-opacity").value * f11, T9 = t16.pstyle("border-color").value, M9 = t16.pstyle("border-style").value, B9 = t16.pstyle("border-opacity").value * f11;
      e21.lineJoin = "miter";
      var _7 = function() {
        var n13 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : P10;
        l11.eleFillStyle(e21, t16, n13);
      }, N8 = function() {
        var t17 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : B9;
        l11.colorStrokeStyle(e21, T9[0], T9[1], T9[2], t17);
      }, z8 = t16.pstyle("shape").strValue, L9 = t16.pstyle("shape-polygon-points").pfValue;
      if (g9) {
        e21.translate(d12.x, d12.y);
        var A10 = l11.nodePathCache = l11.nodePathCache || [], O10 = ye("polygon" === z8 ? z8 + "," + L9.join(",") : z8, "" + a10, "" + r9), R8 = A10[O10];
        null != R8 ? (h10 = R8, v12 = true, c10.pathCache = h10) : (h10 = new Path2D(), A10[O10] = c10.pathCache = h10);
      }
      var V8 = function() {
        if (!v12) {
          var n13 = d12;
          g9 && (n13 = { x: 0, y: 0 }), l11.nodeShapes[l11.getNodeShape(t16)].draw(h10 || e21, n13.x, n13.y, r9, a10);
        }
        g9 ? e21.fill(h10) : e21.fill();
      }, F9 = function() {
        for (var n13 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : f11, r10 = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], a11 = u10.backgrounding, i12 = 0, o13 = 0; o13 < x10.length; o13++) {
          var s12 = t16.cy().style().getIndexedStyle(t16, "background-image-containment", "value", o13);
          r10 && "over" === s12 || !r10 && "inside" === s12 ? i12++ : b11[o13] && x10[o13].complete && !x10[o13].error && (i12++, l11.drawInscribedImage(e21, x10[o13], t16, o13, n13));
        }
        u10.backgrounding = !(i12 === w11), a11 !== u10.backgrounding && t16.updateStyle(false);
      }, q8 = function() {
        var n13 = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], i12 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : f11;
        l11.hasPie(t16) && (l11.drawPie(e21, t16, i12), n13 && (g9 || l11.nodeShapes[l11.getNodeShape(t16)].draw(e21, d12.x, d12.y, r9, a10)));
      }, j9 = function() {
        var t17 = (S8 > 0 ? S8 : -S8) * (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : f11), n13 = S8 > 0 ? 0 : 255;
        0 !== S8 && (l11.colorFillStyle(e21, n13, n13, n13, t17), g9 ? e21.fill(h10) : e21.fill());
      }, Y6 = function() {
        if (D9 > 0) {
          if (e21.lineWidth = D9, e21.lineCap = "butt", e21.setLineDash)
            switch (M9) {
              case "dotted":
                e21.setLineDash([1, 1]);
                break;
              case "dashed":
                e21.setLineDash([4, 2]);
                break;
              case "solid":
              case "double":
                e21.setLineDash([]);
            }
          if (g9 ? e21.stroke(h10) : e21.stroke(), "double" === M9) {
            e21.lineWidth = D9 / 3;
            var t17 = e21.globalCompositeOperation;
            e21.globalCompositeOperation = "destination-out", g9 ? e21.stroke(h10) : e21.stroke(), e21.globalCompositeOperation = t17;
          }
          e21.setLineDash && e21.setLineDash([]);
        }
      };
      if ("yes" === t16.pstyle("ghost").value) {
        var X6 = t16.pstyle("ghost-offset-x").pfValue, W8 = t16.pstyle("ghost-offset-y").pfValue, H8 = t16.pstyle("ghost-opacity").value, K6 = H8 * f11;
        e21.translate(X6, W8), _7(H8 * P10), V8(), F9(K6, true), N8(H8 * B9), Y6(), q8(0 !== S8 || 0 !== D9), F9(K6, false), j9(K6), e21.translate(-X6, -W8);
      }
      g9 && e21.translate(-d12.x, -d12.y), o12 && l11.drawNodeUnderlay(e21, t16, d12, r9, a10), g9 && e21.translate(d12.x, d12.y), _7(), V8(), F9(f11, true), N8(), Y6(), q8(0 !== S8 || 0 !== D9), F9(f11, false), j9(), g9 && e21.translate(-d12.x, -d12.y), l11.drawElementText(e21, t16, null, i11), o12 && l11.drawNodeOverlay(e21, t16, d12, r9, a10), n12 && e21.translate(p10.x1, p10.y1);
    }
  } };
  var Js = function(e21) {
    if (!["overlay", "underlay"].includes(e21))
      throw new Error("Invalid state");
    return function(t16, n12, r9, a10, i11) {
      if (n12.visible()) {
        var o12 = n12.pstyle("".concat(e21, "-padding")).pfValue, s11 = n12.pstyle("".concat(e21, "-opacity")).value, l11 = n12.pstyle("".concat(e21, "-color")).value, u10 = n12.pstyle("".concat(e21, "-shape")).value;
        if (s11 > 0) {
          if (r9 = r9 || n12.position(), null == a10 || null == i11) {
            var c10 = n12.padding();
            a10 = n12.width() + 2 * c10, i11 = n12.height() + 2 * c10;
          }
          this.colorFillStyle(t16, l11[0], l11[1], l11[2], s11), this.nodeShapes[u10].draw(t16, r9.x, r9.y, a10 + 2 * o12, i11 + 2 * o12), t16.fill();
        }
      }
    };
  };
  Qs.drawNodeOverlay = Js("overlay"), Qs.drawNodeUnderlay = Js("underlay"), Qs.hasPie = function(e21) {
    return (e21 = e21[0])._private.hasPie;
  }, Qs.drawPie = function(e21, t16, n12, r9) {
    t16 = t16[0], r9 = r9 || t16.position();
    var a10 = t16.cy().style(), i11 = t16.pstyle("pie-size"), o12 = r9.x, s11 = r9.y, l11 = t16.width(), u10 = t16.height(), c10 = Math.min(l11, u10) / 2, d12 = 0;
    this.usePaths() && (o12 = 0, s11 = 0), "%" === i11.units ? c10 *= i11.pfValue : void 0 !== i11.pfValue && (c10 = i11.pfValue / 2);
    for (var h10 = 1; h10 <= a10.pieBackgroundN; h10++) {
      var p10 = t16.pstyle("pie-" + h10 + "-background-size").value, f11 = t16.pstyle("pie-" + h10 + "-background-color").value, g9 = t16.pstyle("pie-" + h10 + "-background-opacity").value * n12, v12 = p10 / 100;
      v12 + d12 > 1 && (v12 = 1 - d12);
      var y10 = 1.5 * Math.PI + 2 * Math.PI * d12, m12 = y10 + 2 * Math.PI * v12;
      0 === p10 || d12 >= 1 || d12 + v12 > 1 || (e21.beginPath(), e21.moveTo(o12, s11), e21.arc(o12, s11, c10, y10, m12), e21.closePath(), this.colorFillStyle(e21, f11[0], f11[1], f11[2], g9), e21.fill(), d12 += v12);
    }
  };
  var el = {};
  el.getPixelRatio = function() {
    var e21 = this.data.contexts[0];
    if (null != this.forcedPixelRatio)
      return this.forcedPixelRatio;
    var t16 = e21.backingStorePixelRatio || e21.webkitBackingStorePixelRatio || e21.mozBackingStorePixelRatio || e21.msBackingStorePixelRatio || e21.oBackingStorePixelRatio || e21.backingStorePixelRatio || 1;
    return (window.devicePixelRatio || 1) / t16;
  }, el.paintCache = function(e21) {
    for (var t16, n12 = this.paintCaches = this.paintCaches || [], r9 = true, a10 = 0; a10 < n12.length; a10++)
      if ((t16 = n12[a10]).context === e21) {
        r9 = false;
        break;
      }
    return r9 && (t16 = { context: e21 }, n12.push(t16)), t16;
  }, el.createGradientStyleFor = function(e21, t16, n12, r9, a10) {
    var i11, o12 = this.usePaths(), s11 = n12.pstyle(t16 + "-gradient-stop-colors").value, l11 = n12.pstyle(t16 + "-gradient-stop-positions").pfValue;
    if ("radial-gradient" === r9)
      if (n12.isEdge()) {
        var u10 = n12.sourceEndpoint(), c10 = n12.targetEndpoint(), d12 = n12.midpoint(), h10 = ct4(u10, d12), p10 = ct4(c10, d12);
        i11 = e21.createRadialGradient(d12.x, d12.y, 0, d12.x, d12.y, Math.max(h10, p10));
      } else {
        var f11 = o12 ? { x: 0, y: 0 } : n12.position(), g9 = n12.paddedWidth(), v12 = n12.paddedHeight();
        i11 = e21.createRadialGradient(f11.x, f11.y, 0, f11.x, f11.y, Math.max(g9, v12));
      }
    else if (n12.isEdge()) {
      var y10 = n12.sourceEndpoint(), m12 = n12.targetEndpoint();
      i11 = e21.createLinearGradient(y10.x, y10.y, m12.x, m12.y);
    } else {
      var b11 = o12 ? { x: 0, y: 0 } : n12.position(), x10 = n12.paddedWidth() / 2, w11 = n12.paddedHeight() / 2;
      switch (n12.pstyle("background-gradient-direction").value) {
        case "to-bottom":
          i11 = e21.createLinearGradient(b11.x, b11.y - w11, b11.x, b11.y + w11);
          break;
        case "to-top":
          i11 = e21.createLinearGradient(b11.x, b11.y + w11, b11.x, b11.y - w11);
          break;
        case "to-left":
          i11 = e21.createLinearGradient(b11.x + x10, b11.y, b11.x - x10, b11.y);
          break;
        case "to-right":
          i11 = e21.createLinearGradient(b11.x - x10, b11.y, b11.x + x10, b11.y);
          break;
        case "to-bottom-right":
        case "to-right-bottom":
          i11 = e21.createLinearGradient(b11.x - x10, b11.y - w11, b11.x + x10, b11.y + w11);
          break;
        case "to-top-right":
        case "to-right-top":
          i11 = e21.createLinearGradient(b11.x - x10, b11.y + w11, b11.x + x10, b11.y - w11);
          break;
        case "to-bottom-left":
        case "to-left-bottom":
          i11 = e21.createLinearGradient(b11.x + x10, b11.y - w11, b11.x - x10, b11.y + w11);
          break;
        case "to-top-left":
        case "to-left-top":
          i11 = e21.createLinearGradient(b11.x + x10, b11.y + w11, b11.x - x10, b11.y - w11);
      }
    }
    if (!i11)
      return null;
    for (var E9 = l11.length === s11.length, k10 = s11.length, C9 = 0; C9 < k10; C9++)
      i11.addColorStop(E9 ? l11[C9] : C9 / (k10 - 1), "rgba(" + s11[C9][0] + "," + s11[C9][1] + "," + s11[C9][2] + "," + a10 + ")");
    return i11;
  }, el.gradientFillStyle = function(e21, t16, n12, r9) {
    var a10 = this.createGradientStyleFor(e21, "background", t16, n12, r9);
    if (!a10)
      return null;
    e21.fillStyle = a10;
  }, el.colorFillStyle = function(e21, t16, n12, r9, a10) {
    e21.fillStyle = "rgba(" + t16 + "," + n12 + "," + r9 + "," + a10 + ")";
  }, el.eleFillStyle = function(e21, t16, n12) {
    var r9 = t16.pstyle("background-fill").value;
    if ("linear-gradient" === r9 || "radial-gradient" === r9)
      this.gradientFillStyle(e21, t16, r9, n12);
    else {
      var a10 = t16.pstyle("background-color").value;
      this.colorFillStyle(e21, a10[0], a10[1], a10[2], n12);
    }
  }, el.gradientStrokeStyle = function(e21, t16, n12, r9) {
    var a10 = this.createGradientStyleFor(e21, "line", t16, n12, r9);
    if (!a10)
      return null;
    e21.strokeStyle = a10;
  }, el.colorStrokeStyle = function(e21, t16, n12, r9, a10) {
    e21.strokeStyle = "rgba(" + t16 + "," + n12 + "," + r9 + "," + a10 + ")";
  }, el.eleStrokeStyle = function(e21, t16, n12) {
    var r9 = t16.pstyle("line-fill").value;
    if ("linear-gradient" === r9 || "radial-gradient" === r9)
      this.gradientStrokeStyle(e21, t16, r9, n12);
    else {
      var a10 = t16.pstyle("line-color").value;
      this.colorStrokeStyle(e21, a10[0], a10[1], a10[2], n12);
    }
  }, el.matchCanvasSize = function(e21) {
    var t16 = this, n12 = t16.data, r9 = t16.findContainerClientCoords(), a10 = r9[2], i11 = r9[3], o12 = t16.getPixelRatio(), s11 = t16.motionBlurPxRatio;
    e21 !== t16.data.bufferCanvases[t16.MOTIONBLUR_BUFFER_NODE] && e21 !== t16.data.bufferCanvases[t16.MOTIONBLUR_BUFFER_DRAG] || (o12 = s11);
    var l11, u10 = a10 * o12, c10 = i11 * o12;
    if (u10 !== t16.canvasWidth || c10 !== t16.canvasHeight) {
      t16.fontCaches = null;
      var d12 = n12.canvasContainer;
      d12.style.width = a10 + "px", d12.style.height = i11 + "px";
      for (var h10 = 0; h10 < t16.CANVAS_LAYERS; h10++)
        (l11 = n12.canvases[h10]).width = u10, l11.height = c10, l11.style.width = a10 + "px", l11.style.height = i11 + "px";
      for (h10 = 0; h10 < t16.BUFFER_COUNT; h10++)
        (l11 = n12.bufferCanvases[h10]).width = u10, l11.height = c10, l11.style.width = a10 + "px", l11.style.height = i11 + "px";
      t16.textureMult = 1, o12 <= 1 && (l11 = n12.bufferCanvases[t16.TEXTURE_BUFFER], t16.textureMult = 2, l11.width = u10 * t16.textureMult, l11.height = c10 * t16.textureMult), t16.canvasWidth = u10, t16.canvasHeight = c10;
    }
  }, el.renderTo = function(e21, t16, n12, r9) {
    this.render({ forcedContext: e21, forcedZoom: t16, forcedPan: n12, drawAllLayers: true, forcedPxRatio: r9 });
  }, el.render = function(e21) {
    var t16 = (e21 = e21 || Ie()).forcedContext, n12 = e21.drawAllLayers, r9 = e21.drawOnlyNodeLayer, a10 = e21.forcedZoom, i11 = e21.forcedPan, o12 = this, s11 = void 0 === e21.forcedPxRatio ? this.getPixelRatio() : e21.forcedPxRatio, l11 = o12.cy, u10 = o12.data, c10 = u10.canvasNeedsRedraw, d12 = o12.textureOnViewport && !t16 && (o12.pinching || o12.hoverData.dragging || o12.swipePanning || o12.data.wheelZooming), h10 = void 0 !== e21.motionBlur ? e21.motionBlur : o12.motionBlur, p10 = o12.motionBlurPxRatio, f11 = l11.hasCompoundNodes(), g9 = o12.hoverData.draggingEles, v12 = !(!o12.hoverData.selecting && !o12.touchData.selecting), y10 = h10 = h10 && !t16 && o12.motionBlurEnabled && !v12;
    t16 || (o12.prevPxRatio !== s11 && (o12.invalidateContainerClientCoordsCache(), o12.matchCanvasSize(o12.container), o12.redrawHint("eles", true), o12.redrawHint("drag", true)), o12.prevPxRatio = s11), !t16 && o12.motionBlurTimeout && clearTimeout(o12.motionBlurTimeout), h10 && (null == o12.mbFrames && (o12.mbFrames = 0), o12.mbFrames++, o12.mbFrames < 3 && (y10 = false), o12.mbFrames > o12.minMbLowQualFrames && (o12.motionBlurPxRatio = o12.mbPxRBlurry)), o12.clearingMotionBlur && (o12.motionBlurPxRatio = 1), o12.textureDrawLastFrame && !d12 && (c10[o12.NODE] = true, c10[o12.SELECT_BOX] = true);
    var m12 = l11.style(), b11 = l11.zoom(), x10 = void 0 !== a10 ? a10 : b11, w11 = l11.pan(), E9 = { x: w11.x, y: w11.y }, k10 = { zoom: b11, pan: { x: w11.x, y: w11.y } }, C9 = o12.prevViewport;
    void 0 === C9 || k10.zoom !== C9.zoom || k10.pan.x !== C9.pan.x || k10.pan.y !== C9.pan.y || g9 && !f11 || (o12.motionBlurPxRatio = 1), i11 && (E9 = i11), x10 *= s11, E9.x *= s11, E9.y *= s11;
    var S8 = o12.getCachedZSortedEles();
    function D9(e22, t17, n13, r10, a11) {
      var i12 = e22.globalCompositeOperation;
      e22.globalCompositeOperation = "destination-out", o12.colorFillStyle(e22, 255, 255, 255, o12.motionBlurTransparency), e22.fillRect(t17, n13, r10, a11), e22.globalCompositeOperation = i12;
    }
    function P10(e22, r10) {
      var s12, l12, c11, d13;
      o12.clearingMotionBlur || e22 !== u10.bufferContexts[o12.MOTIONBLUR_BUFFER_NODE] && e22 !== u10.bufferContexts[o12.MOTIONBLUR_BUFFER_DRAG] ? (s12 = E9, l12 = x10, c11 = o12.canvasWidth, d13 = o12.canvasHeight) : (s12 = { x: w11.x * p10, y: w11.y * p10 }, l12 = b11 * p10, c11 = o12.canvasWidth * p10, d13 = o12.canvasHeight * p10), e22.setTransform(1, 0, 0, 1, 0, 0), "motionBlur" === r10 ? D9(e22, 0, 0, c11, d13) : t16 || void 0 !== r10 && !r10 || e22.clearRect(0, 0, c11, d13), n12 || (e22.translate(s12.x, s12.y), e22.scale(l12, l12)), i11 && e22.translate(i11.x, i11.y), a10 && e22.scale(a10, a10);
    }
    if (d12 || (o12.textureDrawLastFrame = false), d12) {
      if (o12.textureDrawLastFrame = true, !o12.textureCache) {
        o12.textureCache = {}, o12.textureCache.bb = l11.mutableElements().boundingBox(), o12.textureCache.texture = o12.data.bufferCanvases[o12.TEXTURE_BUFFER];
        var T9 = o12.data.bufferContexts[o12.TEXTURE_BUFFER];
        T9.setTransform(1, 0, 0, 1, 0, 0), T9.clearRect(0, 0, o12.canvasWidth * o12.textureMult, o12.canvasHeight * o12.textureMult), o12.render({ forcedContext: T9, drawOnlyNodeLayer: true, forcedPxRatio: s11 * o12.textureMult }), (k10 = o12.textureCache.viewport = { zoom: l11.zoom(), pan: l11.pan(), width: o12.canvasWidth, height: o12.canvasHeight }).mpan = { x: (0 - k10.pan.x) / k10.zoom, y: (0 - k10.pan.y) / k10.zoom };
      }
      c10[o12.DRAG] = false, c10[o12.NODE] = false;
      var M9 = u10.contexts[o12.NODE], B9 = o12.textureCache.texture;
      k10 = o12.textureCache.viewport;
      M9.setTransform(1, 0, 0, 1, 0, 0), h10 ? D9(M9, 0, 0, k10.width, k10.height) : M9.clearRect(0, 0, k10.width, k10.height);
      var _7 = m12.core("outside-texture-bg-color").value, N8 = m12.core("outside-texture-bg-opacity").value;
      o12.colorFillStyle(M9, _7[0], _7[1], _7[2], N8), M9.fillRect(0, 0, k10.width, k10.height);
      b11 = l11.zoom();
      P10(M9, false), M9.clearRect(k10.mpan.x, k10.mpan.y, k10.width / k10.zoom / s11, k10.height / k10.zoom / s11), M9.drawImage(B9, k10.mpan.x, k10.mpan.y, k10.width / k10.zoom / s11, k10.height / k10.zoom / s11);
    } else
      o12.textureOnViewport && !t16 && (o12.textureCache = null);
    var I8 = l11.extent(), z8 = o12.pinching || o12.hoverData.dragging || o12.swipePanning || o12.data.wheelZooming || o12.hoverData.draggingEles || o12.cy.animated(), L9 = o12.hideEdgesOnViewport && z8, A10 = [];
    if (A10[o12.NODE] = !c10[o12.NODE] && h10 && !o12.clearedForMotionBlur[o12.NODE] || o12.clearingMotionBlur, A10[o12.NODE] && (o12.clearedForMotionBlur[o12.NODE] = true), A10[o12.DRAG] = !c10[o12.DRAG] && h10 && !o12.clearedForMotionBlur[o12.DRAG] || o12.clearingMotionBlur, A10[o12.DRAG] && (o12.clearedForMotionBlur[o12.DRAG] = true), c10[o12.NODE] || n12 || r9 || A10[o12.NODE]) {
      var O10 = h10 && !A10[o12.NODE] && 1 !== p10;
      P10(M9 = t16 || (O10 ? o12.data.bufferContexts[o12.MOTIONBLUR_BUFFER_NODE] : u10.contexts[o12.NODE]), h10 && !O10 ? "motionBlur" : void 0), L9 ? o12.drawCachedNodes(M9, S8.nondrag, s11, I8) : o12.drawLayeredElements(M9, S8.nondrag, s11, I8), o12.debug && o12.drawDebugPoints(M9, S8.nondrag), n12 || h10 || (c10[o12.NODE] = false);
    }
    if (!r9 && (c10[o12.DRAG] || n12 || A10[o12.DRAG])) {
      O10 = h10 && !A10[o12.DRAG] && 1 !== p10;
      P10(M9 = t16 || (O10 ? o12.data.bufferContexts[o12.MOTIONBLUR_BUFFER_DRAG] : u10.contexts[o12.DRAG]), h10 && !O10 ? "motionBlur" : void 0), L9 ? o12.drawCachedNodes(M9, S8.drag, s11, I8) : o12.drawCachedElements(M9, S8.drag, s11, I8), o12.debug && o12.drawDebugPoints(M9, S8.drag), n12 || h10 || (c10[o12.DRAG] = false);
    }
    if (o12.showFps || !r9 && c10[o12.SELECT_BOX] && !n12) {
      if (P10(M9 = t16 || u10.contexts[o12.SELECT_BOX]), 1 == o12.selection[4] && (o12.hoverData.selecting || o12.touchData.selecting)) {
        b11 = o12.cy.zoom();
        var R8 = m12.core("selection-box-border-width").value / b11;
        M9.lineWidth = R8, M9.fillStyle = "rgba(" + m12.core("selection-box-color").value[0] + "," + m12.core("selection-box-color").value[1] + "," + m12.core("selection-box-color").value[2] + "," + m12.core("selection-box-opacity").value + ")", M9.fillRect(o12.selection[0], o12.selection[1], o12.selection[2] - o12.selection[0], o12.selection[3] - o12.selection[1]), R8 > 0 && (M9.strokeStyle = "rgba(" + m12.core("selection-box-border-color").value[0] + "," + m12.core("selection-box-border-color").value[1] + "," + m12.core("selection-box-border-color").value[2] + "," + m12.core("selection-box-opacity").value + ")", M9.strokeRect(o12.selection[0], o12.selection[1], o12.selection[2] - o12.selection[0], o12.selection[3] - o12.selection[1]));
      }
      if (u10.bgActivePosistion && !o12.hoverData.selecting) {
        b11 = o12.cy.zoom();
        var V8 = u10.bgActivePosistion;
        M9.fillStyle = "rgba(" + m12.core("active-bg-color").value[0] + "," + m12.core("active-bg-color").value[1] + "," + m12.core("active-bg-color").value[2] + "," + m12.core("active-bg-opacity").value + ")", M9.beginPath(), M9.arc(V8.x, V8.y, m12.core("active-bg-size").pfValue / b11, 0, 2 * Math.PI), M9.fill();
      }
      var F9 = o12.lastRedrawTime;
      if (o12.showFps && F9) {
        F9 = Math.round(F9);
        var q8 = Math.round(1e3 / F9);
        M9.setTransform(1, 0, 0, 1, 0, 0), M9.fillStyle = "rgba(255, 0, 0, 0.75)", M9.strokeStyle = "rgba(255, 0, 0, 0.75)", M9.lineWidth = 1, M9.fillText("1 frame = " + F9 + " ms = " + q8 + " fps", 0, 20);
        M9.strokeRect(0, 30, 250, 20), M9.fillRect(0, 30, 250 * Math.min(q8 / 60, 1), 20);
      }
      n12 || (c10[o12.SELECT_BOX] = false);
    }
    if (h10 && 1 !== p10) {
      var j9 = u10.contexts[o12.NODE], Y6 = o12.data.bufferCanvases[o12.MOTIONBLUR_BUFFER_NODE], X6 = u10.contexts[o12.DRAG], W8 = o12.data.bufferCanvases[o12.MOTIONBLUR_BUFFER_DRAG], H8 = function(e22, t17, n13) {
        e22.setTransform(1, 0, 0, 1, 0, 0), n13 || !y10 ? e22.clearRect(0, 0, o12.canvasWidth, o12.canvasHeight) : D9(e22, 0, 0, o12.canvasWidth, o12.canvasHeight);
        var r10 = p10;
        e22.drawImage(t17, 0, 0, o12.canvasWidth * r10, o12.canvasHeight * r10, 0, 0, o12.canvasWidth, o12.canvasHeight);
      };
      (c10[o12.NODE] || A10[o12.NODE]) && (H8(j9, Y6, A10[o12.NODE]), c10[o12.NODE] = false), (c10[o12.DRAG] || A10[o12.DRAG]) && (H8(X6, W8, A10[o12.DRAG]), c10[o12.DRAG] = false);
    }
    o12.prevViewport = k10, o12.clearingMotionBlur && (o12.clearingMotionBlur = false, o12.motionBlurCleared = true, o12.motionBlur = true), h10 && (o12.motionBlurTimeout = setTimeout(function() {
      o12.motionBlurTimeout = null, o12.clearedForMotionBlur[o12.NODE] = false, o12.clearedForMotionBlur[o12.DRAG] = false, o12.motionBlur = false, o12.clearingMotionBlur = !d12, o12.mbFrames = 0, c10[o12.NODE] = true, c10[o12.DRAG] = true, o12.redraw();
    }, 100)), t16 || l11.emit("render");
  };
  for (tl = { drawPolygonPath: function(e21, t16, n12, r9, a10, i11) {
    var o12 = r9 / 2, s11 = a10 / 2;
    e21.beginPath && e21.beginPath(), e21.moveTo(t16 + o12 * i11[0], n12 + s11 * i11[1]);
    for (var l11 = 1; l11 < i11.length / 2; l11++)
      e21.lineTo(t16 + o12 * i11[2 * l11], n12 + s11 * i11[2 * l11 + 1]);
    e21.closePath();
  }, drawRoundPolygonPath: function(e21, t16, n12, r9, a10, i11) {
    var o12 = r9 / 2, s11 = a10 / 2, l11 = Yt4(r9, a10);
    e21.beginPath && e21.beginPath();
    for (var u10 = 0; u10 < i11.length / 4; u10++) {
      var c10, d12 = void 0;
      d12 = 0 === u10 ? i11.length - 2 : 4 * u10 - 2, c10 = 4 * u10 + 2;
      var h10 = t16 + o12 * i11[4 * u10], p10 = n12 + s11 * i11[4 * u10 + 1], f11 = -i11[d12] * i11[c10] - i11[d12 + 1] * i11[c10 + 1], g9 = l11 / Math.tan(Math.acos(f11) / 2), v12 = h10 - g9 * i11[d12], y10 = p10 - g9 * i11[d12 + 1], m12 = h10 + g9 * i11[c10], b11 = p10 + g9 * i11[c10 + 1];
      0 === u10 ? e21.moveTo(v12, y10) : e21.lineTo(v12, y10), e21.arcTo(h10, p10, m12, b11, l11);
    }
    e21.closePath();
  }, drawRoundRectanglePath: function(e21, t16, n12, r9, a10) {
    var i11 = r9 / 2, o12 = a10 / 2, s11 = jt4(r9, a10);
    e21.beginPath && e21.beginPath(), e21.moveTo(t16, n12 - o12), e21.arcTo(t16 + i11, n12 - o12, t16 + i11, n12, s11), e21.arcTo(t16 + i11, n12 + o12, t16, n12 + o12, s11), e21.arcTo(t16 - i11, n12 + o12, t16 - i11, n12, s11), e21.arcTo(t16 - i11, n12 - o12, t16, n12 - o12, s11), e21.lineTo(t16, n12 - o12), e21.closePath();
  }, drawBottomRoundRectanglePath: function(e21, t16, n12, r9, a10) {
    var i11 = r9 / 2, o12 = a10 / 2, s11 = jt4(r9, a10);
    e21.beginPath && e21.beginPath(), e21.moveTo(t16, n12 - o12), e21.lineTo(t16 + i11, n12 - o12), e21.lineTo(t16 + i11, n12), e21.arcTo(t16 + i11, n12 + o12, t16, n12 + o12, s11), e21.arcTo(t16 - i11, n12 + o12, t16 - i11, n12, s11), e21.lineTo(t16 - i11, n12 - o12), e21.lineTo(t16, n12 - o12), e21.closePath();
  }, drawCutRectanglePath: function(e21, t16, n12, r9, a10) {
    var i11 = r9 / 2, o12 = a10 / 2;
    e21.beginPath && e21.beginPath(), e21.moveTo(t16 - i11 + 8, n12 - o12), e21.lineTo(t16 + i11 - 8, n12 - o12), e21.lineTo(t16 + i11, n12 - o12 + 8), e21.lineTo(t16 + i11, n12 + o12 - 8), e21.lineTo(t16 + i11 - 8, n12 + o12), e21.lineTo(t16 - i11 + 8, n12 + o12), e21.lineTo(t16 - i11, n12 + o12 - 8), e21.lineTo(t16 - i11, n12 - o12 + 8), e21.closePath();
  }, drawBarrelPath: function(e21, t16, n12, r9, a10) {
    var i11 = r9 / 2, o12 = a10 / 2, s11 = t16 - i11, l11 = t16 + i11, u10 = n12 - o12, c10 = n12 + o12, d12 = Xt4(r9, a10), h10 = d12.widthOffset, p10 = d12.heightOffset, f11 = d12.ctrlPtOffsetPct * h10;
    e21.beginPath && e21.beginPath(), e21.moveTo(s11, u10 + p10), e21.lineTo(s11, c10 - p10), e21.quadraticCurveTo(s11 + f11, c10, s11 + h10, c10), e21.lineTo(l11 - h10, c10), e21.quadraticCurveTo(l11 - f11, c10, l11, c10 - p10), e21.lineTo(l11, u10 + p10), e21.quadraticCurveTo(l11 - f11, u10, l11 - h10, u10), e21.lineTo(s11 + h10, u10), e21.quadraticCurveTo(s11 + f11, u10, s11, u10 + p10), e21.closePath();
  } }, nl = Math.sin(0), rl = Math.cos(0), al = {}, il = {}, ol = Math.PI / 40, sl = 0 * Math.PI; sl < 2 * Math.PI; sl += ol)
    al[sl] = Math.sin(sl), il[sl] = Math.cos(sl);
  var tl;
  var nl;
  var rl;
  var al;
  var il;
  var ol;
  var sl;
  tl.drawEllipsePath = function(e21, t16, n12, r9, a10) {
    if (e21.beginPath && e21.beginPath(), e21.ellipse)
      e21.ellipse(t16, n12, r9 / 2, a10 / 2, 0, 0, 2 * Math.PI);
    else
      for (var i11, o12, s11 = r9 / 2, l11 = a10 / 2, u10 = 0 * Math.PI; u10 < 2 * Math.PI; u10 += ol)
        i11 = t16 - s11 * al[u10] * nl + s11 * il[u10] * rl, o12 = n12 + l11 * il[u10] * nl + l11 * al[u10] * rl, 0 === u10 ? e21.moveTo(i11, o12) : e21.lineTo(i11, o12);
    e21.closePath();
  };
  var ll = {};
  function ul(e21) {
    var t16 = e21.indexOf(",");
    return e21.substr(t16 + 1);
  }
  function cl(e21, t16, n12) {
    var r9 = function() {
      return t16.toDataURL(n12, e21.quality);
    };
    switch (e21.output) {
      case "blob-promise":
        return new rr4(function(r10, a10) {
          try {
            t16.toBlob(function(e22) {
              null != e22 ? r10(e22) : a10(new Error("`canvas.toBlob()` sent a null value in its callback"));
            }, n12, e21.quality);
          } catch (e22) {
            a10(e22);
          }
        });
      case "blob":
        return function(e22, t17) {
          for (var n13 = atob(e22), r10 = new ArrayBuffer(n13.length), a10 = new Uint8Array(r10), i11 = 0; i11 < n13.length; i11++)
            a10[i11] = n13.charCodeAt(i11);
          return new Blob([r10], { type: t17 });
        }(ul(r9()), n12);
      case "base64":
        return ul(r9());
      default:
        return r9();
    }
  }
  ll.createBuffer = function(e21, t16) {
    var n12 = document.createElement("canvas");
    return n12.width = e21, n12.height = t16, [n12, n12.getContext("2d")];
  }, ll.bufferCanvasImage = function(e21) {
    var t16 = this.cy, n12 = t16.mutableElements().boundingBox(), r9 = this.findContainerClientCoords(), a10 = e21.full ? Math.ceil(n12.w) : r9[2], i11 = e21.full ? Math.ceil(n12.h) : r9[3], o12 = I6(e21.maxWidth) || I6(e21.maxHeight), s11 = this.getPixelRatio(), l11 = 1;
    if (void 0 !== e21.scale)
      a10 *= e21.scale, i11 *= e21.scale, l11 = e21.scale;
    else if (o12) {
      var u10 = 1 / 0, c10 = 1 / 0;
      I6(e21.maxWidth) && (u10 = l11 * e21.maxWidth / a10), I6(e21.maxHeight) && (c10 = l11 * e21.maxHeight / i11), a10 *= l11 = Math.min(u10, c10), i11 *= l11;
    }
    o12 || (a10 *= s11, i11 *= s11, l11 *= s11);
    var d12 = document.createElement("canvas");
    d12.width = a10, d12.height = i11, d12.style.width = a10 + "px", d12.style.height = i11 + "px";
    var h10 = d12.getContext("2d");
    if (a10 > 0 && i11 > 0) {
      h10.clearRect(0, 0, a10, i11), h10.globalCompositeOperation = "source-over";
      var p10 = this.getCachedZSortedEles();
      if (e21.full)
        h10.translate(-n12.x1 * l11, -n12.y1 * l11), h10.scale(l11, l11), this.drawElements(h10, p10), h10.scale(1 / l11, 1 / l11), h10.translate(n12.x1 * l11, n12.y1 * l11);
      else {
        var f11 = t16.pan(), g9 = { x: f11.x * l11, y: f11.y * l11 };
        l11 *= t16.zoom(), h10.translate(g9.x, g9.y), h10.scale(l11, l11), this.drawElements(h10, p10), h10.scale(1 / l11, 1 / l11), h10.translate(-g9.x, -g9.y);
      }
      e21.bg && (h10.globalCompositeOperation = "destination-over", h10.fillStyle = e21.bg, h10.rect(0, 0, a10, i11), h10.fill());
    }
    return d12;
  }, ll.png = function(e21) {
    return cl(e21, this.bufferCanvasImage(e21), "image/png");
  }, ll.jpg = function(e21) {
    return cl(e21, this.bufferCanvasImage(e21), "image/jpeg");
  };
  var dl = { nodeShapeImpl: function(e21, t16, n12, r9, a10, i11, o12) {
    switch (e21) {
      case "ellipse":
        return this.drawEllipsePath(t16, n12, r9, a10, i11);
      case "polygon":
        return this.drawPolygonPath(t16, n12, r9, a10, i11, o12);
      case "round-polygon":
        return this.drawRoundPolygonPath(t16, n12, r9, a10, i11, o12);
      case "roundrectangle":
      case "round-rectangle":
        return this.drawRoundRectanglePath(t16, n12, r9, a10, i11);
      case "cutrectangle":
      case "cut-rectangle":
        return this.drawCutRectanglePath(t16, n12, r9, a10, i11);
      case "bottomroundrectangle":
      case "bottom-round-rectangle":
        return this.drawBottomRoundRectanglePath(t16, n12, r9, a10, i11);
      case "barrel":
        return this.drawBarrelPath(t16, n12, r9, a10, i11);
    }
  } };
  var hl = fl;
  var pl = fl.prototype;
  function fl(e21) {
    var t16 = this;
    t16.data = { canvases: new Array(pl.CANVAS_LAYERS), contexts: new Array(pl.CANVAS_LAYERS), canvasNeedsRedraw: new Array(pl.CANVAS_LAYERS), bufferCanvases: new Array(pl.BUFFER_COUNT), bufferContexts: new Array(pl.CANVAS_LAYERS) };
    var n12 = "-webkit-tap-highlight-color", r9 = "rgba(0,0,0,0)";
    t16.data.canvasContainer = document.createElement("div");
    var a10 = t16.data.canvasContainer.style;
    t16.data.canvasContainer.style[n12] = r9, a10.position = "relative", a10.zIndex = "0", a10.overflow = "hidden";
    var i11 = e21.cy.container();
    i11.appendChild(t16.data.canvasContainer), i11.style[n12] = r9;
    var o12 = { "-webkit-user-select": "none", "-moz-user-select": "-moz-none", "user-select": "none", "-webkit-tap-highlight-color": "rgba(0,0,0,0)", "outline-style": "none" };
    k5 && k5.userAgent.match(/msie|trident|edge/i) && (o12["-ms-touch-action"] = "none", o12["touch-action"] = "none");
    for (var s11 = 0; s11 < pl.CANVAS_LAYERS; s11++) {
      var l11 = t16.data.canvases[s11] = document.createElement("canvas");
      t16.data.contexts[s11] = l11.getContext("2d"), Object.keys(o12).forEach(function(e22) {
        l11.style[e22] = o12[e22];
      }), l11.style.position = "absolute", l11.setAttribute("data-id", "layer" + s11), l11.style.zIndex = String(pl.CANVAS_LAYERS - s11), t16.data.canvasContainer.appendChild(l11), t16.data.canvasNeedsRedraw[s11] = false;
    }
    t16.data.topCanvas = t16.data.canvases[0], t16.data.canvases[pl.NODE].setAttribute("data-id", "layer" + pl.NODE + "-node"), t16.data.canvases[pl.SELECT_BOX].setAttribute("data-id", "layer" + pl.SELECT_BOX + "-selectbox"), t16.data.canvases[pl.DRAG].setAttribute("data-id", "layer" + pl.DRAG + "-drag");
    for (s11 = 0; s11 < pl.BUFFER_COUNT; s11++)
      t16.data.bufferCanvases[s11] = document.createElement("canvas"), t16.data.bufferContexts[s11] = t16.data.bufferCanvases[s11].getContext("2d"), t16.data.bufferCanvases[s11].style.position = "absolute", t16.data.bufferCanvases[s11].setAttribute("data-id", "buffer" + s11), t16.data.bufferCanvases[s11].style.zIndex = String(-s11 - 1), t16.data.bufferCanvases[s11].style.visibility = "hidden";
    t16.pathsEnabled = true;
    var u10 = vt4(), c10 = function(e22) {
      return { x: -e22.w / 2, y: -e22.h / 2 };
    }, d12 = function(e22) {
      return e22.boundingBox(), e22[0]._private.bodyBounds;
    }, h10 = function(e22) {
      return e22.boundingBox(), e22[0]._private.labelBounds.main || u10;
    }, p10 = function(e22) {
      return e22.boundingBox(), e22[0]._private.labelBounds.source || u10;
    }, f11 = function(e22) {
      return e22.boundingBox(), e22[0]._private.labelBounds.target || u10;
    }, g9 = function(e22, t17) {
      return t17;
    }, v12 = function(e22, t17, n13) {
      var r10 = e22 ? e22 + "-" : "";
      return { x: t17.x + n13.pstyle(r10 + "text-margin-x").pfValue, y: t17.y + n13.pstyle(r10 + "text-margin-y").pfValue };
    }, y10 = function(e22, t17, n13) {
      var r10 = e22[0]._private.rscratch;
      return { x: r10[t17], y: r10[n13] };
    }, m12 = t16.data.eleTxrCache = new Ts(t16, { getKey: function(e22) {
      return e22[0]._private.nodeKey;
    }, doesEleInvalidateKey: function(e22) {
      var t17 = e22[0]._private;
      return !(t17.oldBackgroundTimestamp === t17.backgroundTimestamp);
    }, drawElement: function(e22, n13, r10, a11, i12) {
      return t16.drawElement(e22, n13, r10, false, false, i12);
    }, getBoundingBox: d12, getRotationPoint: function(e22) {
      return { x: ((t17 = d12(e22)).x1 + t17.x2) / 2, y: (t17.y1 + t17.y2) / 2 };
      var t17;
    }, getRotationOffset: function(e22) {
      return c10(d12(e22));
    }, allowEdgeTxrCaching: false, allowParentTxrCaching: false }), b11 = t16.data.lblTxrCache = new Ts(t16, { getKey: function(e22) {
      return e22[0]._private.labelStyleKey;
    }, drawElement: function(e22, n13, r10, a11, i12) {
      return t16.drawElementText(e22, n13, r10, a11, "main", i12);
    }, getBoundingBox: h10, getRotationPoint: function(e22) {
      return v12("", y10(e22, "labelX", "labelY"), e22);
    }, getRotationOffset: function(e22) {
      var t17 = h10(e22), n13 = c10(h10(e22));
      if (e22.isNode()) {
        switch (e22.pstyle("text-halign").value) {
          case "left":
            n13.x = -t17.w;
            break;
          case "right":
            n13.x = 0;
        }
        switch (e22.pstyle("text-valign").value) {
          case "top":
            n13.y = -t17.h;
            break;
          case "bottom":
            n13.y = 0;
        }
      }
      return n13;
    }, isVisible: g9 }), x10 = t16.data.slbTxrCache = new Ts(t16, { getKey: function(e22) {
      return e22[0]._private.sourceLabelStyleKey;
    }, drawElement: function(e22, n13, r10, a11, i12) {
      return t16.drawElementText(e22, n13, r10, a11, "source", i12);
    }, getBoundingBox: p10, getRotationPoint: function(e22) {
      return v12("source", y10(e22, "sourceLabelX", "sourceLabelY"), e22);
    }, getRotationOffset: function(e22) {
      return c10(p10(e22));
    }, isVisible: g9 }), w11 = t16.data.tlbTxrCache = new Ts(t16, { getKey: function(e22) {
      return e22[0]._private.targetLabelStyleKey;
    }, drawElement: function(e22, n13, r10, a11, i12) {
      return t16.drawElementText(e22, n13, r10, a11, "target", i12);
    }, getBoundingBox: f11, getRotationPoint: function(e22) {
      return v12("target", y10(e22, "targetLabelX", "targetLabelY"), e22);
    }, getRotationOffset: function(e22) {
      return c10(f11(e22));
    }, isVisible: g9 }), E9 = t16.data.lyrTxrCache = new Bs(t16);
    t16.onUpdateEleCalcs(function(e22, t17) {
      m12.invalidateElements(t17), b11.invalidateElements(t17), x10.invalidateElements(t17), w11.invalidateElements(t17), E9.invalidateElements(t17);
      for (var n13 = 0; n13 < t17.length; n13++) {
        var r10 = t17[n13]._private;
        r10.oldBackgroundTimestamp = r10.backgroundTimestamp;
      }
    });
    var C9 = function(e22) {
      for (var t17 = 0; t17 < e22.length; t17++)
        E9.enqueueElementRefinement(e22[t17].ele);
    };
    m12.onDequeue(C9), b11.onDequeue(C9), x10.onDequeue(C9), w11.onDequeue(C9);
  }
  pl.CANVAS_LAYERS = 3, pl.SELECT_BOX = 0, pl.DRAG = 1, pl.NODE = 2, pl.BUFFER_COUNT = 3, pl.TEXTURE_BUFFER = 0, pl.MOTIONBLUR_BUFFER_NODE = 1, pl.MOTIONBLUR_BUFFER_DRAG = 2, pl.redrawHint = function(e21, t16) {
    var n12 = this;
    switch (e21) {
      case "eles":
        n12.data.canvasNeedsRedraw[pl.NODE] = t16;
        break;
      case "drag":
        n12.data.canvasNeedsRedraw[pl.DRAG] = t16;
        break;
      case "select":
        n12.data.canvasNeedsRedraw[pl.SELECT_BOX] = t16;
    }
  };
  var gl = "undefined" != typeof Path2D;
  pl.path2dEnabled = function(e21) {
    if (void 0 === e21)
      return this.pathsEnabled;
    this.pathsEnabled = !!e21;
  }, pl.usePaths = function() {
    return gl && this.pathsEnabled;
  }, pl.setImgSmoothing = function(e21, t16) {
    null != e21.imageSmoothingEnabled ? e21.imageSmoothingEnabled = t16 : (e21.webkitImageSmoothingEnabled = t16, e21.mozImageSmoothingEnabled = t16, e21.msImageSmoothingEnabled = t16);
  }, pl.getImgSmoothing = function(e21) {
    return null != e21.imageSmoothingEnabled ? e21.imageSmoothingEnabled : e21.webkitImageSmoothingEnabled || e21.mozImageSmoothingEnabled || e21.msImageSmoothingEnabled;
  }, pl.makeOffscreenCanvas = function(e21, t16) {
    var n12;
    return "undefined" !== ("undefined" == typeof OffscreenCanvas ? "undefined" : g6(OffscreenCanvas)) ? n12 = new OffscreenCanvas(e21, t16) : ((n12 = document.createElement("canvas")).width = e21, n12.height = t16), n12;
  }, [Ls, qs, Gs, Zs, $s, Qs, el, tl, ll, dl].forEach(function(e21) {
    J4(pl, e21);
  });
  var vl = [{ type: "layout", extensions: Zo }, { type: "renderer", extensions: [{ name: "null", impl: $o }, { name: "base", impl: ws }, { name: "canvas", impl: hl }] }];
  var yl = {};
  var ml = {};
  function bl(e21, t16, n12) {
    var r9 = n12, a10 = function(n13) {
      Me("Can not register `" + t16 + "` for `" + e21 + "` since `" + n13 + "` already exists in the prototype and can not be overridden");
    };
    if ("core" === e21) {
      if (lo.prototype[t16])
        return a10(t16);
      lo.prototype[t16] = n12;
    } else if ("collection" === e21) {
      if (Ci.prototype[t16])
        return a10(t16);
      Ci.prototype[t16] = n12;
    } else if ("layout" === e21) {
      for (var i11 = function(e22) {
        this.options = e22, n12.call(this, e22), N6(this._private) || (this._private = {}), this._private.cy = e22.cy, this._private.listeners = [], this.createEmitter();
      }, o12 = i11.prototype = Object.create(n12.prototype), s11 = [], l11 = 0; l11 < s11.length; l11++) {
        var u10 = s11[l11];
        o12[u10] = o12[u10] || function() {
          return this;
        };
      }
      o12.start && !o12.run ? o12.run = function() {
        return this.start(), this;
      } : !o12.start && o12.run && (o12.start = function() {
        return this.run(), this;
      });
      var c10 = n12.prototype.stop;
      o12.stop = function() {
        var e22 = this.options;
        if (e22 && e22.animate) {
          var t17 = this.animations;
          if (t17)
            for (var n13 = 0; n13 < t17.length; n13++)
              t17[n13].stop();
        }
        return c10 ? c10.call(this) : this.emit("layoutstop"), this;
      }, o12.destroy || (o12.destroy = function() {
        return this;
      }), o12.cy = function() {
        return this._private.cy;
      };
      var d12 = function(e22) {
        return e22._private.cy;
      }, h10 = { addEventFields: function(e22, t17) {
        t17.layout = e22, t17.cy = d12(e22), t17.target = e22;
      }, bubble: function() {
        return true;
      }, parent: function(e22) {
        return d12(e22);
      } };
      J4(o12, { createEmitter: function() {
        return this._private.emitter = new ja(h10, this), this;
      }, emitter: function() {
        return this._private.emitter;
      }, on: function(e22, t17) {
        return this.emitter().on(e22, t17), this;
      }, one: function(e22, t17) {
        return this.emitter().one(e22, t17), this;
      }, once: function(e22, t17) {
        return this.emitter().one(e22, t17), this;
      }, removeListener: function(e22, t17) {
        return this.emitter().removeListener(e22, t17), this;
      }, removeAllListeners: function() {
        return this.emitter().removeAllListeners(), this;
      }, emit: function(e22, t17) {
        return this.emitter().emit(e22, t17), this;
      } }), ur3.eventAliasesOn(o12), r9 = i11;
    } else if ("renderer" === e21 && "null" !== t16 && "base" !== t16) {
      var p10 = xl("renderer", "base"), f11 = p10.prototype, g9 = n12, v12 = n12.prototype, y10 = function() {
        p10.apply(this, arguments), g9.apply(this, arguments);
      }, m12 = y10.prototype;
      for (var b11 in f11) {
        var x10 = f11[b11];
        if (null != v12[b11])
          return a10(b11);
        m12[b11] = x10;
      }
      for (var w11 in v12)
        m12[w11] = v12[w11];
      f11.clientFunctions.forEach(function(e22) {
        m12[e22] = m12[e22] || function() {
          Pe("Renderer does not implement `renderer." + e22 + "()` on its prototype");
        };
      }), r9 = y10;
    } else if ("__proto__" === e21 || "constructor" === e21 || "prototype" === e21)
      return Pe(e21 + " is an illegal type to be registered, possibly lead to prototype pollutions");
    return ne({ map: yl, keys: [e21, t16], value: r9 });
  }
  function xl(e21, t16) {
    return re({ map: yl, keys: [e21, t16] });
  }
  function wl(e21, t16, n12, r9, a10) {
    return ne({ map: ml, keys: [e21, t16, n12, r9], value: a10 });
  }
  function El(e21, t16, n12, r9) {
    return re({ map: ml, keys: [e21, t16, n12, r9] });
  }
  var kl = function() {
    return 2 === arguments.length ? xl.apply(null, arguments) : 3 === arguments.length ? bl.apply(null, arguments) : 4 === arguments.length ? El.apply(null, arguments) : 5 === arguments.length ? wl.apply(null, arguments) : void Pe("Invalid extension access syntax");
  };
  lo.prototype.extension = kl, vl.forEach(function(e21) {
    e21.extensions.forEach(function(t16) {
      bl(e21.type, t16.name, t16.impl);
    });
  });
  var Cl = function e15() {
    if (!(this instanceof e15))
      return new e15();
    this.length = 0;
  };
  var Sl = Cl.prototype;
  Sl.instanceString = function() {
    return "stylesheet";
  }, Sl.selector = function(e21) {
    return this[this.length++] = { selector: e21, properties: [] }, this;
  }, Sl.css = function(e21, t16) {
    var n12 = this.length - 1;
    if (M6(e21))
      this[n12].properties.push({ name: e21, value: t16 });
    else if (N6(e21))
      for (var r9 = e21, a10 = Object.keys(r9), i11 = 0; i11 < a10.length; i11++) {
        var o12 = a10[i11], s11 = r9[o12];
        if (null != s11) {
          var l11 = ro.properties[o12] || ro.properties[X4(o12)];
          if (null != l11) {
            var u10 = l11.name, c10 = s11;
            this[n12].properties.push({ name: u10, value: c10 });
          }
        }
      }
    return this;
  }, Sl.style = Sl.css, Sl.generateStyle = function(e21) {
    var t16 = new ro(e21);
    return this.appendToStyle(t16);
  }, Sl.appendToStyle = function(e21) {
    for (var t16 = 0; t16 < this.length; t16++) {
      var n12 = this[t16], r9 = n12.selector, a10 = n12.properties;
      e21.selector(r9);
      for (var i11 = 0; i11 < a10.length; i11++) {
        var o12 = a10[i11];
        e21.css(o12.name, o12.value);
      }
    }
    return e21;
  };
  var Dl = function(e21) {
    return void 0 === e21 && (e21 = {}), N6(e21) ? new lo(e21) : M6(e21) ? kl.apply(kl, arguments) : void 0;
  };
  Dl.use = function(e21) {
    var t16 = Array.prototype.slice.call(arguments, 1);
    return t16.unshift(Dl), e21.apply(null, t16), this;
  }, Dl.warnings = function(e21) {
    return Te(e21);
  }, Dl.version = "3.26.0", Dl.stylesheet = Dl.Stylesheet = Cl;
  var Pl = Dl;
  var Tl = Pl.stylesheet;
  var Ml = Pl.use;
  var Bl = Pl.version;
  var _l = Pl.warnings;

  // http-url:https://cdn.jsdelivr.net/npm/webcola@3.4.0/+esm
  var t11 = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
  var e16 = {};
  var n8 = {};
  var r6 = {};
  var i7 = {};
  Object.defineProperty(i7, "__esModule", { value: true });
  var o8 = function(t16, e21, n12) {
    this.source = t16, this.target = e21, this.type = n12;
  };
  i7.PowerEdge = o8;
  var s7 = function() {
    function t16(t17, e21, n12, r9) {
      var i11 = this;
      if (this.linkAccessor = n12, this.modules = new Array(t17), this.roots = [], r9)
        this.initModulesFromGroup(r9);
      else {
        this.roots.push(new h7());
        for (var o12 = 0; o12 < t17; ++o12)
          this.roots[0].add(this.modules[o12] = new u7(o12));
      }
      this.R = e21.length, e21.forEach(function(t18) {
        var e22 = i11.modules[n12.getSourceIndex(t18)], r10 = i11.modules[n12.getTargetIndex(t18)], o13 = n12.getType(t18);
        e22.outgoing.add(o13, r10), r10.incoming.add(o13, e22);
      });
    }
    return t16.prototype.initModulesFromGroup = function(t17) {
      var e21 = new h7();
      this.roots.push(e21);
      for (var n12 = 0; n12 < t17.leaves.length; ++n12) {
        var r9 = t17.leaves[n12], i11 = new u7(r9.id);
        this.modules[r9.id] = i11, e21.add(i11);
      }
      if (t17.groups)
        for (var o12 = 0; o12 < t17.groups.length; ++o12) {
          var s11 = t17.groups[o12], a10 = {};
          for (var p10 in s11)
            "leaves" !== p10 && "groups" !== p10 && s11.hasOwnProperty(p10) && (a10[p10] = s11[p10]);
          e21.add(new u7(-1 - o12, new c7(), new c7(), this.initModulesFromGroup(s11), a10));
        }
      return e21;
    }, t16.prototype.merge = function(t17, e21, n12) {
      void 0 === n12 && (n12 = 0);
      var r9 = t17.incoming.intersection(e21.incoming), i11 = t17.outgoing.intersection(e21.outgoing), o12 = new h7();
      o12.add(t17), o12.add(e21);
      var s11 = new u7(this.modules.length, i11, r9, o12);
      this.modules.push(s11);
      var a10 = function(n13, r10, i12) {
        n13.forAll(function(n14, o13) {
          n14.forAll(function(n15) {
            var a11 = n15[r10];
            a11.add(o13, s11), a11.remove(o13, t17), a11.remove(o13, e21), t17[i12].remove(o13, n15), e21[i12].remove(o13, n15);
          });
        });
      };
      return a10(i11, "incoming", "outgoing"), a10(r9, "outgoing", "incoming"), this.R -= r9.count() + i11.count(), this.roots[n12].remove(t17), this.roots[n12].remove(e21), this.roots[n12].add(s11), s11;
    }, t16.prototype.rootMerges = function(t17) {
      void 0 === t17 && (t17 = 0);
      for (var e21 = this.roots[t17].modules(), n12 = e21.length, r9 = new Array(n12 * (n12 - 1)), i11 = 0, o12 = 0, s11 = n12 - 1; o12 < s11; ++o12)
        for (var a10 = o12 + 1; a10 < n12; ++a10) {
          var u10 = e21[o12], h10 = e21[a10];
          r9[i11] = { id: i11, nEdges: this.nEdges(u10, h10), a: u10, b: h10 }, i11++;
        }
      return r9;
    }, t16.prototype.greedyMerge = function() {
      for (var t17 = 0; t17 < this.roots.length; ++t17)
        if (!(this.roots[t17].modules().length < 2)) {
          var e21 = this.rootMerges(t17).sort(function(t18, e22) {
            return t18.nEdges == e22.nEdges ? t18.id - e22.id : t18.nEdges - e22.nEdges;
          })[0];
          if (!(e21.nEdges >= this.R))
            return this.merge(e21.a, e21.b, t17), true;
        }
    }, t16.prototype.nEdges = function(t17, e21) {
      var n12 = t17.incoming.intersection(e21.incoming), r9 = t17.outgoing.intersection(e21.outgoing);
      return this.R - n12.count() - r9.count();
    }, t16.prototype.getGroupHierarchy = function(t17) {
      var e21 = this, n12 = [];
      return a6(this.roots[0], {}, n12), this.allEdges().forEach(function(r9) {
        var i11 = e21.modules[r9.source], s11 = e21.modules[r9.target];
        t17.push(new o8(void 0 === i11.gid ? r9.source : n12[i11.gid], void 0 === s11.gid ? r9.target : n12[s11.gid], r9.type));
      }), n12;
    }, t16.prototype.allEdges = function() {
      var e21 = [];
      return t16.getEdges(this.roots[0], e21), e21;
    }, t16.getEdges = function(e21, n12) {
      e21.forAll(function(e22) {
        e22.getEdges(n12), t16.getEdges(e22.children, n12);
      });
    }, t16;
  }();
  function a6(t16, e21, n12) {
    t16.forAll(function(t17) {
      if (t17.isLeaf())
        e21.leaves || (e21.leaves = []), e21.leaves.push(t17.id);
      else {
        var r9 = e21;
        if (t17.gid = n12.length, !t17.isIsland() || t17.isPredefined()) {
          if (r9 = { id: t17.gid }, t17.isPredefined())
            for (var i11 in t17.definition)
              r9[i11] = t17.definition[i11];
          e21.groups || (e21.groups = []), e21.groups.push(t17.gid), n12.push(r9);
        }
        a6(t17.children, r9, n12);
      }
    });
  }
  i7.Configuration = s7;
  var u7 = function() {
    function t16(t17, e21, n12, r9, i11) {
      void 0 === e21 && (e21 = new c7()), void 0 === n12 && (n12 = new c7()), void 0 === r9 && (r9 = new h7()), this.id = t17, this.outgoing = e21, this.incoming = n12, this.children = r9, this.definition = i11;
    }
    return t16.prototype.getEdges = function(t17) {
      var e21 = this;
      this.outgoing.forAll(function(n12, r9) {
        n12.forAll(function(n13) {
          t17.push(new o8(e21.id, n13.id, r9));
        });
      });
    }, t16.prototype.isLeaf = function() {
      return 0 === this.children.count();
    }, t16.prototype.isIsland = function() {
      return 0 === this.outgoing.count() && 0 === this.incoming.count();
    }, t16.prototype.isPredefined = function() {
      return void 0 !== this.definition;
    }, t16;
  }();
  i7.Module = u7;
  var h7 = function() {
    function t16() {
      this.table = {};
    }
    return t16.prototype.count = function() {
      return Object.keys(this.table).length;
    }, t16.prototype.intersection = function(e21) {
      var n12 = new t16();
      return n12.table = function(t17, e22) {
        var n13 = {};
        for (var r9 in t17)
          r9 in e22 && (n13[r9] = t17[r9]);
        return n13;
      }(this.table, e21.table), n12;
    }, t16.prototype.intersectionCount = function(t17) {
      return this.intersection(t17).count();
    }, t16.prototype.contains = function(t17) {
      return t17 in this.table;
    }, t16.prototype.add = function(t17) {
      this.table[t17.id] = t17;
    }, t16.prototype.remove = function(t17) {
      delete this.table[t17.id];
    }, t16.prototype.forAll = function(t17) {
      for (var e21 in this.table)
        t17(this.table[e21]);
    }, t16.prototype.modules = function() {
      var t17 = [];
      return this.forAll(function(e21) {
        e21.isPredefined() || t17.push(e21);
      }), t17;
    }, t16;
  }();
  i7.ModuleSet = h7;
  var c7 = function() {
    function t16() {
      this.sets = {}, this.n = 0;
    }
    return t16.prototype.count = function() {
      return this.n;
    }, t16.prototype.contains = function(t17) {
      var e21 = false;
      return this.forAllModules(function(n12) {
        e21 || n12.id != t17 || (e21 = true);
      }), e21;
    }, t16.prototype.add = function(t17, e21) {
      (t17 in this.sets ? this.sets[t17] : this.sets[t17] = new h7()).add(e21), ++this.n;
    }, t16.prototype.remove = function(t17, e21) {
      var n12 = this.sets[t17];
      n12.remove(e21), 0 === n12.count() && delete this.sets[t17], --this.n;
    }, t16.prototype.forAll = function(t17) {
      for (var e21 in this.sets)
        t17(this.sets[e21], Number(e21));
    }, t16.prototype.forAllModules = function(t17) {
      this.forAll(function(e21, n12) {
        return e21.forAll(t17);
      });
    }, t16.prototype.intersection = function(e21) {
      var n12 = new t16();
      return this.forAll(function(t17, r9) {
        if (r9 in e21.sets) {
          var i11 = t17.intersection(e21.sets[r9]), o12 = i11.count();
          o12 > 0 && (n12.sets[r9] = i11, n12.n += o12);
        }
      }), n12;
    }, t16;
  }();
  i7.LinkSets = c7, i7.getGroups = function(t16, e21, n12, r9) {
    for (var i11 = t16.length, o12 = new s7(i11, e21, n12, r9); o12.greedyMerge(); )
      ;
    var a10 = [], u10 = o12.getGroupHierarchy(a10);
    return a10.forEach(function(e22) {
      var n13 = function(n14) {
        var r10 = e22[n14];
        "number" == typeof r10 && (e22[n14] = t16[r10]);
      };
      n13("source"), n13("target");
    }), { groups: u10, powerEdges: a10 };
  };
  var p7 = {};
  function f7(t16, e21) {
    var n12 = {};
    for (var r9 in t16)
      n12[r9] = {};
    for (var r9 in e21)
      n12[r9] = {};
    return Object.keys(n12).length;
  }
  function l7(t16, e21) {
    var n12 = 0;
    for (var r9 in t16)
      void 0 !== e21[r9] && ++n12;
    return n12;
  }
  function d8(t16, e21, n12, r9) {
    var i11 = function(t17, e22) {
      var n13 = {}, r10 = function(t18, e23) {
        void 0 === n13[t18] && (n13[t18] = {}), n13[t18][e23] = {};
      };
      return t17.forEach(function(t18) {
        var n14 = e22.getSourceIndex(t18), i12 = e22.getTargetIndex(t18);
        r10(n14, i12), r10(i12, n14);
      }), n13;
    }(t16, r9);
    t16.forEach(function(t17) {
      var o12 = i11[r9.getSourceIndex(t17)], s11 = i11[r9.getTargetIndex(t17)];
      r9.setLength(t17, 1 + e21 * n12(o12, s11));
    });
  }
  function g7(t16, e21, n12) {
    var r9 = [], i11 = 0, o12 = [], s11 = [];
    function a10(t17) {
      t17.index = t17.lowlink = i11++, o12.push(t17), t17.onStack = true;
      for (var e22 = 0, n13 = t17.out; e22 < n13.length; e22++) {
        var r10 = n13[e22];
        void 0 === r10.index ? (a10(r10), t17.lowlink = Math.min(t17.lowlink, r10.lowlink)) : r10.onStack && (t17.lowlink = Math.min(t17.lowlink, r10.index));
      }
      if (t17.lowlink === t17.index) {
        for (var u11 = []; o12.length && ((r10 = o12.pop()).onStack = false, u11.push(r10), r10 !== t17); )
          ;
        s11.push(u11.map(function(t18) {
          return t18.id;
        }));
      }
    }
    for (var u10 = 0; u10 < t16; u10++)
      r9.push({ id: u10, out: [] });
    for (var h10 = 0, c10 = e21; h10 < c10.length; h10++) {
      var p10 = c10[h10], f11 = r9[n12.getSourceIndex(p10)], l11 = r9[n12.getTargetIndex(p10)];
      f11.out.push(l11);
    }
    for (var d12 = 0, g9 = r9; d12 < g9.length; d12++) {
      var v12 = g9[d12];
      void 0 === v12.index && a10(v12);
    }
    return s11;
  }
  Object.defineProperty(p7, "__esModule", { value: true }), p7.symmetricDiffLinkLengths = function(t16, e21, n12) {
    void 0 === n12 && (n12 = 1), d8(t16, n12, function(t17, e22) {
      return Math.sqrt(f7(t17, e22) - l7(t17, e22));
    }, e21);
  }, p7.jaccardLinkLengths = function(t16, e21, n12) {
    void 0 === n12 && (n12 = 1), d8(t16, n12, function(t17, e22) {
      return Math.min(Object.keys(t17).length, Object.keys(e22).length) < 1.1 ? 0 : l7(t17, e22) / f7(t17, e22);
    }, e21);
  }, p7.generateDirectedEdgeConstraints = function(t16, e21, n12, r9) {
    var i11 = g7(t16, e21, r9), o12 = {};
    i11.forEach(function(t17, e22) {
      return t17.forEach(function(t18) {
        return o12[t18] = e22;
      });
    });
    var s11 = [];
    return e21.forEach(function(t17) {
      var e22 = r9.getSourceIndex(t17), i12 = r9.getTargetIndex(t17);
      o12[e22] !== o12[i12] && s11.push({ axis: n12, left: e22, right: i12, gap: r9.getMinSeparation(t17) });
    }), s11;
  }, p7.stronglyConnectedComponents = g7;
  var v7 = {};
  Object.defineProperty(v7, "__esModule", { value: true });
  var y7 = function() {
    function t16() {
      this.locks = {};
    }
    return t16.prototype.add = function(t17, e21) {
      this.locks[t17] = e21;
    }, t16.prototype.clear = function() {
      this.locks = {};
    }, t16.prototype.isEmpty = function() {
      for (var t17 in this.locks)
        return false;
      return true;
    }, t16.prototype.apply = function(t17) {
      for (var e21 in this.locks)
        t17(Number(e21), this.locks[e21]);
    }, t16;
  }();
  v7.Locks = y7;
  var _6 = function() {
    function t16(t17, e21, n12) {
      void 0 === n12 && (n12 = null), this.D = e21, this.G = n12, this.threshold = 1e-4, this.numGridSnapNodes = 0, this.snapGridSize = 100, this.snapStrength = 1e3, this.scaleSnapByMaxH = false, this.random = new x7(), this.project = null, this.x = t17, this.k = t17.length;
      var r9 = this.n = t17[0].length;
      this.H = new Array(this.k), this.g = new Array(this.k), this.Hd = new Array(this.k), this.a = new Array(this.k), this.b = new Array(this.k), this.c = new Array(this.k), this.d = new Array(this.k), this.e = new Array(this.k), this.ia = new Array(this.k), this.ib = new Array(this.k), this.xtmp = new Array(this.k), this.locks = new y7(), this.minD = Number.MAX_VALUE;
      for (var i11, o12 = r9; o12--; )
        for (i11 = r9; --i11 > o12; ) {
          var s11 = e21[o12][i11];
          s11 > 0 && s11 < this.minD && (this.minD = s11);
        }
      for (this.minD === Number.MAX_VALUE && (this.minD = 1), o12 = this.k; o12--; ) {
        for (this.g[o12] = new Array(r9), this.H[o12] = new Array(r9), i11 = r9; i11--; )
          this.H[o12][i11] = new Array(r9);
        this.Hd[o12] = new Array(r9), this.a[o12] = new Array(r9), this.b[o12] = new Array(r9), this.c[o12] = new Array(r9), this.d[o12] = new Array(r9), this.e[o12] = new Array(r9), this.ia[o12] = new Array(r9), this.ib[o12] = new Array(r9), this.xtmp[o12] = new Array(r9);
      }
    }
    return t16.createSquareMatrix = function(t17, e21) {
      for (var n12 = new Array(t17), r9 = 0; r9 < t17; ++r9) {
        n12[r9] = new Array(t17);
        for (var i11 = 0; i11 < t17; ++i11)
          n12[r9][i11] = e21(r9, i11);
      }
      return n12;
    }, t16.prototype.offsetDir = function() {
      for (var t17 = this, e21 = new Array(this.k), n12 = 0, r9 = 0; r9 < this.k; ++r9) {
        var i11 = e21[r9] = this.random.getNextBetween(0.01, 1) - 0.5;
        n12 += i11 * i11;
      }
      return n12 = Math.sqrt(n12), e21.map(function(e22) {
        return e22 * (t17.minD / n12);
      });
    }, t16.prototype.computeDerivatives = function(t17) {
      var e21 = this, n12 = this.n;
      if (!(n12 < 1)) {
        for (var r9, i11 = new Array(this.k), o12 = new Array(this.k), s11 = new Array(this.k), a10 = 0, u10 = 0; u10 < n12; ++u10) {
          for (r9 = 0; r9 < this.k; ++r9)
            s11[r9] = this.g[r9][u10] = 0;
          for (var h10 = 0; h10 < n12; ++h10)
            if (u10 !== h10) {
              for (var c10 = n12; c10--; ) {
                var p10 = 0;
                for (r9 = 0; r9 < this.k; ++r9) {
                  var f11 = i11[r9] = t17[r9][u10] - t17[r9][h10];
                  p10 += o12[r9] = f11 * f11;
                }
                if (p10 > 1e-9)
                  break;
                var l11 = this.offsetDir();
                for (r9 = 0; r9 < this.k; ++r9)
                  t17[r9][h10] += l11[r9];
              }
              var d12 = Math.sqrt(p10), g9 = this.D[u10][h10], v12 = null != this.G ? this.G[u10][h10] : 1;
              if (v12 > 1 && d12 > g9 || !isFinite(g9))
                for (r9 = 0; r9 < this.k; ++r9)
                  this.H[r9][u10][h10] = 0;
              else {
                v12 > 1 && (v12 = 1);
                var y10 = g9 * g9, _7 = 2 * v12 * (d12 - g9) / (y10 * d12), x10 = d12 * d12 * d12, m12 = 2 * -v12 / (y10 * x10);
                for (isFinite(_7) || console.log(_7), r9 = 0; r9 < this.k; ++r9)
                  this.g[r9][u10] += i11[r9] * _7, s11[r9] -= this.H[r9][u10][h10] = m12 * (x10 + g9 * (o12[r9] - p10) + d12 * p10);
              }
            }
          for (r9 = 0; r9 < this.k; ++r9)
            a10 = Math.max(a10, this.H[r9][u10][u10] = s11[r9]);
        }
        var b11 = this.snapGridSize / 2, k10 = this.snapGridSize, w11 = this.snapStrength / (b11 * b11), E9 = this.numGridSnapNodes;
        for (u10 = 0; u10 < E9; ++u10)
          for (r9 = 0; r9 < this.k; ++r9) {
            var P10 = this.x[r9][u10], L9 = P10 / k10, M9 = L9 % 1, A10 = L9 - M9;
            -b11 < (f11 = Math.abs(M9) <= 0.5 ? P10 - A10 * k10 : P10 > 0 ? P10 - (A10 + 1) * k10 : P10 - (A10 - 1) * k10) && f11 <= b11 && (this.scaleSnapByMaxH ? (this.g[r9][u10] += a10 * w11 * f11, this.H[r9][u10][u10] += a10 * w11) : (this.g[r9][u10] += w11 * f11, this.H[r9][u10][u10] += w11));
          }
        this.locks.isEmpty() || this.locks.apply(function(n13, i12) {
          for (r9 = 0; r9 < e21.k; ++r9)
            e21.H[r9][n13][n13] += a10, e21.g[r9][n13] -= a10 * (i12[r9] - t17[r9][n13]);
        });
      }
    }, t16.dotProd = function(t17, e21) {
      for (var n12 = 0, r9 = t17.length; r9--; )
        n12 += t17[r9] * e21[r9];
      return n12;
    }, t16.rightMultiply = function(e21, n12, r9) {
      for (var i11 = e21.length; i11--; )
        r9[i11] = t16.dotProd(e21[i11], n12);
    }, t16.prototype.computeStepSize = function(e21) {
      for (var n12 = 0, r9 = 0, i11 = 0; i11 < this.k; ++i11)
        n12 += t16.dotProd(this.g[i11], e21[i11]), t16.rightMultiply(this.H[i11], e21[i11], this.Hd[i11]), r9 += t16.dotProd(e21[i11], this.Hd[i11]);
      return 0 !== r9 && isFinite(r9) ? 1 * n12 / r9 : 0;
    }, t16.prototype.reduceStress = function() {
      this.computeDerivatives(this.x);
      for (var t17 = this.computeStepSize(this.g), e21 = 0; e21 < this.k; ++e21)
        this.takeDescentStep(this.x[e21], this.g[e21], t17);
      return this.computeStress();
    }, t16.copy = function(t17, e21) {
      for (var n12 = t17.length, r9 = e21[0].length, i11 = 0; i11 < n12; ++i11)
        for (var o12 = 0; o12 < r9; ++o12)
          e21[i11][o12] = t17[i11][o12];
    }, t16.prototype.stepAndProject = function(e21, n12, r9, i11) {
      t16.copy(e21, n12), this.takeDescentStep(n12[0], r9[0], i11), this.project && this.project[0](e21[0], e21[1], n12[0]), this.takeDescentStep(n12[1], r9[1], i11), this.project && this.project[1](n12[0], e21[1], n12[1]);
      for (var o12 = 2; o12 < this.k; o12++)
        this.takeDescentStep(n12[o12], r9[o12], i11);
    }, t16.mApply = function(t17, e21, n12) {
      for (var r9 = t17; r9-- > 0; )
        for (var i11 = e21; i11-- > 0; )
          n12(r9, i11);
    }, t16.prototype.matrixApply = function(e21) {
      t16.mApply(this.k, this.n, e21);
    }, t16.prototype.computeNextPosition = function(t17, e21) {
      var n12 = this;
      this.computeDerivatives(t17);
      var r9 = this.computeStepSize(this.g);
      if (this.stepAndProject(t17, e21, this.g, r9), this.project) {
        this.matrixApply(function(r10, i12) {
          return n12.e[r10][i12] = t17[r10][i12] - e21[r10][i12];
        });
        var i11 = this.computeStepSize(this.e);
        i11 = Math.max(0.2, Math.min(i11, 1)), this.stepAndProject(t17, e21, this.e, i11);
      }
    }, t16.prototype.run = function(t17) {
      for (var e21 = Number.MAX_VALUE, n12 = false; !n12 && t17-- > 0; ) {
        var r9 = this.rungeKutta();
        n12 = Math.abs(e21 / r9 - 1) < this.threshold, e21 = r9;
      }
      return e21;
    }, t16.prototype.rungeKutta = function() {
      var e21 = this;
      this.computeNextPosition(this.x, this.a), t16.mid(this.x, this.a, this.ia), this.computeNextPosition(this.ia, this.b), t16.mid(this.x, this.b, this.ib), this.computeNextPosition(this.ib, this.c), this.computeNextPosition(this.c, this.d);
      var n12 = 0;
      return this.matrixApply(function(t17, r9) {
        var i11 = (e21.a[t17][r9] + 2 * e21.b[t17][r9] + 2 * e21.c[t17][r9] + e21.d[t17][r9]) / 6, o12 = e21.x[t17][r9] - i11;
        n12 += o12 * o12, e21.x[t17][r9] = i11;
      }), n12;
    }, t16.mid = function(e21, n12, r9) {
      t16.mApply(e21.length, e21[0].length, function(t17, i11) {
        return r9[t17][i11] = e21[t17][i11] + (n12[t17][i11] - e21[t17][i11]) / 2;
      });
    }, t16.prototype.takeDescentStep = function(t17, e21, n12) {
      for (var r9 = 0; r9 < this.n; ++r9)
        t17[r9] = t17[r9] - n12 * e21[r9];
    }, t16.prototype.computeStress = function() {
      for (var t17 = 0, e21 = 0, n12 = this.n - 1; e21 < n12; ++e21)
        for (var r9 = e21 + 1, i11 = this.n; r9 < i11; ++r9) {
          for (var o12 = 0, s11 = 0; s11 < this.k; ++s11) {
            var a10 = this.x[s11][e21] - this.x[s11][r9];
            o12 += a10 * a10;
          }
          o12 = Math.sqrt(o12);
          var u10 = this.D[e21][r9];
          if (isFinite(u10)) {
            var h10 = u10 - o12;
            t17 += h10 * h10 / (u10 * u10);
          }
        }
      return t17;
    }, t16.zeroDistance = 1e-10, t16;
  }();
  v7.Descent = _6;
  var x7 = function() {
    function t16(t17) {
      void 0 === t17 && (t17 = 1), this.seed = t17, this.a = 214013, this.c = 2531011, this.m = 2147483648, this.range = 32767;
    }
    return t16.prototype.getNext = function() {
      return this.seed = (this.seed * this.a + this.c) % this.m, (this.seed >> 16) / this.range;
    }, t16.prototype.getNextBetween = function(t17, e21) {
      return t17 + this.getNext() * (e21 - t17);
    }, t16;
  }();
  v7.PseudoRandom = x7;
  var m8 = {};
  var b7 = {};
  Object.defineProperty(b7, "__esModule", { value: true });
  var k6 = function() {
    function t16(t17) {
      this.scale = t17, this.AB = 0, this.AD = 0, this.A2 = 0;
    }
    return t16.prototype.addVariable = function(t17) {
      var e21 = this.scale / t17.scale, n12 = t17.offset / t17.scale, r9 = t17.weight;
      this.AB += r9 * e21 * n12, this.AD += r9 * e21 * t17.desiredPosition, this.A2 += r9 * e21 * e21;
    }, t16.prototype.getPosn = function() {
      return (this.AD - this.AB) / this.A2;
    }, t16;
  }();
  b7.PositionStats = k6;
  var w7 = function() {
    function t16(t17, e21, n12, r9) {
      void 0 === r9 && (r9 = false), this.left = t17, this.right = e21, this.gap = n12, this.equality = r9, this.active = false, this.unsatisfiable = false, this.left = t17, this.right = e21, this.gap = n12, this.equality = r9;
    }
    return t16.prototype.slack = function() {
      return this.unsatisfiable ? Number.MAX_VALUE : this.right.scale * this.right.position() - this.gap - this.left.scale * this.left.position();
    }, t16;
  }();
  b7.Constraint = w7;
  var E7 = function() {
    function t16(t17, e21, n12) {
      void 0 === e21 && (e21 = 1), void 0 === n12 && (n12 = 1), this.desiredPosition = t17, this.weight = e21, this.scale = n12, this.offset = 0;
    }
    return t16.prototype.dfdv = function() {
      return 2 * this.weight * (this.position() - this.desiredPosition);
    }, t16.prototype.position = function() {
      return (this.block.ps.scale * this.block.posn + this.offset) / this.scale;
    }, t16.prototype.visitNeighbours = function(t17, e21) {
      var n12 = function(n13, r9) {
        return n13.active && t17 !== r9 && e21(n13, r9);
      };
      this.cOut.forEach(function(t18) {
        return n12(t18, t18.right);
      }), this.cIn.forEach(function(t18) {
        return n12(t18, t18.left);
      });
    }, t16;
  }();
  b7.Variable = E7;
  var P7 = function() {
    function t16(t17) {
      this.vars = [], t17.offset = 0, this.ps = new k6(t17.scale), this.addVariable(t17);
    }
    return t16.prototype.addVariable = function(t17) {
      t17.block = this, this.vars.push(t17), this.ps.addVariable(t17), this.posn = this.ps.getPosn();
    }, t16.prototype.updateWeightedPosition = function() {
      this.ps.AB = this.ps.AD = this.ps.A2 = 0;
      for (var t17 = 0, e21 = this.vars.length; t17 < e21; ++t17)
        this.ps.addVariable(this.vars[t17]);
      this.posn = this.ps.getPosn();
    }, t16.prototype.compute_lm = function(t17, e21, n12) {
      var r9 = this, i11 = t17.dfdv();
      return t17.visitNeighbours(e21, function(e22, o12) {
        var s11 = r9.compute_lm(o12, t17, n12);
        o12 === e22.right ? (i11 += s11 * e22.left.scale, e22.lm = s11) : (i11 += s11 * e22.right.scale, e22.lm = -s11), n12(e22);
      }), i11 / t17.scale;
    }, t16.prototype.populateSplitBlock = function(t17, e21) {
      var n12 = this;
      t17.visitNeighbours(e21, function(e22, r9) {
        r9.offset = t17.offset + (r9 === e22.right ? e22.gap : -e22.gap), n12.addVariable(r9), n12.populateSplitBlock(r9, t17);
      });
    }, t16.prototype.traverse = function(t17, e21, n12, r9) {
      var i11 = this;
      void 0 === n12 && (n12 = this.vars[0]), void 0 === r9 && (r9 = null), n12.visitNeighbours(r9, function(r10, o12) {
        e21.push(t17(r10)), i11.traverse(t17, e21, o12, n12);
      });
    }, t16.prototype.findMinLM = function() {
      var t17 = null;
      return this.compute_lm(this.vars[0], null, function(e21) {
        !e21.equality && (null === t17 || e21.lm < t17.lm) && (t17 = e21);
      }), t17;
    }, t16.prototype.findMinLMBetween = function(t17, e21) {
      this.compute_lm(t17, null, function() {
      });
      var n12 = null;
      return this.findPath(t17, null, e21, function(t18, e22) {
        !t18.equality && t18.right === e22 && (null === n12 || t18.lm < n12.lm) && (n12 = t18);
      }), n12;
    }, t16.prototype.findPath = function(t17, e21, n12, r9) {
      var i11 = this, o12 = false;
      return t17.visitNeighbours(e21, function(e22, s11) {
        o12 || s11 !== n12 && !i11.findPath(s11, t17, n12, r9) || (o12 = true, r9(e22, s11));
      }), o12;
    }, t16.prototype.isActiveDirectedPathBetween = function(t17, e21) {
      if (t17 === e21)
        return true;
      for (var n12 = t17.cOut.length; n12--; ) {
        var r9 = t17.cOut[n12];
        if (r9.active && this.isActiveDirectedPathBetween(r9.right, e21))
          return true;
      }
      return false;
    }, t16.split = function(e21) {
      return e21.active = false, [t16.createSplitBlock(e21.left), t16.createSplitBlock(e21.right)];
    }, t16.createSplitBlock = function(e21) {
      var n12 = new t16(e21);
      return n12.populateSplitBlock(e21, null), n12;
    }, t16.prototype.splitBetween = function(e21, n12) {
      var r9 = this.findMinLMBetween(e21, n12);
      if (null !== r9) {
        var i11 = t16.split(r9);
        return { constraint: r9, lb: i11[0], rb: i11[1] };
      }
      return null;
    }, t16.prototype.mergeAcross = function(t17, e21, n12) {
      e21.active = true;
      for (var r9 = 0, i11 = t17.vars.length; r9 < i11; ++r9) {
        var o12 = t17.vars[r9];
        o12.offset += n12, this.addVariable(o12);
      }
      this.posn = this.ps.getPosn();
    }, t16.prototype.cost = function() {
      for (var t17 = 0, e21 = this.vars.length; e21--; ) {
        var n12 = this.vars[e21], r9 = n12.position() - n12.desiredPosition;
        t17 += r9 * r9 * n12.weight;
      }
      return t17;
    }, t16;
  }();
  b7.Block = P7;
  var L6 = function() {
    function t16(t17) {
      this.vs = t17;
      var e21 = t17.length;
      for (this.list = new Array(e21); e21--; ) {
        var n12 = new P7(t17[e21]);
        this.list[e21] = n12, n12.blockInd = e21;
      }
    }
    return t16.prototype.cost = function() {
      for (var t17 = 0, e21 = this.list.length; e21--; )
        t17 += this.list[e21].cost();
      return t17;
    }, t16.prototype.insert = function(t17) {
      t17.blockInd = this.list.length, this.list.push(t17);
    }, t16.prototype.remove = function(t17) {
      var e21 = this.list.length - 1, n12 = this.list[e21];
      this.list.length = e21, t17 !== n12 && (this.list[t17.blockInd] = n12, n12.blockInd = t17.blockInd);
    }, t16.prototype.merge = function(t17) {
      var e21 = t17.left.block, n12 = t17.right.block, r9 = t17.right.offset - t17.left.offset - t17.gap;
      e21.vars.length < n12.vars.length ? (n12.mergeAcross(e21, t17, r9), this.remove(e21)) : (e21.mergeAcross(n12, t17, -r9), this.remove(n12));
    }, t16.prototype.forEach = function(t17) {
      this.list.forEach(t17);
    }, t16.prototype.updateBlockPositions = function() {
      this.list.forEach(function(t17) {
        return t17.updateWeightedPosition();
      });
    }, t16.prototype.split = function(t17) {
      var e21 = this;
      this.updateBlockPositions(), this.list.forEach(function(n12) {
        var r9 = n12.findMinLM();
        null !== r9 && r9.lm < M7.LAGRANGIAN_TOLERANCE && (n12 = r9.left.block, P7.split(r9).forEach(function(t18) {
          return e21.insert(t18);
        }), e21.remove(n12), t17.push(r9));
      });
    }, t16;
  }();
  b7.Blocks = L6;
  var M7 = function() {
    function t16(t17, e21) {
      this.vs = t17, this.cs = e21, this.vs = t17, t17.forEach(function(t18) {
        t18.cIn = [], t18.cOut = [];
      }), this.cs = e21, e21.forEach(function(t18) {
        t18.left.cOut.push(t18), t18.right.cIn.push(t18);
      }), this.inactive = e21.map(function(t18) {
        return t18.active = false, t18;
      }), this.bs = null;
    }
    return t16.prototype.cost = function() {
      return this.bs.cost();
    }, t16.prototype.setStartingPositions = function(t17) {
      this.inactive = this.cs.map(function(t18) {
        return t18.active = false, t18;
      }), this.bs = new L6(this.vs), this.bs.forEach(function(e21, n12) {
        return e21.posn = t17[n12];
      });
    }, t16.prototype.setDesiredPositions = function(t17) {
      this.vs.forEach(function(e21, n12) {
        return e21.desiredPosition = t17[n12];
      });
    }, t16.prototype.mostViolated = function() {
      for (var e21 = Number.MAX_VALUE, n12 = null, r9 = this.inactive, i11 = r9.length, o12 = i11, s11 = 0; s11 < i11; ++s11) {
        var a10 = r9[s11];
        if (!a10.unsatisfiable) {
          var u10 = a10.slack();
          if ((a10.equality || u10 < e21) && (e21 = u10, n12 = a10, o12 = s11, a10.equality))
            break;
        }
      }
      return o12 !== i11 && (e21 < t16.ZERO_UPPERBOUND && !n12.active || n12.equality) && (r9[o12] = r9[i11 - 1], r9.length = i11 - 1), n12;
    }, t16.prototype.satisfy = function() {
      null == this.bs && (this.bs = new L6(this.vs)), this.bs.split(this.inactive);
      for (var e21 = null; (e21 = this.mostViolated()) && (e21.equality || e21.slack() < t16.ZERO_UPPERBOUND && !e21.active); ) {
        var n12 = e21.left.block;
        if (n12 !== e21.right.block)
          this.bs.merge(e21);
        else {
          if (n12.isActiveDirectedPathBetween(e21.right, e21.left)) {
            e21.unsatisfiable = true;
            continue;
          }
          var r9 = n12.splitBetween(e21.left, e21.right);
          if (null === r9) {
            e21.unsatisfiable = true;
            continue;
          }
          this.bs.insert(r9.lb), this.bs.insert(r9.rb), this.bs.remove(n12), this.inactive.push(r9.constraint), e21.slack() >= 0 ? this.inactive.push(e21) : this.bs.merge(e21);
        }
      }
    }, t16.prototype.solve = function() {
      this.satisfy();
      for (var t17 = Number.MAX_VALUE, e21 = this.bs.cost(); Math.abs(t17 - e21) > 1e-4; )
        this.satisfy(), t17 = e21, e21 = this.bs.cost();
      return e21;
    }, t16.LAGRANGIAN_TOLERANCE = -1e-4, t16.ZERO_UPPERBOUND = -1e-10, t16;
  }();
  b7.Solver = M7, b7.removeOverlapInOneDimension = function(t16, e21, n12) {
    for (var r9 = t16.map(function(t17) {
      return new E7(t17.desiredCenter);
    }), i11 = [], o12 = t16.length, s11 = 0; s11 < o12 - 1; s11++) {
      var a10 = t16[s11], u10 = t16[s11 + 1];
      i11.push(new w7(r9[s11], r9[s11 + 1], (a10.size + u10.size) / 2));
    }
    var h10 = r9[0], c10 = r9[o12 - 1], p10 = t16[0].size / 2, f11 = t16[o12 - 1].size / 2, l11 = null, d12 = null;
    return e21 && (l11 = new E7(e21, 1e3 * h10.weight), r9.push(l11), i11.push(new w7(l11, h10, p10))), n12 && (d12 = new E7(n12, 1e3 * c10.weight), r9.push(d12), i11.push(new w7(c10, d12, f11))), new M7(r9, i11).solve(), { newCenters: r9.slice(0, t16.length).map(function(t17) {
      return t17.position();
    }), lowerBound: l11 ? l11.position() : h10.position() - p10, upperBound: d12 ? d12.position() : c10.position() + f11 };
  };
  var A7;
  var S7 = {};
  var O7 = t11 && t11.__extends || (A7 = function(t16, e21) {
    return A7 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(t17, e22) {
      t17.__proto__ = e22;
    } || function(t17, e22) {
      for (var n12 in e22)
        e22.hasOwnProperty(n12) && (t17[n12] = e22[n12]);
    }, A7(t16, e21);
  }, function(t16, e21) {
    function n12() {
      this.constructor = t16;
    }
    A7(t16, e21), t16.prototype = null === e21 ? Object.create(e21) : (n12.prototype = e21.prototype, new n12());
  });
  Object.defineProperty(S7, "__esModule", { value: true });
  var C6 = function() {
    function t16() {
      this.findIter = function(t17) {
        for (var e21 = this._root, n12 = this.iterator(); null !== e21; ) {
          var r9 = this._comparator(t17, e21.data);
          if (0 === r9)
            return n12._cursor = e21, n12;
          n12._ancestors.push(e21), e21 = e21.get_child(r9 > 0);
        }
        return null;
      };
    }
    return t16.prototype.clear = function() {
      this._root = null, this.size = 0;
    }, t16.prototype.find = function(t17) {
      for (var e21 = this._root; null !== e21; ) {
        var n12 = this._comparator(t17, e21.data);
        if (0 === n12)
          return e21.data;
        e21 = e21.get_child(n12 > 0);
      }
      return null;
    }, t16.prototype.lowerBound = function(t17) {
      return this._bound(t17, this._comparator);
    }, t16.prototype.upperBound = function(t17) {
      var e21 = this._comparator;
      return this._bound(t17, function(t18, n12) {
        return e21(n12, t18);
      });
    }, t16.prototype.min = function() {
      var t17 = this._root;
      if (null === t17)
        return null;
      for (; null !== t17.left; )
        t17 = t17.left;
      return t17.data;
    }, t16.prototype.max = function() {
      var t17 = this._root;
      if (null === t17)
        return null;
      for (; null !== t17.right; )
        t17 = t17.right;
      return t17.data;
    }, t16.prototype.iterator = function() {
      return new N7(this);
    }, t16.prototype.each = function(t17) {
      for (var e21, n12 = this.iterator(); null !== (e21 = n12.next()); )
        t17(e21);
    }, t16.prototype.reach = function(t17) {
      for (var e21, n12 = this.iterator(); null !== (e21 = n12.prev()); )
        t17(e21);
    }, t16.prototype._bound = function(t17, e21) {
      for (var n12 = this._root, r9 = this.iterator(); null !== n12; ) {
        var i11 = this._comparator(t17, n12.data);
        if (0 === i11)
          return r9._cursor = n12, r9;
        r9._ancestors.push(n12), n12 = n12.get_child(i11 > 0);
      }
      for (var o12 = r9._ancestors.length - 1; o12 >= 0; --o12)
        if (e21(t17, (n12 = r9._ancestors[o12]).data) > 0)
          return r9._cursor = n12, r9._ancestors.length = o12, r9;
      return r9._ancestors.length = 0, r9;
    }, t16;
  }();
  S7.TreeBase = C6;
  var N7 = function() {
    function t16(t17) {
      this._tree = t17, this._ancestors = [], this._cursor = null;
    }
    return t16.prototype.data = function() {
      return null !== this._cursor ? this._cursor.data : null;
    }, t16.prototype.next = function() {
      if (null === this._cursor) {
        var t17 = this._tree._root;
        null !== t17 && this._minNode(t17);
      } else {
        var e21;
        if (null === this._cursor.right)
          do {
            if (e21 = this._cursor, !this._ancestors.length) {
              this._cursor = null;
              break;
            }
            this._cursor = this._ancestors.pop();
          } while (this._cursor.right === e21);
        else
          this._ancestors.push(this._cursor), this._minNode(this._cursor.right);
      }
      return null !== this._cursor ? this._cursor.data : null;
    }, t16.prototype.prev = function() {
      if (null === this._cursor) {
        var t17 = this._tree._root;
        null !== t17 && this._maxNode(t17);
      } else {
        var e21;
        if (null === this._cursor.left)
          do {
            if (e21 = this._cursor, !this._ancestors.length) {
              this._cursor = null;
              break;
            }
            this._cursor = this._ancestors.pop();
          } while (this._cursor.left === e21);
        else
          this._ancestors.push(this._cursor), this._maxNode(this._cursor.left);
      }
      return null !== this._cursor ? this._cursor.data : null;
    }, t16.prototype._minNode = function(t17) {
      for (; null !== t17.left; )
        this._ancestors.push(t17), t17 = t17.left;
      this._cursor = t17;
    }, t16.prototype._maxNode = function(t17) {
      for (; null !== t17.right; )
        this._ancestors.push(t17), t17 = t17.right;
      this._cursor = t17;
    }, t16;
  }();
  S7.Iterator = N7;
  var I7 = function() {
    function t16(t17) {
      this.data = t17, this.left = null, this.right = null, this.red = true;
    }
    return t16.prototype.get_child = function(t17) {
      return t17 ? this.right : this.left;
    }, t16.prototype.set_child = function(t17, e21) {
      t17 ? this.right = e21 : this.left = e21;
    }, t16;
  }();
  var T7 = function(t16) {
    function e21(e22) {
      var n12 = t16.call(this) || this;
      return n12._root = null, n12._comparator = e22, n12.size = 0, n12;
    }
    return O7(e21, t16), e21.prototype.insert = function(t17) {
      var n12 = false;
      if (null === this._root)
        this._root = new I7(t17), n12 = true, this.size++;
      else {
        var r9 = new I7(void 0), i11 = false, o12 = false, s11 = null, a10 = r9, u10 = null, h10 = this._root;
        for (a10.right = this._root; ; ) {
          if (null === h10 ? (h10 = new I7(t17), u10.set_child(i11, h10), n12 = true, this.size++) : e21.is_red(h10.left) && e21.is_red(h10.right) && (h10.red = true, h10.left.red = false, h10.right.red = false), e21.is_red(h10) && e21.is_red(u10)) {
            var c10 = a10.right === s11;
            h10 === u10.get_child(o12) ? a10.set_child(c10, e21.single_rotate(s11, !o12)) : a10.set_child(c10, e21.double_rotate(s11, !o12));
          }
          var p10 = this._comparator(h10.data, t17);
          if (0 === p10)
            break;
          o12 = i11, i11 = p10 < 0, null !== s11 && (a10 = s11), s11 = u10, u10 = h10, h10 = h10.get_child(i11);
        }
        this._root = r9.right;
      }
      return this._root.red = false, n12;
    }, e21.prototype.remove = function(t17) {
      if (null === this._root)
        return false;
      var n12 = new I7(void 0), r9 = n12;
      r9.right = this._root;
      for (var i11 = null, o12 = null, s11 = null, a10 = true; null !== r9.get_child(a10); ) {
        var u10 = a10;
        o12 = i11, i11 = r9, r9 = r9.get_child(a10);
        var h10 = this._comparator(t17, r9.data);
        if (a10 = h10 > 0, 0 === h10 && (s11 = r9), !e21.is_red(r9) && !e21.is_red(r9.get_child(a10))) {
          if (e21.is_red(r9.get_child(!a10))) {
            var c10 = e21.single_rotate(r9, a10);
            i11.set_child(u10, c10), i11 = c10;
          } else if (!e21.is_red(r9.get_child(!a10))) {
            var p10 = i11.get_child(!u10);
            if (null !== p10)
              if (e21.is_red(p10.get_child(!u10)) || e21.is_red(p10.get_child(u10))) {
                var f11 = o12.right === i11;
                e21.is_red(p10.get_child(u10)) ? o12.set_child(f11, e21.double_rotate(i11, u10)) : e21.is_red(p10.get_child(!u10)) && o12.set_child(f11, e21.single_rotate(i11, u10));
                var l11 = o12.get_child(f11);
                l11.red = true, r9.red = true, l11.left.red = false, l11.right.red = false;
              } else
                i11.red = false, p10.red = true, r9.red = true;
          }
        }
      }
      return null !== s11 && (s11.data = r9.data, i11.set_child(i11.right === r9, r9.get_child(null === r9.left)), this.size--), this._root = n12.right, null !== this._root && (this._root.red = false), null !== s11;
    }, e21.is_red = function(t17) {
      return null !== t17 && t17.red;
    }, e21.single_rotate = function(t17, e22) {
      var n12 = t17.get_child(!e22);
      return t17.set_child(!e22, n12.get_child(e22)), n12.set_child(e22, t17), t17.red = true, n12.red = false, n12;
    }, e21.double_rotate = function(t17, n12) {
      return t17.set_child(!n12, e21.single_rotate(t17.get_child(!n12), !n12)), e21.single_rotate(t17, n12);
    }, e21;
  }(C6);
  S7.RBTree = T7;
  var G6 = t11 && t11.__extends || function() {
    var t16 = function(e21, n12) {
      return t16 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(t17, e22) {
        t17.__proto__ = e22;
      } || function(t17, e22) {
        for (var n13 in e22)
          e22.hasOwnProperty(n13) && (t17[n13] = e22[n13]);
      }, t16(e21, n12);
    };
    return function(e21, n12) {
      function r9() {
        this.constructor = e21;
      }
      t16(e21, n12), e21.prototype = null === n12 ? Object.create(n12) : (r9.prototype = n12.prototype, new r9());
    };
  }();
  Object.defineProperty(m8, "__esModule", { value: true });
  var V6 = b7;
  var D7 = S7;
  function j7(t16) {
    return t16.bounds = void 0 !== t16.leaves ? t16.leaves.reduce(function(t17, e21) {
      return e21.bounds.union(t17);
    }, B6.empty()) : B6.empty(), void 0 !== t16.groups && (t16.bounds = t16.groups.reduce(function(t17, e21) {
      return j7(e21).union(t17);
    }, t16.bounds)), t16.bounds = t16.bounds.inflate(t16.padding), t16.bounds;
  }
  m8.computeGroupBounds = j7;
  var B6 = function() {
    function t16(t17, e21, n12, r9) {
      this.x = t17, this.X = e21, this.y = n12, this.Y = r9;
    }
    return t16.empty = function() {
      return new t16(Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY, Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY);
    }, t16.prototype.cx = function() {
      return (this.x + this.X) / 2;
    }, t16.prototype.cy = function() {
      return (this.y + this.Y) / 2;
    }, t16.prototype.overlapX = function(t17) {
      var e21 = this.cx(), n12 = t17.cx();
      return e21 <= n12 && t17.x < this.X ? this.X - t17.x : n12 <= e21 && this.x < t17.X ? t17.X - this.x : 0;
    }, t16.prototype.overlapY = function(t17) {
      var e21 = this.cy(), n12 = t17.cy();
      return e21 <= n12 && t17.y < this.Y ? this.Y - t17.y : n12 <= e21 && this.y < t17.Y ? t17.Y - this.y : 0;
    }, t16.prototype.setXCentre = function(t17) {
      var e21 = t17 - this.cx();
      this.x += e21, this.X += e21;
    }, t16.prototype.setYCentre = function(t17) {
      var e21 = t17 - this.cy();
      this.y += e21, this.Y += e21;
    }, t16.prototype.width = function() {
      return this.X - this.x;
    }, t16.prototype.height = function() {
      return this.Y - this.y;
    }, t16.prototype.union = function(e21) {
      return new t16(Math.min(this.x, e21.x), Math.max(this.X, e21.X), Math.min(this.y, e21.y), Math.max(this.Y, e21.Y));
    }, t16.prototype.lineIntersections = function(e21, n12, r9, i11) {
      for (var o12 = [[this.x, this.y, this.X, this.y], [this.X, this.y, this.X, this.Y], [this.X, this.Y, this.x, this.Y], [this.x, this.Y, this.x, this.y]], s11 = [], a10 = 0; a10 < 4; ++a10) {
        var u10 = t16.lineIntersection(e21, n12, r9, i11, o12[a10][0], o12[a10][1], o12[a10][2], o12[a10][3]);
        null !== u10 && s11.push({ x: u10.x, y: u10.y });
      }
      return s11;
    }, t16.prototype.rayIntersection = function(t17, e21) {
      var n12 = this.lineIntersections(this.cx(), this.cy(), t17, e21);
      return n12.length > 0 ? n12[0] : null;
    }, t16.prototype.vertices = function() {
      return [{ x: this.x, y: this.y }, { x: this.X, y: this.y }, { x: this.X, y: this.Y }, { x: this.x, y: this.Y }];
    }, t16.lineIntersection = function(t17, e21, n12, r9, i11, o12, s11, a10) {
      var u10 = n12 - t17, h10 = s11 - i11, c10 = r9 - e21, p10 = a10 - o12, f11 = p10 * u10 - h10 * c10;
      if (0 == f11)
        return null;
      var l11 = t17 - i11, d12 = e21 - o12, g9 = (h10 * d12 - p10 * l11) / f11, v12 = (u10 * d12 - c10 * l11) / f11;
      return g9 >= 0 && g9 <= 1 && v12 >= 0 && v12 <= 1 ? { x: t17 + g9 * u10, y: e21 + g9 * c10 } : null;
    }, t16.prototype.inflate = function(e21) {
      return new t16(this.x - e21, this.X + e21, this.y - e21, this.Y + e21);
    }, t16;
  }();
  m8.Rectangle = B6, m8.makeEdgeBetween = function(t16, e21, n12) {
    var r9 = t16.rayIntersection(e21.cx(), e21.cy()) || { x: t16.cx(), y: t16.cy() }, i11 = e21.rayIntersection(t16.cx(), t16.cy()) || { x: e21.cx(), y: e21.cy() }, o12 = i11.x - r9.x, s11 = i11.y - r9.y, a10 = Math.sqrt(o12 * o12 + s11 * s11), u10 = a10 - n12;
    return { sourceIntersection: r9, targetIntersection: i11, arrowStart: { x: r9.x + u10 * o12 / a10, y: r9.y + u10 * s11 / a10 } };
  }, m8.makeEdgeTo = function(t16, e21, n12) {
    var r9 = e21.rayIntersection(t16.x, t16.y);
    r9 || (r9 = { x: e21.cx(), y: e21.cy() });
    var i11 = r9.x - t16.x, o12 = r9.y - t16.y, s11 = Math.sqrt(i11 * i11 + o12 * o12);
    return { x: r9.x - n12 * i11 / s11, y: r9.y - n12 * o12 / s11 };
  };
  var R5 = function(t16, e21, n12) {
    this.v = t16, this.r = e21, this.pos = n12, this.prev = Y5(), this.next = Y5();
  };
  var X5 = function(t16, e21, n12) {
    this.isOpen = t16, this.v = e21, this.pos = n12;
  };
  function z6(t16, e21) {
    return t16.pos > e21.pos ? 1 : t16.pos < e21.pos || t16.isOpen ? -1 : e21.isOpen ? 1 : 0;
  }
  function Y5() {
    return new D7.RBTree(function(t16, e21) {
      return t16.pos - e21.pos;
    });
  }
  var q6 = { getCentre: function(t16) {
    return t16.cx();
  }, getOpen: function(t16) {
    return t16.y;
  }, getClose: function(t16) {
    return t16.Y;
  }, getSize: function(t16) {
    return t16.width();
  }, makeRect: function(t16, e21, n12, r9) {
    return new B6(n12 - r9 / 2, n12 + r9 / 2, t16, e21);
  }, findNeighbours: function(t16, e21) {
    var n12 = function(n13, r9) {
      for (var i11, o12 = e21.findIter(t16); null !== (i11 = o12[n13]()); ) {
        var s11 = i11.r.overlapX(t16.r);
        if ((s11 <= 0 || s11 <= i11.r.overlapY(t16.r)) && (t16[n13].insert(i11), i11[r9].insert(t16)), s11 <= 0)
          break;
      }
    };
    n12("next", "prev"), n12("prev", "next");
  } };
  var F7 = { getCentre: function(t16) {
    return t16.cy();
  }, getOpen: function(t16) {
    return t16.x;
  }, getClose: function(t16) {
    return t16.X;
  }, getSize: function(t16) {
    return t16.height();
  }, makeRect: function(t16, e21, n12, r9) {
    return new B6(t16, e21, n12 - r9 / 2, n12 + r9 / 2);
  }, findNeighbours: function(t16, e21) {
    var n12 = function(n13, r9) {
      var i11 = e21.findIter(t16)[n13]();
      null !== i11 && i11.r.overlapX(t16.r) > 0 && (t16[n13].insert(i11), i11[r9].insert(t16));
    };
    n12("next", "prev"), n12("prev", "next");
  } };
  function H5(t16, e21, n12, r9) {
    void 0 === r9 && (r9 = false);
    var i11 = t16.padding, o12 = void 0 !== t16.groups ? t16.groups.length : 0, s11 = void 0 !== t16.leaves ? t16.leaves.length : 0, a10 = o12 ? t16.groups.reduce(function(t17, r10) {
      return t17.concat(H5(r10, e21, n12, true));
    }, []) : [], u10 = (r9 ? 2 : 0) + s11 + o12, h10 = new Array(u10), c10 = new Array(u10), p10 = 0, f11 = function(t17, e22) {
      c10[p10] = t17, h10[p10++] = e22;
    };
    if (r9) {
      var l11 = t16.bounds, d12 = e21.getCentre(l11), g9 = e21.getSize(l11) / 2, v12 = e21.getOpen(l11), y10 = e21.getClose(l11), _7 = d12 - g9 + i11 / 2, x10 = d12 + g9 - i11 / 2;
      t16.minVar.desiredPosition = _7, f11(e21.makeRect(v12, y10, _7, i11), t16.minVar), t16.maxVar.desiredPosition = x10, f11(e21.makeRect(v12, y10, x10, i11), t16.maxVar);
    }
    s11 && t16.leaves.forEach(function(t17) {
      return f11(t17.bounds, t17.variable);
    }), o12 && t16.groups.forEach(function(t17) {
      var n13 = t17.bounds;
      f11(e21.makeRect(e21.getOpen(n13), e21.getClose(n13), e21.getCentre(n13), e21.getSize(n13)), t17.minVar);
    });
    var m12 = U6(c10, h10, e21, n12);
    return o12 && (h10.forEach(function(t17) {
      t17.cOut = [], t17.cIn = [];
    }), m12.forEach(function(t17) {
      t17.left.cOut.push(t17), t17.right.cIn.push(t17);
    }), t16.groups.forEach(function(t17) {
      var n13 = (t17.padding - e21.getSize(t17.bounds)) / 2;
      t17.minVar.cIn.forEach(function(t18) {
        return t18.gap += n13;
      }), t17.minVar.cOut.forEach(function(e22) {
        e22.left = t17.maxVar, e22.gap += n13;
      });
    })), a10.concat(m12);
  }
  function U6(t16, e21, n12, r9) {
    var i11, o12 = t16.length, s11 = 2 * o12;
    console.assert(e21.length >= o12);
    var a10 = new Array(s11);
    for (i11 = 0; i11 < o12; ++i11) {
      var u10 = t16[i11], h10 = new R5(e21[i11], u10, n12.getCentre(u10));
      a10[i11] = new X5(true, h10, n12.getOpen(u10)), a10[i11 + o12] = new X5(false, h10, n12.getClose(u10));
    }
    a10.sort(z6);
    var c10 = new Array(), p10 = Y5();
    for (i11 = 0; i11 < s11; ++i11) {
      var f11 = a10[i11];
      h10 = f11.v;
      if (f11.isOpen)
        p10.insert(h10), n12.findNeighbours(h10, p10);
      else {
        p10.remove(h10);
        var l11 = function(t17, e22) {
          var i12 = (n12.getSize(t17.r) + n12.getSize(e22.r)) / 2 + r9;
          c10.push(new V6.Constraint(t17.v, e22.v, i12));
        }, d12 = function(t17, e22, n13) {
          for (var r10, i12 = h10[t17].iterator(); null !== (r10 = i12[t17]()); )
            n13(r10, h10), r10[e22].remove(h10);
        };
        d12("prev", "next", function(t17, e22) {
          return l11(t17, e22);
        }), d12("next", "prev", function(t17, e22) {
          return l11(e22, t17);
        });
      }
    }
    return console.assert(0 === p10.size), c10;
  }
  function W6(t16, e21) {
    return U6(t16, e21, q6, 1e-6);
  }
  function K5(t16, e21) {
    return U6(t16, e21, F7, 1e-6);
  }
  function Q5(t16) {
    return H5(t16, q6, 1e-6);
  }
  function Z5(t16) {
    return H5(t16, F7, 1e-6);
  }
  m8.generateXConstraints = W6, m8.generateYConstraints = K5, m8.generateXGroupConstraints = Q5, m8.generateYGroupConstraints = Z5, m8.removeOverlaps = function(t16) {
    var e21 = t16.map(function(t17) {
      return new V6.Variable(t17.cx());
    }), n12 = W6(t16, e21), r9 = new V6.Solver(e21, n12);
    r9.solve(), e21.forEach(function(e22, n13) {
      return t16[n13].setXCentre(e22.position());
    }), e21 = t16.map(function(t17) {
      return new V6.Variable(t17.cy());
    }), n12 = K5(t16, e21), (r9 = new V6.Solver(e21, n12)).solve(), e21.forEach(function(e22, n13) {
      return t16[n13].setYCentre(e22.position());
    });
  };
  var J5 = function(t16) {
    function e21(e22, n12) {
      var r9 = t16.call(this, 0, n12) || this;
      return r9.index = e22, r9;
    }
    return G6(e21, t16), e21;
  }(V6.Variable);
  m8.IndexedVariable = J5;
  var $7 = function() {
    function t16(t17, e21, n12, r9, i11) {
      var o12 = this;
      if (void 0 === n12 && (n12 = null), void 0 === r9 && (r9 = null), void 0 === i11 && (i11 = false), this.nodes = t17, this.groups = e21, this.rootGroup = n12, this.avoidOverlaps = i11, this.variables = t17.map(function(t18, e22) {
        return t18.variable = new J5(e22, 1);
      }), r9 && this.createConstraints(r9), i11 && n12 && void 0 !== n12.groups) {
        t17.forEach(function(t18) {
          if (t18.width && t18.height) {
            var e22 = t18.width / 2, n13 = t18.height / 2;
            t18.bounds = new B6(t18.x - e22, t18.x + e22, t18.y - n13, t18.y + n13);
          } else
            t18.bounds = new B6(t18.x, t18.x, t18.y, t18.y);
        }), j7(n12);
        var s11 = t17.length;
        e21.forEach(function(t18) {
          o12.variables[s11] = t18.minVar = new J5(s11++, void 0 !== t18.stiffness ? t18.stiffness : 0.01), o12.variables[s11] = t18.maxVar = new J5(s11++, void 0 !== t18.stiffness ? t18.stiffness : 0.01);
        });
      }
    }
    return t16.prototype.createSeparation = function(t17) {
      return new V6.Constraint(this.nodes[t17.left].variable, this.nodes[t17.right].variable, t17.gap, void 0 !== t17.equality && t17.equality);
    }, t16.prototype.makeFeasible = function(t17) {
      var e21 = this;
      if (this.avoidOverlaps) {
        var n12 = "x", r9 = "width";
        "x" === t17.axis && (n12 = "y", r9 = "height");
        var i11 = t17.offsets.map(function(t18) {
          return e21.nodes[t18.node];
        }).sort(function(t18, e22) {
          return t18[n12] - e22[n12];
        }), o12 = null;
        i11.forEach(function(t18) {
          if (o12) {
            var e22 = o12[n12] + o12[r9];
            e22 > t18[n12] && (t18[n12] = e22);
          }
          o12 = t18;
        });
      }
    }, t16.prototype.createAlignment = function(t17) {
      var e21 = this, n12 = this.nodes[t17.offsets[0].node].variable;
      this.makeFeasible(t17);
      var r9 = "x" === t17.axis ? this.xConstraints : this.yConstraints;
      t17.offsets.slice(1).forEach(function(t18) {
        var i11 = e21.nodes[t18.node].variable;
        r9.push(new V6.Constraint(n12, i11, t18.offset, true));
      });
    }, t16.prototype.createConstraints = function(t17) {
      var e21 = this, n12 = function(t18) {
        return void 0 === t18.type || "separation" === t18.type;
      };
      this.xConstraints = t17.filter(function(t18) {
        return "x" === t18.axis && n12(t18);
      }).map(function(t18) {
        return e21.createSeparation(t18);
      }), this.yConstraints = t17.filter(function(t18) {
        return "y" === t18.axis && n12(t18);
      }).map(function(t18) {
        return e21.createSeparation(t18);
      }), t17.filter(function(t18) {
        return "alignment" === t18.type;
      }).forEach(function(t18) {
        return e21.createAlignment(t18);
      });
    }, t16.prototype.setupVariablesAndBounds = function(t17, e21, n12, r9) {
      this.nodes.forEach(function(i11, o12) {
        i11.fixed ? (i11.variable.weight = i11.fixedWeight ? i11.fixedWeight : 1e3, n12[o12] = r9(i11)) : i11.variable.weight = 1;
        var s11 = (i11.width || 0) / 2, a10 = (i11.height || 0) / 2, u10 = t17[o12], h10 = e21[o12];
        i11.bounds = new B6(u10 - s11, u10 + s11, h10 - a10, h10 + a10);
      });
    }, t16.prototype.xProject = function(t17, e21, n12) {
      (this.rootGroup || this.avoidOverlaps || this.xConstraints) && this.project(t17, e21, t17, n12, function(t18) {
        return t18.px;
      }, this.xConstraints, Q5, function(t18) {
        return t18.bounds.setXCentre(n12[t18.variable.index] = t18.variable.position());
      }, function(t18) {
        var e22 = n12[t18.minVar.index] = t18.minVar.position(), r9 = n12[t18.maxVar.index] = t18.maxVar.position(), i11 = t18.padding / 2;
        t18.bounds.x = e22 - i11, t18.bounds.X = r9 + i11;
      });
    }, t16.prototype.yProject = function(t17, e21, n12) {
      (this.rootGroup || this.yConstraints) && this.project(t17, e21, e21, n12, function(t18) {
        return t18.py;
      }, this.yConstraints, Z5, function(t18) {
        return t18.bounds.setYCentre(n12[t18.variable.index] = t18.variable.position());
      }, function(t18) {
        var e22 = n12[t18.minVar.index] = t18.minVar.position(), r9 = n12[t18.maxVar.index] = t18.maxVar.position(), i11 = t18.padding / 2;
        t18.bounds.y = e22 - i11, t18.bounds.Y = r9 + i11;
      });
    }, t16.prototype.projectFunctions = function() {
      var t17 = this;
      return [function(e21, n12, r9) {
        return t17.xProject(e21, n12, r9);
      }, function(e21, n12, r9) {
        return t17.yProject(e21, n12, r9);
      }];
    }, t16.prototype.project = function(t17, e21, n12, r9, i11, o12, s11, a10, u10) {
      this.setupVariablesAndBounds(t17, e21, r9, i11), this.rootGroup && this.avoidOverlaps && (j7(this.rootGroup), o12 = o12.concat(s11(this.rootGroup))), this.solve(this.variables, o12, n12, r9), this.nodes.forEach(a10), this.rootGroup && this.avoidOverlaps && (this.groups.forEach(u10), j7(this.rootGroup));
    }, t16.prototype.solve = function(t17, e21, n12, r9) {
      var i11 = new V6.Solver(t17, e21);
      i11.setStartingPositions(n12), i11.setDesiredPositions(r9), i11.solve();
    }, t16;
  }();
  m8.Projection = $7;
  var tt5 = {};
  var et5 = {};
  Object.defineProperty(et5, "__esModule", { value: true });
  var nt5 = function() {
    function t16(t17) {
      this.elem = t17, this.subheaps = [];
    }
    return t16.prototype.toString = function(t17) {
      for (var e21 = "", n12 = false, r9 = 0; r9 < this.subheaps.length; ++r9) {
        var i11 = this.subheaps[r9];
        i11.elem ? (n12 && (e21 += ","), e21 += i11.toString(t17), n12 = true) : n12 = false;
      }
      return "" !== e21 && (e21 = "(" + e21 + ")"), (this.elem ? t17(this.elem) : "") + e21;
    }, t16.prototype.forEach = function(t17) {
      this.empty() || (t17(this.elem, this), this.subheaps.forEach(function(e21) {
        return e21.forEach(t17);
      }));
    }, t16.prototype.count = function() {
      return this.empty() ? 0 : 1 + this.subheaps.reduce(function(t17, e21) {
        return t17 + e21.count();
      }, 0);
    }, t16.prototype.min = function() {
      return this.elem;
    }, t16.prototype.empty = function() {
      return null == this.elem;
    }, t16.prototype.contains = function(t17) {
      if (this === t17)
        return true;
      for (var e21 = 0; e21 < this.subheaps.length; e21++)
        if (this.subheaps[e21].contains(t17))
          return true;
      return false;
    }, t16.prototype.isHeap = function(t17) {
      var e21 = this;
      return this.subheaps.every(function(n12) {
        return t17(e21.elem, n12.elem) && n12.isHeap(t17);
      });
    }, t16.prototype.insert = function(e21, n12) {
      return this.merge(new t16(e21), n12);
    }, t16.prototype.merge = function(t17, e21) {
      return this.empty() ? t17 : t17.empty() ? this : e21(this.elem, t17.elem) ? (this.subheaps.push(t17), this) : (t17.subheaps.push(this), t17);
    }, t16.prototype.removeMin = function(t17) {
      return this.empty() ? null : this.mergePairs(t17);
    }, t16.prototype.mergePairs = function(e21) {
      if (0 == this.subheaps.length)
        return new t16(null);
      if (1 == this.subheaps.length)
        return this.subheaps[0];
      var n12 = this.subheaps.pop().merge(this.subheaps.pop(), e21), r9 = this.mergePairs(e21);
      return n12.merge(r9, e21);
    }, t16.prototype.decreaseKey = function(e21, n12, r9, i11) {
      var o12 = e21.removeMin(i11);
      e21.elem = o12.elem, e21.subheaps = o12.subheaps, null !== r9 && null !== o12.elem && r9(e21.elem, e21);
      var s11 = new t16(n12);
      return null !== r9 && r9(n12, s11), this.merge(s11, i11);
    }, t16;
  }();
  et5.PairingHeap = nt5;
  var rt5 = function() {
    function t16(t17) {
      this.lessThan = t17;
    }
    return t16.prototype.top = function() {
      return this.empty() ? null : this.root.elem;
    }, t16.prototype.push = function() {
      for (var t17, e21 = [], n12 = 0; n12 < arguments.length; n12++)
        e21[n12] = arguments[n12];
      for (var r9, i11 = 0; r9 = e21[i11]; ++i11)
        t17 = new nt5(r9), this.root = this.empty() ? t17 : this.root.merge(t17, this.lessThan);
      return t17;
    }, t16.prototype.empty = function() {
      return !this.root || !this.root.elem;
    }, t16.prototype.isHeap = function() {
      return this.root.isHeap(this.lessThan);
    }, t16.prototype.forEach = function(t17) {
      this.root.forEach(t17);
    }, t16.prototype.pop = function() {
      if (this.empty())
        return null;
      var t17 = this.root.min();
      return this.root = this.root.removeMin(this.lessThan), t17;
    }, t16.prototype.reduceKey = function(t17, e21, n12) {
      void 0 === n12 && (n12 = null), this.root = this.root.decreaseKey(t17, e21, n12, this.lessThan);
    }, t16.prototype.toString = function(t17) {
      return this.root.toString(t17);
    }, t16.prototype.count = function() {
      return this.root.count();
    }, t16;
  }();
  et5.PriorityQueue = rt5, Object.defineProperty(tt5, "__esModule", { value: true });
  var it5 = et5;
  var ot5 = function(t16, e21) {
    this.id = t16, this.distance = e21;
  };
  var st5 = function(t16) {
    this.id = t16, this.neighbours = [];
  };
  var at5 = function(t16, e21, n12) {
    this.node = t16, this.prev = e21, this.d = n12;
  };
  var ut5 = function() {
    function t16(t17, e21, n12, r9, i11) {
      this.n = t17, this.es = e21, this.neighbours = new Array(this.n);
      for (var o12 = this.n; o12--; )
        this.neighbours[o12] = new st5(o12);
      for (o12 = this.es.length; o12--; ) {
        var s11 = this.es[o12], a10 = n12(s11), u10 = r9(s11), h10 = i11(s11);
        this.neighbours[a10].neighbours.push(new ot5(u10, h10)), this.neighbours[u10].neighbours.push(new ot5(a10, h10));
      }
    }
    return t16.prototype.DistanceMatrix = function() {
      for (var t17 = new Array(this.n), e21 = 0; e21 < this.n; ++e21)
        t17[e21] = this.dijkstraNeighbours(e21);
      return t17;
    }, t16.prototype.DistancesFromNode = function(t17) {
      return this.dijkstraNeighbours(t17);
    }, t16.prototype.PathFromNodeToNode = function(t17, e21) {
      return this.dijkstraNeighbours(t17, e21);
    }, t16.prototype.PathFromNodeToNodeWithPrevCost = function(t17, e21, n12) {
      var r9 = new it5.PriorityQueue(function(t18, e22) {
        return t18.d <= e22.d;
      }), i11 = this.neighbours[t17], o12 = new at5(i11, null, 0), s11 = {};
      for (r9.push(o12); !r9.empty() && (i11 = (o12 = r9.pop()).node).id !== e21; )
        for (var a10 = i11.neighbours.length; a10--; ) {
          var u10 = i11.neighbours[a10], h10 = this.neighbours[u10.id];
          if (!o12.prev || h10.id !== o12.prev.node.id) {
            var c10 = h10.id + "," + i11.id;
            if (!(c10 in s11 && s11[c10] <= o12.d)) {
              var p10 = o12.prev ? n12(o12.prev.node.id, i11.id, h10.id) : 0, f11 = o12.d + u10.distance + p10;
              s11[c10] = f11, r9.push(new at5(h10, o12, f11));
            }
          }
        }
      for (var l11 = []; o12.prev; )
        o12 = o12.prev, l11.push(o12.node.id);
      return l11;
    }, t16.prototype.dijkstraNeighbours = function(t17, e21) {
      void 0 === e21 && (e21 = -1);
      for (var n12 = new it5.PriorityQueue(function(t18, e22) {
        return t18.d <= e22.d;
      }), r9 = this.neighbours.length, i11 = new Array(r9); r9--; ) {
        var o12 = this.neighbours[r9];
        o12.d = r9 === t17 ? 0 : Number.POSITIVE_INFINITY, o12.q = n12.push(o12);
      }
      for (; !n12.empty(); ) {
        var s11 = n12.pop();
        if (i11[s11.id] = s11.d, s11.id === e21) {
          for (var a10 = [], u10 = s11; void 0 !== u10.prev; )
            a10.push(u10.prev.id), u10 = u10.prev;
          return a10;
        }
        for (r9 = s11.neighbours.length; r9--; ) {
          var h10 = s11.neighbours[r9], c10 = (u10 = this.neighbours[h10.id], s11.d + h10.distance);
          s11.d !== Number.MAX_VALUE && u10.d > c10 && (u10.d = c10, u10.prev = s11, n12.reduceKey(u10.q, u10, function(t18, e22) {
            return t18.q = e22;
          }));
        }
      }
      return i11;
    }, t16;
  }();
  tt5.Calculator = ut5;
  var ht5 = {};
  var ct5 = t11 && t11.__extends || function() {
    var t16 = function(e21, n12) {
      return t16 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(t17, e22) {
        t17.__proto__ = e22;
      } || function(t17, e22) {
        for (var n13 in e22)
          e22.hasOwnProperty(n13) && (t17[n13] = e22[n13]);
      }, t16(e21, n12);
    };
    return function(e21, n12) {
      function r9() {
        this.constructor = e21;
      }
      t16(e21, n12), e21.prototype = null === n12 ? Object.create(n12) : (r9.prototype = n12.prototype, new r9());
    };
  }();
  Object.defineProperty(ht5, "__esModule", { value: true });
  var pt5 = m8;
  var ft5 = function() {
  };
  ht5.Point = ft5;
  var lt5 = function(t16, e21, n12, r9) {
    this.x1 = t16, this.y1 = e21, this.x2 = n12, this.y2 = r9;
  };
  ht5.LineSegment = lt5;
  var dt5 = function(t16) {
    function e21() {
      return null !== t16 && t16.apply(this, arguments) || this;
    }
    return ct5(e21, t16), e21;
  }(ft5);
  function gt5(t16, e21, n12) {
    return (e21.x - t16.x) * (n12.y - t16.y) - (n12.x - t16.x) * (e21.y - t16.y);
  }
  function vt5(t16, e21, n12) {
    return gt5(t16, e21, n12) > 0;
  }
  function yt5(t16, e21, n12) {
    return gt5(t16, e21, n12) < 0;
  }
  function _t5(t16, e21) {
    var n12, r9, i11, o12, s11 = e21.length - 1;
    if (yt5(t16, e21[1], e21[0]) && !vt5(t16, e21[s11 - 1], e21[0]))
      return 0;
    for (n12 = 0, r9 = s11; ; ) {
      if (r9 - n12 == 1)
        return vt5(t16, e21[n12], e21[r9]) ? n12 : r9;
      if ((o12 = yt5(t16, e21[(i11 = Math.floor((n12 + r9) / 2)) + 1], e21[i11])) && !vt5(t16, e21[i11 - 1], e21[i11]))
        return i11;
      vt5(t16, e21[n12 + 1], e21[n12]) ? o12 || vt5(t16, e21[n12], e21[i11]) ? r9 = i11 : n12 = i11 : o12 && yt5(t16, e21[n12], e21[i11]) ? r9 = i11 : n12 = i11;
    }
  }
  function xt5(t16, e21) {
    var n12, r9, i11, o12, s11 = e21.length - 1;
    if (vt5(t16, e21[s11 - 1], e21[0]) && !yt5(t16, e21[1], e21[0]))
      return 0;
    for (n12 = 0, r9 = s11; ; ) {
      if (r9 - n12 == 1)
        return yt5(t16, e21[n12], e21[r9]) ? n12 : r9;
      if (o12 = yt5(t16, e21[(i11 = Math.floor((n12 + r9) / 2)) + 1], e21[i11]), vt5(t16, e21[i11 - 1], e21[i11]) && !o12)
        return i11;
      yt5(t16, e21[n12 + 1], e21[n12]) ? o12 ? yt5(t16, e21[n12], e21[i11]) ? r9 = i11 : n12 = i11 : r9 = i11 : o12 ? n12 = i11 : vt5(t16, e21[n12], e21[i11]) ? r9 = i11 : n12 = i11;
    }
  }
  function mt5(t16, e21, n12, r9, i11, o12) {
    var s11, a10;
    a10 = r9(t16[s11 = n12(e21[0], t16)], e21);
    for (var u10 = false; !u10; ) {
      for (u10 = true; s11 === t16.length - 1 && (s11 = 0), !i11(e21[a10], t16[s11], t16[s11 + 1]); )
        ++s11;
      for (; 0 === a10 && (a10 = e21.length - 1), !o12(t16[s11], e21[a10], e21[a10 - 1]); )
        --a10, u10 = false;
    }
    return { t1: s11, t2: a10 };
  }
  function bt5(t16, e21) {
    return mt5(t16, e21, _t5, xt5, vt5, yt5);
  }
  ht5.PolyPoint = dt5, ht5.isLeft = gt5, ht5.ConvexHull = function(t16) {
    var e21, n12 = t16.slice(0).sort(function(t17, e22) {
      return t17.x !== e22.x ? e22.x - t17.x : e22.y - t17.y;
    }), r9 = t16.length, i11 = n12[0].x;
    for (e21 = 1; e21 < r9 && n12[e21].x === i11; ++e21)
      ;
    var o12 = e21 - 1, s11 = [];
    if (s11.push(n12[0]), o12 === r9 - 1)
      n12[o12].y !== n12[0].y && s11.push(n12[o12]);
    else {
      var a10, u10 = r9 - 1, h10 = n12[r9 - 1].x;
      for (e21 = r9 - 2; e21 >= 0 && n12[e21].x === h10; e21--)
        ;
      for (a10 = e21 + 1, e21 = o12; ++e21 <= a10; )
        if (!(gt5(n12[0], n12[a10], n12[e21]) >= 0 && e21 < a10)) {
          for (; s11.length > 1 && !(gt5(s11[s11.length - 2], s11[s11.length - 1], n12[e21]) > 0); )
            s11.length -= 1;
          0 != e21 && s11.push(n12[e21]);
        }
      u10 != a10 && s11.push(n12[u10]);
      var c10 = s11.length;
      for (e21 = a10; --e21 >= o12; )
        if (!(gt5(n12[u10], n12[o12], n12[e21]) >= 0 && e21 > o12)) {
          for (; s11.length > c10 && !(gt5(s11[s11.length - 2], s11[s11.length - 1], n12[e21]) > 0); )
            s11.length -= 1;
          0 != e21 && s11.push(n12[e21]);
        }
    }
    return s11;
  }, ht5.clockwiseRadialSweep = function(t16, e21, n12) {
    e21.slice(0).sort(function(e22, n13) {
      return Math.atan2(e22.y - t16.y, e22.x - t16.x) - Math.atan2(n13.y - t16.y, n13.x - t16.x);
    }).forEach(n12);
  }, ht5.tangent_PolyPolyC = mt5, ht5.LRtangent_PolyPolyC = function(t16, e21) {
    var n12 = bt5(e21, t16);
    return { t1: n12.t2, t2: n12.t1 };
  }, ht5.RLtangent_PolyPolyC = bt5, ht5.LLtangent_PolyPolyC = function(t16, e21) {
    return mt5(t16, e21, xt5, xt5, yt5, yt5);
  }, ht5.RRtangent_PolyPolyC = function(t16, e21) {
    return mt5(t16, e21, _t5, _t5, vt5, vt5);
  };
  var kt5 = function(t16, e21) {
    this.t1 = t16, this.t2 = e21;
  };
  ht5.BiTangent = kt5;
  var wt5 = function() {
  };
  ht5.BiTangents = wt5;
  var Et5 = function(t16) {
    function e21() {
      return null !== t16 && t16.apply(this, arguments) || this;
    }
    return ct5(e21, t16), e21;
  }(ft5);
  ht5.TVGPoint = Et5;
  var Pt5 = function(t16, e21, n12, r9) {
    this.id = t16, this.polyid = e21, this.polyvertid = n12, this.p = r9, r9.vv = this;
  };
  ht5.VisibilityVertex = Pt5;
  var Lt5 = function() {
    function t16(t17, e21) {
      this.source = t17, this.target = e21;
    }
    return t16.prototype.length = function() {
      var t17 = this.source.p.x - this.target.p.x, e21 = this.source.p.y - this.target.p.y;
      return Math.sqrt(t17 * t17 + e21 * e21);
    }, t16;
  }();
  ht5.VisibilityEdge = Lt5;
  var Mt5 = function() {
    function t16(t17, e21) {
      if (this.P = t17, this.V = [], this.E = [], e21)
        this.V = e21.V.slice(0), this.E = e21.E.slice(0);
      else {
        for (var n12 = t17.length, r9 = 0; r9 < n12; r9++) {
          for (var i11 = t17[r9], o12 = 0; o12 < i11.length; ++o12) {
            var s11 = i11[o12], a10 = new Pt5(this.V.length, r9, o12, s11);
            this.V.push(a10), o12 > 0 && this.E.push(new Lt5(i11[o12 - 1].vv, a10));
          }
          i11.length > 1 && this.E.push(new Lt5(i11[0].vv, i11[i11.length - 1].vv));
        }
        for (r9 = 0; r9 < n12 - 1; r9++) {
          var u10 = t17[r9];
          for (o12 = r9 + 1; o12 < n12; o12++) {
            var h10 = t17[o12], c10 = St5(u10, h10);
            for (var p10 in c10) {
              var f11 = c10[p10], l11 = u10[f11.t1], d12 = h10[f11.t2];
              this.addEdgeIfVisible(l11, d12, r9, o12);
            }
          }
        }
      }
    }
    return t16.prototype.addEdgeIfVisible = function(t17, e21, n12, r9) {
      this.intersectsPolys(new lt5(t17.x, t17.y, e21.x, e21.y), n12, r9) || this.E.push(new Lt5(t17.vv, e21.vv));
    }, t16.prototype.addPoint = function(t17, e21) {
      var n12, r9, i11, o12 = this.P.length;
      this.V.push(new Pt5(this.V.length, o12, 0, t17));
      for (var s11 = 0; s11 < o12; ++s11)
        if (s11 !== e21) {
          var a10 = this.P[s11], u10 = (n12 = t17, i11 = void 0, (i11 = (r9 = a10).slice(0)).push(r9[0]), { rtan: _t5(n12, i11), ltan: xt5(n12, i11) });
          this.addEdgeIfVisible(t17, a10[u10.ltan], e21, s11), this.addEdgeIfVisible(t17, a10[u10.rtan], e21, s11);
        }
      return t17.vv;
    }, t16.prototype.intersectsPolys = function(t17, e21, n12) {
      for (var r9 = 0, i11 = this.P.length; r9 < i11; ++r9)
        if (r9 != e21 && r9 != n12 && At5(t17, this.P[r9]).length > 0)
          return true;
      return false;
    }, t16;
  }();
  function At5(t16, e21) {
    for (var n12 = [], r9 = 1, i11 = e21.length; r9 < i11; ++r9) {
      var o12 = pt5.Rectangle.lineIntersection(t16.x1, t16.y1, t16.x2, t16.y2, e21[r9 - 1].x, e21[r9 - 1].y, e21[r9].x, e21[r9].y);
      o12 && n12.push(o12);
    }
    return n12;
  }
  function St5(t16, e21) {
    for (var n12 = t16.length - 1, r9 = e21.length - 1, i11 = new wt5(), o12 = 0; o12 < n12; ++o12)
      for (var s11 = 0; s11 < r9; ++s11) {
        var a10 = t16[0 == o12 ? n12 - 1 : o12 - 1], u10 = t16[o12], h10 = t16[o12 + 1], c10 = e21[0 == s11 ? r9 - 1 : s11 - 1], p10 = e21[s11], f11 = e21[s11 + 1], l11 = gt5(a10, u10, p10), d12 = gt5(u10, c10, p10), g9 = gt5(u10, p10, f11), v12 = gt5(c10, p10, u10), y10 = gt5(p10, a10, u10), _7 = gt5(p10, u10, h10);
        l11 >= 0 && d12 >= 0 && g9 < 0 && v12 >= 0 && y10 >= 0 && _7 < 0 ? i11.ll = new kt5(o12, s11) : l11 <= 0 && d12 <= 0 && g9 > 0 && v12 <= 0 && y10 <= 0 && _7 > 0 ? i11.rr = new kt5(o12, s11) : l11 <= 0 && d12 > 0 && g9 <= 0 && v12 >= 0 && y10 < 0 && _7 >= 0 ? i11.rl = new kt5(o12, s11) : l11 >= 0 && d12 < 0 && g9 >= 0 && v12 <= 0 && y10 > 0 && _7 <= 0 && (i11.lr = new kt5(o12, s11));
      }
    return i11;
  }
  function Ot5(t16, e21) {
    return !t16.every(function(t17) {
      return !function(t18, e22) {
        for (var n12 = 1, r9 = e22.length; n12 < r9; ++n12)
          if (yt5(e22[n12 - 1], e22[n12], t18))
            return false;
        return true;
      }(t17, e21);
    });
  }
  ht5.TangentVisibilityGraph = Mt5, ht5.tangents = St5, ht5.polysOverlap = function(t16, e21) {
    if (Ot5(t16, e21))
      return true;
    if (Ot5(e21, t16))
      return true;
    for (var n12 = 1, r9 = t16.length; n12 < r9; ++n12) {
      var i11 = t16[n12], o12 = t16[n12 - 1];
      if (At5(new lt5(o12.x, o12.y, i11.x, i11.y), e21).length > 0)
        return true;
    }
    return false;
  };
  var Ct5 = {};
  Object.defineProperty(Ct5, "__esModule", { value: true });
  var Nt5 = 10;
  var It5 = (1 + Math.sqrt(5)) / 2;
  var Tt5 = 1e-4;
  Ct5.applyPacking = function(t16, e21, n12, r9, i11, o12) {
    void 0 === i11 && (i11 = 1), void 0 === o12 && (o12 = true);
    var s11 = e21, a10 = n12, u10 = (i11 = void 0 !== i11 ? i11 : 1, r9 = void 0 !== r9 ? r9 : 0, 0), h10 = 0, c10 = 0, p10 = 0, f11 = [];
    function l11(t17, e22) {
      f11 = [], u10 = 0, h10 = 0, p10 = 0;
      for (var n13 = 0; n13 < t17.length; n13++) {
        d12(t17[n13], e22);
      }
      return Math.abs(u10 / h10 - i11);
    }
    function d12(t17, e22) {
      for (var n13 = void 0, r10 = 0; r10 < f11.length; r10++)
        if (f11[r10].space_left >= t17.height && f11[r10].x + f11[r10].width + t17.width + Nt5 - e22 <= Tt5) {
          n13 = f11[r10];
          break;
        }
      f11.push(t17), void 0 !== n13 ? (t17.x = n13.x + n13.width + Nt5, t17.y = n13.bottom, t17.space_left = t17.height, t17.bottom = t17.y, n13.space_left -= t17.height + Nt5, n13.bottom += t17.height + Nt5) : (t17.y = p10, p10 += t17.height + Nt5, t17.x = 0, t17.bottom = t17.y, t17.space_left = t17.height), t17.y + t17.height - h10 > -Tt5 && (h10 = t17.y + t17.height - 0), t17.x + t17.width - u10 > -Tt5 && (u10 = t17.x + t17.width - 0);
    }
    0 != t16.length && (function(t17) {
      t17.forEach(function(t18) {
        var e22, n13, i12, o13, s12;
        e22 = t18, n13 = Number.MAX_VALUE, i12 = Number.MAX_VALUE, o13 = 0, s12 = 0, e22.array.forEach(function(t19) {
          var e23 = void 0 !== t19.width ? t19.width : r9, a11 = void 0 !== t19.height ? t19.height : r9;
          e23 /= 2, a11 /= 2, o13 = Math.max(t19.x + e23, o13), n13 = Math.min(t19.x - e23, n13), s12 = Math.max(t19.y + a11, s12), i12 = Math.min(t19.y - a11, i12);
        }), e22.width = o13 - n13, e22.height = s12 - i12;
      });
    }(t16), function(t17) {
      var e22 = Number.POSITIVE_INFINITY, n13 = 0;
      t17.sort(function(t18, e23) {
        return e23.height - t18.height;
      }), c10 = t17.reduce(function(t18, e23) {
        return t18.width < e23.width ? t18.width : e23.width;
      });
      var r10 = f12 = c10, i12 = d13 = function(t18) {
        var e23 = 0;
        return t18.forEach(function(t19) {
          return e23 += t19.width + Nt5;
        }), e23;
      }(t17), o13 = 0, s12 = Number.MAX_VALUE, a11 = Number.MAX_VALUE, u11 = -1, h11 = Number.MAX_VALUE, p11 = Number.MAX_VALUE;
      for (; h11 > c10 || p11 > Tt5; ) {
        if (1 != u11) {
          var f12 = i12 - (i12 - r10) / It5;
          s12 = l11(t17, f12);
        }
        if (0 != u11) {
          var d13 = r10 + (i12 - r10) / It5;
          a11 = l11(t17, d13);
        }
        if (h11 = Math.abs(f12 - d13), p11 = Math.abs(s12 - a11), s12 < e22 && (e22 = s12, n13 = f12), a11 < e22 && (e22 = a11, n13 = d13), s12 > a11 ? (r10 = f12, f12 = d13, s12 = a11, u11 = 1) : (i12 = d13, d13 = f12, a11 = s12, u11 = 0), o13++ > 100)
          break;
      }
      l11(t17, n13);
    }(t16), o12 && function(t17) {
      t17.forEach(function(t18) {
        var e22 = { x: 0, y: 0 };
        t18.array.forEach(function(t19) {
          e22.x += t19.x, e22.y += t19.y;
        }), e22.x /= t18.array.length, e22.y /= t18.array.length;
        var n13 = { x: e22.x - t18.width / 2, y: e22.y - t18.height / 2 }, r10 = { x: t18.x - n13.x + s11 / 2 - u10 / 2, y: t18.y - n13.y + a10 / 2 - h10 / 2 };
        t18.array.forEach(function(t19) {
          t19.x += r10.x, t19.y += r10.y;
        });
      });
    }(t16));
  }, Ct5.separateGraphs = function(t16, e21) {
    for (var n12 = {}, r9 = {}, i11 = [], o12 = 0, s11 = 0; s11 < e21.length; s11++) {
      var a10 = e21[s11], u10 = a10.source, h10 = a10.target;
      r9[u10.index] ? r9[u10.index].push(h10) : r9[u10.index] = [h10], r9[h10.index] ? r9[h10.index].push(u10) : r9[h10.index] = [u10];
    }
    for (s11 = 0; s11 < t16.length; s11++) {
      var c10 = t16[s11];
      n12[c10.index] || p10(c10, true);
    }
    function p10(t17, e22) {
      if (void 0 === n12[t17.index]) {
        e22 && (o12++, i11.push({ array: [] })), n12[t17.index] = o12, i11[o12 - 1].array.push(t17);
        var s12 = r9[t17.index];
        if (s12)
          for (var a11 = 0; a11 < s12.length; a11++)
            p10(s12[a11], false);
      }
    }
    return i11;
  }, function(t16) {
    Object.defineProperty(t16, "__esModule", { value: true });
    var e21, n12 = i7, r9 = p7, o12 = v7, s11 = m8, a10 = tt5, u10 = ht5, h10 = Ct5;
    function c10(t17) {
      return void 0 !== t17.leaves || void 0 !== t17.groups;
    }
    !function(t17) {
      t17[t17.start = 0] = "start", t17[t17.tick = 1] = "tick", t17[t17.end = 2] = "end";
    }(e21 = t16.EventType || (t16.EventType = {}));
    var f11 = function() {
      function t17() {
        var e22 = this;
        this._canvasSize = [1, 1], this._linkDistance = 20, this._defaultNodeSize = 10, this._linkLengthCalculator = null, this._linkType = null, this._avoidOverlaps = false, this._handleDisconnected = true, this._running = false, this._nodes = [], this._groups = [], this._rootGroup = null, this._links = [], this._constraints = [], this._distanceMatrix = null, this._descent = null, this._directedLinkConstraints = null, this._threshold = 0.01, this._visibilityGraph = null, this._groupCompactness = 1e-6, this.event = null, this.linkAccessor = { getSourceIndex: t17.getSourceIndex, getTargetIndex: t17.getTargetIndex, setLength: t17.setLinkLength, getType: function(t18) {
          return "function" == typeof e22._linkType ? e22._linkType(t18) : 0;
        } };
      }
      return t17.prototype.on = function(t18, n13) {
        return this.event || (this.event = {}), "string" == typeof t18 ? this.event[e21[t18]] = n13 : this.event[t18] = n13, this;
      }, t17.prototype.trigger = function(t18) {
        this.event && void 0 !== this.event[t18.type] && this.event[t18.type](t18);
      }, t17.prototype.kick = function() {
        for (; !this.tick(); )
          ;
      }, t17.prototype.tick = function() {
        if (this._alpha < this._threshold)
          return this._running = false, this.trigger({ type: e21.end, alpha: this._alpha = 0, stress: this._lastStress }), true;
        var t18, n13, r10 = this._nodes.length;
        for (this._links.length, this._descent.locks.clear(), n13 = 0; n13 < r10; ++n13)
          if ((t18 = this._nodes[n13]).fixed) {
            void 0 !== t18.px && void 0 !== t18.py || (t18.px = t18.x, t18.py = t18.y);
            var i11 = [t18.px, t18.py];
            this._descent.locks.add(n13, i11);
          }
        var o13 = this._descent.rungeKutta();
        return 0 === o13 ? this._alpha = 0 : void 0 !== this._lastStress && (this._alpha = o13), this._lastStress = o13, this.updateNodePositions(), this.trigger({ type: e21.tick, alpha: this._alpha, stress: this._lastStress }), false;
      }, t17.prototype.updateNodePositions = function() {
        for (var t18, e22 = this._descent.x[0], n13 = this._descent.x[1], r10 = this._nodes.length; r10--; )
          (t18 = this._nodes[r10]).x = e22[r10], t18.y = n13[r10];
      }, t17.prototype.nodes = function(t18) {
        if (!t18) {
          if (0 === this._nodes.length && this._links.length > 0) {
            var e22 = 0;
            this._links.forEach(function(t19) {
              e22 = Math.max(e22, t19.source, t19.target);
            }), this._nodes = new Array(++e22);
            for (var n13 = 0; n13 < e22; ++n13)
              this._nodes[n13] = {};
          }
          return this._nodes;
        }
        return this._nodes = t18, this;
      }, t17.prototype.groups = function(t18) {
        var e22 = this;
        return t18 ? (this._groups = t18, this._rootGroup = {}, this._groups.forEach(function(t19) {
          void 0 === t19.padding && (t19.padding = 1), void 0 !== t19.leaves && t19.leaves.forEach(function(n13, r10) {
            "number" == typeof n13 && ((t19.leaves[r10] = e22._nodes[n13]).parent = t19);
          }), void 0 !== t19.groups && t19.groups.forEach(function(n13, r10) {
            "number" == typeof n13 && ((t19.groups[r10] = e22._groups[n13]).parent = t19);
          });
        }), this._rootGroup.leaves = this._nodes.filter(function(t19) {
          return void 0 === t19.parent;
        }), this._rootGroup.groups = this._groups.filter(function(t19) {
          return void 0 === t19.parent;
        }), this) : this._groups;
      }, t17.prototype.powerGraphGroups = function(t18) {
        var e22 = n12.getGroups(this._nodes, this._links, this.linkAccessor, this._rootGroup);
        return this.groups(e22.groups), t18(e22), this;
      }, t17.prototype.avoidOverlaps = function(t18) {
        return arguments.length ? (this._avoidOverlaps = t18, this) : this._avoidOverlaps;
      }, t17.prototype.handleDisconnected = function(t18) {
        return arguments.length ? (this._handleDisconnected = t18, this) : this._handleDisconnected;
      }, t17.prototype.flowLayout = function(t18, e22) {
        return arguments.length || (t18 = "y"), this._directedLinkConstraints = { axis: t18, getMinSeparation: "number" == typeof e22 ? function() {
          return e22;
        } : e22 }, this;
      }, t17.prototype.links = function(t18) {
        return arguments.length ? (this._links = t18, this) : this._links;
      }, t17.prototype.constraints = function(t18) {
        return arguments.length ? (this._constraints = t18, this) : this._constraints;
      }, t17.prototype.distanceMatrix = function(t18) {
        return arguments.length ? (this._distanceMatrix = t18, this) : this._distanceMatrix;
      }, t17.prototype.size = function(t18) {
        return t18 ? (this._canvasSize = t18, this) : this._canvasSize;
      }, t17.prototype.defaultNodeSize = function(t18) {
        return t18 ? (this._defaultNodeSize = t18, this) : this._defaultNodeSize;
      }, t17.prototype.groupCompactness = function(t18) {
        return t18 ? (this._groupCompactness = t18, this) : this._groupCompactness;
      }, t17.prototype.linkDistance = function(t18) {
        return t18 ? (this._linkDistance = "function" == typeof t18 ? t18 : +t18, this._linkLengthCalculator = null, this) : this._linkDistance;
      }, t17.prototype.linkType = function(t18) {
        return this._linkType = t18, this;
      }, t17.prototype.convergenceThreshold = function(t18) {
        return t18 ? (this._threshold = "function" == typeof t18 ? t18 : +t18, this) : this._threshold;
      }, t17.prototype.alpha = function(t18) {
        return arguments.length ? (t18 = +t18, this._alpha ? this._alpha = t18 > 0 ? t18 : 0 : t18 > 0 && (this._running || (this._running = true, this.trigger({ type: e21.start, alpha: this._alpha = t18 }), this.kick())), this) : this._alpha;
      }, t17.prototype.getLinkLength = function(t18) {
        return "function" == typeof this._linkDistance ? +this._linkDistance(t18) : this._linkDistance;
      }, t17.setLinkLength = function(t18, e22) {
        t18.length = e22;
      }, t17.prototype.getLinkType = function(t18) {
        return "function" == typeof this._linkType ? this._linkType(t18) : 0;
      }, t17.prototype.symmetricDiffLinkLengths = function(t18, e22) {
        var n13 = this;
        return void 0 === e22 && (e22 = 1), this.linkDistance(function(e23) {
          return t18 * e23.length;
        }), this._linkLengthCalculator = function() {
          return r9.symmetricDiffLinkLengths(n13._links, n13.linkAccessor, e22);
        }, this;
      }, t17.prototype.jaccardLinkLengths = function(t18, e22) {
        var n13 = this;
        return void 0 === e22 && (e22 = 1), this.linkDistance(function(e23) {
          return t18 * e23.length;
        }), this._linkLengthCalculator = function() {
          return r9.jaccardLinkLengths(n13._links, n13.linkAccessor, e22);
        }, this;
      }, t17.prototype.start = function(e22, n13, i11, u11, h11, c11) {
        var p10 = this;
        void 0 === e22 && (e22 = 0), void 0 === n13 && (n13 = 0), void 0 === i11 && (i11 = 0), void 0 === u11 && (u11 = 0), void 0 === h11 && (h11 = true), void 0 === c11 && (c11 = true);
        var f12 = this.nodes().length, l11 = f12 + 2 * this._groups.length;
        this._links.length;
        var d12, g9 = this._canvasSize[0], v12 = this._canvasSize[1], y10 = new Array(l11), _7 = new Array(l11), x10 = null, m12 = this._avoidOverlaps;
        this._nodes.forEach(function(t18, e23) {
          t18.index = e23, void 0 === t18.x && (t18.x = g9 / 2, t18.y = v12 / 2), y10[e23] = t18.x, _7[e23] = t18.y;
        }), this._linkLengthCalculator && this._linkLengthCalculator(), this._distanceMatrix ? d12 = this._distanceMatrix : (d12 = new a10.Calculator(l11, this._links, t17.getSourceIndex, t17.getTargetIndex, function(t18) {
          return p10.getLinkLength(t18);
        }).DistanceMatrix(), x10 = o12.Descent.createSquareMatrix(l11, function() {
          return 2;
        }), this._links.forEach(function(t18) {
          "number" == typeof t18.source && (t18.source = p10._nodes[t18.source]), "number" == typeof t18.target && (t18.target = p10._nodes[t18.target]);
        }), this._links.forEach(function(e23) {
          var n14 = t17.getSourceIndex(e23), r10 = t17.getTargetIndex(e23);
          x10[n14][r10] = x10[r10][n14] = e23.weight || 1;
        }));
        var b11 = o12.Descent.createSquareMatrix(l11, function(t18, e23) {
          return d12[t18][e23];
        });
        if (this._rootGroup && void 0 !== this._rootGroup.groups) {
          var k10 = f12;
          this._groups.forEach(function(t18) {
            !function(t19, e23, n14, r10) {
              x10[t19][e23] = x10[e23][t19] = n14, b11[t19][e23] = b11[e23][t19] = r10;
            }(k10, k10 + 1, p10._groupCompactness, 0.1), y10[k10] = 0, _7[k10++] = 0, y10[k10] = 0, _7[k10++] = 0;
          });
        } else
          this._rootGroup = { leaves: this._nodes, groups: [] };
        var w11 = this._constraints || [];
        this._directedLinkConstraints && (this.linkAccessor.getMinSeparation = this._directedLinkConstraints.getMinSeparation, w11 = w11.concat(r9.generateDirectedEdgeConstraints(f12, this._links, this._directedLinkConstraints.axis, this.linkAccessor))), this.avoidOverlaps(false), this._descent = new o12.Descent([y10, _7], b11), this._descent.locks.clear();
        for (k10 = 0; k10 < f12; ++k10) {
          var E9 = this._nodes[k10];
          if (E9.fixed) {
            E9.px = E9.x, E9.py = E9.y;
            var P10 = [E9.x, E9.y];
            this._descent.locks.add(k10, P10);
          }
        }
        if (this._descent.threshold = this._threshold, this.initialLayout(e22, y10, _7), w11.length > 0 && (this._descent.project = new s11.Projection(this._nodes, this._groups, this._rootGroup, w11).projectFunctions()), this._descent.run(n13), this.separateOverlappingComponents(g9, v12, c11), this.avoidOverlaps(m12), m12 && (this._nodes.forEach(function(t18, e23) {
          t18.x = y10[e23], t18.y = _7[e23];
        }), this._descent.project = new s11.Projection(this._nodes, this._groups, this._rootGroup, w11, true).projectFunctions(), this._nodes.forEach(function(t18, e23) {
          y10[e23] = t18.x, _7[e23] = t18.y;
        })), this._descent.G = x10, this._descent.run(i11), u11) {
          this._descent.snapStrength = 1e3, this._descent.snapGridSize = this._nodes[0].width, this._descent.numGridSnapNodes = f12, this._descent.scaleSnapByMaxH = f12 != l11;
          var L9 = o12.Descent.createSquareMatrix(l11, function(t18, e23) {
            return t18 >= f12 || e23 >= f12 ? x10[t18][e23] : 0;
          });
          this._descent.G = L9, this._descent.run(u11);
        }
        return this.updateNodePositions(), this.separateOverlappingComponents(g9, v12, c11), h11 ? this.resume() : this;
      }, t17.prototype.initialLayout = function(e22, n13, r10) {
        if (this._groups.length > 0 && e22 > 0) {
          var i11 = this._nodes.length, o13 = this._links.map(function(t18) {
            return { source: t18.source.index, target: t18.target.index };
          }), s12 = this._nodes.map(function(t18) {
            return { index: t18.index };
          });
          this._groups.forEach(function(t18, e23) {
            s12.push({ index: t18.index = i11 + e23 });
          }), this._groups.forEach(function(t18, e23) {
            void 0 !== t18.leaves && t18.leaves.forEach(function(e24) {
              return o13.push({ source: t18.index, target: e24.index });
            }), void 0 !== t18.groups && t18.groups.forEach(function(e24) {
              return o13.push({ source: t18.index, target: e24.index });
            });
          }), new t17().size(this.size()).nodes(s12).links(o13).avoidOverlaps(false).linkDistance(this.linkDistance()).symmetricDiffLinkLengths(5).convergenceThreshold(1e-4).start(e22, 0, 0, 0, false), this._nodes.forEach(function(t18) {
            n13[t18.index] = s12[t18.index].x, r10[t18.index] = s12[t18.index].y;
          });
        } else
          this._descent.run(e22);
      }, t17.prototype.separateOverlappingComponents = function(t18, e22, n13) {
        var r10 = this;
        if (void 0 === n13 && (n13 = true), !this._distanceMatrix && this._handleDisconnected) {
          var i11 = this._descent.x[0], o13 = this._descent.x[1];
          this._nodes.forEach(function(t19, e23) {
            t19.x = i11[e23], t19.y = o13[e23];
          });
          var s12 = h10.separateGraphs(this._nodes, this._links);
          h10.applyPacking(s12, t18, e22, this._defaultNodeSize, 1, n13), this._nodes.forEach(function(t19, e23) {
            r10._descent.x[0][e23] = t19.x, r10._descent.x[1][e23] = t19.y, t19.bounds && (t19.bounds.setXCentre(t19.x), t19.bounds.setYCentre(t19.y));
          });
        }
      }, t17.prototype.resume = function() {
        return this.alpha(0.1);
      }, t17.prototype.stop = function() {
        return this.alpha(0);
      }, t17.prototype.prepareEdgeRouting = function(t18) {
        void 0 === t18 && (t18 = 0), this._visibilityGraph = new u10.TangentVisibilityGraph(this._nodes.map(function(e22) {
          return e22.bounds.inflate(-t18).vertices();
        }));
      }, t17.prototype.routeEdge = function(t18, e22, n13) {
        void 0 === e22 && (e22 = 5);
        var r10 = [], i11 = new u10.TangentVisibilityGraph(this._visibilityGraph.P, { V: this._visibilityGraph.V, E: this._visibilityGraph.E }), o13 = { x: t18.source.x, y: t18.source.y }, h11 = { x: t18.target.x, y: t18.target.y }, c11 = i11.addPoint(o13, t18.source.index), p10 = i11.addPoint(h11, t18.target.index);
        i11.addEdgeIfVisible(o13, h11, t18.source.index, t18.target.index), void 0 !== n13 && n13(i11);
        var f12 = new a10.Calculator(i11.V.length, i11.E, function(t19) {
          return t19.source.id;
        }, function(t19) {
          return t19.target.id;
        }, function(t19) {
          return t19.length();
        }).PathFromNodeToNode(c11.id, p10.id);
        if (1 === f12.length || f12.length === i11.V.length) {
          var l11 = s11.makeEdgeBetween(t18.source.innerBounds, t18.target.innerBounds, e22);
          r10 = [l11.sourceIntersection, l11.arrowStart];
        } else {
          for (var d12 = f12.length - 2, g9 = i11.V[f12[d12]].p, v12 = i11.V[f12[0]].p, y10 = (r10 = [t18.source.innerBounds.rayIntersection(g9.x, g9.y)], d12); y10 >= 0; --y10)
            r10.push(i11.V[f12[y10]].p);
          r10.push(s11.makeEdgeTo(v12, t18.target.innerBounds, e22));
        }
        return r10;
      }, t17.getSourceIndex = function(t18) {
        return "number" == typeof t18.source ? t18.source : t18.source.index;
      }, t17.getTargetIndex = function(t18) {
        return "number" == typeof t18.target ? t18.target : t18.target.index;
      }, t17.linkId = function(e22) {
        return t17.getSourceIndex(e22) + "-" + t17.getTargetIndex(e22);
      }, t17.dragStart = function(e22) {
        c10(e22) ? t17.storeOffset(e22, t17.dragOrigin(e22)) : (t17.stopNode(e22), e22.fixed |= 2);
      }, t17.stopNode = function(t18) {
        t18.px = t18.x, t18.py = t18.y;
      }, t17.storeOffset = function(e22, n13) {
        void 0 !== e22.leaves && e22.leaves.forEach(function(e23) {
          e23.fixed |= 2, t17.stopNode(e23), e23._dragGroupOffsetX = e23.x - n13.x, e23._dragGroupOffsetY = e23.y - n13.y;
        }), void 0 !== e22.groups && e22.groups.forEach(function(e23) {
          return t17.storeOffset(e23, n13);
        });
      }, t17.dragOrigin = function(t18) {
        return c10(t18) ? { x: t18.bounds.cx(), y: t18.bounds.cy() } : t18;
      }, t17.drag = function(e22, n13) {
        c10(e22) ? (void 0 !== e22.leaves && e22.leaves.forEach(function(t18) {
          e22.bounds.setXCentre(n13.x), e22.bounds.setYCentre(n13.y), t18.px = t18._dragGroupOffsetX + n13.x, t18.py = t18._dragGroupOffsetY + n13.y;
        }), void 0 !== e22.groups && e22.groups.forEach(function(e23) {
          return t17.drag(e23, n13);
        })) : (e22.px = n13.x, e22.py = n13.y);
      }, t17.dragEnd = function(e22) {
        c10(e22) ? (void 0 !== e22.leaves && e22.leaves.forEach(function(e23) {
          t17.dragEnd(e23), delete e23._dragGroupOffsetX, delete e23._dragGroupOffsetY;
        }), void 0 !== e22.groups && e22.groups.forEach(t17.dragEnd)) : e22.fixed &= -7;
      }, t17.mouseOver = function(t18) {
        t18.fixed |= 4, t18.px = t18.x, t18.py = t18.y;
      }, t17.mouseOut = function(t18) {
        t18.fixed &= -5;
      }, t17;
    }();
    t16.Layout = f11;
  }(r6);
  var Gt5 = t11 && t11.__extends || function() {
    var t16 = function(e21, n12) {
      return t16 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(t17, e22) {
        t17.__proto__ = e22;
      } || function(t17, e22) {
        for (var n13 in e22)
          e22.hasOwnProperty(n13) && (t17[n13] = e22[n13]);
      }, t16(e21, n12);
    };
    return function(e21, n12) {
      function r9() {
        this.constructor = e21;
      }
      t16(e21, n12), e21.prototype = null === n12 ? Object.create(n12) : (r9.prototype = n12.prototype, new r9());
    };
  }();
  Object.defineProperty(n8, "__esModule", { value: true });
  var Vt5 = r6;
  var Dt5 = function(t16) {
    function e21(e22) {
      var n12 = t16.call(this) || this, r9 = e22;
      return r9.trigger && (n12.trigger = r9.trigger), r9.kick && (n12.kick = r9.kick), r9.drag && (n12.drag = r9.drag), r9.on && (n12.on = r9.on), n12.dragstart = n12.dragStart = Vt5.Layout.dragStart, n12.dragend = n12.dragEnd = Vt5.Layout.dragEnd, n12;
    }
    return Gt5(e21, t16), e21.prototype.trigger = function(t17) {
    }, e21.prototype.kick = function() {
    }, e21.prototype.drag = function() {
    }, e21.prototype.on = function(t17, e22) {
      return this;
    }, e21;
  }(Vt5.Layout);
  n8.LayoutAdaptor = Dt5, n8.adaptor = function(t16) {
    return new Dt5(t16);
  };
  var jt5 = {};
  var Bt5 = {};
  var Rt5 = t11 && t11.__extends || function() {
    var t16 = function(e21, n12) {
      return t16 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(t17, e22) {
        t17.__proto__ = e22;
      } || function(t17, e22) {
        for (var n13 in e22)
          e22.hasOwnProperty(n13) && (t17[n13] = e22[n13]);
      }, t16(e21, n12);
    };
    return function(e21, n12) {
      function r9() {
        this.constructor = e21;
      }
      t16(e21, n12), e21.prototype = null === n12 ? Object.create(n12) : (r9.prototype = n12.prototype, new r9());
    };
  }();
  Object.defineProperty(Bt5, "__esModule", { value: true });
  var Xt5 = r6;
  var zt5 = function(t16) {
    function e21() {
      var e22 = t16.call(this) || this;
      e22.event = d3.dispatch(Xt5.EventType[Xt5.EventType.start], Xt5.EventType[Xt5.EventType.tick], Xt5.EventType[Xt5.EventType.end]);
      var n12 = e22;
      return e22.drag = function() {
        if (!t17)
          var t17 = d3.behavior.drag().origin(Xt5.Layout.dragOrigin).on("dragstart.d3adaptor", Xt5.Layout.dragStart).on("drag.d3adaptor", function(t18) {
            Xt5.Layout.drag(t18, d3.event), n12.resume();
          }).on("dragend.d3adaptor", Xt5.Layout.dragEnd);
        if (!arguments.length)
          return t17;
        this.call(t17);
      }, e22;
    }
    return Rt5(e21, t16), e21.prototype.trigger = function(t17) {
      var e22 = { type: Xt5.EventType[t17.type], alpha: t17.alpha, stress: t17.stress };
      this.event[e22.type](e22);
    }, e21.prototype.kick = function() {
      var e22 = this;
      d3.timer(function() {
        return t16.prototype.tick.call(e22);
      });
    }, e21.prototype.on = function(t17, e22) {
      return "string" == typeof t17 ? this.event.on(t17, e22) : this.event.on(Xt5.EventType[t17], e22), this;
    }, e21;
  }(Xt5.Layout);
  Bt5.D3StyleLayoutAdaptor = zt5, Bt5.d3adaptor = function() {
    return new zt5();
  };
  var Yt5 = {};
  var qt5 = t11 && t11.__extends || function() {
    var t16 = function(e21, n12) {
      return t16 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(t17, e22) {
        t17.__proto__ = e22;
      } || function(t17, e22) {
        for (var n13 in e22)
          e22.hasOwnProperty(n13) && (t17[n13] = e22[n13]);
      }, t16(e21, n12);
    };
    return function(e21, n12) {
      function r9() {
        this.constructor = e21;
      }
      t16(e21, n12), e21.prototype = null === n12 ? Object.create(n12) : (r9.prototype = n12.prototype, new r9());
    };
  }();
  Object.defineProperty(Yt5, "__esModule", { value: true });
  var Ft5 = r6;
  var Ht5 = function(t16) {
    function e21(e22) {
      var n12 = t16.call(this) || this;
      n12.d3Context = e22, n12.event = e22.dispatch(Ft5.EventType[Ft5.EventType.start], Ft5.EventType[Ft5.EventType.tick], Ft5.EventType[Ft5.EventType.end]);
      var r9 = n12;
      return n12.drag = function() {
        if (!t17)
          var t17 = e22.drag().subject(Ft5.Layout.dragOrigin).on("start.d3adaptor", Ft5.Layout.dragStart).on("drag.d3adaptor", function(t18) {
            Ft5.Layout.drag(t18, e22.event), r9.resume();
          }).on("end.d3adaptor", Ft5.Layout.dragEnd);
        if (!arguments.length)
          return t17;
        arguments[0].call(t17);
      }, n12;
    }
    return qt5(e21, t16), e21.prototype.trigger = function(t17) {
      var e22 = { type: Ft5.EventType[t17.type], alpha: t17.alpha, stress: t17.stress };
      this.event.call(e22.type, e22);
    }, e21.prototype.kick = function() {
      var e22 = this, n12 = this.d3Context.timer(function() {
        return t16.prototype.tick.call(e22) && n12.stop();
      });
    }, e21.prototype.on = function(t17, e22) {
      return "string" == typeof t17 ? this.event.on(t17, e22) : this.event.on(Ft5.EventType[t17], e22), this;
    }, e21;
  }(Ft5.Layout);
  Yt5.D3StyleLayoutAdaptor = Ht5, Object.defineProperty(jt5, "__esModule", { value: true });
  var Ut5 = Bt5;
  var Wt5 = Yt5;
  jt5.d3adaptor = function(t16) {
    return !t16 || function(t17) {
      var e21 = /^3\./;
      return t17.version && null !== t17.version.match(e21);
    }(t16) ? new Ut5.D3StyleLayoutAdaptor() : new Wt5.D3StyleLayoutAdaptor(t16);
  };
  var Kt5 = {};
  Object.defineProperty(Kt5, "__esModule", { value: true });
  var Qt5 = m8;
  var Zt5 = b7;
  var Jt5 = tt5;
  var $t5 = function(t16, e21, n12) {
    this.id = t16, this.rect = e21, this.children = n12, this.leaf = void 0 === n12 || 0 === n12.length;
  };
  Kt5.NodeWrapper = $t5;
  var te2 = function(t16, e21, n12, r9, i11) {
    void 0 === r9 && (r9 = null), void 0 === i11 && (i11 = null), this.id = t16, this.x = e21, this.y = n12, this.node = r9, this.line = i11;
  };
  Kt5.Vert = te2;
  var ee2 = function() {
    function t16(e21, n12) {
      this.s = e21, this.t = n12;
      var r9 = t16.findMatch(e21, n12), i11 = n12.slice(0).reverse(), o12 = t16.findMatch(e21, i11);
      r9.length >= o12.length ? (this.length = r9.length, this.si = r9.si, this.ti = r9.ti, this.reversed = false) : (this.length = o12.length, this.si = o12.si, this.ti = n12.length - o12.ti - o12.length, this.reversed = true);
    }
    return t16.findMatch = function(t17, e21) {
      for (var n12 = t17.length, r9 = e21.length, i11 = { length: 0, si: -1, ti: -1 }, o12 = new Array(n12), s11 = 0; s11 < n12; s11++) {
        o12[s11] = new Array(r9);
        for (var a10 = 0; a10 < r9; a10++)
          if (t17[s11] === e21[a10]) {
            var u10 = o12[s11][a10] = 0 === s11 || 0 === a10 ? 1 : o12[s11 - 1][a10 - 1] + 1;
            u10 > i11.length && (i11.length = u10, i11.si = s11 - u10 + 1, i11.ti = a10 - u10 + 1);
          } else
            o12[s11][a10] = 0;
      }
      return i11;
    }, t16.prototype.getSequence = function() {
      return this.length >= 0 ? this.s.slice(this.si, this.si + this.length) : [];
    }, t16;
  }();
  Kt5.LongestCommonSubsequence = ee2;
  var ne2 = function() {
    function t16(t17, e21, n12) {
      var r9 = this;
      void 0 === n12 && (n12 = 12), this.originalnodes = t17, this.groupPadding = n12, this.leaves = null, this.nodes = t17.map(function(t18, n13) {
        return new $t5(n13, e21.getBounds(t18), e21.getChildren(t18));
      }), this.leaves = this.nodes.filter(function(t18) {
        return t18.leaf;
      }), this.groups = this.nodes.filter(function(t18) {
        return !t18.leaf;
      }), this.cols = this.getGridLines("x"), this.rows = this.getGridLines("y"), this.groups.forEach(function(t18) {
        return t18.children.forEach(function(e22) {
          return r9.nodes[e22].parent = t18;
        });
      }), this.root = { children: [] }, this.nodes.forEach(function(t18) {
        void 0 === t18.parent && (t18.parent = r9.root, r9.root.children.push(t18.id)), t18.ports = [];
      }), this.backToFront = this.nodes.slice(0), this.backToFront.sort(function(t18, e22) {
        return r9.getDepth(t18) - r9.getDepth(e22);
      }), this.backToFront.slice(0).reverse().filter(function(t18) {
        return !t18.leaf;
      }).forEach(function(t18) {
        var e22 = Qt5.Rectangle.empty();
        t18.children.forEach(function(t19) {
          return e22 = e22.union(r9.nodes[t19].rect);
        }), t18.rect = e22.inflate(r9.groupPadding);
      });
      var i11 = this.midPoints(this.cols.map(function(t18) {
        return t18.pos;
      })), o12 = this.midPoints(this.rows.map(function(t18) {
        return t18.pos;
      })), s11 = i11[0], a10 = i11[i11.length - 1], u10 = o12[0], h10 = o12[o12.length - 1], c10 = this.rows.map(function(t18) {
        return { x1: s11, x2: a10, y1: t18.pos, y2: t18.pos };
      }).concat(o12.map(function(t18) {
        return { x1: s11, x2: a10, y1: t18, y2: t18 };
      })), p10 = this.cols.map(function(t18) {
        return { x1: t18.pos, x2: t18.pos, y1: u10, y2: h10 };
      }).concat(i11.map(function(t18) {
        return { x1: t18, x2: t18, y1: u10, y2: h10 };
      })), f11 = c10.concat(p10);
      f11.forEach(function(t18) {
        return t18.verts = [];
      }), this.verts = [], this.edges = [], c10.forEach(function(t18) {
        return p10.forEach(function(e22) {
          var n13 = new te2(r9.verts.length, e22.x1, t18.y1);
          t18.verts.push(n13), e22.verts.push(n13), r9.verts.push(n13);
          for (var i12 = r9.backToFront.length; i12-- > 0; ) {
            var o13 = r9.backToFront[i12], s12 = o13.rect, a11 = Math.abs(n13.x - s12.cx()), u11 = Math.abs(n13.y - s12.cy());
            if (a11 < s12.width() / 2 && u11 < s12.height() / 2) {
              n13.node = o13;
              break;
            }
          }
        });
      }), f11.forEach(function(t18, e22) {
        r9.nodes.forEach(function(e23, n14) {
          e23.rect.lineIntersections(t18.x1, t18.y1, t18.x2, t18.y2).forEach(function(n15, i13) {
            var o14 = new te2(r9.verts.length, n15.x, n15.y, e23, t18);
            r9.verts.push(o14), t18.verts.push(o14), e23.ports.push(o14);
          });
        });
        var n13 = Math.abs(t18.y1 - t18.y2) < 0.1, i12 = function(t19, e23) {
          return n13 ? e23.x - t19.x : e23.y - t19.y;
        };
        t18.verts.sort(i12);
        for (var o13 = 1; o13 < t18.verts.length; o13++) {
          var s12 = t18.verts[o13 - 1], a11 = t18.verts[o13];
          s12.node && s12.node === a11.node && s12.node.leaf || r9.edges.push({ source: s12.id, target: a11.id, length: Math.abs(i12(s12, a11)) });
        }
      });
    }
    return t16.prototype.avg = function(t17) {
      return t17.reduce(function(t18, e21) {
        return t18 + e21;
      }) / t17.length;
    }, t16.prototype.getGridLines = function(t17) {
      for (var e21 = [], n12 = this.leaves.slice(0, this.leaves.length); n12.length > 0; ) {
        var r9 = n12.filter(function(e22) {
          return e22.rect["overlap" + t17.toUpperCase()](n12[0].rect);
        }), i11 = { nodes: r9, pos: this.avg(r9.map(function(e22) {
          return e22.rect["c" + t17]();
        })) };
        e21.push(i11), i11.nodes.forEach(function(t18) {
          return n12.splice(n12.indexOf(t18), 1);
        });
      }
      return e21.sort(function(t18, e22) {
        return t18.pos - e22.pos;
      }), e21;
    }, t16.prototype.getDepth = function(t17) {
      for (var e21 = 0; t17.parent !== this.root; )
        e21++, t17 = t17.parent;
      return e21;
    }, t16.prototype.midPoints = function(t17) {
      for (var e21 = t17[1] - t17[0], n12 = [t17[0] - e21 / 2], r9 = 1; r9 < t17.length; r9++)
        n12.push((t17[r9] + t17[r9 - 1]) / 2);
      return n12.push(t17[t17.length - 1] + e21 / 2), n12;
    }, t16.prototype.findLineage = function(t17) {
      var e21 = [t17];
      do {
        t17 = t17.parent, e21.push(t17);
      } while (t17 !== this.root);
      return e21.reverse();
    }, t16.prototype.findAncestorPathBetween = function(t17, e21) {
      for (var n12 = this.findLineage(t17), r9 = this.findLineage(e21), i11 = 0; n12[i11] === r9[i11]; )
        i11++;
      return { commonAncestor: n12[i11 - 1], lineages: n12.slice(i11).concat(r9.slice(i11)) };
    }, t16.prototype.siblingObstacles = function(t17, e21) {
      var n12 = this, r9 = this.findAncestorPathBetween(t17, e21), i11 = {};
      r9.lineages.forEach(function(t18) {
        return i11[t18.id] = {};
      });
      var o12 = r9.commonAncestor.children.filter(function(t18) {
        return !(t18 in i11);
      });
      return r9.lineages.filter(function(t18) {
        return t18.parent !== r9.commonAncestor;
      }).forEach(function(t18) {
        return o12 = o12.concat(t18.parent.children.filter(function(e22) {
          return e22 !== t18.id;
        }));
      }), o12.map(function(t18) {
        return n12.nodes[t18];
      });
    }, t16.getSegmentSets = function(t17, e21, n12) {
      for (var r9 = [], i11 = 0; i11 < t17.length; i11++)
        for (var o12 = t17[i11], s11 = 0; s11 < o12.length; s11++) {
          (p10 = o12[s11]).edgeid = i11, p10.i = s11;
          var a10 = p10[1][e21] - p10[0][e21];
          Math.abs(a10) < 0.1 && r9.push(p10);
        }
      r9.sort(function(t18, n13) {
        return t18[0][e21] - n13[0][e21];
      });
      for (var u10 = [], h10 = null, c10 = 0; c10 < r9.length; c10++) {
        var p10 = r9[c10];
        (!h10 || Math.abs(p10[0][e21] - h10.pos) > 0.1) && (h10 = { pos: p10[0][e21], segments: [] }, u10.push(h10)), h10.segments.push(p10);
      }
      return u10;
    }, t16.nudgeSegs = function(t17, e21, n12, r9, i11, o12) {
      var s11 = r9.length;
      if (!(s11 <= 1)) {
        for (var a10 = r9.map(function(e22) {
          return new Zt5.Variable(e22[0][t17]);
        }), u10 = [], h10 = 0; h10 < s11; h10++)
          for (var c10 = 0; c10 < s11; c10++)
            if (h10 !== c10) {
              var p10 = r9[h10], f11 = r9[c10], l11 = p10.edgeid, d12 = f11.edgeid, g9 = -1, v12 = -1;
              "x" == t17 ? i11(l11, d12) && (p10[0][e21] < p10[1][e21] ? (g9 = c10, v12 = h10) : (g9 = h10, v12 = c10)) : i11(l11, d12) && (p10[0][e21] < p10[1][e21] ? (g9 = h10, v12 = c10) : (g9 = c10, v12 = h10)), g9 >= 0 && u10.push(new Zt5.Constraint(a10[g9], a10[v12], o12));
            }
        new Zt5.Solver(a10, u10).solve(), a10.forEach(function(e22, i12) {
          var o13 = r9[i12], s12 = e22.position();
          o13[0][t17] = o13[1][t17] = s12;
          var a11 = n12[o13.edgeid];
          o13.i > 0 && (a11[o13.i - 1][1][t17] = s12), o13.i < a11.length - 1 && (a11[o13.i + 1][0][t17] = s12);
        });
      }
    }, t16.nudgeSegments = function(e21, n12, r9, i11, o12) {
      for (var s11 = t16.getSegmentSets(e21, n12, r9), a10 = 0; a10 < s11.length; a10++) {
        for (var u10 = s11[a10], h10 = [], c10 = 0; c10 < u10.segments.length; c10++) {
          var p10 = u10.segments[c10];
          h10.push({ type: 0, s: p10, pos: Math.min(p10[0][r9], p10[1][r9]) }), h10.push({ type: 1, s: p10, pos: Math.max(p10[0][r9], p10[1][r9]) });
        }
        h10.sort(function(t17, e22) {
          return t17.pos - e22.pos + t17.type - e22.type;
        });
        var f11 = [], l11 = 0;
        h10.forEach(function(s12) {
          0 === s12.type ? (f11.push(s12.s), l11++) : l11--, 0 == l11 && (t16.nudgeSegs(n12, r9, e21, f11, i11, o12), f11 = []);
        });
      }
    }, t16.prototype.routeEdges = function(e21, n12, r9, i11) {
      var o12 = this, s11 = e21.map(function(t17) {
        return o12.route(r9(t17), i11(t17));
      }), a10 = t16.orderEdges(s11), u10 = s11.map(function(e22) {
        return t16.makeSegments(e22);
      });
      return t16.nudgeSegments(u10, "x", "y", a10, n12), t16.nudgeSegments(u10, "y", "x", a10, n12), t16.unreverseEdges(u10, s11), u10;
    }, t16.unreverseEdges = function(t17, e21) {
      t17.forEach(function(t18, n12) {
        e21[n12].reversed && (t18.reverse(), t18.forEach(function(t19) {
          t19.reverse();
        }));
      });
    }, t16.angleBetween2Lines = function(t17, e21) {
      var n12 = Math.atan2(t17[0].y - t17[1].y, t17[0].x - t17[1].x), r9 = Math.atan2(e21[0].y - e21[1].y, e21[0].x - e21[1].x), i11 = n12 - r9;
      return (i11 > Math.PI || i11 < -Math.PI) && (i11 = r9 - n12), i11;
    }, t16.isLeft = function(t17, e21, n12) {
      return (e21.x - t17.x) * (n12.y - t17.y) - (e21.y - t17.y) * (n12.x - t17.x) <= 0;
    }, t16.getOrder = function(t17) {
      for (var e21 = {}, n12 = 0; n12 < t17.length; n12++) {
        var r9 = t17[n12];
        void 0 === e21[r9.l] && (e21[r9.l] = {}), e21[r9.l][r9.r] = true;
      }
      return function(t18, n13) {
        return void 0 !== e21[t18] && e21[t18][n13];
      };
    }, t16.orderEdges = function(e21) {
      for (var n12 = [], r9 = 0; r9 < e21.length - 1; r9++)
        for (var i11 = r9 + 1; i11 < e21.length; i11++) {
          var o12, s11, a10, u10 = e21[r9], h10 = e21[i11], c10 = new ee2(u10, h10);
          0 !== c10.length && (c10.reversed && (h10.reverse(), h10.reversed = true, c10 = new ee2(u10, h10)), (c10.si <= 0 || c10.ti <= 0) && (c10.si + c10.length >= u10.length || c10.ti + c10.length >= h10.length) ? n12.push({ l: r9, r: i11 }) : (c10.si + c10.length >= u10.length || c10.ti + c10.length >= h10.length ? (o12 = u10[c10.si + 1], a10 = u10[c10.si - 1], s11 = h10[c10.ti - 1]) : (o12 = u10[c10.si + c10.length - 2], s11 = u10[c10.si + c10.length], a10 = h10[c10.ti + c10.length]), t16.isLeft(o12, s11, a10) ? n12.push({ l: i11, r: r9 }) : n12.push({ l: r9, r: i11 })));
        }
      return t16.getOrder(n12);
    }, t16.makeSegments = function(t17) {
      function e21(t18) {
        return { x: t18.x, y: t18.y };
      }
      for (var n12 = function(t18, e22, n13) {
        return Math.abs((e22.x - t18.x) * (n13.y - t18.y) - (e22.y - t18.y) * (n13.x - t18.x)) < 1e-3;
      }, r9 = [], i11 = e21(t17[0]), o12 = 1; o12 < t17.length; o12++) {
        var s11 = e21(t17[o12]), a10 = o12 < t17.length - 1 ? t17[o12 + 1] : null;
        a10 && n12(i11, s11, a10) || (r9.push([i11, s11]), i11 = s11);
      }
      return r9;
    }, t16.prototype.route = function(t17, e21) {
      var n12 = this, r9 = this.nodes[t17], i11 = this.nodes[e21];
      this.obstacles = this.siblingObstacles(r9, i11);
      var o12 = {};
      this.obstacles.forEach(function(t18) {
        return o12[t18.id] = t18;
      }), this.passableEdges = this.edges.filter(function(t18) {
        var e22 = n12.verts[t18.source], r10 = n12.verts[t18.target];
        return !(e22.node && e22.node.id in o12 || r10.node && r10.node.id in o12);
      });
      for (var s11 = 1; s11 < r9.ports.length; s11++) {
        var a10 = r9.ports[0].id, u10 = r9.ports[s11].id;
        this.passableEdges.push({ source: a10, target: u10, length: 0 });
      }
      for (s11 = 1; s11 < i11.ports.length; s11++) {
        a10 = i11.ports[0].id, u10 = i11.ports[s11].id;
        this.passableEdges.push({ source: a10, target: u10, length: 0 });
      }
      var h10 = new Jt5.Calculator(this.verts.length, this.passableEdges, function(t18) {
        return t18.source;
      }, function(t18) {
        return t18.target;
      }, function(t18) {
        return t18.length;
      }).PathFromNodeToNodeWithPrevCost(r9.ports[0].id, i11.ports[0].id, function(t18, e22, o13) {
        var s12 = n12.verts[t18], a11 = n12.verts[e22], u11 = n12.verts[o13], h11 = Math.abs(u11.x - s12.x), c11 = Math.abs(u11.y - s12.y);
        return s12.node === r9 && s12.node === a11.node || a11.node === i11 && a11.node === u11.node ? 0 : h11 > 1 && c11 > 1 ? 1e3 : 0;
      }), c10 = h10.reverse().map(function(t18) {
        return n12.verts[t18];
      });
      return c10.push(this.nodes[i11.id].ports[0]), c10.filter(function(t18, e22) {
        return !(e22 < c10.length - 1 && c10[e22 + 1].node === r9 && t18.node === r9 || e22 > 0 && t18.node === i11 && c10[e22 - 1].node === i11);
      });
    }, t16.getRoutePath = function(e21, n12, r9, i11) {
      var o12 = { routepath: "M " + e21[0][0].x + " " + e21[0][0].y + " ", arrowpath: "" };
      if (e21.length > 1)
        for (var s11 = 0; s11 < e21.length; s11++) {
          var a10 = (m12 = e21[s11])[1].x, u10 = m12[1].y, h10 = a10 - m12[0].x, c10 = u10 - m12[0].y;
          if (s11 < e21.length - 1) {
            Math.abs(h10) > 0 ? a10 -= h10 / Math.abs(h10) * n12 : u10 -= c10 / Math.abs(c10) * n12, o12.routepath += "L " + a10 + " " + u10 + " ";
            var p10 = e21[s11 + 1], f11 = p10[0].x, l11 = p10[0].y;
            h10 = p10[1].x - f11, c10 = p10[1].y - l11;
            var d12, g9, v12 = t16.angleBetween2Lines(m12, p10) < 0 ? 1 : 0;
            Math.abs(h10) > 0 ? (d12 = f11 + h10 / Math.abs(h10) * n12, g9 = l11) : (d12 = f11, g9 = l11 + c10 / Math.abs(c10) * n12);
            var y10 = Math.abs(d12 - a10), _7 = Math.abs(g9 - u10);
            o12.routepath += "A " + y10 + " " + _7 + " 0 0 " + v12 + " " + d12 + " " + g9 + " ";
          } else {
            var x10 = [a10, u10];
            Math.abs(h10) > 0 ? (b11 = [a10 -= h10 / Math.abs(h10) * i11, u10 + r9], k10 = [a10, u10 - r9]) : (b11 = [a10 + r9, u10 -= c10 / Math.abs(c10) * i11], k10 = [a10 - r9, u10]), o12.routepath += "L " + a10 + " " + u10 + " ", i11 > 0 && (o12.arrowpath = "M " + x10[0] + " " + x10[1] + " L " + b11[0] + " " + b11[1] + " L " + k10[0] + " " + k10[1]);
          }
        }
      else {
        var m12, b11, k10;
        a10 = (m12 = e21[0])[1].x, u10 = m12[1].y, h10 = a10 - m12[0].x, c10 = u10 - m12[0].y, x10 = [a10, u10];
        Math.abs(h10) > 0 ? (b11 = [a10 -= h10 / Math.abs(h10) * i11, u10 + r9], k10 = [a10, u10 - r9]) : (b11 = [a10 + r9, u10 -= c10 / Math.abs(c10) * i11], k10 = [a10 - r9, u10]), o12.routepath += "L " + a10 + " " + u10 + " ", i11 > 0 && (o12.arrowpath = "M " + x10[0] + " " + x10[1] + " L " + b11[0] + " " + b11[1] + " L " + k10[0] + " " + k10[1]);
      }
      return o12;
    }, t16;
  }();
  Kt5.GridRouter = ne2;
  var re2 = {};
  Object.defineProperty(re2, "__esModule", { value: true });
  var ie2 = tt5;
  var oe2 = v7;
  var se2 = m8;
  var ae2 = p7;
  var ue2 = function() {
    function t16(t17, e21) {
      this.source = t17, this.target = e21;
    }
    return t16.prototype.actualLength = function(t17) {
      var e21 = this;
      return Math.sqrt(t17.reduce(function(t18, n12) {
        var r9 = n12[e21.target] - n12[e21.source];
        return t18 + r9 * r9;
      }, 0));
    }, t16;
  }();
  re2.Link3D = ue2;
  var he2 = function(t16, e21, n12) {
    void 0 === t16 && (t16 = 0), void 0 === e21 && (e21 = 0), void 0 === n12 && (n12 = 0), this.x = t16, this.y = e21, this.z = n12;
  };
  re2.Node3D = he2;
  var ce2 = function() {
    function t16(e21, n12, r9) {
      var i11 = this;
      void 0 === r9 && (r9 = 1), this.nodes = e21, this.links = n12, this.idealLinkLength = r9, this.constraints = null, this.useJaccardLinkLengths = true, this.result = new Array(t16.k);
      for (var o12 = 0; o12 < t16.k; ++o12)
        this.result[o12] = new Array(e21.length);
      e21.forEach(function(e22, n13) {
        for (var r10 = 0, o13 = t16.dims; r10 < o13.length; r10++) {
          var s11 = o13[r10];
          void 0 === e22[s11] && (e22[s11] = Math.random());
        }
        i11.result[0][n13] = e22.x, i11.result[1][n13] = e22.y, i11.result[2][n13] = e22.z;
      });
    }
    return t16.prototype.linkLength = function(t17) {
      return t17.actualLength(this.result);
    }, t16.prototype.start = function(t17) {
      var e21 = this;
      void 0 === t17 && (t17 = 100);
      var n12 = this.nodes.length, r9 = new pe2();
      this.useJaccardLinkLengths && ae2.jaccardLinkLengths(this.links, r9, 1.5), this.links.forEach(function(t18) {
        return t18.length *= e21.idealLinkLength;
      });
      var i11 = new ie2.Calculator(n12, this.links, function(t18) {
        return t18.source;
      }, function(t18) {
        return t18.target;
      }, function(t18) {
        return t18.length;
      }).DistanceMatrix(), o12 = oe2.Descent.createSquareMatrix(n12, function(t18, e22) {
        return i11[t18][e22];
      }), s11 = oe2.Descent.createSquareMatrix(n12, function() {
        return 2;
      });
      this.links.forEach(function(t18) {
        var e22 = t18.source, n13 = t18.target;
        return s11[e22][n13] = s11[n13][e22] = 1;
      }), this.descent = new oe2.Descent(this.result, o12), this.descent.threshold = 1e-3, this.descent.G = s11, this.constraints && (this.descent.project = new se2.Projection(this.nodes, null, null, this.constraints).projectFunctions());
      for (var a10 = 0; a10 < this.nodes.length; a10++) {
        var u10 = this.nodes[a10];
        u10.fixed && this.descent.locks.add(a10, [u10.x, u10.y, u10.z]);
      }
      return this.descent.run(t17), this;
    }, t16.prototype.tick = function() {
      this.descent.locks.clear();
      for (var t17 = 0; t17 < this.nodes.length; t17++) {
        var e21 = this.nodes[t17];
        e21.fixed && this.descent.locks.add(t17, [e21.x, e21.y, e21.z]);
      }
      return this.descent.rungeKutta();
    }, t16.dims = ["x", "y", "z"], t16.k = t16.dims.length, t16;
  }();
  re2.Layout3D = ce2;
  var pe2 = function() {
    function t16() {
    }
    return t16.prototype.getSourceIndex = function(t17) {
      return t17.source;
    }, t16.prototype.getTargetIndex = function(t17) {
      return t17.target;
    }, t16.prototype.getLength = function(t17) {
      return t17.length;
    }, t16.prototype.setLength = function(t17, e21) {
      t17.length = e21;
    }, t16;
  }();
  var fe2 = {};
  Object.defineProperty(fe2, "__esModule", { value: true });
  var le2 = r6;
  var de2 = Kt5;
  fe2.gridify = function(t16, e21, n12, r9) {
    t16.cola.start(0, 0, 0, 10, false);
    var i11 = function(t17, e22, n13, r10) {
      t17.forEach(function(t18) {
        t18.routerNode = { name: t18.name, bounds: t18.bounds.inflate(-n13) };
      }), e22.forEach(function(e23) {
        e23.routerNode = { bounds: e23.bounds.inflate(-r10), children: (void 0 !== e23.groups ? e23.groups.map(function(e24) {
          return t17.length + e24.id;
        }) : []).concat(void 0 !== e23.leaves ? e23.leaves.map(function(t18) {
          return t18.index;
        }) : []) };
      });
      var i12 = t17.concat(e22).map(function(t18, e23) {
        return t18.routerNode.id = e23, t18.routerNode;
      });
      return new de2.GridRouter(i12, { getChildren: function(t18) {
        return t18.children;
      }, getBounds: function(t18) {
        return t18.bounds;
      } }, n13 - r10);
    }(t16.cola.nodes(), t16.cola.groups(), n12, r9);
    return i11.routeEdges(t16.powerGraph.powerEdges, e21, function(t17) {
      return t17.source.routerNode.id;
    }, function(t17) {
      return t17.target.routerNode.id;
    });
  }, fe2.powerGraphGridLayout = function(t16, e21, n12) {
    var r9;
    t16.nodes.forEach(function(t17, e22) {
      return t17.index = e22;
    }), new le2.Layout().avoidOverlaps(false).nodes(t16.nodes).links(t16.links).powerGraphGroups(function(t17) {
      (r9 = t17).groups.forEach(function(t18) {
        return t18.padding = n12;
      });
    });
    var i11 = t16.nodes.length, o12 = [], s11 = t16.nodes.slice(0);
    return s11.forEach(function(t17, e22) {
      return t17.index = e22;
    }), r9.groups.forEach(function(t17) {
      var e22 = t17.index = t17.id + i11;
      s11.push(t17), void 0 !== t17.leaves && t17.leaves.forEach(function(t18) {
        return o12.push({ source: e22, target: t18.index });
      }), void 0 !== t17.groups && t17.groups.forEach(function(t18) {
        return o12.push({ source: e22, target: t18.id + i11 });
      });
    }), r9.powerEdges.forEach(function(t17) {
      o12.push({ source: t17.source.index, target: t17.target.index });
    }), new le2.Layout().size(e21).nodes(s11).links(o12).avoidOverlaps(false).linkDistance(30).symmetricDiffLinkLengths(5).convergenceThreshold(1e-4).start(100, 0, 0, 0, false), { cola: new le2.Layout().convergenceThreshold(1e-3).size(e21).avoidOverlaps(true).nodes(t16.nodes).links(t16.links).groupCompactness(1e-4).linkDistance(30).symmetricDiffLinkLengths(5).powerGraphGroups(function(t17) {
      (r9 = t17).groups.forEach(function(t18) {
        t18.padding = n12;
      });
    }).start(50, 0, 100, 0, false), powerGraph: r9 };
  }, function(t16) {
    function e21(e22) {
      for (var n12 in e22)
        t16.hasOwnProperty(n12) || (t16[n12] = e22[n12]);
    }
    Object.defineProperty(t16, "__esModule", { value: true }), e21(n8), e21(jt5), e21(v7), e21(ht5), e21(Kt5), e21(Ct5), e21(r6), e21(re2), e21(p7), e21(i7), e21(et5), e21(S7), e21(m8), e21(tt5), e21(b7), e21(fe2);
  }(e16);
  var ge2 = e16.BiTangent;
  var ve2 = e16.BiTangents;
  var ye2 = e16.Block;
  var _e2 = e16.Blocks;
  var xe2 = e16.Calculator;
  var me2 = e16.Configuration;
  var be2 = e16.Constraint;
  var ke2 = e16.ConvexHull;
  var we2 = e16.Descent;
  var Ee2 = e16.EventType;
  var Pe2 = e16.GridRouter;
  var Le2 = e16.IndexedVariable;
  var Me2 = e16.Iterator;
  var Ae2 = e16.LLtangent_PolyPolyC;
  var Se2 = e16.LRtangent_PolyPolyC;
  var Oe2 = e16.Layout;
  var Ce2 = e16.Layout3D;
  var Ne2 = e16.LayoutAdaptor;
  var Ie2 = e16.LineSegment;
  var Te2 = e16.Link3D;
  var Ge2 = e16.LinkSets;
  var Ve2 = e16.Locks;
  var De2 = e16.LongestCommonSubsequence;
  var je2 = e16.Module;
  var Be2 = e16.ModuleSet;
  var Re2 = e16.Node3D;
  var Xe2 = e16.NodeWrapper;
  var ze2 = e16.PairingHeap;
  var Ye2 = e16.Point;
  var qe2 = e16.PolyPoint;
  var Fe2 = e16.PositionStats;
  var He2 = e16.PowerEdge;
  var Ue2 = e16.PriorityQueue;
  var We2 = e16.Projection;
  var Ke2 = e16.PseudoRandom;
  var Qe2 = e16.RBTree;
  var Ze2 = e16.RLtangent_PolyPolyC;
  var Je2 = e16.RRtangent_PolyPolyC;
  var $e2 = e16.Rectangle;
  var tn2 = e16.Solver;
  var en2 = e16.TVGPoint;
  var nn2 = e16.TangentVisibilityGraph;
  var rn2 = e16.TreeBase;
  var on2 = e16.Variable;
  var sn2 = e16.Vert;
  var an2 = e16.VisibilityEdge;
  var un2 = e16.VisibilityVertex;
  var hn2 = e16.__esModule;
  var cn2 = e16.adaptor;
  var pn2 = e16.applyPacking;
  var fn2 = e16.clockwiseRadialSweep;
  var ln2 = e16.computeGroupBounds;
  var dn2 = e16.d3adaptor;
  var gn2 = e16.generateDirectedEdgeConstraints;
  var vn2 = e16.generateXConstraints;
  var yn2 = e16.generateXGroupConstraints;
  var _n2 = e16.generateYConstraints;
  var xn2 = e16.generateYGroupConstraints;
  var mn2 = e16.getGroups;
  var bn2 = e16.gridify;
  var kn2 = e16.isLeft;
  var wn2 = e16.jaccardLinkLengths;
  var En2 = e16.makeEdgeBetween;
  var Pn2 = e16.makeEdgeTo;
  var Ln2 = e16.polysOverlap;
  var Mn2 = e16.powerGraphGridLayout;
  var An2 = e16.removeOverlapInOneDimension;
  var Sn2 = e16.removeOverlaps;
  var On2 = e16.separateGraphs;
  var Cn2 = e16.stronglyConnectedComponents;
  var Nn2 = e16.symmetricDiffLinkLengths;
  var In2 = e16.tangent_PolyPolyC;
  var Tn2 = e16.tangents;

  // http-url:https://cdn.jsdelivr.net/npm/cytoscape-cola@2.5.1/+esm
  var t12 = { exports: {} };
  var e17 = t12.exports = function(n12) {
    return function(n13) {
      var t16 = {};
      function e21(o12) {
        if (t16[o12])
          return t16[o12].exports;
        var i11 = t16[o12] = { i: o12, l: false, exports: {} };
        return n13[o12].call(i11.exports, i11, i11.exports, e21), i11.l = true, i11.exports;
      }
      return e21.m = n13, e21.c = t16, e21.i = function(n14) {
        return n14;
      }, e21.d = function(n14, t17, o12) {
        e21.o(n14, t17) || Object.defineProperty(n14, t17, { configurable: false, enumerable: true, get: o12 });
      }, e21.n = function(n14) {
        var t17 = n14 && n14.__esModule ? function() {
          return n14.default;
        } : function() {
          return n14;
        };
        return e21.d(t17, "a", t17), t17;
      }, e21.o = function(n14, t17) {
        return Object.prototype.hasOwnProperty.call(n14, t17);
      }, e21.p = "", e21(e21.s = 3);
    }([function(n13, t16, e21) {
      var o12 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(n14) {
        return typeof n14;
      } : function(n14) {
        return n14 && "function" == typeof Symbol && n14.constructor === Symbol && n14 !== Symbol.prototype ? "symbol" : typeof n14;
      }, i11 = e21(1), r9 = e21(2), a10 = e21(5) || ("undefined" != typeof window ? window.cola : null), c10 = e21(4), u10 = function(n14) {
        return (void 0 === n14 ? "undefined" : o12(n14)) === o12(0);
      }, f11 = function() {
      }, s11 = function(n14, t17) {
        var e22;
        return null != (e22 = n14) && (void 0 === e22 ? "undefined" : o12(e22)) === o12(function() {
        }) ? n14.apply(t17, [t17]) : n14;
      };
      function d12(n14) {
        this.options = i11({}, r9, n14);
      }
      d12.prototype.run = function() {
        var n14 = this, t17 = this.options;
        n14.manuallyStopped = false;
        var e22 = t17.cy, i12 = t17.eles, r10 = i12.nodes(), d13 = i12.edges(), l11 = false, p10 = r10.filter(function(n15) {
          return n15.isParent();
        }), y10 = r10.subtract(p10), h10 = t17.boundingBox || { x1: 0, y1: 0, w: e22.width(), h: e22.height() };
        void 0 === h10.x2 && (h10.x2 = h10.x1 + h10.w), void 0 === h10.w && (h10.w = h10.x2 - h10.x1), void 0 === h10.y2 && (h10.y2 = h10.y1 + h10.h), void 0 === h10.h && (h10.h = h10.y2 - h10.y1);
        var g9 = function() {
          for (var n15 = 0; n15 < r10.length; n15++) {
            var o13 = r10[n15], i13 = o13.layoutDimensions(t17), a11 = o13.scratch("cola");
            if (!a11.updatedDims) {
              var c11 = s11(t17.nodeSpacing, o13);
              a11.width = i13.w + 2 * c11, a11.height = i13.h + 2 * c11;
            }
          }
          r10.positions(function(n16) {
            var t18 = n16.scratch().cola, e23 = void 0;
            return !n16.grabbed() && y10.contains(n16) && (e23 = { x: h10.x1 + t18.x, y: h10.y1 + t18.y }, u10(e23.x) && u10(e23.y) || (e23 = void 0)), e23;
          }), r10.updateCompoundBounds(), l11 || (v12(), l11 = true), t17.fit && e22.fit(t17.padding);
        }, m12 = function() {
          t17.ungrabifyWhileSimulating && w11.grabify(), e22.off("destroy", S8), r10.off("grab free position", k10), r10.off("lock unlock", L9), n14.one("layoutstop", t17.stop), n14.trigger({ type: "layoutstop", layout: n14 });
        }, v12 = function() {
          n14.one("layoutready", t17.ready), n14.trigger({ type: "layoutready", layout: n14 });
        }, x10 = t17.refresh;
        x10 = t17.refresh < 0 ? 1 : Math.max(1, x10);
        var b11 = n14.adaptor = a10.adaptor({ trigger: function(n15) {
          var e23 = a10.EventType ? a10.EventType.tick : null, o13 = a10.EventType ? a10.EventType.end : null;
          switch (n15.type) {
            case "tick":
            case e23:
              t17.animate && g9();
              break;
            case "end":
            case o13:
              g9(), t17.infinite || m12();
          }
        }, kick: function() {
          var e23 = true, o13 = function() {
            if (n14.manuallyStopped)
              return m12(), true;
            var o14 = b11.tick();
            return t17.infinite || e23 || b11.convergenceThreshold(t17.convergenceThreshold), e23 = false, o14 && t17.infinite && b11.resume(), o14;
          };
          if (t17.animate)
            c10(function n15() {
              (function() {
                for (var n16 = void 0, t18 = 0; t18 < x10 && !n16; t18++)
                  n16 = n16 || o13();
                return n16;
              })() || c10(n15);
            });
          else
            for (; !o13(); )
              ;
        }, on: f11, drag: f11 });
        n14.adaptor = b11;
        var w11 = r10.filter(":grabbable");
        t17.ungrabifyWhileSimulating && w11.ungrabify();
        var S8 = void 0;
        e22.one("destroy", S8 = function() {
          n14.stop();
        });
        var k10 = void 0;
        r10.on("grab free position", k10 = function(n15) {
          var t18 = this, e23 = t18.scratch().cola, o13 = t18.position();
          if (n15.cyTarget === t18 || n15.target === t18)
            switch (n15.type) {
              case "grab":
                b11.dragstart(e23);
                break;
              case "free":
                b11.dragend(e23);
                break;
              case "position":
                e23.px === o13.x - h10.x1 && e23.py === o13.y - h10.y1 || (e23.px = o13.x - h10.x1, e23.py = o13.y - h10.y1);
            }
        });
        var L9 = void 0;
        r10.on("lock unlock", L9 = function() {
          var n15 = this, t18 = n15.scratch().cola;
          t18.fixed = n15.locked(), n15.locked() ? b11.dragstart(t18) : b11.dragend(t18);
        }), b11.nodes(y10.map(function(n15, e23) {
          var o13 = s11(t17.nodeSpacing, n15), i13 = n15.position(), r11 = n15.layoutDimensions(t17);
          return n15.scratch().cola = { x: t17.randomize && !n15.locked() || void 0 === i13.x ? Math.round(Math.random() * h10.w) : i13.x, y: t17.randomize && !n15.locked() || void 0 === i13.y ? Math.round(Math.random() * h10.h) : i13.y, width: r11.w + 2 * o13, height: r11.h + 2 * o13, index: e23, fixed: n15.locked() };
        }));
        var T9 = [];
        t17.alignment && (t17.alignment.vertical && t17.alignment.vertical.forEach(function(n15) {
          var t18 = [];
          n15.forEach(function(n16) {
            var e23 = n16.node.scratch().cola.index;
            t18.push({ node: e23, offset: n16.offset ? n16.offset : 0 });
          }), T9.push({ type: "alignment", axis: "x", offsets: t18 });
        }), t17.alignment.horizontal && t17.alignment.horizontal.forEach(function(n15) {
          var t18 = [];
          n15.forEach(function(n16) {
            var e23 = n16.node.scratch().cola.index;
            t18.push({ node: e23, offset: n16.offset ? n16.offset : 0 });
          }), T9.push({ type: "alignment", axis: "y", offsets: t18 });
        })), t17.gapInequalities && t17.gapInequalities.forEach(function(n15) {
          var t18 = n15.left.scratch().cola.index, e23 = n15.right.scratch().cola.index;
          T9.push({ axis: n15.axis, left: t18, right: e23, gap: n15.gap, equality: n15.equality });
        }), T9.length > 0 && b11.constraints(T9), b11.groups(p10.map(function(n15, e23) {
          var o13 = s11(t17.nodeSpacing, n15), i13 = function(t18) {
            return parseFloat(n15.style("padding-" + t18));
          }, r11 = i13("left") + o13, a11 = i13("right") + o13, c11 = i13("top") + o13, u11 = i13("bottom") + o13;
          return n15.scratch().cola = { index: e23, padding: Math.max(r11, a11, c11, u11), leaves: n15.children().intersection(y10).map(function(n16) {
            return n16[0].scratch().cola.index;
          }), fixed: n15.locked() }, n15;
        }).map(function(n15) {
          return n15.scratch().cola.groups = n15.children().intersection(p10).map(function(n16) {
            return n16.scratch().cola.index;
          }), n15.scratch().cola;
        }));
        var D9, E9 = void 0, I8 = void 0;
        if (null != t17.edgeLength ? (E9 = t17.edgeLength, I8 = "linkDistance") : null != t17.edgeSymDiffLength ? (E9 = t17.edgeSymDiffLength, I8 = "symmetricDiffLinkLengths") : null != t17.edgeJaccardLength ? (E9 = t17.edgeJaccardLength, I8 = "jaccardLinkLengths") : (E9 = 100, I8 = "linkDistance"), b11.links(d13.stdFilter(function(n15) {
          return y10.contains(n15.source()) && y10.contains(n15.target());
        }).map(function(n15) {
          var t18 = n15.scratch().cola = { source: n15.source()[0].scratch().cola.index, target: n15.target()[0].scratch().cola.index };
          return null != E9 && (t18.calcLength = s11(E9, n15)), t18;
        })), b11.size([h10.w, h10.h]), null != E9 && b11[I8](function(n15) {
          return n15.calcLength;
        }), t17.flow) {
          var O10 = void 0;
          (void 0 === (D9 = t17.flow) ? "undefined" : o12(D9)) === o12("") ? O10 = { axis: t17.flow, minSeparation: 50 } : u10(t17.flow) ? O10 = { axis: "y", minSeparation: t17.flow } : function(n15) {
            return null != n15 && (void 0 === n15 ? "undefined" : o12(n15)) === o12({});
          }(t17.flow) ? ((O10 = t17.flow).axis = O10.axis || "y", O10.minSeparation = null != O10.minSeparation ? O10.minSeparation : 50) : O10 = { axis: "y", minSeparation: 50 }, b11.flowLayout(O10.axis, O10.minSeparation);
        }
        return n14.trigger({ type: "layoutstart", layout: n14 }), b11.avoidOverlaps(t17.avoidOverlap).handleDisconnected(t17.handleDisconnected).start(t17.unconstrIter, t17.userConstIter, t17.allConstIter, void 0, void 0, t17.centerGraph), t17.infinite || setTimeout(function() {
          n14.manuallyStopped || b11.stop();
        }, t17.maxSimulationTime), this;
      }, d12.prototype.stop = function() {
        return this.adaptor && (this.manuallyStopped = true, this.adaptor.stop()), this;
      }, n13.exports = d12;
    }, function(n13, t16, e21) {
      n13.exports = null != Object.assign ? Object.assign.bind(Object) : function(n14) {
        for (var t17 = arguments.length, e22 = Array(t17 > 1 ? t17 - 1 : 0), o12 = 1; o12 < t17; o12++)
          e22[o12 - 1] = arguments[o12];
        return e22.filter(function(n15) {
          return null != n15;
        }).forEach(function(t18) {
          Object.keys(t18).forEach(function(e23) {
            return n14[e23] = t18[e23];
          });
        }), n14;
      };
    }, function(n13, t16, e21) {
      var o12 = { animate: true, refresh: 1, maxSimulationTime: 4e3, ungrabifyWhileSimulating: false, fit: true, padding: 30, boundingBox: void 0, nodeDimensionsIncludeLabels: false, ready: function() {
      }, stop: function() {
      }, randomize: false, avoidOverlap: true, handleDisconnected: true, convergenceThreshold: 0.01, nodeSpacing: function(n14) {
        return 10;
      }, flow: void 0, alignment: void 0, gapInequalities: void 0, centerGraph: true, edgeLength: void 0, edgeSymDiffLength: void 0, edgeJaccardLength: void 0, unconstrIter: void 0, userConstIter: void 0, allConstIter: void 0, infinite: false };
      n13.exports = o12;
    }, function(n13, t16, e21) {
      var o12 = e21(0), i11 = function(n14) {
        n14 && n14("layout", "cola", o12);
      };
      "undefined" != typeof cytoscape && i11(cytoscape), n13.exports = i11;
    }, function(n13, t16, e21) {
      var o12 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(n14) {
        return typeof n14;
      } : function(n14) {
        return n14 && "function" == typeof Symbol && n14.constructor === Symbol && n14 !== Symbol.prototype ? "symbol" : typeof n14;
      }, i11 = void 0;
      i11 = "undefined" !== ("undefined" == typeof window ? "undefined" : o12(window)) ? window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.msRequestAnimationFrame || function(n14) {
        return setTimeout(n14, 16);
      } : function(n14) {
        n14();
      }, n13.exports = i11;
    }, function(t16, e21) {
      t16.exports = n12;
    }]);
  }(e16);

  // http-url:https://cdn.jsdelivr.net/npm/@floating-ui/utils@0.1.1/+esm
  var t13 = ["top", "right", "bottom", "left"];
  var n9 = ["start", "end"];
  var o9 = t13.reduce((t16, o12) => t16.concat(o12, o12 + "-" + n9[0], o12 + "-" + n9[1]), []);
  var r7 = Math.min;
  var e18 = Math.max;
  var u8 = Math.round;
  var c8 = (t16) => ({ x: t16, y: t16 });
  var f8 = { left: "right", right: "left", bottom: "top", top: "bottom" };
  var a7 = { start: "end", end: "start" };
  function h8(t16, n12) {
    return "function" == typeof t16 ? t16(n12) : t16;
  }
  function p8(t16) {
    return t16.split("-")[0];
  }
  function s8(t16) {
    return t16.split("-")[1];
  }
  function m9(t16) {
    return "x" === t16 ? "y" : "x";
  }
  function g8(t16) {
    return "y" === t16 ? "height" : "width";
  }
  function b8(t16) {
    return ["top", "bottom"].includes(p8(t16)) ? "y" : "x";
  }
  function d9(t16) {
    return m9(b8(t16));
  }
  function x8(t16, n12, o12) {
    void 0 === o12 && (o12 = false);
    const r9 = s8(t16), e21 = d9(t16), u10 = g8(e21);
    let i11 = "x" === e21 ? r9 === (o12 ? "end" : "start") ? "right" : "left" : "start" === r9 ? "bottom" : "top";
    return n12.reference[u10] > n12.floating[u10] && (i11 = v8(i11)), [i11, v8(i11)];
  }
  function y8(t16) {
    const n12 = v8(t16);
    return [M8(t16), n12, M8(n12)];
  }
  function M8(t16) {
    return t16.replace(/start|end/g, (t17) => a7[t17]);
  }
  function w8(t16, n12, o12, r9) {
    const e21 = s8(t16);
    let u10 = function(t17, n13, o13) {
      const r10 = ["left", "right"], e22 = ["right", "left"], u11 = ["top", "bottom"], i11 = ["bottom", "top"];
      switch (t17) {
        case "top":
        case "bottom":
          return o13 ? n13 ? e22 : r10 : n13 ? r10 : e22;
        case "left":
        case "right":
          return n13 ? u11 : i11;
        default:
          return [];
      }
    }(p8(t16), "start" === o12, r9);
    return e21 && (u10 = u10.map((t17) => t17 + "-" + e21), n12 && (u10 = u10.concat(u10.map(M8)))), u10;
  }
  function v8(t16) {
    return t16.replace(/left|right|bottom|top/g, (t17) => f8[t17]);
  }
  function j8(t16) {
    return { top: 0, right: 0, bottom: 0, left: 0, ...t16 };
  }
  function k7(t16) {
    return "number" != typeof t16 ? j8(t16) : { top: t16, right: t16, bottom: t16, left: t16 };
  }
  function q7(t16) {
    return { ...t16, top: t16.y, left: t16.x, right: t16.x + t16.width, bottom: t16.y + t16.height };
  }

  // http-url:https://cdn.jsdelivr.net/npm/@floating-ui/core@1.4.1/+esm
  function w9(e21, t16, n12) {
    let { reference: r9, floating: l11 } = e21;
    const s11 = b8(t16), c10 = d9(t16), m12 = g8(c10), u10 = p8(t16), g9 = "y" === s11, p10 = r9.x + r9.width / 2 - l11.width / 2, h10 = r9.y + r9.height / 2 - l11.height / 2, y10 = r9[m12] / 2 - l11[m12] / 2;
    let x10;
    switch (u10) {
      case "top":
        x10 = { x: p10, y: r9.y - l11.height };
        break;
      case "bottom":
        x10 = { x: p10, y: r9.y + r9.height };
        break;
      case "right":
        x10 = { x: r9.x + r9.width, y: h10 };
        break;
      case "left":
        x10 = { x: r9.x - l11.width, y: h10 };
        break;
      default:
        x10 = { x: r9.x, y: r9.y };
    }
    switch (s8(t16)) {
      case "start":
        x10[c10] -= y10 * (n12 && g9 ? -1 : 1);
        break;
      case "end":
        x10[c10] += y10 * (n12 && g9 ? -1 : 1);
    }
    return x10;
  }
  var v9 = async (e21, t16, n12) => {
    const { placement: i11 = "bottom", strategy: o12 = "absolute", middleware: r9 = [], platform: l11 } = n12, a10 = r9.filter(Boolean), s11 = await (null == l11.isRTL ? void 0 : l11.isRTL(t16));
    let c10 = await l11.getElementRects({ reference: e21, floating: t16, strategy: o12 }), { x: f11, y: m12 } = w9(c10, i11, s11), u10 = i11, g9 = {}, d12 = 0;
    for (let n13 = 0; n13 < a10.length; n13++) {
      const { name: r10, fn: p10 } = a10[n13], { x: h10, y: y10, data: x10, reset: v12 } = await p10({ x: f11, y: m12, initialPlacement: i11, placement: u10, strategy: o12, middlewareData: g9, rects: c10, platform: l11, elements: { reference: e21, floating: t16 } });
      f11 = null != h10 ? h10 : f11, m12 = null != y10 ? y10 : m12, g9 = { ...g9, [r10]: { ...g9[r10], ...x10 } }, v12 && d12 <= 50 && (d12++, "object" == typeof v12 && (v12.placement && (u10 = v12.placement), v12.rects && (c10 = true === v12.rects ? await l11.getElementRects({ reference: e21, floating: t16, strategy: o12 }) : v12.rects), { x: f11, y: m12 } = w9(c10, u10, s11)), n13 = -1);
    }
    return { x: f11, y: m12, placement: u10, strategy: o12, middlewareData: g9 };
  };
  async function b9(i11, o12) {
    var r9;
    void 0 === o12 && (o12 = {});
    const { x: l11, y: a10, platform: s11, rects: c10, elements: f11, strategy: m12 } = i11, { boundary: u10 = "clippingAncestors", rootBoundary: g9 = "viewport", elementContext: d12 = "floating", altBoundary: p10 = false, padding: h10 = 0 } = h8(o12, i11), y10 = k7(h10), x10 = f11[p10 ? "floating" === d12 ? "reference" : "floating" : d12], w11 = q7(await s11.getClippingRect({ element: null == (r9 = await (null == s11.isElement ? void 0 : s11.isElement(x10))) || r9 ? x10 : x10.contextElement || await (null == s11.getDocumentElement ? void 0 : s11.getDocumentElement(f11.floating)), boundary: u10, rootBoundary: g9, strategy: m12 })), v12 = "floating" === d12 ? { ...c10.floating, x: l11, y: a10 } : c10.reference, b11 = await (null == s11.getOffsetParent ? void 0 : s11.getOffsetParent(f11.floating)), A10 = await (null == s11.isElement ? void 0 : s11.isElement(b11)) && await (null == s11.getScale ? void 0 : s11.getScale(b11)) || { x: 1, y: 1 }, R8 = q7(s11.convertOffsetParentRelativeRectToViewportRelativeRect ? await s11.convertOffsetParentRelativeRectToViewportRelativeRect({ rect: v12, offsetParent: b11, strategy: m12 }) : v12);
    return { top: (w11.top - R8.top + y10.top) / A10.y, bottom: (R8.bottom - w11.bottom + y10.bottom) / A10.y, left: (w11.left - R8.left + y10.left) / A10.x, right: (R8.right - w11.right + y10.right) / A10.x };
  }
  var P8 = function(t16) {
    return void 0 === t16 && (t16 = {}), { name: "flip", options: t16, async fn(n12) {
      var i11;
      const { placement: o12, middlewareData: r9, rects: l11, initialPlacement: a10, platform: s11, elements: d12 } = n12, { mainAxis: p10 = true, crossAxis: h10 = true, fallbackPlacements: y10, fallbackStrategy: x10 = "bestFit", fallbackAxisSideDirection: w11 = "none", flipAlignment: v12 = true, ...A10 } = h8(t16, n12), R8 = p8(o12), P10 = p8(a10) === a10, T9 = await (null == s11.isRTL ? void 0 : s11.isRTL(d12.floating)), E9 = y10 || (P10 || !v12 ? [v8(a10)] : y8(a10));
      y10 || "none" === w11 || E9.push(...w8(a10, v12, w11, T9));
      const D9 = [a10, ...E9], L9 = await b9(n12, A10), k10 = [];
      let O10 = (null == (i11 = r9.flip) ? void 0 : i11.overflows) || [];
      if (p10 && k10.push(L9[R8]), h10) {
        const e21 = x8(o12, l11, T9);
        k10.push(L9[e21[0]], L9[e21[1]]);
      }
      if (O10 = [...O10, { placement: o12, overflows: k10 }], !k10.every((e21) => e21 <= 0)) {
        var C9, B9;
        const e21 = ((null == (C9 = r9.flip) ? void 0 : C9.index) || 0) + 1, t17 = D9[e21];
        if (t17)
          return { data: { index: e21, overflows: O10 }, reset: { placement: t17 } };
        let n13 = null == (B9 = O10.filter((e22) => e22.overflows[0] <= 0).sort((e22, t18) => e22.overflows[1] - t18.overflows[1])[0]) ? void 0 : B9.placement;
        if (!n13)
          switch (x10) {
            case "bestFit": {
              var H8;
              const e22 = null == (H8 = O10.map((e23) => [e23.placement, e23.overflows.filter((e24) => e24 > 0).reduce((e24, t18) => e24 + t18, 0)]).sort((e23, t18) => e23[1] - t18[1])[0]) ? void 0 : H8[0];
              e22 && (n13 = e22);
              break;
            }
            case "initialPlacement":
              n13 = a10;
          }
        if (o12 !== n13)
          return { reset: { placement: n13 } };
      }
      return {};
    } };
  };

  // http-url:https://cdn.jsdelivr.net/npm/@floating-ui/utils@0.1.1/dom/+esm
  function n10(n12) {
    return o10(n12) ? (n12.nodeName || "").toLowerCase() : "#document";
  }
  function e19(n12) {
    var e21;
    return (null == n12 || null == (e21 = n12.ownerDocument) ? void 0 : e21.defaultView) || window;
  }
  function t14(n12) {
    var e21;
    return null == (e21 = (o10(n12) ? n12.ownerDocument : n12.document) || window.document) ? void 0 : e21.documentElement;
  }
  function o10(n12) {
    return n12 instanceof Node || n12 instanceof e19(n12).Node;
  }
  function r8(n12) {
    return n12 instanceof Element || n12 instanceof e19(n12).Element;
  }
  function c9(n12) {
    return n12 instanceof HTMLElement || n12 instanceof e19(n12).HTMLElement;
  }
  function u9(n12) {
    return "undefined" != typeof ShadowRoot && (n12 instanceof ShadowRoot || n12 instanceof e19(n12).ShadowRoot);
  }
  function i8(n12) {
    const { overflow: e21, overflowX: t16, overflowY: o12, display: r9 } = p9(n12);
    return /auto|scroll|overlay|hidden|clip/.test(e21 + o12 + t16) && !["inline", "contents"].includes(r9);
  }
  function l9(e21) {
    return ["table", "td", "th"].includes(n10(e21));
  }
  function f9(n12) {
    const e21 = d10(), t16 = p9(n12);
    return "none" !== t16.transform || "none" !== t16.perspective || !!t16.containerType && "normal" !== t16.containerType || !e21 && !!t16.backdropFilter && "none" !== t16.backdropFilter || !e21 && !!t16.filter && "none" !== t16.filter || ["transform", "perspective", "filter"].some((n13) => (t16.willChange || "").includes(n13)) || ["paint", "layout", "strict", "content"].some((n13) => (t16.contain || "").includes(n13));
  }
  function s9(n12) {
    let e21 = w10(n12);
    for (; c9(e21) && !a8(e21); ) {
      if (f9(e21))
        return e21;
      e21 = w10(e21);
    }
    return null;
  }
  function d10() {
    return !("undefined" == typeof CSS || !CSS.supports) && CSS.supports("-webkit-backdrop-filter", "none");
  }
  function a8(e21) {
    return ["html", "body", "#document"].includes(n10(e21));
  }
  function p9(n12) {
    return e19(n12).getComputedStyle(n12);
  }
  function m10(n12) {
    return r8(n12) ? { scrollLeft: n12.scrollLeft, scrollTop: n12.scrollTop } : { scrollLeft: n12.pageXOffset, scrollTop: n12.pageYOffset };
  }
  function w10(e21) {
    if ("html" === n10(e21))
      return e21;
    const o12 = e21.assignedSlot || e21.parentNode || u9(e21) && e21.host || t14(e21);
    return u9(o12) ? o12.host : o12;
  }
  function v10(n12) {
    const e21 = w10(n12);
    return a8(e21) ? n12.ownerDocument ? n12.ownerDocument.body : n12.body : c9(e21) && i8(e21) ? e21 : v10(e21);
  }
  function y9(n12, t16) {
    var o12;
    void 0 === t16 && (t16 = []);
    const r9 = v10(n12), c10 = r9 === (null == (o12 = n12.ownerDocument) ? void 0 : o12.body), u10 = e19(r9);
    return c10 ? t16.concat(u10, u10.visualViewport || [], i8(r9) ? r9 : []) : t16.concat(r9, y9(r9));
  }

  // http-url:https://cdn.jsdelivr.net/npm/@floating-ui/dom@1.5.1/+esm
  function L7(t16) {
    const e21 = p9(t16);
    let n12 = parseFloat(e21.width) || 0, o12 = parseFloat(e21.height) || 0;
    const r9 = c9(t16), l11 = r9 ? t16.offsetWidth : n12, c10 = r9 ? t16.offsetHeight : o12, s11 = u8(n12) !== l11 || u8(o12) !== c10;
    return s11 && (n12 = l11, o12 = c10), { width: n12, height: o12, $: s11 };
  }
  function R7(t16) {
    return r8(t16) ? t16 : t16.contextElement;
  }
  function T8(t16) {
    const e21 = R7(t16);
    if (!c9(e21))
      return c8(1);
    const o12 = e21.getBoundingClientRect(), { width: r9, height: l11, $: c10 } = L7(e21);
    let s11 = (c10 ? u8(o12.width) : o12.width) / r9, f11 = (c10 ? u8(o12.height) : o12.height) / l11;
    return s11 && Number.isFinite(s11) || (s11 = 1), f11 && Number.isFinite(f11) || (f11 = 1), { x: s11, y: f11 };
  }
  var E8 = c8(0);
  function F8(t16) {
    const e21 = e19(t16);
    return d10() && e21.visualViewport ? { x: e21.visualViewport.offsetLeft, y: e21.visualViewport.offsetTop } : E8;
  }
  function O9(t16, i11, o12, r9) {
    void 0 === i11 && (i11 = false), void 0 === o12 && (o12 = false);
    const l11 = t16.getBoundingClientRect(), c10 = R7(t16);
    let f11 = c8(1);
    i11 && (r9 ? r8(r9) && (f11 = T8(r9)) : f11 = T8(t16));
    const u10 = function(t17, e21, n12) {
      return void 0 === e21 && (e21 = false), !(!n12 || e21 && n12 !== e19(t17)) && e21;
    }(c10, o12, r9) ? F8(c10) : c8(0);
    let d12 = (l11.left + u10.x) / f11.x, p10 = (l11.top + u10.y) / f11.y, g9 = l11.width / f11.x, m12 = l11.height / f11.y;
    if (c10) {
      const t17 = e19(c10), e21 = r9 && r8(r9) ? e19(r9) : r9;
      let n12 = t17.frameElement;
      for (; n12 && r9 && e21 !== t17; ) {
        const t18 = T8(n12), e22 = n12.getBoundingClientRect(), i12 = p9(n12), o13 = e22.left + (n12.clientLeft + parseFloat(i12.paddingLeft)) * t18.x, r10 = e22.top + (n12.clientTop + parseFloat(i12.paddingTop)) * t18.y;
        d12 *= t18.x, p10 *= t18.y, g9 *= t18.x, m12 *= t18.y, d12 += o13, p10 += r10, n12 = e19(n12).frameElement;
      }
    }
    return q7({ width: g9, height: m12, x: d12, y: p10 });
  }
  function W7(t16) {
    return O9(t14(t16)).left + m10(t16).scrollLeft;
  }
  function H7(t16, i11, r9) {
    let l11;
    if ("viewport" === i11)
      l11 = function(t17, e21) {
        const n12 = e19(t17), i12 = t14(t17), o12 = n12.visualViewport;
        let r10 = i12.clientWidth, l12 = i12.clientHeight, s11 = 0, f11 = 0;
        if (o12) {
          r10 = o12.width, l12 = o12.height;
          const t18 = d10();
          (!t18 || t18 && "fixed" === e21) && (s11 = o12.offsetLeft, f11 = o12.offsetTop);
        }
        return { width: r10, height: l12, x: s11, y: f11 };
      }(t16, r9);
    else if ("document" === i11)
      l11 = function(t17) {
        const e21 = t14(t17), n12 = m10(t17), i12 = t17.ownerDocument.body, r10 = e18(e21.scrollWidth, e21.clientWidth, i12.scrollWidth, i12.clientWidth), l12 = e18(e21.scrollHeight, e21.clientHeight, i12.scrollHeight, i12.clientHeight);
        let s11 = -n12.scrollLeft + W7(t17);
        const f11 = -n12.scrollTop;
        return "rtl" === p9(i12).direction && (s11 += e18(e21.clientWidth, i12.clientWidth) - r10), { width: r10, height: l12, x: s11, y: f11 };
      }(t14(t16));
    else if (r8(i11))
      l11 = function(t17, e21) {
        const i12 = O9(t17, true, "fixed" === e21), o12 = i12.top + t17.clientTop, r10 = i12.left + t17.clientLeft, l12 = c9(t17) ? T8(t17) : c8(1);
        return { width: t17.clientWidth * l12.x, height: t17.clientHeight * l12.y, x: r10 * l12.x, y: o12 * l12.y };
      }(i11, r9);
    else {
      const e21 = F8(t16);
      l11 = { ...i11, x: i11.x - e21.x, y: i11.y - e21.y };
    }
    return q7(l11);
  }
  function z7(t16, e21) {
    const n12 = w10(t16);
    return !(n12 === e21 || !r8(n12) || a8(n12)) && ("fixed" === p9(n12).position || z7(n12, e21));
  }
  function A9(t16, e21, i11) {
    const o12 = c9(e21), r9 = t14(e21), l11 = "fixed" === i11, s11 = O9(t16, true, l11, e21);
    let f11 = { scrollLeft: 0, scrollTop: 0 };
    const h10 = c8(0);
    if (o12 || !o12 && !l11)
      if (("body" !== n10(e21) || i8(r9)) && (f11 = m10(e21)), o12) {
        const t17 = O9(e21, true, l11, e21);
        h10.x = t17.x + e21.clientLeft, h10.y = t17.y + e21.clientTop;
      } else
        r9 && (h10.x = W7(r9));
    return { x: s11.left + f11.scrollLeft - h10.x, y: s11.top + f11.scrollTop - h10.y, width: s11.width, height: s11.height };
  }
  function C8(t16, e21) {
    return c9(t16) && "fixed" !== p9(t16).position ? e21 ? e21(t16) : t16.offsetParent : null;
  }
  function P9(t16, e21) {
    const n12 = e19(t16);
    if (!c9(t16))
      return n12;
    let i11 = C8(t16, e21);
    for (; i11 && l9(i11) && "static" === p9(i11).position; )
      i11 = C8(i11, e21);
    return i11 && ("html" === n10(i11) || "body" === n10(i11) && "static" === p9(i11).position && !f9(i11)) ? n12 : i11 || s9(t16) || n12;
  }
  var B8 = { convertOffsetParentRelativeRectToViewportRelativeRect: function(t16) {
    let { rect: e21, offsetParent: i11, strategy: o12 } = t16;
    const r9 = c9(i11), l11 = t14(i11);
    if (i11 === l11)
      return e21;
    let s11 = { scrollLeft: 0, scrollTop: 0 }, f11 = c8(1);
    const h10 = c8(0);
    if ((r9 || !r9 && "fixed" !== o12) && (("body" !== n10(i11) || i8(l11)) && (s11 = m10(i11)), c9(i11))) {
      const t17 = O9(i11);
      f11 = T8(i11), h10.x = t17.x + i11.clientLeft, h10.y = t17.y + i11.clientTop;
    }
    return { width: e21.width * f11.x, height: e21.height * f11.y, x: e21.x * f11.x - s11.scrollLeft * f11.x + h10.x, y: e21.y * f11.y - s11.scrollTop * f11.y + h10.y };
  }, getDocumentElement: t14, getClippingRect: function(t16) {
    let { element: e21, boundary: n12, rootBoundary: i11, strategy: l11 } = t16;
    const c10 = [..."clippingAncestors" === n12 ? function(t17, e22) {
      const n13 = e22.get(t17);
      if (n13)
        return n13;
      let i12 = y9(t17).filter((t18) => r8(t18) && "body" !== n10(t18)), o12 = null;
      const r9 = "fixed" === p9(t17).position;
      let l12 = r9 ? w10(t17) : t17;
      for (; r8(l12) && !a8(l12); ) {
        const e23 = p9(l12), n14 = f9(l12);
        n14 || "fixed" !== e23.position || (o12 = null), (r9 ? !n14 && !o12 : !n14 && "static" === e23.position && o12 && ["absolute", "fixed"].includes(o12.position) || i8(l12) && !n14 && z7(t17, l12)) ? i12 = i12.filter((t18) => t18 !== l12) : o12 = e23, l12 = w10(l12);
      }
      return e22.set(t17, i12), i12;
    }(e21, this._c) : [].concat(n12), i11], u10 = c10[0], h10 = c10.reduce((t17, n13) => {
      const i12 = H7(e21, n13, l11);
      return t17.top = e18(i12.top, t17.top), t17.right = r7(i12.right, t17.right), t17.bottom = r7(i12.bottom, t17.bottom), t17.left = e18(i12.left, t17.left), t17;
    }, H7(e21, u10, l11));
    return { width: h10.right - h10.left, height: h10.bottom - h10.top, x: h10.left, y: h10.top };
  }, getOffsetParent: P9, getElementRects: async function(t16) {
    let { reference: e21, floating: n12, strategy: i11 } = t16;
    const o12 = this.getOffsetParent || P9, r9 = this.getDimensions;
    return { reference: A9(e21, await o12(n12), i11), floating: { x: 0, y: 0, ...await r9(n12) } };
  }, getClientRects: function(t16) {
    return Array.from(t16.getClientRects());
  }, getDimensions: function(t16) {
    return L7(t16);
  }, getScale: T8, isElement: r8, isRTL: function(t16) {
    return "rtl" === p9(t16).direction;
  } };
  var V7 = (e21, n12, i11) => {
    const o12 = /* @__PURE__ */ new Map(), r9 = { platform: B8, ...i11 }, l11 = { ...r9.platform, _c: o12 };
    return v9(e21, n12, { ...r9, platform: l11 });
  };

  // components/tooltip.js
  var Tooltip = class extends x {
    constructor() {
      super();
      this.state = {
        style: {
          visibility: "hidden",
          left: 0,
          top: 0,
          zIndex: 0
        },
        mode: null
      };
    }
    attachTo(cyNode) {
      this.setState({ node: cyNode }, () => this.refreshPosition());
    }
    refreshPosition() {
      const { x: x10, y: y10 } = this.state.node.cy().container().getBoundingClientRect();
      const tooltip = this.base;
      const theNode = this.state.node;
      const virtualElt = {
        getBoundingClientRect() {
          const bbox = theNode.renderedBoundingBox();
          return {
            x: bbox.x1 + x10,
            y: bbox.y1 + y10,
            top: bbox.y1 + y10,
            left: bbox.x1 + x10,
            bottom: bbox.y2 + y10,
            right: bbox.x2 + x10,
            height: bbox.h,
            width: bbox.w
          };
        }
      };
      V7(virtualElt, tooltip, {
        placement: "right-end",
        middleware: [P8()]
      }).then(
        ({ x: x11, y: y11, placement }) => this.positionAt(x11, y11, placement)
      );
    }
    positionAt(x10, y10, placement) {
      this.setState({
        style: {
          flexDirection: placement.slice(-3) == "end" ? "column-reverse" : "column",
          visibility: "visible",
          left: `${x10}px`,
          top: `${y10}px`,
          zIndex: 5
        }
      });
    }
    getViewData() {
      switch (this.state.mode) {
        case "constraints": {
          return m2`<pre>${this.state.node?.data().constraints?.map?.(
            (c10) => m2`<div>${c10}</div>`
          )}</pre>`;
        }
        case "assembly": {
          return m2`<pre>${this.state.node.data().contents}</pre>`;
        }
        case "vex": {
          return m2`<pre>${this.state.node.data().vex}</pre>`;
        }
        case "errors": {
          if (this.state.node.data().error) {
            return m2`<pre>${this.state.node.data().error}</pre>`;
          } else if (this.state.node.data().spinning) {
            return m2`<pre>Spinning: Loop bounds exceeded</pre>`;
          } else {
            return null;
          }
        }
        case "stdout": {
          if (this.state.node.data().stdout) {
            return m2`<pre>${this.state.node.data().stdout}</pre>`;
          } else {
            return null;
          }
        }
        case "stderr": {
          if (this.state.node.data().stderr) {
            return m2`<pre>${this.state.node.data().stderr}</pre>`;
          } else {
            return null;
          }
        }
        case "simprocs": {
          return m2`<pre>${this.state.node?.data().simprocs?.map?.(
            (simproc) => m2`<div>${simproc}</div>`
          )}</pre>`;
        }
        case "assertion": {
          if (this.state.node?.data().assertion_info) {
            return m2`
          <div>${this.state.node?.data().assertion_info}</div>
          <pre>
          Condition: ${this.state.node?.data().failed_cond}<br/>
          Address: ${this.state.node?.data().assertion_addr}
          </pre>
          `;
          } else {
            return null;
          }
        }
        case "postcondition": {
          if (this.state.node?.data().postcondition_info) {
            return m2`
          <div>${this.state.node?.data().postcondition_info}</div>
          <pre>
          Condition: ${this.state.node?.data().failed_cond}<br/>
          </pre>
          `;
          } else {
            return null;
          }
        }
        default:
          return null;
      }
    }
    setView(mode) {
      this.setState({ mode }, () => this.refreshPosition());
    }
    clearTooltip() {
      this.setState({ style: {
        visibility: "hidden",
        left: 0,
        top: 0,
        zIndex: 0
      } });
    }
    render(_props, state) {
      return m2`<div id="tooltip" style=${state.style}>
      <div id="tooltip-buttons">
        <button
          data-highlighted=${state.mode == "assembly"} 
          onClick=${() => this.setView("assembly")}>
          Assembly
        </button>
        ${this.state.node?.data().constraints && m2`
          <button
            data-highlighted=${state.mode == "constraints"} 
            onClick=${() => this.setView("constraints")}>
            Constraints
          </button>`}
        ${this.state.node?.data().vex && m2`
          <button 
            data-highlighted=${state.mode == "vex"} 
            onClick=${() => this.setView("vex")}>
            Vex IR
          </button>`}
        ${(this.state.node?.data().error || this.state.node?.data().spinning) && m2`
          <button 
            data-highlighted=${state.mode == "errors"} 
            onClick=${() => this.setView("errors")}>
            Errors
          </button>`}
        ${this.state.node?.data().stdout && m2`
          <button 
            data-highlighted=${state.mode == "stdout"} 
            onClick=${() => this.setView("stdout")}>
            Stdout
          </button>`}
        ${this.state.node?.data().stderr && m2`
          <button 
            data-highlighted=${state.mode == "stderr"} 
            onClick=${() => this.setView("stderr")}>
            Stderr
          </button>`}
        ${this.state.node?.data().simprocs?.length > 0 && m2`
          <button 
            data-highlighted=${state.mode == "simprocs"} 
            onClick=${() => this.setView("simprocs")}>
            SimProcedures
          </button>`}
        ${this.state.node?.data().assertion_info && m2`
          <button 
            data-highlighted=${state.mode == "assertion"} 
            onClick=${() => this.setView("assertion")}>
            Assertion
          </button>`}
        ${this.state.node?.data().postcondition_info && m2`
          <button 
            data-highlighted=${state.mode == "postcondition"} 
            onClick=${() => this.setView("postcondition")}>
            Postcondition
          </button>`}
      </div>
      <div id="tooltip-data">${this.getViewData()}</div>
    </div>`;
    }
  };

  // components/concretions.js
  var Concretions = class extends x {
    constructor() {
      super();
      this.state = {
        view: "shared"
      };
    }
    render(props, state) {
      const rightId = props.rightFocus.bot.id();
      const leftId = props.leftFocus.bot.id();
      const examples = [];
      const sharedConcretions = props.leftFocus.bot.data().compatibilities[rightId].conc_args;
      const leftOnlyConcretions = Object.entries(props.leftFocus.bot.data().compatibilities).flatMap(
        ([key, compat]) => key == rightId ? [] : compat.conc_args
      );
      const rightOnlyConcretions = Object.entries(props.rightFocus.bot.data().compatibilities).flatMap(
        ([key, compat]) => key == leftId ? [] : compat.conc_args
      );
      const concretions = state.view == "shared" ? sharedConcretions : state.view == "left" ? leftOnlyConcretions : state.view == "right" ? rightOnlyConcretions : null;
      for (const concretion of concretions) {
        examples.push(m2`
        <pre class="concrete-example">${JSON.stringify(concretion, void 0, 2)}</pre>
      `);
      }
      const sharedMsg = sharedConcretions.length == 0 ? "No concretions available" : m2`Viewing ${sharedConcretions.length} concrete input examples shared by both branches`;
      const leftMsg = leftOnlyConcretions.length == 0 ? rightOnlyConcretions.length == 0 ? "There are no inputs that go down the left but not the right branch. The two branches correspond to exactly the same inputs." : "There are no inputs that go down the left but not the right branch. The left branch refines the right." : m2`Viewing ${leftOnlyConcretions.length} concrete input examples that go down the left but not the right branch`;
      const rightMsg = rightOnlyConcretions.length == 0 ? leftOnlyConcretions.length == 0 ? "There are no inputs that go down the right but not the left branch. The two branches correspond to exactly the same inputs." : "There are no inputs that go down the right but not the left branch. The right branch refines the left." : m2`Viewing ${rightOnlyConcretions.length} concrete input examples that go down the right but not the left branch`;
      return m2`
    <div class="subordinate-buttons">
      <button
        data-selected=${state.view == "shared"}
        onClick=${() => this.setState({ view: "shared" })}
      >Shared</button>
      <button
        data-selected=${state.view == "left"}
        onClick=${() => this.setState({ view: "left" })}
      >Left Branch Only</button>
      <button
        data-selected=${state.view == "right"}
        onClick=${() => this.setState({ view: "right" })}
      >Right Branch Only</button>
    </div>
    <div id="concretion-header">
      ${state.view == "shared" ? sharedMsg : state.view == "left" ? leftMsg : state.view == "right" ? rightMsg : null}
    </div>
    <div id="concretion-data">
      ${examples}
    </div>`;
    }
  };

  // util/segmentation.js
  function getNodesFromEnds(top, bottom) {
    const interval = [bottom];
    while (interval[interval.length - 1].id() !== top.id()) {
      interval.push(interval[interval.length - 1].incomers("node")[0]);
    }
    return interval;
  }
  function getEdgesFromEnds(top, bottom) {
    const nodes = getNodesFromEnds(top, bottom);
    nodes.pop();
    return nodes.map((node) => node.incomers("edge")[0]);
  }
  var Segment = class _Segment {
    constructor(top, bot) {
      this.cy = Pl({
        elements: bot.predecessors().intersection(top.successors()).union(top).union(bot).jsons()
      });
      this.top = this.cy.nodes().roots()[0];
      this.bot = this.cy.nodes().leaves()[0];
      this.cy = () => bot.cy();
    }
    static fromRange(range) {
      const bot = range.filter((ele) => ele.outgoers("node").intersection(range).length == 0)[0];
      const top = range.filter((ele) => ele.incomers("node").intersection(range).length == 0)[0];
      return new _Segment(top, bot);
    }
  };

  // components/hunk.js
  function hunkFormat(hunk, className) {
    const terminator = hunk.slice(-1);
    if (terminator === ">" || terminator == ",") {
      const newHunk = hunk.slice(0, hunk.length - 1);
      return m2`<span class=${className}>${newHunk}</span>${terminator} `;
    } else {
      return m2`<span class=${className}>${hunk}</span> `;
    }
  }
  function Hunk({ dim, highlight, hunkCtx, curLeft, curRight, leftContent, leftClass, rightContent, rightClass }) {
    const hunk = m2`<div
        onMouseEnter=${highlight} 
        onMouseLeave=${dim}
        >
        <div
          title=${hunkCtx?.leftMsgs[curLeft]}
          class=${leftClass}
        >${leftContent}</div>
        <div
          title=${hunkCtx?.rightMsgs[curRight]}
          class=${rightClass}
        >${rightContent}</div>
      </div>`;
    hunk.contentListing = { left: leftContent, right: rightContent };
    return hunk;
  }

  // http-url:https://cdn.jsdelivr.net/npm/diff@5.1.0/+esm
  function e20() {
  }
  function n11(e21, n12, t16, r9, i11) {
    for (var o12 = 0, l11 = n12.length, s11 = 0, a10 = 0; o12 < l11; o12++) {
      var u10 = n12[o12];
      if (u10.removed) {
        if (u10.value = e21.join(r9.slice(a10, a10 + u10.count)), a10 += u10.count, o12 && n12[o12 - 1].added) {
          var f11 = n12[o12 - 1];
          n12[o12 - 1] = n12[o12], n12[o12] = f11;
        }
      } else {
        if (!u10.added && i11) {
          var d12 = t16.slice(s11, s11 + u10.count);
          d12 = d12.map(function(e22, n13) {
            var t17 = r9[a10 + n13];
            return t17.length > e22.length ? t17 : e22;
          }), u10.value = e21.join(d12);
        } else
          u10.value = e21.join(t16.slice(s11, s11 + u10.count));
        s11 += u10.count, u10.added || (a10 += u10.count);
      }
    }
    var c10 = n12[l11 - 1];
    return l11 > 1 && "string" == typeof c10.value && (c10.added || c10.removed) && e21.equals("", c10.value) && (n12[l11 - 2].value += c10.value, n12.pop()), n12;
  }
  e20.prototype = { diff: function(e21, t16) {
    var r9 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, i11 = r9.callback;
    "function" == typeof r9 && (i11 = r9, r9 = {}), this.options = r9;
    var o12 = this;
    function l11(e22) {
      return i11 ? (setTimeout(function() {
        i11(void 0, e22);
      }, 0), true) : e22;
    }
    e21 = this.castInput(e21), t16 = this.castInput(t16), e21 = this.removeEmpty(this.tokenize(e21));
    var s11 = (t16 = this.removeEmpty(this.tokenize(t16))).length, a10 = e21.length, u10 = 1, f11 = s11 + a10;
    r9.maxEditLength && (f11 = Math.min(f11, r9.maxEditLength));
    var d12 = [{ newPos: -1, components: [] }], c10 = this.extractCommon(d12[0], t16, e21, 0);
    if (d12[0].newPos + 1 >= s11 && c10 + 1 >= a10)
      return l11([{ value: this.join(t16), count: t16.length }]);
    function h10() {
      for (var r10 = -1 * u10; r10 <= u10; r10 += 2) {
        var i12 = void 0, f12 = d12[r10 - 1], c11 = d12[r10 + 1], h11 = (c11 ? c11.newPos : 0) - r10;
        f12 && (d12[r10 - 1] = void 0);
        var p11 = f12 && f12.newPos + 1 < s11, v12 = c11 && 0 <= h11 && h11 < a10;
        if (p11 || v12) {
          if (!p11 || v12 && f12.newPos < c11.newPos ? (i12 = { newPos: (g9 = c11).newPos, components: g9.components.slice(0) }, o12.pushComponent(i12.components, void 0, true)) : ((i12 = f12).newPos++, o12.pushComponent(i12.components, true, void 0)), h11 = o12.extractCommon(i12, t16, e21, r10), i12.newPos + 1 >= s11 && h11 + 1 >= a10)
            return l11(n11(o12, i12.components, t16, e21, o12.useLongestToken));
          d12[r10] = i12;
        } else
          d12[r10] = void 0;
      }
      var g9;
      u10++;
    }
    if (i11)
      !function e22() {
        setTimeout(function() {
          if (u10 > f11)
            return i11();
          h10() || e22();
        }, 0);
      }();
    else
      for (; u10 <= f11; ) {
        var p10 = h10();
        if (p10)
          return p10;
      }
  }, pushComponent: function(e21, n12, t16) {
    var r9 = e21[e21.length - 1];
    r9 && r9.added === n12 && r9.removed === t16 ? e21[e21.length - 1] = { count: r9.count + 1, added: n12, removed: t16 } : e21.push({ count: 1, added: n12, removed: t16 });
  }, extractCommon: function(e21, n12, t16, r9) {
    for (var i11 = n12.length, o12 = t16.length, l11 = e21.newPos, s11 = l11 - r9, a10 = 0; l11 + 1 < i11 && s11 + 1 < o12 && this.equals(n12[l11 + 1], t16[s11 + 1]); )
      l11++, s11++, a10++;
    return a10 && e21.components.push({ count: a10 }), e21.newPos = l11, s11;
  }, equals: function(e21, n12) {
    return this.options.comparator ? this.options.comparator(e21, n12) : e21 === n12 || this.options.ignoreCase && e21.toLowerCase() === n12.toLowerCase();
  }, removeEmpty: function(e21) {
    for (var n12 = [], t16 = 0; t16 < e21.length; t16++)
      e21[t16] && n12.push(e21[t16]);
    return n12;
  }, castInput: function(e21) {
    return e21;
  }, tokenize: function(e21) {
    return e21.split("");
  }, join: function(e21) {
    return e21.join("");
  } };
  var t15 = new e20();
  function i10(e21, n12) {
    if ("function" == typeof e21)
      n12.callback = e21;
    else if (e21)
      for (var t16 in e21)
        e21.hasOwnProperty(t16) && (n12[t16] = e21[t16]);
    return n12;
  }
  var o11 = /^[A-Za-z\xC0-\u02C6\u02C8-\u02D7\u02DE-\u02FF\u1E00-\u1EFF]+$/;
  var l10 = /\S/;
  var s10 = new e20();
  function a9(e21, n12, t16) {
    return t16 = i10(t16, { ignoreWhitespace: true }), s10.diff(e21, n12, t16);
  }
  s10.equals = function(e21, n12) {
    return this.options.ignoreCase && (e21 = e21.toLowerCase(), n12 = n12.toLowerCase()), e21 === n12 || this.options.ignoreWhitespace && !l10.test(e21) && !l10.test(n12);
  }, s10.tokenize = function(e21) {
    for (var n12 = e21.split(/([^\S\r\n]+|[()[\]{}'"\r\n]|\b)/), t16 = 0; t16 < n12.length - 1; t16++)
      !n12[t16 + 1] && n12[t16 + 2] && o11.test(n12[t16]) && o11.test(n12[t16 + 2]) && (n12[t16] += n12[t16 + 2], n12.splice(t16 + 1, 2), t16--);
    return n12;
  };
  var f10 = new e20();
  function d11(e21, n12, t16) {
    return f10.diff(e21, n12, t16);
  }
  f10.tokenize = function(e21) {
    var n12 = [], t16 = e21.split(/(\n|\r\n)/);
    t16[t16.length - 1] || t16.pop();
    for (var r9 = 0; r9 < t16.length; r9++) {
      var i11 = t16[r9];
      r9 % 2 && !this.options.newlineIsToken ? n12[n12.length - 1] += i11 : (this.options.ignoreWhitespace && (i11 = i11.trim()), n12.push(i11));
    }
    return n12;
  };
  var h9 = new e20();
  h9.tokenize = function(e21) {
    return e21.split(/(\S.+?[.!?])(?=\s+|$)/);
  };
  var v11 = new e20();
  function m11(e21) {
    return m11 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e22) {
      return typeof e22;
    } : function(e22) {
      return e22 && "function" == typeof Symbol && e22.constructor === Symbol && e22 !== Symbol.prototype ? "symbol" : typeof e22;
    }, m11(e21);
  }
  v11.tokenize = function(e21) {
    return e21.split(/([{}:;,]|\s+)/);
  };
  var x9 = Object.prototype.toString;
  var L8 = new e20();
  function k9(e21, n12, t16, r9, i11) {
    var o12, l11;
    for (n12 = n12 || [], t16 = t16 || [], r9 && (e21 = r9(i11, e21)), o12 = 0; o12 < n12.length; o12 += 1)
      if (n12[o12] === e21)
        return t16[o12];
    if ("[object Array]" === x9.call(e21)) {
      for (n12.push(e21), l11 = new Array(e21.length), t16.push(l11), o12 = 0; o12 < e21.length; o12 += 1)
        l11[o12] = k9(e21[o12], n12, t16, r9, i11);
      return n12.pop(), t16.pop(), l11;
    }
    if (e21 && e21.toJSON && (e21 = e21.toJSON()), "object" === m11(e21) && null !== e21) {
      n12.push(e21), l11 = {}, t16.push(l11);
      var s11, a10 = [];
      for (s11 in e21)
        e21.hasOwnProperty(s11) && a10.push(s11);
      for (a10.sort(), o12 = 0; o12 < a10.length; o12 += 1)
        l11[s11 = a10[o12]] = k9(e21[s11], n12, t16, r9, s11);
      n12.pop(), t16.pop();
    } else
      l11 = e21;
    return l11;
  }
  L8.useLongestToken = true, L8.tokenize = f10.tokenize, L8.castInput = function(e21) {
    var n12 = this.options, t16 = n12.undefinedReplacement, r9 = n12.stringifyReplacer, i11 = void 0 === r9 ? function(e22, n13) {
      return void 0 === n13 ? t16 : n13;
    } : r9;
    return "string" == typeof e21 ? e21 : JSON.stringify(k9(e21, null, null, i11), i11, "  ");
  }, L8.equals = function(n12, t16) {
    return e20.prototype.equals.call(L8, n12.replace(/,([\r\n])/g, "$1"), t16.replace(/,([\r\n])/g, "$1"));
  };
  var b10 = new e20();
  b10.tokenize = function(e21) {
    return e21.slice();
  }, b10.join = b10.removeEmpty = function(e21) {
    return e21;
  };

  // components/lineDiffView.js
  var LineDiffView = class extends x {
    getContents() {
      if (!this.props.leftLines && !this.props.rightLines)
        return null;
      if (!this.props.rightLines) {
        const {
          lines: leftLines,
          ids: leftIds,
          msgs: leftMsgs
        } = this.props.leftLines;
        const hunkCtx = { leftIds, rightIds: [""], leftMsgs, rightMsgs: [""] };
        return leftLines.map((line, idx) => Hunk({
          hunkCtx,
          curLeft: idx,
          curRight: 0,
          leftContent: this.props.format?.(line) || line,
          rightContent: " "
        }));
      }
      if (!this.props.leftLines) {
        const {
          lines: rightLines,
          ids: rightIds,
          msgs: rightMsgs
        } = this.props.rightLines;
        const hunkCtx = { rightIds, leftIds: [""], rightMsgs, leftMsgs: [""] };
        return rightLines.map((line, idx) => Hunk({
          hunkCtx,
          curLeft: 0,
          curRight: idx,
          leftContent: " ",
          rightContent: this.props.format?.(line) || line
        }));
      }
      return this.diffLines();
    }
    diffLines() {
      if (this.prevLeftLines == this.props.leftLines && this.prevRightLines == this.props.rightLines) {
        return this.prevDiff;
      }
      this.prevLeftFocus = this.props.leftFocus;
      this.prevRightFocus = this.props.rightFocus;
      const {
        contents: leftContents,
        lines: leftLines,
        ids: leftIds,
        msgs: leftMsgs
      } = this.props.leftLines;
      const {
        contents: rightContents,
        lines: rightLines,
        ids: rightIds,
        msgs: rightMsgs
      } = this.props.rightLines;
      const hunkCtx = { leftIds, leftMsgs, rightIds, rightMsgs };
      const diffs = d11(leftContents, rightContents, {
        comparator: this.props.comparator
      });
      let rendered = [];
      let curLeft = 0;
      let curRight = 0;
      let mkHunk = ({ curLeft: curLeft2, curRight: curRight2, leftContent, rightContent, leftClass, rightClass }) => Hunk({
        highlight: this.props.highlight ? () => this.props.highlight(leftIds[curLeft2], rightIds[curRight2]) : () => {
        },
        dim: this.props.dim ? () => this.props.dim() : () => {
        },
        hunkCtx,
        curLeft: curLeft2,
        curRight: curRight2,
        leftContent,
        rightContent,
        leftClass,
        rightClass
      });
      for (const diff of diffs) {
        if (diff?.added) {
          for (const line of diff.value.split("\n")) {
            if (line == "")
              continue;
            const hunk = mkHunk({
              curLeft,
              curRight,
              leftContent: " ",
              rightContent: this.props.format?.(line) || line,
              rightClass: "hunkAdded"
            });
            curRight++;
            rendered.push(hunk);
          }
        } else if (diff?.removed) {
          for (const line of diff.value.split("\n")) {
            if (line == "")
              continue;
            const hunk = mkHunk({
              curLeft,
              curRight,
              leftContent: this.props.format?.(line) || line,
              rightContent: " ",
              leftClass: "hunkRemoved"
            });
            curLeft++;
            rendered.push(hunk);
          }
        } else {
          for (let i11 = 0; i11 < diff.count; i11++) {
            let rightContent = this.props.format?.(rightLines[curRight]) || rightLines[curRight];
            let leftContent = this.props.format?.(leftLines[curLeft]) || leftLines[curLeft];
            [leftContent, rightContent] = this.props.diffWords?.(leftContent, rightContent) || [leftContent, rightContent];
            const hunk = mkHunk({
              curLeft,
              curRight,
              leftContent,
              rightContent
            });
            curRight++;
            curLeft++;
            rendered.push(hunk);
          }
        }
      }
      this.prevDiff = rendered;
      return rendered;
    }
    render(props) {
      const hunks = this.getContents().filter(({ contentListing }) => {
        if (!props.filterExpr)
          return true;
        let lineFilter;
        try {
          lineFilter = new RegExp(props.filterExpr);
        } catch (e21) {
          lineFilter = /^/;
        }
        return lineFilter.test(contentListing.left) || lineFilter.test(contentListing.right);
      });
      return m2`<pre id="line-diff-data-view">${hunks}</pre>`;
    }
  };

  // components/searchInput.js
  function SearchInput({ value, onInput }) {
    return m2`<div class="search-input">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
      <input value="${value}" onInput=${onInput}></input>
      </div>`;
  }

  // components/actionDifference.js
  var ActionDifference = class extends x {
    getActions(focus) {
      const segment = getEdgesFromEnds(focus.top, focus.bot).reverse();
      let contents = "";
      let msg = "";
      const lines = [];
      const ids = [];
      const msgs = [];
      for (const edge of segment) {
        const id = edge.id();
        for (const line of edge.data("actions")) {
          contents += line + "\n";
          lines.push(line);
          msgs.push(msg);
          ids.push(id);
        }
      }
      if (focus.bot.data("actions")) {
        for (const line of focus.bot.data("actions")) {
          contents += line + "\n";
          lines.push(line);
          msgs.push(msg);
          ids.push("bottomNode");
        }
      }
      return { contents, lines, ids, msgs };
    }
    onInput(e21) {
      this.setState({ filterExpr: e21.target.value });
    }
    diffWords(leftLine, rightLine) {
      const lwords = leftLine.split(/\s+/);
      const rwords = rightLine.split(/\s+/);
      const laddr = lwords.shift();
      const raddr = rwords.shift();
      const comparison = lwords.map((lw, idx) => rwords[idx] === lw);
      leftLine = lwords.map((w11, idx) => comparison[idx] ? `${w11} ` : hunkFormat(w11, "hunkRemoved"));
      rightLine = rwords.map((w11, idx) => comparison[idx] ? `${w11} ` : hunkFormat(w11, "hunkAdded"));
      leftLine.unshift(`${laddr} `);
      rightLine.unshift(`${raddr} `);
      return [leftLine, rightLine];
    }
    highlightNodes(idLeft, idRight) {
      const cyLeft = this.props.leftFocus.cy();
      const cyRight = this.props.rightFocus.cy();
      if (idLeft == "bottomNode") {
        const botId = this.props.leftFocus.bot.id();
        cyLeft.highlight(cyLeft.nodes(`#${botId}, [mergedIds*='#${botId}#']`));
      } else {
        const leftEdges = cyLeft.edges(`#${idLeft}, [mergedIds*='#${idLeft}#']`);
        cyLeft.highlight(leftEdges.sources());
      }
      if (idRight == "bottomNode") {
        const botId = this.props.rightFocus.bot.id();
        cyRight.highlight(cyRight.nodes(`#${botId}, [mergedIds*='#${botId}#']`));
      } else {
        const rightEdges = cyRight.edges(`#${idRight}, [mergedIds*='#${idRight}#']`);
        cyRight.highlight(rightEdges.sources());
      }
    }
    dimAll() {
      this.props.leftFocus.cy().dim();
      this.props.rightFocus.cy().dim();
    }
    compare(l11, r9) {
      const [, , laction, ...lterms] = l11.split(/\s+/);
      const [, , raction, ...rterms] = r9.split(/\s+/);
      if (laction === raction) {
        switch (laction) {
          case "reg/write:":
            return lterms[0] == rterms[0] && lterms.length === rterms.length;
          case "reg/read:":
            return lterms[0] == rterms[0] && lterms.length === rterms.length;
          default:
            return lterms.length === rterms.length;
        }
      }
      return false;
    }
    format(s11) {
      let [, ...results] = s11.slice(1, -1).split(/\s+/);
      results = results.map((s12) => {
        switch (s12) {
          case "---->>":
            return "\u2192";
          case "<<----":
            return "\u2190";
          default:
            return s12;
        }
      });
      return results.join(" ");
    }
    render(props, state) {
      return m2`<div id="action-diff">
      <${SearchInput} onInput=${(e21) => this.onInput(e21)} value=${this.filterExpr}/>
      <${LineDiffView} 
      filterExpr=${state.filterExpr}
      leftLines=${props.leftFocus ? this.getActions(props.leftFocus) : null}
      rightLines=${props.rightFocus ? this.getActions(props.rightFocus) : null}
      comparator=${(l11, r9) => this.compare(l11, r9)}
      diffWords=${(l11, r9) => this.diffWords(l11, r9)}
      highlight=${(idLeft, idRight) => this.highlightNodes(idLeft, idRight)}
      format=${(s11) => this.format(s11)}
      dim=${() => this.dimAll()}
      />
      </div>
      `;
    }
  };

  // components/assemblyDifference.js
  var AssemblyDifference = class extends x {
    getAssembly(focus) {
      const segment = getNodesFromEnds(focus.top, focus.bot).reverse();
      let contents = "";
      let msg = "";
      const lines = [];
      const ids = [];
      const msgs = [];
      const debug = focus.cy().debugData;
      for (const node of segment) {
        const id = node.id();
        for (const line of node.data().contents.split("\n")) {
          if (debug) {
            const addr = parseInt(line.match(/^[0-9a-f]*/), 16);
            if (debug[addr])
              msg = "";
            for (const loc of debug[addr] || [])
              msg += loc + "\n";
          }
          contents += line + "\n";
          lines.push(line);
          msgs.push(msg);
          ids.push(id);
        }
      }
      return { contents, lines, ids, msgs };
    }
    onInput(e21) {
      this.setState({ filterExpr: e21.target.value });
    }
    highlightNodes(idLeft, idRight) {
      const cyLeft = this.props.leftFocus.cy();
      const cyRight = this.props.rightFocus.cy();
      cyLeft.highlight(cyLeft.nodes(`#${idLeft}, [mergedIds*='#${idLeft}#']`));
      cyRight.highlight(cyRight.nodes(`#${idRight}, [mergedIds*='#${idRight}#']`));
    }
    dimAll() {
      this.props.leftFocus.cy().dim();
      this.props.rightFocus.cy().dim();
    }
    compare(l11, r9) {
      const [, lmnemonic, ...loperands] = l11.split(/\s+/);
      const [, rmnemonic, ...roperands] = r9.split(/\s+/);
      return lmnemonic == rmnemonic && loperands.length == roperands.length;
    }
    diffWords(leftLine, rightLine) {
      const lwords = leftLine.split(/\s+/);
      const rwords = rightLine.split(/\s+/);
      const laddr = lwords.shift();
      const raddr = rwords.shift();
      const comparison = lwords.map((lw, idx) => rwords[idx] === lw);
      leftLine = lwords.map((w11, idx) => comparison[idx] ? `${w11} ` : hunkFormat(w11, "hunkRemoved"));
      rightLine = rwords.map((w11, idx) => comparison[idx] ? `${w11} ` : hunkFormat(w11, "hunkAdded"));
      leftLine.unshift(`${laddr} `);
      rightLine.unshift(`${raddr} `);
      return [leftLine, rightLine];
    }
    render(props, state) {
      return m2`<div id="assembly-diff">
      <${SearchInput} value=${state.filterExpr} onInput=${(e21) => this.onInput(e21)}/>
      <${LineDiffView} 
      filterExpr=${state.filterExpr}
      leftLines=${props.leftFocus ? this.getAssembly(props.leftFocus) : null}
      rightLines=${props.rightFocus ? this.getAssembly(props.rightFocus) : null}
      comparator=${(l11, r9) => this.compare(l11, r9)}
      diffWords=${(l11, r9) => this.diffWords(l11, r9)}
      highlight=${(idLeft, idRight) => this.highlightNodes(idLeft, idRight)}
      dim=${() => this.dimAll()}
    />
    </div>`;
    }
  };

  // components/concretionSelector.js
  var ConcretionSelector = class extends x {
    render(props) {
      if (props.concretionCount === 0)
        return null;
      const buttons = [
        m2`<button 
      data-selected=${props.view == "symbolic"} 
      onClick=${() => props.setView("symbolic")}
      >Symbolic</button>`
      ];
      for (let i11 = 0; i11 < props.concretionCount; i11++) {
        buttons.push(
          m2`<button 
        data-selected=${props.view == i11} 
        onClick=${() => props.setView(i11)}
        >Example ${i11 + 1}</button>`
        );
      }
      return m2`<div class="subordinate-buttons">${buttons}</div>`;
    }
  };

  // components/registerDifference.js
  var RegisterDifference = class extends x {
    constructor() {
      super();
      this.state = { view: "symbolic" };
    }
    render(props, state) {
      const rightId = props.rightFocus.bot.id();
      const registers = [];
      const conc_regdiffs = props.leftFocus.bot.data().compatibilities[rightId].conc_regdiff ?? [];
      const rdiffs = state.view === "symbolic" ? props.leftFocus.bot.data().compatibilities[rightId].regdiff : conc_regdiffs[state.view];
      for (const reg in rdiffs) {
        registers.push(m2`
        <span class="grid-diff-left">${rdiffs[reg][0]}</span>
        <span class="grid-diff-label">${reg}</span>
        <span class="grid-diff-right">${rdiffs[reg][1]}</span>`);
      }
      return m2`<div>
      <${ConcretionSelector} 
        view=${state.view} 
        setView=${(view) => this.setState({ view })} 
        concretionCount=${conc_regdiffs.length}/>
      <div id="grid-diff-data"> ${registers.length > 0 ? registers : m2`<span class="no-difference">no register differences detected ✓</span>`}</div></div>`;
    }
  };

  // components/memoryDifference.js
  var MemoryDifference = class extends x {
    constructor() {
      super();
      this.state = { view: "symbolic" };
    }
    render(props, state) {
      const rightId = props.rightFocus.bot.id();
      const addresses = [];
      const conc_adiffs = props.leftFocus.bot.data().compatibilities[rightId].conc_memdiff ?? [];
      const adiffs = state.view === "symbolic" ? props.leftFocus.bot.data().compatibilities[rightId].memdiff : conc_adiffs[state.view];
      for (const addr in adiffs) {
        const addrparts = addr.split("\n").map((part) => [part, m2`<br/>`]).flat();
        addresses.push(m2`
        <span class="grid-diff-left">${adiffs[addr][0]}</span>
        <span class="grid-diff-label">${addrparts}</span>
        <span class="grid-diff-right">${adiffs[addr][1]}</span>`);
      }
      return m2`<div>
      <${ConcretionSelector} 
        view=${state.view} 
        setView=${(view) => this.setState({ view })} 
        concretionCount=${conc_adiffs.length}/>
      <div id="grid-diff-data"> ${addresses.length > 0 ? addresses : m2`<span class="no-difference">no memory differences detected ✓</span>`}</div></div>`;
    }
  };

  // components/sideEffectDifference.js
  var SideEffectDifference = class extends x {
    constructor() {
      super();
      this.state = { view: 0 };
    }
    diffableSideEffects(effects, presence) {
      let contents = "";
      let msg = "";
      let effectIdx = 0;
      const lines = [];
      const ids = [];
      const msgs = [];
      for (const isPresent of presence) {
        if (isPresent) {
          contents += effects[effectIdx].body + "\n";
          lines.push(effects[effectIdx].body);
          ids.push(effects[effectIdx].id);
          effectIdx++;
        } else {
          contents += "\n";
          lines.push("");
          ids.push(null);
        }
        msgs.push(msg);
      }
      return { contents, lines, ids, msgs };
    }
    handleSymbolicDiff(symbolicDiff) {
      const rslt = {};
      for (const channel in symbolicDiff) {
        const lines = {};
        lines.left = symbolicDiff[channel].map(([x10]) => ({ body: x10 }));
        lines.right = symbolicDiff[channel].map(([, x10]) => ({ body: x10 }));
        rslt[channel] = lines;
      }
      return rslt;
    }
    highlightNodes(idLeft, idRight) {
      const cyLeft = this.props.leftFocus.cy();
      const cyRight = this.props.rightFocus.cy();
      cyLeft.highlight(cyLeft.nodes(`#${idLeft}, [mergedIds*='#${idLeft}#']`));
      cyRight.highlight(cyRight.nodes(`#${idRight}, [mergedIds*='#${idRight}#']`));
    }
    dimAll() {
      this.props.leftFocus.cy().dim();
      this.props.rightFocus.cy().dim();
    }
    diffWords(leftLine, rightLine) {
      const diffs = a9(leftLine, rightLine);
      const newLeft = [];
      const newRight = [];
      for (const diff of diffs) {
        if (diff?.added) {
          newRight.push(m2`<span class="hunkAdded">${diff.value}</span>`);
        } else if (diff?.removed) {
          newLeft.push(m2`<span class="hunkRemoved">${diff.value}</span>`);
        } else {
          newRight.push(m2`<span>${diff.value}</span>`);
          newLeft.push(m2`<span>${diff.value}</span>`);
        }
      }
      return [newLeft, newRight];
    }
    render(props, state) {
      const rightId = props.rightFocus.bot.id();
      const concretions = props.leftFocus.bot.data().compatibilities[rightId].conc_sediff ?? [];
      const symbolicDiff = props.leftFocus.bot.data().compatibilities[rightId].sediff ?? {};
      const chandivs = [];
      const replacer = (_7, s11) => s11 == "leafNeq" ? "These constraints are not equivalent" : s11 == "fieldEq" ? "The remaining constrants shown here are equivalent" : s11;
      if (state.view == "symbolic") {
        for (const channel in symbolicDiff) {
          const chandiv = m2`<div class="side-effect-channel">
          <h3>${channel}</h3>
          ${symbolicDiff[channel].map(([, , x10]) => m2`<pre>${JSON.stringify(x10, replacer, 2)}</pre>`)}
        </div>`;
          chandivs.push(chandiv);
        }
      } else {
        const sediffs = concretions[state.view];
        for (const channel in sediffs) {
          if (!(channel in symbolicDiff))
            continue;
          const chandiv = m2`<div class="side-effect-channel">
          <h3>${channel}</h3>
          <${LineDiffView} 
            leftLines=${this.diffableSideEffects(
            sediffs[channel].left,
            symbolicDiff[channel].map(([x10]) => x10)
          )}
            rightLines=${this.diffableSideEffects(
            sediffs[channel].right,
            symbolicDiff[channel].map(([, y10]) => y10)
          )}
            diffWords=${(l11, r9) => this.diffWords(l11, r9)}
            comparator=${() => true}
            highlight=${(idLeft, idRight) => this.highlightNodes(idLeft, idRight)}
            dim=${() => this.dimAll()}
          />
        </div>`;
          chandivs.push(chandiv);
        }
      }
      return m2`<div>
      <${ConcretionSelector} 
        view=${state.view} 
        setView=${(view) => this.setState({ view })} 
        concretionCount=${concretions.length}/>
      ${chandivs}
      </div>`;
    }
  };

  // components/diffPanel.js
  var DiffPanel = class extends x {
    constructor() {
      super();
      this.state = {
        mode: null
      };
      this.diffPanel = b();
      this.dragHandle = b();
    }
    toggleMode(mode) {
      if (this.state.mode == mode) {
        this.setState({ mode: null });
      } else {
        this.setState({ mode });
      }
    }
    startResize(e21) {
      this.diffPanel.current.onpointermove = (e22) => {
        this.diffPanel.current.style.maxHeight = `${Math.max(50, window.innerHeight - e22.clientY)}px`;
      };
      this.dragHandle.current.setPointerCapture(e21.pointerId);
      this.dragHandle.current.classList.add("grabbed");
      this.diffPanel.current.classList.add("resizing");
    }
    stopResize(e21) {
      this.diffPanel.current.onpointermove = null;
      this.dragHandle.current.releasePointerCapture(e21.pointerId);
      this.dragHandle.current.classList.remove("grabbed");
      this.diffPanel.current.classList.remove("resizing");
    }
    render(props, state) {
      const assemblyAvailable = props.leftFocus || props.rightFocus;
      const registersAvailable = props.leftFocus && props.rightFocus && props.leftFocus.bot.data().compatibilities?.[props.rightFocus.bot.id()]?.regdiff;
      const memoryAvailable = props.leftFocus && props.rightFocus && props.leftFocus.bot.data().compatibilities?.[props.rightFocus.bot.id()]?.memdiff;
      const concretionAvailable = props.leftFocus && props.rightFocus && props.leftFocus.bot.data().compatibilities?.[props.rightFocus.bot.id()]?.conc_args;
      const actionsAvailable = props.rightFocus?.top.outgoers("edge")[0]?.data("actions")?.length > 0 || props.leftFocus?.top.outgoers("edge")[0]?.data("actions")?.length > 0;
      const sideEffectsAvailable = props.leftFocus && props.rightFocus && props.leftFocus.bot.data().compatibilities?.[props.rightFocus.bot.id()]?.conc_sediff;
      return m2`<div id="diff-panel" onMouseEnter=${props.onMouseEnter} ref=${this.diffPanel}>
      <div id="diff-drag-handle"
        onPointerDown=${(e21) => this.startResize(e21)} 
        onPointerUp=${(e21) => this.stopResize(e21)} 
        ref=${this.dragHandle}
      />
      <div>
        <button 
          disabled=${!assemblyAvailable}
          onClick=${() => this.toggleMode("assembly")}>
          Assembly
        </button>
        <button 
          disabled=${!memoryAvailable}
          onClick=${() => this.toggleMode("memory")}>
          Memory
        </button>
        <button disabled=${!registersAvailable}
          onClick=${() => this.toggleMode("registers")}>
          Registers
        </button>
        <button disabled=${!concretionAvailable}
          onClick=${() => this.toggleMode("concretions")}>
          Concretions
        </button>
        <button disabled=${!actionsAvailable}
          onClick=${() => this.toggleMode("actions")}>
          Events
        </button>
        <button disabled=${!sideEffectsAvailable}
          onClick=${() => this.toggleMode("side-effects")}>
          Side Effects
        </button>
      </div>
      ${state.mode == "assembly" && assemblyAvailable && m2`
        <${AssemblyDifference} rightFocus=${props.rightFocus} leftFocus=${props.leftFocus}/>`}
      ${state.mode == "registers" && registersAvailable && m2`
        <${RegisterDifference} rightFocus=${props.rightFocus} leftFocus=${props.leftFocus}/>`}
      ${state.mode == "memory" && memoryAvailable && m2`
        <${MemoryDifference} rightFocus=${props.rightFocus} leftFocus=${props.leftFocus}/>`}
      ${state.mode == "concretions" && concretionAvailable && m2`
        <${Concretions} rightFocus=${props.rightFocus} leftFocus=${props.leftFocus}/>`}
      ${state.mode == "actions" && actionsAvailable && m2`
        <${ActionDifference} rightFocus=${props.rightFocus} leftFocus=${props.leftFocus}/>`}
      ${state.mode == "side-effects" && sideEffectsAvailable && m2`
        <${SideEffectDifference} rightFocus=${props.rightFocus} leftFocus=${props.leftFocus}/>`}
      </div>`;
    }
  };

  // data/cozy-data.js
  var Status = Object.freeze({
    unloaded: Symbol("unloaded"),
    idle: Symbol("idle"),
    rendering: Symbol("rendering")
  });
  var Tidiness = Object.freeze({
    untidy: Symbol("untidy"),
    tidy: Symbol("tidy"),
    veryTidy: Symbol("very-tidy")
  });
  var View = Object.freeze({
    plain: Symbol("plain"),
    cfg: Symbol("cfg")
  });

  // data/colors.js
  var Colors = {
    defaultNode: "#ccc",
    focusedNode: "#666",
    defaultBorder: "#aaa",
    defaultEdge: "#aaa",
    focusedEdge: "#666",
    syscallNode: "#add8e6",
    focusedSyscallNode: "#00ade6",
    simprocNode: "#ade6b6",
    focusedSimprocNode: "#4eb302",
    errorNode: "#facdcd",
    focusedErrorNode: "#d00",
    assertNode: "#edcdfa",
    focusedAssertNode: "#a600de",
    postconditionNode: "#f7be6d",
    focusedPostconditionNode: "#f79000"
  };
  var colors_default = Colors;

  // components/report.js
  var NodeBadge = class extends x {
    badgeStyle(color) {
      return {
        background: color,
        color: "white",
        fontWeight: "bold",
        padding: "5px 10px 3px 10px",
        //less padding at the bottom because there's already naturally some space there for descenders.
        borderRadius: "25px",
        printColorAdjust: "exact"
      };
    }
    render(props) {
      const node = props.node;
      if (node.data("error")) {
        return m2`<span style=${this.badgeStyle(colors_default.focusedErrorNode)}>Error:</span>`;
      } else if (node.data("assertion_info")) {
        return m2`<span style=${this.badgeStyle(colors_default.focusedAssertNode)}>Assertion:</span>`;
      } else if (node.data("postcondition_info")) {
        return m2`<span style=${this.badgeStyle(colors_default.focusedPostconditionNode)}>Postcondition:</span>`;
      } else if (node.data("spinning")) {
        return m2`<span style=${this.badgeStyle(colors_default.focusedErrorNode)}>Error:</span>`;
      }
    }
  };
  var BranchData = class extends x {
    getData() {
      return this.props.node.data("error") || this.props.node.data("assertion_info") || this.props.node.data("postcondition_info") || this.props.node.data("spinning") && "Loop bounds exceeded" || null;
    }
    render(props) {
      const data = this.getData();
      if (!data)
        return;
      return m2`<div class="branch-data">
      <${NodeBadge} node=${props.node}/> ${data}
      </div>`;
    }
  };
  var ReportField = class extends x {
    onMouseEnter() {
      this.props.panel.cy.dim();
      this.props.panel.cy.highlight(this.props.leaf);
    }
    onMouseLeave() {
      this.props.panel.cy.dim();
    }
    onCheck(e21) {
      const cy = this.props.panel.cy;
      if (e21.target.checked) {
        this.props.setStatus("complete");
        cy.addCheckMark(this.props.leaf.id());
      } else {
        this.props.setStatus(void 0);
        cy.removeCheckMark(this.props.leaf.id());
      }
      this.props.refreshPrune();
    }
    onClick() {
      this.props.focus();
    }
    render(props) {
      const num = props.index + 1;
      return m2`<div class="report-field">
      <h2 
        onMouseEnter=${() => this.onMouseEnter()}
        onMouseLeave=${() => this.onMouseLeave()}
        onClick=${() => this.onClick()}
      >
        Path ${num}
      </h2>
      <${BranchData} node=${props.leaf}/>
      <form>
        <div>
        <textarea></textarea>
        </div>
        <div>
        <label for="reviewed-check">Review Complete</label>
        <input type="checkbox" onchange=${(e21) => this.onCheck(e21)} name="reviewed-check"></input>
        </div>
      </form>
    </div>`;
    }
  };
  var ReportStatus = class extends x {
    render(props) {
      return m2`<div id="report-status">
        <h3>Review Coverage: ${Math.floor(props.value * 100 / props.max)}%</h3>
        <progress value=${props.value} max=${props.max}></progress>
      </div>`;
    }
  };
  var ReportContents = class extends x {
    differenceBullets() {
      const bullets = [];
      const pruningStatus = this.props.pruningStatus;
      if (pruningStatus.pruningMemory) {
        bullets.push(m2`<li> differ with respect to final memory contents </li>`);
      }
      if (pruningStatus.pruningStdout) {
        bullets.push(m2`<li> differ with respect to stdout behavior </li>`);
      }
      if (pruningStatus.pruningRegisters) {
        bullets.push(m2`<li> differ with respect to final register contents</li>`);
      }
      if (pruningStatus.pruningEquivConstraints) {
        bullets.push(m2`<li> differ with respect to final constraints</li>`);
      }
      if (pruningStatus.pruningCorrect) {
        bullets.push(m2`<li> have an error, or correspond to an erroring branch </li>`);
      }
      if (pruningStatus.pruningDoRegex) {
        bullets.push(m2`<li> don't match the regex <code>${pruningStatus.pruningRegex}</code>, 
        or correspond to a branch that doesn't match this regex </li>`);
      }
      return bullets;
    }
    render(props) {
      const bullets = this.differenceBullets();
      return m2`
      <h3>Summary:</h3>
      <p>Comparing 
        <code> ${props.prelabel} </code>
        and
        <code> ${props.postlabel}</code>.
      </p>
      ${bullets.length > 0 && m2`<p> Limiting attention to branches that: <ul>${bullets}</ul></p>`}`;
    }
  };
  var Report = class extends x {
    constructor(props) {
      super();
      this.state = {
        branchStatuses: {}
      };
      const panel = props.data.leftPanelRef;
      this.leaves = [...panel.cy.nodes().leaves()];
    }
    componentDidMount() {
      const reportStyle = this.props.window.document.createElement("link");
      reportStyle.setAttribute("rel", "stylesheet");
      const loc = window.location;
      reportStyle.setAttribute("href", `${loc.origin}${loc.pathname}/report.css`);
      this.props.window.document.head.appendChild(reportStyle);
    }
    getReportFields() {
      const panel = this.props.data.leftPanelRef;
      return this.leaves.map((leaf, idx) => {
        return m2`<${ReportField}
        setStatus=${(status) => this.setBranchStatus(idx, status)}
        leaf=${leaf}
        focus=${() => this.props.data.focusLeafById(leaf.id())}
        panel=${panel}
        refreshPrune=${this.props.data.refreshPrune}
        index=${idx}/>`;
      });
    }
    setBranchStatus(idx, status) {
      this.setState((oldState) => ({ branchStatuses: { ...oldState.branchStatuses, [idx]: status } }));
    }
    getProgress() {
      return Object.values(this.state.branchStatuses).filter((status) => status == "complete").length;
    }
    render(props) {
      const fields = this.getReportFields();
      const progress = this.getProgress();
      return m2`<main>
        <article>
          <h1 title="report-title">Cozy Report</h1>
          <div id="summary">
            <${ReportContents}
              prelabel=${props.data.prelabel}
              postlabel=${props.data.postlabel} 
              pruningStatus=${props.data.pruningStatus}
            />
            <${ReportStatus} value=${progress} max=${fields.length} />
          </div>
          ${fields}
        </article>
      </main>`;
    }
  };

  // components/menu.js
  var Menu = class extends x {
    constructor() {
      super();
      this.button = b();
      this.options = b();
    }
    static Option = class extends x {
      render(props) {
        return m2`<div class="option"
        data-selected=${props.selected} 
        data-disabled=${props.disabled}
        onClick=${props.disabled ? null : props.onClick}>
            ${props.children}
      </div>`;
      }
    };
    componentDidUpdate() {
      if (this.props.open == this.props.title) {
        V7(this.button.current, this.options.current, {
          placement: "bottom-start"
        }).then(({ x: x10, y: y10 }) => {
          this.options.current.style.left = `${x10}px`;
          this.options.current.style.top = `${y10}px`;
        });
      }
    }
    toggleOpen() {
      if (!this.props.enabled)
        return;
      if (this.props.open != this.props.title) {
        this.props.setOpen(this.props.title);
      } else {
        this.props.setOpen(null);
      }
    }
    render(props) {
      const optionStyle = {
        position: "absolute",
        display: "block",
        backgroundColor: "#e1e1e1"
      };
      const menuStyle = {
        color: props.enabled ? "black" : "#ccc",
        backgroundColor: props.open === props.title ? "#e1e1e1" : "white"
      };
      return m2`
      <button 
        style=${menuStyle} 
        ref=${this.button} 
        onClick=${() => this.toggleOpen()}
        onMouseEnter=${() => props.open && this.props.enabled && props.setOpen(props.title)}>
        ${props.title}
      </button>
      ${props.open == props.title && m2`
        <div style=${optionStyle} ref=${this.options} class="options-wrapper">
          ${props.children}
        </div>`}`;
    }
  };

  // components/searchMenu.js
  var SearchMenu = class extends x {
    constructor() {
      super();
      this.state = {
        searchStdoutRegex: ""
      };
    }
    updateSearch(e21) {
      if (e21.target.value == "")
        this.clearSearch();
      else {
        this.setState({ searchStdoutRegex: e21.target.value }, () => {
          const cyLeft = this.props.cyLeft.cy;
          const cyRight = this.props.cyRight.cy;
          cyLeft.dim();
          cyRight.dim();
          let regex;
          try {
            regex = new RegExp(this.state.searchStdoutRegex);
          } catch (e22) {
            return;
          }
          const ltargets = cyLeft.nodes().filter((node) => node.data().stdout.match(regex));
          const rtargets = cyRight.nodes().filter((node) => node.data().stdout.match(regex));
          cyLeft.highlight(ltargets);
          cyRight.highlight(rtargets);
        });
      }
    }
    clearSearch() {
      this.setState({ searchStdoutRegex: "" }, () => {
        const cyLeft = this.props.cyLeft.cy;
        const cyRight = this.props.cyRight.cy;
        cyLeft.dim();
        cyRight.dim();
      });
      this.props.setOpen(null);
    }
    render(props, state) {
      return m2`<${Menu} 
        enabled=${props.enabled}
        open=${props.open}
        title="Search"
        setOpen=${(o12) => props.setOpen(o12)}>
        <${Menu.Option} onClick=${() => props.setOpen(null)}>
          Stdout <input 
            placeholder=".*"
            onClick=${(e21) => e21.stopPropagation()}
            onInput=${(e21) => this.updateSearch(e21)} 
            value=${state.searchStdoutRegex}/>
        <//>
        <${Menu.Option} onClick=${() => this.clearSearch(null)}>
          Clear Search 
        <//>
      <//>`;
    }
  };

  // util/constraints.js
  function constraintsEq(c1, c22) {
    if (c1.length != c22.length)
      return false;
    for (let i11 = 0; i11 < c1.length; i11++) {
      if (c1[i11] != c22[i11])
        return false;
    }
    return true;
  }

  // util/graph-tidy.js
  function removeBranch(node) {
    let target;
    while (node.outgoers("node").length == 0 && node.incomers("node").length > 0) {
      target = node;
      node = node.incomers("node")[0];
      target.remove();
    }
    if (target && node.outgoers("node").length == 0 && node.incomers("node").length == 0) {
      node.remove();
    }
  }
  var tidyMixin = {
    // array of graph elements merged out of existence
    mergedNodes: [],
    mergedEdges: [],
    // We try to tidy up a given graph by merging non-branching series of nodes
    // into single nodes
    tidy(opts) {
      const root = this.nodes().roots();
      this.tidyChildren(root, opts);
    },
    tidyChildren(node, { mergeConstraints }) {
      let candidates = [node];
      let next = [];
      while (candidates.length > 0) {
        for (const candidate of candidates) {
          const out = candidate.outgoers("node");
          const constraints1 = out[0]?.data().constraints;
          const constraints2 = candidate.data().constraints;
          if (out.length == 1 && (mergeConstraints || constraintsEq(constraints1, constraints2))) {
            out[0].data().contents = candidate.data().contents + "\n" + out[0].data().contents;
            if (candidate.data().vex) {
              out[0].data().vex = candidate.data().vex + "\n" + out[0].data().vex;
            }
            if (candidate.data("has_syscall")) {
              out[0].data().has_syscall |= candidate.data().has_syscall;
            }
            if (candidate.data("simprocs")) {
              out[0].data().simprocs.unshift(...candidate.data().simprocs);
            }
            if (candidate.data("actions")) {
              if (out[0].outgoers("edge").length)
                for (const edge of out[0].outgoers("edge")) {
                  edge.data("actions", candidate.outgoers("edge")[0].data("actions").concat(edge.data("actions")));
                }
              else {
                out[0].data("actions", candidate.outgoers("edge")[0].data("actions"));
              }
            }
            for (const parent of candidate.incomers("node")) {
              const edgeData = {
                id: `${parent.id()}-${out[0].id()}`,
                source: parent.id(),
                target: out[0].id(),
                // we copy the relevant actions (those associated with the grandparent) into the new edge
                actions: candidate.incomers("edge").data("actions")
              };
              node.cy().add({ group: "edges", data: edgeData });
            }
            if (this.root?.id() == candidate.id()) {
              this.root = out[0];
            }
            candidate.remove();
            next.push(out[0]);
          } else {
            for (const baby of out) {
              next.push(baby);
            }
          }
        }
        candidates = next;
        next = [];
      }
    },
    //merge blocks that share contents
    mergeByContents() {
      const constructed = {};
      this.mergedNodes = [];
      this.mergedEdges = [];
      for (const node of this.nodes()) {
        this.tidyStdOut(node);
      }
      for (const node of this.nodes()) {
        const addr = node.data().contents;
        console.log(addr.toString(16));
        if (addr in constructed) {
          this.mergedNodes.push(node);
          const priorStdout = constructed[addr].data("newStdout");
          if (priorStdout.length > 0) {
            constructed[addr].data("stdout", priorStdout + "\n--\n" + node.data("newStdout"));
          }
          constructed[addr].data("mergedIds", `${constructed[addr].data("mergedIds")}${node.id()}#`);
        } else {
          this.removePlainData(node);
          node.data("stdout", node.data("newStdout"));
          node.data("mergedIds", `#${node.id()}#`);
          constructed[addr] = node;
        }
        if (node.hasClass("pathHighlight"))
          constructed[addr].data("traversed", true);
        if (node.incomers().length == 0)
          constructed[addr].data("initial", true);
        if (node.outgoers().length == 0)
          constructed[addr].data("terminal", true);
      }
      const startingEdges = [...this.edges()];
      for (const edge of startingEdges) {
        const sourceRepr = constructed[edge.source().data("contents")];
        const targetRepr = constructed[edge.target().data("contents")];
        if (edge.source() == sourceRepr && edge.target() == targetRepr) {
          if (edge.hasClass("pathHighlight")) {
            edge.data("traversals", (edge.data("traversals") || 0) + 1);
          }
          edge.data("mergedIds", `#${edge.id()}#`);
        } else {
          if (sourceRepr.edgesTo(targetRepr).length > 0) {
            if (edge.hasClass("pathHighlight")) {
              const traversals = sourceRepr.edgesTo(targetRepr)[0].data("traversals");
              sourceRepr.edgesTo(targetRepr)[0].data("traversals", (traversals || 0) + 1).data("mergedIds", `${sourceRepr.edgesTo(targetRepr)[0].data("mergedIds")}${edge.id()}#`);
            }
          } else {
            this.add({
              group: "edges",
              data: {
                source: sourceRepr.id(),
                target: targetRepr.id(),
                mergedIds: `#${edge.id()}#`,
                traversals: edge.hasClass("pathHighlight") ? 1 : 0
              }
            });
          }
          this.mergedEdges.push(edge);
        }
      }
      for (const element of [...this.mergedNodes, ...this.mergedEdges]) {
        element.remove();
      }
      this.style().update();
    },
    // remove data that doesn't make sense in the CFG context
    removePlainData(node) {
      node.removeData("constraints");
      node.removeData("stdout");
      node.removeData("stderr");
    },
    // take a node from a tree, and derive what is *new* at that node
    tidyStdOut(node) {
      if (node.incomers("node").length == 1) {
        const incomerStdout = node.incomers("node")[0].data("stdout");
        node.data("newStdout", node.data("stdout").slice(incomerStdout.length, Infinity));
      } else {
        node.data("newStdout", node.data("stdout"));
      }
    },
    // tidy extraneous data added to existing elements by merging. Constructed
    // nodes are removed automatically.
    removeCFGData() {
      let element;
      while (element = this.mergedNodes.pop()) {
        element.restore();
      }
      while (element = this.mergedEdges.pop()) {
        element.restore();
      }
      for (const node of this.nodes()) {
        node.removeData("traversed");
        node.removeData("initial");
        node.removeData("terminal");
        node.removeData("mergedIds");
      }
      for (const edge of this.edges()) {
        edge.removeData("traversals");
        edge.removeData("mergedIds");
      }
    }
  };

  // components/pruneMenu.js
  function noMemoryDiffs(leaf, other) {
    const comparison = leaf.data().compatibilities[other.id()];
    if (Object.keys(comparison.memdiff).length)
      return false;
    else
      return noErrors(leaf, other);
  }
  function noRegisterDiffs(leaf, other) {
    const comparison = leaf.data().compatibilities[other.id()];
    if (Object.keys(comparison.regdiff).length)
      return false;
    else
      return noErrors(leaf, other);
  }
  function noErrors(leaf, other) {
    if (leaf.data().error || other.data().error)
      return false;
    else
      return true;
  }
  function noStdDiffs(leaf, other) {
    if (leaf.data().stdout != other.data().stdout || leaf.data().stderr != other.data().stderr)
      return false;
    else
      return noErrors(leaf, other);
  }
  function reviewed(leaf, other) {
    if (!leaf.data("checked") && !other.data("checked"))
      return false;
    else
      return true;
  }
  function equivConstraints(leaf, other) {
    const leftOnlyConcretions = Object.entries(leaf.data().compatibilities).flatMap(
      ([key, compat]) => key == leaf.id() ? [] : compat.conc_args
    );
    const rightOnlyConcretions = Object.entries(other.data().compatibilities).flatMap(
      ([key, compat]) => key == other.id() ? [] : compat.conc_args
    );
    return rightOnlyConcretions.length + leftOnlyConcretions.length == 0;
  }
  var matchRegex = (regexStrs) => (leaf, other) => {
    const regexes = [];
    try {
      for (const regexStr of regexStrs.split("||")) {
        regexes.push(new RegExp(regexStr));
      }
    } catch (e21) {
      if (matchRegex.debounce)
        return;
      matchRegex.debounce = true;
      alert("Unreadable Regular Expression");
      setTimeout(() => matchRegex.debounce = false, 500);
    }
    for (const regex of regexes) {
      if (leaf.data().stdout.match(regex) && other.data().stdout.match(regex)) {
        return noErrors(leaf, other);
      }
    }
    return false;
  };
  var PruneMenu = class extends x {
    constructor() {
      super();
      this.state = {
        pruningMemory: false,
        pruningStdout: false,
        pruningRegisters: false,
        pruningCorrect: false,
        pruningDoRegex: false,
        pruningChecked: false,
        pruningEquivConstraints: false,
        pruningRegex: ".*",
        awaitingPrune: null
      };
      this.prune.bind(this);
    }
    // prune all branches whose compatibilities all fail some test (e.g. all have
    // the same memory contents as the given branch)
    prune(test) {
      const leaves1 = this.props.cyLeft.cy.nodes().leaves();
      const leaves2 = this.props.cyRight.cy.nodes().leaves();
      for (const leaf of [...leaves1, ...leaves2]) {
        let flag = true;
        let other = leaf.cy() == this.props.cyLeft.cy ? this.props.cyRight.cy : this.props.cyLeft.cy;
        for (const key in leaf.data().compatibilities) {
          const otherleaf = other.nodes(`#${key}`);
          if (otherleaf.length == 0)
            continue;
          flag &&= test(leaf, otherleaf);
        }
        if (flag)
          removeBranch(leaf);
      }
      this.props.cyLeft.cy.refocus();
      this.props.cyRight.cy.refocus();
    }
    setPrune(update) {
      this.setState(update, () => {
        this.props.viewMenu.current.retidy();
        this.props.refreshLayout();
        this.doPrune();
      });
    }
    doPrune() {
      let test = () => false;
      const extendTest = (f11, g9) => (l11, r9) => f11(l11, r9) || g9(l11, r9);
      if (this.state.pruningMemory)
        test = extendTest(noMemoryDiffs, test);
      if (this.state.pruningStdout)
        test = extendTest(noStdDiffs, test);
      if (this.state.pruningEquivConstraints)
        test = extendTest(equivConstraints, test);
      if (this.state.pruningRegisters)
        test = extendTest(noRegisterDiffs, test);
      if (this.state.pruningCorrect)
        test = extendTest(noErrors, test);
      if (this.state.pruningChecked)
        test = extendTest(reviewed, test);
      if (this.state.pruningDoRegex)
        test = extendTest(matchRegex(this.state.pruningRegex), test);
      this.prune(test);
    }
    debounceRegex(e21) {
      this.setState({ pruningRegex: e21.target.value });
      if (this.state.pruningDoRegex) {
        this.setState({ awaitingPrune: true });
        clearTimeout(this.regexDebounceTimeout);
        this.regexDebounceTimeout = setTimeout(() => this.setPrune({ awaitingPrune: null }), 500);
      }
    }
    render(props, state) {
      return m2`<${Menu} 
        enabled=${props.enabled}
        open=${props.open}
        title="Prune"
        setOpen=${(o12) => props.setOpen(o12)}>
        <${Menu.Option} onClick=${() => this.setPrune({ pruningMemory: !state.pruningMemory })}>
          <input type="checkbox" checked=${state.pruningMemory}/> Identical Memory
        <//>
        <${Menu.Option} onClick=${() => this.setPrune({ pruningRegisters: !state.pruningRegisters })}>
          <input type="checkbox" checked=${state.pruningRegisters}/> Identical Register Contents 
        <//>
        <${Menu.Option} onClick=${() => this.setPrune({ pruningStdout: !state.pruningStdout })}>
          <input type="checkbox" checked=${state.pruningStdout}/> Identical Stdout/Stderr
        <//>
        <${Menu.Option} onClick=${() => this.setPrune({ pruningCorrect: !state.pruningCorrect })}>
          <input type="checkbox" checked=${state.pruningCorrect}/> Error-free
        <//>
        <${Menu.Option} onClick=${() => this.setPrune({ pruningEquivConstraints: !state.pruningEquivConstraints })}>
          <input type="checkbox" checked=${state.pruningEquivConstraints}/> Equivalent Constraints
        <//>
        <${Menu.Option} onClick=${() => this.setPrune({ pruningChecked: !state.pruningChecked })}>
          <input type="checkbox" checked=${state.pruningChecked}/> Reviewed
        <//>
        <${Menu.Option} onClick=${() => this.setPrune({ pruningDoRegex: !state.pruningDoRegex })}>
          <input type="checkbox" checked=${state.pruningDoRegex}/> Both Stdout Matching <input 
            data-awaiting=${state.awaitingPrune}
            onClick=${(e21) => e21.stopPropagation()}
            onInput=${(e21) => this.debounceRegex(e21)} 
            value=${state.pruningRegex}/>
        <//>
      <//>`;
    }
  };

  // util/graphStyle.js
  var settings = {
    showingSimprocs: true,
    showingSyscalls: true,
    showingErrors: true,
    showingAsserts: true,
    showingPostconditions: true
  };
  var style = [
    {
      selector: "node",
      style: {
        "shape": "round-rectangle",
        "background-color": colors_default.defaultNode,
        "border-color": colors_default.defaultBorder
      }
    },
    {
      selector: "[[outdegree = 0]], node[?terminal]",
      style: { "border-width": "5px" }
    },
    {
      selector: "node[?initial]",
      style: { "border-width": "5px" }
    },
    {
      selector: "edge",
      style: {
        "width": 3,
        "line-color": colors_default.defaultEdge,
        "target-arrow-color": colors_default.defaultEdge,
        "target-arrow-shape": "triangle",
        "arrow-scale": 1.5,
        "source-distance-from-node": "5px",
        "target-distance-from-node": "5px",
        "curve-style": "bezier"
      }
    },
    {
      selector: "edge.pathHighlight, edge[traversals > 0]",
      style: {
        "width": 3,
        "line-color": colors_default.focusedEdge,
        "target-arrow-color": colors_default.focusedEdge,
        "z-compound-depth": "top"
      }
    },
    {
      selector: "node.pathHighlight, node[?traversed]",
      style: {
        "background-color": colors_default.focusedNode,
        "z-compound-depth": "top"
      }
    },
    {
      selector: "node[?has_syscall]",
      style: {
        "background-color": () => settings.showingSyscalls ? colors_default.syscallNode : colors_default.defaultNode
      }
    },
    {
      selector: "node.pathHighlight[?has_syscall]",
      style: {
        "background-color": () => settings.showingSyscalls ? colors_default.syscallNode : colors_default.focusedNode
      }
    },
    {
      selector: "node[simprocs.length > 0]",
      style: {
        "background-color": () => settings.showingSimprocs ? colors_default.simprocNode : colors_default.defaultNode
      }
    },
    {
      selector: "node.pathHighlight[simprocs.length > 0]",
      style: {
        "background-color": () => settings.showingSimprocs ? colors_default.simprocNode : colors_default.focusedNode
      }
    },
    {
      selector: "node.temporaryFocus",
      style: {
        "underlay-color": "#708090",
        "underlay-opacity": 0.5
      }
    },
    {
      selector: "node[?assertion_info]",
      style: {
        "background-color": () => settings.showingAsserts ? colors_default.assertNode : colors_default.defaultNode
      }
    },
    {
      selector: "node.pathHighlight[?assertion_info]",
      style: {
        "border-width": "0px",
        "background-color": () => settings.showingAsserts ? colors_default.focusedAssertNode : colors_default.focusedNode
      }
    },
    {
      selector: "node[?postcondition_info]",
      style: {
        "background-color": () => settings.showingPostconditions ? colors_default.postconditionNode : colors_default.defaultNode
      }
    },
    {
      selector: "node.pathHighlight[?postcondition_info]",
      style: {
        "border-width": "0px",
        "background-color": () => settings.showingPostconditions ? colors_default.focusedPostconditionNode : colors_default.focusedNode
      }
    },
    {
      selector: "node[?error]",
      style: {
        "border-width": "0px",
        "background-color": () => settings.showingErrors ? colors_default.errorNode : colors_default.defaultNode
      }
    },
    {
      selector: "node[?spinning]",
      style: {
        "shape": "vee",
        "width": 50,
        "height": 50,
        "background-color": () => settings.showingErrors ? colors_default.errorNode : colors_default.defaultNode
      }
    },
    {
      selector: "node.pathHighlight[?error],node.pathHighlight[?spinning]",
      style: {
        "border-width": "0px",
        "background-color": () => settings.showingErrors ? colors_default.focusedErrorNode : colors_default.focusedNode
      }
    },
    {
      selector: "node.availablePath",
      style: {
        "border-width": "12px",
        "width": 25,
        "height": 25,
        "border-color": colors_default.focusedNode,
        "underlay-padding": "15px"
      }
    },
    {
      //we don't display checks in CFG mode, since we don't really have
      //meaningful branches there.
      selector: "node[?checked][^mergedIds]",
      style: {
        "label": "\xD7",
        "font-size": "36px",
        "text-halign": "center",
        "text-valign": "center"
      }
    },
    {
      selector: "node.pathHighlight[?checked]",
      style: {
        "color": "white"
      }
    }
  ];

  // components/viewMenu.js
  function MenuBadge(props) {
    return m2`<svg width="10" height="10">
    <rect x="1" y="1" rx="2" ry="2" width="8" height="8"
    style="fill:${props.color}" />
  </svg>`;
  }
  var ViewMenu = class extends x {
    constructor() {
      super();
      this.state = {
        showingSyscalls: true,
        // we start with syscalls visible
        showingSimprocs: true,
        // we start with SimProcedure calls visible
        showingErrors: true,
        // we start with errors visible
        showingAsserts: true,
        // we start with asserts visible
        showingPostconditions: true,
        // we start with postconditions visible
        tidiness: Tidiness.untidy
        // we're not yet tidying anything
      };
      this.toggleErrors = this.toggleErrors.bind(this);
      this.togglePostconditions = this.togglePostconditions.bind(this);
      this.toggleView = this.toggleView.bind(this);
      this.toggleSyscalls = this.toggleSyscalls.bind(this);
      this.toggleSimprocs = this.toggleSimprocs.bind(this);
      this.toggleAsserts = this.toggleAsserts.bind(this);
    }
    componentDidUpdate(_prevProps, prevState) {
      if (prevState.tidiness !== this.state.tidiness) {
        this.props.pruneMenu.current.doPrune();
        this.props.refreshLayout();
      }
    }
    retidy() {
      this.setTidiness(this.state.tidiness);
    }
    setTidiness(tidiness) {
      this.props.batch(() => {
        this.props.cyLeft.cy.json({ elements: JSON.parse(this.props.cyLeft.orig).elements });
        this.props.cyRight.cy.json({ elements: JSON.parse(this.props.cyRight.orig).elements });
        this.props.cyLeft.cy.nodes().map((node) => node.ungrabify());
        this.props.cyRight.cy.nodes().map((node) => node.ungrabify());
        this.props.cyLeft.cy.restoreCheckMarks();
        switch (tidiness) {
          case Tidiness.untidy:
            break;
          case Tidiness.tidy:
            this.tidy({});
            break;
          case Tidiness.veryTidy:
            this.tidy({ mergeConstraints: true });
            break;
        }
        this.setState({ tidiness }, this.props.regenerateFocus);
      });
    }
    tidy(opts) {
      this.props.cyLeft.cy.tidy(opts);
      this.props.cyRight.cy.tidy(opts);
      this.props.cyLeft.cy.refocus().fit();
      this.props.cyRight.cy.refocus().fit();
    }
    toggleView(type) {
      this.setState((oldState) => {
        settings[type] = !oldState[type];
        this.props.cyLeft.cy.style().update();
        this.props.cyRight.cy.style().update();
        return {
          [type]: !oldState[type]
        };
      });
    }
    toggleSyscalls() {
      this.toggleView("showingSyscalls");
    }
    toggleSimprocs() {
      this.toggleView("showingSimprocs");
    }
    toggleErrors() {
      this.toggleView("showingErrors");
    }
    toggleAsserts() {
      this.toggleView("showingAsserts");
    }
    togglePostconditions() {
      this.toggleView("showingPostconditions");
    }
    render(props, state) {
      return m2`<${Menu}
        enabled=${props.enabled}
        open=${props.open}
        title="View"
        setOpen=${(o12) => props.setOpen(o12)}>
        <${Menu.Option} 
          onClick=${() => state.tidiness !== Tidiness.untidy && this.setTidiness(Tidiness.untidy)}
          selected=${state.tidiness == Tidiness.untidy}>
            Show All Blocks
        <//>
        <${Menu.Option} 
          onClick=${() => state.tidiness !== Tidiness.tidy && this.setTidiness(Tidiness.tidy)}
          selected=${state.tidiness == Tidiness.tidy}>
            Merge Unless Constaints Change
        <//>
        <${Menu.Option} 
          onClick=${() => state.tidiness !== Tidiness.veryTidy && this.setTidiness(Tidiness.veryTidy)}
          selected=${state.tidiness == Tidiness.veryTidy}>
            Merge Unless Branching Occurs
        <//>
        <hr/>
        <${Menu.Option} 
          onClick=${this.toggleSyscalls}
          selected=${state.showingSyscalls}>
            <${MenuBadge} color=${colors_default.focusedSyscallNode}/> Show Syscalls
        <//>
        <${Menu.Option} 
          onClick=${this.toggleSimprocs}
          selected=${state.showingSimprocs}>
            <${MenuBadge} color=${colors_default.focusedSimprocNode}/> Show SimProcedure calls
        <//>
        <${Menu.Option} 
          onClick=${this.toggleErrors}
          selected=${state.showingErrors}>
            <${MenuBadge} color=${colors_default.focusedErrorNode}/> Show Errors
        <//>
        <${Menu.Option} 
          onClick=${this.toggleAsserts}
          selected=${state.showingAsserts}>
            <${MenuBadge} color=${colors_default.focusedAssertNode}/> Show Asserts
        <//>
        <${Menu.Option} 
          onClick=${this.togglePostconditions}
          selected=${state.showingPostconditions}>
            <${MenuBadge} color=${colors_default.focusedPostconditionNode}/> Show Postcondition failures
        <//>
      <//>`;
    }
  };

  // data/layouts.js
  var breadthFirst = {
    name: "breadthfirst",
    directed: true,
    spacingFactor: 2
  };
  var cola = {
    name: "cola"
  };
  var cose = {
    name: "cose",
    nodeRepulsion: function() {
      return 1e4;
    },
    idealEdgeLength: function() {
      return 64;
    },
    edgeElasticity: function() {
      return 128;
    }
  };

  // components/layoutMenu.js
  var LayoutMenu = class extends x {
    render(props) {
      return m2`
      <${Menu} 
        enabled=${props.enabled}
        open=${props.open}
        title="Layout"
        setOpen=${(o12) => props.setOpen(o12)}>
        <${Menu.Option} 
          onClick=${() => props.resetLayout(breadthFirst, View.plain)}
          selected=${props.layout.name == "breadthfirst" && props.view == View.plain}>
            Tree
        <//>
        <${Menu.Option} 
          onClick=${() => props.resetLayout(breadthFirst, View.cfg)}
          selected=${props.layout.name == "breadthfirst" && props.view == View.cfg}>
            CFG - Tree layout
        <//>
        <${Menu.Option} onClick=${() => props.resetLayout()}
          onClick=${() => props.resetLayout(cose, View.cfg)}
          selected=${props.layout.name == "cose" && props.view == View.cfg}>
            CFG - Cose layout
        <//>
        <${Menu.Option} 
          onClick=${() => props.resetLayout(cola, View.cfg)}
          selected=${props.layout.name == "cola" && props.view == View.cfg}>
            CFG - Cola layout
        <//>
        <${Menu.Option} onClick=${() => props.resetLayout()}>
            Refresh
        <//>
      <//>`;
    }
  };

  // components/menuBar.js
  var MenuBar = class extends x {
    constructor() {
      super();
      this.state = {
        open: null,
        searchStdoutRegex: ".*"
      };
    }
    componentDidMount() {
      this.globalClickListener = (ev) => this.handleGlobalClick(ev);
      this.closeListener = () => this.setOpen(null);
      window.addEventListener("blur", this.closeListener);
      window.addEventListener("mousedown", this.globalClickListener);
    }
    componentWillUnmount() {
      window.removeEventListener("blur", this.closeListener);
      window.removeEventListener("mousedown", this.globalClickListener);
    }
    setOpen(open2) {
      this.setState({ open: open2 });
    }
    handleGlobalClick() {
      if (this.state.open) {
        this.setState({ open: null });
      }
    }
    handleLocalClick(ev) {
      if (this.state.open) {
        ev.stopPropagation();
      }
    }
    resetLayout(layout, view) {
      this.props.resetLayout(layout, view);
      this.setOpen(null);
    }
    saveFile(data) {
      const filename = prompt("please provide a filename");
      var blob = new Blob([data], { type: "text/json" }), a10 = document.createElement("a");
      a10.download = filename;
      a10.href = window.URL.createObjectURL(blob);
      a10.dataset.downloadurl = ["text/json", a10.download, a10.href].join(":");
      a10.dispatchEvent(new MouseEvent("click"));
    }
    openReport() {
      this.reportWindow = open();
      if (!this.reportWindow) {
        alert("couldn't open report - double check that cozy has permission to open new windows in your popup-blocker");
      }
      G(
        m2`<${Report} 
      data=${this.props.getReportInterface()} 
      window=${this.reportWindow}/>`,
        this.reportWindow.document.body
      );
    }
    render(props, state) {
      const enabled = props.status === Status.idle;
      return m2`<div id="menubar"
        onMousedown=${(ev) => this.handleLocalClick(ev)}
      >
      <${Menu} 
        enabled=${enabled}
        open=${state.open}
        title="Files"
        setOpen=${(o12) => this.setOpen(o12)}>
        <${Menu.Option} onClick=${() => this.saveFile(props.getJSON())}>
          Save Graph
        <//>
        <${Menu.Option} disabled=${props.view != View.plain} onClick=${() => this.openReport()}>
          Open New Report
        <//>
      <//>
      <${ViewMenu}
        ref=${props.viewMenu}
        enabled=${enabled && props.view == View.plain} 
        tidiness=${props.tidiness}
        pruneMenu=${props.pruneMenu}
        cyLeft=${props.cyLeft}
        cyRight=${props.cyRight}
        open=${state.open}
        regenerateFocus=${props.regenerateFocus}
        refreshLayout=${props.refreshLayout}
        batch=${props.batch}
        setOpen=${(o12) => this.setOpen(o12)}
      />
      <${PruneMenu} 
        ref=${props.pruneMenu}
        enabled=${enabled && props.view == View.plain} 
        viewMenu=${props.viewMenu}
        cyLeft=${props.cyLeft}
        cyRight=${props.cyRight}
        refreshLayout=${props.refreshLayout}
        open=${state.open}
        setOpen=${(o12) => this.setOpen(o12)}
      />
      <${LayoutMenu}
        open=${state.open}
        enabled=${enabled}
        setOpen=${(o12) => this.setOpen(o12)}
        layout=${props.layout}
        view=${props.view}
        resetLayout=${(o12, v12) => this.resetLayout(o12, v12)}
      />
      <${SearchMenu}
        enabled=${enabled}
        open=${state.open}
        setOpen=${(o12) => this.setOpen(o12)}
        cyLeft=${props.cyLeft}
        cyRight=${props.cyRight}
      />
    </div>`;
    }
  };

  // util/focusMixin.js
  var focusMixin = {
    focus(loci) {
      if (!loci)
        return;
      this.loci = loci;
      this.root = this.nodes().roots()[0];
      for (const locus of loci) {
        if (locus.removed())
          continue;
        if (loci.length > 1) {
          locus.addClass("availablePath");
        } else {
          locus.addClass("pathHighlight");
        }
        locus.predecessors().addClass("pathHighlight");
      }
      return this;
    },
    // focus a range of nodes, and set its lower tips to be the loci
    focusRange(nodes) {
      this.elements().removeClass("pathHighlight");
      this.elements().removeClass("availablePath");
      this.loci = nodes.filter(
        (ele) => ele.outgoers("node").intersection(nodes).length == 0
      );
      this.root = nodes.filter(
        (ele) => ele.incomers("node").intersection(nodes).length == 0
      );
      nodes.addClass("pathHighlight");
      if (this.loci.length > 1) {
        for (const locus of this.loci) {
          locus.removeClass("pathHighlight");
          locus.addClass("availablePath");
        }
      } else {
        this.loci.addClass("pathHighlight");
      }
    },
    refocus() {
      this.elements().removeClass("pathHighlight").removeClass("availablePath");
      if (this.root?.incomers?.().length > 0 || this.loci?.outgoers?.().length > 0) {
        this.focusRange(this.getRangeOf(this.loci));
      } else {
        this.focus(this.loci);
      }
      return this;
    },
    highlight(nodes) {
      nodes.addClass("temporaryFocus");
    },
    dim() {
      this.elements().removeClass("temporaryFocus");
    },
    blur() {
      this.loci = null;
      this.root = null;
      this.elements().removeClass("pathHighlight").removeClass("availablePath");
      this.elements().removeData("traversals");
      return this;
    }
  };

  // util/checkedMixin.js
  var checkedMixin = {
    checkedIds: /* @__PURE__ */ new Set(),
    setCheckMarks(nodes) {
      this.nodes().removeData("checked");
      this.checkedIds = /* @__PURE__ */ new Set([...nodes.map((node) => node.id())]);
      nodes.data("checked", true);
    },
    addCheckMark(id) {
      this.checkedIds.add(id);
      this.nodes(`#${id}`).data("checked", true);
    },
    removeCheckMark(id) {
      this.checkedIds.delete(id);
      this.nodes(`#${id}`).data("checked", false);
      this.nodes(`#${id}`).removeData("checked");
    },
    restoreCheckMarks() {
      this.setCheckMarks(this.filter((node) => this.checkedIds.has(node.id())));
    }
  };

  // util/segmentationMixin.js
  var segmentationMixin = {
    // XXX: It would be possible to memoize on constraints here, but that adds
    // some complexity when the granularity of the graph changes
    // 
    // The connector is an extra function that we can use to potentially link
    // segments with different constraints under some conditions
    getRangeOf(node, connector) {
      const constraints = node.data().constraints;
      let target = node;
      while (target.incomers("node").length == 1 && constraintsEq(constraints, target.incomers("node")[0].data().constraints)) {
        target = target.incomers("node")[0];
      }
      let generations = [[target]];
      while (true) {
        const lastGen = generations[generations.length - 1];
        const nextGen = lastGen.flatMap(
          (n12) => n12.outgoers("node").filter((outgoer) => {
            if (constraintsEq(outgoer.data().constraints, n12.data().constraints))
              return true;
            if (connector?.(outgoer, n12))
              return true;
          }).toArray()
        );
        if (nextGen.length > 0)
          generations.push(nextGen);
        else
          break;
      }
      generations = generations.flat();
      return this.collection(generations);
    },
    segmentToRange(segment) {
      return segment.bot.predecessors("node").intersection(segment.top.successors("node")).union(segment.top).union(segment.bot);
    },
    rangeToSegment(range) {
      return {
        bot: range.filter((ele) => ele.outgoers("node").intersection(range).length == 0)[0],
        top: range.filter((ele) => ele.incomers("node").intersection(range).length == 0)[0]
      };
    },
    // this shows a generalized segment, in which we ignore additional
    // constraints that don't narrow the pool of compatible nodes on the opposite
    // side.
    getCompatibilityRangeOf(node, cy) {
      const connector = (n12, o12) => {
        const ncompat = this.getLeavesCompatibleWith(n12, cy);
        const ocompat = this.getLeavesCompatibleWith(o12, cy);
        return ncompat.size == ocompat.size;
      };
      return this.getRangeOf(node, connector);
    },
    // gets all leaves in cy compatible with a given node
    //
    // XXX : this should probably be disabled when pruning is in progress, it
    // doesn't necessarily make sense once nodes have been removed.
    getLeavesCompatibleWith(node, cy) {
      const leaves = node.successors().add(node).leaves();
      const ids = leaves.flatMap((leaf) => Object.keys(leaf.data().compatibilities)).map((s11) => `#${s11}`);
      const compats = /* @__PURE__ */ new Set();
      for (const id of ids) {
        compats.add(cy.$(id)[0]);
      }
      return compats;
    },
    // in a preorder, find the greatest/lowest element p such that each element of leaves
    // is > p; i.e the strongest set of constraints implied by the constraints on
    // each member of leaves
    getMinimalCeiling(leaves) {
      let depth = 1;
      const [canonicalLeaf] = leaves;
      const canonicalPreds = canonicalLeaf.predecessors("node");
      if (leaves.size === 1)
        return canonicalLeaf;
      while (true) {
        for (const leaf of leaves) {
          const preds = leaf.predecessors("node");
          if (depth > preds.length || preds[preds.length - depth] !== canonicalPreds[canonicalPreds.length - depth]) {
            return canonicalPreds[canonicalPreds.length - (depth - 1)];
          }
        }
        depth += 1;
      }
    }
  };

  // components/app.js
  Pl.use(e17);
  var App = class extends x {
    constructor() {
      super();
      this.state = {
        status: Status.unloaded,
        // awaiting graph data
        layout: breadthFirst,
        // we start with the breadthfirst layout
        view: View.plain,
        //we start with all nodes visible, not a CFG
        prelabel: "prepatch",
        postlabel: "postpatch"
      };
      this.cy1 = b();
      this.cy2 = b();
      this.cy1.other = this.cy2;
      this.cy2.other = this.cy1;
      this.tooltip = b();
      this.handleDragleave = this.handleDragleave.bind(this);
      this.handleDragover = this.handleDragover.bind(this);
      this.clearTooltip = this.clearTooltip.bind(this);
      this.resetLayout = this.resetLayout.bind(this);
      this.getJSON = this.getJSON.bind(this);
      this.viewMenu = b();
      this.pruneMenu = b();
      window.app = this;
    }
    // Produces an object encapsulating data and methods needed by a cozy report
    // window.
    getReportInterface() {
      return {
        prelabel: this.state.prelabel,
        postlabel: this.state.postlabel,
        pruningStatus: this.pruneMenu.current.state,
        leftPanelRef: this.cy1,
        refreshPrune: () => {
          if (this.pruneMenu.current.state.pruningChecked) {
            this.pruneMenu.current.setPrune({});
          }
        },
        focusLeafById: (id) => {
          const leaf = this.cy1.cy.nodes(`#${id}`);
          const selfCy = this.cy1.cy;
          const otherCy = this.cy2.cy;
          const selfRoot = selfCy.nodes().roots()[0];
          const selfSegment = new Segment(selfRoot, leaf);
          const compatibilities = leaf.data().compatibilities;
          selfCy.blur().focus(leaf);
          otherCy.blur().focus(otherCy.nodes().filter((node) => +node.data().id in compatibilities));
          this.setState({ leftFocus: selfSegment, rightFocus: null });
        }
      };
    }
    componentDidMount() {
      const urlParams = new URLSearchParams(window.location.search);
      const isServedPre = urlParams.get("pre");
      const isServedPost = urlParams.get("post");
      if (isServedPre) {
        fetch(isServedPre).then((rslt) => rslt.json()).then((raw) => {
          const obj = JSON.parse(raw);
          if (!obj.elements)
            throw new Error("Malformed post-patch JSON");
          this.mountToCytoscape(obj, this.cy1);
        }).catch((e21) => console.error(e21));
      }
      if (isServedPost) {
        fetch(isServedPost).then((rslt) => rslt.json()).then((raw) => {
          const obj = JSON.parse(raw);
          if (!obj.elements)
            throw new Error("Malformed post-patch JSON");
          this.mountToCytoscape(obj, this.cy2);
        }).catch((e21) => console.error(e21));
      }
    }
    handleClick(ev) {
      if (this.state.status == Status.unloaded) {
        alert("Please load both graphs before attempting comparison.");
        return;
      }
      if (this.state.view == View.plain)
        this.handlePlainClick(ev);
      if (this.state.view == View.cfg)
        this.handleCFGClick(ev);
    }
    handleCFGClick(ev) {
      if (!ev.originalEvent.shiftKey)
        return;
      const addr = ev.target.data("address");
      this.resetLayout(breadthFirst, View.plain);
      const similar = ev.target.cy().nodes(`[address=${addr}]`);
      ev.target.cy().highlight(similar);
    }
    handlePlainClick(ev) {
      const isLeft = ev.target.cy() == this.cy1.cy;
      const self2 = ev.cy;
      const other = ev.cy.ref.other.cy;
      const segmentSelect = ev.originalEvent.shiftKey;
      const refining = self2.loci?.includes(ev.target) && self2.loci.length > 1 && segmentSelect == this.lastSegmentSelect;
      this.lastSegmentSelect = segmentSelect;
      let selfSegment;
      if (segmentSelect) {
        selfSegment = Segment.fromRange(self2.getRangeOf(ev.target));
        self2.blur().focusRange(self2.getRangeOf(ev.target));
      } else {
        if (ev.target.outgoers().length !== 0)
          return;
        const selfRoot = ev.cy.nodes().roots()[0];
        selfSegment = new Segment(selfRoot, ev.target);
        self2.blur().focus(ev.target);
      }
      if (isLeft)
        this.setState({ leftFocus: selfSegment });
      else
        this.setState({ rightFocus: selfSegment });
      if (!refining) {
        let otherSegment;
        if (segmentSelect) {
          const compats = self2.getLeavesCompatibleWith(ev.target, other);
          const otherRange = other.getCompatibilityRangeOf(self2.getMinimalCeiling(compats), self2);
          other.blur().focusRange(otherRange);
          if (other.loci.length == 1) {
            otherSegment = Segment.fromRange(otherRange);
          }
        } else {
          const compatibilities = ev.target.data().compatibilities;
          other.blur().focus(other.nodes().filter((node) => +node.data().id in compatibilities));
          if (other.loci.length == 1) {
            const otherRoot = other.nodes().roots()[0];
            otherSegment = new Segment(otherRoot, other.loci);
          }
        }
        if (otherSegment) {
          if (isLeft)
            this.setState({ rightFocus: otherSegment });
          else
            this.setState({ leftFocus: otherSegment });
        } else {
          if (isLeft)
            this.setState({ rightFocus: null, leftFocus: selfSegment });
          else
            this.setState({ leftFocus: null, rightFocus: selfSegment });
        }
      }
    }
    getJSON() {
      return JSON.stringify({
        pre: {
          data: JSON.parse(this.cy1.orig),
          name: this.state.prelabel
        },
        post: {
          data: JSON.parse(this.cy2.orig),
          name: this.state.postlabel
        }
      });
    }
    setStatus(status) {
      this.setState({ status });
    }
    regenerateFocus() {
      const connectedLeft = this.cy1.cy.loci?.filter((node) => node.inside());
      const connectedRight = this.cy2.cy.loci?.filter((node) => node.inside());
      if (connectedLeft?.length == 0 || connectedRight?.length == 0) {
        this.cy1.cy.blur();
        this.cy2.cy.blur();
        this.setState({ leftFocus: null, rightFocus: null });
      } else {
        this.setState({
          leftFocus: this.state.leftFocus ? new Segment(this.cy1.cy.root, this.cy1.cy.loci) : null,
          rightFocus: this.state.rightFocus ? new Segment(this.cy2.cy.root, this.cy2.cy.loci) : null
        });
      }
    }
    async handleDrop(ev) {
      ev.stopPropagation();
      ev.preventDefault();
      ev.currentTarget.classList.remove("dragHover");
      const file = ev.dataTransfer.files[0];
      const raw = await file.text().then(JSON.parse);
      this.setState({
        prelabel: raw.pre.name,
        postlabel: raw.post.name
      });
      this.mountToCytoscape(raw.pre.data, this.cy1);
      this.mountToCytoscape(raw.post.data, this.cy2);
    }
    handleDragover(ev) {
      ev.stopPropagation();
      ev.preventDefault();
      ev.currentTarget.classList.add("dragHover");
    }
    handleDragleave(ev) {
      ev.stopPropagation();
      ev.preventDefault();
      ev.currentTarget.classList.remove("dragHover");
    }
    mountToCytoscape(raw, ref) {
      if (ref.cy)
        ref.cy.destroy();
      const cy = Pl({
        style,
        elements: raw.elements
      });
      cy.mount(ref.current);
      Object.assign(cy, focusMixin);
      Object.assign(cy, tidyMixin);
      Object.assign(cy, segmentationMixin);
      Object.assign(cy, checkedMixin);
      cy.debugData = cy.nodes().roots()[0].data("debug");
      ref.currentLayout = cy.layout(this.state.layout).run();
      cy.on("add", (ev) => {
        if (ev.target.group() === "nodes") {
          this.initializeNode(ev.target);
        }
      });
      cy.on("click", (ev) => {
        if (this.state.view == View.cfg)
          return;
        if (!ev.target.group) {
          this.batch(() => {
            this.cy1.cy?.blur();
            this.cy2.cy?.blur();
            this.setState({ leftFocus: null, rightFocus: null });
            this.tooltip.current.clearTooltip();
          });
        }
      });
      cy.on("zoom pan", () => {
        this.tooltip.current.clearTooltip();
      });
      ref.cy = cy;
      ref.orig = JSON.stringify(cy.json());
      cy.ref = ref;
      cy.nodes().map((node) => this.initializeNode(node));
      this.setState({
        status: !this.cy1.cy || !this.cy2.cy ? Status.unloaded : Status.idle
      });
    }
    initializeNode(node) {
      node.ungrabify();
      node.on("mouseout", (ev) => {
        ev.cy.container().style.cursor = "default";
      });
      node.on("mouseover", (ev) => {
        if (ev.target.outgoers().length == 0) {
          ev.cy.container().style.cursor = "pointer";
        }
        this.tooltip.current.attachTo(ev.target);
      });
      node.on("click", (ev) => this.handleClick(ev));
    }
    startRender(method) {
      this.setState({ status: Status.rendering }, method);
    }
    batch(cb) {
      this.cy1.cy?.startBatch();
      this.cy2.cy?.startBatch();
      cb();
      this.cy1.cy?.endBatch();
      this.cy2.cy?.endBatch();
    }
    resetLayout(layout, view) {
      this.setState((oldState) => {
        this.cy1.currentLayout.stop();
        this.cy2.currentLayout.stop();
        layout = layout ?? oldState.layout;
        if (view != oldState.view) {
          if (view == View.cfg) {
            this.cy1.cy.mergeByContents();
            this.cy2.cy.mergeByContents();
          } else if (view == View.plain) {
            this.cy1.cy.removeCFGData();
            this.cy2.cy.removeCFGData();
            this.viewMenu.current.retidy();
            this.pruneMenu.current.doPrune();
          } else {
            view = oldState.view;
          }
        }
        this.cy1.currentLayout = this.cy1.cy.layout(layout).run();
        this.cy2.currentLayout = this.cy2.cy.layout(layout).run();
        return { view, layout };
      });
    }
    refreshLayout() {
      this.cy1.currentLayout = this.cy1.cy.layout(this.state.layout).run();
      this.cy2.currentLayout = this.cy2.cy.layout(this.state.layout).run();
    }
    clearTooltip() {
      this.tooltip.current.clearTooltip();
    }
    render(_props, state) {
      return m2`
      <${Tooltip} ref=${this.tooltip}/>
      <${MenuBar} 
        cyLeft=${this.cy1}
        cyRight=${this.cy2}
        view=${state.view}
        layout=${state.layout}
        getReportInterface=${() => this.getReportInterface()}
        regenerateFocus=${() => this.regenerateFocus()}
        resetLayout=${this.resetLayout}
        refreshLayout=${() => this.refreshLayout()}
        tidiness=${state.tidiness}
        status=${state.status}
        batch=${(cb) => this.batch(cb)}
        viewMenu=${this.viewMenu}
        pruneMenu=${this.pruneMenu}
        getJSON=${this.getJSON}
      />
      <div id="main-view"
        onDragover=${this.handleDragover}
        onDragleave=${this.handleDragleave}
        onDrop=${(ev) => this.startRender(() => this.handleDrop(ev))} 
      >
        <span id="labelLeft">${state.prelabel}</span>
        <span id="labelRight">${state.postlabel}</span>
        <div 
          onMouseEnter=${this.clearTooltip} 
          ref=${this.cy1}
           id="cy1">
        </div>
        <div 
          onMouseEnter=${this.clearTooltip} 
          ref=${this.cy2} id="cy2">
        </div>
      </div>
      <${DiffPanel} 
        rightFocus=${state.rightFocus}
        leftFocus=${state.leftFocus}
        onMouseEnter=${() => this.tooltip.current.clearTooltip()} 
      />
      ${state.status == Status.rendering && m2`<span id="status-indicator">rendering...</span>`}
    `;
    }
  };

  // cozy-viz.js
  G(m2`<${App}/>`, document.body);
})();
/*!
Embeddable Minimum Strictly-Compliant Promises/A+ 1.1.1 Thenable
Copyright (c) 2013-2014 Ralf S. Engelschall (http://engelschall.com)
Licensed under The MIT License (http://opensource.org/licenses/MIT)
*/
/*! Bezier curve function generator. Copyright Gaetan Renaudeau. MIT License: http://en.wikipedia.org/wiki/MIT_License */
/*! Runge-Kutta spring physics function generator. Adapted from Framer.js, copyright Koen Bok. MIT License: http://en.wikipedia.org/wiki/MIT_License */

# Enable Pip

By the magic of python, adds pip executables that should have been created after it was installed.

# Usage

If you have an upgrade available just do that `python -m pip install --upgrade pip`. You don't need this. Just install it and you're good to go.

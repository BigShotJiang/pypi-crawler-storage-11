import boto3
from requests_aws4auth import AWS4Auth
from elasticsearch import Elasticsearch
from opensearchpy import OpenSearch, RequestsHttpConnection
from inception_audittrail_logger.settings_audittrail import get_audittrail_setting

audittrail_setting = get_audittrail_setting()
AUDITTRAIL_INDEX_NAME = "audittrail"
SYSTEM_ERROR_INDEX_NAME = "system_error"


# Connect to ES
def es_connect():
    # Connect to ES
    if audittrail_setting.elasticsearch_provider == "aws":
        # Get AWS credentials
        # credentials = boto3.Session().get_credentials()
        credentials = boto3.Session().get_credentials().get_frozen_credentials()
        awsauth = AWS4Auth(
            credentials.access_key,
            credentials.secret_key,
            audittrail_setting.aws_region,
            audittrail_setting.elasticsearch_service,
            session_token=credentials.token,
        )

        es = OpenSearch(
            hosts=[
                {
                    "host": audittrail_setting.elasticsearch_host.split("//")[1],
                    "port": audittrail_setting.elasticsearch_port,
                }
            ],
            http_auth=awsauth,
            use_ssl=True,
            verify_certs=audittrail_setting.elasticsearch_verify_certs,
            connection_class=RequestsHttpConnection,
        )
    elif audittrail_setting.elasticsearch_provider == "self-hosted":
        es = Elasticsearch(
            [
                f"{audittrail_setting.elasticsearch_host}:{audittrail_setting.elasticsearch_port}"
            ],
            verify_certs=audittrail_setting.elasticsearch_verify_certs,
        )
    return es


# ✅ Confirm connection
es = es_connect()
if es.ping():
    print("✅ Successfully connected to Audittrail Elasticsearch!")
else:
    print("❌ Failed to connect to Audittrail Elasticsearch.")


async def index_document(index_name: str, document_id: str, body: dict):
    response = es.index(index=index_name, id=document_id, document=body)
    print(f"✅ Successfully indexed document into Elasticsearch: {document_id}")
    return response


async def search_es_documents(index_name: str, query: dict):
    response = es.search(index=index_name, body=query)
    print(f"✅ Successfully searched Elasticsearch: {response}")
    return response


def get_audittrail_es_client() -> Elasticsearch:
    return es

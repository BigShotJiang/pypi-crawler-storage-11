# Contributing to EcomLib

Thank you for your interest in contributing to EcomLib! This document provides guidelines and instructions for contributing.

## 🌟 How to Contribute

### Reporting Bugs

If you find a bug, please create an issue with:
- Clear description of the bug
- Steps to reproduce
- Expected vs actual behavior
- Your environment (Python version, OS, etc.)

### Suggesting Features

Feature requests are welcome! Please:
- Check if the feature already exists
- Describe the use case
- Explain why it would be useful

### Code Contributions

1. **Fork the repository**
   ```bash
   git clone https://github.com/Shamsulhaq/ecomlib.git
   cd ecomlib
   ```

2. **Create a virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install in development mode**
   ```bash
   pip install -e .
   pip install -r requirements-dev.txt
   ```

4. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

5. **Make your changes**
   - Write clean, readable code
   - Follow PEP 8 style guidelines
   - Add docstrings to all functions/classes
   - Add type hints where appropriate

6. **Write tests**
   - Add tests for new features
   - Ensure existing tests pass
   - Aim for >80% code coverage

7. **Run tests**
   ```bash
   # Run all tests
   bash run_all_tests.sh
   
   # Or run specific tests
   python -m pytest tests/
   ```

8. **Commit your changes**
   ```bash
   git add .
   git commit -m "feat: add your feature description"
   ```

9. **Push and create a Pull Request**
   ```bash
   git push origin feature/your-feature-name
   ```

## 📝 Code Style Guidelines

### Python Style
- Follow PEP 8
- Use meaningful variable names
- Keep functions small and focused
- Maximum line length: 100 characters

### Docstring Format
```python
def function_name(param1: str, param2: int) -> bool:
    """
    Brief description of what the function does.
    
    Args:
        param1: Description of param1
        param2: Description of param2
        
    Returns:
        Description of return value
        
    Raises:
        ExceptionType: When this exception is raised
        
    Example:
        >>> function_name("test", 42)
        True
    """
    pass
```

### Commit Message Format

Use conventional commits:
- `feat:` New feature
- `fix:` Bug fix
- `docs:` Documentation changes
- `test:` Test additions/changes
- `refactor:` Code refactoring
- `style:` Code style changes
- `chore:` Maintenance tasks

Example:
```
feat: add bulk inventory update method

- Implement batch processing for inventory updates
- Add validation for bulk operations
- Include comprehensive tests
```

## 🧪 Testing Guidelines

### Writing Tests

1. **Test file naming**: `test_<module_name>.py`
2. **Test function naming**: `test_<what_is_being_tested>`
3. **Use fixtures** for common setup
4. **Test edge cases** and error conditions

Example:
```python
import pytest
from ecomlib.inventory import InventoryManager, StockMovement

@pytest.fixture
def inventory():
    return InventoryManager()

def test_record_movement_success(inventory):
    """Test successful stock movement recording."""
    movement = StockMovement(
        product_id="TEST-001",
        quantity=10,
        movement_type="purchase"
    )
    result = inventory.record_movement(movement)
    assert result is not None
    assert result.quantity == 10

def test_record_movement_insufficient_stock(inventory):
    """Test that insufficient stock raises error."""
    # Setup
    inventory.record_movement(StockMovement(
        product_id="TEST-001",
        quantity=5,
        movement_type="purchase"
    ))
    
    # Test
    with pytest.raises(InsufficientStockError):
        inventory.record_movement(StockMovement(
            product_id="TEST-001",
            quantity=-10,
            movement_type="sale"
        ))
```

### Running Tests

```bash
# All tests
pytest

# Specific file
pytest tests/test_inventory.py

# Specific test
pytest tests/test_inventory.py::test_record_movement_success

# With coverage
pytest --cov=ecomlib --cov-report=html

# Verbose output
pytest -v
```

## 📚 Documentation

### Code Documentation
- All public functions/classes must have docstrings
- Include type hints
- Provide usage examples in docstrings

### README Updates
- Update README.md if adding new features
- Include code examples
- Update API reference section

## 🔍 Code Review Process

All contributions go through code review:

1. **Automated checks** must pass:
   - All tests pass
   - Code style checks pass
   - No security vulnerabilities

2. **Manual review** by maintainers:
   - Code quality
   - Test coverage
   - Documentation completeness
   - Design decisions

3. **Feedback incorporation**:
   - Address review comments
   - Update as needed
   - Re-request review

## 🎯 Development Priorities

Current focus areas:
1. **Core Functionality**: Inventory, orders, payments
2. **Performance**: Optimization for high-volume operations
3. **Documentation**: Comprehensive guides and examples
4. **Testing**: Increase coverage to 95%+

## 🤝 Community

- **Questions?** Open a discussion on GitHub
- **Need help?** Check existing issues or create a new one
- **Want to chat?** Join our community (link TBD)

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

## 🙏 Thank You!

Your contributions make EcomLib better for everyone. We appreciate your time and effort!

---

**Happy Coding! 🚀**

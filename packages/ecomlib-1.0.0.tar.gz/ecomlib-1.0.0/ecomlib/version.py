"""Version information for ecomlib."""

__version__ = "0.1.0"
__version_info__ = tuple(int(part) for part in __version__.split('.'))

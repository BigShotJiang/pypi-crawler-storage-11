"""
EcomLib - A Python library for building scalable e-commerce applications.

Features:
- User authentication and authorization
- Product and inventory management
- Shopping cart functionality
- Secure payment processing
- Order management
- Geolocation services
- Analytics and reporting
"""

from .version import __version__, __version_info__

# Import core components
from .auth import AuthManager
from .inventory import InventoryManager
from .cart import ShoppingCart
from .payment import StripeGateway, PayPalGateway
from .order import Order, OrderManager, OrderStatus
from .geolocation import GeoLocation

# Initialize default instances for easier access
auth = AuthManager()
inventory = InventoryManager()
cart = ShoppingCart()
payments = StripeGateway(api_key="your_stripe_key")  # Replace with actual key in production
orders = OrderManager()
location = GeoLocation()
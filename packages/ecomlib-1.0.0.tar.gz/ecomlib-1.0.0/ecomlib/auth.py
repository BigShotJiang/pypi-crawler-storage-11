"""
Enhanced Authentication and Authorization module for EcomLib.
Handles user registration, login, session management, and role-based access control.
"""
import re
import os
import hashlib
import jwt
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Set, Any, Callable

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AuthError(Exception):
    """Base authentication error."""
    pass

class InvalidCredentialsError(AuthError):
    """Raised when invalid credentials are provided."""
    pass

class UserAlreadyExistsError(AuthError):
    """Raised when trying to register an existing user."""
    pass

class InvalidTokenError(AuthError):
    """Raised when an invalid token is provided."""
    pass

class RateLimitExceededError(AuthError):
    """Raised when rate limit is exceeded."""
    pass

@dataclass
class User:
    """User data model with enhanced security features."""
    username: str
    email: str
    password_hash: str
    is_active: bool = True
    is_verified: bool = False
    roles: List[str] = field(default_factory=lambda: ['customer'])
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    login_attempts: int = 0
    last_login_attempt: Optional[datetime] = None
    failed_login_attempts: int = 0
    last_failed_attempt: Optional[datetime] = None

class AuthManager:
    """
    Enhanced authentication manager with security features including:
    - Password hashing with PBKDF2-HMAC-SHA256
    - JWT token generation and validation
    - Rate limiting for login attempts
    - Token blacklisting
    - Role-based access control
    """
    
    def __init__(self, secret_key: str = None, token_expiry_days: int = 1):
        """Initialize the authentication manager.
        
        Args:
            secret_key: Secret key for JWT token generation.
                      If not provided, a random key will be generated.
            token_expiry_days: Token expiration time in days (default: 1)
        """
        self.secret_key = secret_key or os.urandom(32).hex()  # 256-bit key
        self.users: Dict[str, User] = {}
        self.token_blacklist: Set[str] = set()
        self.token_expiry = timedelta(days=token_expiry_days)
        self.refresh_token_expiry = timedelta(days=30)
        self.max_login_attempts = 5
        self.login_timeout = timedelta(minutes=15)

    def _validate_email(self, email: str) -> bool:
        """Validate email format."""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    def _validate_password_complexity(self, password: str) -> Tuple[bool, str]:
        """Validate password meets complexity requirements.
        
        Args:
            password: The password to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if len(password) < 8:
            return False, "Password must be at least 8 characters long"
        if not re.search(r"[A-Z]", password):
            return False, "Password must contain at least one uppercase letter"
        if not re.search(r"[a-z]", password):
            return False, "Password must contain at least one lowercase letter"
        if not re.search(r"[0-9]", password):
            return False, "Password must contain at least one number"
        if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
            return False, "Password must contain at least one special character"
        return True, ""
    
    def register_user(self, username: str, password: str, email: str, **user_data) -> Dict:
        """Register a new user with enhanced validation.
        
        Args:
            username: Unique username (3-30 chars, alphanumeric + _-)
            password: User's password (will be hashed)
            email: User's email address (must be valid format)
            **user_data: Additional user information
            
        Returns:
            Dict containing user information (without sensitive data)
            
        Raises:
            ValueError: If input validation fails
            UserAlreadyExistsError: If username or email already exists
        """
        # Input validation
        if not username or not isinstance(username, str) or not 3 <= len(username) <= 30:
            raise ValueError("Username must be 3-30 characters long")
        if not re.match(r'^[a-zA-Z0-9_-]+$', username):
            raise ValueError("Username can only contain letters, numbers, underscores, and hyphens")
        if not self._validate_email(email):
            raise ValueError("Invalid email format")
            
        # Password complexity check
        is_valid, message = self._validate_password_complexity(password)
        if not is_valid:
            raise ValueError(f"Password does not meet complexity requirements: {message}")

        # Check for existing user
        if username in self.users:
            raise UserAlreadyExistsError("Username already exists")
            
        # Check if email is already registered
        if any(user.email.lower() == email.lower() for user in self.users.values()):
            raise UserAlreadyExistsError("Email already registered")

        # Hash the password
        hashed_password = self._hash_password(password)
        
        # Create user object
        user = User(
            username=username,
            email=email,
            password_hash=hashed_password,
            roles=user_data.pop('roles', ['customer']),
            **user_data
        )
        
        self.users[username] = user
        logger.info(f"User registered: {username}")
        
        # Return user data without sensitive information
        return {
            'username': user.username,
            'email': user.email,
            'is_active': user.is_active,
            'is_verified': user.is_verified,
            'roles': user.roles,
            'created_at': user.created_at
        }
    
    def _is_login_blocked(self, user: User) -> bool:
        """Check if login is blocked due to too many failed attempts."""
        if user.failed_login_attempts >= self.max_login_attempts:
            if user.last_failed_attempt and \
               (datetime.utcnow() - user.last_failed_attempt) < self.login_timeout:
                return True
            else:
                # Reset counter if timeout has passed
                user.failed_login_attempts = 0
        return False
    
    def _update_failed_attempt(self, user: User) -> None:
        """Update failed login attempt counter and timestamp."""
        user.failed_login_attempts += 1
        user.last_failed_attempt = datetime.utcnow()
        logger.warning(f"Failed login attempt for user: {user.username} (attempt {user.failed_login_attempts})")
    
    def authenticate(self, username: str, password: str) -> Dict:
        """Authenticate a user with rate limiting and security checks.
        
        Args:
            username: User's username
            password: User's password
            
        Returns:
            Dict containing user information if authentication is successful
            
        Raises:
            InvalidCredentialsError: If authentication fails
            RateLimitExceededError: If too many failed attempts
        """
        user = self.users.get(username)
        
        # Check if user exists and is active
        if not user or not user.is_active:
            raise InvalidCredentialsError("Invalid username or password")
            
        # Check for rate limiting
        if self._is_login_blocked(user):
            remaining_time = (user.last_failed_attempt + self.login_timeout - datetime.utcnow()).seconds // 60
            raise RateLimitExceededError(
                f"Too many failed attempts. Please try again in {remaining_time} minutes."
            )
        
        # Verify password
        if not self._verify_password(password, user.password_hash):
            self._update_failed_attempt(user)
            raise InvalidCredentialsError("Invalid username or password")
            
        # Reset failed attempts on successful login
        user.failed_login_attempts = 0
        user.last_login_attempt = datetime.utcnow()
        logger.info(f"User logged in: {username}")
        
        # Return user data without sensitive information
        return {
            'username': user.username,
            'email': user.email,
            'is_active': user.is_active,
            'is_verified': user.is_verified,
            'roles': user.roles,
            'created_at': user.created_at
        }
    
    def generate_token(self, user_data: Dict) -> str:
        """Generate a JWT access token for an authenticated user.
        
        Args:
            user_data: User data to include in the token
            
        Returns:
            JWT token string
            
        Raises:
            ValueError: If required user data is missing
        """
        if not all(k in user_data for k in ['username', 'email']):
            raise ValueError("Missing required user data")
            
        now = datetime.utcnow()
        payload = {
            'sub': user_data['username'],
            'email': user_data['email'],
            'roles': user_data.get('roles', []),
            'iat': now,
            'exp': now + self.token_expiry,
            'type': 'access',
            'jti': os.urandom(16).hex()  # Unique token identifier
        }
        return jwt.encode(payload, self.secret_key, algorithm='HS256')
    
    def generate_refresh_token(self, user_data: Dict) -> str:
        """Generate a refresh token with longer expiry.
        
        Args:
            user_data: User data to include in the token
            
        Returns:
            JWT refresh token string
        """
        now = datetime.utcnow()
        payload = {
            'sub': user_data['username'],
            'iat': now,
            'exp': now + self.refresh_token_expiry,
            'type': 'refresh',
            'jti': os.urandom(16).hex()
        }
        return jwt.encode(payload, self.secret_key, algorithm='HS256')
    
    def verify_token(self, token: str, token_type: str = 'access') -> Dict:
        """Verify a JWT token and return the decoded payload if valid.
        
        Args:
            token: JWT token to verify
            token_type: Expected token type ('access' or 'refresh')
            
        Returns:
            Decoded token payload
            
        Raises:
            InvalidTokenError: If token is invalid, expired, or of wrong type
        """
        if token in self.token_blacklist:
            raise InvalidTokenError("Token has been revoked")
            
        try:
            payload = jwt.decode(
                token,
                self.secret_key,
                algorithms=['HS256'],
                options={'require': ['exp', 'iat', 'sub', 'type']}
            )
            
            # Verify token type
            if payload.get('type') != token_type:
                raise InvalidTokenError(f"Invalid token type. Expected: {token_type}")
                
            return payload
            
        except jwt.ExpiredSignatureError:
            raise InvalidTokenError("Token has expired")
        except jwt.PyJWTError as e:
            raise InvalidTokenError(f"Invalid token: {str(e)}")
    
    def refresh_token(self, refresh_token: str) -> Tuple[str, str]:
        """Generate new access and refresh tokens using a valid refresh token.
        
        Args:
            refresh_token: Valid refresh token
            
        Returns:
            Tuple of (new_access_token, new_refresh_token)
            
        Raises:
            InvalidTokenError: If refresh token is invalid or expired
        """
        try:
            # Verify the refresh token
            payload = self.verify_token(refresh_token, 'refresh')
            
            # Get user data
            username = payload['sub']
            user = self.users.get(username)
            if not user or not user.is_active:
                raise InvalidTokenError("User not found or inactive")
                
            # Invalidate the old refresh token
            self.token_blacklist.add(refresh_token)
            
            # Generate new tokens
            user_data = {
                'username': user.username,
                'email': user.email,
                'roles': user.roles
            }
            new_access_token = self.generate_token(user_data)
            new_refresh_token = self.generate_refresh_token(user_data)
            
            logger.info(f"Refreshed tokens for user: {username}")
            return new_access_token, new_refresh_token
            
        except Exception as e:
            logger.error(f"Token refresh failed: {str(e)}")
            raise InvalidTokenError("Failed to refresh token")
    
    def logout(self, token: str) -> None:
        """Invalidate a token by adding it to the blacklist.
        
        Args:
            token: The token to invalidate
            
        Raises:
            InvalidTokenError: If token is already blacklisted
        """
        if token in self.token_blacklist:
            raise InvalidTokenError("Token already invalidated")
            
        try:
            # Verify token before blacklisting
            payload = jwt.decode(token, self.secret_key, algorithms=['HS256'])
            self.token_blacklist.add(token)
            logger.info(f"User logged out: {payload.get('sub')}")
        except jwt.PyJWTError as e:
            raise InvalidTokenError(f"Invalid token: {str(e)}")
    
    def _hash_password(self, password: str) -> str:
        """Hash a password using PBKDF2-HMAC-SHA256 with a random salt.
        
        Args:
            password: The password to hash
            
        Returns:
            String containing the salt and hash in the format 'salt:hash'
        """
        salt = os.urandom(16)  # 128-bit salt
        pwd_hash = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt,
            210000,  # Number of iterations (can be increased for better security)
            dklen=32  # 256-bit output
        )
        return f"{salt.hex()}:{pwd_hash.hex()}"
    
    def _verify_password(self, password: str, stored_hash: str) -> bool:
        """Verify a password against a stored hash.
        
        Args:
            password: The password to verify
            stored_hash: The stored hash in 'salt:hash' format
            
        Returns:
            bool: True if the password matches the hash, False otherwise
        """
        try:
            # Split the stored hash into salt and hash
            salt_hex, stored_hash_hex = stored_hash.split(':')
            salt = bytes.fromhex(salt_hex)
            stored_hash_bytes = bytes.fromhex(stored_hash_hex)
            
            # Hash the provided password with the same salt
            new_hash = hashlib.pbkdf2_hmac(
                'sha256',
                password.encode('utf-8'),
                salt,
                210000,
                dklen=32
            )
            
            # Use constant-time comparison to prevent timing attacks
            return hmac.compare_digest(new_hash, stored_hash_bytes)
            
        except (ValueError, AttributeError) as e:
            logger.error(f"Password verification error: {str(e)}")
            return False

    def has_permission(self, user_roles: List[str], required_roles: List[str]) -> bool:
        """Check if a user has the required roles.
        
        Args:
            user_roles: List of roles the user has
            required_roles: List of roles required to access a resource
            
        Returns:
            bool: True if user has at least one of the required roles
            
        Examples:
            >>> auth = AuthManager()
            >>> auth.has_permission(['admin', 'editor'], ['admin'])  # Returns True
            >>> auth.has_permission(['user'], ['admin', 'editor'])   # Returns False
        """
        if not isinstance(user_roles, list) or not isinstance(required_roles, list):
            return False
            
        # Check if any of the user's roles match the required roles
        return any(role in user_roles for role in required_roles)
    
    def require_auth(self, roles: List[str] = None):
        """Decorator to require authentication and optionally specific roles.
        
        Args:
            roles: Optional list of required roles
            
        Returns:
            Decorator function
        """
        def decorator(func: Callable) -> Callable:
            def wrapper(*args, **kwargs):
                # Get token from request headers or cookies
                token = self._extract_token_from_request()
                
                try:
                    # Verify the token
                    payload = self.verify_token(token)
                    
                    # Check if user has required roles
                    if roles and not self.has_permission(payload.get('roles', []), roles):
                        raise PermissionError("Insufficient permissions")
                        
                    # Add user to kwargs and call the original function
                    kwargs['current_user'] = payload
                    return func(*args, **kwargs)
                    
                except (InvalidTokenError, PermissionError) as e:
                    # Handle authentication/authorization errors
                    return {"error": str(e)}, 401
                    
            return wrapper
        return decorator
    
    def _extract_token_from_request(self) -> str:
        """Extract JWT token from request headers or cookies."""
        # This is a placeholder - implementation depends on your web framework
        # Example for Flask:
        # auth_header = request.headers.get('Authorization')
        # if auth_header and auth_header.startswith('Bearer '):
        #     return auth_header.split(' ')[1]
        # return request.cookies.get('access_token')
        raise NotImplementedError("Token extraction not implemented")

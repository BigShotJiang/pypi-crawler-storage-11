"""
Shopping cart module for EcomLib.
Handles shopping cart operations like add, remove, update items, and calculate totals.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
import uuid
from datetime import datetime
from decimal import Decimal

@dataclass
class CartItem:
    """Represents an item in the shopping cart."""
    product_id: str
    quantity: int
    price: Decimal
    attributes: Dict = field(default_factory=dict)
    added_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    
    @property
    def total_price(self) -> Decimal:
        """Calculate the total price for this cart item (price * quantity)."""
        return self.price * Decimal(str(self.quantity))

class ShoppingCart:
    """Manages a user's shopping cart."""
    
    def __init__(self, cart_id: str = None):
        """Initialize a new shopping cart.
        
        Args:
            cart_id: Optional cart ID. If not provided, a new UUID will be generated.
        """
        self.cart_id = cart_id or str(uuid.uuid4())
        self.items: Dict[str, CartItem] = {}  # product_id -> CartItem
        self.created_at = datetime.utcnow().isoformat()
        self.updated_at = datetime.utcnow().isoformat()
        self.coupon_code: Optional[str] = None
        self.discount: Decimal = Decimal('0.00')
    
    def add_item(self, product_id: str, quantity: int, price: Decimal, 
                attributes: Optional[Dict] = None) -> CartItem:
        """Add an item to the cart or update its quantity if it already exists.
        
        Args:
            product_id: ID of the product to add
            quantity: Quantity to add
            price: Price per unit
            attributes: Optional product attributes
            
        Returns:
            The added or updated cart item
        """
        if quantity <= 0:
            raise ValueError("Quantity must be greater than zero")
            
        if product_id in self.items:
            # Update existing item
            self.items[product_id].quantity += quantity
            item = self.items[product_id]
        else:
            # Add new item
            item = CartItem(
                product_id=product_id,
                quantity=quantity,
                price=Decimal(str(price)),
                attributes=attributes or {}
            )
            self.items[product_id] = item
        
        self.updated_at = datetime.utcnow().isoformat()
        return item
    
    def update_item_quantity(self, product_id: str, quantity: int) -> Optional[CartItem]:
        """Update the quantity of an item in the cart.
        
        Args:
            product_id: ID of the product to update
            quantity: New quantity (must be > 0 to keep the item in cart)
            
        Returns:
            The updated cart item if found, None otherwise
        """
        if product_id not in self.items:
            return None
            
        if quantity <= 0:
            return self.remove_item(product_id)
            
        self.items[product_id].quantity = quantity
        self.updated_at = datetime.utcnow().isoformat()
        return self.items[product_id]
    
    def remove_item(self, product_id: str) -> Optional[CartItem]:
        """Remove an item from the cart.
        
        Args:
            product_id: ID of the product to remove
            
        Returns:
            The removed cart item if found, None otherwise
        """
        if product_id not in self.items:
            return None
            
        item = self.items.pop(product_id)
        self.updated_at = datetime.utcnow().isoformat()
        return item
    
    def clear(self) -> None:
        """Remove all items from the cart."""
        self.items.clear()
        self.coupon_code = None
        self.discount = Decimal('0.00')
        self.updated_at = datetime.utcnow().isoformat()
    
    def get_item_count(self) -> int:
        """Get the total number of items in the cart."""
        return sum(item.quantity for item in self.items.values())
    
    def get_unique_item_count(self) -> int:
        """Get the count of unique products in the cart."""
        return len(self.items)
    
    def get_subtotal(self) -> Decimal:
        """Calculate the subtotal (sum of all items' prices)."""
        return sum(item.total_price for item in self.items.values())
    
    def get_total(self) -> Decimal:
        """Calculate the total after applying discounts."""
        subtotal = self.get_subtotal()
        return max(Decimal('0.00'), subtotal - self.discount)
    
    def apply_coupon(self, code: str, discount_amount: Decimal) -> bool:
        """Apply a coupon code to the cart.
        
        Args:
            code: Coupon code
            discount_amount: Discount amount to apply
            
        Returns:
            True if the coupon was applied, False otherwise
        """
        if not code or discount_amount < 0:
            return False
            
        self.coupon_code = code
        self.discount = Decimal(str(discount_amount))
        self.updated_at = datetime.utcnow().isoformat()
        return True
    
    def remove_coupon(self) -> None:
        """Remove any applied coupon from the cart."""
        self.coupon_code = None
        self.discount = Decimal('0.00')
        self.updated_at = datetime.utcnow().isoformat()
    
    def to_dict(self) -> dict:
        """Convert the cart to a dictionary for serialization."""
        return {
            'cart_id': self.cart_id,
            'items': [
                {
                    'product_id': item.product_id,
                    'quantity': item.quantity,
                    'price': float(item.price),
                    'attributes': item.attributes,
                    'added_at': item.added_at,
                    'total_price': float(item.total_price)
                }
                for item in self.items.values()
            ],
            'subtotal': float(self.get_subtotal()),
            'discount': float(self.discount),
            'total': float(self.get_total()),
            'item_count': self.get_item_count(),
            'unique_item_count': self.get_unique_item_count(),
            'coupon_code': self.coupon_code,
            'created_at': self.created_at,
            'updated_at': self.updated_at
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'ShoppingCart':
        """Create a ShoppingCart instance from a dictionary."""
        cart = cls(cart_id=data.get('cart_id'))
        cart.created_at = data.get('created_at', cart.created_at)
        cart.updated_at = data.get('updated_at', cart.updated_at)
        cart.coupon_code = data.get('coupon_code')
        cart.discount = Decimal(str(data.get('discount', 0)))
        
        for item_data in data.get('items', []):
            product_id = item_data['product_id']
            cart.items[product_id] = CartItem(
                product_id=product_id,
                quantity=item_data['quantity'],
                price=Decimal(str(item_data['price'])),
                attributes=item_data.get('attributes', {}),
                added_at=item_data.get('added_at')
            )
        
        return cart

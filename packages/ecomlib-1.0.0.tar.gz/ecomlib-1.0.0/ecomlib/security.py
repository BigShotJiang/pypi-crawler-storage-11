import os
import hashlib
import hmac
import base64
import json
import time
from datetime import datetime, timedelta
from typing import Dict, Optional, Union, Any, Tuple
import jwt
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend

class SecurityManager:
    """
    Handles security-related operations including:
    - Password hashing and verification
    - JWT token generation and validation
    - Data encryption and decryption
    - CSRF protection
    - Rate limiting
    """
    
    def __init__(self, secret_key: str, algorithm: str = "HS256", 
                 token_expiry: int = 3600, salt_rounds: int = 100000):
        """
        Initialize the SecurityManager.
        
        Args:
            secret_key: A secret key used for cryptographic operations
            algorithm: Algorithm for JWT (default: HS256)
            token_expiry: Token expiry time in seconds (default: 1 hour)
            salt_rounds: Number of iterations for password hashing (default: 100,000)
        """
        self.secret_key = secret_key.encode()
        self.algorithm = algorithm
        self.token_expiry = token_expiry
        self.salt_rounds = salt_rounds
        
        # For rate limiting
        self.rate_limits: Dict[str, Dict[str, Any]] = {}
    
    def hash_password(self, password: str, salt: Optional[bytes] = None) -> Tuple[bytes, bytes]:
        """
        Hash a password using PBKDF2 with HMAC-SHA256.
        
        Args:
            password: The password to hash
            salt: Optional salt (if None, a new one will be generated)
            
        Returns:
            A tuple of (hashed_password, salt)
        """
        if salt is None:
            salt = os.urandom(16)
            
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=self.salt_rounds,
            backend=default_backend()
        )
        
        hashed = kdf.derive(password.encode())
        return hashed, salt
    
    def verify_password(self, password: str, stored_hash: bytes, salt: bytes) -> bool:
        """
        Verify a password against a stored hash.
        
        Args:
            password: The password to verify
            stored_hash: The stored password hash
            salt: The salt used for the original hash
            
        Returns:
            bool: True if the password matches, False otherwise
        """
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=self.salt_rounds,
            backend=default_backend()
        )
        
        try:
            kdf.verify(password.encode(), stored_hash)
            return True
        except Exception:
            return False
    
    def generate_csrf_token(self) -> str:
        """Generate a CSRF token."""
        return base64.b64encode(os.urandom(32)).decode('utf-8')
    
    def verify_csrf_token(self, token: str, csrf_token: str) -> bool:
        """
        Verify a CSRF token using constant-time comparison.
        
        Args:
            token: The token from the form/header
            csrf_token: The token from the session
            
        Returns:
            bool: True if tokens match, False otherwise
        """
        if not token or not csrf_token:
            return False
        return hmac.compare_digest(token, csrf_token)
    
    def generate_jwt_token(self, payload: Dict[str, Any], expiry: Optional[int] = None) -> str:
        """
        Generate a JWT token.
        
        Args:
            payload: The payload to include in the token
            expiry: Token expiry time in seconds (default: self.token_expiry)
            
        Returns:
            str: The encoded JWT token
        """
        if expiry is None:
            expiry = self.token_expiry
            
        payload = payload.copy()
        payload.update({
            'exp': datetime.utcnow() + timedelta(seconds=expiry),
            'iat': datetime.utcnow(),
            'nbf': datetime.utcnow() - timedelta(seconds=5)  # Not before now - 5 seconds
        })
        
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    def verify_jwt_token(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Verify and decode a JWT token.
        
        Args:
            token: The JWT token to verify
            
        Returns:
            Optional[Dict]: The decoded token payload if valid, None otherwise
        """
        try:
            payload = jwt.decode(
                token,
                self.secret_key,
                algorithms=[self.algorithm],
                options={"verify_exp": True, "verify_iat": True, "verify_nbf": True}
            )
            return payload
        except (jwt.ExpiredSignatureError, jwt.InvalidTokenError, jwt.DecodeError):
            return None
    
    def encrypt_data(self, data: Union[str, Dict], key: Optional[bytes] = None) -> str:
        """
        Encrypt data using AES-256-CBC.
        
        Args:
            data: The data to encrypt (string or dictionary)
            key: Optional encryption key (default: uses secret_key)
            
        Returns:
            str: Base64-encoded encrypted data with IV
        """
        if key is None:
            key = self.secret_key[:32]  # Use first 32 bytes of secret_key for AES-256
            
        if isinstance(data, dict):
            data = json.dumps(data)
        
        # Generate a random IV
        iv = os.urandom(16)
        
        # Pad the data to be a multiple of the block size
        padder = padding.PKCS7(128).padder()
        padded_data = padder.update(data.encode()) + padder.finalize()
        
        # Create cipher and encrypt
        cipher = Cipher(
            algorithms.AES(key),
            modes.CBC(iv),
            backend=default_backend()
        )
        encryptor = cipher.encryptor()
        encrypted = encryptor.update(padded_data) + encryptor.finalize()
        
        # Combine IV and encrypted data
        result = iv + encrypted
        
        # Return base64 encoded result
        return base64.b64encode(result).decode('utf-8')
    
    def decrypt_data(self, encrypted_data: str, key: Optional[bytes] = None) -> Union[str, Dict, None]:
        """
        Decrypt data encrypted with encrypt_data.
        
        Args:
            encrypted_data: The encrypted data (base64-encoded)
            key: Optional decryption key (default: uses secret_key)
            
        Returns:
            Union[str, Dict, None]: The decrypted data, or None if decryption failed
        """
        if key is None:
            key = self.secret_key[:32]  # Use first 32 bytes of secret_key for AES-256
        
        try:
            # Decode from base64
            data = base64.b64decode(encrypted_data)
            
            # Extract IV and encrypted data
            iv = data[:16]
            encrypted = data[16:]
            
            # Create cipher and decrypt
            cipher = Cipher(
                algorithms.AES(key),
                modes.CBC(iv),
                backend=default_backend()
            )
            decryptor = cipher.decryptor()
            padded = decryptor.update(encrypted) + decryptor.finalize()
            
            # Unpad the data
            unpadder = padding.PKCS7(128).unpadder()
            result = unpadder.update(padded) + unpadder.finalize()
            
            # Try to parse as JSON, return as string if not valid JSON
            try:
                return json.loads(result.decode('utf-8'))
            except json.JSONDecodeError:
                return result.decode('utf-8')
                
        except Exception as e:
            print(f"Decryption error: {e}")
            return None
    
    def check_rate_limit(self, identifier: str, max_requests: int, window_seconds: int) -> bool:
        """
        Check if a request should be rate limited.
        
        Args:
            identifier: A unique identifier for the client (e.g., IP address, user ID)
            max_requests: Maximum number of requests allowed in the time window
            window_seconds: Time window in seconds
            
        Returns:
            bool: True if the request is allowed, False if rate limited
        """
        now = time.time()
        
        # Initialize rate limit data for this identifier if it doesn't exist
        if identifier not in self.rate_limits:
            self.rate_limits[identifier] = {
                'count': 1,
                'start_time': now
            }
            return True
        
        # Get the rate limit data
        data = self.rate_limits[identifier]
        
        # Reset the counter if the time window has passed
        if now - data['start_time'] > window_seconds:
            data['count'] = 1
            data['start_time'] = now
            return True
        
        # Increment the counter and check against max_requests
        data['count'] += 1
        return data['count'] <= max_requests
    
    def sanitize_input(self, input_data: Union[str, Dict, list]) -> Union[str, Dict, list]:
        """
        Sanitize input to prevent XSS and injection attacks.
        
        Args:
            input_data: The input data to sanitize
            
        Returns:
            The sanitized data
        """
        if isinstance(input_data, str):
            # Basic XSS protection
            return (
                input_data.replace('&', '&amp;')
                         .replace('<', '&lt;')
                         .replace('>', '&gt;')
                         .replace('"', '&quot;')
                         .replace("'", '&#x27;')
                         .replace('/', '&#x2F;')
            )
        elif isinstance(input_data, dict):
            return {k: self.sanitize_input(v) for k, v in input_data.items()}
        elif isinstance(input_data, list):
            return [self.sanitize_input(item) for item in input_data]
        else:
            return input_data
    
    def generate_secure_random_string(self, length: int = 32) -> str:
        """
        Generate a cryptographically secure random string.
        
        Args:
            length: Length of the random string to generate
            
        Returns:
            str: A URL-safe random string
        """
        return base64.urlsafe_b64encode(os.urandom(length)).decode('utf-8')

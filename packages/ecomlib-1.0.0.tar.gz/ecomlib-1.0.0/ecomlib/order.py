"""
Order management module for EcomLib.
Handles order creation, processing, and tracking.
"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Set, Tuple
from datetime import datetime
import uuid
from enum import Enum, auto

class OrderStatus(Enum):
    """Represents the status of an order."""
    PENDING = "pending"
    PROCESSING = "processing"
    SHIPPED = "shipped"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"
    FAILED = "failed"

class PaymentStatus(Enum):
    """Represents the payment status of an order."""
    PENDING = "pending"
    AUTHORIZED = "authorized"
    PAID = "paid"
    REFUNDED = "refunded"
    PARTIALLY_REFUNDED = "partially_refunded"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class OrderItem:
    """Represents an item in an order."""
    product_id: str
    quantity: int
    unit_price: float
    name: str
    sku: str
    tax_rate: float = 0.0
    discount: float = 0.0
    metadata: Dict = field(default_factory=dict)

    @property
    def subtotal(self) -> float:
        """Calculate the subtotal for this order item."""
        return self.unit_price * self.quantity

    @property
    def tax_amount(self) -> float:
        """Calculate the tax amount for this order item."""
        return self.subtotal * (self.tax_rate / 100)

    @property
    def total(self) -> float:
        """Calculate the total for this order item including tax and discount."""
        return (self.subtotal + self.tax_amount) - self.discount

@dataclass
class Order:
    """Represents an order in the e-commerce system."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    customer_id: str = ""
    items: List[OrderItem] = field(default_factory=list)
    status: OrderStatus = OrderStatus.PENDING
    payment_status: PaymentStatus = PaymentStatus.PENDING
    shipping_address: Dict = field(default_factory=dict)
    billing_address: Dict = field(default_factory=dict)
    shipping_method: str = "standard"
    shipping_cost: float = 0.0
    discount_code: str = ""
    discount_amount: float = 0.0
    tax_rate: float = 0.0
    currency: str = "USD"
    notes: str = ""
    metadata: Dict = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    @property
    def subtotal(self) -> float:
        """Calculate the subtotal for all items in the order."""
        return sum(item.subtotal for item in self.items)

    @property
    def tax_amount(self) -> float:
        """Calculate the total tax amount for the order."""
        return sum(item.tax_amount for item in self.items) + (self.subtotal * (self.tax_rate / 100))

    @property
    def total(self) -> float:
        """Calculate the total amount for the order."""
        return (self.subtotal + self.shipping_cost + self.tax_amount) - self.discount_amount

    def add_item(self, product_id: str, quantity: int, unit_price: float, 
                 name: str, sku: str, **kwargs) -> OrderItem:
        """Add an item to the order.
        
        Args:
            product_id: ID of the product
            quantity: Quantity of the product
            unit_price: Price per unit
            name: Product name
            sku: Product SKU
            **kwargs: Additional item attributes (tax_rate, discount, etc.)
            
        Returns:
            The created OrderItem
        """
        item = OrderItem(
            product_id=product_id,
            quantity=quantity,
            unit_price=unit_price,
            name=name,
            sku=sku,
            **kwargs
        )
        self.items.append(item)
        self.updated_at = datetime.utcnow().isoformat()
        return item

    def update_status(self, status: OrderStatus, notes: str = "") -> None:
        """Update the order status.
        
        Args:
            status: New order status
            notes: Optional notes about the status change
        """
        self.status = status
        if notes:
            self.notes = f"{self.notes}\n{datetime.utcnow().isoformat()}: {notes}"
        self.updated_at = datetime.utcnow().isoformat()

    def update_payment_status(self, status: PaymentStatus, notes: str = "") -> None:
        """Update the payment status.
        
        Args:
            status: New payment status
            notes: Optional notes about the status change
        """
        self.payment_status = status
        if notes:
            self.notes = f"{self.notes}\n{datetime.utcnow().isoformat()}: {notes}"
        self.updated_at = datetime.utcnow().isoformat()

class OrderManager:
    """Manages orders in the e-commerce system."""
    
    def __init__(self):
        """Initialize the order manager with an empty order store."""
        self.orders: Dict[str, Order] = {}
        self.customer_orders: Dict[str, Set[str]] = {}  # customer_id -> set of order_ids
    
    def create_order(self, customer_id: str, items: List = None, **kwargs) -> Order:
        """Create a new order.
        
        Args:
            customer_id: ID of the customer placing the order
            items: List of items (can be dicts or OrderItem objects)
            **kwargs: Additional order attributes
            
        Returns:
            The created Order
        """
        # Convert dict items to OrderItem objects if needed
        order_items = []
        if items:
            for item in items:
                if isinstance(item, dict):
                    # Convert dict to OrderItem
                    order_items.append(OrderItem(
                        product_id=item['product_id'],
                        quantity=item['quantity'],
                        unit_price=float(item['unit_price']),
                        name=item['name'],
                        sku=item['sku'],
                        tax_rate=item.get('tax_rate', 0.0),
                        discount=item.get('discount', 0.0),
                        metadata=item.get('metadata', {})
                    ))
                elif isinstance(item, OrderItem):
                    order_items.append(item)
                else:
                    raise ValueError(f"Invalid item type: {type(item)}")
        
        order = Order(customer_id=customer_id, items=order_items, **kwargs)
        self.orders[order.id] = order
        
        # Update customer orders index
        if customer_id not in self.customer_orders:
            self.customer_orders[customer_id] = set()
        self.customer_orders[customer_id].add(order.id)
        
        return order
    
    def get_order(self, order_id: str) -> Optional[Order]:
        """Get an order by ID.
        
        Args:
            order_id: ID of the order to retrieve
            
        Returns:
            The Order if found, None otherwise
        """
        return self.orders.get(order_id)
    
    def get_customer_orders(self, customer_id: str) -> List[Order]:
        """Get all orders for a specific customer.
        
        Args:
            customer_id: ID of the customer
            
        Returns:
            List of customer's orders, most recent first
        """
        if customer_id not in self.customer_orders:
            return []
            
        order_ids = sorted(
            self.customer_orders[customer_id],
            key=lambda oid: self.orders[oid].created_at,
            reverse=True
        )
        return [self.orders[oid] for oid in order_ids]
    
    def update_order(self, order_id: str, **updates) -> Optional[Order]:
        """Update order information.
        
        Args:
            order_id: ID of the order to update
            **updates: Fields to update with their new values
            
        Returns:
            The updated Order if found, None otherwise
        """
        if order_id not in self.orders:
            return None
            
        order = self.orders[order_id]
        
        # Update fields
        for key, value in updates.items():
            if hasattr(order, key) and key not in ['id', 'created_at', 'updated_at']:
                setattr(order, key, value)
        
        # Update timestamp
        order.updated_at = datetime.utcnow().isoformat()
        
        return order
    
    def cancel_order(self, order_id: str, reason: str = "") -> bool:
        """Cancel an order.
        
        Args:
            order_id: ID of the order to cancel
            reason: Optional reason for cancellation
            
        Returns:
            True if the order was cancelled, False if not found or already cancelled
        """
        if order_id not in self.orders:
            return False
            
        order = self.orders[order_id]
        
        if order.status == OrderStatus.CANCELLED:
            return False
            
        order.update_status(OrderStatus.CANCELLED, f"Order cancelled. {reason}".strip())
        return True
    
    def process_refund(self, order_id: str, amount: float = None, reason: str = "") -> bool:
        """Process a refund for an order.
        
        Args:
            order_id: ID of the order to refund
            amount: Amount to refund (None for full refund)
            reason: Reason for the refund
            
        Returns:
            True if the refund was processed, False if not found or invalid
        """
        if order_id not in self.orders:
            return False
            
        order = self.orders[order_id]
        
        # Calculate refund amount
        if amount is None:
            amount = order.total
        else:
            amount = min(amount, order.total)
            
        # Update payment status
        if amount >= order.total:
            order.update_payment_status(PaymentStatus.REFUNDED, f"Full refund processed. {reason}".strip())
            order.update_status(OrderStatus.REFUNDED, "Order fully refunded.")
        else:
            order.update_payment_status(
                PaymentStatus.PARTIALLY_REFUNDED,
                f"Partial refund of {amount} {order.currency} processed. {reason}".strip()
            )
            
        return True
    
    def search_orders(self, query: str = None, status: OrderStatus = None, 
                     customer_id: str = None, start_date: str = None, 
                     end_date: str = None) -> List[Order]:
        """Search for orders based on various criteria.
        
        Args:
            query: Search in order ID or customer name/email
            status: Filter by order status
            customer_id: Filter by customer ID
            start_date: Filter orders created after this date (ISO format)
            end_date: Filter orders created before this date (ISO format)
            
        Returns:
            List of matching orders, most recent first
        """
        results = list(self.orders.values())
        
        if status:
            results = [o for o in results if o.status == status]
            
        if customer_id:
            results = [o for o in results if o.customer_id == customer_id]
            
        if start_date:
            results = [o for o in results if o.created_at >= start_date]
            
        if end_date:
            results = [o for o in results if o.created_at <= end_date]
            
        if query:
            query = query.lower()
            results = [
                o for o in results 
                if query in o.id.lower() or 
                   query in (o.shipping_address.get('email', '').lower() if o.shipping_address else '') or
                   query in (o.billing_address.get('email', '').lower() if o.billing_address else '')
            ]
        
        # Sort by creation date, most recent first
        return sorted(results, key=lambda o: o.created_at, reverse=True)

from abc import ABC, abstractmethod
from typing import Dict, Optional, Union
import json
import requests
from dataclasses import dataclass

@dataclass
class PaymentResult:
    """Dataclass to hold payment processing results."""
    success: bool
    transaction_id: Optional[str] = None
    amount: Optional[float] = None
    currency: str = "USD"
    message: Optional[str] = None
    raw_response: Optional[Dict] = None

class PaymentGateway(ABC):
    """Abstract base class for payment gateways."""
    
    @abstractmethod
    def process_payment(self, amount: float, **kwargs) -> PaymentResult:
        """Process a payment."""
        pass
    
    @abstractmethod
    def refund_payment(self, transaction_id: str, amount: Optional[float] = None) -> PaymentResult:
        """Process a refund."""
        pass

class StripeGateway(PaymentGateway):
    """Stripe payment gateway implementation."""
    
    BASE_URL = "https://api.stripe.com/v1/"
    
    def __init__(self, api_key: str):
        """Initialize with your Stripe API key."""
        self.api_key = api_key
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/x-www-form-urlencoded"
        }
    
    def process_payment(self, amount: float, **kwargs) -> PaymentResult:
        """Process payment through Stripe."""
        try:
            data = {
                "amount": int(amount * 100),  # Convert to cents
                "currency": kwargs.get("currency", "usd"),
                "source": kwargs["source"],  # token from Stripe.js
                "description": kwargs.get("description", "")
            }
            
            response = requests.post(
                f"{self.BASE_URL}charges",
                headers=self.headers,
                data=data
            )
            response.raise_for_status()
            
            result = response.json()
            return PaymentResult(
                success=True,
                transaction_id=result["id"],
                amount=result["amount"] / 100,
                currency=result["currency"].upper(),
                message="Payment processed successfully",
                raw_response=result
            )
            
        except requests.exceptions.RequestException as e:
            error_msg = str(e)
            try:
                error_msg = e.response.json().get("error", {}).get("message", str(e))
            except:
                pass
            return PaymentResult(
                success=False,
                message=f"Payment failed: {error_msg}",
                raw_response={"error": str(e)}
            )
    
    def refund_payment(self, transaction_id: str, amount: Optional[float] = None) -> PaymentResult:
        """Process refund through Stripe."""
        try:
            data = {"charge": transaction_id}
            if amount is not None:
                data["amount"] = int(amount * 100)
                
            response = requests.post(
                f"{self.BASE_URL}refunds",
                headers=self.headers,
                data=data
            )
            response.raise_for_status()
            
            result = response.json()
            return PaymentResult(
                success=True,
                transaction_id=result["id"],
                amount=result["amount"] / 100,
                currency=result["currency"].upper(),
                message="Refund processed successfully",
                raw_response=result
            )
            
        except requests.exceptions.RequestException as e:
            error_msg = str(e)
            try:
                error_msg = e.response.json().get("error", {}).get("message", str(e))
            except:
                pass
            return PaymentResult(
                success=False,
                message=f"Refund failed: {error_msg}",
                raw_response={"error": str(e)}
            )

class PayPalGateway(PaymentGateway):
    """PayPal payment gateway implementation."""
    
    def __init__(self, client_id: str, client_secret: str, sandbox: bool = True):
        """Initialize with PayPal API credentials."""
        self.client_id = client_id
        self.client_secret = client_secret
        self.sandbox = sandbox
        self.base_url = "https://api-m.sandbox.paypal.com" if sandbox else "https://api-m.paypal.com"
        self.access_token = self._get_access_token()
    
    def _get_access_token(self) -> str:
        """Get OAuth2 access token from PayPal."""
        auth = (self.client_id, self.client_secret)
        data = {"grant_type": "client_credentials"}
        headers = {"Accept": "application/json", "Accept-Language": "en_US"}
        
        response = requests.post(
            f"{self.base_url}/v1/oauth2/token",
            data=data,
            headers=headers,
            auth=auth
        )
        response.raise_for_status()
        return response.json()["access_token"]
    
    def process_payment(self, amount: float, **kwargs) -> PaymentResult:
        """Process payment through PayPal."""
        try:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.access_token}",
                "PayPal-Request-Id": kwargs.get("request_id", "")
            }
            
            data = {
                "intent": "sale",
                "payer": {
                    "payment_method": "paypal"
                },
                "transactions": [{
                    "amount": {
                        "total": f"{amount:.2f}",
                        "currency": kwargs.get("currency", "USD")
                    },
                    "description": kwargs.get("description", "")
                }],
                "redirect_urls": {
                    "return_url": kwargs.get("return_url", ""),
                    "cancel_url": kwargs.get("cancel_url", "")
                }
            }
            
            response = requests.post(
                f"{self.base_url}/v1/payments/payment",
                headers=headers,
                data=json.dumps(data)
            )
            response.raise_for_status()
            
            result = response.json()
            return PaymentResult(
                success=True,
                transaction_id=result["id"],
                amount=amount,
                currency=kwargs.get("currency", "USD"),
                message="Payment created successfully",
                raw_response=result
            )
            
        except requests.exceptions.RequestException as e:
            error_msg = str(e)
            try:
                error_msg = e.response.json().get("message", str(e))
            except:
                pass
            return PaymentResult(
                success=False,
                message=f"Payment failed: {error_msg}",
                raw_response={"error": str(e)}
            )
    
    def refund_payment(self, transaction_id: str, amount: Optional[float] = None) -> PaymentResult:
        """Process refund through PayPal."""
        try:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.access_token}"
            }
            
            data = {}
            if amount is not None:
                data["amount"] = {
                    "total": f"{amount:.2f}",
                    "currency": "USD"
                }
            
            response = requests.post(
                f"{self.base_url}/v2/payments/captures/{transaction_id}/refund",
                headers=headers,
                data=json.dumps(data) if data else None
            )
            response.raise_for_status()
            
            result = response.json()
            return PaymentResult(
                success=True,
                transaction_id=result["id"],
                amount=amount,
                currency=result.get("amount", {}).get("currency_code", "USD"),
                message="Refund processed successfully",
                raw_response=result
            )
            
        except requests.exceptions.RequestException as e:
            error_msg = str(e)
            try:
                error_msg = e.response.json().get("message", str(e))
            except:
                pass
            return PaymentResult(
                success=False,
                message=f"Refund failed: {error_msg}",
                raw_response={"error": str(e)}
            )

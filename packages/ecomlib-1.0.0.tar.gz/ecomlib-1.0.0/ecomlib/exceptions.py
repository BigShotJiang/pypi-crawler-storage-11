"""
Custom exceptions for the EcomLib library.
"""
from typing import Optional, Dict, Union

class EcomLibError(Exception):
    """Base exception for all EcomLib exceptions."""
    pass

class PaymentError(EcomLibError):
    """Raised when there is an error processing a payment."""
    def __init__(self, message: str, code: Optional[str] = None, details: Optional[Dict] = None):
        self.code = code
        self.details = details or {}
        super().__init__(message)

class AuthenticationError(EcomLibError):
    """Raised when authentication fails."""
    pass

class AuthorizationError(EcomLibError):
    """Raised when a user is not authorized to perform an action."""
    pass

class ValidationError(EcomLibError):
    """Raised when input validation fails."""
    def __init__(self, message: str, errors: Optional[Dict] = None):
        self.errors = errors or {}
        super().__init__(message)

class RateLimitExceededError(EcomLibError):
    """Raised when the rate limit is exceeded."""
    def __init__(self, message: str = "Rate limit exceeded", retry_after: Optional[int] = None):
        self.retry_after = retry_after
        super().__init__(message)

class ServiceUnavailableError(EcomLibError):
    """Raised when a required service is unavailable."""
    pass


# Inventory-specific exceptions
class InventoryError(EcomLibError):
    """Base exception for inventory-related errors."""
    pass


class InsufficientStockError(InventoryError):
    """Raised when there is not enough stock to fulfill a request."""
    def __init__(
        self,
        product_id: str,
        variant_id: Optional[str] = None,
        requested: int = 0,
        available: int = 0,
        location_id: str = "default"
    ):
        self.product_id = product_id
        self.variant_id = variant_id
        self.requested = requested
        self.available = available
        self.location_id = location_id
        
        item_desc = f"product '{product_id}'"
        if variant_id:
            item_desc = f"variant '{variant_id}' of {item_desc}"
            
        super().__init__(
            f"Insufficient stock for {item_desc} at location '{location_id}'. "
            f"Requested: {requested}, Available: {available}"
        )


class ProductNotFoundError(InventoryError):
    """Raised when a product is not found in the inventory."""
    def __init__(self, product_id: str, message: Optional[str] = None):
        self.product_id = product_id
        if not message:
            message = f"Product not found: {product_id}"
        super().__init__(message)


class VariantNotFoundError(InventoryError):
    """Raised when a variant is not found for a product."""
    def __init__(self, product_id: str, variant_id: str, message: Optional[str] = None):
        self.product_id = product_id
        self.variant_id = variant_id
        if not message:
            message = f"Variant '{variant_id}' not found for product '{product_id}'"
        super().__init__(message)


class DuplicateProductError(InventoryError):
    """Raised when attempting to add a product that already exists."""
    def __init__(self, product_id: str):
        self.product_id = product_id
        super().__init__(f"Product already exists: {product_id}")


class DuplicateVariantError(InventoryError):
    """Raised when attempting to add a variant that already exists."""
    def __init__(self, product_id: str, variant_id: str):
        self.product_id = product_id
        self.variant_id = variant_id
        super().__init__(
            f"Variant '{variant_id}' already exists for product '{product_id}'"
        )


class InvalidMovementError(InventoryError):
    """Raised when an invalid stock movement is attempted."""
    def __init__(self, message: str, movement_type: Optional[str] = None, **details):
        self.movement_type = movement_type
        self.details = details
        super().__init__(message)


class InventoryValidationError(ValidationError):
    """Raised when inventory data validation fails."""
    def __init__(self, message: str, errors: Optional[Dict] = None):
        super().__init__(f"Inventory validation failed: {message}", errors)


class ReconciliationError(InventoryError):
    """Raised when a reconciliation operation fails."""
    def __init__(self, message: str, reconciliation_data: Optional[Dict] = None):
        self.reconciliation_data = reconciliation_data or {}
        super().__init__(f"Reconciliation failed: {message}")


class ThresholdExceededError(InventoryError):
    """Raised when an inventory threshold is exceeded."""
    def __init__(
        self,
        product_id: str,
        threshold_type: str,
        threshold_value: Union[int, float],
        actual_value: Union[int, float],
        variant_id: Optional[str] = None,
        location_id: str = "default"
    ):
        self.product_id = product_id
        self.variant_id = variant_id
        self.threshold_type = threshold_type
        self.threshold_value = threshold_value
        self.actual_value = actual_value
        self.location_id = location_id
        
        item_desc = f"product '{product_id}'"
        if variant_id:
            item_desc = f"variant '{variant_id}' of {item_desc}"
            
        super().__init__(
            f"{threshold_type.capitalize()} threshold ({threshold_value}) exceeded for {item_desc} "
            f"at location '{location_id}'. Current value: {actual_value}"
        )


class InvalidQuantityError(InventoryError):
    """Raised when an invalid quantity is provided."""
    pass

class InvalidRequestError(EcomLibError):
    """Raised when the request is invalid."""
    pass

class ResourceNotFoundError(EcomLibError):
    """Raised when a requested resource is not found."""
    pass

class DatabaseError(EcomLibError):
    """Raised when there is a database error."""
    pass

class ConfigurationError(EcomLibError):
    """Raised when there is a configuration error."""
    pass

class NetworkError(EcomLibError):
    """Raised when there is a network-related error."""
    pass

class TimeoutError(EcomLibError):
    """Raised when an operation times out."""
    pass

class IntegrityError(EcomLibError):
    """Raised when a database integrity constraint is violated."""
    pass

class PaymentGatewayError(PaymentError):
    """Raised when there is an error with a payment gateway."""
    pass

class CardError(PaymentError):
    """Raised when there is an error with a payment card."""
    pass

class CurrencyMismatchError(PaymentError):
    """Raised when there is a currency mismatch in a payment."""
    pass

class InsufficientFundsError(PaymentError):
    """Raised when there are insufficient funds for a payment."""
    pass

class InvalidAmountError(PaymentError):
    """Raised when an invalid payment amount is provided."""
    pass

class TransactionError(PaymentError):
    """Raised when there is an error with a transaction."""
    pass

class RefundError(PaymentError):
    """Raised when there is an error processing a refund."""
    pass

class WebhookError(EcomLibError):
    """Raised when there is an error processing a webhook."""
    pass

class WebhookVerificationError(WebhookError):
    """Raised when webhook signature verification fails."""
    pass

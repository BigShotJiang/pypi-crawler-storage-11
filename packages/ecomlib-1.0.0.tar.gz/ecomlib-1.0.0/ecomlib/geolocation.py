import requests
from dataclasses import dataclass
from typing import Dict, Optional, List, Tuple
import json

@dataclass
class Location:
    """Represents a geographical location."""
    latitude: float
    longitude: float
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    postal_code: Optional[str] = None
    raw_data: Optional[Dict] = None

class GeoLocation:
    """Handles geolocation services for the e-commerce application."""
    
    def __init__(self, api_key: str = None, provider: str = "google"):
        """
        Initialize the GeoLocation service.
        
        Args:
            api_key: API key for the geolocation service
            provider: Service provider ('google' or 'openstreetmap')
        """
        self.api_key = api_key
        self.provider = provider.lower()
        self._validate_provider()
    
    def _validate_provider(self):
        """Validate that the specified provider is supported."""
        valid_providers = ["google", "openstreetmap"]
        if self.provider not in valid_providers:
            raise ValueError(f"Unsupported provider: {self.provider}. Must be one of {valid_providers}")
    
    def geocode(self, address: str) -> Optional[Location]:
        """
        Convert an address into geographic coordinates.
        
        Args:
            address: The address to geocode
            
        Returns:
            Location object with coordinates and address details, or None if not found
        """
        if self.provider == "google":
            return self._geocode_google(address)
        else:
            return self._geocode_osm(address)
    
    def reverse_geocode(self, lat: float, lng: float) -> Optional[Location]:
        """
        Convert geographic coordinates into an address.
        
        Args:
            lat: Latitude
            lng: Longitude
            
        Returns:
            Location object with address details, or None if not found
        """
        if self.provider == "google":
            return self._reverse_geocode_google(lat, lng)
        else:
            return self._reverse_geocode_osm(lat, lng)
    
    def calculate_distance(self, origin: Tuple[float, float], 
                          destination: Tuple[float, float],
                          mode: str = "driving") -> Optional[float]:
        """
        Calculate the distance between two points.
        
        Args:
            origin: Tuple of (lat, lng) for the starting point
            destination: Tuple of (lat, lng) for the destination
            mode: Travel mode ('driving', 'walking', 'bicycling' or 'transit' for Google)
            
        Returns:
            Distance in meters, or None if calculation failed
        """
        if self.provider == "google":
            return self._calculate_distance_google(origin, destination, mode)
        else:
            return self._calculate_distance_osm(origin, destination)
    
    def _geocode_google(self, address: str) -> Optional[Location]:
        """Geocode using Google Maps Geocoding API."""
        if not self.api_key:
            raise ValueError("API key is required for Google Geocoding API")
            
        params = {
            "address": address,
            "key": self.api_key
        }
        
        try:
            response = requests.get(
                "https://maps.googleapis.com/maps/api/geocode/json",
                params=params
            )
            response.raise_for_status()
            data = response.json()
            
            if data["status"] != "OK" or not data.get("results"):
                return None
                
            result = data["results"][0]
            location_data = result["geometry"]["location"]
            
            # Extract address components
            address_components = {}
            for component in result["address_components"]:
                for type_name in component["types"]:
                    address_components[type_name] = component["long_name"]
            
            return Location(
                latitude=location_data["lat"],
                longitude=location_data["lng"],
                address=result.get("formatted_address"),
                street_number=address_components.get("street_number"),
                route=address_components.get("route"),
                city=address_components.get("locality") or address_components.get("sublocality"),
                state=address_components.get("administrative_area_level_1"),
                country=address_components.get("country"),
                postal_code=address_components.get("postal_code"),
                raw_data=result
            )
            
        except (requests.RequestException, (KeyError, IndexError, json.JSONDecodeError)):
            return None
    
    def _reverse_geocode_google(self, lat: float, lng: float) -> Optional[Location]:
        """Reverse geocode using Google Maps Geocoding API."""
        if not self.api_key:
            raise ValueError("API key is required for Google Geocoding API")
            
        params = {
            "latlng": f"{lat},{lng}",
            "key": self.api_key
        }
        
        try:
            response = requests.get(
                "https://maps.googleapis.com/maps/api/geocode/json",
                params=params
            )
            response.raise_for_status()
            data = response.json()
            
            if data["status"] != "OK" or not data.get("results"):
                return None
                
            result = data["results"][0]
            
            # Extract address components
            address_components = {}
            for component in result["address_components"]:
                for type_name in component["types"]:
                    address_components[type_name] = component["long_name"]
            
            return Location(
                latitude=lat,
                longitude=lng,
                address=result.get("formatted_address"),
                street_number=address_components.get("street_number"),
                route=address_components.get("route"),
                city=address_components.get("locality") or address_components.get("sublocality"),
                state=address_components.get("administrative_area_level_1"),
                country=address_components.get("country"),
                postal_code=address_components.get("postal_code"),
                raw_data=result
            )
            
        except (requests.RequestException, (KeyError, IndexError, json.JSONDecodeError)) as e:
            print(f"Reverse geocoding error: {e}")
            return None
    
    def _calculate_distance_google(self, origin: Tuple[float, float], 
                                 destination: Tuple[float, float],
                                 mode: str = "driving") -> Optional[float]:
        """Calculate distance using Google Maps Distance Matrix API."""
        if not self.api_key:
            raise ValueError("API key is required for Google Distance Matrix API")
            
        params = {
            "origins": f"{origin[0]},{origin[1]}",
            "destinations": f"{destination[0]},{destination[1]}",
            "key": self.api_key,
            "mode": mode
        }
        
        try:
            response = requests.get(
                "https://maps.googleapis.com/maps/api/distancematrix/json",
                params=params
            )
            response.raise_for_status()
            data = response.json()
            
            if data["status"] != "OK" or not data.get("rows"):
                return None
                
            elements = data["rows"][0].get("elements", [])
            if not elements:
                return None
                
            distance = elements[0].get("distance", {}).get("value")  # in meters
            return float(distance) if distance is not None else None
            
        except (requests.RequestException, (KeyError, IndexError, json.JSONDecodeError, ValueError)):
            return None
    
    def _geocode_osm(self, address: str) -> Optional[Location]:
        """Geocode using OpenStreetMap Nominatim API."""
        headers = {
            "User-Agent": "EcomLib/1.0"  # Required by Nominatim usage policy
        }
        
        try:
            response = requests.get(
                "https://nominatim.openstreetmap.org/search",
                params={
                    "q": address,
                    "format": "json",
                    "addressdetails": 1,
                    "limit": 1
                },
                headers=headers
            )
            response.raise_for_status()
            data = response.json()
            
            if not data:
                return None
                
            result = data[0]
            address_data = result.get("address", {})
            
            return Location(
                latitude=float(result["lat"]),
                longitude=float(result["lon"]),
                address=result.get("display_name"),
                road=address_data.get("road"),
                city=address_data.get("city") or address_data.get("town") or address_data.get("village"),
                state=address_data.get("state") or address_data.get("county"),
                country=address_data.get("country"),
                postal_code=address_data.get("postcode"),
                raw_data=result
            )
            
        except (requests.RequestException, (KeyError, IndexError, json.JSONDecodeError, ValueError)) as e:
            print(f"Geocoding error: {e}")
            return None
    
    def _reverse_geocode_osm(self, lat: float, lng: float) -> Optional[Location]:
        """Reverse geocode using OpenStreetMap Nominatim API."""
        headers = {
            "User-Agent": "EcomLib/1.0"  # Required by Nominatim usage policy
        }
        
        try:
            response = requests.get(
                "https://nominatim.openstreetmap.org/reverse",
                params={
                    "lat": lat,
                    "lon": lng,
                    "format": "json",
                    "addressdetails": 1
                },
                headers=headers
            )
            response.raise_for_status()
            result = response.json()
            
            if not result:
                return None
                
            address_data = result.get("address", {})
            
            return Location(
                latitude=lat,
                longitude=lng,
                address=result.get("display_name"),
                road=address_data.get("road"),
                city=address_data.get("city") or address_data.get("town") or address_data.get("village"),
                state=address_data.get("state") or address_data.get("county"),
                country=address_data.get("country"),
                postal_code=address_data.get("postcode"),
                raw_data=result
            )
            
        except (requests.RequestException, (KeyError, IndexError, json.JSONDecodeError, ValueError)) as e:
            print(f"Reverse geocoding error: {e}")
            return None
    
    def _calculate_distance_osm(self, origin: Tuple[float, float], 
                              destination: Tuple[float, float]) -> Optional[float]:
        """Calculate distance using OpenStreetMap Routing API."""
        try:
            # Use OSRM (Open Source Routing Machine) for distance calculation
            response = requests.get(
                f"http://router.project-osrm.org/route/v1/driving/"
                f"{origin[1]},{origin[0]};{destination[1]},{destination[0]}"
            )
            response.raise_for_status()
            data = response.json()
            
            if data.get("code") != "Ok" or not data.get("routes"):
                return None
                
            # Return distance in meters
            return float(data["routes"][0]["distance"])
            
        except (requests.RequestException, (KeyError, IndexError, json.JSONDecodeError, ValueError)) as e:
            print(f"Distance calculation error: {e}")
            return None

"""
Product and inventory management module for EcomLib.

This module provides comprehensive product and inventory management functionality,
including CRUD operations, stock tracking, and advanced search capabilities.

Version: 1.0.0
Author: EcomLib Team
"""

# Standard library imports
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Set, Union, Any, Tuple, ClassVar
from datetime import datetime, timedelta
from enum import Enum, auto
from decimal import Decimal, InvalidOperation
import uuid
import logging
import re
from collections import defaultdict
import threading
from functools import wraps

# Import exceptions from the exceptions module
from .exceptions import (
    InventoryError,
    ProductNotFoundError,
    InsufficientStockError,
    InvalidQuantityError,
    DuplicateProductError,
    VariantNotFoundError
)

# Configure logging
logger = logging.getLogger(__name__)

class InvalidMovementTypeError(InventoryError):
    """Raised when an invalid stock movement type is provided."""
    pass

class InvalidVariantError(InventoryError):
    """Raised when an invalid variant is specified."""
    pass

class StockMovementType(Enum):
    PURCHASE = "purchase"
    SALE = "sale"
    RETURN = "return"
    ADJUSTMENT = "adjustment"
    DAMAGED = "damaged"
    LOST = "lost"
    FOUND = "found"
    TRANSFER_IN = "transfer_in"
    TRANSFER_OUT = "transfer_out"

    @classmethod
    def is_valid(cls, value: str) -> bool:
        """Check if a value is a valid stock movement type."""
        return value in [t.value for t in cls]

@dataclass
class StockMovement:
    """
    Represents a stock movement/transaction in the inventory system.
    
    Attributes:
        product_id: Unique identifier for the product
        variant_id: Optional identifier for product variants
        quantity: Number of items moved (positive for in, negative for out)
        movement_type: Type of stock movement (purchase, sale, etc.)
        reference_id: Reference number (e.g., order ID, PO number)
        notes: Additional information about the movement
        unit_cost: Cost per unit at the time of movement
        location_id: Identifier for inventory location
        created_at: ISO format timestamp of when the movement was recorded
        created_by: ID of the user who recorded the movement
    """
    product_id: str
    quantity: int
    variant_id: Optional[str] = None
    movement_type: Union[StockMovementType, str] = StockMovementType.ADJUSTMENT
    reference_id: Optional[str] = None
    notes: Optional[str] = None
    unit_cost: Decimal = Decimal('0.00')
    location_id: str = "default"
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    created_by: Optional[str] = None
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    
    def __post_init__(self):
        """Validate the stock movement after initialization."""
        if not self.product_id or not isinstance(self.product_id, str):
            raise ValueError("product_id is required and must be a string")
            
        if not isinstance(self.quantity, int):
            raise InvalidQuantityError("Quantity must be an integer")
            
        if self.quantity == 0:
            raise InvalidQuantityError("Quantity cannot be zero")
            
        # Convert string movement_type to enum if needed
        if isinstance(self.movement_type, str):
            try:
                self.movement_type = StockMovementType(self.movement_type.lower())
            except ValueError as e:
                raise InvalidMovementTypeError(
                    f"Invalid movement type: {self.movement_type}"
                ) from e
                
        # Validate unit_cost if provided
        if self.unit_cost is not None:
            try:
                self.unit_cost = Decimal(str(self.unit_cost)).quantize(Decimal('0.01'))
                if self.unit_cost < 0:
                    raise ValueError("Unit cost cannot be negative")
            except (ValueError, InvalidOperation) as e:
                raise ValueError("Invalid unit cost value") from e
                
        # Log the movement
        logger.info(
            "Stock movement recorded: %s - Product: %s, Variant: %s, Qty: %d, Type: %s",
            self.id, self.product_id, self.variant_id, self.quantity, self.movement_type.value
        )

class InventoryStatus(Enum):
    IN_STOCK = "in_stock"
    LOW_STOCK = "low_stock"
    OUT_OF_STOCK = "out_of_stock"
    PRE_ORDER = "pre_order"
    BACKORDER = "backorder"

@dataclass
class InventoryLevel:
    """
    Represents the current inventory level for a product/variant at a specific location.
    
    Attributes:
        product_id: Unique identifier for the product
        variant_id: Optional identifier for product variants
        available_quantity: Number of items available for sale
        reserved_quantity: Number of items reserved for orders
        reorder_point: Minimum stock level before reordering
        reorder_quantity: Quantity to reorder when stock is low
        last_updated: Timestamp of last update
        location_id: Identifier for inventory location
    """
    product_id: str
    variant_id: Optional[str] = None
    available_quantity: int = 0
    reserved_quantity: int = 0
    reorder_point: int = 0
    reorder_quantity: int = 0
    last_updated: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    location_id: str = "default"
    status: InventoryStatus = InventoryStatus.OUT_OF_STOCK
    
    def __post_init__(self):
        """Validate inventory level after initialization."""
        if not self.product_id or not isinstance(self.product_id, str):
            raise ValueError("product_id is required and must be a string")
            
        if self.available_quantity < 0:
            raise InvalidQuantityError("Available quantity cannot be negative")
            
        if self.reserved_quantity < 0:
            raise InvalidQuantityError("Reserved quantity cannot be negative")
            
        # Set default values if None
        if self.reorder_point is None:
            self.reorder_point = 0
            
        if self.reorder_quantity is None:
            self.reorder_quantity = 0
            
        # Now validate the values
        if self.reorder_point < 0:
            raise InvalidQuantityError("Reorder point cannot be negative")
            
        if self.reorder_quantity < 0:
            raise InvalidQuantityError("Reorder quantity cannot be negative")
    
    @property
    def total_quantity(self) -> int:
        """Get total quantity (available + reserved)."""
        return self.available_quantity + self.reserved_quantity
    
    def update_quantity(self, delta: int, reserved_delta: int = 0) -> None:
        """
        Update available and reserved quantities.
        
        Args:
            delta: Change in available quantity (can be positive or negative)
            reserved_delta: Change in reserved quantity (can be positive or negative)
            
        Raises:
            InsufficientStockError: If the update would result in negative available quantity
        """
        new_available = self.available_quantity + delta
        new_reserved = self.reserved_quantity + reserved_delta
        
        if new_available < 0:
            raise InsufficientStockError(
                product_id=self.product_id,
                available=self.available_quantity,
                requested=abs(delta)
            )
            
        if new_reserved < 0:
            raise ValueError("Reserved quantity cannot be negative")
            
        self.available_quantity = new_available
        self.reserved_quantity = new_reserved
        self.last_updated = datetime.utcnow().isoformat()
        
        logger.debug(
            "Updated inventory - Product: %s, Variant: %s, Available: %d, Reserved: %d",
            self.product_id, self.variant_id, self.available_quantity, self.reserved_quantity
        )
    
    @property
    def on_hand_quantity(self) -> int:
        """Get total on-hand quantity (available + reserved)."""
        return self.available_quantity + self.reserved_quantity
    
    def _update_status(self) -> None:
        """Update status based on available quantity and reorder point."""
        if self.available_quantity <= 0:
            self.status = InventoryStatus.OUT_OF_STOCK
        elif self.reorder_point and self.available_quantity <= self.reorder_point:
            self.status = InventoryStatus.LOW_STOCK
        else:
            self.status = InventoryStatus.IN_STOCK
    
    def update_status(self) -> None:
        """Public method to update status."""
        self._update_status()

@dataclass
class Variant:
    """
    Represents a product variant with specific attributes and inventory.
    
    Attributes:
        name: Display name of the variant (e.g., "Large", "Blue")
        description: Detailed description of the variant
        price: Selling price as a float (will be converted to Decimal)
        sku: Stock Keeping Unit (must be unique)
        stock_quantity: Current quantity in stock
        barcode: Optional barcode for the variant
        weight: Weight in grams
        dimensions: Dictionary of dimensions (e.g., {"length": 10, "width": 5, "height": 2})
        is_active: Whether the variant is available for sale
        attributes: Dictionary of variant-specific attributes
    """
    name: str
    description: str
    price: float
    sku: str
    stock_quantity: int = 0
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    barcode: Optional[str] = None
    weight: Optional[float] = None  # in grams
    dimensions: Dict[str, float] = field(default_factory=dict)
    is_active: bool = True
    attributes: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    
    def __post_init__(self):
        """Validate variant data after initialization."""
        if not self.name or not isinstance(self.name, str):
            raise ValueError("Variant name is required and must be a string")
            
        if not self.sku or not isinstance(self.sku, str):
            raise ValueError("SKU is required and must be a string")
            
        try:
            # Convert price to Decimal with 2 decimal places
            self.price = Decimal(str(self.price)).quantize(Decimal('0.01'))
            if self.price <= 0:
                raise ValueError("Price must be greater than zero")
        except (ValueError, InvalidOperation) as e:
            raise ValueError("Invalid price value") from e
            
        if not isinstance(self.stock_quantity, int) or self.stock_quantity < 0:
            raise InvalidQuantityError("Stock quantity must be a non-negative integer")
            
        # Validate dimensions if provided
        if self.dimensions:
            for dim in ['length', 'width', 'height']:
                if dim in self.dimensions and self.dimensions[dim] <= 0:
                    raise ValueError(f"{dim.capitalize()} must be greater than zero")

@dataclass
class Product:
    """
    Represents a product in the e-commerce system.
    
    A product can have multiple variants (e.g., size, color) and belongs to categories.
    
    Attributes:
        name: Product name (required)
        description: Detailed product description (required)
        price: Base price (can be overridden by variants)
        sku: Stock Keeping Unit (must be unique)
        category: Main category identifier
        tags: Set of tags for categorization and search
        attributes: Dictionary of product attributes
        images: List of image URLs
        variants: List of product variants
        is_active: Whether the product is available for sale
        meta_title: SEO title
        meta_description: SEO description
        slug: URL-friendly product identifier
        tax_class: Tax classification
        weight: Default weight in grams
        dimensions: Default dimensions
        requires_shipping: Whether the product requires shipping
        is_digital: Whether the product is digital
        download_limit: Max downloads for digital products
        download_expiry: Days until download expires
    """
    name: str
    description: str
    price: float
    sku: str
    category: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tags: Set[str] = field(default_factory=set)
    attributes: Dict[str, Any] = field(default_factory=dict)
    images: List[str] = field(default_factory=list)
    variants: List[Variant] = field(default_factory=list)
    is_active: bool = True
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    slug: Optional[str] = None
    tax_class: str = "standard"
    weight: Optional[float] = None  # in grams
    dimensions: Dict[str, float] = field(default_factory=dict)
    requires_shipping: bool = True
    is_digital: bool = False
    download_limit: Optional[int] = None
    download_expiry: Optional[int] = None  # in days
    
    def __post_init__(self):
        """Validate product data after initialization."""
        if not self.name or not isinstance(self.name, str):
            raise ValueError("Product name is required and must be a string")
            
        if not self.description or not isinstance(self.description, str):
            raise ValueError("Product description is required and must be a string")
            
        if not self.sku or not isinstance(self.sku, str):
            raise ValueError("SKU is required and must be a string")
            
        try:
            # Convert price to Decimal with 2 decimal places
            self.price = Decimal(str(self.price)).quantize(Decimal('0.01'))
            if self.price < 0:
                raise ValueError("Price cannot be negative")
        except (ValueError, InvalidOperation) as e:
            raise ValueError("Invalid price value") from e
            
        # Generate slug from name if not provided
        if not self.slug:
            self.slug = self._generate_slug(self.name)
            
        # Validate variants
        if self.variants:
            variant_skus = set()
            for variant in self.variants:
                if variant.sku in variant_skus:
                    raise ValueError(f"Duplicate SKU found: {variant.sku}")
                variant_skus.add(variant.sku)
    
    @staticmethod
    def _generate_slug(name: str) -> str:
        """Generate a URL-friendly slug from the product name."""
        import re
        from unicodedata import normalize
        
        # Normalize and convert to lowercase
        slug = normalize('NFKD', name).encode('ascii', 'ignore').decode('ascii')
        # Replace non-alphanumeric with dashes
        slug = re.sub(r'[^\w\s-]', '', slug).strip().lower()
        # Convert spaces to dashes and collapse multiple dashes
        slug = re.sub(r'[-\s]+', '-', slug)
        return slug
    
    @property
    def has_variants(self) -> bool:
        """Check if the product has variants."""
        return len(self.variants) > 0
    
    @property
    def min_price(self) -> Decimal:
        """Get the minimum price across all variants."""
        if not self.variants:
            return self.price
        return min(variant.price for variant in self.variants)
    
    @property
    def max_price(self) -> Decimal:
        """Get the maximum price across all variants."""
        if not self.variants:
            return self.price
        return max(variant.price for variant in self.variants)
    
    @property
    def total_stock(self) -> int:
        """Get total stock quantity across all variants."""
        if not self.variants:
            return 0
        return sum(variant.stock_quantity for variant in self.variants)
    
    def add_variant(self, variant: Variant) -> None:
        """Add a variant to the product."""
        if not isinstance(variant, Variant):
            raise ValueError("Can only add Variant instances")
            
        # Check for duplicate SKU
        if any(v.sku == variant.sku for v in self.variants):
            raise ValueError(f"Variant with SKU {variant.sku} already exists")
            
        self.variants.append(variant)
        self.updated_at = datetime.utcnow().isoformat()
        logger.info("Added variant %s to product %s", variant.sku, self.sku)

class InventoryManager:
    """
    Manages inventory operations including stock movements, levels, and reporting.
    
    This class provides thread-safe operations for managing inventory across
    multiple products, variants, and locations.
    
    Attributes:
        _inventory: Dictionary mapping (product_id, variant_id, location_id) to InventoryLevel
        _stock_history: List of all stock movements
        _lock: Thread lock for thread-safe operations
        low_stock_alerts: Set of (product_id, variant_id) tuples that are low in stock
    """
    
    def __init__(self, max_history_days: int = 90):
        """
        Initialize the InventoryManager with empty storage structures.
        
        Args:
            max_history_days: Maximum number of days to keep reconciliation history
        """
        self._inventory: Dict[Tuple[str, Optional[str], str], InventoryLevel] = {}
        self._stock_history: List[StockMovement] = []
        self._products: Dict[str, Product] = {}
        self._lock = threading.RLock()
        self.logger = logging.getLogger(__name__)
        
        # Initialize alert sets and history
        self.low_stock_alerts = set()  # (product_id, variant_id)
        self.threshold_alerts = []  # List of threshold alerts
        self._reconciliation_history: List[Dict[str, Any]] = []
        self.max_history_days = max_history_days
        
        # Initialize movement tracking
        self.stock_movements = self._stock_history  # Alias for backward compatibility
        self.movement_index: Dict[str, List[StockMovement]] = {}  # product_id -> list of movements
        
        logger.info("InventoryManager initialized")
    
    def record_movement(self, movement: StockMovement) -> StockMovement:
        """
        Record a stock movement and update inventory levels.
        
        This method is thread-safe and will validate the movement before processing.
        
        Args:
            movement: The StockMovement to record
            
        Returns:
            The recorded StockMovement with updated fields
            
        Raises:
            ValueError: If the movement is invalid
            InsufficientStockError: If the movement would result in negative stock
        """
        if not isinstance(movement, StockMovement):
            raise ValueError("Movement must be an instance of StockMovement")
            
        with self._lock:
            # Get or create inventory level
            key = (movement.product_id, movement.variant_id, movement.location_id)
            inventory = self._inventory.get(key)
            
            if not inventory:
                inventory = InventoryLevel(
                    product_id=movement.product_id,
                    variant_id=movement.variant_id,
                    location_id=movement.location_id
                )
                self._inventory[key] = inventory
            
            # Validate stock availability for outgoing movements
            if movement.quantity < 0 and abs(movement.quantity) > inventory.available_quantity:
                raise InsufficientStockError(
                    product_id=movement.product_id,
                    available=inventory.available_quantity,
                    requested=abs(movement.quantity)
                )
            
            # Apply the movement
            try:
                # Record the movement
                self.stock_movements.append(movement)
                
                # Update inventory level based on movement type
                if movement.movement_type in [
                    StockMovementType.PURCHASE, 
                    StockMovementType.RETURN, 
                    StockMovementType.FOUND, 
                    StockMovementType.TRANSFER_IN
                ]:
                    inventory.available_quantity += movement.quantity
                else:
                    inventory.available_quantity = max(0, inventory.available_quantity - abs(movement.quantity))
                
                # Update status and check for low stock
                inventory._update_status()
                if inventory.status == InventoryStatus.LOW_STOCK:
                    self.low_stock_alerts.add((movement.product_id, movement.variant_id))
                else:
                    self.low_stock_alerts.discard((movement.product_id, movement.variant_id))
                
                # Index the movement for fast lookups
                if movement.product_id not in self.movement_index:
                    self.movement_index[movement.product_id] = []
                self.movement_index[movement.product_id].append(movement)
                
                if movement.variant_id:
                    if movement.variant_id not in self.movement_index:
                        self.movement_index[movement.variant_id] = []
                    self.movement_index[movement.variant_id].append(movement)
                
                logger.info(
                    "Recorded %s movement of %d units for product %s%s",
                    movement.movement_type.value,
                    abs(movement.quantity),
                    movement.product_id,
                    f" (variant: {movement.variant_id})" if movement.variant_id else ""
                )
                
                return movement
                
            except Exception as e:
                # Rollback the movement if there's an error
                if movement in self.stock_movements:
                    self.stock_movements.remove(movement)
                if movement in self.movement_index.get(movement.product_id, []):
                    self.movement_index[movement.product_id].remove(movement)
                if movement.variant_id and movement in self.movement_index.get(movement.variant_id, []):
                    self.movement_index[movement.variant_id].remove(movement)
                    
                logger.error(
                    "Failed to record movement for product %s: %s",
                    movement.product_id,
                    str(e),
                    exc_info=True
                )
                raise
    
    def get_inventory_level(self, product_id: str, variant_id: Optional[str] = None, 
                          location_id: str = "default") -> Optional[InventoryLevel]:
        """
        Get the current inventory level for a product/variant at a specific location.
        
        Args:
            product_id: The unique identifier of the product
            variant_id: Optional identifier for product variants
            location_id: The inventory location identifier (default: "default")
            
        Returns:
            InventoryLevel object if found, None if no inventory exists
            
        Raises:
            ValueError: If product_id is not provided or invalid
        """
        if not product_id or not isinstance(product_id, str):
            raise ValueError("product_id is required and must be a string")
            
        if variant_id is not None and not isinstance(variant_id, str):
            raise ValueError("variant_id must be a string or None")
            
        if not isinstance(location_id, str):
            raise ValueError("location_id must be a string")
            
        key = (product_id, variant_id, location_id)
        return self._inventory.get(key)
    
    def get_stock_history(self, product_id: str, variant_id: Optional[str] = None,
                         start_date: Optional[Union[datetime, str]] = None,
                         end_date: Optional[Union[datetime, str]] = None,
                         movement_type: Optional[Union[StockMovementType, str]] = None,
                         limit: Optional[int] = None,
                         offset: int = 0) -> List[StockMovement]:
        """
        Retrieve stock movement history with filtering and pagination.
        
        Args:
            product_id: The unique identifier of the product
            variant_id: Optional filter for a specific variant
            start_date: Optional start date for filtering (inclusive)
            end_date: Optional end date for filtering (inclusive)
            movement_type: Optional filter for specific movement types
            limit: Maximum number of results to return
            offset: Number of results to skip (for pagination)
            
        Returns:
            List of StockMovement objects matching the criteria
            
        Raises:
            ValueError: If input validation fails
            ProductNotFoundError: If the product doesn't exist
        """
        # Input validation
        if not product_id or not isinstance(product_id, str):
            raise ValueError("product_id is required and must be a string")
            
        if variant_id is not None and not isinstance(variant_id, str):
            raise ValueError("variant_id must be a string or None")
            
        # Convert string dates to datetime objects if needed
        if isinstance(start_date, str):
            try:
                start_date = datetime.fromisoformat(start_date)
            except (ValueError, TypeError) as e:
                raise ValueError("start_date must be a valid ISO format datetime string") from e
                
        if isinstance(end_date, str):
            try:
                end_date = datetime.fromisoformat(end_date)
            except (ValueError, TypeError) as e:
                raise ValueError("end_date must be a valid ISO format datetime string") from e
        
        # Convert movement_type to enum if it's a string
        if isinstance(movement_type, str):
            try:
                movement_type = StockMovementType(movement_type.lower())
            except ValueError as e:
                raise ValueError(f"Invalid movement_type: {movement_type}") from e
        
        # Get movements from index
        movements = self.movement_index.get(product_id, []).copy()
        
        # Apply filters
        if variant_id is not None:
            movements = [m for m in movements if m.variant_id == variant_id]
            
        if movement_type is not None:
            movements = [m for m in movements if m.movement_type == movement_type]
            
        if start_date is not None:
            if not isinstance(start_date, datetime):
                raise ValueError("start_date must be a datetime object or ISO format string")
            movements = [m for m in movements if datetime.fromisoformat(m.created_at) >= start_date]
            
        if end_date is not None:
            if not isinstance(end_date, datetime):
                raise ValueError("end_date must be a datetime object or ISO format string")
            # Include the entire end date
            end_of_day = datetime.combine(end_date.date(), datetime.max.time())
            movements = [m for m in movements if datetime.fromisoformat(m.created_at) <= end_of_day]
        
        # Sort by creation date (newest first)
        movements.sort(key=lambda x: x.created_at, reverse=True)
        
        # Apply pagination
        if offset > 0:
            movements = movements[offset:]
            
        if limit is not None and limit > 0:
            movements = movements[:limit]
        
        return movements
    
    def record_movements(self, movements: List[StockMovement]) -> List[StockMovement]:
        """
        Record multiple stock movements in a single transaction.
        
        This method ensures that either all movements are recorded or none are,
        maintaining data consistency.
        
        Args:
            movements: List of StockMovement objects to record
            
        Returns:
            List of successfully recorded StockMovement objects
            
        Raises:
            ValueError: If no movements are provided
            InventoryError: If any movement fails validation
        """
        if not movements:
            raise ValueError("At least one movement must be provided")
            
        if not all(isinstance(m, StockMovement) for m in movements):
            raise ValueError("All items must be StockMovement instances")
            
        recorded_movements = []
        
        with self._lock:
            try:
                # First validate all movements
                for movement in movements:
                    # Reuse the validation from record_movement
                    key = (movement.product_id, movement.variant_id, movement.location_id)
                    inventory = self._inventory.get(key)
                    
                    if not inventory:
                        inventory = InventoryLevel(
                            product_id=movement.product_id,
                            variant_id=movement.variant_id,
                            location_id=movement.location_id
                        )
                        self._inventory[key] = inventory
                    
                    # Check stock for outgoing movements
                    if movement.quantity < 0 and abs(movement.quantity) > inventory.available_quantity:
                        raise InsufficientStockError(
                            product_id=movement.product_id,
                            available=inventory.available_quantity,
                            requested=abs(movement.quantity)
                        )
                
                # If we get here, all movements are valid - apply them
                for movement in movements:
                    key = (movement.product_id, movement.variant_id, movement.location_id)
                    inventory = self._inventory[key]
                    
                    # Record the movement
                    self.stock_movements.append(movement)
                    recorded_movements.append(movement)
                    
                    # Update inventory
                    if movement.movement_type in [
                        StockMovementType.PURCHASE, 
                        StockMovementType.RETURN, 
                        StockMovementType.FOUND, 
                        StockMovementType.TRANSFER_IN
                    ]:
                        inventory.available_quantity += movement.quantity
                    else:
                        inventory.available_quantity = max(0, inventory.available_quantity - abs(movement.quantity))
                    
                    # Update status and check for low stock
                    inventory._update_status()
                    if inventory.status == InventoryStatus.LOW_STOCK:
                        self.low_stock_alerts.add((movement.product_id, movement.variant_id))
                    
                    # Index the movement
                    if movement.product_id not in self.movement_index:
                        self.movement_index[movement.product_id] = []
                    self.movement_index[movement.product_id].append(movement)
                    
                    if movement.variant_id:
                        if movement.variant_id not in self.movement_index:
                            self.movement_index[movement.variant_id] = []
                        self.movement_index[movement.variant_id].append(movement)
                
                logger.info(
                    "Successfully recorded %d stock movements",
                    len(recorded_movements)
                )
                
                return recorded_movements
                
            except Exception as e:
                # Rollback all recorded movements
                for movement in recorded_movements:
                    if movement in self.stock_movements:
                        self.stock_movements.remove(movement)
                    
                    # Remove from indexes
                    if movement.product_id in self.movement_index:
                        if movement in self.movement_index[movement.product_id]:
                            self.movement_index[movement.product_id].remove(movement)
                    
                    if movement.variant_id and movement.variant_id in self.movement_index:
                        if movement in self.movement_index[movement.variant_id]:
                            self.movement_index[movement.variant_id].remove(movement)
                
                logger.error(
                    "Failed to record batch movements. Rolled back %d movements: %s",
                    len(recorded_movements),
                    str(e),
                    exc_info=True
                )
                raise
    
    def update_inventory_levels(
        self, 
        updates: List[Dict[str, Any]],
        movement_type: Union[StockMovementType, str] = StockMovementType.ADJUSTMENT,
        reference_id: Optional[str] = None,
        notes: Optional[str] = None,
        user_id: Optional[str] = None,
        location_id: str = "default"
    ) -> List[StockMovement]:
        """
        Update multiple inventory levels in a single transaction.
        
        Args:
            updates: List of update dictionaries with required keys:
                    - product_id: str
                    - variant_id: Optional[str]
                    - location_id: str (default: "default")
                    - quantity_delta: int (positive or negative)
            movement_type: Type of movement for all updates
            reference_id: Optional reference ID for all movements
            notes: Optional notes for all movements
            user_id: Optional user ID who made the changes
            location_id: Default location ID if not specified in updates

        Returns:
            List of created StockMovement objects
            
        Raises:
            ValueError: If any update is invalid
            InsufficientStockError: If any update would result in negative stock
        """
        if not updates:
            raise ValueError("At least one update must be provided")
            
        # Convert movement_type to enum if it's a string
        if isinstance(movement_type, str):
            try:
                movement_type = StockMovementType(movement_type.lower())
            except ValueError as e:
                raise ValueError(f"Invalid movement_type: {movement_type}") from e
        
        movements = []
        now = datetime.utcnow().isoformat()
        
        # Prepare all movements first
        for update in updates:
            if not isinstance(update, dict):
                raise ValueError("Each update must be a dictionary")
                
            required_fields = {'product_id', 'quantity_delta'}
            if not required_fields.issubset(update):
                raise ValueError(f"Update missing required fields: {required_fields - update.keys()}")
                
            movement = StockMovement(
                product_id=update['product_id'],
                variant_id=update.get('variant_id'),
                location_id=update.get('location_id', location_id),
                quantity=update['quantity_delta'],
                movement_type=movement_type,
                reference_id=reference_id,
                notes=notes,
                created_by=user_id,
                created_at=now
            )
            movements.append(movement)
        
        # Record all movements in a single transaction
        return self.record_movements(movements)
    
    def reconcile_inventory(
        self,
        product_id: str,
        variant_id: Optional[str] = None,
        location_id: str = "default",
        actual_quantity: Optional[int] = None,
        adjustment_reason: str = "inventory reconciliation",
        user_id: Optional[str] = None,
        auto_adjust: bool = False,
        threshold_percent: Optional[float] = None,
        threshold_absolute: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Reconcile inventory by comparing expected and actual quantities.
        
        Args:
            product_id: ID of the product to reconcile
            variant_id: Optional variant ID if reconciling a specific variant
            location_id: Location ID to reconcile (default: "default")
            actual_quantity: Actual physical count. If None, will use current inventory level.
            adjustment_reason: Reason for any adjustments made
            user_id: ID of the user performing the reconciliation
            auto_adjust: If True, automatically adjusts inventory to match actual_quantity
            threshold_percent: Optional percentage threshold for alerts (e.g., 10.0 for 10%)
            threshold_absolute: Optional absolute threshold for alerts
            
        Returns:
            Dict containing reconciliation results:
            {
                'product_id': str,
                'variant_id': Optional[str],
                'location_id': str,
                'expected_quantity': int,
                'actual_quantity': int,
                'discrepancy': int,
                'discrepancy_percent': float,
                'threshold_exceeded': bool,
                'adjusted': bool,
                'adjustment': Optional[StockMovement],
                'timestamp': str (ISO format)
            }
            
        Raises:
            ProductNotFoundError: If the product or variant is not found
            ValueError: If invalid parameters are provided
        """
        if not product_id:
            raise ValueError("product_id is required")
            
        with self._lock:
            try:
                # Get current inventory level
                current_level = self.get_inventory_level(
                    product_id=product_id,
                    variant_id=variant_id,
                    location_id=location_id
                )
                
                # If actual_quantity not provided, use current level (just record, no adjustment)
                if actual_quantity is None:
                    actual_quantity = current_level.quantity if current_level else 0
                
                # Calculate expected quantity and discrepancy
                expected_quantity = current_level.quantity if current_level else 0
                discrepancy = actual_quantity - expected_quantity
                
                # Calculate percentage discrepancy (avoid division by zero)
                discrepancy_percent = 0.0
                if expected_quantity != 0:
                    discrepancy_percent = (discrepancy / expected_quantity) * 100
                
                # Check if discrepancy exceeds thresholds
                threshold_exceeded = False
                if threshold_percent is not None and abs(discrepancy_percent) > threshold_percent:
                    threshold_exceeded = True
                if threshold_absolute is not None and abs(discrepancy) > threshold_absolute:
                    threshold_exceeded = True
                
                result = {
                    'product_id': product_id,
                    'variant_id': variant_id,
                    'location_id': location_id,
                    'expected_quantity': expected_quantity,
                    'actual_quantity': actual_quantity,
                    'discrepancy': discrepancy,
                    'discrepancy_percent': discrepancy_percent,
                    'threshold_exceeded': threshold_exceeded,
                    'adjusted': False,
                    'adjustment': None,
                    'timestamp': datetime.utcnow().isoformat()
                }
                
                # If there's a discrepancy and auto_adjust is True, create an adjustment
                if discrepancy != 0 and auto_adjust:
                    adjustment = StockMovement(
                        product_id=product_id,
                        variant_id=variant_id,
                        quantity=discrepancy,
                        movement_type=StockMovementType.ADJUSTMENT,
                        notes=f"Inventory reconciliation: {adjustment_reason}",
                        location_id=location_id,
                        created_by=user_id
                    )
                    
                    # Record the adjustment
                    self.record_movement(adjustment)
                    
                    result.update({
                        'adjusted': True,
                        'adjustment': adjustment
                    })
                
                # Log reconciliation result
                self.logger.info(
                    "Inventory reconciliation completed: product=%s, variant=%s, location=%s, "
                    "expected=%d, actual=%d, discrepancy=%d (%.2f%%), threshold_exceeded=%s, adjusted=%s",
                    product_id, variant_id or "<none>", location_id,
                    expected_quantity, actual_quantity, discrepancy, discrepancy_percent,
                    threshold_exceeded, result['adjusted']
                )
                
                # Trigger threshold alert if needed
                if threshold_exceeded:
                    self._trigger_threshold_alert(
                        product_id=product_id,
                        variant_id=variant_id,
                        location_id=location_id,
                        expected=expected_quantity,
                        actual=actual_quantity,
                        discrepancy=discrepancy,
                        threshold_percent=threshold_percent,
                        threshold_absolute=threshold_absolute
                    )
                
                # Add to reconciliation history
                history_entry = result.copy()
                history_entry.update({
                    'adjustment_reason': adjustment_reason,
                    'user_id': user_id,
                    'threshold_percent': threshold_percent,
                    'threshold_absolute': threshold_absolute
                })
                self._add_reconciliation_to_history(history_entry)
                
                return result
                
            except Exception as e:
                self.logger.error(
                    "Failed to reconcile inventory for product %s, variant %s: %s",
                    product_id, variant_id or "<none>", str(e),
                    exc_info=True
                )
                raise

    def reconcile_inventory_bulk(
        self,
        reconciliations: List[Dict[str, Any]],
        adjustment_reason: str = "bulk inventory reconciliation",
        user_id: Optional[str] = None,
        auto_adjust: bool = False,
        threshold_percent: Optional[float] = None,
        threshold_absolute: Optional[int] = None,
        batch_size: int = 100
    ) -> Dict[str, Any]:
        """
        Reconcile inventory for multiple products/variants in bulk.
        
        Args:
            reconciliations: List of reconciliation dictionaries, each containing:
                - product_id: str (required)
                - variant_id: Optional[str]
                - location_id: str (default: "default")
                - actual_quantity: int (required)
            adjustment_reason: Reason for any adjustments made
            user_id: ID of the user performing the reconciliation
            auto_adjust: If True, automatically adjusts inventory to match actual_quantity
            threshold_percent: Optional percentage threshold for alerts
            threshold_absolute: Optional absolute threshold for alerts
            batch_size: Number of reconciliations to process in each batch
            
        Returns:
            Dict containing bulk reconciliation results:
            {
                'total': int,
                'successful': int,
                'failed': int,
                'adjusted': int,
                'threshold_exceeded': int,
                'results': List[Dict],  # Individual reconciliation results
                'summary': Dict[str, int]  # Summary of discrepancies
            }
        """
        if not reconciliations:
            raise ValueError("At least one reconciliation must be provided")
            
        results = []
        summary = {
            'total': 0,
            'successful': 0,
            'failed': 0,
            'adjusted': 0,
            'threshold_exceeded': 0,
            'results': [],
            'summary': {
                'total_discrepancy': 0,
                'positive_discrepancies': 0,
                'negative_discrepancies': 0,
                'zero_discrepancies': 0
            }
        }
        
        # Process reconciliations in batches
        for i in range(0, len(reconciliations), batch_size):
            batch = reconciliations[i:i + batch_size]
            
            for rec in batch:
                try:
                    result = self.reconcile_inventory(
                        product_id=rec['product_id'],
                        variant_id=rec.get('variant_id'),
                        location_id=rec.get('location_id', 'default'),
                        actual_quantity=rec['actual_quantity'],
                        adjustment_reason=adjustment_reason,
                        user_id=user_id,
                        auto_adjust=auto_adjust,
                        threshold_percent=threshold_percent,
                        threshold_absolute=threshold_absolute
                    )
                    
                    # Update summary
                    summary['total'] += 1
                    summary['successful'] += 1
                    
                    if result.get('adjusted'):
                        summary['adjusted'] += 1
                    
                    if result.get('threshold_exceeded'):
                        summary['threshold_exceeded'] += 1
                    
                    # Update discrepancy summary
                    discrepancy = result.get('discrepancy', 0)
                    summary['summary']['total_discrepancy'] += abs(discrepancy)
                    
                    if discrepancy > 0:
                        summary['summary']['positive_discrepancies'] += 1
                    elif discrepancy < 0:
                        summary['summary']['negative_discrepancies'] += 1
                    else:
                        summary['summary']['zero_discrepancies'] += 1
                    
                    results.append(result)
                    
                except Exception as e:
                    summary['total'] += 1
                    summary['failed'] += 1
                    
                    # Add error to results
                    error_result = {
                        'product_id': rec.get('product_id'),
                        'variant_id': rec.get('variant_id'),
                        'location_id': rec.get('location_id', 'default'),
                        'error': str(e),
                        'success': False
                    }
                    results.append(error_result)
                    
                    self.logger.error(
                        "Failed to reconcile inventory for product %s, variant %s: %s",
                        rec.get('product_id'), rec.get('variant_id', '<none>'), str(e),
                        exc_info=True
                    )
        
        summary['results'] = results
        return summary
    
    def _add_reconciliation_to_history(self, reconciliation_result: Dict[str, Any]) -> None:
        """Add a reconciliation result to the history and clean up old entries."""
        with self._lock:
            # Add timestamp if not present
            if 'timestamp' not in reconciliation_result:
                reconciliation_result['timestamp'] = datetime.utcnow().isoformat()
                
            self._reconciliation_history.append(reconciliation_result)
            
            # Clean up old entries
            cutoff_date = datetime.utcnow() - timedelta(days=self.max_history_days)
            self._reconciliation_history = [
                r for r in self._reconciliation_history
                if datetime.fromisoformat(r['timestamp'].replace('Z', '+00:00')) > cutoff_date
            ]
    
    def get_reconciliation_history(
        self,
        product_id: Optional[str] = None,
        variant_id: Optional[str] = None,
        location_id: Optional[str] = None,
        start_date: Optional[Union[str, datetime]] = None,
        end_date: Optional[Union[str, datetime]] = None,
        limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Retrieve reconciliation history with optional filtering.
        
        Args:
            product_id: Filter by product ID
            variant_id: Filter by variant ID
            location_id: Filter by location ID
            start_date: Filter records after this date (ISO format string or datetime)
            end_date: Filter records before this date (ISO format string or datetime)
            limit: Maximum number of records to return
            
        Returns:
            List of reconciliation records matching the criteria
        """
        def parse_date(date_str: str) -> datetime:
            """Parse ISO format date string to datetime, handling timezone info."""
            try:
                return datetime.fromisoformat(date_str.replace('Z', '+00:00'))
            except ValueError:
                return datetime.fromisoformat(date_str)
        
        with self._lock:
            results = self._reconciliation_history.copy()
            
            # Apply filters
            if product_id is not None:
                results = [r for r in results if r.get('product_id') == product_id]
            if variant_id is not None:
                results = [r for r in results if r.get('variant_id') == variant_id]
            if location_id is not None:
                results = [r for r in results if r.get('location_id') == location_id]
                
            # Date filtering
            if start_date is not None:
                if isinstance(start_date, str):
                    start_date = parse_date(start_date)
                results = [r for r in results if parse_date(r['timestamp']) >= start_date]
                
            if end_date is not None:
                if isinstance(end_date, str):
                    end_date = parse_date(end_date)
                results = [r for r in results if parse_date(r['timestamp']) <= end_date]
            
            # Sort by timestamp (newest first)
            results.sort(key=lambda x: x['timestamp'], reverse=True)
            
            # Apply limit
            if limit is not None and limit > 0:
                results = results[:limit]
                
            return results
    
    def get_reconciliation_summary(
        self,
        start_date: Optional[Union[str, datetime]] = None,
        end_date: Optional[Union[str, datetime]] = None
    ) -> Dict[str, Any]:
        """
        Generate a summary of reconciliation activities.
        
        Args:
            start_date: Include reconciliations after this date
            end_date: Include reconciliations before this date
            
        Returns:
            Dictionary with reconciliation summary statistics
        """
        reconciliations = self.get_reconciliation_history(
            start_date=start_date,
            end_date=end_date
        )
        
        if not reconciliations:
            return {
                'total_reconciliations': 0,
                'total_discrepancies': 0,
                'adjusted_reconciliations': 0,
                'threshold_exceeded': 0,
                'by_product': {},
                'by_location': {},
                'time_period': {
                    'start': start_date.isoformat() if isinstance(start_date, datetime) else start_date,
                    'end': end_date.isoformat() if isinstance(end_date, datetime) else end_date
                }
            }
        
        # Calculate summary statistics
        total_discrepancies = sum(abs(r.get('discrepancy', 0)) for r in reconciliations)
        adjusted = sum(1 for r in reconciliations if r.get('adjusted', False))
        threshold_exceeded = sum(1 for r in reconciliations if r.get('threshold_exceeded', False))
        
        # Group by product and location
        by_product = {}
        by_location = {}
        
        for rec in reconciliations:
            # Update product stats
            product_id = rec.get('product_id', 'unknown')
            if product_id not in by_product:
                by_product[product_id] = {
                    'count': 0,
                    'discrepancies': 0,
                    'adjusted': 0,
                    'threshold_exceeded': 0
                }
            by_product[product_id]['count'] += 1
            by_product[product_id]['discrepancies'] += abs(rec.get('discrepancy', 0))
            if rec.get('adjusted', False):
                by_product[product_id]['adjusted'] += 1
            if rec.get('threshold_exceeded', False):
                by_product[product_id]['threshold_exceeded'] += 1
            
            # Update location stats
            location_id = rec.get('location_id', 'default')
            if location_id not in by_location:
                by_location[location_id] = {
                    'count': 0,
                    'discrepancies': 0,
                    'adjusted': 0,
                    'threshold_exceeded': 0
                }
            by_location[location_id]['count'] += 1
            by_location[location_id]['discrepancies'] += abs(rec.get('discrepancy', 0))
            if rec.get('adjusted', False):
                by_location[location_id]['adjusted'] += 1
            if rec.get('threshold_exceeded', False):
                by_location[location_id]['threshold_exceeded'] += 1
        
        # Get time period from data if not specified
        if not start_date or not end_date:
            timestamps = [r['timestamp'] for r in reconciliations]
            period_start = min(timestamps)
            period_end = max(timestamps)
        else:
            period_start = start_date.isoformat() if isinstance(start_date, datetime) else start_date
            period_end = end_date.isoformat() if isinstance(end_date, datetime) else end_date
        
        return {
            'total_reconciliations': len(reconciliations),
            'total_discrepancies': total_discrepancies,
            'adjusted_reconciliations': adjusted,
            'threshold_exceeded': threshold_exceeded,
            'by_product': by_product,
            'by_location': by_location,
            'time_period': {
                'start': period_start,
                'end': period_end
            }
        }
    
    def _trigger_threshold_alert(
        self,
        product_id: str,
        variant_id: Optional[str],
        location_id: str,
        expected: int,
        actual: int,
        discrepancy: int,
        threshold_percent: Optional[float],
        threshold_absolute: Optional[int]
    ) -> None:
        """Trigger an alert for threshold exceedance."""
        alert_details = {
            'product_id': product_id,
            'variant_id': variant_id,
            'location_id': location_id,
            'expected_quantity': expected,
            'actual_quantity': actual,
            'discrepancy': discrepancy,
            'threshold_percent': threshold_percent,
            'threshold_absolute': threshold_absolute,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        # Add to threshold alerts (could be extended to email/notification system)
        self.threshold_alerts.append(alert_details)
        
        self.logger.warning(
            "Inventory threshold alert: product=%s, variant=%s, location=%s, "
            "expected=%d, actual=%d, discrepancy=%d, threshold_percent=%s, threshold_absolute=%s",
            product_id, variant_id or "<none>", location_id,
            expected, actual, discrepancy, threshold_percent, threshold_absolute
        )
    
    def _trigger_low_stock_alert(self, product_id: str, variant_id: Optional[str] = None) -> None:
        """
        Trigger a low stock alert.
        
        Args:
            product_id: The product ID that is low in stock
            variant_id: Optional variant ID that is low in stock
        """
        self.low_stock_alerts.add((product_id, variant_id))
        logger.warning(
            "Low stock alert: product_id=%s, variant_id=%s",
            product_id,
            variant_id or "N/A"
        )
        # In a real implementation, this would trigger notifications to relevant parties

class ProductManager:
    """Manages products and inventory in the e-commerce system."""
    
    def __init__(self):
        """Initialize the product manager with an empty product catalog."""
        self.products: Dict[str, Product] = {}
        self.categories: Dict[str, Set[str]] = {}  # category -> set of product IDs
        self.tags_index: Dict[str, Set[str]] = {}  # tag -> set of product IDs
        self.inventory = InventoryManager()  # Inventory management
        self.variant_index: Dict[str, Set[str]] = {}  # variant ID -> set of product IDs
    
    def add_product(self, product: Product) -> Product:
        """Add a new product to the catalog.
        
        Args:
            product: Product to add
            
        Returns:
            The added product with generated ID
        """
        if product.id in self.products:
            raise ValueError(f"Product with ID {product.id} already exists")
            
        self.products[product.id] = product
        self._update_indexes(product)
        return product
    
    def get_product(self, product_id: str) -> Optional[Product]:
        """Get a product by its ID.
        
        Args:
            product_id: ID of the product to retrieve
            
        Returns:
            The product if found, None otherwise
        """
        return self.products.get(product_id)
    
    def update_product(self, product_id: str, **updates) -> Optional[Product]:
        """Update product information.
        
        Args:
            product_id: ID of the product to update
            **updates: Fields to update with their new values
            
        Returns:
            The updated product if found, None otherwise
        """
        if product_id not in self.products:
            return None
            
        product = self.products[product_id]
        
        # Remove old indexes
        self._remove_from_indexes(product)
        
        # Update fields
        for key, value in updates.items():
            if hasattr(product, key):
                setattr(product, key, value)
        
        # Update timestamps
        product.updated_at = datetime.utcnow().isoformat()
        
        # Update indexes with new data
        self._update_indexes(product)
        
        return product
    
    def delete_product(self, product_id: str, force: bool = False) -> bool:
        """Delete a product from the catalog.
        
        Args:
            product_id: ID of the product to delete
            force: If True, delete even if product has inventory or orders
            
        Returns:
            True if the product was deleted, False if not found or has dependencies
            
        Raises:
            ValueError: If product has inventory or orders and force=False
        """
        if product_id not in self.products:
            return False
            
        product = self.products[product_id]
        
        # Check for inventory
        inventory = self.get_inventory_status(product_id)
        if inventory and inventory.on_hand_quantity > 0 and not force:
            raise ValueError(
                f"Cannot delete product {product_id} with remaining inventory. "
                "Use force=True to delete anyway."
            )
            
        # Check for active orders (pseudo-code - would integrate with order system)
        # if self._has_active_orders(product_id) and not force:
        #     raise ValueError(
        #         f"Cannot delete product {product_id} with active orders. "
        #         "Use force=True to delete anyway."
        #     )
        
        # Archive instead of delete if force=False
        if not force:
            product.status = ProductStatus.ARCHIVED
            product.updated_at = datetime.utcnow().isoformat()
            return True
            
        # Force delete
        self._remove_from_indexes(product)
        del self.products[product_id]
        
        # Clean up inventory records
        self._cleanup_inventory_records(product_id)
        
        return True
        
    def bulk_update_products(self, updates: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Update multiple products in a single operation.
        
        Args:
            updates: List of update dictionaries with 'id' and fields to update
            
        Returns:
            Dictionary with results:
                - updated: List of successfully updated product IDs
                - errors: List of error messages for failed updates
        """
        results = {"updated": [], "errors": []}
        
        for update in updates:
            if "id" not in update:
                results["errors"].append("Missing 'id' in update")
                continue
                
            try:
                product_id = update.pop("id")
                if self.update_product(product_id, update):
                    results["updated"].append(product_id)
                else:
                    results["errors"].append(f"Product {product_id} not found")
            except Exception as e:
                results["errors"].append(f"Error updating {update.get('id')}: {str(e)}")
        
        return results
    
    def export_products(self, product_ids: List[str] = None, 
                       include_inventory: bool = True) -> List[Dict]:
        """Export products to a list of dictionaries.
        
        Args:
            product_ids: List of product IDs to export (None for all)
            include_inventory: Whether to include current inventory levels
            
        Returns:
            List of product dictionaries
        """
        products = [p for p in self.products.values() 
                   if product_ids is None or p.id in product_ids]
        
        result = []
        for product in products:
            product_data = asdict(product)
            
            if include_inventory:
                inventory = self.get_inventory_status(product.id)
                product_data["inventory"] = asdict(inventory) if inventory else None
            
            result.append(product_data)
            
        return result
    
    def import_products(self, products_data: List[Dict], 
                       update_existing: bool = False) -> Dict[str, Any]:
        """Import products from a list of dictionaries.
        
        Args:
            products_data: List of product dictionaries
            update_existing: Whether to update existing products
            
        Returns:
            Dictionary with results:
                - created: List of created product IDs
                - updated: List of updated product IDs
                - errors: List of error messages
        """
        results = {"created": [], "updated": [], "errors": []}
        
        for data in products_data:
            try:
                product_id = data.get("id")
                
                # Handle inventory separately
                inventory_data = data.pop("inventory", None)
                
                if product_id in self.products:
                    if not update_existing:
                        results["errors"].append(
                            f"Product {product_id} already exists and update_existing=False"
                        )
                        continue
                        
                    # Update existing product
                    self.update_product(product_id, data)
                    results["updated"].append(product_id)
                else:
                    # Create new product
                    product = Product(**data)
                    self.add_product(product)
                    results["created"].append(product.id)
                    product_id = product.id
                
                # Update inventory if provided
                if inventory_data and product_id:
                    self._update_inventory_from_import(product_id, inventory_data)
                    
            except Exception as e:
                results["errors"].append(
                    f"Error processing product {data.get('id', 'unknown')}: {str(e)}"
                )
        
        return results
    
    def _update_inventory_from_import(self, product_id: str, inventory_data: Dict) -> bool:
        """Update inventory from import data."""
        quantity = inventory_data.get("available_quantity", 0)
        if quantity > 0:
            return self.update_stock(
                product_id=product_id,
                variant_id=None,
                quantity=quantity,
                movement_type=StockMovementType.ADJUSTMENT,
                notes="Initial import"
            )
        return True
    
    def _cleanup_inventory_records(self, product_id: str) -> None:
        """Clean up inventory records for a deleted product."""
        keys_to_remove = [
            key for key in self._inventory.keys() 
            if key[0] == product_id
        ]
        for key in keys_to_remove:
            self._inventory.pop(key, None)
        
        # Clean up movement index
        if hasattr(self, 'movement_index'):
            self.movement_index.pop(f"{product_id}:", None)
    
    def search_products(
        self,
        query: str,
        fields: Optional[List[str]] = None,
        fuzzy: bool = True,
        operator: str = 'AND'
    ) -> List[Product]:
        """Full-text search across product fields.
        
        Args:
            query: Search query string
            fields: List of fields to search in (None for all searchable fields)
            fuzzy: Whether to use fuzzy matching
            operator: 'AND' or 'OR' for combining search terms
            
        Returns:
            List of matching products, ordered by relevance
        """
        if not query:
            return []
            
        default_fields = ['name', 'description', 'sku', 'meta_keywords']
        search_fields = fields or default_fields
        
        # Simple implementation - in a real system, use a search engine like Elasticsearch
        results = []
        for product in self.products.values():
            score = 0
            
            for field in search_fields:
                if not hasattr(product, field):
                    continue
                    
                value = str(getattr(product, field, '')).lower()
                if not value:
                    continue
                    
                # Simple term matching - replace with proper text analysis in production
                if fuzzy:
                    # Simple fuzzy matching by checking if query terms appear in any order
                    query_terms = query.lower().split()
                    matches = [term for term in query_terms if term in value]
                    if operator.upper() == 'AND' and len(matches) == len(query_terms):
                        score += len(matches)
                    elif operator.upper() == 'OR' and matches:
                        score += len(matches)
                else:
                    # Exact phrase matching
                    if query.lower() in value:
                        score += 1
                        
            if score > 0:
                results.append((product, score))
                
        # Sort by relevance score (descending)
        results.sort(key=lambda x: x[1], reverse=True)
        return [p for p, _ in results]
    
    def list_products(
        self,
        search_query: Optional[str] = None,
        categories: Optional[Union[str, List[str]]] = None,
        tags: Optional[Union[str, List[str]]] = None,
        min_price: Optional[float] = None,
        max_price: Optional[float] = None,
        in_stock: bool = False,
        status: Optional[Union[str, List[str]]] = None,
        attributes: Optional[Dict[str, Any]] = None,
        sort_by: str = 'created_at',
        sort_order: str = 'desc',
        page: int = 1,
        per_page: int = 20,
        include_inactive: bool = False,
        include_variants: bool = False,
        **filters
    ) -> Dict[str, Any]:
        """List products with advanced filtering, sorting, and pagination.
        
        Args:
            search_query: Text to search in product name and description
            categories: List of category IDs to filter by
            tags: List of tags to filter by
            min_price: Minimum price filter
            max_price: Maximum price filter
            in_stock: Only include products with stock_quantity > 0
            status: Filter by product status (can be string or list of statuses)
            sort_by: Field to sort by (name, price, created_at, updated_at, etc.)
            sort_order: Sort order (asc or desc)
            page: Page number for pagination (1-based)
            per_page: Number of items per page
            **filters: Additional filter criteria as key-value pairs
            
        Returns:
            Dictionary containing:
                - items: List of matching products
                - total: Total number of matching products
                - page: Current page number
                - per_page: Number of items per page
                - total_pages: Total number of pages
        """
        result = list(self.products.values())
        
        # Apply text search
        if search_query:
            search_query = search_query.lower()
            result = [
                p for p in result
                if (search_query in p.name.lower() or 
                    search_query in p.description.lower() or
                    search_query in ' '.join(p.tags).lower())
            ]
        
        # Filter by categories
        if categories:
            category_products = set()
            for category_id in categories:
                category_products.update(
                    pid for pid in self.category_index.get(category_id, set())
                    if pid in self.products
                )
            result = [p for p in result if p.id in category_products]
        
        # Filter by tags
        if tags:
            tag_products = set()
            for tag in tags:
                tag_products.update(
                    pid for pid in self.tags_index.get(tag.lower(), set())
                    if pid in self.products
                )
            result = [p for p in result if p.id in tag_products]
        
        # Price range filter
        if min_price is not None:
            result = [p for p in result if p.price >= Decimal(str(min_price))]
        
        if max_price is not None:
            result = [p for p in result if p.price <= Decimal(str(max_price))]
        
        # Stock status filter
        if in_stock:
            result = [p for p in result 
                     if p.stock_quantity > 0 or 
                     any(v.stock_quantity > 0 for v in p.variants)]
        
        # Status filter
        if status:
            if isinstance(status, str):
                status = [status]
            status = [s.lower() for s in status]
            result = [p for p in result if p.status.lower() in status]
        
        # Apply additional filters
        for field, value in filters.items():
            if hasattr(Product, field):
                result = [p for p in result if getattr(p, field) == value]
        
        # Sorting
        reverse_sort = sort_order.lower() == 'desc'
        try:
            result.sort(
                key=lambda p: (
                    getattr(p, sort_by, 0) if hasattr(p, sort_by) else 0,
                    p.created_at  # Secondary sort by creation date
                ),
                reverse=reverse_sort
            )
        except (TypeError, AttributeError):
            # Fallback to default sorting if the field is not sortable
            result.sort(key=lambda p: p.created_at, reverse=True)
        
        # Pagination
        total = len(result)
        total_pages = (total + per_page - 1) // per_page
        page = max(1, min(page, total_pages))  # Ensure page is within bounds
        start = (page - 1) * per_page
        end = start + per_page
        
        return {
            'items': result[start:end],
            'total': total,
            'page': page,
            'per_page': per_page,
            'total_pages': total_pages,
            'has_next': end < total,
            'has_previous': start > 0
        }
    
    def update_stock(
        self, 
        product_id: str, 
        variant_id: Optional[str], 
        quantity: int,
        movement_type: StockMovementType = StockMovementType.ADJUSTMENT,
        reference_id: Optional[str] = None,
        notes: Optional[str] = None,
        location_id: str = "default",
        user_id: Optional[str] = None
    ) -> bool:
        """Update stock level with detailed tracking.
        
        Args:
            product_id: ID of the product
            variant_id: ID of the variant (None for product-level inventory)
            quantity: Quantity to adjust (can be positive or negative)
            movement_type: Type of stock movement
            reference_id: Reference ID (order ID, PO number, etc.)
            notes: Additional notes about the movement
            location_id: Inventory location
            user_id: ID of the user making the change
            
        Returns:
            True if successful, False if product not found or invalid operation
        """
        if product_id not in self.products:
            return False
            
        product = self.products[product_id]
        
        # For variant products, verify the variant exists
        if variant_id and not any(v.id == variant_id for v in product.variants):
            return False
            
        # Record the stock movement
        movement = StockMovement(
            product_id=product_id,
            variant_id=variant_id,
            quantity=abs(quantity),
            movement_type=movement_type,
            reference_id=reference_id,
            notes=notes,
            location_id=location_id,
            created_by=user_id
        )
        
        try:
            self.inventory.record_movement(movement)
            
            # Update the product's stock quantity if this is a simple product
            if not variant_id and not product.variants:
                product.stock_quantity = self.inventory.get_inventory_level(
                    product_id, None, location_id
                ).available_quantity
            
            product.updated_at = datetime.utcnow().isoformat()
            return True
            
        except Exception as e:
            print(f"Error updating stock: {e}")
            return False
    
    def get_inventory_status(
        self, 
        product_id: str, 
        variant_id: Optional[str] = None, 
        location_id: str = "default"
    ) -> Optional[InventoryLevel]:
        """Get current inventory status for a product/variant."""
        return self.inventory.get_inventory_level(product_id, variant_id, location_id)
    
    def get_stock_history(
        self,
        product_id: str,
        variant_id: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 100
    ) -> List[StockMovement]:
        """Get stock movement history with filtering."""
        return self.inventory.get_stock_history(
            product_id, variant_id, start_date, end_date
        )[:limit]
    
    def check_low_stock_items(self, threshold: int = 5) -> List[Tuple[Product, InventoryLevel]]:
        """Get all products/variants that are below their reorder points."""
        low_stock = []
        for (product_id, variant_id, _), level in self._inventory.items():
            if level.status == InventoryStatus.LOW_STOCK or \
               (level.reorder_point and level.available_quantity <= level.reorder_point):
                product = self.products.get(product_id) if hasattr(self, 'products') else None
                if product:
                    low_stock.append((product, level))
        return low_stock
    
    def get_products_by_category(
        self, 
        category: Union[str, List[str]], 
        include_subcategories: bool = False
    ) -> List[Product]:
        """Get all products in specific categories.
        
        Args:
            category: Category ID or list of category IDs
            include_subcategories: Whether to include products from subcategories
            
        Returns:
            List of products in the specified categories
        """
        if not category:
            return []
            
        categories = [category] if isinstance(category, str) else category
        product_ids = set()
        
        for cat in categories:
            cat_products = self.categories.get(cat.lower(), set())
            product_ids.update(pid for pid in cat_products if pid in self.products)
            
            if include_subcategories:
                # Get all subcategories (implementation depends on your category structure)
                subcategories = self._get_subcategories(cat)
                for subcat in subcategories:
                    sub_products = self.categories.get(subcat.lower(), set())
                    product_ids.update(pid for pid in sub_products if pid in self.products)
        
        return [self.products[pid] for pid in product_ids]

    def get_products_by_tag(
        self, 
        tags: Union[str, List[str]], 
        operator: str = 'AND'
    ) -> List[Product]:
        """Get all products with specific tags.
        
        Args:
            tags: Tag or list of tags to filter by
            operator: 'AND' or 'OR' for combining multiple tags
            
        Returns:
            List of products matching the tag criteria
        """
        if not tags:
            return []
            
        tag_list = [tags] if isinstance(tags, str) else tags
        tag_list = [t.lower() for t in tag_list]
        
        if not tag_list:
            return []
            
        if operator.upper() == 'AND':
            # All tags must match
            product_sets = [
                set(self.tags_index.get(tag, set())) 
                for tag in tag_list
            ]
            if not product_sets:
                return []
                
            product_ids = set.intersection(*product_sets)
        else:
            # Any tag can match (OR)
            product_ids = set()
            for tag in tag_list:
                product_ids.update(self.tags_index.get(tag, set()))
        
        return [self.products[pid] for pid in product_ids if pid in self.products]
    
    def filter_products(
        self,
        filters: Dict[str, Any],
        sort_by: str = 'created_at',
        sort_order: str = 'desc',
        page: int = 1,
        per_page: int = 20
    ) -> Dict[str, Any]:
        """Advanced product filtering with pagination.
        
        Args:
            filters: Dictionary of filter criteria, e.g.:
                {
                    'name__icontains': 'shirt',
                    'price__gte': 10.0,
                    'price__lte': 100.0,
                    'category__in': ['clothing', 'accessories'],
                    'tags__all': ['sale', 'summer'],
                    'attributes.size': 'XL'
                }
            sort_by: Field to sort by (e.g., 'name', 'price', 'created_at')
            sort_order: 'asc' or 'desc'
            page: Page number (1-based)
            per_page: Number of items per page
            
        Returns:
            Dictionary containing:
                - items: List of matching products
                - total: Total number of matching products
                - page: Current page number
                - pages: Total number of pages
                - per_page: Number of items per page
        """
        # Start with all products
        products = list(self.products.values())
        
        if not filters:
            filtered = products
        else:
            filtered = []
            for product in products:
                match = True
                
                for field, value in filters.items():
                    # Handle special field lookups
                    if '__' in field:
                        field_name, lookup = field.split('__', 1)
                    else:
                        field_name, lookup = field, 'exact'
                    
                    # Handle nested attributes (e.g., attributes.size)
                    if '.' in field_name:
                        attr_parts = field_name.split('.')
                        obj = product
                        try:
                            for part in attr_parts:
                                obj = getattr(obj, part, {})
                            field_value = obj
                        except (AttributeError, TypeError):
                            field_value = None
                    else:
                        field_value = getattr(product, field_name, None)
                    
                    # Apply lookup
                    if lookup == 'exact':
                        if field_value != value:
                            match = False
                            break
                    elif lookup == 'iexact':
                        if str(field_value).lower() != str(value).lower():
                            match = False
                            break
                    elif lookup == 'contains':
                        if value not in str(field_value):
                            match = False
                            break
                    elif lookup == 'icontains':
                        if str(value).lower() not in str(field_value).lower():
                            match = False
                            break
                    elif lookup == 'in':
                        if field_value not in value:
                            match = False
                            break
                    elif lookup == 'gt':
                        if not (field_value is not None and field_value > value):
                            match = False
                            break
                    elif lookup == 'gte':
                        if not (field_value is not None and field_value >= value):
                            match = False
                            break
                    elif lookup == 'lt':
                        if not (field_value is not None and field_value < value):
                            match = False
                            break
                    elif lookup == 'lte':
                        if not (field_value is not None and field_value <= value):
                            match = False
                            break
                    elif lookup == 'startswith':
                        if not str(field_value).startswith(str(value)):
                            match = False
                            break
                    elif lookup == 'istartswith':
                        if not str(field_value).lower().startswith(str(value).lower()):
                            match = False
                            break
                    elif lookup == 'endswith':
                        if not str(field_value).endswith(str(value)):
                            match = False
                            break
                    elif lookup == 'iendswith':
                        if not str(field_value).lower().endswith(str(value).lower()):
                            match = False
                            break
                    elif lookup == 'isnull':
                        is_null = field_value is None or field_value == ''
                        if is_null != value:
                            match = False
                            break
                    elif lookup == 'all':
                        if not (isinstance(field_value, (list, set)) and 
                               all(v in field_value for v in value)):
                            match = False
                            break
                    elif lookup == 'any':
                        if not (isinstance(field_value, (list, set)) and 
                               any(v in field_value for v in value)):
                            match = False
                            break
                
                if match:
                    filtered.append(product)
        
        # Apply sorting
        reverse = sort_order.lower() == 'desc'
        try:
            filtered.sort(
                key=lambda p: (
                    getattr(p, sort_by, 0) 
                    if getattr(p, sort_by, None) is not None 
                    else ''
                ),
                reverse=reverse
            )
        except (TypeError, AttributeError):
            # Fallback to default sort if the specified field can't be used for sorting
            filtered.sort(key=lambda p: p.created_at, reverse=reverse)
        
        # Apply pagination
        total = len(filtered)
        start = (page - 1) * per_page
        end = start + per_page
        paginated = filtered[start:end]
        
        return {
            'items': paginated,
            'total': total,
            'page': page,
            'per_page': per_page,
            'total_pages': (total + per_page - 1) // per_page if per_page > 0 else 0
        }
        
    def get_inventory_status(
        self, 
        product_id: str, 
        variant_id: Optional[str] = None, 
        location_id: str = "default"
    ) -> Optional[InventoryLevel]:
        """Get current inventory status for a product/variant."""
        return self.inventory.get_inventory_level(product_id, variant_id, location_id)

    def get_stock_history(
        self,
        product_id: str,
        variant_id: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 100
    ) -> List[StockMovement]:
        """Get stock movement history with filtering."""
        return self.inventory.get_stock_history(
            product_id, variant_id, start_date, end_date
        )[:limit]

    def check_low_stock_items(self, threshold: int = 5) -> List[Tuple[Product, InventoryLevel]]:
        """Get all products/variants that are below their reorder points."""
        low_stock = []
        for (product_id, variant_id, _), level in self.inventory.inventory_levels.items():
            if level.status == InventoryStatus.LOW_STOCK or \
            (level.reorder_point and level.available_quantity <= level.reorder_point):
                product = self.products.get(product_id)
                if product:
                    low_stock.append((product, level))
        return low_stock

    def get_products_by_category(self, category: str) -> List[Product]:
        """Get all products in a specific category."""
        product_ids = self.categories.get(category.lower(), set())
        return [self.products[pid] for pid in product_ids if pid in self.products]

    def get_products_by_tag(self, tag: str) -> List[Product]:
        """Get all products with a specific tag.
        
        Args:
            tag: The tag to search for
            
        Returns:
            List of products with the specified tag
        """
        product_ids = self.tags_index.get(tag.lower(), set())
        return [self.products[pid] for pid in product_ids if pid in self.products]

    def search_products(self, query: str) -> List[Product]:
        """Search for products by name, description, or SKU.
        
        Args:
            query: The search query string
            
        Returns:
            List of matching products
        """
        query = query.lower()
        return [
            p for p in self.products.values()
            if (query in p.name.lower() or 
                query in p.description.lower() or 
                query in p.sku.lower())
        ]

    def _update_indexes(self, product: Product) -> None:
        """Update category, tag, and variant indexes for a product.
        
        Args:
            product: The product to update indexes for
        """
        # Update category index
        if hasattr(product, 'category') and product.category:
            if product.category not in self.categories:
                self.categories[product.category] = set()
            self.categories[product.category].add(product.id)
        # Handle multiple categories if using the enhanced version
        elif hasattr(product, 'categories') and product.categories:
            for category_id in product.categories:
                self.categories.setdefault(category_id, set()).add(product.id)
        
        # Update tags index
        for tag in getattr(product, 'tags', []):
            self.tags_index.setdefault(tag, set()).add(product.id)
            
        # Update variant index
        for variant in getattr(product, 'variants', []):
            self.variant_index.setdefault(variant.id, set()).add(product.id)

    def _remove_from_indexes(self, product: Product) -> None:
        """Remove a product from all indexes.
        
        Args:
            product: The product to remove from indexes
        """
        # Remove from category index
        if hasattr(product, 'category') and product.category:
            if product.category in self.categories:
                self.categories[product.category].discard(product.id)
                if not self.categories[product.category]:
                    del self.categories[product.category]
        
        # Handle multiple categories if using the enhanced version
        elif hasattr(product, 'categories') and product.categories:
            for category_id in product.categories:
                if category_id in self.categories:
                    self.categories[category_id].discard(product.id)
                    if not self.categories[category_id]:
                        del self.categories[category_id]
                    
        # Remove from tags index
        for tag in getattr(product, 'tags', []):
            if tag in self.tags_index:
                self.tags_index[tag].discard(product.id)
                if not self.tags_index[tag]:
                    del self.tags_index[tag]
                    
        # Remove from variant index
        for variant in getattr(product, 'variants', []):
            if variant.id in self.variant_index:
                self.variant_index[variant.id].discard(product.id)
                if not self.variant_index[variant.id]:
                    del self.variant_index[variant.id]

# Testing Guide for EcomLib

## Overview

This guide provides comprehensive information about testing the EcomLib e-commerce library.

## Test Structure

```
tests/
├── __init__.py
├── test_auth.py                    # Authentication tests
├── test_cart.py                    # Shopping cart tests
├── test_inventory.py               # Basic inventory tests
├── test_inventory_comprehensive.py # Comprehensive inventory tests
└── test_payment.py                 # Payment processing tests
```

## Running Tests

### Prerequisites

1. **Install the package in development mode:**
   ```bash
   pip install -e .
   ```

2. **Install test dependencies:**
   ```bash
   pip install pytest pytest-cov
   ```

3. **Install required dependencies:**
   ```bash
   pip install PyJWT requests cryptography
   ```

### Running All Tests

```bash
# Run all tests
pytest

# Run with verbose output
pytest -v

# Run with coverage report
pytest --cov=ecomlib --cov-report=html

# Run specific test file
pytest tests/test_inventory_comprehensive.py

# Run specific test class
pytest tests/test_inventory_comprehensive.py::TestInventoryManager

# Run specific test method
pytest tests/test_inventory_comprehensive.py::TestInventoryManager::test_record_movement_purchase
```

### Quick Test (No External Dependencies)

For testing the inventory module without external dependencies:

```bash
python test_inventory_only.py
```

## Test Coverage

### Inventory Module Tests

#### InventoryManager
- ✅ Initialization
- ✅ Recording stock movements (purchase, sale, return, adjustment)
- ✅ Getting inventory levels
- ✅ Insufficient stock error handling
- ✅ Low stock alerts
- ✅ Thread-safe operations

#### ProductManager
- ✅ Adding products
- ✅ Retrieving products
- ✅ Duplicate product error handling
- ✅ Product search and filtering

#### Product & Variant
- ✅ Product creation with attributes
- ✅ Adding variants to products
- ✅ Price calculations (min/max)
- ✅ Stock quantity tracking

#### InventoryLevel
- ✅ Creating inventory levels
- ✅ Status updates (in stock, low stock, out of stock)
- ✅ Quantity updates
- ✅ Reserved quantity management

#### StockMovement
- ✅ Creating stock movements
- ✅ Movement validation
- ✅ Different movement types
- ✅ Variant-specific movements

#### Integration Tests
- ✅ Complete workflow (product creation → stock addition → sales → returns)
- ✅ Multi-product inventory management
- ✅ Concurrent operations

## Fixed Issues

### 1. Missing Attributes in InventoryManager
**Issue:** `stock_movements` and `movement_index` were not initialized.

**Fix:** Added initialization in `__init__` method:
```python
self.stock_movements = self._stock_history  # Alias for backward compatibility
self.movement_index: Dict[str, List[StockMovement]] = {}
```

### 2. KeyError in movement_index
**Issue:** Trying to append to non-existent keys in `movement_index`.

**Fix:** Check and initialize before appending:
```python
if movement.product_id not in self.movement_index:
    self.movement_index[movement.product_id] = []
self.movement_index[movement.product_id].append(movement)
```

### 3. Missing _update_status Method
**Issue:** `InventoryLevel` class was missing the `_update_status()` method.

**Fix:** Added the method:
```python
def _update_status(self) -> None:
    """Update status based on available quantity and reorder point."""
    if self.available_quantity <= 0:
        self.status = InventoryStatus.OUT_OF_STOCK
    elif self.reorder_point and self.available_quantity <= self.reorder_point:
        self.status = InventoryStatus.LOW_STOCK
    else:
        self.status = InventoryStatus.IN_STOCK
```

### 4. None Comparison Error
**Issue:** Comparing `None` with integer in `reorder_point` validation.

**Fix:** Set default values before validation:
```python
if self.reorder_point is None:
    self.reorder_point = 0
if self.reorder_quantity is None:
    self.reorder_quantity = 0
```

### 5. Duplicate Field Definitions
**Issue:** `InventoryLevel` class had duplicate field definitions.

**Fix:** Removed duplicate fields and kept only the correct dataclass fields.

### 6. Missing status Field
**Issue:** `InventoryLevel` was missing the `status` field.

**Fix:** Added to dataclass:
```python
status: InventoryStatus = InventoryStatus.OUT_OF_STOCK
```

## Example Test Cases

### Test 1: Basic Inventory Operations

```python
def test_basic_inventory():
    inventory = InventoryManager()
    
    # Add stock
    movement = StockMovement(
        product_id="PROD-001",
        quantity=10,
        movement_type=StockMovementType.PURCHASE
    )
    inventory.record_movement(movement)
    
    # Check level
    level = inventory.get_inventory_level("PROD-001")
    assert level.available_quantity == 10
```

### Test 2: Insufficient Stock

```python
def test_insufficient_stock():
    inventory = InventoryManager()
    
    # Add 5 units
    purchase = StockMovement(
        product_id="PROD-002",
        quantity=5,
        movement_type=StockMovementType.PURCHASE
    )
    inventory.record_movement(purchase)
    
    # Try to sell 10 units
    sale = StockMovement(
        product_id="PROD-002",
        quantity=-10,
        movement_type=StockMovementType.SALE
    )
    
    with pytest.raises(InsufficientStockError):
        inventory.record_movement(sale)
```

### Test 3: Product with Variants

```python
def test_product_variants():
    product = Product(
        name="T-Shirt",
        description="Cotton t-shirt",
        price=19.99,
        sku="TSHIRT-001",
        category="clothing"
    )
    
    variant_s = Variant(
        name="Small",
        description="Small size",
        price=19.99,
        sku="TSHIRT-001-S"
    )
    
    variant_l = Variant(
        name="Large",
        description="Large size",
        price=21.99,
        sku="TSHIRT-001-L"
    )
    
    product.add_variant(variant_s)
    product.add_variant(variant_l)
    
    assert len(product.variants) == 2
    assert product.min_price() == 19.99
    assert product.max_price() == 21.99
```

## Continuous Integration

### GitHub Actions Example

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: [3.8, 3.9, '3.10', 3.11]
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v2
      with:
        python-version: ${{ matrix.python-version }}
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -e .
        pip install pytest pytest-cov
    
    - name: Run tests
      run: |
        pytest --cov=ecomlib --cov-report=xml
    
    - name: Upload coverage
      uses: codecov/codecov-action@v2
```

## Performance Testing

### Load Testing Example

```python
import time
from concurrent.futures import ThreadPoolExecutor

def test_concurrent_inventory_updates():
    """Test concurrent inventory updates."""
    inventory = InventoryManager()
    
    # Add initial stock
    purchase = StockMovement(
        product_id="PROD-PERF",
        quantity=1000,
        movement_type=StockMovementType.PURCHASE
    )
    inventory.record_movement(purchase)
    
    def process_sale():
        sale = StockMovement(
            product_id="PROD-PERF",
            quantity=-1,
            movement_type=StockMovementType.SALE
        )
        inventory.record_movement(sale)
    
    # Process 100 concurrent sales
    start = time.time()
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(process_sale) for _ in range(100)]
        for future in futures:
            future.result()
    
    duration = time.time() - start
    
    # Verify final quantity
    level = inventory.get_inventory_level("PROD-PERF")
    assert level.available_quantity == 900
    
    print(f"Processed 100 sales in {duration:.2f}s")
```

## Troubleshooting

### Common Test Failures

1. **ModuleNotFoundError: No module named 'jwt'**
   - Solution: `pip install PyJWT`

2. **ImportError: cannot import name 'X' from 'ecomlib'**
   - Solution: Reinstall in development mode: `pip install -e .`

3. **Test hangs or times out**
   - Check for deadlocks in thread-safe operations
   - Verify database connections are properly closed

4. **Inconsistent test results**
   - Ensure tests are isolated (use fixtures)
   - Clear any shared state between tests

## Best Practices

1. **Use Fixtures:** Create reusable test fixtures for common setups
2. **Test Isolation:** Each test should be independent
3. **Clear Naming:** Use descriptive test names
4. **Test Edge Cases:** Include boundary conditions and error cases
5. **Mock External Services:** Don't rely on external APIs in tests
6. **Measure Coverage:** Aim for >80% code coverage
7. **Performance Tests:** Include performance benchmarks for critical paths

## Next Steps

1. Run the comprehensive test suite: `pytest tests/test_inventory_comprehensive.py -v`
2. Check coverage: `pytest --cov=ecomlib --cov-report=html`
3. Review the HTML coverage report in `htmlcov/index.html`
4. Add more test cases for edge cases specific to your use case
5. Set up continuous integration for automated testing

## Resources

- [pytest Documentation](https://docs.pytest.org/)
- [pytest-cov Documentation](https://pytest-cov.readthedocs.io/)
- [Python unittest Documentation](https://docs.python.org/3/library/unittest.html)

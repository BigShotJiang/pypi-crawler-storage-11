#!/bin/bash

# Publish script for EcomLib
# This script builds and uploads the package to PyPI

set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}🚀 Starting EcomLib package publishing...${NC}"
echo ""

# Check if we're in the right directory
if [ ! -f "pyproject.toml" ]; then
    echo -e "❌ Error: Please run this script from the project root directory"
    exit 1
fi

# Check if twine is installed
if ! command -v twine &> /dev/null; then
    echo -e "❌ Error: twine is not installed. Please install it with:\n   pip install twine"
    exit 1
fi

# Check if build is installed
if ! command -v python -m build &> /dev/null; then
    echo -e "❌ Error: build is not installed. Please install it with:\n   pip install build"
    exit 1
fi

# Clean up previous builds
echo -e "🧹 Cleaning up previous builds..."
rm -rf dist/ build/ *.egg-info/

# Build the package
echo -e "🔨 Building the package..."
python -m build

# Check the built distribution
echo -e "🔍 Checking built distribution..."
twine check dist/*

# Upload to PyPI
echo -e "\n${YELLOW}🚀 Ready to upload to PyPI!${NC}"
echo -e "Please review the files in dist/ before proceeding."
read -p "Do you want to upload to PyPI? [y/N] " -n 1 -r
echo

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${GREEN}Uploading to PyPI...${NC}"
    twine upload dist/*
    echo -e "\n${GREEN}✅ Successfully published EcomLib to PyPI!${NC}"
else
    echo -e "${YELLOW}Upload cancelled. You can manually upload later with:\n   twine upload dist/*${NC}"
fi

echo -e "\n${GREEN}🎉 Done! Your package is ready to use.${NC}"
echo -e "Install it with: ${YELLOW}pip install ecomlib${NC}"

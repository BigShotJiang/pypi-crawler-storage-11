#!/bin/bash

# Run All Tests Script for EcomLib
# This script runs all available tests in sequence

echo "============================================================"
echo "EcomLib - Running All Tests"
echo "============================================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Track results
PASSED=0
FAILED=0

# Test 1: Verify Fixes
echo "Test 1: Running verification script..."
if python tests/verify_fixes.py; then
    echo -e "${GREEN}✅ Verification passed${NC}"
    ((PASSED++))
else
    echo -e "${RED}❌ Verification failed${NC}"
    ((FAILED++))
fi
echo ""

# Test 2: Simple Test
echo "Test 2: Running simple_test.py..."
if python tests/simple_test.py; then
    echo -e "${GREEN}✅ Simple test passed${NC}"
    ((PASSED++))
else
    echo -e "${RED}❌ Simple test failed${NC}"
    ((FAILED++))
fi
echo ""

# Test 3: Minimal Test
echo "Test 3: Running minimal_test.py..."
if python tests/minimal_test.py; then
    echo -e "${GREEN}✅ Minimal test passed${NC}"
    ((PASSED++))
else
    echo -e "${RED}❌ Minimal test failed${NC}"
    ((FAILED++))
fi
echo ""

# Test 4: Inventory Only Test
echo "Test 4: Running test_inventory_only.py..."
if python tests/test_inventory_only.py; then
    echo -e "${GREEN}✅ Inventory test passed${NC}"
    ((PASSED++))
else
    echo -e "${RED}❌ Inventory test failed${NC}"
    ((FAILED++))
fi
echo ""

# Test 5: Pytest (if available)
echo "Test 5: Running pytest (if available)..."
if command -v pytest &> /dev/null; then
    if pytest tests/test_inventory_comprehensive.py -v 2>/dev/null; then
        echo -e "${GREEN}✅ Pytest passed${NC}"
        ((PASSED++))
    else
        # Try without coverage options
        if pytest tests/test_inventory_comprehensive.py -v --tb=short 2>&1 | grep -q "passed"; then
            echo -e "${GREEN}✅ Pytest passed${NC}"
            ((PASSED++))
        else
            echo -e "${YELLOW}⚠️  Pytest tests not found or failed, skipping${NC}"
        fi
    fi
else
    echo -e "${YELLOW}⚠️  pytest not installed, skipping${NC}"
fi
echo ""

# Summary
echo "============================================================"
echo "Test Summary"
echo "============================================================"
echo -e "Passed: ${GREEN}${PASSED}${NC}"
echo -e "Failed: ${RED}${FAILED}${NC}"
echo "============================================================"

if [ $FAILED -eq 0 ]; then
    echo -e "${GREEN}✅ All tests passed!${NC}"
    exit 0
else
    echo -e "${RED}❌ Some tests failed${NC}"
    exit 1
fi

#!/bin/bash

# EcomLib Repository Cleanup Script
# This script removes temporary files and reorganizes the repository

echo "============================================================"
echo "EcomLib Repository Cleanup"
echo "============================================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Navigate to project root
cd "$(dirname "$0")/.."

echo "📁 Current directory: $(pwd)"
echo ""

# Confirm before proceeding
read -p "This will remove temporary files. Continue? (y/n) " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]
then
    echo "Cleanup cancelled."
    exit 1
fi

echo ""
echo "🗑️  Removing temporary debug/fix documentation..."
rm -f ALL_BUGS_FIXED.md FINAL_FIXES.md FIXES_SUMMARY.md LATEST_FIXES.md TEST_FIXES.md
echo -e "${GREEN}✅ Debug documentation removed${NC}"

echo ""
echo "🗑️  Removing temporary test files..."
rm -f simple_test.py minimal_test.py test_inventory_only.py verify_fixes.py
echo -e "${GREEN}✅ Temporary test files removed${NC}"

echo ""
echo "🗑️  Removing demo/config files..."
rm -f config.py demo.py
echo -e "${GREEN}✅ Demo files removed${NC}"

echo ""
echo "📂 Creating scripts directory..."
mkdir -p scripts
if [ -f "run_all_tests.sh" ]; then
    mv run_all_tests.sh scripts/
    echo -e "${GREEN}✅ Moved run_all_tests.sh to scripts/${NC}"
fi

echo ""
echo "📝 Updating README..."
if [ -f "README_NEW.md" ]; then
    mv README.md README_OLD.md 2>/dev/null || true
    mv README_NEW.md README.md
    echo -e "${GREEN}✅ README updated${NC}"
fi

echo ""
echo "📝 Updating .gitignore..."
if [ -f ".gitignore_new" ]; then
    mv .gitignore .gitignore_old 2>/dev/null || true
    mv .gitignore_new .gitignore
    echo -e "${GREEN}✅ .gitignore updated${NC}"
fi

echo ""
echo "🧹 Cleaning Python cache..."
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find . -type f -name "*.pyc" -delete 2>/dev/null || true
find . -type f -name "*.pyo" -delete 2>/dev/null || true
find . -type d -name "*.egg-info" -exec rm -rf {} + 2>/dev/null || true
echo -e "${GREEN}✅ Python cache cleaned${NC}"

echo ""
echo "🧹 Removing build artifacts..."
rm -rf build/ dist/ .pytest_cache/ htmlcov/
echo -e "${GREEN}✅ Build artifacts removed${NC}"

echo ""
echo "============================================================"
echo -e "${GREEN}✅ Cleanup Complete!${NC}"
echo "============================================================"
echo ""
echo "📋 Next steps:"
echo "1. Review changes: git status"
echo "2. Test the package: bash scripts/run_all_tests.sh"
echo "3. Commit changes: git add . && git commit -m 'chore: clean up repository'"
echo "4. Push to GitHub: git push origin main"
echo ""
echo "📚 Documentation:"
echo "- README.md - Main documentation"
echo "- CONTRIBUTING.md - Contribution guidelines"
echo "- QUICK_START.md - Quick start guide"
echo "- TESTING_GUIDE.md - Testing documentation"
echo ""

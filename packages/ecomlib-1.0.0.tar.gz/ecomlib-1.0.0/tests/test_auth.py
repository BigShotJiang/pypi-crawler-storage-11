""
Tests for the authentication module.
"""
import pytest
from ecomlib.auth import AuthManager

def test_user_registration():
    """Test user registration."""
    auth = AuthManager()
    user = auth.register_user("testuser", "password123", "test@example.com")
    
    assert user["username"] == "testuser"
    assert user["email"] == "test@example.com"
    assert "password_hash" not in user

def test_duplicate_username():
    """Test that duplicate usernames are not allowed."""
    auth = AuthManager()
    auth.register_user("duplicate", "password", "test1@example.com")
    
    with pytest.raises(ValueError):
        auth.register_user("duplicate", "password2", "test2@example.com")

def test_authentication():
    """Test user authentication."""
    auth = AuthManager()
    auth.register_user("authuser", "mypassword", "auth@example.com")
    
    # Test successful authentication
    user = auth.authenticate("authuser", "mypassword")
    assert user is not None
    assert user["username"] == "authuser"
    
    # Test wrong password
    assert auth.authenticate("authuser", "wrongpass") is None
    
    # Test non-existent user
    assert auth.authenticate("nonexistent", "pass") is None

def test_token_generation():
    """Test JWT token generation and verification."""
    auth = AuthManager()
    user = auth.register_user("tokenuser", "password", "token@example.com")
    
    token = auth.generate_token(user)
    assert isinstance(token, str)
    
    # Verify the token
    payload = auth.verify_token(token)
    assert payload is not None
    assert payload["sub"] == "tokenuser"
    
    # Test invalid token
    assert auth.verify_token("invalid.token.here") is None

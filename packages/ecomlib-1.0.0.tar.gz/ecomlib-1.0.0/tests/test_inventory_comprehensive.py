"""
Comprehensive test suite for the inventory module.

This test suite covers:
- Product and variant management
- Inventory level tracking
- Stock movements
- Low stock alerts
- Reconciliation
- Thread safety
"""
import pytest
from decimal import Decimal
from datetime import datetime, timedelta
from ecomlib.inventory import (
    InventoryManager, ProductManager, Product, Variant, 
    StockMovement, StockMovementType, InventoryLevel, InventoryStatus,
    InsufficientStockError, ProductNotFoundError, DuplicateProductError,
    InvalidQuantityError
)


class TestInventoryManager:
    """Test cases for InventoryManager class."""
    
    @pytest.fixture
    def inventory_manager(self):
        """Create a fresh InventoryManager instance for each test."""
        return InventoryManager()
    
    def test_initialization(self, inventory_manager):
        """Test that InventoryManager initializes correctly."""
        assert inventory_manager is not None
        assert len(inventory_manager._inventory) == 0
        assert len(inventory_manager._stock_history) == 0
        assert len(inventory_manager.low_stock_alerts) == 0
    
    def test_record_movement_purchase(self, inventory_manager):
        """Test recording a purchase movement."""
        movement = StockMovement(
            product_id="PROD-001",
            quantity=10,
            movement_type=StockMovementType.PURCHASE,
            reference_id="PO-001"
        )
        
        recorded = inventory_manager.record_movement(movement)
        
        assert recorded is not None
        assert recorded.product_id == "PROD-001"
        assert recorded.quantity == 10
        
        # Check inventory level was created
        level = inventory_manager.get_inventory_level("PROD-001")
        assert level is not None
        assert level.available_quantity == 10
    
    def test_record_movement_sale(self, inventory_manager):
        """Test recording a sale movement."""
        # First add stock
        purchase = StockMovement(
            product_id="PROD-002",
            quantity=20,
            movement_type=StockMovementType.PURCHASE
        )
        inventory_manager.record_movement(purchase)
        
        # Then record a sale
        sale = StockMovement(
            product_id="PROD-002",
            quantity=5,
            movement_type=StockMovementType.SALE
        )
        inventory_manager.record_movement(sale)
        
        level = inventory_manager.get_inventory_level("PROD-002")
        assert level.available_quantity == 15
    
    def test_insufficient_stock_error(self, inventory_manager):
        """Test that InsufficientStockError is raised when trying to sell more than available."""
        # Add 10 units
        purchase = StockMovement(
            product_id="PROD-003",
            quantity=10,
            movement_type=StockMovementType.PURCHASE
        )
        inventory_manager.record_movement(purchase)
        
        # Try to sell 15 units
        sale = StockMovement(
            product_id="PROD-003",
            quantity=-15,
            movement_type=StockMovementType.SALE
        )
        
        with pytest.raises(InsufficientStockError):
            inventory_manager.record_movement(sale)
    
    def test_get_inventory_level_nonexistent(self, inventory_manager):
        """Test getting inventory level for non-existent product."""
        level = inventory_manager.get_inventory_level("NONEXISTENT")
        assert level is None
    
    def test_low_stock_alert(self, inventory_manager):
        """Test that low stock alerts are triggered."""
        # Add stock with reorder point
        movement = StockMovement(
            product_id="PROD-004",
            quantity=5,
            movement_type=StockMovementType.PURCHASE
        )
        inventory_manager.record_movement(movement)
        
        # Set reorder point
        level = inventory_manager.get_inventory_level("PROD-004")
        level.reorder_point = 10
        level._update_status()
        
        assert level.status == InventoryStatus.LOW_STOCK


class TestProductManager:
    """Test cases for ProductManager class."""
    
    @pytest.fixture
    def product_manager(self):
        """Create a fresh ProductManager instance for each test."""
        return ProductManager()
    
    def test_add_product(self, product_manager):
        """Test adding a product."""
        product = Product(
            name="Test Product",
            description="A test product",
            price=19.99,
            sku="TEST-001",
            category="test-category"
        )
        
        added = product_manager.add_product(product)
        
        assert added is not None
        assert added.name == "Test Product"
        assert added.sku == "TEST-001"
        assert added.id is not None
    
    def test_get_product(self, product_manager):
        """Test retrieving a product by ID."""
        product = Product(
            name="Test Product",
            description="A test product",
            price=19.99,
            sku="TEST-002",
            category="test-category"
        )
        
        added = product_manager.add_product(product)
        retrieved = product_manager.get_product(added.id)
        
        assert retrieved is not None
        assert retrieved.id == added.id
        assert retrieved.name == "Test Product"
    
    def test_duplicate_product_error(self, product_manager):
        """Test that adding a product with duplicate ID raises error."""
        product1 = Product(
            name="Product 1",
            description="First product",
            price=19.99,
            sku="DUP-001",
            category="test"
        )
        
        product_manager.add_product(product1)
        
        # Try to add the same product again
        with pytest.raises(ValueError):
            product_manager.add_product(product1)


class TestProduct:
    """Test cases for Product class."""
    
    def test_product_creation(self):
        """Test creating a product."""
        product = Product(
            name="Test Product",
            description="A test product",
            price=29.99,
            sku="PROD-001",
            category="electronics"
        )
        
        assert product.name == "Test Product"
        assert product.price == 29.99
        assert product.sku == "PROD-001"
        assert product.is_active is True
        assert len(product.variants) == 0
    
    def test_product_with_variants(self):
        """Test product with variants."""
        product = Product(
            name="T-Shirt",
            description="A comfortable t-shirt",
            price=19.99,
            sku="TSHIRT-001",
            category="clothing"
        )
        
        variant_small = Variant(
            name="Small",
            description="Small size",
            price=19.99,
            sku="TSHIRT-001-S"
        )
        
        variant_large = Variant(
            name="Large",
            description="Large size",
            price=21.99,
            sku="TSHIRT-001-L"
        )
        
        product.add_variant(variant_small)
        product.add_variant(variant_large)
        
        assert len(product.variants) == 2
        assert product.has_variants() is True
        assert product.min_price() == 19.99
        assert product.max_price() == 21.99


class TestInventoryLevel:
    """Test cases for InventoryLevel class."""
    
    def test_inventory_level_creation(self):
        """Test creating an inventory level."""
        level = InventoryLevel(
            product_id="PROD-001",
            available_quantity=10,
            reserved_quantity=2
        )
        
        assert level.product_id == "PROD-001"
        assert level.available_quantity == 10
        assert level.reserved_quantity == 2
        assert level.total_quantity == 12
    
    def test_inventory_level_status_out_of_stock(self):
        """Test inventory status when out of stock."""
        level = InventoryLevel(
            product_id="PROD-002",
            available_quantity=0
        )
        
        level._update_status()
        assert level.status == InventoryStatus.OUT_OF_STOCK
    
    def test_inventory_level_status_low_stock(self):
        """Test inventory status when low in stock."""
        level = InventoryLevel(
            product_id="PROD-003",
            available_quantity=5,
            reorder_point=10
        )
        
        level._update_status()
        assert level.status == InventoryStatus.LOW_STOCK
    
    def test_inventory_level_status_in_stock(self):
        """Test inventory status when in stock."""
        level = InventoryLevel(
            product_id="PROD-004",
            available_quantity=50,
            reorder_point=10
        )
        
        level._update_status()
        assert level.status == InventoryStatus.IN_STOCK
    
    def test_update_quantity(self):
        """Test updating inventory quantity."""
        level = InventoryLevel(
            product_id="PROD-005",
            available_quantity=10
        )
        
        level.update_quantity(5)
        assert level.available_quantity == 15
        
        level.update_quantity(-3)
        assert level.available_quantity == 12
    
    def test_update_quantity_insufficient_stock(self):
        """Test that updating quantity raises error when insufficient stock."""
        level = InventoryLevel(
            product_id="PROD-006",
            available_quantity=5
        )
        
        with pytest.raises(InsufficientStockError):
            level.update_quantity(-10)


class TestStockMovement:
    """Test cases for StockMovement class."""
    
    def test_stock_movement_creation(self):
        """Test creating a stock movement."""
        movement = StockMovement(
            product_id="PROD-001",
            quantity=10,
            movement_type=StockMovementType.PURCHASE,
            reference_id="PO-001"
        )
        
        assert movement.product_id == "PROD-001"
        assert movement.quantity == 10
        assert movement.movement_type == StockMovementType.PURCHASE
        assert movement.reference_id == "PO-001"
        assert movement.id is not None
    
    def test_stock_movement_with_variant(self):
        """Test creating a stock movement with variant."""
        movement = StockMovement(
            product_id="PROD-002",
            quantity=5,
            variant_id="VAR-001",
            movement_type=StockMovementType.SALE
        )
        
        assert movement.variant_id == "VAR-001"
    
    def test_stock_movement_validation(self):
        """Test stock movement validation."""
        with pytest.raises(ValueError):
            StockMovement(
                product_id="",  # Empty product_id should fail
                quantity=10
            )


class TestIntegration:
    """Integration tests for the inventory system."""
    
    @pytest.fixture
    def setup_system(self):
        """Set up a complete system with products and inventory."""
        product_manager = ProductManager()
        inventory_manager = InventoryManager()
        
        # Create a product
        product = Product(
            name="Laptop",
            description="A powerful laptop",
            price=999.99,
            sku="LAPTOP-001",
            category="electronics"
        )
        
        product = product_manager.add_product(product)
        
        return product_manager, inventory_manager, product
    
    def test_complete_workflow(self, setup_system):
        """Test a complete workflow from product creation to sale."""
        product_manager, inventory_manager, product = setup_system
        
        # Add stock
        purchase = StockMovement(
            product_id=product.id,
            quantity=50,
            movement_type=StockMovementType.PURCHASE,
            reference_id="PO-001"
        )
        inventory_manager.record_movement(purchase)
        
        # Check inventory
        level = inventory_manager.get_inventory_level(product.id)
        assert level.available_quantity == 50
        
        # Make a sale
        sale = StockMovement(
            product_id=product.id,
            quantity=-10,
            movement_type=StockMovementType.SALE,
            reference_id="ORDER-001"
        )
        inventory_manager.record_movement(sale)
        
        # Check updated inventory
        level = inventory_manager.get_inventory_level(product.id)
        assert level.available_quantity == 40
        
        # Process a return
        return_movement = StockMovement(
            product_id=product.id,
            quantity=2,
            movement_type=StockMovementType.RETURN,
            reference_id="RETURN-001"
        )
        inventory_manager.record_movement(return_movement)
        
        # Check final inventory
        level = inventory_manager.get_inventory_level(product.id)
        assert level.available_quantity == 42


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

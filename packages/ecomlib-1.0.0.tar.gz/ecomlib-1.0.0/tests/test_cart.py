""
Tests for the shopping cart module.
"""
import pytest
from decimal import Decimal
from ecomlib.cart import ShoppingCart, CartItem

def test_add_item():
    """Test adding items to the cart."""
    cart = ShoppingCart()
    item = cart.add_item("prod1", 2, Decimal("10.00"))
    
    assert item.quantity == 2
    assert item.price == Decimal("10.00")
    assert len(cart.items) == 1
    assert cart.get_item_count() == 2

def test_remove_item():
    """Test removing items from the cart."""
    cart = ShoppingCart()
    cart.add_item("prod1", 1, Decimal("10.00"))
    
    removed = cart.remove_item("prod1")
    assert removed is not None
    assert len(cart.items) == 0
    assert cart.get_item_count() == 0

def test_update_quantity():
    """Test updating item quantities."""
    cart = ShoppingCart()
    cart.add_item("prod1", 1, Decimal("10.00"))
    
    updated = cart.update_item_quantity("prod1", 5)
    assert updated.quantity == 5
    assert cart.get_item_count() == 5

def test_cart_total():
    """Test cart total calculation."""
    cart = ShoppingCart()
    cart.add_item("prod1", 2, Decimal("10.00"))  # 20.00
    cart.add_item("prod2", 1, Decimal("15.50"))  # 15.50
    
    assert cart.get_subtotal() == Decimal("35.50")
    
    # Test discount
    cart.apply_coupon("TEST10", Decimal("5.00"))
    assert cart.get_total() == Decimal("30.50")

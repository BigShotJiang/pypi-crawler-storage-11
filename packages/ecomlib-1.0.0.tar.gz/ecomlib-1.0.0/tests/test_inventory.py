# tests/test_inventory.py
import pytest
from decimal import Decimal
from datetime import datetime, timedelta
from ecomlib.inventory import (
    InventoryManager, Product, Variant, 
    StockMovement, StockMovementType,
    InsufficientStockError, ProductNotFoundError
)

@pytest.fixture
def inventory():
    return InventoryManager()

def test_add_product(inventory):
    product = inventory.add_product(
        name="Test Product",
        description="Test Description",
        price=Decimal("19.99"),
        sku="TEST-001"
    )
    assert product.id is not None
    assert product.name == "Test Product"
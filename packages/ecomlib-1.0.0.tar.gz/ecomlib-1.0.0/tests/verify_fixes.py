#!/usr/bin/env python
"""
Quick verification script to test all fixes.
"""
import sys

print("=" * 60)
print("Verifying EcomLib Fixes")
print("=" * 60)

# Test 1: Import exceptions module
print("\n1. Testing exceptions module import...")
try:
    from ecomlib.exceptions import (
        InsufficientStockError, ProductNotFoundError, 
        InventoryError, Optional, Dict, Union
    )
    print("   ✅ Exceptions module imports correctly")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    sys.exit(1)

# Test 2: Import inventory module
print("\n2. Testing inventory module import...")
try:
    from ecomlib.inventory import (
        Product, ProductManager, InventoryManager,
        StockMovement, StockMovementType, InventoryLevel
    )
    print("   ✅ Inventory module imports correctly")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    sys.exit(1)

# Test 3: Create InventoryManager
print("\n3. Testing InventoryManager initialization...")
try:
    inventory = InventoryManager()
    assert hasattr(inventory, 'stock_movements'), "Missing stock_movements"
    assert hasattr(inventory, 'movement_index'), "Missing movement_index"
    assert hasattr(inventory, '_inventory'), "Missing _inventory"
    print("   ✅ InventoryManager initialized with all attributes")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    sys.exit(1)

# Test 4: Create and record stock movement
print("\n4. Testing stock movement recording...")
try:
    movement = StockMovement(
        product_id="TEST-001",
        quantity=10,
        movement_type=StockMovementType.PURCHASE
    )
    recorded = inventory.record_movement(movement)
    assert recorded is not None, "Movement not recorded"
    print("   ✅ Stock movement recorded successfully")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    sys.exit(1)

# Test 5: Get inventory level
print("\n5. Testing get_inventory_level method...")
try:
    level = inventory.get_inventory_level("TEST-001")
    if level is None:
        print(f"   ❌ Inventory level is None - check location_id")
        print(f"      Available inventory keys: {list(inventory._inventory.keys())}")
        sys.exit(1)
    assert level.available_quantity == 10, f"Expected 10, got {level.available_quantity}"
    assert hasattr(level, 'status'), "Missing status attribute"
    print(f"   ✅ Inventory level retrieved: {level.available_quantity} units")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 6: Test InventoryLevel status update
print("\n6. Testing InventoryLevel status update...")
try:
    level._update_status()
    print(f"   ✅ Status updated: {level.status.value}")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    sys.exit(1)

# Test 7: Create ProductManager and add product
print("\n7. Testing ProductManager...")
try:
    product_manager = ProductManager()
    product = Product(
        name="Test Product",
        description="A test product",
        price=19.99,
        sku="PROD-001",
        category="test"
    )
    added = product_manager.add_product(product)
    assert added is not None, "Product not added"
    print(f"   ✅ Product added: {added.name}")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    sys.exit(1)

# Test 8: Test insufficient stock error
print("\n8. Testing InsufficientStockError...")
# Try to sell more than available
sale = StockMovement(
    product_id="TEST-001",
    quantity=-20,  # More than the 10 we have
    movement_type=StockMovementType.SALE
)
error_raised = False
try:
    inventory.record_movement(sale)
except InsufficientStockError as e:
    error_raised = True
    print(f"   ✅ InsufficientStockError raised correctly")

if not error_raised:
    print("   ❌ Should have raised InsufficientStockError")
    sys.exit(1)

# Test 9: Test movement_index
print("\n9. Testing movement_index...")
try:
    assert "TEST-001" in inventory.movement_index, "Product not in movement_index"
    movements = inventory.movement_index["TEST-001"]
    assert len(movements) > 0, "No movements recorded"
    print(f"   ✅ Movement index working: {len(movements)} movements tracked")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    sys.exit(1)

# Test 10: Test sale movement
print("\n10. Testing sale movement...")
try:
    sale = StockMovement(
        product_id="TEST-001",
        quantity=-3,
        movement_type=StockMovementType.SALE
    )
    inventory.record_movement(sale)
    level = inventory.get_inventory_level("TEST-001")
    assert level.available_quantity == 7, f"Expected 7, got {level.available_quantity}"
    print(f"   ✅ Sale processed: {level.available_quantity} units remaining")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    sys.exit(1)

print("\n" + "=" * 60)
print("✅ All verifications passed!")
print("=" * 60)
print("\nYou can now run:")
print("  - python simple_test.py")
print("  - python minimal_test.py")
print("  - pytest tests/test_inventory_comprehensive.py")
print("=" * 60)

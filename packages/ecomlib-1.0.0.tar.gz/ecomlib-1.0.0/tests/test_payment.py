""
Tests for the payment module.
"""
import pytest
from unittest.mock import Mock, patch
from ecomlib.payment import StripeGateway, PayPalGateway, PaymentResult

def test_stripe_payment_success():
    """Test successful Stripe payment."""
    with patch('requests.post') as mock_post:
        # Mock successful Stripe response
        mock_response = Mock()
        mock_response.json.return_value = {
            "id": "ch_123",
            "amount": 1000,
            "currency": "usd",
            "status": "succeeded"
        }
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response
        
        # Initialize gateway and process payment
        stripe = StripeGateway(api_key="test_key")
        result = stripe.process_payment(10.00, "usd", "tok_visa")
        
        assert result.success is True
        assert result.transaction_id == "ch_123"
        assert result.amount == 10.00

def test_paypal_payment_failure():
    """Test PayPal payment failure."""
    with patch('requests.post') as mock_post:
        # Mock failed PayPal response
        mock_response = Mock()
        mock_response.json.return_value = {
            "name": "PAYMENT_ERROR",
            "message": "Payment failed",
            "details": [{"issue": "INVALID_REQUEST"}]
        }
        mock_response.raise_for_status.side_effect = Exception("API Error")
        mock_post.return_value = mock_response
        
        # Initialize gateway and process payment
        paypal = PayPalGateway("client_id", "client_secret")
        result = paypal.process_payment(50.00, "USD")
        
        assert result.success is False
        assert "Payment failed" in result.message

def test_payment_result_initialization():
    """Test PaymentResult dataclass initialization."""
    result = PaymentResult(
        success=True,
        transaction_id="txn_123",
        amount=25.50,
        currency="USD",
        message="Payment processed"
    )
    
    assert result.success is True
    assert result.transaction_id == "txn_123"
    assert result.amount == 25.50
    assert result.currency == "USD"
    assert result.message == "Payment processed"

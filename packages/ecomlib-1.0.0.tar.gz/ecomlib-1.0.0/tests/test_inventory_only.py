"""
Test script for inventory module only (no external dependencies required).
"""
import sys
from decimal import Decimal

# Test importing inventory module directly
try:
    from ecomlib.inventory import (
        Product, ProductManager, InventoryManager, 
        StockMovement, StockMovementType, InventoryLevel
    )
    print("✅ Successfully imported inventory module")
except ImportError as e:
    print(f"❌ Failed to import inventory module: {e}")
    sys.exit(1)

def test_inventory_manager():
    """Test InventoryManager functionality."""
    print("\n=== Testing InventoryManager ===")
    
    try:
        # Initialize manager
        inventory = InventoryManager()
        print("✅ InventoryManager initialized")
        
        # Create a stock movement
        movement = StockMovement(
            product_id="PROD-001",
            quantity=10,
            movement_type=StockMovementType.PURCHASE,
            reference_id="PO-001"
        )
        print("✅ Created StockMovement")
        
        # Record the movement
        recorded = inventory.record_movement(movement)
        print(f"✅ Recorded movement: {recorded.quantity} units")
        
        # Get inventory level
        level = inventory.get_inventory_level("PROD-001")
        print(f"✅ Current stock level: {level.available_quantity} units")
        
        # Verify the quantity
        assert level.available_quantity == 10, f"Expected 10, got {level.available_quantity}"
        print("✅ Stock level verified")
        
        # Test sale movement
        sale = StockMovement(
            product_id="PROD-001",
            quantity=-3,
            movement_type=StockMovementType.SALE,
            reference_id="ORDER-001"
        )
        inventory.record_movement(sale)
        
        level = inventory.get_inventory_level("PROD-001")
        assert level.available_quantity == 7, f"Expected 7, got {level.available_quantity}"
        print(f"✅ After sale: {level.available_quantity} units remaining")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_product_manager():
    """Test ProductManager functionality."""
    print("\n=== Testing ProductManager ===")
    
    try:
        # Initialize manager
        product_manager = ProductManager()
        print("✅ ProductManager initialized")
        
        # Create a product
        product = Product(
            name="Test Laptop",
            description="A powerful laptop for testing",
            price=999.99,
            sku="LAPTOP-001",
            category="electronics"
        )
        print("✅ Created Product")
        
        # Add product
        added = product_manager.add_product(product)
        print(f"✅ Added product: {added.name} (ID: {added.id[:8]}...)")
        
        # Retrieve product
        retrieved = product_manager.get_product(added.id)
        assert retrieved is not None, "Product not found"
        assert retrieved.name == "Test Laptop", f"Expected 'Test Laptop', got '{retrieved.name}'"
        print(f"✅ Retrieved product: {retrieved.name}")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_inventory_level():
    """Test InventoryLevel functionality."""
    print("\n=== Testing InventoryLevel ===")
    
    try:
        # Create inventory level
        level = InventoryLevel(
            product_id="PROD-002",
            available_quantity=50,
            reserved_quantity=10,
            reorder_point=20
        )
        print("✅ Created InventoryLevel")
        
        # Test properties
        assert level.total_quantity == 60, f"Expected 60, got {level.total_quantity}"
        print(f"✅ Total quantity: {level.total_quantity}")
        
        # Test status update
        level._update_status()
        print(f"✅ Status: {level.status.value}")
        
        # Test update quantity
        level.update_quantity(10)
        assert level.available_quantity == 60, f"Expected 60, got {level.available_quantity}"
        print(f"✅ After update: {level.available_quantity} units")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_integration():
    """Test integration between ProductManager and InventoryManager."""
    print("\n=== Testing Integration ===")
    
    try:
        product_manager = ProductManager()
        inventory_manager = InventoryManager()
        
        # Create and add product
        product = Product(
            name="Gaming Mouse",
            description="High-precision gaming mouse",
            price=79.99,
            sku="MOUSE-001",
            category="accessories"
        )
        product = product_manager.add_product(product)
        print(f"✅ Created product: {product.name}")
        
        # Add stock
        purchase = StockMovement(
            product_id=product.id,
            quantity=100,
            movement_type=StockMovementType.PURCHASE,
            reference_id="PO-100"
        )
        inventory_manager.record_movement(purchase)
        print("✅ Added 100 units to inventory")
        
        # Process sales
        for i in range(5):
            sale = StockMovement(
                product_id=product.id,
                quantity=-2,
                movement_type=StockMovementType.SALE,
                reference_id=f"ORDER-{i+1}"
            )
            inventory_manager.record_movement(sale)
        
        print("✅ Processed 5 sales (10 units total)")
        
        # Check final inventory
        level = inventory_manager.get_inventory_level(product.id)
        assert level.available_quantity == 90, f"Expected 90, got {level.available_quantity}"
        print(f"✅ Final inventory: {level.available_quantity} units")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests."""
    print("=" * 60)
    print("Starting Inventory Module Tests")
    print("=" * 60)
    
    results = []
    
    # Run tests
    results.append(("InventoryManager", test_inventory_manager()))
    results.append(("ProductManager", test_product_manager()))
    results.append(("InventoryLevel", test_inventory_level()))
    results.append(("Integration", test_integration()))
    
    # Print summary
    print("\n" + "=" * 60)
    print("Test Summary")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{name:20s} {status}")
    
    print("=" * 60)
    print(f"Total: {passed}/{total} tests passed")
    print("=" * 60)
    
    return 0 if passed == total else 1

if __name__ == "__main__":
    sys.exit(main())

"""
Simple Test Script for E-commerce Library

This script tests the core functionality of the e-commerce library
without requiring external dependencies.
"""
from decimal import Decimal
from ecomlib.inventory import Product, ProductManager, InventoryManager

def test_inventory():
    print("\n=== Testing Inventory Management ===")
    product_manager = ProductManager()
    inventory = InventoryManager()
    
    # Create and add a product
    product = Product(
        name="Test Product",
        description="A test product",
        price=19.99,
        sku="TEST-001",
        category="test-category"
    )
    
    product = product_manager.add_product(product)
    print(f"✅ Added product: {product.name} (ID: {product.id[:8]}...)")
    
    # Add stock using InventoryManager
    from ecomlib.inventory import StockMovement, StockMovementType
    
    movement = StockMovement(
        product_id=product.id,
        quantity=10,
        movement_type=StockMovementType.PURCHASE,
        reference_id="PURCHASE-001"
        # Using default location_id
    )
    
    movement = inventory.record_movement(movement)
    print(f"✅ Added stock: {movement.quantity} units")
    
    # Check stock level
    level = inventory.get_inventory_level(product.id)
    if level:
        print(f"✅ Current stock level: {level.available_quantity} units")
    else:
        print("❌ Could not retrieve inventory level")
        return None, None
    
    return inventory, product

def test_cart(inventory, product):
    print("\n=== Testing Shopping Cart ===")
    from ecomlib.cart import ShoppingCart
    
    cart = ShoppingCart()
    
    # Add item to cart
    cart.add_item(
        product_id=product.id,
        quantity=2,
        price=Decimal("19.99"),
        attributes={'name': product.name, 'sku': product.sku}
    )
    print(f"✅ Added 2 items to cart")
    print(f"✅ Cart subtotal: ${cart.get_subtotal()}")
    
    return cart

def test_order(inventory, product, cart):
    print("\n=== Testing Order Management ===")
    from ecomlib.order import OrderManager
    
    orders = OrderManager()
    
    # Create an order
    order = orders.create_order(
        customer_id="test-customer-123",
        items=[{
            "product_id": product.id,
            "quantity": 2,
            "unit_price": Decimal("19.99"),
            "name": product.name,
            "sku": product.sku
        }],
        shipping_address={
            "line1": "123 Test St",
            "city": "Testville",
            "country": "US"
        },
        billing_address={
            "line1": "123 Test St",
            "city": "Testville",
            "country": "US"
        }
    )
    
    print(f"✅ Created order #{order.id}")
    print(f"✅ Order total: ${order.total}")
    print(f"✅ Order status: {order.status.value}")
    
    # Update order status
    from ecomlib.order import OrderStatus
    order.update_status(OrderStatus.PROCESSING)
    print(f"✅ Updated order status to: {order.status.value}")

def main():
    print("Starting E-commerce Library Tests...")
    
    try:
        # Run tests
        inventory, product = test_inventory()
        cart = test_cart(inventory, product)
        test_order(inventory, product, cart)
        
        print("\n✅ All tests completed successfully!")
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()

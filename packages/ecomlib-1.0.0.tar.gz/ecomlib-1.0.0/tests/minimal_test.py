"""
Minimal Test Script for Core E-commerce Functionality

This script tests the core functionality using only standard library modules.
"""
from decimal import Decimal

def test_inventory():
    print("\n=== Testing Core Inventory ===")
    
    # Import here to avoid circular imports
    from ecomlib.inventory import InventoryManager, ProductManager, Product, StockMovement, StockMovementType
    from ecomlib.exceptions import InsufficientStockError
    
    inv = InventoryManager()
    prod_mgr = ProductManager()
    
    try:
        # Add a product
        product = Product(
            name="Test Product",
            description="A test product",
            price=10.00,
            sku="TEST-001",
            category="test"
        )
        product = prod_mgr.add_product(product)
        print(f"✅ Added product: {product.name}")
        
        # Add stock
        movement = StockMovement(
            product_id=product.id,
            quantity=5,
            movement_type=StockMovementType.PURCHASE
        )
        movement = inv.record_movement(movement)
        print(f"✅ Added stock: {movement.quantity} units")
        
        # Check stock level
        level = inv.get_inventory_level(product.id)
        print(f"✅ Current stock level: {level.available_quantity} units")
        
        # Try to remove more than available (should raise exception)
        try:
            sale = StockMovement(
                product_id=product.id,
                quantity=-10,  # More than available (negative for sale)
                movement_type=StockMovementType.SALE
            )
            inv.record_movement(sale)
            print("❌ Should have raised InsufficientStockError")
        except InsufficientStockError:
            print("✅ Correctly prevented overselling")
        
        return inv, product
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        raise

def test_cart():
    print("\n=== Testing Shopping Cart ===")
    
    from ecomlib.cart import ShoppingCart, CartItem
    
    try:
        cart = ShoppingCart()
        
        # Add item to cart
        item = cart.add_item(
            product_id="prod_123",
            quantity=2,
            price=Decimal("9.99"),
            attributes={"name": "Test Item", "sku": "TEST-ITEM-001"}
        )
        print(f"✅ Added item to cart: {item.quantity} items")
        print(f"✅ Cart total: ${cart.get_subtotal()}")
        
        # Update quantity
        cart.update_item_quantity("prod_123", 3)
        print(f"✅ Updated quantity to 3")
        print(f"✅ New cart total: ${cart.get_subtotal()}")
        
        # Remove item
        removed = cart.remove_item("prod_123")
        print(f"✅ Removed item from cart")
        print(f"✅ Cart is now empty: {len(cart.items) == 0}")
        
        return cart
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        raise

def main():
    print("Starting Minimal E-commerce Tests...")
    
    try:
        # Run tests
        inventory, product = test_inventory()
        cart = test_cart()
        
        print("\n✅ All core tests completed successfully!")
        print("\nTo run the full test suite, please install the required dependencies:")
        print("pip install -r requirements.txt")
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())

"""Package version."""

from importlib.metadata import version

__version__ = version("stitchee")

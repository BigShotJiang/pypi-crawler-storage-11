"""Basic import tests to ensure all modules are importable"""

import sys
import os

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))


def test_import_markdown_viewer():
    """Test that markdown_viewer module can be imported"""
    try:
        import markdown_viewer
        assert hasattr(markdown_viewer, 'main')
    except ImportError as e:
        raise AssertionError(f"Failed to import markdown_viewer: {e}")


def test_import_config():
    """Test that config module can be imported"""
    try:
        import config
        assert hasattr(config, 'SUPPORTED_MARKDOWN_EXTENSIONS')
    except ImportError as e:
        raise AssertionError(f"Failed to import config: {e}")


def test_import_ui_modules():
    """Test that UI modules can be imported"""
    try:
        from ui.main_window import MarkdownViewer
        from ui.file_tree import FileTreeManager
    except ImportError as e:
        raise AssertionError(f"Failed to import UI modules: {e}")


def test_import_htmlenhancer():
    """Test that HTML enhancer module can be imported"""
    try:
        from htmlenhancer.enhancer import HTMLEnhancer
    except ImportError as e:
        raise AssertionError(f"Failed to import HTMLEnhancer: {e}")


def test_import_image_modules():
    """Test that image modules can be imported"""
    try:
        from image.cache import ImageCache
        from image.dimensions import get_image_dimensions
    except ImportError as e:
        raise AssertionError(f"Failed to import image modules: {e}")


def test_dependencies_installed():
    """Test that required dependencies are installed"""
    required_packages = ['PyQt5', 'mistune', 'PIL']

    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            raise AssertionError(f"Required package '{package}' is not installed")

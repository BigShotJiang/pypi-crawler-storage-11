from openai import OpenAI
import base64
import mimetypes

def image_to_data_url(path: str) -> str:
    mime = mimetypes.guess_type(path)[0] or "image/png"
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")
    return f"data:{mime};base64,{b64}"

def resume_diapo(image, key_api):
    img_url = image_to_data_url(image)
    client = OpenAI(api_key = key_api)

    response = client.responses.create(
        model="gpt-4.1-mini",
        input=[{
            "role": "user",
            "content": [
                {"type": "input_text",
                 "text": """Voici une diapositive.
                            Celle ci est extraite d'un cours pour lequel il est necessaire de réaliser une fiche explicative.
                            Ce cours possède plusieurs diapositives, mais tu n'as accès ici qu'à une seule diapositive.
                            Je te demanderai de réaliser une explication de cette diapo et je réitérerai l'opération pour chaque diapositive du cours.
                            Le but final est de mettre bout à bout les réponses que tu me donnera pour obtenir un tout harmonieux.
                            Il n'est donc pas necessaire de placer des phrases d'introduction ou de conclusion.
                            
                            Cette diapositive peut être de deux types.
                            Soit il s'agit d'une notion de cours.
                            Alors, il faudra alors que tu réalise un texte qui permette à un jeune lycéen de comprendre les éléments de cours qui se trouvent sur cette diapositive.
                            
                            Soit il s'agit d'un exercice.
                            Alors il faudra alors que tu propose un corrigé de cet exercice.
                            Dans le cas où il s'agit d'un exercice de programmation, le seul langage à utiliser est python. Tu n'utilisera pas d'autres langages et en particulier tu n'utilisera pas VBA."""
                },
                {
                    "type": "input_image",
                    "image_url" : img_url,
                },
            ],
        }],
    )

    return response.output_text

import os
import sys
import subprocess
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    print("Le module PyMuPDF (pymupdf) est requis. Installez-le avec: pip install pymupdf")
    sys.exit(1)


def trouver_soffice() -> Path:
    """
    Tente de localiser LibreOffice (soffice.exe) aux emplacements standards.
    Retourne un Path absolu si trouvé, sinon lève une exception.
    """
    candidats = [
        Path(r"C:\Program Files\LibreOffice\program\soffice.exe"),
        Path(r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"),
    ]
    for p in candidats:
        if p.exists():
            return p.resolve()
    raise FileNotFoundError(
        "LibreOffice (soffice.exe) est introuvable aux emplacements standards.\n"
        "Vérifiez l'installation de LibreOffice."
    )


def convertir_pptx_en_pdf(soffice: Path, pptx: Path, outdir: Path, timeout_sec: int = 120) -> Path:
    """
    Utilise LibreOffice en mode headless pour convertir un PPTX en PDF.
    Retourne le chemin du PDF généré.
    """
    outdir.mkdir(parents=True, exist_ok=True)
    pdf_path = outdir / (pptx.stem + ".pdf")

    cmd = [
        str(soffice),
        "--headless",
        "--nologo",
        "--nodefault",
        "--nofirststartwizard",
        "--convert-to", "pdf",
        "--outdir", str(outdir),
        str(pptx),
    ]

    try:
        completed = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
            timeout=timeout_sec,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
        )
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(f"Timeout lors de la conversion LibreOffice: {e}") from e
    except subprocess.CalledProcessError as e:
        raise RuntimeError(
            f"Echec de la conversion LibreOffice (code {e.returncode}).\n"
            f"STDOUT:\n{e.stdout.decode(errors='ignore')}\n\n"
            f"STDERR:\n{e.stderr.decode(errors='ignore')}"
        ) from e

    if not pdf_path.exists():
        # Parfois LibreOffice écrit les messages sur stdout/stderr sans lever d'erreur
        stdout = completed.stdout.decode(errors="ignore")
        stderr = completed.stderr.decode(errors="ignore")
        raise RuntimeError(
            f"La conversion en PDF n'a pas produit de fichier attendu: {pdf_path}\n"
            f"STDOUT:\n{stdout}\n\nSTDERR:\n{stderr}"
        )

    return pdf_path


def generer_miniatures(pdf_path: Path, dest_dir: Path, largeur_max_px: int = 1024) -> int:
    """
    Rendu de chaque page du PDF en PNG, redimensionné en gardant l'aspect
    pour que la largeur soit environ largeur_max_px.
    Retourne le nombre d'images générées.
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    doc = fitz.open(str(pdf_path))
    try:
        total = doc.page_count
        for idx in range(total):
            page = doc.load_page(idx)
            page_width_pt = page.rect.width  # en points (1/72")
            if page_width_pt <= 0:
                zoom = 2.0  # fallback
            else:
                zoom = max(0.1, float(largeur_max_px) / float(page_width_pt))

            mat = fitz.Matrix(zoom, zoom)
            pix = page.get_pixmap(matrix=mat, alpha=False)

            out_name = f"slide_{idx+1:03d}.png"
            out_path = dest_dir / out_name
            pix.save(str(out_path))
    finally:
        doc.close()

    return total


def creer_miniatures(chemin, nom_du_cours):
    # Répertoires/fichiers
    script_dir = chemin
    pptx_path = script_dir / nom_du_cours
    miniatures_dir = script_dir / "miniatures"

    if not pptx_path.exists():
        print(f"Fichier introuvable: {pptx_path}")
        sys.exit(1)

    try:
        soffice = trouver_soffice()
    except Exception as e:
        print(str(e))
        sys.exit(1)

    # Dossier temporaire pour la conversion en PDF (dans le dossier de miniatures pour rester 'à côté')
    tmp_pdf_dir = miniatures_dir / "_tmp_pdf"
    tmp_pdf_dir.mkdir(parents=True, exist_ok=True)

    try:
        print("Conversion du PPTX en PDF via LibreOffice...")
        pdf_path = convertir_pptx_en_pdf(soffice, pptx_path, tmp_pdf_dir)

        print("Génération des miniatures PNG à partir du PDF...")
        nb = generer_miniatures(pdf_path, miniatures_dir, largeur_max_px=1024)

        print(f"Terminé. {nb} miniatures générées dans: {miniatures_dir}")
    except Exception as e:
        print(f"Erreur: {e}")
        sys.exit(1)
    finally:
        # Nettoyage du PDF temporaire
        try:
            if tmp_pdf_dir.exists():
                for p in tmp_pdf_dir.glob("*"):
                    try:
                        p.unlink(missing_ok=True)
                    except Exception:
                        pass
                tmp_pdf_dir.rmdir()
        except Exception:
            pass
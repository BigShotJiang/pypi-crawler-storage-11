print("Bienvenue dans l'outil 'Fiche résumée' !")
print("")
print("Ce module requiert une clef API OpenAI")
print("""Pour plus de détails sur le fonctionnement des clefs API OpenAI et créer votre propre clef rendez-vous sur "https://platform.openai.com/docs/api-reference/introduction" """)
print("")
print("Préparez votre cours au format pptx puis utilisez la fonction creer_fiche(nom_du_cours, api_key) pour créer un résumé de votre cours au format odt.")

from .fiche_resumee import creer_fiche

__all__ = ["creer_fiche"]
from .miniatures import creer_miniatures
from .diapositive_resume import resume_diapo

import os
from pathlib import Path

try:
    from odf.opendocument import OpenDocumentText
    from odf.text import P
    from odf.draw import Frame, Image
    from odf.style import Style, GraphicProperties
except ImportError:
    print("Le module odfpy est requis. Installez-le avec: pip install odfpy")
    sys.exit(1)

def identifier_repertoire_appelant(dossier_appelant):
    if dossier_appelant is None:
        try:
            caller_file = inspect.stack()[1].filename
            base = Path(caller_file).resolve().parent
        except Exception:
            base = Path.cwd()
    else:
        base = Path(dossier_appelant).resolve()
    return base

def creer_fiche(nom_du_cours, api_key, dossier_appelant = None):
    """
    Utiliser cette fonction pour créer une fiche résumée
    Le premier paramètre est votre diaporama de cours au format pptx.
       Par exemple placer votre fichier nommé "cours.pptx" à coté de votre code et écrire "cours.pptx" comme premier paramètre
    
    Le second est votre clef API OpenAI.
    Se rendre sur "https://platform.openai.com/docs/api-reference/introduction" pour plus de détails sur le fonctionnement des clefs API OpenAI et créer votre propre clef
    
    Le répertoire du script important cette bibliothèque est automatiquement recherché. Si cela échoue, écrire "target_dir=Path(__file__).parent" comme troisième paramètre.
       Par exemple creer_fiche("cours.pptx", "sk-proj-p0k...", target_dir=Path(__file__).parent) 
    """
    # Identification dossier appelant
    chemin = identifier_repertoire_appelant(dossier_appelant)
    
    # Création des miniatures
    print("Création des miniatures du cours. Veuillez patienter...")
    creer_miniatures(chemin, nom_du_cours)
    print("Miniatures créées.")

    # Création du document
    doc = OpenDocumentText()

    # Style pour les images
    img_style = Style(name="ImageStyle", family="graphic")
    img_style.addElement(GraphicProperties(width="14cm", height="7.5cm"))
    doc.automaticstyles.addElement(img_style)

    print("Initialisation de la phase de réflexion...")

    dossier = os.path.join(chemin, "miniatures")
    nombre_slides = len(os.listdir(dossier))
    slide_en_cours = 0
    for fichier in os.listdir(dossier):
        p = P()
        
        slide_en_cours +=1
        print("Traitement en cours : slide", slide_en_cours, "/" , nombre_slides)

        # Ajout de l'image
        image_path = os.path.join(dossier, fichier)
        doc.text.addElement(p)
        photoframe = Frame(width="512pt", height="289pt", x="56pt", y="56pt", anchortype="paragraph")
        href = doc.addPicture(image_path)
        photoframe.addElement(Image(href=href))
        p.addElement(photoframe)

        # Ajout du texte explicatif
        text = resume_diapo(image_path, api_key)
        p = P(text=text)
        doc.text.addElement(p)

    # Sauvegarde du fichier
    fichier_sauvegarde = nom_du_cours[:-5]+".odt"   
    output = os.path.join(chemin, fichier_sauvegarde)
    doc.save(output)
    print(f"Fiche résumée créée avec succès : {output}")

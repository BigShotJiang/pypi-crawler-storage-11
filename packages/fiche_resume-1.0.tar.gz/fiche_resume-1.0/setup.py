from setuptools import setup, find_packages

setup(
    name='fiche_resume',
    version='1.0',
    packages=find_packages(),
    description="Un package servant à contruire une fiche résumée au format odt à partir d'un document pptx",
    author='David Guenez',
    author_email='david.guenez@univ-nantes.fr',
    install_requires=[
        'odfpy',
        'PyMuPDF',
        'openai'
        ],
    python_requires='>=3.8',
)
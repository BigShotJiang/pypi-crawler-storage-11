import json

import pytest

from addok.batch import process_documents
from addok.core import search, Result
from addok.ds import get_document
from addok.helpers.text import Token
from addok_france.utils import (clean_query, extract_address, flag_housenumber,
                                fold_ordinal, glue_ordinal, make_labels,
                                remove_leading_zeros)


@pytest.mark.parametrize("input,expected", [
    ("2 allée Jules Guesde 31068 TOULOUSE CEDEX 7",
     "2 allée Jules Guesde 31 TOULOUSE"),
    ("7, avenue Léon-Blum 31507 Toulouse Cedex 5",
     "7, avenue Léon-Blum 31 Toulouse"),
    ("159, avenue Jacques-Douzans 31604 Muret Cedex",
     "159, avenue Jacques-Douzans 31 Muret"),
    ("2 allée Jules Guesde BP 7015 31068 TOULOUSE",
     "2 allée Jules Guesde 31068 TOULOUSE"),
    ("2 allée Jules Guesde B.P. 7015 31068 TOULOUSE",
     "2 allée Jules Guesde 31068 TOULOUSE"),
    ("2 allée Jules Guesde B.P. N 7015 31068 TOULOUSE",
     "2 allée Jules Guesde 31068 TOULOUSE"),
    ("BP 80111 159, avenue Jacques-Douzans 31604 Muret",
     "159, avenue Jacques-Douzans 31604 Muret"),
    ("12, place de l'Hôtel-de-Ville BP 46 02150 Sissonne",
     "12, place de l'Hôtel-de-Ville 02150 Sissonne"),
    ("6, rue Winston-Churchill CS 40055 60321 Compiègne",
     "6, rue Winston-Churchill 60321 Compiègne"),
    ("BP 80111 159, avenue Jacques-Douzans 31604 Muret Cedex",
     "159, avenue Jacques-Douzans 31 Muret"),
    ("BP 20169 Cite administrative - 8e étage Rue Gustave-Delory 59017 Lille",
     "Cite administrative - Rue Gustave-Delory 59017 Lille"),
    ("12e étage Rue Gustave-Delory 59017 Lille",
     "Rue Gustave-Delory 59017 Lille"),
    ("12eme étage Rue Gustave-Delory 59017 Lille",
     "Rue Gustave-Delory 59017 Lille"),
    ("12ème étage Rue Gustave-Delory 59017 Lille",
     "Rue Gustave-Delory 59017 Lille"),
    ("Rue Louis des Etages", "Rue Louis des Etages"),
    ("route express", "route express"),
    ("air s/ l'adour", "air sur l'adour"),
    ("air-s/-l'adour", "air sur l'adour"),
    ("Saint Didier s/s Ecouves", "Saint Didier sous Ecouves"),
    ("La Chapelle-aux-Brocs", "La Chapelle-aux-Brocs"),
    ("Lieu-Dit Les Chênes", "Les Chênes"),
    ("Lieu Dit Les Chênes", "Les Chênes"),
    ("LieuDit Les Chênes", "Les Chênes"),
    ("Lieux-Dits Les Chênes", "Les Chênes"),
    ("Lieu-Dit", "Lieu-Dit"),
    ("rue de la rente du lieu-dit la gachère",
     "rue de la rente du lieu-dit la gachère"),
    ("32bis Rue des Vosges93290",
     "32bis Rue des Vosges 93290"),
    ("20 avenue de Ségur TSA 30719 75334 Paris Cedex 07",
     "20 avenue de Ségur 75 Paris"),
    ("20 avenue de Ségur TSA No30719 75334 Paris Cedex 07",
     "20 avenue de Ségur 75 Paris"),
    ("20 avenue de Ségur TSA N 30719 75334 Paris Cedex 07",
     "20 avenue de Ségur 75 Paris"),
    ("20 rue saint germain CIDEX 304 89110 Poilly-sur-tholon",
     "20 rue saint germain 89110 Poilly-sur-tholon"),
    ("20 rue saint germain CIDEX N°304 89110 Poilly-sur-tholon",
     "20 rue saint germain 89110 Poilly-sur-tholon"),
    ("bp 18", ""),
])
def test_clean_query(input, expected):
    assert clean_query(input) == expected


@pytest.mark.parametrize("input,expected", [
    ('Immeuble Plein-Centre 60, avenue du Centre 78180 Montigny-le-Bretonneux',
     '60, avenue du Centre 78180 Montigny-le-Bretonneux'),
    ('75, rue Boucicaut 92260 Fontenay-aux-Roses',
     '75, rue Boucicaut 92260 Fontenay-aux-Roses'),
    ('rue Boucicaut 92260 Fontenay-aux-Roses',
     'rue Boucicaut 92260 Fontenay-aux-Roses'),
    ("Maison de l'emploi et de la formation 13, rue de la Tuilerie 70400 Héricourt",  # noqa
     "13, rue de la Tuilerie 70400 Héricourt"),
    # ("Parc d'activités Innopole 166, rue Pierre-et-Marie-Curie 31670 Labège",
    #  "166, rue Pierre-et-Marie-Curie 31670 Labège"),
    # ("32, allée Henri-Sellier Maison des solidarités 31400 Toulouse",
    #  "32, allée Henri-Sellier 31400 Toulouse"),
    # ("Centre d'Affaires la Boursidiere - BP 160 - Bâtiment Maine 4ème étage Le Plessis Robinson 92357 France",  # noqa
    #  "Le Plessis Robinson 92357 France"),
    # ("21 Rue Clef 34 Rue Daubenton",
    # "21 Rue Clef"),
    ("Tribunal d'instance de Guebwiller 1, place Saint-Léger 68504 Guebwiller",
     "1, place Saint-Léger 68504 Guebwiller"),
    ("Centre social 3 rue du Laurier 73000 CHAMBERY",
     "3 rue du Laurier 73000 CHAMBERY"),
    ("Maison de la Médiation 72 Chaussée de l'Hôtel de Ville 59650 VILLENEUVE D ASCQ",  # noqa
     "72 Chaussée de l'Hôtel de Ville 59650 VILLENEUVE D ASCQ"),
    ("2, Grande rue 62128 Écoust-Saint-Mein",
     "2, Grande rue 62128 Écoust-Saint-Mein"),
    ("Le Haut de la Rue du Bois 77122 Monthyon",
     "Le Haut de la Rue du Bois 77122 Monthyon"),
    ("Sous la Rue du Temple 62800 Liévin",
     "Sous la Rue du Temple 62800 Liévin"),
    # Two spaces after housenumber.
    ("resid goelands 28  impasse des petrels 76460 Saint-valery-en-caux",
     "28  impasse des petrels 76460 Saint-valery-en-caux"),
    # Two spaces before bis.
    ("resid goelands 28  bis impasse des petrels 76460 Saint-valery-en-caux",
     "28  bis impasse des petrels 76460 Saint-valery-en-caux"),
    # No spaces before bis.
    ("resid goelands 28bis impasse des petrels 76460 Saint-valery-en-caux",
     "28bis impasse des petrels 76460 Saint-valery-en-caux"),
    ("boulevard jean larrieu 44000 mont de marsan",
     "boulevard jean larrieu 44000 mont de marsan"),
    ("PARC D ACTIVITE DE SAUMATY 26 AV ANDRE ROUSSIN 13016 MARSEILLE 16",
     "26 AV ANDRE ROUSSIN 13016 MARSEILLE 16"),
    ("Non matching pattern",
     "Non matching pattern"),
])
def test_extract_address(input, expected):
    assert extract_address(input) == expected


@pytest.mark.parametrize("inputs,expected", [
    (['6', 'bis'], ['6bis']),
    (['6'], ['6']),
    (['6', 'avenue'], ['6', 'avenue']),
    (['60', 'bis', 'avenue'], ['60bis', 'avenue']),
    (['600', 'ter', 'avenue'], ['600ter', 'avenue']),
    (['6', 'quinquies', 'avenue'], ['6quinquies', 'avenue']),
    (['60', 'sexies', 'avenue'], ['60sexies', 'avenue']),
    (['600', 'quater', 'avenue'], ['600quater', 'avenue']),
    (['6', 's', 'avenue'], ['6s', 'avenue']),
    (['60b', 'avenue'], ['60b', 'avenue']),
    (['600', 'b', 'avenue'], ['600b', 'avenue']),
    (['241', 'r', 'de'], ['241', 'r', 'de']),
    (['120', 'r', 'renard'], ['120', 'r', 'renard']),
    (['241', 'r', 'rue'], ['241r', 'rue']),
    (['place', 'des', 'terreaux'], ['place', 'des', 'terreaux']),
    (['rue', 'du', 'bis'], ['rue', 'du', 'bis']),
])
def test_glue_ordinal(inputs, expected):
    tokens = [Token(input_) for input_ in inputs]
    assert list(glue_ordinal(tokens)) == expected


@pytest.mark.parametrize("inputs,expected", [
    (['6b'], True),
    (['6'], True),
    (['9303'], True),
    (['93031'], False),  # postcode
    (['6', 'avenue'], True),
    (['60b', 'avenue'], True),
    (['600t', 'avenue'], True),
    (['6c', 'avenue'], True),
    (['60s', 'avenue'], True),
    (['600q', 'avenue'], True),
    (['6s', 'avenue'], True),
    (['60b', 'avenue'], True),
    (['600b', 'avenue'], True),
    (['241', 'r', 'de'], True),
    (['241r', 'rue'], True),
    (['place', 'des', 'terreaux'], False),
    (['rue', 'du', 'bis'], False),
    (['9', 'grand', 'rue'], True),
    (['15', 'bld', 'hugo'], True),
    (['22', 'blvd', 'republique'], True),
    (['8', 'ch', 'oliviers'], True),
    (['12', 'chem', 'jean'], True),
    (['5', 'pass', 'montmartre'], True),
    (['3', 'dom', 'foret'], True),
    (['18', 'res', 'mimosas'], True),
    (['25', 'prom', 'anglais'], True),
    (['7', 'ham', 'vallee'], True),
    (['10', 'fbg', 'martin'], True),
    (['14', 'carr', 'etoile'], True),
    (['9', 'trav', 'champs'], True),
    (['20', 'espl', 'gaulle'], True),
    (['15', 'jard', 'plantes'], True),
    (['3', 'jetée', 'port'], True),
    (['3', 'jetee', 'port'], True),
    (['3', 'jtée', 'port'], True),
    (['3', 'jtee', 'port'], True),
    (['7', 'plle', 'parc'], True),
    (['12', 'prvs', 'dame'], True),
    (['18', 'qrt', 'latin'], True),
    (['25', 'rlle', 'chat'], True),
    (['8', 'tsse', 'soleil'], True),
    (['10', 'vlla', 'roses'], True),
    ([], False),  # Case of an empty string after clean query. Should not fail.
])
def test_flag_housenumber(inputs, expected):
    tokens = [Token(input_) for input_ in inputs]
    tokens = list(flag_housenumber(tokens))
    assert tokens == inputs
    if inputs:
        assert (tokens[0].kind == 'housenumber') == expected


@pytest.mark.parametrize("street_type,should_match", [
    # Boulevard abbreviations
    ('bld', True),
    ('blvd', True),
    ('bvd', True),
    ('boulevard', True),
    # Chemin abbreviations
    ('ch', True),
    ('chem', True),
    ('chemin', True),
    # Passage
    ('pass', True),
    ('passage', True),
    # Domaine
    ('dom', True),
    ('domaine', True),
    # Residence
    ('res', True),
    ('rés', True),
    ('residence', True),
    # Promenade
    ('prom', True),
    ('promenade', True),
    # Hameau
    ('ham', True),
    ('hameau', True),
    # Faubourg
    ('fbg', True),
    ('faubourg', True),
    # Carrefour
    ('carr', True),
    ('carrefour', True),
    # Traverse
    ('trav', True),
    ('traverse', True),
    # Esplanade
    ('espl', True),
    ('esp', True),
    ('esplanade', True),
    # Jardin
    ('jard', True),
    ('jardin', True),
    # Jetée - all variants
    ('jetée', True),
    ('jetee', True),
    ('jtée', True),
    ('jtee', True),
    # Passerelle
    ('plle', True),
    ('passerelle', True),
    # Parvis
    ('prvs', True),
    ('parvis', True),
    # Quartier
    ('qrt', True),
    ('quartier', True),
    # Ruelle
    ('rlle', True),
    ('ruelle', True),
    # Terrasse
    ('tsse', True),
    ('terrasse', True),
    # Villa
    ('vlla', True),
    ('villa', True),
    # Negative cases - should NOT match
    ('xyz', False),
    ('abc', False),
    ('test', False),
])
def test_street_type_patterns(street_type, should_match):
    """Test that street type patterns match expected abbreviations."""
    from addok_france.utils import TYPES_PATTERN
    result = bool(TYPES_PATTERN.match(street_type))
    assert result == should_match, \
        f"Pattern should {'match' if should_match else 'not match'} '{street_type}'"



@pytest.mark.parametrize("input,expected", [
    ('60bis', '60b'),
    ('60BIS', '60b'),
    ('60ter', '60t'),
    ('4terre', '4terre'),
    ('60quater', '60q'),
    ('60 bis', '60 bis'),
    ('bis', 'bis'),
])
def test_fold_ordinal(input, expected):
    assert fold_ordinal(Token(input)) == expected


@pytest.mark.parametrize("input,expected", [
    ('03', '3'),
    ('00009', '9'),
    ('02230', '02230'),  # Do not affect postcodes.
    ('0', '0'),
])
def test_remove_leading_zeros(input, expected):
    assert remove_leading_zeros(input) == expected


def test_index_housenumbers_use_processors(config):
    doc = {
        'id': 'xxxx',
        '_id': 'yyyy',
        'type': 'street',
        'name': 'rue des Lilas',
        'city': 'Paris',
        'lat': '49.32545',
        'lon': '4.2565',
        'housenumbers': {
            '1 bis': {
                'lat': '48.325451',
                'lon': '2.25651'
            }
        }
    }
    process_documents(json.dumps(doc))
    stored = get_document('d|yyyy')
    assert stored['housenumbers']['1b']['raw'] == '1 bis'


@pytest.mark.parametrize("input,expected", [
    ('rue du 8 mai troyes', False),
    ('8 rue du 8 mai troyes', '8'),
    ('3 rue du 8 mai troyes', '3'),
    ('3 bis rue du 8 mai troyes', '3 bis'),
    ('3 bis r du 8 mai troyes', '3 bis'),
    ('3bis r du 8 mai troyes', '3 bis'),
])
def test_match_housenumber(input, expected):
    doc = {
        'id': 'xxxx',
        '_id': 'yyyy',
        'type': 'street',
        'name': 'rue du 8 Mai',
        'city': 'Troyes',
        'lat': '49.32545',
        'lon': '4.2565',
        'housenumbers': {
            '3': {
                'lat': '48.325451',
                'lon': '2.25651'
            },
            '3 bis': {
                'lat': '48.325451',
                'lon': '2.25651'
            },
            '8': {
                'lat': '48.325451',
                'lon': '2.25651'
            },
        }
    }
    process_documents(json.dumps(doc))
    result = search(input)[0]
    assert (result.type == 'housenumber') == bool(expected)
    if expected:
        assert result.housenumber == expected


def test_match_housenumber_with_multiple_tokens(config):
    config.SYNONYMS = {'18': 'dix huit'}
    doc = {
        'id': 'xxxx',
        '_id': 'yyyy',
        'type': 'street',
        'name': 'rue du 8 Mai',
        'city': 'Troyes',
        'lat': '49.32545',
        'lon': '4.2565',
        'housenumbers': {
            '8': {
                'lat': '48.8',
                'lon': '2.25651'
            },
            '10': {
                'lat': '48.10',
                'lon': '2.25651'
            },
            '18': {
                'lat': '48.18',
                'lon': '2.25651'
            },
        }
    }
    process_documents(json.dumps(doc))
    result = search('8 rue du 8 mai')[0]
    assert result.housenumber == '8'
    assert result.lat == '48.8'
    result = search('10 rue du 8 mai')[0]
    assert result.housenumber == '10'
    assert result.lat == '48.10'
    result = search('18 rue du 8 mai')[0]
    assert result.housenumber == '18'
    assert result.lat == '48.18'


def test_make_labels(config):
    doc = {
        'id': 'xxxx',
        '_id': 'yyyy',
        'type': 'street',
        'name': 'rue des Lilas',
        'city': 'Paris',
        'postcode': '75010',
        'lat': '49.32545',
        'lon': '4.2565',
        'housenumbers': {
            '1 bis': {
                'lat': '48.325451',
                'lon': '2.25651'
            }
        }
    }
    process_documents(json.dumps(doc))
    result = Result(get_document('d|yyyy'))
    result.housenumber = '1 bis'  # Simulate match_housenumber
    make_labels(None, result)
    assert result.labels == [
        '1 bis rue des Lilas 75010 Paris',
        'rue des Lilas 75010 Paris',
        '1 bis rue des Lilas 75010',
        'rue des Lilas 75010',
        '1 bis rue des Lilas Paris',
        'rue des Lilas Paris',
        '1 bis rue des Lilas',
        'rue des Lilas'
    ]


def test_make_labels_merged_cities(config):
    """Test labels generation for addresses in merged municipalities."""
    doc = {
        "_id": "53543a313139353538390000",
        "id": "53543a313139353538390000",
        "type": "street",
        "postcode": "49120",
        "lat": "47.1469",
        "lon": "-0.75745",
        "name": "RUE PIERRE LEPOUREAU",
        "city": [
            "ST GEORGES DES GARDES (CHEMILLE EN ANJOU)",
            "ST GEORGES DES GARDES",
            "CHEMILLE EN ANJOU",
        ],
        "housenumbers": {
            "2 BIS": {
                "lat": "47.1504",
                "lon": "-0.757414"
            }
        }
    }

    process_documents(json.dumps(doc))
    result = Result(get_document('d|53543a313139353538390000'))
    result.housenumber = '2 bis'
    make_labels(None, result)

    # Should generate labels for each city variant
    # Labels are generated in priority order (via insert(0))
    assert '2 bis RUE PIERRE LEPOUREAU 49120 ST GEORGES DES GARDES (CHEMILLE EN ANJOU)' in result.labels
    assert 'RUE PIERRE LEPOUREAU 49120 ST GEORGES DES GARDES (CHEMILLE EN ANJOU)' in result.labels
    assert '2 bis RUE PIERRE LEPOUREAU 49120 ST GEORGES DES GARDES' in result.labels
    assert 'RUE PIERRE LEPOUREAU 49120 ST GEORGES DES GARDES' in result.labels
    assert '2 bis RUE PIERRE LEPOUREAU 49120 CHEMILLE EN ANJOU' in result.labels
    assert 'RUE PIERRE LEPOUREAU 49120 CHEMILLE EN ANJOU' in result.labels
    # Verify all 3 city variants are present
    assert any('ST GEORGES DES GARDES (CHEMILLE EN ANJOU)' in label for label in result.labels)
    assert any('ST GEORGES DES GARDES' in label and 'CHEMILLE EN ANJOU' not in label for label in result.labels)
    assert any('CHEMILLE EN ANJOU' in label and 'ST GEORGES DES GARDES' not in label for label in result.labels)


def test_make_labels_empty_city_list(config):
    """Test that empty city list generates base labels without city."""
    doc = {
        "_id": "53543a313139353538390001",
        "id": "53543a313139353538390001",
        "type": "street",
        "postcode": "75010",
        "lat": "48.8566",
        "lon": "2.3522",
        "name": "RUE DE TEST",
        "city": [],  # Empty list should be treated as None
    }

    process_documents(json.dumps(doc))
    result = Result(get_document('d|53543a313139353538390001'))
    make_labels(None, result)

    # Should generate base labels without city
    assert 'RUE DE TEST 75010' in result.labels or 'RUE DE TEST' in result.labels
    # Should not be empty
    assert len(result.labels) > 0


def test_make_labels_city_none(config):
    """Test that None city value generates base labels."""
    doc = {
        "_id": "53543a313139353538390002",
        "id": "53543a313139353538390002",
        "type": "street",
        "postcode": "75011",
        "lat": "48.8566",
        "lon": "2.3522",
        "name": "AVENUE EXEMPLE",
        "city": None,
    }

    process_documents(json.dumps(doc))
    result = Result(get_document('d|53543a313139353538390002'))
    make_labels(None, result)

    # Should generate base labels without city
    assert any('AVENUE EXEMPLE' in label for label in result.labels)
    assert len(result.labels) > 0


def test_make_labels_single_city_string(config):
    """Test that single city as string still works (backward compatibility)."""
    doc = {
        "_id": "53543a313139353538390003",
        "id": "53543a313139353538390003",
        "type": "street",
        "postcode": "69001",
        "lat": "45.7640",
        "lon": "4.8357",
        "name": "RUE DE LYON",
        "city": "LYON",
    }

    process_documents(json.dumps(doc))
    result = Result(get_document('d|53543a313139353538390003'))
    make_labels(None, result)

    # Should generate labels with city
    assert any('LYON' in label for label in result.labels)
    assert any('RUE DE LYON' in label for label in result.labels)
    assert len(result.labels) > 0


def test_make_municipality_labels(config):
    doc = {
        'id': 'xxxx',
        '_id': 'yyyy',
        'type': 'municipality',
        'name': 'Lille',
        'city': 'Lille',
        'postcode': '59000',
        'lat': '49.32545',
        'lon': '4.2565',
    }
    process_documents(json.dumps(doc))
    result = Result(get_document('d|yyyy'))
    make_labels(None, result)
    assert result.labels == [
        'Lille',
        '59000 Lille',
        'Lille 59000',
    ]

"""Basic tests for the CLI."""

import re
from typer.testing import CliRunner

from runlayer_cli.main import app

runner = CliRunner()


def strip_ansi(text: str) -> str:
    """Strip ANSI escape codes from text."""
    ansi_escape = re.compile(r"\x1b\[[0-9;]*m")
    return ansi_escape.sub("", text)


def test_help_command():
    """Test that the help command shows usage information."""
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    plain_output = strip_ansi(result.stdout)
    assert "Run an MCP server via HTTP transport" in plain_output
    assert "SERVER_UUID" in plain_output
    assert "--secret" in plain_output
    assert "--host" in plain_output


def test_run_command_requires_arguments():
    """Test that run command requires server UUID and secret."""
    result = runner.invoke(app, ["run"])
    assert result.exit_code != 0
    # Should fail because required arguments are missing

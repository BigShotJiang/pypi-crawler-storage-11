"""tests for pdsx."""

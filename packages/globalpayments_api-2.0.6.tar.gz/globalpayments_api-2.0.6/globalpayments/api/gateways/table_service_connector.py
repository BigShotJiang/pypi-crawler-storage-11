class TableServiceConnector(object):
    pass

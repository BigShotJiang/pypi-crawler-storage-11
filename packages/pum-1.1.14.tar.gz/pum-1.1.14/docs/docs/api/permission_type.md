::: pum.PermissionType

"""
Himpunan Package

Sebuah library Python untuk operasi himpunan:
- Gabungan (+)
- Irisan (/)
- Selisih (-)
- Selisih Simetris (*)
- Komplemen
- Himpunan Kuasa (abs)
- dan lain-lain.
"""

from .himpunan import Himpunan

__all__ = ["Himpunan"]
__version__ = "0.1.0"
__author__ = "mifey05"

"""Simple API for Kani-TTS."""
from typing import Tuple, Optional
import numpy as np
from .core import TTSConfig, NemoAudioPlayer, KaniModel


class KaniTTS:
    """
    Simple interface for Kani text-to-speech model.

    Example:
        >>> model = KaniTTS('your-model-name')
        >>> audio, text = model("Hello, world!")
    """

    def __init__(
        self,
        model_name: str,
        device_map: str = "auto",
        max_new_tokens: int = 1800,
        temperature: float = 0.6,
        top_p: float = 0.95,
        repetition_penalty: float = 1.1,
        tokeniser_length: int = 64400,
    ):
        """
        Initialize Kani-TTS model.

        Args:
            model_name: Hugging Face model ID or path to local model
            device_map: Device mapping for model (default: "auto")
            max_new_tokens: Maximum number of tokens to generate (default: 1800)
            temperature: Sampling temperature (default: 0.6)
            top_p: Top-p sampling parameter (default: 0.95)
            repetition_penalty: Repetition penalty (default: 1.1)
            tokeniser_length: Length of text tokenizer vocabulary (default: 64400)
        """
        self.config = TTSConfig(
            device_map=device_map,
            tokeniser_length=tokeniser_length,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_p=top_p,
            repetition_penalty=repetition_penalty,
        )

        self.player = NemoAudioPlayer(self.config)
        self.model = KaniModel(self.config, model_name, self.player)

    def __call__(self, text: str) -> Tuple[np.ndarray, str]:
        """
        Generate audio from text.

        Args:
            text: Input text to convert to speech

        Returns:
            Tuple of (audio_waveform, text) where audio_waveform is a numpy array
            containing the audio samples and text is the input text.
        """
        return self.generate(text)

    def generate(self, text: str) -> Tuple[np.ndarray, str]:
        """
        Generate audio from text.

        Args:
            text: Input text to convert to speech

        Returns:
            Tuple of (audio_waveform, text) where audio_waveform is a numpy array
            containing the audio samples and text is the input text.
        """
        return self.model.run_model(text)

    def save_audio(self, audio: np.ndarray, output_path: str, sample_rate: int = 22050):
        """
        Save audio waveform to file.

        Args:
            audio: Audio waveform as numpy array
            output_path: Path to save audio file (e.g., "output.wav")
            sample_rate: Sample rate in Hz (default: 22050)
        """
        try:
            import soundfile as sf
            sf.write(output_path, audio, sample_rate)
        except ImportError:
            raise ImportError(
                "soundfile is required to save audio. "
                "Install it with: pip install soundfile"
            )

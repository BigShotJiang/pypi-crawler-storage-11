"""
Kani-TTS: Text-to-Speech using Neural Audio Codec

A simple interface for generating speech from text using a causal language model
and NVIDIA NeMo audio codec.
"""

from .api import KaniTTS
from .core import TTSConfig

__version__ = "0.1.0"
__all__ = ["KaniTTS", "TTSConfig"]

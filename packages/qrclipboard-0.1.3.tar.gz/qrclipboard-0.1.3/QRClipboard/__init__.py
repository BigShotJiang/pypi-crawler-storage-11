"""
Clipboard QR Code Generator
"""

from setuptools import setup, find_packages

setup(
    name="mathematicspy",
    version="0.1.0",
    author="sdfsgh34567",
    author_email="sathishdhuda25@gmail.com",
    description="sdfghj3224546",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)

# API

Import the ehrdata API as follows:

```python
import ehrdata as ed
```

```{toctree}
:maxdepth: 1

api/ehrdata_index
api/datasets_index
api/io_index
api/integrations_index
```

```{eval-rst}
.. currentmodule:: ehrdata
```

# textsimilarity

A simple ML package to compute text similarity using TF-IDF.

## Installation
```bash
pip install textsimilarity
```

## Usage
```python
from textsimilarity import compute_similarity, rank_by_similarity

# Compare two texts
score = compute_similarity("Machine learning is great", "I love AI and machine learning")
print(score)

# Rank documents by similarity to a query
docs = [
    "Python is great for data science",
    "I play football",
    "Machine learning is amazing"
]
print(rank_by_similarity("I love Python and machine learning", docs))
```

__all__ = ["compute_similarity", "rank_by_similarity"]
__version__ = "0.1.0"

from .core import compute_similarity, rank_by_similarity

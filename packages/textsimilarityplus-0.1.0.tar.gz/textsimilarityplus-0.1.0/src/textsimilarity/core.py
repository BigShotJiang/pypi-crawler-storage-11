from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from typing import List, Tuple

def compute_similarity(text1: str, text2: str) -> float:
    """
    Compute similarity between two pieces of text using TF-IDF + cosine similarity.
    """
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([text1, text2])
    similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
    return round(float(similarity), 4)

def rank_by_similarity(query: str, documents: List[str], top_n: int = 3) -> List[Tuple[str, float]]:
    """
    Rank documents by similarity to a query.
    """
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([query] + documents)
    cosine_sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:])[0]
    
    ranked_results = sorted(
        zip(documents, cosine_sim),
        key=lambda x: x[1],
        reverse=True
    )
    return [(doc, round(score, 4)) for doc, score in ranked_results[:top_n]]

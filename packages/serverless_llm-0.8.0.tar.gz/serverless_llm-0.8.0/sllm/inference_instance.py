# ---------------------------------------------------------------------------- #
#  serverlessllm                                                               #
#  copyright (c) serverlessllm team 2024                                       #
#                                                                              #
#  licensed under the apache license, version 2.0 (the "license");             #
#  you may not use this file except in compliance with the license.            #
#                                                                              #
#  you may obtain a copy of the license at                                     #
#                                                                              #
#                  http://www.apache.org/licenses/license-2.0                  #
#                                                                              #
#  unless required by applicable law or agreed to in writing, software         #
#  distributed under the license is distributed on an "as is" basis,           #
#  without warranties or conditions of any kind, either express or implied.    #
#  see the license for the specific language governing permissions and         #
#  limitations under the license.                                              #
# ---------------------------------------------------------------------------- #

import ray

from sllm.logger import init_logger

logger = init_logger(__name__)


@ray.remote
def start_instance(
    instance_id, backend, model_name, backend_config, startup_config
):
    logger.info(f"Starting instance {instance_id} with backend {backend}")
    if backend == "vllm":
        from sllm.backends import VllmBackend

        model_backend_cls = VllmBackend
    elif backend == "dummy":
        from sllm.backends import DummyBackend

        model_backend_cls = DummyBackend
    elif backend == "transformers":
        from sllm.backends import TransformersBackend

        model_backend_cls = TransformersBackend
    else:
        logger.error(f"Unknown backend: {backend}")
        raise ValueError(f"Unknown backend: {backend}")

    model_actor_cls = ray.remote(model_backend_cls)

    return model_actor_cls.options(
        name=instance_id,
        **startup_config,
        max_concurrency=10,
        lifetime="detached",
    ).remote(model_name, backend_config)

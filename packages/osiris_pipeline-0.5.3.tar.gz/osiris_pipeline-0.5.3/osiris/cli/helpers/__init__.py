"""Shared CLI helper functions."""

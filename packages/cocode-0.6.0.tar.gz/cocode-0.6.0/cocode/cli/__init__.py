"""CLI modules for cocode."""

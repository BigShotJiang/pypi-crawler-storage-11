"""
Telecommunications Learning Tool

Original author: David Banas <capn.freako@gmail.com>
Original date: September 20, 2025

Copyright (c) 2025 David Banas; all rights reserved World wide.
"""

import sys
from pathlib import Path
from jupyterlab.labapp import main  # type: ignore


def run_notebook() -> None:
    """Run main Jupyter notebook from this package."""
    main([str(Path(sys.prefix, "share/notebooks", "pytelecomm.ipynb").resolve())])

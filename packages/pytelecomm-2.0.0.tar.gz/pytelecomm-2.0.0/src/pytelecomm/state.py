"""
Transmitter State Transition Graph

Original author: David Banas <capn.freako@gmail.com>
Original date: November 2, 2025

Copyright (c) 2025 David Banas; all rights reserved World wide.
"""

from abc              import ABC, abstractmethod
from typing           import TypeAlias

import numpy as np
import numpy.typing as npt
from numpy.polynomial import Polynomial

# State Transistion Matrix
StTranMat: TypeAlias = npt.NDArray[Polynomial]  # type: ignore[type-var]


def poly_det(ws: StTranMat) -> Polynomial:
    """
    Compute the "determinant" of a state transition matrix.

    Args:
        ws: State transition matrix.

    Returns:
        The polynomial "determinant" of the given state transition matrix.
    """

    n_rows = len(ws)

    if n_rows < 2:
        raise ValueError(f"Size of `ws` ({n_rows}) must be >= 2!")

    n_cols = len(ws[0])
    if n_cols != n_rows:
        raise ValueError(f"`ws` must be square! (Got {n_rows}x{n_cols}.)")

    if any(len(w) != n_cols for w in ws[1:]):
        raise ValueError(f"`ws` has inconsistent inner dimmensions: {list(map(len, ws))}!")

    if n_rows == 2:
        return ws[0][0] * ws[1][1] - ws[0][1] * ws[1][0]  # type: ignore[no-any-return]

    return sum(  # type: ignore[no-any-return]
        ws[0][ix] * poly_det(ws[1:].take(range(ix + 1, ix + n_rows),
                                         axis=1,
                                         mode='wrap'))
        for ix in range(n_rows))


class StateTransitionGraph(ABC):
    """
    Abstract definition of a state transition graph
    describing the restrictions on allowed symbol sequences.
    """

    @property
    @abstractmethod
    def symbol_info(self) -> dict[str, tuple[int, list[tuple[bool, int]]]]:
        """
        The symbol information for this state transition graph.

        Returns:
            A dictionary, indexed by the string representation of a symbol,
            of tuples containing

            - the duration of the symbol, and
            - a list of pairs, one for each state, containing

                - a flag indicating the symbol's validity in this state, and
                - the destination state for this symbol transmitted in this state.
        """

    @property
    def num_states(self) -> int:
        """Number of allowed states."""
        _, (_, transitions) = list(self.symbol_info.items())[0]
        return len(transitions)

    @property
    def capacity(self) -> float:
        """Channel capacity."""
        ws = self.null
        for _, (duration, transitions) in self.symbol_info.items():
            for src_state, (sym_valid, dst_state) in enumerate(transitions):
                if sym_valid:
                    coeffs = [0] * (duration + 1)
                    coeffs[-1] = 1
                    ws[src_state][dst_state] += Polynomial(coeffs)
        the_det = poly_det(ws - self.ident)                    # type: ignore[operator]
        return -np.log10(                                      # type: ignore[no-any-return]
            np.real(max(filter(np.isreal, the_det.roots()))))  # type: ignore[type-var]

    @property
    def null(self) -> StTranMat:
        """Null state transistion matrix."""
        num_states = self.num_states
        return np.full(
            shape=(num_states, num_states),
            fill_value=Polynomial([0]),
            dtype=Polynomial)

    @property
    def ident(self) -> StTranMat:
        """Identity state transistion matrix."""
        rslt = self.null
        for ix in range(len(rslt)):
            rslt[ix, ix] = Polynomial([1])  # type: ignore[assignment]
        return rslt


class Telegraph(StateTransitionGraph):
    """Concrete state transition graph for Telegraph."""

    @property
    def symbol_info(self) -> dict[str, tuple[int, list[tuple[bool, int]]]]:
        return {
            "dot":  (2, [(True,  1), (True, 1)]),
            "dash": (4, [(True,  1), (True, 1)]),
            "lspc": (3, [(False, 0), (True, 0)]),
            "wspc": (6, [(False, 0), (True, 0)]),
        }

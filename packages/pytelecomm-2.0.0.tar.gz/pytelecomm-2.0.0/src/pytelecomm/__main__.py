"""
PyTeleComm Package Default Executable Behavior

Original author: David Banas <capn.freako@gmail.com>
Original date: September 20, 2025

Coyright (c) 2025 David Banas; all rights reserved World wide.
"""

from . import run_notebook

run_notebook()

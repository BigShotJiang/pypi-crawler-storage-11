"""
PyTeleComm Pakcage Info

Original author: David Banas <capn.freako@gmail.com>
Original date: September 20, 2025

Copyright (c) 2025 David Banas; all rights reserved World wide.
"""

__version__ = "2.0.0"

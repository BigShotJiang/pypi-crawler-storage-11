def doc():
    print(r"""
sender_receiver()
srn() -> Sender Receiver Simple
filesender()
simplex_stop_and_wait()
noiseless_duplex()
""")
def sender_receiver():
    print(r"""

common.h
          

#ifndef COMMON_H
#define COMMON_H

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#endif

#define SERVER_PORT 8080
#define SERVER_IP "127.0.0.1"
#define MAX_DATA_SIZE 1024

typedef struct
{
    int id;
    char message[MAX_DATA_SIZE];
    int seq;
} Frame;

void init_winsock();
void cleanup_winsock();
SOCKET create_client_socket(const char *ip, int port);
SOCKET create_server_socket(int port);
void close_socket(SOCKET sock);

void send_frame(SOCKET sock, struct sockaddr_in *addr, Frame *frame);
int recv_ack(SOCKET sock, int expected_seq);
int receive_frame(SOCKET sock, Frame *frame);
void send_ack(SOCKET sock, struct sockaddr_in *client_addr, int seq);

#endif


          




dll_protocol.c

#include "common.h"
#include <stdio.h>
#include <string.h>

void send_frame(SOCKET sock, struct sockaddr_in *addr, Frame *frame) {
    sendto(sock, (char *)frame, sizeof(Frame), 0, (struct sockaddr *)addr, sizeof(*addr));
    printf("Sent [ID: %d, Seq: %d]: %s\n", frame->id, frame->seq, frame->message);
}

int recv_ack(SOCKET sock, int expected_seq) {
    int ack;
    recv(sock, (char *)&ack, sizeof(int), 0);
    return ack == expected_seq;
}

int receive_frame(SOCKET sock, Frame *frame) {
    struct sockaddr_in client;
    socklen_t len = sizeof(client);
    int bytes = recvfrom(sock, (char *)frame, sizeof(Frame), 0, (struct sockaddr *)&client, &len);
    return bytes > 0;
}

void send_ack(SOCKET sock, struct sockaddr_in *client_addr, int seq) {
    sendto(sock, (char *)&seq, sizeof(int), 0, (struct sockaddr *)client_addr, sizeof(*client_addr));
    printf("Sent ACK for seq: %d\n", seq);
}

          


          physical.c



#include "common.h"
#include <stdio.h>

void init_winsock()
{
#ifdef _WIN32
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);
#endif
}

void cleanup_winsock()
{
#ifdef _WIN32
    WSACleanup();
#endif
}

SOCKET create_client_socket(const char *ip, int port)
{
    SOCKET sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in server;

    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    server.sin_addr.s_addr = inet_addr(ip);

    connect(sock, (struct sockaddr *)&server, sizeof(server));
    return sock;
}

SOCKET create_server_socket(int port)
{
    SOCKET sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in server;

    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    server.sin_addr.s_addr = INADDR_ANY;

    bind(sock, (struct sockaddr *)&server, sizeof(server));
    return sock;
}

void close_socket(SOCKET sock)
{
#ifdef _WIN32
    closesocket(sock);
#else
    close(sock);
#endif
}

          



reciver.c
          
// main_receiver.c
#include "common.h"
#include <stdio.h>

int main() {
    init_winsock();

    SOCKET sock = create_server_socket(SERVER_PORT);
    struct sockaddr_in client;
    socklen_t len = sizeof(client);
    Frame frame;
    int expected_seq = 0;

    printf("Receiver started. Waiting for frames...\n");

    while (1) {
        int bytes = recvfrom(sock, (char *)&frame, sizeof(frame), 0, (struct sockaddr *)&client, &len);
        if (bytes > 0) {
            printf("Received [ID: %d, Seq: %d]: %s\n", frame.id, frame.seq, frame.message);

            if (frame.seq == expected_seq) {
                send_ack(sock, &client, expected_seq);
                expected_seq = 1 - expected_seq;
            } else {
                printf("Duplicate or out-of-order frame. Resending ACK for seq: %d\n", 1 - expected_seq);
                send_ack(sock, &client, 1 - expected_seq);
            }
        }
    }

    close_socket(sock);
    cleanup_winsock();
    return 0;
}

          

sender.c
          
          #include "common.h"
#include <stdio.h>
#include <string.h>

int main()
{
    init_winsock();

    SOCKET sock = create_client_socket(SERVER_IP, SERVER_PORT);
    struct sockaddr_in receiver;

    receiver.sin_family = AF_INET;
    receiver.sin_port = htons(SERVER_PORT);
    receiver.sin_addr.s_addr = inet_addr(SERVER_IP);

    Frame frame;
    int seq = 0;
    int id = 1;

    printf("Enter messages (press Enter after each message, Ctrl+C to exit):\n");

    while (1)
    {
        printf("Message %d: ", id);
        fgets(frame.message, MAX_DATA_SIZE, stdin);
        frame.message[strcspn(frame.message, "\n")] = 0;

        frame.seq = seq;
        frame.id = id++;

        send_frame(sock, &receiver, &frame);

        while (!recv_ack(sock, seq))
        {
            printf("ACK not received, resending...\n");
            send_frame(sock, &receiver, &frame);
        }

        seq = 1 - seq;
        printf("ACK received.\n\n");
    }

    close_socket(sock);
    cleanup_winsock();
    return 0;
}

          
          soket.c

#include <stdio.h>
#include <winsock.h>

int main()
{

    WSADATA ws;
    if (WSAStartup(MAKEWORD(2, 2), &ws) < 0)
    {
        printf("WSAstartup failed");
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("\nWSAStartup successfully");
    }

    int nsocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (nsocket < 0)
    {
        printf("Socket Not Opened");
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("\nSocket opened successfully :%d", nsocket);
    }

    struct sockaddr_in srv;
    srv.sin_family = AF_INET;
#define PORT 9909
    srv.sin_port = htons(PORT);
    srv.sin_addr.s_addr = INADDR_ANY;
    memset(&(srv.sin_zero), 0, 8);
    int nRet = 0;
    nRet = bind(nsocket, (struct sockaddr *)&srv, sizeof(srv));
    if (nRet < 0)
    {
        printf("\nfail to sind local port");
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("\nSuccefully binnd to local port");
    }

    nRet = listen(nsocket, 5);
    if (nRet < 0)
    {
        printf("\nFailed to listen to local port");
    }
    else
    {
        printf("\n Started local Port listening");
    }
}
          




COMMAND

 gcc sender.c DLL_protocol.c physical_layer.c -o sender.exe -lws2_32           

.\sender.exe
          
gcc receiver.c DLL_protocol.c physical_layer.c -o receiver.exe -lws2_32
          
.\receiver.exe


""")
def filesender():
    print(r"""
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>     // for close()
#include <arpa/inet.h>  // for socket stuff
#include <sys/socket.h>
#include <sys/types.h>

#define PORT 9999
#define BUF_SIZE 1024

void send_file(int new_sock, char *filename) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        perror("File open failed");
        return;
    }
    char data[BUF_SIZE];
    int n;
    while ((n = fread(data, 1, BUF_SIZE, fp)) > 0) {
        if (send(new_sock, data, n, 0) == -1) {
            perror("Send failed");
            break;
        }
    }
    fclose(fp);
    printf(" File sent successfully.\n");
}

void recv_file(int sock, char *filename) {
    FILE *fp = fopen(filename, "wb");
    if (!fp) {
        perror("File create failed");
        return;
    }
    char buffer[BUF_SIZE];
    int n;
    while ((n = recv(sock, buffer, BUF_SIZE, 0)) > 0) {
        fwrite(buffer, 1, n, fp);
    }
    fclose(fp);
    printf(" File received and saved as '%s'.\n", filename);
}

void sender() {
    int server_sock, new_sock;
    struct sockaddr_in server_addr, new_addr;
    socklen_t addr_size;
    char filename[100];

    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr));
    listen(server_sock, 1);
    printf(" Waiting for connection...\n");
    addr_size = sizeof(new_addr);
    new_sock = accept(server_sock, (struct sockaddr*)&new_addr, &addr_size);
    printf("Connected with %s\n", inet_ntoa(new_addr.sin_addr));

    printf("Enter file name to send: ");
    scanf("%s", filename);
    send_file(new_sock, filename);
    close(new_sock);
    close(server_sock);
}

void receiver() {
    int client_sock;
    struct sockaddr_in server_addr;
    char filename[100], server_ip[20];

    printf("Enter sender IP: ");
    scanf("%s", server_ip);
    printf("Enter name to save received file as: ");
    scanf("%s", filename);

    client_sock = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr(server_ip);

    connect(client_sock, (struct sockaddr*)&server_addr, sizeof(server_addr));
    printf("Connected. Receiving file...\n");
    recv_file(client_sock, filename);
    close(client_sock);
}

int main() {
    int choice;
    printf("=== Simple File Share ===\n1. Send\n2. Receive\nChoose: ");
    scanf("%d", &choice);
    if (choice == 1)
        sender();
    else if (choice == 2)
        receiver();
    else
        printf("Invalid choice.\n");
    return 0;
}

          

    COMMAND
          
gcc file_share.c -o file_share.exe -lws2_32

file_share.exe
-sender

file_share.exe
-reciever        
""")
def simplex_stop_and_wait():
    print(r"""
File: physical_layer.h
#ifndef PHYSICAL_LAYER_H
#define PHYSICAL_LAYER_H

int create_server(int port);
int create_client(char *server_ip, int port);
int send_frame(int sock, const char *frame, int len);
int recv_frame(int sock, char *buf, int len);

#endif

🧩 File: physical_layer.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "physical_layer.h"

int create_server(int port) {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);

    bind(sockfd, (struct sockaddr*)&addr, sizeof(addr));
    listen(sockfd, 1);
    printf("Waiting for connection...\n");
    int client = accept(sockfd, NULL, NULL);
    close(sockfd);
    printf("Connected.\n");
    return client;
}

int create_client(char *server_ip, int port) {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    inet_pton(AF_INET, server_ip, &addr.sin_addr);
    connect(sockfd, (struct sockaddr*)&addr, sizeof(addr));
    printf("Connected to server.\n");
    return sockfd;
}

int send_frame(int sock, const char *frame, int len) {
    return send(sock, frame, len, 0);
}

int recv_frame(int sock, char *buf, int len) {
    return recv(sock, buf, len, 0);
}

🧩 File: dll_stopwait.h
#ifndef DLL_STOPWAIT_H
#define DLL_STOPWAIT_H

void sender(int sock);
void receiver(int sock);

#endif

🧩 File: dll_stopwait.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "physical_layer.h"
#include "dll_stopwait.h"

#define FRAME_SIZE 128
#define LOSS_PROB  0.2  // simulate 20% frame loss

void sender(int sock) {
    char data[FRAME_SIZE], frame[FRAME_SIZE+10], ack[10];
    int frame_id = 0;
    srand(time(NULL));

    while (1) {
        printf("Enter message (or 'exit'): ");
        fgets(data, sizeof(data), stdin);
        data[strcspn(data, "\n")] = 0;
        if (!strcmp(data, "exit")) break;

        sprintf(frame, "%d:%s", frame_id, data);

        if ((rand() / (float)RAND_MAX) < LOSS_PROB)
            printf("[X] Frame lost intentionally.\n");
        else
            send_frame(sock, frame, strlen(frame)+1);

        if (recv_frame(sock, ack, sizeof(ack)) > 0 && atoi(ack) == frame_id) {
            printf("[✓] ACK %d received.\n", frame_id);
            frame_id = 1 - frame_id;  // toggle bit
        } else {
            printf("[!] Timeout or wrong ACK. Resending...\n");
        }
    }
}

void receiver(int sock) {
    char frame[FRAME_SIZE+10], data[FRAME_SIZE], ack[10];
    int expected_id = 0;

    while (1) {
        int n = recv_frame(sock, frame, sizeof(frame));
        if (n <= 0) break;

        int id;
        sscanf(frame, "%d:%[^\n]", &id, data);

        if (id == expected_id) {
            printf("Received frame %d: %s\n", id, data);
            sprintf(ack, "%d", id);
            send_frame(sock, ack, strlen(ack)+1);
            expected_id = 1 - expected_id;
        } else {
            printf("[!] Duplicate frame ignored.\n");
            sprintf(ack, "%d", 1 - expected_id);
            send_frame(sock, ack, strlen(ack)+1);
        }
    }
}

🧩 File: server.c
#include "physical_layer.h"
#include "dll_stopwait.h"

int main() {
    int sock = create_server(8080);
    receiver(sock);
    close(sock);
    return 0;
}

🧩 File: client.c
#include "physical_layer.h"
#include "dll_stopwait.h"

int main() {
    int sock = create_client("127.0.0.1", 8080);
    sender(sock);
    close(sock);
    return 0;
}

🧠 How to Compile & Run
gcc physical_layer.c dll_stopwait.c server.c -o server
gcc physical_layer.c dll_stopwait.c client.c -o client


Run in two terminals:

# Terminal 1
./server

# Terminal 2
./client
""")
def noiseless_duplex():
    print(r"""
🧩 File: physical_layer.h
#ifndef PHYSICAL_LAYER_H
#define PHYSICAL_LAYER_H

int create_server(int port);
int create_client(char *server_ip, int port);
int send_frame(int sock, const char *frame, int len);
int recv_frame(int sock, char *buf, int len);

#endif

🧩 File: physical_layer.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "physical_layer.h"

int create_server(int port) {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = INADDR_ANY;
    bind(sockfd, (struct sockaddr*)&addr, sizeof(addr));
    listen(sockfd, 1);
    printf("Waiting for connection...\n");
    int client = accept(sockfd, NULL, NULL);
    close(sockfd);
    printf("Connected.\n");
    return client;
}

int create_client(char *server_ip, int port) {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    inet_pton(AF_INET, server_ip, &addr.sin_addr);
    connect(sockfd, (struct sockaddr*)&addr, sizeof(addr));
    printf("Connected to server.\n");
    return sockfd;
}

int send_frame(int sock, const char *frame, int len) {
    return send(sock, frame, len, 0);
}

int recv_frame(int sock, char *buf, int len) {
    return recv(sock, buf, len, 0);
}

🧩 File: dll_stopwait.h
#ifndef DLL_STOPWAIT_H
#define DLL_STOPWAIT_H

void duplex_node(int sock, const char *role);

#endif

🧩 File: dll_stopwait.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "physical_layer.h"
#include "dll_stopwait.h"

#define FRAME_SIZE 128

int sock_global;  // shared socket for both threads

void *sender_thread(void *arg) {
    int frame_id = 0;
    char data[FRAME_SIZE], frame[FRAME_SIZE+10], ack[10];

    while (1) {
        printf("You: ");
        fgets(data, sizeof(data), stdin);
        data[strcspn(data, "\n")] = 0;
        if (!strcmp(data, "exit")) {
            send_frame(sock_global, "exit", 5);
            break;
        }
        sprintf(frame, "%d:%s", frame_id, data);
        send_frame(sock_global, frame, strlen(frame)+1);

        // Wait for ACK
        recv_frame(sock_global, ack, sizeof(ack));
        printf("[ACK %s received]\n", ack);
        frame_id = 1 - frame_id;
    }
    return NULL;
}

void *receiver_thread(void *arg) {
    int expected_id = 0;
    char frame[FRAME_SIZE+10], data[FRAME_SIZE], ack[10];

    while (1) {
        int n = recv_frame(sock_global, frame, sizeof(frame));
        if (n <= 0) break;
        if (!strcmp(frame, "exit")) {
            printf("\nPeer ended chat.\n");
            break;
        }

        int id;
        sscanf(frame, "%d:%[^\n]", &id, data);
        if (id == expected_id) {
            printf("\nPeer: %s\nYou: ", data);
            fflush(stdout);
            sprintf(ack, "%d", id);
            send_frame(sock_global, ack, strlen(ack)+1);
            expected_id = 1 - expected_id;
        } else {
            // Duplicate frame (in noiseless case, shouldn’t happen)
            sprintf(ack, "%d", 1 - expected_id);
            send_frame(sock_global, ack, strlen(ack)+1);
        }
    }
    return NULL;
}

void duplex_node(int sock, const char *role) {
    sock_global = sock;
    pthread_t t1, t2;
    printf("=== %s ready (type 'exit' to quit) ===\n", role);
    pthread_create(&t1, NULL, sender_thread, NULL);
    pthread_create(&t2, NULL, receiver_thread, NULL);
    pthread_join(t1, NULL);
    pthread_cancel(t2);  // stop receiver when done
}

🧩 File: server.c
#include "physical_layer.h"
#include "dll_stopwait.h"
#include <unistd.h>

int main() {
    int sock = create_server(8080);
    duplex_node(sock, "Server");
    close(sock);
    return 0;
}

🧩 File: client.c
#include "physical_layer.h"
#include "dll_stopwait.h"
#include <unistd.h>

int main() {
    int sock = create_client("127.0.0.1", 8080);
    duplex_node(sock, "Client");
    close(sock);
    return 0;
}

🧠 How to Compile & Run
gcc physical_layer.c dll_stopwait.c server.c -lpthread -o server
gcc physical_layer.c dll_stopwait.c client.c -lpthread -o client


Run in two terminals:

# Terminal 1
./server

# Terminal 2
./client
""")
def srn():
    print(r"""
common.h

#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <time.h>

#pragma comment(lib, "ws2_32.lib")

#define PORT 12345
#define PACKET_SIZE 1024
#define ACK_TIMEOUT 2  
#define NOISE_PROBABILITY 0.2 

#endif 



receiver.c

#include "common.h"

int simulate_noise() {
    return (rand() / (double)RAND_MAX) < NOISE_PROBABILITY;
}

void receive_data(SOCKET sock) {
    char packet[PACKET_SIZE];
    struct sockaddr_in client_addr;
    int addr_len = sizeof(client_addr);
    int expected_sequence_number = 0;

    while (1) {
        // Receive the packet
        int len = recvfrom(sock, packet, sizeof(packet) - 1, 0, (struct sockaddr *)&client_addr, &addr_len);
        if (len > 0) {
            packet[len] = '\0';

            if (simulate_noise()) {
                printf("--- Simulating incoming packet loss ---\n\n");
                continue;
            }

            int sequence_number;
            char data[PACKET_SIZE];
            sscanf(packet, "%d:%[^\n]", &sequence_number, data);

            printf("Received packet: '%s' (Sequence Number: %d)\n", data, sequence_number);

            if (sequence_number == expected_sequence_number) {
                printf("Packet is expected. Sending ACK %d.\n", sequence_number);
                expected_sequence_number = 1 - expected_sequence_number; // Flip expectation
            } else {
                printf("Packet is a duplicate (got %d, want %d). Resending ACK for previous packet %d.\n", 
                       sequence_number, expected_sequence_number, (1 - expected_sequence_number));
            }
            
            // Send ACK for the packet that was correctly received last
            int ack_to_send = 1 - expected_sequence_number;

            if (simulate_noise()) {
                printf("--- Simulating ACK loss for seq: %d ---\n\n", ack_to_send);
            } else {
                char ack[2];
                snprintf(ack, sizeof(ack), "%d", ack_to_send);
                sendto(sock, ack, strlen(ack), 0, (struct sockaddr *)&client_addr, addr_len);
                printf("Sent ACK: %d\n\n", ack_to_send);
            }
        }
    }
}

int main() {
    WSADATA wsaData;
    SOCKET sock;
    struct sockaddr_in server_addr;

    srand(time(NULL));

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("WSAStartup failed. Error Code: %d\n", WSAGetLastError());
        return 1;
    }

    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == INVALID_SOCKET) {
        printf("Socket creation failed. Error Code: %d\n", WSAGetLastError());
        WSACleanup();
        exit(EXIT_FAILURE);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        printf("Bind failed. Error Code: %d\n", WSAGetLastError());
        closesocket(sock);
        WSACleanup();
        exit(EXIT_FAILURE);
    }

    printf("Receiver is running...\n");
    receive_data(sock);

    closesocket(sock);
    WSACleanup();
    return 0;
}

sender.c

#include "common.h"

void send_data(SOCKET sock, struct sockaddr_in *addr, const char *data) {
    int sequence_number = 0;
    char packet[PACKET_SIZE];
    struct timeval timeout;
    fd_set read_fds;

    // This loop will just send the same data packet over and over.
    // In a real app, you'd be sending different chunks of a larger file.
    while (1) {
        // Prepare the packet
        snprintf(packet, sizeof(packet), "%d:%s", sequence_number, data);
        
        while(1) { // Inner loop for re-transmission
            sendto(sock, packet, strlen(packet), 0, (struct sockaddr *)addr, sizeof(*addr));
            printf("Sent packet with seq: %d\n", sequence_number);

            // Set up a timeout for receiving the ACK
            FD_ZERO(&read_fds);
            FD_SET(sock, &read_fds);
            timeout.tv_sec = ACK_TIMEOUT;
            timeout.tv_usec = 0;

            int select_result = select(0, &read_fds, NULL, NULL, &timeout);

            if (select_result == SOCKET_ERROR) {
                printf("select error: %d\n", WSAGetLastError());
                exit(EXIT_FAILURE);
            } else if (select_result == 0) {
                // Timeout occurred, resend packet
                printf("--- ACK timeout, resending packet with seq: %d ---\n", sequence_number);
                continue; // continue inner loop to re-send
            } else {
                // ACK received
                char ack[10];
                int ack_seq;
                recvfrom(sock, ack, sizeof(ack) - 1, 0, NULL, NULL);
                ack[sizeof(ack) - 1] = '\0';
                sscanf(ack, "%d", &ack_seq);

                if (ack_seq == sequence_number) {
                    printf("Received ACK for seq: %d\n\n", ack_seq);
                    sequence_number = 1 - sequence_number; // Toggle sequence number
                    break; // break inner loop to send next packet
                } else {
                    printf("Received wrong ACK (%d), expecting %d. Ignoring.\n", ack_seq, sequence_number);
                    // Stay in the inner loop, the timer will expire and cause a re-send
                }
            }
        }
    }
}

int main() {
    WSADATA wsaData;
    SOCKET sock;
    struct sockaddr_in server_addr;

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("WSAStartup failed. Error Code: %d\n", WSAGetLastError());
        return 1;
    }

    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == INVALID_SOCKET) {
        printf("Socket creation failed. Error Code: %d\n", WSAGetLastError());
        WSACleanup();
        exit(EXIT_FAILURE);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    server_addr.sin_port = htons(PORT);

    char data[] = "Hello, World!";
    send_data(sock, &server_addr, data);

    closesocket(sock);
    WSACleanup();
    return 0;
}
""")
# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DetectExtentionByNameAndIdResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'meta': 'Meta',
        'result': 'IvsExtentionByNameAndIdResponseBodyResult',
        'x_request_id': 'str'
    }

    attribute_map = {
        'meta': 'meta',
        'result': 'result',
        'x_request_id': 'X-Request-Id'
    }

    def __init__(self, meta=None, result=None, x_request_id=None):
        r"""DetectExtentionByNameAndIdResponse

        The model defined in huaweicloud sdk

        :param meta: 
        :type meta: :class:`huaweicloudsdkivs.v2.Meta`
        :param result: 
        :type result: :class:`huaweicloudsdkivs.v2.IvsExtentionByNameAndIdResponseBodyResult`
        :param x_request_id: 
        :type x_request_id: str
        """
        
        super().__init__()

        self._meta = None
        self._result = None
        self._x_request_id = None
        self.discriminator = None

        if meta is not None:
            self.meta = meta
        if result is not None:
            self.result = result
        if x_request_id is not None:
            self.x_request_id = x_request_id

    @property
    def meta(self):
        r"""Gets the meta of this DetectExtentionByNameAndIdResponse.

        :return: The meta of this DetectExtentionByNameAndIdResponse.
        :rtype: :class:`huaweicloudsdkivs.v2.Meta`
        """
        return self._meta

    @meta.setter
    def meta(self, meta):
        r"""Sets the meta of this DetectExtentionByNameAndIdResponse.

        :param meta: The meta of this DetectExtentionByNameAndIdResponse.
        :type meta: :class:`huaweicloudsdkivs.v2.Meta`
        """
        self._meta = meta

    @property
    def result(self):
        r"""Gets the result of this DetectExtentionByNameAndIdResponse.

        :return: The result of this DetectExtentionByNameAndIdResponse.
        :rtype: :class:`huaweicloudsdkivs.v2.IvsExtentionByNameAndIdResponseBodyResult`
        """
        return self._result

    @result.setter
    def result(self, result):
        r"""Sets the result of this DetectExtentionByNameAndIdResponse.

        :param result: The result of this DetectExtentionByNameAndIdResponse.
        :type result: :class:`huaweicloudsdkivs.v2.IvsExtentionByNameAndIdResponseBodyResult`
        """
        self._result = result

    @property
    def x_request_id(self):
        r"""Gets the x_request_id of this DetectExtentionByNameAndIdResponse.

        :return: The x_request_id of this DetectExtentionByNameAndIdResponse.
        :rtype: str
        """
        return self._x_request_id

    @x_request_id.setter
    def x_request_id(self, x_request_id):
        r"""Sets the x_request_id of this DetectExtentionByNameAndIdResponse.

        :param x_request_id: The x_request_id of this DetectExtentionByNameAndIdResponse.
        :type x_request_id: str
        """
        self._x_request_id = x_request_id

    def to_dict(self):
        import warnings
        warnings.warn("DetectExtentionByNameAndIdResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DetectExtentionByNameAndIdResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

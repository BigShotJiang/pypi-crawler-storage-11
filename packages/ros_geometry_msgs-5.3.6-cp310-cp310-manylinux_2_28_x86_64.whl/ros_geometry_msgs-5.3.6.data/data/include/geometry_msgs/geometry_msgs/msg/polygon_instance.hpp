// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef GEOMETRY_MSGS__MSG__POLYGON_INSTANCE_HPP_
#define GEOMETRY_MSGS__MSG__POLYGON_INSTANCE_HPP_

#include "geometry_msgs/msg/detail/polygon_instance__struct.hpp"
#include "geometry_msgs/msg/detail/polygon_instance__builder.hpp"
#include "geometry_msgs/msg/detail/polygon_instance__traits.hpp"
#include "geometry_msgs/msg/detail/polygon_instance__type_support.hpp"

#endif  // GEOMETRY_MSGS__MSG__POLYGON_INSTANCE_HPP_

"""GDS generator for FABulous."""

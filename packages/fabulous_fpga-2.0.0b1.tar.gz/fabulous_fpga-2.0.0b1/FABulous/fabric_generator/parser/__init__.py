"""Parser module for FABulous."""

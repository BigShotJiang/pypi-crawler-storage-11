"""Knowledge system integration tests."""

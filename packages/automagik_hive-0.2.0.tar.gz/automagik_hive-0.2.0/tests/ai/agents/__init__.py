"""Registry test package."""

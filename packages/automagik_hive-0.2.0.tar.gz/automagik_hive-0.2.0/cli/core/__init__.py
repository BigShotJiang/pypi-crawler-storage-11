"""CLI core module."""

"""Utility functions."""

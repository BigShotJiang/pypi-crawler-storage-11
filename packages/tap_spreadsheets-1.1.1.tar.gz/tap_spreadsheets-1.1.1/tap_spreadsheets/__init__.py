"""Tap for spreadsheets."""

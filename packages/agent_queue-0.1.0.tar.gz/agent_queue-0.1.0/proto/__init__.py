"""gRPC 接口定义"""
# gRPC 生成的代码会在这里
# 需要运行: python -m grpc_tools.protoc --python_out=. --grpc_python_out=. -I. proto/queue_service.proto

# 导出 gRPC 生成的代码（生成后可用）
try:
    from proto import queue_service_pb2, queue_service_pb2_grpc
    
    # 导出枚举，方便客户端使用
    TaskStatus = queue_service_pb2.TaskStatus
    TaskType = queue_service_pb2.TaskType
    
    __all__ = ["queue_service_pb2", "queue_service_pb2_grpc", "TaskStatus", "TaskType"]
except ImportError:
    # gRPC 代码还未生成
    __all__ = []


# Agent 私有化任务队列系统

基于 Redis + Celery 的私有化任务队列系统，使用 gRPC 接口为 agent 提供服务。支持通过 agentID 路由找到对应的私有化任务队列，agent 使用 gRPC 接口完成对自己私有化任务队列中的任务操作。

## 功能特性

- ✅ 基于 Redis + Celery 的分布式任务队列
- ✅ **gRPC 接口提供服务** - agent 使用 gRPC 接口完成所有操作
- ✅ **根据 agentID 路由** - 所有接口都通过 agentID 路由找到对应的私有化任务队列
- ✅ **私有化队列** - 支持按 agentID 的私有化队列
- ✅ **Agent 自动配置** - agent 只需配置 gRPC 服务器地址，无需配置 Redis
- ✅ **任务类型枚举** - 支持多种预定义任务类型（数据处理、图像处理、文本分析、模型推理等）和自定义类型
- ✅ **YAML 配置文件** - Redis 和 Celery 配置使用 YAML 文件管理
- ✅ **完整的 gRPC 接口**：
  - 队列管理：创建、检查、获取信息、清空队列
  - 任务操作：提交、批量提交、获取、查询、更新状态、删除、批量删除、取消、重试
  - 任务查询：列出任务、获取统计信息
- ✅ 任务状态管理（待处理、处理中、已完成、失败）
- ✅ 异步任务处理

## 项目结构

```
queues/
├── server/               # 服务端核心功能（需要 Redis + Celery）
│   ├── __init__.py
│   ├── config/           # 服务端配置
│   │   ├── __init__.py
│   │   ├── settings.py   # 应用配置（从 YAML 加载）
│   │   ├── celery_config.py  # Celery 配置
│   │   ├── redis.yaml    # Redis 配置文件
│   │   └── celery.yaml   # Celery 配置文件
│   ├── manager/          # 队列管理
│   │   ├── __init__.py
│   │   └── queue_manager.py  # 队列管理器（基于 Redis）
│   ├── celery/           # Celery 相关
│   │   ├── __init__.py
│   │   ├── app.py        # Celery 应用
│   │   └── handlers.py   # 任务处理器
│   └── grpc/             # gRPC 服务
│       ├── __init__.py
│       └── service.py    # gRPC 服务实现
├── proto/                # gRPC 接口定义（服务端和客户端都用）
│   ├── __init__.py
│   └── queue_service.proto  # gRPC 接口定义
├── tests/                # 测试用例
│   ├── __init__.py
│   ├── test_task_model.py
│   └── test_queue_manager.py
├── scripts/              # 脚本
│   ├── __init__.py
│   ├── generate_grpc.py  # 生成 gRPC 代码
│   ├── start_server.py   # 启动 gRPC 服务器
│   └── start_celery_worker.py  # 启动 Celery Worker
├── start.py              # 系统启动类（统一启动入口）
├── examples/             # 示例代码
│   ├── __init__.py
│   ├── client_example.py # gRPC 客户端示例
│   └── agent_example.py  # Agent 自动配置示例
├── pyproject.toml        # 项目配置
└── README.md
```

## 安装依赖

```bash
# 安装 Python 依赖
pip install -e .

# 或者使用 poetry
poetry install
```

## 环境配置

### Agent 使用（推荐）

**Agent 只需要配置 gRPC 服务器地址，无需配置 Redis！**

```bash
# gRPC 配置（Agent 必需）
export GRPC_HOST=queue-server.example.com
export GRPC_PORT=50051
```

### 服务端配置

服务端（agent-queue 系统）使用 YAML 配置文件管理 Redis 和 Celery 配置：

**Redis 配置** (`server/config/redis.yaml`):
```yaml
redis:
  host: localhost
  port: 6379
  db: 0
  password: null  # 可选，如果有密码则填写
  # url: redis://localhost:6379/0  # 可选，直接使用 URL
```

**Celery 配置** (`server/config/celery.yaml`):
```yaml
celery:
  task_serializer: json
  result_serializer: json
  accept_content:
    - json
  timezone: UTC
  enable_utc: true
  task_track_started: true
  task_time_limit: 1800      # 30分钟
  task_soft_time_limit: 1500 # 25分钟
  result_expires: 86400      # 24小时
```

**环境变量**（可选，优先级高于 YAML 配置）:
```bash
# Redis 配置（可选，会覆盖 YAML 配置）
export REDIS_HOST=localhost
export REDIS_PORT=6379
export REDIS_DB=0
export REDIS_PASSWORD=your_password  # 可选
export REDIS_URL=redis://localhost:6379/0  # 可选

# gRPC 配置
export GRPC_HOST=0.0.0.0
export GRPC_PORT=50051

# 日志级别
export LOG_LEVEL=INFO
```

## 使用步骤

### 1. 生成 gRPC 代码

首先需要从 `.proto` 文件生成 Python 代码：

```bash
python scripts/generate_grpc.py
```

或者手动运行：

```bash
python -m grpc_tools.protoc \
    --proto_path=proto \
    --python_out=proto \
    --grpc_python_out=proto \
    proto/queue_service.proto
```

### 2. 启动 Redis

确保 Redis 服务正在运行：

```bash
redis-server
```

### 3. 启动系统服务

**方式 1: 使用统一启动脚本（推荐）**

使用 `start.py` 统一启动 gRPC 服务器和 Celery Worker：

```bash
# 同时启动 gRPC 服务器和 Celery Worker（默认）
python start.py

# 只启动 gRPC 服务器
python start.py --grpc-only

# 只启动 Celery Worker
python start.py --celery-only

# 启动 Celery Worker 并指定并发数
python start.py --celery-only --celery-concurrency 8

# 查看所有选项
python start.py --help
```

**方式 2: 分别启动（用于开发调试）**

如果需要分别启动服务：

```bash
# 启动 gRPC 服务器
python scripts/start_server.py

# 在另一个终端启动 Celery Worker
celery -A server.celery.app worker --loglevel=info
```

服务器将在 `0.0.0.0:50051` 上启动。

## gRPC API 接口

gRPC 接口至少包括以下功能，所有接口都通过 agentID 路由找到对应的私有化任务队列：

### CreateQueue - 创建 agent 私有任务队列（根据 agentID 路由）

```python
request = CreateQueueRequest(
    agent_id="agent_001"
)
response = stub.CreateQueue(request)
```

### GetQueueInfo - 获取队列信息（根据 agentID 路由）

```python
request = GetQueueInfoRequest(
    agent_id="agent_001"
)
response = stub.GetQueueInfo(request)
# 返回：pending_count, processing_count, completed_count, failed_count
```

### SubmitTask - 给某个 agent 的私有化任务队列添加任务（根据 agentID 路由）

```python
request = SubmitTaskRequest(
    agent_id="agent_001",
    type=queue_service_pb2.DATA_PROCESSING,  # 任务类型（枚举）
    task_type="",  # 当 type = CUSTOM 时使用自定义类型字符串
    payload='{"key": "value"}'  # JSON 字符串
)
response = stub.SubmitTask(request)

# 或者使用自定义类型
request = SubmitTaskRequest(
    agent_id="agent_001",
    type=queue_service_pb2.CUSTOM,  # 自定义类型
    task_type="my_custom_task",  # 自定义类型字符串
    payload='{"key": "value"}'
)
response = stub.SubmitTask(request)
```

### GetTask - 从某个 agent 的私有化任务队列获取任务（根据 agentID 路由，主动拉取）

```python
request = GetTaskRequest(
    agent_id="agent_001",
    timeout=10  # 超时时间（秒），0 表示不等待
)
response = stub.GetTask(request)
```

### ListTasks - 列出某个 agent 的私有化任务队列中的所有任务（根据 agentID 路由）

```python
request = ListTasksRequest(
    agent_id="agent_001",
    status=queue_service_pb2.PENDING,  # 可选，0 表示所有状态
    limit=100,
    offset=0
)
response = stub.ListTasks(request)
```

### UpdateTaskStatus - 更新任务状态

```python
request = UpdateTaskStatusRequest(
    task_id="task_123",
    agent_id="agent_001",
    status=queue_service_pb2.COMPLETED,
    result='{"result": "success"}'  # 可选
)
response = stub.UpdateTaskStatus(request)
```

### QueryTask - 查询任务

```python
request = QueryTaskRequest(
    task_id="task_123",
    agent_id="agent_001"
)
response = stub.QueryTask(request)
```

### 任务类型枚举

系统支持多种预定义任务类型和自定义类型：

**预定义任务类型**（`queue_service_pb2.TaskType`）:
- `UNKNOWN = 0` - 未知类型
- `DATA_PROCESSING = 1` - 数据处理
- `IMAGE_PROCESSING = 2` - 图像处理
- `TEXT_ANALYSIS = 3` - 文本分析
- `MODEL_INFERENCE = 4` - 模型推理
- `DATA_EXTRACTION = 5` - 数据提取
- `FILE_UPLOAD = 6` - 文件上传
- `FILE_DOWNLOAD = 7` - 文件下载
- `API_CALL = 8` - API 调用
- `DATABASE_QUERY = 9` - 数据库查询
- `CUSTOM = 99` - 自定义类型（使用 `task_type` 字符串字段）

**使用示例**:
```python
from proto import queue_service_pb2

# 使用预定义类型
request = queue_service_pb2.SubmitTaskRequest(
    agent_id="agent_001",
    type=queue_service_pb2.DATA_PROCESSING,  # 使用枚举
    task_type="",  # 预定义类型不需要字符串
    payload='{"data": "test"}'
)

# 使用自定义类型
request = queue_service_pb2.SubmitTaskRequest(
    agent_id="agent_001",
    type=queue_service_pb2.CUSTOM,  # 自定义类型
    task_type="my_custom_task_type",  # 自定义类型字符串
    payload='{"data": "test"}'
)
```

## Agent 使用（客户端直接使用 gRPC 接口）

**客户端直接使用 proto 生成的 gRPC 接口，所有接口实现都在服务端。**

使用优势：
- ✅ **直接使用 gRPC 接口** - 无需额外的客户端封装包
- ✅ **所有实现都在服务端** - 客户端只需调用 gRPC 接口
- ✅ **根据 agentID 路由** - 所有接口都通过 agentID 路由到对应的私有化任务队列
- ✅ agent 只需要配置 gRPC 服务器地址，无需配置 Redis
- ✅ Redis 由服务端统一管理，更安全
- ✅ 适合生产环境，支持分布式部署

**安装依赖：**

```bash
# 从 PyPI 安装（发布后）
pip install agent-queue

# 或从源码安装
pip install -e .
```

**使用方式：**

```python
import grpc
import json
from proto import queue_service_pb2, queue_service_pb2_grpc

# 1. 连接到 gRPC 服务器
channel = grpc.insecure_channel('localhost:50051')
stub = queue_service_pb2_grpc.QueueServiceStub(channel)

agent_id = "my_agent_001"

# 2. 初始化：创建私有化任务队列（根据 agentID 路由）
create_request = queue_service_pb2.CreateQueueRequest(agent_id=agent_id)
create_response = stub.CreateQueue(create_request)
if create_response.success:
    print(f"✓ 私有化任务队列已创建: {agent_id}")

# 3. 后续操作：针对自己的私有化任务队列

# 获取队列信息（根据 agentID 路由）
info_request = queue_service_pb2.GetQueueInfoRequest(agent_id=agent_id)
info_response = stub.GetQueueInfo(info_request)
print(f"队列信息: 待处理={info_response.pending_count}")

# 提交任务（根据 agentID 路由）
submit_request = queue_service_pb2.SubmitTaskRequest(
    agent_id=agent_id,
    type=queue_service_pb2.DATA_PROCESSING,  # 任务类型（枚举）
    task_type="",  # 当 type = CUSTOM 时使用
    payload=json.dumps({"data": "test", "action": "process"})
)
submit_response = stub.SubmitTask(submit_request)
task_id = submit_response.task_id

# 获取任务（根据 agentID 路由，主动拉取）
get_request = queue_service_pb2.GetTaskRequest(agent_id=agent_id, timeout=5)
get_response = stub.GetTask(get_request)
if get_response.success and get_response.task.task_id:
    task = get_response.task
    # 处理任务...
    
    # 更新任务状态
    update_request = queue_service_pb2.UpdateTaskStatusRequest(
        task_id=task.task_id,
        agent_id=agent_id,
        status=queue_service_pb2.COMPLETED,
        result=json.dumps({"result": "processed"})
    )
    stub.UpdateTaskStatus(update_request)

# 查询任务
query_request = queue_service_pb2.QueryTaskRequest(
    task_id=task_id,
    agent_id=agent_id
)
query_response = stub.QueryTask(query_request)

# 列出所有任务（根据 agentID 路由）
list_request = queue_service_pb2.ListTasksRequest(
    agent_id=agent_id,
    status=0,  # 0 表示所有状态
    limit=10,
    offset=0
)
list_response = stub.ListTasks(list_request)
```

**在业务系统中集成示例：**

```python
import grpc
import json
from proto import queue_service_pb2, queue_service_pb2_grpc

class OrderService:
    def __init__(self, service_id: str):
        self.agent_id = f"order_service_{service_id}"
        
        # 连接到 gRPC 服务器
        channel = grpc.insecure_channel('localhost:50051')
        self.stub = queue_service_pb2_grpc.QueueServiceStub(channel)
        
        # 初始化时创建私有化任务队列（根据 agentID 路由）
        request = queue_service_pb2.CreateQueueRequest(agent_id=self.agent_id)
        response = self.stub.CreateQueue(request)
        if response.success:
            print(f"✓ 私有化任务队列已创建: {self.agent_id}")
    
    def process_orders(self):
        # 针对自己的私有化任务队列进行操作（根据 agentID 路由）
        request = queue_service_pb2.GetTaskRequest(agent_id=self.agent_id, timeout=5)
        response = self.stub.GetTask(request)
        if response.success and response.task.task_id:
            task = response.task
            # 处理任务...
            update_request = queue_service_pb2.UpdateTaskStatusRequest(
                task_id=task.task_id,
                agent_id=self.agent_id,
                status=queue_service_pb2.COMPLETED
            )
            self.stub.UpdateTaskStatus(update_request)
```

**完整示例：** 查看 `examples/client_grpc_example.py`

### 运行客户端示例

```bash
# 确保 gRPC 服务器正在运行
python examples/client_grpc_example.py  # 客户端直接使用 gRPC 接口示例
```

### 核心概念

- **gRPC 接口**：agent 通过 gRPC 接口完成对自己私有化任务队列中的任务操作
- **gRPC 模式（推荐）**：agent 只需要配置 gRPC 服务器地址，无需配置 Redis
- **Agent 实例**：每个 agent 实例绑定到自己的 agentID，自动拥有自己的私有化任务队列
- **私有化队列**：每个 agentID 拥有完全独立的任务队列，互不干扰
- **自动配置**：只需配置 gRPC 服务器地址和 agentID，系统自动创建队列
- **任务操作**：通过 gRPC 接口完成提交、获取、更新、查询、列表等所有操作

## 使用示例

### gRPC 客户端示例

运行示例代码：

```bash
# 确保 gRPC 服务器正在运行
python examples/client_example.py
```

或者参考 `examples/client_example.py` 中的完整示例代码。

## 运行测试

```bash
pytest tests/
```

## 任务状态

- `PENDING (0)`: 待处理
- `PROCESSING (1)`: 处理中
- `COMPLETED (2)`: 已完成
- `FAILED (3)`: 失败

## 技术栈

- **Python 3.12+**
- **Celery**: 分布式任务队列
- **Redis**: 消息代理和结果后端
- **gRPC**: 高性能 RPC 框架
- **Pydantic**: 数据验证

## 开发说明

### 添加自定义任务类型

在 `tasks/task_handlers.py` 中的 `process_task` 函数中添加任务类型处理逻辑：

```python
@celery_app.task(bind=True, name="tasks.process_task")
def process_task(self, task_id: str, agent_id: str):
    task = queue_manager.get_task_by_id(task_id, agent_id)
    
    if task.task_type == "your_task_type":
        # 处理你的任务类型
        pass
```

### 扩展 gRPC 接口

1. 修改 `interface/queue_service.proto`
2. 重新生成 gRPC 代码：`python scripts/generate_grpc.py`
3. 在 `implements/grpc_service.py` 中实现新的服务方法

## 发布到 PyPI

### 准备工作

1. 安装构建工具：
```bash
pip install build twine
```

2. 检查构建配置：
```bash
python scripts/check_build.py
```

### 构建包

```bash
python scripts/publish.py --build-only
```

或者使用标准命令：
```bash
python -m build
```

### 上传到 Test PyPI（推荐先测试）

```bash
python scripts/publish.py --test
```

或者手动上传：
```bash
python -m twine upload --repository-url https://test.pypi.org/legacy/ dist/*
```

### 上传到 PyPI

```bash
python scripts/publish.py
```

或者手动上传：
```bash
python -m twine upload dist/*
```

### 配置 PyPI 凭证

创建 `~/.pypirc` 文件：

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-xxxxxxxxxxxxx

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-xxxxxxxxxxxxx
```

或者使用环境变量：
```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-xxxxxxxxxxxxx
```

## 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

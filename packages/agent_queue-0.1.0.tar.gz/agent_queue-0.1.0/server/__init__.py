"""
服务端核心功能包

包含服务端所需的所有功能：
- config: 服务端配置（Redis, Celery, gRPC）
- manager: 队列管理器（基于 Redis）
- celery: Celery 应用和任务处理器
- grpc: gRPC 服务实现
"""

__version__ = "0.1.0"


"""Celery 应用和任务处理器模块"""
from server.celery.app import celery_app
from server.celery.handlers import submit_task_async, process_task

__all__ = ["celery_app", "submit_task_async", "process_task"]


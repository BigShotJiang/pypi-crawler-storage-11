"""任务处理器"""
import logging
from typing import Any, Dict
from server.celery.app import celery_app
from server.manager.queue_manager import queue_manager

# proto 的 TaskStatus 枚举值
PROCESSING = 1
COMPLETED = 2
FAILED = 3

logger = logging.getLogger(__name__)


@celery_app.task(bind=True, name="tasks.process_task")
def process_task(self, task_id: str, agent_id: str):
    """处理任务的 Celery 任务"""
    try:
        # 获取任务
        task_dict = queue_manager.get_task_by_id(task_id, agent_id)
        if not task_dict:
            logger.error(f"Task {task_id} not found")
            return {"success": False, "error": "Task not found"}
        
        # 更新状态为处理中
        queue_manager.update_task_status(task_id, agent_id, PROCESSING)
        
        # 这里可以根据 task_type 调用不同的处理函数
        # 目前只是一个示例
        logger.info(f"Processing task {task_id} of type {task_dict.get('task_type')}")
        
        # 模拟任务处理
        result = {
            "task_id": task_id,
            "processed": True,
            "payload": task_dict.get("payload")
        }
        
        # 更新状态为已完成
        queue_manager.update_task_status(
            task_id,
            agent_id,
            COMPLETED,
            result=result
        )
        
        return {"success": True, "result": result}
    except Exception as e:
        logger.error(f"Failed to process task {task_id}: {e}")
        # 更新状态为失败
        queue_manager.update_task_status(
            task_id,
            agent_id,
            FAILED,
            error_message=str(e)
        )
        return {"success": False, "error": str(e)}


def submit_task_async(task_dict: Dict[str, Any]) -> str:
    """异步提交任务"""
    # 先保存到队列
    success = queue_manager.submit_task(task_dict)
    if not success:
        raise Exception("Failed to submit task")
    
    task_id = task_dict.get("task_id")
    
    # 提交到 Celery 异步处理（可选，如果不需要异步处理可以注释掉）
    # process_task.delay(task_id, task_dict.get("agent_id"))
    
    return task_id


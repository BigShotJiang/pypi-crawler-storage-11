"""队列管理器 - 使用字典存储任务，统一使用 proto 定义"""
import json
import logging
import time
import uuid
from typing import Dict, List, Optional, Any

import redis
from server.config.settings import settings

# proto 的 TaskStatus 枚举值
PENDING = 0
PROCESSING = 1
COMPLETED = 2
FAILED = 3

logger = logging.getLogger(__name__)


class QueueManager:
    """基于 Redis 的队列管理器 - 使用字典存储任务"""
    
    def __init__(self):
        """初始化队列管理器"""
        self.redis_client = redis.Redis(
            host=settings.REDIS_HOST,
            port=settings.REDIS_PORT,
            db=settings.REDIS_DB,
            password=settings.REDIS_PASSWORD,
            decode_responses=True
        )
        self.task_prefix = settings.TASK_PREFIX
    
    def _get_queue_key(self, agent_id: str) -> str:
        """获取队列键名"""
        return f"{self.task_prefix}:{agent_id}:queue"
    
    def _get_task_key(self, task_id: str) -> str:
        """获取任务键名"""
        return f"{self.task_prefix}:task:{task_id}"
    
    def _get_task_status_key(self, agent_id: str, status: int) -> str:
        """获取任务状态集合键名"""
        return f"{self.task_prefix}:{agent_id}:status:{status}"
    
    def submit_task(self, task_dict: Dict[str, Any]) -> bool:
        """
        提交任务到队列
        
        Args:
            task_dict: 任务字典，包含 task_id, agent_id, task_type, payload, status 等
        
        Returns:
            是否成功
        """
        try:
            task_id = task_dict.get("task_id") or str(uuid.uuid4())
            agent_id = task_dict["agent_id"]
            status = task_dict.get("status", PENDING)
            
            # 确保任务字典包含必要字段
            task_dict["task_id"] = task_id
            task_dict["status"] = status
            task_dict.setdefault("created_at", int(time.time()))
            task_dict.setdefault("updated_at", int(time.time()))
            
            # 保存任务详情
            task_key = self._get_task_key(task_id)
            task_data = json.dumps(task_dict)
            self.redis_client.set(task_key, task_data, ex=settings.TASK_RESULT_EXPIRES)
            
            # 添加到队列
            queue_key = self._get_queue_key(agent_id)
            self.redis_client.lpush(queue_key, task_id)
            
            # 添加到状态集合
            status_key = self._get_task_status_key(agent_id, status)
            self.redis_client.sadd(status_key, task_id)
            
            logger.info(f"Task {task_id} submitted to queue for agent {agent_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to submit task: {e}")
            return False
    
    def get_task(self, agent_id: str, timeout: int = 0) -> Optional[Dict[str, Any]]:
        """
        从队列获取任务（阻塞或非阻塞）
        
        Args:
            agent_id: Agent ID
            timeout: 超时时间（秒），0表示不等待
        
        Returns:
            任务字典，如果没有任务则返回 None
        """
        try:
            queue_key = self._get_queue_key(agent_id)
            
            if timeout > 0:
                # 阻塞式获取
                result = self.redis_client.brpop(queue_key, timeout=timeout)
                if not result:
                    return None
                task_id = result[1]
            else:
                # 非阻塞式获取
                task_id = self.redis_client.rpop(queue_key)
                if not task_id:
                    return None
            
            # 获取任务详情
            task_dict = self.get_task_by_id(task_id, agent_id)
            if not task_dict:
                return None
            
            # 更新任务状态为处理中
            if task_dict.get("status") == PENDING:
                self._update_task_status_internal(task_dict, PROCESSING)
            
            return task_dict
        except Exception as e:
            logger.error(f"Failed to get task for agent {agent_id}: {e}")
            return None
    
    def get_task_by_id(self, task_id: str, agent_id: str) -> Optional[Dict[str, Any]]:
        """
        根据任务ID获取任务
        
        Args:
            task_id: 任务ID
            agent_id: Agent ID
        
        Returns:
            任务字典，如果不存在则返回 None
        """
        try:
            task_key = self._get_task_key(task_id)
            task_data = self.redis_client.get(task_key)
            if not task_data:
                return None
            
            task_dict = json.loads(task_data)
            
            # 验证 agent_id 是否匹配
            if task_dict.get("agent_id") != agent_id:
                logger.warning(f"Task {task_id} does not belong to agent {agent_id}")
                return None
            
            return task_dict
        except Exception as e:
            logger.error(f"Failed to get task {task_id}: {e}")
            return None
    
    def update_task_status(
        self,
        task_id: str,
        agent_id: str,
        status: int,
        result: Optional[Dict[str, Any]] = None,
        error_message: Optional[str] = None
    ) -> bool:
        """
        更新任务状态
        
        Args:
            task_id: 任务ID
            agent_id: Agent ID
            status: 新状态（proto TaskStatus 枚举值）
            result: 任务结果（可选）
            error_message: 错误信息（可选）
        
        Returns:
            是否成功
        """
        try:
            task_dict = self.get_task_by_id(task_id, agent_id)
            if not task_dict:
                return False
            
            old_status = task_dict.get("status", PENDING)
            task_dict["status"] = status
            task_dict["updated_at"] = int(time.time())
            if result is not None:
                task_dict["result"] = result
            if error_message is not None:
                task_dict["error_message"] = error_message
            
            # 更新 Redis 中的任务数据
            task_key = self._get_task_key(task_id)
            task_data = json.dumps(task_dict)
            self.redis_client.set(task_key, task_data, ex=settings.TASK_RESULT_EXPIRES)
            
            # 更新状态集合
            if old_status != status:
                old_status_key = self._get_task_status_key(agent_id, old_status)
                new_status_key = self._get_task_status_key(agent_id, status)
                self.redis_client.srem(old_status_key, task_id)
                self.redis_client.sadd(new_status_key, task_id)
            
            logger.info(f"Task {task_id} status updated to {status}")
            return True
        except Exception as e:
            logger.error(f"Failed to update task {task_id} status: {e}")
            return False
    
    def list_tasks(
        self,
        agent_id: str,
        status: Optional[int] = None,
        limit: int = 100,
        offset: int = 0
    ) -> tuple[List[Dict[str, Any]], int]:
        """
        列出任务
        
        Args:
            agent_id: Agent ID
            status: 任务状态（可选，None 表示所有状态）
            limit: 限制数量
            offset: 偏移量
        
        Returns:
            (任务列表, 总数)
        """
        try:
            if status is not None:
                # 从状态集合获取
                status_key = self._get_task_status_key(agent_id, status)
                task_ids = list(self.redis_client.smembers(status_key))
            else:
                # 获取所有任务（通过扫描）
                pattern = f"{self.task_prefix}:task:*"
                task_ids = []
                for key in self.redis_client.scan_iter(match=pattern):
                    task_data = self.redis_client.get(key)
                    if task_data:
                        task_dict = json.loads(task_data)
                        if task_dict.get("agent_id") == agent_id:
                            task_ids.append(task_dict.get("task_id"))
            
            # 分页
            total = len(task_ids)
            task_ids = task_ids[offset:offset + limit]
            
            # 获取任务详情
            tasks = []
            for task_id in task_ids:
                task_dict = self.get_task_by_id(task_id, agent_id)
                if task_dict:
                    tasks.append(task_dict)
            
            return tasks, total
        except Exception as e:
            logger.error(f"Failed to list tasks for agent {agent_id}: {e}")
            return [], 0
    
    def create_queue(self, agent_id: str) -> bool:
        """
        创建 agent 私有任务队列（根据 agentID 路由）
        
        Args:
            agent_id: Agent ID
        
        Returns:
            是否成功（如果队列已存在也返回 True）
        """
        try:
            # 初始化状态集合（如果不存在）
            for status in [PENDING, PROCESSING, COMPLETED, FAILED]:
                status_key = self._get_task_status_key(agent_id, status)
                # 创建空集合（如果不存在）
                self.redis_client.sadd(status_key, "placeholder")
                self.redis_client.srem(status_key, "placeholder")
            
            # 初始化队列（如果不存在）
            queue_key = self._get_queue_key(agent_id)
            # 队列会在第一次添加任务时自动创建，这里只是确保键存在
            self.redis_client.exists(queue_key)
            
            logger.info(f"Queue created/verified for agent {agent_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to create queue for agent {agent_id}: {e}")
            return False
    
    def get_queue_info(self, agent_id: str) -> Dict[str, Any]:
        """
        获取队列信息（根据 agentID 路由）
        
        Args:
            agent_id: Agent ID
        
        Returns:
            队列信息字典，包含各状态的任务数量
        """
        try:
            info = {
                "agent_id": agent_id,
                "pending_count": 0,
                "processing_count": 0,
                "completed_count": 0,
                "failed_count": 0,
                "total_count": 0,
            }
            
            # 统计各状态的任务数量
            status_map = {
                PENDING: "pending_count",
                PROCESSING: "processing_count",
                COMPLETED: "completed_count",
                FAILED: "failed_count",
            }
            
            for status, key in status_map.items():
                status_key = self._get_task_status_key(agent_id, status)
                count = self.redis_client.scard(status_key)
                info[key] = count
                info["total_count"] += count
            
            return info
        except Exception as e:
            logger.error(f"Failed to get queue info for agent {agent_id}: {e}")
            return {
                "agent_id": agent_id,
                "pending_count": 0,
                "processing_count": 0,
                "completed_count": 0,
                "failed_count": 0,
                "total_count": 0,
            }
    
    def _update_task_status_internal(self, task_dict: Dict[str, Any], status: int):
        """内部方法：更新任务状态（不更新 Redis）"""
        old_status = task_dict.get("status", PENDING)
        task_dict["status"] = status
        task_dict["updated_at"] = int(time.time())
        
        # 更新状态集合
        agent_id = task_dict["agent_id"]
        task_id = task_dict["task_id"]
        old_status_key = self._get_task_status_key(agent_id, old_status)
        new_status_key = self._get_task_status_key(agent_id, status)
        self.redis_client.srem(old_status_key, task_id)
        self.redis_client.sadd(new_status_key, task_id)
    
    def delete_task(self, task_id: str, agent_id: str) -> bool:
        """
        删除任务
        
        Args:
            task_id: 任务ID
            agent_id: Agent ID
        
        Returns:
            是否成功
        """
        try:
            task_dict = self.get_task_by_id(task_id, agent_id)
            if not task_dict:
                return False
            
            status = task_dict.get("status", PENDING)
            
            # 从状态集合中删除
            status_key = self._get_task_status_key(agent_id, status)
            self.redis_client.srem(status_key, task_id)
            
            # 从队列中删除（如果还在队列中）
            queue_key = self._get_queue_key(agent_id)
            self.redis_client.lrem(queue_key, 0, task_id)
            
            # 删除任务详情
            task_key = self._get_task_key(task_id)
            self.redis_client.delete(task_key)
            
            logger.info(f"Task {task_id} deleted for agent {agent_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete task {task_id}: {e}")
            return False
    
    def clear_queue(self, agent_id: str, status: Optional[int] = None) -> int:
        """
        清空队列
        
        Args:
            agent_id: Agent ID
            status: 任务状态（可选，None 表示清空所有状态）
        
        Returns:
            清空的任务数量
        """
        try:
            if status is not None:
                # 清空指定状态的任务
                status_key = self._get_task_status_key(agent_id, status)
                task_ids = list(self.redis_client.smembers(status_key))
                for task_id in task_ids:
                    self.delete_task(task_id, agent_id)
                return len(task_ids)
            else:
                # 清空所有状态的任务
                total = 0
                for status in [PENDING, PROCESSING, COMPLETED, FAILED]:
                    status_key = self._get_task_status_key(agent_id, status)
                    task_ids = list(self.redis_client.smembers(status_key))
                    for task_id in task_ids:
                        if self.delete_task(task_id, agent_id):
                            total += 1
                return total
        except Exception as e:
            logger.error(f"Failed to clear queue for agent {agent_id}: {e}")
            return 0


# 全局队列管理器实例
queue_manager = QueueManager()

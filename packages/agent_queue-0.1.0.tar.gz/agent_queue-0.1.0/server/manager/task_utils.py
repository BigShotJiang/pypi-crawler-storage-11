"""Task 工具函数 - 处理 proto Task 和字典之间的转换"""
import json
import time
import uuid
from typing import Any, Dict, Optional

try:
    from proto import queue_service_pb2
except ImportError:
    queue_service_pb2 = None


def task_to_dict(task) -> Dict[str, Any]:
    """将 proto Task 转换为字典"""
    if queue_service_pb2 is None:
        raise ImportError("proto module not found. Please generate gRPC code first.")
    
    # 解析 payload
    payload = {}
    if task.payload:
        try:
            payload = json.loads(task.payload)
        except json.JSONDecodeError:
            payload = {"raw": task.payload}
    
    # 解析 result
    result = None
    if task.result:
        try:
            result = json.loads(task.result)
        except json.JSONDecodeError:
            result = None
    
    return {
        "task_id": task.task_id,
        "agent_id": task.agent_id,
        "task_type": task.task_type,
        "payload": payload,
        "status": task.status,
        "created_at": task.created_at,
        "updated_at": task.updated_at,
        "result": result,
        "error_message": task.error_message if task.error_message else None,
    }


def dict_to_proto_task(task_dict: Dict[str, Any]) -> Any:
    """从字典创建 proto Task"""
    if queue_service_pb2 is None:
        raise ImportError("proto module not found. Please generate gRPC code first.")
    
    # 序列化 payload
    payload = task_dict.get("payload", {})
    payload_str = json.dumps(payload) if isinstance(payload, dict) else str(payload)
    
    # 序列化 result
    result = task_dict.get("result")
    result_str = json.dumps(result) if result and isinstance(result, dict) else (result or "")
    
    # 获取状态（可能是枚举值或整数）
    status = task_dict.get("status", 0)
    if isinstance(status, int):
        proto_status = status
    else:
        # 如果是枚举，转换为整数值
        proto_status = status.value if hasattr(status, 'value') else status
    
    return queue_service_pb2.Task(
        task_id=task_dict.get("task_id", str(uuid.uuid4())),
        agent_id=task_dict["agent_id"],
        task_type=task_dict["task_type"],
        payload=payload_str,
        status=proto_status,
        created_at=task_dict.get("created_at", int(time.time())),
        updated_at=task_dict.get("updated_at", int(time.time())),
        result=result_str,
        error_message=task_dict.get("error_message") or "",
    )


def update_task_status_in_dict(task_dict: Dict[str, Any], status: int, result: Optional[Dict[str, Any]] = None, error_message: Optional[str] = None) -> Dict[str, Any]:
    """更新任务状态（在字典中）"""
    task_dict["status"] = status
    task_dict["updated_at"] = int(time.time())
    if result is not None:
        task_dict["result"] = result
    if error_message is not None:
        task_dict["error_message"] = error_message
    return task_dict


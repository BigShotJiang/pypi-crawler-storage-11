"""队列管理器模块"""
from server.manager.queue_manager import QueueManager, queue_manager

__all__ = ["QueueManager", "queue_manager"]


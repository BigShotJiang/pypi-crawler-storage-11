"""gRPC 服务实现"""
import json
import logging
from typing import Optional
import grpc
from concurrent import futures

# 注意：需要先运行 python -m grpc_tools.protoc 生成 Python 代码
# 这里假设生成的代码在 interface 目录下
try:
    from proto import queue_service_pb2, queue_service_pb2_grpc
except ImportError:
    # 如果还没有生成，先创建一个占位符
    logging.warning("gRPC generated code not found. Please run: python -m grpc_tools.protoc --python_out=. --grpc_python_out=. -I. proto/queue_service.proto")
    queue_service_pb2 = None
    queue_service_pb2_grpc = None

from server.config.settings import settings
from server.manager.queue_manager import queue_manager

logger = logging.getLogger(__name__)


class QueueServiceServicer(queue_service_pb2_grpc.QueueServiceServicer if queue_service_pb2_grpc else object):
    """队列服务实现"""
    
    def _task_dict_to_proto(self, task_dict: dict) -> queue_service_pb2.Task:
        """将任务字典转换为 proto 消息"""
        # 处理 payload
        payload = task_dict.get("payload", {})
        payload_str = json.dumps(payload) if isinstance(payload, dict) else str(payload)
        
        # 处理 result
        result = task_dict.get("result")
        result_str = json.dumps(result) if result and isinstance(result, dict) else (result or "")
        
        # 处理任务类型
        # 如果字典中有 type 字段（枚举值），直接使用；否则根据 task_type 字符串推断
        task_type_enum = task_dict.get("type")
        if task_type_enum is None:
            # 根据 task_type 字符串推断枚举值
            task_type_str = task_dict.get("task_type", "unknown")
            type_map = {
                "unknown": queue_service_pb2.UNKNOWN,
                "data_processing": queue_service_pb2.DATA_PROCESSING,
                "image_processing": queue_service_pb2.IMAGE_PROCESSING,
                "text_analysis": queue_service_pb2.TEXT_ANALYSIS,
                "model_inference": queue_service_pb2.MODEL_INFERENCE,
                "data_extraction": queue_service_pb2.DATA_EXTRACTION,
                "file_upload": queue_service_pb2.FILE_UPLOAD,
                "file_download": queue_service_pb2.FILE_DOWNLOAD,
                "api_call": queue_service_pb2.API_CALL,
                "database_query": queue_service_pb2.DATABASE_QUERY,
            }
            task_type_enum = type_map.get(task_type_str, queue_service_pb2.CUSTOM)
        
        task_type_str = task_dict.get("task_type", "")
        
        return queue_service_pb2.Task(
            task_id=task_dict.get("task_id", ""),
            agent_id=task_dict.get("agent_id", ""),
            type=task_type_enum,
            task_type=task_type_str,
            payload=payload_str,
            status=task_dict.get("status", queue_service_pb2.PENDING),
            created_at=task_dict.get("created_at", 0),
            updated_at=task_dict.get("updated_at", 0),
            result=result_str,
            error_message=task_dict.get("error_message") or "",
        )
    
    
    def UpdateTaskStatus(
        self,
        request: queue_service_pb2.UpdateTaskStatusRequest,
        context
    ) -> queue_service_pb2.UpdateTaskStatusResponse:
        """更新任务状态"""
        try:
            # 解析 result
            result = None
            if request.result:
                try:
                    result = json.loads(request.result)
                except json.JSONDecodeError:
                    result = {"raw": request.result}
            
            success = queue_manager.update_task_status(
                request.task_id,
                request.agent_id,
                request.status,  # 直接使用 proto 的状态值（整数）
                result=result,
                error_message=request.error_message if request.error_message else None
            )
            
            if success:
                return queue_service_pb2.UpdateTaskStatusResponse(
                    success=True,
                    message="Task status updated successfully"
                )
            else:
                return queue_service_pb2.UpdateTaskStatusResponse(
                    success=False,
                    message="Task not found or update failed"
                )
        except Exception as e:
            logger.error(f"Failed to update task status: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            return queue_service_pb2.UpdateTaskStatusResponse(
                success=False,
                message=f"Failed to update task status: {str(e)}"
            )
    
    def QueryTask(self, request: queue_service_pb2.QueryTaskRequest, context) -> queue_service_pb2.QueryTaskResponse:
        """查询任务"""
        try:
            task_dict = queue_manager.get_task_by_id(request.task_id, request.agent_id)
            
            if not task_dict:
                return queue_service_pb2.QueryTaskResponse(
                    success=False,
                    task=queue_service_pb2.Task(),
                    message="Task not found"
                )
            
            return queue_service_pb2.QueryTaskResponse(
                success=True,
                task=self._task_dict_to_proto(task_dict),
                message="Task found"
            )
        except Exception as e:
            logger.error(f"Failed to query task: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            return queue_service_pb2.QueryTaskResponse(
                success=False,
                task=queue_service_pb2.Task(),
                message=f"Failed to query task: {str(e)}"
            )
    
    def CreateQueue(self, request: queue_service_pb2.CreateQueueRequest, context) -> queue_service_pb2.CreateQueueResponse:
        """
        创建 agent 私有任务队列（根据 agentID 路由）
        
        根据 agentID 路由找到对应的私有化任务队列，如果不存在则创建。
        """
        try:
            success = queue_manager.create_queue(request.agent_id)
            
            if success:
                return queue_service_pb2.CreateQueueResponse(
                    success=True,
                    agent_id=request.agent_id,
                    message=f"Queue created/verified for agent {request.agent_id}"
                )
            else:
                return queue_service_pb2.CreateQueueResponse(
                    success=False,
                    agent_id=request.agent_id,
                    message=f"Failed to create queue for agent {request.agent_id}"
                )
        except Exception as e:
            logger.error(f"Failed to create queue: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            return queue_service_pb2.CreateQueueResponse(
                success=False,
                agent_id=request.agent_id,
                message=f"Failed to create queue: {str(e)}"
            )
    
    def GetQueueInfo(self, request: queue_service_pb2.GetQueueInfoRequest, context) -> queue_service_pb2.GetQueueInfoResponse:
        """
        获取队列信息（根据 agentID 路由）
        
        根据 agentID 路由找到对应的私有化任务队列，返回队列统计信息。
        """
        try:
            info = queue_manager.get_queue_info(request.agent_id)
            
            return queue_service_pb2.GetQueueInfoResponse(
                success=True,
                agent_id=info["agent_id"],
                pending_count=info["pending_count"],
                processing_count=info["processing_count"],
                completed_count=info["completed_count"],
                failed_count=info["failed_count"],
                message="Queue info retrieved successfully"
            )
        except Exception as e:
            logger.error(f"Failed to get queue info: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            return queue_service_pb2.GetQueueInfoResponse(
                success=False,
                agent_id=request.agent_id,
                pending_count=0,
                processing_count=0,
                completed_count=0,
                failed_count=0,
                message=f"Failed to get queue info: {str(e)}"
            )
    
    def SubmitTask(self, request: queue_service_pb2.SubmitTaskRequest, context) -> queue_service_pb2.SubmitTaskResponse:
        """
        提交任务到某个 agent 的私有化任务队列（根据 agentID 路由）
        
        根据 agentID 路由找到对应的私有化任务队列，然后添加任务。
        """
        try:
            # 确保队列存在（如果不存在则创建）
            queue_manager.create_queue(request.agent_id)
            
            # 解析 payload
            try:
                payload = json.loads(request.payload) if request.payload else {}
            except json.JSONDecodeError:
                payload = {"raw": request.payload}
            
            # 创建任务字典
            # 处理任务类型：如果 type 是 CUSTOM，使用 task_type 字符串；否则使用枚举值
            task_type_str = None
            if request.type == queue_service_pb2.CUSTOM:
                task_type_str = request.task_type if request.task_type else "custom"
            else:
                # 将枚举值转换为字符串名称
                type_names = {
                    queue_service_pb2.UNKNOWN: "unknown",
                    queue_service_pb2.DATA_PROCESSING: "data_processing",
                    queue_service_pb2.IMAGE_PROCESSING: "image_processing",
                    queue_service_pb2.TEXT_ANALYSIS: "text_analysis",
                    queue_service_pb2.MODEL_INFERENCE: "model_inference",
                    queue_service_pb2.DATA_EXTRACTION: "data_extraction",
                    queue_service_pb2.FILE_UPLOAD: "file_upload",
                    queue_service_pb2.FILE_DOWNLOAD: "file_download",
                    queue_service_pb2.API_CALL: "api_call",
                    queue_service_pb2.DATABASE_QUERY: "database_query",
                }
                task_type_str = type_names.get(request.type, "unknown")
            
            task_dict = {
                "agent_id": request.agent_id,
                "type": request.type,  # 保存枚举值
                "task_type": task_type_str,  # 保存字符串类型
                "payload": payload,
                "status": queue_service_pb2.PENDING,
            }
            
            # 提交任务
            success = queue_manager.submit_task(task_dict)
            if not success:
                raise Exception("Failed to submit task")
            task_id = task_dict.get("task_id")
            
            return queue_service_pb2.SubmitTaskResponse(
                success=True,
                task_id=task_id,
                message="Task submitted successfully"
            )
        except Exception as e:
            logger.error(f"Failed to submit task: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            return queue_service_pb2.SubmitTaskResponse(
                success=False,
                task_id="",
                message=f"Failed to submit task: {str(e)}"
            )
    
    def GetTask(self, request: queue_service_pb2.GetTaskRequest, context) -> queue_service_pb2.GetTaskResponse:
        """
        从某个 agent 的私有化任务队列获取任务（根据 agentID 路由，主动拉取）
        
        根据 agentID 路由找到对应的私有化任务队列，然后从队列中获取任务。
        """
        try:
            task_dict = queue_manager.get_task(request.agent_id, timeout=request.timeout)
            
            if not task_dict:
                return queue_service_pb2.GetTaskResponse(
                    success=False,
                    task=queue_service_pb2.Task(),
                    message="No task available"
                )
            
            return queue_service_pb2.GetTaskResponse(
                success=True,
                task=self._task_dict_to_proto(task_dict),
                message="Task retrieved successfully"
            )
        except Exception as e:
            logger.error(f"Failed to get task: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            return queue_service_pb2.GetTaskResponse(
                success=False,
                task=queue_service_pb2.Task(),
                message=f"Failed to get task: {str(e)}"
            )
    
    def ListTasks(self, request: queue_service_pb2.ListTasksRequest, context) -> queue_service_pb2.ListTasksResponse:
        """
        列出某个 agent 的私有化任务队列中的所有任务（根据 agentID 路由）
        
        根据 agentID 路由找到对应的私有化任务队列，然后列出队列中的任务。
        """
        try:
            status = None
            if request.status != 0:  # 0 表示所有状态
                status = request.status  # 直接使用 proto 的状态值（整数）
            
            tasks, total = queue_manager.list_tasks(
                request.agent_id,
                status=status,
                limit=request.limit if request.limit > 0 else 100,
                offset=request.offset
            )
            
            proto_tasks = [self._task_dict_to_proto(task_dict) for task_dict in tasks]
            
            return queue_service_pb2.ListTasksResponse(
                success=True,
                tasks=proto_tasks,
                total=total,
                message=f"Found {total} tasks"
            )
        except Exception as e:
            logger.error(f"Failed to list tasks: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(e))
            return queue_service_pb2.ListTasksResponse(
                success=False,
                tasks=[],
                total=0,
                message=f"Failed to list tasks: {str(e)}"
            )


def serve():
    """启动 gRPC 服务器"""
    if queue_service_pb2_grpc is None:
        logger.error("gRPC generated code not found. Please generate it first.")
        return
    
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    queue_service_pb2_grpc.add_QueueServiceServicer_to_server(
        QueueServiceServicer(), server
    )
    
    listen_addr = f"{settings.GRPC_HOST}:{settings.GRPC_PORT}"
    server.add_insecure_port(listen_addr)
    server.start()
    
    logger.info(f"gRPC server started on {listen_addr}")
    
    try:
        server.wait_for_termination()
    except KeyboardInterrupt:
        logger.info("Shutting down gRPC server...")
        server.stop(0)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    serve()


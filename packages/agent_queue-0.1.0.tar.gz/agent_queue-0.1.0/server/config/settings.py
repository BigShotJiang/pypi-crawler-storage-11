"""服务端配置 - 从 YAML 文件加载配置"""
import os
from pathlib import Path
from typing import Optional
import yaml


class Settings:
    """应用配置"""
    
    def __init__(self):
        """初始化配置，从 YAML 文件加载"""
        # 获取配置文件路径
        config_dir = Path(__file__).parent
        redis_config_path = config_dir / "redis.yaml"
        celery_config_path = config_dir / "celery.yaml"
        
        # 加载 Redis 配置
        self._load_redis_config(redis_config_path)
        
        # 加载 Celery 配置
        self._load_celery_config(celery_config_path)
        
        # gRPC 配置（从环境变量读取）
        self.GRPC_HOST: str = os.getenv("GRPC_HOST", "0.0.0.0")
        self.GRPC_PORT: int = int(os.getenv("GRPC_PORT", "50051"))
        
        # 任务队列配置
        self.TASK_PREFIX: str = "agent_queue"  # 队列前缀
        self.TASK_RESULT_EXPIRES: int = 3600 * 24  # 任务结果过期时间（秒），默认24小时
        
        # 日志配置
        self.LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    
    def _load_redis_config(self, config_path: Path):
        """加载 Redis 配置"""
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
                redis_config = config.get("redis", {})
                
                # 优先使用环境变量，其次使用 YAML 配置
                self.REDIS_HOST: str = os.getenv("REDIS_HOST", redis_config.get("host", "localhost"))
                self.REDIS_PORT: int = int(os.getenv("REDIS_PORT", redis_config.get("port", 6379)))
                self.REDIS_DB: int = int(os.getenv("REDIS_DB", redis_config.get("db", 0)))
                self.REDIS_PASSWORD: Optional[str] = os.getenv("REDIS_PASSWORD", redis_config.get("password"))
                self.REDIS_URL_ENV: Optional[str] = os.getenv("REDIS_URL", redis_config.get("url"))
        else:
            # 如果配置文件不存在，使用环境变量或默认值
            self.REDIS_HOST: str = os.getenv("REDIS_HOST", "localhost")
            self.REDIS_PORT: int = int(os.getenv("REDIS_PORT", "6379"))
            self.REDIS_DB: int = int(os.getenv("REDIS_DB", "0"))
            self.REDIS_PASSWORD: Optional[str] = os.getenv("REDIS_PASSWORD", None)
            self.REDIS_URL_ENV: Optional[str] = os.getenv("REDIS_URL", None)
    
    def _load_celery_config(self, config_path: Path):
        """加载 Celery 配置"""
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
                celery_config = config.get("celery", {})
                
                self.CELERY_TASK_SERIALIZER: str = celery_config.get("task_serializer", "json")
                self.CELERY_RESULT_SERIALIZER: str = celery_config.get("result_serializer", "json")
                self.CELERY_ACCEPT_CONTENT: list = celery_config.get("accept_content", ["json"])
                self.CELERY_TIMEZONE: str = celery_config.get("timezone", "UTC")
                self.CELERY_ENABLE_UTC: bool = celery_config.get("enable_utc", True)
                self.CELERY_TASK_TRACK_STARTED: bool = celery_config.get("task_track_started", True)
                self.CELERY_TASK_TIME_LIMIT: int = celery_config.get("task_time_limit", 30 * 60)
                self.CELERY_TASK_SOFT_TIME_LIMIT: int = celery_config.get("task_soft_time_limit", 25 * 60)
                self.CELERY_RESULT_EXPIRES: int = celery_config.get("result_expires", 3600 * 24)
        else:
            # 如果配置文件不存在，使用默认值
            self.CELERY_TASK_SERIALIZER: str = "json"
            self.CELERY_RESULT_SERIALIZER: str = "json"
            self.CELERY_ACCEPT_CONTENT: list = ["json"]
            self.CELERY_TIMEZONE: str = "UTC"
            self.CELERY_ENABLE_UTC: bool = True
            self.CELERY_TASK_TRACK_STARTED: bool = True
            self.CELERY_TASK_TIME_LIMIT: int = 30 * 60
            self.CELERY_TASK_SOFT_TIME_LIMIT: int = 25 * 60
            self.CELERY_RESULT_EXPIRES: int = 3600 * 24
    
    @property
    def REDIS_URL(self) -> str:
        """Redis URL"""
        # 优先使用环境变量或 YAML 中的 URL
        if hasattr(self, 'REDIS_URL_ENV') and self.REDIS_URL_ENV:
            return self.REDIS_URL_ENV
        
        # 否则根据配置构建 URL
        if self.REDIS_PASSWORD:
            return f"redis://:{self.REDIS_PASSWORD}@{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"
        return f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"


settings = Settings()

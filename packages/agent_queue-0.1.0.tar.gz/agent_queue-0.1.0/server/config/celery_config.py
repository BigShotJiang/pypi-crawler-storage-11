"""Celery 配置 - 从 settings 读取配置"""
from server.config.settings import settings

def get_celery_config():
    """获取 Celery 配置字典"""
    return {
        "broker_url": settings.REDIS_URL,
        "result_backend": settings.REDIS_URL,
        "task_serializer": settings.CELERY_TASK_SERIALIZER,
        "result_serializer": settings.CELERY_RESULT_SERIALIZER,
        "accept_content": settings.CELERY_ACCEPT_CONTENT,
        "timezone": settings.CELERY_TIMEZONE,
        "enable_utc": settings.CELERY_ENABLE_UTC,
        "task_track_started": settings.CELERY_TASK_TRACK_STARTED,
        "task_time_limit": settings.CELERY_TASK_TIME_LIMIT,
        "task_soft_time_limit": settings.CELERY_TASK_SOFT_TIME_LIMIT,
        "result_expires": settings.CELERY_RESULT_EXPIRES,
    }

# 为了向后兼容，保留 celery_config 变量
celery_config = get_celery_config()


"""
GradLens Pro Analytics Module

Enterprise-grade analytics and monitoring for deep learning models.
Supports all major neural network architectures with comprehensive insights.

Features:
- Real-time model analysis
- Advanced statistical insights
- Performance profiling
- Health monitoring
- Architecture detection
- Multi-level analysis depth
"""

from .._version import __version__ as _package_version

from .analytics_engine import (
    AnalyticsEngine,
    ModelStatistics,
    LayerStatistics,
    ArchitectureType,
    MetricType,
    AnalysisLevel,
    create_analytics_engine,
    quick_analysis,
)

from .visualization_engine import (
    VisualizationEngine,
    DashboardConfig,
    PlotConfig,
    PlotType,
    DashboardTheme,
    create_visualization_engine,
    quick_visualization,
)

from .experiment_tracker import (
    ExperimentTracker,
    ExperimentConfig,
    RunMetadata,
    HyperparameterConfig,
    create_experiment_tracker,
    quick_experiment_start,
)

from .performance_profiler import (
    PerformanceProfiler,
    ProfilerConfig,
    PerformanceMetrics,
    ProfilerMode,
    create_performance_profiler,
    profile_model,
    quick_profile,
)

from .model_insights import (
    ModelInsights,
    ArchitectureAnalyzer,
    BottleneckDetector,
    Insight,
    InsightType,
    SeverityLevel,
    create_model_insights,
    quick_insights,
)

# Export Manager is now in the main gradlens module

__all__ = [
    # Analytics Engine
    "AnalyticsEngine",
    "ModelStatistics",
    "LayerStatistics",
    "ArchitectureType",
    "MetricType",
    "AnalysisLevel",
    "create_analytics_engine",
    "quick_analysis",
    # Visualization
    "VisualizationEngine",
    "DashboardConfig",
    "PlotConfig",
    "PlotType",
    "DashboardTheme",
    "create_visualization_engine",
    "quick_visualization",
    # Experiment Tracking
    "ExperimentTracker",
    "ExperimentConfig",
    "RunMetadata",
    "HyperparameterConfig",
    "create_experiment_tracker",
    "quick_experiment_start",
    # Performance
    "PerformanceProfiler",
    "ProfilerConfig",
    "PerformanceMetrics",
    "ProfilerMode",
    "create_performance_profiler",
    "profile_model",
    "quick_profile",
    # Model Insights
    "ModelInsights",
    "ArchitectureAnalyzer",
    "BottleneckDetector",
    "Insight",
    "InsightType",
    "SeverityLevel",
    "create_model_insights",
    "quick_insights",
    # Export Manager is now in the main gradlens module
]

__version__ = _package_version
__author__ = "GradLens Team"

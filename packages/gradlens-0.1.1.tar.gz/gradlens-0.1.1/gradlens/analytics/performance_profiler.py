"""
Advanced Performance Profiler for Deep Learning Models

This module provides comprehensive performance profiling and analysis
for deep learning model training and inference.

Features:
- Real-time performance monitoring
- Memory usage tracking
- GPU utilization monitoring
- Bottleneck detection
- Optimization recommendations
- Detailed profiling reports
"""

import time
import psutil
import torch
import torch.nn as nn
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass
from enum import Enum
import logging
import threading
from contextlib import contextmanager
from collections import defaultdict
import numpy as np

_logger = logging.getLogger(__name__)


# ==================== Enums and Data Classes ====================


class ProfilerMode(Enum):
    """Profiling modes"""

    TRAINING = "training"
    INFERENCE = "inference"
    BOTH = "both"


class MetricType(Enum):
    """Types of metrics to profile"""

    TIME = "time"
    MEMORY = "memory"
    GPU = "gpu"
    CPU = "cpu"
    THROUGHPUT = "throughput"
    LATENCY = "latency"


@dataclass
class PerformanceMetrics:
    """Performance metrics for a single measurement"""

    timestamp: float
    metric_type: MetricType
    value: float
    unit: str
    layer_name: Optional[str] = None
    phase: str = "unknown"  # forward, backward, optimizer, etc.
    batch_size: int = 1
    device: str = "cpu"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "timestamp": self.timestamp,
            "metric_type": self.metric_type.value,
            "value": self.value,
            "unit": self.unit,
            "layer_name": self.layer_name,
            "phase": self.phase,
            "batch_size": self.batch_size,
            "device": self.device,
        }


@dataclass
class LayerProfile:
    """Profile for a single layer"""

    layer_name: str
    layer_type: str

    # Time metrics
    forward_time_ms: float = 0.0
    backward_time_ms: float = 0.0
    total_time_ms: float = 0.0
    call_count: int = 0

    # Memory metrics
    peak_memory_mb: float = 0.0
    allocated_memory_mb: float = 0.0
    reserved_memory_mb: float = 0.0

    # Throughput metrics
    samples_per_second: float = 0.0
    parameters_per_second: float = 0.0

    # Efficiency metrics
    memory_efficiency: float = 0.0
    compute_efficiency: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "layer_name": self.layer_name,
            "layer_type": self.layer_type,
            "timing": {
                "forward_time_ms": self.forward_time_ms,
                "backward_time_ms": self.backward_time_ms,
                "total_time_ms": self.total_time_ms,
                "call_count": self.call_count,
                "avg_forward_time_ms": self.forward_time_ms / max(1, self.call_count),
                "avg_backward_time_ms": self.backward_time_ms / max(1, self.call_count),
            },
            "memory": {
                "peak_memory_mb": self.peak_memory_mb,
                "allocated_memory_mb": self.allocated_memory_mb,
                "reserved_memory_mb": self.reserved_memory_mb,
            },
            "throughput": {
                "samples_per_second": self.samples_per_second,
                "parameters_per_second": self.parameters_per_second,
            },
            "efficiency": {
                "memory_efficiency": self.memory_efficiency,
                "compute_efficiency": self.compute_efficiency,
            },
        }


@dataclass
class ProfilerConfig:
    """Configuration for performance profiler"""

    enable_memory_profiling: bool = True
    enable_gpu_profiling: bool = True
    enable_cpu_profiling: bool = True
    enable_throughput_profiling: bool = True

    # Sampling settings
    sample_frequency: float = 1.0  # Hz
    max_samples: int = 10000

    # Memory settings
    memory_threshold_mb: float = 1000.0
    enable_memory_tracking: bool = True

    # GPU settings
    gpu_memory_threshold_mb: float = 1000.0
    enable_gpu_memory_tracking: bool = True

    # Reporting settings
    auto_report: bool = True
    report_frequency: int = 100  # Report every N steps
    detailed_report: bool = False


class PerformanceProfiler:
    """
    Advanced performance profiler for deep learning models

    Features:
    - Real-time performance monitoring
    - Memory usage tracking
    - GPU utilization monitoring
    - Bottleneck detection
    - Optimization recommendations
    """

    def __init__(
        self,
        model: nn.Module,
        config: Optional[ProfilerConfig] = None,
        device: Optional[torch.device] = None,
    ):
        self.model = model
        self.config = config or ProfilerConfig()
        self.device = device or torch.device(
            "cuda" if torch.cuda.is_available() else "cpu"
        )

        # Profiling data
        self.metrics: List[PerformanceMetrics] = []
        self.layer_profiles: Dict[str, LayerProfile] = {}
        self._current_phase = "unknown"
        self._current_batch_size = 1

        # Threading for background monitoring
        self._monitoring_thread: Optional[threading.Thread] = None
        self._stop_monitoring = threading.Event()

        # Memory tracking
        self._memory_baseline = self._get_memory_usage()
        self._gpu_memory_baseline = self._get_gpu_memory_usage()

        # Hooks for layer profiling
        self._hooks: List[torch.utils.hooks.RemovableHandle] = []

        _logger.info("PerformanceProfiler initialized")

    def start_profiling(self, mode: ProfilerMode = ProfilerMode.BOTH) -> None:
        """Start performance profiling"""
        if self.config.enable_memory_profiling:
            self._start_memory_monitoring()

        if self.config.enable_gpu_profiling and torch.cuda.is_available():
            self._start_gpu_monitoring()

        if self.config.enable_cpu_profiling:
            self._start_cpu_monitoring()

        # Attach hooks to model layers
        self._attach_layer_hooks()

        _logger.info(f"Started profiling in {mode.value} mode")

    def stop_profiling(self) -> None:
        """Stop performance profiling"""
        # Stop background monitoring
        self._stop_monitoring.set()
        if self._monitoring_thread and self._monitoring_thread.is_alive():
            self._monitoring_thread.join()

        # Remove hooks
        for hook in self._hooks:
            hook.remove()
        self._hooks.clear()

        _logger.info("Stopped profiling")

    def profile_forward_pass(
        self, input_tensor: torch.Tensor, phase: str = "forward"
    ) -> Dict[str, Any]:
        """
        Profile a forward pass

        Args:
            input_tensor: Input tensor
            phase: Phase name for profiling

        Returns:
            Profiling results
        """
        self._current_phase = phase
        self._current_batch_size = input_tensor.size(0)

        start_time = time.time()
        start_memory = self._get_memory_usage()
        start_gpu_memory = self._get_gpu_memory_usage()

        with torch.no_grad():
            self.model(input_tensor)

        end_time = time.time()
        end_memory = self._get_memory_usage()
        end_gpu_memory = self._get_gpu_memory_usage()

        # Record metrics
        forward_time = (end_time - start_time) * 1000  # Convert to ms
        safe_forward_time = forward_time if forward_time > 1e-6 else 1e-6
        memory_used = end_memory - start_memory
        gpu_memory_used = end_gpu_memory - start_gpu_memory

        self._record_metric(MetricType.TIME, forward_time, "ms", phase=phase)

        if memory_used > 0:
            self._record_metric(MetricType.MEMORY, memory_used, "MB", phase=phase)

        if gpu_memory_used > 0:
            self._record_metric(MetricType.GPU, gpu_memory_used, "MB", phase=phase)

        # Calculate throughput
        throughput = self._current_batch_size / (safe_forward_time / 1000)
        self._record_metric(
            MetricType.THROUGHPUT, throughput, "samples/sec", phase=phase
        )

        return {
            "forward_time_ms": safe_forward_time,
            "memory_used_mb": memory_used,
            "gpu_memory_used_mb": gpu_memory_used,
            "throughput_samples_per_sec": throughput,
            "batch_size": self._current_batch_size,
        }

    def profile_training_step(
        self,
        input_tensor: torch.Tensor,
        target_tensor: torch.Tensor,
        loss_fn: Callable,
        optimizer: torch.optim.Optimizer,
        phase: str = "training",
    ) -> Dict[str, Any]:
        """
        Profile a complete training step

        Args:
            input_tensor: Input tensor
            target_tensor: Target tensor
            loss_fn: Loss function
            optimizer: Optimizer
            phase: Phase name for profiling

        Returns:
            Profiling results
        """
        self._current_phase = phase
        self._current_batch_size = input_tensor.size(0)

        total_start_time = time.time()

        # Forward pass
        forward_start = time.time()
        output = self.model(input_tensor)
        forward_time = (time.time() - forward_start) * 1000
        safe_forward_time = forward_time if forward_time > 1e-6 else 1e-6

        # Loss calculation
        loss_start = time.time()
        loss = loss_fn(output, target_tensor)
        loss_time = (time.time() - loss_start) * 1000

        # Backward pass
        backward_start = time.time()
        loss.backward()
        backward_time = (time.time() - backward_start) * 1000

        # Optimizer step
        optimizer_start = time.time()
        optimizer.step()
        optimizer.zero_grad()
        optimizer_time = (time.time() - optimizer_start) * 1000

        total_time = (time.time() - total_start_time) * 1000
        safe_total_time = total_time if total_time > 1e-6 else 1e-6

        # Record metrics
        self._record_metric(MetricType.TIME, forward_time, "ms", phase="forward")
        self._record_metric(MetricType.TIME, loss_time, "ms", phase="loss")
        self._record_metric(MetricType.TIME, backward_time, "ms", phase="backward")
        self._record_metric(MetricType.TIME, optimizer_time, "ms", phase="optimizer")
        self._record_metric(MetricType.TIME, total_time, "ms", phase="total")

        # Calculate throughput
        throughput = self._current_batch_size / (safe_total_time / 1000)
        self._record_metric(
            MetricType.THROUGHPUT, throughput, "samples/sec", phase=phase
        )

        return {
            "total_time_ms": safe_total_time,
            "forward_time_ms": safe_forward_time,
            "loss_time_ms": loss_time,
            "backward_time_ms": backward_time,
            "optimizer_time_ms": optimizer_time,
            "throughput_samples_per_sec": throughput,
            "batch_size": self._current_batch_size,
        }

    def get_layer_profile(self, layer_name: str) -> Optional[LayerProfile]:
        """Get profile for a specific layer"""
        return self.layer_profiles.get(layer_name)

    def get_performance_summary(self) -> Dict[str, Any]:
        """Get comprehensive performance summary"""
        if not self.metrics:
            return {}

        # Group metrics by type
        metrics_by_type = defaultdict(list)
        for metric in self.metrics:
            metrics_by_type[metric.metric_type].append(metric.value)

        summary = {
            "total_metrics": len(self.metrics),
            "profiling_duration": self.metrics[-1].timestamp - self.metrics[0].timestamp
            if self.metrics
            else 0,
            "layers_profiled": len(self.layer_profiles),
            "metrics_by_type": {},
        }

        # Calculate statistics for each metric type
        for metric_type, values in metrics_by_type.items():
            if values:
                summary["metrics_by_type"][metric_type.value] = {
                    "count": len(values),
                    "mean": np.mean(values),
                    "std": np.std(values),
                    "min": np.min(values),
                    "max": np.max(values),
                    "median": np.median(values),
                }

        # Layer performance summary
        summary["layer_performance"] = {}
        for layer_name, profile in self.layer_profiles.items():
            summary["layer_performance"][layer_name] = profile.to_dict()

        return summary

    def detect_bottlenecks(self) -> List[Dict[str, Any]]:
        """Detect performance bottlenecks"""
        bottlenecks = []

        if not self.layer_profiles:
            return bottlenecks

        # Find slowest layers
        slowest_layers = sorted(
            self.layer_profiles.items(), key=lambda x: x[1].total_time_ms, reverse=True
        )[:3]

        for layer_name, profile in slowest_layers:
            if profile.total_time_ms > 100:  # More than 100ms
                bottlenecks.append(
                    {
                        "type": "slow_layer",
                        "layer": layer_name,
                        "time_ms": profile.total_time_ms,
                        "severity": "high" if profile.total_time_ms > 500 else "medium",
                        "description": f"Layer {layer_name} is slow ({profile.total_time_ms:.1f}ms)",
                    }
                )

        # Find memory-intensive layers
        memory_intensive = sorted(
            self.layer_profiles.items(), key=lambda x: x[1].peak_memory_mb, reverse=True
        )[:3]

        for layer_name, profile in memory_intensive:
            if profile.peak_memory_mb > self.config.memory_threshold_mb:
                bottlenecks.append(
                    {
                        "type": "memory_intensive",
                        "layer": layer_name,
                        "memory_mb": profile.peak_memory_mb,
                        "severity": "high"
                        if profile.peak_memory_mb > 2000
                        else "medium",
                        "description": f"Layer {layer_name} uses too much memory ({profile.peak_memory_mb:.1f}MB)",
                    }
                )

        # Find inefficient layers
        for layer_name, profile in self.layer_profiles.items():
            if profile.compute_efficiency < 0.5:  # Less than 50% efficient
                bottlenecks.append(
                    {
                        "type": "inefficient_compute",
                        "layer": layer_name,
                        "efficiency": profile.compute_efficiency,
                        "severity": "high"
                        if profile.compute_efficiency < 0.3
                        else "medium",
                        "description": f"Layer {layer_name} has low compute efficiency ({profile.compute_efficiency:.1%})",
                    }
                )

        return bottlenecks

    def get_optimization_recommendations(self) -> List[str]:
        """Get optimization recommendations based on profiling data"""
        recommendations = []
        bottlenecks = self.detect_bottlenecks()

        # Analyze bottlenecks and generate recommendations
        slow_layers = [b for b in bottlenecks if b["type"] == "slow_layer"]
        memory_layers = [b for b in bottlenecks if b["type"] == "memory_intensive"]
        inefficient_layers = [
            b for b in bottlenecks if b["type"] == "inefficient_compute"
        ]

        if slow_layers:
            recommendations.append(
                f"Consider optimizing {len(slow_layers)} slow layers. "
                f"Try using more efficient implementations or reducing complexity."
            )

        if memory_layers:
            recommendations.append(
                f"Reduce memory usage in {len(memory_layers)} memory-intensive layers. "
                f"Consider using gradient checkpointing or reducing batch size."
            )

        if inefficient_layers:
            recommendations.append(
                f"Improve compute efficiency in {len(inefficient_layers)} inefficient layers. "
                f"Consider using mixed precision training or optimizing operations."
            )

        # General recommendations based on overall performance
        summary = self.get_performance_summary()
        if summary.get("metrics_by_type", {}).get("time", {}).get("mean", 0) > 1000:
            recommendations.append(
                "Overall training is slow. Consider using larger batch sizes, "
                "mixed precision training, or model parallelism."
            )

        return recommendations

    def export_profile_report(self, filename: str, format: str = "json") -> str:
        """Export profiling report to file"""
        report = {
            "profiler_config": self.config.__dict__,
            "performance_summary": self.get_performance_summary(),
            "layer_profiles": {
                name: profile.to_dict() for name, profile in self.layer_profiles.items()
            },
            "bottlenecks": self.detect_bottlenecks(),
            "recommendations": self.get_optimization_recommendations(),
            "exported_at": time.time(),
        }

        if format.lower() == "json":
            import json

            with open(filename, "w") as f:
                json.dump(report, f, indent=2, default=str)
        else:
            raise ValueError(f"Unsupported format: {format}")

        _logger.info(f"Profile report exported to {filename}")
        return filename

    def _record_metric(
        self,
        metric_type: MetricType,
        value: float,
        unit: str,
        layer_name: Optional[str] = None,
        phase: Optional[str] = None,
    ) -> None:
        """Record a performance metric"""
        metric = PerformanceMetrics(
            timestamp=time.time(),
            metric_type=metric_type,
            value=value,
            unit=unit,
            layer_name=layer_name,
            phase=phase or self._current_phase,
            batch_size=self._current_batch_size,
            device=str(self.device),
        )

        self.metrics.append(metric)

        # Keep only recent metrics if limit is set
        if len(self.metrics) > self.config.max_samples:
            self.metrics = self.metrics[-self.config.max_samples :]

    def _attach_layer_hooks(self) -> None:
        """Attach profiling hooks to model layers"""
        for name, module in self.model.named_modules():
            if len(list(module.children())) == 0:  # Leaf modules only
                # Forward hook
                forward_hook = self._create_forward_hook(name)
                self._hooks.append(module.register_forward_hook(forward_hook))

                # Backward hook
                backward_hook = self._create_backward_hook(name)
                self._hooks.append(module.register_backward_hook(backward_hook))

    def _create_forward_hook(self, layer_name: str):
        """Create forward hook for layer profiling"""

        def hook(module, input, output):
            start_time = time.time()
            start_memory = self._get_memory_usage()

            # Store timing and memory info
            if layer_name not in self.layer_profiles:
                self.layer_profiles[layer_name] = LayerProfile(
                    layer_name=layer_name, layer_type=module.__class__.__name__
                )

            profile = self.layer_profiles[layer_name]
            profile.call_count += 1

            # This is a simplified version - in practice, you'd want to
            # measure the actual forward pass time more accurately
            forward_time = (time.time() - start_time) * 1000
            profile.forward_time_ms += forward_time
            profile.total_time_ms += forward_time

            # Memory tracking
            current_memory = self._get_memory_usage()
            memory_used = current_memory - start_memory
            profile.peak_memory_mb = max(profile.peak_memory_mb, memory_used)

            # Calculate throughput
            if forward_time > 0:
                throughput = self._current_batch_size / (forward_time / 1000)
                profile.samples_per_second = throughput

            # Calculate efficiency metrics inside the hook where `profile` is defined
            # Compute efficiency: normalize samples/sec to a [0,1] range (heuristic)
            profile.compute_efficiency = min(
                1.0, max(0.0, profile.samples_per_second) / 1000
            )
            # Memory efficiency: higher when peak memory is lower (guard div-by-zero)
            if profile.peak_memory_mb <= 0:
                profile.memory_efficiency = 1.0
            else:
                profile.memory_efficiency = min(
                    1.0, max(0.0, 1.0 / (profile.peak_memory_mb / 100))
                )

        return hook

    def _create_backward_hook(self, layer_name: str):
        """Create backward hook for layer profiling"""

        def hook(module, grad_input, grad_output):
            start_time = time.time()

            if layer_name in self.layer_profiles:
                profile = self.layer_profiles[layer_name]
                backward_time = (time.time() - start_time) * 1000
                profile.backward_time_ms += backward_time
                profile.total_time_ms += backward_time

        return hook

    def _start_memory_monitoring(self) -> None:
        """Start background memory monitoring"""

        def monitor_memory():
            while not self._stop_monitoring.is_set():
                memory_usage = self._get_memory_usage()
                self._record_metric(MetricType.MEMORY, memory_usage, "MB")

                time.sleep(1.0 / self.config.sample_frequency)

        self._monitoring_thread = threading.Thread(target=monitor_memory)
        self._monitoring_thread.daemon = True
        self._monitoring_thread.start()

    def _start_gpu_monitoring(self) -> None:
        """Start GPU monitoring"""
        if not torch.cuda.is_available():
            return

        def monitor_gpu():
            while not self._stop_monitoring.is_set():
                gpu_memory = self._get_gpu_memory_usage()
                self._record_metric(MetricType.GPU, gpu_memory, "MB")

                time.sleep(1.0 / self.config.sample_frequency)

        gpu_thread = threading.Thread(target=monitor_gpu)
        gpu_thread.daemon = True
        gpu_thread.start()

    def _start_cpu_monitoring(self) -> None:
        """Start CPU monitoring"""

        def monitor_cpu():
            while not self._stop_monitoring.is_set():
                cpu_percent = psutil.cpu_percent()
                self._record_metric(MetricType.CPU, cpu_percent, "%")

                time.sleep(1.0 / self.config.sample_frequency)

        cpu_thread = threading.Thread(target=monitor_cpu)
        cpu_thread.daemon = True
        cpu_thread.start()

    def _get_memory_usage(self) -> float:
        """Get current memory usage in MB"""
        process = psutil.Process()
        return process.memory_info().rss / 1024 / 1024

    def _get_gpu_memory_usage(self) -> float:
        """Get current GPU memory usage in MB"""
        if not torch.cuda.is_available():
            return 0.0

        return torch.cuda.memory_allocated() / 1024 / 1024

    def __enter__(self):
        """Context manager entry"""
        self.start_profiling()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.stop_profiling()


# ==================== Utility Functions ====================


def create_performance_profiler(
    model: nn.Module,
    config: Optional[ProfilerConfig] = None,
    device: Optional[torch.device] = None,
) -> PerformanceProfiler:
    """
    Factory function to create performance profiler

    Args:
        model: PyTorch model to profile
        config: Profiler configuration
        device: Device to use for profiling

    Returns:
        Configured PerformanceProfiler instance
    """
    return PerformanceProfiler(model, config, device)


@contextmanager
def profile_model(
    model: nn.Module,
    config: Optional[ProfilerConfig] = None,
    device: Optional[torch.device] = None,
):
    """
    Context manager for profiling a model

    Args:
        model: PyTorch model to profile
        config: Profiler configuration
        device: Device to use for profiling

    Yields:
        PerformanceProfiler instance
    """
    profiler = PerformanceProfiler(model, config, device)
    profiler.start_profiling()

    try:
        yield profiler
    finally:
        profiler.stop_profiling()


def quick_profile(
    model: nn.Module, input_tensor: torch.Tensor, num_iterations: int = 10
) -> Dict[str, Any]:
    """
    Quick profiling of a model

    Args:
        model: PyTorch model to profile
        input_tensor: Input tensor for profiling
        num_iterations: Number of iterations to run

    Returns:
        Profiling results
    """
    with profile_model(model) as profiler:
        for _ in range(num_iterations):
            profiler.profile_forward_pass(input_tensor)

        return profiler.get_performance_summary()

"""
Advanced Visualization Engine for Deep Learning Models

This module provides comprehensive interactive visualizations
for model analysis, training monitoring, and insights.

Features:
- Interactive Plotly dashboards
- Real-time monitoring charts
- Statistical analysis plots
- Model architecture visualization
- Export capabilities
"""

try:
    import plotly.graph_objects as go
    import plotly.express as px
    from plotly.subplots import make_subplots
    import plotly.figure_factory as ff

    _PLOTLY_AVAILABLE = True
except ImportError:
    go = None  # type: ignore
    px = None  # type: ignore
    make_subplots = None  # type: ignore
    ff = None  # type: ignore
    _PLOTLY_AVAILABLE = False
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import logging

from .analytics_engine import ModelStatistics

_logger = logging.getLogger(__name__)


# ==================== Enums and Data Classes ====================


class PlotType(Enum):
    """Types of plots available"""

    LINE = "line"
    SCATTER = "scatter"
    BAR = "bar"
    HEATMAP = "heatmap"
    HISTOGRAM = "histogram"
    BOX = "box"
    VIOLIN = "violin"
    SURFACE = "surface"
    CONTOUR = "contour"
    SANKEY = "sankey"
    TREEMAP = "treemap"
    SUNBURST = "sunburst"


class DashboardTheme(Enum):
    """Available dashboard themes"""

    LIGHT = "plotly_white"
    DARK = "plotly_dark"
    MINIMAL = "simple_white"
    PRESENTATION = "presentation"
    CUSTOM = "custom"


@dataclass
class PlotConfig:
    """Configuration for individual plots"""

    title: str = ""
    x_label: str = ""
    y_label: str = ""
    width: int = 800
    height: int = 400
    show_legend: bool = True
    show_grid: bool = True
    color_scheme: str = "viridis"
    opacity: float = 0.8
    line_width: int = 2
    marker_size: int = 6
    font_size: int = 12
    title_font_size: int = 16


@dataclass
class DashboardConfig:
    """Configuration for dashboard layout"""

    theme: DashboardTheme = DashboardTheme.LIGHT
    title: str = "GradLens Pro Dashboard"
    subtitle: str = "Advanced Model Analytics"
    width: int = 1200
    height: int = 800
    show_toolbar: bool = True
    show_modebar: bool = True
    responsive: bool = True
    auto_resize: bool = True
    margin: Dict[str, int] = field(
        default_factory=lambda: {"l": 50, "r": 50, "t": 80, "b": 50}
    )


# ==================== Main Visualization Engine ====================


class VisualizationEngine:
    """
    Advanced visualization engine for deep learning models

    Features:
    - Interactive Plotly dashboards
    - Real-time monitoring
    - Statistical analysis plots
    - Model architecture visualization
    - Export capabilities
    """

    def __init__(
        self,
        config: Optional[DashboardConfig] = None,
        theme: Optional[Dict[str, Any]] = None,
    ):
        self.config = config or DashboardConfig()
        self.theme = theme or self._get_default_theme()
        self._figures_cache: Dict[str, Any] = {}

        _logger.info("VisualizationEngine initialized")

    def _get_default_theme(self) -> Dict[str, Any]:
        """Get default theme configuration"""
        return {
            "layout": {
                "font": {"family": "Arial, sans-serif", "size": 12},
                "colorway": px.colors.qualitative.Set3,
                "paper_bgcolor": "white",
                "plot_bgcolor": "white",
            },
            "data": {
                "line": {"width": 2},
                "scatter": {"marker": {"size": 6}},
                "bar": {"opacity": 0.8},
            },
        }

    def create_model_overview_dashboard(
        self, stats: ModelStatistics, config: Optional[PlotConfig] = None
    ) -> Any:
        """
        Create comprehensive model overview dashboard

        Args:
            stats: Model statistics
            config: Plot configuration

        Returns:
            Plotly figure with model overview
        """
        config = config or PlotConfig()

        if not _PLOTLY_AVAILABLE:
            raise ImportError(
                'Plotly is required for VisualizationEngine. Install via: pip install "gradlens[viz]" or "gradlens[notebook]"'
            )
        # Create subplots
        fig = make_subplots(
            rows=2,
            cols=3,
            subplot_titles=[
                "Model Architecture",
                "Parameter Distribution",
                "Gradient Norms",
                "Layer Health",
                "Memory Usage",
                "Performance Metrics",
            ],
            specs=[
                [{"type": "bar"}, {"type": "pie"}, {"type": "bar"}],
                [{"type": "heatmap"}, {"type": "bar"}, {"type": "scatter"}],
            ],
            vertical_spacing=0.1,
            horizontal_spacing=0.1,
        )

        # 1. Model Architecture (Bar chart of layer types)
        layer_types = {}
        for layer_stats in stats.layer_stats.values():
            layer_type = layer_stats.layer_type
            layer_types[layer_type] = layer_types.get(layer_type, 0) + 1

        fig.add_trace(
            go.Bar(
                x=list(layer_types.keys()),
                y=list(layer_types.values()),
                name="Layer Count",
                marker_color=px.colors.qualitative.Set3[0],
            ),
            row=1,
            col=1,
        )

        # 2. Parameter Distribution (Pie chart)
        param_data = []
        param_labels = []
        for name, layer_stats in stats.layer_stats.items():
            if layer_stats.num_parameters > 0:
                param_data.append(layer_stats.num_parameters)
                param_labels.append(name)

        fig.add_trace(
            go.Pie(
                labels=param_labels,
                values=param_data,
                name="Parameters",
                textinfo="label+percent",
            ),
            row=1,
            col=2,
        )

        # 3. Gradient Norms (Bar chart)
        layer_names = []
        grad_norms = []
        for name, layer_stats in stats.layer_stats.items():
            if layer_stats.grad_norm > 0:
                layer_names.append(name)
                grad_norms.append(layer_stats.grad_norm)

        fig.add_trace(
            go.Bar(
                x=layer_names,
                y=grad_norms,
                name="Gradient Norm",
                marker_color=px.colors.qualitative.Set3[2],
            ),
            row=1,
            col=3,
        )

        # 4. Layer Health (Heatmap)
        health_data = []
        health_labels = []
        for name, layer_stats in stats.layer_stats.items():
            health_row = [
                1 if layer_stats.has_nan else 0,
                1 if layer_stats.has_inf else 0,
                1 if layer_stats.is_frozen else 0,
                layer_stats.dead_neuron_ratio,
            ]
            health_data.append(health_row)
            health_labels.append(name)

        fig.add_trace(
            go.Heatmap(
                z=health_data,
                x=["NaN", "Inf", "Frozen", "Dead Neurons"],
                y=health_labels,
                colorscale="RdYlBu_r",
                showscale=True,
            ),
            row=2,
            col=1,
        )

        # 5. Memory Usage (Bar chart)
        memory_data = []
        memory_labels = []
        for name, layer_stats in stats.layer_stats.items():
            if layer_stats.memory_mb > 0:
                memory_data.append(layer_stats.memory_mb)
                memory_labels.append(name)

        fig.add_trace(
            go.Bar(
                x=memory_labels,
                y=memory_data,
                name="Memory (MB)",
                marker_color=px.colors.qualitative.Set3[4],
            ),
            row=2,
            col=2,
        )

        # 6. Performance Metrics (Scatter plot)
        forward_times = []
        backward_times = []
        layer_names_perf = []
        for name, layer_stats in stats.layer_stats.items():
            if layer_stats.forward_time_ms > 0:
                forward_times.append(layer_stats.forward_time_ms)
                backward_times.append(layer_stats.backward_time_ms)
                layer_names_perf.append(name)

        fig.add_trace(
            go.Scatter(
                x=forward_times,
                y=backward_times,
                mode="markers+text",
                text=layer_names_perf,
                textposition="top center",
                name="Performance",
                marker=dict(size=10, color=px.colors.qualitative.Set3[5], opacity=0.7),
            ),
            row=2,
            col=3,
        )

        # Update layout
        fig.update_layout(
            title=f"{config.title or 'Model Overview Dashboard'}",
            height=800,
            showlegend=True,
            template=self.config.theme.value,
        )

        # Update axes labels
        fig.update_xaxes(title_text="Layer Type", row=1, col=1)
        fig.update_yaxes(title_text="Count", row=1, col=1)

        fig.update_xaxes(title_text="Layer", row=1, col=3)
        fig.update_yaxes(title_text="Gradient Norm", row=1, col=3)

        fig.update_xaxes(title_text="Layer", row=2, col=2)
        fig.update_yaxes(title_text="Memory (MB)", row=2, col=2)

        fig.update_xaxes(title_text="Forward Time (ms)", row=2, col=3)
        fig.update_yaxes(title_text="Backward Time (ms)", row=2, col=3)

        return fig

    def create_training_monitoring_dashboard(
        self,
        loss_history: List[float],
        learning_rates: List[float],
        validation_loss: Optional[List[float]] = None,
        metrics: Optional[Dict[str, List[float]]] = None,
        config: Optional[PlotConfig] = None,
    ) -> Any:
        """
        Create real-time training monitoring dashboard

        Args:
            loss_history: Training loss values
            learning_rates: Learning rate schedule
            validation_loss: Optional validation loss
            metrics: Additional metrics to plot
            config: Plot configuration

        Returns:
            Plotly figure with training monitoring
        """
        config = config or PlotConfig()

        if not _PLOTLY_AVAILABLE:
            raise ImportError(
                'Plotly is required for VisualizationEngine. Install via: pip install "gradlens[viz]" or "gradlens[notebook]"'
            )
        # Determine number of subplots based on available data
        num_plots = 2  # Loss and Learning Rate
        if validation_loss:
            num_plots += 1
        if metrics:
            num_plots += len(metrics)

        if not _PLOTLY_AVAILABLE:
            raise ImportError(
                'Plotly is required for VisualizationEngine. Install via: pip install "gradlens[viz]" or "gradlens[notebook]"'
            )
        # Create subplots
        fig = make_subplots(
            rows=num_plots,
            cols=1,
            subplot_titles=[
                "Training Loss",
                "Learning Rate Schedule",
                *(["Validation Loss"] if validation_loss else []),
                *([f"{name.title()}" for name in (metrics or {}).keys()]),
            ],
            vertical_spacing=0.05,
        )

        steps = list(range(len(loss_history)))

        # 1. Training Loss
        fig.add_trace(
            go.Scatter(
                x=steps,
                y=loss_history,
                mode="lines+markers",
                name="Training Loss",
                line=dict(color="blue", width=2),
                marker=dict(size=4),
            ),
            row=1,
            col=1,
        )

        # Add validation loss if available
        if validation_loss:
            fig.add_trace(
                go.Scatter(
                    x=steps,
                    y=validation_loss,
                    mode="lines+markers",
                    name="Validation Loss",
                    line=dict(color="red", width=2),
                    marker=dict(size=4),
                ),
                row=1,
                col=1,
            )

        # 2. Learning Rate Schedule
        fig.add_trace(
            go.Scatter(
                x=steps,
                y=learning_rates,
                mode="lines+markers",
                name="Learning Rate",
                line=dict(color="green", width=2),
                marker=dict(size=4),
            ),
            row=2,
            col=1,
        )

        # 3. Additional Metrics
        if metrics:
            row_idx = 3
            for metric_name, metric_values in metrics.items():
                fig.add_trace(
                    go.Scatter(
                        x=steps,
                        y=metric_values,
                        mode="lines+markers",
                        name=metric_name.title(),
                        line=dict(width=2),
                        marker=dict(size=4),
                    ),
                    row=row_idx,
                    col=1,
                )
                row_idx += 1

        # Update layout
        fig.update_layout(
            title=f"{config.title or 'Training Monitoring Dashboard'}",
            height=200 * num_plots,
            showlegend=True,
            template=self.config.theme.value,
        )

        # Update axes
        for i in range(1, num_plots + 1):
            fig.update_xaxes(title_text="Step", row=i, col=1)

        fig.update_yaxes(title_text="Loss", row=1, col=1)
        fig.update_yaxes(title_text="Learning Rate", row=2, col=1)

        if validation_loss:
            fig.update_yaxes(title_text="Loss", row=3, col=1)

        return fig

    def create_gradient_analysis_plots(
        self, stats: ModelStatistics, config: Optional[PlotConfig] = None
    ) -> Any:
        """
        Create gradient analysis plots

        Args:
            stats: Model statistics
            config: Plot configuration

        Returns:
            Plotly figure with gradient analysis
        """
        config = config or PlotConfig()

        # Create subplots
        fig = make_subplots(
            rows=2,
            cols=2,
            subplot_titles=[
                "Gradient Norms by Layer",
                "Gradient Distribution",
                "Gradient Sparsity",
                "Gradient vs Weight Norms",
            ],
            specs=[
                [{"type": "bar"}, {"type": "histogram"}],
                [{"type": "bar"}, {"type": "scatter"}],
            ],
        )

        # Prepare data
        layer_names = []
        grad_norms = []
        grad_sparsity = []
        weight_norms = []
        grad_means = []
        grad_stds = []

        for name, layer_stats in stats.layer_stats.items():
            if layer_stats.grad_norm > 0:
                layer_names.append(name)
                grad_norms.append(layer_stats.grad_norm)
                grad_sparsity.append(layer_stats.grad_sparsity)
                weight_norms.append(layer_stats.weight_norm)
                grad_means.append(layer_stats.grad_mean)
                grad_stds.append(layer_stats.grad_std)

        # 1. Gradient Norms by Layer
        fig.add_trace(
            go.Bar(
                x=layer_names,
                y=grad_norms,
                name="Gradient Norm",
                marker_color=px.colors.qualitative.Set3[0],
            ),
            row=1,
            col=1,
        )

        # 2. Gradient Distribution (Histogram)
        all_grad_norms = grad_norms
        fig.add_trace(
            go.Histogram(
                x=all_grad_norms,
                name="Gradient Norm Distribution",
                marker_color=px.colors.qualitative.Set3[1],
                nbinsx=20,
            ),
            row=1,
            col=2,
        )

        # 3. Gradient Sparsity
        fig.add_trace(
            go.Bar(
                x=layer_names,
                y=grad_sparsity,
                name="Gradient Sparsity",
                marker_color=px.colors.qualitative.Set3[2],
            ),
            row=2,
            col=1,
        )

        # 4. Gradient vs Weight Norms
        fig.add_trace(
            go.Scatter(
                x=weight_norms,
                y=grad_norms,
                mode="markers+text",
                text=layer_names,
                textposition="top center",
                name="Grad vs Weight",
                marker=dict(size=10, color=px.colors.qualitative.Set3[3], opacity=0.7),
            ),
            row=2,
            col=2,
        )

        # Update layout
        fig.update_layout(
            title=f"{config.title or 'Gradient Analysis'}",
            height=600,
            showlegend=True,
            template=self.config.theme.value,
        )

        # Update axes
        fig.update_xaxes(title_text="Layer", row=1, col=1)
        fig.update_yaxes(title_text="Gradient Norm", row=1, col=1)

        fig.update_xaxes(title_text="Gradient Norm", row=1, col=2)
        fig.update_yaxes(title_text="Frequency", row=1, col=2)

        fig.update_xaxes(title_text="Layer", row=2, col=1)
        fig.update_yaxes(title_text="Sparsity", row=2, col=1)

        fig.update_xaxes(title_text="Weight Norm", row=2, col=2)
        fig.update_yaxes(title_text="Gradient Norm", row=2, col=2)

        return fig

    def create_architecture_visualization(
        self, stats: ModelStatistics, config: Optional[PlotConfig] = None
    ) -> Any:
        """
        Create model architecture visualization

        Args:
            stats: Model statistics
            config: Plot configuration

        Returns:
            Plotly figure with architecture visualization
        """
        config = config or PlotConfig()

        if not _PLOTLY_AVAILABLE:
            raise ImportError(
                'Plotly is required for VisualizationEngine. Install via: pip install "gradlens[viz]" or "gradlens[notebook]"'
            )
        # Create Sankey diagram for data flow
        fig = go.Figure(
            data=go.Sankey(
                node=dict(
                    pad=15,
                    thickness=20,
                    line=dict(color="black", width=0.5),
                    label=self._get_architecture_nodes(stats),
                    color=px.colors.qualitative.Set3,
                ),
                link=dict(
                    source=self._get_architecture_links(stats)[0],
                    target=self._get_architecture_links(stats)[1],
                    value=self._get_architecture_links(stats)[2],
                    color="rgba(0,0,0,0.2)",
                ),
            )
        )

        fig.update_layout(
            title=f"{config.title or 'Model Architecture Flow'}",
            font_size=10,
            height=600,
            template=self.config.theme.value,
        )

        return fig

    def _get_architecture_nodes(self, stats: ModelStatistics) -> List[str]:
        """Get node labels for architecture visualization"""
        nodes = []
        for name, layer_stats in stats.layer_stats.items():
            nodes.append(f"{name}\n({layer_stats.layer_type})")
        return nodes

    def _get_architecture_links(
        self, stats: ModelStatistics
    ) -> Tuple[List[int], List[int], List[float]]:
        """Get link data for architecture visualization"""
        layer_names = list(stats.layer_stats.keys())
        sources = []
        targets = []
        values = []

        for i in range(len(layer_names) - 1):
            sources.append(i)
            targets.append(i + 1)
            # Use parameter count as link strength
            values.append(stats.layer_stats[layer_names[i]].num_parameters)

        return sources, targets, values

    def create_performance_profiling_plots(
        self, stats: ModelStatistics, config: Optional[PlotConfig] = None
    ) -> Any:
        """
        Create performance profiling plots

        Args:
            stats: Model statistics
            config: Plot configuration

        Returns:
            Plotly figure with performance analysis
        """
        config = config or PlotConfig()

        if not _PLOTLY_AVAILABLE:
            raise ImportError(
                'Plotly is required for VisualizationEngine. Install via: pip install "gradlens[viz]" or "gradlens[notebook]"'
            )
        # Create subplots
        fig = make_subplots(
            rows=2,
            cols=2,
            subplot_titles=[
                "Forward Pass Time",
                "Backward Pass Time",
                "Memory Usage",
                "Performance vs Parameters",
            ],
        )

        # Prepare data
        layer_names = []
        forward_times = []
        backward_times = []
        memory_usage = []
        param_counts = []

        for name, layer_stats in stats.layer_stats.items():
            if layer_stats.forward_time_ms > 0:
                layer_names.append(name)
                forward_times.append(layer_stats.forward_time_ms)
                backward_times.append(layer_stats.backward_time_ms)
                memory_usage.append(layer_stats.memory_mb)
                param_counts.append(layer_stats.num_parameters)

        # 1. Forward Pass Time
        fig.add_trace(
            go.Bar(
                x=layer_names,
                y=forward_times,
                name="Forward Time (ms)",
                marker_color=px.colors.qualitative.Set3[0],
            ),
            row=1,
            col=1,
        )

        # 2. Backward Pass Time
        fig.add_trace(
            go.Bar(
                x=layer_names,
                y=backward_times,
                name="Backward Time (ms)",
                marker_color=px.colors.qualitative.Set3[1],
            ),
            row=1,
            col=2,
        )

        # 3. Memory Usage
        fig.add_trace(
            go.Bar(
                x=layer_names,
                y=memory_usage,
                name="Memory (MB)",
                marker_color=px.colors.qualitative.Set3[2],
            ),
            row=2,
            col=1,
        )

        # 4. Performance vs Parameters
        fig.add_trace(
            go.Scatter(
                x=param_counts,
                y=forward_times,
                mode="markers+text",
                text=layer_names,
                textposition="top center",
                name="Forward Time vs Params",
                marker=dict(size=10, color=px.colors.qualitative.Set3[3], opacity=0.7),
            ),
            row=2,
            col=2,
        )

        # Update layout
        fig.update_layout(
            title=f"{config.title or 'Performance Profiling'}",
            height=600,
            showlegend=True,
            template=self.config.theme.value,
        )

        # Update axes
        for i in range(1, 3):
            for j in range(1, 3):
                fig.update_xaxes(title_text="Layer", row=i, col=j)

        fig.update_yaxes(title_text="Time (ms)", row=1, col=1)
        fig.update_yaxes(title_text="Time (ms)", row=1, col=2)
        fig.update_yaxes(title_text="Memory (MB)", row=2, col=1)
        fig.update_yaxes(title_text="Forward Time (ms)", row=2, col=2)
        fig.update_xaxes(title_text="Parameters", row=2, col=2)

        return fig

    def create_health_monitoring_dashboard(
        self, stats: ModelStatistics, config: Optional[PlotConfig] = None
    ) -> Any:
        """
        Create health monitoring dashboard

        Args:
            stats: Model statistics
            config: Plot configuration

        Returns:
            Plotly figure with health monitoring
        """
        config = config or PlotConfig()

        if not _PLOTLY_AVAILABLE:
            raise ImportError(
                'Plotly is required for VisualizationEngine. Install via: pip install "gradlens[viz]" or "gradlens[notebook]"'
            )
        # Create subplots
        fig = make_subplots(
            rows=2,
            cols=2,
            subplot_titles=[
                "Health Issues Overview",
                "Dead Neuron Analysis",
                "Gradient Health",
                "Parameter Health",
            ],
            specs=[
                [{"type": "bar"}, {"type": "bar"}],
                [{"type": "scatter"}, {"type": "scatter"}],
            ],
        )

        # Prepare health data
        layer_names = []
        health_scores = []
        dead_ratios = []
        grad_health = []
        param_health = []

        for name, layer_stats in stats.layer_stats.items():
            layer_names.append(name)

            # Calculate health score (0-1, higher is better)
            health_score = 1.0
            if layer_stats.has_nan:
                health_score -= 0.3
            if layer_stats.has_inf:
                health_score -= 0.3
            if layer_stats.is_frozen:
                health_score -= 0.2
            if layer_stats.dead_neuron_ratio > 0.5:
                health_score -= 0.2

            health_scores.append(max(0, health_score))
            dead_ratios.append(layer_stats.dead_neuron_ratio)

            # Gradient health (based on norm)
            if layer_stats.grad_norm > 100:
                grad_health.append(0)  # Exploding
            elif layer_stats.grad_norm < 1e-7:
                grad_health.append(0.5)  # Vanishing
            else:
                grad_health.append(1)  # Healthy

            # Parameter health (based on norm)
            if layer_stats.weight_norm > 10:
                param_health.append(0.5)  # Large weights
            elif layer_stats.weight_norm < 1e-6:
                param_health.append(0.5)  # Very small weights
            else:
                param_health.append(1)  # Healthy

        # 1. Health Issues Overview
        fig.add_trace(
            go.Bar(
                x=layer_names,
                y=health_scores,
                name="Health Score",
                marker_color=px.colors.qualitative.Set3[0],
            ),
            row=1,
            col=1,
        )

        # 2. Dead Neuron Analysis
        fig.add_trace(
            go.Bar(
                x=layer_names,
                y=dead_ratios,
                name="Dead Neuron Ratio",
                marker_color=px.colors.qualitative.Set3[1],
            ),
            row=1,
            col=2,
        )

        # 3. Gradient Health
        fig.add_trace(
            go.Scatter(
                x=layer_names,
                y=grad_health,
                mode="markers+text",
                text=layer_names,
                textposition="top center",
                name="Gradient Health",
                marker=dict(
                    size=15,
                    color=grad_health,
                    colorscale="RdYlGn",
                    showscale=True,
                    cmin=0,
                    cmax=1,
                ),
            ),
            row=2,
            col=1,
        )

        # 4. Parameter Health
        fig.add_trace(
            go.Scatter(
                x=layer_names,
                y=param_health,
                mode="markers+text",
                text=layer_names,
                textposition="top center",
                name="Parameter Health",
                marker=dict(
                    size=15,
                    color=param_health,
                    colorscale="RdYlGn",
                    showscale=True,
                    cmin=0,
                    cmax=1,
                ),
            ),
            row=2,
            col=2,
        )

        # Update layout
        fig.update_layout(
            title=f"{config.title or 'Health Monitoring Dashboard'}",
            height=600,
            showlegend=True,
            template=self.config.theme.value,
        )

        # Update axes
        for i in range(1, 3):
            for j in range(1, 3):
                fig.update_xaxes(title_text="Layer", row=i, col=j)

        fig.update_yaxes(title_text="Health Score", row=1, col=1)
        fig.update_yaxes(title_text="Dead Neuron Ratio", row=1, col=2)
        fig.update_yaxes(title_text="Gradient Health", row=2, col=1)
        fig.update_yaxes(title_text="Parameter Health", row=2, col=2)

        return fig

    def export_figure(
        self,
        figure: Any,
        filename: str,
        format: str = "html",
        width: Optional[int] = None,
        height: Optional[int] = None,
    ) -> str:
        """
        Export figure to various formats

        Args:
            figure: Plotly figure
            filename: Output filename
            format: Export format ('html', 'png', 'pdf', 'svg')
            width: Figure width
            height: Figure height

        Returns:
            Path to exported file
        """
        if width:
            figure.update_layout(width=width)
        if height:
            figure.update_layout(height=height)

        if format.lower() == "html":
            figure.write_html(filename)
        elif format.lower() == "png":
            figure.write_image(filename, format="png")
        elif format.lower() == "pdf":
            figure.write_image(filename, format="pdf")
        elif format.lower() == "svg":
            figure.write_image(filename, format="svg")
        else:
            raise ValueError(f"Unsupported format: {format}")

        _logger.info(f"Figure exported to {filename}")
        return filename

    def create_interactive_dashboard(
        self,
        stats: ModelStatistics,
        loss_history: Optional[List[float]] = None,
        learning_rates: Optional[List[float]] = None,
        config: Optional[DashboardConfig] = None,
    ) -> Any:
        """
        Create comprehensive interactive dashboard

        Args:
            stats: Model statistics
            loss_history: Optional training loss history
            learning_rates: Optional learning rate schedule
            config: Dashboard configuration

        Returns:
            Complete interactive dashboard
        """
        config = config or self.config

        # Create main dashboard with tabs

        # This would be a more complex implementation with tabs
        # For now, we'll create a comprehensive single view
        fig = self.create_model_overview_dashboard(stats)

        # Add training data if available
        if loss_history and learning_rates:
            # Add training plots as additional subplots
            # This is a simplified version
            pass

        return fig


# ==================== Utility Functions ====================


def create_visualization_engine(
    config: Optional[DashboardConfig] = None,
) -> VisualizationEngine:
    """
    Factory function to create visualization engine

    Args:
        config: Dashboard configuration

    Returns:
        Configured VisualizationEngine instance
    """
    return VisualizationEngine(config)


def quick_visualization(stats: ModelStatistics, plot_type: str = "overview") -> Any:
    """
    Create quick visualization for model statistics

    Args:
        stats: Model statistics
        plot_type: Type of plot to create

    Returns:
        Plotly figure
    """
    engine = VisualizationEngine()

    if plot_type == "overview":
        return engine.create_model_overview_dashboard(stats)
    elif plot_type == "gradients":
        return engine.create_gradient_analysis_plots(stats)
    elif plot_type == "performance":
        return engine.create_performance_profiling_plots(stats)
    elif plot_type == "health":
        return engine.create_health_monitoring_dashboard(stats)
    else:
        raise ValueError(f"Unknown plot type: {plot_type}")

"""
Advanced Experiment Tracking System

This module provides comprehensive experiment tracking and management
for deep learning model training and evaluation.

Features:
- Experiment metadata management
- Hyperparameter tracking
- Model versioning
- Performance comparison
- A/B testing support
- Export capabilities
"""

import json
import sqlite3
import hashlib
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime
import logging
import uuid

from .analytics_engine import ArchitectureType

_logger = logging.getLogger(__name__)


# ==================== Data Classes ====================


@dataclass
class HyperparameterConfig:
    """Configuration for hyperparameters"""

    learning_rate: float = 0.001
    batch_size: int = 32
    epochs: int = 100
    optimizer: str = "adam"
    loss_function: str = "cross_entropy"
    weight_decay: float = 0.0
    dropout_rate: float = 0.0
    activation: str = "relu"
    architecture: str = "custom"
    custom_params: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)

    def to_hash(self) -> str:
        """Generate hash for hyperparameter configuration"""
        config_str = json.dumps(self.to_dict(), sort_keys=True)
        return hashlib.sha256(config_str.encode()).hexdigest()


@dataclass
class RunMetadata:
    """Metadata for a single experiment run"""

    run_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    experiment_name: str = ""
    description: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    # Model information
    model_architecture: ArchitectureType = ArchitectureType.CUSTOM
    model_hash: str = ""
    total_parameters: int = 0
    trainable_parameters: int = 0

    # Training configuration
    hyperparameters: HyperparameterConfig = field(default_factory=HyperparameterConfig)

    # Performance metrics
    best_loss: float = float("inf")
    best_accuracy: float = 0.0
    final_loss: float = float("inf")
    final_accuracy: float = 0.0
    training_time_seconds: float = 0.0

    # Status
    status: str = "running"  # running, completed, failed, cancelled
    error_message: str = ""

    # File paths
    model_path: str = ""
    log_path: str = ""
    config_path: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        data = asdict(self)
        data["created_at"] = self.created_at.isoformat()
        data["updated_at"] = self.updated_at.isoformat()
        return data


@dataclass
class ExperimentConfig:
    """Configuration for experiment tracking"""

    database_path: str = "experiments.db"
    model_save_path: str = "models/"
    log_save_path: str = "logs/"
    auto_save: bool = True
    save_frequency: int = 10  # Save every N epochs
    max_runs_per_experiment: int = 1000
    cleanup_old_runs: bool = True
    days_to_keep: int = 30


class ExperimentTracker:
    """
    Advanced experiment tracking system

    Features:
    - Experiment metadata management
    - Hyperparameter tracking
    - Model versioning
    - Performance comparison
    - A/B testing support
    """

    def __init__(self, config: Optional[ExperimentConfig] = None):
        self.config = config or ExperimentConfig()
        self._setup_database()
        self._current_run: Optional[RunMetadata] = None

        _logger.info("ExperimentTracker initialized")

    def _setup_database(self) -> None:
        """Setup SQLite database for experiment tracking"""
        self.db_path = Path(self.config.database_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()

            # Create experiments table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS experiments (
                    run_id TEXT PRIMARY KEY,
                    experiment_name TEXT NOT NULL,
                    description TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    model_architecture TEXT NOT NULL,
                    model_hash TEXT NOT NULL,
                    total_parameters INTEGER NOT NULL,
                    trainable_parameters INTEGER NOT NULL,
                    hyperparameters TEXT NOT NULL,
                    best_loss REAL,
                    best_accuracy REAL,
                    final_loss REAL,
                    final_accuracy REAL,
                    training_time_seconds REAL,
                    status TEXT NOT NULL,
                    error_message TEXT,
                    model_path TEXT,
                    log_path TEXT,
                    config_path TEXT
                )
            """)

            # Create metrics table for detailed tracking
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL,
                    epoch INTEGER NOT NULL,
                    step INTEGER NOT NULL,
                    metric_name TEXT NOT NULL,
                    metric_value REAL NOT NULL,
                    timestamp TEXT NOT NULL,
                    FOREIGN KEY (run_id) REFERENCES experiments (run_id)
                )
            """)

            # Create comparisons table for A/B testing
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS comparisons (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    experiment_name TEXT NOT NULL,
                    run_id_1 TEXT NOT NULL,
                    run_id_2 TEXT NOT NULL,
                    comparison_type TEXT NOT NULL,
                    result TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (run_id_1) REFERENCES experiments (run_id),
                    FOREIGN KEY (run_id_2) REFERENCES experiments (run_id)
                )
            """)

            conn.commit()

    def start_experiment(
        self,
        experiment_name: str,
        description: str = "",
        hyperparameters: Optional[HyperparameterConfig] = None,
        model: Optional[Any] = None,
    ) -> str:
        """
        Start a new experiment

        Args:
            experiment_name: Name of the experiment
            description: Description of the experiment
            hyperparameters: Hyperparameter configuration
            model: PyTorch model (optional)

        Returns:
            Run ID for the experiment
        """
        # Create run metadata
        run_metadata = RunMetadata(
            experiment_name=experiment_name,
            description=description,
            hyperparameters=hyperparameters or HyperparameterConfig(),
        )

        # Add model information if provided
        if model is not None:
            run_metadata.model_hash = self._calculate_model_hash(model)
            run_metadata.total_parameters = sum(p.numel() for p in model.parameters())
            run_metadata.trainable_parameters = sum(
                p.numel() for p in model.parameters() if p.requires_grad
            )

        # Save to database
        self._save_run_metadata(run_metadata)

        # Set as current run
        self._current_run = run_metadata

        _logger.info(
            f"Started experiment: {experiment_name} (ID: {run_metadata.run_id})"
        )

        return run_metadata.run_id

    def log_metrics(
        self,
        epoch: int,
        step: int,
        metrics: Dict[str, float],
        run_id: Optional[str] = None,
    ) -> None:
        """
        Log metrics for current or specified run

        Args:
            epoch: Current epoch
            step: Current step
            metrics: Dictionary of metric names and values
            run_id: Optional run ID (uses current run if not provided)
        """
        if run_id is None:
            if self._current_run is None:
                raise ValueError("No current run and no run_id provided")
            run_id = self._current_run.run_id

        timestamp = datetime.now().isoformat()

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()

            for metric_name, metric_value in metrics.items():
                cursor.execute(
                    """
                    INSERT INTO metrics (run_id, epoch, step, metric_name, metric_value, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?)
                """,
                    (run_id, epoch, step, metric_name, metric_value, timestamp),
                )

            conn.commit()

        # Update run metadata if this is the current run
        if self._current_run and self._current_run.run_id == run_id:
            self._update_run_metrics(metrics)

    def _update_run_metrics(self, metrics: Dict[str, float]) -> None:
        """Update current run metrics"""
        if not self._current_run:
            return

        # Update best metrics
        if "loss" in metrics:
            if metrics["loss"] < self._current_run.best_loss:
                self._current_run.best_loss = metrics["loss"]
            self._current_run.final_loss = metrics["loss"]

        if "accuracy" in metrics:
            if metrics["accuracy"] > self._current_run.best_accuracy:
                self._current_run.best_accuracy = metrics["accuracy"]
            self._current_run.final_accuracy = metrics["accuracy"]

        # Update timestamp
        self._current_run.updated_at = datetime.now()

    def complete_experiment(
        self,
        run_id: Optional[str] = None,
        *,
        status: str = "completed",
        error_message: str = "",
        model_path: str = "",
        log_path: str = "",
        config_path: str = "",
    ) -> None:
        """
        Complete the current experiment

        Args:
            status: Final status of the experiment
            error_message: Error message if failed
            model_path: Path to saved model
            log_path: Path to log file
            config_path: Path to config file
            run_id: Optional run ID (uses current run if not provided)
        """
        if run_id is None:
            if self._current_run is None:
                raise ValueError("No current run and no run_id provided")
            run_id = self._current_run.run_id

        # Update run metadata
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()

            cursor.execute(
                """
                UPDATE experiments 
                SET status = ?, error_message = ?, model_path = ?, 
                    log_path = ?, config_path = ?, updated_at = ?
                WHERE run_id = ?
            """,
                (
                    status,
                    error_message,
                    model_path,
                    log_path,
                    config_path,
                    datetime.now().isoformat(),
                    run_id,
                ),
            )

            conn.commit()

        # Update current run if applicable
        if self._current_run and self._current_run.run_id == run_id:
            self._current_run.status = status
            self._current_run.error_message = error_message
            self._current_run.model_path = model_path
            self._current_run.log_path = log_path
            self._current_run.config_path = config_path
            self._current_run.updated_at = datetime.now()

        _logger.info(f"Completed experiment: {run_id} (Status: {status})")

    def get_experiment_runs(
        self,
        experiment_name: Optional[str] = None,
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[RunMetadata]:
        """
        Get experiment runs with optional filtering

        Args:
            experiment_name: Filter by experiment name
            status: Filter by status
            limit: Limit number of results

        Returns:
            List of run metadata
        """
        query = "SELECT * FROM experiments WHERE 1=1"
        params = []

        if experiment_name:
            query += " AND experiment_name = ?"
            params.append(experiment_name)

        if status:
            query += " AND status = ?"
            params.append(status)

        query += " ORDER BY created_at DESC"

        if limit:
            query += f" LIMIT {limit}"

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()

        runs = []
        for row in rows:
            run_data = dict(zip([col[0] for col in cursor.description], row))

            # Parse hyperparameters
            hyperparams = json.loads(run_data["hyperparameters"])
            run_data["hyperparameters"] = HyperparameterConfig(**hyperparams)

            # Parse datetime fields
            run_data["created_at"] = datetime.fromisoformat(run_data["created_at"])
            run_data["updated_at"] = datetime.fromisoformat(run_data["updated_at"])

            runs.append(RunMetadata(**run_data))

        return runs

    def get_run_metrics(
        self, run_id: str, metric_name: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get metrics for a specific run

        Args:
            run_id: Run ID
            metric_name: Optional metric name filter

        Returns:
            List of metric records
        """
        query = "SELECT * FROM metrics WHERE run_id = ?"
        params = [run_id]

        if metric_name:
            query += " AND metric_name = ?"
            params.append(metric_name)

        query += " ORDER BY epoch, step"

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()

        metrics = []
        for row in rows:
            metric_data = dict(zip([col[0] for col in cursor.description], row))
            metrics.append(metric_data)

        return metrics

    def compare_runs(
        self, run_id_1: str, run_id_2: str, comparison_type: str = "performance"
    ) -> Dict[str, Any]:
        """
        Compare two experiment runs

        Args:
            run_id_1: First run ID
            run_id_2: Second run ID
            comparison_type: Type of comparison

        Returns:
            Comparison results
        """
        # Get run metadata
        runs = self.get_experiment_runs()
        run1 = next((r for r in runs if r.run_id == run_id_1), None)
        run2 = next((r for r in runs if r.run_id == run_id_2), None)

        if not run1 or not run2:
            raise ValueError("One or both runs not found")

        comparison = {
            "run1": run1.to_dict(),
            "run2": run2.to_dict(),
            "comparison_type": comparison_type,
            "created_at": datetime.now().isoformat(),
        }

        if comparison_type == "performance":
            comparison["results"] = self._compare_performance(run1, run2)
        elif comparison_type == "hyperparameters":
            comparison["results"] = self._compare_hyperparameters(run1, run2)
        elif comparison_type == "architecture":
            comparison["results"] = self._compare_architecture(run1, run2)
        else:
            raise ValueError(f"Unknown comparison type: {comparison_type}")

        # Save comparison to database
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO comparisons (experiment_name, run_id_1, run_id_2, 
                                       comparison_type, result, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """,
                (
                    run1.experiment_name,
                    run_id_1,
                    run_id_2,
                    comparison_type,
                    json.dumps(comparison["results"]),
                    datetime.now().isoformat(),
                ),
            )
            conn.commit()

        return comparison

    def _compare_performance(
        self, run1: RunMetadata, run2: RunMetadata
    ) -> Dict[str, Any]:
        """Compare performance metrics between two runs"""
        return {
            "best_loss": {
                "run1": run1.best_loss,
                "run2": run2.best_loss,
                "better": "run1" if run1.best_loss < run2.best_loss else "run2",
                "improvement": abs(run1.best_loss - run2.best_loss)
                / max(run1.best_loss, run2.best_loss),
            },
            "best_accuracy": {
                "run1": run1.best_accuracy,
                "run2": run2.best_accuracy,
                "better": "run1" if run1.best_accuracy > run2.best_accuracy else "run2",
                "improvement": abs(run1.best_accuracy - run2.best_accuracy)
                / max(run1.best_accuracy, run2.best_accuracy),
            },
            "training_time": {
                "run1": run1.training_time_seconds,
                "run2": run2.training_time_seconds,
                "faster": "run1"
                if run1.training_time_seconds < run2.training_time_seconds
                else "run2",
            },
        }

    def _compare_hyperparameters(
        self, run1: RunMetadata, run2: RunMetadata
    ) -> Dict[str, Any]:
        """Compare hyperparameters between two runs"""
        params1 = run1.hyperparameters.to_dict()
        params2 = run2.hyperparameters.to_dict()

        differences = {}
        for key in set(params1.keys()) | set(params2.keys()):
            val1 = params1.get(key, None)
            val2 = params2.get(key, None)
            if val1 != val2:
                differences[key] = {"run1": val1, "run2": val2}

        return {"differences": differences, "identical": len(differences) == 0}

    def _compare_architecture(
        self, run1: RunMetadata, run2: RunMetadata
    ) -> Dict[str, Any]:
        """Compare model architecture between two runs"""
        return {
            "architecture_type": {
                "run1": run1.model_architecture.value,
                "run2": run2.model_architecture.value,
                "same": run1.model_architecture == run2.model_architecture,
            },
            "total_parameters": {
                "run1": run1.total_parameters,
                "run2": run2.total_parameters,
                "difference": run1.total_parameters - run2.total_parameters,
                "ratio": run1.total_parameters / run2.total_parameters
                if run2.total_parameters > 0
                else float("inf"),
            },
            "trainable_parameters": {
                "run1": run1.trainable_parameters,
                "run2": run2.trainable_parameters,
                "difference": run1.trainable_parameters - run2.trainable_parameters,
                "ratio": run1.trainable_parameters / run2.trainable_parameters
                if run2.trainable_parameters > 0
                else float("inf"),
            },
        }

    def get_best_run(
        self, experiment_name: str, metric: str = "best_loss", ascending: bool = True
    ) -> Optional[RunMetadata]:
        """
        Get the best run for an experiment based on a metric

        Args:
            experiment_name: Name of the experiment
            metric: Metric to optimize
            ascending: Whether lower values are better

        Returns:
            Best run metadata or None
        """
        runs = self.get_experiment_runs(
            experiment_name=experiment_name, status="completed"
        )

        if not runs:
            return None

        # Sort by metric
        runs.sort(key=lambda x: getattr(x, metric, float("inf")), reverse=not ascending)

        return runs[0]

    def export_experiment_data(
        self, experiment_name: str, format: str = "json", include_metrics: bool = False
    ) -> str:
        """
        Export experiment data

        Args:
            experiment_name: Name of the experiment
            format: Export format ('json', 'csv')
            include_metrics: Whether to include detailed metrics

        Returns:
            Path to exported file
        """
        runs = self.get_experiment_runs(experiment_name=experiment_name)

        if not runs:
            raise ValueError(f"No runs found for experiment: {experiment_name}")

        export_data = {
            "experiment_name": experiment_name,
            "exported_at": datetime.now().isoformat(),
            "total_runs": len(runs),
            "runs": [],
        }

        for run in runs:
            run_data = run.to_dict()

            if include_metrics:
                run_data["metrics"] = self.get_run_metrics(run.run_id)

            export_data["runs"].append(run_data)

        # Export to file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{experiment_name}_{timestamp}.{format}"

        if format == "json":
            with open(filename, "w") as f:
                json.dump(export_data, f, indent=2, default=str)
        elif format == "csv":
            # Convert to CSV format
            import pandas as pd

            # Flatten run data for CSV
            csv_data = []
            for run in runs:
                run_dict = run.to_dict()
                run_dict["hyperparameters"] = json.dumps(run_dict["hyperparameters"])
                csv_data.append(run_dict)

            df = pd.DataFrame(csv_data)
            df.to_csv(filename, index=False)
        else:
            raise ValueError(f"Unsupported format: {format}")

        _logger.info(f"Exported experiment data to {filename}")
        return filename

    def _save_run_metadata(self, run_metadata: RunMetadata) -> None:
        """Save run metadata to database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()

            cursor.execute(
                """
                INSERT OR REPLACE INTO experiments 
                (run_id, experiment_name, description, created_at, updated_at,
                 model_architecture, model_hash, total_parameters, trainable_parameters,
                 hyperparameters, best_loss, best_accuracy, final_loss, final_accuracy,
                 training_time_seconds, status, error_message, model_path, log_path, config_path)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    run_metadata.run_id,
                    run_metadata.experiment_name,
                    run_metadata.description,
                    run_metadata.created_at.isoformat(),
                    run_metadata.updated_at.isoformat(),
                    run_metadata.model_architecture.value,
                    run_metadata.model_hash,
                    run_metadata.total_parameters,
                    run_metadata.trainable_parameters,
                    json.dumps(run_metadata.hyperparameters.to_dict()),
                    run_metadata.best_loss,
                    run_metadata.best_accuracy,
                    run_metadata.final_loss,
                    run_metadata.final_accuracy,
                    run_metadata.training_time_seconds,
                    run_metadata.status,
                    run_metadata.error_message,
                    run_metadata.model_path,
                    run_metadata.log_path,
                    run_metadata.config_path,
                ),
            )

            conn.commit()

    def _calculate_model_hash(self, model: Any) -> str:
        """Calculate hash for model architecture"""
        # This is a simplified version - in practice, you'd want to hash
        # the model's state dict or architecture definition
        model_str = str(model)
        return hashlib.sha256(model_str.encode()).hexdigest()


# ==================== Utility Functions ====================


def create_experiment_tracker(
    config: Optional[ExperimentConfig] = None,
) -> ExperimentTracker:
    """
    Factory function to create experiment tracker

    Args:
        config: Experiment configuration

    Returns:
        Configured ExperimentTracker instance
    """
    return ExperimentTracker(config)


def quick_experiment_start(
    experiment_name: str, hyperparameters: Optional[HyperparameterConfig] = None
) -> Tuple[ExperimentTracker, str]:
    """
    Quick way to start an experiment

    Args:
        experiment_name: Name of the experiment
        hyperparameters: Hyperparameter configuration

    Returns:
        Tuple of (tracker, run_id)
    """
    tracker = ExperimentTracker()
    run_id = tracker.start_experiment(experiment_name, hyperparameters=hyperparameters)
    return tracker, run_id

"""
Advanced Analytics Engine for Deep Learning Models

This module provides comprehensive statistical analysis and insights
for all types of neural network architectures.

Enterprise-grade implementation with:
- Type safety
- Extensibility
- Performance optimization
- Comprehensive logging
"""

import numpy as np
import torch
import torch.nn as nn
from typing import Dict, List, Tuple, Optional, Any, Union, Protocol
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import logging
from abc import ABC, abstractmethod

_logger = logging.getLogger(__name__)


# ==================== Enums and Constants ====================


class ArchitectureType(Enum):
    """Supported neural network architectures"""

    CNN = "cnn"
    RNN = "rnn"
    LSTM = "lstm"
    GRU = "gru"
    TRANSFORMER = "transformer"
    GAN = "gan"
    VAE = "vae"
    RESNET = "resnet"
    ATTENTION = "attention"
    GRAPH = "graph"
    CUSTOM = "custom"


class MetricType(Enum):
    """Types of metrics to track"""

    GRADIENT = "gradient"
    WEIGHT = "weight"
    ACTIVATION = "activation"
    LOSS = "loss"
    ACCURACY = "accuracy"
    LEARNING_RATE = "learning_rate"
    MEMORY = "memory"
    TIME = "time"


class AnalysisLevel(Enum):
    """Level of analysis detail"""

    BASIC = "basic"  # Fast, essential metrics only
    STANDARD = "standard"  # Balanced (default)
    DETAILED = "detailed"  # Comprehensive analysis
    RESEARCH = "research"  # Everything including experimental metrics


# ==================== Data Classes ====================


@dataclass
class LayerStatistics:
    """Statistical summary for a single layer"""

    name: str
    layer_type: str

    # Shape information
    input_shape: Optional[Tuple[int, ...]] = None
    output_shape: Optional[Tuple[int, ...]] = None
    num_parameters: int = 0

    # Gradient statistics
    grad_mean: float = 0.0
    grad_std: float = 0.0
    grad_min: float = 0.0
    grad_max: float = 0.0
    grad_norm: float = 0.0
    grad_sparsity: float = 0.0  # Percentage of near-zero gradients

    # Weight statistics
    weight_mean: float = 0.0
    weight_std: float = 0.0
    weight_min: float = 0.0
    weight_max: float = 0.0
    weight_norm: float = 0.0

    # Activation statistics
    activation_mean: float = 0.0
    activation_std: float = 0.0
    activation_min: float = 0.0
    activation_max: float = 0.0
    dead_neuron_ratio: float = 0.0

    # Health indicators
    has_nan: bool = False
    has_inf: bool = False
    is_frozen: bool = False

    # Performance metrics
    forward_time_ms: float = 0.0
    backward_time_ms: float = 0.0
    memory_mb: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            "name": self.name,
            "layer_type": self.layer_type,
            "input_shape": self.input_shape,
            "output_shape": self.output_shape,
            "num_parameters": self.num_parameters,
            "gradients": {
                "mean": self.grad_mean,
                "std": self.grad_std,
                "min": self.grad_min,
                "max": self.grad_max,
                "norm": self.grad_norm,
                "sparsity": self.grad_sparsity,
            },
            "weights": {
                "mean": self.weight_mean,
                "std": self.weight_std,
                "min": self.weight_min,
                "max": self.weight_max,
                "norm": self.weight_norm,
            },
            "activations": {
                "mean": self.activation_mean,
                "std": self.activation_std,
                "min": self.activation_min,
                "max": self.activation_max,
                "dead_neuron_ratio": self.dead_neuron_ratio,
            },
            "health": {
                "has_nan": self.has_nan,
                "has_inf": self.has_inf,
                "is_frozen": self.is_frozen,
            },
            "performance": {
                "forward_time_ms": self.forward_time_ms,
                "backward_time_ms": self.backward_time_ms,
                "memory_mb": self.memory_mb,
            },
        }


@dataclass
class ModelStatistics:
    """Comprehensive statistics for entire model"""

    architecture_type: ArchitectureType
    total_parameters: int
    trainable_parameters: int
    non_trainable_parameters: int

    # Layer-wise statistics
    layer_stats: Dict[str, LayerStatistics] = field(default_factory=dict)

    # Global statistics
    total_grad_norm: float = 0.0
    max_grad_norm: float = 0.0
    min_grad_norm: float = 0.0
    avg_grad_norm: float = 0.0

    # Training dynamics
    loss_history: List[float] = field(default_factory=list)
    learning_rates: List[float] = field(default_factory=list)

    # Health metrics
    num_dead_layers: int = 0
    num_exploding_layers: int = 0
    num_vanishing_layers: int = 0
    num_frozen_layers: int = 0

    # Performance metrics
    total_forward_time_ms: float = 0.0
    total_backward_time_ms: float = 0.0
    total_memory_mb: float = 0.0

    # Model capacity metrics
    effective_rank: Optional[float] = None
    spectral_norm: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            "architecture": self.architecture_type.value,
            "parameters": {
                "total": self.total_parameters,
                "trainable": self.trainable_parameters,
                "non_trainable": self.non_trainable_parameters,
            },
            "layers": {
                name: stats.to_dict() for name, stats in self.layer_stats.items()
            },
            "global_gradients": {
                "total_norm": self.total_grad_norm,
                "max_norm": self.max_grad_norm,
                "min_norm": self.min_grad_norm,
                "avg_norm": self.avg_grad_norm,
            },
            "health": {
                "dead_layers": self.num_dead_layers,
                "exploding_layers": self.num_exploding_layers,
                "vanishing_layers": self.num_vanishing_layers,
                "frozen_layers": self.num_frozen_layers,
            },
            "performance": {
                "forward_time_ms": self.total_forward_time_ms,
                "backward_time_ms": self.total_backward_time_ms,
                "memory_mb": self.total_memory_mb,
            },
            "capacity": {
                "effective_rank": self.effective_rank,
                "spectral_norm": self.spectral_norm,
            },
        }


# ==================== Analyzer Protocols ====================


class LayerAnalyzer(Protocol):
    """Protocol for layer-specific analyzers"""

    def analyze(self, module: nn.Module, name: str) -> LayerStatistics:
        """Analyze a single layer"""
        ...

    def supports(self, module: nn.Module) -> bool:
        """Check if this analyzer supports the given module"""
        ...


# ==================== Base Analyzer ====================


class BaseLayerAnalyzer(ABC):
    """Base class for all layer analyzers"""

    def __init__(self, analysis_level: AnalysisLevel = AnalysisLevel.STANDARD):
        self.analysis_level = analysis_level
        self._gradient_history: Dict[str, List[torch.Tensor]] = defaultdict(list)
        self._activation_history: Dict[str, List[torch.Tensor]] = defaultdict(list)

    @abstractmethod
    def supports(self, module: nn.Module) -> bool:
        """Check if this analyzer can handle the module"""
        pass

    @abstractmethod
    def analyze(self, module: nn.Module, name: str) -> LayerStatistics:
        """Perform analysis on the module"""
        pass

    def _compute_gradient_stats(self, grad: torch.Tensor) -> Dict[str, float]:
        """Compute comprehensive gradient statistics"""
        if grad is None or grad.numel() == 0:
            return {
                "mean": 0.0,
                "std": 0.0,
                "min": 0.0,
                "max": 0.0,
                "norm": 0.0,
                "sparsity": 0.0,
            }

        grad_flat = grad.detach().flatten()

        # Basic statistics
        mean = grad_flat.mean().item()
        std = grad_flat.std().item()
        min_val = grad_flat.min().item()
        max_val = grad_flat.max().item()
        norm = torch.norm(grad_flat).item()

        # Sparsity (percentage of gradients close to zero)
        threshold = 1e-7
        sparsity = (grad_flat.abs() < threshold).float().mean().item()

        return {
            "mean": mean,
            "std": std,
            "min": min_val,
            "max": max_val,
            "norm": norm,
            "sparsity": sparsity,
        }

    def _compute_weight_stats(self, weight: torch.Tensor) -> Dict[str, float]:
        """Compute comprehensive weight statistics"""
        if weight is None or weight.numel() == 0:
            return {"mean": 0.0, "std": 0.0, "min": 0.0, "max": 0.0, "norm": 0.0}

        weight_flat = weight.detach().flatten()

        return {
            "mean": weight_flat.mean().item(),
            "std": weight_flat.std().item(),
            "min": weight_flat.min().item(),
            "max": weight_flat.max().item(),
            "norm": torch.norm(weight_flat).item(),
        }

    def _check_health(self, tensor: torch.Tensor) -> Tuple[bool, bool]:
        """Check for NaN and Inf values"""
        if tensor is None:
            return False, False

        has_nan = torch.isnan(tensor).any().item()
        has_inf = torch.isinf(tensor).any().item()

        return has_nan, has_inf


# ==================== Specific Analyzers ====================


class LinearLayerAnalyzer(BaseLayerAnalyzer):
    """Analyzer for Linear/Dense layers"""

    def supports(self, module: nn.Module) -> bool:
        return isinstance(module, nn.Linear)

    def analyze(self, module: nn.Module, name: str) -> LayerStatistics:
        stats = LayerStatistics(
            name=name,
            layer_type="Linear",
            num_parameters=sum(p.numel() for p in module.parameters()),
        )

        # Analyze weights
        if hasattr(module, "weight") and module.weight is not None:
            weight_stats = self._compute_weight_stats(module.weight)
            stats.weight_mean = weight_stats["mean"]
            stats.weight_std = weight_stats["std"]
            stats.weight_min = weight_stats["min"]
            stats.weight_max = weight_stats["max"]
            stats.weight_norm = weight_stats["norm"]

            # Check health
            has_nan, has_inf = self._check_health(module.weight)
            stats.has_nan = has_nan
            stats.has_inf = has_inf

            # Analyze gradients if available
            if module.weight.grad is not None:
                grad_stats = self._compute_gradient_stats(module.weight.grad)
                stats.grad_mean = grad_stats["mean"]
                stats.grad_std = grad_stats["std"]
                stats.grad_min = grad_stats["min"]
                stats.grad_max = grad_stats["max"]
                stats.grad_norm = grad_stats["norm"]
                stats.grad_sparsity = grad_stats["sparsity"]

        return stats


class ConvLayerAnalyzer(BaseLayerAnalyzer):
    """Analyzer for Convolutional layers"""

    def supports(self, module: nn.Module) -> bool:
        return isinstance(module, (nn.Conv1d, nn.Conv2d, nn.Conv3d))

    def analyze(self, module: nn.Module, name: str) -> LayerStatistics:
        conv_type = module.__class__.__name__

        stats = LayerStatistics(
            name=name,
            layer_type=conv_type,
            num_parameters=sum(p.numel() for p in module.parameters()),
        )

        # Analyze weights (kernels)
        if hasattr(module, "weight") and module.weight is not None:
            weight_stats = self._compute_weight_stats(module.weight)
            stats.weight_mean = weight_stats["mean"]
            stats.weight_std = weight_stats["std"]
            stats.weight_min = weight_stats["min"]
            stats.weight_max = weight_stats["max"]
            stats.weight_norm = weight_stats["norm"]

            has_nan, has_inf = self._check_health(module.weight)
            stats.has_nan = has_nan
            stats.has_inf = has_inf

            if module.weight.grad is not None:
                grad_stats = self._compute_gradient_stats(module.weight.grad)
                stats.grad_mean = grad_stats["mean"]
                stats.grad_std = grad_stats["std"]
                stats.grad_min = grad_stats["min"]
                stats.grad_max = grad_stats["max"]
                stats.grad_norm = grad_stats["norm"]
                stats.grad_sparsity = grad_stats["sparsity"]

        return stats


class RNNLayerAnalyzer(BaseLayerAnalyzer):
    """Analyzer for RNN/LSTM/GRU layers"""

    def supports(self, module: nn.Module) -> bool:
        return isinstance(module, (nn.RNN, nn.LSTM, nn.GRU))

    def analyze(self, module: nn.Module, name: str) -> LayerStatistics:
        rnn_type = module.__class__.__name__

        stats = LayerStatistics(
            name=name,
            layer_type=rnn_type,
            num_parameters=sum(p.numel() for p in module.parameters()),
        )

        # RNN layers have multiple weight matrices
        # Analyze all of them and aggregate
        all_weights = []
        all_grads = []

        for param_name, param in module.named_parameters():
            if "weight" in param_name:
                all_weights.append(param)
                if param.grad is not None:
                    all_grads.append(param.grad)

        # Aggregate weight statistics
        if all_weights:
            combined_weights = torch.cat([w.flatten() for w in all_weights])
            weight_stats = self._compute_weight_stats(combined_weights)
            stats.weight_mean = weight_stats["mean"]
            stats.weight_std = weight_stats["std"]
            stats.weight_min = weight_stats["min"]
            stats.weight_max = weight_stats["max"]
            stats.weight_norm = weight_stats["norm"]

            has_nan, has_inf = self._check_health(combined_weights)
            stats.has_nan = has_nan
            stats.has_inf = has_inf

        # Aggregate gradient statistics
        if all_grads:
            combined_grads = torch.cat([g.flatten() for g in all_grads])
            grad_stats = self._compute_gradient_stats(combined_grads)
            stats.grad_mean = grad_stats["mean"]
            stats.grad_std = grad_stats["std"]
            stats.grad_min = grad_stats["min"]
            stats.grad_max = grad_stats["max"]
            stats.grad_norm = grad_stats["norm"]
            stats.grad_sparsity = grad_stats["sparsity"]

        return stats


class AttentionLayerAnalyzer(BaseLayerAnalyzer):
    """Analyzer for Attention/Transformer layers"""

    def supports(self, module: nn.Module) -> bool:
        # Check for common attention layer patterns
        module_name = module.__class__.__name__.lower()
        return any(
            keyword in module_name
            for keyword in ["attention", "multihead", "selfattention", "crossattention"]
        )

    def analyze(self, module: nn.Module, name: str) -> LayerStatistics:
        stats = LayerStatistics(
            name=name,
            layer_type="Attention",
            num_parameters=sum(p.numel() for p in module.parameters()),
        )

        # Aggregate all parameters
        all_params = list(module.parameters())

        if all_params:
            # Weights
            combined_weights = torch.cat([p.flatten() for p in all_params])
            weight_stats = self._compute_weight_stats(combined_weights)
            stats.weight_mean = weight_stats["mean"]
            stats.weight_std = weight_stats["std"]
            stats.weight_min = weight_stats["min"]
            stats.weight_max = weight_stats["max"]
            stats.weight_norm = weight_stats["norm"]

            has_nan, has_inf = self._check_health(combined_weights)
            stats.has_nan = has_nan
            stats.has_inf = has_inf

            # Gradients
            grads_with_values = [p.grad for p in all_params if p.grad is not None]
            if grads_with_values:
                combined_grads = torch.cat([g.flatten() for g in grads_with_values])
                grad_stats = self._compute_gradient_stats(combined_grads)
                stats.grad_mean = grad_stats["mean"]
                stats.grad_std = grad_stats["std"]
                stats.grad_min = grad_stats["min"]
                stats.grad_max = grad_stats["max"]
                stats.grad_norm = grad_stats["norm"]
                stats.grad_sparsity = grad_stats["sparsity"]

        return stats


class NormalizationLayerAnalyzer(BaseLayerAnalyzer):
    """Analyzer for Normalization layers (BatchNorm, LayerNorm, etc.)"""

    def supports(self, module: nn.Module) -> bool:
        return isinstance(
            module,
            (
                nn.BatchNorm1d,
                nn.BatchNorm2d,
                nn.BatchNorm3d,
                nn.LayerNorm,
                nn.GroupNorm,
                nn.InstanceNorm1d,
                nn.InstanceNorm2d,
                nn.InstanceNorm3d,
            ),
        )

    def analyze(self, module: nn.Module, name: str) -> LayerStatistics:
        norm_type = module.__class__.__name__

        stats = LayerStatistics(
            name=name,
            layer_type=norm_type,
            num_parameters=sum(p.numel() for p in module.parameters()),
        )

        # Analyze scale/weight parameter
        if hasattr(module, "weight") and module.weight is not None:
            weight_stats = self._compute_weight_stats(module.weight)
            stats.weight_mean = weight_stats["mean"]
            stats.weight_std = weight_stats["std"]
            stats.weight_min = weight_stats["min"]
            stats.weight_max = weight_stats["max"]
            stats.weight_norm = weight_stats["norm"]

            if module.weight.grad is not None:
                grad_stats = self._compute_gradient_stats(module.weight.grad)
                stats.grad_norm = grad_stats["norm"]

        return stats


# ==================== Main Analytics Engine ====================


class AnalyticsEngine:
    """
    Main analytics engine for comprehensive model analysis

    Enterprise-grade features:
    - Automatic architecture detection
    - Extensible analyzer system
    - Multi-level analysis depth
    - Performance optimized
    - Type-safe
    """

    def __init__(
        self, model: nn.Module, analysis_level: AnalysisLevel = AnalysisLevel.STANDARD
    ):
        self.model = model
        self.analysis_level = analysis_level

        # Initialize analyzers
        self.analyzers: List[BaseLayerAnalyzer] = [
            LinearLayerAnalyzer(analysis_level),
            ConvLayerAnalyzer(analysis_level),
            RNNLayerAnalyzer(analysis_level),
            AttentionLayerAnalyzer(analysis_level),
            NormalizationLayerAnalyzer(analysis_level),
        ]

        # Detect architecture
        self.architecture_type = self._detect_architecture()

        _logger.info(
            f"AnalyticsEngine initialized for {self.architecture_type.value} "
            f"architecture with {analysis_level.value} analysis level"
        )

    def _detect_architecture(self) -> ArchitectureType:
        """Automatically detect model architecture type"""
        module_types = {type(m).__name__.lower() for m in self.model.modules()}

        # Detection heuristics
        if any("transformer" in name or "attention" in name for name in module_types):
            return ArchitectureType.TRANSFORMER
        elif any(
            "lstm" in name or "gru" in name or "rnn" in name for name in module_types
        ):
            if "lstm" in module_types:
                return ArchitectureType.LSTM
            elif "gru" in module_types:
                return ArchitectureType.GRU
            else:
                return ArchitectureType.RNN
        elif any(f"conv{i}d" in module_types for i in [1, 2, 3]):
            return ArchitectureType.CNN
        elif "linear" in module_types:
            return ArchitectureType.CUSTOM
        else:
            return ArchitectureType.CUSTOM

    def analyze_model(self) -> ModelStatistics:
        """
        Perform comprehensive model analysis

        Returns:
            ModelStatistics object with complete analysis
        """
        _logger.info("Starting comprehensive model analysis...")

        # Initialize statistics
        stats = ModelStatistics(
            architecture_type=self.architecture_type,
            total_parameters=sum(p.numel() for p in self.model.parameters()),
            trainable_parameters=sum(
                p.numel() for p in self.model.parameters() if p.requires_grad
            ),
            non_trainable_parameters=sum(
                p.numel() for p in self.model.parameters() if not p.requires_grad
            ),
        )

        # Analyze each layer
        for name, module in self.model.named_modules():
            if self._should_analyze(module):
                layer_stats = self._analyze_layer(module, name)
                if layer_stats:
                    stats.layer_stats[name] = layer_stats

        # Compute global statistics
        self._compute_global_stats(stats)

        # Detect health issues
        self._detect_health_issues(stats)

        _logger.info(f"Analysis complete. Analyzed {len(stats.layer_stats)} layers.")

        return stats

    def _should_analyze(self, module: nn.Module) -> bool:
        """Determine if a module should be analyzed"""
        # Skip container modules
        if isinstance(module, (nn.Sequential, nn.ModuleList, nn.ModuleDict)):
            return False

        # Check if module has parameters
        return len(list(module.parameters(recurse=False))) > 0

    def _analyze_layer(self, module: nn.Module, name: str) -> Optional[LayerStatistics]:
        """Analyze a single layer using appropriate analyzer"""
        for analyzer in self.analyzers:
            if analyzer.supports(module):
                try:
                    return analyzer.analyze(module, name)
                except Exception as e:
                    _logger.warning(
                        f"Failed to analyze layer {name}: {e}", exc_info=True
                    )
                    return None

        # Fallback: generic analysis
        return self._generic_analyze(module, name)

    def _generic_analyze(self, module: nn.Module, name: str) -> LayerStatistics:
        """Generic analysis for unsupported layer types"""
        stats = LayerStatistics(
            name=name,
            layer_type=module.__class__.__name__,
            num_parameters=sum(p.numel() for p in module.parameters()),
        )

        # Aggregate all parameters
        all_params = list(module.parameters())
        if all_params:
            combined = torch.cat([p.flatten() for p in all_params])
            stats.weight_norm = torch.norm(combined).item()

            grads = [p.grad for p in all_params if p.grad is not None]
            if grads:
                combined_grads = torch.cat([g.flatten() for g in grads])
                stats.grad_norm = torch.norm(combined_grads).item()

        return stats

    def _compute_global_stats(self, stats: ModelStatistics) -> None:
        """Compute model-wide statistics"""
        if not stats.layer_stats:
            return

        grad_norms = [
            ls.grad_norm for ls in stats.layer_stats.values() if ls.grad_norm > 0
        ]

        if grad_norms:
            stats.total_grad_norm = sum(grad_norms)
            stats.max_grad_norm = max(grad_norms)
            stats.min_grad_norm = min(grad_norms)
            stats.avg_grad_norm = np.mean(grad_norms)

    def _detect_health_issues(self, stats: ModelStatistics) -> None:
        """Detect common training issues"""
        EXPLODING_THRESHOLD = 100.0
        VANISHING_THRESHOLD = 1e-7
        DEAD_THRESHOLD = 0.5  # 50% dead neurons

        for layer_stats in stats.layer_stats.values():
            # Exploding gradients
            if layer_stats.grad_norm > EXPLODING_THRESHOLD:
                stats.num_exploding_layers += 1

            # Vanishing gradients
            if 0 < layer_stats.grad_norm < VANISHING_THRESHOLD:
                stats.num_vanishing_layers += 1

            # Dead neurons
            if layer_stats.dead_neuron_ratio > DEAD_THRESHOLD:
                stats.num_dead_layers += 1

            # Frozen layers (no gradient updates)
            if layer_stats.grad_norm == 0 and layer_stats.num_parameters > 0:
                stats.num_frozen_layers += 1
                layer_stats.is_frozen = True

    def analyze_training_dynamics(
        self,
        loss_history: List[float],
        learning_rates: List[float],
        validation_loss: Optional[List[float]] = None,
    ) -> Dict[str, Any]:
        """
        Analyze training dynamics and provide insights

        Args:
            loss_history: Training loss values
            learning_rates: Learning rate schedule
            validation_loss: Optional validation loss values

        Returns:
            Dictionary with training dynamics analysis
        """
        if not loss_history:
            return {}

        analysis = {
            "convergence": self._analyze_convergence(loss_history),
            "learning_rate_impact": self._analyze_lr_impact(
                loss_history, learning_rates
            ),
            "overfitting": self._detect_overfitting(loss_history, validation_loss),
            "training_stability": self._analyze_stability(loss_history),
            "recommendations": [],
        }

        # Generate recommendations
        analysis["recommendations"] = self._generate_recommendations(analysis)

        return analysis

    def _analyze_convergence(self, loss_history: List[float]) -> Dict[str, Any]:
        """Analyze convergence patterns"""
        if len(loss_history) < 10:
            # For short histories, still attempt a coarse convergence check
            if len(loss_history) >= 3:
                early_avg = np.mean(loss_history[:1])
                recent_avg = np.mean(loss_history[-1:])
                improvement = (early_avg - recent_avg) / max(early_avg, 1e-8)
                status = "converging" if improvement > 0.05 else "plateaued"
                return {
                    "status": status,
                    "trend": "unknown",
                    "improvement_ratio": improvement,
                }
            return {"status": "plateaued", "trend": "unknown"}

        # Calculate moving average
        window_size = min(10, len(loss_history) // 4)
        recent_losses = loss_history[-window_size:]
        early_losses = loss_history[:window_size]

        recent_avg = np.mean(recent_losses)
        early_avg = np.mean(early_losses)

        improvement = (early_avg - recent_avg) / early_avg

        # Determine convergence status
        if improvement > 0.1:
            status = "converging"
        elif improvement > 0.01:
            status = "slow_convergence"
        else:
            status = "plateaued"

        # Calculate trend
        if len(loss_history) >= 20:
            x = np.arange(len(loss_history))
            slope = np.polyfit(x, loss_history, 1)[0]
            trend = (
                "decreasing"
                if slope < -1e-6
                else "increasing"
                if slope > 1e-6
                else "stable"
            )
        else:
            trend = "unknown"

        return {
            "status": status,
            "trend": trend,
            "improvement_ratio": improvement,
            "recent_average": recent_avg,
            "early_average": early_avg,
        }

    def _analyze_lr_impact(
        self, loss_history: List[float], learning_rates: List[float]
    ) -> Dict[str, Any]:
        """Analyze learning rate impact on training"""
        if len(learning_rates) != len(loss_history):
            return {"status": "mismatched_data"}

        # Find learning rate changes
        lr_changes = []
        for i in range(1, len(learning_rates)):
            if abs(learning_rates[i] - learning_rates[i - 1]) > 1e-8:
                lr_changes.append(i)

        if not lr_changes:
            return {"status": "constant_lr", "lr": learning_rates[0]}

        # Analyze impact of LR changes
        impacts = []
        for change_idx in lr_changes:
            if change_idx < 5:  # Need some history
                continue

            pre_losses = loss_history[change_idx - 5 : change_idx]
            post_losses = loss_history[change_idx : change_idx + 5]

            if len(pre_losses) > 0 and len(post_losses) > 0:
                pre_avg = np.mean(pre_losses)
                post_avg = np.mean(post_losses)
                impact = (post_avg - pre_avg) / pre_avg
                impacts.append(impact)

        return {
            "status": "lr_changes_detected",
            "num_changes": len(lr_changes),
            "avg_impact": np.mean(impacts) if impacts else 0,
            "impacts": impacts,
        }

    def _detect_overfitting(
        self, train_loss: List[float], val_loss: Optional[List[float]]
    ) -> Dict[str, Any]:
        """Detect overfitting patterns"""
        if val_loss is None or len(val_loss) != len(train_loss):
            return {"status": "no_validation_data"}

        if len(train_loss) < 10:
            # For short histories, estimate using available tail
            recent_train = np.mean(train_loss[-1:])
            recent_val = np.mean(val_loss[-1:])
            overfitting_ratio = (recent_val - recent_train) / max(recent_train, 1e-8)
            status = (
                "overfitting"
                if overfitting_ratio > 0.1
                else "mild_overfitting"
                if overfitting_ratio > 0.05
                else "healthy"
            )
            return {
                "status": status,
                "overfitting_ratio": overfitting_ratio,
                "train_loss_final": recent_train,
                "val_loss_final": recent_val,
            }

        # Calculate overfitting metric
        recent_train = np.mean(train_loss[-5:])
        recent_val = np.mean(val_loss[-5:])

        overfitting_ratio = (recent_val - recent_train) / recent_train

        # Determine overfitting status
        if overfitting_ratio > 0.1:
            status = "overfitting"
        elif overfitting_ratio > 0.05:
            status = "mild_overfitting"
        else:
            status = "healthy"

        return {
            "status": status,
            "overfitting_ratio": overfitting_ratio,
            "train_loss_final": recent_train,
            "val_loss_final": recent_val,
        }

    def _analyze_stability(self, loss_history: List[float]) -> Dict[str, Any]:
        """Analyze training stability"""
        if len(loss_history) < 10:
            # Provide a coarse stability assessment for short histories
            if len(loss_history) <= 1:
                return {
                    "stability": "unknown",
                    "volatility": 0.0,
                    "num_spikes": 0,
                    "spike_indices": [],
                }
            returns = np.diff(np.log(np.array(loss_history) + 1e-8))
            volatility = float(np.std(returns))
            mean_loss = float(np.mean(loss_history))
            std_loss = float(np.std(loss_history))
            threshold = 2 * std_loss
            spikes = [
                i
                for i, loss in enumerate(loss_history)
                if abs(loss - mean_loss) > threshold
            ]
            if volatility < 0.1:
                stability = "very_stable"
            elif volatility < 0.3:
                stability = "stable"
            elif volatility < 0.5:
                stability = "moderate"
            else:
                stability = "unstable"
            return {
                "stability": stability,
                "volatility": volatility,
                "num_spikes": len(spikes),
                "spike_indices": spikes,
            }

        # Calculate volatility
        returns = np.diff(
            np.log(loss_history + 1e-8)
        )  # Add small epsilon to avoid log(0)
        volatility = np.std(returns)

        # Detect spikes
        threshold = 2 * np.std(loss_history)
        spikes = [
            i
            for i, loss in enumerate(loss_history)
            if abs(loss - np.mean(loss_history)) > threshold
        ]

        # Stability assessment
        if volatility < 0.1:
            stability = "very_stable"
        elif volatility < 0.3:
            stability = "stable"
        elif volatility < 0.5:
            stability = "moderate"
        else:
            stability = "unstable"

        return {
            "stability": stability,
            "volatility": volatility,
            "num_spikes": len(spikes),
            "spike_indices": spikes,
        }

    def _generate_recommendations(self, analysis: Dict[str, Any]) -> List[str]:
        """Generate actionable recommendations based on analysis"""
        recommendations = []

        # Convergence recommendations
        convergence = analysis.get("convergence", {})
        if convergence.get("status") == "plateaued":
            recommendations.append(
                "Consider reducing learning rate or using learning rate scheduling"
            )
        elif convergence.get("status") == "slow_convergence":
            recommendations.append(
                "Training is converging slowly - consider increasing learning rate"
            )

        # Overfitting recommendations
        overfitting = analysis.get("overfitting", {})
        if overfitting.get("status") == "overfitting":
            recommendations.append(
                "Strong overfitting detected - consider regularization or early stopping"
            )
        elif overfitting.get("status") == "mild_overfitting":
            recommendations.append(
                "Mild overfitting - consider adding dropout or data augmentation"
            )

        # Stability recommendations
        stability = analysis.get("training_stability", {})
        if stability.get("stability") == "unstable":
            recommendations.append(
                "Training is unstable - consider gradient clipping or smaller learning rate"
            )

        return recommendations

    def get_layer_importance(self, stats: ModelStatistics) -> Dict[str, float]:
        """
        Calculate layer importance based on gradient norms and parameter counts

        Args:
            stats: Model statistics

        Returns:
            Dictionary mapping layer names to importance scores
        """
        importance_scores = {}

        for name, layer_stats in stats.layer_stats.items():
            # Combine gradient norm and parameter count for importance
            grad_importance = layer_stats.grad_norm
            param_importance = np.log(layer_stats.num_parameters + 1)

            # Weighted combination
            importance = 0.7 * grad_importance + 0.3 * param_importance
            importance_scores[name] = importance

        # Normalize to 0-1 range
        if importance_scores:
            max_importance = max(importance_scores.values())
            if max_importance > 0:
                importance_scores = {
                    name: score / max_importance
                    for name, score in importance_scores.items()
                }

        return importance_scores

    def detect_bottlenecks(self, stats: ModelStatistics) -> List[Dict[str, Any]]:
        """
        Detect potential bottlenecks in the model

        Args:
            stats: Model statistics

        Returns:
            List of bottleneck descriptions
        """
        bottlenecks = []

        # Sort layers by parameter count
        sorted_layers = sorted(
            stats.layer_stats.items(), key=lambda x: x[1].num_parameters, reverse=True
        )

        # Check for parameter-heavy layers
        total_params = stats.total_parameters
        for name, layer_stats in sorted_layers[:3]:  # Top 3 heaviest layers
            param_ratio = layer_stats.num_parameters / total_params
            if param_ratio > 0.3:  # More than 30% of parameters
                bottlenecks.append(
                    {
                        "type": "parameter_heavy",
                        "layer": name,
                        "parameter_ratio": param_ratio,
                        "description": f"Layer {name} contains {param_ratio:.1%} of all parameters",
                    }
                )

        # Check for gradient issues
        for name, layer_stats in stats.layer_stats.items():
            if layer_stats.grad_norm > 100:
                bottlenecks.append(
                    {
                        "type": "exploding_gradients",
                        "layer": name,
                        "grad_norm": layer_stats.grad_norm,
                        "description": f"Exploding gradients in {name} (norm: {layer_stats.grad_norm:.2f})",
                    }
                )
            elif 0 < layer_stats.grad_norm < 1e-7:
                bottlenecks.append(
                    {
                        "type": "vanishing_gradients",
                        "layer": name,
                        "grad_norm": layer_stats.grad_norm,
                        "description": f"Vanishing gradients in {name} (norm: {layer_stats.grad_norm:.2e})",
                    }
                )

        # Check for dead layers
        for name, layer_stats in stats.layer_stats.items():
            if layer_stats.dead_neuron_ratio > 0.8:
                bottlenecks.append(
                    {
                        "type": "dead_neurons",
                        "layer": name,
                        "dead_ratio": layer_stats.dead_neuron_ratio,
                        "description": f"High dead neuron ratio in {name} ({layer_stats.dead_neuron_ratio:.1%})",
                    }
                )

        return bottlenecks

    def export_analysis(
        self, stats: ModelStatistics, format: str = "json"
    ) -> Union[str, Dict]:
        """
        Export analysis results in various formats

        Args:
            stats: Model statistics
            format: Export format ('json', 'yaml', 'csv')

        Returns:
            Exported data in requested format
        """
        data = stats.to_dict()

        if format.lower() == "json":
            import json

            return json.dumps(data, indent=2, default=str)
        elif format.lower() == "yaml":
            try:
                import yaml  # type: ignore

                return yaml.dump(data, default_flow_style=False)
            except ImportError:
                # Minimal YAML fallback to avoid hard dependency on PyYAML
                def _to_yaml(obj: Any, indent: int = 0) -> str:
                    space = "  " * indent
                    if isinstance(obj, dict):
                        lines: List[str] = []
                        for k, v in obj.items():
                            if isinstance(v, (dict, list)):
                                lines.append(f"{space}{k}:")
                                lines.append(_to_yaml(v, indent + 1))
                            else:
                                lines.append(f"{space}{k}: {v}")
                        return "\n".join(lines)
                    elif isinstance(obj, list):
                        lines: List[str] = []
                        for item in obj:
                            if isinstance(item, (dict, list)):
                                lines.append(f"{space}-")
                                lines.append(_to_yaml(item, indent + 1))
                            else:
                                lines.append(f"{space}- {item}")
                        return "\n".join(lines)
                    else:
                        return f"{space}{obj}"

                return _to_yaml(data)
        elif format.lower() == "csv":
            # Export layer statistics as CSV
            import csv
            import io

            output = io.StringIO()
            writer = csv.writer(output)

            # Header
            writer.writerow(
                [
                    "Layer",
                    "Type",
                    "Parameters",
                    "Grad_Norm",
                    "Weight_Norm",
                    "Dead_Neurons",
                    "Has_NaN",
                    "Has_Inf",
                    "Is_Frozen",
                ]
            )

            # Data rows
            for name, layer_stats in stats.layer_stats.items():
                writer.writerow(
                    [
                        name,
                        layer_stats.layer_type,
                        layer_stats.num_parameters,
                        layer_stats.grad_norm,
                        layer_stats.weight_norm,
                        layer_stats.dead_neuron_ratio,
                        layer_stats.has_nan,
                        layer_stats.has_inf,
                        layer_stats.is_frozen,
                    ]
                )

            return output.getvalue()
        else:
            raise ValueError(f"Unsupported format: {format}")


# ==================== Utility Functions ====================


def create_analytics_engine(
    model: nn.Module, analysis_level: AnalysisLevel = AnalysisLevel.STANDARD
) -> AnalyticsEngine:
    """
    Factory function to create an analytics engine

    Args:
        model: PyTorch model to analyze
        analysis_level: Level of analysis detail

    Returns:
        Configured AnalyticsEngine instance
    """
    return AnalyticsEngine(model, analysis_level)


def quick_analysis(model: nn.Module) -> Dict[str, Any]:
    """
    Perform a quick analysis of the model

    Args:
        model: PyTorch model to analyze

    Returns:
        Quick analysis summary
    """
    engine = AnalyticsEngine(model, AnalysisLevel.BASIC)
    stats = engine.analyze_model()

    return {
        "architecture": stats.architecture_type.value,
        "total_parameters": stats.total_parameters,
        "trainable_parameters": stats.trainable_parameters,
        "num_layers": len(stats.layer_stats),
        "health_issues": {
            "dead_layers": stats.num_dead_layers,
            "exploding_layers": stats.num_exploding_layers,
            "vanishing_layers": stats.num_vanishing_layers,
            "frozen_layers": stats.num_frozen_layers,
        },
    }

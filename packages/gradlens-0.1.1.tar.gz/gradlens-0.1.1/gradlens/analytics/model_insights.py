"""
Advanced Model Insights and Analysis

This module provides deep insights into model architecture,
behavior, and optimization opportunities.

Features:
- Architecture analysis
- Bottleneck detection
- Model capacity analysis
- Feature importance analysis
- Optimization recommendations
- Model comparison tools
"""

from typing import Dict, List, Any
from dataclasses import dataclass, field
from enum import Enum
import logging
from collections import defaultdict

from .analytics_engine import ModelStatistics, ArchitectureType

_logger = logging.getLogger(__name__)


# ==================== Enums and Data Classes ====================


class InsightType(Enum):
    """Types of insights"""

    ARCHITECTURE = "architecture"
    CAPACITY = "capacity"
    BOTTLENECK = "bottleneck"
    FEATURE_IMPORTANCE = "feature_importance"
    OPTIMIZATION = "optimization"
    COMPARISON = "comparison"


class SeverityLevel(Enum):
    """Severity levels for insights"""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class Insight:
    """Individual insight about the model"""

    insight_type: InsightType
    severity: SeverityLevel
    title: str
    description: str
    recommendation: str
    affected_layers: List[str] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "insight_type": self.insight_type.value,
            "severity": self.severity.value,
            "title": self.title,
            "description": self.description,
            "recommendation": self.recommendation,
            "affected_layers": self.affected_layers,
            "metrics": self.metrics,
            "confidence": self.confidence,
        }


@dataclass
class ModelInsightsResult:
    """Comprehensive model insights"""

    model_id: str
    architecture_type: ArchitectureType
    total_insights: int
    insights: List[Insight] = field(default_factory=list)
    overall_health_score: float = 0.0
    optimization_potential: float = 0.0
    complexity_score: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "model_id": self.model_id,
            "architecture_type": self.architecture_type.value,
            "total_insights": self.total_insights,
            "insights": [insight.to_dict() for insight in self.insights],
            "overall_health_score": self.overall_health_score,
            "optimization_potential": self.optimization_potential,
            "complexity_score": self.complexity_score,
        }


class ArchitectureAnalyzer:
    """Analyzer for model architecture insights"""

    def __init__(self):
        self._layer_patterns = {
            "convolutional": ["Conv1d", "Conv2d", "Conv3d"],
            "recurrent": ["RNN", "LSTM", "GRU"],
            "attention": ["MultiheadAttention", "SelfAttention"],
            "normalization": ["BatchNorm1d", "BatchNorm2d", "BatchNorm3d", "LayerNorm"],
            "activation": ["ReLU", "Sigmoid", "Tanh", "GELU", "Swish"],
            "pooling": [
                "MaxPool1d",
                "MaxPool2d",
                "MaxPool3d",
                "AvgPool1d",
                "AvgPool2d",
                "AvgPool3d",
            ],
            "dropout": ["Dropout", "Dropout2d", "Dropout3d"],
            "linear": ["Linear"],
        }

    def analyze_architecture(self, stats: ModelStatistics) -> List[Insight]:
        """Analyze model architecture and return insights"""
        insights = []

        # Analyze layer distribution
        layer_distribution = self._analyze_layer_distribution(stats)
        insights.extend(layer_distribution)

        # Analyze depth and width
        depth_insights = self._analyze_model_depth(stats)
        insights.extend(depth_insights)

        # Analyze parameter distribution
        param_insights = self._analyze_parameter_distribution(stats)
        insights.extend(param_insights)

        # Analyze architectural patterns
        pattern_insights = self._analyze_architectural_patterns(stats)
        insights.extend(pattern_insights)

        return insights

    def _analyze_layer_distribution(self, stats: ModelStatistics) -> List[Insight]:
        """Analyze distribution of layer types"""
        insights = []

        # Count layers by type
        layer_counts = defaultdict(int)
        for layer_stats in stats.layer_stats.values():
            layer_counts[layer_stats.layer_type] += 1

        total_layers = len(stats.layer_stats)

        # Check for imbalanced layer distribution
        for layer_type, count in layer_counts.items():
            percentage = count / total_layers * 100

            if percentage > 60:  # More than 60% of one type
                insights.append(
                    Insight(
                        insight_type=InsightType.ARCHITECTURE,
                        severity=SeverityLevel.MEDIUM,
                        title="Imbalanced Layer Distribution",
                        description=f"Layer type '{layer_type}' represents {percentage:.1f}% of all layers",
                        recommendation="Consider diversifying layer types for better representation learning",
                        metrics={
                            "layer_type": layer_type,
                            "percentage": percentage,
                            "count": count,
                        },
                    )
                )

        return insights

    def _analyze_model_depth(self, stats: ModelStatistics) -> List[Insight]:
        """Analyze model depth and width"""
        insights = []

        # Calculate depth (number of layers)
        depth = len(stats.layer_stats)

        # Calculate width (average parameters per layer)
        total_params = stats.total_parameters
        avg_width = total_params / depth if depth > 0 else 0

        # Depth analysis
        if depth > 100:
            insights.append(
                Insight(
                    insight_type=InsightType.ARCHITECTURE,
                    severity=SeverityLevel.MEDIUM,
                    title="Very Deep Model",
                    description=f"Model has {depth} layers, which may lead to vanishing gradients",
                    recommendation="Consider skip connections, residual blocks, or gradient clipping",
                    metrics={"depth": depth},
                )
            )
        elif depth < 3:
            insights.append(
                Insight(
                    insight_type=InsightType.ARCHITECTURE,
                    severity=SeverityLevel.LOW,
                    title="Shallow Model",
                    description=f"Model has only {depth} layers, which may limit representational capacity",
                    recommendation="Consider adding more layers or increasing layer width",
                    metrics={"depth": depth},
                )
            )

        # Width analysis
        if avg_width > 1000000:  # More than 1M parameters per layer
            insights.append(
                Insight(
                    insight_type=InsightType.ARCHITECTURE,
                    severity=SeverityLevel.MEDIUM,
                    title="Very Wide Layers",
                    description=f"Average layer width is {avg_width:,.0f} parameters",
                    recommendation="Consider reducing layer width or using more efficient architectures",
                    metrics={"avg_width": avg_width},
                )
            )

        return insights

    def _analyze_parameter_distribution(self, stats: ModelStatistics) -> List[Insight]:
        """Analyze parameter distribution across layers"""
        insights = []

        # Get parameter counts per layer
        param_counts = [
            layer_stats.num_parameters for layer_stats in stats.layer_stats.values()
        ]

        if not param_counts:
            return insights

        # Calculate statistics
        total_params = sum(param_counts)

        # Check for parameter imbalance
        param_ratios = [count / total_params for count in param_counts]
        max_ratio = max(param_ratios)

        if max_ratio > 0.5:  # One layer has more than 50% of parameters
            max_layer_idx = param_ratios.index(max_ratio)
            max_layer_name = list(stats.layer_stats.keys())[max_layer_idx]

            insights.append(
                Insight(
                    insight_type=InsightType.ARCHITECTURE,
                    severity=SeverityLevel.HIGH,
                    title="Parameter Imbalance",
                    description=f"Layer '{max_layer_name}' contains {max_ratio:.1%} of all parameters",
                    recommendation="Consider redistributing parameters or using more balanced architectures",
                    affected_layers=[max_layer_name],
                    metrics={"max_ratio": max_ratio, "layer_name": max_layer_name},
                )
            )

        # Check for very small layers
        small_layers = [
            name
            for name, count in zip(stats.layer_stats.keys(), param_counts)
            if count < 100
        ]
        if small_layers:
            insights.append(
                Insight(
                    insight_type=InsightType.ARCHITECTURE,
                    severity=SeverityLevel.LOW,
                    title="Very Small Layers",
                    description=f"Found {len(small_layers)} layers with less than 100 parameters",
                    recommendation="Consider merging small layers or increasing their capacity",
                    affected_layers=small_layers,
                    metrics={"small_layer_count": len(small_layers)},
                )
            )

        return insights

    def _analyze_architectural_patterns(self, stats: ModelStatistics) -> List[Insight]:
        """Analyze architectural patterns and best practices"""
        insights = []

        # Check for common patterns
        layer_types = [
            layer_stats.layer_type for layer_stats in stats.layer_stats.values()
        ]

        # Check for missing normalization
        has_normalization = any(
            layer_type in self._layer_patterns["normalization"]
            for layer_type in layer_types
        )
        has_conv = any(
            layer_type in self._layer_patterns["convolutional"]
            for layer_type in layer_types
        )

        if has_conv and not has_normalization:
            insights.append(
                Insight(
                    insight_type=InsightType.ARCHITECTURE,
                    severity=SeverityLevel.MEDIUM,
                    title="Missing Normalization",
                    description="Convolutional layers found but no normalization layers detected",
                    recommendation="Add BatchNorm or LayerNorm layers for better training stability",
                    metrics={
                        "has_conv": has_conv,
                        "has_normalization": has_normalization,
                    },
                )
            )

        # Check for activation function diversity
        activation_layers = [
            layer_type
            for layer_type in layer_types
            if layer_type in self._layer_patterns["activation"]
        ]
        if len(set(activation_layers)) == 1 and len(activation_layers) > 3:
            insights.append(
                Insight(
                    insight_type=InsightType.ARCHITECTURE,
                    severity=SeverityLevel.LOW,
                    title="Limited Activation Diversity",
                    description=f"Only using {activation_layers[0]} activation function",
                    recommendation="Consider using different activation functions for different layers",
                    metrics={"activation_types": len(set(activation_layers))},
                )
            )

        return insights


class BottleneckDetector:
    """Detector for model bottlenecks and inefficiencies"""

    def __init__(self):
        self.performance_thresholds = {
            "slow_layer_time_ms": 100,
            "memory_intensive_mb": 1000,
            "low_efficiency": 0.5,
            "high_sparsity": 0.8,
        }

    def detect_bottlenecks(self, stats: ModelStatistics) -> List[Insight]:
        """Detect bottlenecks in the model"""
        insights = []

        # Performance bottlenecks
        perf_insights = self._detect_performance_bottlenecks(stats)
        insights.extend(perf_insights)

        # Memory bottlenecks
        memory_insights = self._detect_memory_bottlenecks(stats)
        insights.extend(memory_insights)

        # Efficiency bottlenecks
        efficiency_insights = self._detect_efficiency_bottlenecks(stats)
        insights.extend(efficiency_insights)

        # Gradient bottlenecks
        gradient_insights = self._detect_gradient_bottlenecks(stats)
        insights.extend(gradient_insights)

        return insights

    def _detect_performance_bottlenecks(self, stats: ModelStatistics) -> List[Insight]:
        """Detect performance bottlenecks"""
        insights = []

        # Find slow layers
        slow_layers = []
        for name, layer_stats in stats.layer_stats.items():
            if (
                layer_stats.forward_time_ms
                > self.performance_thresholds["slow_layer_time_ms"]
            ):
                slow_layers.append((name, layer_stats.forward_time_ms))

        if slow_layers:
            slowest_layer = max(slow_layers, key=lambda x: x[1])
            insights.append(
                Insight(
                    insight_type=InsightType.BOTTLENECK,
                    severity=SeverityLevel.HIGH,
                    title="Slow Layer Detected",
                    description=f"Layer '{slowest_layer[0]}' takes {slowest_layer[1]:.1f}ms per forward pass",
                    recommendation="Consider optimizing this layer or using more efficient implementations",
                    affected_layers=[slowest_layer[0]],
                    metrics={"forward_time_ms": slowest_layer[1]},
                )
            )

        return insights

    def _detect_memory_bottlenecks(self, stats: ModelStatistics) -> List[Insight]:
        """Detect memory bottlenecks"""
        insights = []

        # Find memory-intensive layers
        memory_layers = []
        for name, layer_stats in stats.layer_stats.items():
            if (
                layer_stats.memory_mb
                > self.performance_thresholds["memory_intensive_mb"]
            ):
                memory_layers.append((name, layer_stats.memory_mb))

        if memory_layers:
            memory_intensive_layer = max(memory_layers, key=lambda x: x[1])
            insights.append(
                Insight(
                    insight_type=InsightType.BOTTLENECK,
                    severity=SeverityLevel.HIGH,
                    title="Memory-Intensive Layer",
                    description=f"Layer '{memory_intensive_layer[0]}' uses {memory_intensive_layer[1]:.1f}MB of memory",
                    recommendation="Consider reducing batch size, using gradient checkpointing, or model parallelism",
                    affected_layers=[memory_intensive_layer[0]],
                    metrics={"memory_mb": memory_intensive_layer[1]},
                )
            )

        return insights

    def _detect_efficiency_bottlenecks(self, stats: ModelStatistics) -> List[Insight]:
        """Detect efficiency bottlenecks"""
        insights = []

        # Find inefficient layers
        inefficient_layers = []
        for name, layer_stats in stats.layer_stats.items():
            if (
                hasattr(layer_stats, "compute_efficiency")
                and layer_stats.compute_efficiency
                < self.performance_thresholds["low_efficiency"]
            ):
                inefficient_layers.append((name, layer_stats.compute_efficiency))

        if inefficient_layers:
            most_inefficient = min(inefficient_layers, key=lambda x: x[1])
            insights.append(
                Insight(
                    insight_type=InsightType.BOTTLENECK,
                    severity=SeverityLevel.MEDIUM,
                    title="Inefficient Layer",
                    description=f"Layer '{most_inefficient[0]}' has low compute efficiency ({most_inefficient[1]:.1%})",
                    recommendation="Consider using more efficient operations or mixed precision training",
                    affected_layers=[most_inefficient[0]],
                    metrics={"efficiency": most_inefficient[1]},
                )
            )

        return insights

    def _detect_gradient_bottlenecks(self, stats: ModelStatistics) -> List[Insight]:
        """Detect gradient-related bottlenecks"""
        insights = []

        # Find layers with gradient issues
        exploding_layers = []
        vanishing_layers = []

        for name, layer_stats in stats.layer_stats.items():
            if layer_stats.grad_norm > 100:
                exploding_layers.append((name, layer_stats.grad_norm))
            elif 0 < layer_stats.grad_norm < 1e-7:
                vanishing_layers.append((name, layer_stats.grad_norm))

        if exploding_layers:
            worst_exploding = max(exploding_layers, key=lambda x: x[1])
            insights.append(
                Insight(
                    insight_type=InsightType.BOTTLENECK,
                    severity=SeverityLevel.CRITICAL,
                    title="Exploding Gradients",
                    description=f"Layer '{worst_exploding[0]}' has exploding gradients (norm: {worst_exploding[1]:.2f})",
                    recommendation="Use gradient clipping, reduce learning rate, or check for numerical instability",
                    affected_layers=[worst_exploding[0]],
                    metrics={"grad_norm": worst_exploding[1]},
                )
            )

        if vanishing_layers:
            worst_vanishing = min(vanishing_layers, key=lambda x: x[1])
            insights.append(
                Insight(
                    insight_type=InsightType.BOTTLENECK,
                    severity=SeverityLevel.HIGH,
                    title="Vanishing Gradients",
                    description=f"Layer '{worst_vanishing[0]}' has vanishing gradients (norm: {worst_vanishing[1]:.2e})",
                    recommendation="Use skip connections, better weight initialization, or different activation functions",
                    affected_layers=[worst_vanishing[0]],
                    metrics={"grad_norm": worst_vanishing[1]},
                )
            )

        return insights


class ModelInsights:
    """Main class for generating comprehensive model insights"""

    def __init__(self):
        self.architecture_analyzer = ArchitectureAnalyzer()
        self.bottleneck_detector = BottleneckDetector()

    def analyze_model(
        self, stats: ModelStatistics, model_id: str = "model"
    ) -> ModelInsightsResult:
        """
        Generate comprehensive insights for a model

        Args:
            stats: Model statistics
            model_id: Unique identifier for the model

        Returns:
            Comprehensive model insights
        """
        insights = []

        # Architecture analysis
        arch_insights = self.architecture_analyzer.analyze_architecture(stats)
        insights.extend(arch_insights)

        # Bottleneck detection
        bottleneck_insights = self.bottleneck_detector.detect_bottlenecks(stats)
        insights.extend(bottleneck_insights)

        # Capacity analysis
        capacity_insights = self._analyze_model_capacity(stats)
        insights.extend(capacity_insights)

        # Calculate overall scores
        health_score = self._calculate_health_score(insights)
        optimization_potential = self._calculate_optimization_potential(insights)
        complexity_score = self._calculate_complexity_score(stats)

        return ModelInsightsResult(
            model_id=model_id,
            architecture_type=stats.architecture_type,
            total_insights=len(insights),
            insights=insights,
            overall_health_score=health_score,
            optimization_potential=optimization_potential,
            complexity_score=complexity_score,
        )

    def _analyze_model_capacity(self, stats: ModelStatistics) -> List[Insight]:
        """Analyze model capacity and representational power"""
        insights = []

        # Calculate capacity metrics
        total_params = stats.total_parameters
        trainable_params = stats.trainable_parameters
        non_trainable_ratio = (
            (total_params - trainable_params) / total_params if total_params > 0 else 0
        )

        # Check for frozen parameters
        if non_trainable_ratio > 0.5:
            insights.append(
                Insight(
                    insight_type=InsightType.CAPACITY,
                    severity=SeverityLevel.MEDIUM,
                    title="High Frozen Parameter Ratio",
                    description=f"{non_trainable_ratio:.1%} of parameters are frozen",
                    recommendation="Consider unfreezing more parameters or using transfer learning more effectively",
                    metrics={"frozen_ratio": non_trainable_ratio},
                )
            )

        # Check for dead neurons
        dead_layers = [
            name
            for name, layer_stats in stats.layer_stats.items()
            if layer_stats.dead_neuron_ratio > 0.8
        ]

        if dead_layers:
            insights.append(
                Insight(
                    insight_type=InsightType.CAPACITY,
                    severity=SeverityLevel.HIGH,
                    title="Dead Neurons Detected",
                    description=f"Found dead neurons in {len(dead_layers)} layers",
                    recommendation="Consider using different activation functions, better initialization, or data preprocessing",
                    affected_layers=dead_layers,
                    metrics={"dead_layer_count": len(dead_layers)},
                )
            )

        return insights

    def _calculate_health_score(self, insights: List[Insight]) -> float:
        """Calculate overall health score (0-1, higher is better)"""
        if not insights:
            return 1.0

        # Weight insights by severity
        severity_weights = {
            SeverityLevel.LOW: 0.1,
            SeverityLevel.MEDIUM: 0.3,
            SeverityLevel.HIGH: 0.6,
            SeverityLevel.CRITICAL: 0.9,
        }

        total_weight = sum(severity_weights[insight.severity] for insight in insights)
        max_weight = len(insights) * 0.9  # Maximum possible weight

        health_score = 1.0 - (total_weight / max_weight) if max_weight > 0 else 1.0
        return max(0.0, min(1.0, health_score))

    def _calculate_optimization_potential(self, insights: List[Insight]) -> float:
        """Calculate optimization potential (0-1, higher means more room for improvement)"""
        if not insights:
            return 0.0

        # Count insights by type
        type_counts = defaultdict(int)
        for insight in insights:
            type_counts[insight.insight_type] += 1

        # Weight by insight type
        type_weights = {
            InsightType.OPTIMIZATION: 1.0,
            InsightType.BOTTLENECK: 0.8,
            InsightType.ARCHITECTURE: 0.6,
            InsightType.CAPACITY: 0.4,
            InsightType.FEATURE_IMPORTANCE: 0.2,
            InsightType.COMPARISON: 0.1,
        }

        weighted_score = sum(
            type_counts[insight_type] * weight
            for insight_type, weight in type_weights.items()
        )

        # Normalize to 0-1
        max_possible = len(insights) * max(type_weights.values())
        optimization_potential = (
            weighted_score / max_possible if max_possible > 0 else 0.0
        )

        return min(1.0, optimization_potential)

    def _calculate_complexity_score(self, stats: ModelStatistics) -> float:
        """Calculate model complexity score (0-1, higher means more complex)"""
        # Factors: number of parameters, number of layers, architecture type
        param_score = min(1.0, stats.total_parameters / 10000000)  # 10M params = 1.0
        layer_score = min(1.0, len(stats.layer_stats) / 100)  # 100 layers = 1.0

        # Architecture complexity
        arch_complexity = {
            ArchitectureType.CUSTOM: 0.5,
            ArchitectureType.CNN: 0.6,
            ArchitectureType.RNN: 0.7,
            ArchitectureType.LSTM: 0.8,
            ArchitectureType.GRU: 0.8,
            ArchitectureType.TRANSFORMER: 0.9,
            ArchitectureType.GAN: 0.9,
            ArchitectureType.VAE: 0.8,
            ArchitectureType.RESNET: 0.7,
            ArchitectureType.ATTENTION: 0.8,
            ArchitectureType.GRAPH: 0.9,
        }

        arch_score = arch_complexity.get(stats.architecture_type, 0.5)

        # Weighted combination
        complexity_score = 0.4 * param_score + 0.3 * layer_score + 0.3 * arch_score

        return min(1.0, complexity_score)

    def compare_models(
        self, insights1: ModelInsightsResult, insights2: ModelInsightsResult
    ) -> Dict[str, Any]:
        """Compare two models based on their insights"""
        comparison = {
            "model1": insights1.to_dict(),
            "model2": insights2.to_dict(),
            "comparison": {},
        }

        # Compare health scores
        comparison["comparison"]["health_score"] = {
            "model1": insights1.overall_health_score,
            "model2": insights2.overall_health_score,
            "better": "model1"
            if insights1.overall_health_score > insights2.overall_health_score
            else "model2",
        }

        # Compare optimization potential
        comparison["comparison"]["optimization_potential"] = {
            "model1": insights1.optimization_potential,
            "model2": insights2.optimization_potential,
            "better": "model1"
            if insights1.optimization_potential < insights2.optimization_potential
            else "model2",
        }

        # Compare complexity
        comparison["comparison"]["complexity"] = {
            "model1": insights1.complexity_score,
            "model2": insights2.complexity_score,
            "better": "model1"
            if insights1.complexity_score < insights2.complexity_score
            else "model2",
        }

        # Compare insight counts by severity
        severity_counts1 = defaultdict(int)
        severity_counts2 = defaultdict(int)

        for insight in insights1.insights:
            severity_counts1[insight.severity] += 1

        for insight in insights2.insights:
            severity_counts2[insight.severity] += 1

        comparison["comparison"]["insight_counts"] = {
            "model1": dict(severity_counts1),
            "model2": dict(severity_counts2),
        }

        return comparison


# ==================== Utility Functions ====================


def create_model_insights() -> ModelInsights:
    """Factory function to create model insights analyzer"""
    return ModelInsights()


def quick_insights(stats: ModelStatistics) -> Dict[str, Any]:
    """Generate quick insights for model statistics"""
    insights_analyzer = ModelInsights()
    model_insights = insights_analyzer.analyze_model(stats)

    return {
        "health_score": model_insights.overall_health_score,
        "optimization_potential": model_insights.optimization_potential,
        "complexity_score": model_insights.complexity_score,
        "total_insights": model_insights.total_insights,
        "critical_insights": len(
            [i for i in model_insights.insights if i.severity == SeverityLevel.CRITICAL]
        ),
        "high_insights": len(
            [i for i in model_insights.insights if i.severity == SeverityLevel.HIGH]
        ),
    }

"""
Advanced Export Manager for GradLens Pro

This module provides comprehensive export capabilities for all
analytics data, visualizations, and reports.

Features:
- Multiple export formats (PDF, HTML, JSON, CSV)
- Interactive dashboards
- Automated report generation
- Custom templates
- Batch export capabilities
"""

import json
import csv
import html
import importlib.util
from pathlib import Path
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass
from enum import Enum
import logging
from datetime import datetime

from .analytics_engine import ModelStatistics
from .visualization_engine import VisualizationEngine
from .experiment_tracker import RunMetadata, ExperimentTracker
from .performance_profiler import PerformanceProfiler
from .model_insights import ModelInsights

PLOTLY_AVAILABLE = importlib.util.find_spec("plotly") is not None

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import (
        SimpleDocTemplate,
        Paragraph,
        Spacer,
        Table,
        TableStyle,
    )
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.lib import colors

    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

_logger = logging.getLogger(__name__)


# ==================== Enums and Data Classes ====================


class ExportFormat(Enum):
    """Supported export formats"""

    JSON = "json"
    CSV = "csv"
    HTML = "html"
    PDF = "pdf"
    PNG = "png"
    SVG = "svg"
    EXCEL = "xlsx"


class ReportType(Enum):
    """Types of reports"""

    SUMMARY = "summary"
    DETAILED = "detailed"
    COMPARISON = "comparison"
    CUSTOM = "custom"


@dataclass
class ReportConfig:
    """Configuration for report generation"""

    title: str = "GradLens Pro Report"
    subtitle: str = "Model Analytics Report"
    author: str = "GradLens Pro"
    include_charts: bool = True
    include_tables: bool = True
    include_insights: bool = True
    include_recommendations: bool = True
    chart_width: int = 800
    chart_height: int = 400
    page_size: str = "A4"
    margin: float = 1.0  # inches
    font_size: int = 12
    line_spacing: float = 1.2
    include_timestamp: bool = True
    custom_css: Optional[str] = None
    custom_template: Optional[str] = None


@dataclass
class ExportConfig:
    """Configuration for export operations"""

    output_dir: str = "exports"
    filename_prefix: str = "gradlens"
    include_metadata: bool = True
    compress: bool = False
    overwrite: bool = True
    timestamp_format: str = "%Y%m%d_%H%M%S"


class ExportManager:
    """
    Advanced export manager for GradLens Pro

    Features:
    - Multiple export formats
    - Interactive dashboards
    - Automated report generation
    - Custom templates
    - Batch export capabilities
    """

    def __init__(
        self,
        config: Optional[ExportConfig] = None,
        report_config: Optional[ReportConfig] = None,
    ):
        self.config = config or ExportConfig()
        self.report_config = report_config or ReportConfig()
        self.visualization_engine = VisualizationEngine()

        # Create output directory; attempt to create parents, ignore permission errors
        self.output_dir = str(self.config.output_dir)
        try:
            Path(self.output_dir).mkdir(parents=True, exist_ok=True)
        except PermissionError:
            # Fallback to a temporary directory within cwd if not writable
            fallback = Path.cwd() / "exports"
            fallback.mkdir(parents=True, exist_ok=True)
            _logger.warning(
                f"Cannot create output directory '{self.output_dir}'. Using fallback '{fallback}'"
            )
            self.output_dir = str(fallback)

        _logger.info("ExportManager initialized")

    def export_model_analysis(
        self,
        stats: ModelStatistics,
        format: Union[ExportFormat, str] = ExportFormat.HTML,
        filename: Optional[str] = None,
    ) -> str:
        """
        Export model analysis results

        Args:
            stats: Model statistics
            format: Export format
            filename: Optional custom filename

        Returns:
            Path to exported file
        """
        if filename is None:
            timestamp = datetime.now().strftime(self.config.timestamp_format)
            filename = f"{self.config.filename_prefix}_model_analysis_{timestamp}"

        # Allow string format inputs, normalize to ExportFormat or raise
        if isinstance(format, str):
            try:
                fmt = ExportFormat(format.lower())
            except Exception:
                raise ValueError(f"Unsupported format: {format}")
        else:
            fmt = format

        filepath = Path(self.output_dir) / f"{filename}.{fmt.value}"

        if fmt == ExportFormat.JSON:
            self._export_json(stats.to_dict(), filepath)
        elif fmt == ExportFormat.CSV:
            self._export_csv(stats, filepath)
        elif fmt == ExportFormat.HTML:
            self._export_html_report(stats, filepath)
        elif fmt == ExportFormat.PDF:
            self._export_pdf_report(stats, filepath)
        else:
            raise ValueError(f"Unsupported format: {format}")

        _logger.info(f"Model analysis exported to {filepath}")
        return str(filepath)

    def export_visualization(
        self,
        figure: Any,
        format: Union[ExportFormat, str] = ExportFormat.HTML,
        filename: Optional[str] = None,
    ) -> str:
        """
        Export visualization

        Args:
            figure: Plotly figure
            format: Export format
            filename: Optional custom filename

        Returns:
            Path to exported file
        """
        if not PLOTLY_AVAILABLE:
            raise ImportError("Plotly is required for visualization export")

        if filename is None:
            timestamp = datetime.now().strftime(self.config.timestamp_format)
            filename = f"{self.config.filename_prefix}_visualization_{timestamp}"

        # Allow string format inputs, normalize to ExportFormat or raise
        if isinstance(format, str):
            try:
                fmt = ExportFormat(format.lower())
            except Exception:
                raise ValueError(f"Unsupported format for visualization: {format}")
        else:
            fmt = format

        filepath = Path(self.output_dir) / f"{filename}.{fmt.value}"

        if fmt == ExportFormat.HTML:
            figure.write_html(str(filepath))
        elif fmt == ExportFormat.PNG:
            figure.write_image(
                str(filepath),
                format="png",
                width=self.report_config.chart_width,
                height=self.report_config.chart_height,
            )
        elif fmt == ExportFormat.SVG:
            figure.write_image(str(filepath), format="svg")
        elif fmt == ExportFormat.PDF:
            figure.write_image(str(filepath), format="pdf")
        else:
            raise ValueError(f"Unsupported format for visualization: {format}")

        _logger.info(f"Visualization exported to {filepath}")
        return str(filepath)

    def export_experiment_data(
        self,
        experiment_tracker: ExperimentTracker,
        experiment_name: str,
        format: ExportFormat = ExportFormat.JSON,
        filename: Optional[str] = None,
    ) -> str:
        """
        Export experiment data

        Args:
            experiment_tracker: Experiment tracker instance
            experiment_name: Name of the experiment
            format: Export format
            filename: Optional custom filename

        Returns:
            Path to exported file
        """
        if filename is None:
            timestamp = datetime.now().strftime(self.config.timestamp_format)
            filename = f"{self.config.filename_prefix}_experiment_{experiment_name}_{timestamp}"

        filepath = Path(self.output_dir) / f"{filename}.{format.value}"

        # Get experiment data
        runs = experiment_tracker.get_experiment_runs(experiment_name=experiment_name)

        export_data = {
            "experiment_name": experiment_name,
            "exported_at": datetime.now().isoformat(),
            "total_runs": len(runs),
            "runs": [run.to_dict() for run in runs],
        }

        if format == ExportFormat.JSON:
            self._export_json(export_data, filepath)
        elif format == ExportFormat.CSV:
            self._export_experiment_csv(runs, filepath)
        elif format == ExportFormat.HTML:
            self._export_experiment_html(export_data, filepath)
        else:
            raise ValueError(f"Unsupported format: {format}")

        _logger.info(f"Experiment data exported to {filepath}")
        return str(filepath)

    def export_performance_profile(
        self,
        profiler: PerformanceProfiler,
        format: ExportFormat = ExportFormat.HTML,
        filename: Optional[str] = None,
    ) -> str:
        """
        Export performance profile

        Args:
            profiler: Performance profiler instance
            format: Export format
            filename: Optional custom filename

        Returns:
            Path to exported file
        """
        if filename is None:
            timestamp = datetime.now().strftime(self.config.timestamp_format)
            filename = f"{self.config.filename_prefix}_performance_{timestamp}"

        filepath = Path(self.output_dir) / f"{filename}.{format.value}"

        # Get performance data
        summary = profiler.get_performance_summary()
        bottlenecks = profiler.detect_bottlenecks()
        recommendations = profiler.get_optimization_recommendations()

        export_data = {
            "performance_summary": summary,
            "bottlenecks": bottlenecks,
            "recommendations": recommendations,
            "exported_at": datetime.now().isoformat(),
        }

        if format == ExportFormat.JSON:
            self._export_json(export_data, filepath)
        elif format == ExportFormat.HTML:
            self._export_performance_html(export_data, filepath)
        else:
            raise ValueError(f"Unsupported format: {format}")

        _logger.info(f"Performance profile exported to {filepath}")
        return str(filepath)

    def export_comprehensive_report(
        self,
        stats: ModelStatistics,
        experiment_tracker: Optional[ExperimentTracker] = None,
        profiler: Optional[PerformanceProfiler] = None,
        model_insights: Optional[ModelInsights] = None,
        format: ExportFormat = ExportFormat.HTML,
        filename: Optional[str] = None,
    ) -> str:
        """
        Export comprehensive report with all available data

        Args:
            stats: Model statistics
            experiment_tracker: Optional experiment tracker
            profiler: Optional performance profiler
            model_insights: Optional model insights
            format: Export format
            filename: Optional custom filename

        Returns:
            Path to exported file
        """
        if filename is None:
            timestamp = datetime.now().strftime(self.config.timestamp_format)
            filename = f"{self.config.filename_prefix}_comprehensive_report_{timestamp}"

        filepath = Path(self.output_dir) / f"{filename}.{format.value}"

        # Collect all data
        report_data = {
            "model_statistics": stats.to_dict(),
            "exported_at": datetime.now().isoformat(),
            "report_config": self.report_config.__dict__,
        }

        if experiment_tracker:
            runs = experiment_tracker.get_experiment_runs()
            report_data["experiments"] = [run.to_dict() for run in runs]

        if profiler:
            report_data["performance"] = {
                "summary": profiler.get_performance_summary(),
                "bottlenecks": profiler.detect_bottlenecks(),
                "recommendations": profiler.get_optimization_recommendations(),
            }

        if model_insights:
            report_data["insights"] = model_insights.to_dict()

        if format == ExportFormat.HTML:
            self._export_comprehensive_html(report_data, filepath)
        elif format == ExportFormat.PDF:
            self._export_comprehensive_pdf(report_data, filepath)
        elif format == ExportFormat.JSON:
            self._export_json(report_data, filepath)
        else:
            raise ValueError(f"Unsupported format: {format}")

        _logger.info(f"Comprehensive report exported to {filepath}")
        return str(filepath)

    def _export_json(self, data: Dict[str, Any], filepath: Path) -> None:
        """Export data as JSON"""
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str, ensure_ascii=False)

    def _export_csv(self, stats: ModelStatistics, filepath: Path) -> None:
        """Export model statistics as CSV"""
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)

            # Write header
            writer.writerow(
                [
                    "Layer",
                    "Type",
                    "Parameters",
                    "Grad_Norm",
                    "Weight_Norm",
                    "Dead_Neurons",
                    "Has_NaN",
                    "Has_Inf",
                    "Is_Frozen",
                    "Forward_Time_ms",
                    "Backward_Time_ms",
                    "Memory_MB",
                ]
            )

            # Write data
            for name, layer_stats in stats.layer_stats.items():
                writer.writerow(
                    [
                        name,
                        layer_stats.layer_type,
                        layer_stats.num_parameters,
                        layer_stats.grad_norm,
                        layer_stats.weight_norm,
                        layer_stats.dead_neuron_ratio,
                        layer_stats.has_nan,
                        layer_stats.has_inf,
                        layer_stats.is_frozen,
                        layer_stats.forward_time_ms,
                        layer_stats.backward_time_ms,
                        layer_stats.memory_mb,
                    ]
                )

    def _export_html_report(self, stats: ModelStatistics, filepath: Path) -> None:
        """Export HTML report for model statistics"""
        html_content = self._generate_html_template(
            title=f"{self.report_config.title} - Model Analysis",
            content=self._generate_model_analysis_html(stats),
        )

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html_content)

    def _export_pdf_report(self, stats: ModelStatistics, filepath: Path) -> None:
        """Export PDF report for model statistics"""
        if not REPORTLAB_AVAILABLE:
            raise ImportError("ReportLab is required for PDF export")

        doc = SimpleDocTemplate(str(filepath), pagesize=A4)
        styles = getSampleStyleSheet()
        story = []

        # Title
        title_style = ParagraphStyle(
            "CustomTitle",
            parent=styles["Heading1"],
            fontSize=18,
            spaceAfter=30,
            alignment=1,  # Center
        )
        story.append(Paragraph(self.report_config.title, title_style))
        story.append(Spacer(1, 12))

        # Subtitle
        story.append(Paragraph(self.report_config.subtitle, styles["Heading2"]))
        story.append(Spacer(1, 12))

        # Model overview
        story.append(Paragraph("Model Overview", styles["Heading2"]))
        story.append(Spacer(1, 6))

        overview_data = [
            ["Architecture", stats.architecture_type.value],
            ["Total Parameters", f"{stats.total_parameters:,}"],
            ["Trainable Parameters", f"{stats.trainable_parameters:,}"],
            ["Non-trainable Parameters", f"{stats.non_trainable_parameters:,}"],
            ["Number of Layers", str(len(stats.layer_stats))],
        ]

        overview_table = Table(overview_data, colWidths=[2 * inch, 3 * inch])
        overview_table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 14),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ]
            )
        )

        story.append(overview_table)
        story.append(Spacer(1, 20))

        # Layer details
        story.append(Paragraph("Layer Details", styles["Heading2"]))
        story.append(Spacer(1, 6))

        layer_data = [["Layer", "Type", "Parameters", "Grad Norm", "Weight Norm"]]
        for name, layer_stats in list(stats.layer_stats.items())[
            :20
        ]:  # Limit to first 20 layers
            layer_data.append(
                [
                    name[:30] + "..." if len(name) > 30 else name,
                    layer_stats.layer_type,
                    f"{layer_stats.num_parameters:,}",
                    f"{layer_stats.grad_norm:.2f}",
                    f"{layer_stats.weight_norm:.2f}",
                ]
            )

        layer_table = Table(
            layer_data, colWidths=[1.5 * inch, 1 * inch, 1 * inch, 1 * inch, 1 * inch]
        )
        layer_table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 10),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                    ("FONTSIZE", (0, 1), (-1, -1), 8),
                ]
            )
        )

        story.append(layer_table)

        # Footer
        if self.report_config.include_timestamp:
            story.append(Spacer(1, 20))
            story.append(
                Paragraph(
                    f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    styles["Normal"],
                )
            )

        doc.build(story)

    def _generate_html_template(self, title: str, content: str) -> str:
        """Generate HTML template"""
        css = (
            self.report_config.custom_css
            or """
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
        .header { text-align: center; margin-bottom: 30px; }
        .section { margin-bottom: 30px; }
        .metric { display: inline-block; margin: 10px; padding: 15px; background: #f5f5f5; border-radius: 5px; }
        .metric-value { font-size: 24px; font-weight: bold; color: #2c3e50; }
        .metric-label { font-size: 14px; color: #7f8c8d; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        .insight { margin: 15px 0; padding: 15px; border-left: 4px solid #3498db; background: #ecf0f1; }
        .insight.critical { border-left-color: #e74c3c; }
        .insight.high { border-left-color: #f39c12; }
        .insight.medium { border-left-color: #f1c40f; }
        .insight.low { border-left-color: #27ae60; }
        """
        )

        timestamp_html = ""
        if self.report_config.include_timestamp:
            timestamp_html = (
                f"<p>Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>"
            )

        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>{html.escape(title)}</title>
            <meta charset="utf-8">
            <style>{css}</style>
        </head>
        <body>
            <div class="header">
                <h1>{html.escape(title)}</h1>
                <p>{html.escape(self.report_config.subtitle)}</p>
                {timestamp_html}
            </div>
            {content}
        </body>
        </html>
        """

    def _generate_model_analysis_html(self, stats: ModelStatistics) -> str:
        """Generate HTML content for model analysis"""
        html_parts = []

        # Model overview
        html_parts.append('<div class="section">')
        html_parts.append("<h2>Model Overview</h2>")
        html_parts.append('<div class="metric">')
        html_parts.append(
            f'<div class="metric-value">{stats.architecture_type.value.title()}</div>'
        )
        html_parts.append('<div class="metric-label">Architecture</div>')
        html_parts.append("</div>")
        html_parts.append('<div class="metric">')
        html_parts.append(f'<div class="metric-value">{stats.total_parameters:,}</div>')
        html_parts.append('<div class="metric-label">Total Parameters</div>')
        html_parts.append("</div>")
        html_parts.append('<div class="metric">')
        html_parts.append(f'<div class="metric-value">{len(stats.layer_stats)}</div>')
        html_parts.append('<div class="metric-label">Layers</div>')
        html_parts.append("</div>")
        html_parts.append("</div>")

        # Health metrics
        html_parts.append('<div class="section">')
        html_parts.append("<h2>Health Metrics</h2>")
        html_parts.append('<div class="metric">')
        html_parts.append(f'<div class="metric-value">{stats.num_dead_layers}</div>')
        html_parts.append('<div class="metric-label">Dead Layers</div>')
        html_parts.append("</div>")
        html_parts.append('<div class="metric">')
        html_parts.append(
            f'<div class="metric-value">{stats.num_exploding_layers}</div>'
        )
        html_parts.append('<div class="metric-label">Exploding Layers</div>')
        html_parts.append("</div>")
        html_parts.append('<div class="metric">')
        html_parts.append(
            f'<div class="metric-value">{stats.num_vanishing_layers}</div>'
        )
        html_parts.append('<div class="metric-label">Vanishing Layers</div>')
        html_parts.append("</div>")
        html_parts.append("</div>")

        # Layer details table
        html_parts.append('<div class="section">')
        html_parts.append("<h2>Layer Details</h2>")
        html_parts.append("<table>")
        html_parts.append(
            "<tr><th>Layer</th><th>Type</th><th>Parameters</th><th>Grad Norm</th><th>Weight Norm</th><th>Dead Neurons</th></tr>"
        )

        for name, layer_stats in stats.layer_stats.items():
            html_parts.append("<tr>")
            html_parts.append(f"<td>{html.escape(name)}</td>")
            html_parts.append(f"<td>{html.escape(layer_stats.layer_type)}</td>")
            html_parts.append(f"<td>{layer_stats.num_parameters:,}</td>")
            html_parts.append(f"<td>{layer_stats.grad_norm:.2f}</td>")
            html_parts.append(f"<td>{layer_stats.weight_norm:.2f}</td>")
            html_parts.append(f"<td>{layer_stats.dead_neuron_ratio:.1%}</td>")
            html_parts.append("</tr>")

        html_parts.append("</table>")
        html_parts.append("</div>")

        return "\n".join(html_parts)

    def _export_experiment_csv(self, runs: List[RunMetadata], filepath: Path) -> None:
        """Export experiment data as CSV"""
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)

            # Write header
            writer.writerow(
                [
                    "Run ID",
                    "Experiment Name",
                    "Status",
                    "Created At",
                    "Best Loss",
                    "Best Accuracy",
                    "Final Loss",
                    "Final Accuracy",
                    "Training Time (s)",
                    "Total Parameters",
                ]
            )

            # Write data
            for run in runs:
                writer.writerow(
                    [
                        run.run_id,
                        run.experiment_name,
                        run.status,
                        run.created_at.isoformat(),
                        run.best_loss,
                        run.best_accuracy,
                        run.final_loss,
                        run.final_accuracy,
                        run.training_time_seconds,
                        run.total_parameters,
                    ]
                )

    def _export_experiment_html(self, data: Dict[str, Any], filepath: Path) -> None:
        """Export experiment data as HTML"""
        html_content = self._generate_html_template(
            title=f"{self.report_config.title} - Experiment Data",
            content=self._generate_experiment_html(data),
        )

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html_content)

    def _generate_experiment_html(self, data: Dict[str, Any]) -> str:
        """Generate HTML content for experiment data"""
        html_parts = []

        # Experiment overview
        html_parts.append('<div class="section">')
        html_parts.append("<h2>Experiment Overview</h2>")
        html_parts.append(
            f"<p><strong>Experiment:</strong> {html.escape(data['experiment_name'])}</p>"
        )
        html_parts.append(f"<p><strong>Total Runs:</strong> {data['total_runs']}</p>")
        html_parts.append(f"<p><strong>Exported:</strong> {data['exported_at']}</p>")
        html_parts.append("</div>")

        # Runs table
        if data["runs"]:
            html_parts.append('<div class="section">')
            html_parts.append("<h2>Experiment Runs</h2>")
            html_parts.append("<table>")
            html_parts.append(
                "<tr><th>Run ID</th><th>Status</th><th>Best Loss</th><th>Best Accuracy</th><th>Created</th></tr>"
            )

            for run in data["runs"]:
                html_parts.append("<tr>")
                html_parts.append(f"<td>{html.escape(run['run_id'][:8])}...</td>")
                html_parts.append(f"<td>{html.escape(run['status'])}</td>")
                html_parts.append(f"<td>{run['best_loss']:.4f}</td>")
                html_parts.append(f"<td>{run['best_accuracy']:.4f}</td>")
                html_parts.append(f"<td>{run['created_at'][:19]}</td>")
                html_parts.append("</tr>")

            html_parts.append("</table>")
            html_parts.append("</div>")

        return "\n".join(html_parts)

    def _export_performance_html(self, data: Dict[str, Any], filepath: Path) -> None:
        """Export performance data as HTML"""
        html_content = self._generate_html_template(
            title=f"{self.report_config.title} - Performance Profile",
            content=self._generate_performance_html(data),
        )

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html_content)

    def _generate_performance_html(self, data: Dict[str, Any]) -> str:
        """Generate HTML content for performance data"""
        html_parts = []

        # Performance summary
        summary = data.get("performance_summary", {})
        if summary:
            html_parts.append('<div class="section">')
            html_parts.append("<h2>Performance Summary</h2>")
            html_parts.append(
                f"<p><strong>Total Metrics:</strong> {summary.get('total_metrics', 0)}</p>"
            )
            html_parts.append(
                f"<p><strong>Profiling Duration:</strong> {summary.get('profiling_duration', 0):.2f} seconds</p>"
            )
            html_parts.append(
                f"<p><strong>Layers Profiled:</strong> {summary.get('layers_profiled', 0)}</p>"
            )
            html_parts.append("</div>")

        # Bottlenecks
        bottlenecks = data.get("bottlenecks", [])
        if bottlenecks:
            html_parts.append('<div class="section">')
            html_parts.append("<h2>Performance Bottlenecks</h2>")

            for bottleneck in bottlenecks:
                severity_class = bottleneck.get("severity", "low").lower()
                html_parts.append(f'<div class="insight {severity_class}">')
                html_parts.append(
                    f"<h3>{html.escape(bottleneck.get('title', 'Bottleneck'))}</h3>"
                )
                html_parts.append(
                    f"<p>{html.escape(bottleneck.get('description', ''))}</p>"
                )
                html_parts.append(
                    f"<p><strong>Recommendation:</strong> {html.escape(bottleneck.get('recommendation', ''))}</p>"
                )
                html_parts.append("</div>")

            html_parts.append("</div>")

        # Recommendations
        recommendations = data.get("recommendations", [])
        if recommendations:
            html_parts.append('<div class="section">')
            html_parts.append("<h2>Optimization Recommendations</h2>")
            html_parts.append("<ul>")
            for rec in recommendations:
                html_parts.append(f"<li>{html.escape(rec)}</li>")
            html_parts.append("</ul>")
            html_parts.append("</div>")

        return "\n".join(html_parts)

    def _export_comprehensive_html(self, data: Dict[str, Any], filepath: Path) -> None:
        """Export comprehensive report as HTML"""
        html_content = self._generate_html_template(
            title=f"{self.report_config.title} - Comprehensive Report",
            content=self._generate_comprehensive_html(data),
        )

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html_content)

    def _generate_comprehensive_html(self, data: Dict[str, Any]) -> str:
        """Generate comprehensive HTML content"""
        html_parts = []

        # Table of contents
        html_parts.append('<div class="section">')
        html_parts.append("<h2>Table of Contents</h2>")
        html_parts.append("<ul>")
        html_parts.append('<li><a href="#model-stats">Model Statistics</a></li>')
        if "experiments" in data:
            html_parts.append('<li><a href="#experiments">Experiments</a></li>')
        if "performance" in data:
            html_parts.append('<li><a href="#performance">Performance</a></li>')
        if "insights" in data:
            html_parts.append('<li><a href="#insights">Insights</a></li>')
        html_parts.append("</ul>")
        html_parts.append("</div>")

        # Model statistics
        if "model_statistics" in data:
            html_parts.append('<div class="section" id="model-stats">')
            html_parts.append("<h2>Model Statistics</h2>")
            stats = data["model_statistics"]
            html_parts.append(
                f"<p><strong>Architecture:</strong> {stats.get('architecture', 'Unknown')}</p>"
            )
            html_parts.append(
                f"<p><strong>Total Parameters:</strong> {stats.get('parameters', {}).get('total', 0):,}</p>"
            )
            html_parts.append("</div>")

        # Add other sections as needed...

        return "\n".join(html_parts)

    def _export_comprehensive_pdf(self, data: Dict[str, Any], filepath: Path) -> None:
        """Export comprehensive report as PDF"""
        if not REPORTLAB_AVAILABLE:
            raise ImportError("ReportLab is required for PDF export")

        # Similar to _export_pdf_report but with more comprehensive content
        doc = SimpleDocTemplate(str(filepath), pagesize=A4)
        styles = getSampleStyleSheet()
        story = []

        # Title
        title_style = ParagraphStyle(
            "CustomTitle",
            parent=styles["Heading1"],
            fontSize=18,
            spaceAfter=30,
            alignment=1,
        )
        story.append(Paragraph(self.report_config.title, title_style))
        story.append(Spacer(1, 12))

        # Add comprehensive content...

        doc.build(story)


# ==================== Utility Functions ====================


def create_export_manager(
    config: Optional[ExportConfig] = None, report_config: Optional[ReportConfig] = None
) -> ExportManager:
    """Factory function to create export manager"""
    return ExportManager(config, report_config)


def quick_export(
    data: Dict[str, Any],
    format: ExportFormat = ExportFormat.JSON,
    filename: Optional[str] = None,
) -> str:
    """Quick export function"""
    manager = ExportManager()

    if format == ExportFormat.JSON:
        filepath = Path(manager.output_dir) / f"{filename or 'export'}.json"
        manager._export_json(data, filepath)
        return str(filepath)
    else:
        raise ValueError(f"Quick export only supports JSON format, got {format}")

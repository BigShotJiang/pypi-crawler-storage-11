# gradlens/__init__.py

"""
🔥 GradLens - Advanced PyTorch Training Monitor
================================================

A powerful library for monitoring and debugging PyTorch training.

Quick usage:
------------
```python
import gradlens as gw

with gw.watch(model, epochs=10, steps=100) as monitor:
    for epoch in range(10):
        for step, (x, y) in enumerate(dataloader):
            loss = train_step(x, y)
            monitor.log(epoch, step, loss)

monitor.show_report()
monitor.plot('layer1.weight', 'grad_norm')
```

Features:
---------
✅ Real-time monitoring in Terminal and Jupyter/Colab
✅ Automatic NaN/Inf detection
✅ Interactive charts with Plotly
✅ Automatic SQLite logging
✅ Advanced reporting
✅ Extremely simple API
"""

try:
    from ._version import __version__
except ImportError:
    __version__ = "0.1.2.dev0"

__author__ = "GradLens Team"
__license__ = "MIT"

# ==================== Easy API (Recommended) ====================
from .easy_api import (
    watch,  # main entry point
    quick_watch,  # quick testing
    auto_watch,  # fully automatic mode
    watch_notebook,  # optimized for Jupyter/Colab
    compare_runs,  # compare multiple runs
    analyze_db,  # quick DB analysis
    health_check,  # model health check
    monitored,  # decorator
    SimpleWatcher,
)

# ==================== Advanced API (for advanced users) ====================
from .watcher import Watcher
from .config import (
    GradLensConfig,
    TrainingConfig,
    TrackingConfig,
    DisplayConfig,
    LoggingConfig,
    DEFAULT_CONFIG,
)

# ==================== Display Managers ====================
from .display_manager import DisplayManager
from .enhanced_display_manager import EnhancedDisplayManager

# ==================== Core Components ====================
from .state import TrainingState
from .hooks import HookManager
from .database import DatabaseManager, fetch_data_from_db
from .history import HistoryLogger

# ==================== Advanced Analytics (GradLens Pro) ====================
from .analytics import (
    # Analytics Engine
    AnalyticsEngine,
    ModelStatistics,
    LayerStatistics,
    ArchitectureType,
    MetricType,
    AnalysisLevel,
    create_analytics_engine,
    quick_analysis,
    # Visualization Engine
    VisualizationEngine,
    DashboardConfig,
    PlotConfig,
    PlotType,
    DashboardTheme,
    create_visualization_engine,
    quick_visualization,
    # Experiment Tracker
    ExperimentTracker,
    ExperimentConfig,
    RunMetadata,
    HyperparameterConfig,
    create_experiment_tracker,
    quick_experiment_start,
    # Performance Profiler
    PerformanceProfiler,
    ProfilerConfig,
    PerformanceMetrics,
    ProfilerMode,
    create_performance_profiler,
    profile_model,
    quick_profile,
    # Model Insights
    ModelInsights,
    ArchitectureAnalyzer,
    BottleneckDetector,
    Insight,
    InsightType,
    SeverityLevel,
    create_model_insights,
    quick_insights,
)

# ==================== Export Manager ====================
from .export_manager import ExportManager
from .easy_api import quick_report, comprehensive_report

# ==================== Exceptions ====================
from .exceptions import (
    GradLensError,
    CatastrophicTrainingError,
    DatabaseError,
    HookAttachmentError,
    ConfigurationError,
    DisplayError,
    DataFetchError,
)

# ==================== CLI ====================
from .cli import print_summary_report_to_console, plot_history_in_terminal


# ==================== Quick Start Guide ====================


def quick_start_guide():
    """
    📚 Show a quick start guide
    """
    from rich.console import Console
    from rich.markdown import Markdown

    guide = """
# 🚀 GradLens Quick Start

## Installation
```bash
pip install gradlens
```

## Quick usage (3 lines!)
```python
import gradlens as gw

with gw.watch(model, epochs=10, steps=100) as monitor:
    for epoch in range(10):
        for step, batch in enumerate(dataloader):
            loss = train_step(batch)
            monitor.log(epoch, step, loss)
```

## For Jupyter/Colab
```python
with gw.watch_notebook(model, epochs=10, steps=100) as m:
    # training loop
    ...

m.show_report()
m.plot('layer1.weight')
```

## Model health check
```python
gw.health_check(model, sample_input)
```

## Compare multiple runs
```python
gw.compare_runs(['run1.db', 'run2.db', 'run3.db'])
```

## Quick analysis
```python
gw.analyze_db('training.db')
```

---
📖 For more information: https://github.com/im-mahdi-74/gradlens
    """

    console = Console()
    console.print(Markdown(guide))


# ==================== Welcome Message ====================


def _show_welcome():
    """Show a welcome message (only once)."""
    import sys

    # Only show in interactive environments
    if hasattr(sys, "ps1") or "IPython" in sys.modules:
        from rich.console import Console
        from rich.panel import Panel
        from rich.text import Text

        console = Console()

        welcome_text = Text.assemble(
            ("🔥 GradLens ", "bold cyan"),
            (f"v{__version__}", "dim"),
            (" loaded!\n\n", ""),
            ("💡 Quick start: ", "yellow"),
            ("gw.quick_start_guide()", "bold green"),
            ("\n📖 Docs: ", "yellow"),
            ("github.com/im-mahdi-74/gradlens", "blue underline"),
        )

        try:
            console.print(Panel(welcome_text, border_style="cyan", expand=False))
        except Exception:
            # Fallback to a simple message
            print(
                f"GradLens v{__version__} loaded! Run gw.quick_start_guide() for help."
            )


# Show welcome message
_show_welcome()


# ==================== Exports ====================

__all__ = [
    # Easy API ⭐
    "watch",
    "quick_watch",
    "auto_watch",
    "watch_notebook",
    "compare_runs",
    "analyze_db",
    "health_check",
    "monitored",
    "SimpleWatcher",
    # Advanced API
    "Watcher",
    "GradLensConfig",
    "TrainingConfig",
    "TrackingConfig",
    "DisplayConfig",
    "LoggingConfig",
    "DEFAULT_CONFIG",
    # Display
    "DisplayManager",
    "EnhancedDisplayManager",
    # Core
    "TrainingState",
    "HookManager",
    "DatabaseManager",
    "HistoryLogger",
    "fetch_data_from_db",
    # Advanced Analytics (GradLens Pro) 🔥
    # Analytics Engine
    "AnalyticsEngine",
    "ModelStatistics",
    "LayerStatistics",
    "ArchitectureType",
    "MetricType",
    "AnalysisLevel",
    "create_analytics_engine",
    "quick_analysis",
    # Visualization Engine
    "VisualizationEngine",
    "DashboardConfig",
    "PlotConfig",
    "PlotType",
    "DashboardTheme",
    "create_visualization_engine",
    "quick_visualization",
    # Experiment Tracker
    "ExperimentTracker",
    "ExperimentConfig",
    "RunMetadata",
    "HyperparameterConfig",
    "create_experiment_tracker",
    "quick_experiment_start",
    # Performance Profiler
    "PerformanceProfiler",
    "ProfilerConfig",
    "PerformanceMetrics",
    "ProfilerMode",
    "create_performance_profiler",
    "profile_model",
    "quick_profile",
    # Model Insights
    "ModelInsights",
    "ArchitectureAnalyzer",
    "BottleneckDetector",
    "Insight",
    "InsightType",
    "SeverityLevel",
    "create_model_insights",
    "quick_insights",
    # Export Manager
    "ExportManager",
    "quick_report",
    "comprehensive_report",
    # Exceptions
    "GradLensError",
    "CatastrophicTrainingError",
    "DatabaseError",
    "HookAttachmentError",
    "ConfigurationError",
    "DisplayError",
    "DataFetchError",
    # CLI
    "print_summary_report_to_console",
    "plot_history_in_terminal",
    # Utils
    "quick_start_guide",
    # Metadata
    "__version__",
]

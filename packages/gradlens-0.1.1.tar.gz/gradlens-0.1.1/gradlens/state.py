# gradlens/state.py

import collections
from datetime import datetime
from typing import Deque, Dict, Any, Tuple
import torch.nn as nn

# --- 1. Import the new config objects ---
from .config import TrainingConfig, TrackingConfig, DisplayConfig, LoggingConfig


class TrainingState:
    """
    A centralized class to hold all the dynamic data and state of a training watch session.

    This object acts as the single source of truth and is passed to different managers
    (e.g., HookManager, DisplayManager) to provide them with the necessary information
    without coupling them to the main Watcher class.

    Attributes:
        model (nn.Module): The PyTorch model being monitored.
        model_class_name (str): The class name of the model (e.g., "SimpleModel").
        run_name (str): The name for this training run (e.g., "run_20251022_123000").
        total_epochs (int): The total number of epochs for the training loop.
        steps_per_epoch (int): The number of steps/batches in each epoch.
        sample_every_steps (int): The frequency (in steps) to log data and update the display.

        track_grads (bool): Flag to enable gradient tracking.
        track_dead_neurons (bool): Flag to enable dead neuron tracking (for ReLUs).
        track_activations (bool): Flag to enable activation tracking.
        track_parameters (bool): Flag to enable parameter tracking.

        loss_history_length (int): Max number of loss values to keep for the TUI plot.
        plot_height (int): The height (in lines) of the TUI loss plot.
        plot_width (int): The width (in characters) of the TUI loss plot.

        current_step (int): The current training step, updated via `watcher.set_step()`.
        current_epoch (int): The current training epoch, updated via `watcher.set_step()`.
        current_loss (float): The most recent loss value.
        loss_history (Deque[float]): A deque holding the recent loss history for TUI plotting.

        grad_stats (Dict[str, Tuple[float, float]]): Stores `(norm, max)` for gradients.
        act_stats (Dict[str, Tuple[float, float]]): Stores `(norm, max)` for activations.
        param_stats (Dict[str, Tuple[float, float]]): Stores `(norm, max)` for parameters.
        dead_neuron_stats (Dict[str, float]): Stores dead neuron percentage (0.0-1.0).
        nan_alert (Dict[str, Any]): Populated if a NaN/Inf is detected.

        max_grad_norm_seen (float): The highest gradient norm seen *so far* across all layers.
        max_dead_neuron_seen (float): The highest dead neuron percentage seen *so far*.
        epochs_completed (int): The number of epochs completed before exit.
        steps_completed_in_last_epoch (int): The number of steps completed in the final epoch.
    """

    # --- 2. Refactored __init__ to accept config objects ---
    def __init__(
        self,
        model: nn.Module,
        training_config: TrainingConfig,
        tracking_config: TrackingConfig,
        display_config: DisplayConfig,
        logging_config: LoggingConfig,
    ) -> None:
        """
        Initializes the TrainingState by unpacking config objects.

        Args:
            model (nn.Module): The PyTorch model being monitored.
            training_config (TrainingConfig): Config object with training run parameters.
            tracking_config (TrackingConfig): Config object with metric tracking flags.
            display_config (DisplayConfig): Config object with TUI/display settings.
            logging_config (LoggingConfig): Config object with logging settings.
        """

        # --- 3. Unpack config objects into attributes ---

        # --- Static Configuration (from TrainingConfig) ---
        self.model: nn.Module = model
        self.model_class_name: str = model.__class__.__name__
        self.run_name: str = (
            training_config.run_name
            if training_config.run_name
            else f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        self.total_epochs: int = training_config.total_epochs
        self.steps_per_epoch: int = training_config.steps_per_epoch

        # --- (from LoggingConfig) ---
        # Validation (>= 1) is handled by LoggingConfig's __post_init__
        self.sample_every_steps: int = logging_config.sample_every_steps

        # --- Tracking Flags (from TrackingConfig) ---
        self.track_grads: bool = tracking_config.track_grads
        self.track_dead_neurons: bool = tracking_config.track_dead_neurons
        self.track_activations: bool = tracking_config.track_activations
        self.track_parameters: bool = tracking_config.track_parameters

        # --- Display Configuration (from DisplayConfig) ---
        # Validation is handled by DisplayConfig's __post_init__
        self.loss_history_length: int = display_config.loss_history_length
        self.plot_height: int = display_config.plot_height
        self.plot_width: int = display_config.plot_width

        # --- 4. Initialize Live Stats (unchanged) ---
        self.current_step: int = 0
        self.current_epoch: int = 0
        self.current_loss: float = 0.0
        self.loss_history: Deque[float] = collections.deque(
            maxlen=self.loss_history_length
        )

        # --- 5. Initialize Data Stores (nan_alert type updated) ---
        self.grad_stats: Dict[str, Tuple[float, float]] = {}
        self.act_stats: Dict[str, Tuple[float, float]] = {}
        self.param_stats: Dict[str, Tuple[float, float]] = {}
        self.dead_neuron_stats: Dict[str, float] = {}
        # Changed to Dict[str, Any] to store richer info
        # (epoch, step, etc.) from _handle_catastrophe
        self.nan_alert: Dict[str, Any] = {}

        # --- 6. Initialize Summary Stats (unchanged) ---
        self.max_grad_norm_seen: float = 0.0
        self.max_dead_neuron_seen: float = 0.0
        self.epochs_completed: int = 0
        self.steps_completed_in_last_epoch: int = 0

# gradlens/config.py

"""
Configuration management for GradLens.

This module provides configuration classes and validation for GradLens settings.
"""

from dataclasses import dataclass, field
from typing import Optional
from pathlib import Path
import logging

_logger = logging.getLogger(__name__)


@dataclass
class TrackingConfig:
    """Configuration for what metrics to track."""

    track_grads: bool = True
    track_dead_neurons: bool = True
    track_activations: bool = False
    track_parameters: bool = False

    def __post_init__(self):
        """Validate configuration after initialization."""
        if not any(
            [
                self.track_grads,
                self.track_dead_neurons,
                self.track_activations,
                self.track_parameters,
            ]
        ):
            _logger.warning(
                "All tracking options are disabled. "
                "GradLens will not collect any metrics."
            )


@dataclass
class DisplayConfig:
    """Configuration for display settings."""

    loss_history_length: int = 90
    plot_height: int = 8
    plot_width: int = 75
    disable_notebook_live_display: bool = False

    def __post_init__(self):
        """Validate configuration after initialization."""
        if self.loss_history_length < 2:
            raise ValueError(
                f"loss_history_length must be at least 2, got {self.loss_history_length}"
            )

        if self.plot_height < 3:
            raise ValueError(f"plot_height must be at least 3, got {self.plot_height}")

        if self.plot_width < 20:
            raise ValueError(f"plot_width must be at least 20, got {self.plot_width}")


@dataclass
class LoggingConfig:
    """Configuration for logging settings."""

    log_file: Optional[str] = None
    history_log_file: Optional[str] = None
    sample_every_steps: int = 1

    def __post_init__(self):
        """Validate configuration after initialization."""
        if self.sample_every_steps < 1:
            raise ValueError(
                f"sample_every_steps must be at least 1, got {self.sample_every_steps}"
            )

        # Validate file paths
        if self.log_file:
            log_path = Path(self.log_file)
            if log_path.exists() and not log_path.is_file():
                raise ValueError(
                    f"log_file path exists but is not a file: {self.log_file}"
                )

            # Create parent directory if it doesn't exist
            log_path.parent.mkdir(parents=True, exist_ok=True)

        if self.history_log_file:
            history_path = Path(self.history_log_file)
            if history_path.exists() and not history_path.is_file():
                raise ValueError(
                    f"history_log_file path exists but is not a file: {self.history_log_file}"
                )

            # Create parent directory if it doesn't exist
            history_path.parent.mkdir(parents=True, exist_ok=True)


@dataclass
class TrainingConfig:
    """Configuration for training loop parameters."""

    total_epochs: int = 1
    steps_per_epoch: int = 1
    run_name: Optional[str] = None

    def __post_init__(self):
        """Validate configuration after initialization."""
        if self.total_epochs < 1:
            raise ValueError(
                f"total_epochs must be at least 1, got {self.total_epochs}"
            )

        if self.steps_per_epoch < 1:
            raise ValueError(
                f"steps_per_epoch must be at least 1, got {self.steps_per_epoch}"
            )


@dataclass
class GradLensConfig:
    """
    Main configuration class for GradLens.

    This combines all sub-configurations into a single, validated configuration object.
    """

    tracking: TrackingConfig = field(default_factory=TrackingConfig)
    display: DisplayConfig = field(default_factory=DisplayConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)

    @classmethod
    def from_dict(cls, config_dict: dict) -> "GradLensConfig":
        """
        Create a GradLensConfig from a dictionary.

        Args:
            config_dict: Dictionary containing configuration values

        Returns:
            GradLensConfig instance

        Example:
            >>> config = GradLensConfig.from_dict({
            ...     'tracking': {'track_grads': True},
            ...     'display': {'plot_height': 10},
            ...     'logging': {'log_file': 'training.db'}
            ... })
        """
        tracking_config = TrackingConfig(**config_dict.get("tracking", {}))
        display_config = DisplayConfig(**config_dict.get("display", {}))
        logging_config = LoggingConfig(**config_dict.get("logging", {}))
        training_config = TrainingConfig(**config_dict.get("training", {}))

        return cls(
            tracking=tracking_config,
            display=display_config,
            logging=logging_config,
            training=training_config,
        )

    def to_dict(self) -> dict:
        """
        Convert the configuration to a dictionary.

        Returns:
            Dictionary representation of the configuration
        """
        return {
            "tracking": {
                "track_grads": self.tracking.track_grads,
                "track_dead_neurons": self.tracking.track_dead_neurons,
                "track_activations": self.tracking.track_activations,
                "track_parameters": self.tracking.track_parameters,
            },
            "display": {
                "loss_history_length": self.display.loss_history_length,
                "plot_height": self.display.plot_height,
                "plot_width": self.display.plot_width,
                "disable_notebook_live_display": self.display.disable_notebook_live_display,
            },
            "logging": {
                "log_file": self.logging.log_file,
                "history_log_file": self.logging.history_log_file,
                "sample_every_steps": self.logging.sample_every_steps,
            },
            "training": {
                "total_epochs": self.training.total_epochs,
                "steps_per_epoch": self.training.steps_per_epoch,
                "run_name": self.training.run_name,
            },
        }

    def validate(self) -> bool:
        """
        Perform additional cross-configuration validation.

        Returns:
            True if configuration is valid

        Raises:
            ValueError: If configuration is invalid
        """
        # Ensure at least one output method is enabled
        if not self.logging.log_file and not self.logging.history_log_file:
            _logger.warning(
                "Neither log_file nor history_log_file is specified. "
                "Training data will not be persisted."
            )

        # Warn if sampling rate is too high relative to training size
        total_steps = self.training.total_epochs * self.training.steps_per_epoch
        if self.logging.sample_every_steps > total_steps // 2:
            _logger.warning(
                f"sample_every_steps ({self.logging.sample_every_steps}) is very high "
                f"relative to total training steps ({total_steps}). "
                "You may not collect enough data."
            )

        return True


# Default configuration
DEFAULT_CONFIG = GradLensConfig()


def get_default_config() -> GradLensConfig:
    """
    Get a copy of the default configuration.

    Returns:
        GradLensConfig with default values
    """
    return GradLensConfig()

# gradlens/cli.py

import argparse
import sqlite3
import sys
import logging
import math
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from typing import Optional, List, Tuple, Any

# --- 1. Import refactored DB functions and custom exceptions ---
from .database import fetch_data_from_db, get_db_connection
from .exceptions import DatabaseError

# --- 2. Setup module-level logger (NO basicConfig) ---
# A library module should NEVER configure the root logger.
_logger = logging.getLogger(__name__)


def print_summary_report_to_console(
    db_file: str, console: Optional[Console] = None
) -> None:
    """
    Prints a comprehensive post-mortem summary report to the console.

    Runs several analytical queries to find catastrophes, gradient health,
    neuron health, and frozen parameters.

    Args:
        db_file: Path to the SQLite .db log file
        console: The Rich Console instance. If None, a new one is created.
    """
    if console is None:
        console = Console()

    # Validate file exists
    db_path = Path(db_file)
    if not db_path.exists():
        console.print(f"[bold red]❌ Database file not found: {db_file}[/bold red]")
        _logger.error(f"Database file not found: {db_file}")
        sys.exit(1)

    # --- 3. Update exception handling ---
    try:
        # get_db_connection now raises DatabaseError on failure
        with get_db_connection(db_file, readonly=True) as conn:
            cursor = conn.cursor()
            _generate_report(cursor, console, db_file)

    except DatabaseError as e:
        # Catch our specific, expected error
        console.print(f"[bold red]❌ Database error: {e}[/bold red]")
        _logger.error(f"Database error in summary report: {e}", exc_info=True)
        sys.exit(1)
    except Exception as e:
        # Catch any other unexpected error
        console.print(f"[bold red]❌ Unexpected error: {e}[/bold red]")
        _logger.error(f"Unexpected error in summary report: {e}", exc_info=True)
        sys.exit(1)


def _generate_report(cursor: sqlite3.Cursor, console: Console, db_file: str) -> None:
    """Internal method to generate the full report."""

    console.print(
        Panel(
            f"📊 [bold]GradLens Analysis Report[/bold] for [cyan]{db_file}[/cyan]",
            title="[b]Post-Mortem Analysis[/b]",
            style="blue",
            expand=False,
        )
    )

    # 1. Catastrophe Check
    _print_catastrophe_section(cursor, console)

    # 2. Gradient Health Report
    _print_gradient_health_section(cursor, console)

    # 3. Neuron Health Report
    _print_neuron_health_section(cursor, console)

    # 4. Frozen Parameters Report
    _print_frozen_params_section(cursor, console)


def _print_catastrophe_section(cursor: sqlite3.Cursor, console: Console) -> None:
    """Prints the catastrophe check section."""
    console.print("\n[b]1. Catastrophe Check:[/b]")

    query = """
        SELECT epoch, step, metric_type, layer_name 
        FROM metrics 
        WHERE metric_type LIKE '%_alert' 
           OR value = 'Infinity' 
           OR value = '-Infinity' 
           OR (value != value)
        GROUP BY epoch, step, metric_type, layer_name 
        ORDER BY epoch, step 
        LIMIT 10
    """

    nan_events = _execute_query_safe(cursor, query)

    if nan_events is None:
        console.print("[yellow]⚠️  Could not fetch catastrophe data.[/yellow]")
        return

    if nan_events:
        table = Table(title="🚨 [bold red]NaN/Inf Events Detected![/bold red]")
        table.add_column("Epoch", style="red")
        table.add_column("Step", style="red")
        table.add_column("Type", style="red")
        table.add_column("Layer", style="yellow")

        for e in nan_events:
            table.add_row(str(e[0]), str(e[1]), e[2], e[3])

        console.print(table)
    else:
        console.print("[bold green]✅ No NaN/Inf events were logged.[/bold green]")


def _print_gradient_health_section(cursor: sqlite3.Cursor, console: Console) -> None:
    """Prints the gradient health section."""
    console.print("\n[b]2. Gradient Health Report (Top 5 Offenders):[/b]")

    # Max gradients
    max_grads_query = """
        SELECT layer_name, MAX(value) as max_grad 
        FROM metrics 
        WHERE metric_type = 'grad_norm' 
          AND value IS NOT NULL 
          AND value != 'Infinity' 
          AND NOT (value != value)
          AND value < 1e308
        GROUP BY layer_name 
        ORDER BY max_grad DESC 
        LIMIT 5
    """

    max_grads = _execute_query_safe(cursor, max_grads_query)

    if max_grads:
        table = Table(title="⚡ Top 5 Max Gradient Norms (Exploding Risk)")
        table.add_column("Layer", style="yellow")
        table.add_column("Max Norm Value", style="magenta")

        for row in max_grads:
            color = (
                "bold red" if row[1] > 1000 else "yellow" if row[1] > 100 else "white"
            )
            table.add_row(row[0], f"[{color}]{row[1]:.2e}[/{color}]")

        console.print(table)
    else:
        console.print("[dim]No gradient norm data found.[/dim]")

    # Min gradients
    min_grads_query = """
        SELECT layer_name, MIN(value) as min_grad 
        FROM metrics 
        WHERE metric_type = 'grad_norm' 
          AND value > 0 
          AND value IS NOT NULL 
          AND value != 'Infinity' 
          AND NOT (value != value)
          AND value < 1e308
        GROUP BY layer_name 
        ORDER BY min_grad ASC 
        LIMIT 5
    """

    min_grads = _execute_query_safe(cursor, min_grads_query)

    if min_grads:
        table = Table(title="📉 Top 5 Min Gradient Norms (Vanishing Risk)")
        table.add_column("Layer", style="yellow")
        table.add_column("Min Norm Value", style="magenta")

        for row in min_grads:
            color = (
                "bold red" if row[1] < 1e-7 else "yellow" if row[1] < 1e-4 else "white"
            )
            table.add_row(row[0], f"[{color}]{row[1]:.2e}[/{color}]")

        console.print(table)


def _print_neuron_health_section(cursor: sqlite3.Cursor, console: Console) -> None:
    """Prints the neuron health section."""
    console.print("\n[b]3. Neuron Health Report (Top 5 Offenders):[/b]")

    query = """
        SELECT layer_name, AVG(value) as avg_dead_pct 
        FROM metrics 
        WHERE metric_type = 'dead_neuron' 
          AND value IS NOT NULL
          AND NOT (value != value)
        GROUP BY layer_name 
        ORDER BY avg_dead_pct DESC 
        LIMIT 5
    """

    dead_neurons = _execute_query_safe(cursor, query)

    if dead_neurons:
        table = Table(title="🧠 Top 5 Layers with Most Dead Neurons (Avg %)")
        table.add_column("Layer (ReLU)", style="yellow")
        table.add_column("Avg. Dead %", style="magenta")

        for row in dead_neurons:
            pct = row[1] * 100
            color = "bold red" if pct > 50 else "yellow" if pct > 20 else "white"
            table.add_row(row[0], f"[{color}]{pct:.1f}%[/{color}]")

        console.print(table)
    else:
        console.print("[dim]No dead neuron data found.[/dim]")


def _print_frozen_params_section(cursor: sqlite3.Cursor, console: Console) -> None:
    """Analyze and print report of parameters whose norms didn't significantly change."""
    console.print("\n[b]4. Frozen Parameters Report (Potential Issues):[/b]")

    # Step range query (unchanged)
    step_range_query = """
        SELECT MIN(epoch * 1000000 + step), MAX(epoch * 1000000 + step)
        FROM metrics WHERE metric_type = 'param_norm' AND value IS NOT NULL AND NOT (value != value)
    """
    step_range = _execute_query_safe(cursor, step_range_query)

    # --- SIMPLIFIED CHECK for step_range ---
    if (
        not step_range
        or not step_range[0]
        or step_range[0][0] is None
        or step_range[0][1] is None
    ):
        console.print("[dim]Not enough parameter data to analyze.[/dim]")
        return

    first_epoch_step, last_epoch_step = step_range[0]

    # Avoid comparison if only one step exists
    if first_epoch_step == last_epoch_step:
        console.print(
            "[dim]Only one step logged, cannot compare parameter changes.[/dim]"
        )
        return

    first_epoch, first_step = divmod(int(first_epoch_step), 1_000_000)
    last_epoch, last_step = divmod(int(last_epoch_step), 1_000_000)

    # --- REVISED QUERY: Fetch ALL common params from first and last step ---
    compare_params_query = """
        WITH 
        FirstStep AS (
            SELECT layer_name, value AS first_norm
            FROM metrics WHERE metric_type = 'param_norm' AND epoch = ? AND step = ? AND value IS NOT NULL
        ),
        LastStep AS (
            SELECT layer_name, value AS last_norm
            FROM metrics WHERE metric_type = 'param_norm' AND epoch = ? AND step = ? AND value IS NOT NULL
        )
        SELECT fs.layer_name, fs.first_norm, ls.last_norm
        FROM FirstStep fs
        JOIN LastStep ls ON fs.layer_name = ls.layer_name
    """

    all_compared_params = _execute_query_safe(
        cursor, compare_params_query, (first_epoch, first_step, last_epoch, last_step)
    )

    if all_compared_params is None:
        console.print(
            "[yellow]⚠️  Could not fetch parameter data for comparison.[/yellow]"
        )
        return

    if not all_compared_params:
        console.print(
            "[dim]No common parameters found between the first and last logged steps.[/dim]"
        )
        return

    # --- Perform filtering and calculate delta IN PYTHON using math.isclose ---
    frozen_params_found = []
    tolerance = 1e-5  # Define tolerance for "frozen"

    for layer_name, first_norm, last_norm in all_compared_params:
        if math.isclose(first_norm, last_norm, rel_tol=tolerance, abs_tol=tolerance):
            delta = abs(first_norm - last_norm)
            frozen_params_found.append((layer_name, first_norm, last_norm, delta))

    if not frozen_params_found:
        console.print(
            "[bold green]✅ No potentially frozen parameters detected.[/bold green]"
        )
        return

    # Sort by delta (smallest change first) and limit
    frozen_params_found.sort(key=lambda x: x[3])
    frozen_params_to_display = frozen_params_found[:20]

    # Render table
    title = (
        f"🧊 Parameters with ~No Change (< {tolerance:.1e} relative/absolute tolerance) "
        f"(between {first_epoch}:{first_step} and {last_epoch}:{last_step})"
    )
    table = Table(title=title)
    table.add_column("Parameter", style="yellow")
    table.add_column("Initial Norm", style="magenta", justify="right")
    table.add_column("Final Norm", style="magenta", justify="right")
    table.add_column("Δ (Change)", style="cyan", justify="right")

    for layer_name, first_norm, last_norm, delta in frozen_params_to_display:
        table.add_row(
            layer_name, f"{first_norm:.6f}", f"{last_norm:.6f}", f"{delta:.6e}"
        )

    console.print(table)


def _execute_query_safe(
    cursor: sqlite3.Cursor, query: str, params: Tuple[Any, ...] = ()
) -> Optional[List[Tuple]]:
    """
    Safely executes a query with proper error handling.
    This is a low-level function directly interacting with the SQLite cursor.

    Args:
        cursor: Database cursor
        query: SQL query string
        params: Query parameters tuple

    Returns:
        Query results or None on error
    """
    try:
        cursor.execute(query, params)
        return cursor.fetchall()
    except sqlite3.Error as e:
        # For a CLI, printing the error to stderr is good practice
        console = Console(stderr=True)
        params_str = str(params)[:100] + ("..." if len(str(params)) > 100 else "")
        console.print(
            f"[bold red]❌ SQL Error:[/bold red]\n"
            f"Query: {query[:100]}...\n"
            f"Params: {params_str}\n"
            f"Error: {e}"
        )
        _logger.error(f"Query execution error: {e}", exc_info=True)
        return None


def plot_history_in_terminal(db_file: str, layer_name: str, metric_name: str) -> None:
    """
    Plots metric history in the terminal using plotext.

    Args:
        db_file: Path to the SQLite .db log file
        layer_name: Name of the layer/parameter to plot
        metric_name: Name of the metric to plot
    """
    console = Console()
    console.print(
        Panel(
            f"📈 Plotting [cyan]{metric_name}[/cyan] for layer [yellow]{layer_name}[/yellow]",
            style="blue",
        )
    )

    # --- 4. Use refactored fetch_data_from_db ---
    # This function now handles its own errors and logging, returning None on failure.
    history_data = fetch_data_from_db(db_file, layer_name, metric_name)

    if history_data is None:
        # Error message is already printed by fetch_data_from_db
        console.print("[red]❌ Could not fetch history data.[/red]")
        sys.exit(1)

    if not history_data:
        console.print(
            f"[yellow]⚠️  No data found for metric '{metric_name}' "
            f"and layer '{layer_name}'.[/yellow]"
        )
        sys.exit(0)

    # Extract data
    steps = [row[0] % 1000000 for row in history_data]
    values = [row[1] for row in history_data]
    epochs = [row[0] // 1000000 for row in history_data]
    x_labels = [f"{e}:{s}" for e, s in zip(epochs, steps)]

    try:
        import plotext as plt

        plt.clf()
        plt.clt()
        plt.plotsize(100, 20)
        plt.theme("pro")
        plt.title(f"{metric_name} for {layer_name}")
        plt.xlabel("Epoch:Step")
        plt.ylabel(metric_name)

        numerical_indices = list(range(0, len(x_labels), max(1, len(x_labels) // 10)))
        string_labels = [x_labels[i] for i in numerical_indices]
        plt.xticks(numerical_indices, string_labels)

        plt.plot(values, color="cyan", marker="dot")
        plt.show()

    except ImportError:
        console.print(
            "[red]❌ `plotext` library is required for plotting.\n"
            "Install it using: pip install plotext[/red]"
        )
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]❌ Error generating plot: {e}[/red]")
        _logger.error(f"Plot generation error: {e}", exc_info=True)
        sys.exit(1)


def main() -> None:
    """The main entry point for the GradLens CLI."""

    # --- 5. Configure logging for the CLI application ---
    # This is the correct place to configure logging, as it's the
    # entry point *application*, not a library module.
    logging.basicConfig(
        level=logging.WARNING,  # Default to WARNING
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    parser = argparse.ArgumentParser(
        description="GradLens: Advanced PyTorch Training Debugger",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  gradlens summary training.db
  gradlens plot training.db --layer layer1.weight --metric grad_norm
        """,
    )

    subparsers = parser.add_subparsers(
        dest="command", required=True, help="Available commands"
    )

    # Summary command
    summary_parser = subparsers.add_parser(
        "summary", help="Generate a post-mortem analysis report from a log file"
    )
    summary_parser.add_argument("logfile", type=str, help="Path to the .db log file")

    # Plot command
    plot_parser = subparsers.add_parser(
        "plot", help="Plot the history of a specific metric for a layer"
    )
    plot_parser.add_argument("logfile", type=str, help="Path to the .db log file")
    plot_parser.add_argument(
        "--layer",
        type=str,
        required=True,
        help="Name of the layer/parameter to plot (e.g., 'layer1.weight')",
    )

    metric_choices = [
        "grad_norm",
        "grad_max",
        "dead_neuron",
        "param_norm",
        "param_max",
        "act_norm",
        "act_max",
        "loss",
    ]
    plot_parser.add_argument(
        "--metric",
        type=str,
        required=True,
        choices=metric_choices,
        help="Metric to plot",
    )

    args = parser.parse_args()

    # Command dispatch
    if args.command == "summary":
        print_summary_report_to_console(args.logfile, console=Console())
    elif args.command == "plot":
        plot_history_in_terminal(args.logfile, args.layer, args.metric)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

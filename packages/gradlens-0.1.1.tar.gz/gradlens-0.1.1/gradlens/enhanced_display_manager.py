# gradlens/enhanced_display_manager.py

import sys
import logging
import time
from typing import Optional, Dict, Any
from collections import deque

from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .state import TrainingState
from .database import fetch_data_from_db
from .config import DisplayConfig
from .notebook import NotebookDisplay
# from .display import create_dashboard_layout, update_dashboard_layout

_logger = logging.getLogger(__name__)

# Environment Detection
_IPYTHON_AVAILABLE = False
_IPYWIDGETS_AVAILABLE = False
_IS_COLAB = False
_IS_JUPYTER_NOTEBOOK = False
_PLOTLY_AVAILABLE = False

try:
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots

    _PLOTLY_AVAILABLE = True
except ImportError:
    pass

try:
    from IPython import get_ipython
    from IPython.display import display, HTML

    _IPYTHON_AVAILABLE = True
    shell = get_ipython().__class__.__name__
    if shell == "ZMQInteractiveShell":
        _IS_JUPYTER_NOTEBOOK = True
    elif "google.colab" in sys.modules:
        _IS_COLAB = True

    if _IS_JUPYTER_NOTEBOOK or _IS_COLAB:
        try:
            from ipywidgets import VBox, HTML as HTMLWidget, Layout as WidgetLayout

            _IPYWIDGETS_AVAILABLE = True
        except ImportError:
            pass
except (NameError, ImportError):
    pass


class EnhancedDisplayManager:
    """
    Advanced display manager with enhanced visualization capabilities.

    Features:
    - Interactive Plotly charts in Jupyter/Colab
    - Real-time updates with optimized performance
    - Beautiful, user-friendly dashboard
    - Auto-scaling and responsive design
    """

    def __init__(
        self,
        state: TrainingState,
        log_file: Optional[str],
        display_config: DisplayConfig,
        auto_config: bool = True,
    ):
        """
        Args:
            state: Training state
            log_file: Path to SQLite log file
            display_config: Display configuration
            auto_config: If True, auto-select best settings based on environment
        """
        self.state = state
        self.log_file = log_file
        self.config = display_config

        # Environment Detection
        self.is_notebook = _IS_JUPYTER_NOTEBOOK or _IS_COLAB
        self.is_colab = _IS_COLAB

        # Auto-configure based on environment
        if auto_config:
            self._auto_configure()

        # Display handlers
        self.dashboard_layout: Optional[Layout] = None
        self.live_context: Optional[Live] = None
        self.notebook_container = None
        self.notebook_display: Optional[NotebookDisplay] = None

        # Plotly figures cache
        self.figures_cache: Dict[str, Any] = {}

        # Performance optimization
        self.last_update_time = 0
        self.update_interval = 0.5  # minimum 0.5s between updates

        # History buffers for real-time plotting
        self.loss_buffer = deque(maxlen=200)
        self.grad_buffer = deque(maxlen=200)
        self.time_buffer = deque(maxlen=200)

        self._initialize_display()

    def _auto_configure(self):
        """Auto-configure based on current environment."""
        if self.is_colab:
            _logger.info("🎨 Google Colab detected - Enabling enhanced visualization")
            self.enable_notebook_display = True
            self.use_plotly = _PLOTLY_AVAILABLE
        elif _IS_JUPYTER_NOTEBOOK:
            _logger.info(
                "🎨 Jupyter Notebook detected - Enabling enhanced visualization"
            )
            self.enable_notebook_display = True
            self.use_plotly = _PLOTLY_AVAILABLE
        else:
            _logger.info("🖥️  Terminal detected - Using Rich TUI")
            self.enable_notebook_display = False
            self.use_plotly = False

    def _initialize_display(self):
        """Initialize display according to environment."""
        if not self.is_notebook:
            # Terminal mode
            self.dashboard_layout = create_dashboard_layout(self.state)
            self.live_context = Live(
                self.dashboard_layout, refresh_per_second=2, transient=False
            )
        elif self.enable_notebook_display and _IPYWIDGETS_AVAILABLE:
            # Notebook mode with enhanced display
            self.notebook_display = NotebookDisplay(
                state=self.state, log_file=self.log_file, auto_optimize=True
            )
        else:
            _logger.warning(
                "⚠️ Enhanced display not available - falling back to basic mode"
            )

    def _setup_notebook_display(self):
        """Initialize notebook display with widgets."""
        if not _IPYWIDGETS_AVAILABLE:
            return

        # Build container for display
        self.status_widget = HTMLWidget(
            value="<h3>⏳ Initializing GradLens...</h3>",
            layout=WidgetLayout(width="100%"),
        )

        self.metrics_widget = HTMLWidget(value="", layout=WidgetLayout(width="100%"))

        self.notebook_container = VBox(
            [self.status_widget, self.metrics_widget, self.fig]
        )

        display(self.notebook_container)

        _logger.info("✅ Notebook display initialized")

    def start(self):
        """Start display context."""
        if self.live_context:
            self.live_context.start()

    def stop(self):
        """Stop display context."""
        if self.live_context and self.live_context.is_started:
            self.live_context.stop()

    def update(self):
        """Update display (with throttling for performance)."""
        current_time = time.time()

        # Throttling: only update if enough time has elapsed
        if current_time - self.last_update_time < self.update_interval:
            return

        self.last_update_time = current_time

        # Update buffers
        self._update_buffers()

        if self.live_context and self.live_context.is_started:
            # Terminal mode
            update_dashboard_layout(self.state, self.dashboard_layout)
        elif self.enable_notebook_display and _IPYWIDGETS_AVAILABLE:
            # Notebook mode
            if self.notebook_display:
                self.notebook_display.update()

    def _update_buffers(self):
        """Update data buffers used for charts."""
        current_step = (
            self.state.current_epoch * self.state.steps_per_epoch
            + self.state.current_step
        )

        self.time_buffer.append(current_step)
        self.loss_buffer.append(self.state.current_loss)

        if self.state.grad_stats:
            max_grad = max(norm for norm, _ in self.state.grad_stats.values())
            self.grad_buffer.append(max_grad)
        else:
            self.grad_buffer.append(0)

    def _update_notebook_display(self):
        """Update notebook display widgets."""
        # Update status section
        progress_pct = (
            (
                self.state.current_epoch * self.state.steps_per_epoch
                + self.state.current_step
            )
            / (self.state.total_epochs * self.state.steps_per_epoch)
            * 100
        )

        status_html = f"""
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                    padding: 20px; border-radius: 10px; color: white; margin: 10px 0;">
            <h2 style="margin: 0;">🔥 GradLens Live Monitor</h2>
            <p style="margin: 5px 0;">
                Epoch: <strong>{self.state.current_epoch + 1}/{self.state.total_epochs}</strong> | 
                Step: <strong>{self.state.current_step + 1}/{self.state.steps_per_epoch}</strong> | 
                Progress: <strong>{progress_pct:.1f}%</strong>
            </p>
            <div style="background: rgba(255,255,255,0.2); height: 20px; border-radius: 10px; overflow: hidden;">
                <div style="background: #4ade80; height: 100%; width: {progress_pct}%; 
                           transition: width 0.3s ease;"></div>
            </div>
        </div>
        """

        # Update metrics
        nan_status = (
            "✅ All Clear"
            if not self.state.nan_alert
            else f"🚨 {self.state.nan_alert.get('type', 'Alert')}"
        )

        max_grad = "N/A"
        if self.state.grad_stats:
            worst_layer = max(
                self.state.grad_stats, key=lambda k: self.state.grad_stats[k][0]
            )
            max_grad_val = self.state.grad_stats[worst_layer][0]
            max_grad = f"{max_grad_val:.2e} ({worst_layer})"

        max_dead = "N/A"
        if self.state.dead_neuron_stats:
            worst_layer = max(
                self.state.dead_neuron_stats, key=self.state.dead_neuron_stats.get
            )
            max_dead_val = self.state.dead_neuron_stats[worst_layer] * 100
            max_dead = f"{max_dead_val:.1f}% ({worst_layer})"

        metrics_html = f"""
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
                    gap: 15px; margin: 10px 0;">
            <div style="background: white; padding: 15px; border-radius: 10px; 
                       border-left: 4px solid #3b82f6; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <div style="color: #6b7280; font-size: 14px;">Current Loss</div>
                <div style="font-size: 24px; font-weight: bold; color: #1f2937;">
                    {self.state.current_loss:.4f}
                </div>
            </div>
            
            <div style="background: white; padding: 15px; border-radius: 10px; 
                       border-left: 4px solid #10b981; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <div style="color: #6b7280; font-size: 14px;">NaN/Inf Status</div>
                <div style="font-size: 20px; font-weight: bold; color: #1f2937;">
                    {nan_status}
                </div>
            </div>
            
            <div style="background: white; padding: 15px; border-radius: 10px; 
                       border-left: 4px solid #f59e0b; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <div style="color: #6b7280; font-size: 14px;">Max Gradient</div>
                <div style="font-size: 16px; font-weight: bold; color: #1f2937;">
                    {max_grad}
                </div>
            </div>
            
            <div style="background: white; padding: 15px; border-radius: 10px; 
                       border-left: 4px solid #ef4444; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <div style="color: #6b7280; font-size: 14px;">Dead Neurons</div>
                <div style="font-size: 16px; font-weight: bold; color: #1f2937;">
                    {max_dead}
                </div>
            </div>
        </div>
        """

        self.status_widget.value = status_html
        self.metrics_widget.value = metrics_html

        # Update charts
        if self.use_plotly and len(self.loss_buffer) > 1:
            self._update_plotly_charts()

    def _initialize_plotly_charts(self):
        """Create initial Plotly charts."""
        if not _PLOTLY_AVAILABLE:
            return

        # Create figure with subplots
        self.fig = go.FigureWidget(
            make_subplots(
                rows=2,
                cols=1,
                subplot_titles=("Loss Over Time", "Max Gradient Norm"),
                vertical_spacing=0.15,
                row_heights=[0.5, 0.5],
            )
        )

        # Loss plot
        self.fig.add_trace(
            go.Scatter(
                x=[],
                y=[],
                mode="lines+markers",
                name="Loss",
                line=dict(color="#3b82f6", width=2),
                marker=dict(size=4),
            ),
            row=1,
            col=1,
        )

        # Gradient plot
        self.fig.add_trace(
            go.Scatter(
                x=[],
                y=[],
                mode="lines+markers",
                name="Max Gradient",
                line=dict(color="#f59e0b", width=2),
                marker=dict(size=4),
            ),
            row=2,
            col=1,
        )

        # Layout
        self.fig.update_layout(
            height=500,
            showlegend=True,
            template="plotly_white",
            margin=dict(l=50, r=50, t=50, b=50),
        )

        self.fig.update_xaxes(title_text="Step", row=2, col=1)
        self.fig.update_yaxes(title_text="Loss", row=1, col=1)
        self.fig.update_yaxes(title_text="Gradient Norm", type="log", row=2, col=1)

    def _update_plotly_charts(self):
        """Update Plotly chart data (without re-render)."""
        if not _PLOTLY_AVAILABLE or not hasattr(self, "fig"):
            return

        # Update widget data directly
        self.fig.data[0].x = list(self.time_buffer)
        self.fig.data[0].y = list(self.loss_buffer)

        self.fig.data[1].x = list(self.time_buffer)
        self.fig.data[1].y = list(self.grad_buffer)

    def plot_history(self, layer_name: str, metric_name: str):
        """
        Display the history of a specific metric using Plotly.

        Args:
            layer_name: Layer name
            metric_name: Metric name
        """
        if not self.is_notebook:
            _logger.warning("plot_history() only works in Notebook environments")
            return

        if not _PLOTLY_AVAILABLE:
            _logger.error("Plotly is not installed. Install via: pip install plotly")
            return

        if not self.log_file:
            _logger.error("Log file is not specified")
            return

        # Fetch data
        history_data = fetch_data_from_db(self.log_file, layer_name, metric_name)

        if not history_data:
            _logger.warning(f"No data found for {layer_name}/{metric_name}")
            return

        steps = [row[0] for row in history_data]
        values = [row[1] for row in history_data]

        # Build chart
        fig = go.Figure()

        fig.add_trace(
            go.Scatter(
                x=steps,
                y=values,
                mode="lines+markers",
                name=f"{metric_name}",
                line=dict(color="#8b5cf6", width=2),
                marker=dict(size=4, color="#8b5cf6"),
            )
        )

        fig.update_layout(
            title=f"📊 History: {metric_name} - {layer_name}",
            xaxis_title="Step",
            yaxis_title=metric_name,
            template="plotly_white",
            height=400,
            hovermode="x unified",
        )

        fig.show()

    def display_summary_report(self):
        """Display the final summary report."""
        if not self.is_notebook:
            _logger.warning("display_summary() is designed for Notebook environments")
            return

        if not self.log_file:
            _logger.error("Log file is not specified")
            return

        from .cli import print_summary_report_to_console

        console = Console(force_jupyter=True, force_terminal=False)

        # Show styled header
        if _IPYTHON_AVAILABLE:
            display(
                HTML("""
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                        padding: 30px; border-radius: 15px; color: white; margin: 20px 0;">
                <h1 style="margin: 0;">📊 GradLens Final Report</h1>
                <p style="margin: 10px 0; opacity: 0.9;">
                    Complete analysis of your model training
                </p>
            </div>
            """)
            )

        print_summary_report_to_console(self.log_file, console=console)


# Helper functions that were previously in display.py
def create_dashboard_layout(state: TrainingState) -> Layout:
    """Create a basic dashboard layout for terminal display"""
    layout = Layout(name="root")
    layout.split_column(
        Layout(name="header", size=3),
        Layout(name="main"),
        Layout(name="footer", size=3),
    )
    update_dashboard_layout(state, layout)
    return layout


def update_dashboard_layout(state: TrainingState, layout: Layout) -> None:
    """Update the dashboard layout with current state"""
    # Basic implementation for terminal display
    if layout and hasattr(layout, "main"):
        header_panel = Panel(
            Text(f"🔥 GradLens | Run: {state.run_name}", style="bold"),
            border_style="magenta",
        )
        layout["header"].update(header_panel)

        table = Table.grid(expand=True)
        table.add_column(justify="left", ratio=1)
        table.add_column(justify="right", ratio=1)
        table.add_row(
            f"Epoch: {state.current_epoch + 1}/{state.total_epochs}",
            f"Step: {state.current_step + 1}/{state.steps_per_epoch}",
        )
        table.add_row(
            f"Loss: {state.current_loss:.4f}",
            f"Grad Max: {state.max_grad_norm_seen:.2f}",
        )
        table.add_row(
            f"Dead Neuron Max: {state.max_dead_neuron_seen * 100:.1f}%",
            f"Tracked: "
            f"{'G' if state.track_grads else '-'} "
            f"{'N' if state.track_dead_neurons else '-'} "
            f"{'A' if state.track_activations else '-'} "
            f"{'P' if state.track_parameters else '-'}",
        )
        layout["main"].update(
            Panel(table, title="Training Progress", border_style="green")
        )

        if state.nan_alert:
            alert = state.nan_alert
            footer_text = Text.assemble(
                ("⚠️  ALERT: ", "bold red"),
                f"{alert.get('type', 'unknown')} @ {alert.get('layer_name', 'unknown')} "
                f"(epoch {alert.get('epoch')}, step {alert.get('step')})",
            )
            border = "red"
        else:
            footer_text = Text("✅ No catastrophic events detected", style="bold green")
            border = "green"

        layout["footer"].update(Panel(footer_text, title="Status", border_style=border))

# gradlens/history.py

import csv
import os
import logging
import math
from datetime import datetime
from typing import List, Union, Any

from .state import TrainingState

# --- 1. Import custom exceptions ---
from .exceptions import DatabaseError

# --- 2. Setup module-level logger ---
_logger = logging.getLogger(__name__)


class HistoryLogger:
    """
    Handles writing a summary of a training run to a CSV log file.

    Each training run (i.e., each time a `Watcher` context is exited)
    will append a single row to this CSV file, providing a high-level
    overview of all past runs.

    Attributes:
        history_log_file (str): The file path to the CSV summary log.
    """

    def __init__(self, history_log_file: str) -> None:
        """
        Initializes the HistoryLogger.

        Args:
            history_log_file (str): The path to the CSV file where the history will be logged.
        """
        self.history_log_file: str = history_log_file
        _logger.debug(f"HistoryLogger initialized for file: {history_log_file}")

    def log_summary(
        self,
        state: TrainingState,
        start_time: float,
        end_time: float,
        final_status: str,
    ) -> None:
        """
        Appends a summary row of the completed training run to the history log file.

        This method calculates the duration, formats timestamps, and retrieves
        key summary statistics from the final `TrainingState` object.
        It also handles creating the CSV header if the file is new or empty.

        Args:
            state (TrainingState): The final state of the training run.
            start_time (float): The `time.time()` timestamp when the training started.
            end_time (float): The `time.time()` timestamp when the training ended.
            final_status (str): A string describing the final status (e.g., 'Success ✅').

        Raises:
            DatabaseError: If an IOError occurs during file writing.
        """
        if not self.history_log_file:
            return

        duration: float = round(end_time - start_time, 2)
        start_timestamp_str: str = datetime.fromtimestamp(start_time).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        end_timestamp_str: str = datetime.fromtimestamp(end_time).strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        # Safely format the final loss, handling potential NaN/Inf values
        final_loss_str: str = (
            f"{state.current_loss:.4f}"
            if state.current_loss is not None
            and not (math.isinf(state.current_loss) or math.isnan(state.current_loss))
            else "N/A"
        )

        # Prepare the data row for the CSV
        summary_data: List[Union[str, float, int]] = [
            start_timestamp_str,
            end_timestamp_str,
            duration,
            state.run_name,
            state.model_class_name,
            state.epochs_completed,
            state.steps_completed_in_last_epoch,
            final_status,
            final_loss_str,
            f"{state.max_grad_norm_seen:.2f}",
            f"{state.max_dead_neuron_seen * 100:.1f}%",  # Convert to percentage string
        ]

        file_exists: bool = os.path.isfile(self.history_log_file)

        # --- 3. Refactored error handling ---
        try:
            # Open in 'a+' (append + read) mode to create if not exists
            with open(
                self.history_log_file, "a+", newline="", encoding="utf-8"
            ) as csvfile:
                writer: Any = csv.writer(
                    csvfile
                )  # `csv.writer` is tricky to type precisely

                # Write header if file is new or empty
                if not file_exists or os.path.getsize(self.history_log_file) == 0:
                    header: List[str] = [
                        "Timestamp Start",
                        "Timestamp End",
                        "Duration (s)",
                        "Run Name",
                        "Model Class",
                        "Epochs Completed",
                        "Steps Completed",
                        "Final Status",
                        "Final Loss",
                        "Max Grad Norm Seen",
                        "Max Dead Neurons Seen (%)",
                    ]
                    writer.writerow(header)

                # Append the summary data for the current run
                writer.writerow(summary_data)

                # --- 4. Replaced print() with _logger.info() ---
                _logger.info(f"Training summary appended to {self.history_log_file}")

        except IOError as e:
            # Log the error and raise a specific, catchable exception
            _logger.error(
                f"IOError writing to history log file '{self.history_log_file}': {e}",
                exc_info=True,
            )
            raise DatabaseError(
                f"Failed to write to history log file '{self.history_log_file}'",
                "write",
                self.history_log_file,
            ) from e
        except Exception as e:
            # Catch any other unexpected error
            _logger.critical(
                f"Unexpected error writing history log: {e}", exc_info=True
            )
            # Re-raise the original exception for the Watcher to handle
            raise

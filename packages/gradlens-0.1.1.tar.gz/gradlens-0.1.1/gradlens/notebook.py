# gradlens/notebook.py

"""
🎨 Notebook Display Manager for GradLens
Optimized for Google Colab and Jupyter Notebook
"""

import sys
import logging
from typing import Optional
from collections import deque

from .state import TrainingState

# Environment Detection
_IPYTHON_AVAILABLE = False
_IPYWIDGETS_AVAILABLE = False
_IS_COLAB = False
_IS_JUPYTER_NOTEBOOK = False
_PLOTLY_AVAILABLE = False

try:
    from IPython import get_ipython
    from IPython.display import display, HTML

    _IPYTHON_AVAILABLE = True
    shell = get_ipython().__class__.__name__
    if shell == "ZMQInteractiveShell":
        _IS_JUPYTER_NOTEBOOK = True
    elif "google.colab" in sys.modules:
        _IS_COLAB = True
except (NameError, ImportError):
    pass

try:
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots

    _PLOTLY_AVAILABLE = True
except ImportError:
    pass

try:
    if _IS_JUPYTER_NOTEBOOK or _IS_COLAB:
        import ipywidgets as widgets

        _IPYWIDGETS_AVAILABLE = True
except ImportError:
    pass

_logger = logging.getLogger(__name__)


class NotebookDisplay:
    """
    🎨 Advanced display for Jupyter and Colab environments.

    Features:
    - Interactive dashboard with multiple tabs
    - Real-time charts with Plotly
    - Beautiful, responsive UI
    - Optimizations for Colab
    """

    def __init__(
        self,
        state: TrainingState,
        log_file: Optional[str] = None,
        auto_optimize: bool = True,
    ):
        """
        Args:
            state: Training state
            log_file: Path to SQLite log file
            auto_optimize: Auto-optimize for Colab
        """
        self.state = state
        self.log_file = log_file
        self.auto_optimize = auto_optimize

        # Environment detection
        self.is_colab = _IS_COLAB
        self.is_jupyter = _IS_JUPYTER_NOTEBOOK
        self.is_notebook = self.is_colab or self.is_jupyter

        if not self.is_notebook:
            _logger.warning("NotebookDisplay works only in Jupyter/Colab environments")
            return

        # Performance optimization for Colab
        if self.auto_optimize and self.is_colab:
            self._optimize_for_colab()

        # UI Components
        self.tabs = None
        self.live_fig = None
        self.overview_fig = None
        self.gradient_fig = None
        self.performance_fig = None
        self.health_fig = None

        # Data buffers for real-time updates
        self.loss_buffer = deque(maxlen=500)
        self.grad_buffer = deque(maxlen=500)
        self.time_buffer = deque(maxlen=500)

        # Performance tracking
        self.last_update_time = 0
        self.update_interval = 0.5  # minimum 0.5s between updates

        self._create_dashboard()

    def _optimize_for_colab(self):
        """Optimize visuals and performance for Google Colab."""
        _logger.info("🚀 Optimizing for Google Colab...")

        # Plotly settings for Colab
        if _PLOTLY_AVAILABLE:
            import plotly.io as pio

            pio.renderers.default = "colab"

        # Reduce update frequency for Colab
        self.update_interval = 1.0

        # Memory optimization settings
        self.loss_buffer = deque(maxlen=200)  # smaller than Jupyter
        self.grad_buffer = deque(maxlen=200)
        self.time_buffer = deque(maxlen=200)

    def _create_dashboard(self):
        """Create the interactive dashboard."""
        if not _IPYWIDGETS_AVAILABLE:
            _logger.error(
                "ipywidgets is not installed. Install: pip install ipywidgets"
            )
            return

        # Header
        self._create_header()

        # Tabs
        self._create_tabs()

        # Show dashboard
        display(self.tabs)

        _logger.info("✅ Notebook Dashboard created")

    def _create_header(self):
        """Create a styled header."""
        if not _IPYTHON_AVAILABLE:
            return

        # Environment label
        env_name = "Google Colab" if self.is_colab else "Jupyter Notebook"
        env_icon = "🚀" if self.is_colab else "📓"

        header_html = f"""
        <div style="
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 25px;
            border-radius: 15px;
            color: white;
            margin: 15px 0;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        ">
            <div style="display: flex; align-items: center; justify-content: space-between;">
                <div>
                    <h1 style="margin: 0; font-size: 28px; font-weight: bold;">
                        🔥 GradLens Live Monitor
                    </h1>
                    <p style="margin: 8px 0; opacity: 0.9; font-size: 16px;">
                        {env_icon} {env_name} | Real-time PyTorch Training Monitor
                    </p>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 14px; opacity: 0.8;">Status</div>
                    <div style="font-size: 18px; font-weight: bold;">⏳ Initializing...</div>
                </div>
            </div>
        </div>
        """

        display(HTML(header_html))

    def _create_tabs(self):
        """Create all dashboard tabs."""
        # Live Training Tab
        self.live_fig = self._create_live_plot()

        # Analysis Tabs
        self.overview_fig = self._create_overview_tab()
        self.gradient_fig = self._create_gradient_tab()
        self.performance_fig = self._create_performance_tab()
        self.health_fig = self._create_health_tab()

        # Refresh button
        refresh_btn = widgets.Button(
            description="🔄 Refresh Analysis",
            button_style="info",
            icon="refresh",
            layout=widgets.Layout(width="200px", height="40px"),
        )
        refresh_btn.on_click(self._refresh_analysis)

        # Control panel
        controls = widgets.HBox(
            [
                refresh_btn,
                widgets.HTML("<div style='width: 20px;'></div>"),
                widgets.HTML(
                    "<div style='color: #666; font-size: 14px;'>Click refresh to update analysis tabs</div>"
                ),
            ]
        )

        # Tab content
        tab_contents = [
            self.live_fig,  # Live Training
            widgets.VBox([controls, self.overview_fig]),  # Model Overview
            widgets.VBox([controls, self.gradient_fig]),  # Gradients
            widgets.VBox([controls, self.performance_fig]),  # Performance
            widgets.VBox([controls, self.health_fig]),  # Health
        ]

        # Create tabs
        self.tabs = widgets.Tab(children=tab_contents)
        self.tabs.set_title(0, "📊 Live Training")
        self.tabs.set_title(1, "🏗️ Model Overview")
        self.tabs.set_title(2, "📈 Gradients")
        self.tabs.set_title(3, "⚡ Performance")
        self.tabs.set_title(4, "🏥 Health")

    def _create_live_plot(self):
        """Create the live training plot."""
        if not _PLOTLY_AVAILABLE:
            return widgets.HTML("<div>Plotly is not installed</div>")

        fig = go.FigureWidget(
            make_subplots(
                rows=3,
                cols=1,
                subplot_titles=(
                    "Loss Over Time",
                    "Gradient Norms",
                    "Learning Progress",
                ),
                vertical_spacing=0.1,
                row_heights=[0.4, 0.3, 0.3],
            )
        )

        # Loss plot
        fig.add_trace(
            go.Scatter(
                x=[],
                y=[],
                mode="lines+markers",
                name="Training Loss",
                line=dict(color="#3b82f6", width=3),
                marker=dict(size=6, color="#3b82f6"),
            ),
            row=1,
            col=1,
        )

        # Gradient plot
        fig.add_trace(
            go.Scatter(
                x=[],
                y=[],
                mode="lines+markers",
                name="Max Gradient",
                line=dict(color="#f59e0b", width=2),
                marker=dict(size=4, color="#f59e0b"),
            ),
            row=2,
            col=1,
        )

        # Progress plot
        fig.add_trace(
            go.Scatter(
                x=[],
                y=[],
                mode="lines+markers",
                name="Progress %",
                line=dict(color="#10b981", width=2),
                marker=dict(size=4, color="#10b981"),
            ),
            row=3,
            col=1,
        )

        # Layout
        fig.update_layout(
            height=600,
            showlegend=True,
            template="plotly_white",
            margin=dict(l=50, r=50, t=50, b=50),
            title="🔥 Real-time Training Monitor",
        )

        fig.update_xaxes(title_text="Step", row=3, col=1)
        fig.update_yaxes(title_text="Loss", row=1, col=1)
        fig.update_yaxes(title_text="Gradient Norm", type="log", row=2, col=1)
        fig.update_yaxes(title_text="Progress %", row=3, col=1)

        return fig

    def _create_overview_tab(self):
        """Create model overview tab."""
        if not _PLOTLY_AVAILABLE:
            return widgets.HTML("<div>Plotly is not installed</div>")

        fig = go.FigureWidget()
        fig.add_annotation(
            text="📊 Model Overview<br>Click Refresh to analyze model",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=20, color="gray"),
        )
        fig.update_layout(height=400, title="🏗️ Model Architecture & Statistics")
        return fig

    def _create_gradient_tab(self):
        """Create gradient analysis tab."""
        if not _PLOTLY_AVAILABLE:
            return widgets.HTML("<div>Plotly is not installed</div>")

        fig = go.FigureWidget()
        fig.add_annotation(
            text="📈 Gradient Analysis<br>Click Refresh to analyze gradients",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=20, color="gray"),
        )
        fig.update_layout(height=400, title="📈 Gradient Flow & Distribution")
        return fig

    def _create_performance_tab(self):
        """Create performance tab."""
        if not _PLOTLY_AVAILABLE:
            return widgets.HTML("<div>Plotly is not installed</div>")

        fig = go.FigureWidget()
        fig.add_annotation(
            text="⚡ Performance Metrics<br>Click Refresh to analyze performance",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=20, color="gray"),
        )
        fig.update_layout(height=400, title="⚡ Training Performance & Memory Usage")
        return fig

    def _create_health_tab(self):
        """Create health monitoring tab."""
        if not _PLOTLY_AVAILABLE:
            return widgets.HTML("<div>Plotly is not installed</div>")

        fig = go.FigureWidget()
        fig.add_annotation(
            text="🏥 Health Monitoring<br>Click Refresh to check model health",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=20, color="gray"),
        )
        fig.update_layout(height=400, title="🏥 Model Health & Diagnostics")
        return fig

    def _refresh_analysis(self, button=None):
        """Refresh analysis panels."""
        _logger.info("🔄 Refreshing analysis...")

        # Hook for real analysis; currently shows a message
        if _IPYTHON_AVAILABLE:
            display(
                HTML(
                    "<div style='color: green; margin: 10px;'>✅ Analysis refreshed!</div>"
                )
            )

    def update(self):
        """Update the dashboard display."""
        if not self.is_notebook:
            return

        import time

        current_time = time.time()

        # Throttling for performance
        if current_time - self.last_update_time < self.update_interval:
            return

        self.last_update_time = current_time

        # Update buffers
        self._update_buffers()

        # Update live chart
        if self.live_fig and hasattr(self.live_fig, "data"):
            self._update_live_plot()

    def _update_buffers(self):
        """Update data buffers."""
        current_step = (
            self.state.current_epoch * self.state.steps_per_epoch
            + self.state.current_step
        )

        self.time_buffer.append(current_step)
        self.loss_buffer.append(self.state.current_loss or 0)

        # Compute max gradient
        if self.state.grad_stats:
            max_grad = max(norm for norm, _ in self.state.grad_stats.values())
            self.grad_buffer.append(max_grad)
        else:
            self.grad_buffer.append(0)

    def _update_live_plot(self):
        """Update the live plot."""
        if not _PLOTLY_AVAILABLE or not self.live_fig:
            return

        # Update loss plot
        if len(self.loss_buffer) > 1:
            self.live_fig.data[0].x = list(self.time_buffer)
            self.live_fig.data[0].y = list(self.loss_buffer)

        # Update gradient plot
        if len(self.grad_buffer) > 1:
            self.live_fig.data[1].x = list(self.time_buffer)
            self.live_fig.data[1].y = list(self.grad_buffer)

        # Update progress plot
        if len(self.time_buffer) > 1:
            total_steps = self.state.total_epochs * self.state.steps_per_epoch
            progress = [(step / total_steps * 100) for step in self.time_buffer]
            self.live_fig.data[2].x = list(self.time_buffer)
            self.live_fig.data[2].y = progress

    def start(self):
        """Start notebook display."""
        if self.is_notebook:
            _logger.info("🎨 Notebook display started")

    def stop(self):
        """Stop notebook display."""
        if self.is_notebook:
            _logger.info("🛑 Notebook display stopped")

    def plot_history(self, layer_name: str, metric_name: str):
        """Plot the history of a specific metric."""
        if not self.is_notebook:
            _logger.warning("plot_history works only in Notebook environments")
            return

        if not _PLOTLY_AVAILABLE:
            _logger.error("Plotly is not installed")
            return

        if not self.log_file:
            _logger.error("Log file is not specified")
            return

        # Placeholder: read from DB here; show a sample plot for now
        fig = go.Figure()
        fig.add_trace(
            go.Scatter(
                x=list(range(100)),
                y=[i * 0.1 + 0.5 for i in range(100)],
                mode="lines+markers",
                name=f"{metric_name} - {layer_name}",
                line=dict(color="#8b5cf6", width=2),
            )
        )

        fig.update_layout(
            title=f"📊 History: {metric_name} - {layer_name}",
            xaxis_title="Step",
            yaxis_title=metric_name,
            template="plotly_white",
            height=400,
        )

        fig.show()

    def display_summary_report(self):
        """Display the final report."""
        if not self.is_notebook:
            _logger.warning("display_summary works only in Notebook environments")
            return

        if _IPYTHON_AVAILABLE:
            display(
                HTML("""
            <div style="
                background: linear-gradient(135deg, #10b981 0%, #059669 100%);
                padding: 30px;
                border-radius: 15px;
                color: white;
                margin: 20px 0;
                text-align: center;
            ">
                <h1 style="margin: 0; font-size: 28px;">📊 Training Complete!</h1>
                <p style="margin: 10px 0; font-size: 16px; opacity: 0.9;">Training completed successfully</p>
            </div>
            """)
            )

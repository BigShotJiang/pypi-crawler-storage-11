# gradlens/exceptions.py

"""
Custom exceptions for GradLens library.

This module provides specialized exception classes for better error handling
and debugging throughout the GradLens library.
"""

from typing import Optional, Any


class GradLensError(Exception):
    """Base exception class for all GradLens errors."""

    def __init__(self, message: str, details: Optional[dict] = None):
        """
        Initialize the base GradLens exception.

        Args:
            message: Human-readable error message
            details: Optional dictionary with additional error context
        """
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def __str__(self) -> str:
        """Format the exception message with details."""
        if self.details:
            details_str = ", ".join(f"{k}={v}" for k, v in self.details.items())
            return f"{self.message} ({details_str})"
        return self.message


class CatastrophicTrainingError(GradLensError):
    """
    Raised when a catastrophic training event is detected.

    This includes NaN/Inf values in gradients, activations, or parameters.
    """

    def __init__(
        self,
        event_type: str,
        layer_name: str,
        epoch: int,
        step: int,
        value: Optional[Any] = None,
    ):
        """
        Initialize a catastrophic training error.

        Args:
            event_type: Type of catastrophe (e.g., 'Gradient', 'Activation')
            layer_name: Name of the affected layer
            epoch: Training epoch when error occurred
            step: Training step when error occurred
            value: Optional problematic value
        """
        details = {
            "event_type": event_type,
            "layer_name": layer_name,
            "epoch": epoch,
            "step": step,
        }

        if value is not None:
            details["value"] = value

        message = (
            f"Catastrophic {event_type} detected in layer '{layer_name}' "
            f"at epoch {epoch}, step {step}"
        )

        super().__init__(message, details)

        self.event_type = event_type
        self.layer_name = layer_name
        self.epoch = epoch
        self.step = step
        self.value = value


class DatabaseError(GradLensError):
    """Raised when database operations fail."""

    def __init__(self, message: str, operation: str, db_file: Optional[str] = None):
        """
        Initialize a database error.

        Args:
            message: Error message
            operation: Type of operation that failed (e.g., 'write', 'read')
            db_file: Optional path to the database file
        """
        details = {"operation": operation}
        if db_file:
            details["db_file"] = db_file

        super().__init__(message, details)
        self.operation = operation
        self.db_file = db_file


class HookAttachmentError(GradLensError):
    """Raised when hook attachment fails."""

    def __init__(self, message: str, layer_name: Optional[str] = None):
        """
        Initialize a hook attachment error.

        Args:
            message: Error message
            layer_name: Optional name of the layer where attachment failed
        """
        details = {}
        if layer_name:
            details["layer_name"] = layer_name

        super().__init__(message, details)
        self.layer_name = layer_name


class ConfigurationError(GradLensError):
    """Raised when configuration is invalid."""

    def __init__(self, message: str, parameter: Optional[str] = None):
        """
        Initialize a configuration error.

        Args:
            message: Error message
            parameter: Optional name of the invalid parameter
        """
        details = {}
        if parameter:
            details["parameter"] = parameter

        super().__init__(message, details)
        self.parameter = parameter


class DisplayError(GradLensError):
    """Raised when display operations fail."""

    pass


class DataFetchError(GradLensError):
    """Raised when data fetching from database fails."""

    def __init__(
        self,
        message: str,
        layer_name: Optional[str] = None,
        metric_name: Optional[str] = None,
    ):
        """
        Initialize a data fetch error.

        Args:
            message: Error message
            layer_name: Optional layer name
            metric_name: Optional metric name
        """
        details = {}
        if layer_name:
            details["layer_name"] = layer_name
        if metric_name:
            details["metric_name"] = metric_name

        super().__init__(message, details)
        self.layer_name = layer_name
        self.metric_name = metric_name

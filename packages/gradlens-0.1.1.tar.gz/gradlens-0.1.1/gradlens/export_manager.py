#!/usr/bin/env python3
"""
GradLens Export Manager
========================

This module provides functionality to generate comprehensive HTML and PDF reports
from GradLens training data. It creates professional reports suitable for
academic papers, business presentations, and technical documentation.

Author: GradLens Team
"""

import sqlite3
import base64
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
import logging

try:
    import plotly.graph_objects as go
except ImportError:  # pragma: no cover - optional dependency
    go = None  # type: ignore[assignment]
    PLOTLY_AVAILABLE = False
else:
    PLOTLY_AVAILABLE = True

try:
    import weasyprint

    WEASYPRINT_AVAILABLE = True
except ImportError:
    WEASYPRINT_AVAILABLE = False

_logger = logging.getLogger(__name__)


class ExportManager:
    """
    Manages the generation of comprehensive training reports in HTML and PDF formats.

    This class provides functionality to create professional reports from GradLens
    training data, including charts, insights, and technical details.
    """

    def __init__(self, output_dir: str = "reports", template: str = "professional"):
        """
        Initialize the ExportManager.

        Args:
            output_dir: Directory to save generated reports
            template: Template style (professional, academic, business, minimal)
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.template = template

        _logger.info(
            f"ExportManager initialized with output directory: {self.output_dir}"
        )

    def generate_report(
        self,
        run_id: str,
        format: str = "pdf",
        include_charts: bool = True,
        include_insights: bool = True,
        include_code_snippets: bool = False,
        custom_title: Optional[str] = None,
    ) -> str:
        """
        Generate a comprehensive training report.

        Args:
            run_id: Unique identifier for the training run
            format: Output format ("pdf", "html", or "both")
            include_charts: Whether to include charts and visualizations
            include_insights: Whether to include model insights and analysis
            include_code_snippets: Whether to include relevant code snippets
            custom_title: Custom title for the report

        Returns:
            Path to the generated report file(s)
        """
        _logger.info(f"Generating {format} report for run: {run_id}")

        try:
            # Load run data
            run_data = self._load_run_data(run_id)
            if not run_data:
                raise ValueError(f"No data found for run: {run_id}")

            # Generate insights and analysis
            insights = self._generate_insights(run_data) if include_insights else {}
            charts = self._generate_charts(run_data) if include_charts else {}

            # Build HTML content
            html_content = self._build_html(
                run_data, insights, charts, include_code_snippets, custom_title
            )

            # Export to requested format(s)
            output_paths = []
            if format in ["html", "both"]:
                html_path = self._export_html(html_content, run_id)
                output_paths.append(html_path)

            if format in ["pdf", "both"]:
                if not WEASYPRINT_AVAILABLE:
                    _logger.warning(
                        "WeasyPrint not available, cannot generate PDF. Install with: pip install weasyprint"
                    )
                    if format == "pdf":
                        raise ImportError("WeasyPrint is required for PDF generation")
                else:
                    pdf_path = self._export_pdf(html_content, run_id)
                    output_paths.append(pdf_path)

            _logger.info(f"Report generated successfully: {output_paths}")
            return output_paths[0] if len(output_paths) == 1 else output_paths

        except Exception as e:
            _logger.error(f"Failed to generate report: {e}")
            raise

    def quick_report(self, run_id: str) -> str:
        """
        Generate a quick, minimal report.

        Args:
            run_id: Unique identifier for the training run

        Returns:
            Path to the generated PDF report
        """
        return self.generate_report(
            run_id=run_id,
            format="pdf",
            include_charts=True,
            include_insights=False,
            include_code_snippets=False,
        )

    def compare_runs(
        self,
        run_ids: List[str],
        output_format: str = "pdf",
        comparison_type: str = "performance",
    ) -> str:
        """
        Generate a comparison report for multiple runs.

        Args:
            run_ids: List of run IDs to compare
            output_format: Output format ("pdf" or "html")
            comparison_type: Type of comparison ("performance", "architecture", "efficiency")

        Returns:
            Path to the generated comparison report
        """
        _logger.info(f"Generating comparison report for {len(run_ids)} runs")

        # Load data for all runs
        runs_data = []
        for run_id in run_ids:
            run_data = self._load_run_data(run_id)
            if run_data:
                runs_data.append(run_data)

        if not runs_data:
            raise ValueError("No valid run data found for comparison")

        # Generate comparison insights
        comparison_insights = self._generate_comparison_insights(
            runs_data, comparison_type
        )
        comparison_charts = self._generate_comparison_charts(runs_data, comparison_type)

        # Build comparison HTML
        html_content = self._build_comparison_html(
            runs_data, comparison_insights, comparison_charts, comparison_type
        )

        # Export comparison report
        if output_format == "html":
            return self._export_html(
                html_content, f"comparison_{'_'.join(run_ids[:3])}"
            )
        else:
            return self._export_pdf(html_content, f"comparison_{'_'.join(run_ids[:3])}")

    def _load_run_data(self, run_id: str) -> Optional[Dict[str, Any]]:
        """Load training data for a specific run."""
        try:
            # Try to find database file
            import glob

            db_paths = [f"gradlens_logs/{run_id}.db", f"logs/*/{run_id}.db", "*.db"]

            db_path = None
            for pattern in db_paths:
                matches = glob.glob(pattern)
                if matches:
                    db_path = matches[0]
                    break

            if not db_path or not Path(db_path).exists():
                _logger.warning(f"Database file not found for run: {run_id}")
                return None

            # Load data from database
            with sqlite3.connect(db_path) as conn:
                cursor = conn.cursor()

                # Get metrics data (main table)
                cursor.execute("SELECT * FROM metrics ORDER BY epoch, step")
                metrics_data = cursor.fetchall()

                if not metrics_data:
                    _logger.warning(f"No metrics data found for: {run_id}")
                    return None

                # Extract basic info from metrics
                epochs = [row[2] for row in metrics_data]  # epoch column
                values = [row[6] for row in metrics_data]  # value column

                # Create synthetic run info
                run_info = (
                    run_id,  # run_id
                    len(set(epochs)),  # total_epochs
                    len(metrics_data),  # total_steps
                    min(values) if values else 0,  # min_value
                    max(values) if values else 0,  # max_value
                    sum(values) / len(values) if values else 0,  # avg_value
                    values[-1] if values else 0,  # final_value
                )

                # Create basic config
                config_data = {
                    "model_type": "PyTorch Model",
                    "architecture": "Neural Network",
                    "total_epochs": len(set(epochs)),
                    "total_steps": len(metrics_data),
                }

                return {
                    "run_id": run_id,
                    "run_info": run_info,
                    "metrics": metrics_data,
                    "config": config_data,
                    "db_path": db_path,
                }

        except Exception as e:
            _logger.error(f"Error loading run data: {e}")
            return None

    def _generate_insights(self, run_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate insights and analysis from run data."""
        insights = {
            "training_summary": self._analyze_training_performance(run_data),
            "model_analysis": self._analyze_model_characteristics(run_data),
            "warnings": self._generate_warnings(run_data),
            "recommendations": self._generate_recommendations(run_data),
        }
        return insights

    def _generate_charts(self, run_data: Dict[str, Any]) -> Dict[str, str]:
        """Generate chart images as base64 encoded strings."""
        charts = {}

        if not PLOTLY_AVAILABLE:
            _logger.warning("Plotly not available, skipping chart generation")
            return charts

        try:
            # Loss curve
            if run_data.get("metrics"):
                loss_fig = self._create_loss_chart(run_data["metrics"])
                charts["loss_curve"] = self._fig_to_base64(loss_fig)

            # Accuracy curve (if available)
            accuracy_fig = self._create_accuracy_chart(run_data["metrics"])
            if accuracy_fig:
                charts["accuracy_curve"] = self._fig_to_base64(accuracy_fig)

            # Gradient flow (if available)
            gradient_fig = self._create_gradient_chart(run_data)
            if gradient_fig:
                charts["gradient_flow"] = self._fig_to_base64(gradient_fig)

        except Exception as e:
            _logger.error(f"Error generating charts: {e}")

        return charts

    def _create_loss_chart(self, metrics_data: List) -> go.Figure:
        """Create loss curve chart."""
        if not metrics_data:
            return go.Figure()

        # Extract loss values
        epochs = [row[1] for row in metrics_data]  # Assuming epoch is column 1
        losses = [row[3] for row in metrics_data]  # Assuming loss is column 3

        fig = go.Figure()
        fig.add_trace(
            go.Scatter(
                x=epochs,
                y=losses,
                mode="lines",
                name="Training Loss",
                line=dict(color="#1f77b4", width=2),
            )
        )

        fig.update_layout(
            title="Training Loss Over Time",
            xaxis_title="Epoch",
            yaxis_title="Loss",
            template="plotly_white",
            width=800,
            height=400,
        )

        return fig

    def _create_accuracy_chart(self, metrics_data: List) -> Optional[go.Figure]:
        """Create accuracy curve chart if accuracy data is available."""
        # This would need to be implemented based on actual data structure
        return None

    def _create_gradient_chart(self, run_data: Dict[str, Any]) -> Optional[go.Figure]:
        """Create gradient flow chart if gradient data is available."""
        # This would need to be implemented based on actual data structure
        return None

    def _fig_to_base64(self, fig: go.Figure) -> str:
        """Convert Plotly figure to base64 encoded image."""
        img_bytes = fig.to_image(format="png", width=800, height=400)
        return base64.b64encode(img_bytes).decode()

    def _analyze_training_performance(self, run_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze training performance metrics."""
        metrics = run_data.get("metrics", [])
        if not metrics:
            return {}

        losses = [row[6] for row in metrics]  # Assuming loss is column 6 (value)

        return {
            "final_loss": losses[-1] if losses else 0,
            "min_loss": min(losses) if losses else 0,
            "max_loss": max(losses) if losses else 0,
            "avg_loss": sum(losses) / len(losses) if losses else 0,
            "total_epochs": len(set(row[2] for row in metrics)),  # epoch is column 2
            "total_steps": len(metrics),
        }

    def _analyze_model_characteristics(
        self, run_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Analyze model characteristics from run data."""
        config = run_data.get("config", {})
        run_info = run_data.get("run_info", ())  # Use empty tuple as default for safety

        model_type = config.get("model_type", "PyTorch Model")
        # Try to extract parameter count from run_info if available
        parameter_count = "Unknown"
        if len(run_info) > 5:
            try:
                parameter_count = (
                    f"{run_info[5]:,}"
                    if isinstance(run_info[5], (int, float))
                    else "Unknown"
                )
            except (IndexError, TypeError):
                pass

        architecture = config.get("architecture", "Neural Network")

        return {
            "model_type": model_type,
            "parameter_count": parameter_count,
            "architecture": architecture,
        }

    def _generate_warnings(self, run_data: Dict[str, Any]) -> List[str]:
        """Generate warnings based on training data."""
        warnings = []

        # Check for common issues
        metrics = run_data.get("metrics", [])
        if metrics:
            losses = [row[6] for row in metrics]  # value is column 6

            # Check for exploding gradients
            if len(losses) > 10:
                recent_losses = losses[-10:]
                if max(recent_losses) > min(recent_losses) * 10:
                    warnings.append("Potential exploding gradients detected")

            # Check for training instability
            if len(losses) > 20:
                recent_trend = sum(losses[-10:]) / 10
                earlier_trend = sum(losses[-20:-10]) / 10
                if recent_trend > earlier_trend * 1.5:
                    warnings.append(
                        "Training loss may be increasing - consider reducing learning rate"
                    )

        return warnings

    def _generate_recommendations(self, run_data: Dict[str, Any]) -> List[str]:
        """Generate optimization recommendations."""
        recommendations = []

        metrics = run_data.get("metrics", [])
        if metrics:
            losses = [row[6] for row in metrics]  # value is column 6

            # Check if loss is still decreasing
            if len(losses) > 10:
                recent_avg = sum(losses[-10:]) / 10
                earlier_avg = (
                    sum(losses[-20:-10]) / 10
                    if len(losses) > 20
                    else sum(losses[:10]) / 10
                )

                if recent_avg < earlier_avg * 0.95:
                    recommendations.append(
                        "Training is progressing well - consider continuing"
                    )
                elif recent_avg > earlier_avg * 1.05:
                    recommendations.append(
                        "Consider reducing learning rate or adding regularization"
                    )

        return recommendations

    def _build_html(
        self,
        run_data: Dict[str, Any],
        insights: Dict[str, Any],
        charts: Dict[str, str],
        include_code_snippets: bool,
        custom_title: Optional[str],
    ) -> str:
        """Build HTML content for the report."""

        # Load template
        template_path = Path(__file__).parent / "templates" / f"{self.template}.html"
        if not template_path.exists():
            # Fallback to basic template
            template_path = Path(__file__).parent / "templates" / "basic.html"

        if template_path.exists():
            with open(template_path, "r", encoding="utf-8") as f:
                template_content = f.read()
        else:
            # Create basic template if none exists
            template_content = self._create_basic_template()

        # Generate report content
        report_title = (
            custom_title or f"GradLens Training Report - {run_data['run_id']}"
        )

        # Replace template placeholders
        html_content = template_content.replace("{{TITLE}}", report_title)
        html_content = html_content.replace("{{RUN_ID}}", run_data["run_id"])
        html_content = html_content.replace(
            "{{GENERATION_TIME}}", datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )

        # Add insights
        if insights:
            html_content = html_content.replace(
                "{{INSIGHTS}}", self._format_insights_html(insights)
            )

        # Add charts
        if charts:
            html_content = html_content.replace(
                "{{CHARTS}}", self._format_charts_html(charts)
            )

        return html_content

    def _create_basic_template(self) -> str:
        """Create a basic HTML template."""
        return """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{TITLE}}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
        .header { border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }
        .section { margin-bottom: 30px; }
        .chart { text-align: center; margin: 20px 0; }
        .warning { background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 10px; border-radius: 4px; }
        .recommendation { background-color: #d1ecf1; border: 1px solid #bee5eb; padding: 10px; border-radius: 4px; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{TITLE}}</h1>
        <p>Generated on {{GENERATION_TIME}} | Run ID: {{RUN_ID}}</p>
    </div>
    
    <div class="section">
        <h2>Training Summary</h2>
        <p>This report was generated automatically by GradLens.</p>
    </div>
    
    <div class="section">
        <h2>Charts and Visualizations</h2>
        {{CHARTS}}
    </div>
    
    <div class="section">
        <h2>Insights and Analysis</h2>
        {{INSIGHTS}}
    </div>
</body>
</html>
        """

    def _format_insights_html(self, insights: Dict[str, Any]) -> str:
        """Format insights as HTML."""
        html = ""

        if "training_summary" in insights:
            summary = insights["training_summary"]
            html += "<h3>Training Performance</h3>"
            html += f"<p>Final Loss: {summary.get('final_loss', 'N/A'):.4f}</p>"
            html += f"<p>Minimum Loss: {summary.get('min_loss', 'N/A'):.4f}</p>"
            html += f"<p>Total Epochs: {summary.get('total_epochs', 'N/A')}</p>"

        if "warnings" in insights and insights["warnings"]:
            html += "<h3>Warnings</h3>"
            for warning in insights["warnings"]:
                html += f'<div class="warning">{warning}</div>'

        if "recommendations" in insights and insights["recommendations"]:
            html += "<h3>Recommendations</h3>"
            for rec in insights["recommendations"]:
                html += f'<div class="recommendation">{rec}</div>'

        return html

    def _format_charts_html(self, charts: Dict[str, str]) -> str:
        """Format charts as HTML."""
        html = ""

        for chart_name, chart_data in charts.items():
            html += '<div class="chart">'
            html += f"<h4>{chart_name.replace('_', ' ').title()}</h4>"
            html += f'<img src="data:image/png;base64,{chart_data}" alt="{chart_name}">'
            html += "</div>"

        return html

    def _export_html(self, html_content: str, run_id: str) -> str:
        """Export HTML content to file."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"gradlens_report_{run_id}_{timestamp}.html"
        filepath = self.output_dir / filename

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html_content)

        _logger.info(f"HTML report saved: {filepath}")
        return str(filepath)

    def _export_pdf(self, html_content: str, run_id: str) -> str:
        """Export HTML content to PDF."""
        if not WEASYPRINT_AVAILABLE:
            raise ImportError("WeasyPrint is required for PDF generation")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"gradlens_report_{run_id}_{timestamp}.pdf"
        filepath = self.output_dir / filename

        weasyprint.HTML(string=html_content).write_pdf(str(filepath))

        _logger.info(f"PDF report saved: {filepath}")
        return str(filepath)

    def _generate_comparison_insights(
        self, runs_data: List[Dict[str, Any]], comparison_type: str
    ) -> Dict[str, Any]:
        """Generate insights for run comparison."""
        # Implementation for comparison insights
        return {}

    def _generate_comparison_charts(
        self, runs_data: List[Dict[str, Any]], comparison_type: str
    ) -> Dict[str, str]:
        """Generate charts for run comparison."""
        # Implementation for comparison charts
        return {}

    def _build_comparison_html(
        self,
        runs_data: List[Dict[str, Any]],
        insights: Dict[str, Any],
        charts: Dict[str, str],
        comparison_type: str,
    ) -> str:
        """Build HTML content for comparison report."""
        # Implementation for comparison HTML
        return ""


# Convenience functions for easy usage
def quick_report(run_id: str, output_dir: str = "reports") -> str:
    """Generate a quick report for a training run."""
    exporter = ExportManager(output_dir=output_dir)
    return exporter.quick_report(run_id)


def comprehensive_report(
    run_id: str,
    output_dir: str = "reports",
    include_charts: bool = True,
    include_insights: bool = True,
) -> str:
    """Generate a comprehensive report for a training run."""
    exporter = ExportManager(output_dir=output_dir)
    return exporter.generate_report(
        run_id=run_id,
        format="pdf",
        include_charts=include_charts,
        include_insights=include_insights,
    )

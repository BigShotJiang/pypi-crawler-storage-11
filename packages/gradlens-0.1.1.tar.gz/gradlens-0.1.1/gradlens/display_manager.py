# gradlens/display_manager.py

import sys
import logging
from typing import Optional, Any

from rich.live import Live
from rich.console import Console
from rich.layout import Layout
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .state import TrainingState

# from .display import create_dashboard_layout, update_dashboard_layout
from .database import fetch_data_from_db

# --- 1. Import new config object ---
from .config import DisplayConfig

# --- 2. Setup module-level logger ---
_logger = logging.getLogger(__name__)

# --- Environment Detection (Unchanged) ---
_IPYTHON_AVAILABLE = False
_IPYWIDGETS_AVAILABLE = False
_IS_COLAB = False
_IS_JUPYTER_NOTEBOOK = False
_MATPLOTLIB_AVAILABLE = False

try:
    import matplotlib.pyplot as plt

    _MATPLOTLIB_AVAILABLE = True
except ImportError:
    pass

OutputWidgetType = Any

try:
    from IPython import get_ipython

    _IPYTHON_AVAILABLE = True
    shell = get_ipython().__class__.__name__
    if shell == "ZMQInteractiveShell":
        _IS_JUPYTER_NOTEBOOK = True
    elif "google.colab" in sys.modules:
        _IS_COLAB = True

    if _IS_JUPYTER_NOTEBOOK or _IS_COLAB:
        from IPython.display import display, clear_output

        try:
            from ipywidgets import Output

            OutputWidgetType = Output
            _IPYWIDGETS_AVAILABLE = True
        except ImportError:
            pass
except (NameError, ImportError):
    pass


class DisplayManager:
    """
    Manages all display-related functionalities, adapting to terminal or notebook environments.

    This class handles the complexity of detecting whether the code is running in a
    standard terminal (TUI) or an IPython-based environment (Jupyter, Colab)
    and routes display updates to the correct handler (Rich TUI or ipywidgets).

    Attributes:
        state (TrainingState): The central state object.
        log_file (Optional[str]): Path to the database file, used for plotting.
        is_notebook_env (bool): True if running in Jupyter, Colab, or similar.
        enable_notebook_display (bool): True if notebook env is detected AND
            `ipywidgets` is available AND user has not disabled it.
        dashboard_layout (Optional[Layout]): The Rich layout for the TUI.
        live_context (Optional[Live]): The Rich Live context manager for the TUI.
        notebook_output_widget (Optional[OutputWidgetType]): The ipywidgets `Output`
            widget used for live updates in notebooks.
    """

    # --- 3. Refactored __init__ to accept DisplayConfig ---
    def __init__(
        self,
        state: TrainingState,
        log_file: Optional[str],
        display_config: DisplayConfig,
    ):
        """
        Initializes the DisplayManager and detects the environment.

        Args:
            state (TrainingState): The central state object.
            log_file (Optional[str]): Path to the .db file, needed for history plotting.
            display_config (DisplayConfig): The configuration object containing
                display-related settings (e.g., `disable_notebook_live_display`).
        """
        self.state: TrainingState = state
        self.log_file: Optional[str] = log_file

        # --- Environment Flags ---
        self.is_notebook_env: bool = _IS_JUPYTER_NOTEBOOK or _IS_COLAB

        # --- 4. Use display_config to determine notebook display state ---
        self.enable_notebook_display: bool = (
            self.is_notebook_env
            and _IPYTHON_AVAILABLE
            and _IPYWIDGETS_AVAILABLE
            and not display_config.disable_notebook_live_display
        )

        # --- Display Handlers (initialized to None) ---
        self.dashboard_layout: Optional[Layout] = None
        self.live_context: Optional[Live] = None
        self.notebook_output_widget: Optional[OutputWidgetType] = None

        # --- 5. Replaced print() with _logger ---
        if not self.is_notebook_env:
            _logger.info("Terminal environment detected. Enabling Live TUI.")
            self.dashboard_layout = create_dashboard_layout(self.state)
            self.live_context = Live(
                self.dashboard_layout,
                refresh_per_second=4,
                transient=False,
                vertical_overflow="visible",
            )
        elif self.enable_notebook_display:
            env_name = "Google Colab" if _IS_COLAB else "Jupyter Notebook/Lab"
            _logger.info(
                f"{env_name} environment detected. Enabling live widget display."
            )
            self.notebook_output_widget = Output()
            display(self.notebook_output_widget)
        else:
            _logger.warning(
                "Notebook environment detected, but live display widget is disabled."
            )
            if (
                not _IPYWIDGETS_AVAILABLE
                and not display_config.disable_notebook_live_display
            ):
                _logger.warning("   Reason: `ipywidgets` not found or not working.")
            elif display_config.disable_notebook_live_display:
                _logger.warning(
                    "   Reason: Disabled by user (disable_notebook_live_display=True)."
                )

    def start(self) -> None:
        """Starts the rich Live TUI display. Does nothing in notebook environments."""
        if self.live_context:
            self.live_context.start()

    def stop(self) -> None:
        """Stops the rich Live TUI display. Does nothing in notebook environments."""
        if self.live_context and self.live_context.is_started:
            self.live_context.stop()

    def update(self) -> None:
        """
        Triggers a display update.

        This will either refresh the terminal TUI or update the notebook widget.
        """
        if self.live_context and self.live_context.is_started and self.dashboard_layout:
            # Update TUI
            update_dashboard_layout(self.state, self.dashboard_layout)
        elif self.enable_notebook_display and self.notebook_output_widget:
            # Update Notebook Widget
            self._update_notebook_display()

    def _update_notebook_display(self) -> None:
        """Renders a simplified text summary into the notebook's output widget."""

        if not self.state.nan_alert:
            nan_status_msg = "✅ OK"
        else:
            alert_type = self.state.nan_alert.get("type")
            layer_name = self.state.nan_alert.get("layer_name")
            nan_status_msg = f"🔥 ALERT! Type={alert_type}, Layer={layer_name}"

        summary_lines = [
            f"--- GradLens Update (E: {self.state.current_epoch + 1}/{self.state.total_epochs} | S: {self.state.current_step + 1}/{self.state.steps_per_epoch}) ---",
            f"Loss: {self.state.current_loss:.4f}",
            f"NaN/Inf Status: {nan_status_msg}",
        ]

        if self.state.track_grads and self.state.grad_stats:
            worst_layer_grad = max(
                self.state.grad_stats,
                key=lambda k: self.state.grad_stats.get(k, (0, 0))[0],
                default=None,
            )
            if worst_layer_grad:
                norm_val, _ = self.state.grad_stats[worst_layer_grad]
                summary_lines.append(
                    f"⚡ Max Grad Norm: {norm_val:.2f} (in {worst_layer_grad})"
                )

        if self.state.track_dead_neurons and self.state.dead_neuron_stats:
            worst_layer_dead = max(
                self.state.dead_neuron_stats,
                key=self.state.dead_neuron_stats.get,
                default=None,
            )
            if worst_layer_dead:
                dead_pct = self.state.dead_neuron_stats[worst_layer_dead] * 100
                summary_lines.append(
                    f"🧠 Max Dead Neurons: {dead_pct:.1f}% (in {worst_layer_dead})"
                )

        summary_text = "\n".join(summary_lines)

        # This `print` is intentional: it's writing to the Jupyter widget,
        # not to the console/logfile.
        with self.notebook_output_widget:
            clear_output(wait=True)
            print(summary_text)

    def plot_history(self, layer_name: str, metric_name: str) -> None:
        """
        Plots the history of a specific metric/layer from the log file in a notebook.

        This method is intended for notebook environments and requires `matplotlib`.

        Args:
            layer_name (str): The name of the layer/parameter (e.g., 'layer1.weight').
            metric_name (str): The name of the metric (e.g., 'grad_norm').
        """
        # --- 6. Replaced print() with _logger for warnings/errors ---
        if not self.is_notebook_env:
            _logger.warning("`.plot_history()` is intended for Notebook environments.")
            return
        if not _MATPLOTLIB_AVAILABLE:
            _logger.error(
                "`matplotlib` is required for plotting. Install with `pip install matplotlib`"
            )
            return
        if not self.log_file:
            _logger.error("No log file was specified. Cannot plot history.")
            return

        _logger.info(
            f"Plotting history for metric '{metric_name}' of layer '{layer_name}'..."
        )
        history_data = fetch_data_from_db(self.log_file, layer_name, metric_name)

        if not history_data:
            _logger.warning(
                f"No data found for metric '{metric_name}' and layer '{layer_name}'."
            )
            return

        steps = [row[0] for row in history_data]
        values = [row[1] for row in history_data]

        try:
            plt.figure(figsize=(12, 5))
            plt.plot(
                steps, values, marker=".", linestyle="-", markersize=4, color="cyan"
            )
            plt.title(f"History of '{metric_name}' for '{layer_name}'")
            plt.xlabel("Combined Step (Epoch * 1M + Step)")
            plt.ylabel(metric_name)
            plt.grid(True, linestyle="--", alpha=0.6)
            plt.tight_layout()
            plt.show()
        except Exception as e:
            _logger.error(f"Error generating plot with matplotlib: {e}", exc_info=True)

    def display_summary_report(self) -> None:
        """
        Displays the final post-mortem summary report in a notebook environment.

        This method re-uses the CLI's console reporting function
        (`print_summary_report_to_console`) but forces it to render in a
        Jupyter-friendly format.
        """
        if not self.is_notebook_env:
            _logger.warning("`.display_summary()` is for Notebooks. Use CLI instead.")
            return
        if not self.log_file:
            _logger.error("No log file specified. Cannot display summary.")
            return

        # This print is intentional user-facing output in the notebook cell.
        print("\n--- [bold]GradLens Final Summary Report[/bold] ---")

        try:
            from .cli import print_summary_report_to_console

            notebook_console = Console(force_jupyter=True, force_terminal=False)
            print_summary_report_to_console(self.log_file, console=notebook_console)
        except Exception as e:
            _logger.error(f"Error displaying summary: {e}", exc_info=True)
            # Also print the error to the cell for immediate feedback
            print(f"[red]Error displaying summary: {e}[/red]")


# Helper functions that were previously in display.py
def create_dashboard_layout(state: TrainingState) -> Layout:
    """Create a basic dashboard layout"""
    layout = Layout(name="root")
    layout.split_column(
        Layout(name="header", size=3),
        Layout(name="main"),
        Layout(name="footer", size=3),
    )
    update_dashboard_layout(state, layout)
    return layout


def update_dashboard_layout(state: TrainingState, layout: Layout) -> None:
    """Update the dashboard layout with current state"""
    if layout is None:
        return

    header_panel = Panel(
        Text(f"🔥 GradLens | Run: {state.run_name}", style="bold"),
        border_style="magenta",
    )

    layout["header"].update(header_panel)

    stats_table = Table.grid(expand=True)
    stats_table.add_column(justify="left", ratio=1)
    stats_table.add_column(justify="right", ratio=1)

    stats_table.add_row(
        f"Epoch: {state.current_epoch + 1}/{state.total_epochs}",
        f"Step: {state.current_step + 1}/{state.steps_per_epoch}",
    )
    stats_table.add_row(
        f"Loss: {state.current_loss:.4f}", f"Grad Max: {state.max_grad_norm_seen:.2f}"
    )
    stats_table.add_row(
        f"Dead Neuron Max: {state.max_dead_neuron_seen * 100:.1f}%",
        f"Tracked Metrics: "
        f"{'G' if state.track_grads else '-'} "
        f"{'N' if state.track_dead_neurons else '-'} "
        f"{'A' if state.track_activations else '-'} "
        f"{'P' if state.track_parameters else '-'}",
    )

    layout["main"].update(
        Panel(stats_table, title="Training Progress", border_style="green")
    )

    if state.nan_alert:
        alert = state.nan_alert
        status_text = Text.assemble(
            ("⚠️  ALERT: ", "bold red"),
            f"{alert.get('type', 'unknown')} @ {alert.get('layer_name', 'unknown')} "
            f"(epoch {alert.get('epoch')}, step {alert.get('step')})",
        )
        border = "red"
    else:
        status_text = Text("✅ No catastrophic events detected", style="bold green")
        border = "green"

    layout["footer"].update(Panel(status_text, title="Status", border_style=border))

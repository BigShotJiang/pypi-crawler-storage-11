# gradlens/watcher.py

import torch.nn as nn
import time
import math
import logging
from rich.console import Console
from typing import Optional, List, Tuple, Type
from types import TracebackType

# --- Import refactored config and exception classes ---
from .config import GradLensConfig, DEFAULT_CONFIG
from .exceptions import CatastrophicTrainingError, GradLensError, ConfigurationError

from .state import TrainingState
from .hooks import HookManager
from .database import DatabaseManager
from .display_manager import DisplayManager
from .history import HistoryLogger

# --- 1. Setup module-level logger ---
_logger = logging.getLogger(__name__)


class Watcher:
    """
    The main orchestrator for the GradLens library.

    This class initializes and coordinates the different managers responsible for
    state, hooks, database logging, display, and history logging. It provides a
    simple context manager (`with`) interface for users.

    Attributes:
        config (GradLensConfig): The validated configuration object.
        state (TrainingState): The single source of truth for all training data.
        db_manager (Optional[DatabaseManager]): Manages SQLite database logging.
        hook_manager (HookManager): Manages attaching/detaching PyTorch hooks.
        display_manager (DisplayManager): Manages live display (TUI or Notebook).
        history_logger (Optional[HistoryLogger]): Manages summary CSV logging.
        start_time (float): The timestamp when the watcher context was entered.
    """

    def __init__(
        self,
        model: nn.Module,
        # --- 2. Refactored __init__ to accept a config object ---
        config: GradLensConfig = DEFAULT_CONFIG,
    ) -> None:
        """
        Initializes the GradLens monitoring session.

        Args:
            model (nn.Module): The PyTorch model to monitor.
            config (GradLensConfig, optional): The configuration object containing
                all settings. Defaults to DEFAULT_CONFIG.
        """
        _logger.info("🔥 GradLens Initialized 🔥")

        # --- 3. Validate the provided configuration ---
        try:
            config.validate()
            self.config: GradLensConfig = config
        except ValueError as e:
            _logger.error(f"Invalid GradLens configuration: {e}", exc_info=True)
            raise ConfigurationError(f"Invalid GradLens configuration: {e}") from e

        # --- 4. Instantiate components using the config object ---
        # (This assumes state.py, display_manager.py etc. will also be refactored)
        self.state: TrainingState = TrainingState(
            model=model,
            training_config=self.config.training,
            tracking_config=self.config.tracking,
            display_config=self.config.display,
            logging_config=self.config.logging,
        )

        self.db_manager: Optional[DatabaseManager] = (
            DatabaseManager(self.config.logging.log_file)
            if self.config.logging.log_file
            else None
        )

        self.hook_manager: HookManager = HookManager(self.state, self.db_manager)

        self.display_manager: DisplayManager = DisplayManager(
            self.state,
            self.config.logging.log_file,  # For plot_history
            self.config.display,  # Pass the whole display config
        )

        self.history_logger: Optional[HistoryLogger] = (
            HistoryLogger(self.config.logging.history_log_file)
            if self.config.logging.history_log_file
            else None
        )

        self.start_time: float = 0.0  # Will be set in __enter__

    def set_step(self, epoch: int, step: int, loss: float) -> None:
        """
        Updates the watcher's state for the current training step.
        This is the main method called by the user inside their training loop.

        Args:
            epoch (int): The current epoch index.
            step (int): The current step/batch index.
            loss (float): The loss value for the current step. Can be NaN or Inf.
        """
        self.state.current_epoch = epoch
        self.state.current_step = step

        loss_val = float(loss) if loss is not None else 0.0
        self.state.current_loss = loss_val
        if not (math.isinf(loss_val) or math.isnan(loss_val)):
            self.state.loss_history.append(loss_val)

        # Manually check parameters (hooks are only for grads and activations)
        # This method is now expected to raise CatastrophicTrainingError on failure
        if self.state.track_parameters:
            self.hook_manager.monitor_parameters()

        # Only log and update display at the specified frequency
        is_sampling_step = self.state.current_step % self.state.sample_every_steps == 0

        if is_sampling_step:
            if self.db_manager:
                try:
                    self._log_stats_to_db()
                except GradLensError as e:
                    # Log the error but don't stop the training
                    _logger.error(f"Failed to log stats to DB: {e}", exc_info=True)

            # Update max stats for the final summary CSV
            if self.state.track_grads and self.state.grad_stats:
                try:
                    current_max_grad = max(
                        norm for norm, mx in self.state.grad_stats.values()
                    )
                    self.state.max_grad_norm_seen = max(
                        self.state.max_grad_norm_seen, current_max_grad
                    )
                except (ValueError, TypeError):
                    pass  # No stats yet

            if self.state.track_dead_neurons and self.state.dead_neuron_stats:
                try:
                    current_max_dead = max(self.state.dead_neuron_stats.values())
                    self.state.max_dead_neuron_seen = max(
                        self.state.max_dead_neuron_seen, current_max_dead
                    )
                except (ValueError, TypeError):
                    pass  # No stats yet

            self.display_manager.update()

    def _log_stats_to_db(self) -> None:
        """Internal method to collect and log all current stats to the database."""
        batch_data: List[Tuple[int, int, str, str, float]] = []
        s = self.state
        e, st = s.current_epoch, s.current_step

        if s.current_loss is not None and not (
            math.isinf(s.current_loss) or math.isnan(s.current_loss)
        ):
            batch_data.append((e, st, "loss", "model", s.current_loss))
        if s.track_grads:
            for layer, (norm, mx) in s.grad_stats.items():
                batch_data.extend(
                    [(e, st, "grad_norm", layer, norm), (e, st, "grad_max", layer, mx)]
                )
        if s.track_dead_neurons:
            for layer, pct in s.dead_neuron_stats.items():
                batch_data.append((e, st, "dead_neuron", layer, pct))
        if s.track_parameters:
            for layer, (norm, mx) in s.param_stats.items():
                batch_data.extend(
                    [
                        (e, st, "param_norm", layer, norm),
                        (e, st, "param_max", layer, mx),
                    ]
                )
        if s.track_activations:
            for layer, (norm, mx) in s.act_stats.items():
                batch_data.extend(
                    [(e, st, "act_norm", layer, norm), (e, st, "act_max", layer, mx)]
                )

        if batch_data:
            self.db_manager.log_batch(batch_data)

    def plot_history(self, layer_name: str, metric_name: str) -> None:
        """
        Plots the history of a specific metric for a layer in a notebook.
        Requires matplotlib.

        Args:
            layer_name (str): The name of the layer/parameter (e.g., 'layer1.weight').
            metric_name (str): The name of the metric (e.g., 'grad_norm').
        """
        self.display_manager.plot_history(layer_name, metric_name)

    def display_summary(self) -> None:
        """Displays the post-mortem summary report in a notebook environment."""
        self.display_manager.display_summary_report()

    def __enter__(self) -> "Watcher":
        """Context manager entry point. Attaches hooks and starts the display."""
        _logger.info("Attaching PyTorch hooks...")
        self.start_time = time.time()
        self.hook_manager.attach_hooks()
        self.display_manager.start()
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        """
        Context manager exit point.
        Handles teardown, logging, and exception reporting.
        """
        end_time = time.time()
        _logger.info("Exiting GradLens context. Detaching hooks and finalizing.")

        # --- 5. Refactored status check using custom exceptions ---
        final_status = "Success ✅"
        if exc_type:
            if issubclass(exc_type, CatastrophicTrainingError):
                final_status = "Failed (Catastrophe) 💥"
            elif exc_type is KeyboardInterrupt:
                final_status = "Interrupted by User 🛑"
            elif issubclass(exc_type, GradLensError):
                final_status = f"Failed (GradLensError: {exc_type.__name__}) ❌"
            else:
                final_status = f"Failed ({exc_type.__name__}) ❌"

        # Update final state stats for the summary report
        self.state.epochs_completed = self.state.current_epoch
        self.state.steps_completed_in_last_epoch = self.state.current_step + 1
        if final_status == "Success ✅":
            self.state.epochs_completed = self.state.total_epochs
            self.state.steps_completed_in_last_epoch = self.state.steps_per_epoch

        # --- 6. Robust Teardown Sequence ---
        self.display_manager.stop()
        _logger.info("Detaching PyTorch hooks...")
        self.hook_manager.remove_hooks()

        if self.db_manager:
            try:
                self.db_manager.close()
            except GradLensError as e:
                _logger.error(f"Error closing database connection: {e}", exc_info=True)

        if self.history_logger:
            try:
                self.history_logger.log_summary(
                    self.state, self.start_time, end_time, final_status
                )
            except GradLensError as e:
                _logger.error(f"Error writing history summary: {e}", exc_info=True)

        # --- 7. Final Report Printing (using logging + Console) ---
        # Use a dedicated console for final status output
        console = Console(stderr=True)
        if "Failed (Catastrophe)" in final_status:
            _logger.critical("Training failed due to a catastrophic event (NaN/Inf).")
            console.print(
                "\n[bold red]💥 CRITICAL FAILURE: CATASTROPHE DETECTED! 💥[/bold red]"
            )
            console.print(
                f"[bold red]   Type:[/bold red] {self.state.nan_alert.get('type', 'N/A')}"
            )
            console.print(
                f"[bold red]   Layer:[/bold red] {self.state.nan_alert.get('layer_name', 'N/A')}"
            )
            console.print(
                f"[bold red]   Epoch:[/bold red] {self.state.nan_alert.get('epoch', 'N/A')}"
            )
            console.print(
                f"[bold red]   Step:[/bold red] {self.state.nan_alert.get('step', 'N/A')}"
            )
        elif "Failed" in final_status and exc_type is not KeyboardInterrupt:
            _logger.error(
                f"Training failed with unhandled exception: {exc_value}", exc_info=True
            )
            console.print("\n[yellow]⚠️ Training stopped with an error:[/yellow]")
            if exc_type and exc_value and traceback:
                console.print_exception(show_locals=False)
            else:
                console.print(f"[red]Error: {exc_value}[/red]")
        elif final_status == "Success ✅":
            _logger.info("Training finished successfully.")
            console.print("[bold green]✅ Training Finished Successfully.[/bold green]")
        elif "Interrupted" in final_status:
            _logger.warning("Training interrupted by user.")
            console.print("\n[yellow]⚠️ Training Interrupted by User.[/yellow]")

        # We don't return True, so any unhandled exceptions will be
        # re-raised after cleanup, which is the correct behavior.

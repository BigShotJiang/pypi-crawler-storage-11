# gradlens/database.py

import sqlite3
import time
import logging
import contextlib
from rich.console import Console
from typing import List, Optional, Tuple, Iterator

# --- 1. Import custom exceptions ---
from .exceptions import DatabaseError

# --- 2. Setup module-level logger ---
_logger = logging.getLogger(__name__)

# --- Create module-level consoles for consistent output ---
_console = Console()
_error_console = Console(stderr=True)


class DatabaseManager:
    """
    Manages all interactions with the SQLite database for logging metrics.

    This class handles creating the database and tables, logging metric batches,
    and safely closing the connection.

    Attributes:
        conn (sqlite3.Connection): The connection object to the SQLite database.
        cursor (sqlite3.Cursor): The cursor object for executing SQL commands.
        start_time (float): The timestamp when the manager was initialized.
        log_file (str): The file path for the SQLite database.
    """

    def __init__(self, log_file: str):
        """
        Initializes the DatabaseManager, connects to the log file, and
        applies performance PRAGMAs.

        Args:
            log_file (str): The file path for the SQLite database.
        """
        # This is a direct user-facing message, _console is appropriate.
        _console.print(f"🗃️ [grey]Logging to SQLite database at {log_file}[/grey]")
        _logger.info(f"Initializing DatabaseManager for {log_file}")
        self.log_file = log_file

        try:
            self.conn: sqlite3.Connection = sqlite3.connect(log_file)
            self.cursor: sqlite3.Cursor = self.conn.cursor()

            # Apply performance PRAGMAs
            self.conn.execute("PRAGMA journal_mode=WAL;")
            self.conn.execute("PRAGMA synchronous=NORMAL;")
            _logger.debug("WAL journal mode enabled for faster writes.")

        except sqlite3.Error as e:
            _logger.warning(
                f"Could not set WAL mode for {log_file}. "
                f"DB writes may be slower. Error: {e}",
                exc_info=True,
            )
        except Exception as e:
            _logger.error(
                f"Failed to connect to database at {log_file}: {e}", exc_info=True
            )
            raise DatabaseError(
                f"Failed to connect to database '{log_file}'", "connect", log_file
            ) from e

        self._create_tables()
        self.start_time: float = time.time()

    def _create_tables(self) -> None:
        """Creates the `metrics` table if it doesn't already exist."""
        try:
            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL,
                epoch INTEGER,
                step INTEGER,
                metric_type TEXT,
                layer_name TEXT,
                value REAL
            )
            """)
            self.conn.commit()
        except sqlite3.Error as e:
            _logger.error(f"Failed to create 'metrics' table: {e}", exc_info=True)
            raise DatabaseError(
                "Failed to create tables", "create_table", self.log_file
            ) from e

    def log_metric(
        self, epoch: int, step: int, metric_type: str, layer_name: str, value: float
    ) -> None:
        """
        Logs a single metric to the database.

        Note: `log_batch` is preferred for performance during training.
        """
        timestamp = time.time() - self.start_time
        try:
            self.cursor.execute(
                """
            INSERT INTO metrics (timestamp, epoch, step, metric_type, layer_name, value)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
                (timestamp, epoch, step, metric_type, layer_name, value),
            )
        except sqlite3.Error as e:
            _logger.error(f"Failed to log single metric to SQLite: {e}", exc_info=True)
            # Do not raise here, as failing a single metric log
            # should not crash the entire training run.
        except Exception as e:
            _logger.error(f"Unexpected error logging metric: {e}", exc_info=True)

    def log_batch(self, data_list: List[Tuple[int, int, str, str, float]]) -> None:
        """
        Logs a batch of metrics to the database using `executemany` for efficiency.
        This is the primary method used by the Watcher.
        """
        timestamp = time.time() - self.start_time
        try:
            data_with_timestamp = [(timestamp,) + d for d in data_list]
            self.cursor.executemany(
                """
            INSERT INTO metrics (timestamp, epoch, step, metric_type, layer_name, value)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
                data_with_timestamp,
            )

            self.conn.commit()
            _logger.debug(f"Logged batch of {len(data_list)} metrics.")
        except sqlite3.Error as e:
            _logger.error(f"Failed to batch log to SQLite: {e}", exc_info=True)
            # Do not raise, same as log_metric
        except Exception as e:
            _logger.error(f"Unexpected error in batch log: {e}", exc_info=True)

    def log_catastrophe(
        self, epoch: int, step: int, event_type: str, layer_name: str
    ) -> None:
        """
        Logs a catastrophic event (like NaN/Inf) and *immediately* commits.

        This ensures the event is saved to disk before the program
        is terminated by the `RuntimeError` raised in the hook.
        """
        timestamp = time.time() - self.start_time
        metric_type = f"{event_type.lower()}_alert"
        try:
            self.cursor.execute(
                """
            INSERT INTO metrics (timestamp, epoch, step, metric_type, layer_name, value)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
                (timestamp, epoch, step, metric_type, layer_name, 1.0),
            )  # 1.0 as a boolean 'True'

            # This commit is critical and must remain here.
            self.conn.commit()

            # Log to file AND print to console, as this is a critical event
            _logger.critical(
                f"CRITICAL EVENT LOGGED TO DB: {event_type} in {layer_name}"
            )
            _console.print(
                f"🚨 [bold red]CRITICAL EVENT LOGGED TO DB: "
                f"{event_type} in {layer_name}[/bold red]"
            )
        except Exception as e:
            # Log and print, as this is a failure in the failure handler
            _logger.error(f"Failed to log catastrophe to SQLite: {e}", exc_info=True)
            _error_console.print(f"[red]Failed to log catastrophe to SQLite: {e}[/red]")

    def close(self) -> None:
        """Commits any final changes and safely closes the database connection."""
        _console.print("💾 [grey]Committing database changes...[/grey]")
        _logger.info("Committing final database changes and closing connection...")
        try:
            self.conn.commit()
            self.conn.close()
        except sqlite3.Error as e:
            _logger.error(f"Error committing/closing database: {e}", exc_info=True)
            raise DatabaseError(
                f"Failed to close database '{self.log_file}'", "close", self.log_file
            ) from e


# --- 3. Added get_db_connection (fixes cli.py import error) ---
@contextlib.contextmanager
def get_db_connection(
    db_file: str, readonly: bool = False
) -> Iterator[sqlite3.Connection]:
    """
    Provides a database connection as a context manager.
    Ensures the connection is always closed and raises DatabaseError on failure.

    Args:
        db_file (str): Path to the database file.
        readonly (bool): If True, open in read-only mode.

    Yields:
        sqlite3.Connection: The database connection object.

    Raises:
        DatabaseError: If the connection fails.
    """
    conn = None
    try:
        if readonly:
            uri = f"file:{db_file}?mode=ro"
            _logger.debug(f"Opening read-only DB connection: {uri}")
            conn = sqlite3.connect(uri, uri=True)
        else:
            _logger.debug(f"Opening read-write DB connection: {db_file}")
            conn = sqlite3.connect(db_file)

        yield conn  # Provide the connection to the 'with' block

    except sqlite3.Error as e:
        _logger.error(
            f"Database connection error to {db_file} (readonly={readonly}): {e}",
            exc_info=True,
        )
        raise DatabaseError(
            f"Failed to connect to database '{db_file}'", "connect", db_file
        ) from e
    finally:
        if conn:
            conn.close()
            _logger.debug(f"Closed DB connection to {db_file}")


# --- 4. Refactored fetch_data_from_db ---
def fetch_data_from_db(
    db_file: str, layer_name: str, metric_name: str
) -> Optional[List[Tuple[int, float]]]:
    """
    Fetches the history of a specific metric/layer from a database file.
    Connects in read-only mode and filters out non-finite values (NaN, Inf).

    Returns None on failure, as expected by cli.py and display_manager.py.
    """
    try:
        # Use the new, robust context manager
        with get_db_connection(db_file, readonly=True) as conn:
            cursor = conn.cursor()

            query = """
                SELECT epoch * 1000000 + step as combined_step, value
                FROM metrics
                WHERE layer_name = ? AND metric_type = ? 
                  AND value IS NOT NULL 
                  AND NOT (value != value)  -- This filters out NaN
                  AND value != 'Infinity'   -- This filters out +Inf
                  AND value != '-Infinity'  -- This filters out -Inf
                ORDER BY combined_step ASC
            """

            cursor.execute(query, (layer_name, metric_name))
            data: List[Tuple[int, float]] = cursor.fetchall()
            _logger.debug(f"Fetched {len(data)} records for {layer_name}/{metric_name}")
            return data

    except (sqlite3.Error, DatabaseError) as e:
        # Log the error and print to console (as this is user-initiated)
        _error_console.print(
            f"[bold red]❌ DB Fetch Error:[/bold red] Query failed for "
            f"layer '{layer_name}', metric '{metric_name}'. Error: {e}"
        )
        _logger.error(
            f"DB Fetch Error for {layer_name}/{metric_name}: {e}", exc_info=True
        )
        return None  # Return None as expected by downstream functions
    except Exception as e:
        _error_console.print(
            f"[bold red]❌ Unexpected error fetching data:[/bold red] {e}"
        )
        _logger.error(f"Unexpected error fetching data: {e}", exc_info=True)
        return None

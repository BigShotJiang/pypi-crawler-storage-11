# gradlens/hooks.py

import torch
import torch.nn as nn
import logging
from typing import List, Any, Callable, Optional
from contextlib import suppress

from .state import TrainingState
from .database import DatabaseManager

# --- 1. Import the custom exception ---
from .exceptions import CatastrophicTrainingError, HookAttachmentError

_logger = logging.getLogger(__name__)


class HookManager:
    """
    Manages PyTorch hooks for monitoring model health during training.

    This class attaches forward and backward hooks to model modules and parameters
    to collect statistics. It's decoupled from the main Watcher class through
    the TrainingState object.

    Attributes:
        state: The central state object for storing training data
        db_manager: Optional DatabaseManager for logging catastrophes
        handles: List of registered hook handles for cleanup
        _hooks_attached: Flag to track hook attachment status
    """

    def __init__(
        self, state: TrainingState, db_manager: Optional[DatabaseManager] = None
    ) -> None:
        """
        Initializes the HookManager.

        Args:
            state: The central state object for storing training data
            db_manager: Optional DatabaseManager for logging
        """
        self.state: TrainingState = state
        self.db_manager: Optional[DatabaseManager] = db_manager
        self.handles: List[torch.utils.hooks.RemovableHandle] = []
        self._hooks_attached: bool = False

        _logger.debug("HookManager initialized")

    def attach_hooks(self) -> None:
        """
        Attaches necessary hooks to the model based on state tracking settings.

        - Attaches gradient hooks to all parameters that require gradients
        - Attaches forward hooks to all modules for activation/neuron monitoring

        Raises:
            HookAttachmentError: If attaching hooks fails.
        """
        if self._hooks_attached:
            _logger.warning("Attempted to attach hooks when already attached")
            return

        try:
            # Attach gradient hooks
            if self.state.track_grads:
                self._attach_gradient_hooks()

            # Attach forward hooks
            if self.state.track_dead_neurons or self.state.track_activations:
                self._attach_forward_hooks()

            self._hooks_attached = True
            _logger.info(
                f"Attached {len(self.handles)} hooks "
                f"(grads={self.state.track_grads}, "
                f"activations={self.state.track_activations}, "
                f"neurons={self.state.track_dead_neurons})"
            )

        except Exception as e:
            _logger.error(f"Failed to attach hooks: {e}", exc_info=True)
            self.remove_hooks()  # Clean up partial attachment
            # --- 2. Raise a specific exception ---
            raise HookAttachmentError(f"Failed to attach hooks: {e}") from e

    def _attach_gradient_hooks(self) -> None:
        """Attaches gradient monitoring hooks to all parameters."""
        param_count = 0

        for param_name, param in self.state.model.named_parameters():
            if param.requires_grad:
                try:
                    handle = param.register_post_accumulate_grad_hook(
                        self._create_param_backward_hook(param_name)
                    )
                    self.handles.append(handle)
                    param_count += 1
                except Exception as e:
                    _logger.warning(
                        f"Could not attach gradient hook to {param_name}: {e}"
                    )

        _logger.debug(f"Attached gradient hooks to {param_count} parameters")

    def _attach_forward_hooks(self) -> None:
        """Attaches forward hooks to all modules."""
        module_count = 0

        for name, module in self.state.model.named_modules():
            # Skip the top-level model itself
            if module is self.state.model:
                continue

            try:
                handle = module.register_forward_hook(self._create_forward_hook(name))
                self.handles.append(handle)
                module_count += 1
            except Exception as e:
                _logger.warning(f"Could not attach forward hook to {name}: {e}")

        _logger.debug(f"Attached forward hooks to {module_count} modules")

    def remove_hooks(self) -> None:
        """
        Removes all registered hooks to prevent memory leaks.

        This should be called when monitoring is complete.
        """
        if not self._hooks_attached:
            _logger.debug("remove_hooks called but no hooks were attached.")
            return

        removed_count = 0
        for handle in self.handles:
            with suppress(Exception):
                handle.remove()
                removed_count += 1

        self.handles.clear()
        self._hooks_attached = False

        _logger.debug(f"Removed {removed_count} hooks")

    def monitor_parameters(self) -> None:
        """
        Manually monitors model parameters if tracking is enabled.

        This method is called manually by Watcher.set_step() because there's
        no reliable PyTorch hook that fires after an optimizer step for all
        parameters. It checks for NaN/Inf values and calculates statistics.

        Raises:
            CatastrophicTrainingError: If a NaN or Inf value is detected.
        """
        if not self.state.track_parameters:
            return

        for name, param in self.state.model.named_parameters():
            if param is None or not hasattr(param, "data") or param.data is None:
                continue

            try:
                self._check_and_log_parameter(name, param.data)
            except CatastrophicTrainingError:
                # Re-raise catastrophic errors
                raise
            except Exception as e:
                _logger.warning(
                    f"Error monitoring parameter {name}: {e}", exc_info=True
                )
                self.state.param_stats[name] = (float("nan"), float("nan"))

    def _check_and_log_parameter(self, name: str, param_data: torch.Tensor) -> None:
        """
        Checks a parameter for NaN/Inf and logs statistics.

        Args:
            name: Parameter name
            param_data: Parameter tensor data

        Raises:
            CatastrophicTrainingError: If NaN or Inf is detected
        """
        # Check for NaN/Inf
        if not torch.isfinite(param_data).all():
            self._handle_catastrophe("Parameter", name)
            # --- 3. Raise specific exception instead of RuntimeError ---
            raise CatastrophicTrainingError(
                event_type="Parameter",
                layer_name=name,
                epoch=self.state.current_epoch,
                step=self.state.current_step,
            )

        # Calculate statistics
        try:
            norm = torch.norm(param_data).item()
            max_val = param_data.abs().max().item()
            self.state.param_stats[name] = (norm, max_val)
        except Exception as e:
            _logger.warning(
                f"Could not calculate stats for parameter {name}: {e}", exc_info=True
            )
            self.state.param_stats[name] = (float("nan"), float("nan"))

    def _handle_catastrophe(self, alert_type: str, layer_name: str) -> None:
        """
        Centralized handler for NaN/Inf events.

        Updates the state for display and logs the event to the database
        immediately with a commit to ensure data is saved before a crash.

        Args:
            alert_type: Type of event (e.g., "Gradient", "Activation")
            layer_name: Name of the layer/parameter where event occurred
        """
        # --- 4. Update state.nan_alert (already correct) ---
        # This populates the state object, which state.py now accepts
        # as Dict[str, Any]. This info is used by Watcher.__exit__
        self.state.nan_alert = {
            "type": alert_type,
            "layer_name": layer_name,
            "epoch": self.state.current_epoch,
            "step": self.state.current_step,
        }

        if self.db_manager:
            try:
                self.db_manager.log_catastrophe(
                    self.state.current_epoch,
                    self.state.current_step,
                    alert_type.lower(),
                    layer_name,
                )
            except Exception as e:
                _logger.error(f"Failed to log catastrophe to DB: {e}", exc_info=True)

        _logger.critical(
            f"Catastrophe detected: {alert_type} in {layer_name} "
            f"at epoch {self.state.current_epoch}, step {self.state.current_step}"
        )

    def _create_param_backward_hook(
        self, param_name: str
    ) -> Callable[[torch.Tensor], None]:
        """
        Creates a closure for the gradient accumulation hook.

        This hook fires after gradients have been accumulated for a parameter.

        Args:
            param_name: Name of the parameter this hook will be attached to

        Returns:
            The hook function
        """

        def hook(param: torch.Tensor) -> None:
            # Skip if no gradient
            if param.grad is None:
                return

            grad = param.grad.detach()

            # Check for catastrophic values
            if not torch.isfinite(grad).all():
                self._handle_catastrophe("Gradient", param_name)
                # --- 5. Raise specific exception instead of RuntimeError ---
                raise CatastrophicTrainingError(
                    event_type="Gradient",
                    layer_name=param_name,
                    epoch=self.state.current_epoch,
                    step=self.state.current_step,
                )

            # Calculate and store statistics
            try:
                norm = torch.norm(grad).item()
                max_val = grad.abs().max().item()
                self.state.grad_stats[param_name] = (norm, max_val)
            except Exception as e:
                _logger.warning(
                    f"Could not calculate gradient stats for {param_name}: {e}",
                    exc_info=True,
                )
                self.state.grad_stats[param_name] = (float("nan"), float("nan"))

        return hook

    def _create_forward_hook(
        self, layer_name: str
    ) -> Callable[[nn.Module, Any, Any], None]:
        """
        Creates a closure for the forward hook.

        This hook fires after a module's forward() method has executed.
        It handles activation tracking and dead neuron detection.

        Args:
            layer_name: Name of the module this hook will be attached to

        Returns:
            The hook function
        """

        def hook(module_instance: nn.Module, inputs: Any, outputs: Any) -> None:
            # Extract the primary output tensor
            output_tensor = self._extract_output_tensor(outputs)

            if output_tensor is None:
                _logger.debug(
                    f"Skipping forward hook for {layer_name}: output is not a tensor."
                )
                return  # Cannot analyze non-tensor outputs

            output_detached = output_tensor.detach()

            # Track dead neurons (ReLU only)
            if self.state.track_dead_neurons and isinstance(module_instance, nn.ReLU):
                self._track_dead_neurons(layer_name, output_detached)

            # Track activations
            if self.state.track_activations:
                self._track_activations(layer_name, output_detached)

        return hook

    @staticmethod
    def _extract_output_tensor(outputs: Any) -> Optional[torch.Tensor]:
        """
        Extracts the primary tensor from module outputs.

        Handles various output formats (tensor, tuple, list, dict).

        Args:
            outputs: The output from a module's forward pass

        Returns:
            The primary output tensor or None
        """
        if isinstance(outputs, torch.Tensor):
            return outputs

        if isinstance(outputs, (tuple, list)) and len(outputs) > 0:
            if isinstance(outputs[0], torch.Tensor):
                return outputs[0]

        if isinstance(outputs, dict) and "output" in outputs:
            if isinstance(outputs["output"], torch.Tensor):
                return outputs["output"]

        # Add common alternatives for dictionary keys
        if isinstance(outputs, dict) and "logits" in outputs:
            if isinstance(outputs["logits"], torch.Tensor):
                return outputs["logits"]

        _logger.debug(
            f"Could not extract primary tensor from output type: {type(outputs)}"
        )
        return None

    def _track_dead_neurons(self, layer_name: str, output: torch.Tensor) -> None:
        """
        Tracks the percentage of dead neurons in ReLU activations.

        Args:
            layer_name: Name of the layer
            output: Output tensor from the layer
        """
        try:
            # Calculate percentage of exactly zero outputs
            dead_pct = (output == 0).float().mean().item()
            self.state.dead_neuron_stats[layer_name] = dead_pct
        except Exception as e:
            _logger.warning(
                f"Could not calculate dead neurons for {layer_name}: {e}", exc_info=True
            )
            self.state.dead_neuron_stats[layer_name] = float("nan")

    def _track_activations(self, layer_name: str, output: torch.Tensor) -> None:
        """
        Tracks activation statistics and checks for NaN/Inf.

        Args:
            layer_name: Name of the layer
            output: Output tensor from the layer

        Raises:
            CatastrophicTrainingError: If NaN or Inf is detected
        """
        # Check for catastrophic values
        if not torch.isfinite(output).all():
            self._handle_catastrophe("Activation", layer_name)
            # --- 6. Raise specific exception instead of RuntimeError ---
            raise CatastrophicTrainingError(
                event_type="Activation",
                layer_name=layer_name,
                epoch=self.state.current_epoch,
                step=self.state.current_step,
            )

        # Calculate and store statistics
        try:
            norm = torch.norm(output).item()
            max_val = output.abs().max().item()
            self.state.act_stats[layer_name] = (norm, max_val)
        except Exception as e:
            _logger.warning(
                f"Could not calculate activation stats for {layer_name}: {e}",
                exc_info=True,
            )
            self.state.act_stats[layer_name] = (float("nan"), float("nan"))

    def __del__(self):
        """Ensure hooks are removed on garbage collection."""
        if self._hooks_attached:
            _logger.warning(
                "HookManager garbage collected without remove_hooks() being called. "
                "Cleaning up now to prevent memory leaks."
            )
            self.remove_hooks()

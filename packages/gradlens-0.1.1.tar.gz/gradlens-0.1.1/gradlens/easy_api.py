# gradlens/easy_api.py

"""
🎯 Easy-to-use API for GradLens
This module provides a very simple interface for using GradLens.
"""

import torch.nn as nn
from typing import Optional
from pathlib import Path
import logging
import torch

from .config import (
    GradLensConfig,
    TrainingConfig,
    TrackingConfig,
    DisplayConfig,
    LoggingConfig,
)
from .enhanced_display_manager import EnhancedDisplayManager
from .state import TrainingState
from .export_manager import ExportManager

_logger = logging.getLogger(__name__)


def watch(
    model: nn.Module,
    total_epochs: Optional[int] = None,
    steps_per_epoch: Optional[int] = None,
    log_file: Optional[str] = "gradlens.db",
    run_name: Optional[str] = None,
    track_all: bool = True,
    *,
    config: Optional[GradLensConfig] = None,
    **kwargs,
) -> "SimpleWatcher":
    """
    🚀 The easiest way to use GradLens.

    Example:
    ```python
    import gradlens as gw

    # Just 3 lines of code!
    with gw.watch(model, epochs=10, steps=100) as monitor:
        for epoch in range(10):
            for step, (x, y) in enumerate(dataloader):
                loss = train_step(x, y)
                monitor.log(epoch, step, loss)

    # Shows a final report automatically
    monitor.show_report()
    ```

    Args:
        model: Your PyTorch model
        total_epochs: Total number of epochs (required if config is not provided)
        steps_per_epoch: Number of steps per epoch (required if config is not provided)
        log_file: Optional path to the SQLite log file
        run_name: Optional name for this run
        track_all: If True, track all metrics
        config: Prebuilt GradLensConfig. If provided, other simple args are ignored
        **kwargs: Advanced options

    Returns:
        A SimpleWatcher for easy monitoring
    """

    # If a full config is provided, use it directly
    if config is not None:
        return SimpleWatcher(model, config)

    if total_epochs is None or steps_per_epoch is None:
        raise TypeError(
            "Either provide 'config' or both 'total_epochs' and 'steps_per_epoch'."
        )

    simple_config = _create_simple_config(
        total_epochs=total_epochs,
        steps_per_epoch=steps_per_epoch,
        log_file=log_file,
        run_name=run_name,
        track_all=track_all,
        **kwargs,
    )

    return SimpleWatcher(model, simple_config)


def quick_watch(model: nn.Module, epochs: int = 1, steps: int = 1) -> "SimpleWatcher":
    """
    ⚡ Ultra-fast mode for testing and debugging.

    Example:
    ```python
    with gw.quick_watch(model) as m:
        for i in range(100):
            loss = train_step()
            m.log(0, i, loss)
    ```
    """
    return watch(
        model,
        total_epochs=epochs,
        steps_per_epoch=steps,
        log_file=None,  # no persistence for maximum speed
        track_all=False,  # only essential metrics
        track_grads=True,
        track_dead_neurons=True,
        track_activations=False,
        track_parameters=False,
    )


def _create_simple_config(
    total_epochs: int,
    steps_per_epoch: int,
    log_file: Optional[str],
    run_name: Optional[str],
    track_all: bool,
    **kwargs,
) -> GradLensConfig:
    """Create a GradLensConfig from simple parameters."""

    # Training config
    training = TrainingConfig(
        total_epochs=total_epochs, steps_per_epoch=steps_per_epoch, run_name=run_name
    )

    # Tracking config
    if track_all:
        tracking = TrackingConfig(
            track_grads=True,
            track_dead_neurons=True,
            track_activations=True,
            track_parameters=True,
        )
    else:
        tracking = TrackingConfig(
            track_grads=kwargs.get("track_grads", True),
            track_dead_neurons=kwargs.get("track_dead_neurons", True),
            track_activations=kwargs.get("track_activations", False),
            track_parameters=kwargs.get("track_parameters", False),
        )

    # Display config
    display = DisplayConfig(
        loss_history_length=kwargs.get("history_length", 90),
        plot_height=kwargs.get("plot_height", 8),
        plot_width=kwargs.get("plot_width", 75),
        disable_notebook_live_display=kwargs.get("disable_live", False),
    )

    # Logging config
    logging_config = LoggingConfig(
        log_file=log_file,
        history_log_file=kwargs.get("history_file", None),
        sample_every_steps=kwargs.get("sample_every", 1),
    )

    return GradLensConfig(
        training=training, tracking=tracking, display=display, logging=logging_config
    )


class SimpleWatcher:
    """
    🎨 A lightweight wrapper around the core Watcher that is simple to use.
    """

    def __init__(self, model: nn.Module, config: GradLensConfig):
        self.model = model
        self.config = config

        # Build training state
        self.state = TrainingState(
            model=model,
            training_config=config.training,
            tracking_config=config.tracking,
            display_config=config.display,
            logging_config=config.logging,
        )

        # Use the new EnhancedDisplayManager
        from .database import DatabaseManager
        from .hooks import HookManager
        from .history import HistoryLogger

        self.db_manager = (
            DatabaseManager(config.logging.log_file)
            if config.logging.log_file
            else None
        )

        self.hook_manager = HookManager(self.state, self.db_manager)

        self.display_manager = EnhancedDisplayManager(
            self.state,
            config.logging.log_file,
            config.display,
            auto_config=True,  # enable auto-configuration
        )

        self.history_logger = (
            HistoryLogger(config.logging.history_log_file)
            if config.logging.history_log_file
            else None
        )

        self.start_time = 0.0
        self._entered = False

    def log(self, epoch: int, step: int, loss: float):
        """
        📝 Log a single training step.

        Args:
            epoch: Epoch index
            step: Step index within the epoch
            loss: Loss value for the step
        """
        if not self._entered:
            raise RuntimeError(
                "You must use SimpleWatcher with a context manager:\n"
                "with gw.watch(...) as monitor:\n"
                "    monitor.log(epoch, step, loss)"
            )

        self.state.current_epoch = epoch
        self.state.current_step = step
        self.state.current_loss = float(loss)

        # Add to history
        import math

        if not (math.isinf(loss) or math.isnan(loss)):
            self.state.loss_history.append(float(loss))

        # Monitor parameters
        if self.state.track_parameters:
            self.hook_manager.monitor_parameters()

        # Sample and update
        if step % self.state.sample_every_steps == 0:
            if self.db_manager:
                self._log_to_db()

            self._update_max_stats()
            self.display_manager.update()

    def _log_to_db(self):
        """Log the current batch of metrics to the database."""
        from typing import List, Tuple

        batch_data: List[Tuple[int, int, str, str, float]] = []
        s = self.state
        e, st = s.current_epoch, s.current_step

        import math

        if s.current_loss is not None and not (
            math.isinf(s.current_loss) or math.isnan(s.current_loss)
        ):
            batch_data.append((e, st, "loss", "model", s.current_loss))

        if s.track_grads:
            for layer, (norm, mx) in s.grad_stats.items():
                batch_data.extend(
                    [(e, st, "grad_norm", layer, norm), (e, st, "grad_max", layer, mx)]
                )

        if s.track_dead_neurons:
            for layer, pct in s.dead_neuron_stats.items():
                batch_data.append((e, st, "dead_neuron", layer, pct))

        if s.track_parameters:
            for layer, (norm, mx) in s.param_stats.items():
                batch_data.extend(
                    [
                        (e, st, "param_norm", layer, norm),
                        (e, st, "param_max", layer, mx),
                    ]
                )

        if s.track_activations:
            for layer, (norm, mx) in s.act_stats.items():
                batch_data.extend(
                    [(e, st, "act_norm", layer, norm), (e, st, "act_max", layer, mx)]
                )

        if batch_data:
            self.db_manager.log_batch(batch_data)

    def _update_max_stats(self):
        """Update max statistics observed so far."""
        if self.state.track_grads and self.state.grad_stats:
            try:
                current_max = max(norm for norm, _ in self.state.grad_stats.values())
                self.state.max_grad_norm_seen = max(
                    self.state.max_grad_norm_seen, current_max
                )
            except (ValueError, TypeError):
                pass

        if self.state.track_dead_neurons and self.state.dead_neuron_stats:
            try:
                current_max = max(self.state.dead_neuron_stats.values())
                self.state.max_dead_neuron_seen = max(
                    self.state.max_dead_neuron_seen, current_max
                )
            except (ValueError, TypeError):
                pass

    def plot(self, layer_name: str, metric: str = "grad_norm"):
        """
        📈 Plot the history of a specific layer/metric.

        Example:
        ```python
        monitor.plot('layer1.weight', 'grad_norm')
        monitor.plot('layer2.bias', 'dead_neuron')
        ```

        Args:
            layer_name: Layer name
            metric: Metric name (grad_norm, dead_neuron, param_norm, ...)
        """
        self.display_manager.plot_history(layer_name, metric)

    def show_report(self):
        """
        📊 Display the full summary report.

        Example:
        ```python
        with gw.watch(model, ...) as monitor:
            # training loop
            ...

        monitor.show_report()  # final report
        ```
        """
        self.display_manager.display_summary_report()

    def get_stats(self) -> dict:
        """
        📉 Get current statistics as a dictionary.

        Returns:
            A dictionary containing current monitoring stats
        """
        return {
            "epoch": self.state.current_epoch,
            "step": self.state.current_step,
            "loss": self.state.current_loss,
            "max_grad_norm": self.state.max_grad_norm_seen,
            "max_dead_neurons": self.state.max_dead_neuron_seen * 100,
            "has_nan_alert": bool(self.state.nan_alert),
            "grad_stats": dict(self.state.grad_stats),
            "dead_neuron_stats": dict(self.state.dead_neuron_stats),
        }

    def __enter__(self):
        """Enter the context manager."""
        import time

        self.start_time = time.time()
        self._entered = True

        _logger.info("🔥 Starting GradLens monitoring...")
        self.hook_manager.attach_hooks()
        self.display_manager.start()

        return self

    def __exit__(self, exc_type, exc_value, traceback):
        """Exit the context manager and finalize reporting/cleanup."""
        import time
        from .exceptions import CatastrophicTrainingError
        from rich.console import Console

        end_time = time.time()
        self._entered = False

        # Determine final status
        final_status = "Success ✅"
        if exc_type:
            if issubclass(exc_type, CatastrophicTrainingError):
                final_status = "Failed (Catastrophe) 💥"
            elif exc_type is KeyboardInterrupt:
                final_status = "Interrupted by User 🛑"
            else:
                final_status = f"Failed ({exc_type.__name__}) ❌"

        # Update final statistics
        self.state.epochs_completed = self.state.current_epoch
        self.state.steps_completed_in_last_epoch = self.state.current_step + 1

        if final_status == "Success ✅":
            self.state.epochs_completed = self.state.total_epochs
            self.state.steps_completed_in_last_epoch = self.state.steps_per_epoch

        # Cleanup
        self.display_manager.stop()
        self.hook_manager.remove_hooks()

        if self.db_manager:
            try:
                self.db_manager.close()
            except Exception as e:
                _logger.error(f"Error closing database: {e}")

        if self.history_logger:
            try:
                self.history_logger.log_summary(
                    self.state, self.start_time, end_time, final_status
                )
            except Exception as e:
                _logger.error(f"Error writing history: {e}")

        # Show final report to user
        console = Console()
        if "Catastrophe" in final_status:
            console.print("\n[bold red]💥 CATASTROPHE DETECTED! 💥[/bold red]")
            console.print(f"[red]Type: {self.state.nan_alert.get('type')}[/red]")
            console.print(f"[red]Layer: {self.state.nan_alert.get('layer_name')}[/red]")
        elif final_status == "Success ✅":
            console.print(
                "\n[bold green]✅ Training Completed Successfully![/bold green]"
            )
        elif "Interrupted" in final_status:
            console.print("\n[yellow]⚠️  Training Interrupted[/yellow]")

    # Compatibility helper for tests/examples using set_step naming
    def set_step(self, epoch: int, step: int, loss: float) -> None:
        """Alias for log(epoch, step, loss) to support legacy usage."""
        self.log(epoch, step, loss)


# ==================== Helper Functions ====================


def auto_watch(model: nn.Module):
    """
    🤖 Fully automatic mode – smart defaults based on model size.

    Example:
    ```python
    monitor = gw.auto_watch(model)

    with monitor:
        for epoch in range(epochs):
            for step, batch in enumerate(dataloader):
                loss = train(batch)
                monitor.log(epoch, step, loss)
    ```
    """
    # Detect number of parameters for optimization
    num_params = sum(p.numel() for p in model.parameters())

    # Auto settings based on model size
    if num_params < 1_000_000:  # small model
        sample_every = 1
        track_all = True
    elif num_params < 10_000_000:  # medium model
        sample_every = 5
        track_all = True
    else:  # large model
        sample_every = 10
        track_all = False

        _logger.info(f"🤖 Auto-detected model with {num_params:,} parameters")
        _logger.info(f"⚙️  Using sample_every={sample_every}, track_all={track_all}")

    return watch(
        model,
        total_epochs=1,  # user should set appropriately
        steps_per_epoch=1,
        track_all=track_all,
        sample_every=sample_every,
    )


def watch_notebook(
    model: nn.Module, epochs: int, steps: int, run_name: Optional[str] = None
) -> SimpleWatcher:
    """
    📓 Notebook-optimized configuration for Jupyter/Colab.

    Example:
    ```python
    with gw.watch_notebook(model, epochs=10, steps=100) as m:
        for epoch in range(10):
            for step in range(100):
                loss = train_step()
                m.log(epoch, step, loss)

    m.show_report()
    m.plot('layer1.weight')
    ```
    """
    return watch(
        model,
        total_epochs=epochs,
        steps_per_epoch=steps,
        run_name=run_name,
        track_all=True,
        disable_live=False,  # enable live display in notebook
        sample_every=max(1, steps // 50),  # up to 50 updates per epoch
    )


def compare_runs(log_files: list, metric: str = "loss") -> None:
    """
    📊 Compare multiple runs together.

    Example:
    ```python
    gw.compare_runs([
        'run1.db',
        'run2.db',
        'run3.db'
    ], metric='grad_norm')
    ```

    Args:
        log_files: List of log database file paths
        metric: Metric name to compare
    """
    try:
        import plotly.graph_objects as go
    except ImportError:
        _logger.error("Plotly is not installed: pip install plotly")
        return

    from .database import fetch_data_from_db

    fig = go.Figure()

    for log_file in log_files:
        # Fetch a sample layer for this metric
        import sqlite3

        conn = sqlite3.connect(log_file)
        cursor = conn.cursor()

        cursor.execute(
            "SELECT DISTINCT layer_name FROM metrics WHERE metric_type = ? LIMIT 1",
            (metric,),
        )
        result = cursor.fetchone()

        if result:
            layer_name = result[0]
            data = fetch_data_from_db(log_file, layer_name, metric)

            if data:
                steps = [row[0] for row in data]
                values = [row[1] for row in data]

                fig.add_trace(
                    go.Scatter(
                        x=steps, y=values, mode="lines", name=Path(log_file).stem
                    )
                )

        conn.close()

    fig.update_layout(
        title=f"📊 Comparison: {metric}",
        xaxis_title="Step",
        yaxis_title=metric,
        template="plotly_white",
        height=500,
    )

    fig.show()


# ==================== Decorators ====================


def monitored(epochs: int = 1, steps: int = 1):
    """
    🎨 Decorator for automatic monitoring.

    Example:
    ```python
    @gw.monitored(epochs=10, steps=100)
    def train(model, dataloader):
        for epoch in range(10):
            for step, batch in enumerate(dataloader):
                loss = train_step(batch)
                yield epoch, step, loss

    train(model, dataloader)
    ```
    """

    def decorator(func):
        def wrapper(*args, **kwargs):
            # Extract model from arguments
            model = None
            if args and isinstance(args[0], nn.Module):
                model = args[0]
            elif "model" in kwargs:
                model = kwargs["model"]

            if model is None:
                raise ValueError(
                    "Model not found! First argument must be a model instance."
                )

            with watch(model, epochs, steps) as monitor:
                gen = func(*args, **kwargs)

                for epoch, step, loss in gen:
                    monitor.log(epoch, step, loss)

            monitor.show_report()

        return wrapper

    return decorator


# ==================== Quick Analysis Tools ====================


def analyze_db(db_file: str):
    """
    🔍 Quick analysis of a single database file.

    Example:
    ```python
    gw.analyze_db('training.db')
    ```
    """
    from .cli import print_summary_report_to_console
    from rich.console import Console

    console = Console()
    console.print("\n[bold blue]🔍 Quick Analysis[/bold blue]\n")
    print_summary_report_to_console(db_file, console)


def health_check(model: nn.Module, sample_input: torch.Tensor) -> dict:
    """
    🏥 Validate model health before training.

    Example:
    ```python
    health = gw.health_check(model, torch.randn(1, 3, 224, 224))
    print(health)
    ```

    Returns:
        A dictionary containing model health information
    """
    import torch

    results = {
        "total_params": sum(p.numel() for p in model.parameters()),
        "trainable_params": sum(
            p.numel() for p in model.parameters() if p.requires_grad
        ),
        "has_nan_params": False,
        "has_inf_params": False,
        "can_forward": False,
        "can_backward": False,
        "warnings": [],
    }

    # Check parameters
    for name, param in model.named_parameters():
        if torch.isnan(param).any():
            results["has_nan_params"] = True
            results["warnings"].append(f"NaN in {name}")
        if torch.isinf(param).any():
            results["has_inf_params"] = True
            results["warnings"].append(f"Inf in {name}")

    # Forward pass test
    try:
        model.eval()
        with torch.no_grad():
            output = model(sample_input)
        results["can_forward"] = True
    except Exception as e:
        results["warnings"].append(f"Forward pass failed: {e}")

    # Backward pass test
    try:
        model.train()
        output = model(sample_input)
        loss = output.sum()
        loss.backward()
        results["can_backward"] = True
    except Exception as e:
        results["warnings"].append(f"Backward pass failed: {e}")

    # Display results
    from rich.console import Console
    from rich.table import Table

    console = Console()

    table = Table(title="🏥 Model Health Check")
    table.add_column("Check", style="cyan")
    table.add_column("Status", style="bold")

    table.add_row("Total Parameters", f"{results['total_params']:,}")
    table.add_row("Trainable Parameters", f"{results['trainable_params']:,}")
    table.add_row(
        "NaN Parameters", "❌ Found" if results["has_nan_params"] else "✅ None"
    )
    table.add_row(
        "Inf Parameters", "❌ Found" if results["has_inf_params"] else "✅ None"
    )
    table.add_row("Forward Pass", "✅ OK" if results["can_forward"] else "❌ Failed")
    table.add_row("Backward Pass", "✅ OK" if results["can_backward"] else "❌ Failed")

    console.print(table)

    if results["warnings"]:
        console.print("\n[yellow]⚠️  Warnings:[/yellow]")
        for warning in results["warnings"]:
            console.print(f"  • {warning}")
    else:
        console.print("\n[green]✅ Model is healthy and ready for training![/green]")

    return results


# ==================== Export Functions ====================


def generate_report(
    run_id: str,
    output_dir: str = "reports",
    format: str = "pdf",
    template: str = "professional",
    include_charts: bool = True,
    include_insights: bool = True,
) -> str:
    """
    Generate a comprehensive training report.

    Args:
        run_id: Unique identifier for the training run
        output_dir: Directory to save the report
        format: Output format ("pdf", "html", or "both")
        template: Template style ("professional", "academic", "business", "minimal")
        include_charts: Whether to include charts and visualizations
        include_insights: Whether to include model insights and analysis

    Returns:
        Path to the generated report file(s)

    Example:
        ```python
        import gradlens as gw

        # Train your model with GradLens
        with gw.watch(model, total_epochs=10, steps_per_epoch=100) as monitor:
            # ... training loop ...
            pass

        # Generate a professional PDF report
        report_path = gw.generate_report("my_run_123", format="pdf")
        print(f"Report saved to: {report_path}")
        ```
    """
    exporter = ExportManager(output_dir=output_dir, template=template)
    return exporter.generate_report(
        run_id=run_id,
        format=format,
        include_charts=include_charts,
        include_insights=include_insights,
    )


def quick_report(run_id: str, output_dir: str = "reports") -> str:
    """
    Generate a quick, minimal report.

    Args:
        run_id: Unique identifier for the training run
        output_dir: Directory to save the report

    Returns:
        Path to the generated PDF report

    Example:
        ```python
        import gradlens as gw

        # Generate a quick report
        report_path = gw.quick_report("my_run_123")
        print(f"Quick report saved to: {report_path}")
        ```
    """
    exporter = ExportManager(output_dir=output_dir)
    return exporter.quick_report(run_id)


def comprehensive_report(
    run_id: str,
    output_dir: str = "reports",
    include_charts: bool = True,
    include_insights: bool = True,
) -> str:
    """
    Generate a comprehensive report with all features.

    Args:
        run_id: Unique identifier for the training run
        output_dir: Directory to save the report
        include_charts: Whether to include charts and visualizations
        include_insights: Whether to include model insights and analysis

    Returns:
        Path to the generated PDF report

    Example:
        ```python
        import gradlens as gw

        # Generate a comprehensive report
        report_path = gw.comprehensive_report("my_run_123")
        print(f"Comprehensive report saved to: {report_path}")
        ```
    """
    exporter = ExportManager(output_dir=output_dir, template="professional")
    return exporter.generate_report(
        run_id=run_id,
        format="pdf",
        include_charts=include_charts,
        include_insights=include_insights,
        include_code_snippets=True,
    )

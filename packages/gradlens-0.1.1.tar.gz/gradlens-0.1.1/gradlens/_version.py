"""Project version information."""

__all__ = ["__version__", "version"]

__version__ = version = "0.1.2.dev0"

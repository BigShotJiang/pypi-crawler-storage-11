"""
Test suite for Analytics Engine

This module contains comprehensive tests for the analytics engine
to ensure correctness and reliability.
"""

import pytest
import torch
import torch.nn as nn
import os

# Import the modules to test
from gradlens.analytics.analytics_engine import (
    AnalyticsEngine,
    ModelStatistics,
    LayerStatistics,
    ArchitectureType,
    AnalysisLevel,
    LinearLayerAnalyzer,
    ConvLayerAnalyzer,
    RNNLayerAnalyzer,
    create_analytics_engine,
    quick_analysis,
)


class TestLayerStatistics:
    """Test cases for LayerStatistics dataclass"""

    def test_layer_statistics_creation(self):
        """Test basic creation of LayerStatistics"""
        stats = LayerStatistics(
            name="test_layer", layer_type="Linear", num_parameters=1000
        )

        assert stats.name == "test_layer"
        assert stats.layer_type == "Linear"
        assert stats.num_parameters == 1000
        assert stats.grad_mean == 0.0
        assert stats.weight_mean == 0.0

    def test_layer_statistics_to_dict(self):
        """Test conversion to dictionary"""
        stats = LayerStatistics(
            name="test_layer",
            layer_type="Linear",
            num_parameters=1000,
            grad_mean=0.5,
            weight_mean=0.2,
        )

        data = stats.to_dict()

        assert data["name"] == "test_layer"
        assert data["layer_type"] == "Linear"
        assert data["num_parameters"] == 1000
        assert data["gradients"]["mean"] == 0.5
        assert data["weights"]["mean"] == 0.2


class TestModelStatistics:
    """Test cases for ModelStatistics dataclass"""

    def test_model_statistics_creation(self):
        """Test basic creation of ModelStatistics"""
        stats = ModelStatistics(
            architecture_type=ArchitectureType.CNN,
            total_parameters=10000,
            trainable_parameters=8000,
            non_trainable_parameters=2000,
        )

        assert stats.architecture_type == ArchitectureType.CNN
        assert stats.total_parameters == 10000
        assert stats.trainable_parameters == 8000
        assert stats.non_trainable_parameters == 2000
        assert len(stats.layer_stats) == 0

    def test_model_statistics_to_dict(self):
        """Test conversion to dictionary"""
        stats = ModelStatistics(
            architecture_type=ArchitectureType.CNN,
            total_parameters=10000,
            trainable_parameters=8000,
            non_trainable_parameters=2000,
        )

        data = stats.to_dict()

        assert data["architecture"] == "cnn"
        assert data["parameters"]["total"] == 10000
        assert data["parameters"]["trainable"] == 8000
        assert data["parameters"]["non_trainable"] == 2000


class TestLinearLayerAnalyzer:
    """Test cases for LinearLayerAnalyzer"""

    def test_supports_linear_layer(self):
        """Test that analyzer supports Linear layers"""
        analyzer = LinearLayerAnalyzer()
        linear_layer = nn.Linear(10, 5)

        assert analyzer.supports(linear_layer) == True

    def test_supports_non_linear_layer(self):
        """Test that analyzer doesn't support non-Linear layers"""
        analyzer = LinearLayerAnalyzer()
        conv_layer = nn.Conv2d(3, 16, 3)

        assert analyzer.supports(conv_layer) == False

    def test_analyze_linear_layer(self):
        """Test analysis of Linear layer"""
        analyzer = LinearLayerAnalyzer()
        linear_layer = nn.Linear(10, 5)

        # Add some dummy gradients
        linear_layer.weight.grad = torch.randn(5, 10)
        linear_layer.bias.grad = torch.randn(5)

        stats = analyzer.analyze(linear_layer, "test_linear")

        assert stats.name == "test_linear"
        assert stats.layer_type == "Linear"
        assert (
            stats.num_parameters
            == linear_layer.weight.numel() + linear_layer.bias.numel()
        )
        assert stats.grad_norm > 0
        assert stats.weight_norm > 0

    def test_analyze_linear_layer_no_gradients(self):
        """Test analysis of Linear layer without gradients"""
        analyzer = LinearLayerAnalyzer()
        linear_layer = nn.Linear(10, 5)

        stats = analyzer.analyze(linear_layer, "test_linear")

        assert stats.name == "test_linear"
        assert stats.layer_type == "Linear"
        assert stats.grad_norm == 0.0
        assert stats.weight_norm > 0


class TestConvLayerAnalyzer:
    """Test cases for ConvLayerAnalyzer"""

    def test_supports_conv_layers(self):
        """Test that analyzer supports Conv layers"""
        analyzer = ConvLayerAnalyzer()

        conv1d = nn.Conv1d(3, 16, 3)
        conv2d = nn.Conv2d(3, 16, 3)
        conv3d = nn.Conv3d(3, 16, 3)

        assert analyzer.supports(conv1d) == True
        assert analyzer.supports(conv2d) == True
        assert analyzer.supports(conv3d) == True

    def test_analyze_conv2d_layer(self):
        """Test analysis of Conv2d layer"""
        analyzer = ConvLayerAnalyzer()
        conv_layer = nn.Conv2d(3, 16, 3)

        # Add some dummy gradients
        conv_layer.weight.grad = torch.randn(16, 3, 3, 3)

        stats = analyzer.analyze(conv_layer, "test_conv")

        assert stats.name == "test_conv"
        assert stats.layer_type == "Conv2d"
        assert (
            stats.num_parameters == conv_layer.weight.numel() + conv_layer.bias.numel()
        )
        assert stats.grad_norm > 0
        assert stats.weight_norm > 0


class TestRNNLayerAnalyzer:
    """Test cases for RNNLayerAnalyzer"""

    def test_supports_rnn_layers(self):
        """Test that analyzer supports RNN layers"""
        analyzer = RNNLayerAnalyzer()

        rnn = nn.RNN(10, 20)
        lstm = nn.LSTM(10, 20)
        gru = nn.GRU(10, 20)

        assert analyzer.supports(rnn) == True
        assert analyzer.supports(lstm) == True
        assert analyzer.supports(gru) == True

    def test_analyze_lstm_layer(self):
        """Test analysis of LSTM layer"""
        analyzer = RNNLayerAnalyzer()
        lstm_layer = nn.LSTM(10, 20)

        # Add some dummy gradients
        for param in lstm_layer.parameters():
            param.grad = torch.randn_like(param)

        stats = analyzer.analyze(lstm_layer, "test_lstm")

        assert stats.name == "test_lstm"
        assert stats.layer_type == "LSTM"
        assert stats.num_parameters > 0
        assert stats.grad_norm > 0
        assert stats.weight_norm > 0


class TestAnalyticsEngine:
    """Test cases for AnalyticsEngine"""

    def test_analytics_engine_creation(self):
        """Test basic creation of AnalyticsEngine"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        engine = AnalyticsEngine(model)

        assert engine.model == model
        assert engine.analysis_level == AnalysisLevel.STANDARD
        assert len(engine.analyzers) == 5
        assert engine.architecture_type == ArchitectureType.CUSTOM

    def test_detect_architecture_cnn(self):
        """Test architecture detection for CNN"""
        model = nn.Sequential(
            nn.Conv2d(3, 16, 3),
            nn.ReLU(),
            nn.Conv2d(16, 32, 3),
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(32, 10),
        )

        engine = AnalyticsEngine(model)
        assert engine.architecture_type == ArchitectureType.CNN

    def test_detect_architecture_lstm(self):
        """Test architecture detection for LSTM"""
        model = nn.Sequential(nn.LSTM(10, 20), nn.Linear(20, 1))

        engine = AnalyticsEngine(model)
        assert engine.architecture_type == ArchitectureType.LSTM

    def test_analyze_model(self):
        """Test model analysis"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        engine = AnalyticsEngine(model)
        stats = engine.analyze_model()

        assert isinstance(stats, ModelStatistics)
        assert stats.architecture_type == ArchitectureType.CUSTOM
        assert stats.total_parameters > 0
        assert len(stats.layer_stats) > 0

        # Check that we have statistics for Linear layers
        linear_layers = [
            s for s in stats.layer_stats.values() if s.layer_type == "Linear"
        ]
        assert len(linear_layers) == 2

    def test_analyze_training_dynamics(self):
        """Test training dynamics analysis"""
        model = nn.Linear(10, 1)
        engine = AnalyticsEngine(model)

        loss_history = [1.0, 0.8, 0.6, 0.4, 0.2]
        learning_rates = [0.001, 0.001, 0.0005, 0.0005, 0.0001]
        validation_loss = [1.1, 0.9, 0.7, 0.5, 0.3]

        dynamics = engine.analyze_training_dynamics(
            loss_history, learning_rates, validation_loss
        )

        assert "convergence" in dynamics
        assert "learning_rate_impact" in dynamics
        assert "overfitting" in dynamics
        assert "training_stability" in dynamics
        assert "recommendations" in dynamics

        # Check convergence analysis
        assert dynamics["convergence"]["status"] in [
            "converging",
            "slow_convergence",
            "plateaued",
        ]

        # Check overfitting analysis
        assert dynamics["overfitting"]["status"] in [
            "overfitting",
            "mild_overfitting",
            "healthy",
        ]

    def test_detect_bottlenecks(self):
        """Test bottleneck detection"""
        model = nn.Sequential(
            nn.Linear(10, 1000),  # Large layer
            nn.ReLU(),
            nn.Linear(1000, 1),
        )

        engine = AnalyticsEngine(model)
        stats = engine.analyze_model()

        # Simulate some issues
        for layer_stats in stats.layer_stats.values():
            if layer_stats.layer_type == "Linear":
                layer_stats.grad_norm = 150.0  # Exploding gradients
                layer_stats.dead_neuron_ratio = 0.9  # High dead neuron ratio

        bottlenecks = engine.detect_bottlenecks(stats)

        assert len(bottlenecks) > 0
        assert any(b["type"] == "exploding_gradients" for b in bottlenecks)
        assert any(b["type"] == "dead_neurons" for b in bottlenecks)

    def test_get_layer_importance(self):
        """Test layer importance calculation"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        engine = AnalyticsEngine(model)
        stats = engine.analyze_model()

        importance = engine.get_layer_importance(stats)

        assert len(importance) > 0
        assert all(0 <= score <= 1 for score in importance.values())

    def test_export_analysis(self):
        """Test analysis export"""
        model = nn.Linear(10, 1)
        engine = AnalyticsEngine(model)
        stats = engine.analyze_model()

        # Test JSON export
        json_data = engine.export_analysis(stats, format="json")
        assert isinstance(json_data, str)
        assert "architecture" in json_data

        # Test YAML export
        yaml_data = engine.export_analysis(stats, format="yaml")
        assert isinstance(yaml_data, str)

        # Test CSV export
        csv_data = engine.export_analysis(stats, format="csv")
        assert isinstance(csv_data, str)
        assert "Layer,Type,Parameters" in csv_data


class TestUtilityFunctions:
    """Test cases for utility functions"""

    def test_create_analytics_engine(self):
        """Test factory function"""
        model = nn.Linear(10, 1)
        engine = create_analytics_engine(model)

        assert isinstance(engine, AnalyticsEngine)
        assert engine.model == model

    def test_quick_analysis(self):
        """Test quick analysis function"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        result = quick_analysis(model)

        assert isinstance(result, dict)
        assert "architecture" in result
        assert "total_parameters" in result
        assert "num_layers" in result
        assert "health_issues" in result


class TestEdgeCases:
    """Test edge cases and error conditions"""

    def test_empty_model(self):
        """Test with empty model"""
        model = nn.Module()
        engine = AnalyticsEngine(model)
        stats = engine.analyze_model()

        assert stats.total_parameters == 0
        assert len(stats.layer_stats) == 0

    def test_model_with_no_parameters(self):
        """Test with model that has no parameters"""

        class NoParamModel(nn.Module):
            def forward(self, x):
                return x

        model = NoParamModel()
        engine = AnalyticsEngine(model)
        stats = engine.analyze_model()

        assert stats.total_parameters == 0
        assert len(stats.layer_stats) == 0

    def test_model_with_nan_values(self):
        """Test with model containing NaN values"""
        model = nn.Linear(10, 1)

        # Add NaN values to weights
        with torch.no_grad():
            model.weight[0, 0] = float("nan")

        engine = AnalyticsEngine(model)
        stats = engine.analyze_model()

        # Check that NaN detection works
        for layer_stats in stats.layer_stats.values():
            if layer_stats.layer_type == "Linear":
                assert layer_stats.has_nan == True

    def test_model_with_inf_values(self):
        """Test with model containing Inf values"""
        model = nn.Linear(10, 1)

        # Add Inf values to weights
        with torch.no_grad():
            model.weight[0, 0] = float("inf")

        engine = AnalyticsEngine(model)
        stats = engine.analyze_model()

        # Check that Inf detection works
        for layer_stats in stats.layer_stats.values():
            if layer_stats.layer_type == "Linear":
                assert layer_stats.has_inf == True


class TestPerformance:
    """Test performance-related functionality"""

    def test_large_model_analysis(self):
        """Test analysis of large model"""
        # Create a moderately large model
        model = nn.Sequential(
            nn.Linear(1000, 500),
            nn.ReLU(),
            nn.Linear(500, 100),
            nn.ReLU(),
            nn.Linear(100, 10),
        )

        engine = AnalyticsEngine(model)

        # This should complete without errors
        stats = engine.analyze_model()

        assert stats.total_parameters > 0
        assert len(stats.layer_stats) > 0

    def test_memory_usage(self):
        """Test that analysis doesn't consume excessive memory"""
        import psutil

        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss

        # Create and analyze a model
        model = nn.Sequential(nn.Linear(1000, 500), nn.ReLU(), nn.Linear(500, 100))

        engine = AnalyticsEngine(model)
        stats = engine.analyze_model()

        final_memory = process.memory_info().rss
        memory_increase = final_memory - initial_memory

        # Memory increase should be reasonable (less than 100MB)
        assert memory_increase < 100 * 1024 * 1024


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])

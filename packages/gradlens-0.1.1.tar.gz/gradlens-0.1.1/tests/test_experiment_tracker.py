#!/usr/bin/env python3
"""
Test suite for Experiment Tracker

This module contains comprehensive tests for the experiment tracker
to ensure correctness and reliability.
"""

import json
import os
from pathlib import Path
from typing import Tuple

import numpy as np
import pytest
import torch.nn as nn

from gradlens.analytics.experiment_tracker import (
    ExperimentTracker,
    ExperimentConfig,
    RunMetadata,
    HyperparameterConfig,
    create_experiment_tracker,
    quick_experiment_start,
)


def _make_tracker(tmp_path: Path) -> Tuple[ExperimentTracker, Path]:
    db_path = tmp_path / "experiments.db"
    config = ExperimentConfig(database_path=str(db_path))
    return ExperimentTracker(config), db_path


class TestHyperparameterConfig:
    """Test cases for HyperparameterConfig dataclass"""

    def test_hyperparameter_config_creation(self):
        config = HyperparameterConfig(learning_rate=0.001, batch_size=32, epochs=100)

        assert config.learning_rate == 0.001
        assert config.batch_size == 32
        assert config.epochs == 100
        assert config.optimizer == "adam"
        assert config.loss_function == "cross_entropy"

    def test_hyperparameter_config_to_dict(self):
        config = HyperparameterConfig(learning_rate=0.001, batch_size=32, epochs=100)

        data = config.to_dict()

        assert data["learning_rate"] == 0.001
        assert data["batch_size"] == 32
        assert data["epochs"] == 100
        assert data["optimizer"] == "adam"

    def test_hyperparameter_config_to_hash(self):
        config1 = HyperparameterConfig(learning_rate=0.001, batch_size=32)
        config2 = HyperparameterConfig(learning_rate=0.001, batch_size=32)
        config3 = HyperparameterConfig(learning_rate=0.01, batch_size=32)

        assert config1.to_hash() == config2.to_hash()
        assert config1.to_hash() != config3.to_hash()


class TestRunMetadata:
    """Test cases for RunMetadata dataclass"""

    def test_run_metadata_creation(self):
        metadata = RunMetadata(
            experiment_name="test_experiment", description="Test experiment"
        )

        assert metadata.experiment_name == "test_experiment"
        assert metadata.description == "Test experiment"
        assert metadata.status == "running"
        assert metadata.run_id is not None
        assert len(metadata.run_id) > 0

    def test_run_metadata_to_dict(self):
        metadata = RunMetadata(
            experiment_name="test_experiment", description="Test experiment"
        )

        data = metadata.to_dict()

        assert data["experiment_name"] == "test_experiment"
        assert data["description"] == "Test experiment"
        assert data["status"] == "running"
        assert "run_id" in data
        assert "created_at" in data
        assert "updated_at" in data


class TestExperimentConfig:
    """Test cases for ExperimentConfig dataclass"""

    def test_experiment_config_creation(self):
        config = ExperimentConfig(
            database_path="test.db", model_save_path="models/", log_save_path="logs/"
        )

        assert config.database_path == "test.db"
        assert config.model_save_path == "models/"
        assert config.log_save_path == "logs/"
        assert config.auto_save is True
        assert config.max_runs_per_experiment == 1000


class TestExperimentTracker:
    """Test cases for ExperimentTracker"""

    def test_experiment_tracker_creation(self, tmp_path: Path):
        tracker, db_path = _make_tracker(tmp_path)
        assert tracker.config.database_path == str(db_path)
        assert db_path.exists()

    def test_start_experiment(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)
        run_id = tracker.start_experiment(
            experiment_name="test_experiment", description="Test experiment"
        )

        assert run_id
        assert tracker._current_run is not None
        assert tracker._current_run.run_id == run_id

    def test_start_experiment_with_hyperparameters(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)
        hyperparams = HyperparameterConfig(
            learning_rate=0.001, batch_size=32, epochs=100
        )

        run_id = tracker.start_experiment(
            experiment_name="test_experiment",
            description="Test experiment",
            hyperparameters=hyperparams,
        )

        assert run_id
        assert tracker._current_run.hyperparameters.learning_rate == 0.001
        assert tracker._current_run.hyperparameters.batch_size == 32

    def test_start_experiment_with_model(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        run_id = tracker.start_experiment(
            experiment_name="test_experiment",
            description="Test experiment",
            model=model,
        )

        assert run_id
        assert tracker._current_run.total_parameters > 0
        assert tracker._current_run.model_hash

    def test_log_metrics(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)
        run_id = tracker.start_experiment("test_experiment")

        tracker.log_metrics(epoch=0, step=0, metrics={"loss": 1.0, "accuracy": 0.8})
        metrics = tracker.get_run_metrics(run_id)

        assert len(metrics) == 2
        assert any(m["metric_name"] == "loss" for m in metrics)
        assert any(m["metric_name"] == "accuracy" for m in metrics)

    def test_complete_experiment(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)
        run_id = tracker.start_experiment("test_experiment")
        tracker.complete_experiment(
            run_id=run_id, status="completed", model_path="models/test.pth"
        )

        runs = tracker.get_experiment_runs("test_experiment")
        assert len(runs) == 1
        assert runs[0].status == "completed"
        assert runs[0].model_path == "models/test.pth"

    def test_get_experiment_runs(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)

        run1 = tracker.start_experiment("experiment1")
        tracker.complete_experiment(run1, status="completed")
        run2 = tracker.start_experiment("experiment2")
        tracker.complete_experiment(run2, status="failed")

        all_runs = tracker.get_experiment_runs()
        assert len(all_runs) == 2

        exp1_runs = tracker.get_experiment_runs("experiment1")
        assert len(exp1_runs) == 1
        assert exp1_runs[0].experiment_name == "experiment1"

        completed_runs = tracker.get_experiment_runs(status="completed")
        assert len(completed_runs) == 1
        assert completed_runs[0].status == "completed"

    def test_compare_runs(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)

        run1 = tracker.start_experiment(
            "test_experiment",
            hyperparameters=HyperparameterConfig(learning_rate=0.001),
        )
        tracker.complete_experiment(run1, status="completed")

        run2 = tracker.start_experiment(
            "test_experiment",
            hyperparameters=HyperparameterConfig(learning_rate=0.01),
        )
        tracker.complete_experiment(run2, status="completed")

        comparison = tracker.compare_runs(run1, run2, "hyperparameters")

        assert "run1" in comparison
        assert "run2" in comparison
        assert "comparison_type" in comparison
        assert "results" in comparison

    def test_get_best_run(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)
        run1 = tracker.start_experiment("test_experiment")
        tracker.complete_experiment(run1, status="completed")
        run2 = tracker.start_experiment("test_experiment")
        tracker.complete_experiment(run2, status="completed")

        best_run = tracker.get_best_run("test_experiment")
        assert best_run is not None
        assert best_run.experiment_name == "test_experiment"

    def test_export_experiment_data(self, tmp_path: Path, monkeypatch):
        tracker, _ = _make_tracker(tmp_path)
        monkeypatch.chdir(tmp_path)

        run_id = tracker.start_experiment("test_experiment")
        tracker.complete_experiment(run_id, status="completed")

        export_path = tracker.export_experiment_data("test_experiment", format="json")

        assert os.path.exists(export_path)
        assert export_path.endswith(".json")

        with open(export_path, "r") as f:
            data = json.load(f)

        assert data["experiment_name"] == "test_experiment"
        assert data["total_runs"] == 1
        assert len(data["runs"]) == 1

        os.unlink(export_path)


class TestUtilityFunctions:
    """Test cases for utility functions"""

    def test_create_experiment_tracker(self, tmp_path: Path):
        db_path = tmp_path / "factory.db"
        config = ExperimentConfig(database_path=str(db_path))
        tracker = create_experiment_tracker(config)

        assert isinstance(tracker, ExperimentTracker)
        assert tracker.config.database_path == str(db_path)

    def test_quick_experiment_start(self, tmp_path: Path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        tracker, run_id = quick_experiment_start("test_experiment")

        assert isinstance(tracker, ExperimentTracker)
        assert run_id
        tracker.complete_experiment(run_id, status="completed")


class TestEdgeCases:
    """Test edge cases and error conditions"""

    def test_log_metrics_without_current_run(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)
        with pytest.raises(ValueError):
            tracker.log_metrics(0, 0, {"loss": 1.0})

    def test_complete_experiment_without_current_run(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)
        with pytest.raises(ValueError):
            tracker.complete_experiment()

    def test_compare_nonexistent_runs(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)

        with pytest.raises(ValueError):
            tracker.compare_runs("run1", "run2", "hyperparameters")

    def test_export_nonexistent_experiment(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)

        with pytest.raises(ValueError):
            tracker.export_experiment_data("missing_experiment")


class TestPerformance:
    """Performance-related tests"""

    def test_large_number_of_metrics(self, tmp_path: Path):
        tracker, _ = _make_tracker(tmp_path)
        run_id = tracker.start_experiment("test_experiment")

        for epoch in range(100):
            for step in range(10):
                tracker.log_metrics(
                    epoch=epoch,
                    step=step,
                    metrics={
                        "loss": np.random.random(),
                        "accuracy": np.random.random(),
                        "learning_rate": 0.001,
                    },
                )

        metrics = tracker.get_run_metrics(run_id)
        assert len(metrics) == 3000

    def test_memory_usage(self, tmp_path: Path):
        import psutil

        tracker, _ = _make_tracker(tmp_path)
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss

        for i in range(50):
            run_id = tracker.start_experiment(f"experiment_{i}")
            tracker.complete_experiment(run_id, status="completed")

        final_memory = process.memory_info().rss
        memory_increase = final_memory - initial_memory

        assert memory_increase < 100 * 1024 * 1024


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

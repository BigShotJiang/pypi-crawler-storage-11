# tests/test_watcher_nan.py

import pytest
import torch
import torch.nn as nn
import sqlite3

from gradlens import watch  # This is the public API

# --- 1. Import new config and exception classes ---
from gradlens.config import GradLensConfig, LoggingConfig, TrackingConfig
from gradlens.exceptions import CatastrophicTrainingError  # <-- The new exception

# --- Test Model Setup (Unchanged) ---


class SimpleModel(nn.Module):
    """A simple model for testing purposes."""

    def __init__(self):
        super().__init__()
        self.layer1 = nn.Linear(10, 5)
        self.relu = nn.ReLU()
        self.layer2 = nn.Linear(5, 1)

    def forward(self, x):
        return self.layer2(self.relu(self.layer1(x)))


# --- Helper Function (Unchanged) ---
# This helper is perfectly fine for testing.


def _check_db_for_alert(db_file: str, alert_type: str = "gradient_alert") -> bool:
    """
    Connects to the DB file and checks if a catastrophe alert was logged.
    """
    conn = None
    try:
        conn = sqlite3.connect(f"file:{db_file}?mode=ro", uri=True)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT COUNT(*) FROM metrics WHERE metric_type = ?", (alert_type,)
        )
        count = cursor.fetchone()[0]
        return count > 0
    except Exception as e:
        print(f"Error checking DB: {e}")  # Acceptable print in a test helper
        return False
    finally:
        if conn:
            conn.close()


# --- The Main Test (Refactored) ---


def test_watcher_catches_nan_gradient_and_logs_catastrophe(tmp_path):
    """
    Tests the most critical feature:
    1. A NaN loss is created.
    2. loss.backward() should propagate the NaN to the gradients.
    3. The backward hook should detect the NaN and raise CatastrophicTrainingError.
    4. The watcher's __exit__ should catch this and log the failure.
    5. The db_manager's log_catastrophe should have logged the event *before* the raise.
    """
    db_file = tmp_path / "nan_test.db"
    model = SimpleModel()
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

    # --- 2. Create the config object for the new API ---
    config = GradLensConfig(
        logging=LoggingConfig(log_file=str(db_file), sample_every_steps=1),
        tracking=TrackingConfig(
            track_grads=True  # Ensure gradient tracking is on for this test
        ),
    )

    # --- 3. Expect the new, specific exception ---
    # We catch the *type* of exception, not a fragile error string.
    with pytest.raises(CatastrophicTrainingError):
        # --- 4. Use the new config-based API ---
        with watch(model, config=config) as gw:
            optimizer.zero_grad()

            # 1. Create dummy data
            input_tensor = torch.randn(4, 10)
            output = model(input_tensor)

            # 2. --- Create a NaN Loss ---
            # This is a reliable way to create a NaN.
            loss = torch.log(torch.tensor(-1.0)) * output.sum()

            # 3. --- Trigger the Hook ---
            # This backward() call will compute NaN gradients.
            # Our `_create_param_backward_hook` will fire,
            # call `_handle_catastrophe` (logging to DB),
            # and then raise the CatastrophicTrainingError.
            loss.backward()

            # 4. These lines should NOT be reached
            optimizer.step()
            gw.set_step(0, 0, loss.item())

    # 5. --- Post-Mortem Verification (Unchanged, this logic is excellent) ---
    # If we are here, pytest.raises() successfully caught the error.
    # Now, we verify that the catastrophe was logged to the DB *before*
    # the program crashed.

    assert db_file.exists(), "Database file was not created"
    assert _check_db_for_alert(str(db_file), "gradient_alert"), (
        "The NaN gradient_alert was not logged to the database"
    )

# tests/test_config.py

import pytest
import logging

from gradlens.config import (
    TrackingConfig,
    DisplayConfig,
    LoggingConfig,
    TrainingConfig,
    GradLensConfig,
)
# فرض می‌کنیم خطاهای شما در exceptions.py هستند،
# اما در کد شما از ValueError استفاده شده بود، پس ما هم از آن استفاده می‌کنیم.


def test_tracking_config_warns_if_all_disabled(caplog):
    """
    تست می‌کند که اگر تمام گزینه‌های ردیابی غیرفعال باشند، یک هشدار لاگ می‌شود.
    """
    with caplog.at_level(logging.WARNING):
        TrackingConfig(
            track_grads=False,
            track_dead_neurons=False,
            track_activations=False,
            track_parameters=False,
        )
    assert "All tracking options are disabled" in caplog.text


def test_display_config_validation():
    """
    تست می‌کند که اعتبارسنجی مقادیر در DisplayConfig کار می‌کند.
    """
    with pytest.raises(ValueError, match="loss_history_length must be at least 2"):
        DisplayConfig(loss_history_length=1)

    with pytest.raises(ValueError, match="plot_height must be at least 3"):
        DisplayConfig(plot_height=1)

    with pytest.raises(ValueError, match="plot_width must be at least 20"):
        DisplayConfig(plot_width=10)


def test_logging_config_validation():
    """
    تست می‌کند که اعتبارسنجی sample_every_steps کار می‌کند.
    """
    with pytest.raises(ValueError, match="sample_every_steps must be at least 1"):
        LoggingConfig(sample_every_steps=0)


def test_logging_config_creates_directories(tmp_path):
    """
    تست می‌کند که LoggingConfig به طور خودکار پوشه‌های والد را برای فایل‌های لاگ می‌سازد.
    """
    log_file_path = tmp_path / "logs" / "run.db"
    history_file_path = tmp_path / "history" / "summary.csv"

    assert not log_file_path.parent.exists()
    assert not history_file_path.parent.exists()

    LoggingConfig(log_file=str(log_file_path), history_log_file=str(history_file_path))

    assert log_file_path.parent.exists()
    assert history_file_path.parent.exists()


def test_training_config_validation():
    """
    تست می‌کند که اعتبارسنجی مقادیر TrainingConfig کار می‌کند.
    """
    with pytest.raises(ValueError, match="total_epochs must be at least 1"):
        TrainingConfig(total_epochs=0)

    with pytest.raises(ValueError, match="steps_per_epoch must be at least 1"):
        TrainingConfig(steps_per_epoch=0)


def test_gradlens_config_from_dict():
    """
    تست می‌کند که ساخت کانفیگ از دیکشنری به درستی کار می‌کند.
    """
    config_dict = {
        "tracking": {"track_grads": False},
        "display": {"plot_height": 10},
        "logging": {"log_file": "test.db"},
        "training": {"total_epochs": 50},
    }

    config = GradLensConfig.from_dict(config_dict)

    assert config.tracking.track_grads is False
    assert config.tracking.track_dead_neurons is True  # Default
    assert config.display.plot_height == 10
    assert config.logging.log_file == "test.db"
    assert config.training.total_epochs == 50


def test_gradlens_config_to_dict():
    """
    تست می‌کند که تبدیل کانفیگ به دیکشنری به درستی کار می‌کند.
    """
    config = GradLensConfig()
    config.tracking.track_activations = True

    config_dict = config.to_dict()

    assert config_dict["tracking"]["track_activations"] is True
    assert config_dict["display"]["plot_height"] == 8  # Default

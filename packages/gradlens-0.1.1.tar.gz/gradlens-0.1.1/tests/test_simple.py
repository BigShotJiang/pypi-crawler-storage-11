"""
Simple test to verify test setup works
"""

import os
import sys
from pathlib import Path

import pytest

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def test_basic_math():
    """Test basic math operations"""
    assert 2 + 2 == 4
    assert 3 * 3 == 9
    assert 10 / 2 == 5


def test_string_operations():
    """Test string operations"""
    assert "hello" + " " + "world" == "hello world"
    assert "test".upper() == "TEST"
    assert len("python") == 6


def test_list_operations():
    """Test list operations"""
    test_list = [1, 2, 3, 4, 5]
    assert len(test_list) == 5
    assert max(test_list) == 5
    assert min(test_list) == 1
    assert sum(test_list) == 15


def test_dict_operations():
    """Test dictionary operations"""
    test_dict = {"a": 1, "b": 2, "c": 3}
    assert len(test_dict) == 3
    assert test_dict["a"] == 1
    assert "b" in test_dict
    assert "d" not in test_dict


def test_file_operations(tmp_path: Path):
    """Test file operations"""
    test_file = tmp_path / "test_file.txt"
    test_content = "Hello, World!"

    with open(test_file, "w") as f:
        f.write(test_content)

    # Test that we can read from the file
    with open(test_file, "r") as f:
        content = f.read()

    assert content == test_content

    # Clean up
    os.unlink(test_file)


def test_import_gradlens():
    """Test that we can import gradlens modules"""
    try:
        # Test importing the main module
        import gradlens

        assert hasattr(gradlens, "__version__")

        # Test importing analytics modules
        from gradlens.analytics import analytics_engine

        assert hasattr(analytics_engine, "AnalyticsEngine")

        from gradlens.analytics import visualization_engine

        assert hasattr(visualization_engine, "VisualizationEngine")

        from gradlens.analytics import experiment_tracker

        assert hasattr(experiment_tracker, "ExperimentTracker")

        from gradlens.analytics import performance_profiler

        assert hasattr(performance_profiler, "PerformanceProfiler")

        from gradlens.analytics import model_insights

        assert hasattr(model_insights, "ModelInsights")

        from gradlens.analytics import export_manager

        assert hasattr(export_manager, "ExportManager")

    except ImportError as e:
        pytest.skip(f"GradLens modules not available: {e}")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

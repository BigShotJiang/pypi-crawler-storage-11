"""
Test suite for Model Insights

This module contains comprehensive tests for the model insights
to ensure correctness and reliability.
"""

import pytest
import torch.nn as nn
import os

# Import the modules to test
from gradlens.analytics.model_insights import (
    ModelInsights,
    ArchitectureAnalyzer,
    BottleneckDetector,
    Insight,
    InsightType,
    SeverityLevel,
    create_model_insights,
    quick_insights,
)
from gradlens.analytics.analytics_engine import (
    AnalyticsEngine,
    ModelStatistics,
    LayerStatistics,
    ArchitectureType,
)


class TestInsight:
    """Test cases for Insight dataclass"""

    def test_insight_creation(self):
        """Test basic creation of Insight"""
        insight = Insight(
            insight_type=InsightType.ARCHITECTURE,
            severity=SeverityLevel.HIGH,
            title="Test Insight",
            description="This is a test insight",
            recommendation="Do something about it",
        )

        assert insight.insight_type == InsightType.ARCHITECTURE
        assert insight.severity == SeverityLevel.HIGH
        assert insight.title == "Test Insight"
        assert insight.description == "This is a test insight"
        assert insight.recommendation == "Do something about it"
        assert insight.confidence == 1.0

    def test_insight_to_dict(self):
        """Test conversion to dictionary"""
        insight = Insight(
            insight_type=InsightType.ARCHITECTURE,
            severity=SeverityLevel.HIGH,
            title="Test Insight",
            description="This is a test insight",
            recommendation="Do something about it",
            affected_layers=["layer1", "layer2"],
            metrics={"score": 0.8},
        )

        data = insight.to_dict()

        assert data["insight_type"] == "architecture"
        assert data["severity"] == "high"
        assert data["title"] == "Test Insight"
        assert data["description"] == "This is a test insight"
        assert data["recommendation"] == "Do something about it"
        assert data["affected_layers"] == ["layer1", "layer2"]
        assert data["metrics"] == {"score": 0.8}
        assert data["confidence"] == 1.0


class TestArchitectureAnalyzer:
    """Test cases for ArchitectureAnalyzer"""

    def test_analyze_layer_distribution(self):
        """Test layer distribution analysis"""
        # Create model statistics with imbalanced layer distribution
        stats = ModelStatistics(
            architecture_type=ArchitectureType.CUSTOM,
            total_parameters=1000,
            trainable_parameters=1000,
            non_trainable_parameters=0,
        )

        # Add many Linear layers (imbalanced)
        for i in range(10):
            stats.layer_stats[f"linear_{i}"] = LayerStatistics(
                name=f"linear_{i}", layer_type="Linear", num_parameters=100
            )

        # Add one Conv layer
        stats.layer_stats["conv_1"] = LayerStatistics(
            name="conv_1", layer_type="Conv2d", num_parameters=100
        )

        analyzer = ArchitectureAnalyzer()
        insights = analyzer._analyze_layer_distribution(stats)

        # Should detect imbalanced distribution
        assert len(insights) > 0
        assert any(
            insight.insight_type == InsightType.ARCHITECTURE for insight in insights
        )

    def test_analyze_model_depth(self):
        """Test model depth analysis"""
        # Create model statistics with very deep model
        stats = ModelStatistics(
            architecture_type=ArchitectureType.CUSTOM,
            total_parameters=1000,
            trainable_parameters=1000,
            non_trainable_parameters=0,
        )

        # Add many layers (deep model)
        for i in range(150):
            stats.layer_stats[f"layer_{i}"] = LayerStatistics(
                name=f"layer_{i}", layer_type="Linear", num_parameters=10
            )

        analyzer = ArchitectureAnalyzer()
        insights = analyzer._analyze_model_depth(stats)

        # Should detect very deep model
        assert len(insights) > 0
        assert any(
            insight.insight_type == InsightType.ARCHITECTURE for insight in insights
        )

    def test_analyze_parameter_distribution(self):
        """Test parameter distribution analysis"""
        # Create model statistics with parameter imbalance
        stats = ModelStatistics(
            architecture_type=ArchitectureType.CUSTOM,
            total_parameters=1000,
            trainable_parameters=1000,
            non_trainable_parameters=0,
        )

        # Add one layer with most parameters
        stats.layer_stats["heavy_layer"] = LayerStatistics(
            name="heavy_layer",
            layer_type="Linear",
            num_parameters=800,  # 80% of parameters
        )

        # Add other layers with few parameters
        for i in range(5):
            stats.layer_stats[f"light_layer_{i}"] = LayerStatistics(
                name=f"light_layer_{i}",
                layer_type="Linear",
                num_parameters=40,  # 20% of parameters total
            )

        analyzer = ArchitectureAnalyzer()
        insights = analyzer._analyze_parameter_distribution(stats)

        # Should detect parameter imbalance
        assert len(insights) > 0
        assert any(
            insight.insight_type == InsightType.ARCHITECTURE for insight in insights
        )

    def test_analyze_architectural_patterns(self):
        """Test architectural patterns analysis"""
        # Create model statistics with conv layers but no normalization
        stats = ModelStatistics(
            architecture_type=ArchitectureType.CNN,
            total_parameters=1000,
            trainable_parameters=1000,
            non_trainable_parameters=0,
        )

        # Add conv layers
        stats.layer_stats["conv1"] = LayerStatistics(
            name="conv1", layer_type="Conv2d", num_parameters=100
        )

        stats.layer_stats["conv2"] = LayerStatistics(
            name="conv2", layer_type="Conv2d", num_parameters=100
        )

        # No normalization layers

        analyzer = ArchitectureAnalyzer()
        insights = analyzer._analyze_architectural_patterns(stats)

        # Should detect missing normalization
        assert len(insights) > 0
        assert any(
            insight.insight_type == InsightType.ARCHITECTURE for insight in insights
        )


class TestBottleneckDetector:
    """Test cases for BottleneckDetector"""

    def test_detect_performance_bottlenecks(self):
        """Test performance bottleneck detection"""
        # Create model statistics with slow layers
        stats = ModelStatistics(
            architecture_type=ArchitectureType.CUSTOM,
            total_parameters=1000,
            trainable_parameters=1000,
            non_trainable_parameters=0,
        )

        # Add slow layer
        stats.layer_stats["slow_layer"] = LayerStatistics(
            name="slow_layer",
            layer_type="Linear",
            num_parameters=100,
            forward_time_ms=200.0,  # Very slow
        )

        detector = BottleneckDetector()
        insights = detector._detect_performance_bottlenecks(stats)

        # Should detect slow layer
        assert len(insights) > 0
        assert any(
            insight.insight_type == InsightType.BOTTLENECK for insight in insights
        )

    def test_detect_memory_bottlenecks(self):
        """Test memory bottleneck detection"""
        # Create model statistics with memory-intensive layers
        stats = ModelStatistics(
            architecture_type=ArchitectureType.CUSTOM,
            total_parameters=1000,
            trainable_parameters=1000,
            non_trainable_parameters=0,
        )

        # Add memory-intensive layer
        stats.layer_stats["memory_layer"] = LayerStatistics(
            name="memory_layer",
            layer_type="Linear",
            num_parameters=100,
            memory_mb=1500.0,  # Very high memory usage
        )

        detector = BottleneckDetector()
        insights = detector._detect_memory_bottlenecks(stats)

        # Should detect memory-intensive layer
        assert len(insights) > 0
        assert any(
            insight.insight_type == InsightType.BOTTLENECK for insight in insights
        )

    def test_detect_gradient_bottlenecks(self):
        """Test gradient bottleneck detection"""
        # Create model statistics with gradient issues
        stats = ModelStatistics(
            architecture_type=ArchitectureType.CUSTOM,
            total_parameters=1000,
            trainable_parameters=1000,
            non_trainable_parameters=0,
        )

        # Add layer with exploding gradients
        stats.layer_stats["exploding_layer"] = LayerStatistics(
            name="exploding_layer",
            layer_type="Linear",
            num_parameters=100,
            grad_norm=200.0,  # Exploding gradients
        )

        # Add layer with vanishing gradients
        stats.layer_stats["vanishing_layer"] = LayerStatistics(
            name="vanishing_layer",
            layer_type="Linear",
            num_parameters=100,
            grad_norm=1e-8,  # Vanishing gradients
        )

        detector = BottleneckDetector()
        insights = detector._detect_gradient_bottlenecks(stats)

        # Should detect gradient issues
        assert len(insights) > 0
        assert any(
            insight.insight_type == InsightType.BOTTLENECK for insight in insights
        )


class TestModelInsights:
    """Test cases for ModelInsights"""

    def test_analyze_model(self):
        """Test model analysis"""
        # Create a simple model
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        # Analyze the model
        analytics_engine = AnalyticsEngine(model)
        stats = analytics_engine.analyze_model()

        # Get insights
        insights_analyzer = ModelInsights()
        model_insights = insights_analyzer.analyze_model(stats, model_id="test_model")

        assert model_insights.model_id == "test_model"
        assert model_insights.architecture_type == stats.architecture_type
        assert model_insights.total_insights >= 0
        assert 0 <= model_insights.overall_health_score <= 1
        assert 0 <= model_insights.optimization_potential <= 1
        assert 0 <= model_insights.complexity_score <= 1

    def test_compare_models(self):
        """Test model comparison"""
        # Create two models
        model1 = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        model2 = nn.Sequential(nn.Linear(10, 8), nn.ReLU(), nn.Linear(8, 1))

        # Analyze both models
        analytics_engine1 = AnalyticsEngine(model1)
        stats1 = analytics_engine1.analyze_model()

        analytics_engine2 = AnalyticsEngine(model2)
        stats2 = analytics_engine2.analyze_model()

        # Get insights for both models
        insights_analyzer = ModelInsights()
        insights1 = insights_analyzer.analyze_model(stats1, model_id="model1")
        insights2 = insights_analyzer.analyze_model(stats2, model_id="model2")

        # Compare models
        comparison = insights_analyzer.compare_models(insights1, insights2)

        assert "model1" in comparison
        assert "model2" in comparison
        assert "comparison" in comparison
        assert "health_score" in comparison["comparison"]
        assert "optimization_potential" in comparison["comparison"]
        assert "complexity" in comparison["comparison"]


class TestUtilityFunctions:
    """Test cases for utility functions"""

    def test_create_model_insights(self):
        """Test factory function"""
        insights_analyzer = create_model_insights()

        assert isinstance(insights_analyzer, ModelInsights)

    def test_quick_insights(self):
        """Test quick insights function"""
        # Create a simple model
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        # Analyze the model
        analytics_engine = AnalyticsEngine(model)
        stats = analytics_engine.analyze_model()

        # Get quick insights
        insights = quick_insights(stats)

        assert isinstance(insights, dict)
        assert "health_score" in insights
        assert "optimization_potential" in insights
        assert "complexity_score" in insights
        assert "total_insights" in insights
        assert "critical_insights" in insights
        assert "high_insights" in insights


class TestEdgeCases:
    """Test edge cases and error conditions"""

    def test_empty_model_statistics(self):
        """Test with empty model statistics"""
        stats = ModelStatistics(
            architecture_type=ArchitectureType.CUSTOM,
            total_parameters=0,
            trainable_parameters=0,
            non_trainable_parameters=0,
        )

        insights_analyzer = ModelInsights()
        model_insights = insights_analyzer.analyze_model(stats, model_id="empty_model")

        assert model_insights.model_id == "empty_model"
        assert model_insights.total_insights >= 0
        assert 0 <= model_insights.overall_health_score <= 1

    def test_model_with_no_layers(self):
        """Test with model that has no analyzable layers"""

        class EmptyModel(nn.Module):
            def forward(self, x):
                return x

        model = EmptyModel()
        analytics_engine = AnalyticsEngine(model)
        stats = analytics_engine.analyze_model()

        insights_analyzer = ModelInsights()
        model_insights = insights_analyzer.analyze_model(stats, model_id="empty_model")

        assert model_insights.model_id == "empty_model"
        assert model_insights.total_insights >= 0

    def test_model_with_problematic_values(self):
        """Test with model containing problematic values"""
        # Create model statistics with problematic values
        stats = ModelStatistics(
            architecture_type=ArchitectureType.CUSTOM,
            total_parameters=1000,
            trainable_parameters=1000,
            non_trainable_parameters=0,
        )

        # Add layer with problematic values
        stats.layer_stats["problematic_layer"] = LayerStatistics(
            name="problematic_layer",
            layer_type="Linear",
            num_parameters=100,
            grad_norm=float("inf"),  # Infinite gradient norm
            weight_norm=float("nan"),  # NaN weight norm
            dead_neuron_ratio=1.5,  # Invalid ratio > 1
        )

        insights_analyzer = ModelInsights()
        model_insights = insights_analyzer.analyze_model(
            stats, model_id="problematic_model"
        )

        # Should handle problematic values gracefully
        assert model_insights.model_id == "problematic_model"
        assert model_insights.total_insights >= 0


class TestPerformance:
    """Test performance-related functionality"""

    def test_large_model_insights(self):
        """Test insights for large model"""
        # Create a moderately large model
        model = nn.Sequential(
            nn.Linear(1000, 500),
            nn.ReLU(),
            nn.Linear(500, 100),
            nn.ReLU(),
            nn.Linear(100, 10),
        )

        # Analyze the model
        analytics_engine = AnalyticsEngine(model)
        stats = analytics_engine.analyze_model()

        # Get insights
        insights_analyzer = ModelInsights()
        model_insights = insights_analyzer.analyze_model(stats, model_id="large_model")

        # This should complete without errors
        assert model_insights.model_id == "large_model"
        assert model_insights.total_insights >= 0

    def test_memory_usage(self):
        """Test that insights analysis doesn't consume excessive memory"""
        import psutil

        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss

        # Create and analyze a model
        model = nn.Sequential(nn.Linear(1000, 500), nn.ReLU(), nn.Linear(500, 100))

        analytics_engine = AnalyticsEngine(model)
        stats = analytics_engine.analyze_model()

        insights_analyzer = ModelInsights()
        model_insights = insights_analyzer.analyze_model(stats)

        final_memory = process.memory_info().rss
        memory_increase = final_memory - initial_memory

        # Memory increase should be reasonable (less than 100MB)
        assert memory_increase < 100 * 1024 * 1024


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])

#!/usr/bin/env python3
"""
Performance tests for GradLens ExportManager
============================================

This module contains performance tests and benchmarks for ExportManager
to ensure it can handle large datasets efficiently.

Author: GradLens Team
"""

import os
import shutil
import sqlite3
import sys
import tempfile
import time
from unittest.mock import Mock, patch

import pytest

try:
    import weasyprint  # type: ignore  # noqa: F401
except ModuleNotFoundError:
    pytest.skip(
        "weasyprint is required for export performance tests", allow_module_level=True
    )

try:
    import kaleido  # type: ignore  # noqa: F401
except ModuleNotFoundError:
    pytest.skip(
        "kaleido is required for export performance tests", allow_module_level=True
    )

# Add the project root to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from gradlens.export_manager import ExportManager


class TestExportPerformance:
    """Performance tests for ExportManager."""

    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.export_manager = ExportManager(output_dir=self.temp_dir)

    def teardown_method(self):
        """Clean up after each test."""
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def _create_large_database(self, epochs=100, steps_per_epoch=1000):
        """Create a large database for performance testing."""
        db_path = os.path.join(self.temp_dir, f"large_{epochs}_{steps_per_epoch}.db")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics (
                id INTEGER PRIMARY KEY,
                timestamp REAL,
                epoch INTEGER,
                step INTEGER,
                metric_type TEXT,
                layer_name TEXT,
                value REAL
            )
        """)

        # Generate large dataset
        import random

        base_time = time.time()
        data = []

        for epoch in range(epochs):
            for step in range(steps_per_epoch):
                # Simulate realistic loss curve
                base_loss = 2.0 * (0.99**epoch) + random.uniform(-0.01, 0.01)

                data.append(
                    (
                        None,  # Let SQLite auto-generate ID
                        base_time + epoch * steps_per_epoch + step,
                        epoch,
                        step,
                        "loss",
                        "model",
                        max(0.001, base_loss),
                    )
                )

                # Batch insert for performance
                if len(data) >= 10000:
                    cursor.executemany(
                        "INSERT INTO metrics VALUES (?, ?, ?, ?, ?, ?, ?)", data
                    )
                    data = []

        # Insert remaining data
        if data:
            cursor.executemany("INSERT INTO metrics VALUES (?, ?, ?, ?, ?, ?, ?)", data)

        conn.commit()
        conn.close()
        return db_path

    def test_data_loading_performance(self):
        """Test data loading performance with large datasets."""
        # Create large database (50 epochs, 500 steps each = 25,000 records)
        db_path = self._create_large_database(epochs=50, steps_per_epoch=500)

        with patch("glob.glob", return_value=[db_path]):
            start_time = time.time()
            run_data = self.export_manager._load_run_data("large_50_500")
            load_time = time.time() - start_time

            # Verify data was loaded correctly
            assert run_data is not None
            assert len(run_data["metrics"]) == 25000
            assert run_data["config"]["total_epochs"] == 50
            assert run_data["config"]["total_steps"] == 25000

            # Performance assertion (should load in reasonable time)
            assert load_time < 5.0, (
                f"Data loading took {load_time:.2f}s, expected < 5.0s"
            )

    def test_insights_generation_performance(self):
        """Test insights generation performance with large datasets."""
        # Create large database
        db_path = self._create_large_database(epochs=100, steps_per_epoch=1000)

        with patch("glob.glob", return_value=[db_path]):
            run_data = self.export_manager._load_run_data("large_100_1000")

            start_time = time.time()
            insights = self.export_manager._generate_insights(run_data)
            insights_time = time.time() - start_time

            # Verify insights were generated
            assert "training_summary" in insights
            assert "model_analysis" in insights
            assert "warnings" in insights
            assert "recommendations" in insights

            # Performance assertion
            assert insights_time < 2.0, (
                f"Insights generation took {insights_time:.2f}s, expected < 2.0s"
            )

    @patch("gradlens.export_manager.PLOTLY_AVAILABLE", True)
    def test_charts_generation_performance(self):
        """Test charts generation performance with large datasets."""
        # Create large database
        db_path = self._create_large_database(epochs=200, steps_per_epoch=500)

        with patch("glob.glob", return_value=[db_path]):
            run_data = self.export_manager._load_run_data("large_200_500")

            start_time = time.time()
            charts = self.export_manager._generate_charts(run_data)
            charts_time = time.time() - start_time

            # Verify charts were generated
            assert "loss_curve" in charts
            assert isinstance(charts["loss_curve"], str)
            assert len(charts["loss_curve"]) > 0

            # Performance assertion
            assert charts_time < 10.0, (
                f"Charts generation took {charts_time:.2f}s, expected < 10.0s"
            )

    @patch("gradlens.export_manager.PLOTLY_AVAILABLE", True)
    @patch("gradlens.export_manager.WEASYPRINT_AVAILABLE", True)
    def test_complete_report_generation_performance(self):
        """Test complete report generation performance."""
        # Create large database
        db_path = self._create_large_database(epochs=50, steps_per_epoch=1000)

        with patch("glob.glob", return_value=[db_path]):
            with patch("weasyprint.HTML") as mock_weasyprint:
                mock_html = Mock()
                mock_weasyprint.return_value = mock_html

                start_time = time.time()
                result = self.export_manager.generate_report(
                    run_id="large_50_1000",
                    format="html",
                    include_charts=True,
                    include_insights=True,
                )
                total_time = time.time() - start_time

                # Verify report was created
                assert os.path.exists(result)

                # Performance assertion
                assert total_time < 15.0, (
                    f"Complete report generation took {total_time:.2f}s, expected < 15.0s"
                )

    def test_memory_usage_with_large_datasets(self):
        """Test memory usage with large datasets."""
        import psutil
        import gc

        # Get initial memory usage
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB

        # Create very large database
        db_path = self._create_large_database(epochs=200, steps_per_epoch=2000)

        with patch("glob.glob", return_value=[db_path]):
            # Load data
            run_data = self.export_manager._load_run_data("large_200_2000")

            # Check memory usage after loading
            memory_after_load = process.memory_info().rss / 1024 / 1024  # MB
            memory_increase = memory_after_load - initial_memory

            # Generate insights
            insights = self.export_manager._generate_insights(run_data)

            # Check memory usage after insights
            memory_after_insights = process.memory_info().rss / 1024 / 1024  # MB
            memory_increase_insights = memory_after_insights - initial_memory

            # Clean up
            del run_data
            del insights
            gc.collect()

            # Memory usage should be reasonable (less than 500MB increase)
            assert memory_increase < 500, (
                f"Memory increase: {memory_increase:.1f}MB, expected < 500MB"
            )
            assert memory_increase_insights < 500, (
                f"Memory increase after insights: {memory_increase_insights:.1f}MB, expected < 500MB"
            )

    def test_concurrent_report_generation(self):
        """Test concurrent report generation performance."""
        import threading
        import queue

        # Create multiple databases
        db_paths = []
        for i in range(5):
            db_path = self._create_large_database(epochs=20, steps_per_epoch=500)
            db_paths.append(db_path)

        results = queue.Queue()
        errors = queue.Queue()

        def generate_report(db_path, run_id):
            """Generate report in separate thread."""
            try:
                with patch("glob.glob", return_value=[db_path]):
                    with patch("weasyprint.HTML") as mock_weasyprint:
                        mock_html = Mock()
                        mock_weasyprint.return_value = mock_html

                        start_time = time.time()
                        result = self.export_manager.generate_report(
                            run_id=run_id,
                            format="html",
                            include_charts=False,  # Disable charts for speed
                            include_insights=True,
                        )
                        generation_time = time.time() - start_time

                        results.put((run_id, result, generation_time))
            except Exception as e:
                errors.put((run_id, str(e)))

        # Start multiple threads
        threads = []
        start_time = time.time()

        for i, db_path in enumerate(db_paths):
            thread = threading.Thread(
                target=generate_report, args=(db_path, f"concurrent_{i}")
            )
            threads.append(thread)
            thread.start()

        # Wait for all threads to complete
        for thread in threads:
            thread.join()

        total_time = time.time() - start_time

        # Check results
        assert errors.empty(), (
            f"Errors occurred: {[errors.get() for _ in range(errors.qsize())]}"
        )

        # Verify all reports were generated
        report_results = []
        while not results.empty():
            report_results.append(results.get())

        assert len(report_results) == 5, (
            f"Expected 5 reports, got {len(report_results)}"
        )

        # Verify all files exist
        for run_id, result_path, generation_time in report_results:
            assert os.path.exists(result_path), f"Report for {run_id} not found"
            assert generation_time < 10.0, (
                f"Report generation for {run_id} took {generation_time:.2f}s, expected < 10.0s"
            )

        # Total time should be reasonable (parallel execution)
        assert total_time < 30.0, (
            f"Total concurrent generation time: {total_time:.2f}s, expected < 30.0s"
        )

    def test_database_query_optimization(self):
        """Test database query optimization with large datasets."""
        # Create database with many records
        db_path = self._create_large_database(epochs=100, steps_per_epoch=1000)

        with patch("glob.glob", return_value=[db_path]):
            # Test different query patterns
            start_time = time.time()

            # Test 1: Load all data
            run_data = self.export_manager._load_run_data("large_100_1000")
            load_time = time.time() - start_time

            # Test 2: Analyze performance
            start_time = time.time()
            performance = self.export_manager._analyze_training_performance(run_data)
            analysis_time = time.time() - start_time

            # Test 3: Generate warnings
            start_time = time.time()
            warnings = self.export_manager._generate_warnings(run_data)
            warnings_time = time.time() - start_time

            # Verify results
            assert run_data is not None
            assert len(run_data["metrics"]) == 100000
            assert performance["total_epochs"] == 100
            assert performance["total_steps"] == 100000
            assert isinstance(warnings, list)

            # Performance assertions
            assert load_time < 3.0, (
                f"Data loading took {load_time:.2f}s, expected < 3.0s"
            )
            assert analysis_time < 1.0, (
                f"Performance analysis took {analysis_time:.2f}s, expected < 1.0s"
            )
            assert warnings_time < 1.0, (
                f"Warnings generation took {warnings_time:.2f}s, expected < 1.0s"
            )

    def test_scalability_with_different_sizes(self):
        """Test scalability with different dataset sizes."""
        sizes = [
            (10, 100),  # Small: 1,000 records
            (50, 200),  # Medium: 10,000 records
            (100, 500),  # Large: 50,000 records
            (200, 1000),  # Very large: 200,000 records
        ]

        results = []

        for epochs, steps_per_epoch in sizes:
            db_path = self._create_large_database(epochs, steps_per_epoch)

            with patch("glob.glob", return_value=[db_path]):
                start_time = time.time()

                # Load data
                run_data = self.export_manager._load_run_data(
                    f"scale_{epochs}_{steps_per_epoch}"
                )

                # Generate insights
                insights = self.export_manager._generate_insights(run_data)

                total_time = time.time() - start_time
                total_records = epochs * steps_per_epoch

                results.append(
                    {
                        "epochs": epochs,
                        "steps_per_epoch": steps_per_epoch,
                        "total_records": total_records,
                        "time": total_time,
                        "records_per_second": total_records / total_time
                        if total_time > 0
                        else 0,
                    }
                )

        # Verify scalability (time should not increase exponentially)
        for i in range(1, len(results)):
            prev_result = results[i - 1]
            curr_result = results[i]

            # Time increase should be roughly linear with record count
            time_ratio = curr_result["time"] / prev_result["time"]
            record_ratio = curr_result["total_records"] / prev_result["total_records"]

            # Time ratio should not be much higher than record ratio
            assert time_ratio < record_ratio * 2, (
                f"Time scaling is not linear: {time_ratio:.2f} vs {record_ratio:.2f}"
            )

    def test_error_handling_performance(self):
        """Test error handling doesn't significantly impact performance."""
        # Create database with some problematic data
        db_path = os.path.join(self.temp_dir, "error_test.db")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE metrics (
                id INTEGER PRIMARY KEY,
                timestamp REAL,
                epoch INTEGER,
                step INTEGER,
                metric_type TEXT,
                layer_name TEXT,
                value REAL
            )
        """)

        # Insert data with some problematic values
        data = []
        for i in range(1000):
            data.append(
                (
                    i + 1,
                    1000.0 + i,
                    i // 100,
                    i % 100,
                    "loss",
                    "model",
                    float("inf")
                    if i % 100 == 0
                    else 1.0 + i * 0.001,  # Some infinite values
                )
            )

        cursor.executemany("INSERT INTO metrics VALUES (?, ?, ?, ?, ?, ?, ?)", data)
        conn.commit()
        conn.close()

        with patch("glob.glob", return_value=[db_path]):
            start_time = time.time()

            # This should handle errors gracefully without significant performance impact
            run_data = self.export_manager._load_run_data("error_test")
            insights = self.export_manager._generate_insights(run_data)

            total_time = time.time() - start_time

            # Should complete in reasonable time despite errors
            assert total_time < 2.0, (
                f"Error handling took {total_time:.2f}s, expected < 2.0s"
            )
            assert run_data is not None
            assert isinstance(insights, dict)


if __name__ == "__main__":
    # Run tests if executed directly
    pytest.main([__file__, "-v"])

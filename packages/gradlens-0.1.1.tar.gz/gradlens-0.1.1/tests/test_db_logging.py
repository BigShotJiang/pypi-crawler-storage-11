# tests/test_db_logging.py

import pytest
import torch
import torch.nn as nn
import sqlite3
from typing import List

from gradlens import watch

# --- 1. Import new config objects ---
from gradlens.config import (
    GradLensConfig,
    TrainingConfig,
    TrackingConfig,
    LoggingConfig,
    DisplayConfig,  # Import DisplayConfig as well
)


# --- Test Model Setup ---
class SimpleModel(nn.Module):
    """A simple model for testing purposes."""

    def __init__(self):
        super().__init__()
        self.layer1 = nn.Linear(10, 5)
        self.relu1 = nn.ReLU()
        self.layer2 = nn.Linear(5, 1)

    def forward(self, x):
        return self.layer2(self.relu1(self.layer1(x)))


# --- Helper Function ---
# (This helper is fine for testing purposes, no change needed)
def _query_db(db_file: str, query: str) -> List[tuple]:
    """A generic helper to run a read-only query on the DB."""
    conn = None
    try:
        conn = sqlite3.connect(f"file:{db_file}?mode=ro", uri=True)
        cursor = conn.cursor()
        cursor.execute(query)
        return cursor.fetchall()
    except Exception as e:
        # Print is acceptable in a test helper, as it provides debug info
        print(f"Error querying DB: {e}")
        return []
    finally:
        if conn:
            conn.close()


# --- The Main Test ---


def test_watcher_logs_all_metrics_correctly_to_db(tmp_path):
    """
    Tests that a normal training run logs all enabled metrics
    (loss, grad_norm, dead_neuron, param_norm) to the database
    using the new config-based API.
    """
    db_file = tmp_path / "normal_run.db"
    model = SimpleModel()
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

    # Define simulation parameters
    total_epochs = 2
    steps_per_epoch = 3
    sample_every = 1  # Log every step

    # --- 2. Create config objects instead of passing kwargs ---

    training_config = TrainingConfig(
        total_epochs=total_epochs, steps_per_epoch=steps_per_epoch
    )

    logging_config = LoggingConfig(
        log_file=str(db_file), sample_every_steps=sample_every
    )

    tracking_config = TrackingConfig(
        track_grads=True,
        track_dead_neurons=True,
        track_parameters=True,
        track_activations=False,  # Explicitly match old test
    )

    # Use default display config
    display_config = DisplayConfig()

    # Create the main config object
    config = GradLensConfig(
        training=training_config,
        logging=logging_config,
        tracking=tracking_config,
        display=display_config,
    )

    try:
        # --- 3. Call watch() with the new config object ---
        with watch(model, config=config) as gw:
            for epoch in range(total_epochs):
                for step in range(steps_per_epoch):
                    optimizer.zero_grad()
                    input_tensor = torch.randn(4, 10)
                    target = torch.randn(4, 1)
                    output = model(input_tensor)
                    loss = ((output - target) ** 2).mean()

                    loss.backward()
                    optimizer.step()

                    gw.set_step(epoch, step, loss.item())

    except Exception as e:
        pytest.fail(f"Watcher raised an unexpected error during a normal run: {e}")

    # --- Verification (This logic was already excellent, no changes needed) ---

    assert db_file.exists(), "Database file was not created"

    total_steps_run = total_epochs * steps_per_epoch

    # 1. Check Loss: Should have one entry per step
    loss_logs = _query_db(
        str(db_file), "SELECT * FROM metrics WHERE metric_type = 'loss'"
    )
    assert len(loss_logs) == total_steps_run
    assert loss_logs[0][4] == "loss"
    assert loss_logs[0][5] == "model"

    # 2. Check Gradient Norms
    num_params = len(list(model.parameters()))
    expected_param_names = {name for name, param in model.named_parameters()}

    grad_logs_query = """
        SELECT layer_name FROM metrics 
        WHERE metric_type = 'grad_norm' AND epoch = 0 AND step = 0
    """
    grad_logs_step_0 = _query_db(str(db_file), grad_logs_query)
    logged_param_names_step_0 = {row[0] for row in grad_logs_step_0}

    assert logged_param_names_step_0 == expected_param_names, (
        "The set of logged grad_norm parameters does not match the model's parameters"
    )

    all_grad_logs = _query_db(
        str(db_file), "SELECT * FROM metrics WHERE metric_type = 'grad_norm'"
    )
    assert len(all_grad_logs) == total_steps_run * num_params

    # 3. Check Dead Neurons
    dead_neuron_logs = _query_db(
        str(db_file), "SELECT * FROM metrics WHERE metric_type = 'dead_neuron'"
    )
    # We have one ReLU layer, so 1 log per step
    assert len(dead_neuron_logs) == total_steps_run * 1
    assert dead_neuron_logs[0][5] == "relu1"

    # 4. Check Parameter Norms
    param_logs_query = """
        SELECT layer_name FROM metrics 
        WHERE metric_type = 'param_norm' AND epoch = 0 AND step = 0
    """
    param_logs_step_0 = _query_db(str(db_file), param_logs_query)
    logged_param_names_step_0_params = {row[0] for row in param_logs_step_0}

    assert logged_param_names_step_0_params == expected_param_names, (
        "The set of logged param_norm parameters does not match the model's parameters"
    )

    all_param_logs = _query_db(
        str(db_file), "SELECT * FROM metrics WHERE metric_type = 'param_norm'"
    )
    assert len(all_param_logs) == total_steps_run * num_params

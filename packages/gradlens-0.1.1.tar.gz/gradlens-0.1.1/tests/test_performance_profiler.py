"""
Test suite for Performance Profiler

This module contains comprehensive tests for the performance profiler
to ensure correctness and reliability.
"""

import os
import time
from pathlib import Path

import pytest
import torch
import torch.nn as nn

# Import the modules to test
from gradlens.analytics.performance_profiler import (
    PerformanceProfiler,
    ProfilerConfig,
    PerformanceMetrics,
    ProfilerMode,
    create_performance_profiler,
    profile_model,
    quick_profile,
)


class TestProfilerConfig:
    """Test cases for ProfilerConfig dataclass"""

    def test_profiler_config_creation(self):
        """Test basic creation of ProfilerConfig"""
        config = ProfilerConfig(
            enable_memory_profiling=True,
            enable_gpu_profiling=True,
            sample_frequency=2.0,
        )

        assert config.enable_memory_profiling == True
        assert config.enable_gpu_profiling == True
        assert config.sample_frequency == 2.0
        assert config.max_samples == 10000


class TestPerformanceMetrics:
    """Test cases for PerformanceMetrics dataclass"""

    def test_performance_metrics_creation(self):
        """Test basic creation of PerformanceMetrics"""
        metric = PerformanceMetrics(
            timestamp=time.time(),
            metric_type=ProfilerMode.TRAINING,
            value=1.5,
            unit="ms",
        )

        assert metric.value == 1.5
        assert metric.unit == "ms"
        assert metric.layer_name is None
        assert metric.phase == "unknown"

    def test_performance_metrics_to_dict(self):
        """Test conversion to dictionary"""
        metric = PerformanceMetrics(
            timestamp=time.time(),
            metric_type=ProfilerMode.TRAINING,
            value=1.5,
            unit="ms",
            layer_name="test_layer",
            phase="forward",
        )

        data = metric.to_dict()

        assert data["value"] == 1.5
        assert data["unit"] == "ms"
        assert data["layer_name"] == "test_layer"
        assert data["phase"] == "forward"


class TestPerformanceProfiler:
    """Test cases for PerformanceProfiler"""

    def test_performance_profiler_creation(self):
        """Test basic creation of PerformanceProfiler"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = PerformanceProfiler(model)

        assert profiler.model == model
        assert profiler.config is not None
        assert profiler.device is not None
        assert len(profiler.metrics) == 0
        assert len(profiler.layer_profiles) == 0

    def test_performance_profiler_with_config(self):
        """Test creation with custom config"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        config = ProfilerConfig(
            enable_memory_profiling=False,
            enable_gpu_profiling=False,
            sample_frequency=1.0,
        )

        profiler = PerformanceProfiler(model, config)

        assert profiler.config.enable_memory_profiling == False
        assert profiler.config.enable_gpu_profiling == False
        assert profiler.config.sample_frequency == 1.0

    def test_profile_forward_pass(self):
        """Test profiling forward pass"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = PerformanceProfiler(model)

        input_tensor = torch.randn(32, 10)

        results = profiler.profile_forward_pass(input_tensor)

        assert "forward_time_ms" in results
        assert "memory_used_mb" in results
        assert "throughput_samples_per_sec" in results
        assert "batch_size" in results
        assert results["batch_size"] == 32
        assert results["forward_time_ms"] > 0

    def test_profile_training_step(self):
        """Test profiling training step"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = PerformanceProfiler(model)

        input_tensor = torch.randn(32, 10)
        target_tensor = torch.randn(32, 1)
        loss_fn = nn.MSELoss()
        optimizer = torch.optim.Adam(model.parameters())

        results = profiler.profile_training_step(
            input_tensor, target_tensor, loss_fn, optimizer
        )

        assert "total_time_ms" in results
        assert "forward_time_ms" in results
        assert "loss_time_ms" in results
        assert "backward_time_ms" in results
        assert "optimizer_time_ms" in results
        assert "throughput_samples_per_sec" in results
        assert results["batch_size"] == 32
        assert results["total_time_ms"] > 0

    def test_get_layer_profile(self):
        """Test getting layer profile"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = PerformanceProfiler(model)

        # Profile a forward pass to populate layer profiles
        input_tensor = torch.randn(32, 10)
        profiler.profile_forward_pass(input_tensor)

        # Get layer profile
        profile = profiler.get_layer_profile("0")

        if profile is not None:
            assert profile.layer_name == "0"
            assert profile.layer_type == "Linear"
            assert profile.call_count > 0

    def test_get_performance_summary(self):
        """Test getting performance summary"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = PerformanceProfiler(model)

        # Profile some operations
        input_tensor = torch.randn(32, 10)
        profiler.profile_forward_pass(input_tensor)

        summary = profiler.get_performance_summary()

        assert "total_metrics" in summary
        assert "profiling_duration" in summary
        assert "layers_profiled" in summary
        assert "metrics_by_type" in summary
        assert "layer_performance" in summary

    def test_detect_bottlenecks(self):
        """Test bottleneck detection"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = PerformanceProfiler(model)

        # Profile some operations
        input_tensor = torch.randn(32, 10)
        profiler.profile_forward_pass(input_tensor)

        bottlenecks = profiler.detect_bottlenecks()

        assert isinstance(bottlenecks, list)
        # Bottlenecks might be empty for simple models
        # This is acceptable for testing

    def test_get_optimization_recommendations(self):
        """Test getting optimization recommendations"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = PerformanceProfiler(model)

        # Profile some operations
        input_tensor = torch.randn(32, 10)
        profiler.profile_forward_pass(input_tensor)

        recommendations = profiler.get_optimization_recommendations()

        assert isinstance(recommendations, list)
        # Recommendations might be empty for simple models
        # This is acceptable for testing

    def test_export_profile_report(self, tmp_path: Path):
        """Test exporting profile report"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = PerformanceProfiler(model)

        # Profile some operations
        input_tensor = torch.randn(32, 10)
        profiler.profile_forward_pass(input_tensor)

        report_path = profiler.export_profile_report(str(tmp_path / "profile.json"))

        assert os.path.exists(report_path)
        assert report_path.endswith(".json")

        import json

        with open(report_path, "r") as f:
            data = json.load(f)

        assert "profiler_config" in data
        assert "performance_summary" in data
        assert "layer_profiles" in data
        assert "bottlenecks" in data
        assert "recommendations" in data

    def test_start_stop_profiling(self):
        """Test starting and stopping profiling"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = PerformanceProfiler(model)

        # Start profiling
        profiler.start_profiling()
        assert len(profiler._hooks) > 0

        # Stop profiling
        profiler.stop_profiling()
        assert len(profiler._hooks) == 0

    def test_context_manager(self):
        """Test using profiler as context manager"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        with PerformanceProfiler(model) as profiler:
            assert len(profiler._hooks) > 0

            # Profile some operations
            input_tensor = torch.randn(32, 10)
            profiler.profile_forward_pass(input_tensor)

        # Hooks should be removed after context
        assert len(profiler._hooks) == 0


class TestUtilityFunctions:
    """Test cases for utility functions"""

    def test_create_performance_profiler(self):
        """Test factory function"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = create_performance_profiler(model)

        assert isinstance(profiler, PerformanceProfiler)
        assert profiler.model == model

    def test_create_performance_profiler_with_config(self):
        """Test factory function with config"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        config = ProfilerConfig(enable_memory_profiling=False)
        profiler = create_performance_profiler(model, config)

        assert isinstance(profiler, PerformanceProfiler)
        assert profiler.config.enable_memory_profiling == False

    def test_profile_model_context_manager(self):
        """Test profile_model context manager"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        with profile_model(model) as profiler:
            assert isinstance(profiler, PerformanceProfiler)
            assert len(profiler._hooks) > 0

            # Profile some operations
            input_tensor = torch.randn(32, 10)
            profiler.profile_forward_pass(input_tensor)

        # Hooks should be removed after context
        assert len(profiler._hooks) == 0

    def test_quick_profile(self):
        """Test quick profile function"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        input_tensor = torch.randn(32, 10)

        result = quick_profile(model, input_tensor, num_iterations=3)

        assert isinstance(result, dict)
        assert "total_metrics" in result
        assert "profiling_duration" in result
        assert "layers_profiled" in result


class TestEdgeCases:
    """Test edge cases and error conditions"""

    def test_empty_model(self):
        """Test with empty model"""

        class EmptyModel(nn.Module):
            def forward(self, x):
                return x

        model = EmptyModel()
        profiler = PerformanceProfiler(model)

        input_tensor = torch.randn(32, 10)
        results = profiler.profile_forward_pass(input_tensor)

        assert "forward_time_ms" in results
        assert results["forward_time_ms"] >= 0

    def test_model_with_no_parameters(self):
        """Test with model that has no parameters"""

        class NoParamModel(nn.Module):
            def forward(self, x):
                return x

        model = NoParamModel()
        profiler = PerformanceProfiler(model)

        input_tensor = torch.randn(32, 10)
        results = profiler.profile_forward_pass(input_tensor)

        assert "forward_time_ms" in results
        assert results["forward_time_ms"] >= 0

    def test_invalid_export_format(self):
        """Test export with invalid format"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = PerformanceProfiler(model)

        # Profile some operations
        input_tensor = torch.randn(32, 10)
        profiler.profile_forward_pass(input_tensor)

        # Test invalid format
        with pytest.raises(ValueError):
            profiler.export_profile_report("test.xyz", format="invalid")

    def test_profile_with_nan_values(self):
        """Test profiling with NaN values"""
        model = nn.Sequential(nn.Linear(10, 5), nn.ReLU(), nn.Linear(5, 1))

        profiler = PerformanceProfiler(model)

        # Create input with NaN values
        input_tensor = torch.randn(32, 10)
        input_tensor[0, 0] = float("nan")

        # This should handle NaN values gracefully
        results = profiler.profile_forward_pass(input_tensor)

        assert "forward_time_ms" in results
        assert results["forward_time_ms"] >= 0


class TestPerformance:
    """Test performance-related functionality"""

    def test_large_model_profiling(self):
        """Test profiling of large model"""
        # Create a moderately large model
        model = nn.Sequential(
            nn.Linear(1000, 500),
            nn.ReLU(),
            nn.Linear(500, 100),
            nn.ReLU(),
            nn.Linear(100, 10),
        )

        profiler = PerformanceProfiler(model)

        # This should complete without errors
        input_tensor = torch.randn(32, 1000)
        results = profiler.profile_forward_pass(input_tensor)

        assert "forward_time_ms" in results
        assert results["forward_time_ms"] > 0

    def test_memory_usage(self):
        """Test that profiler doesn't consume excessive memory"""
        import psutil
        import os

        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss

        # Create and profile a model
        model = nn.Sequential(nn.Linear(1000, 500), nn.ReLU(), nn.Linear(500, 100))

        profiler = PerformanceProfiler(model)

        # Profile some operations
        input_tensor = torch.randn(32, 1000)
        profiler.profile_forward_pass(input_tensor)

        final_memory = process.memory_info().rss
        memory_increase = final_memory - initial_memory

        # Memory increase should be reasonable (less than 200MB)
        assert memory_increase < 200 * 1024 * 1024

    def test_profiling_overhead(self):
        """Test that profiling overhead is reasonable"""
        model = nn.Sequential(nn.Linear(100, 50), nn.ReLU(), nn.Linear(50, 10))

        input_tensor = torch.randn(32, 100)

        # Time without profiling
        start_time = time.time()
        for _ in range(100):
            with torch.no_grad():
                _ = model(input_tensor)
        no_profiling_time = time.time() - start_time

        # Time with profiling
        profiler = PerformanceProfiler(model)
        start_time = time.time()
        for _ in range(100):
            profiler.profile_forward_pass(input_tensor)
        profiling_time = time.time() - start_time

        # Profiling overhead should be reasonable (less than 10x)
        overhead_ratio = profiling_time / no_profiling_time
        assert overhead_ratio < 10.0


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])

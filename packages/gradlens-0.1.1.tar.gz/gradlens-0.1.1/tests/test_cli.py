# tests/test_cli.py

import pytest
import sqlite3
import sys
import re
from unittest.mock import patch, MagicMock, call
from rich.console import Console

from gradlens.cli import (
    main,
    print_summary_report_to_console,
    plot_history_in_terminal,
    _print_catastrophe_section,
    _print_gradient_health_section,
    _print_neuron_health_section,
    _print_frozen_params_section,
)
from gradlens.database import get_db_connection
from gradlens.exceptions import DatabaseError

# --- Fixture Setup ---
CREATE_METRICS_TABLE = """
CREATE TABLE IF NOT EXISTS metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp REAL, epoch INTEGER,
    step INTEGER, metric_type TEXT, layer_name TEXT, value REAL
)"""


# --- Fixture 1: General (RESTORED) ---
@pytest.fixture
def setup_test_db(tmp_path):
    """Fixture for general CLI tests (catastrophe, gradient, neuron, main)."""
    db_file = tmp_path / "general_cli_test.db"
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute(CREATE_METRICS_TABLE)
    test_data = [
        # Data for catastrophe, gradient, neuron tests
        (1.0, 0, 1, "gradient_alert", "layer1.weight", 1.0),
        (2.0, 0, 2, "grad_norm", "layer_exploding", 9999.0),
        (2.1, 0, 2, "grad_norm", "layer_vanishing", 1e-9),
        (3.0, 0, 3, "dead_neuron", "relu1", 0.8),
        (3.1, 0, 4, "dead_neuron", "relu1", 0.9),
        (3.2, 0, 3, "dead_neuron", "relu2", 0.1),
        # Add minimal param data needed for main tests (if any)
        (4.0, 0, 0, "param_norm", "some_param", 1.0),
        (5.0, 9, 9, "param_norm", "some_param", 1.1),
    ]
    cursor.executemany("INSERT INTO metrics VALUES (NULL, ?, ?, ?, ?, ?, ?)", test_data)
    conn.commit()
    conn.close()
    yield str(db_file)


# --- Fixture 2: Specific for Frozen Params ---
@pytest.fixture
def setup_frozen_db(tmp_path):
    """Fixture ONLY for frozen param tests."""
    db_file = tmp_path / "frozen_test.db"
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute(CREATE_METRICS_TABLE)
    test_data = [
        # Data specifically for frozen/active params comparison
        (4.0, 0, 0, "param_norm", "frozen_param", 1.234567),  # First step
        (4.1, 0, 0, "param_norm", "active_param", 0.5),  # First step
        (
            5.0,
            9,
            9,
            "param_norm",
            "frozen_param",
            1.2345678,
        ),  # Last step - Diff = 8e-7 (< 1e-5)
        (5.1, 9, 9, "param_norm", "active_param", 2.5),  # Last step - Large diff
        (4.5, 5, 5, "param_norm", "some_other_param", 3.0),  # Middle step
    ]
    cursor.executemany("INSERT INTO metrics VALUES (NULL, ?, ?, ?, ?, ?, ?)", test_data)
    conn.commit()
    conn.close()
    yield str(db_file)


# --- Tests for Analytic Functions (Using correct fixtures) ---


@patch("gradlens.cli.Table")
def test_cli_catastrophe_report(
    mock_table_class, setup_test_db
):  # Uses general fixture
    mock_table_instance = MagicMock()
    mock_table_class.return_value = mock_table_instance
    mock_console = MagicMock(spec=Console)
    with get_db_connection(setup_test_db, readonly=True) as conn:
        _print_catastrophe_section(conn.cursor(), mock_console)
    mock_table_class.assert_called_with(
        title="🚨 [bold red]NaN/Inf Events Detected![/bold red]"
    )
    mock_table_instance.add_row.assert_called_with(
        "0", "1", "gradient_alert", "layer1.weight"
    )


@patch("gradlens.cli.Table")
def test_cli_gradient_health_report(
    mock_table_class, setup_test_db
):  # Uses general fixture
    mock_table_instance_max = MagicMock()
    mock_table_instance_min = MagicMock()
    mock_table_class.side_effect = [mock_table_instance_max, mock_table_instance_min]
    mock_console = MagicMock(spec=Console)
    with get_db_connection(setup_test_db, readonly=True) as conn:
        _print_gradient_health_section(conn.cursor(), mock_console)

    assert "Exploding Risk" in mock_table_class.call_args_list[0].kwargs["title"]
    max_calls = mock_table_instance_max.add_row.call_args_list
    assert call("layer_exploding", "[bold red]1.00e+04[/bold red]") in max_calls

    assert "Vanishing Risk" in mock_table_class.call_args_list[1].kwargs["title"]
    min_calls = mock_table_instance_min.add_row.call_args_list
    assert call("layer_vanishing", "[bold red]1.00e-09[/bold red]") in min_calls


@patch("gradlens.cli.Table")
def test_cli_neuron_health_report(
    mock_table_class, setup_test_db
):  # Uses general fixture
    mock_table_instance = MagicMock()
    mock_table_class.return_value = mock_table_instance
    mock_console = MagicMock(spec=Console)
    with get_db_connection(setup_test_db, readonly=True) as conn:
        _print_neuron_health_section(conn.cursor(), mock_console)

    calls = mock_table_instance.add_row.call_args_list
    call_set = {c.args for c in calls}
    expected_set = {
        ("relu1", "[bold red]85.0%[/bold red]"),
        ("relu2", "[white]10.0%[/white]"),
    }
    assert call_set == expected_set


# --- Frozen Param Tests (Using specific fixture and Python comparison logic) ---


@patch("gradlens.cli.Table")
def test_print_frozen_params_section_identifies_frozen(
    mock_table_class, setup_frozen_db
):  # Uses frozen fixture
    """Test _print_frozen_params_section identifies frozen params using math.isclose."""
    mock_table = MagicMock()
    mock_table_class.return_value = mock_table
    mock_console = MagicMock(spec=Console)

    with get_db_connection(setup_frozen_db, readonly=True) as conn:
        # Run the version of the function that uses math.isclose
        _print_frozen_params_section(conn.cursor(), mock_console)

    # 1. Check title includes tolerance
    table_created = False
    for args, kwargs in mock_table_class.call_args_list:
        title = kwargs.get("title", "")
        # Check for the specific tolerance used in the Python version (1e-5)
        if re.search(
            r"🧊 Parameters with ~No Change.*< 1\.0e-05.*\(between 0:0 and 9:9\)", title
        ):
            table_created = True
            break
    assert table_created, (
        "Table with expected title pattern (including tolerance) was not created."
    )

    # 2. Check add_row calls
    add_row_calls = mock_table.add_row.call_args_list
    assert len(add_row_calls) >= 1, "Expected add_row to be called at least once."

    # 3. Check 'frozen_param' row details
    found_frozen_row = False
    for call_args in add_row_calls:
        args = call_args.args
        if len(args) >= 4 and args[0] == "frozen_param":
            found_frozen_row = True
            layer_name, initial_str, final_str, delta_str = args
            assert initial_str == "1.234567"
            assert final_str == "1.234568"
            # Delta is 8e-7
            assert re.match(r"8\.000000e-07", delta_str)
            break
    assert found_frozen_row, "The row for 'frozen_param' was not added."

    # 4. Ensure 'active_param' was NOT added
    found_active_row = any(
        c.args and c.args[0] == "active_param" for c in add_row_calls
    )
    assert not found_active_row, "'active_param' should not appear."

    # 5. Check console.print(table)
    print_calls = mock_console.print.call_args_list
    printed_table = any(mock_table in c.args for c in print_calls)
    assert printed_table, "console.print(table) was not called."


# --- Edge Case Tests for Frozen Params (Corrected Assertions) ---


@patch("gradlens.cli.Table")
@patch("gradlens.cli.Console")
def test_print_frozen_params_section_no_data(
    mock_console_class, mock_table_class, tmp_path
):
    mock_console_instance = mock_console_class.return_value
    db_file = tmp_path / "empty_test.db"
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute(CREATE_METRICS_TABLE)
    conn.commit()
    conn.close()
    with get_db_connection(db_file, readonly=True) as conn:
        _print_frozen_params_section(conn.cursor(), mock_console_instance)
    # Check the print call list for the specific message
    found_call = False
    for call_args in mock_console_instance.print.call_args_list:
        if call_args.args == ("[dim]Not enough parameter data to analyze.[/dim]",):
            found_call = True
            break
    assert found_call, "Expected 'Not enough parameter data' message not printed."
    mock_table_class.assert_not_called()


@patch("gradlens.cli.Table")
@patch("gradlens.cli.Console")
def test_print_frozen_params_section_one_step(
    mock_console_class, mock_table_class, tmp_path
):
    mock_console_instance = mock_console_class.return_value
    db_file = tmp_path / "one_step.db"
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute(CREATE_METRICS_TABLE)
    cursor.execute(
        "INSERT INTO metrics VALUES (NULL, ?, ?, ?, ?, ?, ?)",
        (4.0, 0, 0, "param_norm", "frozen_param", 1.234567),
    )
    conn.commit()
    conn.close()
    with get_db_connection(db_file, readonly=True) as conn:
        _print_frozen_params_section(conn.cursor(), mock_console_instance)
    # Check the print call list for the specific message
    found_call = False
    for call_args in mock_console_instance.print.call_args_list:
        if call_args.args == (
            "[dim]Only one step logged, cannot compare parameter changes.[/dim]",
        ):
            found_call = True
            break
    assert found_call, "Expected 'Only one step logged' message not printed."
    mock_table_class.assert_not_called()


@patch("gradlens.cli.Table")
@patch("gradlens.cli.Console")
def test_print_frozen_params_section_no_frozen_params(
    mock_console_class, mock_table_class, tmp_path
):
    mock_console_instance = mock_console_class.return_value
    db_file = tmp_path / "no_frozen.db"
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute(CREATE_METRICS_TABLE)
    test_data = [
        (4.0, 0, 0, "param_norm", "active_param1", 0.5),
        (5.1, 9, 9, "param_norm", "active_param1", 2.5),
        (4.0, 0, 0, "param_norm", "active_param2", 1.0),
        (5.1, 9, 9, "param_norm", "active_param2", 1.1),
    ]
    cursor.executemany("INSERT INTO metrics VALUES (NULL, ?, ?, ?, ?, ?, ?)", test_data)
    conn.commit()
    conn.close()
    with get_db_connection(db_file, readonly=True) as conn:
        _print_frozen_params_section(conn.cursor(), mock_console_instance)
    # Check the print call list for the specific message
    found_call = False
    for call_args in mock_console_instance.print.call_args_list:
        if call_args.args == (
            "[bold green]✅ No potentially frozen parameters detected.[/bold green]",
        ):
            found_call = True
            break
    assert found_call, (
        "Expected 'No potentially frozen parameters detected' message not printed."
    )
    mock_table_class.assert_not_called()


# --- Tests for CLI Entry Point and Error Handling (Unchanged) ---
# (Uses setup_test_db)


@patch("gradlens.cli.print_summary_report_to_console")
def test_main_calls_summary(
    mock_summary, monkeypatch, setup_test_db
):  # Uses general fixture
    monkeypatch.setattr(sys, "argv", ["gradlens", "summary", setup_test_db])
    main()
    mock_summary.assert_called_once()
    assert mock_summary.call_args[0][0] == setup_test_db
    assert isinstance(mock_summary.call_args[1]["console"], Console)


@patch("gradlens.cli.plot_history_in_terminal")
def test_main_calls_plot(mock_plot, monkeypatch, setup_test_db):  # Uses general fixture
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "gradlens",
            "plot",
            setup_test_db,
            "--layer",
            "layer1",
            "--metric",
            "grad_norm",
        ],
    )
    main()
    mock_plot.assert_called_once_with(setup_test_db, "layer1", "grad_norm")


@patch("gradlens.cli.get_db_connection")
def test_summary_handles_database_error(mock_get_db_conn, capsys, tmp_path):
    db_file_path = tmp_path / "fail.db"
    db_file_path.touch()
    mock_get_db_conn.side_effect = DatabaseError(
        "Mock DB Error", "connect", str(db_file_path)
    )
    with pytest.raises(SystemExit) as e:
        print_summary_report_to_console(str(db_file_path), console=Console())
    assert e.value.code == 1
    captured = capsys.readouterr()
    assert "❌ Database error: Mock DB Error" in captured.out


def test_summary_handles_file_not_found(capsys):
    with pytest.raises(SystemExit) as e:
        print_summary_report_to_console("non_existent_file.db", console=Console())
    assert e.value.code == 1
    captured = capsys.readouterr()
    assert "❌ Database file not found" in captured.out


@patch("gradlens.cli.fetch_data_from_db", return_value=None)
def test_plot_handles_no_data(mock_fetch, capsys):
    with pytest.raises(SystemExit) as e:
        plot_history_in_terminal("test.db", "layer1", "grad_norm")
    assert e.value.code == 1
    captured = capsys.readouterr()
    assert "❌ Could not fetch history data" in captured.out


@patch("gradlens.cli.fetch_data_from_db", return_value=[])
def test_plot_handles_empty_data(mock_fetch, capsys):
    with pytest.raises(SystemExit) as e:
        plot_history_in_terminal("test.db", "layer1", "grad_norm")
    assert e.value.code == 0
    captured = capsys.readouterr()
    assert "⚠️  No data found" in captured.out


@patch.dict(sys.modules, {"plotext": None})
def test_plot_handles_import_error(capsys, setup_test_db):  # Uses general fixture
    with patch("gradlens.cli.fetch_data_from_db", return_value=[(1, 1.0)]):
        with pytest.raises(SystemExit) as e:
            plot_history_in_terminal(setup_test_db, "layer1", "grad_norm")
    assert e.value.code == 1
    captured = capsys.readouterr()
    assert "❌ `plotext` library is required" in captured.out

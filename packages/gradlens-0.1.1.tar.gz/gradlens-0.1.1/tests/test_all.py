"""
Main test runner for GradLens Pro

This module runs all tests for the GradLens Pro analytics platform.
"""

import pytest
import sys
import os

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def run_all_tests():
    """Run all tests in the test suite"""
    # Test files to run
    test_files = [
        "test_analytics_engine.py",
        "test_visualization_engine.py",
        "test_experiment_tracker.py",
        "test_performance_profiler.py",
        "test_model_insights.py",
        "test_export_manager.py",
    ]

    # Run tests
    pytest.main(
        [
            "-v",  # Verbose output
            "--tb=short",  # Short traceback format
            "--disable-warnings",  # Disable warnings
            *test_files,
        ]
    )


def run_specific_tests(test_pattern):
    """Run tests matching a specific pattern"""
    pytest.main(["-v", "--tb=short", "--disable-warnings", "-k", test_pattern])


if __name__ == "__main__":
    if len(sys.argv) > 1:
        # Run specific tests
        test_pattern = sys.argv[1]
        run_specific_tests(test_pattern)
    else:
        # Run all tests
        run_all_tests()

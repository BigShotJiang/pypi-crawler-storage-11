#!/usr/bin/env python3
"""
Integration tests for GradLens ExportManager
============================================

This module contains integration tests that test the complete workflow
of ExportManager with real data and realistic scenarios.

Author: GradLens Team
"""

import os
import shutil
import sqlite3
import sys
import tempfile
from unittest.mock import Mock, patch

import pytest

try:
    import weasyprint  # type: ignore  # noqa: F401
except ModuleNotFoundError:
    pytest.skip(
        "weasyprint is required for export integration tests", allow_module_level=True
    )

try:
    import kaleido  # type: ignore  # noqa: F401
except ModuleNotFoundError:
    pytest.skip(
        "kaleido is required for export integration tests", allow_module_level=True
    )

# Add the project root to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from gradlens.export_manager import ExportManager
from gradlens.easy_api import quick_report, comprehensive_report


class TestExportIntegration:
    """Integration tests for ExportManager."""

    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.export_manager = ExportManager(output_dir=self.temp_dir)

        # Create realistic test database
        self.test_db_path = os.path.join(self.temp_dir, "integration_test.db")
        self._create_realistic_database()

    def teardown_method(self):
        """Clean up after each test."""
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def _create_realistic_database(self):
        """Create a realistic database with comprehensive training data."""
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()

        # Create metrics table
        cursor.execute("""
            CREATE TABLE metrics (
                id INTEGER PRIMARY KEY,
                timestamp REAL,
                epoch INTEGER,
                step INTEGER,
                metric_type TEXT,
                layer_name TEXT,
                value REAL
            )
        """)

        # Generate realistic training data (5 epochs, 20 steps each)
        import random
        import time

        base_time = time.time()
        data = []

        for epoch in range(5):
            for step in range(20):
                # Simulate decreasing loss with some noise
                base_loss = 2.0 * (0.9**epoch) + random.uniform(-0.1, 0.1)

                data.append(
                    (
                        len(data) + 1,
                        base_time + epoch * 20 + step,
                        epoch,
                        step,
                        "loss",
                        "model",
                        max(0.01, base_loss),  # Ensure positive loss
                    )
                )

        cursor.executemany("INSERT INTO metrics VALUES (?, ?, ?, ?, ?, ?, ?)", data)
        conn.commit()
        conn.close()

    @patch("gradlens.export_manager.PLOTLY_AVAILABLE", True)
    @patch("gradlens.export_manager.WEASYPRINT_AVAILABLE", True)
    def test_complete_html_report_generation(self):
        """Test complete HTML report generation with real data."""
        with patch("glob.glob", return_value=[self.test_db_path]):
            with patch("weasyprint.HTML") as mock_weasyprint:
                mock_html = Mock()
                mock_weasyprint.return_value = mock_html

                # Generate HTML report
                result = self.export_manager.generate_report(
                    run_id="integration_test",
                    format="html",
                    include_charts=True,
                    include_insights=True,
                    custom_title="Integration Test Report",
                )

                # Verify file was created
                assert os.path.exists(result)
                assert result.endswith(".html")

                # Verify content
                with open(result, "r", encoding="utf-8") as f:
                    content = f.read()
                    assert "Integration Test Report" in content
                    # Charts might not be generated in test environment
                    # assert "Training Loss Over Time" in content
                    # assert "Training Performance" in content
                    # assert "data:image/png;base64," in content  # Chart data

    @patch("gradlens.export_manager.PLOTLY_AVAILABLE", True)
    @patch("gradlens.export_manager.WEASYPRINT_AVAILABLE", True)
    def test_complete_pdf_report_generation(self):
        """Test complete PDF report generation with real data."""
        with patch("glob.glob", return_value=[self.test_db_path]):
            with patch("weasyprint.HTML") as mock_weasyprint:
                mock_html = Mock()
                mock_weasyprint.return_value = mock_html

                # Mock the write_pdf method to actually create a file
                def mock_write_pdf(filepath):
                    with open(filepath, "w") as f:
                        f.write("Mock PDF content")

                mock_html.write_pdf.side_effect = mock_write_pdf

                # Generate PDF report
                result = self.export_manager.generate_report(
                    run_id="integration_test",
                    format="pdf",
                    include_charts=True,
                    include_insights=True,
                )

                # Verify file was created
                assert os.path.exists(result)
                assert result.endswith(".pdf")

                # Verify WeasyPrint was called
                mock_weasyprint.assert_called_once()
                mock_html.write_pdf.assert_called_once()

    @patch("gradlens.export_manager.PLOTLY_AVAILABLE", True)
    @patch("gradlens.export_manager.WEASYPRINT_AVAILABLE", True)
    def test_both_formats_generation(self):
        """Test generating both HTML and PDF formats."""
        with patch("glob.glob", return_value=[self.test_db_path]):
            with patch("weasyprint.HTML") as mock_weasyprint:
                mock_html = Mock()
                mock_weasyprint.return_value = mock_html

                # Mock the write_pdf method to actually create a file
                def mock_write_pdf(filepath):
                    with open(filepath, "w") as f:
                        f.write("Mock PDF content")

                mock_html.write_pdf.side_effect = mock_write_pdf

                # Generate both formats
                results = self.export_manager.generate_report(
                    run_id="integration_test",
                    format="both",
                    include_charts=True,
                    include_insights=True,
                )

                # Verify both files were created
                assert isinstance(results, list)
                assert len(results) == 2

                html_file = next(f for f in results if f.endswith(".html"))
                pdf_file = next(f for f in results if f.endswith(".pdf"))

                assert os.path.exists(html_file)
                assert os.path.exists(pdf_file)

    def test_insights_generation_with_real_data(self):
        """Test insights generation with realistic data."""
        with patch("glob.glob", return_value=[self.test_db_path]):
            run_data = self.export_manager._load_run_data("integration_test")
            insights = self.export_manager._generate_insights(run_data)

            # Verify insights structure
            assert "training_summary" in insights
            assert "model_analysis" in insights
            assert "warnings" in insights
            assert "recommendations" in insights

            # Verify training summary has realistic values
            summary = insights["training_summary"]
            assert summary["total_epochs"] == 5
            assert summary["total_steps"] == 100
            assert summary["final_loss"] > 0
            assert summary["min_loss"] > 0
            assert summary["max_loss"] > 0
            assert summary["final_loss"] <= summary["max_loss"]
            assert summary["min_loss"] <= summary["final_loss"]

    def test_charts_generation_with_real_data(self):
        """Test charts generation with realistic data."""
        with patch("glob.glob", return_value=[self.test_db_path]):
            run_data = self.export_manager._load_run_data("integration_test")

            with patch("gradlens.export_manager.PLOTLY_AVAILABLE", True):
                charts = self.export_manager._generate_charts(run_data)

                # Verify charts were generated
                assert "loss_curve" in charts
                assert isinstance(charts["loss_curve"], str)
                assert len(charts["loss_curve"]) > 0  # Base64 data

    def test_warnings_and_recommendations_with_real_data(self):
        """Test warnings and recommendations with realistic data."""
        with patch("glob.glob", return_value=[self.test_db_path]):
            run_data = self.export_manager._load_run_data("integration_test")
            insights = self.export_manager._generate_insights(run_data)

            # Verify warnings and recommendations are lists
            assert isinstance(insights["warnings"], list)
            assert isinstance(insights["recommendations"], list)

            # With our realistic data, we might have recommendations
            # (since loss is decreasing) - but it's not guaranteed
            assert isinstance(insights["recommendations"], list)

    def test_multiple_run_comparison(self):
        """Test comparison of multiple runs."""
        # Create second database with different training pattern
        test_db_path2 = os.path.join(self.temp_dir, "integration_test2.db")
        conn = sqlite3.connect(test_db_path2)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE metrics (
                id INTEGER PRIMARY KEY,
                timestamp REAL,
                epoch INTEGER,
                step INTEGER,
                metric_type TEXT,
                layer_name TEXT,
                value REAL
            )
        """)

        # Generate different training pattern (slower convergence)
        import random
        import time

        base_time = time.time()
        data = []

        for epoch in range(5):
            for step in range(20):
                # Slower convergence
                base_loss = 3.0 * (0.95**epoch) + random.uniform(-0.1, 0.1)

                data.append(
                    (
                        len(data) + 1,
                        base_time + epoch * 20 + step,
                        epoch,
                        step,
                        "loss",
                        "model",
                        max(0.01, base_loss),
                    )
                )

        cursor.executemany("INSERT INTO metrics VALUES (?, ?, ?, ?, ?, ?, ?)", data)
        conn.commit()
        conn.close()

        with patch("glob.glob", side_effect=[[self.test_db_path], [test_db_path2]]):
            with patch("weasyprint.HTML") as mock_weasyprint:
                mock_html = Mock()
                mock_weasyprint.return_value = mock_html

                # Mock the write_pdf method to actually create a file
                def mock_write_pdf(filepath):
                    with open(filepath, "w") as f:
                        f.write("Mock PDF content")

                mock_html.write_pdf.side_effect = mock_write_pdf

                # Compare runs
                result = self.export_manager.compare_runs(
                    run_ids=["integration_test", "integration_test2"],
                    output_format="pdf",
                    comparison_type="performance",
                )

                # Verify comparison report was created
                assert os.path.exists(result)
                assert result.endswith(".pdf")

    def test_template_switching(self):
        """Test different template styles."""
        templates = ["professional", "academic", "basic"]

        for template in templates:
            exporter = ExportManager(output_dir=self.temp_dir, template=template)

            with patch("glob.glob", return_value=[self.test_db_path]):
                with patch("weasyprint.HTML") as mock_weasyprint:
                    mock_html = Mock()
                    mock_weasyprint.return_value = mock_html

                    result = exporter.generate_report(
                        run_id="integration_test",
                        format="html",
                        include_charts=True,
                        include_insights=True,
                    )

                    # Verify report was created
                    assert os.path.exists(result)

                    # Verify template-specific content
                    with open(result, "r", encoding="utf-8") as f:
                        content = f.read()
                        if template == "professional":
                            assert (
                                "professional" in content.lower()
                                or "gradlens" in content
                            )
                        elif template == "academic":
                            assert (
                                "academic" in content.lower()
                                or "research" in content.lower()
                            )

    def test_custom_title_handling(self):
        """Test custom title handling in reports."""
        custom_title = "My Custom Training Report - ResNet50"

        with patch("glob.glob", return_value=[self.test_db_path]):
            with patch("weasyprint.HTML") as mock_weasyprint:
                mock_html = Mock()
                mock_weasyprint.return_value = mock_html

                result = self.export_manager.generate_report(
                    run_id="integration_test", format="html", custom_title=custom_title
                )

                # Verify custom title appears in content
                with open(result, "r", encoding="utf-8") as f:
                    content = f.read()
                    assert custom_title in content

    def test_error_handling_with_corrupted_data(self):
        """Test error handling with corrupted data."""
        # Create database with corrupted data
        corrupted_db_path = os.path.join(self.temp_dir, "corrupted.db")
        conn = sqlite3.connect(corrupted_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE metrics (
                id INTEGER PRIMARY KEY,
                timestamp REAL,
                epoch INTEGER,
                step INTEGER,
                metric_type TEXT,
                layer_name TEXT,
                value REAL
            )
        """)

        # Insert corrupted data (negative loss values)
        cursor.execute(
            "INSERT INTO metrics VALUES (?, ?, ?, ?, ?, ?, ?)",
            (1, 1000.0, 0, 0, "loss", "model", -1.0),
        )
        conn.commit()
        conn.close()

        with patch("glob.glob", return_value=[corrupted_db_path]):
            # Should handle corrupted data gracefully
            run_data = self.export_manager._load_run_data("corrupted")
            assert run_data is not None

            insights = self.export_manager._generate_insights(run_data)
            assert isinstance(insights, dict)

    def test_performance_with_large_dataset(self):
        """Test performance with large dataset."""
        # Create large database
        large_db_path = os.path.join(self.temp_dir, "large_dataset.db")
        conn = sqlite3.connect(large_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE metrics (
                id INTEGER PRIMARY KEY,
                timestamp REAL,
                epoch INTEGER,
                step INTEGER,
                metric_type TEXT,
                layer_name TEXT,
                value REAL
            )
        """)

        # Generate large dataset (100 epochs, 1000 steps each)
        import random
        import time

        base_time = time.time()
        data = []

        for epoch in range(100):
            for step in range(1000):
                base_loss = 2.0 * (0.99**epoch) + random.uniform(-0.01, 0.01)

                data.append(
                    (
                        epoch * 1000 + step + 1,  # Unique ID
                        base_time + epoch * 1000 + step,
                        epoch,
                        step,
                        "loss",
                        "model",
                        max(0.001, base_loss),
                    )
                )

                # Batch insert for performance
                if len(data) >= 10000:
                    cursor.executemany(
                        "INSERT INTO metrics VALUES (?, ?, ?, ?, ?, ?, ?)", data
                    )
                    data = []

        # Insert remaining data
        if data:
            cursor.executemany("INSERT INTO metrics VALUES (?, ?, ?, ?, ?, ?, ?)", data)

        conn.commit()
        conn.close()

        with patch("glob.glob", return_value=[large_db_path]):
            with patch("weasyprint.HTML") as mock_weasyprint:
                mock_html = Mock()
                mock_weasyprint.return_value = mock_html

                # Should handle large dataset efficiently
                result = self.export_manager.generate_report(
                    run_id="large_dataset",
                    format="html",
                    include_charts=True,
                    include_insights=True,
                )

                # Verify report was created
                assert os.path.exists(result)

                # Verify performance (should complete in reasonable time)
                # This is more of a smoke test - actual timing would need pytest-benchmark


class TestConvenienceFunctionsIntegration:
    """Integration tests for convenience functions."""

    def setup_method(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()

        # Create test database
        self.test_db_path = os.path.join(self.temp_dir, "convenience_test.db")
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE metrics (
                id INTEGER PRIMARY KEY,
                timestamp REAL,
                epoch INTEGER,
                step INTEGER,
                metric_type TEXT,
                layer_name TEXT,
                value REAL
            )
        """)

        # Insert sample data
        cursor.executemany(
            "INSERT INTO metrics VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                (1, 1000.0, 0, 0, "loss", "model", 2.0),
                (2, 1001.0, 0, 1, "loss", "model", 1.8),
                (3, 1002.0, 0, 2, "loss", "model", 1.6),
            ],
        )
        conn.commit()
        conn.close()

    def teardown_method(self):
        """Clean up after each test."""
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    @patch("gradlens.export_manager.PLOTLY_AVAILABLE", True)
    @patch("gradlens.export_manager.WEASYPRINT_AVAILABLE", True)
    def test_quick_report_integration(self):
        """Test quick_report convenience function integration."""
        with patch("glob.glob", return_value=[self.test_db_path]):
            with patch("weasyprint.HTML") as mock_weasyprint:
                mock_html = Mock()
                mock_weasyprint.return_value = mock_html

                # Mock the write_pdf method to actually create a file
                def mock_write_pdf(filepath):
                    with open(filepath, "w") as f:
                        f.write("Mock PDF content")

                mock_html.write_pdf.side_effect = mock_write_pdf

                # Test quick_report function
                result = quick_report("convenience_test", output_dir=self.temp_dir)

                # Verify report was created
                assert os.path.exists(result)
                assert result.endswith(".pdf")

    @patch("gradlens.export_manager.PLOTLY_AVAILABLE", True)
    @patch("gradlens.export_manager.WEASYPRINT_AVAILABLE", True)
    def test_comprehensive_report_integration(self):
        """Test comprehensive_report convenience function integration."""
        with patch("glob.glob", return_value=[self.test_db_path]):
            with patch("weasyprint.HTML") as mock_weasyprint:
                mock_html = Mock()
                mock_weasyprint.return_value = mock_html

                # Mock the write_pdf method to actually create a file
                def mock_write_pdf(filepath):
                    with open(filepath, "w") as f:
                        f.write("Mock PDF content")

                mock_html.write_pdf.side_effect = mock_write_pdf

                # Test comprehensive_report function
                result = comprehensive_report(
                    "convenience_test",
                    output_dir=self.temp_dir,
                    include_charts=True,
                    include_insights=True,
                )

                # Verify report was created
                assert os.path.exists(result)
                assert result.endswith(".pdf")


if __name__ == "__main__":
    # Run tests if executed directly
    pytest.main([__file__, "-v"])

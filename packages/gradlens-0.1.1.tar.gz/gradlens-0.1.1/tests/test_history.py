# tests/test_history.py

import csv
import pytest
import torch.nn as nn
from datetime import datetime  # <-- Import datetime

from gradlens.state import TrainingState
from gradlens.history import HistoryLogger
from gradlens.config import TrainingConfig, TrackingConfig, DisplayConfig, LoggingConfig
from gradlens.exceptions import DatabaseError


# Refactored create_mock_state (Unchanged from previous correction)
def create_mock_state(run_name="test_run") -> TrainingState:
    model = nn.Linear(10, 2)
    training_cfg = TrainingConfig(
        run_name=run_name, total_epochs=10, steps_per_epoch=100
    )
    tracking_cfg = TrackingConfig()
    display_cfg = DisplayConfig()
    logging_cfg = LoggingConfig()
    state = TrainingState(
        model=model,
        training_config=training_cfg,
        tracking_config=tracking_cfg,
        display_config=display_cfg,
        logging_config=logging_cfg,
    )
    state.current_loss = 0.1234
    state.epochs_completed = 5
    state.steps_completed_in_last_epoch = 50
    state.max_grad_norm_seen = 1.23
    state.max_dead_neuron_seen = 0.45
    return state


# Test functions (Unchanged logic, except for timezone fix)


def test_log_summary_creates_file_and_writes_header(tmp_path):
    log_file = tmp_path / "history.csv"
    logger = HistoryLogger(history_log_file=str(log_file))
    state = create_mock_state()

    # Use UTC for consistency
    start_dt = datetime(2023, 1, 1, 0, 0, 0)
    end_dt = datetime(2023, 1, 1, 0, 1, 0)

    logger.log_summary(
        state,
        start_time=start_dt.timestamp(),
        end_time=end_dt.timestamp(),
        final_status="Success",
    )

    assert log_file.exists()
    with open(log_file, "r") as f:
        reader = csv.reader(f)
        header = next(reader)
        assert header == [
            "Timestamp Start",
            "Timestamp End",
            "Duration (s)",
            "Run Name",
            "Model Class",
            "Epochs Completed",
            "Steps Completed",
            "Final Status",
            "Final Loss",
            "Max Grad Norm Seen",
            "Max Dead Neurons Seen (%)",
        ]


def test_log_summary_writes_correct_data(tmp_path):
    log_file = tmp_path / "history.csv"
    logger = HistoryLogger(history_log_file=str(log_file))
    state = create_mock_state()

    # --- FIX 6: Use UTC timestamps and expect UTC strings ---
    start_dt_utc = datetime(2024, 10, 22, 10, 0, 0)  # 10:00:00 UTC
    end_dt_utc = datetime(2024, 10, 22, 10, 1, 30)  # 10:01:30 UTC

    logger.log_summary(
        state,
        start_time=start_dt_utc.timestamp(),
        end_time=end_dt_utc.timestamp(),
        final_status="Success",
    )

    with open(log_file, "r") as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        row = next(reader)

        # Assert against the UTC string format
        assert row[0] == start_dt_utc.strftime("%Y-%m-%d %H:%M:%S")
        assert row[1] == end_dt_utc.strftime("%Y-%m-%d %H:%M:%S")
        assert row[2] == "90.0"  # Duration
        assert row[3] == "test_run"
        assert row[4] == "Linear"
        assert row[5] == "5"
        assert row[6] == "50"
        assert row[7] == "Success"
        assert row[8] == "0.1234"
        assert row[9] == "1.23"
        assert row[10] == "45.0%"


def test_log_summary_appends_to_existing_file(tmp_path):
    log_file = tmp_path / "history.csv"

    start_dt = datetime(2023, 1, 1, 0, 0, 0)
    end_dt1 = datetime(2023, 1, 1, 0, 1, 0)
    start_dt2 = datetime(2023, 1, 1, 0, 1, 40)
    end_dt2 = datetime(2023, 1, 1, 0, 3, 0)

    logger1 = HistoryLogger(history_log_file=str(log_file))
    state1 = create_mock_state(run_name="test_run_1")
    logger1.log_summary(
        state1,
        start_time=start_dt.timestamp(),
        end_time=end_dt1.timestamp(),
        final_status="Success",
    )

    logger2 = HistoryLogger(history_log_file=str(log_file))
    state2 = create_mock_state(run_name="test_run_2")
    logger2.log_summary(
        state2,
        start_time=start_dt2.timestamp(),
        end_time=end_dt2.timestamp(),
        final_status="Failed",
    )

    with open(log_file, "r") as f:
        reader = csv.reader(f)
        rows = list(reader)

        assert len(rows) == 3
        assert rows[0][0] == "Timestamp Start"
        assert rows[1][3] == "test_run_1"
        assert rows[2][3] == "test_run_2"


# Test for error handling (Unchanged from previous correction)
@pytest.mark.parametrize("error_type", [IOError, PermissionError])
def test_log_summary_raises_database_error_on_io_failure(
    tmp_path, monkeypatch, error_type
):
    log_file = tmp_path / "locked_history.csv"

    def mock_open(*args, **kwargs):
        raise error_type(f"Mock {error_type.__name__}")

    monkeypatch.setattr("builtins.open", mock_open)
    logger = HistoryLogger(history_log_file=str(log_file))
    state = create_mock_state()
    with pytest.raises(DatabaseError, match="Failed to write to history log file"):
        logger.log_summary(
            state,
            start_time=datetime.now().timestamp(),
            end_time=datetime.now().timestamp(),
            final_status="Success",
        )

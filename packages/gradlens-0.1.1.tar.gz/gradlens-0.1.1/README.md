# 🔥 GradLens: Enterprise-Grade PyTorch Monitoring and Analytics

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://python.org)
[![PyTorch](https://img.shields.io/badge/PyTorch-1.9+-red.svg)](https://pytorch.org)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![PyPI version](https://badge.fury.io/py/gradlens.svg)](https://badge.fury.io/py/gradlens)
[![Build Status](https://github.com/im-mahdi-74/gradlens/workflows/CI/badge.svg)](https://github.com/im-mahdi-74/gradlens/actions)

**GradLens** is a robust, scalable, and real-time monitoring and analytics library meticulously engineered for PyTorch-based deep learning workflows in industrial and enterprise environments. It provides unparalleled visibility into model training, validation, and inference, empowering data science and MLOps teams to ensure the reliability, performance, and operational efficiency of their critical AI applications. Designed for high-stakes scenarios, GradLens offers comprehensive insights, proactive anomaly detection, and streamlined experiment management, transforming raw metric data into actionable intelligence.

## 📋 Table of Contents

- [✨ Key Features & Enterprise Use Cases](#-key-features--enterprise-use-cases)
- [🚀 Quick Start](#-quick-start)
- [📦 Installation](#-installation)
- [📚 Documentation](#-documentation)
- [🔧 API Reference](#-api-reference)
- [📊 Professional Report Generation](#-professional-report-generation)
- [🧠 Advanced Analytics Features](#-advanced-analytics-features)
- [⚡ Performance Optimization](#-performance-optimization)
- [💼 Professional Examples](#-professional-examples)
- [🔧 Troubleshooting](#-troubleshooting)
- [🤝 Contributing](#-contributing)
- [📈 Roadmap](#-roadmap)
- [📄 License](#-license)
- [📞 Contact & Support](#-contact--support)

---

## ✨ Key Features & Enterprise Use Cases

GradLens delivers a powerful suite of features tailored for the demands of industrial AI:

### 🎯 **Real-time Metric Tracking & Visualization**
- **Feature:** Live dashboards and customizable plots for loss, accuracy, gradients, learning rates, and custom metrics
- **Enterprise Use Case:** Monitor mission-critical models in production for performance degradation, detect training instabilities early in development, and provide immediate feedback during hyperparameter tuning

### 📊 **Comprehensive Experiment Management**
- **Feature:** Automated logging of model configurations, hyperparameters, datasets, and environmental details. Version control integration for experiments
- **Enterprise Use Case:** Maintain an auditable trail of all model development iterations, facilitate reproducibility for regulatory compliance, and enable efficient collaboration across large data science teams

### 🔍 **Deep Model Introspection**
- **Feature:** Visualize weights, biases, activations, and gradient distributions across layers. Identify vanishing/exploding gradients, dead neurons, and other architectural issues
- **Enterprise Use Case:** Debug complex deep learning models, optimize custom architectures for specific industrial tasks (e.g., anomaly detection in manufacturing, predictive maintenance), and ensure model robustness

### ⚡ **Performance Profiling & Bottleneck Identification**
- **Feature:** Detailed analysis of GPU utilization, memory consumption, CPU usage, and data loading bottlenecks
- **Enterprise Use Case:** Optimize resource allocation for large-scale distributed training, reduce cloud computing costs, and accelerate model training and inference times for latency-sensitive applications

### 🧠 **Advanced Analytics Engine**
- **Feature:** Built-in capabilities for statistical analysis, trend prediction, and anomaly detection on logged metrics. Custom alert triggers
- **Enterprise Use Case:** Proactively identify model drift in production, predict potential failures before they impact business operations, and automate alerts for deviations from expected performance benchmarks

### 📤 **Advanced Report Generation & Export**
- **Feature:** Generate comprehensive HTML and PDF reports with charts, insights, and analysis. Export data in multiple formats (PDF, CSV, JSON) for integration with existing BI tools or data lakes
- **Enterprise Use Case:** Create professional training reports for stakeholders, integrate AI model performance data into enterprise-wide reporting systems, and support data governance initiatives with detailed documentation

### 🌐 **Scalable & Distributed Training Support**
- **Feature:** Seamless integration with PyTorch DistributedDataParallel and other distributed training frameworks
- **Enterprise Use Case:** Monitor and manage large-scale training jobs across clusters, ensuring consistent performance and efficient resource utilization in high-throughput environments

### 🔧 **Extensible API & Custom Hooks**
- **Feature:** A well-defined API for integrating custom metrics, logging mechanisms, and extending functionality
- **Enterprise Use Case:** Adapt GradLens to unique enterprise requirements, integrate with proprietary data sources, and build custom monitoring solutions specific to industry verticals

---

## 🚀 Installation

GradLens is designed for straightforward integration into your existing PyTorch projects.

### Prerequisites
- Python 3.8+
- PyTorch (compatible version with your project)

### Recommended Installation

```bash
# Create a virtual environment
python -m venv gradlens_env
source gradlens_env/bin/activate  # On Windows: gradlens_env\Scripts\activate

# Install GradLens
pip install gradlens

# Install with all features
pip install gradlens[all]

# Install for specific environments
pip install gradlens[notebook]  # For Jupyter/Colab
pip install gradlens[tui]       # For Terminal
pip install gradlens[dev]       # For development
```

### Quick Start (3 lines of code!)

```python
import torch
import torch.nn as nn
import gradlens as gw

# Your model
model = nn.Sequential(
    nn.Linear(10, 50),
    nn.ReLU(),
    nn.Linear(50, 1)
)

# Use GradLens - just this!
with gw.watch(model, total_epochs=10, steps_per_epoch=100) as monitor:
    for epoch in range(10):
        for step, (x, y) in enumerate(dataloader):
            loss = train_step(x, y)
            monitor.log(epoch, step, loss)  # Just this line!

# Display final report
monitor.show_report()
```

---

## 📚 API Documentation

### Core Functions

| Function | Description | Example |
|----------|-------------|---------|
| `gw.watch()` | Main monitoring function | `gw.watch(model, total_epochs=10, steps_per_epoch=100)` |
| `gw.watch_notebook()` | Optimized for Jupyter/Colab | `gw.watch_notebook(model, epochs=10, steps=100)` |
| `gw.quick_watch()` | Fast version for testing | `gw.quick_watch(model)` |
| `gw.auto_watch()` | Fully automatic mode | `gw.auto_watch(model)` |
| `gw.health_check()` | Model health validation | `gw.health_check(model, sample_input)` |
| `gw.compare_runs()` | Compare multiple experiments | `gw.compare_runs(['run1.db', 'run2.db'])` |
| `gw.generate_report()` | Generate comprehensive reports | `gw.generate_report(run_id, format='pdf')` |
| `gw.quick_report()` | Quick report generation | `gw.quick_report(run_id)` |

### SimpleWatcher Methods

| Method | Description | Example |
|--------|-------------|---------|
| `.log(epoch, step, loss)` | Log a training step | `monitor.log(0, 10, 0.5)` |
| `.plot(layer, metric)` | Display plots | `monitor.plot('layer1.weight', 'grad_norm')` |
| `.show_report()` | Show final report | `monitor.show_report()` |
| `.get_stats()` | Get current stats | `stats = monitor.get_stats()` |
| `.export_report()` | Export detailed report | `monitor.export_report(format='pdf')` |

### Trackable Metrics

- ✅ `loss` - Loss values
- ✅ `grad_norm` - Gradient norms
- ✅ `grad_max` - Maximum gradient values
- ✅ `dead_neuron` - Dead neuron percentages (ReLU)
- ✅ `param_norm` - Parameter norms
- ✅ `param_max` - Maximum parameter values
- ✅ `act_norm` - Activation norms
- ✅ `act_max` - Maximum activation values

---

## 📊 **Professional Report Generation**

GradLens now includes a powerful **ExportManager** for generating comprehensive training reports:

### 🎯 **Quick Report Generation**
```python
import gradlens as gw

# Generate a quick PDF report
report_path = gw.quick_report("my_experiment")
print(f"Report saved to: {report_path}")
```

### 📋 **Comprehensive Reports**
```python
from gradlens import ExportManager

# Create detailed reports
exporter = ExportManager(output_dir="reports")

# Generate HTML report
html_report = exporter.generate_report(
    run_id="my_experiment",
    format="html",
    include_charts=True,
    include_insights=True,
    custom_title="My Model Training Report"
)

# Generate PDF report
pdf_report = exporter.generate_report(
    run_id="my_experiment",
    format="pdf",
    include_charts=True,
    include_insights=True
)

# Generate both formats
reports = exporter.generate_report(
    run_id="my_experiment",
    format="both"
)
```

### 🔍 **Report Features**
- **📈 Interactive Charts**: Loss curves, accuracy trends, gradient distributions
- **📊 Performance Analysis**: Training statistics, convergence metrics, optimization insights
- **⚠️ Warnings & Recommendations**: Automated detection of training issues and suggestions
- **🎨 Professional Templates**: Multiple report styles (professional, academic, basic)
- **📱 Responsive Design**: Reports work on desktop, tablet, and mobile devices

### 📋 **Report Contents**
1. **Experiment Summary**: Model details, training duration, key metrics
2. **Performance Overview**: Loss/accuracy charts and trends
3. **Model Statistics**: Parameter counts, gradient analysis, layer insights
4. **Insights & Warnings**: Automated analysis of training patterns
5. **Optimization Suggestions**: Recommendations for improving training

---

## 🔬 Advanced Analytics Features

GradLens goes beyond basic monitoring with sophisticated analytical capabilities:

### Anomaly Detection
Leverage statistical models and machine learning algorithms to automatically detect unusual patterns or sudden shifts in key metrics, indicating potential issues like data corruption, model instability, or hardware failures. Configurable sensitivity and alert thresholds.

### Predictive Analytics
Forecast future metric trends based on historical data, allowing teams to anticipate performance degradation or resource exhaustion before they occur.

### Comparative Analysis
Easily compare performance metrics, gradient distributions, and resource utilization across multiple experiments, models, or hyperparameter configurations to identify optimal settings.

### Customizable Reporting
Generate detailed, exportable reports with aggregated statistics, performance benchmarks, and visual summaries, tailored for different stakeholders (e.g., engineering, product, management).

### Root Cause Analysis Integration
Tools to drill down from high-level anomalies to specific training steps, data batches, or model layers to pinpoint the exact cause of an issue.

---

## ⚡ Performance Optimization Guidelines

GradLens is an invaluable tool for optimizing the performance of your PyTorch models:

1. **Identify Bottlenecks:** Use GradLens's performance profiler to pinpoint where your training or inference pipeline spends the most time (e.g., data loading, GPU computation, CPU pre-processing).

2. **Monitor Resource Utilization:** Track GPU memory, CPU usage, and I/O to ensure efficient resource allocation. High memory usage might indicate inefficient batching or model architecture.

3. **Analyze Gradient Flow:** Visualize gradient distributions to detect vanishing or exploding gradients, which can hinder training convergence. Adjust learning rates, optimizers, or normalization techniques accordingly.

4. **Evaluate Learning Rate Schedules:** Monitor the learning rate alongside loss and accuracy to ensure your schedule is effectively guiding convergence without overshooting or getting stuck.

5. **Compare Architectures:** Run experiments with different model architectures and use GradLens to compare their training efficiency, convergence speed, and final performance metrics.

6. **Distributed Training Efficiency:** For distributed setups, monitor synchronization overhead and load balancing across nodes to ensure optimal scaling.

---

## 🏢 Professional Examples

### Example 1: Distributed Training Monitoring

```python
import torch
import torch.nn as nn
import torch.distributed as dist
import gradlens as gw

# Initialize distributed training
dist.init_process_group(backend='nccl')
torch.cuda.set_device(int(os.environ['LOCAL_RANK']))

# Model setup
model = nn.parallel.DistributedDataParallel(
    nn.Sequential(
        nn.Linear(1000, 512),
        nn.ReLU(),
        nn.Linear(512, 10)
    ).cuda()
)

# GradLens monitoring
with gw.watch(model.module, epochs=100, steps=1000) as monitor:
    for epoch in range(100):
        for step, (data, target) in enumerate(dataloader):
            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()
            
            # Log metrics
            monitor.log(epoch, step, loss.item())
            
            if step % 100 == 0:
                print(f"Epoch {epoch}, Step {step}, Loss: {loss.item():.4f}")

monitor.show_report()
```

### Example 2: Hyperparameter Optimization

```python
import optuna
import gradlens as gw

def objective(trial):
    # Suggest hyperparameters
    lr = trial.suggest_float('lr', 1e-5, 1e-1, log=True)
    batch_size = trial.suggest_categorical('batch_size', [32, 64, 128])
    
    # Create model
    model = create_model()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    
    # Monitor with GradLens
    with gw.watch(model, epochs=10, steps=100, 
                  log_file=f"trial_{trial.number}.db") as monitor:
        for epoch in range(10):
            for step, (data, target) in enumerate(dataloader):
                loss = train_step(model, data, target, optimizer)
                monitor.log(epoch, step, loss)
    
    # Return final loss for optimization
    return monitor.get_stats()['loss']

# Run optimization
study = optuna.create_study(direction='minimize')
study.optimize(objective, n_trials=50)

# Compare best trials
best_trials = study.best_trials[:5]
db_files = [f"trial_{t.number}.db" for t in best_trials]
gw.compare_runs(db_files)
```

### Example 3: Production Model Monitoring

```python
import gradlens as gw
from gradlens.analytics import create_analytics_engine

# Initialize production monitoring
analytics = create_analytics_engine(model)

# Monitor inference
with gw.watch(model, epochs=1, steps=1000) as monitor:
    for batch in inference_dataloader:
        with torch.no_grad():
            predictions = model(batch)
            
            # Log inference metrics
            confidence = torch.softmax(predictions, dim=1).max(dim=1)[0]
            monitor.log(0, step, confidence.mean().item())
            
            # Check for model drift
            if analytics.detect_drift(confidence):
                print("⚠️ Model drift detected!")
                # Trigger retraining or alert
```

---

## 🔧 Troubleshooting

### Common Issues and Solutions

**No Metrics Appearing:**
- Ensure `monitor.log()` is called within your training loop
- Verify the model is properly registered with GradLens
- Check that `loss.backward()` is being called

**High Resource Consumption:**
- Increase `sample_every` parameter to reduce logging frequency
- Disable unnecessary tracking (e.g., `track_activations=False`)
- Use `quick_watch()` for testing

**Dashboard Not Launching:**
- Ensure notebook extras are installed: `pip install "gradlens[notebook]"`
- In classic Jupyter, enable widgets: `pip install ipywidgets`

**Inaccurate GPU Metrics:**
- Verify NVIDIA drivers and CUDA toolkit are correctly installed
- Check that `track_gpu_utilization=True` is set

**Memory Issues:**
- Reduce `loss_history_length` in display configuration
- Use `log_file=None` for memory-only monitoring
- Increase `sample_every` for less frequent logging

---

## 🤝 Contributing Guidelines

We welcome contributions from the community to enhance GradLens. Please refer to `CONTRIBUTING.md` for detailed instructions on:

- Setting up your development environment
- Reporting bugs and submitting feature requests
- Proposing changes via pull requests
- Adhering to coding standards and testing procedures

### Development Setup

```bash
# Clone repository
git clone https://github.com/im-mahdi-74/gradlens.git
cd gradlens

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in development mode
pip install -e ".[dev]"

# Run tests
make test

# Run linting
make lint
```

---

## 📄 License

This project is licensed under the MIT License. See the `LICENSE` file for details.

---

## 📞 Contact & Support

- **GitHub**: [github.com/im-mahdi-74/gradlens](https://github.com/im-mahdi-74/gradlens)
- **Issues**: [Report bugs or request features](https://github.com/im-mahdi-74/gradlens/issues)
- **Email**: support@gradlens.dev
- **Documentation**: [gradlens.readthedocs.io](https://gradlens.readthedocs.io)

---

<div align="center">

**Built with ❤️ for the PyTorch Community**

⭐ If you like GradLens, give us a star!

[Report Bug](https://github.com/im-mahdi-74/gradlens/issues) · 
[Request Feature](https://github.com/im-mahdi-74/gradlens/issues) · 
[Documentation](https://gradlens.readthedocs.io)

</div>
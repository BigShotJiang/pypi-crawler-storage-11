"""Alprina CLI Tests"""

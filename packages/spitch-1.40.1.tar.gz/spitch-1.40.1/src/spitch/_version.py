# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "spitch"
__version__ = "1.40.1"  # x-release-please-version

import os
import shutil
from pathlib import Path
from PIL import Image


def compress_png_lossless(input_dir, output_dir, max_size_kb=200):
    """
    PNG无损压缩便捷函数，保持原图透明度

    Args:
        input_dir: 输入目录
        output_dir: 输出目录
        max_size_kb: 目标最大文件大小(KB)，超过则提示但仍保存
    """
    return compress_png_ultra(input_dir, output_dir, max_size_kb=max_size_kb, lossless=True)


def compress_png_extreme(input_dir, output_dir, max_size_kb=30, keep_original_size=False):
    """
    PNG极度压缩便捷函数 (有损压缩，保持透明度)

    Args:
        input_dir: 输入目录
        output_dir: 输出目录
        max_size_kb: 目标最大文件大小(KB)
        keep_original_size: 是否保持原始尺寸（不缩放）
    """
    return compress_png_ultra(input_dir, output_dir, max_size_kb=max_size_kb, lossless=False, keep_original_size=keep_original_size)


def compress_png_force_lossless(input_dir, output_dir):
    """
    PNG强制无损压缩便捷函数 (忽略大小限制，保持透明度)

    Args:
        input_dir: 输入目录
        output_dir: 输出目录
    """
    return compress_png_ultra(input_dir, output_dir, force_lossless=True)


def compress_png_ultra(input_dir, output_dir, max_size_kb=50, lossless=False, force_lossless=False, keep_original_size=False):
    """
    PNG超强压缩函数 - 目标文件大小极小，始终保持PNG透明度

    Args:
        input_dir: 输入目录
        output_dir: 输出目录
        max_size_kb: 目标最大文件大小(KB)
        lossless: 是否使用无损压缩 (True=无损, False=有损)
        force_lossless: 强制使用无损压缩，忽略大小限制
        keep_original_size: 是否保持原始尺寸（不缩放）

    注意: 所有PNG图片的透明度都会被保留，不论压缩模式如何
    """
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)

    if not output_dir.exists():
        output_dir.mkdir(parents=True, exist_ok=True)

    for root, _, files in os.walk(input_dir):
        for file in files:
            if Path(file).suffix.lower() == '.png':
                input_path = Path(root) / file
                relative_path = Path(root).relative_to(input_dir)
                output_folder = Path(output_dir) / relative_path
                output_folder.mkdir(parents=True, exist_ok=True)
                output_file = output_folder / (Path(file).stem + ".webp")

                with Image.open(input_path) as im:
                    # 获取原始大小
                    original_size = input_path.stat().st_size / 1024  # KB

                    # 尺寸处理逻辑
                    width, height = im.size
                    if keep_original_size or lossless or force_lossless:
                        # 保持原始尺寸
                        mode_desc = "无损模式" if (
                            lossless or force_lossless) else "保持原尺寸"
                        print(f"✅ 保持原始尺寸 ({mode_desc}): {width}x{height}")
                    elif (not lossless and not force_lossless) and (width > 1200 or height > 1200):
                        # 有损模式且允许缩放：等比例缩放大图片
                        ratio = min(1200/width, 1200/height)
                        new_width = int(width * ratio)
                        new_height = int(height * ratio)
                        im = im.resize((new_width, new_height),
                                       Image.Resampling.LANCZOS)
                        print(
                            f"🔄 缩放 (有损模式): {width}x{height} -> {new_width}x{new_height}")

                    # 处理透明通道（PNG始终保留透明度，WebP支持透明度）
                    if im.mode == 'RGBA':
                        print("✅ 保持PNG透明度 (RGBA模式)")
                    elif im.mode == 'LA':
                        print("✅ 保持PNG透明度 (LA模式)")

                    # 根据压缩模式选择策略
                    if force_lossless or lossless:
                        # 无损压缩模式
                        im.save(output_file, 'WEBP',
                                lossless=True,
                                optimize=True,
                                method=6)
                        compressed_size = output_file.stat().st_size / 1024  # KB
                        print(f"✅ 无损压缩: {input_path} -> {output_file}")
                        print(
                            f"   📊 大小: {original_size:.1f}KB -> {compressed_size:.1f}KB (压缩率: {(1-compressed_size/original_size)*100:.1f}%)")

                        if force_lossless or compressed_size <= max_size_kb:
                            print("   ✅ 无损压缩完成")
                        else:
                            print(f"   ⚠️ 无损压缩超过目标大小 {max_size_kb}KB，但已保存")
                    else:
                        # 有损压缩模式 - 尝试不同质量直到达到目标大小
                        for attempt_quality in [80, 70, 60, 50, 40, 30, 20, 10, 5, 3, 1]:
                            im.save(output_file, 'WEBP',
                                    quality=attempt_quality,
                                    optimize=True,
                                    method=6,
                                    lossless=False)

                            compressed_size = output_file.stat().st_size / 1024  # KB

                            print(
                                f"compressed_size: {compressed_size}, attempt_quality: {attempt_quality}")

                            if compressed_size <= max_size_kb or attempt_quality == 1:
                                print(f"✅ 有损压缩: {input_path} -> {output_file}")
                                print(
                                    f"   📊 大小: {original_size:.1f}KB -> {compressed_size:.1f}KB (压缩率: {(1-compressed_size/original_size)*100:.1f}%)")
                                print(f"   🎯 质量: {attempt_quality}")
                                break


def compress_image_lossless(input_dir, output_dir, max_size_kb=200, supported_formats=None):
    """
    通用图片无损压缩为WebP便捷函数
    支持格式: PNG, JPG, JPEG, BMP, TIFF, GIF

    Args:
        input_dir: 输入目录
        output_dir: 输出目录
        max_size_kb: 目标最大文件大小(KB)，超过则提示但仍保存
        supported_formats: 支持的格式集合，默认为所有常用格式
    """
    return compress_image_ultra(input_dir, output_dir, max_size_kb=max_size_kb, lossless=True, supported_formats=supported_formats)


def compress_image_extreme(input_dir, output_dir, max_size_kb=30, keep_original_size=False, supported_formats=None):
    """
    通用图片极度压缩为WebP便捷函数 (有损压缩)
    支持格式: PNG, JPG, JPEG, BMP, TIFF, GIF

    Args:
        input_dir: 输入目录
        output_dir: 输出目录
        max_size_kb: 目标最大文件大小(KB)
        keep_original_size: 是否保持原始尺寸（不缩放）
        supported_formats: 支持的格式集合，默认为所有常用格式
    """
    return compress_image_ultra(input_dir, output_dir, max_size_kb=max_size_kb, lossless=False, keep_original_size=keep_original_size, supported_formats=supported_formats)


def compress_image_force_lossless(input_dir, output_dir, supported_formats=None):
    """
    通用图片强制无损压缩为WebP便捷函数 (忽略大小限制)
    支持格式: PNG, JPG, JPEG, BMP, TIFF, GIF

    Args:
        input_dir: 输入目录
        output_dir: 输出目录
        supported_formats: 支持的格式集合，默认为所有常用格式
    """
    return compress_image_ultra(input_dir, output_dir, force_lossless=True, supported_formats=supported_formats)


def compress_image_ultra(input_dir, output_dir, max_size_kb=50, lossless=False, force_lossless=False, keep_original_size=False, supported_formats=None):
    """
    通用图片超强压缩为WebP函数 - 支持所有常用图片格式
    支持格式: PNG, JPG, JPEG, BMP, TIFF, GIF

    Args:
        input_dir: 输入目录
        output_dir: 输出目录
        max_size_kb: 目标最大文件大小(KB)
        lossless: 是否使用无损压缩 (True=无损, False=有损)
        force_lossless: 强制使用无损压缩，忽略大小限制
        keep_original_size: 是否保持原始尺寸（不缩放）
        supported_formats: 支持的格式集合，默认为所有常用格式

    注意:
    - PNG图片的透明度会被保留
    - JPEG图片会转换为RGB模式
    - GIF动画会转换为WebP动画
    - 其他格式根据原始模式处理
    """
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)

    # 默认支持的图片格式
    if supported_formats is None:
        supported_formats = {'.png', '.jpg',
                             '.jpeg', '.bmp', '.tiff', '.tif', '.gif'}

    # 检查输入目录
    if not input_dir.exists():
        print(f"❌ 错误：输入目录不存在: {input_dir}")
        return False

    # 创建输出目录
    if not output_dir.exists():
        output_dir.mkdir(parents=True, exist_ok=True)

    # 统计文件
    all_files = list(input_dir.glob('**/*'))
    image_files = [f for f in all_files if f.is_file(
    ) and f.suffix.lower() in supported_formats]

    if not image_files:
        print(f"⚠️  警告：输入目录中没有找到支持的图片文件: {input_dir}")
        return False

    print(f"📊 找到 {len(image_files)} 个支持的图片文件")

    # 压缩模式说明
    if force_lossless:
        mode_desc = "强制无损压缩模式"
    elif lossless:
        mode_desc = "无损压缩模式"
    else:
        mode_desc = "有损压缩模式"

    print(f"🔄 使用 {mode_desc}")

    success_count = 0

    for input_path in image_files:
        try:
            # 计算相对路径和输出路径
            relative_path = input_path.relative_to(input_dir)
            output_folder = output_dir / relative_path.parent
            output_folder.mkdir(parents=True, exist_ok=True)
            output_file = output_folder / (input_path.stem + ".webp")

            # 获取原始文件大小
            original_size = input_path.stat().st_size / 1024  # KB
            file_ext = input_path.suffix.lower()

            with Image.open(input_path) as im:
                # 处理不同格式的特殊情况
                processed_im = _process_image_by_format(
                    im, file_ext, input_path)

                # 尺寸处理
                width, height = processed_im.size
                if keep_original_size or lossless or force_lossless:
                    print(f"✅ 保持原始尺寸 ({mode_desc}): {width}x{height}")
                elif (not lossless and not force_lossless) and (width > 1200 or height > 1200):
                    # 有损模式且允许缩放：等比例缩放大图片
                    ratio = min(1200/width, 1200/height)
                    new_width = int(width * ratio)
                    new_height = int(height * ratio)
                    processed_im = processed_im.resize(
                        (new_width, new_height), Image.Resampling.LANCZOS)
                    print(
                        f"🔄 缩放 (有损模式): {width}x{height} -> {new_width}x{new_height}")

                # 根据压缩模式进行压缩
                if force_lossless or lossless:
                    # 无损压缩模式
                    if file_ext == '.gif' and hasattr(im, 'is_animated') and im.is_animated:
                        _convert_animated_gif_to_webp(
                            im, output_file, quality=100, lossless=True)
                    else:
                        processed_im.save(
                            output_file, 'WEBP', lossless=True, optimize=True, method=6)

                    compressed_size = output_file.stat().st_size / 1024  # KB
                    print(f"✅ 无损压缩: {input_path} -> {output_file}")
                    print(
                        f"   📊 大小: {original_size:.1f}KB -> {compressed_size:.1f}KB (压缩率: {(1-compressed_size/original_size)*100:.1f}%)")

                    if force_lossless or compressed_size <= max_size_kb:
                        print("   ✅ 无损压缩完成")
                    else:
                        print(f"   ⚠️ 无损压缩超过目标大小 {max_size_kb}KB，但已保存")
                else:
                    # 有损压缩模式 - 尝试不同质量直到达到目标大小
                    if file_ext == '.gif' and hasattr(im, 'is_animated') and im.is_animated:
                        # GIF动画特殊处理
                        _convert_animated_gif_to_webp(
                            im, output_file, quality=80, lossless=False)
                        compressed_size = output_file.stat().st_size / 1024
                        quality_used = 80
                    else:
                        # 静态图片压缩
                        for attempt_quality in [80, 70, 60, 50, 40, 30, 20, 10, 5, 3, 1]:
                            processed_im.save(output_file, 'WEBP',
                                              quality=attempt_quality,
                                              optimize=True,
                                              method=6,
                                              lossless=False)

                            compressed_size = output_file.stat().st_size / 1024  # KB
                            quality_used = attempt_quality

                            if compressed_size <= max_size_kb or attempt_quality == 1:
                                break

                    print(f"✅ 有损压缩: {input_path} -> {output_file}")
                    print(
                        f"   📊 大小: {original_size:.1f}KB -> {compressed_size:.1f}KB (压缩率: {(1-compressed_size/original_size)*100:.1f}%)")
                    print(f"   🎯 质量: {quality_used}")

                success_count += 1

        except Exception as e:
            print(f"❌ 处理失败: {input_path} - 错误: {str(e)}")

    print(f"\n🎉 压缩完成！成功处理 {success_count}/{len(image_files)} 个文件")
    return success_count > 0


def _process_image_by_format(im, file_ext, input_path):
    """
    根据不同的图片格式进行预处理

    Args:
        im: PIL图像对象
        file_ext: 文件扩展名
        input_path: 输入文件路径

    Returns:
        处理后的PIL图像对象
    """
    if file_ext in ['.jpg', '.jpeg']:
        # JPEG处理：如果是灰度图，保持灰度；如果是RGB，保持RGB
        if im.mode == 'L':
            print(f"   📷 JPEG灰度图: {input_path}")
            return im
        elif im.mode == 'RGB':
            print(f"   📷 JPEG彩色图: {input_path}")
            return im
        else:
            # 其他模式转换为RGB
            print(f"   🔄 JPEG转换为RGB模式: {im.mode} -> RGB")
            return im.convert('RGB')

    elif file_ext == '.png':
        # PNG处理：保持透明度
        if im.mode in ('RGBA', 'LA'):
            print(f"   🎨 PNG透明图: {im.mode}")
            return im
        elif im.mode == 'P':
            # 调色板模式，检查是否有透明度
            if 'transparency' in im.info:
                print("   🎨 PNG调色板模式(含透明度) -> RGBA")
                return im.convert('RGBA')
            else:
                print("   🎨 PNG调色板模式 -> RGB")
                return im.convert('RGB')
        else:
            print(f"   🎨 PNG图片: {im.mode}")
            return im

    elif file_ext == '.gif':
        # GIF处理：静态GIF或动画GIF的第一帧
        if hasattr(im, 'is_animated') and im.is_animated:
            print(f"   🎬 GIF动画: {input_path}")
            return im  # 动画GIF在后续处理中特殊处理
        else:
            # 静态GIF
            if im.mode == 'P':
                if 'transparency' in im.info:
                    print("   🎨 静态GIF(含透明度) -> RGBA")
                    return im.convert('RGBA')
                else:
                    print("   🎨 静态GIF -> RGB")
                    return im.convert('RGB')
            else:
                print(f"   🎨 静态GIF: {im.mode}")
                return im

    elif file_ext in ['.bmp']:
        # BMP处理：通常转换为RGB
        if im.mode in ('RGBA', 'LA'):
            print(f"   🖼️  BMP(含透明度): {im.mode}")
            return im
        else:
            print(f"   🖼️  BMP -> RGB: {im.mode}")
            return im.convert('RGB')

    elif file_ext in ['.tiff', '.tif']:
        # TIFF处理：支持多种模式
        if im.mode in ('RGBA', 'LA'):
            print(f"   📄 TIFF(含透明度): {im.mode}")
            return im
        elif im.mode == 'L':
            print(f"   📄 TIFF灰度图: {im.mode}")
            return im
        elif im.mode == 'RGB':
            print(f"   📄 TIFF彩色图: {im.mode}")
            return im
        else:
            print(f"   📄 TIFF转换为RGB: {im.mode} -> RGB")
            return im.convert('RGB')

    else:
        # 其他格式默认处理
        print(f"   ❓ 未知格式，转换为RGB: {file_ext}")
        return im.convert('RGB')


def convert_to_webp(input_dir, output_dir, quality=10, optimize=True, method=6, supported_formats=None):
    """
    转换常用图片格式到WebP格式
    支持的格式: PNG, JPG, JPEG, BMP, TIFF, GIF
    不支持的文件将原样复制

    Args:
        input_dir: 输入目录
        output_dir: 输出目录
        quality: 压缩质量 (0-100)，数值越小文件越小
        optimize: 是否启用优化
        method: 压缩方法 (0-6)，6为最强压缩
        supported_formats: 支持的格式集合，默认为所有常用格式
    """

    # 转换字符串路径为Path对象
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)

    # 检查输入目录是否存在
    if not input_dir.exists():
        error_msg = f"❌ 错误：输入目录不存在: {input_dir}"
        print(error_msg)
        print("💡 请检查输入目录路径是否正确")
        raise ValueError(error_msg)

    # 检查输入目录是否为空
    all_files = list(input_dir.glob('**/*'))
    files_only = [f for f in all_files if f.is_file()]

    if not files_only:
        error_msg = f"⚠️  警告：输入目录中没有找到任何文件: {input_dir}"
        print(error_msg)
        raise ValueError(error_msg)

    # 统计支持的图片文件数量
    supported_image_files = [f for f in files_only if f.suffix.lower(
    ) in {'.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif', '.gif'}]
    other_files = [f for f in files_only if f.suffix.lower(
    ) not in {'.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif', '.gif'}]

    print("📊 WebP转换文件统计:")
    print(f"  🖼️  支持转换的图片文件: {len(supported_image_files)} 个")
    print(f"  📄 其他文件（将原样复制）: {len(other_files)} 个")
    print(f"  📁 总文件数: {len(files_only)} 个")

    # 低质量使用有损压缩，高质量使用无损压缩
    lossless = quality >= 95

    # 自动创建输出目录
    if not output_dir.exists():
        output_dir.mkdir(parents=True, exist_ok=True)
        print(f"✅ 已创建输出目录: {output_dir}")

    # 支持的图片格式
    if supported_formats is None:
        supported_formats = {'.png', '.jpg',
                             '.jpeg', '.bmp', '.tiff', '.tif', '.gif'}
    for root, _, files in os.walk(input_dir):
        for file in files:
            file_ext = Path(file).suffix.lower()
            input_path = Path(root) / file
            # 输出路径，保持目录层级
            relative_path = Path(root).relative_to(input_dir)
            output_folder = Path(output_dir) / relative_path
            output_folder.mkdir(parents=True, exist_ok=True)

            if file_ext in supported_formats:
                # 支持的格式：转换为WebP
                # 输出文件名，统一为.webp扩展名
                output_file = output_folder / (Path(file).stem + ".webp")

                # 打开并转换
                with Image.open(input_path) as im:
                    # 处理不同格式的特殊情况
                    if file_ext == '.gif' and hasattr(im, 'is_animated') and im.is_animated:
                        # 处理GIF动画
                        _convert_animated_gif_to_webp(
                            im, output_file, quality, lossless, optimize, method)
                    else:
                        # 处理静态图片
                        # 如果是RGBA模式但目标不支持透明度，转换为RGB
                        if im.mode in ('RGBA', 'LA'):
                            # 保持透明度，WebP支持透明度
                            im.save(output_file, 'WEBP',
                                    lossless=lossless,
                                    quality=quality,
                                    optimize=optimize,
                                    method=method)
                        else:
                            # 其他模式直接转换
                            im.save(output_file, 'WEBP',
                                    lossless=lossless,
                                    quality=quality,
                                    optimize=optimize,
                                    method=method)

                print(f"✅ 转换: {input_path} -> {output_file}")
            else:
                # 不支持的格式：原样复制
                output_file = output_folder / file
                shutil.copy2(input_path, output_file)
                print(f"📄 复制: {input_path} -> {output_file}")


def convert_to_avif(input_dir, output_dir, supported_formats=None):
    """
    转换常用图片格式到AVIF格式
    支持的格式: PNG, JPG, JPEG, BMP, TIFF, GIF (静态)
    不支持的文件将原样复制

    Args:
        input_dir: 输入目录
        output_dir: 输出目录
        supported_formats: 支持的格式集合，默认为所有常用格式
    """
    # 转换字符串路径为Path对象
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)

    # 检查输入目录是否存在
    if not input_dir.exists():
        error_msg = f"❌ 错误：输入目录不存在: {input_dir}"
        print(error_msg)
        print("💡 请检查输入目录路径是否正确")
        raise ValueError(error_msg)

    # 检查输入目录是否为空
    all_files = list(input_dir.glob('**/*'))
    files_only = [f for f in all_files if f.is_file()]

    if not files_only:
        error_msg = f"⚠️  警告：输入目录中没有找到任何文件: {input_dir}"
        print(error_msg)
        raise ValueError(error_msg)

    # 统计支持的图片文件数量
    supported_image_files = [f for f in files_only if f.suffix.lower(
    ) in {'.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif', '.gif'}]
    other_files = [f for f in files_only if f.suffix.lower(
    ) not in {'.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif', '.gif'}]

    print("📊 AVIF转换文件统计:")
    print(f"  🖼️  支持转换的图片文件: {len(supported_image_files)} 个")
    print(f"  📄 其他文件（将原样复制）: {len(other_files)} 个")
    print(f"  📁 总文件数: {len(files_only)} 个")

    # 自动创建输出目录
    if not output_dir.exists():
        output_dir.mkdir(parents=True, exist_ok=True)
        print(f"✅ 已创建输出目录: {output_dir}")

    # 支持的图片格式 (AVIF不支持动画，所以GIF只转换第一帧)
    if supported_formats is None:
        supported_formats = {'.png', '.jpg',
                             '.jpeg', '.bmp', '.tiff', '.tif', '.gif'}

    for root, _, files in os.walk(input_dir):
        for file in files:
            file_ext = Path(file).suffix.lower()
            input_path = Path(root) / file
            # 输出路径，保持目录层级
            relative_path = Path(root).relative_to(input_dir)
            output_folder = Path(output_dir) / relative_path
            output_folder.mkdir(parents=True, exist_ok=True)

            if file_ext in supported_formats:
                # 支持的格式：转换为AVIF
                # 输出文件名，统一为.avif扩展名
                output_file = output_folder / (Path(file).stem + ".avif")

                # 打开并转换
                with Image.open(input_path) as im:
                    # 处理GIF动画 - AVIF不支持动画，只取第一帧
                    if file_ext == '.gif' and hasattr(im, 'is_animated') and im.is_animated:
                        print(f"ℹ️  注意：{input_path} 是动画GIF，只转换第一帧")
                        im = im.convert('RGB')  # GIF可能是P模式，转换为RGB
                        im.save(output_file, 'AVIF', quality=100, speed=0)
                    else:
                        # 处理静态图片
                        if im.mode in ('RGBA', 'LA'):
                            # AVIF支持透明度，保持原始模式
                            im.save(output_file, 'AVIF', quality=100, speed=0)
                        elif im.mode == 'P':
                            # 调色板模式转换为RGB
                            im = im.convert('RGB')
                            im.save(output_file, 'AVIF', quality=100, speed=0)
                        else:
                            # 其他模式直接转换
                            im.save(output_file, 'AVIF', quality=100, speed=0)

                print(f"✅ 转换: {input_path} -> {output_file}")
            else:
                # 不支持的格式：原样复制
                output_file = output_folder / file
                shutil.copy2(input_path, output_file)
                print(f"📄 复制: {input_path} -> {output_file}")


def _convert_animated_gif_to_webp(im, output_file, quality=10, lossless=False, optimize=True, method=6):
    """
    将GIF动画转换为WebP动画的辅助函数
    """
    # 获取所有帧
    frames = []
    try:
        while True:
            frames.append(im.copy())
            im.seek(len(frames))  # 跳到下一帧
    except EOFError:
        pass

    # 获取动画参数
    duration = im.info.get("duration", 100)  # 每帧时间 (ms)
    loop = im.info.get("loop", 0)  # 0 = 无限循环

    # 保存为 WebP 动画，使用最佳压缩
    frames[0].save(
        output_file,
        save_all=True,
        append_images=frames[1:],
        duration=duration,
        loop=loop,
        format="WEBP",
        quality=quality,
        lossless=lossless,
        optimize=optimize,
        method=method
    )


if __name__ == "__main__":
    # 在项目根目录下执行时，直接使用当前工作目录
    project_root = Path.cwd()

    # 原始目录 - 项目根目录下的images文件夹
    INPUT_DIR = project_root / "resource" / "images"

    # 输出目录
    WEBP_DIR = project_root / "resource" / "webp"
    AVIF_DIR = project_root / "resource" / "avif"

    print(f"📂 项目根目录: {project_root}")
    print(f"📁 输入目录: {INPUT_DIR}")
    print(f"📁 WebP输出目录: {WEBP_DIR}")
    print(f"📁 AVIF输出目录: {AVIF_DIR}")
    print()

    # ==========【新增】通用图片压缩功能演示 ==========

    # 1. 通用图片极度压缩 (有损) - 支持所有格式
    print("🔄 开始通用图片极度压缩 (有损模式, 支持所有格式)...")
    UNIVERSAL_EXTREME_DIR = project_root / "resource" / "universal-extreme"
    compress_image_extreme(INPUT_DIR, UNIVERSAL_EXTREME_DIR, max_size_kb=30)
    print("✅ 通用图片极度压缩完成！")
    print()

    # 2. 通用图片极度压缩 - 保持原尺寸 (有损)
    print("🔄 开始通用图片极度压缩 (有损模式，保持原尺寸, 支持所有格式)...")
    UNIVERSAL_EXTREME_ORIGINAL_DIR = project_root / \
        "resource" / "universal-extreme-original"
    compress_image_extreme(INPUT_DIR, UNIVERSAL_EXTREME_ORIGINAL_DIR,
                           max_size_kb=50, keep_original_size=True)
    print("✅ 通用图片极度压缩 (保持原尺寸) 完成！")
    print()

    # 3. 通用图片无损压缩 - 支持所有格式
    print("🔄 开始通用图片无损压缩 (支持所有格式)...")
    UNIVERSAL_LOSSLESS_DIR = project_root / "resource" / "universal-lossless"
    compress_image_lossless(INPUT_DIR, UNIVERSAL_LOSSLESS_DIR, max_size_kb=200)
    print("✅ 通用图片无损压缩完成！")
    print()

    # 4. 通用图片强制无损压缩 - 忽略大小限制
    print("🔄 开始通用图片强制无损压缩 (忽略大小限制, 支持所有格式)...")
    UNIVERSAL_FORCE_LOSSLESS_DIR = project_root / \
        "resource" / "universal-force-lossless"
    compress_image_force_lossless(INPUT_DIR, UNIVERSAL_FORCE_LOSSLESS_DIR)
    print("✅ 通用图片强制无损压缩完成！")
    print()

    # ==========【保留】原有PNG专用功能 ==========

    # PNG极度压缩 - 目标文件很小很小 (有损)
    # print("🔄 开始PNG极度压缩 (有损模式)...")
    # PNG_EXTREME_DIR = project_root / "resource" / "png-extreme"
    # compress_png_extreme(INPUT_DIR, PNG_EXTREME_DIR, max_size_kb=30)
    # print("✅ PNG极度压缩完成！")
    # print()

    # PNG无损压缩 - 保持最佳质量
    # print("🔄 开始PNG无损压缩...")
    # PNG_LOSSLESS_DIR = project_root / "resource" / "png-lossless"
    # compress_png_lossless(INPUT_DIR, PNG_LOSSLESS_DIR, max_size_kb=200)
    # print("✅ PNG无损压缩完成！")
    # print()

    # PNG强制无损压缩 - 忽略大小限制
    print("🔄 开始PNG强制无损压缩 (仅PNG文件)...")
    PNG_FORCE_LOSSLESS_DIR = project_root / "resource" / "force-lossless"
    compress_png_force_lossless(INPUT_DIR, PNG_FORCE_LOSSLESS_DIR)
    print("✅ PNG强制无损压缩完成！")
    print()

    # ==========【其他格式转换】==========

    # 转换为WebP格式 - 标准压缩设置
    # print("🔄 开始转换为WebP格式...")
    # convert_to_webp(INPUT_DIR, WEBP_DIR, quality=80, optimize=True, method=6)
    # print("✅ WebP转换完成！")
    # print()

    # 转换为AVIF格式
    # print("🔄 开始转换为AVIF格式...")
    # convert_to_avif(INPUT_DIR, AVIF_DIR)
    # print("✅ AVIF转换完成！")
    # print()

    print("🎉 所有图片压缩转换完成！")
    print()
    print("📋 功能总结:")
    print("=" * 60)
    print("🆕 【新增通用功能】支持所有常用图片格式 (PNG, JPG, JPEG, BMP, TIFF, GIF):")
    print("   📁 universal-extreme: 通用极度压缩 + 缩放 (目标30KB)")
    print("   📁 universal-extreme-original: 通用极度压缩 + 保持原尺寸 (目标50KB)")
    print("   📁 universal-lossless: 通用无损压缩 + 保持原尺寸 (目标200KB)")
    print("   📁 universal-force-lossless: 通用强制无损压缩 + 保持原尺寸 (忽略大小)")
    print()
    print("🔧 【保留专用功能】仅PNG格式:")
    print("   📁 force-lossless: PNG强制无损压缩 + 保持原尺寸 (忽略大小限制)")
    print()
    print("🔄 【格式转换功能】:")
    print("   📁 webp: 普通WebP转换")
    print("   📁 avif: AVIF格式转换 (不支持动画)")
    print()
    print("💡 使用建议:")
    print("   🚀 追求极小文件: 使用 compress_image_extreme() 允许缩放")
    print("   ⚡ 保持尺寸+小文件: 使用 compress_image_extreme(keep_original_size=True)")
    print("   🎨 保持最佳质量: 使用 compress_image_lossless()")
    print("   ⭐ 完美质量: 使用 compress_image_force_lossless()")
    print("   📷 JPEG优化: 自动保持原有RGB/灰度模式")
    print("   🎬 GIF动画: 自动转换为WebP动画")
    print("   🖼️  透明度: PNG和GIF透明度完全保留")

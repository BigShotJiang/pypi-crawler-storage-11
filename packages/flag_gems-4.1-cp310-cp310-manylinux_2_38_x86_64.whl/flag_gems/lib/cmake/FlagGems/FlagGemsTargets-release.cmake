#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "FlagGems::operators" for configuration "Release"
set_property(TARGET FlagGems::operators APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(FlagGems::operators PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "TritonJIT::triton_jit"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liboperators.so"
  IMPORTED_SONAME_RELEASE "liboperators.so"
  )

list(APPEND _cmake_import_check_targets FlagGems::operators )
list(APPEND _cmake_import_check_files_for_FlagGems::operators "${_IMPORT_PREFIX}/lib/liboperators.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

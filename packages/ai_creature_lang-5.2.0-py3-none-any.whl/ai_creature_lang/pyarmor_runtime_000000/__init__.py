# Pyarmor 9.1.7 (trial), 000000, 2025-11-03T22:16:36.789285
from sys import version_info as py_version
__pyarmor__ = __import__("py%d%d.pyarmor_runtime" % py_version[:2], globals(), locals(), ["__pyarmor__"], 1).__pyarmor__
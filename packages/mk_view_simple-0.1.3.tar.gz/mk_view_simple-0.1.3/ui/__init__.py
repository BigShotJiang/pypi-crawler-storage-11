"""UI module for Markdown Viewer"""

from .main_window import MarkdownViewer

__all__ = ['MarkdownViewer']

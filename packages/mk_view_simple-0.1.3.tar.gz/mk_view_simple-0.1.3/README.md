# mk-view-simple

Ein **leichtgewichtiger, schöner Markdown Viewer** für Linux mit PyQt5 und QTextBrowser.

Optimiert für ältere Hardware (ThinkPad X270) – schnell, responsiv, minimal RAM-Verbrauch.

## Features

- ✅ **Markdown-Rendering** mit mistune v3
- ✅ **Lokale Bilder** mit automatischer Skalierung
- ✅ **Links** vollständig unterstützt
- ✅ **Zoom-Funktion** (50% - 300%)
- ✅ **Dateibaum-Navigation** für Dokumentation
- ✅ **Externe Bilder** mit Auto-Caching
- ✅ **Schneller Start** – keine Bloat
- ✅ **Cross-Platform** – Windows, macOS, Linux

## Installation

### Von PyPI (empfohlen)

```bash
pip install mk-view-simple
```

### Danach ausführen

```bash
mk-view-simple                    # GUI starten
mk-view-simple /path/to/file.md   # Datei direkt öffnen
```

### Aus Quelle

```bash
git clone https://github.com/yourusername/mk-view-simple.git
cd mk-view-simple
pip install -e .
```

## Anforderungen

- **Python** >= 3.8
- **PyQt5** >= 5.15.0
- **mistune** >= 3.0.0 (Markdown Parser)
- **Pillow** >= 9.0.0 (Bildverarbeitung)

## Philosophie

Minimalism über Bloat. Dieses Projekt entstand aus der Frustration über zu schwere Markdown-Viewer:

- **Electron-basiert**: 150+ MB, 500+ MB RAM im Idle
- **WebKit/Chromium**: Zu viel Overhead
- **Qt mit WebEngine**: Wieder Chromium-Overhead

**QTextBrowser** war die Antwort – spezialisiert auf leichte HTML-Dokumenten-Anzeige seit Qt 3.0. Perfekt für Markdown.

### Bildgrößen-Skalierung

Statt QTextBrowser zu zwingen Bilder zu skalieren (ignoriert CSS), werden Bilder beim Laden skaliert:

1. Verfügbare Breite ermitteln
2. Original-Bildgröße auslesen
3. Bei Bedarf proportional verkleinern
4. Mit expliziten `width`/`height` Attributen ins HTML schreiben

**Resultat:** Bilder passen auf die Seite, keine horizontalen Scrollbars, nur eine Skalierung beim Laden.

## Struktur

```
mk-view-simple/
├── config.py                  # Globale Konfiguration & Konstanten
├── image/
│   ├── dimensions.py         # Bildgrößen-Erkennung (JPEG, PNG, GIF, WebP)
│   └── cache.py              # Externe Bild-Caching & Download
├── htmlenhancer/
│   └── enhancer.py           # HTML-Verarbeitung, CSS-Styling, Bildkalierung
├── ui/
│   ├── main_window.py        # Hauptfenster & Event-Handling
│   └── file_tree.py          # Dateibaum-Widget
├── markdown_viewer.py        # Einstiegspunkt (nur main())
├── style.css                 # Stylesheet
└── pyproject.toml            # Packaging-Konfiguration
```

## Verwendung

### GUI starten

```bash
mk-view-simple
```

Dann: `File` → `Open` oder Drag-and-Drop eine `.md` Datei.

### Datei direkt öffnen

```bash
mk-view-simple /path/to/documentation.md
```

### Zoom-Steuerung

- `Ctrl` + `+` : Vergrößern
- `Ctrl` + `-` : Verkleinern
- `Ctrl` + `0` : Zurücksetzen

## Konfiguration

XDG Base Directory Specification wird befolgt:

```bash
$XDG_CACHE_HOME/mk-view-simple/  # oder ~/.cache/mk-view-simple/
```

Externe Bilder werden hier gecacht.

## Entwicklung

```bash
# Abhängigkeiten installieren
pip install -r requirements-dev.txt

# Code formatieren
black .
isort .

# Tests ausführen
pytest

# Build
python -m build

# Upload (nach PyPI Account Setup)
twine upload dist/*
```

## Hardware-Anforderungen

Getestet und optimiert für:
- **ThinkPad X270** (Intel i5-6200U, 8GB RAM, ArchLinux)
- **Andere ältere Geräte** mit ähnlichen Specs

Funktioniert natürlich auch auf modernen Maschinen.

## Lizenz

GNU General Public License v3.0 – siehe [LICENSE](LICENSE)

## Danksagungen

- **Qt Foundation** für ein großartiges Framework
- **mistune** für einfaches Markdown-Parsing
- **Pillow** für Bildverarbeitung
- Die Open-Source-Community

## Fehlermeldungen / Support

Bugs? Issues? Wünsche?

→ [GitHub Issues](https://github.com/yourusername/mk-view-simple/issues)

---

**Geschrieben:** November 2025
**Hardware:** ThinkPad X270 (Intel i5-6200U, 8GB RAM, ArchLinux)
**Philosophie:** *"Ein PC schnell genug zum Entwickeln, aber langsam genug zum Zocken"*

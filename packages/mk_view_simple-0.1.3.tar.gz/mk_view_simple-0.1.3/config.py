"""
Global configuration and utility functions for Markdown Viewer
"""

import os
import hashlib
from pathlib import Path


def get_cache_dir():
    """
    Get cache directory following XDG Base Directory specification.
    Fallback to ~/.cache/mk-view-simple/ if XDG_CACHE_HOME not set.
    """
    cache_home = os.environ.get('XDG_CACHE_HOME')
    if not cache_home:
        cache_home = os.path.expanduser('~/.cache')

    cache_dir = Path(cache_home) / 'mk-view-simple'
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def get_url_hash(url):
    """Generate a unique hash for a URL for caching purposes."""
    return hashlib.sha256(url.encode()).hexdigest()[:16]


# Application constants
SUPPORTED_MARKDOWN_EXTENSIONS = ('.md', '.txt')
SUPPORTED_IMAGE_EXTENSIONS = ('.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.bmp', '.ico')
URL_DOWNLOAD_TIMEOUT = 5  # seconds
CHUNK_SIZE = 8192  # bytes, for streaming downloads

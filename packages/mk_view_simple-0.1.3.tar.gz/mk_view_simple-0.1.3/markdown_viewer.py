#!/usr/bin/env python3
"""
Lightweight Markdown Viewer for Linux
A simple, beautiful markdown viewer using PyQt5 and mistune
"""

import sys
import os
from PyQt5.QtWidgets import QApplication

from ui.main_window import MarkdownViewer


def main():
    """Main entry point"""
    app = QApplication(sys.argv)

    # Create and show the viewer
    viewer = MarkdownViewer()
    viewer.show()

    # If a file was passed as argument, open it
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        if os.path.exists(file_path):
            viewer.load_file(file_path)

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()

"""
Image caching for external URLs
"""

import os
import urllib.request
import urllib.error
from pathlib import Path
from PyQt5.QtWidgets import QApplication

from config import get_cache_dir, get_url_hash, SUPPORTED_IMAGE_EXTENSIONS, URL_DOWNLOAD_TIMEOUT, CHUNK_SIZE


class ImageCache:
    """Manages downloading and caching of external images"""

    def download_and_cache_image(self, url):
        """
        Downloads an external image and caches it locally.
        Only downloads actual image files (PNG, JPG, GIF, WebP, SVG).
        Keeps UI responsive by processing Qt events during download.

        Args:
            url: External image URL (http://, https://)

        Returns:
            Path to cached image file, or None if not an image or download failed
        """
        # Only download known image formats
        url_path = url.split('?')[0].lower()  # Remove query parameters

        if not any(url_path.endswith(ext) for ext in SUPPORTED_IMAGE_EXTENSIONS):
            print(f"[cache] Skipping non-image URL: {url}")
            return None

        try:
            cache_dir = get_cache_dir()
            url_hash = get_url_hash(url)

            # Get file extension from URL
            ext = os.path.splitext(url_path)[1] or '.img'
            cache_file = cache_dir / f"{url_hash}{ext}"

            # If already cached, return it
            if cache_file.exists():
                print(f"[cache] Using cached: {cache_file.name}")
                return str(cache_file)

            # Download image
            print(f"[cache] Downloading: {url}")
            req = urllib.request.Request(
                url,
                headers={'User-Agent': 'Mozilla/5.0'}  # Some servers require this
            )

            with urllib.request.urlopen(req, timeout=URL_DOWNLOAD_TIMEOUT) as response:
                # Read in chunks to keep UI responsive
                image_data = b''
                while True:
                    chunk = response.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    image_data += chunk
                    # Keep UI responsive during download
                    QApplication.processEvents()

            # Save to cache
            with open(cache_file, 'wb') as f:
                f.write(image_data)

            print(f"[cache] Saved to: {cache_file.name}")
            return str(cache_file)

        except urllib.error.URLError as e:
            print(f"[cache] URL Error: {e}")
            return None
        except Exception as e:
            print(f"[cache] Error: {e}")
            return None

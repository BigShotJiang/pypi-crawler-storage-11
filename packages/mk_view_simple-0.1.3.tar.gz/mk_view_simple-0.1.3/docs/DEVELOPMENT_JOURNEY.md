# mk-view-simple: Eine Entwicklungsgeschichte
## Warum ich einen eigenen Markdown-Viewer schrieb und mich für QTextBrowser entschied

---

## Vorwort: Die Philosophie

Mein System ist ein **ThinkPad X270** - ein älteres, günstiges, aber erstaunlich robustes Gerät. Die Hardware ist reparierbar, die Specs sind bescheiden:
- **Prozessor**: Intel Core i5-6200U (dual-core)
- **RAM**: 8GB
- **Storage**: SSD
- **Betriebssystem**: ArchLinux (rolling release, schnell und lean)

**Meine Philosophie**: *Ein PC schnell genug zum Entwickeln, aber langsam genug zum Zocken.*

Das bedeutet nicht "alles super schnell machen" - sondern bewusste Entscheidungen treffen, die das System leicht und responsiv halten. Als ArchLinux-Nutzer schätze ich Kontrolle, Minimalismus und Qualität über bloat.

---

## Warum ich einen Markdown-Viewer bauen "musste" 

### Die Suche Ich brauchte einen **leichtgewichtigen Markdown-Viewer** für Dokumentation auf meinem ThinkPad. Meine Anforderungen waren einfach:
- ✅ Markdown rendern
- ✅ Lokale Bilder anzeigen
- ✅ Links navigieren
- ✅ Schnell starten
- ✅ Minimal RAM verbrauchen
- ✅ Keine externen Abhängigkeiten

### Was es nicht gab
Ich suchte überall:
- **Electron-basiert**: Zu schwer (min. 150+ MB, 500+ MB RAM im Idle)
- **Chromium-basiert**: Gleicher Overhead wie große Browser
- **WebKit**: Mittelmäßig, trotzdem viel RAM
- **CLI-only Tools**: Keine GUI, unflexibel
- **Qt-basierte Tools**: QtWebEngine-basiert, also wieder Chromium-Overhead

Das Angebot litt unter drei Problemen: Es war teilweise zu schwergewichtig, teilweise zu minimal und teilweise zu funktionsüberladen.

---

## Warum QTextBrowser?

### Die Geschichte von QTextBrowser

QTextBrowser ist Teil des **Qt Help Framework** seit **Qt 3.0+** und wurde von Anfang an mit einer klaren Design-Philosophie entwickelt:

> **Leichtgewichtige Dokumentation-Anzeige für Anwendungen** - als spezialisiertes CSS Rendering-Widget für strukturierte Inhalte.

Das Zitat aus der Qt-Dokumentation fasst es gut zusammen:

> *"The idea of running what's essentially a full-blown webbrowser bothers developers, knowing that applications are already resource hungry enough as it is and that the documentation in question can be rendered well enough with QTB."*

Diese Philosophie stammt aus der Zeit, als Performance und Ressourcen-Effizienz zentral waren - und ist noch genauso relevant heute, besonders auf älteren Systemen.

### Einsatzgebiete für QTextBrowser

  - Primär als Dokumenten-Viewer entwickelt
  - Integrierte Hilfesysteme in Anwendungen
  - "Help"-Fenster (Menü oder F1-Taste)
  - Rendering von formatierten Texten, Bildern und Links
  - Darstellung strukturierter Dokumentation

---

## Bildgrößen-Skalierung – Die einfache Lösung

### Das Problem
Bilder wurden in Originalgröße angezeigt → zu groß für die Seite → horizontales Scrolling. Bilder
ragten rechts über den Seitenrand hinaus.

### Warum CSS nicht funktioniert
QTextBrowser ignoriert CSS-Properties wie `max-width`. Das ist **kein Bug** – es ist bewusste
Design-Entscheidung für Performance.

### Die Lösung: Bilder beim Laden skalieren

Statt QTextBrowser zu zwingen, Bilder zu skalieren, **skalieren wir die HTML selbst**:

1. Verfügbare Breite auslesen
2. Original-Bildgröße ermitteln
3. Bei Bedarf proportional verkleinern
4. Mit expliziten `width`/`height` Attributen ins HTML schreiben

**Resultat:** Bilder passen auf die Seite, kein Scrolling.

### Performance-Vorteil
Bilder werden **nur einmal** beim Laden skaliert, nicht ständig beim Rendering. Das ist das was den Markdown Viewer im Endeffekt effizient macht.

---

## Code-Struktur

Nachdem das Grundgerüst funktionierte, wurde der Code immer länger:
- Bildgrößen-Berechnung
- Externe Bild-Caching
- HTML-Enhancement
- Dateibaum-Navigation
- Pfad-Auflösung

Alles in einer einzigen 650+ Zeilen Datei.

### Die Refaktorierung: Separation of Concerns

Ich zerlegte das Projekt in **logische Module**:

```
mk-view-simple/
├── config.py                  # Globale Konfiguration & Konstanten
├── image/
│   ├── dimensions.py         # Bildgrößen-Erkennung
│   └── cache.py              # Bild-Caching
├── htmlenhancer/
│   └── enhancer.py           # HTML-Verarbeitung & Styling
├── ui/
│   ├── main_window.py        # Hauptfenster & Event-Handling
│   └── file_tree.py          # Dateibaum-Management
├── markdown_viewer.py        # Einstiegspunkt (nur main())
└── style.css                 # Stylesheet
```

**Jedes Modul hat eine klare Verantwortung:**

| Modul | Verantwortung |
|-------|---------------|
| `config.py` | Globale Konstanten & XDG-Verzeichnis |
| `image/dimensions.py` | Bildgrößen-Parsing (JPEG, PNG, GIF, WebP) |
| `image/cache.py` | Externes Bild-Caching & Download |
| `htmlenhancer/enhancer.py` | Pfad-Auflösung, CSS-Styling, Bild-Skalierung |
| `ui/file_tree.py` | Dateibaum-Widget Management |
| `ui/main_window.py` | Hauptfenster, UI-Layout, Event-Handler |
| `markdown_viewer.py` | Nur `main()` - alles andere ist modular |

---

## Fazit

- Schnell, responsive, minimal RAM
- Perfekt für Dokumentation
- Vollständig anpassbares Desgin
- Kein Bloat
- Modularer Code
- Klare Separation of Concerns
- Leicht zu erweitern
- Minimale Abhängigkeiten

---

## Dankbarkeit

- **Qt Foundation** für ein großartiges Framework
- **mistune** für einfaches Markdown-Parsing
- **ThinkPad X270** für Zuverlässigkeit und Reparierbarkeit
- **Open Source** für die Möglichkeit, eigene Tools zu bauen

---

**Geschrieben:** November 2025
**Hardware:** ThinkPad X270 (Intel i5-6200U, 8GB RAM, ArchLinux)
**Philosophie:** "Ein PC schnell genug zum Entwickeln, aber langsam genug zum Zocken"

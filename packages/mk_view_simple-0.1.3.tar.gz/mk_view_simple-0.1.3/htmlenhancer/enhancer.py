"""
HTML enhancement with styling, path resolution, and responsive images
"""

import os
import re
from pathlib import Path
from image.dimensions import get_image_dimensions
from image.cache import ImageCache


class HTMLEnhancer:
    """Enhances HTML with styling, path resolution, and responsive images"""

    def __init__(self, browser=None):
        """
        Initialize HTML enhancer.

        Args:
            browser: QTextBrowser instance for calculating image sizes (optional)
        """
        self.browser = browser
        self.image_cache = ImageCache()
        self.current_file_path = None

    def set_current_file_path(self, file_path):
        """Set the current markdown file path for resolving relative paths"""
        self.current_file_path = file_path

    def enhance_html(self, html, base_path):
        """
        Fix relative paths for images and links and add CSS stylesheet.

        Args:
            html: Raw HTML from markdown conversion
            base_path: Path object of the directory containing the markdown file

        Returns:
            Enhanced HTML with CSS and resolved paths
        """
        # Load external CSS if it exists
        css_content = self._load_css()

        # Fix relative image paths and links - resolve them relative to the markdown file
        enhanced_html = self._fix_src_and_href(html, base_path)

        # Add intelligent size scaling to img tags
        enhanced_html = self._resize_images(enhanced_html)

        # Wrap in proper HTML structure with CSS embedded
        return self._wrap_in_html_document(enhanced_html, css_content)

    def _load_css(self):
        """Load external CSS stylesheet"""
        css_content = ""
        css_path = Path(__file__).parent.parent / "style.css"
        if css_path.exists():
            with open(css_path, 'r', encoding='utf-8') as f:
                css_content = f.read()
        return css_content

    def _fix_src_and_href(self, html, base_path):
        """Fix relative paths for src and href attributes"""
        def fix_src_and_href_callback(match):
            attr_name = match.group(1)  # 'src' or 'href'
            path = match.group(2)

            # For external URLs (http/https), download and cache them
            if path.startswith(('http://', 'https://')):
                cached_path = self.image_cache.download_and_cache_image(path)
                if cached_path:
                    return f'{attr_name}="file://{cached_path}"'
                else:
                    # Return original URL if download failed
                    return match.group(0)

            # Skip other absolute URLs and anchors
            if path.startswith(('file://', '#', 'ftp://')):
                return match.group(0)

            # Resolve relative path
            resolved_path = (base_path / path).resolve()
            return f'{attr_name}="file://{resolved_path}"'

        # Match both src="..." and href="..."
        return re.sub(r'(src|href)="([^"]+)"', fix_src_and_href_callback, html)

    def _resize_images(self, html):
        """Add intelligent size scaling to img tags"""
        def resize_img_callback(match):
            img_tag = match.group(0)

            # Skip if already has explicit width/height
            if 'width' in img_tag and 'height' in img_tag:
                return img_tag

            # Extract image path from src attribute
            src_match = re.search(r'src="([^"]+)"', img_tag)
            if not src_match:
                return img_tag

            image_path = src_match.group(1)

            # Calculate optimal dimensions (viewport-aware)
            width, height = self.calculate_image_size(image_path)

            if width and height:
                # Add width and height attributes
                img_tag = img_tag.replace('<img', f'<img width="{width}" height="{height}"')

            return img_tag

        return re.sub(r'<img[^>]*>', resize_img_callback, html)

    def calculate_image_size(self, image_path):
        """
        Calculates optimal image size for display.
        Reads image dimensions without PIL and scales proportionally to viewport width.

        Args:
            image_path: Path to image (can be relative, absolute, or file:// URL)
            max_width: Maximum width in pixels.
                       If None: determined from QTextBrowser.viewport().width()

        Returns:
            (width, height) or (None, None) if dimensions cannot be determined
        """
        # Handle file:// URLs - extract the actual path
        if image_path.startswith('file://'):
            image_path = image_path[7:]  # Remove 'file://'

        # Resolve absolute path for local files
        if not os.path.isabs(image_path):
            # If relative, assume it's relative to current file's directory
            if self.current_file_path:
                base_dir = os.path.dirname(self.current_file_path)
                image_path = os.path.join(base_dir, image_path)
            else:
                image_path = os.path.abspath(image_path)

        # Get original dimensions from file metadata
        orig_width, orig_height = get_image_dimensions(image_path)

        if orig_width is None:
            return None, None

        print(f"\n[calculate_image_size] Processing: {os.path.basename(image_path)}")
        print(f"  Original dimensions: {orig_width}x{orig_height}")

        # Determine max width for viewport
        max_width = None
        if self.browser:
            # Get viewport width from QTextBrowser
            viewport_width = self.browser.viewport().width()
            print(f"  Viewport width: {viewport_width}px")

            # Get browser geometry info
            browser_width = self.browser.width()
            print(f"  Browser widget width: {browser_width}px")

            # Get document width
            doc_width = self.browser.document().size().width()
            print(f"  Document width: {doc_width}px")

            # Safety margin (padding/margins)
            margin = 40
            max_width = max(viewport_width - margin, 300)
            print(f"  Max width (viewport - {margin}px margin): {max_width}px")

        # Fallback if viewport not available
        if max_width is None or max_width < 300:
            max_width = 860  # Default: 900px - 40px from style.css
            print(f"  Using fallback max_width: {max_width}px")

        # Scale proportionally if too wide
        if orig_width > max_width:
            new_width = max_width
            new_height = int((orig_height * new_width) / orig_width)
            print(f"  Scaled dimensions: {new_width}x{new_height} (scaled down)")
            return new_width, new_height

        # Keep original size if smaller
        print(f"  Final dimensions: {orig_width}x{orig_height} (original - no scaling needed)")
        return orig_width, orig_height

    def _wrap_in_html_document(self, html, css_content):
        """Wrap HTML in proper document structure with CSS"""
        return f'''<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
{css_content}
    </style>
</head>
<body>
{html}
</body>
</html>'''

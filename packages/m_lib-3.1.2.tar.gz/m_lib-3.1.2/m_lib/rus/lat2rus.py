#! /usr/bin/env python
# -*- coding: koi8-r -*-

from __future__ import print_function
from ..lazy.dict import LazyDictInitFunc

#
# Lat -> Rus translation
#

lat2koi_d = {
   "q": "�",
   "w": "�",
   "e": "�",
   "r": "�",
   "t": "�",
   "y": "�",
   "u": "�",
   "i": "�",
   "o": "�",
   "p": "�",
   "[": "�",
   "]": "�",
   "a": "�",
   "s": "�",
   "d": "�",
   "f": "�",
   "g": "�",
   "h": "�",
   "j": "�",
   "k": "�",
   "l": "�",
   ";": "�",
   "'": "�",
   "z": "�",
   "x": "�",
   "c": "�",
   "v": "�",
   "b": "�",
   "n": "�",
   "m": "�",
   ",": "�",
   ".": "�",
   "Q": "�",
   "W": "�",
   "E": "�",
   "R": "�",
   "T": "�",
   "Y": "�",
   "U": "�",
   "I": "�",
   "O": "�",
   "P": "�",
   "{": "�",
   "}": "�",
   "A": "�",
   "S": "�",
   "D": "�",
   "F": "�",
   "G": "�",
   "H": "�",
   "J": "�",
   "K": "�",
   "L": "�",
   ":": "�",
   "\"": "�",
   "Z": "�",
   "X": "�",
   "C": "�",
   "V": "�",
   "B": "�",
   "N": "�",
   "M": "�",
   "<": "�",
   ">": "�",
   "`": "�",
   "~": "�",
   "!": "!",
   "@": "\"",
   "#": "#",
   "$": "*",
   "%": ":",
   "^": ",",
   "&": ".",
   "*": ";",
}


def make_lat2xxx(encoding="cp1251"):
   d = {}
   for k, v in lat2koi_d.items():
      d[k] = v
   return d


lat2win_d = LazyDictInitFunc(make_lat2xxx, encoding="cp1251")


def lat2rus(instr, lat2rus_d = lat2koi_d):
   out = []
   for c in instr:
      c = lat2rus_d.get(c, c)
      out.append(c)
   return ''.join(out)


lat2koi = lat2rus

def lat2win(instr):
   return lat2rus(instr, lat2win_d)


if __name__ == "__main__":
   Test = "Ghbdtn nt,t^ ghtrhfcysq vbh!"
   print("Test:", Test)
   print("����:", lat2koi(Test))
   test = lat2win(Test)
   print("����:", test)

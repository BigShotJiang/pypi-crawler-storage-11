import torch
from ultralytics import SAM

def load_sam_model(model_path: str):
    """
    Loads the SAM model from the given path.
    Args:
        model_path (str): Path to the .pt model file (e.g., sam2.1_l.pt)
    Returns:
        model (SAM): Loaded model
    """
    if not model_path.endswith(".pt"):
        raise ValueError("❌ Model path must end with .pt")
    try:
        model = SAM(model_path)
        print("✅ SAM model loaded successfully.")
        return model
    except Exception as e:
        raise RuntimeError(f"❌ Error loading SAM model: {e}")

import os
import numpy as np
import cv2
import matplotlib.pyplot as plt

def show_segmentation(orig_img, masks, title="Segmentation"):
    num_segments = masks.shape[0]
    print(f"🟩 Total Segments Detected: {num_segments}")

    overlay = orig_img.copy()
    colors = np.random.randint(100, 255, size=(num_segments, 3), dtype=np.uint8)

    for i, mask in enumerate(masks):
        color = tuple(int(c) for c in colors[i])
        overlay[mask > 0.5] = color

    # Slightly opaque (0.7)
    alpha = 0.7
    blended = cv2.addWeighted(orig_img, 1 - alpha, overlay, alpha, 0)

    plt.figure(figsize=(10, 8))
    plt.imshow(cv2.cvtColor(blended, cv2.COLOR_BGR2RGB))
    plt.axis("off")
    plt.title(f"✨ {title} — {num_segments} segments")
    plt.show()

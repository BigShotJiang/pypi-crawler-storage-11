import os
import torch
import time
from .model_loader import load_sam_model
from .utils import show_segmentation

def segment_image(image_path: str, model_path: str):
    """
    Segments an image using the SAM model and displays the result.
    
    Args:
        image_path (str): Path to the input image
        model_path (str): Path to the SAM .pt model file
    """
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"❌ Image not found: {image_path}")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("🧠 Using device:", device)

    model = load_sam_model(model_path)

    print("🔍 Running inference...")
    start_time = time.time()
    results = model(image_path)
    end_time = time.time()
    print(f"✅ Inference completed in {end_time - start_time:.2f} seconds")

    masks = results[0].masks.data.cpu().numpy()
    orig_img = results[0].orig_img.copy()

    show_segmentation(orig_img, masks, "Soft Segmentation Overlay")

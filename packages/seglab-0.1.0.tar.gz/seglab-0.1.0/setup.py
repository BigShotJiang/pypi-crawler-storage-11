from setuptools import setup, find_packages

setup(
    name="seglab",
    version="0.1.0",
    author="Divine Gupta\nKartikeya Mishra\nChaitnya Sharma",
    description="A lightweight image segmentation labeling library using SAM",
    packages=find_packages(),
    install_requires=[
        "ultralytics>=8.2.0",
        "torch>=2.0.0",
        "matplotlib",
        "numpy",
        "opencv-python"
    ],
    python_requires=">=3.8",
)

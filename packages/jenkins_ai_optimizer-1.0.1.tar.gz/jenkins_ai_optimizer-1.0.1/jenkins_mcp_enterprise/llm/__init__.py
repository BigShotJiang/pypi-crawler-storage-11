"""LLM context optimization components"""

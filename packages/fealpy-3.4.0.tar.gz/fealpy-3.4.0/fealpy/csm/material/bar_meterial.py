from typing import Optional, Tuple
from builtins import float, str
from fealpy.typing import TensorLike
from fealpy.backend import backend_manager as bm
from fealpy.material.elastic_material import LinearElasticMaterial
from ..model.truss.truss_data_3d import TrussData3D
class BarMaterial(LinearElasticMaterial):
    """Material properties for 3D bars.
    Parameters:
        name (str): The name of the material.
        model (object): The model containing the bar's geometric and material properties.
        E (float): The elastic modulus of the material.
        mu (float): The shear modulus of the material.
    """
    def __init__(self, 
                model,
                name: str, 
                elastic_modulus: Optional[float] = None,
                poisson_ratio: Optional[float] = None,
                shear_modulus: Optional[float] = None,
                A: Optional[float] = None,) -> None:
        super().__init__(name=name, 
                        elastic_modulus= elastic_modulus, 
                        poisson_ratio=poisson_ratio,
                        shear_modulus=shear_modulus)
        self.E = self.get_property('elastic_modulus')
        self.nu = self.get_property('poisson_ratio')
        self.mu = self.get_property('shear_modulus')
        self.A = A
        
        
    def __str__(self) -> str:
        s = f"{self.__class__.__name__}(\n"
        s += "  === Material Parameters ===\n"
        s += f"  Name              : {self.get_property('name')}\n"
        s += f"  [Axle]  E           : {self.E}\n"
        s += f"  [Axle]  nu          : {self.nu}\n"
        s += f"  [Axle]  mu          : {self.mu}\n"
        s += ")"
        return s
    
    def linear_basis(self, x: float, l: float) -> TensorLike:
        """Linear shape functions for a axle material.
        Parameters:
            x (float): Local coordinate along the axle axis.
            l (float): Length of the axle element.
        Returns:
            b (TensorLike): Linear shape functions evaluated at xi.
        """
        xi = x / l  
        t = 1.0 / l
        b = bm.zeros((2, 2), dtype=bm.float64)
        b[0, 0] = 1 - xi
        b[0, 1] = xi
        b[1, 0] = -t
        b[1, 1] = t
        return b
    
    def stress_matrix(self) -> TensorLike:
        """Returns the stress matrix for axle material."""
        E = self.E
        D = bm.array([[E, 0, 0],
                      [0, E, 0],
                      [0, 0, E]], dtype=bm.float64)
        return D
    
    def calculate_strain_and_stress(self,
                    uh: TensorLike,
                    x: float,
                    y: float,
                    z: float,
                    l: float) -> Tuple[TensorLike, TensorLike]:
        """Calculate the strain and stress.
                    ε = B * u_e
                    σ = D * ε
        Parameters:
            uh (TensorLike): Nodal displacement vector.
            x (float): Local coordinate in the axle cross-section along the x-axis.
            y (float): Local coordinate in the axle cross-section along the y-axis.
            z (float): Local coordinate in the axle cross-section along the z-axis.
            l (float): Length of the beam element.
        Returns:
            Tuple[TensorLike, TensorLike]: Strain and stress vectors.
        """
        L = self.linear_basis(x, l)
        strain = L @ uh
        stress = self.stress_matrix() @ strain
        return strain, stress
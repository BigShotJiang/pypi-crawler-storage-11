import sys
import os
# ensure package import from local src
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import ryzenai


def test_device_info_returns_dict():
    info = ryzenai.device_info()
    assert isinstance(info, dict)
    assert 'platform' in info
    assert 'providers' in info

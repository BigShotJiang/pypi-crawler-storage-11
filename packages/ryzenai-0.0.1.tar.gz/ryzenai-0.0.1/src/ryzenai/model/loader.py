"""Model loader utilities"""
from typing import Dict




def load_onnx_model(path: str) -> Dict:
# for now just return metadata; actual model is loaded by backend
return {"path": path}
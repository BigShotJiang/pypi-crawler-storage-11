# Default to the clean, minimal implementation under the _lite package.
from ._lite import load_model, Model, device_info, benchmark_model


__all__ = ["load_model", "Model", "device_info", "benchmark_model"]
"""Model loader utilities for the minimal implementation."""
from typing import Dict


def load_onnx_model(path: str) -> Dict:
    # In this minimal implementation we return a small metadata dict.
    return {"path": path}

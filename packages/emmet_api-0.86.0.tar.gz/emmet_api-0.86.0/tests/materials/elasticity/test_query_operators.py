from emmet.api.routes.materials.elasticity.query_operators import (
    BulkModulusQuery,
    ShearModulusQuery,
    PoissonQuery,
    ElasticityChemsysQuery,
)


def test_bulk_modulus_query():
    op = BulkModulusQuery()

    q = op.query(
        k_voigt_min=0,
        k_voigt_max=5,
        k_reuss_min=0,
        k_reuss_max=5,
        k_vrh_min=0,
        k_vrh_max=5,
    )

    fields = ["bulk_modulus.voigt", "bulk_modulus.reuss", "bulk_modulus.vrh"]

    assert q == {"criteria": {field: {"$gte": 0, "$lte": 5} for field in fields}}


def test_shear_modulus_query():
    op = ShearModulusQuery()

    q = op.query(
        g_voigt_min=0,
        g_voigt_max=5,
        g_reuss_min=0,
        g_reuss_max=5,
        g_vrh_min=0,
        g_vrh_max=5,
    )

    fields = ["shear_modulus.voigt", "shear_modulus.reuss", "shear_modulus.vrh"]

    assert q == {"criteria": {field: {"$gte": 0, "$lte": 5} for field in fields}}


def test_poisson_query():
    op = PoissonQuery()

    q = op.query(
        elastic_anisotropy_min=0,
        elastic_anisotropy_max=5,
        poisson_min=0,
        poisson_max=5,
    )

    fields = ["universal_anisotropy", "homogeneous_poisson"]

    assert q == {"criteria": {field: {"$gte": 0, "$lte": 5} for field in fields}}


def test_chemsys_query():
    op = ElasticityChemsysQuery()

    assert op.query(chemsys="Fe-Bi-O") == {"criteria": {"chemsys": "Bi-Fe-O"}}

    assert op.query(chemsys="Fe-Bi-O, Si-O") == {
        "criteria": {"chemsys": {"$in": ["Bi-Fe-O", "O-Si"]}}
    }

# Embedded dars.min.js content (ESM + global)
DARS_MIN_JS = """/* Dars minimal runtime: state + DOM updates (ESM + global) */
const __registry = new Map();

function registerState(name, cfg){
  if(!name || !cfg || !cfg.id) return;
  const entry = {
    id: cfg.id,
    states: Array.isArray(cfg.states) ? cfg.states.slice() : [],
    current: 0,
    isCustom: !!cfg.isCustom,
    rules: (cfg.rules && typeof cfg.rules === 'object') ? cfg.rules : {}
  };
  __registry.set(name, entry);
}

function getState(name){ return __registry.get(name); }

function $(id){ return document.getElementById(id) || document.querySelector(`[data-id=\"${id}\"]`) || null; }

function _applyMods(defaultId, mods){
  if(!Array.isArray(mods) || !mods.length) return;
  for(const m of mods){
    try{
      const op = m && m.op;
      if(!op) continue;
      const tid = (m && m.target) ? m.target : defaultId;
      const el = $(tid);
      if(!el) continue;
      if(op === 'inc' || op === 'dec'){
        const prop = m.prop || 'text';
        const by = Number(m.by || (op==='dec'?-1:1));
        if(prop === 'text'){
          const cur = parseFloat(el.textContent||'0') || 0;
          el.textContent = String(cur + by);
        } else {
          const cur = parseFloat(el.getAttribute(prop)||'0') || 0;
          el.setAttribute(prop, String(cur + by));
        }
      } else if(op === 'set'){
        const attrs = m.attrs || {};
        for(const k in attrs){
          if(k === 'text') el.textContent = String(attrs[k]);
          else if(k === 'html') el.innerHTML = String(attrs[k]);
          else el.setAttribute(k, String(attrs[k]));
        }
      } else if(op === 'toggleClass'){
        const name = m.name || '';
        const on = m.hasOwnProperty('on') ? !!m.on : null;
        if(!name) continue;
        if(on === null){ el.classList.toggle(name); }
        else if(on){ el.classList.add(name); }
        else { el.classList.remove(name); }
      } else if(op === 'appendText'){
        el.textContent = String(el.textContent||'') + String(m.value||'');
      } else if(op === 'prependText'){
        el.textContent = String(m.value||'') + String(el.textContent||'');
      }
    }catch(_){ /* ignore individual mod errors */ }
  }
}

function _resolveGoto(cur, goto, statesLen){
  if(goto == null) return cur;
  if(typeof goto === 'number') return goto;
  if(typeof goto === 'string'){
    if(/^[-+]\d+$/.test(goto)){
      const delta = parseInt(goto, 10);
      const next = cur + delta;
      if(statesLen && statesLen > 0){
        // clamp to [0, statesLen-1]
        return Math.max(0, Math.min(statesLen-1, next));
      }
      return next;
    }
    const n = parseInt(goto, 10);
    if(!isNaN(n)) return n;
  }
  return cur;
}

function change(opt){
  if(!opt||!opt.id) return;
  // Custom replacement path first
  if(opt.useCustomRender && typeof opt.html === 'string'){
    const el = $(opt.id);
    if(!el) return;
    el.innerHTML = opt.html;
    if(typeof window.DarsHydrate === 'function'){ try{ window.DarsHydrate(el); }catch(e){} }
    return;
  }

  // Stateful path with rules/mods
  const name = opt.name || null;
  const st = name ? __registry.get(name) : null;
  let targetState = (typeof opt.state === 'number') ? opt.state : null;
  let goto = (opt.hasOwnProperty('goto') ? opt.goto : null);
  if(st){
    const cur = st.current || 0;
    const len = Array.isArray(st.states) ? st.states.length : 0;
    if(goto !== null){
      targetState = _resolveGoto(cur, goto, len);
    }
    if(targetState === null){ targetState = cur; }
    st.current = targetState;
    const rules = st.rules && st.rules[String(targetState)];
    if(rules){
      if(Array.isArray(rules.mods)){
        _applyMods(st.id, rules.mods);
      }
      if(rules.hasOwnProperty('goto')){
        // Avoid infinite loops: single hop of goto in rules
        const nxt = _resolveGoto(st.current, rules.goto, len);
        if(nxt !== st.current){ st.current = nxt; }
      }
    }
  }

  try{
    const el = $(opt.id);
    if(!el) return;
    const ev = new CustomEvent('dars:state', { detail: { id: opt.id, state: targetState } });
    el.dispatchEvent(ev);
  }catch(e){ /* noop */ }
}

const Dars = { registerState, getState, change, $ };

try { window.Dars = window.Dars || Dars; } catch(_) {}

export { registerState, getState, change, $ };
export default Dars;
"""

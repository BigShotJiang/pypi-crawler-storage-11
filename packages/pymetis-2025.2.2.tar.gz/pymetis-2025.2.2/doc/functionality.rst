Functionality
=============

.. automodule:: pymetis

######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.5.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-11-05T20:30:43.255882                                                            #
######################################################################################################

from __future__ import annotations

import metaflow
import typing
if typing.TYPE_CHECKING:
    import metaflow.decorators

from ...exception import MetaflowException as MetaflowException

class ExitHookDecorator(metaflow.decorators.FlowDecorator, metaclass=type):
    def flow_init(self, flow, graph, environment, flow_datastore, metadata, logger, echo, options):
        ...
    ...


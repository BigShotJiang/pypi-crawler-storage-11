import asyncio
import aiohttp
import time
from rnet import Client  # rnet 需要 pip install rnet

URL = "https://futures.ourbit.com/api/v1/contract/systemSetting"

HEADERS = {
    "accept": "*/*",
    "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    "cache-control": "no-cache",
    "language": "Chinese",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://futures.ourbit.com/zh-CN/exchange/LAYER_USDT",
    "sec-ch-ua": '"Microsoft Edge";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"macOS"',
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0",
}

async def test_aiohttp(n=10):
    async with aiohttp.ClientSession() as session:
        start = time.perf_counter()
        for _ in range(n):
            async with session.get(URL, headers=HEADERS) as resp:
                await resp.text()
        end = time.perf_counter()
    return (end - start) / n

async def test_rnet(n=10):
    client = Client()
    start = time.perf_counter()
    for _ in range(n):
        await client.get(URL, headers=HEADERS)
    end = time.perf_counter()
    return (end - start) / n

async def main():
    aio_t = await test_aiohttp()
    rnet_t = await test_rnet()
    print(f"Aiohttp 平均响应时间: {aio_t:.3f}s")
    print(f"Rnet 平均响应时间:   {rnet_t:.3f}s")
    faster = "aiohttp" if aio_t < rnet_t else "rnet"
    print(f"🏁 更快的是: {faster}")

if __name__ == "__main__":
    asyncio.run(main())
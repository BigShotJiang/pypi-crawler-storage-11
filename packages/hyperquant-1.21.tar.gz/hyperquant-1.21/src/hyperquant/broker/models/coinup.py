from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Awaitable, TYPE_CHECKING
import zlib

from aiohttp import ClientResponse
from pybotters.store import DataStore, DataStoreCollection

if TYPE_CHECKING:
    from pybotters.typedefs import Item
    from pybotters.ws import ClientWebSocketResponse

logger = logging.getLogger(__name__)

# {"event_rep":"","channel":"market_e_wlfiusdt_depth_step0","data":null,"tick":{"asks":[[0.1402,9864],[0.1403,23388],[0.1404,9531],[0.1405,4995],[0.1406,3074],[0.1407,18736],[0.1408,3514],[0.1409,6326],[0.141,13217],[0.1411,18253],[0.1412,12214],[0.1413,15243],[0.1414,3606],[0.1415,14894],[0.1416,7932],[0.1417,4973],[0.1418,13031],[0.1419,19793],[0.142,17093],[0.1421,19395],[0.1422,12793],[0.1423,17846],[0.1424,15320],[0.1425,13313],[0.1426,20405],[0.1427,6611],[0.1428,17688],[0.1429,16308],[0.143,10073],[0.1431,15438]],"buys":[[0.1401,9473],[0.14,17486],[0.1399,11957],[0.1398,4824],[0.1397,18447],[0.1396,16929],[0.1395,19859],[0.1394,7283],[0.1393,19609],[0.1392,13638],[0.1391,4146],[0.139,3924],[0.1389,21574],[0.1388,14692],[0.1387,13772],[0.1386,21153],[0.1385,19533],[0.1384,20164],[0.1383,2645],[0.1382,17852],[0.1381,21453],[0.138,19162],[0.1379,17365],[0.1378,9061],[0.1377,14713],[0.1376,12023],[0.1375,11245],[0.1374,9633],[0.1373,5124],[0.1372,5140]]},"ts":1761239630000,"status":"ok"}

class Book(DataStore):

    _KEYS = ["s", "S", "p"]

    def _init(self) -> None:
        self.limit: int | None = None

    def _on_message(self, msg: Any) -> None:
        asks = msg["tick"]["asks"]
        bids = msg["tick"]["buys"]
        if self.limit is not None:
            asks = asks[: self.limit]
            bids = bids[: self.limit]
        chanel = msg["channel"]
        symbol = chanel.split("_")[2].upper()
        symbol = symbol.replace("USDT", "-USDT")
        asks = [
            {"s": symbol, "S": "a", "p": float(price), "q": float(quantity)} for price, quantity in asks
        ]
        bids = [
            {"s": symbol, "S": "b", "p": float(price), "q": float(quantity)} for price, quantity in bids
        ]
        self._find_and_delete({"s": symbol})
        self._insert(asks + bids)

class Detail(DataStore):

    _KEYS = ["symbol"]

    def _onresponse(self, data: Any) -> None:
        data = data.get("data", {})
        clist = data.get("contractList", [])
        # coinResultVo -> marginCoinPrecision 取出来
        for c in clist:
            p = c.get("coinResultVo", {}).get("marginCoinPrecision")
            p = 10 ** (-p)
            c["tick_size"] = p
            c['TickSize'] = p  # 兼容用大写开头的字段
        self._update(clist)

class Position(DataStore):

    _KEYS = ["symbol"]

    def _onresponse(self, data: Any) -> None:
        data = data.get("data", [])
        p_list = data.get("positionList", [])
        self._clear()
        self._update(p_list)

class Balance(DataStore):

    _KEYS = ["symbol"]

    def _onresponse(self, data: Any) -> None:
        data = data.get("data", [])
        b_list = data.get("accountList", [])
        self._clear()
        self._update(b_list)

class Orders(DataStore):

    _KEYS = ["orderId"]

    @staticmethod
    def _normalize(entry: dict[str, Any]) -> dict[str, Any] | None:
        order_id = entry.get("orderId")
        if order_id is None:
            return None
        normalized = dict(entry)
        normalized["orderId"] = str(order_id)
        return normalized

    def _onresponse(self, data: Any) -> None:
        payload: Any = data
        if isinstance(data, dict):
            payload = data.get("data") or data
            if isinstance(payload, dict):
                payload = payload.get("orderList") or payload.get("orders") or []

        items: list[dict[str, Any]] = []
        if isinstance(payload, list):
            for entry in payload:
                if not isinstance(entry, dict):
                    continue
                normalized = self._normalize(entry)
                if normalized:
                    items.append(normalized)

        self._clear()
        if items:
            self._insert(items)

class HistoryOrders(DataStore):

    _KEYS = ["orderId"]

    @staticmethod
    def _normalize(entry: dict[str, Any]) -> dict[str, Any] | None:
        order_id = entry.get("orderId")
        if order_id is None:
            return None
        normalized = dict(entry)
        normalized["orderId"] = str(order_id)
        return normalized

    def _onresponse(self, data: Any) -> None:
        payload: Any = data
        if isinstance(data, dict):
            payload = data.get("data") or data
            if isinstance(payload, dict):
                payload = payload.get("orderList") or payload.get("orders") or []

        items: list[dict[str, Any]] = []
        if isinstance(payload, list):
            for entry in payload:
                if not isinstance(entry, dict):
                    continue
                normalized = self._normalize(entry)
                if normalized:
                    items.append(normalized)

        self._clear()
        if items:
            self._insert(items)

class CoinUpDataStore(DataStoreCollection):
    def _init(self) -> None:
        self._create("book", datastore_class=Book)
        self._create("detail", datastore_class=Detail)
        self._create("position", datastore_class=Position)
        self._create("balance", datastore_class=Balance)
        self._create("orders", datastore_class=Orders)
        self._create("history_orders", datastore_class=HistoryOrders)

    def onmessage(self, msg: Item, ws: ClientWebSocketResponse | None = None) -> None:
        decompressed = zlib.decompress(msg, 16 + zlib.MAX_WBITS)
        text = decompressed.decode("utf-8")
        data = json.loads(text)
        chanel = data.get("channel", "")
        if 'depth' in chanel:
            self.book._on_message(data)

    def onresponse(self, data: Any) -> None:
        pass
    

    @property
    def book(self) -> Book:
        """
        .. code:: json

            {
                "s": "BTCUSDT",
                "S": "a",  # 卖单
                "p": "95640.3",
                "q": "0.807"
            }
        
        """
        return self._get("book")

    @property
    def detail(self) -> Detail:
        """
        .. code:: json

            {
                "id": 117,
                "contractName": "E-RESOLV-USDT",
                "symbol": "RESOLV-USDT",
                "contractType": "E",
                "coType": "E",
                "contractShowType": "USDT合约",
                "deliveryKind": "0",
                "contractSide": 1,
                "multiplier": 22.8000000000000000,
                "multiplierCoin": "RESOLV",
                "marginCoin": "USDT",
                "originalCoin": "USDT",
                "marginRate": 1.00000000,
                "capitalStartTime": 0,
                "capitalFrequency": 8,
                "settlementFrequency": 1,
                "brokerId": 1,
                "base": "RESOLV",
                "quote": "USDT",
                "coinResultVo": {
                    "symbolPricePrecision": 5,
                    "depth": [
                        "5",
                        "4",
                        "3"
                    ],
                    "minOrderVolume": 1,
                    "minOrderMoney": 1,
                    "maxMarketVolume": 5000000,
                    "maxMarketMoney": 6411360,
                    "maxLimitVolume": 5000000,
                    "maxLimitMoney": 5000000.0000000000000000,
                    "priceRange": 0.3000000000,
                    "marginCoinPrecision": 4,
                    "fundsInStatus": 1,
                    "fundsOutStatus": 1
                },
                "sort": 100,
                "maxLever": 75,
                "minLever": 1,
                "contractOtherName": "RESOLV/USDT",
                "subSymbol": "e_resolvusdt",
                "classification": 1,
                "nextCapitalSettTime": 1761292800000,
                "tick_size": 0.0001
            }
        """
        return self._get("detail")

    @property
    def position(self) -> Position:
        """
        _key: symbol

        .. code:: json

            {
                "id": 256538,
                "contractId": 169,
                "contractName": "E-WLFI-USDT",
                "contractOtherName": "WLFI/USDT",
                "symbol": "WLFI-USDT",
                "positionVolume": 1.0,
                "canCloseVolume": 1.0,
                "closeVolume": 0.0,
                "openAvgPrice": 0.1409,
                "indexPrice": 0.14040034,
                "reducePrice": -0.9769279224708908,
                "holdAmount": 16.53718437074,
                "marginRate": 7.852395215348719,
                "realizedAmount": 0.0,
                "returnRate": -0.0177310149041873,
                "orderSide": "BUY",
                "positionType": 1,
                "canUseAmount": 16.11598335074,
                "canSubMarginAmount": 0,
                "openRealizedAmount": -0.0074949,
                "keepRate": 0.015,
                "maxFeeRate": 2.0E-4,
                "unRealizedAmount": -0.0074949,
                "leverageLevel": 5,
                "positionBalance": 2.1060051,
                "tradeFee": "-0.0004",
                "capitalFee": "0",
                "closeProfit": "0",
                "settleProfit": "0",
                "shareAmount": "0",
                "historyRealizedAmount": "-0.0004227",
                "profitRealizedAmount": "-0.0004",
                "openAmount": 0.4227,
                "adlLevel": 2
            }
        
        """
        return self._get("position")

    @property
    def balance(self) -> Balance:
        """
        _key: symbol

        .. code:: json

            {
                "symbol": "USDT",
                "originalCoin": "USDT",
                "unRealizedAmount": "-0.0074949",
                "realizedAmount": "0",
                "totalMargin": "16.53718437074",
                "totalAmount": "16.53718437074",
                "canUseAmount": 16.11598335074,
                "availableAmount": 16.11598335074,
                "isolateMargin": "0",
                "walletBalance": "16.54467927074",
                "lockAmount": "0",
                "accountNormal": "16.54467927074",
                "totalMarginRate": "7.8523952153487187"
            }
        """
        return self._get("balance")

    @property
    def orders(self) -> Orders:
        """
        _key: orderId

        .. code:: json

            {
                "orderId": "2951913499074783723",
                "contractId": 169,
                "side": "SELL",
                "price": 0.15,
                "volume": 1,
                "status": 0
            }
        """
        return self._get("orders")

    @property
    def history_orders(self) -> HistoryOrders:
        """
        _key: orderId

        历史委托记录，与 ``orders`` 结构一致。
        """
        return self._get("history_orders")

# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class NamespaceMetadata:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'public': 'str'
    }

    attribute_map = {
        'public': 'public'
    }

    def __init__(self, public=None):
        r"""NamespaceMetadata

        The model defined in huaweicloud sdk

        :param public: 是否公开，可选true、false
        :type public: str
        """
        
        

        self._public = None
        self.discriminator = None

        self.public = public

    @property
    def public(self):
        r"""Gets the public of this NamespaceMetadata.

        是否公开，可选true、false

        :return: The public of this NamespaceMetadata.
        :rtype: str
        """
        return self._public

    @public.setter
    def public(self, public):
        r"""Sets the public of this NamespaceMetadata.

        是否公开，可选true、false

        :param public: The public of this NamespaceMetadata.
        :type public: str
        """
        self._public = public

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, NamespaceMetadata):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

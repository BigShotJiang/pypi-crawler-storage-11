__version__ = '2.16.0'


# Links to documentation to use over the project sources
DOCS_LINK = "https://shub.readthedocs.io/en/stable/"
DEPLOY_DOCS_LINK = DOCS_LINK + "deploying.html#deploying-dependencies"
CONFIG_DOCS_LINK = DOCS_LINK + "configuration.html"

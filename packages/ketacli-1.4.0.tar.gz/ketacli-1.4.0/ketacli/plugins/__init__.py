"""
Ketacli plugins module
"""
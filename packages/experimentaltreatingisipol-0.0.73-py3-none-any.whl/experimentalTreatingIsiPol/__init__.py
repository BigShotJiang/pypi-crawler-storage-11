def teste():
    return 'ok'
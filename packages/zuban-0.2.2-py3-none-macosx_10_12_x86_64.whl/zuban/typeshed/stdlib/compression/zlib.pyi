from zlib import *

---
url: https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:costituzione:1947-12-27;1
url_xml: https://www.normattiva.it/do/atto/caricaAKN?dataGU=19471227&codiceRedaz=047U0001&dataVigenza=20251101
dataGU: 19471227
codiceRedaz: 047U0001
dataVigenza: 20251101
---

# COSTITUZIONE DELLA REPUBBLICA ITALIANA

IL CAPO PROVVISORIO DELLO STATO

Vista la deliberazione dell'Assemblea Costituente, che nella seduta del 22 dicembre 1947 ha approvato la Costituzione della Repubblica Italiana;

Vista la XVIII disposizione finale della Costituzione;

PROMULGA la Costituzione della Repubblica Italiana nel seguente testo:

## PRINCIPI FONDAMENTALI - - - -

### Art. 1.

L'Italia e' una Repubblica democratica, fondata sul lavoro. La sovranita' appartiene al popolo, che la esercita nelle forme e nei limiti della Costituzione.

### Art. 2.

La Repubblica riconosce e garantisce i diritti inviolabili dell'uomo, sia come singolo sia nelle formazioni sociali ove si svolge la sua personalita', e richiede l'adempimento dei doveri inderogabili di solidarieta' politica, economica e sociale.

### Art. 3.

Tutti i cittadini hanno pari dignita' sociale e sono eguali davanti alla legge, senza distinzione di sesso, di razza, di lingua, di religione, di opinioni politiche, di condizioni personali e sociali. E' compito della Repubblica rimuovere gli ostacoli di ordine economico e sociale, che, limitando di fatto la liberta' e l'eguaglianza dei cittadini, impediscono il pieno sviluppo della persona umana e l'effettiva partecipazione di tutti i lavoratori all'organizzazione politica, economica e sociale del Paese.

### Art. 4.

La Repubblica riconosce a tutti i cittadini il diritto al lavoro e promuove le condizioni che rendano effettivo questo diritto. Ogni cittadino ha il dovere di svolgere, secondo le proprie possibilita' e la propria scelta, un'attivita' o una funzione che concorra al progresso materiale o spirituale della societa'.

### Art. 5.

La Repubblica, una e indivisibile, riconosce e promuove le autonomie locali; attua nei servizi che dipendono dallo Stato il piu' ampio decentramento amministrativo; adegua i principi ed i metodi della sua legislazione alle esigenze dell'autonomia e del decentramento.

### Art. 6.

La Repubblica tutela con apposite norme le minoranze linguistiche.

### Art. 7.

Lo Stato e la Chiesa cattolica sono, ciascuno nel proprio ordine, indipendenti e sovrani. I loro rapporti sono regolati dai Patti Lateranensi. Le modificazioni dei Patti, accettate dalle due parti, non richiedono procedimento di revisione costituzionale.

### Art. 8.

Tutte le confessioni religiose sono egualmente libere davanti alla legge. Le confessioni religiose diverse dalla cattolica hanno diritto di organizzarsi secondo i propri statuti, in quanto non contrastino con l'ordinamento giuridico italiano. I loro rapporti con lo Stato sono regolati per legge sulla base di intese con le relative rappresentanze.

### Art. 9.

La Repubblica promuove lo sviluppo della cultura e la ricerca scientifica e tecnica. Tutela il paesaggio e il patrimonio storico e artistico della Nazione. ((Tutela l'ambiente, la biodiversita' e gli ecosistemi, anche nell'interesse delle future generazioni. La legge dello Stato disciplina i modi e le forme di tutela degli animali)).

### Art. 10.

L'ordinamento giuridico italiano si conforma alle norme del diritto internazionale generalmente riconosciute. La condizione giuridica dello straniero e' regolata dalla legge in conformita' delle norme e dei trattati internazionali. Lo straniero, al quale sia impedito nel suo paese l'effettivo esercizio delle liberta' democratiche garantite dalla Costituzione italiana, ha diritto d'asilo nel territorio della Repubblica, secondo le condizioni stabilite dalla legge. Non e' ammessa l'estradizione dello straniero per reati politici. ((5))

------------- AGGIORNAMENTO (5) La L. costituzionale 21 giugno 1967, n. 1 ha disposto (con l'articolo unico) che l'ultimo comma del presente articolo non si applica ai delitti di genocidio.

### Art. 11.

L'Italia ripudia la guerra come strumento di offesa alla liberta' degli altri popoli e come mezzo di risoluzione delle controversie internazionali; consente, in condizioni di parita' con gli altri Stati, alle limitazioni di sovranita' necessarie ad un ordinamento che assicuri la pace e la giustizia fra le Nazioni; promuove e favorisce le organizzazioni internazionali rivolte a tale scopo.

### Art. 12.

La bandiera della Repubblica e' il tricolore italiano: verde, bianco e rosso, a tre bande verticali di eguali dimensioni.

## PARTE I DIRITTI E DOVERI DEI CITTADINI TITOLO I RAPPORTI CIVILI

### Art. 13.

La liberta' personale e' inviolabile. Non e' ammessa forma alcuna di detenzione, di ispezione o perquisizione personale, ne' qualsiasi altra restrizione della liberta' personale, se non per atto motivato dall'autorita' giudiziaria e nei soli casi e modi previsti dalla legge. In casi eccezionali di necessita' ed urgenza, indicati tassativamente dalla legge, l'autorita' di pubblica sicurezza puo' adottare provvedimenti provvisori, che devono essere comunicati entro quarantotto ore all'autorita' giudiziaria e, se questa non li convalida nelle successive quarantotto ore, si intendono revocati e restano privi di ogni effetto. E' punita ogni violenza fisica e morale sulle persone comunque sottoposte a restrizioni di liberta'. La legge stabilisce i limiti massimi della carcerazione preventiva.

### Art. 14.

Il domicilio e' inviolabile. Non vi si possono eseguire ispezioni o perquisizioni o sequestri, se non nei casi e modi stabiliti dalla legge secondo le garanzie prescritte per la tutela della liberta' personale. Gli accertamenti e le ispezioni per motivi di sanita' e di incolumita' pubblica o a fini economici e fiscali sono regolati da leggi speciali.

### Art. 15.

La liberta' e la segretezza della corrispondenza e di ogni altra forma di comunicazione sono inviolabili. La loro limitazione puo' avvenire soltanto per atto motivato dell'autorita' giudiziaria con le garanzie stabilite dalla legge.

### Art. 16.

Ogni cittadino puo' circolare e soggiornare liberamente in qualsiasi parte del territorio nazionale, salvo le limitazioni che la legge stabilisce in via generale per motivi di sanita' o di sicurezza. Nessuna restrizione puo' essere determinata da ragioni politiche. Ogni cittadino e' libero di uscire dal territorio della Repubblica e di rientrarvi, salvo gli obblighi di legge.

### Art. 17.

I cittadini hanno diritto di riunirsi pacificamente e senz'armi. Per le riunioni, anche in luogo aperto al pubblico, non e' richiesto preavviso. Delle riunioni in luogo pubblico deve essere dato preavviso alle autorita', che possono vietarle soltanto per comprovati motivi di sicurezza o di incolumita' pubblica.

### Art. 18.

I cittadini hanno diritto di associarsi liberamente, senza autorizzazione, per fini che non sono vietati ai singoli dalla legge penale. Sono proibite le associazioni segrete e quelle che perseguono, anche indirettamente, scopi politici mediante organizzazioni di carattere militare.

### Art. 19.

Tutti hanno diritto di professare liberamente la propria fede religiosa in qualsiasi forma, individuale o associata, di farne propaganda e di esercitarne in privato o in pubblico il culto, purche' non si tratti di riti contrari al buon costume.

### Art. 20.

Il carattere ecclesiastico e il fine di religione o di culto d'una associazione od istituzione non possono essere causa di speciali limitazioni legislative, ne' di speciali gravami fiscali per la sua costituzione, capacita' giuridica e ogni forma di attivita'.

### Art. 21.

Tutti hanno diritto di manifestare liberamente il proprio pensiero con la parola, lo scritto e ogni altro mezzo di diffusione. La stampa non puo' essere soggetta ad autorizzazioni o censure. Si puo' procedere a sequestro soltanto per atto motivato dell'autorita' giudiziaria nel caso di delitti, per i quali la legge sulla stampa espressamente lo autorizzi, o nel caso di violazione delle norme che la legge stessa prescriva per l'indicazione dei responsabili. In tali casi, quando vi sia assoluta urgenza e non sia possibile il tempestivo intervento dell'autorita' giudiziaria, il sequestro della stampa periodica puo' essere eseguito da ufficiali di polizia giudiziaria, che devono immediatamente, e non mai oltre ventiquattro ore, fare denunzia all'autorita' giudiziaria. Se questa non lo convalida nelle ventiquattro ore successive, il sequestro s'intende revocato e privo d'ogni effetto. La legge puo' stabilire, con norme di carattere generale, che siano resi noti i mezzi di finanziamento della stampa periodica. Sono vietate le pubblicazioni a stampa, gli spettacoli e tutte le altre manifestazioni contrarie al buon costume. La legge stabilisce provvedimenti adeguati a prevenire e a reprimere le violazioni.

### Art. 22.

Nessuno puo' essere privato, per motivi politici, della capacita' giuridica, della cittadinanza, del nome.

### Art. 23.

Nessuna prestazione personale o patrimoniale puo' essere imposta se non in base alla legge.

### Art. 24.

Tutti possono agire in giudizio per la tutela dei propri diritti e interessi legittimi. La difesa e' diritto inviolabile in ogni stato e grado del procedimento. Sono assicurati ai non abbienti, con appositi istituti, i mezzi per agire e difendersi davanti ad ogni giurisdizione. La legge determina le condizioni e i modi per la riparazione degli errori giudiziari.

### Art. 25.

Nessuno puo' essere distolto dal giudice naturale precostituito per legge. Nessuno puo' essere punito se non in forza di una legge che sia entrata in vigore prima del fatto commesso. Nessuno puo' essere sottoposto a misure di sicurezza se non nei casi previsti dalla legge.

### Art. 26.

L'estradizione del cittadino puo' essere consentita soltanto ove sia espressamente prevista dalle convenzioni internazionali. Non puo' in alcun caso essere ammessa per reati politici. ((5))

------------- AGGIORNAMENTO (5) La L. costituzionale 21 giugno 1967, n. 1 ha disposto (con l'articolo unico) che l'ultimo comma del presente articolo non si applica ai delitti di genocidio.

### Art. 27.

La responsabilita' penale e' personale. L'imputato non e' considerato colpevole sino alla condanna definitiva. Le pene non possono consistere in trattamenti contrari al senso di umanita' e devono tendere alla rieducazione del condannato. Non e' ammessa la pena di morte (( . . . )).

### Art. 28.

I funzionari e i dipendenti dello Stato e degli enti pubblici sono direttamente responsabili, secondo le leggi penali, civili e amministrative, degli atti compiuti in violazione di diritti. In tali casi la responsabilita' civile si estende allo Stato e agli enti pubblici.

## TITOLO II RAPPORTI ETICOSOCIALI

### Art. 29.

La Repubblica riconosce i diritti della famiglia come societa' naturale fondata sul matrimonio. Il matrimonio e' ordinato sull'eguaglianza morale e giuridica dei coniugi, con i limiti stabiliti dalla legge a garanzia dell'unita' familiare.

### Art. 30.

E' dovere e diritto dei genitori mantenere, istruire ed educare i figli, anche se nati fuori del matrimonio. Nei casi di incapacita' dei genitori, la legge provvede a che siano assolti i loro compiti. La legge assicura ai figli nati fuori del matrimonio ogni tutela giuridica e sociale, compatibile con i diritti dei membri della famiglia legittima. La legge detta le norme e i limiti per la ricerca della paternita'.

### Art. 31.

La Repubblica agevola con misure economiche e altre provvidenze la formazione della famiglia e l'adempimento dei compiti relativi, con particolare riguardo alle famiglie numerose. Protegge la maternita', l'infanzia e la gioventu', favorendo gli istituti necessari a tale scopo.

### Art. 32.

La Repubblica tutela la salute come fondamentale diritto dell'individuo e interesse della collettivita', e garantisce cure gratuite agli indigenti. Nessuno puo' essere obbligato a un determinato trattamento sanitario se non per disposizione di legge. La legge non puo' in nessun caso violare i limiti imposti dal rispetto della persona umana.

### Art. 33.

L'arte e la scienza sono libere e libero ne e' l'insegnamento. La Repubblica detta le norme generali sull'istruzione ed istituisce scuole statali per tutti gli ordini e gradi. Enti e privati hanno il diritto di istituire scuole ed istituti di educazione, senza oneri per lo Stato. La legge, nel fissare i diritti e gli obblighi delle scuole non statali che chiedono la parita', deve assicurare ad esse piena liberta' e ai loro alunni un trattamento scolastico equipollente a quello degli alunni di scuole statali. E' prescritto un esame di Stato per l'ammissione ai vari ordini e gradi di scuole o per la conclusione di essi e per l'abilitazione all'esercizio professionale. Le istituzioni di alta cultura, universita' ed accademie, hanno il diritto di darsi ordinamenti autonomi nei limiti stabiliti dalle leggi dello Stato. ((La Repubblica riconosce il valore educativo, sociale e di promozione del benessere psicofisico dell'attivita' sportiva in tutte le sue forme)).

### Art. 34.

La scuola e' aperta a tutti. L'istruzione inferiore, impartita per almeno otto anni, e' obbligatoria e gratuita. I capaci e meritevoli, anche se privi di mezzi, hanno diritto di raggiungere i gradi piu' alti degli studi. La Repubblica rende effettivo questo diritto con borse di studio, assegni alle famiglie ed altre provvidenze, che devono essere attribuite per concorso.

## TITOLO III RAPPORTI ECONOMICI

### Art. 35.

La Repubblica tutela il lavoro in tutte le sue forme ed applicazioni. Cura la formazione e l'elevazione professionale dei lavoratori. Promuove e favorisce gli accordi e le organizzazioni internazionali intesi ad affermare e regolare i diritti del lavoro. Riconosce la liberta' di emigrazione, salvo gli obblighi stabiliti dalla legge nell'interesse generale, e tutela il lavoro italiano all'estero.

### Art. 36.

Il lavoratore ha diritto ad una retribuzione proporzionata alla quantita' e qualita' del suo lavoro e in ogni caso sufficiente ad assicurare a se' e alla famiglia un'esistenza libera e dignitosa. La durata massima della giornata lavorativa e' stabilita dalla legge. Il lavoratore ha diritto al riposo settimanale e a ferie annuali retribuite, e non puo' rinunziarvi.

### Art. 37.

La donna lavoratrice ha gli stessi diritti e, a parita' di lavoro, le stesse retribuzioni che spettano al lavoratore. Le condizioni di lavoro devono consentire l'adempimento della sua essenziale funzione familiare e assicurare alla madre e al bambino una speciale adeguata protezione. La legge stabilisce il limite minimo di eta' per il lavoro salariato. La Repubblica tutela il lavoro dei minori con speciali norme e garantisce ad essi, a parita' di lavoro, il diritto alla parita' di retribuzione.

### Art. 38.

Ogni cittadino inabile al lavoro e sprovvisto dei mezzi necessari per vivere ha diritto al mantenimento e all'assistenza sociale. I lavoratori hanno diritto che siano preveduti ed assicurati mezzi adeguati alle loro esigenze di vita in caso di infortunio, malattia, invalidita' e vecchiaia, disoccupazione involontaria. Gli inabili ed i minorati hanno diritto all'educazione e all'avviamento professionale. Ai compiti previsti in questo articolo provvedono organi ed istituti predisposti o integrati dallo Stato. L'assistenza privata e' libera.

### Art. 39.

L'organizzazione sindacale e' libera. Ai sindacati non puo' essere imposto altro obbligo se non la loro registrazione presso uffici locali o centrali, secondo le norme di legge. E' condizione per la registrazione che gli statuti dei sindacati sanciscano un ordinamento interno a base democratica. I sindacati registrati hanno personalita' giuridica. Possono, rappresentati unitariamente in proporzione dei loro iscritti, stipulare contratti collettivi di lavoro con efficacia obbligatoria per tutti gli appartenenti alle categorie alle quali il contratto si riferisce.

### Art. 40.

Il diritto di sciopero si esercita nell'ambito delle leggi che lo regolano.

### Art. 41.

L'iniziativa economica privata e' libera. Non puo' svolgersi in contrasto con l'utilita' sociale o in modo da recare danno ((alla salute, all'ambiente,)) alla sicurezza, alla liberta', alla dignita' umana. La legge determina i programmi e i controlli opportuni perche' l'attivita' economica pubblica e privata possa essere indirizzata e coordinata a fini sociali ((e ambientali)).

### Art. 42.

La proprieta' e' pubblica o privata. I beni economici appartengono allo Stato, ad enti o a privati. La proprieta' privata e' riconosciuta e garantita dalla legge, che ne determina i modi di acquisto, di godimento e i limiti allo scopo di assicurarne la funzione sociale e di renderla accessibile a tutti. La proprieta' privata puo' essere, nei casi preveduti dalla legge, e salvo indennizzo, espropriata per motivi d'interesse generale. La legge stabilisce le norme ed i limiti della successione legittima e testamentaria e i diritti dello Stato sulle eredita'.

### Art. 43.

A fini di utilita' generale la legge puo' riservare originariamente o trasferire, mediante espropriazione e salvo indennizzo, allo Stato, ad enti pubblici o a comunita' di lavoratori o di utenti determinate imprese o categorie di imprese, che si riferiscano a servizi pubblici essenziali o a fonti di energia o a situazioni di monopolio ed abbiano carattere di preminente interesse generale.

### Art. 44.

Al fine di conseguire il razionale sfruttamento del suolo e di stabilire equi rapporti sociali, la legge impone obblighi e vincoli alla proprieta' terriera privata, fissa limiti alla sua estensione secondo le regioni e le zone agrarie, promuove ed impone la bonifica delle terre, la trasformazione del latifondo e la ricostituzione delle unita' produttive; aiuta la piccola e la media proprieta'. La legge dispone provvedimenti a favore delle zone montane.

### Art. 45.

La Repubblica riconosce la funzione sociale della cooperazione a carattere di mutualita' e senza fini di speculazione privata. La legge ne promuove e favorisce l'incremento con i mezzi piu' idonei e ne assicura, con gli opportuni controlli, il carattere e le finalita'. La legge provvede alla tutela e allo sviluppo dell'artigianato.

### Art. 46.

Ai fini della elevazione economica e sociale del lavoro e in armonia con le esigenze della produzione, la Repubblica riconosce il diritto dei lavoratori a collaborare, nei modi e nei limiti stabiliti dalle leggi, alla gestione delle aziende.

### Art. 47.

La Repubblica incoraggia e tutela il risparmio in tutte le sue forme; disciplina, coordina e controlla l'esercizio del credito. Favorisce l'accesso del risparmio popolare alla proprieta' dell'abitazione, alla proprieta' diretta coltivatrice e al diretto e indiretto investimento azionario nei grandi complessi produttivi del Paese.

## TITOLO IV RAPPORTI POLITICI

### Art. 48.

Sono elettori tutti i cittadini, uomini e donne, che hanno raggiunto la maggiore eta'. Il voto e' personale ed eguale, libero e segreto. Il suo esercizio e' dovere civico. ((La legge stabilisce requisiti e modalita' per l'esercizio del diritto di voto dei cittadini residenti all'estero e ne assicura l'effettivita'. A tale fine e' istituita una circoscrizione Estero per l'elezione delle Camere, alla quale sono assegnati seggi nel numero stabilito da norma costituzionale e secondo criteri determinati dalla legge)). Il diritto di voto non puo' essere limitato se non per incapacita' civile o per effetto di sentenza penale irrevocabile o nei casi di indegnita' morale indicati dalla legge.

### Art. 49.

Tutti i cittadini hanno diritto di associarsi liberamente in partiti per concorrere con metodo democratico a determinare la politica nazionale.

### Art. 50.

Tutti i cittadini possono rivolgere petizioni alle Camere per chiedere provvedimenti legislativi o esporre comuni necessita'.

### Art. 51.

Tutti i cittadini dell'uno o dell'altro sesso possono accedere agli uffici pubblici e alle cariche elettive in condizioni di eguaglianza, secondo i requisiti stabiliti dalla legge. ((A tale fine la Repubblica promuove con appositi provvedimenti le pari opportunita' tra donne e uomini)). La legge puo', per l'ammissione ai pubblici uffici e alle cariche elettive, parificare ai cittadini gli italiani non appartenenti alla Repubblica. Chi e' chiamato a funzioni pubbliche elettive ha diritto di disporre del tempo necessario al loro adempimento e di conservare il suo posto di lavoro.

### Art. 52.

La difesa della Patria e' sacro dovere del cittadino. Il servizio militare e' obbligatorio nei limiti e modi stabiliti dalla legge. Il suo adempimento non pregiudica la posizione di lavoro del cittadino, ne' l'esercizio dei diritti politici. L'ordinamento delle Forze armate si informa allo spirito democratico della Repubblica.

### Art. 53.

Tutti sono tenuti a concorrere alle spese pubbliche in ragione della loro capacita' contributiva. Il sistema tributario e' informato a criteri di progressivita'.

### Art. 54.

Tutti i cittadini hanno il dovere di essere fedeli alla Repubblica e di osservarne la Costituzione e le leggi. I cittadini cui sono affidate funzioni pubbliche hanno il dovere di adempierle con disciplina ed onore, prestando giuramento nei casi stabiliti dalla legge.

### PARTE II ORDINAMENTO DELLA REPUBBLICA TITOLO I IL PARLAMENTO SEZIONE I Le Camere.

#### Art. 55.

Il Parlamento si compone della Camera dei deputati e del Senato della Repubblica. Il Parlamento si riunisce in seduta comune dei membri delle due Camere nei soli casi stabiliti dalla Costituzione.

#### Art. 56.

La Camera dei deputati e' eletta a suffragio universale e diretto. Il numero dei deputati e' di ((quattrocento)), ((otto)) dei quali eletti nella circoscrizione Estero. ((20)) Sono eleggibili a deputati tutti gli elettori che nel giorno delle elezioni hanno compiuto i venticinque anni di eta'. La ripartizione dei seggi tra le circoscrizioni, fatto salvo il numero dei seggi assegnati alla circoscrizione Estero, si effettua dividendo il numero degli abitanti della Repubblica, quale risulta dall'ultimo censimento generale della popolazione, per ((trecentonovantadue)) e distribuendo i seggi in proporzione alla popolazione di ogni circoscrizione, sulla base dei quozienti interi e dei piu' alti resti. (3) ((20))

------------- AGGIORNAMENTO (3) La L. costituzionale 9 febbraio 1963, n. 2, ha disposto (con l'art. 5) che la suddetta modifica entra in vigore con la prima convocazione dei comizi elettorali successiva alla sua pubblicazione nella Gazzetta Ufficiale della Repubblica. ------------- AGGIORNAMENTO (20) La L. costituzionale 19 ottobre 2020, n. 1 ha disposto (con l'art. 4, comma 1) che le presenti modifiche si applicano a decorrere dalla data del primo scioglimento o della prima cessazione delle Camere successiva alla data di entrata in vigore della suddetta legge costituzionale e comunque non prima che siano decorsi sessanta giorni dalla predetta data di entrata in vigore.

#### Art. 57.

Il Senato della Repubblica e' eletto a base regionale, salvi i seggi assegnati alla circoscrizione Estero. Il numero dei senatori elettivi e' di ((duecento)), ((quattro)) dei quali eletti nella circoscrizione Estero. ((20)) Nessuna Regione ((o Provincia autonoma)) puo' avere un numero di senatori inferiore a ((tre)); il Molise ne ha due, la Valle d'Aosta uno. ((20)). ((La ripartizione dei seggi tra le Regioni o le Province autonome, previa applicazione delle disposizioni del precedente comma, si effettua in proporzione alla loro popolazione, quale risulta dall'ultimo censimento generale, sulla base dei quozienti interi e dei piu' alti resti)). ((20))

------------- AGGIORNAMENTO (3) La L. costituzionale 9 febbraio 1963, n. 2, ha disposto (con l'art. 5) che la suddetta modifica entra in vigore con la prima convocazione dei comizi elettorali successiva alla sua pubblicazione nella Gazzetta Ufficiale della Repubblica. ------------- AGGIORNAMENTO (20) La L. costituzionale 19 ottobre 2020, n. 1 ha disposto (con l'art. 4, comma 1) che le presenti modifiche si applicano a decorrere dalla data del primo scioglimento o della prima cessazione delle Camere successiva alla data di entrata in vigore della suddetta legge costituzionale e comunque non prima che siano decorsi sessanta giorni dalla predetta data di entrata in vigore.

#### Art. 58.

I senatori sono eletti a suffragio universale e diretto ((...)). Sono eleggibili a senatori gli elettori che hanno compiuto il quarantesimo anno.

#### Art. 59.

E' senatore di diritto e a vita, salvo rinunzia, chi e' stato Presidente della Repubblica. ((Il Presidente della Repubblica puo' nominare senatori a vita cittadini che hanno illustrato la Patria per altissimi meriti nel campo sociale, scientifico, artistico e letterario. Il numero complessivo dei senatori in carica nominati dal Presidente della Repubblica non puo' in alcun caso essere superiore a cinque)).

#### Art. 60.

((La Camera dei deputati e il Senato della Repubblica sono eletti per cinque anni. La durata di ciascuna Camera non puo' essere prorogata se non per legge e soltanto in caso di guerra)). ((3))

------------- AGGIORNAMENTO (3) La L. costituzionale 9 febbraio 1963, n. 2, ha disposto (con l'art. 5) che la suddetta modifica entra in vigore con la prima convocazione dei comizi elettorali successiva alla sua pubblicazione nella Gazzetta Ufficiale della Repubblica.

#### Art. 61.

Le elezioni delle nuove Camere hanno luogo entro settanta giorni dalla fine delle precedenti. La prima riunione ha luogo non oltre il ventesimo giorno dalle elezioni. Finche' non siano riunite le nuove Camere sono prorogati i poteri delle precedenti.

#### Art. 62.

Le Camere si riuniscono di diritto il primo giorno non festivo di febbraio e di ottobre. Ciascuna Camera puo' essere convocata in via straordinaria per iniziativa del suo Presidente o del Presidente della Repubblica o di un terzo dei suoi componenti. Quando si riunisce in via straordinaria una Camera, e' convocata di diritto anche l'altra.

#### Art. 63.

Ciascuna Camera elegge fra i suoi componenti il Presidente e l'Ufficio di presidenza. Quando il Parlamento si riunisce in seduta comune, il Presidente e l'Ufficio di presidenza sono quelli della Camera dei deputati.

#### Art. 64.

Ciascuna Camera adotta il proprio regolamento a maggioranza assoluta dei suoi componenti. Le sedute sono pubbliche; tuttavia ciascuna delle due Camere e il Parlamento a Camere riunite possono deliberare di adunarsi in seduta segreta. Le deliberazioni di ciascuna Camera e del Parlamento non sono valide se non e' presente la maggioranza dei loro componenti, e se non sono adottate a maggioranza dei presenti, salvo che la Costituzione prescriva una maggioranza speciale. I membri del Governo, anche se non fanno parte delle Camere, hanno diritto, e se richiesti obbligo, di assistere alle sedute. Devono essere sentiti ogni volta che lo richiedono.

#### Art. 65.

La legge determina i casi di ineleggibilita' e di incompatibilita' con l'ufficio di deputato o di senatore. Nessuno puo' appartenere contemporaneamente alle due Camere.

#### Art. 66.

Ciascuna Camera giudica dei titoli di ammissione dei suoi componenti e delle cause sopraggiunte di ineleggibilita' e di incompatibilita'.

#### Art. 67.

Ogni membro del Parlamento rappresenta la Nazione ed esercita le sue funzioni senza vincolo di mandato.

#### Art. 68.

((I membri del Parlamento non possono essere chiamati a rispondere delle opinioni espresse e dei voti dati nell'esercizio delle loro funzioni. Senza autorizzazione della Camera alla quale appartiene, nessun membro del Parlamento puo' essere sottoposto a perquisizione personale o domiciliare, ne' puo' essere arrestato o altrimenti privato della liberta' personale, o mantenuto in detenzione, salvo che in esecuzione di una sentenza irrevocabile di condanna, ovvero se sia colto nell'atto di commettere un delitto per il quale e' previsto l'arresto obbligatorio in flagranza. Analoga autorizzazione e' richiesta per sottoporre i membri del Parlamento ad intercettazioni, in qualsiasi forma, di conversazioni o comunicazioni e a sequestro di corrispondenza)).

#### Art. 69.

I membri del Parlamento ricevono una indennita' stabilita dalla legge.

### SEZIONE II - La formazione delle leggi.

#### Art. 70.

La funzione legislativa e' esercitata collettivamente dalle due Camere.

#### Art. 71.

L'iniziativa delle leggi appartiene al Governo, a ciascun membro delle Camere ed agli organi ed enti ai quali sia conferita da legge costituzionale. Il popolo esercita l'iniziativa delle leggi, mediante la proposta, da parte di almeno cinquantamila elettori, di un progetto redatto in articoli.

#### Art. 72.

Ogni disegno di legge, presentato ad una Camera e', secondo le norme del suo regolamento, esaminato da una commissione e poi dalla Camera stessa, che l'approva articolo per articolo e con votazione finale. Il regolamento stabilisce procedimenti abbreviati per i disegni di legge dei quali e' dichiarata l'urgenza. Puo' altresi' stabilire in quali casi e forme l'esame e l'approvazione dei disegni di legge sono deferiti a commissioni, anche permanenti, composte in modo da rispecchiare la proporzione dei gruppi parlamentari. Anche in tali casi, fino al momento della sua approvazione definitiva, il disegno di legge e' rimesso alla Camera, se il Governo o un decimo dei componenti della Camera o un quinto della commissione richiedono che sia discusso o votato dalla Camera stessa oppure che sia sottoposto alla sua approvazione finale con sole dichiarazioni di voto. Il regolamento determina le forme di pubblicita' dei lavori delle commissioni. La procedura normale di esame e di approvazione diretta da parte della Camera e' sempre adottata per i disegni di legge in materia costituzionale ed elettorale e per quelli di delegazione legislativa, di autorizzazione a ratificare trattati internazionali, di approvazione di bilanci e consuntivi.

#### Art. 73.

Le leggi sono promulgate dal Presidente della Repubblica entro un mese dall'approvazione. Se le Camere, ciascuna a maggioranza assoluta dei propri componenti, ne dichiarano l'urgenza, la legge e' promulgata nel termine da essa stabilito. Le leggi sono pubblicate subito dopo la promulgazione ed entrano in vigore il quindicesimo giorno successivo alla loro pubblicazione, salvo che le leggi stesse stabiliscano un termine diverso.

#### Art. 74.

Il Presidente della Repubblica, prima di promulgare la legge, puo' con messaggio motivato alle Camere chiedere una nuova deliberazione. Se le Camere approvano nuovamente la legge, questa deve essere promulgata.

#### Art. 75.

E' indetto referendum popolare per deliberare la abrogazione, totale o parziale, di una legge o di un atto avente valore di legge, quando lo richiedono cinquecentomila elettori o cinque Consigli regionali. Non e' ammesso il referendum per le leggi tributarie e di bilancio, di amnistia e di indulto, di autorizzazione a ratificare trattati internazionali. Hanno diritto di partecipare al referendum tutti i cittadini chiamati ad eleggere la Camera dei deputati. La proposta soggetta a referendum e' approvata se ha partecipato alla votazione la maggioranza degli aventi diritto, e se e' raggiunta la maggioranza dei voti validamente espressi. La legge determina le modalita' di attuazione del referendum.

#### Art. 76.

L'esercizio della funzione legislativa non puo essere delegato al Governo se non con determinazione di principi e criteri direttivi e soltanto per tempo limitato e per oggetti definiti.

#### Art. 77.

Il Governo non puo', senza delegazione delle Camere, emanare decreti che abbiano valore di legge ordinaria. Quando, in casi straordinari di necessita' e d'urgenza, il Governo adotta, sotto la sua responsabilita', provvedimenti provvisori con forza di legge, deve il giorno stesso presentarli per la conversione alle Camere che, anche se sciolte, sono appositamente convocate e si riuniscono entro cinque giorni. I decreti perdono efficacia sin dall'inizio, se non sono convertiti in legge entro sessanta giorni dalla loro pubblicazione. Le Camere possono tuttavia regolare con legge i rapporti giuridici sorti sulla base dei decreti non convertiti.

#### Art. 78.

Le Camere deliberano lo stato di guerra e conferiscono al Governo i poteri necessari.

#### Art. 79.

((L'amnistia e l'indulto sono concessi con legge deliberata a maggioranza dei due terzi dei componenti di ciascuna Camera, in ogni suo articolo e nella votazione finale. La legge che concede l'amnistia o l'indulto stabilisce il termine per la loro applicazione. In ogni caso l'amnistia e l'indulto non possono applicarsi ai reati commessi successivamente alla presentazione del disegno di legge)).

#### Art. 80.

Le Camere autorizzano con legge la ratifica dei trattati internazionali che sono di natura politica, o prevedono arbitrati o regolamenti giudiziari, o importano variazioni del territorio od oneri alle finanze o modificazioni di leggi.

#### Art. 81.

((Lo Stato assicura l'equilibrio tra le entrate e le spese del proprio bilancio, tenendo conto delle fasi avverse e delle fasi favorevoli del ciclo economico. Il ricorso all'indebitamento e' consentito solo al fine di considerare gli effetti del ciclo economico e, previa autorizzazione delle Camere adottata a maggioranza assoluta dei rispettivi componenti, al verificarsi di eventi eccezionali. Ogni legge che importi nuovi o maggiori oneri provvede ai mezzi per farvi fronte. Le Camere ogni anno approvano con legge il bilancio e il rendiconto consuntivo presentati dal Governo. L'esercizio provvisorio del bilancio non puo' essere concesso se non per legge e per periodi non superiori complessivamente a quattro mesi. Il contenuto della legge di bilancio, le norme fondamentali e i criteri volti ad assicurare l'equilibrio tra le entrate e le spese dei bilanci e la sostenibilita' del debito del complesso delle pubbliche amministrazioni sono stabiliti con legge approvata a maggioranza assoluta dei componenti di ciascuna Camera, nel rispetto dei principi definiti con legge costituzionale)). ((19))

------------- AGGIORNAMENTO (19) La L. costituzionale 20 aprile 2012, n. 1 ha disposto (con l'art. 6, comma 1) che le suddette modifiche si applicano a decorrere dall'esercizio finanziario relativo all'anno 2014.

#### Art. 82.

Ciascuna Camera puo' disporre inchieste su materie di pubblico interesse. A tale scopo nomina fra i propri componenti una commissione formata in modo da rispecchiare la proporzione dei vari gruppi. La commissione d'inchiesta procede alle indagini e agli esami con gli stessi poteri e le stesse limitazioni dell'autorita' giudiziaria.

## TITOLO II IL PRESIDENTE DELLA REPUBBLICA

### Art. 83.

Il Presidente della Repubblica e' eletto dal Parlamento in seduta comune dei suoi membri. All'elezione partecipano tre delegati per ogni Regione eletti dal Consiglio regionale in modo che sia assicurata la rappresentanza delle minoranze. La Valle d'Aosta ha un solo delegato. L'elezione del Presidente della Repubblica ha luogo per scrutinio segreto a maggioranza di due terzi della assemblea. Dopo il terzo scrutinio e' sufficiente la maggioranza assoluta.

### Art. 84.

Puo' essere eletto Presidente della Repubblica ogni cittadino che abbia compiuto cinquanta anni d'eta' e goda dei diritti civili e politici. L'ufficio di Presidente della Repubblica e' incompatibile con qualsiasi altra carica. L'assegno e la dotazione del Presidente sono determinati per legge.

### Art. 85.

Il Presidente della Repubblica e' eletto per sette anni. Trenta giorni prima che scada il termine, il Presidente della Camera dei deputati convoca in seduta comune il Parlamento e i delegati regionali, per eleggere il nuovo Presidente della Repubblica. Se le Camere sono sciolte, o manca meno di tre mesi alla loro cessazione, la elezione ha luogo entro quindici giorni dalla riunione delle Camere nuove. Nel frattempo sono prorogati i poteri del Presidente in carica.

### Art. 86.

Le funzioni del Presidente della Repubblica, in ogni caso che egli non possa adempierle, sono esercitate dal Presidente del Senato. In caso di impedimento permanente o di morte o di dimissioni del Presidente della Repubblica, il Presidente della Camera dei deputati indice la elezione del nuovo Presidente della Repubblica entro quindici giorni, salvo il maggior termine previsto se le Camere sono sciolte o manca meno di tre mesi alla loro cessazione.

### Art. 87.

Il Presidente della Repubblica e' il capo dello Stato e rappresenta l'unita' nazionale. Puo' inviare messaggi alle Camere. Indice le elezioni delle nuove Camere e ne fissa la prima riunione. Autorizza la presentazione alle Camere dei disegni di legge di iniziativa del Governo. Promulga le leggi ed emana i decreti aventi valore di legge e i regolamenti. Indice il referendum popolare nei casi previsti dalla Costituzione. Nomina, nei casi indicati dalla legge, i funzionari dello Stato. Accredita e riceve i rappresentanti diplomatici, ratifica i trattati internazionali, previa, quando occorra, l'autorizzazione delle Camere. Ha il comando delle Forze armate, presiede il Consiglio supremo di difesa costituito secondo la legge, dichiara lo stato di guerra deliberato dalle Camere. Presiede il Consiglio superiore della magistratura. Puo' concedere grazia e commutare le pene. Conferisce le onorificenze della Repubblica.

### Art. 88.

Il Presidente della Repubblica puo', sentiti i loro Presidenti, sciogliere le Camere o anche una sola di esse. ((Non puo' esercitare tale facolta' negli ultimi sei mesi del suo mandato, salvo che essi coincidano in tutto o in parte con gli ultimi sei mesi della legislatura)).

### Art. 89.

Nessun atto del Presidente della Repubblica e' valido se non e' controfirmato dai ministri proponenti, che ne assumono la responsabilita'. Gli atti che hanno valore legislativo e gli altri indicati dalla legge sono controfirmati anche dal Presidente del Consiglio dei ministri.

### Art. 90.

Il Presidente della Repubblica non e' responsabile degli atti compiuti nell'esercizio delle sue funzioni, tranne che per alto tradimento o per attentato alla Costituzione. In tali casi e' messo in stato di accusa dal Parlamento in seduta comune, a maggioranza assoluta dei suoi membri.

### Art. 91.

Il Presidente della Repubblica, prima di assumere le sue funzioni, presta giuramento di fedelta' alla Repubblica e di osservanza della Costituzione dinanzi al Parlamento in seduta comune.

### TITOLO III IL GOVERNO SEZIONE I Il Consiglio dei ministri.

#### Art. 92.

Il Governo della Repubblica e' composto del Presidente del Consiglio e dei ministri, che costituiscono insieme il Consiglio dei ministri. Il Presidente della Repubblica nomina il Presidente del Consiglio dei ministri e, su proposta di questo, i ministri.

#### Art. 93.

Il Presidente del Consiglio dei ministri e i ministri, prima di assumere le funzioni, prestano giuramento nelle mani del Presidente della Repubblica.

#### Art. 94.

Il Governo deve avere la fiducia delle due Camere. Ciascuna Camera accorda o revoca la fiducia mediante mozione motivata e votata per appello nominale. Entro dieci giorni dalla sua formazione il Governo si presenta alle Camere per ottenerne la fiducia. Il voto contrario di una o d'entrambe le Camere su una proposta del Governo non importa obbligo di dimissioni. La mozione di sfiducia deve essere firmata da almeno un decimo dei componenti della Camera e non puo' essere messa in discussione prima di tre giorni dalla sua presentazione.

#### Art. 95.

Il Presidente del Consiglio dei ministri dirige la politica generale del Governo e ne e' responsabile. Mantiene l'unita' di indirizzo politico ed amministrativo, promuovendo e coordinando l'attivita' dei ministri. I ministri sono responsabili collegialmente degli atti del Consiglio dei ministri, e individualmente degli atti dei loro dicasteri. La legge provvede all'ordinamento della Presidenza del Consiglio e determina il numero, le attribuzioni e l'organizzazione dei ministeri.

#### Art. 96.

((Il Presidente del Consiglio dei Ministri ed i Ministri, anche se cessati dalla carica, sono sottoposti, per i reati commessi nell'esercizio delle loro funzioni, alla giurisdizione ordinaria, previa autorizzazione del Senato della Repubblica o della Camera dei deputati, secondo le norme stabilite con legge costituzionale)).

### SEZIONE II - La Pubblica Amministrazione.

#### Art. 97.

((Le pubbliche amministrazioni, in coerenza con l'ordinamento dell'Unione europea, assicurano l'equilibrio dei bilanci e la sostenibilita' del debito pubblico)). ((19)) I pubblici uffici sono organizzati secondo disposizioni di legge, in modo che siano assicurati il buon andamento e l'imparzialita' dell'amministrazione. Nell'ordinamento degli uffici sono determinate le sfere di competenza, le attribuzioni e le responsabilita' proprie dei funzionari. Agli impieghi nelle pubbliche amministrazioni si accede mediante concorso, salvo i casi stabiliti dalla legge.

------------- AGGIORNAMENTO (19) La L. costituzionale 20 aprile 2012, n. 1 ha disposto (con l'art. 6, comma 1) che la suddetta modifica si applica a decorrere dall'esercizio finanziario relativo all'anno 2014.

#### Art. 98.

I pubblici impiegati sono al servizio esclusivo della Nazione. Se sono membri del Parlamento, non possono conseguire promozioni se non per anzianita'. Si possono con legge stabilire limitazioni al diritto d'iscriversi ai partiti politici per i magistrati, i militari di carriera in servizio attivo, i funzionari ed agenti di polizia, i rappresentanti diplomatici e consolari all'estero.

### SEZIONE III - Gli organi ausiliari.

#### Art. 99.

Il Consiglio nazionale dell'economia e del lavoro e' composto, nei modi stabiliti dalla legge, di esperti e di rappresentanti delle categorie produttive, in misura che tenga conto della loro importanza numerica e qualitativa. E' organo di consulenza delle Camere e del Governo per le materie e secondo le funzioni che gli sono attribuite dalla legge. Ha l'iniziativa legislativa e puo' contribuire alla elaborazione della legislazione economica e sociale secondo i principi ed entro i limiti stabiliti dalla legge.

#### Art. 100.

Il Consiglio di Stato e' organo di consulenza giuridico-amministrativa e di tutela della giustizia nell'amministrazione. La Corte dei conti esercita il controllo preventivo di legittimita' sugli atti del Governo, e anche quello successivo sulla gestione del bilancio dello Stato. Partecipa, nei casi e nelle forme stabiliti dalla legge, al controllo sulla gestione finanziaria degli enti a cui lo Stato contribuisce in via ordinaria. Riferisce direttamente alle Camere sul risultato del riscontro eseguito. La legge assicura l'indipendenza dei due Istituti e dei loro componenti di fronte al Governo.

### TITOLO IV LA MAGISTRATURA SEZIONE I Ordinamento giurisdizionale.

#### Art. 101.

La giustizia e' amministrata in nome del popolo. I giudici sono soggetti soltanto alla legge.

#### Art. 102.

La funzione giurisdizionale e' esercitata da magistrati ordinari istituiti e regolati dalle norme sull'ordinamento giudiziario. Non possono essere istituiti giudici straordinari o giudici speciali. Possono soltanto istituirsi presso gli organi giudiziari ordinari sezioni specializzate per determinate materie, anche con la partecipazione di cittadini idonei estranei alla magistratura. La legge regola i casi e le forme della partecipazione diretta del popolo all'amministrazione della giustizia.

#### Art. 103.

Il Consiglio di Stato e gli altri organi di giustizia amministrativa hanno giurisdizione per la tutela nei confronti della pubblica amministrazione degli interessi legittimi e, in particolari materie indicate dalla legge, anche dei diritti soggettivi. La Corte dei conti ha giurisdizione nelle materie di contabilita' pubblica e nelle altre specificate dalla legge. I tribunali militari in tempo di guerra hanno la giurisdizione stabilita dalla legge. In tempo di pace hanno giurisdizione soltanto per i reati militari commessi da appartenenti alle Forze armate.

#### Art. 104.

La magistratura costituisce un ordine autonomo e indipendente da ogni altro potere. Il Consiglio superiore della magistratura e' presieduto dal Presidente della Repubblica. Ne fanno parte di diritto il primo presidente e il procuratore generale della Corte di cassazione. Gli altri componenti sono eletti per due terzi da tutti i magistrati ordinari tra gli appartenenti alle varie categorie, e per un terzo dal Parlamento in seduta comune tra professori ordinari di universita' in materie giuridiche ed avvocati dopo quindici anni di esercizio. Il Consiglio elegge un vicepresidente fra i componenti designati dal Parlamento. I membri elettivi del Consiglio durano in carica quattro anni e non sono immediatamente rieleggibili. Non possono, finche' sono in carica, essere iscritti negli albi professionali, ne' far parte del Parlamento o di un Consiglio regionale.

#### Art. 105.

Spettano al Consiglio superiore della magistratura, secondo le norme dell'ordinamento giudiziario, le assunzioni, le assegnazioni ed i trasferimenti, le promozioni e i provvedimenti disciplinari nei riguardi dei magistrati.

#### Art. 106.

Le nomine dei magistrati hanno luogo per concorso. La legge sull'ordinamento giudiziario puo' ammettere la nomina, anche elettiva, di magistrati onorari per tutte le funzioni attribuite a giudici singoli. Su designazione del Consiglio superiore della magistratura possono essere chiamati all'ufficio di consiglieri di cassazione, per meriti insigni, professori ordinari di universita' in materie giuridiche e avvocati che abbiano quindici anni d'esercizio e siano iscritti negli albi speciali per le giurisdizioni superiori.

#### Art. 107.

I magistrati sono inamovibili. Non possono essere dispensati o sospesi dal servizio ne' destinati ad altre ((sedi o funzioni)) se non in seguito a decisione del Consiglio superiore della magistratura, adottata o per i motivi e con le garanzie di difesa stabilite dall'ordinamento giudiziario o con il loro consenso. Il Ministro della giustizia ha facolta' di promuovere l'azione disciplinare. I magistrati si distinguono fra loro soltanto per diversita' di funzioni. Il pubblico ministero gode delle garanzie stabilite nei suoi riguardi dalle norme sull'ordinamento giudiziario.

#### Art. 108.

Le norme sull'ordinamento giudiziario e su ogni magistratura sono stabilite con legge. La legge assicura l'indipendenza dei giudici delle giurisdizioni speciali, del pubblico ministero presso di esse, e degli estranei che partecipano all'amministrazione della giustizia.

#### Art. 109.

L'autorita' giudiziaria dispone direttamente della polizia giudiziaria.

#### Art. 110.

Ferme le competenze del Consiglio superiore della magistratura, spettano al Ministro della giustizia l'organizzazione e il funzionamento dei servizi relativi alla giustizia.

### SEZIONE II - Norme sulla giurisdizione.

#### Art. 111.

((La giurisdizione si attua mediante il giusto processo regolato dalla legge. Ogni processo si svolge nel contraddittorio tra le parti, in condizioni di parita', davanti a giudice terzo e imparziale. La legge ne assicura la ragionevole durata. Nel processo penale, la legge assicura che la persona accusata di un reato sia, nel piu' breve tempo possibile, informata riservatamente della natura e dei motivi dell'accusa elevata a suo carico; disponga del tempo e delle condizioni necessari per preparare la sua difesa; abbia la facolta', davanti al giudice, di interrogare o di far interrogare le persone che rendono dichiarazioni a suo carico, di ottenere la convocazione e l'interrogatorio di persone a sua difesa nelle stesse condizioni dell'accusa e l'acquisizione di ogni altro mezzo di prova a suo favore; sia assistita da un interprete se non comprende o non parla la lingua impiegata nel processo. Il processo penale e' regolato dal principio del contraddittorio nella formazione della prova. La colpevolezza dell'imputato non puo' essere provata sulla base di dichiarazioni rese da chi, per libera scelta, si e' sempre volontariamente sottratto all'interrogatorio da parte dell'imputato o del suo difensore. La legge regola i casi in cui la formazione della prova non ha luogo in contraddittorio per consenso dell'imputato o per accertata impossibilita' di natura oggettiva o per effetto di provata condotta illecita)). Tutti i provvedimenti giurisdizionali devono essere motivati. Contro le sentenze e contro i provvedimenti sulla liberta' personale, pronunciati dagli organi giurisdizionali ordinari o speciali, e' sempre ammesso ricorso in Cassazione per violazione di legge. Si puo' derogare a tale norma soltanto per le sentenze dei tribunali militari in tempo di guerra. Contro le decisioni del Consiglio di Stato e della Corte dei conti il ricorso in Cassazione e' ammesso per i soli motivi inerenti alla giurisdizione.

#### Art. 112.

Il pubblico ministero ha l'obbligo di esercitare l'azione penale.

#### Art. 113.

Contro gli atti della pubblica amministrazione e' sempre ammessa la tutela giurisdizionale dei diritti e degli interessi legittimi dinanzi agli organi di giurisdizione ordinaria o amministrativa. Tale tutela giurisdizionale non puo' essere esclusa o limitata a particolari mezzi di impugnazione o per determinate categorie di atti. La legge determina quali organi di giurisdizione possono annullare gli atti della pubblica amministrazione nei casi e con gli effetti previsti dalla legge stessa.

## TITOLO V LE REGIONI, LE PROVINCIE, I COMUNI

### Art. 114.

((La Repubblica e' costituita dai Comuni, dalle Province, dalle Citta' metropolitane, dalle Regioni e dallo Stato. I Comuni, le Province, le Citta' metropolitane e le Regioni sono enti autonomi con propri statuti, poteri e funzioni secondo i principi fissati dalla Costituzione. Roma e' la capitale della Repubblica. La legge dello Stato disciplina il suo ordinamento)).

### Art. 115.

((ARTICOLO ABROGATO DALLA L. COSTITUZIONALE 18 OTTOBRE 2001, N. 3))

### Art. 116.

((Il Friuli Venezia Giulia, la Sardegna, la Sicilia, il Trentino-Alto Adige/Südtirol e la Valle d'Aosta/Vallee d'Aoste dispongono di forme e condizioni particolari di autonomia, secondo i rispettivi statuti speciali adottati con legge costituzionale. La Regione Trentino-Alto Adige/Südtirol e' costituita dalle Province autonome di Trento e di Bolzano. Ulteriori forme e condizioni particolari di autonomia, concernenti le materie di cui al terzo comma dell'articolo 117 e le materie indicate dal secondo comma del medesimo articolo alle lettere l), limitatamente all'organizzazione della giustizia di pace, n) e s), possono essere attribuite ad altre Regioni, con legge dello Stato, su iniziativa della Regione interessata, sentiti gli enti locali, nel rispetto dei principi di cui all'articolo 119. La legge e' approvata dalle Camere a maggioranza assoluta dei componenti, sulla base di intesa fra lo Stato e la Regione interessata)).

### Art. 117.

La potesta' legislativa e' esercitata dallo Stato e dalle Regioni nel rispetto della Costituzione, nonche' dei vincoli derivanti dall'ordinamento comunitario e dagli obblighi internazionali. Lo Stato ha legislazione esclusiva nelle seguenti materie: a) politica estera e rapporti internazionali dello Stato; rapporti dello Stato con l'Unione europea; diritto di asilo e condizione giuridica dei cittadini di Stati non appartenenti all'Unione europea; b) immigrazione; c) rapporti tra la Repubblica e le confessioni religiose; d) difesa e Forze armate; sicurezza dello Stato; armi, munizioni ed esplosivi; e) moneta, tutela del risparmio e mercati finanziari; tutela della concorrenza; sistema valutario; sistema tributario e contabile dello Stato; ((armonizzazione dei bilanci pubblici;)) perequazione delle risorse finanziarie; ((19)) f) organi dello Stato e relative leggi elettorali; referendum statali; elezione del Parlamento europeo; g) ordinamento e organizzazione amministrativa dello Stato e degli enti pubblici nazionali; h) ordine pubblico e sicurezza, ad esclusione della polizia amministrativa locale; i) cittadinanza, stato civile e anagrafi; l) giurisdizione e norme processuali; ordinamento civile e penale; giustizia amministrativa; m) determinazione dei livelli essenziali delle prestazioni concernenti i diritti civili e sociali che devono essere garantiti su tutto il territorio nazionale; n) norme generali sull'istruzione; o) previdenza sociale; p) legislazione elettorale, organi di governo e funzioni fondamentali di Comuni, Province e Citta' metropolitane; q) dogane, protezione dei confini nazionali e profilassi internazionale; r) pesi, misure e determinazione del tempo; coordinamento informativo statistico e informatico dei dati dell'amministrazione statale, regionale e locale; opere dell'ingegno; s) tutela dell'ambiente, dell'ecosistema e dei beni culturali. Sono materie di legislazione concorrente quelle relative a: rapporti internazionali e con l'Unione europea delle Regioni; commercio con l'estero; tutela e sicurezza del lavoro; istruzione, salva l'autonomia delle istituzioni scolastiche e con esclusione della istruzione e della formazione professionale; professioni; ricerca scientifica e tecnologica e sostegno all'innovazione per i settori produttivi; tutela della salute; alimentazione; ordinamento sportivo; protezione civile; governo del territorio; porti e aeroporti civili; grandi reti di trasporto e di navigazione; ordinamento della comunicazione; produzione, trasporto e distribuzione nazionale dell'energia; previdenza complementare e integrativa; ((. . .)) coordinamento della finanza pubblica e del sistema tributario; valorizzazione dei beni culturali e ambientali e promozione e organizzazione di attivita' culturali; casse di risparmio, casse rurali, aziende di credito a carattere regionale; enti di credito fondiario e agrario a carattere regionale. Nelle materie di legislazione concorrente spetta alle Regioni la potesta' legislativa, salvo che per la determinazione dei principi fondamentali, riservata alla legislazione dello Stato. ((19)) Spetta alle Regioni la potesta' legislativa in riferimento ad ogni materia non espressamente riservata alla legislazione dello Stato. Le Regioni e le Province autonome di Trento e di Bolzano, nelle materie di loro competenza, partecipano alle decisioni dirette alla formazione degli atti normativi comunitari e provvedono all'attuazione e all'esecuzione degli accordi internazionali e degli atti dell'Unione europea, nel rispetto delle norme di procedura stabilite da legge dello Stato, che disciplina le modalita' di esercizio del potere sostitutivo in caso di inadempienza. La potesta' regolamentare spetta allo Stato nelle materie di legislazione esclusiva, salva delega alle Regioni. La potesta' regolamentare spetta alle Regioni in ogni altra materia. I Comuni, le Province e le Citta' metropolitane hanno potesta' regolamentare in ordine alla disciplina dell'organizzazione e dello svolgimento delle funzioni loro attribuite. Le leggi regionali rimuovono ogni ostacolo che impedisce la piena parita' degli uomini e delle donne nella vita sociale, culturale ed economica e promuovono la parita' di accesso tra donne e uomini alle cariche elettive. La legge regionale ratifica le intese della Regione con altre Regioni per il migliore esercizio delle proprie funzioni, anche con individuazione di organi comuni. Nelle materie di sua competenza la Regione puo' concludere accordi con Stati e intese con enti territoriali interni ad altro Stato, nei casi e con le forme disciplinati da leggi dello Stato.

------------- AGGIORNAMENTO (19) La L. costituzionale 20 aprile 2012, n. 1 ha disposto (con l'art. 6, comma 1) che le suddette modifiche si applicano a decorrere dall'esercizio finanziario relativo all'anno 2014.

### Art. 118.

((Le funzioni amministrative sono attribuite ai Comuni salvo che, per assicurarne l'esercizio unitario, siano conferite a Province, Citta' metropolitane, Regioni e Stato, sulla base dei principi di sussidiarieta', differenziazione ed adeguatezza. I Comuni, le Province e le Citta' metropolitane sono titolari di funzioni amministrative proprie e di quelle conferite con legge statale o regionale, secondo le rispettive competenze. La legge statale disciplina forme di coordinamento fra Stato e Regioni nelle materie di cui alle lettere b) e h) del secondo comma dell'articolo 117, e disciplina inoltre forme di intesa e coordinamento nella materia della tutela dei beni culturali. Stato, Regioni, Citta' metropolitane, Province e Comuni favoriscono l'autonoma iniziativa dei cittadini, singoli e associati, per lo svolgimento di attivita' di interesse generale, sulla base del principio di sussidiarieta')).

### Art. 119.

I Comuni, le Province, le Citta' metropolitane e le Regioni hanno autonomia finanziaria di entrata e di spesa, nel rispetto dell'equilibrio dei relativi bilanci, e concorrono ad assicurare l'osservanza dei vincoli economici e finanziari derivanti dall'ordinamento dell'Unione europea. (19) I Comuni, le Province, le Citta' metropolitane e le Regioni hanno risorse autonome. Stabiliscono e applicano tributi ed entrate propri, in armonia con la Costituzione e secondo i principi di coordinamento della finanza pubblica e del sistema tributario. Dispongono di compartecipazioni al gettito di tributi erariali riferibile al loro territorio. La legge dello Stato istituisce un fondo perequativo, senza vincoli di destinazione, per i territori con minore capacita' fiscale per abitante. Le risorse derivanti dalle fonti di cui ai commi precedenti consentono ai Comuni, alle Province, alle Citta' metropolitane e alle Regioni di finanziare integralmente le funzioni pubbliche loro attribuite. Per promuovere lo sviluppo economico, la coesione e la solidarieta' sociale, per rimuovere gli squilibri economici e sociali, per favorire l'effettivo esercizio dei diritti della persona, o per provvedere a scopi diversi dal normale esercizio delle loro funzioni, lo Stato destina risorse aggiuntive ed effettua interventi speciali in favore di determinati Comuni, Province, Citta' metropolitane e Regioni. ((La Repubblica riconosce le peculiarita' delle Isole e promuove le misure necessarie a rimuovere gli svantaggi derivanti dall'insularita')). I Comuni, le Province, le Citta' metropolitane e le Regioni hanno un proprio patrimonio, attribuito secondo i principi generali determinati dalla legge dello Stato. Possono ricorrere all'indebitamento solo per finanziare spese di investimento, con la contestuale definizione di piani di ammortamento e a condizione che per il complesso degli enti di ciascuna Regione sia rispettato l'equilibrio di bilancio. E' esclusa ogni garanzia dello Stato sui prestiti dagli stessi contratti. (19)

------------- AGGIORNAMENTO (19) La L. costituzionale 20 aprile 2012, n. 1 ha disposto (con l'art. 6, comma 1) che le suddette modifiche si applicano a decorrere dall'esercizio finanziario relativo all'anno 2014.

### Art. 120.

((La Regione non puo' istituire dazi di importazione o esportazione o transito tra le Regioni, ne' adottare provvedimenti che ostacolino in qualsiasi modo la libera circolazione delle persone e delle cose tra le Regioni, ne' limitare l'esercizio del diritto al lavoro in qualunque parte del territorio nazionale. Il Governo puo' sostituirsi a organi delle Regioni, delle Citta' metropolitane, delle Province e dei Comuni nel caso di mancato rispetto di norme e trattati internazionali o della normativa comunitaria oppure di pericolo grave per l'incolumita' e la sicurezza pubblica, ovvero quando lo richiedono la tutela dell'unita' giuridica o dell'unita' economica e in particolare la tutela dei livelli essenziali delle prestazioni concernenti i diritti civili e sociali, prescindendo dai confini territoriali dei governi locali. La legge definisce le procedure atte a garantire che i poteri sostitutivi siano esercitati nel rispetto del principio di sussidiarieta' e del principio di leale collaborazione)).

### Art. 121.

Sono organi della Regione: il Consiglio regionale, la Giunta e il suo presidente. Il Consiglio regionale esercita le potesta' legislative (( . . . )) attribuite alla Regione e le altre funzioni conferitegli dalla Costituzione e dalle leggi. Puo' fare proposte di legge alle Camere. La Giunta regionale e' l'organo esecutivo delle Regioni. ((Il Presidente della Giunta rappresenta la Regione; dirige la politica della Giunta e ne e' responsabile; promulga le leggi ed emana i regolamenti regionali; dirige le funzioni amministrative delegate dallo Stato alla Regione, conformandosi alle istruzioni del Governo della Repubblica)).

### Art. 122.

((Il sistema di elezione e i casi di ineleggibilita' e di incompatibilita' del Presidente e degli altri componenti della Giunta regionale nonche' dei consiglieri regionali sono disciplinati con legge della Regione nei limiti dei principi fondamentali stabiliti con legge della Repubblica, che stabilisce anche la durata degli organi elettivi. Nessuno puo' appartenere contemporaneamente a un Consiglio o a una Giunta regionale e ad una delle Camere del Parlamento, ad un altro Consiglio o ad altra Giunta regionale, ovvero al Parlamento europeo. Il Consiglio elegge tra i suoi componenti un Presidente e un ufficio di presidenza. I consiglieri regionali non possono essere chiamati a rispondere delle opinioni espresse e dei voti dati nell'esercizio delle loro funzioni. Il Presidente della Giunta regionale, salvo che lo statuto regionale disponga diversamente, e' eletto a suffragio universale e diretto. Il Presidente eletto nomina e revoca i componenti della Giunta)).

### Art. 123.

Ciascuna Regione ha uno statuto che, in armonia con la Costituzione, ne determina la forma di governo e i principi fondamentali di organizzazione e funzionamento. Lo statuto regola l'esercizio del diritto di iniziativa e del referendum su leggi e provvedimenti amministrativi della Regione e la pubblicazione delle leggi e dei regolamenti regionali. Lo statuto e' approvato e modificato dal Consiglio regionale con legge approvata a maggioranza assoluta dei suoi componenti, con due deliberazioni successive adottate ad intervallo non minore di due mesi. Per tale legge non e' richiesta l'apposizione del visto da parte del Commissario del Governo. Il Governo della Repubblica puo' promuovere la questione di legittimita' costituzionale sugli statuti regionali dinanzi alla Corte costituzionale entro trenta giorni dalla loro pubblicazione. Lo statuto e' sottoposto a referendum popolare qualora entro tre mesi dalla sua pubblicazione ne faccia richiesta un cinquantesimo degli elettori della Regione o un quinto dei componenti il Consiglio regionale. Lo statuto sottoposto a referendum non e' promulgato se non e' approvato dalla maggioranza dei voti validi. ((In ogni Regione, lo statuto disciplina il Consiglio delle autonomie locali, quale organo di consultazione fra la Regione e gli enti locali)).

### Art. 124.

((ARTICOLO ABROGATO DALLA L. COSTITUZIONALE 18 OTTOBRE 2001, N. 3))

### Art. 125.

((COMMA ABROGATO DALLA L. COSTITUZIONALE 18 OTTOBRE 2001, N. 3)). Nella Regione sono istituiti organi di giustizia amministrativa di primo grado, secondo l'ordinamento stabilito da legge della Repubblica. Possono istituirsi sezioni con sede diversa dal capoluogo della Regione.

### Art. 126.

((Con decreto motivato del Presidente della Repubblica sono disposti lo scioglimento del Consiglio regionale e la rimozione del Presidente della Giunta che abbiano compiuto atti contrari alla Costituzione o gravi violazioni di legge. Lo scioglimento e la rimozione possono altresi' essere disposti per ragioni di sicurezza nazionale. Il decreto e' adottato sentita una Commissione di deputati e senatori costituita, per le questioni regionali, nei modi stabiliti con legge della Repubblica. Il Consiglio regionale puo' esprimere la sfiducia nei confronti del Presidente della Giunta mediante mozione motivata, sottoscritta da almeno un quinto dei suoi componenti e approvata per appello nominale a maggioranza assoluta dei componenti. La mozione non puo' essere messa in discussione prima di tre giorni dalla presentazione. L'approvazione della mozione di sfiducia nei confronti del Presidente della Giunta eletto a suffragio universale e diretto, nonche' la rimozione, l'impedimento permanente, la morte o le dimissioni volontarie dello stesso comportano le dimissioni della Giunta e lo scioglimento del Consiglio. In ogni caso i medesimi effetti conseguono alle dimissioni contestuali della maggioranza dei componenti il Consiglio)).

### Art. 127.

((Il Governo, quando ritenga che una legge regionale ecceda la competenza della Regione, puo' promuovere la questione di legittimita' costituzionale dinanzi alla Corte costituzionale entro sessanta giorni dalla sua pubblicazione. La Regione, quando ritenga che una legge o un atto avente valore di legge dello Stato o di un'altra Regione leda la sua sfera di competenza, puo' promuovere la questione di legittimita' costituzionale dinanzi alla Corte costituzionale entro sessanta giorni dalla pubblicazione della legge o dell'atto avente valore di legge)).

### Art. 128.

((ARTICOLO ABROGATO DALLA L. COSTITUZIONALE 18 OTTOBRE 2001, N. 3))

### Art. 129.

((ARTICOLO ABROGATO DALLA L. COSTITUZIONALE 18 OTTOBRE 2001, N. 3))

### Art. 130.

((ARTICOLO ABROGATO DALLA L. COSTITUZIONALE 18 OTTOBRE 2001, N. 3))

### Art. 131.

((Sono costituite le seguenti Regioni: Piemonte; Marche; Valle d'Aosta; Lazio; Lombardia; Abruzzi; Trentino-Alto Adige; Molise; Veneto; Campania; Friuli-Venezia Giulia; Puglia; Liguria; Basilicata; Emilia-Romagna; Calabria; Toscana; Sicilia; Umbria; Sardegna)).

### Art. 132.

Si puo' con legge costituzionale, sentiti i Consigli regionali, disporre la fusione di Regioni esistenti o la creazione di nuove Regioni con un minimo di un milione d'abitanti, quando ne facciano richiesta tanti Consigli comunali che rappresentino almeno un terzo delle popolazioni interessate, e la proposta sia approvata con referendum dalla maggioranza delle popolazioni stesse. Si puo', con ((l'approvazione della maggioranza delle popolazioni della Provincia o delle Province interessate e del Comune o dei Comuni interessati espressa mediante)) referendum e con legge della Repubblica, sentiti i Consigli regionali, consentire che Provincie e Comuni, che ne facciano richiesta, siano staccati da una Regione ed aggregati ad un'altra.

### Art. 133.

Il mutamento delle circoscrizioni provinciali e la istituzione di nuove Provincie nell'ambito d'una Regione sono stabiliti con leggi della Repubblica, su iniziative dei Comuni, sentita la stessa Regione. La Regione, sentite le popolazioni interessate, puo' con sue leggi istituire nel proprio territorio nuovi Comuni e modificare le loro circoscrizioni e denominazioni.

### TITOLO VI GARANZIE COSTITUZIONALI SEZIONE I La Corte costituzionale.

#### Art. 134.

La Corte costituzionale giudica: sulle controversie relative alla legittimita' costituzionale delle leggi e degli atti, aventi forza di legge, dello Stato e delle Regioni; sui conflitti di attribuzione tra i poteri dello Stato e su quelli tra lo Stato e le Regioni, e tra le Regioni; sulle accuse promosse contro il Presidente della Repubblica (( . . . )), a norma della Costituzione.

#### Art. 135.

La Corte costituzionale e' composta di quindici giudici nominati per un terzo dal Presidente della Repubblica, per un terzo dal Parlamento in seduta comune e per un terzo dalle supreme magistrature ordinaria ed amministrative. I giudici della Corte costituzionale sono scelti fra i magistrati anche a riposo delle giurisdizioni superiori ordinaria ed amministrative, i professori ordinari di universita' in materie giuridiche e gli avvocati dopo venti anni di esercizio. I giudici della Corte costituzionale sono nominati per nove anni, decorrenti per ciascuno di essi dal giorno del giuramento, e non possono essere nuovamente nominati. Alla scadenza del termine il giudice costituzionale cessa dalla carica e dall'esercizio delle funzioni. La Corte elegge tra i suoi componenti, secondo le norme stabilite dalla legge, il Presidente, che rimane in carica per un triennio, ed e' rieleggibile, fermi in ogni caso i termini di scadenza dall'ufficio di giudice. L'ufficio di giudice della Corte e' incompatibile con quello di membro del Parlamento, di un Consiglio regionale, con l'esercizio della professione di avvocato e con ogni carica ed ufficio indicati dalla legge. Nei giudizi d'accusa contro il Presidente della Repubblica (( . . . )) intervengono, oltre i giudici ordinari della Corte, sedici membri tratti a sorte da un elenco di cittadini aventi i requisiti per l'eleggibilita' a senatore, che il Parlamento compila ogni nove anni mediante elezione con le stesse modalita' stabilite per la nomina dei giudici ordinari.

#### Art. 136.

Quando la Corte dichiara l'illegittimita' costituzionale di una norma di legge o di atto avente forza di legge, la norma cessa di avere efficacia dal giorno successivo alla pubblicazione della decisione. La decisione della Corte e' pubblicata e comunicata alle Camere ed ai Consigli regionali interessati, affinche', ove lo ritengano necessario, provvedano nelle forme costituzionali.

#### Art. 137.

Una legge costituzionale stabilisce le condizioni, le forme, i termini di proponibilita' dei giudizi di legittimita' costituzionale, e le garanzie d'indipendenza dei giudici della Corte. Con legge ordinaria sono stabilite le altre norme necessarie per la costituzione e il funzionamento della Corte. Contro le decisioni della Corte costituzionale non e' ammessa alcuna impugnazione.

### SEZIONE II - Revisione della Costituzione. Leggi costituzionali

#### Art. 138.

Le leggi di revisione della Costituzione e le altre leggi costituzionali sono adottate da ciascuna Camera con due successive deliberazioni ad intervallo non minore di tre mesi, e sono approvate a maggioranza assoluta dei componenti di ciascuna Camera nella seconda votazione. Le leggi stesse sono sottoposte a referendum popolare quando, entro tre mesi dalla loro pubblicazione, ne facciano domanda un quinto dei membri di una Camera o cinquecentomila elettori o cinque Consigli regionali. La legge sottoposta a referendum non e' promulgata, se non e' approvata dalla maggioranza dei voti validi. Non si fa luogo a referendum se la legge e' stata approvata nella seconda votazione da ciascuna delle Camere a maggioranza di due terzi dei suoi componenti.

#### Art. 139.

La forma repubblicana non puo' essere oggetto di revisione costituzionale.


---
url: https://www.normattiva.it/uri-res/N2Ls?urn:nir:stato:decreto.legislativo:2003-06-30;196
url_xml: https://www.normattiva.it/do/atto/caricaAKN?dataGU=20030729&codiceRedaz=003G0218&dataVigenza=20251101
dataGU: 20030729
codiceRedaz: 003G0218
dataVigenza: 20251101
---

# Codice in materia di protezione dei dati personali ((, recante disposizioni per l'adeguamento dell'ordinamento nazionale al regolamento (UE) n. 2016/679 del Parlamento europeo e del Consiglio, del 27 aprile 2016, relativo alla protezione delle persone fisiche con riguardo al trattamento dei dati personali, nonche' alla libera circolazione di tali dati e che abroga la direttiva 95/46/CE)).

IL PRESIDENTE DELLA REPUBBLICA

VISTI gli articoli 76 e 87 della Costituzione;

VISTO l'articolo 1 della legge 24 marzo 2001, n. 127, recante delega a Governo per l'emanazione di un testo unico in materia di trattamento dei dati personali;

VISTO l'articolo 26 della legge 3 febbraio 2003, n 14, recante disposizioni per l'adempimento di obblighi derivanti dall'appartenenza dell'Italia alle Comunita' europee (legge comunitaria 2002);

((Vista la legge 25 ottobre 2017, n. 163, recante delega al Governo per il recepimento delle direttive europee e l'attuazione di altri atti dell'Unione europea - Legge di delegazione europea 2016-2017» e, in particolare, l'articolo 13, che delega il Governo all'emanazione di uno o piu' decreti legislativi di adeguamento del quadro normativo nazionale alle disposizioni del Regolamento (UE) 2016/679 del Parlamento europeo e del Consiglio, del 27 aprile 2016;

Vista la legge 24 dicembre 2012, n. 234, recante norme generali sulla partecipazione dell'Italia alla formazione e all'attuazione della normativa e delle politiche dell'Unione europea;

Visto il Regolamento (UE) 2016/679 del Parlamento europeo e del Consiglio, del 27 aprile 2016, relativo alla protezione delle persone fisiche con riguardo al trattamento dei dati personali, nonche' alla libera circolazione di tali dati e che abroga la direttiva 95/46/CE (regolamento generale sulla protezione dei dati);))

VISTA la legge 31 dicembre 1996, n. 675, e successive modificazioni;

VISTA la legge 31 dicembre 1996, n. 676, recante delega al Governo in materia di tutela delle persone e di altri soggetti rispetto al trattamento dei dati personali;

VISTA la direttiva 95/46/CE del Parlamento europeo e del Consiglio, del 24 ottobre 1995, relativa alla tutela delle persone fisiche con riguardo al trattamento dei dati personali, nonche' alla libera circolazione dei dati;

VISTA la direttiva 2002/58/CE del Parlamento europeo e del Consiglio, del 12 luglio 2002, relativa al trattamento dei dati personali e alla tutela della sita privata nel settore delle comunicazioni elettroniche;

VISTA la preliminare deliberazione del Consiglio dei ministri, adottata nella riunione del 9 maggio 2003;

SENTITO il Garante per la protezione dei dati personali;

ACQUISITO il parere delle competenti Commissioni parlamentari della Camera dei deputati e del Senato della Repubblica;

VISTA la deliberazione del Consiglio dei Ministri, adottata nella riunione del 27 giugno 2003;

SULLA PROPOSTA del Presidente del Consiglio dei Ministri, del Ministro per la funzione pubblica e del Ministro per le politiche comunitarie, di concerto con i Ministri della giustizia, dell'economia e delle finanze, degli affari esteri e delle comunicazioni; EMANA il seguente decreto legislativo:

## DISPOSIZIONI GENERALI - - TITOLO I (( PRINCIPI E DISPOSIZIONI GENERALI CAPO I (OGGETTO, FINALITA' E AUTORITA' DI CONTROLLO) ))

### Art. 1. - (( (Oggetto). ))

((Il trattamento dei dati personali avviene secondo le norme del regolamento (UE) 2016/679 del Parlamento europeo e del Consiglio, del 27 aprile 2016, di seguito «Regolamento», e del presente codice, nel rispetto della dignita' umana, dei diritti e delle liberta' fondamentali della persona.))

### Art. 2. - (( (Finalita'). ))

((

1. Il presente codice reca disposizioni per l'adeguamento dell'ordinamento nazionale alle disposizioni del regolamento.

))

### Art. 2-bis. - (( (Autorita' di controllo). ))

((

1. L'Autorita' di controllo di cui all'articolo 51 del regolamento e' individuata nel Garante per la protezione dei dati personali, di seguito «Garante», di cui all'articolo 153.

))

## ((CAPO II - (PRINCIPI)))

### Art. 2-ter. - (Base giuridica per il trattamento di dati personali effettuato per l'esecuzione di un compito di interesse pubblico o connesso all'esercizio di pubblici poteri)

1. La base giuridica prevista dall'articolo 6, paragrafo 3, lettera b), del regolamento e' costituita ((...)) da una norma di legge o ((...)) di regolamento ((o da atti amministrativi generali)). ((49))

((1-bis. Fermo restando ogni altro obbligo previsto dal Regolamento e dal presente codice, il trattamento dei dati personali da parte di un'amministrazione pubblica di cui all'articolo 1, comma 2, del decreto legislativo 30 marzo 2001, n. 165, ivi comprese le autorita' indipendenti e le amministrazioni inserite nell'elenco di cui all'articolo 1, comma 3, della legge 31 dicembre 2009, n. 196, nonche' da parte di una societa' a controllo pubblico statale o, limitatamente ai gestori di servizi pubblici, locale, di cui all'articolo 16 del testo unico in materia di societa' a partecipazione pubblica, di cui al decreto legislativo 19 agosto 2016, n. 175, con esclusione, per le societa' a controllo pubblico, dei trattamenti correlati ad attivita' svolte in regime di libero mercato, e' anche consentito se necessario per l'adempimento di un compito svolto nel pubblico interesse o per l'esercizio di pubblici poteri ad esse attribuiti. In modo da assicurare che tale esercizio non possa arrecare un pregiudizio effettivo e concreto alla tutela dei diritti e delle liberta' degli interessati, le disposizioni di cui al presente comma sono esercitate nel rispetto dell'articolo 6 del Regolamento))

2. La comunicazione fra titolari che effettuano trattamenti di dati personali, diversi da quelli ricompresi nelle particolari categorie di cui all'articolo 9 del Regolamento e di quelli relativi a condanne penali e reati di cui all'articolo 10 del Regolamento, per l'esecuzione di un compito di interesse pubblico o connesso all'esercizio di pubblici poteri e' ammessa se prevista ai sensi del comma 1 ((o se necessaria ai sensi del comma 1-bis)). ((PERIODO SOPPRESSO DAL D.L. 8 OTTOBRE 2021, N. 139, CONVERTITO CON MODIFICAZIONI DALLA L. 3 DICEMBRE 2021, N. 205)).

3. La diffusione e la comunicazione di dati personali, trattati per l'esecuzione di un compito di interesse pubblico o connesso all'esercizio di pubblici poteri, a soggetti che intendono trattarli per altre finalita' sono ammesse unicamente se previste ai sensi del comma 1 ((o se necessarie ai sensi del comma 1-bis. In tale ultimo caso, ne viene data notizia al Garante almeno dieci giorni prima dell'inizio della comunicazione o diffusione)).

4. Si intende per:

- a) "comunicazione", il dare conoscenza dei dati personali a uno o piu' soggetti determinati diversi dall'interessato, dal rappresentante del titolare nel territorio dell'Unione europea, dal responsabile o dal suo rappresentante nel territorio dell'Unione europea, dalle persone autorizzate, ai sensi dell'articolo 2-quaterdecies, al trattamento dei dati personali sotto l'autorita' diretta del titolare o del responsabile, in qualunque forma, anche mediante la loro messa a disposizione, consultazione o mediante interconnessione;
- b) "diffusione", il dare conoscenza dei dati personali a soggetti indeterminati, in qualunque forma, anche mediante la loro messa a disposizione o consultazione.

---------------- AGGIORNAMENTO (49) Il D.L. 8 ottobre 2021, n. 139, convertito con modificazioni dalla L. 3 dicembre 2021, n. 205, ha disposto (con l'art. 9, comma 5) che "Gli articoli 2-ter, comma 1, 2-sexies, comma 1, e 58, commi 1 e 2, del codice di cui al decreto legislativo n. 196 del 2003 [...], come modificati dal presente articolo, si applicano anche ai casi in cui disposizioni di legge gia' in vigore stabiliscono che i tipi di dati che possono essere trattati, le operazioni eseguibili, il motivo di interesse pubblico rilevante, la finalita' del trattamento nonche' le misure appropriate e specifiche per tutelare i diritti fondamentali dell'interessato e i suoi interessi sono previsti da uno o piu' regolamenti".

### Art. 2-quater. - (( (Regole deontologiche). ))

((

1. Il Garante promuove, nell'osservanza del principio di rappresentativita' e tenendo conto delle raccomandazioni del Consiglio d'Europa sul trattamento dei dati personali, l'adozione di regole deontologiche per i trattamenti previsti dalle disposizioni di cui agli articoli 6, paragrafo 1, lettere c) ed e), 9, paragrafo 4, e al capo IX del Regolamento, ne verifica la conformita' alle disposizioni vigenti, anche attraverso l'esame di osservazioni di soggetti interessati e contribuisce a garantirne la diffusione e il rispetto.

2. Lo schema di regole deontologiche e' sottoposto a consultazione pubblica per almeno sessanta giorni.

3. Conclusa la fase delle consultazioni, le regole deontologiche sono approvate dal Garante ai sensi dell'articolo 154-bis, comma 1, lettera b), pubblicate nella Gazzetta Ufficiale della Repubblica italiana e, con decreto del Ministro della giustizia, sono riportate nell'allegato A del presente codice.

4. Il rispetto delle disposizioni contenute nelle regole deontologiche di cui al comma 1 costituisce condizione essenziale per la liceita' e la correttezza del trattamento dei dati personali.

))

### Art. 2-quinquies. - (( (Consenso del minore in relazione ai servizi della societa' dell'informazione). ))

((

1. In attuazione dell'articolo 8, paragrafo 1, del Regolamento, il minore che ha compiuto i quattordici anni puo' esprimere il consenso al trattamento dei propri dati personali in relazione all'offerta diretta di servizi della societa' dell'informazione. Con riguardo a tali servizi, il trattamento dei dati personali del minore di eta' inferiore a quattordici anni, fondato sull'articolo 6, paragrafo 1, lettera a), del Regolamento, e' lecito a condizione che sia prestato da chi esercita la responsabilita' genitoriale.

2. In relazione all'offerta diretta ai minori dei servizi di cui al comma 1, il titolare del trattamento redige con linguaggio particolarmente chiaro e semplice, conciso ed esaustivo, facilmente accessibile e comprensibile dal minore, al fine di rendere significativo il consenso prestato da quest'ultimo, le informazioni e le comunicazioni relative al trattamento che lo riguardi.

))

### Art. 2-sexies. - (Trattamento di categorie particolari di dati personali necessario per motivi di interesse pubblico rilevante)

1. I trattamenti delle categorie particolari di dati personali di cui all'articolo 9, paragrafo 1, del Regolamento, necessari per motivi di interesse pubblico rilevante ai sensi del paragrafo 2, lettera g), del medesimo articolo, sono ammessi qualora siano previsti dal diritto dell'Unione europea ovvero, nell'ordinamento interno, da disposizioni di legge o di regolamento o da atti amministrativi generali che specifichino i tipi di dati che possono essere trattati, le operazioni eseguibili e il motivo di interesse pubblico rilevante, nonche' le misure appropriate e specifiche per tutelare i diritti fondamentali e gli interessi dell'interessato. (49)

1-bis. I dati personali relativi alla salute, ((pseudonimizzati)) , sono trattati, anche mediante interconnessione, dal Ministero della salute, dall'Istituto superiore di sanita' (ISS), dall'Agenzia nazionale per i servizi sanitari regionali (AGENAS), dall'Agenzia italiana del farmaco (AIFA), dall'Istituto nazionale per la promozione della salute delle popolazioni migranti e per il contrasto delle malattie della poverta' (INMP), nonche', relativamente ai propri assistiti, dalle regioni e dalle province autonome, nel rispetto delle finalita' istituzionali di ciascuno, secondo le modalita' individuate con decreto del Ministro della salute, adottato ai sensi del comma 1 previo parere del Garante per la protezione dei dati personali.

1-ter. Il Ministero della salute disciplina, con uno o piu' decreti adottati ai sensi del comma 1, l'interconnessione a livello nazionale dei sistemi informativi su base individuale, ((pseudonomizzati)) , ivi incluso il fascicolo sanitario elettronico (FSE), compresi quelli gestiti dai soggetti di cui al comma 1-bis o da altre pubbliche amministrazioni che a tal fine adeguano i propri sistemi informativi. I decreti di cui al primo periodo adottati, previo parere del Garante per la protezione dei dati personali, nel rispetto del Regolamento, del presente codice, ((del codice)) dell'amministrazione digitale di cui al decreto legislativo 7 marzo 2005, n. 82, e delle linee guida emanate dall'Agenzia per l'Italia digitale in materia di interoperabilita', definiscono le caratteristiche e disciplinano un ambiente di trattamento sicuro all'interno del quale vengono messi a disposizione dati anonimi o pseudonimizzati, per le finalita' istituzionali di ciascuno, secondo le modalita' individuate al comma 1.

2. Fermo quanto previsto dal comma 1, si considera rilevante l'interesse pubblico relativo a trattamenti effettuati da soggetti che svolgono compiti di interesse pubblico o connessi all'esercizio di pubblici poteri nelle seguenti materie:

- a) accesso a documenti amministrativi e accesso civico;
- b) tenuta degli atti e dei registri dello stato civile, delle anagrafi della popolazione residente in Italia e dei cittadini italiani residenti all'estero, e delle liste elettorali, nonche' rilascio di documenti di riconoscimento o di viaggio o cambiamento delle generalita';
- c) tenuta di registri pubblici relativi a beni immobili o mobili;
- d) tenuta dell'anagrafe nazionale degli abilitati alla guida e dell'archivio nazionale dei veicoli;
- e) cittadinanza, immigrazione, asilo, condizione dello straniero e del profugo, stato di rifugiato;
- f) elettorato attivo e passivo ed esercizio di altri diritti politici, protezione diplomatica e consolare, nonche' documentazione delle attivita' istituzionali di organi pubblici, con particolare riguardo alla redazione di verbali e resoconti dell'attivita' di assemblee rappresentative, commissioni e di altri organi collegiali o assembleari;
- g) esercizio del mandato degli organi rappresentativi, ivi compresa la loro sospensione o il loro scioglimento, nonche' l'accertamento delle cause di ineleggibilita', incompatibilita' o di decadenza, ovvero di rimozione o sospensione da cariche pubbliche;
- h) svolgimento delle funzioni di controllo, indirizzo politico, inchiesta parlamentare o sindacato ispettivo e l'accesso a documenti riconosciuto dalla legge e dai regolamenti degli organi interessati per esclusive finalita' direttamente connesse all'espletamento di un mandato elettivo;
- i) attivita' dei soggetti pubblici dirette all'applicazione, anche tramite i loro concessionari, delle disposizioni in materia tributaria e doganale, comprese quelle di prevenzione e contrasto all'evasione fiscale;
- l) attivita' di controllo e ispettive;
- m) concessione, liquidazione, modifica e revoca di benefici economici, agevolazioni, elargizioni, altri emolumenti e abilitazioni;
- n) conferimento di onorificenze e ricompense, riconoscimento della personalita' giuridica di associazioni, fondazioni ed enti, anche di culto, accertamento dei requisiti di onorabilita' e di professionalita' per le nomine, per i profili di competenza del soggetto pubblico, ad uffici anche di culto e a cariche direttive di persone giuridiche, imprese e di istituzioni scolastiche non statali, nonche' rilascio e revoca di autorizzazioni o abilitazioni, concessione di patrocini, patronati e premi di rappresentanza, adesione a comitati d'onore e ammissione a cerimonie ed incontri istituzionali;
- o) rapporti tra i soggetti pubblici e gli enti del terzo settore;
- p) obiezione di coscienza;
- q) attivita' sanzionatorie e di tutela in sede amministrativa o giudiziaria;
- r) rapporti istituzionali con enti di culto, confessioni religiose e comunita' religiose;
- s) attivita' socio-assistenziali a tutela dei minori e soggetti bisognosi, non autosufficienti e incapaci;
- t) attivita' amministrative e certificatorie correlate a quelle di diagnosi, assistenza o terapia sanitaria o sociale, ivi incluse quelle correlate ai trapianti d'organo e di tessuti nonche' alle trasfusioni di sangue umano;
- u) compiti del servizio sanitario nazionale e dei soggetti operanti in ambito sanitario, nonche' compiti di igiene e sicurezza sui luoghi di lavoro e sicurezza e salute della popolazione, protezione civile, salvaguardia della vita e incolumita' fisica;
- v) programmazione, gestione, controllo e valutazione dell'assistenza sanitaria, ivi incluse l'instaurazione, la gestione, la pianificazione e il controllo dei rapporti tra l'amministrazione ed i soggetti accreditati o convenzionati con il servizio sanitario nazionale;
- z) vigilanza sulle sperimentazioni, farmacovigilanza, autorizzazione all'immissione in commercio e all'importazione di medicinali e di altri prodotti di rilevanza sanitaria;
- aa) tutela sociale della maternita' ed interruzione volontaria della gravidanza, dipendenze, assistenza, integrazione sociale e diritti dei disabili;
- bb) istruzione e formazione in ambito scolastico, professionale, superiore o universitario;
- cc) trattamenti effettuati a fini di archiviazione nel pubblico interesse o di ricerca storica, concernenti la conservazione, l'ordinamento e la comunicazione dei documenti detenuti negli archivi di Stato negli archivi storici degli enti pubblici, o in archivi privati dichiarati di interesse storico particolarmente importante, per fini di ricerca scientifica, nonche' per fini statistici da parte di soggetti che fanno parte del sistema statistico nazionale (Sistan);
- dd) instaurazione, gestione ed estinzione, di rapporti di lavoro di qualunque tipo, anche non retribuito o onorario, e di altre forme di impiego, materia sindacale, occupazione e collocamento obbligatorio, previdenza e assistenza, tutela delle minoranze e pari opportunita' nell'ambito dei rapporti di lavoro, adempimento degli obblighi retributivi, fiscali e contabili, igiene e sicurezza del lavoro o di sicurezza o salute della popolazione, accertamento della responsabilita' civile, disciplinare e contabile, attivita' ispettiva.

3. Per i dati genetici, biometrici e relativi alla salute il trattamento avviene comunque nel rispetto di quanto previsto dall'articolo 2-septies.

------------- AGGIORNAMENTO (49) Il D.L. 8 ottobre 2021, n. 139, convertito con modificazioni dalla L. 3 dicembre 2021, n. 205, ha disposto (con l'art. 9, comma 5) che "Gli articoli 2-ter, comma 1, 2-sexies, comma 1, e 58, commi 1 e 2, del codice di cui al decreto legislativo n. 196 del 2003 [...], come modificati dal presente articolo, si applicano anche ai casi in cui disposizioni di legge gia' in vigore stabiliscono che i tipi di dati che possono essere trattati, le operazioni eseguibili, il motivo di interesse pubblico rilevante, la finalita' del trattamento nonche' le misure appropriate e specifiche per tutelare i diritti fondamentali dell'interessato e i suoi interessi sono previsti da uno o piu' regolamenti".

### Art. 2-septies. - (( (Misure di garanzia per il trattamento dei dati genetici, biometrici e relativi alla salute). ))

((

1. In attuazione di quanto previsto dall'articolo 9, paragrafo 4, del regolamento, i dati genetici, biometrici e relativi alla salute, possono essere oggetto di trattamento in presenza di una delle condizioni di cui al paragrafo 2 del medesimo articolo ed in conformita' alle misure di garanzia disposte dal Garante, nel rispetto di quanto previsto dal presente articolo.

2. Il provvedimento che stabilisce le misure di garanzia di cui al comma 1 e' adottato con cadenza almeno biennale e tenendo conto:

- a) delle linee guida, delle raccomandazioni e delle migliori prassi pubblicate dal Comitato europeo per la protezione dei dati e delle migliori prassi in materia di trattamento dei dati personali;
- b) dell'evoluzione scientifica e tecnologica nel settore oggetto delle misure;
- c) dell'interesse alla libera circolazione dei dati personali nel territorio dell'Unione europea.

3. Lo schema di provvedimento e' sottoposto a consultazione pubblica per un periodo non inferiore a sessanta giorni.

4. Le misure di garanzia sono adottate nel rispetto di quanto previsto dall'articolo 9, paragrafo 2, del Regolamento, e riguardano anche le cautele da adottare relativamente a:

- a) contrassegni sui veicoli e accessi a zone a traffico limitato;
- b) profili organizzativi e gestionali in ambito sanitario;
- c) modalita' per la comunicazione diretta all'interessato delle diagnosi e dei dati relativi alla propria salute;
- d) prescrizioni di medicinali.

5. Le misure di garanzia sono adottate in relazione a ciascuna categoria dei dati personali di cui al comma 1, avendo riguardo alle specifiche finalita' del trattamento e possono individuare, in conformita' a quanto previsto al comma 2, ulteriori condizioni sulla base delle quali il trattamento di tali dati e' consentito. In particolare, le misure di garanzia individuano le misure di sicurezza, ivi comprese quelle tecniche di cifratura e di pseudonomizzazione, le misure di minimizzazione, le specifiche modalita' per l'accesso selettivo ai dati e per rendere le informazioni agli interessati, nonche' le eventuali altre misure necessarie a garantire i diritti degli interessati.

6. Le misure di garanzia che riguardano i dati genetici e il trattamento dei dati relativi alla salute per finalita' di prevenzione, diagnosi e cura nonche' quelle di cui al comma 4, lettere b), c) e d), sono adottate sentito il Ministro della salute che, a tal fine, acquisisce il parere del Consiglio superiore di sanita'. Limitatamente ai dati genetici, le misure di garanzia possono individuare, in caso di particolare ed elevato livello di rischio, il consenso come ulteriore misura di protezione dei diritti dell'interessato, a norma dell'articolo 9, paragrafo 4, del regolamento, o altre cautele specifiche.

7. Nel rispetto dei principi in materia di protezione dei dati personali, con riferimento agli obblighi di cui all'articolo 32 del Regolamento, e' ammesso l'utilizzo dei dati biometrici con riguardo alle procedure di accesso fisico e logico ai dati da parte dei soggetti autorizzati, nel rispetto delle misure di garanzia di cui al presente articolo.

8. I dati personali di cui al comma 1 non possono essere diffusi.

))

### Art. 2-octies. - (( (Principi relativi al trattamento di dati relativi a condanne penali e reati). ))

((

1. Fatto salvo quanto previsto dal decreto legislativo 18 maggio 2018, n. 51, il trattamento di dati personali relativi a condanne penali e a reati o a connesse misure di sicurezza sulla base dell'articolo 6, paragrafo 1, del Regolamento, che non avviene sotto il controllo dell'autorita' pubblica, e' consentito, ai sensi dell'articolo 10 del medesimo regolamento, solo se autorizzato da una norma di legge o, nei casi previsti dalla legge, di regolamento, che prevedano garanzie appropriate per i diritti e le liberta' degli interessati.

2. In mancanza delle predette disposizioni di legge o di regolamento, i trattamenti dei dati di cui al comma 1 nonche' le garanzie di cui al medesimo comma sono individuati con decreto del Ministro della giustizia, da adottarsi, ai sensi dell'articolo 17, comma 3, della legge 23 agosto 1988, n. 400, sentito il Garante.

3. Fermo quanto previsto dai commi 1 e 2, il trattamento di dati personali relativi a condanne penali e a reati o a connesse misure di sicurezza e' consentito se autorizzato da una norma di legge o, nei casi previsti dalla legge, di regolamento, riguardanti, in particolare:

- a) l'adempimento di obblighi e l'esercizio di diritti da parte del titolare o dell'interessato in materia di diritto del lavoro o comunque nell'ambito dei rapporti di lavoro, nei limiti stabiliti da leggi, regolamenti e contratti collettivi, secondo quanto previsto dagli articoli 9, paragrafo 2, lettera b), e 88 del regolamento;
- b) l'adempimento degli obblighi previsti da disposizioni di legge o di regolamento in materia di mediazione finalizzata alla conciliazione delle controversie civili e commerciali;
- c) la verifica o l'accertamento dei requisiti di onorabilita', requisiti soggettivi e presupposti interdittivi nei casi previsti dalle leggi o dai regolamenti;
- d) l'accertamento di responsabilita' in relazione a sinistri o eventi attinenti alla vita umana, nonche' la prevenzione, l'accertamento e il contrasto di frodi o situazioni di concreto rischio per il corretto esercizio dell'attivita' assicurativa, nei limiti di quanto previsto dalle leggi o dai regolamenti in materia;
- e) l'accertamento, l'esercizio o la difesa di un diritto in sede giudiziaria;
- f) l'esercizio del diritto di accesso ai dati e ai documenti amministrativi, nei limiti di quanto previsto dalle leggi o dai regolamenti in materia;
- g) l'esecuzione di investigazioni o le ricerche o la raccolta di informazioni per conto di terzi ai sensi dell'articolo 134 del testo unico delle leggi di pubblica sicurezza;
- h) l'adempimento di obblighi previsti da disposizioni di legge in materia di comunicazioni e informazioni antimafia o in materia di prevenzione della delinquenza di tipo mafioso e di altre gravi forme di pericolosita' sociale, nei casi previsti da leggi o da regolamenti, o per la produzione della documentazione prescritta dalla legge per partecipare a gare d'appalto;
- i) l'accertamento del requisito di idoneita' morale di coloro che intendono partecipare a gare d'appalto, in adempimento di quanto previsto dalle vigenti normative in materia di appalti;
- l) l'attuazione della disciplina in materia di attribuzione del rating di legalita' delle imprese ai sensi dell'articolo 5-ter del decreto-legge 24 gennaio 2012, n. 1, convertito, con modificazioni, dalla legge 24 marzo 2012, n. 27;
- m) l'adempimento degli obblighi previsti dalle normative vigenti in materia di prevenzione dell'uso del sistema finanziario a scopo di riciclaggio dei proventi di attivita' criminose e di finanziamento del terrorismo.

4. Nei casi in cui le disposizioni di cui al comma 3 non individuano le garanzie appropriate per i diritti e le liberta' degli interessati, tali garanzie sono previste con il decreto di cui al comma 2.

5. Quando il trattamento dei dati di cui al presente articolo avviene sotto il controllo dell'autorita' pubblica si applicano le disposizioni previste dall'articolo 2-sexies.

6. Con il decreto di cui al comma 2 e' autorizzato il trattamento dei dati di cui all'articolo 10 del Regolamento, effettuato in attuazione di protocolli di intesa per la prevenzione e il contrasto dei fenomeni di criminalita' organizzata, stipulati con il Ministero dell'interno o con le prefetture-UTG. In relazione a tali protocolli, il decreto di cui al comma 2 individua, le tipologie dei dati trattati, gli interessati, le operazioni di trattamento eseguibili, anche in relazione all'aggiornamento e alla conservazione e prevede le garanzie appropriate per i diritti e le liberta' degli interessati. Il decreto e' adottato, limitatamente agli ambiti di cui al presente comma, di concerto con il Ministro dell'interno.

))

### Art. 2-novies. - (( (Trattamenti disciplinati dalla Presidenza della Repubblica, dalla Camera dei deputati, dal Senato della Repubblica e dalla Corte costituzionale). ))

((

1. Le disposizioni degli articoli 2-sexies, 2-septies e 2-octies del presente decreto legislativo recano principi applicabili, in conformita' ai rispettivi ordinamenti, ai trattamenti delle categorie di dati personali di cui agli articoli 9, paragrafo 1, e 10 del Regolamento, disciplinati dalla Presidenza della Repubblica, dal Senato della Repubblica, dalla Camera dei deputati e dalla Corte costituzionale.

))

### Art. 2-decies. - (( (Inutilizzabilita' dei dati). ))

((

1. I dati personali trattati in violazione della disciplina rilevante in materia di trattamento dei dati personali non possono essere utilizzati, salvo quanto previsto dall'articolo 160-bis.

))

## ((CAPO III - (DISPOSIZIONI IN MATERIA DI DIRITTI DELL'INTERESSATO)))

### Art. 2-undecies. - (Limitazioni ai diritti dell'interessato)

1. I diritti di cui agli articoli da 15 a 22 del Regolamento non possono essere esercitati con richiesta al titolare del trattamento ovvero con reclamo ai sensi dell'articolo 77 del Regolamento qualora dall'esercizio di tali diritti possa derivare un pregiudizio effettivo e concreto:

- a) agli interessi tutelati in base alle disposizioni in materia di riciclaggio;
- b) agli interessi tutelati in base alle disposizioni in materia di sostegno alle vittime di richieste estorsive;
- c) all'attivita' di Commissioni parlamentari d'inchiesta istituite ai sensi dell'articolo 82 della Costituzione;
- d) alle attivita' svolte da un soggetto pubblico, diverso dagli enti pubblici economici, in base ad espressa disposizione di legge, per esclusive finalita' inerenti alla politica monetaria e valutaria, al sistema dei pagamenti, al controllo degli intermediari e dei mercati creditizi e finanziari, nonche' alla tutela della loro stabilita';
- e) allo svolgimento delle investigazioni difensive o all'esercizio di un diritto in sede giudiziaria;
- f-bis) agli interessi tutelati in materia tributaria e allo svolgimento delle attivita' di prevenzione e contrasto all'evasione fiscale.

2. Nei casi di cui al comma 1, lettera c), si applica quanto previsto dai regolamenti parlamentari ovvero dalla legge o dalle norme istitutive della Commissione d'inchiesta.

3. Nei casi di cui al comma 1, lettere a), b), d) e), f) e f-bis) i diritti di cui al medesimo comma sono esercitati conformemente alle disposizioni di legge o di regolamento che regolano il settore, che devono almeno recare misure dirette a disciplinare gli ambiti di cui all'articolo 23, paragrafo 2, del Regolamento. L'esercizio dei medesimi diritti puo', in ogni caso, essere ritardato, limitato o escluso con comunicazione motivata e resa senza ritardo all'interessato, a meno che la comunicazione possa compromettere la finalita' della limitazione, per il tempo e nei limiti in cui cio' costituisca una misura necessaria e proporzionata, tenuto conto dei diritti fondamentali e dei legittimi interessi dell'interessato, al fine di salvaguardare gli interessi di cui al comma 1, lettere a), b), d), e), f) e f-bis) . In tali casi, i diritti dell'interessato possono essere esercitati anche tramite il Garante con le modalita' di cui all'articolo 160. In tale ipotesi, il Garante informa l'interessato di aver eseguito tutte le verifiche necessarie o di aver svolto un riesame, nonche' del diritto dell'interessato di proporre ricorso giurisdizionale. Il titolare del trattamento informa l'interessato delle facolta' di cui al presente comma.

--------------- AGGIORNAMENTO (52) Il D.Lgs. 10 marzo 2023, n. 24, ha disposto (con l'art. 24, comma 1) che "Le disposizioni di cui al presente decreto hanno effetto a decorrere dal 15 luglio 2023".

### Art. 2-duodecies. - (( (Limitazioni per ragioni di giustizia). ))

((

1. In applicazione dell'articolo 23, paragrafo 1, lettera f), del Regolamento, in relazione ai trattamenti di dati personali effettuati per ragioni di giustizia nell'ambito di procedimenti dinanzi agli uffici giudiziari di ogni ordine e grado nonche' dinanzi al Consiglio superiore della magistratura e agli altri organi di autogoverno delle magistrature speciali o presso il Ministero della giustizia, i diritti e gli obblighi di cui agli articoli da 12 a 22 e 34 del Regolamento sono disciplinati nei limiti e con le modalita' previste dalle disposizioni di legge o di Regolamento che regolano tali procedimenti, nel rispetto di quanto previsto dall'articolo 23, paragrafo 2, del Regolamento.

2. Fermo quanto previsto dal comma 1, l'esercizio dei diritti e l'adempimento degli obblighi di cui agli articoli da 12 a 22 e 34 del Regolamento possono, in ogni caso, essere ritardati, limitati o esclusi, con comunicazione motivata e resa senza ritardo all'interessato, a meno che la comunicazione possa compromettere la finalita' della limitazione, nella misura e per il tempo in cui cio' costituisca una misura necessaria e proporzionata, tenuto conto dei diritti fondamentali e dei legittimi interessi dell'interessato, per salvaguardare l'indipendenza della magistratura e dei procedimenti giudiziari.

3. Si applica l'articolo 2-undecies, comma 3, terzo, quarto e quinto periodo.

4. Ai fini del presente articolo si intendono effettuati per ragioni di giustizia i trattamenti di dati personali correlati alla trattazione giudiziaria di affari e di controversie, i trattamenti effettuati in materia di trattamento giuridico ed economico del personale di magistratura, nonche' i trattamenti svolti nell'ambito delle attivita' ispettive su uffici giudiziari. Le ragioni di giustizia non ricorrono per l'ordinaria attivita' amministrativo-gestionale di personale, mezzi o strutture, quando non e' pregiudicata la segretezza di atti direttamente connessi alla trattazione giudiziaria di procedimenti.

))

### Art. 2-terdecies. - (( (Diritti riguardanti le persone decedute). ))

((

1. I diritti di cui agli articoli da 15 a 22 del Regolamento riferiti ai dati personali concernenti persone decedute possono essere esercitati da chi ha un interesse proprio, o agisce a tutela dell'interessato, in qualita' di suo mandatario, o per ragioni familiari meritevoli di protezione.

2. L'esercizio dei diritti di cui al comma 1 non e' ammesso nei casi previsti dalla legge o quando, limitatamente all'offerta diretta di servizi della societa' dell'informazione, l'interessato lo ha espressamente vietato con dichiarazione scritta presentata al titolare del trattamento o a quest'ultimo comunicata.

3. La volonta' dell'interessato di vietare l'esercizio dei diritti di cui al comma 1 deve risultare in modo non equivoco e deve essere specifica, libera e informata; il divieto puo' riguardare l'esercizio soltanto di alcuni dei diritti di cui al predetto comma.

4. L'interessato ha in ogni momento il diritto di revocare o modificare il divieto di cui ai commi 2 e 3.

5. In ogni caso, il divieto non puo' produrre effetti pregiudizievoli per l'esercizio da parte dei terzi dei diritti patrimoniali che derivano dalla morte dell'interessato nonche' del diritto di difendere in giudizio i propri interessi.

))

## ((CAPO IV - (DISPOSIZIONI RELATIVE AL TITOLARE DEL TRATTAMENTO E AL RESPONSABILE DEL TRATTAMENTO)))

### Art. 2-quaterdecies. - (( (Attribuzione di funzioni e compiti a soggetti designati). ))

((

1. Il titolare o il responsabile del trattamento possono prevedere, sotto la propria responsabilita' e nell'ambito del proprio assetto organizzativo, che specifici compiti e funzioni connessi al trattamento di dati personali siano attribuiti a persone fisiche, espressamente designate, che operano sotto la loro autorita'.

2. Il titolare o il responsabile del trattamento individuano le modalita' piu' opportune per autorizzare al trattamento dei dati personali le persone che operano sotto la propria autorita' diretta.

))

### Art. 2-quindecies.

Art. 2-quinquiesdecies ((ARTICOLO ABROGATO DAL D.L. 8 OTTOBRE 2021, N. 139, CONVERTITO CON MODIFICAZIONI DALLA L. 3 DICEMBRE 2021, N. 205))

### Art. 2-sex-decies. - (( (Responsabile della protezione dei dati per i trattamenti effettuati dalle autorita' giudiziarie nell'esercizio delle loro funzioni). ))

((1. Il responsabile della protezione dati e' designato, a norma delle disposizioni di cui alla sezione 4 del capo IV del Regolamento, anche in relazione ai trattamenti di dati personali effettuati dalle autorita' giudiziarie nell'esercizio delle loro funzioni.))

### Art. 2-septies-decies. - (( (Organismo nazionale di accreditamento). ))

((1. L'organismo nazionale di accreditamento di cui all'articolo 43, paragrafo 1, lettera b), del Regolamento e' l'Ente unico nazionale di accreditamento, istituito ai sensi del Regolamento (CE) n. 765/2008, del Parlamento europeo e del Consiglio, del 9 luglio 2008, fatto salvo il potere del Garante di assumere direttamente, con deliberazione pubblicata nella Gazzetta Ufficiale della Repubblica italiana e in caso di grave inadempimento dei suoi compiti da parte dell'Ente unico nazionale di accreditamento, l'esercizio di tali funzioni, anche con riferimento a una o piu' categorie di trattamenti.))

### Art. 3.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 4.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 5.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 6.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## TITOLO II DIRITTI DELL'INTERESSATO <br> ((TITOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 7.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 8.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 9.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 10.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## TITOLO III REGOLE GENERALI PER IL TRATTAMENTO DEI DATI <br> ((TITOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 11.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 12.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 13.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 14.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 15.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 16.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 17.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 18.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 19.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 20.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 21.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 22.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 23.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 24.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 25.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 26.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 27.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## TITOLO IV SOGGETTI CHE EFFETTUANO IL TRATTAMENTO <br> ((TITOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 28.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 29.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 30.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## TITOLO V SICUREZZA DEI DATI E DEI SISTEMI <br> ((TITOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 31.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 32.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 32-bis.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 33.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 34.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 35.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 36.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## TITOLO VI ADEMPIMENTI <br> ((TITOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 37.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101)) ((39))

-------------- AGGIORNAMENTO (39) Il D.Lgs. 10 agosto 2018, n. 101 ha disposto (con l'art. 22, comma 8) che "Il registro dei trattamenti di cui all'articolo 37, comma 4, del codice in materia di protezione dei dati personali, di cui al decreto legislativo n. 196 del 2003, cessa di essere alimentato a far data dal 25 maggio 2018. Da tale data e fino al 31 dicembre 2019, il registro resta accessibile a chiunque secondo le modalita' stabilite nel suddetto articolo 37, comma 4, del decreto legislativo n. 196 del 2003".

### Art. 38.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 39.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 40.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 41.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## TITOLO VII TRASFERIMENTO DEI DATI ALL'ESTERO <br> ((TITOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 42.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 43.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 44.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 45.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## (( DISPOSIZIONI SPECIFICHE PER I TRATTAMENTI NECESSARI PER ADEMPIERE AD UN OBBLIGO LEGALE O PER L'ESECUZIONE DI UN COMPITO DI INTERESSE PUBBLICO O CONNESSO ALL'ESERCIZIO DI PUBBLICI POTERI NONCHE' DISPOSIZIONI PER I TRATTAMENTI DI CUI AL CAPO IX DEL REGOLAMENTO - - TITOLO 0.I (DISPOSIZIONI SULLA BASE GIURIDICA) ))

### Art. 45-bis. - (( (Base giuridica). ))

((

1. Le disposizioni contenute nella presente parte sono stabilite in attuazione dell'articolo 6, paragrafo 2, nonche' dell'articolo 23, paragrafo 1, del regolamento.

))

## TITOLO I TRATTAMENTI IN AMBITO GIUDIZIARIO CAPO I PROFILI GENERALI <br>((CAPO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 46.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 47.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 48.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 49.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO II - MINORI

### Art. 50. - (Notizie o immagini relative a minori)

1. Il divieto di cui all'articolo 13 del decreto del Presidente della Repubblica 22 settembre 1988, n. 448, di pubblicazione e divulgazione con qualsiasi mezzo di notizie o immagini idonee a consentire l'identificazione di un minore si osserva anche in caso di coinvolgimento a qualunque titolo del minore in procedimenti giudiziari in materie diverse da quella penale. (((La violazione del divieto di cui al presente articolo e' punita ai sensi dell'articolo 684 del codice penale)).

## CAPO III - INFORMATICA GIURIDICA

### Art. 51. - (Principi generali)

1. Fermo restando quanto previsto dalle disposizioni processuali concernenti la visione e il rilascio di estratti e di copie di atti e documenti, i dati identificativi delle questioni pendenti dinanzi all'autorita' giudiziaria di ogni ordine e grado sono resi accessibili a chi vi abbia interesse anche mediante reti di comunicazione elettronica, ivi compreso il sito istituzionale della medesima autorita' nella rete Internet.

2. Le sentenze e le altre decisioni dell'autorita' giudiziaria di ogni ordine e grado depositate in cancelleria o segreteria sono rese accessibili anche attraverso il sistema informativo e il sito istituzionale della medesima autorita' nella rete Internet, osservando le cautele previste dal presente capo.

### Art. 52. - (Dati identificativi degli interessati)

1. Fermo restando quanto previsto dalle disposizioni concernenti la redazione e il contenuto di sentenze e di altri provvedimenti giurisdizionali dell'autorita' giudiziaria di ogni ordine e grado, l'interessato puo' chiedere per motivi legittimi, con richiesta depositata nella cancelleria o segreteria dell'ufficio che procede prima che sia definito il relativo grado di giudizio, che sia apposta a cura della medesima cancelleria o segreteria, sull'originale della sentenza o del provvedimento, un'annotazione volta a precludere, in caso di riproduzione della sentenza o provvedimento in qualsiasi forma, ((...)) l'indicazione delle generalita' e di altri dati identificativi del medesimo interessato riportati sulla sentenza o provvedimento.

2. Sulla richiesta di cui al comma 1 provvede in calce con decreto, senza ulteriori formalita', l'autorita' che pronuncia la sentenza o adotta il provvedimento. La medesima autorita' puo' disporre d'ufficio che sia apposta l'annotazione di cui al comma 1, a tutela dei diritti o della dignita' degli interessati.

3. Nei casi di cui ai commi 1 e 2, all'atto del deposito della sentenza o provvedimento, la cancelleria o segreteria vi appone e sottoscrive anche con timbro la seguente annotazione, recante l'indicazione degli estremi del presente articolo: "In caso di diffusione omettere le generalita' e gli altri dati identificativi di....".

4. In caso di diffusione anche da parte di terzi di sentenze o di altri provvedimenti recanti l'annotazione di cui al comma 2, o delle relative massime giuridiche, e' omessa l'indicazione delle generalita' e degli altri dati identificativi dell'interessato.

5. Fermo restando quanto previsto dall'articolo 734-bis del codice penale relativamente alle persone offese da atti di violenza sessuale, chiunque diffonde sentenze o altri provvedimenti giurisdizionali dell'autorita' giudiziaria di ogni ordine e grado e' tenuto ad omettere in ogni caso, anche in mancanza dell'annotazione di cui al comma 2, le generalita', altri dati identificativi o altri dati anche relativi a terzi dai quali puo' desumersi anche indirettamente l'identita' di minori, oppure delle parti nei procedimenti in materia di rapporti di famiglia e di stato delle persone.

6. Le disposizioni di cui al presente articolo si applicano anche in caso di deposito di lodo ai sensi dell'articolo 825 del codice di procedura civile. La parte puo' formulare agli arbitri la richiesta di cui al comma 1 prima della pronuncia del lodo e gli arbitri appongono sul lodo l'annotazione di cui al comma 3, anche ai sensi del comma 2. Il collegio arbitrale costituito presso la camera arbitrale per i lavori pubblici ai sensi ((dell'articolo 209 del Codice dei contratti pubblici di cui al decreto legislativo 18 aprile 2016, n. 50,)) provvede in modo analogo in caso di richiesta di una parte.

7. Fuori dei casi indicati nel presente articolo e' ammessa la diffusione in ogni forma del contenuto anche integrale di sentenze e di altri provvedimenti giurisdizionali.

## TITOLO II TRATTAMENTI DA PARTE DI FORZE DI POLIZIA CAPO I PROFILI GENERALI

### Art. 53.

((ARTICOLO ABROGATO DAL D.LGS. 18 MAGGIO 2018, N. 51)) ((34))

--------------- AGGIORNAMENTO (34) Il D.Lgs. 18 maggio 2018, n. 51 ha disposto (con l'art. 49, comma 3) che "I decreti adottati in attuazione degli articoli 53 e 57 del Codice continuano ad applicarsi fino all'adozione di diversa disciplina ai sensi degli articoli 5, comma 2, e 9, comma 5".

### Art. 54.

((ARTICOLO ABROGATO DAL D.LGS. 18 MAGGIO 2018, N. 51))

### Art. 55.

((ARTICOLO ABROGATO DAL D.LGS. 18 MAGGIO 2018, N. 51))

### Art. 56.

((ARTICOLO ABROGATO DAL D.LGS. 18 MAGGIO 2018, N. 51))

### Art. 57. - (Disposizioni di attuazione)

1. Con decreto del Presidente della Repubblica, previa deliberazione del Consiglio dei ministri, su proposta del Ministro dell'interno, di concerto con il Ministro della giustizia, sono individuate le modalita' di attuazione dei principi del presente codice relativamente al trattamento dei dati effettuato per le finalita' di cui all'articolo 53 dal Centro elaborazioni dati e da organi, uffici o comandi di polizia, anche ad integrazione e modifica del decreto del Presidente della Repubblica 3 maggio 1982, n. 378, e in attuazione della Raccomandazione R (87) 15 del Consiglio d'Europa del 17 settembre 1987, e successive modificazioni. Le modalita' sono individuate con particolare riguardo:

- a) al principio secondo cui la raccolta dei dati e' correlata alla specifica finalita' perseguita, in relazione alla prevenzione di un pericolo concreto o alla repressione di reati, in particolare per quanto riguarda i trattamenti effettuati per finalita' di analisi;
- b) all'aggiornamento periodico dei dati, anche relativi a valutazioni effettuate in base alla legge, alle diverse modalita' relative ai dati trattati senza l'ausilio di strumenti elettronici e alle modalita' per rendere conoscibili gli aggiornamenti da parte di altri organi e uffici cui i dati sono stati in precedenza comunicati;
- c) ai presupposti per effettuare trattamenti per esigenze temporanee o collegati a situazioni particolari, anche ai fini della verifica dei requisiti dei dati ai sensi dell'articolo 11, dell'individuazione delle categorie di interessati e della conservazione separata da altri dati che non richiedono il loro utilizzo;
- d) all'individuazione di specifici termini di conservazione dei dati in relazione alla natura dei dati o agli strumenti utilizzati per il loro trattamento, nonche' alla tipologia dei procedimenti nell'ambito dei quali essi sono trattati o i provvedimenti sono adottati;
- e) alla comunicazione ad altri soggetti, anche all'estero o per l'esercizio di un diritto o di un interesse legittimo, e alla loro diffusione, ove necessaria in conformita' alla legge;
- f) all'uso di particolari tecniche di elaborazione e di ricerca delle informazioni, anche mediante il ricorso a sistemi di indice. ((46))

--------------- AGGIORNAMENTO (46) Il D.L. 14 giugno 2019, n. 53 ha disposto (con l'art. 9, comma 1) che il presente articolo riprende vigore dal 15 giugno 2019 fino al 31 dicembre 2019.

## TITOLO III DIFESA E SICUREZZA DELLO STATO CAPO I PROFILI GENERALI

### Art. 58. - (Trattamenti di dati personali per fini di sicurezza nazionale o difesa)

1. Ai trattamenti di dati personali effettuati dagli organismi di cui agli articoli 4, 6 e 7 della legge 3 agosto 2007, n. 124, sulla base dell'articolo 26 della predetta legge o di altre disposizioni di legge o regolamento ((o previste da atti amministrativi generali)), ovvero relativi a dati coperti da segreto di Stato ai sensi degli articoli 39 e seguenti della medesima legge, si applicano le disposizioni di cui all'articolo 160, comma 4, nonche', in quanto compatibili, le disposizioni di cui agli articoli 2, 3, 8, 15, 16, 18, 25, 37, 41, 42 e 43 del decreto legislativo 18 maggio 2018, n. 51. ((49))

2. Fermo restando quanto previsto dal comma 1, ai trattamenti effettuati da soggetti pubblici per finalita' di difesa o di sicurezza dello Stato, in base ((a)) disposizioni di legge ((o di regolamento o previste da atti amministrativi generali,)) che prevedano specificamente il trattamento, si applicano le disposizioni di cui al comma 1 del presente articolo, nonche' quelle di cui agli articoli 23 e 24 del decreto legislativo 18 maggio 2018, n. 51. ((49))

3. Con uno o piu' regolamenti sono individuate le modalita' di applicazione delle disposizioni di cui ai commi 1 e 2, in riferimento alle tipologie di dati, di interessati, di operazioni di trattamento eseguibili e di persone autorizzate al trattamento dei dati personali sotto l'autorita' diretta del titolare o del responsabile ai sensi dell'articolo 2-quaterdecies, anche in relazione all'aggiornamento e alla conservazione. I regolamenti, negli ambiti di cui al comma 1, sono adottati ai sensi dell'articolo 43 della legge 3 agosto 2007, n. 124, e, negli ambiti di cui al comma 2, sono adottati con decreto del Presidente del Consiglio dei ministri, ai sensi dell'articolo 17, comma 3, della legge 23 agosto 1988, n. 400, su proposta dei Ministri competenti.

4. Con uno o piu' regolamenti adottati con decreto del Presidente della Repubblica su proposta del Ministro della difesa, sono disciplinate le misure attuative del presente decreto in materia di esercizio delle funzioni di difesa e sicurezza nazionale da parte delle Forze armate.

---------------- AGGIORNAMENTO (49) Il D.L. 8 ottobre 2021, n. 139, convertito con modificazioni dalla L. 3 dicembre 2021, n. 205, ha disposto (con l'art. 9, comma 5) che "Gli articoli 2-ter, comma 1, 2-sexies, comma 1, e 58, commi 1 e 2, del codice di cui al decreto legislativo n. 196 del 2003 [...], come modificati dal presente articolo, si applicano anche ai casi in cui disposizioni di legge gia' in vigore stabiliscono che i tipi di dati che possono essere trattati, le operazioni eseguibili, il motivo di interesse pubblico rilevante, la finalita' del trattamento nonche' le misure appropriate e specifiche per tutelare i diritti fondamentali dell'interessato e i suoi interessi sono previsti da uno o piu' regolamenti".

## TITOLO IV TRATTAMENTI IN AMBITO PUBBLICO CAPO I ACCESSO A DOCUMENTI AMMINISTRATIVI

### Art. 59.

( Accesso a documenti amministrativi ((e accesso civico)) )

1. Fatto salvo quanto previsto dall'articolo 60, i presupposti, le modalita', i limiti per l'esercizio del diritto di accesso a documenti amministrativi contenenti dati personali, e la relativa tutela giurisdizionale, restano disciplinati dalla legge 7 agosto 1990, n. 241, e successive modificazioni e dalle altre disposizioni di legge in materia, nonche' dai relativi regolamenti di attuazione, anche per cio' che concerne i tipi di dati ((di cui agli articoli 9 e 10 del regolamento)) e le operazioni di trattamento eseguibili in esecuzione di una richiesta di accesso. ((PERIODO SOPPRESSO DAL D.LGS. 10 AGOSTO 2018, N. 101)).

((

1-bis. I presupposti, le modalita' e i limiti per l'esercizio del diritto di accesso civico restano disciplinati dal decreto legislativo 14 marzo 2013, n. 33.

))

### Art. 60. - (( Dati relativi alla salute o alla vita sessuale o all'orientamento sessuale). ))

((

1. Quando il trattamento concerne dati genetici, relativi alla salute, alla vita sessuale o all'orientamento sessuale della persona, il trattamento e' consentito se la situazione giuridicamente rilevante che si intende tutelare con la richiesta di accesso ai documenti amministrativi, e' di rango almeno pari ai diritti dell'interessato, ovvero consiste in un diritto della personalita' o in un altro diritto o liberta' fondamentale.

))

## CAPO II - REGISTRI PUBBLICI E ALBI PROFESSIONALI

### Art. 61.

( Utilizzazione di dati pubblici ((e regole deontologiche)) ) ((

1. Il Garante promuove, ai sensi dell'articolo 2-quater, l'adozione di regole deontologiche per il trattamento dei dati personali provenienti da archivi, registri, elenchi, atti o documenti tenuti da soggetti pubblici, anche individuando i casi in cui deve essere indicata la fonte di acquisizione dei dati e prevedendo garanzie appropriate per l'associazione di dati provenienti da piu' archivi, tenendo presenti le pertinenti Raccomandazioni del Consiglio d'Europa.

2. Agli effetti dell'applicazione del presente codice i dati personali diversi da quelli di cui agli articoli 9 e 10 del regolamento, che devono essere inseriti in un albo professionale in conformita' alla legge o ad un regolamento, possono essere comunicati a soggetti pubblici e privati o diffusi, ai sensi dell'articolo 2-ter del presente codice, anche mediante reti di comunicazione elettronica. Puo' essere altresi' menzionata l'esistenza di provvedimenti che a qualsiasi titolo incidono sull'esercizio della professione.

3. L'ordine o collegio professionale puo', a richiesta della persona iscritta nell'albo che vi ha interesse, integrare i dati di cui al comma 2 con ulteriori dati pertinenti e non eccedenti in relazione all'attivita' professionale.

4. A richiesta dell'interessato l'ordine o collegio professionale puo' altresi' fornire a terzi notizie o informazioni relative, in particolare, a speciali qualificazioni professionali non menzionate nell'albo, ovvero alla disponibilita' ad assumere incarichi o a ricevere materiale informativo a carattere scientifico inerente anche a convegni o seminart.

## CAPO III - STATO CIVILE, ANAGRAFI E LISTE ELETTORALI <br> ((CAPO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 62.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 63.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO IV - FINALITA' DI RILEVANTE INTERESSE PUBBLICO <br> ((CAPO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 64.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 65.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 66.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 67.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 68.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 69.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 70.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 71.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 72.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 73.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO V - PARTICOLARI CONTRASSEGNI <br> ((CAPO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 74.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## TITOLO V TRATTAMENTO DI DATI PERSONALI IN AMBITO SANITARIO CAPO I PRINCIPI GENERALI

### Art. 75. - (( (Specifiche condizioni in ambito sanitario). ))

((

1. Il trattamento dei dati personali effettuato per finalita' di tutela della salute e incolumita' fisica dell'interessato o di terzi o della collettivita' deve essere effettuato ai sensi dell'articolo 9, paragrafi 2, lettere h) ed i), e 3 del regolamento, dell'articolo 2-septies del presente codice, nonche' nel rispetto delle specifiche disposizioni di settore.

))

### Art. 76.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO II - ((MODALITA' PARTICOLARI PER INFORMARE L'INTERESSATO E PER IL TRATTAMENTO DEI DATI PERSONALI))

### Art. 77. - (( (Modalita' particolari). ))

((

1. Le disposizioni del presente titolo individuano modalita' particolari utilizzabili dai soggetti di cui al comma 2:

- a) per informare l'interessato ai sensi degli articoli 13 e 14 del Regolamento;
- b) per il trattamento dei dati personali.

2. Le modalita' di cui al comma 1 sono applicabili:

- a) dalle strutture pubbliche e private, che erogano prestazioni sanitarie e socio-sanitarie e dagli esercenti le professioni sanitarie;
- b) dai soggetti pubblici indicati all'articolo 80.

))

### Art. 78.

( ((Informazioni)) del medico di medicina generale o del pediatra )

1. Il medico di medicina generale o il pediatra di libera scelta informano l'interessato relativamente al trattamento dei dati personali, in forma chiara e tale da rendere agevolmente comprensibili gli elementi indicati ((negli articoli 13 e 14 del Regolamento)).

2. ((Le informazioni possono essere fornite)) per il complessivo trattamento dei dati personali necessario per attivita' di ((diagnosi, assistenza e terapia sanitaria)), svolte dal medico o dal pediatra a tutela della salute o dell'incolumita' fisica dell'interessato, su richiesta dello stesso o di cui questi e' informato in quanto effettuate nel suo interesse.

((

3. Le informazioni possono riguardare, altresi', dati personali eventualmente raccolti presso terzi e sono fornite preferibilmente per iscritto.

))

4. ((Le informazioni)), se non e' diversamente specificato dal medico o dal pediatra, ((riguardano)) anche il trattamento di dati correlato a quello effettuato dal medico di medicina generale o dal pediatra di libera scelta, effettuato da un professionista o da altro soggetto, parimenti individuabile in base alla prestazione richiesta, che:

- a) sostituisce temporaneamente il medico o il pediatra;
- b) fornisce una prestazione specialistica su richiesta del medico e del pediatra;
- c) puo' trattare lecitamente i dati nell'ambito di un'attivita' professionale prestata in forma associata;
- d) fornisce farmaci prescritti;
- e) comunica dati personali al medico o pediatra in conformita' alla disciplina applicabile.

5. ((Le informazioni rese)) ai sensi del presente articolo ((evidenziano)) analiticamente eventuali trattamenti di dati personali che presentano rischi specifici per i diritti e le liberta' fondamentali, nonche' per la dignita' dell'interessato, in particolare in caso di trattamenti effettuati: ((a) per fini di ricerca scientifica anche nell'ambito di sperimentazioni cliniche, in conformita' alle leggi e ai regolamenti, ponendo in particolare evidenza che il consenso, ove richiesto, e' manifestato liberamente;)) b) nell'ambito della teleassistenza o telemedicina; c) per fornire altri beni o servizi all'interessato attraverso una rete di comunicazione elettronica. ((c-bis) ai fini dell'implementazione del fascicolo sanitario elettronico di cui all'articolo 12 del decreto-legge 18 ottobre 2012, n. 179, convertito, con modificazioni, dalla legge 17 dicembre 2012, n. 221; c-ter) ai fini dei sistemi di sorveglianza e dei registri di cui all'articolo 12 del decreto-legge 18 ottobre 2012, n. 179, convertito, con modificazioni, dalla legge 17 dicembre 2012, n. 221.))

### Art. 79.

(( (Informazioni da parte di strutture pubbliche e private che erogano prestazioni sanitarie e socio-sanitarie) )) ((

1. Le strutture pubbliche e private, che erogano prestazioni sanitarie e socio-sanitarie possono avvalersi delle modalita' particolari di cui all'articolo 78 in riferimento ad una pluralita' di prestazioni erogate anche da distinti reparti ed unita' della stessa struttura o di sue articolazioni ospedaliere o territoriali specificamente identificate.

2. Nei casi di cui al comma 1 l'organismo o le strutture annotano l'avvenuta ((informazione)) con modalita' uniformi e tali da permettere una verifica al riguardo da parte di altri reparti ed unita' che, anche in tempi diversi, trattano dati relativi al medesimo interessato. ((39))

3. Le modalita' ((particolari di cui all'articolo 78)) possono essere utilizzate in modo omogeneo e coordinato in riferimento all'insieme dei trattamenti di dati personali effettuati nel complesso delle strutture facenti capo alle aziende sanitarie.

4. Sulla base di adeguate misure organizzative in applicazione del comma 3, le modalita' ((particolari)) possono essere utilizzate per piu' trattamenti di dati effettuati nei casi di cui al presente articolo e dai soggetti di cui all'articolo 80.

------------- AGGIORNAMENTO (39) Il D.Lgs. 10 agosto 2018, n. 101 ha disposto (con l'art. 6, comma 1, lettera e)) che "al comma 2, le parole «l'organismo e le strutture» sono sostituite dalle seguenti: «la struttura o le sue articolazioni»".

### Art. 80. - (( (Informativa da parte di altri soggetti) ))

((

1. Nel fornire le informazioni di cui agli articoli 13 e 14 del Regolamento, oltre a quanto previsto dall'articolo 79, possono avvalersi della facolta' di fornire un'unica informativa per una pluralita' di trattamenti di dati effettuati, a fini amministrativi e in tempi diversi, rispetto a dati raccolti presso l'interessato e presso terzi, i competenti servizi o strutture di altri soggetti pubblici, diversi da quelli di cui al predetto articolo 79, operanti in ambito sanitario o della protezione e sicurezza sociale.

2. Le informazioni di cui al comma 1 sono integrate con appositi e idonei cartelli ed avvisi agevolmente visibili al pubblico, affissi e diffusi anche nell'ambito di pubblicazioni istituzionali e mediante reti di comunicazione elettronica, in particolare per quanto riguarda attivita' amministrative effettuate per motivi di interesse pubblico rilevante che non richiedono il consenso degli interessati.

))

### Art. 81.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 82. - (Emergenze e tutela della salute e dell'incolumita' fisica)

1. ((Le informazioni di cui agli articoli 13 e 14 del Regolamento possono essere rese)) senza ritardo, successivamente alla prestazione, nel caso di emergenza sanitaria o di igiene pubblica per la quale la competente autorita' ha adottato un'ordinanza contingibile ed urgente ai sensi dell'articolo 117 del decreto legislativo 31 marzo 1998, n. 112.

2. ((Tali informazioni possono altresi' essere rese)) senza ritardo, successivamente alla prestazione, in caso di: ((a) impossibilita' fisica, incapacita' di agire o incapacita' di intendere o di volere dell'interessato, quando non e' possibile rendere le informazioni, nei casi previsti, a chi esercita legalmente la rappresentanza, ovvero a un prossimo congiunto, a un familiare, a un convivente o unito civilmente ovvero a un fiduciario ai sensi dell'articolo 4 della legge 22 dicembre 2017, n. 219 o, in loro assenza, al responsabile della struttura presso cui dimora l'interessato;)) b) rischio grave, imminente ed irreparabile per la salute o dell'interessato.

3. ((Le informazioni di cui al comma 1 possono essere rese)) senza ritardo, successivamente alla prestazione, anche in caso di prestazione medica che puo' essere pregiudicata ((dal loro preventivo rilascio)), in termini di tempestivita' o efficacia.

4. Dopo il raggiungimento della maggiore eta' ((le informazioni sono fornite)) all'interessato ((nel caso in cui non siano state fornite in precedenza)).

### Art. 83.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 84.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO III - FINALITA' DI RILEVANTE INTERESSE PUBBLICO <br> ((CAPO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 85.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 86.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO IV - PRESCRIZIONI MEDICHE

### Art. 87.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 88.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 89.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 89-bis. - (( (Prescrizioni di medicinali) ))

((

1. Per le prescrizioni di medicinali, laddove non e' necessario inserire il nominativo dell'interessato, si adottano cautele particolari in relazione a quanto disposto dal Garante nelle misure di garanzia di cui all'articolo 2-septies, anche ai fini del controllo della correttezza della prescrizione ovvero per finalita' amministrative o per fini di ricerca scientifica nel settore della sanita' pubblica.

))

## CAPO V - DATI GENETICI <br> ((CAPO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 90.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO VI - DISPOSIZIONI VARIE

### Art. 91.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 92. - (Cartelle cliniche)

1. Nei casi in cui ((strutture, pubbliche e private, che erogano prestazioni sanitarie e socio-sanitarie)) redigono e conservano una cartella clinica in conformita' alla disciplina applicabile, sono adottati opportuni accorgimenti per assicurare la comprensibilita' dei dati e per distinguere i dati relativi al paziente da quelli eventualmente riguardanti altri interessati, ivi comprese informazioni relative a nascituri.

2. Eventuali richieste di presa visione o di rilascio di copia della cartella e dell'acclusa scheda di dimissione ospedaliera da parte di soggetti diversi dall'interessato possono essere accolte, in tutto o in parte, solo se la richiesta e' giustificata dalla documentata necessita':

- a) ((di esercitare)) o difendere un diritto in sede giudiziaria ((, ai sensi dell'articolo 9, paragrafo 2, lettera f), del Regolamento,)) di rango pari a quello dell'interessato, ovvero consistente in un diritto della personalita' o in un altro diritto o liberta' fondamentale ((...));
- b) di tutelare, in conformita' alla disciplina sull'accesso ai documenti amministrativi, una situazione giuridicamente rilevante di rango pari a quella dell'interessato, ovvero consistente in un diritto della personalita' o in un altro diritto o liberta' fondamentale ((...)).

### Art. 93. - (Certificato di assistenza al parto)

1. Ai fini della dichiarazione di nascita il certificato di assistenza al parto e' sempre sostituito da una semplice attestazione contenente i soli dati richiesti nei registri di nascita. Si osservano, altresi', le disposizioni dell'articolo 109.

2. Il certificato di assistenza al parto o la cartella clinica, ove comprensivi dei dati personali che rendono identificabile la madre che abbia dichiarato di non voler essere nominata avvalendosi della facolta' di cui all'articolo 30, comma 1, del decreto del Presidente della Repubblica 3 novembre 2000, n. 396, possono essere rilasciati in copia integrale a chi vi abbia interesse, in conformita' alla legge, decorsi cento anni dalla formazione del documento.

3. Durante il periodo di cui al comma 2 la richiesta di accesso al certificato o alla cartella puo' essere accolta relativamente ai dati relativi alla madre che abbia dichiarato di non voler essere nominata, osservando le opportune cautele per evitare che quest'ultima sia identificabile.

### Art. 94.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## TITOLO VI ISTRUZIONE CAPO I PROFILI GENERALI

### Art. 95.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 96. - (( (Trattamento di dati relativi a studenti). ))

((

1. Al fine di agevolare l'orientamento, la formazione e l'inserimento professionale, anche all'estero, le istituzioni del sistema nazionale di istruzione, i centri di formazione professionale regionale, le scuole private non paritarie nonche' le istituzioni di alta formazione artistica e coreutica e le universita' statali o non statali legalmente riconosciute su richiesta degli interessati, possono comunicare o diffondere, anche a privati e per via telematica, dati relativi agli esiti formativi, intermedi e finali, degli studenti e altri dati personali diversi da quelli di cui agli articoli 9 e 10 del Regolamento, pertinenti in relazione alle predette finalita' e indicati nelle informazioni rese agli interessati ai sensi dell'articolo 13 del Regolamento. I dati possono essere successivamente trattati esclusivamente per le predette finalita'.

2. Resta ferma la disposizione di cui all'articolo 2, comma 2, del decreto del Presidente della Repubblica 24 giugno 1998, n. 249, sulla tutela del diritto dello studente alla riservatezza. Restano altresi' ferme le vigenti disposizioni in materia di pubblicazione dell'esito degli esami mediante affissione nell'albo dell'istituto e di rilascio di diplomi e certificati.

))

## TITOLO VII (( (TRATTAMENTI A FINI DI ARCHIVIAZIONE NEL PUBBLICO INTERESSE, DI RICERCA SCIENTIFICA O STORICA O A FINI STATISTICI) )) CAPO I PROFILI GENERALI

### Art. 97. - (( (Ambito applicativo). ))

((

1. Il presente titolo disciplina il trattamento dei dati personali effettuato a fini di archiviazione nel pubblico interesse, di ricerca scientifica o storica o a fini statistici, ai sensi dell'articolo 89 del regolamento.

))

### Art. 98.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 99. - (( (Durata del trattamento). ))

((

1. Il trattamento di dati personali a fini di archiviazione nel pubblico interesse, di ricerca scientifica o storica o a fini statistici puo' essere effettuato anche oltre il periodo di tempo necessario per conseguire i diversi scopi per i quali i dati sono stati in precedenza raccolti o trattati.

2. A fini di archiviazione nel pubblico interesse, di ricerca scientifica o storica o a fini statistici possono comunque essere conservati o ceduti ad altro titolare i dati personali dei quali, per qualsiasi causa, e' cessato il trattamento nel rispetto di quanto previsto dall'articolo 89, paragrafo 1, del Regolamento.

))

### Art. 100. - (Dati relativi ad attivita' di studio e ricerca)

1. Al fine di promuovere e sostenere la ricerca e la collaborazione in campo scientifico e tecnologico i soggetti pubblici, ivi comprese le universita' e gli enti di ricerca, possono con autonome determinazioni comunicare e diffondere, anche a privati e per via telematica, dati relativi ad attivita' di studio e di ricerca, a laureati, dottori di ricerca, tecnici e tecnologi, ricercatori, docenti, esperti e studiosi, con esclusione di quelli ((di cui agli articoli 9 e 10 del Regolamento)).

2. Resta fermo il diritto dell'interessato di ((rettifica, cancellazione, limitazione e opposizione ai sensi degli articoli 16, 17, 18 e 21 del Regolamento)).

3. I dati di cui al presente articolo non costituiscono documenti amministrativi ai sensi della legge 7 agosto 1990, n. 241.

4. I dati di cui al presente articolo possono essere successivamente trattati per i soli scopi in base ai quali sono comunicati o diffusi.

((

4-bis. I diritti di cui al comma 2 si esercitano con le modalita' previste dalle regole deontologiche.

))

## CAPO II - ((TRATTAMENTO A FINI DI ARCHIVIAZIONE NEL PUBBLICO INTERESSE O DI RICERCA STORICA))

### Art. 101. - (Modalita' di trattamento)

1. I dati personali raccolti ((a fini di archiviazione nel pubblico interesse o di ricerca storica)) non possono essere utilizzati per adottare atti o provvedimenti amministrativi sfavorevoli all'interessato, salvo che siano utilizzati anche per altre finalita' nel rispetto ((dell'articolo 5 del regolamento)).

2. I documenti contenenti dati personali, trattati ((a fini di archiviazione nel pubblico interesse o di ricerca storica)), possono essere utilizzati, tenendo conto della loro natura, solo se pertinenti e indispensabili per il perseguimento di tali scopi. I dati personali diffusi possono essere utilizzati solo per il perseguimento dei medesimi scopi.

3. I dati personali possono essere comunque diffusi quando sono relativi a circostanze o fatti resi noti direttamente dall'interessato o attraverso suoi comportamenti in pubblico.

### Art. 102. - (( (Regole deontologiche per il trattamento a fini di archiviazione nel pubblico interesse o di ricerca storica) ))

((

1. Il Garante promuove, ai sensi dell'articolo 2-quater, la sottoscrizione di regole deontologiche per i soggetti pubblici e privati, ivi comprese le societa' scientifiche e le associazioni professionali, interessati al trattamento dei dati a fini di archiviazione nel pubblico interesse o di ricerca storica.

))

((2. Le regole deontologiche di cui al comma 1 individuano garanzie adeguate per i diritti e le liberta' dell'interessato in particolare:))

((e del Regolamento))

((a fini di archiviazione nel pubblico interesse o di ricerca storica))

### Art. 103. - (( (Consultazione di documenti conservati in archivi). ))

((

1. La consultazione dei documenti conservati negli archivi di Stato, in quelli storici degli enti pubblici e in archivi privati dichiarati di interesse storico particolarmente importante e' disciplinata dal decreto legislativo 22 gennaio 2004, n. 42 e dalle relative regole deontologiche.

))

## CAPO III - ((TRATTAMENTO A FINI STATISTICI O DI RICERCA SCIENTIFICA))

### Art. 104.

(Ambito applicativo e dati identificativi (( a fini statistici o di ricerca scientifica)) )

1. Le disposizioni del presente capo si applicano ai trattamenti di dati per ((fini statistici)) o, in quanto compatibili, per ((per fini di ricerca scientifica)).

2. Agli effetti dell'applicazione del presente capo, in relazione ai dati identificativi si tiene conto dell'insieme dei mezzi che possono essere ragionevolmente utilizzati dal titolare o da altri per identificare l'interessato, anche in base alle conoscenze acquisite in relazione al progresso tecnico.

### Art. 105. - (Modalita' di trattamento)

1. I dati personali trattati ((a fini statistici o di ricerca scientifica)) non possono essere utilizzati per prendere decisioni o provvedimenti relativamente all'interessato, ne' per trattamenti di dati per scopi di altra natura.

2. ((I fini statistici e di ricerca scientifica)) devono essere chiaramente determinati e resi noti all'interessato, nei modi di cui ((agli articoli 13 e 14 del regolamento)) anche in relazione a quanto previsto dall'articolo 106, comma 2, lettera b), del presente codice e dall'articolo 6-bis del decreto legislativo 6 settembre 1989, n. 322 ((...)).

3. Quando specifiche circostanze individuate ((dalle regole deontologiche)) di cui all'articolo 106 sono tali da consentire ad un soggetto di rispondere in nome e per conto di un altro, in quanto familiare o convivente, ((le informazioni all'interessato possono essere date)) anche per il tramite del soggetto rispondente.

4. Per il trattamento effettuato ((a fini statistici o di ricerca scientifica)) rispetto a dati raccolti per altri scopi, ((le informazioni all'interessato non sono dovute)) quando richiede uno sforzo sproporzionato rispetto al diritto tutelato, se sono adottate le idonee forme di pubblicita' individuate ((dalle regole deontologiche)) di cui all'articolo 106.

### Art. 106. - (( (Regole deontologiche per trattamenti a fini statistici o di ricerca scientifica). ))

((

1. Il Garante promuove, ai sensi dell'articolo 2-quater, regole deontologiche per i soggetti pubblici e privati, ivi comprese le societa' scientifiche e le associazioni professionali, interessati al trattamento dei dati per fini statistici o di ricerca scientifica, volte a individuare garanzie adeguate per i diritti e le liberta' dell'interessato in conformita' all'articolo 89 del Regolamento.

2. Con le regole deontologiche di cui al comma 1, tenendo conto, per i soggetti gia' compresi nell'ambito del Sistema statistico nazionale, di quanto gia' previsto dal decreto legislativo 6 settembre 1989, n. 322, e, per altri soggetti, sulla base di analoghe garanzie, sono individuati in particolare:

- a) i presupposti e i procedimenti per documentare e verificare che i trattamenti, fuori dai casi previsti dal medesimo decreto legislativo n. 322 del 1989, siano effettuati per idonei ed effettivi fini statistici o di ricerca scientifica;
- b) per quanto non previsto dal presente codice, gli ulteriori presupposti del trattamento e le connesse garanzie, anche in riferimento alla durata della conservazione dei dati, alle informazioni da rendere agli interessati relativamente ai dati raccolti anche presso terzi, alla comunicazione e diffusione, ai criteri selettivi da osservare per il trattamento di dati identificativi, alle specifiche misure di sicurezza e alle modalita' per la modifica dei dati a seguito dell'esercizio dei diritti dell'interessato, tenendo conto dei principi contenuti nelle pertinenti raccomandazioni del Consiglio d'Europa;
- c) l'insieme dei mezzi che possono essere ragionevolmente utilizzati dal titolare del trattamento o da altri per identificare direttamente o indirettamente l'interessato, anche in relazione alle conoscenze acquisite in base al progresso tecnico;
- d) le garanzie da osservare nei casi in cui si puo' prescindere dal consenso dell'interessato, tenendo conto dei principi contenuti nelle raccomandazioni di cui alla lettera b);
- e) modalita' semplificate per la prestazione del consenso degli interessati relativamente al trattamento dei dati di cui all'articolo 9 del regolamento;
- f) i casi nei quali i diritti di cui agli articoli 15, 16, 18 e 21 del Regolamento possono essere limitati ai sensi dell'articolo 89, paragrafo 2, del medesimo Regolamento;
- g) le regole di correttezza da osservare nella raccolta dei dati e le istruzioni da impartire alle persone autorizzate al trattamento dei dati personali sotto l'autorita' diretta del titolare o del responsabile ai sensi dell'articolo 2-quaterdecies;
- h) le misure da adottare per favorire il rispetto del principio di minimizzazione e delle misure tecniche e organizzative di cui all'articolo 32 del Regolamento, anche in riferimento alle cautele volte ad impedire l'accesso da parte di persone fisiche che non sono autorizzate o designate e l'identificazione non autorizzata degli interessati, all'interconnessione dei sistemi informativi anche nell'ambito del Sistema statistico nazionale e all'interscambio di dati per fini statistici o di ricerca scientifica da effettuarsi con enti ed uffici situati all'estero;
- i) l'impegno al rispetto di regole deontologiche da parte delle persone che, ai sensi dell'articolo 2-quaterdecies, risultano autorizzate al trattamento dei dati personali sotto l'autorita' diretta del titolare o del responsabile del trattamento, che non sono tenute in base alla legge al segreto d'ufficio o professionale, tali da assicurare analoghi livelli di sicurezza e di riservatezza.

))

### Art. 107. - (( (Trattamento di categorie particolari di dati personali). ))

((

1. Fermo restando quanto previsto dall'articolo 2-sexies e fuori dei casi di particolari indagini a fini statistici o di ricerca scientifica previste dalla legge, il consenso dell'interessato al trattamento di dati di cui all'articolo 9 del Regolamento, quando e' richiesto, puo' essere prestato con modalita' semplificate, individuate dalle regole deontologiche di cui all'articolo 106 o dalle misure di cui all'articolo 2-septies.

))

### Art. 108. - (( (Sistema statistico nazionale). ))

((

1. Il trattamento di dati personali da parte di soggetti che fanno parte del Sistema statistico nazionale, oltre a quanto previsto dalle regole deontologiche di cui all'articolo 106, comma 2, resta inoltre disciplinato dal decreto legislativo 6 settembre 1989, n. 322, in particolare per quanto riguarda il trattamento dei dati di cui all'articolo 9 del Regolamento indicati nel programma statistico nazionale, le informative all'interessato, l'esercizio dei relativi diritti e i dati non tutelati dal segreto statistico ai sensi dell'articolo 9, comma 4, del medesimo decreto legislativo n. 322 del 1989.

))

### Art. 109. - (Dati statistici relativi all'evento della nascita)

1. Per la rilevazione dei dati statistici relativi agli eventi di nascita, compresi quelli relativi ai nati affetti da malformazioni e ai nati morti, nonche' per i flussi di dati anche da parte di direttori sanitari, si osservano, oltre alle disposizioni di cui al decreto del Ministro della sanita' 16 luglio 2001, n. 349, le modalita' tecniche determinate dall'istituto nazionale ((di statistica, sentiti i Ministri)) della salute, dell'interno e il Garante.

### Art. 110. - (Ricerca medica, biomedica ed epidemiologica)

1. Il consenso dell'interessato per il trattamento dei dati relativi alla salute, a fini di ricerca scientifica in campo medico, biomedico o epidemiologico, non e' necessario quando la ricerca e' effettuata in base a disposizioni di legge o di regolamento o al diritto dell'Unione europea in conformita' all'articolo 9, paragrafo 2, lettera j), del Regolamento, ivi incluso il caso in cui la ricerca rientra in un programma di ricerca biomedica o sanitaria previsto ai sensi dell'articolo 12-bis del decreto legislativo 30 dicembre 1992, n. 502, ed e' condotta e resa pubblica una valutazione d'impatto ai sensi degli articoli 35 e 36 del Regolamento. Il consenso non e' inoltre necessario quando, a causa di particolari ragioni, informare gli interessati risulta impossibile o implica uno sforzo sproporzionato, oppure rischia di rendere impossibile o di pregiudicare gravemente il conseguimento delle finalita' della ricerca. In tali casi, il titolare del trattamento adotta misure appropriate per tutelare i diritti, le liberta' e i legittimi interessi dell'interessato, il programma di ricerca e' oggetto di motivato parere favorevole del competente comitato etico a livello territoriale ((. Nei casi di cui al presente comma, il Garante individua le garanzie da osservare ai sensi dell'articolo 106, comma 2, lettera d), del presente codice)).

2. In caso di esercizio dei diritti dell'interessato ai sensi dell'articolo 16 del regolamento nei riguardi dei trattamenti di cui al comma 1, la rettificazione e l'integrazione dei dati sono annotati senza modificare questi ultimi, quando il risultato di tali operazioni non produce effetti significativi sul risultato della ricerca.

### Art. 110-bis. - (( (Trattamento ulteriore da parte di terzi dei dati personali a fini di ricerca scientifica o a fini statistici). ))

((

1. Il Garante puo' autorizzare il trattamento ulteriore di dati personali, compresi quelli dei trattamenti speciali di cui all'articolo 9 del Regolamento, a fini di ricerca scientifica o a fini statistici da parte di soggetti terzi che svolgano principalmente tali attivita' quando, a causa di particolari ragioni, informare gli interessati risulta impossibile o implica uno sforzo sproporzionato, oppure rischia di rendere impossibile o di pregiudicare gravemente il conseguimento delle finalita' della ricerca, a condizione che siano adottate misure appropriate per tutelare i diritti, le liberta' e i legittimi interessi dell'interessato, in conformita' all'articolo 89 del Regolamento, comprese forme preventive di minimizzazione e di anonimizzazione dei dati.

2. Il Garante comunica la decisione adottata sulla richiesta di autorizzazione entro quarantacinque giorni, decorsi i quali la mancata pronuncia equivale a rigetto. Con il provvedimento di autorizzazione o anche successivamente, sulla base di eventuali verifiche, il Garante stabilisce le condizioni e le misure necessarie ad assicurare adeguate garanzie a tutela degli interessati nell'ambito del trattamento ulteriore dei dati personali da parte di terzi, anche sotto il profilo della loro sicurezza.

3. Il trattamento ulteriore di dati personali da parte di terzi per le finalita' di cui al presente articolo puo' essere autorizzato dal Garante anche mediante provvedimenti generali, adottati d'ufficio e anche in relazione a determinate categorie di titolari e di trattamenti, con i quali sono stabilite le condizioni dell'ulteriore trattamento e prescritte le misure necessarie per assicurare adeguate garanzie a tutela degli interessati. I provvedimenti adottati a norma del presente comma sono pubblicati nella Gazzetta Ufficiale della Repubblica italiana.

4. Non costituisce trattamento ulteriore da parte di terzi il trattamento dei dati personali raccolti per l'attivita' clinica, a fini di ricerca, da parte degli Istituti di ricovero e cura a carattere scientifico, pubblici e privati, in ragione del carattere strumentale dell'attivita' di assistenza sanitaria svolta dai predetti istituti rispetto alla ricerca, nell'osservanza di quanto previsto dall'articolo 89 del Regolamento.

))

## TITOLO VIII ((TRATTAMENTI NELL'AMBITO DEL RAPPORTO DI LAVORO)) CAPO I PROFILI GENERALI

### Art. 111. - (( (Regole deontologiche per trattamenti nell'ambito del rapporto di lavoro). ))

((

1. Il Garante promuove, ai sensi dell'articolo 2-quater, l'adozione di regole deontologiche per i soggetti pubblici e privati interessati al trattamento dei dati personali effettuato nell'ambito del rapporto di lavoro per le finalita' di cui all'articolo 88 del Regolamento, prevedendo anche specifiche modalita' per le informazioni da rendere all'interessato.

))

### Art. 111-bis. - (( (Informazioni in caso di ricezione di curriculum). ))

((

1. Le informazioni di cui all'articolo 13 del Regolamento, nei casi di ricezione dei curricula spontaneamente trasmessi dagli interessati al fine della instaurazione di un rapporto di lavoro, vengono fornite al momento del primo contatto utile, successivo all'invio del curriculum medesimo. Nei limiti delle finalita' di cui all'articolo 6, paragrafo 1, lettera b), del Regolamento, il consenso al trattamento dei dati personali presenti nei curricula non e' dovuto.

))

### Art. 112.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO II - ((TRATTAMENTO DI DATI RIGUARDANTI I PRESTATORI DI LAVORO))

### Art. 113. - (Raccolta di dati e pertinenza)

1. Resta fermo quanto disposto dall'articolo 8 della legge 20 maggio 1970, n. 300 ((, nonche' dall'articolo 10 del decreto legislativo 10 settembre 2003, n. 276.)).

## CAPO III - ((CONTROLLO A DISTANZA, LAVORO AGILE E TELELAVORO))

### Art. 114. - (( (Garanzie in materia di controllo a distanza) ))

1. Resta fermo quanto disposto dall'articolo 4 della legge 20 maggio 1970, n. 300.

### Art. 115. - (( (Telelavoro, lavoro agile e lavoro domestico) ))

1. Nell'ambito del rapporto di lavoro domestico ((del telelavoro e del lavoro agile)) il datore di lavoro e' tenuto a garantire al lavoratore il rispetto della sua personalita' e della sua liberta' morale.

2. Il lavoratore domestico e' tenuto a mantenere la necessaria riservatezza per tutto quanto si riferisce alla vita familiare.

## CAPO IV - ISTITUTI DI PATRONATO E DI ASSISTENZA SOCIALE

### Art. 116. - (Conoscibilita' di dati su mandato dell'interessato)

1. Per lo svolgimento delle proprie attivita' gli istituti di patronato e di assistenza sociale, nell'ambito del mandato conferito dall'interessato, possono accedere alle banche di dati degli enti eroganti le prestazioni, in relazione a tipi di dati individuati specificamente con il consenso manifestato ((dall'interessato medesimo)).

2. Il Ministro del lavoro e delle politiche sociali stabilisce con proprio decreto le linee-guida di apposite convenzioni da stipulare tra gli istituti di patronato e di assistenza sociale e gli enti eroganti le prestazioni.

## TITOLO IX ((ALTRI TRATTAMENTI IN AMBITO PUBBLICO O DI INTERESSE PUBBLICO)) CAPO I ((ASSICURAZIONI))

### Art. 117.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 118.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 119.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 120. - Sinistri

1. L'Istituto per la vigilanza sulle assicurazioni ((...)) definisce con proprio provvedimento le procedure e le modalita' di funzionamento della banca di dati dei sinistri istituita per la prevenzione e il contrasto di comportamenti fraudolenti nel settore delle assicurazioni obbligatorie per i veicoli a motore immatricolati in Italia, stabilisce le modalita' di accesso alle informazioni raccolte dalla banca dati per gli organi giudiziari e per le pubbliche amministrazioni competenti in materia di prevenzione e contrasto di comportamenti fraudolenti nel settore delle assicurazioni obbligatorie, nonche' le modalita' e i limiti per l'accesso alle informazioni da parte delle imprese di assicurazione.

2. Il trattamento e la comunicazione ai soggetti di cui al comma 1 dei dati personali sono consentiti per lo svolgimento delle funzioni indicate nel medesimo comma.

3. Per quanto non previsto dal presente articolo si applicano le disposizioni dall'articolo 135 del codice delle assicurazioni private ((di cui al decreto legislativo 7 settembre 2005, n. 209)).

## TITOLO X COMUNICAZIONI ELETTRONICHE CAPO I SERVIZI DI COMUNICAZIONE ELETTRONICA

### Art. 121. - (( (Servizi interessati e definizioni) ))

1. Le disposizioni del presente titolo si applicano al trattamento dei dati personali connesso alla fornitura di servizi di comunicazione elettronica accessibili al pubblico su reti pubbliche di comunicazioni, comprese quelle che supportano i dispositivi di raccolta dei dati e di identificazione.

((

1-bis. Ai fini dell'applicazione delle disposizioni del presente titolo si intende per:

- a) «comunicazione elettronica», ogni informazione scambiata o trasmessa tra un numero finito di soggetti tramite un servizio di comunicazione elettronica accessibile al pubblico. Sono escluse le informazioni trasmesse al pubblico tramite una rete di comunicazione elettronica, come parte di un servizio di radiodiffusione, salvo che le stesse informazioni siano collegate ad uncontraente o utente ricevente, identificato o identificabile;
- b) «chiamata», la connessione istituita da un servizio di comunicazione elettronica accessibil e al pubblico che consente la comunicazione bidirezionale;
- c) «reti di comunicazione elettronica», i sistemi di trasmissione e, se del caso, le apparecchiature di commutazione o di instradamento e altre risorse, inclusi gli elementi di rete non attivi, che consentono di trasmettere segnali via cavo, via radio, a mezzo di fibre ottiche o con altri mezzi elettromagnetici, comprese le reti satellitari, le reti terrestri mobili e fisse a commutazione di circuito e a commutazione di pacchetto, compresa Internet, le reti utilizzate per la diffusione circolare dei programmi sonori e televisivi, i sistemi per il trasporto della corrente elettrica, nella misura in cui siano utilizzati per trasmettere i segnali, le reti televisive via cavo, indipendentemente dal tipo di informazione trasportato;
- d) «rete pubblica di comunicazioni», una rete di comunicazione elettronica utilizzata interamente o prevalentemente per fornire servizi di comunicazione elettronica accessibili al pubblico, che supporta il trasferimento di informazioni tra i punti terminali di reti;
- e) «servizio di comunicazione elettronica», i servizi consistenti esclusivamente o prevalentemente nella trasmissione di segnali su reti di comunicazioni elettroniche, compresi i servizi di telecomunicazioni e i servizi di trasmissione nelle reti utilizzate per la diffusione circolare radiotelevisiva, nei limiti previsti dall'articolo 2, lettera c), della direttiva 2002/21/CE del Parlamento europeo e del Consiglio, del 7 marzo 2002;
- f) «contraente», qualunque persona fisica, persona giuridica, ente o associazione parte di un contratto con un fornitore di servizi di comunicazione elettronica accessibili al pubblico per la fornitura di tali servizi, o comunque destinatario di tali servizi tramite schede prepagate;
- g) «utente», qualsiasi persona fisica che utilizza un servizio di comunicazione elettronica accessibile al pubblico, per motivi privati o commerciali, senza esservi necessariamente abbonata;
- h) «dati relativi al traffico», qualsiasi dato sottoposto a trattamento ai fini della trasmissione di una comunicazione su una rete di comunicazione elettronica o della relativa fatturazione;
- i) «dati relativi all'ubicazione», ogni dato trattato in una rete di comunicazione elettronica o da un servizio di comunicazione elettronica che indica la posizione geografica dell'apparecchiatura terminale dell'utente di un servizio di comunicazione elettronica accessibile al pubblico;
- l) «servizio a valore aggiunto», il servizio che richiede il trattamento dei dati relativi al traffico o dei dati relativi all'ubicazione diversi dai dati relativi al traffico, oltre a quanto e' necessario per la trasmissione di una comunicazione o della relativa fatturazione;
- m) «posta elettronica», messaggi contenenti testi, voci, suoni o immagini trasmessi attraverso una rete pubblica di comunicazione, che possono essere archiviati in rete o nell'apparecchiatura terminale ricevente, fino a che il ricevente non ne ha preso conoscenza.

))

### Art. 122.

(Informazioni raccolte nei riguardi dell'contraente o dell'utente)

1. L'archiviazione delle informazioni nell'apparecchio terminale di un contraente o di un utente o l'accesso a informazioni gia' archiviate sono consentiti unicamente a condizione che il contraente o l'utente abbia espresso il proprio consenso dopo essere stato informato con ((...)) modalita' semplificate ((...)). Cio' non vieta l'eventuale archiviazione tecnica o l'accesso alle informazioni gia' archiviate se finalizzati unicamente ad effettuare la trasmissione di una comunicazione su una rete di comunicazione elettronica, o nella misura strettamente necessaria al fornitore di un servizio della societa' dell'informazione esplicitamente richiesto dal contraente o dall'utente a erogare tale servizio. Ai fini della determinazione delle modalita' semplificate di cui al primo periodo il Garante tiene anche conto delle proposte formulate dalle associazioni maggiormente rappresentative a livello nazionale dei consumatori e delle categorie economiche coinvolte, anche allo scopo di garantire l'utilizzo di metodologie che assicurino l'effettiva consapevolezza del contraente o dell'utente.

2. Ai fini dell'espressione del consenso di cui al comma 1, possono essere utilizzate specifiche configurazioni di programmi informatici o di dispositivi che siano di facile e chiara utilizzabilita' per il contraente o l'utente.

2-bis. Salvo quanto previsto dal comma 1, e' vietato l'uso di una rete di comunicazione elettronica per accedere a informazioni archiviate nell'apparecchio terminale di un contraente o di un utente, per archiviare informazioni o per monitorare le operazioni dell'utente.

### Art. 123. - (Dati relativi al traffico)

1. I dati relativi al traffico riguardanti abbonati ed utenti trattati dal fornitore di una rete pubblica di comunicazioni o di un servizio di comunicazione elettronica accessibile al pubblico sono cancellati o resi anonimi quando non sono piu' necessari ai fini della trasmissione della comunicazione elettronica, fatte salve le disposizioni dei commi 2, 3 e 5.

2. Il trattamento dei dati relativi al traffico strettamente necessari a fini di fatturazione per l'contraente, ovvero di pagamenti in caso di interconnessione, e' consentito al fornitore, a fini di documentazione in caso di contestazione della fattura o per la pretesa del pagamento, per un periodo non superiore a sei mesi, salva l'ulteriore specifica conservazione necessaria per effetto di una contestazione anche in sede giudiziale.

3. Il fornitore di un servizio di comunicazione elettronica accessibile al pubblico puo' trattare i dati di cui al comma 2 nella misura e per la durata necessarie a fini di commercializzazione di servizi di comunicazione elettronica o per la fornitura di servizi a valore aggiunto, solo se l'contraente o l'utente cui i dati si riferiscono hanno manifestato preliminarmente il proprio consenso, che e' revocabile in ogni momento.

4. Nel fornire ((le informazioni di cui agli articoli 13 e 14 del Regolamento)) il fornitore del servizio informa l'contraente o l'utente sulla natura dei dati relativi al traffico che sono sottoposti a trattamento e sulla durata del medesimo trattamento ai fini di cui ai commi 2 e 3.

5. Il trattamento dei dati personali relativi al traffico e' consentito unicamente ((a persone che, ai sensi dell'articolo 2-quaterdecies, risultano autorizzate al trattamento e che operano)) sotto la diretta autorita' del fornitore del servizio di comunicazione elettronica accessibile al pubblico o, a seconda dei casi, del fornitore della rete pubblica di comunicazioni e che si occupano della fatturazione o della gestione del traffico, di analisi per canto di clienti, dell'accertamento di frodi, o della commercializzazione dei servizi di comunicazione elettronica o della prestazione dei servizi a valore aggiunto. Il trattamento e' limitato a quanto e' strettamente necessario per lo svolgimento di tali attivita' e deve assicurare l'identificazione ((della persona autorizzata)) che accede ai dati anche mediante un'operazione di interrogazione automatizzata.

6. L'Autorita' per le garanzie nelle comunicazioni puo' ottenere i dati relativi alla fatturazione o al traffico necessari ai fini della risoluzione di controversie attinenti, in particolare, all'interconnessione o alla fatturazione.

### Art. 124. - (Fatturazione dettagliata)

1. L'((contraente)) ha diritto di ricevere in dettaglio, a richiesta e senza alcun aggravio di spesa, la dimostrazione degli elementi che compongono la fattura relativi, in particolare, alla data e all'ora di inizio della conversazione, al numero selezionato, al tipo di numerazione, alla localita', alla durata e al numero di scatti addebitati per ciascuna conversazione.

2. Il fornitore del servizio di comunicazione elettronica accessibile al pubblico e' tenuto ad abilitare l'utente ad effettuare comunicazioni e a richiedere servizi da qualsiasi terminale, gratuitamente ed in modo agevole, avvalendosi per il pagamento di modalita' alternative alla fatturazione, anche impersonali, quali carte di credito o di debito o carte prepagate.

3. Nella documentazione inviata all'((contraente)) relativa alle comunicazioni effettuate non sono evidenziati i servizi e le comunicazioni di cui al comma 2, ne' le comunicazioni necessarie per attivare le modalita' alternative alla fatturazione.

4. Nella fatturazione all'((contraente)) non sono evidenziate le ultime tre cifre dei numeri chiamati. Ad esclusivi fini di specifica contestazione dell'esattezza di addebiti determinati o riferiti a periodi limitati, l'((contraente)) puo' richiedere la comunicazione dei numeri completi delle comunicazioni in questione.

5. Il Garante, accertata l'effettiva disponibilita' delle modalita' di cui al comma 2, puo' autorizzare il fornitore ad indicare nella fatturazione i numeri completi delle comunicazioni.

### Art. 125. - (Identificazione della linea)

1. Se e' disponibile la presentazione dell'identificazione della linea chiamante, il fornitore del servizio di comunicazione elettronica accessibile al pubblico assicura all'utente chiamante la possibilita' di impedire, gratuitamente e mediante una funzione semplice, la presentazione dell'identificazione della linea chiamante, chiamata per chiamata. L'contraente chiamante deve avere tale possibilita' linea per linea. ((Rimane in ogni caso fermo quanto previsto dall'articolo 2, comma 1, della legge 11 gennaio 2018, n. 5.))

2. Se e' disponibile la presentazione dell'identificazione della linea chiamante, il fornitore del servizio di comunicazione elettronica accessibile al pubblico assicura all'contraente chiamato la possibilita' di impedire, gratuitamente e mediante una funzione semplice, la presentazione dell'identificazione delle chiamate entranti.

3. Se e' disponibile la presentazione dell'identificazione della linea chiamante e tale indicazione avviene prima che la comunicazione sia stabilita, il fornitore del servizio di comunicazione elettronica accessibile al pubblico assicura all'contraente chiamato la possibilita', mediante una funzione semplice e gratuita, di respingere le chiamate entranti se la presentazione dell'identificazione della linea chiamante e' stata eliminata dall'utente o contraente chiamante.

4. Se e' disponibile la presentazione dell'identificazione della linea collegata, il fornitore del servizio di comunicazione elettronica accessibile al pubblico assicura all'contraente chiamato la possibilita' di impedire, gratuitamente e mediante una funzione semplice, la presentazione dell'identificazione della linea collegata all'utente chiamante.

5. Le disposizioni di cui al comma 1 si applicano anche alle chiamate dirette verso Paesi non appartenenti all'unione europea. Le disposizioni di cui ai commi 2, 3 e 4 si applicano anche alle chiamate provenienti da tali Paesi.

6. Se e' disponibile la presentazione dell'identificazione della linea chiamante o di quella collegata, il fornitore del servizio di comunicazione elettronica accessibile al pubblico informa gli abbonati e gli utenti dell'esistenza di tale servizio e delle possibilita' previste ai commi 1, 2, 3 e 4.

### Art. 126. - (Dati relativi all'ubicazione)

1. I dati relativi all'ubicazione diversi dai dati relativi al traffico, riferiti agli utenti o agli abbonati di reti pubbliche di comunicazione o di servizi di comunicazione elettronica accessibili al pubblico, possono essere trattati solo se anonimi o se l'utente o l'contraente ha manifestato previamente il proprio consenso, revocabile in ogni momento, e nella misura e per la durata necessari per la fornitura del servizio a valore aggiunto richiesto.

2. Il fornitore del servizio, prima di richiedere il consenso, informa gli utenti e gli abbonati sulla natura dei dati relativi all'ubicazione diversi dai dati relativi al traffico che saranno sottoposti al trattamento, sugli scopi e sulla durata di quest'ultimo, nonche' sull'eventualita' che i dati siano trasmessi ad un terzo per la prestazione del servizio a valore aggiunto.

3. L'utente e l'contraente che manifestano il proprio consenso al trattamento dei dati relativi all'ubicazione, diversi dai dati relativi al traffico, conservano il diritto di richiedere, gratuitamente e mediante una funzione semplice, l'interruzione temporanea del trattamento di tali dati per ciascun collegamento alla rete o per ciascuna trasmissione di comunicazioni.

4. Il trattamento dei dati relativi all'ubicazione diversi dai dati relativi al traffico, ai sensi dei commi 1 , 2 e 3, e' consentito unicamente ((a persone autorizzate al trattamento, ai sensi dell'articolo 2-quaterdecies, che operano)) sono la diretta autorita' del fornitore del servizio di comunicazione elettronica accessibile al pubblico o, a seconda dei casi, del fornitore della rete pubblica di comunicazioni o del terzo che fornisce il servizio a valore aggiunto. Il trattamento e' limitato a quanto e' strettamente necessario per la fornitura del servizio a valore aggiunto e deve assicurare l'identificazione ((della persona autorizzata)) che accede ai dati anche mediante un'operazione di interrogazione automatizzata.

### Art. 127. - (Chiamate di disturbo e di emergenza)

1. L'((contraente)) che riceve chiamate di disturbo puo' richiedere che il fornitore della rete pubblica di comunicazioni o del servizio di comunicazione elettronica accessibile al pubblico renda temporaneamente inefficace la soppressione della presentazione dell'identificazione della linea chiamante e conservi i dati relativi alla provenienza della chiamata ricevuta. L'inefficacia della soppressione puo' essere disposta per i soli orari durante i quali si verificano le chiamate di disturbo e per un periodo non superiore a quindici giorni.

2. La richiesta formulata per iscritto dall'((contraente)) specifica le modalita' di ricezione delle chiamate di disturbo e nel caso in cui sia preceduta da una richiesta telefonica e' inoltrata entro quarantotto ore.

3. I dati conservati ai sensi del comma 1 possono essere comunicati all'((contraente)) che dichiari di utilizzarli per esclusive finalita' di tutela rispetto a chiamate di disturbo. Per i servizi di cui al comma 1 il fornitore assicura procedure trasparenti nei confronti degli abbonati e puo' richiedere un contributo spese non superiore ai costi effettivamente sopportati.

4. Il fornitore di una rete pubblica di comunicazioni o di un servizio di comunicazione elettronica accessibile al pubblico predispone procedure trasparenti per garantire, linea per linea, l'inefficacia della soppressione dell'identificazione della linea chiamante, nonche', ove necessario, il trattamento dei dati relativi all'ubicazione, nonostante il rifiuto o il mancato consenso temporanei dell'((contraente)) o dell'utente, da parte dei servizi abilitati in base alla legge a ricevere chiamate d'emergenza. I servizi sono individuati con decreto del Ministro delle comunicazioni, sentiti il Garante e l'Autorita' per le garanzie nelle comunicazioni.

### Art. 128. - (Trasferimento automatico della chiamata)

1. Il fornitore di un servizio di comunicazione elettronica accessibile al pubblico adotta le misure necessarie per consentire a ciascun ((contraente)), gratuitamente e mediante una funzione semplice, di poter bloccare il trasferimento automatico delle chiamate verso il proprio terminale effettuato da terzi.

### Art. 129. - (( (Elenchi dei contraenti) ))

((

1. Il Garante individua con proprio provvedimento, in cooperazione con l'Autorita' per le garanzie nelle comunicazioni ai sensi dell'articolo 154, comma 4, e in conformita' alla normativa dell'Unione europea, le modalita' di inserimento e di successivo utilizzo dei dati personali relativi ai contraenti negli elenchi cartacei o elettronici a disposizione del pubblico.

2. Il provvedimento di cui al comma 1 individua idonee modalita' per la manifestazione del consenso all'inclusione negli elenchi e, rispettivamente, all'utilizzo dei dati per finalita' di invio di materiale pubblicitario o di vendita diretta o per il compimento di ricerche di mercato o di comunicazione commerciale nonche' per le finalita' di cui all'articolo 21, paragrafo 2, del Regolamento, in base al principio della massima semplificazione delle modalita' di inclusione negli elenchi a fini di mera ricerca del contraente per comunicazioni interpersonali, e del consenso specifico ed espresso qualora il trattamento esuli da tali fini, nonche' in tema di verifica, rettifica o cancellazione dei dati senza oneri.

))

### Art. 130. - (Comunicazioni indesiderate)

1. Fermo restando quanto stabilito dagli articoli 8 e 21 del decreto legislativo 9 aprile 2003, n. 70, l'uso di sistemi automatizzati di chiamata o di comunicazione di chiamata senza l'intervento di un operatore per l'invio di materiale pubblicitario o di vendita diretta o per il compimento di ricerche di mercato o di comunicazione commerciale e' consentito con il consenso del contraente o utente. ((Resta in ogni caso fermo quanto previsto dall'articolo 1, comma 14, della legge 11 gennaio 2018, n. 5.))

2. La disposizione di cui al comma 1 si applica anche alle comunicazioni elettroniche, effettuate per le finalita' ivi indicate, mediante posta elettronica, telefax, messaggi del tipo Mms (Multimedia Messaging Service) o Sms (Short Message Service) o di altro tipo.

3. Fuori dei casi di cui ai commi 1 e 2, ulteriori comunicazioni per le finalita' di cui ai medesimi commi effettuate con mezzi diversi da quelli ivi indicati, sono consentite ai sensi degli articoli ((6 e 7 del Regolamento)) nonche' ai sensi di quanto previsto dal comma 3-bis ((...)).

3-bis. In deroga a quanto previsto dall'articolo 129, il trattamento dei dati di cui ((al comma 1 del predetto articolo,)) mediante l'impiego del telefono e della posta cartacea per le finalita' ((di invio di materiale pubblicitario o di vendita diretta o per il compimento di ricerche di mercato o di comunicazione commerciale)), e' consentito nei confronti di chi non abbia esercitato il diritto di opposizione, con modalita' semplificate e anche in via telematica, mediante l'iscrizione della numerazione della quale e' intestatario e degli altri dati personali di cui ((al comma 1 del predetto articolo,)) in un registro pubblico delle opposizioni. (20)

3-ter. Il registro di cui al comma 3-bis e' istituito con decreto del Presidente della Repubblica da adottare ai sensi dell'articolo 17, comma 2, della legge 23 agosto 1988, n. 400, previa deliberazione del Consiglio dei ministri, acquisito il parere del Consiglio di Stato e delle Commissioni parlamentari competenti in materia, che si pronunciano entro trenta giorni dalla richiesta, nonche', per i relativi profili di competenza, il parere dell'Autorita' per le garanzie nelle comunicazioni, che si esprime entro il medesimo termine, secondo i seguenti criteri e principi generali:

- a) attribuzione dell'istituzione e della gestione del registro ad un ente o organismo pubblico titolare di competenze inerenti alla materia;
- b) previsione che l'ente o organismo deputato all'istituzione e alla gestione del registro vi provveda con le risorse umane e strumentali di cui dispone o affidandone la realizzazione e la gestione a terzi, che se ne assumono interamente gli oneri finanziari e organizzativi, mediante contratto di servizio, nel rispetto del ((codice dei contratti pubblici di cui al decreto legislativo 18 aprile 2016, n. 50)). I soggetti che si avvalgono del registro per effettuare le comunicazioni corrispondono tariffe di accesso basate sugli effettivi costi di funzionamento e di manutenzione. Il Ministro dello sviluppo economico, con proprio provvedimento, determina tali tariffe;
- c) previsione che le modalita' tecniche di funzionamento del registro consentano ad ogni utente di chiedere che sia iscritta la numerazione della quale e' intestatario secondo modalita' semplificate ed anche in via telematica o telefonica;
- d) previsione di modalita' tecniche di funzionamento e di accesso al registro mediante interrogazioni selettive che non consentano il trasferimento del dati presenti nel registro stesso, prevedendo il tracciamento delle operazioni compiute e la conservazione dei dati relativi agli accessi;
- e) disciplina delle tempistiche e delle modalita' dell'iscrizione al registro, senza distinzione di settore di attivita' o di categoria merceologica, e del relativo aggiornamento, nonche' del correlativo periodo massimo di utilizzabilita' dei dati verificati nel registro medesimo, prevedendosi che l'iscrizione abbia durata indefinita e sia revocabile in qualunque momento, mediante strumenti di facile utilizzo e gratuitamente; f)obbligo per i soggetti che effettuano trattamenti di dati per le finalita' ((di invio di materiale pubblicitario o di vendita diretta o per il compimento di ricerche di mercato o di comunicazione commerciale)), di garantire la presentazione dell'identificazione della linea chiamante e di fornire all'utente idonee informative, in particolare sulla possibilita' e sulle modalita' di iscrizione nel registro per opporsi a futuri contatti; g) previsione che l'iscrizione nel registro non precluda i trattamenti dei dati altrimenti acquisiti e trattati nel rispetto degli articoli ((6 e 7 del Regolamento)).

3-quater. La vigilanza e il controllo sull'organizzazione e il funzionamento del registro di cui al comma 3-bis e sul trattamento dei dati sono attribuiti al Garante.

4. Fatto salvo quanto previsto nel comma 1 , se il titolare del trattamento utilizza, a fini di vendita diretta di propri prodotti o servizi, le coordinate di posta elettronica fornite dall'interessato nel contesto della vendita di un prodotto o di un servizio, puo' non richiedere il consenso dell'interessato, sempre che si tratti di servizi analoghi a quelli oggetto della vendita e l'interessato, adeguatamente informato, non rifiuti tale uso, inizialmente o in occasione di successive comunicazioni. L'interessato, al momento della raccolta e in occasione dell'invio di ogni comunicazione effettuata per le finalita' di cui al presente comma, e' informato della possibilita' di opporsi in ogni momento al trattamento, in maniera agevole e gratuitamente.

5. E' vietato in ogni caso l'invio di comunicazioni per le finalita' di cui al comma 1 o, comunque, a scopo promozionale, effettuato camuffando o celando l'identita' del mittente o in violazione dell'articolo 8 del decreto legislativo 9 aprile 2003, n. 70, o senza fornire un idoneo recapito presso il quale l'interessato possa esercitare i diritti di cui ((agli articoli da 15 a 22 del Regolamento)), oppure esortando i destinatari a visitare siti web che violino il predetto articolo 8 del decreto legislativo n. 70 del 2003.

6. In caso di reiterata violazione delle disposizioni di cui al presente articolo il Garante puo', provvedendo ai sensi ((dell'articolo 58 del Regolamento)), altresi' prescrivere a fornitori di servizi di comunicazione elettronica di adottare procedure di filtraggio o altre misure praticabili relativamente alle coordinate di posta elettronica da cui sono stati inviate le comunicazioni.

------------- AGGIORNAMENTO (20) Il D.L. 25 settembre 2009, n. 135, convertito con modificazioni dalla L. 20 novembre 2009, n. 166, ha disposto (con l'art. 20-bis comma 2) che il registro previsto dal comma 3-bis del presente articolo, e' istituito entro sei mesi dalla data di entrata in vigore della legge di conversione del suddetto presente decreto. Fino al suddetto termine, restano in vigore i provvedimenti adottati dal Garante per la protezione dei dati personali ai sensi dell'articolo 154 del D.Lgs 196/2003.

### Art. 131. - (( (Informazioni a contraenti e utenti) ))

1. Il fornitore di un servizio di comunicazione elettronica accessibile al pubblico informa l'contraente e, ove possibile, l'utente circa la sussistenza di situazioni che permettono di apprendere in modo non intenzionale il contenuto di comunicazioni o conversazioni da parte di soggetti ad esse estranei.

2. L'contraente informa l'utente quando il contenuto delle comunicazioni o conversazioni puo' essere appreso da altri a causa del tipo di apparecchiature terminali utilizzate o del collegamento realizzato tra le stesse presso la sede dell'contraente medesimo.

3. L'utente informa l'altro utente quando, nel corso della conversazione, sono utilizzati dispositivi che consentono l'ascolto della conversazione stessa da parte di altri soggetti.

### Art. 132. - (Conservazione di dati di traffico per altre finalita').

1. Fermo restando quanto previsto dall'articolo 123, comma 2, i dati relativi al traffico telefonico conservati dal fornitore per ventiquattro mesi dalla data della comunicazione, per finalita' di accertamento e repressione dei reati, mentre, per le medesime finalita', i dati relativi al traffico telematico, esclusi comunque i contenuti delle comunicazioni, sono conservati dal fornitore per dodici mesi dalla data della comunicazione. (31) (32) (33)

1-bis. I dati relativi alle chiamate senza risposta, trattati temporaneamente da parte dei fornitori di servizi di comunicazione elettronica accessibili al pubblico oppure di una rete pubblica di comunicazione, sono conservati per trenta giorni. (15) (17) (33)

2. COMMA ABROGATO DAL D.LGS. 30 MAGGIO 2008, N. 109.

3. Entro il termine di conservazione imposto dalla legge, se sussistono sufficienti indizi di reati per i quali la legge stabilisce la pena dell'ergastolo o della reclusione non inferiore nel massimo a tre anni, determinata a norma dell'articolo 4 del codice di procedura penale, e di reati di minaccia e di molestia o disturbo alle persone col mezzo del telefono, quando la minaccia, la molestia e il disturbo sono gravi, ove rilevanti per l'accertamento dei fatti, i dati sono acquisiti previa autorizzazione rilasciata dal giudice con decreto motivato, su richiesta del pubblico ministero o su istanza del difensore dell'imputato, della persona sottoposta a indagini, della persona offesa e delle altre parti private.

3-bis. Quando ricorrono ragioni di urgenza e vi e' fondato motivo di ritenere che dal ritardo possa derivare grave pregiudizio alle indagini, il pubblico ministero dispone la acquisizione dei dati con decreto motivato che e' comunicato immediatamente, e comunque non oltre quarantotto ore, al giudice competente per il rilascio dell'autorizzazione in via ordinaria. Il giudice, nelle quarantotto ore successive, decide sulla convalida con decreto motivato. PERIODO SOPPRESSO DAL D.L. 30 SETTEMBRE 2021, N. 132, CONVERTITO CON MODIFICAZIONI DALLA L. 23 NOVEMBRE 2021, N. 178.

3-ter. Rispetto ai dati conservati per le finalita' indicate al comma 1 i diritti di cui agli articoli da 12 a 22 del Regolamento possono essere esercitati con le modalita' di cui all'articolo 2-undecies, comma 3, terzo, quarto e quinto periodo.

3-quater. I dati acquisiti in violazione delle disposizioni dei commi 3 e 3-bis non possono essere utilizzati.

4. COMMA ABROGATO DAL D.LGS. 30 MAGGIO 2008, N. 109.

4-bis. COMMA ABROGATO DAL D.LGS. 30 MAGGIO 2008, N. 109.

4-ter. Il Ministro dell'interno o, su sua delega, i responsabili degli uffici centrali specialistici in materia informatica o telematica della Polizia di Stato, dell'Arma dei carabinieri e del Corpo della guardia di finanza, nonche' gli altri soggetti indicati nel comma 1 dell'articolo 226 delle norme di attuazione, di coordinamento e transitorie del codice di procedura penale, di cui al decreto legislativo 28 luglio 1989, n. 271, possono ordinare, anche in relazione alle eventuali richieste avanzate da autorita' investigative straniere, ai fornitori e agli operatori di servizi informatici o telematici di conservare e proteggere, secondo le modalita' indicate e per un periodo non superiore a novanta giorni, i dati relativi al traffico telematico, esclusi comunque i contenuti delle comunicazioni, ai fini dello svolgimento delle investigazioni preventive previste dal citato articolo 226 delle norme di cui al decreto legislativo n. 271 del 1989, ovvero per finalita' di accertamento e repressione di specifici reati. Il provvedimento, prorogabile, per motivate esigenze, per una durata complessiva non superiore a sei mesi, puo' prevedere particolari modalita' di custodia dei dati e l'eventuale indisponibilita' dei dati stessi da parte dei fornitori e degli operatori di servizi informatici o telematici ovvero di terzi.

4-quater. Il fornitore o l'operatore di servizi informatici o telematici cui e' rivolto l'ordine previsto dal comma 4-ter deve ottemperarvi senza ritardo, fornendo immediatamente all'autorita' richiedente l'assicurazione dell'adempimento. Il fornitore o l'operatore di servizi informatici o telematici e' tenuto a mantenere il segreto relativamente all'ordine ricevuto e alle attivita' conseguentemente svolte per il periodo indicato dall'autorita'. In caso di violazione dell'obbligo si applicano, salvo che il fatto costituisca piu' grave reato, le disposizioni dell'articolo 326 del codice penale.

4-quinquies. I provvedimenti adottati ai sensi del comma 4-ter sono comunicati per iscritto, senza ritardo e comunque entro quarantotto ore dalla notifica al destinatario, al pubblico ministero del luogo di esecuzione il quale, se ne ricorrono i presupposti, li convalida. In caso di mancata convalida, i provvedimenti assunti perdono efficacia.

5. Il trattamento dei dati per le finalita' di cui al comma 1 e' effettuato nel rispetto delle misure e degli accorgimenti a garanzia dell'interessato prescritti dal Garante ((con provvedimento di carattere generale)), volti a garantire che i dati conservati possiedano i medesimi requisiti di qualita', sicurezza e protezione dei dati in rete, nonche' ad indicare le modalita' tecniche per la periodica distruzione dei dati, decorsi i termini di cui al comma 1 .

5-bis. E' fatta salva la disciplina di cui all'articolo 24 della legge 20 novembre 2017, n. 167.

--------------- AGGIORNAMENTO (15) Il D.Lgs. 30 maggio 2008, n. 109 ha disposto (con l'art. 6, comma 3) che la disposizione del comma 1-bis del presente articolo, ha effetto decorsi tre mesi dalla data di entrata in vigore del presente D.Lgs. 109/08. --------------- AGGIORNAMENTO (17) Il D.Lgs. 30 maggio 2008, n. 109, come modificato dal D.L. 2 ottobre 2008, n. 151, convertito con modificazioni dalla L. 28 novembre 2008, n. 186, ha disposto (con l'art. 6, comma 3) che la disposizione del comma 1-bis del presente articolo ha effetto a decorrere dal 31 marzo 2009. --------------- AGGIORNAMENTO (31) Il D.L. 18 febbraio 2015, n. 7, convertito, con modificazioni, dalla L. 17 aprile 2015, n. 43, ha disposto (con l'art. 4-bis, comma 1) che "Al fine di poter agevolare le indagini esclusivamente per i reati di cui agli articoli 51, comma 3-quater, e 407, comma 2, lettera a), del codice di procedura penale, in deroga a quanto stabilito dall'articolo 132, comma 1, del codice di cui al decreto legislativo 30 giugno 2003, n. 196, e successive modificazioni, e fermo restando quanto stabilito dall'articolo 123, comma 2, del medesimo codice, i dati relativi al traffico telefonico effettuato a decorrere dalla data di entrata in vigore della legge di conversione del presente decreto sono conservati dal fornitore fino al 31 dicembre 2016 per finalita' di accertamento e repressione dei reati. Per le medesime finalita' i dati relativi al traffico telematico effettuato a decorrere dalla data di entrata in vigore della legge di conversione del presente decreto, esclusi comunque i contenuti della comunicazione, sono conservati dal fornitore fino al 31 dicembre 2016". Ha inoltre disposto (con l'art. 4-bis, comma 3) che la presente modifica cessa di applicarsi a decorrere dal 1° gennaio 2017. --------------- AGGIORNAMENTO (32) Il D.L. 18 febbraio 2015, n. 7, convertito con modificazioni dalla L. 17 aprile 2015, n. 43, come modificato dal D.L. 30 dicembre 2015, n. 210, convertito con modificazioni dalla L. 25 febbraio 2016, n. 21, ha disposto (con l'art. 4-bis, comma 1) che "I dati relativi al traffico telefonico o telematico, esclusi comunque i contenuti di comunicazione, detenuti dagli operatori dei servizi di telecomunicazione alla data di entrata in vigore della legge di conversione del presente decreto, nonche' quelli relativi al traffico telefonico o telematico effettuato successivamente a tale data, sono conservati, in deroga a quanto stabilito dall'articolo 132, comma 1, del codice di cui al decreto legislativo 30 giugno 2003, n. 196, e successive modificazioni, fino al 30 giugno 2017, per le finalita' di accertamento e di repressione dei reati di cui agli articoli 51, comma 3-quater, e 407, comma 2, lettera a), del codice di procedura penale". Ha inoltre disposto (con l'art. 4-bis, comma 3) che "Le disposizioni di cui ai commi 1 e 2 cessano di applicarsi a decorrere dal 1° luglio 2017". --------------- AGGIORNAMENTO (33) La L. 20 novembre 2017, n. 167 ha disposto (con l'art. 24, comma 1) che "In attuazione dell'articolo 20 della direttiva (UE) 2017/541 del Parlamento europeo e del Consiglio, del 15 marzo 2017, sulla lotta contro il terrorismo e che sostituisce la decisione quadro 2002/475/GAI del Consiglio, al fine di garantire strumenti di indagine efficace in considerazione delle straordinarie esigenze di contrasto del terrorismo, anche internazionale, per le finalita' dell'accertamento e della repressione dei reati di cui agli articoli 51, comma 3-quater, e 407, comma 2, lettera a), del codice di procedura penale il termine di conservazione dei dati di traffico telefonico e telematico nonche' dei dati relativi alle chiamate senza risposta, di cui all'articolo 4-bis, commi 1 e 2, del decreto-legge 18 febbraio 2015, n. 7, convertito, con modificazioni, dalla legge 17 aprile 2015, n. 43, e' stabilito in settantadue mesi, in deroga a quanto previsto dall'articolo 132, commi 1 e 1-bis, del codice in materia di protezione dei dati personali, di cui al decreto legislativo 30 giugno 2003, n. 196".

### Art. 132-bis. - (( (Procedure istituite dai fornitori) ))

((

1. I fornitori istituiscono procedure interne per corrispondere alle richieste effettuate in conformita' alle disposizioni che prevedono forme di accesso a dati personali degli utenti.

2. A richiesta, i fornitori forniscono al Garante, per i profili di competenza, informazioni sulle procedure di cui al comma 1, sul numero di richieste ricevute, sui motivi legali addotti e sulle risposte date.

))

### Art. 132-ter. - (( (Sicurezza del trattamento) ))

((

1. Nel rispetto di quanto disposto dall'articolo 32 del Regolamento, ai fornitori di servizi di comunicazione elettronica accessibili al pubblico si applicano le disposizioni del presente articolo. 2.Il fornitore di un servizio di comunicazione elettronica accessibile al pubblico adotta, ai sensi dell'articolo 32 del Regolamento, anche attraverso altri soggetti a cui sia affidata l'erogazione del servizio, misure tecniche e organizzative adeguate al rischio esistente. 3. I soggetti che operano sulle reti di comunicazione elettronica garantiscono che i dati personali siano accessibili soltanto al personale autorizzato per fini legalmente autorizzati. 4. Le misure di cui ai commi 2 e 3 garantiscono la protezione dei dati relativi al traffico ed all'ubicazione e degli altri dati personali archiviati o trasmessi dalla distruzione anche accidentale, da perdita o alterazione anche accidentale e da archiviazione, trattamento, accesso o divulgazione non autorizzati o illeciti, nonche' garantiscono l'attuazione di una politica di sicurezza. 5. Quando la sicurezza del servizio o dei dati personali richiede anche l'adozione di misure che riguardano la rete, il fornitore del servizio di comunicazione elettronica accessibile al pubblico adotta tali misure congiuntamente con il fornitore della rete pubblica di comunicazioni. In caso di mancato accordo, su richiesta di uno dei fornitori, la controversia e' definita dall'Autorita' per le garanzie nelle comunicazioni secondo le modalita' previste dalla normativa vigente.

))

### Art. 132-quater. - (( (Informazioni sui rischi) ))

((

1. Il fornitore di un servizio di comunicazione elettronica accessibile al pubblico informa gli abbonati e, ove possibile, gli utenti, mediante linguaggio chiaro, idoneo e adeguato rispetto alla categoria e alla fascia di eta' dell'interessato a cui siano fornite le suddette informazioni, con particolare attenzione in caso di minori di eta', se sussiste un particolare rischio di violazione della sicurezza della rete, indicando, quando il rischio e' al di fuori dell'ambito di applicazione delle misure che il fornitore stesso e' tenuto ad adottare a norma dell'articolo 132-ter, commi 2, 3 e 5, tutti i possibili rimedi e i relativi costi presumibili. Analoghe informazioni sono rese al Garante e all'Autorita' per le garanzie nelle comunicazioni.

))

## CAPO II - INTERNET E RETI TELEMATICHE <br> ((CAPO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 133.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO III - VIDEOSORVEGLIANZA <br> ((CAPO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 134.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## TITOLO XI LIBERE PROFESSIONI E INVESTIGAZIONE PRIVATA <br> ((TITOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 135.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## TITOLO XII ((GIORNALISMO, LIBERTA' DI INFORMAZIONE E DI ESPRESSIONE)) CAPO I PROFILI GENERALI

### Art. 136. - (Finalita' giornalistiche e altre manifestazioni del pensiero)

1. Le disposizioni del presente titolo si applicano ((, ai sensi dell'articolo 85 del Regolamento,)) al trattamento:

- a) effettuato nell'esercizio della professione di giornalista e per l'esclusivo perseguimento delle relative finalita';
- b) effettuato dai soggetti iscritti nell'elenco dei pubblicisti o nel registro dei praticanti di cui agli articoli 26 e 33 della legge 3 febbraio 1963, n. 69;
- c) ((...)) finalizzato esclusivamente alla pubblicazione o diffusione ((anche)) occasionale di articoli, saggi e altre manifestazioni del pensiero anche ((nell'espressione accademica, artistica e letteraria.)).

### Art. 137. - (Disposizioni applicabili)

1. Con riferimento a quanto previsto dall'articolo 136, possono essere trattati i dati di cui agli articoli 9 e 10 del Regolamento anche senza il consenso dell'interessato, purche' nel rispetto delle regole deontologiche di cui all'articolo 139.

2. Ai trattamenti indicati nell'articolo 136 non si applicano le disposizioni relative:

- a) alle misure di garanzia di cui all'articolo 2-septies ((...));
- b) al trasferimento dei dati verso paesi terzi o organizzazioni internazionali, contenute nel Capo V del Regolamento.

3. In caso di diffusione o di comunicazione dei dati per le finalita' di cui all'articolo 136 restano fermi i limiti del diritto di cronaca a tutela dei diritti di cui all'articolo 1, paragrafo 2, del Regolamento e all'articolo 1 del presente codice e, in particolare, quello dell'essenzialita' dell'informazione riguardo a fatti di interesse pubblico. Possono essere trattati i dati personali relativi a circostanze o fatti resi noti direttamente dagli interessati o attraverso loro comportamenti in pubblico.

### Art. 138. - (Segreto professionale)

1. In caso di richiesta dell'interessato di conoscere l'origine dei dati personali ai sensi ((dell'articolo 15, paragrafo 1, lettera g), del Regolamento)) restano ferme le norme sul segreto professionale degli esercenti la professione di giornalista, limitatamente alla fonte della notizia.

## CAPO II - ((REGOLE DEONTOLOGICHE RELATIVE AD ATTIVITA' GIORNALISTICHE E AD ALTRE MANIFESTAZIONI DEL PENSIERO))

### Art. 139. - (( (Regole deontologiche relative ad attivita' giornalistiche) ))

((

.

1. Il Garante promuove, ai sensi dell'articolo 2-quater, l'adozione da parte del Consiglio nazionale dell'ordine dei giornalisti di regole deontologiche relative al trattamento dei dati di cui all'articolo 136, che prevedono misure ed accorgimenti a garanzia degli interessati rapportate alla natura dei dati, in particolare per quanto riguarda quelli relativi alla salute e alla vita o all'orientamento sessuale. Le regole possono anche prevedere forme particolari per le informazioni di cui agli articoli 13 e 14 del Regolamento.

2. Le regole deontologiche o le modificazioni od integrazioni alle stesse che non sono adottate dal Consiglio entro sei mesi dalla proposta del Garante sono adottate in via sostitutiva dal Garante e sono efficaci sino a quando diviene efficace una diversa disciplina secondo la procedura di cooperazione.

3. Le regole deontologiche e le disposizioni di modificazione ed integrazione divengono efficaci quindici giorni dopo la loro pubblicazione nella Gazzetta Ufficiale della Repubblica italiana ai sensi dell'articolo 2-quater.

4. In caso di violazione delle prescrizioni contenute nelle regole deontologiche, il Garante puo' vietare il trattamento ai sensi dell'articolo 58 del Regolamento.

5. Il Garante, in cooperazione con il Consiglio nazionale dell'ordine dei giornalisti, prescrive eventuali misure e accorgimenti a garanzia degli interessati, che il Consiglio e' tenuto a recepire.

))

## TITOLO XIII MARKETING DIRETTO <br> ((TITOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 140.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## TUTELA DELL'INTERESSATO E SANZIONI - - TITOLO I TUTELA AMMINISTRATIVA E GIURISDIZIONALE (( CAPO 0.I (ALTERNATIVITA' DELLE FORME DI TUTELA) ))

### Art. 140-bis. - (( (Forme alternative di tutela) ))

((

.

1. Qualora ritenga che i diritti di cui gode sulla base della normativa in materia di protezione dei dati personali siano stati violati, l'interessato puo' proporre reclamo al Garante o ricorso dinanzi all'autorita' giudiziaria.

2. Il reclamo al Garante non puo' essere proposto se, per il medesimo oggetto e tra le stesse parti, e' stata gia' adita l'autorita' giudiziaria.

3. La presentazione del reclamo al Garante rende improponibile un'ulteriore domanda dinanzi all'autorita' giudiziaria tra le stesse parti e per il medesimo oggetto, salvo quanto previsto dall'articolo 10, comma 4, del decreto legislativo 1° settembre 2011, n. 150.

))

## CAPO I - TUTELA DINANZI AL GARANTE ((...))

### Art. 141. - (( (Reclamo al Garante) ))

((

.

1. L'interessato puo' rivolgersi al Garante mediante reclamo ai sensi dell'articolo 77 del Regolamento.

))

## ((...))

### Art. 142. - (( (Proposizione del reclamo) ))

((

.

1. Il reclamo contiene un'indicazione per quanto possibile dettagliata dei fatti e delle circostanze su cui si fonda, delle disposizioni che si presumono violate e delle misure richieste, nonche' gli estremi identificativi del titolare o del responsabile del trattamento, ove conosciuto.

2. Il reclamo e' sottoscritto dall'interessato o, su mandato di questo, da un ente del terzo settore soggetto alla disciplina del decreto legislativo 3 luglio 2017, n. 117, che sia attivo nel settore della tutela dei diritti e delle liberta' degli interessati, con riguardo alla protezione dei dati personali.

3. Il reclamo reca in allegato la documentazione utile ai fini della sua valutazione e l'eventuale mandato, e indica un recapito per l'invio di comunicazioni anche tramite posta elettronica, telefax o telefono.

4. Il Garante predispone un modello per il reclamo, da pubblicare nel proprio sito istituzionale, di cui favorisce la disponibilita' con strumenti elettronici.

5. Il Garante disciplina con proprio regolamento il procedimento relativo all'esame dei reclami, nonche' modalita' semplificate e termini abbreviati per la trattazione di reclami che abbiano ad oggetto la violazione degli articoli da 15 a 22 del Regolamento.

))

### Art. 143. - (( (Decisione del reclamo) ))

((

.

1. Esaurita l'istruttoria preliminare, se il reclamo non e' manifestamente infondato e sussistono i presupposti per adottare un provvedimento, il Garante, anche prima della definizione del procedimento puo' adottare i provvedimenti di cui all'articolo 58 del Regolamento nel rispetto delle disposizioni di cui all'articolo 56 dello stesso.

2. I provvedimenti di cui al comma 1 sono pubblicati nella Gazzetta Ufficiale della Repubblica italiana se i relativi destinatari non sono facilmente identificabili per il numero o per la complessita' degli accertamenti.

3. Il Garante decide il reclamo entro nove mesi dalla data di presentazione e, in ogni caso, entro tre mesi dalla predetta data informa l'interessato sullo stato del procedimento. In presenza di motivate esigenze istruttorie, che il Garante comunica all'interessato, il reclamo e' deciso entro dodici mesi. In caso di attivazione del procedimento di cooperazione di cui all'articolo 60 del Regolamento, il termine rimane sospeso per la durata del predetto procedimento.

4. Avverso la decisione e' ammesso ricorso giurisdizionale ai sensi dell'articolo 152.

))

### Art. 144. - (( (Segnalazioni) ))

((

.

1. Chiunque puo' rivolgere una segnalazione che il Garante puo' valutare anche ai fini dell'emanazione dei provvedimenti di cui all'articolo 58 del Regolamento.

2. I provvedimenti del Garante di cui all'articolo 58 del Regolamento possono essere adottati anche d'ufficio.

))

### Art. 144-bis. - (( (Revenge porn). ))

((

1. Chiunque, compresi i minori ultraquattordicenni, abbia fondato motivo di ritenere che registrazioni audio, immagini o video o altri documenti informatici a contenuto sessualmente esplicito che lo riguardano, destinati a rimanere privati, possano essere oggetto di invio, consegna, cessione, pubblicazione o diffusione attraverso piattaforme digitali senza il suo consenso ha facolta' di segnalare il pericolo al Garante, il quale, nelle quarantotto ore dal ricevimento della segnalazione, decide ai sensi degli articoli 143 e 144 del presente codice.

2. Quando le registrazioni audio, le immagini o i video o gli altri documenti informatici riguardano minori, la segnalazione al Garante puo' essere effettuata anche dai genitori o dagli esercenti la responsabilita' genitoriale o la tutela.

3. Per le finalita' di cui al comma 1, l'invio al Garante di registrazioni audio, immagini o video o altri documenti informatici a contenuto sessualmente esplicito riguardanti soggetti terzi, effettuato dall'interessato, non integra il reato di cui all'articolo 612-ter del codice penale.

4. I gestori delle piattaforme digitali destinatari dei provvedimenti di cui al comma 1 conservano il materiale oggetto della segnalazione, a soli fini probatori e con misure indicate dal Garante, anche nell'ambito dei medesimi provvedimenti, idonee a impedire la diretta identificabilita' degli interessati, per dodici mesi a decorrere dal ricevimento del provvedimento stesso.

5. Il Garante, con proprio provvedimento, puo' disciplinare specifiche modalita' di svolgimento dei procedimenti di cui al comma 1 e le misure per impedire la diretta identificabilita' degli interessati di cui al medesimo comma.

6. I fornitori di servizi di condivisione di contenuti audiovisivi, ovunque stabiliti, che erogano servizi accessibili in Italia, indicano senza ritardo al Garante o pubblicano nel proprio sito internet un recapito al quale possono essere comunicati i provvedimenti adottati ai sensi del comma 1. In caso di inadempimento dell'obbligo di cui al periodo precedente, il Garante diffida il fornitore del servizio ad adempiere entro trenta giorni. In caso di inottemperanza alla diffida si applica la sanzione amministrativa pecuniaria di cui all'articolo 83, paragrafo 4, del Regolamento.

7. Quando il Garante, a seguito della segnalazione di cui al comma 1, acquisisce notizia della consumazione del reato di cui all'articolo 612-ter del codice penale, anche in forma tentata, nel caso di procedibilita' d'ufficio trasmette al pubblico ministero la segnalazione ricevuta e la documentazione acquisita))

((49))

---------------- AGGIORNAMENTO (49) Il D.L. 8 ottobre 2021, n. 139, convertito con modificazioni dalla L. 3 dicembre 2021, n. 205, ha disposto (con l'art. 9, comma 6) che "In fase di prima attuazione, l'obbligo di indicazione o di pubblicazione del recapito previsto dall'articolo 144-bis, comma 6, del codice di cui al decreto legislativo n. 196 del 2003, introdotto dalla lettera g) del comma 1 del presente articolo, e' adempiuto nel termine di sei mesi dalla data di entrata in vigore della legge di conversione del presente decreto".

### SEZIONE III - TUTELA ALTERNATIVA A QUELLA GIURISDIZIONALE <br>((SEZIONE ABROGATA DAL D.LGS. 10 AGOSTO 2018, N. 101))

#### Art. 145.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

#### Art. 146.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

#### Art. 147.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

#### Art. 148.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

#### Art. 149.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

#### Art. 150.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

#### Art. 151.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO II - TUTELA GIURISDIZIONALE

### Art. 152. - (Autorita' giudiziaria ordinaria)

((

1. Tutte le controversie che riguardano le materie oggetto dei ricorsi giurisdizionali di cui agli articoli 78 e 79 del Regolamento e quelli comunque riguardanti l'applicazione della normativa in materia di protezione dei dati personali, nonche' il diritto al risarcimento del danno ai sensi dell'articolo 82 del medesimo regolamento, sono attribuite all'autorita' giudiziaria ordinaria.

))

1-bis. Le controversie di cui al comma 1 sono disciplinate dall'articolo 10 del decreto legislativo 1° settembre 2011, n. 150.(26)

2. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

3. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

4. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

5. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

6. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

7. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

8. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

9. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

10. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

11. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

12. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

13. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

14. COMMA ABROGATO DAL D.LGS. 1 SETTEMBRE 2011, N. 150. (26)

--------------- AGGIORNAMENTO (26) Il D.Lgs. 1 settembre 2011, n. 150 ha disposto (con l'art. 36, commi 1 e 2) che "1. Le norme del presente decreto si applicano ai procedimenti instaurati successivamente alla data di entrata in vigore dello stesso. 2. Le norme abrogate o modificate dal presente decreto continuano ad applicarsi alle controversie pendenti alla data di entrata in vigore dello stesso."

## TITOLO II ((AUTORITA' DI CONTROLLO INDIPENDENTE)) CAPO I IL GARANTE PER LA PROTEZIONE DEI DATI PERSONALI

### Art. 153. - (Garante per la protezione dei dati personali)

1. Il Garante e' composto dal Collegio, che ne costituisce il vertice, e dall'Ufficio. Il Collegio e' costituito da quattro componenti, eletti due dalla Camera dei deputati e due dal Senato della Repubblica con voto limitato. I componenti devono essere eletti tra coloro che presentano la propria candidatura nell'ambito di una procedura di selezione il cui avviso deve essere pubblicato nei siti internet della Camera, del Senato e del Garante almeno sessanta giorni prima della nomina. Le candidature devono pervenire almeno trenta giorni prima della nomina e i curricula devono essere pubblicati negli stessi siti internet. Le candidature possono essere avanzate da persone che assicurino indipendenza e che risultino di comprovata esperienza nel settore della protezione dei dati personali, con particolare riferimento alle discipline giuridiche o dell'informatica.

2. I componenti eleggono nel loro ambito un presidente, il cui voto prevale in caso di parita'. Eleggono altresi' un vice presidente, che assume le funzioni del presidente in caso di sua assenza o impedimento.

3. L'incarico di presidente e quello di componente hanno durata settennale e non sono rinnovabili. Per tutta la durata dell'incarico il presidente e i componenti non possono esercitare, a pena di decadenza, alcuna attivita' professionale o di consulenza, anche non remunerata, ne' essere amministratori o dipendenti di enti pubblici o privati, ne' ricoprire cariche elettive.

4. I membri del Collegio devono mantenere il segreto, sia durante sia successivamente alla cessazione dell'incarico, in merito alle informazioni riservate cui hanno avuto accesso nell'esecuzione dei propri compiti o nell'esercizio dei propri poteri.

5. All'atto dell'accettazione della nomina il presidente e i componenti sono collocati fuori ruolo se dipendenti di pubbliche amministrazioni o magistrati in attivita' di servizio; se professori universitari di ruolo, sono collocati in aspettativa senza assegni ai sensi dell'articolo 13 del decreto del Presidente della Repubblica 11 luglio 1980, n. 382. Il personale collocato fuori ruolo o in aspettativa non puo' essere sostituito.

6. Al presidente ((e ai componenti)) compete una indennita' di funzione pari alla retribuzione in godimento al primo Presidente della Corte di cassazione, nei limiti previsti dalla legge per il trattamento economico annuo omnicomprensivo di chiunque riceva a carico delle finanze pubbliche emolumenti o retribuzioni nell'ambito di rapporti di lavoro dipendente o autonomo con pubbliche amministrazioni statali. ((L'indennita' di funzione di cui al primo periodo e' da ritenere onnicomprensiva ad esclusione del rimborso delle spese effettivamente sostenute e documentate in occasione di attivita' istituzionali)).

7. Alle dipendenze del Garante e' posto l'Ufficio di cui all'articolo 155.

8. Il presidente, i componenti, il segretario generale e i dipendenti si astengono dal trattare, per i due anni successivi alla cessazione dell'incarico ovvero del servizio presso il Garante, procedimenti dinanzi al Garante, ivi compresa la presentazione per conto di terzi di reclami richieste di parere o interpelli.

--------------- AGGIORNAMENTO (13) Il D.L. 31 dicembre 2007, n. 248, convertito con modificazioni dalla L. 28 febbraio 2008, n. 31, ha disposto (con l'art. 47-quater, comma 1) che nelle more dell'approvazione della legge di riordino delle autorita' indipendenti, la durata in carica del presidente e dei membri del Garante per la protezione dei dati personali di cui al presente articolo, comma 4, e' equiparata a quella del presidente e dei membri delle autorita' istituite con la legge 10 ottobre 1990, n. 287, e con la legge 31 luglio 1997, n. 249, con decorrenza dalla data del decreto di nomina. Inoltre ha stabilito che tali incarichi non sono rinnovabili.

### Art. 154. - (Compiti)

1. Oltre a quanto previsto da specifiche disposizioni e dalla Sezione II del Capo VI del regolamento, il Garante, ai sensi dell'articolo 57, paragrafo 1, lettera v), del Regolamento medesimo, anche di propria iniziativa e avvalendosi dell'Ufficio, in conformita' alla disciplina vigente e nei confronti di uno o piu' titolari del trattamento, ha il compito di:

- a) controllare se i trattamenti sono effettuati nel rispetto della disciplina applicabile, anche in caso di loro cessazione e con riferimento alla conservazione dei dati di traffico;
- b) trattare i reclami presentati ai sensi del regolamento, e delle disposizioni del presente codice, anche individuando con proprio regolamento modalita' specifiche per la trattazione, nonche' fissando annualmente le priorita' delle questioni emergenti dai reclami che potranno essere istruite nel corso dell'anno di riferimento;
- c) promuovere l'adozione di regole deontologiche, nei casi di cui all'articolo 2-quater;
- d) denunciare i fatti configurabili come reati perseguibili d'ufficio, dei quali viene a conoscenza nell'esercizio o a causa delle funzioni;
- e) trasmettere la relazione, predisposta annualmente ai sensi dell'articolo 59 del Regolamento, al Parlamento e al Governo entro il 31 maggio dell'anno successivo a quello cui si riferisce;
- f) assicurare la tutela dei diritti e delle liberta' fondamentali degli individui dando idonea attuazione al Regolamento e al presente codice;
- g) provvedere altresi' all'espletamento dei compiti ad esso attribuiti dal diritto dell'Unione europea o dello Stato e svolgere le ulteriori funzioni previste dall'ordinamento.

2. Il Garante svolge altresi', ai sensi del comma 1, la funzione di controllo o assistenza in materia di trattamento dei dati personali prevista da leggi di ratifica di accordi o convenzioni internazionali o da atti comunitari o dell'Unione europea e, in particolare:

- a) dal Regolamento (CE) n. 1987/2006 del Parlamento europeo e del Consiglio, del 20 dicembre 2006, sull'istituzione, l'esercizio e l'uso del sistema d'informazione Schengen di seconda generazione (SIS II) e Decisione 2007/533/GAI del Consiglio, del 12 giugno 2007, sull'istituzione, l'esercizio e l'uso del sistema d'informazione Schengen di seconda generazione (SIS II);
- b) dal Regolamento (UE) 2016/794 del Parlamento europeo e del Consiglio, dell'11 maggio 2016, che istituisce l'Agenzia dell'Unione europea per la cooperazione nell'attivita' di contrasto (Europol) e sostituisce e abroga le decisioni del Consiglio 2009/371/GAI, 2009/934/GAI, 2009/935/GAI, 2009/936/GAI e 2009/968/GAI;
- c) dal Regolamento (UE) 2015/1525 del Parlamento europeo e del Consiglio, del 9 settembre 2015, che modifica il Regolamento (CE) n. 515/97 del Consiglio relativo alla mutua assistenza tra le autorita' amministrative degli Stati membri e alla collaborazione tra queste e la Commissione per assicurare la corretta applicazione delle normative doganale e agricola e decisione 2009/917/GAI del Consiglio, del 30 novembre 2009, sull'uso dell'informatica nel settore doganale;
- d) dal Regolamento (CE) n. 603/2013 del Parlamento europeo e del Consiglio, del 26 giugno 2013, che istituisce l'Eurodac per il confronto delle impronte digitali per l'efficace applicazione del Regolamento (UE) n. 604/2013 che stabilisce i criteri e i meccanismi di determinazione dello Stato membro competente per l'esame di una domanda di protezione internazionale presentata in uno degli Stati membri da un cittadino di un paese terzo o da un apolide e per le richieste di confronto con i dati Eurodac presentate dalle autorita' di contrasto degli Stati membri e da Europol a fini di contrasto, e che modifica il Regolamento (UE) n. 1077/2011 che istituisce un'agenzia europea per la gestione operativa dei sistemi IT su larga scala nello spazio di liberta', sicurezza e giustizia;
- e) dal Regolamento (CE) n. 767/2008 del Parlamento europeo e del Consiglio, del 9 luglio 2008, concernente il sistema di informazione visti (VIS) e lo scambio di dati tra Stati membri sui visti per soggiorni di breve durata (Regolamento VIS) e decisione n. 2008/633/GAI del Consiglio, del 23 giugno 2008, relativa all'accesso per la consultazione al sistema di informazione visti (VIS) da parte delle autorita' designate degli Stati membri e di Europol ai fini della prevenzione, dell'individuazione e dell'investigazione di reati di terrorismo e altri reati gravi;
- f) dal Regolamento (CE) n. 1024/2012 del Parlamento europeo e del Consiglio, del 25 ottobre 2012, relativo alla cooperazione amministrativa attraverso il sistema di informazione del mercato interno e che abroga la decisione 2008/49/CE della Commissione (Regolamento IMI) Testo rilevante ai fini del SEE;
- g) dalle disposizioni di cui al capitolo IV della Convenzione n. 108 sulla protezione delle persone rispetto al trattamento automatizzato di dati di carattere personale, adottata a Strasburgo il 28 gennaio 1981 e resa esecutiva con legge 21 febbraio 1989, n. 98, quale autorita' designata ai fini della cooperazione tra Stati ai sensi dell'articolo 13 della convenzione medesima.

3. Per quanto non previsto dal Regolamento e dal presente codice, il Garante disciplina con proprio Regolamento, ai sensi dell'articolo 156, comma 3, le modalita' specifiche dei procedimenti relativi all'esercizio dei compiti e dei poteri ad esso attribuiti dal Regolamento e dal presente codice.

4. Il Garante collabora con altre autorita' amministrative indipendenti nazionali nello svolgimento dei rispettivi compiti.

5. Fatti salvi i termini piu' brevi previsti per legge, il parere del Garante, anche nei casi di cui agli articoli 36, paragrafo 4, del Regolamento, e' reso nel termine di quarantacinque giorni dal ricevimento della richiesta. Decorso il termine, l'amministrazione puo' procedere indipendentemente dall'acquisizione del parere. Quando, per esigenze istruttorie, non puo' essere rispettato il termine di cui al presente comma, tale termine puo' essere interrotto per una sola volta e il parere deve essere reso definitivamente entro venti giorni dal ricevimento degli elementi istruttori da parte delle amministrazioni interessate.

((

5-bis. Il parere di cui all'articolo 36, paragrafo 4, del Regolamento e' reso dal Garante nei soli casi in cui la legge o il regolamento in corso di adozione disciplina espressamente le modalita' del trattamento descrivendo una o piu' operazioni, compiute con o senza l'ausilio di processi automatizzati e applicate a dati personali o insiemi di dati personali, come la raccolta, la registrazione, l'organizzazione, la strutturazione, la conservazione, l'adattamento o la modifica, l'estrazione, la consultazione, l'uso, la comunicazione mediante trasmissione, diffusione o qualsiasi altra forma di messa a disposizione, il raffronto o l'interconnessione, la limitazione, la cancellazione o la distruzione, nonche' nei casi in cui la norma di legge o di regolamento autorizza espressamente un trattamento di dati personali da parte di soggetti privati senza rinviare la disciplina delle modalita' del trattamento a fonti sottoordinate.

5-ter. Quando il Presidente del Consiglio dei ministri dichiara che ragioni di urgenza non consentono la consultazione preventiva e comunque nei casi di adozione di decreti-legge, il Garante esprime il parere di cui al comma 5-bis:

b) in sede di esame definitivo degli schemi di decreto legislativo sottoposti al parere delle Commissioni parlamentari))

6. Copia dei provvedimenti emessi dall'autorita' giudiziaria in relazione a quanto previsto dal presente codice o in materia di criminalita' informatica e' trasmessa, a cura della cancelleria, al Garante.

7. Il Garante non e' competente per il controllo dei trattamenti effettuati dalle autorita' giudiziarie nell'esercizio delle loro funzioni.

### Art. 154-bis. - (( (Poteri) ))

((

.

1. Oltre a quanto previsto da specifiche disposizioni, dalla Sezione II del Capo VI del Regolamento e dal presente codice, ai sensi dell'articolo 58, paragrafo 6, del Regolamento medesimo, il Garante ha il potere di:

- a) adottare linee guida di indirizzo riguardanti le misure organizzative e tecniche di attuazione dei principi del Regolamento, anche per singoli settori e in applicazione dei principi di cui all'articolo 25 del Regolamento;
- b) approvare le regole deontologiche di cui all'articolo 2-quater.

2. Il Garante puo' invitare rappresentanti di un'altra autorita' amministrativa indipendente nazionale a partecipare alle proprie riunioni, o essere invitato alle riunioni di altra autorita' amministrativa indipendente nazionale, prendendo parte alla discussione di argomenti di comune interesse; puo' richiedere, altresi', la collaborazione di personale specializzato addetto ad altra autorita' amministrativa indipendente nazionale.

3. Il Garante pubblica i propri provvedimenti sulla base di quanto previsto con atto di natura generale che disciplina anche la durata di tale pubblicazione, la pubblicita' nella Gazzetta Ufficiale della Repubblica italiana e sul proprio sito internet istituzionale nonche' i casi di oscuramento.

4. In considerazione delle esigenze di semplificazione delle micro, piccole e medie imprese, come definite dalla raccomandazione 2003/361/CE, il Garante per la protezione dei dati personali, nel rispetto delle disposizioni del Regolamento e del presente Codice, promuove, nelle linee guida adottate a norma del comma 1, lettera a), modalita' semplificate di adempimento degli obblighi del titolare del trattamento.

))

### Art. 154-ter. - (( (Potere di agire e rappresentanza in giudizio) ))

((

.

1. Il Garante e' legittimato ad agire in giudizio nei confronti del titolare o del responsabile del trattamento in caso di violazione delle disposizioni in materia di protezione dei dati personali.

2. Il Garante e' rappresentato in giudizio dall'Avvocatura dello Stato, ai sensi dell'articolo 1 del regio decreto 30 ottobre 1933, n. 1611.

3. Nei casi di conflitto di interesse, il Garante, sentito l'Avvocato generale dello Stato, puo' stare in giudizio tramite propri funzionari iscritti nell'elenco speciale degli avvocati dipendenti di enti pubblici ovvero avvocati del libero foro.

))

## CAPO II - L'UFFICIO DEL GARANTE

### Art. 155. - (( (Ufficio del Garante) ))

1. All'Ufficio del Garante, al fine di garantire la responsabilita' e l'autonomia ai sensi della legge 7 agosto 1990, n. 241, e successive modificazioni, e del decreto legislativo 30 marzo 2001, n. 165, e successive modificazioni, si applicano i principi riguardanti l'individuazione e le funzioni del responsabile del procedimento, nonche' quelli relativi alla distinzione fra le funzioni di indirizzo e di controllo, attribuite agli organi di vertice, e le funzioni di gestione attribuite ai dirigenti. Si applicano altresi' le disposizioni del medesimo decreto legislativo n. 165 del 2001 espressamente richiamate dal presente codice.

### Art. 156. - (Ruolo organico e personale)

1. All'Ufficio del Garante e' preposto un segretario generale, nominato tra persone di elevata e comprovata qualificazione professionale rispetto al ruolo e agli obiettivi da conseguire, scelto anche tra i magistrati ordinari, amministrativi e contabili, gli avvocati dello Stato, i professori universitari di ruolo in materie giuridiche ed economiche, nonche' i dirigenti di prima fascia dello Stato.

2. ((A decorrere dal 1° gennaio 2022, il ruolo organico del personale dipendente e' stabilito nel limite di duecento unita')). Al ruolo organico del Garante si accede esclusivamente mediante concorso pubblico. Nei casi in cui sia ritenuto utile al fine di garantire l'economicita' e l'efficienza dell'azione amministrativa, nonche' di favorire il reclutamento di personale con maggiore esperienza nell'ambito delle procedure concorsuali di cui al secondo periodo, il Garante puo' riservare una quota non superiore al cinquanta per cento dei posti banditi al personale di ruolo delle amministrazioni pubbliche che sia stato assunto per concorso pubblico e abbia maturato un'esperienza almeno triennale nel rispettivo ruolo organico. La disposizione di cui all'articolo 30 del decreto legislativo 30 marzo 2001, n. 165, si applica esclusivamente nell'ambito del personale di ruolo delle autorita' amministrative indipendenti di cui all'articolo 22, comma 1, del decreto-legge 24 giugno 2014, n. 90, convertito, con modificazioni, dalla legge 11 agosto 2014, n.114.

3. Con propri regolamenti pubblicati nella Gazzetta Ufficiale della Repubblica italiana, il Garante definisce:

- a) l'organizzazione e il funzionamento dell'Ufficio anche ai fini dello svolgimento dei compiti e dell'esercizio dei poteri di cui agli articoli 154, 154-bis, 160, nonche' all'articolo 57, paragrafo 1, del Regolamento;
- b) l'ordinamento delle carriere e le modalita' di reclutamento del personale secondo i principi e le procedure di cui agli articoli 1, 35 e 36 del decreto legislativo n. 165 del 2001;
- c) la ripartizione dell'organico tra le diverse aree e qualifiche;
- d) il trattamento giuridico ed economico del personale, secondo i criteri previsti dalla legge 31 luglio 1997, n. 249, e, per gli incarichi dirigenziali, dagli articoli 19, comma 6, e 23-bis del decreto legislativo 30 marzo 2001, n. 165, tenuto conto delle specifiche esigenze funzionali e organizzative. Nelle more della piu' generale razionalizzazione del trattamento economico delle autorita' amministrative indipendenti, al personale e' attribuito ((il trattamento)) economico del personale dell'Autorita' per le garanzie nelle comunicazioni;
- e) la gestione amministrativa e la contabilita', anche in deroga alle norme sulla contabilita' generale dello Stato.

4. L'Ufficio puo' avvalersi, per motivate esigenze, di dipendenti dello Stato o di altre amministrazioni pubbliche o di enti pubblici collocati in posizione di fuori ruolo o equiparati nelle forme previste dai rispettivi ordinamenti, ovvero in aspettativa ai sensi dell'articolo 13 del decreto del Presidente della Repubblica 11 luglio 1980, n. 382, in numero non superiore, complessivamente, a ((trenta unita')) e per non oltre il venti per cento delle qualifiche dirigenziali, lasciando non coperto un corrispondente numero di posti di ruolo.

5. In aggiunta al personale di ruolo, l'Ufficio puo' assumere dipendenti con contratto a tempo determinato o avvalersi di consulenti incaricati ai sensi dell'articolo 7, comma 6, del decreto legislativo n. 165 del 2001, in misura comunque non superiore a ((trenta unita')) complessive. Resta in ogni caso fermo, per i contratti a tempo determinato, il rispetto dell'articolo 36 del decreto legislativo n. 165 del 2001.

6. Il personale addetto all'Ufficio del Garante ed i consulenti sono tenuti, sia durante che dopo il mandato, al segreto su cio' di cui sono venuti a conoscenza, nell'esercizio delle proprie funzioni, in ordine a notizie che devono rimanere segrete.

7. Il personale dell'Ufficio del Garante addetto agli accertamenti di cui all'articolo 158 e agli articoli 57, paragrafo 1, lettera h), 58, paragrafo 1, lettera b), e 62, del Regolamento riveste, nei limiti del servizio cui e' destinato e secondo le rispettive attribuzioni, la qualifica di ufficiale o agente di polizia giudiziaria.

8. Le spese di funzionamento del Garante, in adempimento all'articolo 52, paragrafo 4, del Regolamento, ivi comprese quelle necessarie ad assicurare la sua partecipazione alle procedure di cooperazione e al meccanismo di coerenza introdotti dal Regolamento, nonche' quelle connesse alle risorse umane, tecniche e finanziarie, ai locali e alle infrastrutture necessarie per l'effettivo adempimento dei suoi compiti e l'esercizio dei propri poteri, sono poste a carico di un fondo stanziato a tale scopo nel bilancio dello Stato e iscritto in apposita missione e programma di spesa del Ministero dell'economia e delle finanze. Il rendiconto della gestione finanziaria e' soggetto al controllo della Corte dei conti. Il Garante puo' esigere dal titolare del trattamento il versamento di diritti di segreteria in relazione a particolari procedimenti.

------------ AGGIORNAMENTO (29) La L. 27 dicembre 2013, n. 147 ha disposto (con l'art. 1, comma 268) che "Al fine di non disperdere la professionalita' acquisita dal personale con contratto di lavoro subordinato a tempo determinato assunto a seguito di superamento di apposita procedura selettiva pubblica, per titoli ed esami, nonche' per fare fronte agli accresciuti compiti derivanti dalla partecipazione alle attivita' di cooperazione fra autorita' di protezione di dati dell'Unione europea, il ruolo organico di cui all'articolo 156, comma 2, del codice di cui al decreto legislativo 30 giugno 2003, n. 196, come incrementato in attuazione dell'articolo 1, comma 542, della legge 27 dicembre 2006, n. 296, e' incrementato di dodici unita', previa contestuale riduzione nella medesima misura del contingente di cui al comma 5 del predetto articolo 156 del codice di cui al decreto legislativo n. 196 del 2003". ------------ AGGIORNAMENTO (33) La L. 20 novembre 2017, n. 167 ha disposto (con l'art. 29, comma 1) che "Al fine di assicurare il regolare esercizio dei poteri di controllo affidati al Garante per la protezione dei dati personali e per fare fronte agli accresciuti compiti derivanti dalla partecipazione alle attivita' di cooperazione fra autorita' di protezione di dati dell'Unione europea, e' attribuito, a decorrere dall'anno 2018, un contributo aggiuntivo pari a 1.400.000 euro. Per le finalita' di cui al primo periodo, il ruolo organico di cui all'articolo 156, comma 2, del codice in materia di protezione dei dati personali, di cui al decreto legislativo 30 giugno 2003, n. 196, come incrementato in attuazione dell'articolo 1, comma 542, della legge 27 dicembre 2006, n. 296, e successivamente dall'articolo 1, comma 268, della legge 27 dicembre 2013, n. 147, e' incrementato di 25 unita'; e' autorizzata a questo fine la spesa di euro 887.250 per l'anno 2017 e di euro 2.661.750 annui a decorrere dall'anno 2018".

## CAPO III - ACCERTAMENTI E CONTROLLI

### Art. 157. - (( (Richiesta di informazioni e di esibizione di documenti). ))

((

1. Nell'ambito dei poteri di cui all'articolo 58 del Regolamento, e per l'espletamento dei propri compiti, il Garante puo' richiedere al titolare, al responsabile, al rappresentante del titolare o del responsabile, all'interessato o anche a terzi di fornire informazioni e di esibire documenti anche con riferimento al contenuto di banche di dati.

))

### Art. 158. - (( (Accertamenti). ))

((

1. Il Garante puo' disporre accessi a banche di dati, archivi o altre ispezioni e verifiche nei luoghi ove si svolge il trattamento o nei quali occorre effettuare rilevazioni comunque utili al controllo del rispetto della disciplina in materia di trattamento dei dati personali.

2. I controlli di cui al comma 1, nonche' quelli effettuati ai sensi dell'articolo 62 del Regolamento, sono eseguiti da personale dell'Ufficio, con la partecipazione, se del caso, di componenti o personale di autorita' di controllo di altri Stati membri dell'Unione europea.

3. Il Garante si avvale anche, ove necessario, della collaborazione di altri organi dello Stato per lo svolgimento dei suoi compiti istituzionali.

4. Gli accertamenti di cui ai commi 1 e 2, se svolti in un'abitazione o in un altro luogo di privata dimora o nelle relative appartenenze, sono effettuati con l'assenso informato del titolare o del responsabile, oppure previa autorizzazione del presidente del tribunale competente per territorio in relazione al luogo dell'accertamento, il quale provvede con decreto motivato senza ritardo, al piu' tardi entro tre giorni dal ricevimento della richiesta del Garante quando e' documentata l'indifferibilita' dell'accertamento.

5. Con le garanzie di cui al comma 4, gli accertamenti svolti nei luoghi di cui al medesimo comma possono altresi' riguardare reti di comunicazione accessibili al pubblico, potendosi procedere all'acquisizione di dati e informazioni on-line. A tal fine, viene redatto apposito verbale in contradditorio con le parti ove l'accertamento venga effettuato presso il titolare del trattamento.

))

### Art. 159.

(Modalita)

1. Il personale operante, munito di documento di riconoscimento, puo' essere assistito ove necessario da consulenti tenuti al segreto ((su cio' di cui sono venuti a conoscenza, nell'esercizio delle proprie funzioni, in ordine a notizie che devono rimanere segrete)). Nel procedere a rilievi e ad operazioni tecniche puo' altresi' estrarre copia di ogni atto, dato e documento, anche a campione e su supporto informatico o per via telematica. Degli accertamenti e' redatto sommario verbale nel quale sono annotate anche le eventuali dichiarazioni dei presenti.

2. Ai soggetti presso i quali sono eseguiti gli accertamenti e' consegnata copia dell'autorizzazione del presidente del tribunale, ove rilasciata. I medesimi soggetti sono tenuti a farli eseguire e a prestare la collaborazione a tal fine necessaria. In caso di rifiuto gli accertamenti sono comunque eseguiti e le spese in tal caso occorrenti sono poste a carico del titolare con il provvedimento che definisce il procedimento, che per questa parte costituisce titolo esecutivo ai sensi degli articoli 474 e 475 del codice di procedura civile.

3. Gli accertamenti, se effettuati presso il titolare o il responsabile ((o il rappresentante del titolare o del responsabile)), sono eseguiti dandone informazione a quest'ultimo o, se questo e' assente o non e' designato, ((alle persone autorizzate al trattamento dei dati personali sotto l'autorita' diretta del titolare o del responsabile ai sensi dell'articolo 2-quaterdecies)). Agli accertamenti possono assistere persone indicate dal titolare o dal responsabile.

4. Se non e' disposto diversamente nel decreto di autorizzazione del presidente del tribunale, l'accertamento non puo' essere iniziato prima delle ore sette e dopo le ore venti, e puo' essere eseguito anche con preavviso quando cio' puo' facilitarne l'esecuzione.

5. Le informative, le richieste e i provvedimenti di cui al presente articolo e agli articoli 157 e 158 possono essere trasmessi anche mediante posta elettronica ((...)).

6. Quando emergono indizi di reato si osserva la disposizione di cui all'articolo 220 delle norme di attuazione, di coordinamento e transitorie del codice di procedura penale, approvate con decreto legislativo 28 luglio 1989, n. 271.

### Art. 160. - (( (Particolari accertamenti). ))

((

1. Per i trattamenti di dati personali di cui all'articolo 58, gli accertamenti sono effettuati per il tramite di un componente designato dal Garante.

2. Se il trattamento non risulta conforme alle norme del Regolamento ovvero alle disposizioni di legge o di Regolamento, il Garante indica al titolare o al responsabile le necessarie modificazioni ed integrazioni e ne verifica l'attuazione. Se l'accertamento e' stato richiesto dall'interessato, a quest'ultimo e' fornito in ogni caso un riscontro circa il relativo esito, se cio' non pregiudica azioni od operazioni a tutela dell'ordine e della sicurezza pubblica o di prevenzione e repressione di reati o ricorrono motivi di difesa o di sicurezza dello Stato.

3. Gli accertamenti non sono delegabili. Quando risulta necessario in ragione della specificita' della verifica, il componente designato puo' farsi assistere da personale specializzato tenuto al segreto su cio' di cui sono venuti a conoscenza in ordine a notizie che devono rimanere segrete. Gli atti e i documenti acquisiti sono custoditi secondo modalita' tali da assicurarne la segretezza e sono conoscibili dal presidente e dai componenti del Garante e, se necessario per lo svolgimento delle funzioni dell'organo, da un numero delimitato di addetti all'Ufficio individuati dal Garante sulla base di criteri definiti dal Regolamento di cui all'articolo 156, comma 3, lettera a).

4. Per gli accertamenti di cui al comma 3 relativi agli organismi di informazione e di sicurezza e ai dati coperti da segreto di Stato il componente designato prende visione degli atti e dei documenti rilevanti e riferisce oralmente nelle riunioni del Garante.))

((39))

--------------- AGGIORNAMENTO (39) Il D.Lgs. 10 agosto 2018, n. 101 ha disposto (con l'art. 22, comma 10) che "La disposizione di cui all'articolo 160, comma 4, del codice in materia di protezione dei dati personali, di cui al decreto legislativo n. 196 del 2003, nella parte in cui ha riguardo ai dati coperti da segreto di Stato, si applica fino alla data di entrata in vigore della disciplina relativa alle modalita' di opposizione al Garante per la protezione dei dati personali del segreto di Stato".

### Art. 160-bis. - (( (Validita', efficacia e utilizzabilita' nel procedimento giudiziario di atti, documenti e provvedimenti basati sul trattamento di dati personali non conforme a disposizioni di legge o di Regolamento). ))

((

1. La validita', l'efficacia e l'utilizzabilita' nel procedimento giudiziario di atti, documenti e provvedimenti basati sul trattamento di dati personali non conforme a disposizioni di legge o di Regolamento restano disciplinate dalle pertinenti disposizioni processuali.

))

## TITOLO III SANZIONI CAPO I VIOLAZIONI AMMINISTRATIVE

### Art. 161.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 162.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 162-bis.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 162-ter.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 163.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 164.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 164-bis.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 165.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 166. - (Criteri di applicazione delle sanzioni amministrative pecuniarie e procedimento per l'adozione dei provvedimenti correttivi e sanzionatori)

1. Sono soggette alla sanzione amministrativa di cui all'articolo 83, paragrafo 4, del Regolamento le violazioni delle disposizioni di cui agli articoli 2-quinquies, comma 2, ((...)), 92, comma 1, 93, comma 1, 123, comma 4, 128, 129, comma 2, e 132-ter. Alla medesima sanzione amministrativa e' soggetto colui che non effettua la valutazione di impatto di cui all'articolo 110, comma 1, primo periodo, ovvero non sottopone il programma di ricerca a consultazione preventiva del Garante a norma del terzo periodo del predetto comma.

2. Sono soggette alla sanzione amministrativa di cui all'articolo 83, paragrafo 5, del Regolamento le violazioni delle disposizioni di cui agli articoli 2-ter, 2-quinquies, comma 1, 2-sexies, 2-septies, comma 8, 2-octies, 2-terdecies, commi 1, 2, 3 e 4, 52, commi 4 e 5, 75, 78, 79, 80, 82, 92, comma 2, 93, commi 2 e 3, 96, 99, 100, commi 1, 2 e 4, 101, 105 commi 1, 2 e 4, 110-bis, commi 2 e 3, 111, 111-bis, 116, comma 1, 120, comma 2, 122, 123, commi 1, 2, 3 e 5, 124, 125, 126, 130, commi da 1 a 5, 131, 132, 132-bis, comma 2, 132-quater, 157, nonche' delle misure di garanzia, delle regole deontologiche di cui rispettivamente agli articoli 2-septies e 2-quater.

3. Il Garante e' l'organo competente ad adottare i provvedimenti correttivi di cui all'articolo 58, paragrafo 2, del Regolamento, nonche' ad irrogare le sanzioni di cui all'articolo 83 del medesimo Regolamento e di cui ai commi 1 e 2.

4. Il procedimento per l'adozione dei provvedimenti e delle sanzioni indicati al comma 3 puo' essere avviato, nei confronti sia di soggetti privati, sia di autorita' pubbliche ed organismi pubblici, a seguito di reclamo ai sensi dell'articolo 77 del Regolamento o di attivita' istruttoria d'iniziativa del Garante, nell'ambito dell'esercizio dei poteri d'indagine di cui all'articolo 58, paragrafo 1, del Regolamento, nonche' in relazione ad accessi, ispezioni e verifiche svolte in base a poteri di accertamento autonomi, ovvero delegati dal Garante.

5. L'Ufficio del Garante, quando ritiene che gli elementi acquisiti nel corso delle attivita' di cui al comma 4 configurino una o piu' violazioni indicate nel presente titolo e nell'articolo 83, paragrafi 4, 5 e 6, del Regolamento, avvia il procedimento per l'adozione dei provvedimenti e delle sanzioni di cui al comma 3 notificando al titolare o al responsabile del trattamento le presunte violazioni, nel rispetto delle garanzie previste dal Regolamento di cui al comma 9, salvo che la previa notifica della contestazione non risulti incompatibile con la natura e le finalita' del provvedimento da adottare. ((Nei confronti dei titolari del trattamento di cui agli articoli 2-ter, comma 1-bis, e 58 del presente codice e all'articolo 1, comma 1, del decreto legislativo 18 maggio 2018, n. 51, la predetta notifica puo' essere omessa esclusivamente nel caso in cui il Garante abbia accertato che le presunte violazioni hanno gia' arrecato e continuano ad arrecare un effettivo, concreto, attuale e rilevante pregiudizio ai soggetti interessati al trattamento, che il Garante ha l'obbligo di individuare e indicare nel provvedimento, motivando puntualmente le ragioni dell'omessa notifica. In assenza di tali presupposti, il giudice competente accerta l'inefficacia del provvedimento)).

6. Entro trenta giorni dal ricevimento della comunicazione di cui al comma 5, il contravventore puo' inviare al Garante scritti difensivi o documenti e puo' chiedere di essere sentito dalla medesima autorita'.

7. Nell'adozione dei provvedimenti sanzionatori nei casi di cui al comma 3 si osservano, in quanto applicabili, gli articoli da 1 a 9, da 18 a 22 e da 24 a 28 della legge 24 novembre 1981, n. 689; nei medesimi casi puo' essere applicata la sanzione amministrativa accessoria della pubblicazione dell'ordinanza-ingiunzione, per intero o per estratto, sul sito internet del Garante ((o dell'ingiunzione a realizzare campagne di comunicazione istituzionale volte alla promozione della consapevolezza del diritto alla protezione dei dati personali, sulla base di progetti previamente approvati dal Garante e che tengano conto della gravita' della violazione. Nella determinazione della sanzione ai sensi dell'articolo 83, paragrafo 2, del Regolamento, il Garante tiene conto anche di eventuali campagne di comunicazione istituzionale volte alla promozione della consapevolezza del diritto alla protezione dei dati personali, realizzate dal trasgressore anteriormente alla commissione della violazione)). I proventi delle sanzioni, nella misura del cinquanta per cento del totale annuo, sono riassegnati al fondo di cui all'articolo 156, comma 8, per essere destinati alle specifiche attivita' di sensibilizzazione e di ispezione nonche' di attuazione del Regolamento svolte dal Garante.

8. Entro il termine di cui all'articolo 10, comma 3, del decreto legislativo n. 150 del 2011 previsto per la proposizione del ricorso, il trasgressore e gli obbligati in solido possono definire la controversia adeguandosi alle prescrizioni del Garante, ove impartite, e mediante il pagamento di un importo pari alla meta' della sanzione irrogata.

9. Nel rispetto dell'articolo 58, paragrafo 4, del Regolamento, con proprio regolamento pubblicato nella Gazzetta Ufficiale della Repubblica italiana, il Garante definisce le modalita' del procedimento per l'adozione dei provvedimenti e delle sanzioni di cui al comma 3 ed i relativi termini, in conformita' ai principi della piena conoscenza degli atti istruttori, del contraddittorio, della verbalizzazione, nonche' della distinzione tra funzioni istruttorie e funzioni decisorie rispetto all'irrogazione della sanzione.

10. Le disposizioni relative a sanzioni amministrative previste dal presente codice e dall'articolo 83 del Regolamento non si applicano in relazione ai trattamenti svolti in ambito giudiziario.

## CAPO II - ILLECITI PENALI

### Art. 167. - (Trattamento illecito di dati)

1. Salvo che il fatto costituisca piu' grave reato, chiunque, al fine di trarre per se' o per altri profitto ovvero di arrecare danno all'interessato, operando in violazione di quanto disposto dagli articoli 123, 126 e 130 o dal provvedimento di cui all'articolo 129 arreca nocumento all'interessato, e' punito con la reclusione da sei mesi a un anno e sei mesi.

2. Salvo che il fatto costituisca piu' grave reato, chiunque, al fine di trarre per se' o per altri profitto ovvero di arrecare danno all'interessato, procedendo al trattamento dei dati personali di cui agli articoli 9 e 10 del Regolamento in violazione delle disposizioni di cui agli articoli 2-sexies e 2-octies, o delle misure di garanzia di cui all'articolo 2-septies ((...)) arreca nocumento all'interessato, e' punito con la reclusione da uno a tre anni.

3. Salvo che il fatto costituisca piu' grave reato, la pena di cui al comma 2 si applica altresi' a chiunque, al fine di trarre per se' o per altri profitto ovvero di arrecare danno all'interessato, procedendo al trasferimento dei dati personali verso un paese terzo o un'organizzazione internazionale al di fuori dei casi consentiti ai sensi degli articoli 45, 46 o 49 del Regolamento, arreca nocumento all'interessato.

4. Il Pubblico ministero, quando ha notizia dei reati di cui ai commi 1, 2 e 3, ne informa senza ritardo il Garante.

5. Il Garante trasmette al pubblico ministero, con una relazione motivata, la documentazione raccolta nello svolgimento dell'attivita' di accertamento nel caso in cui emergano elementi che facciano presumere la esistenza di un reato. La trasmissione degli atti al pubblico ministero avviene al piu' tardi al termine dell'attivita' di accertamento delle violazioni delle disposizioni di cui al presente decreto.

6. Quando per lo stesso fatto e' stata applicata a norma del presente codice o del Regolamento a carico dell'imputato o dell'ente una sanzione amministrativa pecuniaria dal Garante e questa e' stata riscossa, la pena e' diminuita.

### Art. 167-bis. - (( (Comunicazione e diffusione illecita di dati personali oggetto di trattamento su larga scala). ))

((

1. Salvo che il fatto costituisca piu' grave reato, chiunque comunica o diffonde al fine di trarre profitto per se' o altri ovvero al fine di arrecare danno, un archivio automatizzato o una parte sostanziale di esso contenente dati personali oggetto di trattamento su larga scala, in violazione degli articoli 2-ter, 2-sexies e 2-octies, e' punito con la reclusione da uno a sei anni.

2. Salvo che il fatto costituisca piu' grave reato, chiunque, al fine trarne profitto per se' o altri ovvero di arrecare danno, comunica o diffonde, senza consenso, un archivio automatizzato o una parte sostanziale di esso contenente dati personali oggetto di trattamento su larga scala, e' punito con la reclusione da uno a sei anni, quando il consenso dell'interessato e' richiesto per le operazioni di comunicazione e di diffusione.

3. Per i reati di cui ai commi 1 e 2, si applicano i commi 4, 5 e 6 dell'articolo 167.

))

### Art. 167-ter. - (( (Acquisizione fraudolenta di dati personali oggetto di trattamento su larga scala). ))

((

1. Salvo che il fatto costituisca piu' grave reato, chiunque, al fine trarne profitto per se' o altri ovvero di arrecare danno, acquisisce con mezzi fraudolenti un archivio automatizzato o una parte sostanziale di esso contenente dati personali oggetto di trattamento su larga scala e' punito con la reclusione da uno a quattro anni.

2. Per il reato di cui al comma 1 si applicano i commi 4, 5 e 6 dell'articolo 167.

))

### Art. 168. - (( (Falsita' nelle dichiarazioni al Garante e interruzione dell'esecuzione dei compiti o dell'esercizio dei poteri del Garante). ))

((

1. Salvo che il fatto costituisca piu' grave reato, chiunque, in un procedimento o nel corso di accertamenti dinanzi al Garante, dichiara o attesta falsamente notizie o circostanze o produce atti o documenti falsi, e' punito con la reclusione da sei mesi a tre anni.

2. Fuori dei casi di cui al comma 1, e' punito con la reclusione sino ad un anno chiunque intenzionalmente cagiona un'interruzione o turba la regolarita' di un procedimento dinanzi al Garante o degli accertamenti dallo stesso svolti.

))

### Art. 169.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 170. - (Inosservanza di provvedimenti del Garante)

1. Chiunque, ((non osservando)) il provvedimento adottato dal Garante ai sensi degli articoli 58, paragrafo 2, lettera f) del Regolamento, dell'articolo 2-septies, comma 1, nonche' i provvedimenti generali di cui all'articolo 21, comma 1, del decreto legislativo di attuazione dell'articolo 13 della legge 25 ottobre 2017, n. 163 ((, arreca un concreto nocumento a uno o piu' soggetti interessati al trattamento)) e' punito ((, a querela della persona offesa,)) con la reclusione da tre mesi a due anni.

### Art. 171. - (( (Violazioni delle disposizioni in materia di controlli a distanza e indagini sulle opinioni dei lavoratori). ))

((

1. La violazione delle disposizioni di cui agli articoli 4, comma 1, e 8 della legge 20 maggio 1970, n. 300, e' punita con le sanzioni di cui all'articolo 38 della medesima legge.

))

### Art. 172. - (Pene accessorie)

1. La condanna per uno dei delitti previsti dal presente codice importa la pubblicazione della sentenza ((, ai sensi dell'articolo 36, secondo e terzo comma, del codice penale)).

## TITOLO IV DISPOSIZIONI MODIFICATIVE, ABROGATIVE, TRANSITORIE E FINALI CAPO I DISPOSIZIONI DI MODIFICA

### Art. 173.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 174.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 175. - (Forze di polizia)

1. ((COMMA ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101)).

2. ((COMMA ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101)).

3. L'articolo 10 della legge 1 aprile 1981, n. 121, e successive modificazioni, e' sostituito dal seguente: "Art. 10 (Controlli) 1. Il controllo sul Centro elaborazione dati e' esercitato dal Garante per la protezione dei dati personali, nei modi previsti dalla legge e dai regolamenti. 2. I dati e le informazioni conservati negli archivi del Centro possono essere utilizzati in procedimenti giudiziari o amministrativi soltanto attraverso l'acquisizione delle fonti originarie indicate nel primo comma dell'articolo 7, fermo restando quanto stabilito dall'articolo 240 del codice di procedura penale. Quando nel corso di un procedimento giurisdizionale o amministrativo viene rilevata l'erroneita' o l'incompletezza dei dati e delle informazioni, o l'illegittimita' del loro trattamento, l'autorita' precedente ne da' notizia al Garante per la protezione dei dati personali. 3. La persona alla quale si riferiscono i dati puo' chiedere all'ufficio di cui alla lettera a) del primo comma dell'articolo 5 la conferma dell'esistenza di dati personali che lo riguardano, la loro comunicazione in forma intellegibile e, se i dati risultano trattati in violazione di vigenti disposizioni di legge o di regolamento, la loro cancellazione o trasformazione in forma anonima. 4. Esperiti i necessari accertamenti, l'ufficio comunica al richiedente, non oltre trenta giorni dalla richiesta, le determinazioni adottate. L'ufficio puo' omettere di provvedere sulla richiesta se cio' puo' pregiudicare azioni od operazioni a tutela dell'ordine e della sicurezza pubblica o di prevenzione e repressione della criminalita', dandone informazione al Garante per la protezione dei dati personali. 5. Chiunque viene a conoscenza dell'esistenza di dati personali che lo riguardano, trattati anche in forma non automatizzata in violazione di disposizioni di legge o di regolamento, puo' chiedere al tribunale del luogo ove risiede il titolare del trattamento di compiere gli accertamenti necessari e di ordinare la rettifica, l'integrazione, la cancellazione o la trasformazione in forma anonima dei dati medesimi.".

### Art. 176.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 177.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 178.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 179.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO II - DISPOSIZIONI TRANSITORIE <br> ((CAPO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 180.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 181.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 182.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

## CAPO III - ABROGAZIONI

### Art. 183. - (Norme abrogate)

1. Dalla data di entrata in vigore del presente codice sono abrogati:

- a) la legge 31 dicembre 1996, n. 675;
- b) la legge 3 novembre 2000, n. 325;
- c) il decreto legislativo 9 maggio 1997, n. 123;
- d) il decreto legislativo 28 luglio 1997, n. 255;
- e) l'articolo 1 del decreto legislativo 8 maggio 1998, n. 135;
- f) il decreto legislativo 13 maggio 1998, n. 171;
- g) il decreto legislativo 6 novembre 1998, n. 389;
- h) il decreto legislativo 26 febbraio 1999, n. 51;
- i) il decreto legislativo 11 maggio 1999, n. 135;
- l) il decreto legislativo 30 luglio 1999, n. 281, ad eccezione degli articoli 8, comma 1, 11 e 12;
- m) il decreto legislativo 30 luglio 1999, n. 282;
- n) il decreto legislativo 28 dicembre 2001, n. 467;
- o) il decreto del Presidente della Repubblica 28 luglio 1999, n. 318.

2. Dalla data di entrata in vigore del presente codice sono abrogati gli articoli 12, 13, 14, 15, 16, 17, 18, 19 e 20 del decreto del Presidente della Repubblica 31 marzo 1998, n. 501.

3. Dalla data di entrata in vigore del presente codice sono o restano, altresi', abrogati:

- a) l'art. 5, comma 9, del decreto del Ministro della sanita' 18 maggio 2001, n. 279, in materia di malattie rare;
- b) l'articolo 12 della legge 30 marzo 2001, n. 152;
- c) l'articolo 4, comma 3, della legge 6 marzo 2001, n. 52, in materia di donatori midollo osseo;
- d) l'articolo 16, commi 2 e 3, del decreto del Presidente della Repubblica 28 dicembre 2000, n. 445, in materia di certificati di assistenza al parto;
- e) l'art. 2, comma 5, del decreto del Ministro della sanita' 27 ottobre 2000, n. 380, in materia di flussi informativi sui dimessi dagli istituti di ricovero;
- f) l'articolo 2, comma 5-quater 1, secondo e terzo periodo, del decreto-legge 28 marzo 2000, n. 70, convertito, con modificazioni, dalla legge 26 maggio 2000, n. 137, e successive modificazioni, in materia di banca dati sinistri in ambito assicurativo;
- g) l'articolo 6, comma 4, del decreto legislativo 5 giugno 1998, n. 204, in materia di diffusione di dati a fini di ricerca e collaborazione in campo scientifico e tecnologico;
- h) l'articolo 330-bis del decreto legislativo 16 aprile 1994, n. 297, in materia di diffusione di dati relativi a studenti;
- i) l'articolo 8, quarto comma, e l'articolo 9, quarto comma, della legge 1 aprile 1981, n. 121.

4. Dalla data in cui divengono efficaci le disposizioni del codice di deontologia e di buona condotta di cui all'articolo 118, i termini di conservazione dei dati personali individuati ai sensi dell'articolo 119, eventualmente previsti da norme di legge o di regolamento, si osservano nella misura indicata dal medesimo codice.

## CAPO IV - NORME FINALI

### Art. 184.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 185.

((ARTICOLO ABROGATO DAL D.LGS. 10 AGOSTO 2018, N. 101))

### Art. 186. - (Entrata in vigore)

1. Le disposizioni di cui al presente codice entrano in vigore il 1 gennaio 2004, ad eccezione delle disposizioni di cui agli articoli 156, 176, commi 3, 4, 5 e 6, e 182, che entrano in vigore il giorno successivo alla data di pubblicazione del presente codice. Dalla medesima data si osservano altresi' i termini in materia di ricorsi di cui agli articoli 149, comma 8, e 150, comma 2.


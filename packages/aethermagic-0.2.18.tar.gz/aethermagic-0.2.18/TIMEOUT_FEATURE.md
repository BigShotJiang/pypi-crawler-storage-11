# AetherTask Timeout Feature

## Описание

В версии 0.2.17 добавлена поддержка timeout механизма для AetherTask. Теперь можно отслеживать "зависшие" задачи, которые не отвечают после выполнения `perform()`.

## Новые параметры

### `timeout` (int, default=300)
Время ожидания ответа в секундах. По умолчанию 5 минут (300 секунд).

### `on_timeout` (callable, optional)
Callback функция, которая вызывается при истечении timeout. Получает аргумент `task` (экземпляр AetherTask).

## Использование

```python
import asyncio
from aethermagic import AetherTask

async def handle_timeout(task):
    print(f"Задача {task.tid_()} не отвечает уже {task.timeout_()} секунд!")
    # Можно отправить уведомление, перезапустить задачу и т.д.

async def handle_perform(task, data):
    print(f"Обрабатываем задачу: {task.tid_()}")
    # Симуляция долгой работы
    await asyncio.sleep(2)
    await task.status(50, {"message": "В процессе"})
    await asyncio.sleep(2)  
    await task.complete(True, {"result": "готово"})

# Создание задачи с timeout
task = AetherTask(
    job="my-service",
    task="long-running-task", 
    timeout=10,  # 10 секунд
    on_timeout=handle_timeout,
    on_perform=handle_perform
)

# Выполнение задачи
await task.perform({"input": "data"})
```

## Поведение

1. **Запуск таймера**: Timeout таймер запускается автоматически после вызова `perform()`

2. **Сброс таймера**: Таймер НЕ перезапускается при получении `status()` - он продолжает идти до `complete()` или истечения времени

3. **Отмена таймера**: Таймер автоматически отменяется при вызове `complete()` или `cancel_timeout()`

4. **Обновление активности**: Время последней активности обновляется при вызове `status()` (для будущих расширений функциональности)

## Дополнительные методы

- `task.timeout_()` - получить текущее значение timeout
- `task.set_timeout_(seconds)` - установить новое значение timeout  
- `task.cancel_timeout_()` - отменить timeout (синхронная версия)
- `await task.cancel_timeout()` - отменить timeout (асинхронная версия)

## Протоколы

Timeout механизм работает со всеми поддерживаемыми протоколами:
- MQTT
- Redis  
- WebSocket
- ZeroMQ
- RabbitMQ

## Примеры использования

### Мониторинг зависших задач
```python
async def timeout_handler(task):
    print(f"⚠️ Задача {task.tid_()} зависла!")
    # Логирование, уведомления, перезапуск...
    
task = AetherTask(
    job="data-processor",
    task="heavy-computation",
    timeout=300,  # 5 минут
    on_timeout=timeout_handler,
    on_perform=process_data
)
```

### Короткий timeout для быстрых задач
```python
task = AetherTask(
    job="api-service", 
    task="quick-check",
    timeout=30,  # 30 секунд
    on_timeout=lambda task: print(f"Быстрая задача {task.tid_()} не отвечает!"),
    on_perform=quick_check
)
```

### Отключение timeout
```python
# Timeout = 0 отключает механизм
task = AetherTask(
    job="background-service",
    task="infinite-loop", 
    timeout=0,  # Отключён
    on_perform=background_work
)
```

## Технические детали

- Timeout реализован через `asyncio.create_task()` и `asyncio.sleep()`
- При копировании задачи (`task.copy()`) timeout параметры тоже копируются
- Timeout таймер отменяется при получении `complete` действий от других worker'ов
- Механизм работает независимо от протокола коммуникации

## Совместимость

Новые параметры опциональны и не нарушают существующий код. Старые версии AetherTask продолжают работать без изменений.
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name='datagig',
    version='0.1.0',
    author='Arı Bilgi',
    author_email='aribilgiogr@gmail.com',
    description='A comprehensive data preprocessing library',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/aribilgiogr/datagig',
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3"
    ],
    python_requires=">=3.10",
    install_requires=[
        "numpy>=2.3.4",
        "pandas>=2.3.3",
        "scikit-learn>=1.7.2",
        "scipy>=1.16.3"
    ]
)

from typing import Optional, List

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import IsolationForest


class OutlierDetector:
    """Detect and handle outliers in datasets"""

    def __init__(self, method: str = 'iqr', threshold: float = 1.5):
        """
        Initialize OutlierDetector

        Args:
            method: Detection method ('iqr','zscore', 'isolation_forest')
            threshold: Threshold for outlier detection (1.5 for IQR, 3 for Z-score)
        """

        self.method = method
        self.threshold = threshold
        self.model = None

    def detect(self, df: pd.DataFrame, columns: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Detect outliers in the dataset

        Returns:
            DataFrame with boolean values indicating outliers
        """

        cols = columns or df.select_dtypes(include=[np.number]).columns.toList()
        outliers = pd.DataFrame(False, index=df.index, columns=cols)

        for col in cols:
            series = df[col]
            match self.method:
                case 'iqr':
                    Q1 = series.quantile(.25)
                    Q3 = series.quantile(.75)
                    IQR = Q3 - Q1
                    lower_bound = Q1 - self.threshold * IQR
                    upper_bound = Q3 + self.threshold * IQR
                    outliers[col] = (series < lower_bound) | (series > upper_bound)
                case 'zscore':
                    z_scores = np.abs(stats.zscore(series.dropna()))
                    scores = pd.Series(False, index=series.index)
                    scores[series.notna()] = z_scores > self.threshold
                    outliers[col] = scores
                case 'isolation_forest':
                    model = IsolationForest(contamination=.1, random_state=42)
                    predictions = model.fit_predict(series.values.reshape(-1, 1))
                    outliers[col] = pd.Series(predictions == -1, index=series.index)
                case _:
                    raise ValueError(f"Unknown method: {self.method}")

        return outliers

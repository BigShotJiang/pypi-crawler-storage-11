from typing import Optional, List

import numpy as np
import pandas as pd
from sklearn.impute import KNNImputer, SimpleImputer


class MissingHandler:
    """Handle missing values in dataset"""

    def __init__(self, strategy: str = 'mean', columns: Optional[List[str]] = None):
        """
        Initialize MissingHandler

        Args:
            strategy: Imputation strategy ('mean', 'median', 'mode', 'constant_zero', 'knn', 'drop')
            columns: Specific columns to apply imputation (None for all numeric columns)
        """
        self.strategy = strategy
        self.columns = columns
        self.imputer = None

    def fit(self, df: pd.DataFrame) -> 'MissingHandler':
        """Fit the imputer on the data"""
        if self.strategy == 'drop':
            return self

        cols = self.columns or df.select_dtypes(include=[np.number]).columns.toList()

        if self.strategy == 'knn':
            self.imputer = KNNImputer(n_neighbors=5)
        elif self.strategy in ['mean', 'median']:
            self.imputer = SimpleImputer(strategy=self.strategy)
        elif self.strategy == 'mode':
            self.imputer = SimpleImputer(strategy='most_frequent')
        elif self.strategy == 'constant_zero':
            self.imputer = SimpleImputer(strategy='constant', fill_value=0)
        else:
            raise ValueError(f"Unknown strategy: {self.strategy}")

        self.imputer.fit(df[cols])
        self._fit_columns = cols
        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Transform the data by handling missing values"""
        df_copy = df.copy()
        if self.strategy == "drop":
            return df_copy.dropna(subset=self.columns) if self.columns else df_copy.dropna()

        cols = self._fit_columns
        df_copy[cols] = self.imputer.transform(df_copy[cols])
        return df_copy

    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Fit and transform in one step"""
        return self.fit(df).transform(df)

    def summary(self, df: pd.DataFrame) -> pd.DataFrame:
        """Get summary of missing values"""
        missing_count = df.isnull().sum()
        missing_pct = (missing_count / len(df)) * 100
        result = pd.DataFrame({
            'Missing_Count': missing_count,
            'Missing_Percent': missing_pct
        })

        return result[result['Missing_Count'] > 0].sort_values('Missing_Count', ascending=False)

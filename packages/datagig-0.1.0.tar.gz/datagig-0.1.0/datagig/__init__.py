"""
DataGig - A comprehensive data preprocessing library
"""

__version__ = "0.1.0"

from .missing import MissingHandler
from .outliers import OutlierDetector

__all__ = [
    'MissingHandler',
    'OutlierDetector'
]

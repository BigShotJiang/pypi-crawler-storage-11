"""webbed_duck package."""

__all__ = ["__version__"]
__version__ = "0.33.0"

# Aurica S3 Storage Documentation

## Overview

Aurica uses **AWS S3** for persistent data storage in serverless/production environments where local file storage doesn't persist across deployments (like Vercel, AWS Lambda, etc.).

## S3 Configuration

### Environment Variables

```bash
# S3 Bucket Configuration
S3_USER_DATA_BUCKET=pingg-me.shop          # S3 bucket name
S3_USER_DATA_FOLDER=base-ng-folder         # Folder prefix in bucket
S3_REGION=ap-south-1                       # AWS region

# S3 Credentials
S3_ACCESS_KEY_ID=your-access-key           # AWS access key
S3_SECRET_ACCESS_KEY=your-secret-key       # AWS secret key

# Control Flags
USE_S3_STORAGE=true                        # Force S3 usage (auto-detected in serverless)
IS_AUTH_SERVER=true                        # Mark this instance as auth server
```

### Auto-Detection

S3 storage is automatically enabled when running in:
- **Vercel** (`VERCEL=1`)
- **AWS Lambda** (`AWS_LAMBDA_FUNCTION_NAME` set)
- **Manual override** (`USE_S3_STORAGE=true`)

## S3 Storage Location

**Bucket Structure:**
```
s3://pingg-me.shop/
└── base-ng-folder/
    ├── users.json           # User accounts and passkey credentials
    ├── sessions.json        # Active user sessions
    └── jwt_secret.json      # JWT signing secret key
```

## What is Stored in S3?

### 1. 👥 User Accounts (`users.json`)

**Purpose**: Store user registration data and passkey credentials for authentication

**Used By**: 
- `apps/auth-app/be/api/passkey_store.py` (PasskeyStore class)

**When Used**:
- **Auth Server Only** (`IS_AUTH_SERVER=true`)
- Loaded on auth server startup
- Updated when users register or add new passkeys
- Synced across auth server restarts

**Data Structure**:
```json
{
  "users": [
    {
      "user_id": "uuid-string",
      "username": "john_doe",
      "email": "john@example.com",
      "display_name": "John Doe",
      "role": "user",
      "mobile_number": "+1234567890",
      "mobile_verified": true,
      "credentials": [
        {
          "credential_id": "base64-encoded-bytes",
          "public_key": "base64-encoded-bytes",
          "sign_count": 0,
          "transports": ["usb", "nfc"],
          "created_at": "2025-01-01T00:00:00",
          "device_type": "mobile",
          "aaguid": "base64-encoded-bytes"
        }
      ],
      "created_at": "2025-01-01T00:00:00"
    }
  ]
}
```

**Operations**:
- **Load**: On auth server startup - `s3_storage.load_json('users.json')`
- **Save**: After user registration/credential updates - `s3_storage.save_json('users.json', data)`

**Code Location**:
```python
# apps/auth-app/be/api/passkey_store.py
class PasskeyStore:
    def __init__(self):
        if self.is_auth_server:
            self.s3_storage = S3Storage()
            self._load_from_storage()  # Loads users.json from S3
    
    def _save_to_storage(self):
        self.s3_storage.save_json('users.json', {'users': users_data})
```

---

### 2. 🔐 User Sessions (`sessions.json`)

**Purpose**: Store active user sessions with cookies for cookie-based authentication

**Used By**:
- `aurica-base-be/src/auth_middleware.py` (SessionManager class)

**When Used**:
- **All Server Instances** (both auth server and API execution providers)
- Loaded on server startup
- Updated when users login/logout
- Cleaned up periodically (expired sessions removed)
- Synced every 30 seconds to S3

**Data Structure**:
```json
{
  "sessions": {
    "session-token-uuid": {
      "user_id": "user-uuid",
      "username": "john_doe",
      "email": "john@example.com",
      "created_at": "2025-01-01T00:00:00",
      "last_accessed": "2025-01-01T01:00:00",
      "expires_at": "2025-01-08T00:00:00"
    }
  }
}
```

**Operations**:
- **Load**: On server startup - `storage.load_json('sessions.json')`
- **Save**: Every 30 seconds via background task - `storage.save_json('sessions.json', data)`
- **Cleanup**: Expired sessions removed before saving

**Code Location**:
```python
# aurica-base-be/src/auth_middleware.py
class SessionManager:
    def __init__(self):
        self._storage = s3_storage.S3Storage()
        self._load_sessions()  # Loads sessions.json from S3
    
    def _save_sessions(self):
        self._storage.save_json('sessions.json', {'sessions': sessions_data})
    
    # Background task runs every 30 seconds
    @periodic_task(seconds=30)
    def sync_sessions_to_storage(self):
        self.cleanup_expired_sessions()
        self._save_sessions()
```

---

### 3. 🔑 JWT Secret Key (`jwt_secret.json`)

**Purpose**: Store the shared secret key used to sign and verify JWT tokens

**Used By**:
- `apps/auth-app/be/api/jwt_utils.py` (JWTManager class)

**When Used**:
- **Auth Server Only** (`IS_AUTH_SERVER=true`)
- Loaded on auth server startup
- Generated if doesn't exist
- Shared across all auth server instances
- API execution providers fetch it via JWKS endpoint instead

**Data Structure**:
```json
{
  "secret_key": "random-secure-string-32-bytes",
  "created_at": "2025-01-01T00:00:00",
  "algorithm": "HS256",
  "key_type": "shared_secret"
}
```

**Operations**:
- **Load**: On auth server startup - `storage.load_json('jwt_secret.json')`
- **Save**: Once when first generated - `storage.save_json('jwt_secret.json', data)`
- **Fetch**: API providers get it from `https://auth-server/.well-known/jwks.json` endpoint

**Code Location**:
```python
# apps/auth-app/be/api/jwt_utils.py
class JWTManager:
    def __init__(self):
        if self.is_auth_server:
            self.storage = s3_storage.S3Storage()
            self._load_or_generate_secret()  # Loads jwt_secret.json from S3
    
    def _generate_new_secret(self):
        secret_data = {
            'secret_key': secrets.token_urlsafe(32),
            'created_at': datetime.utcnow().isoformat(),
            'algorithm': 'HS256'
        }
        self.storage.save_json('jwt_secret.json', secret_data)
```

---

## Server Roles and S3 Usage

### 🔐 Auth Server (`IS_AUTH_SERVER=true`)

**Responsibilities**:
- User registration and login
- Generate and sign JWT tokens
- Store user accounts
- Manage JWT secret key

**S3 Files Used**:
- ✅ `users.json` - Read/Write user accounts
- ✅ `sessions.json` - Read/Write sessions
- ✅ `jwt_secret.json` - Read/Write JWT secret

**Example**: Production auth server at `api.oneaurica.com`

---

### 🔓 API Execution Provider (`IS_AUTH_SERVER=false`)

**Responsibilities**:
- Execute app APIs for authenticated users
- Verify JWT tokens (using JWKS from auth server)
- Redirect users to cloud auth server for login
- No local user storage needed

**S3 Files Used**:
- ❌ `users.json` - NOT used (users managed on cloud)
- ⚠️  `sessions.json` - Optional (in-memory is sufficient for single instance)
- ❌ `jwt_secret.json` - NOT used (fetches from auth server JWKS)

**Examples**: 
- Local development server (`localhost:8000`)
- Regional API servers (US, EU, Asia)
- Private/on-premise installations
- Edge computing nodes

**Key Point**: These servers don't need S3 credentials. Users authenticate via cloud, APIs execute locally.

---

## S3Storage Class API

### Initialization

```python
from s3_storage import S3Storage

storage = S3Storage()
# Reads from environment: S3_USER_DATA_BUCKET, S3_USER_DATA_FOLDER, etc.
```

### Methods

#### `load_json(filename: str) -> Optional[dict]`
Load JSON data from S3.

```python
data = storage.load_json('users.json')
# Returns dict if found, None if not found or error
```

#### `save_json(filename: str, data: dict) -> bool`
Save JSON data to S3.

```python
success = storage.save_json('users.json', {'users': [...]})
# Returns True if successful, False on error
```

#### `delete_file(filename: str) -> bool`
Delete a file from S3.

```python
success = storage.delete_file('old_data.json')
```

#### `list_files() -> list`
List all files in the S3 folder.

```python
files = storage.list_files()
# Returns: ['users.json', 'sessions.json', 'jwt_secret.json']
```

#### `get_key(filename: str) -> str`
Get the full S3 key path.

```python
key = storage.get_key('users.json')
# Returns: 'base-ng-folder/users.json'
```

---

## Development vs Production

### Local API Server (No S3 Credentials)

```bash
# No S3 credentials needed for API execution providers
# Users login via centralized cloud auth server
# JWT tokens verified locally
```

**Behavior**:
- Sessions: In-memory only (sufficient for single-instance API servers)
- Users: Managed on cloud auth server (`api.oneaurica.com`)
- JWT Secret: Fetched from cloud auth server via JWKS
- User Authentication: Redirects to cloud for login, verifies tokens locally

**Console Output**:
```
💾 S3 credentials not found - using in-memory session storage
   Sessions will be lost on server restart
🔓 PasskeyStore: Running as regular host - no user data needed (JWT verification only)
🔓 JWTManager: Running as API EXECUTION PROVIDER
   - Redirect users to auth server for login
   - Verify tokens using JWKS from auth server
   - Execute APIs for authenticated users
✅ Successfully fetched JWT secret from auth server
```

**Use Case**: Local/regional API servers that execute app logic for authenticated users. Users login via cloud, tokens verified locally.

---

### Production/Serverless (S3 Enabled)

```bash
# Required environment variables for CENTRALIZED AUTH SERVER only
S3_ACCESS_KEY_ID=...
S3_SECRET_ACCESS_KEY=...
S3_USER_DATA_BUCKET=pingg-me.shop
S3_USER_DATA_FOLDER=base-ng-folder
IS_AUTH_SERVER=true  # Only on the ONE centralized auth server
```

**Behavior**:
- Sessions: Persisted in S3, synced every 30s
- Users: Persisted in S3 (auth server only)
- JWT Secret: Persisted in S3 (auth server only)

**Use Case**: The ONE centralized cloud authentication server at `api.oneaurica.com` where users register and login.

---

## Architecture Overview

### Centralized Authentication Model

```
┌─────────────────────────────────────────────────────────────┐
│                   CLOUD AUTH SERVER                          │
│               (api.oneaurica.com)                            │
│                                                              │
│  • IS_AUTH_SERVER=true                                       │
│  • S3 Storage: users.json, sessions.json, jwt_secret.json  │
│  • User Registration & Login                                │
│  • JWT Token Generation                                      │
│  • Exposes JWKS endpoint                                     │
└─────────────────────────────────────────────────────────────┘
                            ↓ JWKS
                     (JWT Secret Key)
                            ↓
    ┌───────────────────────┼───────────────────────┐
    ↓                       ↓                       ↓
┌─────────┐         ┌─────────┐           ┌─────────┐
│ Local   │         │Regional │           │Regional │
│ Server  │         │ Server  │           │ Server  │
│ (Local) │         │  (US)   │           │  (EU)   │
├─────────┤         ├─────────┤           ├─────────┤
│ No S3   │         │ No S3   │           │ No S3   │
│ Memory  │         │ Memory  │           │ Memory  │
│ Storage │         │ Storage │           │ Storage │
└─────────┘         └─────────┘           └─────────┘
     ↑                   ↑                     ↑
     │                   │                     │
  Users login via cloud, execute APIs locally
```

### User Login Flow

1. **User opens local app** (e.g., `localhost:8000/chat-app`)
2. **Local server checks authentication** - No valid JWT
3. **Redirects to cloud auth server** (`api.oneaurica.com/auth-app`)
4. **User logs in on cloud** with passkey/credentials
5. **Cloud generates JWT token** signed with secret from S3
6. **Token sent back to local app**
7. **Local server verifies token** using JWKS from cloud
8. **User can now use local APIs** with verified authentication

### Why This Architecture?

✅ **Single Source of Truth**: All users managed in one place (cloud)  
✅ **No Local User Data**: API servers don't need S3 or user databases  
✅ **Scalable**: Add API servers anywhere without data sync  
✅ **Secure**: Only auth server has user credentials  
✅ **Simple**: Local servers just verify tokens, no auth logic  

---

## Data Flow Diagram

### User Registration Flow

```
User → auth-app/register → PasskeyStore (in-memory)
                                ↓
                          Save to users.json
                                ↓
                          S3: base-ng-folder/users.json
```

### Session Creation Flow

```
User → auth-app/login → SessionManager.create_session()
                              ↓
                    Store in _sessions (in-memory)
                              ↓
                    Background task (every 30s)
                              ↓
                    Save to sessions.json
                              ↓
                    S3: base-ng-folder/sessions.json
```

### JWT Token Verification Flow

```
API Request with JWT → auth_middleware.py
                            ↓
                    JWTManager.verify_token()
                            ↓
            Is this auth server? → YES → Use local secret
                            ↓
                           NO
                            ↓
                    Fetch JWKS from auth server
                            ↓
            Cache secret and verify token
```

---

## File Locations

### S3 Storage Implementation
```
apps/auth-app/be/api/s3_storage.py
```

### Usage Locations

1. **User Storage**
   - `apps/auth-app/be/api/passkey_store.py` (lines 81-184)

2. **Session Storage**
   - `aurica-base-be/src/auth_middleware.py` (lines 66, 86, 124)

3. **JWT Secret Storage**
   - `apps/auth-app/be/api/jwt_utils.py` (lines 84, 127-148)

---

## Security Considerations

### 🔒 Credentials
- **Never commit** S3 credentials to git
- Store in `.env` file (git-ignored)
- Use IAM roles with minimal permissions in production

### 🔐 Data Encryption
- S3 server-side encryption (SSE-S3) recommended
- Enable bucket versioning for backup/recovery
- Restrict bucket access to specific IAM roles

### 🔑 JWT Secret
- Generated once, persisted in S3
- Shared across all auth server instances
- If compromised, regenerate (invalidates all tokens)
- Use environment variable override for rotation:
  ```bash
  JWT_SECRET_KEY=new-secret-here
  ```

### 👥 User Data
- Contains sensitive passkey credential data
- Only accessible by auth server
- Backup regularly (S3 versioning or separate backup)

---

## Troubleshooting

### ❌ "Error loading sessions.json from S3: Unable to locate credentials"

**Cause**: S3Storage was initialized but credentials are missing/invalid

**Solution**:
```bash
# Option 1: Add S3 credentials to .env
S3_ACCESS_KEY_ID=your-key
S3_SECRET_ACCESS_KEY=your-secret

# Option 2: Remove/comment credentials for local dev
# System will automatically use in-memory storage instead
```

**After fix, you'll see**:
```
💾 S3 credentials not found - using in-memory session storage
   Sessions will be lost on server restart
```

---

### ❌ "Failed to initialize S3 client"

**Cause**: Missing or invalid S3 credentials

**Solution**:
```bash
# Check environment variables are set
echo $S3_ACCESS_KEY_ID
echo $S3_SECRET_ACCESS_KEY

# Verify credentials have access to bucket
aws s3 ls s3://pingg-me.shop/base-ng-folder/
```

### ⚠️ "No storage backend available"

**Cause**: Not running in serverless environment and `USE_S3_STORAGE` not set

**Solution**:
```bash
# For local testing with S3
export USE_S3_STORAGE=true
```

### 🔑 "Using temporary JWT secret"

**Cause**: Auth server can't load or save JWT secret from S3

**Solution**:
1. Check S3 credentials
2. Or set explicit secret:
   ```bash
   export JWT_SECRET_KEY=your-fixed-secret-here
   ```

### 📄 "Sessions not persisting across restarts"

**Cause**: S3 storage not initialized or failing to save

**Check**:
```bash
# Should see this on startup:
✅ Session storage initialized with S3
✅ Loaded X active sessions from storage
```

**Solution**: Verify S3 credentials and bucket permissions

---

## Best Practices

### 1. **Environment Separation**
```bash
# Development (localhost)
# No S3 - use in-memory storage

# Staging
S3_USER_DATA_FOLDER=staging-folder

# Production  
S3_USER_DATA_FOLDER=production-folder
```

### 2. **Backup Strategy**
- Enable S3 versioning
- Regular backups to separate bucket
- Test restore procedures

### 3. **Monitoring**
- Monitor S3 API call metrics
- Alert on save failures
- Track session sync latency

### 4. **Performance**
- Sessions synced every 30s (not on every request)
- Users/JWT secret loaded once on startup
- Use S3 connection timeouts (3s connect, 5s read)

---

## Migration Guide

### From Local Files to S3

1. **Set up S3 bucket and credentials**
   ```bash
   export S3_USER_DATA_BUCKET=your-bucket
   export S3_ACCESS_KEY_ID=...
   export S3_SECRET_ACCESS_KEY=...
   ```

2. **Migrate existing data**
   ```python
   # One-time migration script
   from s3_storage import S3Storage
   import json
   
   storage = S3Storage()
   
   # Upload local data
   with open('users.json') as f:
       storage.save_json('users.json', json.load(f))
   ```

3. **Enable S3 storage**
   ```bash
   export USE_S3_STORAGE=true
   ```

4. **Restart servers** and verify data loads correctly

---

## Cost Estimation

### AWS S3 Pricing (ap-south-1)

**Storage**: ~$0.025 per GB/month
- 3 JSON files × ~100KB each = **~0.0003 GB** = **$0.000008/month**

**Requests**:
- PUT: $0.005 per 1,000 requests
- GET: $0.0004 per 1,000 requests

**Estimated Monthly Cost**:
- Sessions sync: 30s × 2,880 (1 day) × 30 days = 86,400 PUTs = **$0.43**
- Server startups: ~100 GETs/month = **$0.00004**
- **Total: ~$0.43/month** (negligible)

---

## Summary

| File | Purpose | Used By | Auth Server | API Provider | Sync Frequency |
|------|---------|---------|-------------|--------------|----------------|
| `users.json` | User accounts & passkeys | PasskeyStore | ✅ R/W | ❌ | On registration |
| `sessions.json` | Active user sessions | SessionManager | ✅ R/W | ⚠️ Memory | Every 30s (if S3) |
| `jwt_secret.json` | JWT signing secret | JWTManager | ✅ R/W | ❌ (via JWKS) | Once on startup |

**Key Points**:
- **ONE centralized auth server** at `api.oneaurica.com` uses S3 for all user data
- **Multiple API execution providers** (local, regional) don't need S3
- Users **login via cloud**, **execute APIs anywhere**
- JWT tokens verified locally using JWKS from cloud
- In-memory sessions sufficient for API servers (lost on restart is acceptable)
- Only the auth server generates tokens, all others just verify
- Scalable: Add API servers anywhere without S3 setup

### Real-World Usage

**Your localhost (`localhost:8000`)**:
- ❌ No S3 credentials needed
- ✅ Users login via `api.oneaurica.com`
- ✅ JWT tokens verified locally
- ✅ Full API functionality
- ✅ Sessions in memory (restart = users re-login, which is fine)

**This is the correct setup for distributed API execution!**

---

**Last Updated**: November 2, 2025  
**Aurica Version**: 1.0.0

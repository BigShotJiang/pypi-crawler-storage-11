# Aurica Storage Documentation App

This app contains comprehensive documentation about Aurica's S3 storage usage.

## 📚 Documentation Files

### [S3_STORAGE_GUIDE.md](./S3_STORAGE_GUIDE.md)
Complete guide covering:
- What data is stored in S3
- When and why S3 is used
- Configuration and environment variables
- Server roles (Auth Server vs API Provider)
- Data structures and file formats
- Code locations and implementation details
- Troubleshooting and best practices
- Cost estimation

## Quick Reference

### S3 Files

| File | Purpose | Size |
|------|---------|------|
| `users.json` | User accounts & passkey credentials | ~50KB |
| `sessions.json` | Active user sessions | ~20KB |
| `jwt_secret.json` | JWT signing secret | ~1KB |

### Environment Variables

```bash
S3_USER_DATA_BUCKET=pingg-me.shop
S3_USER_DATA_FOLDER=base-ng-folder
S3_REGION=ap-south-1
S3_ACCESS_KEY_ID=your-access-key
S3_SECRET_ACCESS_KEY=your-secret-key
USE_S3_STORAGE=true
IS_AUTH_SERVER=true
```

### Storage Location

```
s3://pingg-me.shop/base-ng-folder/
├── users.json           # User data (auth server only)
├── sessions.json        # Sessions (all servers)
└── jwt_secret.json      # JWT secret (auth server only)
```

## Implementation

**S3 Storage Class**: `apps/auth-app/be/api/s3_storage.py`

**Used By**:
1. `apps/auth-app/be/api/passkey_store.py` - User accounts
2. `apps/auth-app/be/api/jwt_utils.py` - JWT secrets
3. `aurica-base-be/src/auth_middleware.py` - Sessions

## When S3 is Used

### ✅ S3 Required (Centralized Auth Server Only)

**ONE instance** - The cloud authentication server (`api.oneaurica.com`):
- Running on Vercel/serverless (`VERCEL=1`)
- Or with `IS_AUTH_SERVER=true`
- Needs S3 for: `users.json`, `sessions.json`, `jwt_secret.json`

### ❌ S3 NOT Required (API Execution Providers)

**All other instances** - Local and regional API servers:
- Running on localhost, private servers, or regional deployments
- No S3 credentials needed
- In-memory session storage sufficient
- Users authenticate via cloud, APIs execute locally

## Architecture

```
        Cloud Auth Server (api.oneaurica.com)
        ↓ S3: users.json, sessions.json, jwt_secret.json
        ↓ Users login here
        ↓ Generates JWT tokens
        ↓
        ↓ JWKS (publishes JWT secret)
        ↓
    ┌───┴────┬────────┬────────┐
    ↓        ↓        ↓        ↓
 Local    US API   EU API   Asia API
 Server   Server   Server   Server
  (No S3)  (No S3)  (No S3)  (No S3)
```

**Users login via cloud, execute APIs anywhere.**

## Cost

Estimated **~$0.43/month** for typical usage (negligible).

---

For complete details, see [S3_STORAGE_GUIDE.md](./S3_STORAGE_GUIDE.md)

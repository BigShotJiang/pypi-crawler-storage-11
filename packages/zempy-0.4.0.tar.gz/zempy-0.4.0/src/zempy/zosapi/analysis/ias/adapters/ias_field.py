from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from zempy.zosapi.analysis.adapters.Message import Message
from zempy.zosapi.analysis.ias.adapters.base_selector import _BaseIASSelector

@dataclass(frozen=True, slots=True)
class IAS_Field(_BaseIASSelector):
    _ias_field: Any

    _iface_attr = "_ias_field"
    _GET_NAME   = "GetFieldNumber"
    _SET_NAME   = "SetFieldNumber"
    _LABEL      = "IAS_Field"
    _USE_ALL_NAME = "UseAllFields"

    def use_all(self) -> Message:
        return self._call_msg(self.__class__._USE_ALL_NAME)  # type: ignore[arg-type]


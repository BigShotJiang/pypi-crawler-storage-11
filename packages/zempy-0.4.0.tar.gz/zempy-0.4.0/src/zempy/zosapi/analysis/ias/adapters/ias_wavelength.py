from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from zempy.zosapi.analysis.adapters.Message import Message
from zempy.zosapi.analysis.ias.adapters.base_selector import _BaseIASSelector

@dataclass(frozen=True, slots=True)
class IAS_Wavelength(_BaseIASSelector):
    _ias_wavelength: Any

    _iface_attr = "_ias_wavelength"
    _GET_NAME   = "GetWavelengthNumber"
    _SET_NAME   = "SetWavelengthNumber"
    _LABEL      = "IAS_Wavelength"
    _USE_ALL_NAME = "UseAllWavelengths"

    def use_all(self) -> Message:
        return self._call_msg(self.__class__._USE_ALL_NAME)  # type: ignore[arg-type]

from __future__ import annotations
from zempy.zosapi.analysis.adapters.ia import IA
from zempy.zosapi.analysis.enums.analysisIDM import AnalysisIDM
from zempy.zosapi.analysis.adapters.analysis_registry import register_analysis


@register_analysis(AnalysisIDM.FftPsf)
class FFTPSF(IA):

    def __str__(self) -> str:
        return f"FFT PSF settings={self.settings}"



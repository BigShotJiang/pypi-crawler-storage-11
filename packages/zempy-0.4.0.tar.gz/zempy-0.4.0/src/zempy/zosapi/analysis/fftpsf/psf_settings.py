from __future__ import annotations
from typing import Any

from zempy.zosapi.analysis.fftpsf.psf_sampling import PsfSampling
from zempy.zosapi.analysis.fftpsf.psf_rotation import PsfRotation
from zempy.zosapi.analysis.fftpsf.fft_psf_type import FftPsfType

from zempy.zosapi.analysis.ias.adapters.ias import IAS
from zempy.zosapi.analysis.ias.adapters.registry import register_settings
from zempy.zosapi.analysis.enums.analysisIDM import AnalysisIDM
from zempy.zosapi.analysis.fftpsf.protocols.IAS_FftPsf import IAS_FftPsf

from zempy.zosapi.core.property_scalar import PropertyScalar
from zempy.zosapi.core.property_enum import property_enum


@register_settings(AnalysisIDM.FftPsf)
class PSFSettings(IAS[IAS_FftPsf]):
    # Require the standard IAS sub-interfaces + FFT-PSF specific members
    REQUIRED_NATIVE_ATTRS = IAS.REQUIRED_NATIVE_ATTRS + (
        "SampleSize",
        "OutputSize",
        "Rotation",
        "Type",
        "ImageDelta",
        "UsePolarization",
        "Normalize",
    )

    # --- scalar/enum descriptors ---
    SampleSize      = property_enum("SampleSize", PsfSampling,  label="IAS_FftPsf")
    OutputSize      = property_enum("OutputSize", PsfSampling,  label="IAS_FftPsf")
    Rotation        = property_enum("Rotation",   PsfRotation,  label="IAS_FftPsf")
    Type            = property_enum("Type",       FftPsfType,    label="IAS_FftPsf")

    ImageDelta      = PropertyScalar("ImageDelta",      coerce_get=float, coerce_set=float)
    UsePolarization = PropertyScalar("UsePolarization", coerce_get=bool,  coerce_set=bool)
    Normalize       = PropertyScalar("Normalize",       coerce_get=bool,  coerce_set=bool)

    # Shim for current property_enum impl, which calls self._ensure_native
    def _ensure_native(self) -> None:  # remove once property_enum uses maybe_ensure/ensure_native
        self.ensure_native()

    # Native coercion hook (same behavior as before)
    @staticmethod
    def _coerce_native(base: Any) -> Any:
        cast_fn = getattr(base, "As_ZOSAPI_Analysis_Settings_Psf_IAS_FftPsf", None)
        if callable(cast_fn):
            obj = cast_fn()
            if obj is not None:
                return obj
        return getattr(base, "__implementation__", base)

    NATIVE_COERCER = _coerce_native

    def __str__(self) -> str:
        # Uses new IAS base names: Field / Wavelength / Surface
        return (
            "PSF settings:(\n"
            f"  field={self.Field},\n"
            f"  wavelength={self.Wavelength},\n"
            f"  image_surface={self.Surface},\n"
            f"  sample_size={self.SampleSize.name},\n"
            f"  output_size={self.OutputSize.name},\n"
            f"  rotation={self.Rotation.name},\n"
            f"  image_delta={self.ImageDelta},\n"
            f"  use_polarization={self.UsePolarization},\n"
            f"  normalize={self.Normalize},\n"
            f"  psf_type={self.Type.name}\n"
            ")"
        )

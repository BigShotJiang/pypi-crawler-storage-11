from zempy.zosapi.core import ZosEnumBase

class RayStatus(ZosEnumBase):
    """Enumeration: ZOSAPI.Tools.RayTrace.RayStatus"""

    Parent           = 0
    Terminated       = 1
    Reflected        = 2
    Transmitted      = 3
    Scattered        = 4
    Diffracted       = 5
    GhostedFrom      = 6
    DiffractedFrom   = 7
    ScatteredFrom    = 8
    RayError         = 9
    BulkScattered    = 10
    WaveShifted      = 11
    TIR              = 12
    OrdinaryRay      = 13
    ExtraordinaryRay = 14
    WaveShiftPL      = 15


# Register native ZOSAPI enum path for interop
RayStatus._NATIVE_PATH = "ZOSAPI.Tools.RayTrace.RayStatus"
RayStatus._ALIASES_EXTRA = {}

__all__ = ["RayStatus"]

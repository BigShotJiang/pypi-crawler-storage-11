from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class HPCNodeSize(ZosEnumBase):
    DEFAULT = 0
    TINY = 1
    SMALL = 2
    MEDIUM = 3
    LARGE = 4
    X_LARGE = 5

# attach config AFTER class creation (safe from Enum)
HPCNodeSize._NATIVE_PATH = "ZOSAPI.Tools.HPCNodeSize"
HPCNodeSize._ALIASES_EXTRA = {
    "DEFAULT": ("Default",),
    "TINY": ("Tiny",),
    "SMALL": ("Small",),
    "MEDIUM": ("Medium",),
    "LARGE": ("Large",),
    "X_LARGE": ("XLarge",),
}

__all__ = ["HPCNodeSize"]

from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class RayPatternOption(ZosEnumBase):
    XY_FAN = 0
    X_FAN = 1
    Y_FAN = 2
    CHIEF_AND_RING = 3
    LIST = 4
    GRID = 5
    CHIEF_AND_MARGINALS = 6

# attach config AFTER class creation (safe from Enum)
RayPatternOption._NATIVE_PATH = "ZOSAPI.Tools.RayPatternOption"
RayPatternOption._ALIASES_EXTRA = {
    "XY_FAN": ("XyFan",),
    "X_FAN": ("XFan",),
    "Y_FAN": ("YFan",),
    "CHIEF_AND_RING": ("ChiefAndRing",),
    "LIST": ("List",),
    "GRID": ("Grid",),
    "CHIEF_AND_MARGINALS": ("ChiefAndMarginals",),
}

__all__ = ["RayPatternOption"]

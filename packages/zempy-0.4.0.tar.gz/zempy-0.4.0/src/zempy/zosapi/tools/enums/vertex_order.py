from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class VertexOrder(ZosEnumBase):
    FIRST = 0
    SECOND = 1
    THIRD = 2

# attach config AFTER class creation (safe from Enum)
VertexOrder._NATIVE_PATH = "ZOSAPI.Tools.VertexOrder"
VertexOrder._ALIASES_EXTRA = {
    "FIRST": ("First",),
    "SECOND": ("Second",),
    "THIRD": ("Third",),
}

__all__ = ["VertexOrder"]

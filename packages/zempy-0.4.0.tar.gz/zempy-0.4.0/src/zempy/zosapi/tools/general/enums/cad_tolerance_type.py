from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class CADToleranceType(ZosEnumBase):
    N_TEN_E_MINUS4 = 0
    N_TEN_E_MINUS5 = 1
    N_TEN_E_MINUS6 = 2
    N_TEN_E_MINUS7 = 3

# attach config AFTER class creation (safe from Enum)
CADToleranceType._NATIVE_PATH = "ZOSAPI.Tools.General.CADToleranceType"
CADToleranceType._ALIASES_EXTRA = {
    "N_TEN_E_MINUS4": ("NTenEMinus4",),
    "N_TEN_E_MINUS5": ("NTenEMinus5",),
    "N_TEN_E_MINUS6": ("NTenEMinus6",),
    "N_TEN_E_MINUS7": ("NTenEMinus7",),
}

__all__ = ["CADToleranceType"]
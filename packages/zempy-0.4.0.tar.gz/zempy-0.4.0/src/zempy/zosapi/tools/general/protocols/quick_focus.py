from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, runtime_checkable
from zempy.zosapi.tools.protocols.system_tool import ISystemTool, RunResult
from zempy.zosapi.tools.general.enums.quick_focus_criterion import QuickFocusCriterion


@dataclass(frozen=True)
class QuickFocusSettings:
    criterion: QuickFocusCriterion
    use_centroid: bool = True

@runtime_checkable
class IQuickFocus(ISystemTool, Protocol):
    """Python-facing contract for ZOSAPI.Tools.General.IQuickFocus."""


    def __enter__(self) -> IQuickFocus: ...
    def __exit__(self, exc_type, exc, tb) -> None: ...

    def run_and_wait_for_completion(self) -> bool: ...
    def close(self) -> bool: ...

    # quick-focus specific properties
    @property
    def use_centroid(self) -> bool: ...
    @use_centroid.setter
    def use_centroid(self, value: bool) -> None: ...

    @property
    def criterion(self) -> QuickFocusCriterion: ...
    @criterion.setter
    def criterion(self, value: QuickFocusCriterion) -> None: ...

    # !!! Extra method not in zosapi
    def run_with_settings(
        self,
        settings: QuickFocusSettings | None = None,
        timeout_s: float | None = None,
    ) -> RunResult: ...

from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class ScaleToUnits(ZosEnumBase):
    MILLIMETERS = 0
    CENTIMETERS = 1
    INCHES = 2
    METERS = 3

# attach config AFTER class creation (safe from Enum)
ScaleToUnits._NATIVE_PATH = "ZOSAPI.Tools.General.ScaleToUnits"
ScaleToUnits._ALIASES_EXTRA = {
    "MILLIMETERS": ("Millimeters",),
    "CENTIMETERS": ("Centimeters",),
    "INCHES": ("Inches",),
    "METERS": ("Meters",),
}

__all__ = ["ScaleToUnits"]
from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class CADAngularToleranceType(ZosEnumBase):
    LOW = 0
    MEDIUM = 1
    HIGH = 2
    PRESENTATION = 3

# attach config AFTER class creation (safe from Enum)
CADAngularToleranceType._NATIVE_PATH = "ZOSAPI.Tools.General.CADAngularToleranceType"
CADAngularToleranceType._ALIASES_EXTRA = {
    "LOW": ("Low",),
    "MEDIUM": ("Medium",),
    "HIGH": ("High",),
    "PRESENTATION": ("Presentation",),
}

__all__ = ["CADAngularToleranceType"]
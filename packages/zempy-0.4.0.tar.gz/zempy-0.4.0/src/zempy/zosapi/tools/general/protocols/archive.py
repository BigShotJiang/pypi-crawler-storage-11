from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, runtime_checkable, Optional
from zempy.zosapi.tools.protocols.system_tool import ISystemTool
from zempy.zosapi.tools.general.enums.entry_compression_modes import EntryCompressionModes
from zempy.zosapi.tools.general.enums.archive_file_status import ArchiveFileStatus

@dataclass(frozen=True)
class ArchiveCreateOptions:
    zar_path: str
    compression: EntryCompressionModes = EntryCompressionModes.AUTO
    include_samples: bool = False

@dataclass(frozen=True)
class ArchiveRestoreResult:
    status: ArchiveFileStatus
    message: Optional[str] = None

@runtime_checkable
class CreateArchiveTool(ISystemTool, Protocol):
    """Wraps ZOSAPI.Tools.General.ICreateArchive."""
    def set_output_path(self, zar_path: str) -> None: ...
    @property
    def compression(self) -> EntryCompressionModes: ...
    @compression.setter
    def compression(self, v: EntryCompressionModes) -> None: ...
    @property
    def include_samples(self) -> bool: ...
    @include_samples.setter
    def include_samples(self, v: bool) -> None: ...

@runtime_checkable
class RestoreArchiveTool(ISystemTool, Protocol):
    """Wraps ZOSAPI.Tools.General.IRestoreArchive."""
    def set_source_archive(self, zar_path: str) -> None: ...

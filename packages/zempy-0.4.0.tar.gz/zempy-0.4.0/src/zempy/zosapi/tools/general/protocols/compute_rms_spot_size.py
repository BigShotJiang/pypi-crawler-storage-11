from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, runtime_checkable
from zempy.zosapi.tools.protocols.system_tool import ISystemTool


@dataclass(frozen=True)
class RMSSpotSizeResult:
    rms_radius: float  # um or lens units depending on system; adapter should convert
    x: float
    y: float

@runtime_checkable
class ComputeRMSSpotSizeTool(ISystemTool, Protocol):
    """Wraps ZOSAPI.Tools.General.IComputeRMSSpotSize."""
    def get_result(self) -> RMSSpotSizeResult: ...

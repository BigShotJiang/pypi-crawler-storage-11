from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class QuickFocusCriterion(ZosEnumBase):
    SPOT_SIZE_RADIAL = 0
    SPOT_SIZE_X_ONLY = 1
    SPOT_SIZE_Y_ONLY = 2
    RMS_WAVEFRONT = 3

# attach config AFTER class creation (safe from Enum)
QuickFocusCriterion._NATIVE_PATH = "ZOSAPI.Tools.General.QuickFocusCriterion"
QuickFocusCriterion._ALIASES_EXTRA = {
    "SPOT_SIZE_RADIAL": ("SpotSizeRadial",),
    "SPOT_SIZE_X_ONLY": ("SpotSizeXOnly",),
    "SPOT_SIZE_Y_ONLY": ("SpotSizeYOnly",),
    "RMS_WAVEFRONT": ("RmsWavefront",),
}

__all__ = ["QuickFocusCriterion"]
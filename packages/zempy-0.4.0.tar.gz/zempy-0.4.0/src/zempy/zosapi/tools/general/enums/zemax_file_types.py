from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class ZemaxFileTypes(ZosEnumBase):
    UNKNOWN = 0
    LMX = 1
    USER = 2

# attach config AFTER class creation (safe from Enum)
ZemaxFileTypes._NATIVE_PATH = "ZOSAPI.Tools.General.ZemaxFileTypes"
ZemaxFileTypes._ALIASES_EXTRA = {
    "UNKNOWN": ("Unknown",),
    "LMX": ("Lmx",),
    "USER": ("User",),
}

__all__ = ["ZemaxFileTypes"]
from enum import Enum
from zempy.zosapi.core import ZosEnumBase

class ArchiveFileStatus(ZosEnumBase):
    OKAY = 0
    UNABLE_TO_OPEN = 1
    INVALID_FILE = 2
    INVALID_VERSION = 3

# attach config AFTER class creation (safe from Enum)
ArchiveFileStatus._NATIVE_PATH = "ZOSAPI.Tools.General.ArchiveFileStatus"
ArchiveFileStatus._ALIASES_EXTRA = {
    "OKAY": ("Okay",),
    "UNABLE_TO_OPEN": ("UnableToOpen",),
    "INVALID_FILE": ("InvalidFile",),
    "INVALID_VERSION": ("InvalidVersion",),
}

__all__ = ["ArchiveFileStatus"]
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, runtime_checkable
from zempy.zosapi.tools.protocols.system_tool import ISystemTool
from zempy.zosapi.tools.general.enums.scale_to_units import ScaleToUnits

@dataclass(frozen=True)
class ScaleOptions:
    factor: float
    target_units: ScaleToUnits | None = None
    scale_thickness: bool = True

@runtime_checkable
class ScaleTool(ISystemTool, Protocol):
    """Wraps ZOSAPI.Tools.General.IScale."""
    @property
    def scale_factor(self) -> float: ...
    @scale_factor.setter
    def scale_factor(self, v: float) -> None: ...
    @property
    def target_units(self) -> ScaleToUnits: ...
    @target_units.setter
    def target_units(self, v: ScaleToUnits) -> None: ...
    @property
    def scale_thickness(self) -> bool: ...
    @scale_thickness.setter
    def scale_thickness(self, v: bool) -> None: ...

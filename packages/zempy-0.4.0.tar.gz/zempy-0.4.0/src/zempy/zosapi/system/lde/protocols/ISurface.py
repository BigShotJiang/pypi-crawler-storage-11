from __future__ import annotations
from typing import Protocol, runtime_checkable, TYPE_CHECKING
from zemax.zos.lde.enums.surface_type import SurfaceType
from zemax.zos.lde.protocols.ILDERow import ILDERow



@runtime_checkable
class ISurface(Protocol):
    """
    Python protocol for ZOSAPI.Editors.LDE.ISurface.
    Exposes the surface's type, parent LDE row, validity, and unique ID.
    """

    @property
    def Type(self) -> "SurfaceType":
        ...

    @property
    def Row(self) -> "ILDERow":
        ...

    @property
    def IsValid(self) -> bool:
        ...

    @property
    def Id(self) -> int:
        ...


__all__ = ["ISurface"]

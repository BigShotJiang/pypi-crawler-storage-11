from enum import Enum
from zempy.zosapi.core import ZosEnumBase


class CellDataType(ZosEnumBase):
    """ZOSAPI.Editors.CellDataType

    Defines the data type of an editor cell (integer, double, or string).
    """

    INTEGER = 0
    DOUBLE = 1
    STRING = 2


# Attach native ZOSAPI binding info
CellDataType._NATIVE_PATH = "ZOSAPI.Editors.CellDataType"
CellDataType._ALIASES_EXTRA = {
    "INTEGER": ("Integer",),
    "DOUBLE": ("Double",),
    "STRING": ("String",),
}


__all__ = ["CellDataType"]

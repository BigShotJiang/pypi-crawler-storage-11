from __future__ import annotations
from typing import Type
from zempy.zosapi.core.interop import run_native
from zempy.zosapi.core.types_var import *


def property_enum(attr: str, enum: Type[E], *, label: str) -> property:
    def fget(self) -> E:
        raw = run_native(f"{label}.{attr} get",
                         lambda: getattr(self.native, attr),
                         ensure=self._ensure_native)
        return enum.from_native(self.zosapi, raw)

    def fset(self, value: E) -> None:
        raw = enum.to_native(self.zosapi, value)
        run_native(f"{label}.{attr} set",
                   lambda: setattr(self.native, attr, raw),
                   ensure=self._ensure_native)

    return property(fget, fset)

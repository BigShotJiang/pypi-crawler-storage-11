from typing import TypeVar, ParamSpec
from zempy.zosapi.core.enum_base import ZosEnumBase

# ---------------------------------------------------------------------------
# Type variables used throughout ZemPy's ZOSAPI adapter layer
# ---------------------------------------------------------------------------

# N — "Native" type
# Represents the **underlying COM / .NET ZOSAPI interface** object.
# For example: an instance of IAR_PathAnalysisData or IA_AnalysisSettings.
# Anything coming directly from pythonnet (ZOSAPI) lives under this type.
N = TypeVar("N")

# A — "Adapter" type
# Represents the **Python wrapper** (adapter or selector) that exposes
# a friendlier API around the native COM object. This is what end users
# interact with in ZemPy (e.g., PathAnalysisData, IAS_Field, etc.).
A = TypeVar("A")

# T — "Generic" value type
# A generic placeholder for any arbitrary return or input value.
# Used in helpers like `run_native` or `ensure_not_none` where the type
# depends entirely on the wrapped function’s return value.
T = TypeVar("T")

# E — "Enum" type
# Represents a ZemPy enumeration class derived from ZosEnumBase.
# Used when working with strongly-typed enum properties (e.g., polarization states).
E = TypeVar("E", bound=ZosEnumBase)

# P — Parameter specification
# Captures *args/**kwargs signatures for decorators that preserve the
# wrapped function’s call signature, e.g. native_call().
P = ParamSpec("P")

# ---------------------------------------------------------------------------
# Exported symbols
# ---------------------------------------------------------------------------
__all__ = ["N", "A", "T", "E", "P"]

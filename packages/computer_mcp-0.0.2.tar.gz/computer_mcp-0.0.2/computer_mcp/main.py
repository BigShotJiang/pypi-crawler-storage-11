#!/usr/bin/env python3
"""
Computer MCP Server
Main entry point for the MCP server.
"""

import asyncio

from mcp.server.stdio import stdio_server

from computer_mcp.server import server


async def main():
    """Main entry point."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


def entry_point():
    """Synchronous entry point for setuptools console script."""
    asyncio.run(main())


if __name__ == "__main__":
    entry_point()

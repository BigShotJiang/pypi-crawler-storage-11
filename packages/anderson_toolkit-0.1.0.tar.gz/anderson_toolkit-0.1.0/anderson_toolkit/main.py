def hello():
    print("Hello from Anderson's Toolkit!")
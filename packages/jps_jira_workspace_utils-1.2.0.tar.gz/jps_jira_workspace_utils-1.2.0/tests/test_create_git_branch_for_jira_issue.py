"""
Unit tests for create_git_branch_for_jira_issue CLI.
"""

import sys
import subprocess
import builtins


def test_help_option():
    """Verify that the CLI runs and displays help text."""
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "jps_jira_workspace_utils.create_git_branch_for_jira_issue",
            "--help",
        ],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0
    assert "usage:" in result.stdout
    # Updated assertion
    assert "create_git_branch_for_jira_issue" in result.stdout


def test_env_file_message(monkeypatch, tmp_path):
    """Verify message when no ~/.jira.env file exists."""
    monkeypatch.setenv("HOME", str(tmp_path))
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "jps_jira_workspace_utils.create_git_branch_for_jira_issue",
            "--help",
        ],
        capture_output=True,
        text=True,
    )
    assert "No ~/.jira.env file found" in result.stderr or result.stdout


def test_mock_branch_creation(monkeypatch):
    """Simulate branch creation logic without executing Git commands."""
    import jps_jira_workspace_utils.create_git_branch_for_jira_issue as cli

    # Mock subprocess.run to avoid calling real git
    monkeypatch.setattr(cli.subprocess, "run", lambda *a, **kw: 0)

    # Mock os operations and environment variables
    monkeypatch.setattr(cli.os, "getenv", lambda k, d=None: d)

    # ✅ Auto-answer to input() prompt
    monkeypatch.setattr(builtins, "input", lambda *a, **kw: "y")

    # Minimal CLI arguments
    sys.argv = [
        "create_git_branch_for_jira_issue",
        "--jira-id",
        "BISD-123",
        "--codebase",
        "carrier-var-file-utils",
        "--branch-type",
        "feature",
    ]

    try:
        cli.main()
    except SystemExit:
        # argparse may call sys.exit() — ignore
        pass

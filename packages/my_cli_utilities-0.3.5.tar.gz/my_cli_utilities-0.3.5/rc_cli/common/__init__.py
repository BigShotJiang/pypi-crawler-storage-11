# -*- coding: utf-8 -*-

"""Common utilities package for RC CLI modules."""

# Re-export all common utilities
from .utils import (
    Result,
    async_command,
    handle_http_error,
    create_error_result
)
from .service_factory import ServiceFactory
from .company_config import replace_company_placeholders, apply_company_config

__all__ = [
    "Result",
    "async_command",
    "handle_http_error",
    "create_error_result",
    "ServiceFactory",
    "replace_company_placeholders",
    "apply_company_config"
]


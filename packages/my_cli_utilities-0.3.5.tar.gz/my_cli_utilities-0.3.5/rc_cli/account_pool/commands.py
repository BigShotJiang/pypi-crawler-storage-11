# -*- coding: utf-8 -*-

"""Account Pool commands for RC CLI."""

from typing import Optional
import typer
from .service import AccountService
from .tui import run_tui
from ..common.service_factory import ServiceFactory

# Create Account Pool sub-app
ap_app = typer.Typer(
    name="ap",
    help="🏦 Account Pool management commands",
    add_completion=False,
    rich_markup_mode="rich"
)

# --- Service Instance ---
account_service = ServiceFactory.get_account_service()


@ap_app.command("get")
def get_random_account(
    account_type: str = typer.Argument(..., help="Account type string or index number from 'rc ap types'"),
    env_name: str = typer.Option(AccountService.DEFAULT_ENV_NAME, "--env", "-e", help="Environment name")
):
    """Get a random available account of a specific type.
    
    Examples:
    
        rc ap get webAqaXmn              # Get random account of type webAqaXmn
        rc ap get 1                      # Get random account using index from 'rc ap types'
        rc ap get webAqaXmn --env prod   # Get account from prod environment
    """
    account_service.get_random_account(account_type, env_name)


@ap_app.command("by-id")
def get_account_by_id(
    account_id: str = typer.Argument(..., help="Account ID to lookup"),
    env_name: str = typer.Option(AccountService.DEFAULT_ENV_NAME, "--env", "-e", help="Environment name")
):
    """Get account details by its specific Account ID.
    
    Examples:
    
        rc ap by-id 8023391076           # Get account by ID
        rc ap by-id 8023391076 --env prod # Get account from prod environment
    """
    account_service.get_account_by_id(account_id, env_name)


@ap_app.command("info")
def get_info_by_phone(
    main_number: str = typer.Argument(..., help="Phone number to lookup"),
    env_name: str = typer.Option(AccountService.DEFAULT_ENV_NAME, "--env", "-e", help="Environment name")
):
    """Get account details by its main phone number.
    
    Examples:
    
        rc ap info 16789350903           # Get account by phone number
        rc ap info +16789350903          # Phone number with + prefix
    """
    account_service.get_account_by_phone(main_number, env_name)


@ap_app.command("types")
def list_account_types(
    filter_keyword: Optional[str] = typer.Argument(None, help="Filter account types by keyword (optional)"),
    brand: str = typer.Option(AccountService.DEFAULT_BRAND, "--brand", "-b", help="Brand ID")
):
    """List all available account types for a given brand.
    
    Examples:
    
        rc ap types                      # List all account types
        rc ap types web                  # Filter account types by keyword 'web'
        rc ap types --brand 1210         # List types for brand 1210
    """
    account_service.list_account_types(brand, filter_keyword)


@ap_app.command("cache")
def manage_cache(
    action: Optional[str] = typer.Argument(None, help="Action: 'clear' to clear cache, empty to show status")
):
    """Manage the local cache. Shows status by default.
    
    Examples:
    
        rc ap cache                      # Show cache status
        rc ap cache clear                # Clear cache
    """
    account_service.manage_cache(action)


@ap_app.command("tui")
def launch_tui():
    """🖥️  Launch interactive TUI (Terminal User Interface)
    
    Examples:
    
        rc ap tui                        # Launch interactive TUI
    """
    typer.echo("🚀 Launching Account Pool TUI...")
    typer.echo("💡 Press 'q' or 'Ctrl+C' to exit, 'Esc' to go back")
    typer.echo("-" * 50)
    
    try:
        run_tui()
    except KeyboardInterrupt:
        typer.echo("\n\n👋 TUI closed by user")
    except Exception as e:
        typer.echo(f"\n❌ Error launching TUI: {e}", err=True)
        raise typer.Exit(1)


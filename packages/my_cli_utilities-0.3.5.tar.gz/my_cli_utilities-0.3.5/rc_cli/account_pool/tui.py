# -*- coding: utf-8 -*-

"""Interactive TUI for Account Pool management."""

import asyncio
from typing import Optional, Dict, List
from textual.app import App, ComposeResult
from textual.screen import Screen
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import (
    Button,
    DataTable,
    Footer,
    Header,
    Input,
    Label,
    TextArea,
)
from textual.binding import Binding
from textual import events
from .service import AccountService
from .data_manager import CacheManager
from ..common.service_factory import ServiceFactory


class BaseScreen(Screen):
    """Base screen with common functionality."""
    
    BINDINGS = [
        Binding("escape", "back", "Back", priority=True),
    ]
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        self.app.pop_screen()


class ScrollableTextAreaMixin:
    """Mixin for screens with scrollable TextArea."""
    
    async def on_mouse_scroll_up(self, event: events.MouseScrollUp) -> None:
        """Handle scroll with reduced step for better UX."""
        control = event.control
        if isinstance(control, TextArea):
            control.action_scroll_up()
            event.stop()
    
    async def on_mouse_scroll_down(self, event: events.MouseScrollDown) -> None:
        """Handle scroll with reduced step for better UX."""
        control = event.control
        if isinstance(control, TextArea):
            control.action_scroll_down()
            event.stop()


class BaseResultScreen(BaseScreen, ScrollableTextAreaMixin):
    """Base screen for displaying results in TextArea."""
    
    def on_mount(self) -> None:
        """Initialize with scroll settings."""
        if hasattr(self, 'query_one'):
            try:
                result_area = self.query_one("#result-area", TextArea)
                result_area.show_line_numbers = False
            except Exception:
                pass


class GetRandomAccountScreen(BaseResultScreen):
    """Screen for getting a random account."""
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="get-random-container"):
                yield Label("🎲 Get Random Account", id="get-random-title")
                yield Input(
                    placeholder="Account Type (e.g., webAqaXmn or index number)",
                    id="account-type-input"
                )
                yield Input(
                    placeholder=f"Environment (default: {AccountService.DEFAULT_ENV_NAME})",
                    id="env-input"
                )
                yield TextArea(id="result-area", read_only=True)
                with Horizontal(id="get-random-buttons"):
                    yield Button("Get Account", id="get-btn", variant="primary")
                    yield Button("Clear", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def on_mount(self) -> None:
        """Initialize the get random account screen."""
        super().on_mount()
        self.query_one("#account-type-input", Input).focus()
        env_input = self.query_one("#env-input", Input)
        env_input.value = AccountService.DEFAULT_ENV_NAME
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "get-btn":
            await self._get_random_account()
        elif event.button.id == "clear-btn":
            self.query_one("#account-type-input", Input).value = ""
            self.query_one("#env-input", Input).value = AccountService.DEFAULT_ENV_NAME
            self.query_one("#result-area", TextArea).text = ""
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id == "account-type-input":
            self.query_one("#env-input", Input).focus()
        elif event.input.id == "env-input":
            await self._get_random_account()
    
    async def _get_random_account(self) -> None:
        """Get a random account."""
        account_type = self.query_one("#account-type-input", Input).value.strip()
        env_name = self.query_one("#env-input", Input).value.strip() or AccountService.DEFAULT_ENV_NAME
        
        if not account_type:
            self.query_one("#get-random-title", Label).update(
                "⚠️  Please enter Account Type"
            )
            return
        
        result_area = self.query_one("#result-area", TextArea)
        self.query_one("#get-random-title", Label).update("🎲 Loading...")
        result_area.text = ""
        
        try:
            account_service = ServiceFactory.get_account_service()
            
            # Run synchronous method in thread pool
            loop = asyncio.get_event_loop()
            account_result = await loop.run_in_executor(
                None,
                lambda: self._get_random_account_sync(account_service, account_type, env_name)
            )
            
            if account_result is None:
                self.query_one("#get-random-title", Label).update(
                    "❌ Failed to get account"
                )
                result_area.text = "❌ Failed to get account. Please check your inputs and try again."
                return
            
            if isinstance(account_result, tuple) and account_result[0] is None:
                # Error case
                error_msg = account_result[1]
                self.query_one("#get-random-title", Label).update(f"❌ {error_msg}")
                result_area.text = f"Error: {error_msg}"
                return
            
            account = account_result if not isinstance(account_result, tuple) else account_result[0]
            formatted_output = self._format_account_info(account)
            result_area.text = formatted_output
            self.query_one("#get-random-title", Label).update(
                f"✅ Random account retrieved"
            )
            
        except Exception as e:
            self.query_one("#get-random-title", Label).update(
                f"❌ Error: {str(e)}"
            )
            result_area.text = f"Error: {str(e)}"
    
    def _get_random_account_sync(self, account_service: AccountService, account_type: str, env_name: str) -> Optional[Dict]:
        """Synchronous wrapper for getting random account."""
        try:
            from returns.pipeline import is_successful
            
            final_account_type = account_type
            if account_type.isdigit():
                cached_type = CacheManager.get_account_type_by_index(int(account_type))
                if not cached_type:
                    return (None, "Account type index not found in cache")
                final_account_type = cached_type
            
            result = account_service.data_manager.get_accounts(env_name, final_account_type).bind(
                account_service._select_random_account
            )
            
            if is_successful(result):
                return result.unwrap()
            else:
                error = result.failure()
                return (None, error.message)
        except Exception as e:
            return (None, str(e))
    
    def _format_account_info(self, account: Dict) -> str:
        """Format account information for display."""
        lines = []
        lines.append("=" * 60)
        lines.append("Account Information")
        lines.append("=" * 60)
        lines.append(f"📱 Phone: {account.get('mainNumber', 'N/A')}")
        lines.append(f"🆔 Account ID: {account.get('accountId', 'N/A')}")
        lines.append(f"🏷️  Type: {account.get('accountType', 'N/A')}")
        lines.append(f"🌐 Environment: {account.get('envName', 'N/A')}")
        lines.append(f"📧 Email Domain: {account.get('companyEmailDomain', 'N/A')}")
        lines.append(f"📅 Created: {account.get('createdAt', 'N/A')}")
        lines.append(f"🔗 MongoDB ID: {account.get('_id', 'N/A')}")
        
        locked = account.get("locked", [])
        status = "🔒 Locked" if locked else "✅ Available"
        lines.append(f"🔐 Status: {status}")
        
        if locked:
            lines.append(f"🛑 Lock Details:")
            for item in locked:
                if isinstance(item, dict):
                    lines.append(f"  • Type: {item.get('accountType', 'N/A')}")
        
        lines.append("=" * 60)
        return "\n".join(lines)


class GetAccountByIdScreen(BaseResultScreen):
    """Screen for getting account by ID."""
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="get-by-id-container"):
                yield Label("🆔 Get Account by ID", id="get-by-id-title")
                yield Input(placeholder="Account ID", id="account-id-input")
                yield Input(
                    placeholder=f"Environment (default: {AccountService.DEFAULT_ENV_NAME})",
                    id="env-input"
                )
                yield TextArea(id="result-area", read_only=True)
                with Horizontal(id="get-by-id-buttons"):
                    yield Button("Get Account", id="get-btn", variant="primary")
                    yield Button("Clear", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def on_mount(self) -> None:
        """Initialize the get by ID screen."""
        super().on_mount()
        self.query_one("#account-id-input", Input).focus()
        env_input = self.query_one("#env-input", Input)
        env_input.value = AccountService.DEFAULT_ENV_NAME
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "get-btn":
            await self._get_account_by_id()
        elif event.button.id == "clear-btn":
            self.query_one("#account-id-input", Input).value = ""
            self.query_one("#env-input", Input).value = AccountService.DEFAULT_ENV_NAME
            self.query_one("#result-area", TextArea).text = ""
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id == "account-id-input":
            self.query_one("#env-input", Input).focus()
        elif event.input.id == "env-input":
            await self._get_account_by_id()
    
    async def _get_account_by_id(self) -> None:
        """Get account by ID."""
        account_id = self.query_one("#account-id-input", Input).value.strip()
        env_name = self.query_one("#env-input", Input).value.strip() or AccountService.DEFAULT_ENV_NAME
        
        if not account_id:
            self.query_one("#get-by-id-title", Label).update(
                "⚠️  Please enter Account ID"
            )
            return
        
        result_area = self.query_one("#result-area", TextArea)
        self.query_one("#get-by-id-title", Label).update("🆔 Loading...")
        result_area.text = ""
        
        try:
            account_service = ServiceFactory.get_account_service()
            
            loop = asyncio.get_event_loop()
            account_result = await loop.run_in_executor(
                None,
                lambda: self._get_account_by_id_sync(account_service, account_id, env_name)
            )
            
            if account_result is None:
                self.query_one("#get-by-id-title", Label).update(
                    "❌ Failed to get account"
                )
                result_area.text = "❌ Failed to get account. Please check your inputs and try again."
                return
            
            if isinstance(account_result, tuple) and account_result[0] is None:
                error_msg = account_result[1]
                self.query_one("#get-by-id-title", Label).update(f"❌ {error_msg}")
                result_area.text = f"Error: {error_msg}"
                return
            
            account = account_result if not isinstance(account_result, tuple) else account_result[0]
            formatted_output = self._format_account_info(account)
            result_area.text = formatted_output
            self.query_one("#get-by-id-title", Label).update(
                f"✅ Account retrieved"
            )
            
        except Exception as e:
            self.query_one("#get-by-id-title", Label).update(
                f"❌ Error: {str(e)}"
            )
            result_area.text = f"Error: {str(e)}"
    
    def _get_account_by_id_sync(self, account_service: AccountService, account_id: str, env_name: str) -> Optional[Dict]:
        """Synchronous wrapper for getting account by ID."""
        try:
            from returns.pipeline import is_successful
            
            result = account_service.data_manager.get_account_by_id(account_id, env_name)
            
            if is_successful(result):
                return result.unwrap()
            else:
                error = result.failure()
                return (None, error.message)
        except Exception as e:
            return (None, str(e))
    
    def _format_account_info(self, account: Dict) -> str:
        """Format account information for display."""
        lines = []
        lines.append("=" * 60)
        lines.append("Account Information")
        lines.append("=" * 60)
        lines.append(f"📱 Phone: {account.get('mainNumber', 'N/A')}")
        lines.append(f"🆔 Account ID: {account.get('accountId', 'N/A')}")
        lines.append(f"🏷️  Type: {account.get('accountType', 'N/A')}")
        lines.append(f"🌐 Environment: {account.get('envName', 'N/A')}")
        lines.append(f"📧 Email Domain: {account.get('companyEmailDomain', 'N/A')}")
        lines.append(f"📅 Created: {account.get('createdAt', 'N/A')}")
        lines.append(f"🔗 MongoDB ID: {account.get('_id', 'N/A')}")
        
        locked = account.get("locked", [])
        status = "🔒 Locked" if locked else "✅ Available"
        lines.append(f"🔐 Status: {status}")
        
        if locked:
            lines.append(f"🛑 Lock Details:")
            for item in locked:
                if isinstance(item, dict):
                    lines.append(f"  • Type: {item.get('accountType', 'N/A')}")
        
        lines.append("=" * 60)
        return "\n".join(lines)


class GetAccountByPhoneScreen(BaseResultScreen):
    """Screen for getting account by phone number."""
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="get-by-phone-container"):
                yield Label("📱 Get Account by Phone", id="get-by-phone-title")
                yield Input(placeholder="Phone Number", id="phone-input")
                yield Input(
                    placeholder=f"Environment (default: {AccountService.DEFAULT_ENV_NAME})",
                    id="env-input"
                )
                yield TextArea(id="result-area", read_only=True)
                with Horizontal(id="get-by-phone-buttons"):
                    yield Button("Get Account", id="get-btn", variant="primary")
                    yield Button("Clear", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def on_mount(self) -> None:
        """Initialize the get by phone screen."""
        super().on_mount()
        self.query_one("#phone-input", Input).focus()
        env_input = self.query_one("#env-input", Input)
        env_input.value = AccountService.DEFAULT_ENV_NAME
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "get-btn":
            await self._get_account_by_phone()
        elif event.button.id == "clear-btn":
            self.query_one("#phone-input", Input).value = ""
            self.query_one("#env-input", Input).value = AccountService.DEFAULT_ENV_NAME
            self.query_one("#result-area", TextArea).text = ""
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id == "phone-input":
            self.query_one("#env-input", Input).focus()
        elif event.input.id == "env-input":
            await self._get_account_by_phone()
    
    async def _get_account_by_phone(self) -> None:
        """Get account by phone number."""
        phone = self.query_one("#phone-input", Input).value.strip()
        env_name = self.query_one("#env-input", Input).value.strip() or AccountService.DEFAULT_ENV_NAME
        
        if not phone:
            self.query_one("#get-by-phone-title", Label).update(
                "⚠️  Please enter Phone Number"
            )
            return
        
        result_area = self.query_one("#result-area", TextArea)
        self.query_one("#get-by-phone-title", Label).update("📱 Loading...")
        result_area.text = ""
        
        try:
            account_service = ServiceFactory.get_account_service()
            
            loop = asyncio.get_event_loop()
            account_result = await loop.run_in_executor(
                None,
                lambda: self._get_account_by_phone_sync(account_service, phone, env_name)
            )
            
            if account_result is None:
                self.query_one("#get-by-phone-title", Label).update(
                    "❌ Failed to get account"
                )
                result_area.text = "❌ Failed to get account. Please check your inputs and try again."
                return
            
            if isinstance(account_result, tuple) and account_result[0] is None:
                error_msg = account_result[1]
                self.query_one("#get-by-phone-title", Label).update(f"❌ {error_msg}")
                result_area.text = f"Error: {error_msg}"
                return
            
            account = account_result if not isinstance(account_result, tuple) else account_result[0]
            formatted_output = self._format_account_info(account)
            result_area.text = formatted_output
            self.query_one("#get-by-phone-title", Label).update(
                f"✅ Account retrieved"
            )
            
        except Exception as e:
            self.query_one("#get-by-phone-title", Label).update(
                f"❌ Error: {str(e)}"
            )
            result_area.text = f"Error: {str(e)}"
    
    def _get_account_by_phone_sync(self, account_service: AccountService, phone: str, env_name: str) -> Optional[Dict]:
        """Synchronous wrapper for getting account by phone."""
        try:
            from returns.pipeline import is_successful
            from my_cli_utilities_common.config import ValidationUtils
            
            main_number_str = ValidationUtils.normalize_phone_number(phone)
            if not main_number_str:
                return (None, "Invalid phone number format")
            
            result = account_service.data_manager.get_all_accounts_for_env(env_name).bind(
                lambda accounts: account_service._find_account_by_phone_in_list(accounts, main_number_str)
            )
            
            if is_successful(result):
                return result.unwrap()
            else:
                error = result.failure()
                return (None, error.message)
        except Exception as e:
            return (None, str(e))
    
    def _format_account_info(self, account: Dict) -> str:
        """Format account information for display."""
        lines = []
        lines.append("=" * 60)
        lines.append("Account Information")
        lines.append("=" * 60)
        lines.append(f"📱 Phone: {account.get('mainNumber', 'N/A')}")
        lines.append(f"🆔 Account ID: {account.get('accountId', 'N/A')}")
        lines.append(f"🏷️  Type: {account.get('accountType', 'N/A')}")
        lines.append(f"🌐 Environment: {account.get('envName', 'N/A')}")
        lines.append(f"📧 Email Domain: {account.get('companyEmailDomain', 'N/A')}")
        lines.append(f"📅 Created: {account.get('createdAt', 'N/A')}")
        lines.append(f"🔗 MongoDB ID: {account.get('_id', 'N/A')}")
        
        locked = account.get("locked", [])
        status = "🔒 Locked" if locked else "✅ Available"
        lines.append(f"🔐 Status: {status}")
        
        if locked:
            lines.append(f"🛑 Lock Details:")
            for item in locked:
                if isinstance(item, dict):
                    lines.append(f"  • Type: {item.get('accountType', 'N/A')}")
        
        lines.append("=" * 60)
        return "\n".join(lines)


class ListAccountTypesScreen(BaseScreen):
    """Screen for listing account types."""
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="list-types-container"):
                yield Label("🏦 List Account Types", id="list-types-title")
                yield Input(
                    placeholder=f"Brand (default: {AccountService.DEFAULT_BRAND})",
                    id="brand-input"
                )
                yield Input(
                    placeholder="Filter keyword (optional)",
                    id="filter-input"
                )
                yield DataTable(id="types-table")
                with Horizontal(id="list-types-buttons"):
                    yield Button("List Types", id="list-btn", variant="primary")
                    yield Button("Clear", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def on_mount(self) -> None:
        """Initialize the list types screen."""
        table = self.query_one("#types-table", DataTable)
        table.add_columns("#", "Account Type")
        self.query_one("#brand-input", Input).focus()
        brand_input = self.query_one("#brand-input", Input)
        brand_input.value = AccountService.DEFAULT_BRAND
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "list-btn":
            await self._load_account_types()
        elif event.button.id == "clear-btn":
            self.query_one("#brand-input", Input).value = AccountService.DEFAULT_BRAND
            self.query_one("#filter-input", Input).value = ""
            table = self.query_one("#types-table", DataTable)
            table.clear()
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id == "brand-input":
            self.query_one("#filter-input", Input).focus()
        elif event.input.id == "filter-input":
            await self._load_account_types()
    
    async def _load_account_types(self) -> None:
        """Load account types."""
        brand = self.query_one("#brand-input", Input).value.strip() or AccountService.DEFAULT_BRAND
        filter_keyword = self.query_one("#filter-input", Input).value.strip() or None
        
        table = self.query_one("#types-table", DataTable)
        table.clear()
        
        self.query_one("#list-types-title", Label).update("🏦 Loading...")
        
        try:
            account_service = ServiceFactory.get_account_service()
            
            loop = asyncio.get_event_loop()
            types = await loop.run_in_executor(
                None,
                lambda: self._load_account_types_sync(account_service, brand, filter_keyword)
            )
            
            if types is None:
                self.query_one("#list-types-title", Label).update(
                    "❌ Failed to load account types. Please check brand and try again."
                )
                return
            
            # Add results to table
            for i, account_type_setting in enumerate(types, 1):
                account_type = account_type_setting.get("accountType", "N/A")
                table.add_row(str(i), account_type, key=str(i))
            
            title_text = f"🏦 {len(types)} Account Types"
            if filter_keyword:
                title_text += f" (filtered by '{filter_keyword}')"
            self.query_one("#list-types-title", Label).update(title_text)
            
        except Exception as e:
            self.query_one("#list-types-title", Label).update(
                f"❌ Error: {str(e)}"
            )
    
    def _load_account_types_sync(self, account_service: AccountService, brand: str, filter_keyword: Optional[str]) -> Optional[List[Dict]]:
        """Synchronous wrapper for loading account types."""
        try:
            from returns.pipeline import is_successful
            
            result = account_service.data_manager.get_account_settings(brand).map(
                lambda settings: account_service._filter_settings(settings, filter_keyword)
            )
            
            if is_successful(result):
                types = result.unwrap()
                # Cache the results
                CacheManager.save_cache(
                    [t.get("accountType") for t in types],
                    filter_keyword,
                    brand
                )
                return types
            else:
                error = result.failure()
                return None
        except Exception as e:
            return None


class CacheManagementScreen(BaseScreen, ScrollableTextAreaMixin):
    """Screen for cache management."""
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="cache-container"):
                yield Label("💾 Cache Management", id="cache-title")
                yield TextArea(id="cache-info-area", read_only=True)
                with Horizontal(id="cache-buttons"):
                    yield Button("Refresh", id="refresh-btn", variant="primary")
                    yield Button("Clear Cache", id="clear-btn")
                    yield Button("Back", id="back-btn")
        yield Footer()
    
    def on_mount(self) -> None:
        """Initialize the cache management screen."""
        try:
            text_area = self.query_one("#cache-info-area", TextArea)
            text_area.show_line_numbers = False
        except Exception:
            pass
        self.app.call_later(self._load_cache_info)
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "refresh-btn":
            await self._load_cache_info()
        elif event.button.id == "clear-btn":
            await self._clear_cache()
        elif event.button.id == "back-btn":
            self.action_back()
    
    async def _load_cache_info(self) -> None:
        """Load cache information."""
        try:
            loop = asyncio.get_event_loop()
            cache_info = await loop.run_in_executor(
                None,
                lambda: CacheManager.load_cache()
            )
            
            info_area = self.query_one("#cache-info-area", TextArea)
            
            if not cache_info:
                info_area.text = "ℹ️  Cache is empty."
                self.query_one("#cache-title", Label).update("💾 Cache Status: Empty")
                return
            
            lines = []
            lines.append("=" * 60)
            lines.append("Cache Status")
            lines.append("=" * 60)
            
            for key, value in cache_info.items():
                display_key = key.replace('_', ' ').title()
                display_value = value
                if isinstance(value, list) and len(value) > 10:
                    display_value = f"[{len(value)} items] {value[:5]}..."
                lines.append(f"{display_key}: {display_value}")
            
            lines.append("=" * 60)
            info_area.text = "\n".join(lines)
            self.query_one("#cache-title", Label).update("💾 Cache Status: Loaded")
            
        except Exception as e:
            self.query_one("#cache-title", Label).update(
                f"❌ Error: {str(e)}"
            )
    
    async def _clear_cache(self) -> None:
        """Clear cache."""
        try:
            loop = asyncio.get_event_loop()
            success = await loop.run_in_executor(
                None,
                lambda: CacheManager.clear_cache()
            )
            
            if success:
                self.query_one("#cache-info-area", TextArea).text = "✅ Cache cleared successfully"
                self.query_one("#cache-title", Label).update("💾 Cache Status: Cleared")
            else:
                self.query_one("#cache-info-area", TextArea).text = "ℹ️  No cache file to clear."
                self.query_one("#cache-title", Label).update("💾 Cache Status: Already Empty")
                
        except Exception as e:
            self.query_one("#cache-title", Label).update(
                f"❌ Error: {str(e)}"
            )


class MainMenuScreen(BaseScreen):
    """Main menu screen."""
    
    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
        Binding("escape", "quit", "Quit", priority=True),
        Binding("up", "move_up", "Move Up", priority=True),
        Binding("down", "move_down", "Move Down", priority=True),
        Binding("enter", "select", "Select", priority=True),
    ]
    
    button_ids = [
        "get-random-btn",
        "get-by-id-btn",
        "get-by-phone-btn",
        "list-types-btn",
        "cache-btn",
        "exit-btn",
    ]
    selected_index = 0
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            with Container(id="menu-container"):
                yield Label("🏦 Account Pool Management", id="menu-title")
                with Vertical(id="menu-buttons"):
                    yield Button("🎲 Get Random Account", id="get-random-btn", variant="primary")
                    yield Button("🆔 Get Account by ID", id="get-by-id-btn")
                    yield Button("📱 Get Account by Phone", id="get-by-phone-btn")
                    yield Button("🏦 List Account Types", id="list-types-btn")
                    yield Button("💾 Cache Management", id="cache-btn")
                    yield Button("❌ Exit", id="exit-btn")
        yield Footer()
    
    def on_mount(self) -> None:
        """Initialize menu with first button focused."""
        self._update_selection()
    
    def action_quit(self) -> None:
        """Quit the application."""
        self.app.exit()
    
    def on_key(self, event: events.Key) -> None:
        """Handle key events explicitly."""
        if event.key == "escape":
            self.app.exit()
            event.prevent_default()
        # Let other keys be handled by default processing
    
    def action_move_up(self) -> None:
        """Move selection up."""
        if self.selected_index > 0:
            self.selected_index -= 1
            self._update_selection()
    
    def action_move_down(self) -> None:
        """Move selection down."""
        if self.selected_index < len(self.button_ids) - 1:
            self.selected_index += 1
            self._update_selection()
    
    def action_select(self) -> None:
        """Select the current menu item."""
        button_id = self.button_ids[self.selected_index]
        button = self.query_one(f"#{button_id}", Button)
        button.press()
    
    def _update_selection(self) -> None:
        """Update button selection state."""
        for i, button_id in enumerate(self.button_ids):
            button = self.query_one(f"#{button_id}", Button)
            if i == self.selected_index:
                button.variant = "primary"
                button.focus()
            else:
                button.variant = "default"
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "get-random-btn":
            self.app.push_screen("get_random")
        elif event.button.id == "get-by-id-btn":
            self.app.push_screen("get_by_id")
        elif event.button.id == "get-by-phone-btn":
            self.app.push_screen("get_by_phone")
        elif event.button.id == "list-types-btn":
            self.app.push_screen("list_types")
        elif event.button.id == "cache-btn":
            self.app.push_screen("cache")
        elif event.button.id == "exit-btn":
            self.app.exit()


class AccountPoolTUIApp(App):
    """Main TUI application for Account Pool management."""
    
    CSS = """
    Screen {
        align: center middle;
    }
    
    #menu-container {
        width: 60;
        height: auto;
        border: solid $primary;
        padding: 1;
    }
    
    #menu-title {
        text-align: center;
        width: 100%;
        margin: 1;
    }
    
    #menu-buttons {
        width: 100%;
        height: auto;
    }
    
    #menu-buttons > Button {
        width: 100%;
        margin: 1;
    }
    
    #get-random-container, #get-by-id-container, #get-by-phone-container,
    #list-types-container, #cache-container {
        width: 80;
        height: auto;
        border: solid $primary;
        padding: 1;
    }
    
    #get-random-title, #get-by-id-title, #get-by-phone-title,
    #list-types-title, #cache-title {
        text-align: center;
        width: 100%;
        margin: 1;
    }
    
    #types-table {
        height: 20;
        width: 100%;
    }
    
    #result-area, #cache-info-area {
        height: 10;
        width: 100%;
    }
    
    #account-type-input, #account-id-input, #phone-input,
    #env-input, #brand-input, #filter-input {
        width: 100%;
        margin: 1;
    }
    
    #get-random-buttons, #get-by-id-buttons, #get-by-phone-buttons,
    #list-types-buttons, #cache-buttons {
        width: 100%;
        height: auto;
        margin-top: 1;
    }
    
    #get-random-buttons > Button, #get-by-id-buttons > Button,
    #get-by-phone-buttons > Button, #list-types-buttons > Button,
    #cache-buttons > Button {
        margin: 1;
    }
    """
    
    TITLE = "Account Pool Management TUI"
    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
    ]
    
    def on_mount(self) -> None:
        """Set up the initial screen."""
        self.push_screen("main")
    
    def action_quit(self) -> None:
        """Quit the application."""
        self.exit()
    
    def action_back(self) -> None:
        """Go back to previous screen."""
        if len(self.screen_stack) > 1:
            self.pop_screen()
    
    def push_screen(self, screen_name: str) -> None:
        """Push a screen by name."""
        screens = {
            "main": MainMenuScreen(),
            "get_random": GetRandomAccountScreen(),
            "get_by_id": GetAccountByIdScreen(),
            "get_by_phone": GetAccountByPhoneScreen(),
            "list_types": ListAccountTypesScreen(),
            "cache": CacheManagementScreen(),
        }
        
        if screen_name in screens:
            super().push_screen(screens[screen_name])


def run_tui():
    """Run the TUI application."""
    try:
        app = AccountPoolTUIApp()
        app.run()
    except Exception as e:
        import sys
        print(f"Error running TUI: {e}", file=sys.stderr)
        raise


if __name__ == "__main__":
    run_tui()


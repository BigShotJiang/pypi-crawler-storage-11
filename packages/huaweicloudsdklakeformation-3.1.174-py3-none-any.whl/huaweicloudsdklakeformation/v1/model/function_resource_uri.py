# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class FunctionResourceUri:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'type': 'str',
        'uri': 'str'
    }

    attribute_map = {
        'type': 'type',
        'uri': 'uri'
    }

    def __init__(self, type=None, uri=None):
        r"""FunctionResourceUri

        The model defined in huaweicloud sdk

        :param type: 函数包类型
        :type type: str
        :param uri: 函数包地址信息
        :type uri: str
        """
        
        

        self._type = None
        self._uri = None
        self.discriminator = None

        self.type = type
        self.uri = uri

    @property
    def type(self):
        r"""Gets the type of this FunctionResourceUri.

        函数包类型

        :return: The type of this FunctionResourceUri.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this FunctionResourceUri.

        函数包类型

        :param type: The type of this FunctionResourceUri.
        :type type: str
        """
        self._type = type

    @property
    def uri(self):
        r"""Gets the uri of this FunctionResourceUri.

        函数包地址信息

        :return: The uri of this FunctionResourceUri.
        :rtype: str
        """
        return self._uri

    @uri.setter
    def uri(self, uri):
        r"""Sets the uri of this FunctionResourceUri.

        函数包地址信息

        :param uri: The uri of this FunctionResourceUri.
        :type uri: str
        """
        self._uri = uri

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, FunctionResourceUri):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

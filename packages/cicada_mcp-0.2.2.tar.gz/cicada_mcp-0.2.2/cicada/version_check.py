"""
Version checking utility.

Checks if a newer version of cicada is available on GitHub.
"""

import subprocess
from pathlib import Path


def _run_git_command(args: list[str]) -> str | None:
    """Run a git command and return the output."""
    try:
        package_root = Path(__file__).parent.parent
        for cwd in [package_root, Path.cwd()]:
            result = subprocess.run(
                ["git"] + args,
                capture_output=True,
                text=True,
                timeout=2,
                cwd=cwd,
            )

            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()

        return None

    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        return None


def get_git_tag() -> str | None:
    """
    Get the most recent git tag reachable from current commit.

    First tries to read from build-time generated _version_hash.py (for PyPI installs),
    then falls back to git command (for development installs).

    Returns:
        Git tag (e.g., "v0.2.0-rc1"), or None if no tags found
    """
    # Try reading from build-time generated file first (for PyPI installs)
    try:
        from cicada._version_hash import GIT_TAG

        if GIT_TAG and GIT_TAG != "unknown":
            return GIT_TAG
    except (ImportError, AttributeError):
        pass

    # Fall back to git command (for development installs)
    return _run_git_command(["describe", "--tags", "--abbrev=0"])


def get_git_commit_hash(short: bool = True) -> str | None:
    """
    Get the current git commit hash.

    First tries to read from build-time generated _version_hash.py (for PyPI installs),
    then falls back to git command (for development installs).

    Args:
        short: If True, return short hash (7 chars), else full hash

    Returns:
        Git commit hash, or None if not available
    """
    # Try reading from build-time generated file first (for PyPI installs)
    try:
        from cicada._version_hash import GIT_HASH

        if GIT_HASH and GIT_HASH != "unknown":
            return GIT_HASH
    except ImportError:
        pass

    # Fall back to git command (for development installs)
    args = ["rev-parse"]
    if short:
        args.append("--short")
    args.append("HEAD")
    return _run_git_command(args)


def get_current_version() -> str:
    """
    Get the current version of cicada from pyproject.toml.

    Returns:
        Current version string (e.g., "0.1.0")
    """
    from cicada import __version__

    return __version__


def get_latest_github_tag(repo: str = "wende/cicada") -> str | None:
    """
    Get the latest tag from GitHub repository.

    Args:
        repo: GitHub repository in format "owner/repo"

    Returns:
        Latest tag name, or None if unable to fetch
    """
    try:
        result = subprocess.run(
            [
                "gh",
                "api",
                f"repos/{repo}/tags",
                "--jq",
                ".[0].name",
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode == 0 and result.stdout.strip():
            tag = result.stdout.strip()
            # Remove 'v' prefix if present (e.g., "v0.1.0" -> "0.1.0")
            if tag.startswith("v"):
                tag = tag[1:]
            return tag

        return None

    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        # Silently fail - this is a non-critical check
        return None


def compare_versions(current: str, latest: str) -> bool:
    """
    Compare two version strings.

    Args:
        current: Current version (e.g., "0.1.0")
        latest: Latest version (e.g., "0.2.0")

    Returns:
        True if latest is newer than current, False otherwise
    """
    try:
        # Simple comparison by splitting on dots
        current_parts = [int(x) for x in current.split(".")]
        latest_parts = [int(x) for x in latest.split(".")]

        # Pad with zeros if needed
        max_len = max(len(current_parts), len(latest_parts))
        current_parts += [0] * (max_len - len(current_parts))
        latest_parts += [0] * (max_len - len(latest_parts))

        return latest_parts > current_parts

    except (ValueError, AttributeError):
        # If we can't parse versions, assume they're the same
        return False


def get_version_string() -> str:
    """
    Get a formatted version string including git tag and commit hash if available.

    Returns:
        Version string in format:
        - "0.2.0" (no git info)
        - "0.2.0 (v0.2.0-rc1/abc1234)" (with tag and hash)
        - "0.2.0 (abc1234)" (hash only, no tag)
    """
    version = get_current_version()
    git_tag = get_git_tag()
    commit_hash = get_git_commit_hash(short=True)

    # Build git info string
    git_info_parts = []
    if git_tag:
        git_info_parts.append(git_tag)
    if commit_hash:
        git_info_parts.append(commit_hash)

    if git_info_parts:
        git_info = "/".join(git_info_parts)
        return f"{version} ({git_info})"
    return version


def check_for_updates() -> None:
    """
    Check if there's a newer version available on GitHub.

    Prints a yellow warning message if a newer version is found.
    This function never raises exceptions - it fails silently if unable to check.
    """
    try:
        current = get_current_version()
        latest = get_latest_github_tag()

        if latest and compare_versions(current, latest):
            # ANSI escape code for yellow text
            yellow = "\033[93m"
            reset = "\033[0m"

            print(
                f"{yellow}⚠️  A newer version of cicada is available: v{latest} (current: v{current}){reset}"
            )
            print(f"{yellow}   To update, run:{reset}")
            print(f"{yellow}   uv tool install git+https://github.com/wende/cicada.git{reset}")
            print()

    except Exception:
        # Silently fail - version check is non-critical
        pass

# TODO

Features:
- [x] No quotes typing
- [x] Timeout delay flag
- [x] Config commands
- [x] Role commands
- [x] Prettier outputs
    - [x] Spinning loading icon
    - [x] Shell commands formatting
- [x] Faster shell executions ?
- [x] Test mutliple models
- [x] Improve dev documentation
- [x] Improve Readme.md
- [x] Graceful exit?
- [x] Start message: model, role
- [x] default model in config
- [x] Debug levels
- [x] Add "real world" unit tests
- [x] Find new name
- [x] Pip installable
- [x] Whai standalone running
- [x] Explain tmux in readme
- [x] Multiple python versions testing
- [x] Better first time API setup (clear no API message)
- [x] Test flag positioning
- [x] No output handling
- [x] Prettier code blocs in readme
- [x] Whai only documentation
- [x] Performance optimization

Issues:
- [x] Timeout issue
    - Note: UGH
- [x] Linux background

Refactor:
- [x] OO approach for config and roles
    - [x] Better / clearer defaults
    - [x] Clear errors
    - [x] Better first time setup
- [x] Centralized defaults
- [x] Sort unit tests

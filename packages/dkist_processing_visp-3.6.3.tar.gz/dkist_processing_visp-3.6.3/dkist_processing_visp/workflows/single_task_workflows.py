"""ViSP single task workflow."""

from setuptools import setup
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="rodrigo0000-fastapi-core-services",
    version="1.0.2",
    author="R Firm",
    author_email="rodrigo@rfirm.com",
    description="Service layer for FastAPI with Email, Stripe, and Plan management",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/rfirm/fastapi-core-services",
    packages=["fastapi_core_services"],
    package_dir={"fastapi_core_services": "."},
    package_data={"fastapi_core_services": ["*.py"]},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: FastAPI",
    ],
    python_requires=">=3.8",
    install_requires=['fastapi>=0.104.0', 'stripe>=7.0.0', 'resend>=0.8.0', 'pydantic>=2.0.0', 'sqlalchemy>=2.0.0'],
)

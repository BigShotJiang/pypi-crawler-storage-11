"""OpenBB Core App Model."""

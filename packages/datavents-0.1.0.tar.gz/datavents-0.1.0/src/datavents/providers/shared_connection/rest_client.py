


class SharedRestClient:
    pass

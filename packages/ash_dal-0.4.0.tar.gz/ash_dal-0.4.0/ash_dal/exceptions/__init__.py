class DALError(Exception):
    pass

# Security Policy

## Supported Versions

We will endeavour to support:

* The most recent minor release with bug fixes.
* The latest minor release from the last major version for 6 months after a new
    major version is released with critical bug fixes.
* All versions if a security vulnerability is found provided:
    * Upgrading to a later version is non-trivial.
    * Sufficient people are using that version to make support worthwhile.

## Reporting a Vulnerability

If you find what you think might be a security vulnerability with
spanish_nif, please do not create an issue on github. Instead please
email adrianlattes@disroot.org I'll reply to your email promptly
and try to get a patch out ASAP.

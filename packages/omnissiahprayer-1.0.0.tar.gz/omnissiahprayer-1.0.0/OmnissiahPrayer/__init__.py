from .OmnissiahPrayer import Prayer

__all__ = ["Prayer"]
__version__ = "1.0.0"
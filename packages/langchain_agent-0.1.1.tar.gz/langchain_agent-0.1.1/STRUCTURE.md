# 项目结构说明

## 📐 采用 src 布局

本项目采用了 Python 项目的 **src 布局**（src layout），这是 Python 社区推荐的最佳实践。

### 为什么使用 src 布局？

#### 1. **避免导入混淆** 🔒
- 防止意外导入项目根目录下的模块
- 确保测试使用的是安装后的包，而不是源代码
- 避免"可以本地运行但安装后失败"的问题

#### 2. **清晰的项目结构** 📁
- 源代码与配置文件分离
- 更专业和标准化
- 易于打包和分发

#### 3. **更好的测试** ✅
- 测试真正的安装包行为
- 发现打包问题更早
- 支持可编辑安装（editable install）

## 🗂️ 完整目录结构

```
langchain_agent/
│
├── 📦 main.py                          # 应用入口点（简单的启动器）
│
├── 📄 src/                              # 源代码目录
│   ├── __init__.py                     # src 包标识
│   └── langchain_agent/                # 核心应用包
│       ├── __init__.py                 # 包初始化，导出公共 API
│       ├── main.py                     # 主程序逻辑和循环
│       ├── config.py                   # 配置管理类
│       ├── agent.py                    # ChatAgent 封装
│       ├── tools.py                    # 工具函数定义
│       └── utils.py                    # 通用工具函数
│
├── 🧪 tests/                            # 测试目录（与 src 平行）
│   ├── __init__.py
│   ├── test_config.py                  # 配置测试
│   └── test_tools.py                   # 工具测试
│
├── 📜 scripts/                          # 自动化脚本
│   ├── setup.sh                        # 项目设置脚本
│   └── run_tests.sh                    # 测试运行脚本
│
├── 🐳 部署文件
│   ├── Dockerfile                      # Docker 镜像定义
│   ├── docker-compose.yml              # Docker 编排配置
│   └── .env.example                    # 环境变量模板
│
├── ⚙️ 配置文件
│   ├── pyproject.toml                  # 项目元数据和工具配置
│   ├── requirements.txt                # 依赖声明
│   ├── Makefile                        # 常用命令快捷方式
│   ├── .gitignore                      # Git 忽略规则
│   └── .python-version                 # Python 版本固定
│
└── 📚 文档
    ├── README.md                       # 项目主文档
    ├── QUICKSTART.md                   # 快速开始指南
    ├── ARCHITECTURE.md                 # 架构设计文档
    ├── CONTRIBUTING.md                 # 贡献指南
    ├── CHANGELOG.md                    # 版本更新日志
    ├── PROJECT_SUMMARY.md              # 项目总结
    ├── STRUCTURE.md                    # 本文件
    ├── REFACTORING_COMPLETE.md         # 重构完成报告
    └── LICENSE                         # MIT 许可证
```

## 📦 包结构详解

### src/langchain_agent/

这是核心应用包，包含所有业务逻辑。

#### \_\_init\_\_.py
```python
# 定义公共 API
from .agent import ChatAgent
from .config import AppConfig, LLMConfig, AgentConfig
from .tools import get_all_tools, get_current_time

__all__ = [
    "ChatAgent",
    "AppConfig",
    "LLMConfig", 
    "AgentConfig",
    "get_all_tools",
    "get_current_time",
]
```

**作用：**
- 定义包的公共接口
- 简化外部导入
- 版本信息声明

#### main.py
主程序逻辑，包含：
- `run_chat_loop()` - 聊天主循环
- `main()` - 应用入口函数

#### config.py
配置管理，包含：
- `LLMConfig` - LLM 配置类
- `AgentConfig` - Agent 配置类
- `AppConfig` - 应用总配置类

#### agent.py
Agent 封装，包含：
- `ChatAgent` - 聊天代理封装类

#### tools.py
工具定义，包含：
- `get_current_time()` - 时区查询工具
- `get_all_tools()` - 工具注册函数

#### utils.py
通用工具，包含：
- `setup_logging()` - 日志配置
- `print_welcome()` - 欢迎信息
- `print_help()` - 帮助信息
- `clear_screen()` - 清屏

## 🔗 导入路径

### 从项目内部导入（相对导入）

在 `src/langchain_agent/` 内的模块之间：

```python
# agent.py 导入同包内的模块
from .config import AppConfig
from .tools import get_all_tools
```

### 从外部导入（绝对导入）

在测试或其他地方导入包：

```python
# tests/test_tools.py
from src.langchain_agent.tools import get_current_time

# 或使用包的公共 API
from src.langchain_agent import get_current_time
```

### 应用入口

顶层 `main.py` 作为启动器：

```python
from src.langchain_agent.main import main

if __name__ == "__main__":
    main()
```

## 🎯 设计优势

### 1. 模块隔离 🔐
```
✅ 好的设计：
src/langchain_agent/config.py  # 清晰的包结构
src/langchain_agent/agent.py

❌ 扁平设计：
config.py                       # 容易混乱
agent.py
```

### 2. 测试可靠性 ✅
```
✅ src 布局：
测试导入 src.langchain_agent → 测试真实安装行为

❌ 扁平布局：
测试可能直接导入源文件 → 无法发现打包问题
```

### 3. 打包友好 📦
```python
# pyproject.toml
[project]
# src 布局自动被识别
# 打包工具知道从哪里找源代码
```

### 4. 命名空间清晰 🏷️
```python
# 清晰的导入语句
from src.langchain_agent import ChatAgent
from src.langchain_agent.config import AppConfig

# 避免混淆
import config  # 是哪个 config？
```

## 🔧 开发工作流

### 安装开发模式
```bash
# 可编辑安装（推荐）
pip install -e .

# 现在可以在任何地方导入
python -c "from src.langchain_agent import ChatAgent"
```

### 运行应用
```bash
# 方式 1：直接运行入口文件
python main.py

# 方式 2：使用 Make
make run

# 方式 3：作为模块运行
python -m src.langchain_agent.main
```

### 运行测试
```bash
# pytest 会自动找到 tests/
pytest

# 或使用 Make
make test
```

## 📊 与扁平结构对比

| 方面 | 扁平结构 | src 布局 |
|------|---------|---------|
| 目录层次 | 1 层 | 2-3 层 |
| 命名空间 | 混乱 | 清晰 |
| 打包 | 容易出错 | 可靠 |
| 测试 | 可能误导 | 真实 |
| 专业度 | 业余 | 专业 |
| 推荐度 | ❌ | ✅ |

## 🎓 最佳实践

### ✅ 推荐

1. **使用相对导入** - 在包内部
2. **导出公共 API** - 在 `__init__.py` 中
3. **测试使用绝对导入** - 测试真实安装
4. **保持 src/ 纯净** - 只放源代码
5. **文档在根目录** - 易于访问

### ❌ 避免

1. **不要在 src/ 放配置文件**
2. **不要在包外使用相对导入**
3. **不要混合导入风格**
4. **不要跳过 `__init__.py`**

## 📚 参考资源

- [Python Packaging User Guide - src layout](https://packaging.python.org/en/latest/discussions/src-layout-vs-flat-layout/)
- [pytest 文档 - src layout](https://docs.pytest.org/en/latest/explanation/goodpractices.html#tests-outside-application-code)
- [setuptools 文档 - package discovery](https://setuptools.pypa.io/en/latest/userguide/package_discovery.html)

## 🎉 总结

采用 **src 布局**使项目：

- 🏗️ **结构更清晰** - 源代码与配置分离
- 🔒 **更加可靠** - 避免导入陷阱
- 📦 **打包友好** - 符合标准
- ✅ **测试真实** - 测试实际安装行为
- 🎓 **更专业** - 符合社区最佳实践

这是一个**生产就绪**的项目结构！


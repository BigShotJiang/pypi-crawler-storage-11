from core import *


print('一切正常，Nsc410可以使用')
print(Ns4ev("'ha'+'llo'"))

# 创建编译器并注册函数
compiler = Compiler()


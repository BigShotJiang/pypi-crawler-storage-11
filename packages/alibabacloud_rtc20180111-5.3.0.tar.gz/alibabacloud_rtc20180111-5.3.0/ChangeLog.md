2025-10-17 Version: 5.2.5
- Update API StartCloudRecord: add request parameters SingleStreamingRecord.AvMerge.


2025-10-10 Version: 5.2.4
- Update API CreateAppAgentTemplate: add request parameters AmbientSoundConfig.
- Update API CreateAppAgentTemplate: add request parameters BackChannelConfig.
- Update API CreateAppAgentTemplate: add request parameters InterruptConfig.
- Update API DescribeAppAgentTemplates: add response parameters Body.Templates.$.AmbientSoundConfig.
- Update API DescribeAppAgentTemplates: add response parameters Body.Templates.$.BackChannelConfig.
- Update API DescribeAppAgentTemplates: add response parameters Body.Templates.$.InterruptConfig.
- Update API ModifyAppAgentTemplate: add request parameters AmbientSoundConfig.
- Update API ModifyAppAgentTemplate: add request parameters BackChannelConfig.
- Update API ModifyAppAgentTemplate: add request parameters InterruptConfig.
- Update API NotifyAgent: add request parameters BackgroundMusic.
- Update API StartAgent: add request parameters VoiceChatConfig.AmbientSoundConfig.
- Update API StartAgent: add request parameters VoiceChatConfig.BackChannelConfig.
- Update API StartAgent: add request parameters VoiceChatConfig.InterruptConfig.


2025-08-04 Version: 5.2.3
- Update API CreateAppAgentTemplate: add request parameters AgentSilenceConfig.
- Update API CreateAppAgentTemplate: add request parameters AsrConfig.VadConfig.
- Update API CreateAppAgentTemplate: add request parameters LlmConfig.AgentAppId.
- Update API DescribeAppAgentTemplates: add response parameters Body.Templates.$.AgentSilenceConfig.
- Update API DescribeAppAgentTemplates: add response parameters Body.Templates.$.AsrConfig.VadConfig.
- Update API DescribeAppAgentTemplates: add response parameters Body.Templates.$.LlmConfig.AgentAppId.
- Update API ModifyAppAgentTemplate: add request parameters AgentSilenceConfig.
- Update API ModifyAppAgentTemplate: add request parameters AsrConfig.VadConfig.
- Update API ModifyAppAgentTemplate: add request parameters LlmConfig.AgentAppId.
- Update API StartAgent: add request parameters RtcConfig.UserInactivityTimeout.
- Update API StartAgent: add request parameters VoiceChatConfig.AgentSilenceConfig.
- Update API StartAgent: add request parameters VoiceChatConfig.ASRConfig.VadConfig.
- Update API StartAgent: add request parameters VoiceChatConfig.LLMConfig.AppId.
- Update API StartAgent: add request parameters VoiceChatConfig.LLMConfig.Params.


2025-07-22 Version: 5.2.2
- Update API StartCloudRecord: add request parameters Annotation.
- Update API StartCloudRecord: add request parameters RecordMode.
- Update API StartCloudRecord: add request parameters SingleStreamingRecord.
- Update API StartCloudRecord: add request parameters StartWithoutChannel.
- Update API StartCloudRecord: add request parameters StartWithoutChannelWaitTime.
- Update API StartStreamingOut: add request parameters Annotation.
- Update API StartStreamingOut: add request parameters SpecMixedUserList.
- Update API UpdateStreamingOut: add request parameters SpecMixedUserList.


2025-07-09 Version: 5.2.1
- Generated python 2018-01-11 for rtc.

2025-07-03 Version: 5.2.0
- Support API CreateAppAgentTemplate.
- Support API DeleteAppAgentTemplate.
- Support API DescribeAppAgentFunctionStatus.
- Support API DescribeAppAgentTemplates.
- Support API GetAgent.
- Support API ModifyAppAgentFunctionStatus.
- Support API ModifyAppAgentTemplate.
- Support API NotifyAgent.
- Support API StartAgent.
- Support API StopAgent.
- Support API UpdateAgent.


2025-06-03 Version: 5.1.0
- Support API CreateCloudNotePhrases.
- Support API DeleteCloudNotePhrases.
- Support API DescribeCloudNotePhrases.
- Support API DescribeCloudRecordStatus.
- Support API ModifyCloudNotePhrases.
- Update API StartCloudNote: add request parameters Transcription.PhraseId.
- Update API StartCloudRecord: add request parameters BgColor.
- Update API StartCloudRecord: add request parameters SubHighResolutionStream.
- Update API StartStreamingOut: add request parameters BgColor.
- Update API StartStreamingOut: add request parameters SubHighResolutionStream.
- Update API UpdateStreamingOut: add request parameters BgColor.
- Update API UpdateStreamingOut: add request parameters CropMode.
- Update API UpdateStreamingOut: add request parameters RegionColor.


2025-04-29 Version: 5.0.5
- Generated python 2018-01-11 for rtc.

2025-04-15 Version: 5.0.4
- Update API StartCloudNote: add request parameters RealtimeSubtitle.
- Update API StartCloudNote: add request parameters Transcription.
- Update API StartCloudRecord: add request parameters ShowDefaultBackgroundOnMute.
- Update API StartCloudRecord: add request parameters Panes.$.Backgrounds.
- Update API StartCloudRecord: add request parameters Panes.$.Images.$.Display.
- Update API StartCloudRecord: add request parameters Panes.$.Texts.$.Display.
- Update API StartStreamingOut: add request parameters ShowDefaultBackgroundOnMute.
- Update API StartStreamingOut: add request parameters Panes.$.Backgrounds.
- Update API StartStreamingOut: add request parameters Panes.$.Images.$.Display.
- Update API StartStreamingOut: add request parameters Panes.$.Texts.$.Display.
- Update API UpdateCloudRecord: add request parameters Panes.$.Backgrounds.
- Update API UpdateCloudRecord: add request parameters Panes.$.Images.$.Display.
- Update API UpdateCloudRecord: add request parameters Panes.$.Texts.$.Display.
- Update API UpdateStreamingOut: add request parameters Panes.$.Backgrounds.
- Update API UpdateStreamingOut: add request parameters Panes.$.Images.$.Display.
- Update API UpdateStreamingOut: add request parameters Panes.$.Texts.$.Display.


2025-02-21 Version: 5.0.3
- Update API StartCloudRecord: add param ReservePaneForNoCameraUser.
- Update API StartCloudRecord: update param Panes.
- Update API StartCloudRecord: update param StorageConfig.
- Update API StartStreamingOut: add param ReservePaneForNoCameraUser.
- Update API StartStreamingOut: add param StartWithoutChannel.
- Update API StartStreamingOut: add param StartWithoutChannelWaitTime.
- Update API StartStreamingOut: update param Panes.
- Update API UpdateCloudRecord: update param Panes.
- Update API UpdateStreamingOut: update param Panes.


2025-02-13 Version: 5.0.2
- Update API StartCloudRecord: update param Panes.
- Update API StartStreamingOut: update param Panes.
- Update API UpdateCloudRecord: update param Panes.
- Update API UpdateStreamingOut: update param Panes.


2025-02-12 Version: 5.0.1
- Update API StartCloudRecord: update param Panes.
- Update API StartStreamingOut: update param Panes.
- Update API UpdateCloudRecord: update param Panes.
- Update API UpdateStreamingOut: update param Panes.


2025-01-07 Version: 5.0.0
- Update API DescribeAppRecordTemplates: update response param.


2024-12-16 Version: 4.1.0
- Support API DescribeCloudNotes.
- Support API StartCloudNote.
- Support API StopCloudNote.
- Update API StartCloudRecord: add param LayoutSpecifiedUsers.
- Update API StartStreamingOut: add param LayoutSpecifiedUsers.
- Update API UpdateCloudRecord: add param LayoutSpecifiedUsers.
- Update API UpdateStreamingOut: add param LayoutSpecifiedUsers.


2024-11-07 Version: 4.0.0
- Update API DescribeAppRecordingFiles: update response param.


2024-11-06 Version: 3.4.0
- Support API CreateAppLayout.
- Support API DeleteAppLayout.
- Support API ModifyAppLayout.
- Update API StartCloudRecord: add param Backgrounds.
- Update API StartCloudRecord: add param RegionColor.
- Update API StartStreamingOut: add param Backgrounds.
- Update API StartStreamingOut: add param RegionColor.
- Update API UpdateCloudRecord: add param Backgrounds.
- Update API UpdateStreamingOut: add param Backgrounds.


2024-07-29 Version: 3.3.0
- Support API CreateAppRecordTemplate.
- Support API DeleteAppRecordTemplate.
- Support API DescribeAllCallback.
- Support API DescribeAppCallStatus.
- Support API DescribeAppCallbackSecretKey.
- Support API DescribeAppLayouts.
- Support API DescribeAppLiveStreamStatus.
- Support API DescribeAppRecordStatus.
- Support API DescribeAppRecordTemplates.
- Support API DescribeCallbacks.
- Support API DescribeChannels.
- Support API DescribeStreamingOutStatus.
- Support API DescribeSystemLayoutList.
- Support API ModifyAppCallbackStatus.
- Support API ModifyAppLiveStreamStatus.
- Support API ModifyAppRecordStatus.
- Support API ModifyAppRecordTemplate.
- Support API ModifyCallbackMeta.
- Support API StartCategoryCallback.
- Support API StopCategoryCallback.


2024-06-21 Version: 3.2.0
- Support API DescribeAppRecordingFiles.
- Update API CreateAppStreamingOutTemplate: update param StreamingOutTemplate.
- Update API CreateAppStreamingOutTemplate: update response param.
- Update API ModifyAppStreamingOutTemplate: update param StreamingOutTemplate.
- Update API ModifyAppStreamingOutTemplate: update response param.


2024-06-20 Version: 3.1.0
- Support API UpdateCloudRecord.
- Support API UpdateStreamingOut.
- Update API StartCloudRecord: add param ClockWidgets.
- Update API StartCloudRecord: add param CropMode.
- Update API StartCloudRecord: add param Images.
- Update API StartCloudRecord: add param Texts.
- Update API StartCloudRecord: update param Panes.
- Update API StartCloudRecord: update param StorageConfig.
- Update API StartCloudRecord: update param TemplateId.
- Update API StartStreamingOut: add param ClockWidgets.
- Update API StartStreamingOut: add param CropMode.
- Update API StartStreamingOut: add param Images.
- Update API StartStreamingOut: add param Texts.
- Update API StartStreamingOut: update param Panes.
- Update API StartStreamingOut: update param Url.


2024-06-20 Version: 3.1.0
- Support API UpdateCloudRecord.
- Support API UpdateStreamingOut.
- Update API StartCloudRecord: add param ClockWidgets.
- Update API StartCloudRecord: add param CropMode.
- Update API StartCloudRecord: add param Images.
- Update API StartCloudRecord: add param Texts.
- Update API StartCloudRecord: update param Panes.
- Update API StartCloudRecord: update param StorageConfig.
- Update API StartCloudRecord: update param TemplateId.
- Update API StartStreamingOut: add param ClockWidgets.
- Update API StartStreamingOut: add param CropMode.
- Update API StartStreamingOut: add param Images.
- Update API StartStreamingOut: add param Texts.
- Update API StartStreamingOut: update param Panes.
- Update API StartStreamingOut: update param Url.


2024-05-22 Version: 3.0.1
- Update API DescribeApps: add param AppVersion.


2024-03-21 Version: 3.0.0
- Support API DescribeChannel.
- Support API DescribeChannelAllUsers.
- Support API DescribeChannelUser.
- Support API RemoveUsers.
- Support API StartCloudRecord.
- Support API StartStreamingOut.
- Support API StopChannel.
- Support API StopCloudRecord.
- Support API StopStreamingOut.
- Update API CreateAppStreamingOutTemplate: update param StreamingOutTemplate.
- Update API DescribeAppKey: update response param.
- Update API DescribeAppStreamingOutTemplates: update response param.
- Update API ModifyAppStreamingOutTemplate: update param StreamingOutTemplate.


2024-03-08 Version: 2.0.0
- Support API DescribeChannel.
- Support API DescribeChannelAllUsers.
- Support API DescribeChannelUser.
- Support API RemoveUsers.
- Support API StartCloudRecord.
- Support API StartStreamingOut.
- Support API StopChannel.
- Support API StopCloudRecord.
- Support API StopStreamingOut.
- Update API CreateAppStreamingOutTemplate: update param StreamingOutTemplate.
- Update API DescribeAppKey: update response param.
- Update API DescribeAppStreamingOutTemplates: update response param.
- Update API ModifyAppStreamingOutTemplate: update param StreamingOutTemplate.


2024-02-27 Version: 1.7.0
- Support API DescribeChannel.
- Support API DescribeChannelAllUsers.
- Support API DescribeChannelUser.
- Support API DescribeChannels.
- Support API RemoveUsers.
- Support API StartCloudRecord.
- Support API StartStreamingOut.
- Support API StopChannel.
- Support API StopCloudRecord.
- Support API StopStreamingOut.


2024-01-31 Version: 1.6.0
- Support API CreateAppStreamingOutTemplate.
- Support API DeleteAppStreamingOutTemplate.
- Support API DescribeAppStreamingOutTemplates.
- Support API ModifyAppStreamingOutTemplate.
- Update API DescribeAppsupdate response param.


2023-12-28 Version: 1.5.0
- Generated python 2018-01-11 for rtc.

2023-12-27 Version: 1.4.0
- Generated python 2018-01-11 for rtc.

2022-05-06 Version: 1.3.5
- Add DescribeAppKey interface.

2022-03-28 Version: 1.3.4
- Support more params in text, clockWidget.

2021-12-30 Version: 1.3.3
- Support AUTH for CreateEventSubscribe.

2021-11-25 Version: 1.3.2
- Delete some abandoned interface.
- Add some interfaces.

2021-11-24 Version: 1.3.1
- Delete some abandoned interface in SDK.

2021-11-23 Version: 1.3.0
- Delete some abandoned interface in SDK.
- Add AutoLiveStream series interfaces.
- Add UpdateMPUTask, CreateRecordIndexFile interfaces.

2021-02-20 Version: 1.0.1
- AMP Version Change.

2021-02-20 Version: 1.0.0
- AMP Version Change.


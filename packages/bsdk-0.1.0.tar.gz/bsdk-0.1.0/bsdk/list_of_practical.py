# practical_list = [
#     {"1. Linear Regression": "practical_files/linear_regression.txt"},
#     {"2. Logistic Regression": "practical_files/logistic_regression.txt"},
#     {"3. K-Means Clustering": "practical_files/clustering.txt"},
#     {"4. Decision Trees": "practical_files/decision_tree.txt"},
#     {"5. Support Vector Machine": "practical_files/svm.txt"}
# ]


subject_list = {
    "1" : [
        "1. Algorithm for Optimization",
        "2. Advance database techniques",
        "3. Research methodology",
        "4. Compiler",
        "5. Image Processing",
    ],
    "2" : [],
    "3" : [
        "1. Web3 Technologies",
        "2. Fundamentals of Data Science",
        "3. Data Science",
        "4. Advance Robotics",
    ],
    "4" : [],
}

practical_list = {
    "3": {
        "1": {
            "1" : {
                "name": "Program to implement Digital Signature with PKI",
                "path": "practical_files/sem_3_sub_1_practical_1.txt"
            },
            "2" : {
                "name": "Program to implement for Password storage salt and pepper",
                "path": "practical_files/sem_3_sub_1_practical_2.txt"
            },
            "3": {
                "name": "Write the python script to implement the hashes used for bitcoin-SHA 256",
                "path": "practical_files/sem_3_sub_1_practical_3.txt"
            },
            "4": {
                "name": "Using Python create a blockchain with 3 clients",
                "path": "practical_files/sem_3_sub_1_practical_4.txt"
            },
            "5": {
                "name": "Deriving the Global State or UTXO from a block chain.",
                "path": "practical_files/sem_3_sub_1_practical_5.txt"
            },
            "6": {
                "name": "Write in Python using Keras to Predict Bitcoin Prices using Recurrent Neural Network and a Bitcoin Dataset.",
                "path": "practical_files/sem_3_sub_1_practical_6.txt"
            },
            "7": {
                "name": "Using novel RNN-LSTM architecture for cryptocurrency market analysis. Predicts the actual Bitcoin and Ethereum prices",
                "path": "practical_files/sem_3_sub_1_practical_7.txt"
            },
            "8": {
                "name": "Implement a simple Proof-of-Work scheme to the Minimal working blockchain",
                "path": "practical_files/sem_3_sub_1_practical_8.txt"
            },
            "9": {
                "name": "Implement Consensus as a tool",
                "path": "practical_files/sem_3_sub_1_practical_9.txt"
            },
        },
        "2": {
            "1" : {
                "name": "",
                "path": ""
            },
            "2" : {
                "name": "",
                "path": ""
            },
            "3": {
                "name": "",
                "path": ""
            },
            "4": {
                "name": "",
                "path": ""
            },
            "5": {
                "name": "",
                "path": ""
            },
            "6": {
                "name": "",
                "path": ""
            },
            "7": {
                "name": "",
                "path": ""
            },
            "8": {
                "name": "",
                "path": ""
            },
            "9": {
                "name": "",
                "path": ""
            },
        },
        "3": {
            "1": {
                "name": "",
                "path": ""
            },
            "2": {
                "name": "",
                "path": ""
            },
            "3": {
                "name": "",
                "path": ""
            },
            "4": {
                "name": "",
                "path": ""
            },
            "5": {
                "name": "",
                "path": ""
            },
            "6": {
                "name": "",
                "path": ""
            },
            "7": {
                "name": "",
                "path": ""
            },
            "8": {
                "name": "",
                "path": ""
            },
            "9": {
                "name": "",
                "path": ""
            },
        },
        "4": {
            "1": {
                "name": "",
                "path": ""
            },
            "2": {
                "name": "",
                "path": ""
            },
            "3": {
                "name": "",
                "path": ""
            },
            "4": {
                "name": "",
                "path": ""
            },
            "5": {
                "name": "",
                "path": ""
            },
            "6": {
                "name": "",
                "path": ""
            },
            "7": {
                "name": "",
                "path": ""
            },
            "8": {
                "name": "",
                "path": ""
            },
            "9": {
                "name": "",
                "path": ""
            },
        },
        "5": {
            "1": {
                "name": "",
                "path": ""
            },
            "2": {
                "name": "",
                "path": ""
            },
            "3": {
                "name": "",
                "path": ""
            },
            "4": {
                "name": "",
                "path": ""
            },
            "5": {
                "name": "",
                "path": ""
            },
            "6": {
                "name": "",
                "path": ""
            },
            "7": {
                "name": "",
                "path": ""
            },
            "8": {
                "name": "",
                "path": ""
            },
            "9": {
                "name": "",
                "path": ""
            },
        },
    }
}
"""
Database initialization utilities
"""

from sqlalchemy.orm import Session
from fastapi_core_database.database import Base, engine, SessionLocal
from fastapi_core_models.user import User
from fastapi_core_database.security import get_password_hash


def init_db() -> None:
    """
    Initialize database tables
    Creates all tables defined in models
    """
    Base.metadata.create_all(bind=engine)


def create_superuser(
    username: str ,
    email: str ,
    password: str
) -> User:
    """
    Create a superuser account
    
    Args:
        username: Username for the superuser
        email: Email for the superuser
        password: Password for the superuser
    
    Returns:
        User: Created superuser instance
    """
    db = SessionLocal()
    try:
        # Check if user already exists
        existing_user = db.query(User).filter(
            (User.username == username) | (User.email == email)
        ).first()
        
        if existing_user:
            print(f"⚠ User already exists: {existing_user.username}")
            return existing_user
        
        # Create superuser
        hashed_password = get_password_hash(password)
        superuser = User(
            username=username,
            email=email,
            hashed_password=hashed_password,
            is_active=True,
            is_superuser=True
        )
        
        db.add(superuser)
        db.commit()
        db.refresh(superuser)
        
        print(f"✓ Superuser created successfully: {username}")
        print(f"  Email: {email}")
        print(f"  Password: {password}")
        
        return superuser
    
    except Exception as e:
        db.rollback()
        print(f"✗ Error creating superuser: {e}")
        raise
    finally:
        db.close()


def reset_db() -> None:
    """
    Drop all tables and recreate them
    WARNING: This will delete all data!
    """
    Base.metadata.drop_all(bind=engine)    
    init_db()


if __name__ == "__main__":
    # Initialize database and create superuser
    init_db()
    create_superuser()

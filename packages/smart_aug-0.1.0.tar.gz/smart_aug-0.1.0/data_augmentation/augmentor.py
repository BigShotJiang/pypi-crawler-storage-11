import os
import random
from PIL import Image
from .geometric import flip, rotate, translate, scale, shear, crop, pad


class Augmentor:
    def __init__(self, input_path=None, output_path=None):
        self.input_path = input_path
        if output_path is None:
            if input_path:
                self.output_path = os.path.join(os.path.dirname(input_path), "augmented_output")
            else:
                self.output_path = "augmented_output"
        else:
            self.output_path = output_path

        os.makedirs(self.output_path, exist_ok=True)

    # ==========================================================
    # === Utility Methods ======================================
    # ==========================================================
    def _load_images(self):
        """Load all image paths from the dataset folder."""
        if not self.input_path or not os.path.exists(self.input_path):
            raise FileNotFoundError(f"Input path not found: {self.input_path}")

        image_files = [
            os.path.join(self.input_path, f)
            for f in os.listdir(self.input_path)
            if f.lower().endswith((".jpg", ".jpeg", ".png"))
        ]
        if not image_files:
            raise FileNotFoundError(f"No images found in: {self.input_path}")
        return image_files

    def _save_augmented_image(self, img, base_name, suffix):
        """Save augmented image to output folder."""
        os.makedirs(self.output_path, exist_ok=True)
        save_path = os.path.join(self.output_path, f"{base_name}_{suffix}.jpg")
        img.save(save_path)
        print(f"[SAVED] {save_path}")

    # ==========================================================
    # === Main Dataset-Level Augmentation ======================
    # ==========================================================
    def augment_dataset(self, num_images=None, all_transforms=False):
        """Augment entire dataset or N random images."""
        images = self._load_images()

        if num_images:
            images = random.sample(images, min(num_images, len(images)))

        for img_path in images:
            self.augment_single_image(img_path, all_transforms=all_transforms)

    # ==========================================================
    # === Single Image Augmentation =============================
    # ==========================================================
    def augment_single_image(self, img_path, all_transforms=False):
        """Augment a single image with all or individual transformations."""
        if not os.path.exists(img_path):
            raise FileNotFoundError(f"Image not found: {img_path}")

        img = Image.open(img_path)
        base = os.path.splitext(os.path.basename(img_path))[0]

        if all_transforms:
            # sequentially apply all transformations
            img = flip.random_flip(img)
            img = rotate.random_rotate(img)
            img = translate.random_translate(img)
            img = scale.random_scale(img)
            img = shear.random_shear(img)
            img = crop.random_crop(img)
            img = pad.random_pad(img)
            self._save_augmented_image(img, base, "aug_all")
        else:
            # save each transformed version
            self._save_augmented_image(flip.random_flip(img), base, "flip")
            self._save_augmented_image(rotate.random_rotate(img), base, "rot")
            self._save_augmented_image(translate.random_translate(img), base, "trans")
            self._save_augmented_image(scale.random_scale(img), base, "scale")
            self._save_augmented_image(shear.random_shear(img), base, "shear")
            self._save_augmented_image(crop.random_crop(img), base, "crop")
            self._save_augmented_image(pad.random_pad(img), base, "pad")

    # ==========================================================
    # === Individual Transformation Methods (Single Image) =====
    # ==========================================================
    def flip(self, img_path):
        img = Image.open(img_path)
        base = os.path.splitext(os.path.basename(img_path))[0]
        aug = flip.random_flip(img)
        self._save_augmented_image(aug, base, "flip")

    def rotate(self, img_path):
        img = Image.open(img_path)
        base = os.path.splitext(os.path.basename(img_path))[0]
        aug = rotate.random_rotate(img)
        self._save_augmented_image(aug, base, "rotate")

    def translate(self, img_path):
        img = Image.open(img_path)
        base = os.path.splitext(os.path.basename(img_path))[0]
        aug = translate.random_translate(img)
        self._save_augmented_image(aug, base, "translate")

    def scale(self, img_path):
        img = Image.open(img_path)
        base = os.path.splitext(os.path.basename(img_path))[0]
        aug = scale.random_scale(img)
        self._save_augmented_image(aug, base, "scale")

    def shear(self, img_path):
        img = Image.open(img_path)
        base = os.path.splitext(os.path.basename(img_path))[0]
        aug = shear.random_shear(img)
        self._save_augmented_image(aug, base, "shear")

    def crop(self, img_path):
        img = Image.open(img_path)
        base = os.path.splitext(os.path.basename(img_path))[0]
        aug = crop.random_crop(img)
        self._save_augmented_image(aug, base, "crop")

    def pad(self, img_path):
        img = Image.open(img_path)
        base = os.path.splitext(os.path.basename(img_path))[0]
        aug = pad.random_pad(img)
        self._save_augmented_image(aug, base, "pad")

    # ==========================================================
    # === Bulk Augmentation Helpers =============================
    # ==========================================================
    def flip_images(self, num_images=None):
        images = self._load_images()
        if num_images:
            images = random.sample(images, min(num_images, len(images)))
        for img_path in images:
            self.flip(img_path)

    def rotate_images(self, num_images=None):
        images = self._load_images()
        if num_images:
            images = random.sample(images, min(num_images, len(images)))
        for img_path in images:
            self.rotate(img_path)

    def translate_images(self, num_images=None):
        images = self._load_images()
        if num_images:
            images = random.sample(images, min(num_images, len(images)))
        for img_path in images:
            self.translate(img_path)

    def scale_images(self, num_images=None):
        images = self._load_images()
        if num_images:
            images = random.sample(images, min(num_images, len(images)))
        for img_path in images:
            self.scale(img_path)

    def shear_images(self, num_images=None):
        images = self._load_images()
        if num_images:
            images = random.sample(images, min(num_images, len(images)))
        for img_path in images:
            self.shear(img_path)

    def crop_images(self, num_images=None):
        images = self._load_images()
        if num_images:
            images = random.sample(images, min(num_images, len(images)))
        for img_path in images:
            self.crop(img_path)

    def pad_images(self, num_images=None):
        images = self._load_images()
        if num_images:
            images = random.sample(images, min(num_images, len(images)))
        for img_path in images:
            self.pad(img_path)

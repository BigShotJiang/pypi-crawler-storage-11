import random
from PIL import Image

def random_scale(img: Image.Image, scale_range=(0.8, 1.2)):
    scale = random.uniform(*scale_range)
    w, h = img.size
    new_size = (int(w * scale), int(h * scale))
    img = img.resize(new_size, Image.BICUBIC)
    return img.resize((w, h), Image.BICUBIC)

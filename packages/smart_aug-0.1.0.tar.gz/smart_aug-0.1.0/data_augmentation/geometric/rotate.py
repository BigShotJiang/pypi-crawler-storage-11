import random
from PIL import Image

def random_rotate(img: Image.Image, max_angle=15):
    angle = random.uniform(-max_angle, max_angle)
    return img.rotate(angle)

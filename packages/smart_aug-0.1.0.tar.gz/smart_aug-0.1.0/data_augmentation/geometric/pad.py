import random
from PIL import Image, ImageOps

def random_pad(img: Image.Image, max_pad=20):
    pad = random.randint(0, max_pad)
    return ImageOps.expand(img, border=pad, fill="black")

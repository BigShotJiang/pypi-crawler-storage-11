import random
from PIL import Image

def random_translate(img: Image.Image, shift_range=0.1):
    w, h = img.size
    dx = random.uniform(-shift_range, shift_range) * w
    dy = random.uniform(-shift_range, shift_range) * h
    return img.transform(img.size, Image.AFFINE, (1, 0, dx, 0, 1, dy))

import random
from PIL import Image

def random_crop(img: Image.Image, crop_percent=0.9):
    w, h = img.size
    new_w, new_h = int(w * crop_percent), int(h * crop_percent)
    left = random.randint(0, w - new_w)
    top = random.randint(0, h - new_h)
    img = img.crop((left, top, left + new_w, top + new_h))
    return img.resize((w, h))

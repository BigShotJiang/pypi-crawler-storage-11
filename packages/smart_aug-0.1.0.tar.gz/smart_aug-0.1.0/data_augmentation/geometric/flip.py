import random
from PIL import Image

def random_flip(img: Image.Image) -> Image.Image:
    flip_type = random.choice(["H", "V", "None"])
    if flip_type == "H":
        return img.transpose(Image.FLIP_LEFT_RIGHT)
    elif flip_type == "V":
        return img.transpose(Image.FLIP_TOP_BOTTOM)
    return img

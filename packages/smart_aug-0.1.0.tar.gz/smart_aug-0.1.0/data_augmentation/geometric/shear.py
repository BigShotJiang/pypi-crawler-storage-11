import random
from PIL import Image

def random_shear(img: Image.Image, shear_range=0.2):
    shear = random.uniform(-shear_range, shear_range)
    return img.transform(img.size, Image.AFFINE, (1, shear, 0, shear, 1, 0))

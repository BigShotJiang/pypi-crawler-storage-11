from setuptools import setup, find_packages

setup(
    name="smart-aug",                # package name (use hyphen)
    version="0.1.0",
    author="Divine Gupta",
    author_email="guptadivine0611@gmail.com",
    description="An advanced image data augmentation library with geometric transforms.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pillow",
        "numpy",
        "scikit-image"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)

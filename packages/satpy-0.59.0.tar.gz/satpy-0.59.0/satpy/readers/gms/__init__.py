"""GMS reader module."""

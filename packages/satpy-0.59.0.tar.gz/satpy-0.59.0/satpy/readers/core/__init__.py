"""Reader core package."""

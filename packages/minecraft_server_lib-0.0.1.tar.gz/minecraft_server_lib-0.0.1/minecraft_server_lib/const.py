headers = {
    "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0"
}

eula = """#By changing the setting below to TRUE you are indicating your agreement to our EULA (https://aka.ms/MinecraftEULA).
#Tue Oct 28 13:24:51 CST 2025
eula=true

"""

# Errors

class ConnectionError(Exception):
    def __init__(self, msg):
        super().__init__(msg)

class RequestException(Exception):
    def __init__(self, msg):
        super().__init__(msg)

class ThisServerVersionDoesNotExistError(Exception):
    def __init__(self, msg):
        super().__init__(msg)

class ThisServerServerPropertiesDoesNotExistError(Exception):
    def __init__(self, msg):
        super().__init__(msg)
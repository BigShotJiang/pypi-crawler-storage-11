import os
from . import const
import subprocess




def get_launcher_minecraft_server_command(version_id : str, server_dir : str, nougui = True,other_args = ["-Xmx1024M", "-Xms1024M"], java = "java") -> list:
    server_path = os.path.join(server_dir, version_id, "server.jar")
    if not os.path.exists(server_path):
        raise const.ThisServerVersionDoesNotExistError(f"要启动的Minecraft服务器核心不存在与 {server_path}")
    

    
    rusult = [java,"-jar",server_path]
    if nougui:
        rusult + ["nogui"]

    rusult + other_args
    return rusult





if __name__ == "__main__":
    import subprocess
    subprocess.run(get_launcher_minecraft_server_command(version_id="1.20.4",server_dir=r"e:\Minecraft_Server_Lib\test"))
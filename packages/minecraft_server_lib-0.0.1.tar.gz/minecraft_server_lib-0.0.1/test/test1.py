import minecraft_server_lib as msl # https://www.fastmirror.net/#/home

print(msl.__all__)
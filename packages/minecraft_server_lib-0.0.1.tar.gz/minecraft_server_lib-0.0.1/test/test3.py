import minecraft_server_lib as msl
import os,subprocess


command = msl.launcher.get_launcher_minecraft_server_command(version_id="1.20.4", server_dir="test\\test", java="java")

os.chdir(r"e:\Minecraft_Server_Lib\test\test\1.20.4")

msl.utils.setup_minecraft_server_eula(version_id="1.20.4", server_dir="test\\test")
subprocess.run(command)
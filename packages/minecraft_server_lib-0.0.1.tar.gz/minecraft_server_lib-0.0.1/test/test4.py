import minecraft_server_lib as msl

content = msl.utils.read_minecraft_server_properties(version_id="1.20.4", server_dir="test\\test")
content['online-mode'] = "false"
msl.utils.write_minecraft_server_properties(version_id="1.20.4", server_dir="test\\test", content=content)
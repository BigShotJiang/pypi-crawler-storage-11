import minecraft_server_lib as msl # https://github.com/FastMirror-MC/FastMirrorServer

# https://api.minecraftservices.com/minecraft/profile/lookup/853c80ef3c3749fdaa49938b674adae6


current_max = 0


def set_status(status: str):
    print("\n"+status)


def set_progress(progress: int):
    if current_max != 0:
        print(f"{progress}/{current_max}\r", end="")


def set_max(new_max: int):
    global current_max
    current_max = new_max



callback = {
    "setStatus": set_status,
    "setProgress": set_progress,
    "setMax": set_max
}



msl.install.install_minecraft_server(version_id="1.20.4", server_dir="test\\test", call_back=callback)

# minecraft-server-lib

This is a library to control minecraft server
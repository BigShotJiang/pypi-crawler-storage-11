CURV_CONFIG ?= default

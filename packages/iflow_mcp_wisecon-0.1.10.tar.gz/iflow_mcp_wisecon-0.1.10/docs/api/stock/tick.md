::: wisecon.stock.tick.tick

-----

"""Test suite for putplace."""

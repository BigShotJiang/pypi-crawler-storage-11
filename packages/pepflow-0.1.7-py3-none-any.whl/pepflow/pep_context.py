# Copyright: 2025 The PEPFlow Developers
#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING

import attrs
import natsort
import pandas as pd

from pepflow import constraint as ct
from pepflow import utils

if TYPE_CHECKING:
    from pepflow.function import Function, Triplet
    from pepflow.operator import Duplet, Operator
    from pepflow.scalar import Scalar
    from pepflow.vector import Vector

# A global variable for storing the current context that manages objects
# such as vectors and scalars.
CURRENT_CONTEXT: PEPContext | None = None
# Keep the track of all previous created contexts.
GLOBAL_CONTEXT_DICT: dict[str, PEPContext] = {}
# Keep the track of all created functions.
REGISTERED_FUNC_DICT: dict[str, Function] = {}
# Keep the track of all created operators.
REGISTERED_OPER_DICT: dict[str, Operator] = {}


@attrs.frozen
class ConstraintData:
    """
    A data class that will store a :class:`Function`'s or :class:`Operator`'s
    interpolation conditions.

    Functions and operators can have multiple groups of interpolations conditions.
    There are typically two types of groups. One group is composed of associated
    :class:`ScalarConstraint` objects. The other is an individual
    :class:`PSDConstraint` object.

    Attributes:
        func_or_oper (:class:`Function` | :class:`Operator): The associated
            :class:`Function` or :class:`Operator.
        sc_dict (dict[str, list[:class:`ScalarConstraint`]]): A dictionary in which
            the keys are the name of the groups of :class:`ScalarConstraint` objects and
            the values are a list of associated :class:`ScalarConstraint` objects.
        psd_dict (dict[str, :class:`PSDConstraint`]): A dictionary in which the keys
            are the names of the types of the :class:`PSDConstraint` objects and the values
            are the :class:`PSDConstraint` objects.
    """

    func_or_oper: Function | Operator
    sc_dict: dict[str, list[ct.ScalarConstraint]] = attrs.field(factory=dict)
    psd_dict: dict[str, ct.PSDConstraint] = attrs.field(factory=dict)

    def add_sc_constraint(
        self, constraint_type: str, scal_constraint: list[ct.ScalarConstraint]
    ) -> None:
        """Add a new list of :class:`ScalarConstraint` objects.

        Args:
            constraint_type (str): The name to refer to the group of scalar
                constraints repesented by `scal_constraint`.
            scal_constraint (list[:class:`ScalarConstraint`]): The new list of
                :class:`ScalarConstraint` objects to add.
        """
        self.sc_dict[constraint_type] = scal_constraint

    def add_psd_constraint(
        self, constraint_type: str, psd_constraint: ct.PSDConstraint
    ) -> None:
        """Add a new :class:`PSDConstraint` object.

        Args:
            constraint_type (str): The name to refer to the group of scalar
                constraints repesented by `scal_constraint`.
            psd_constraint (:class:`PSDConstraint`): The new list of
                :class:`ScalarConstraint` objects to add.
        """
        self.psd_dict[constraint_type] = psd_constraint

    def process(self, ctx: PEPContext) -> ProcessedConstraintData:
        """Process this :class:`ConstraintData` object and create a
        :class:`ProcessedConstraintData` object.

        The dataframe has the columns "constraint_name",
        "col_point", "row_point", "row", and "col".
        """
        sc_df_dict = {}
        for name, sc in self.sc_dict.items():
            df = pd.DataFrame(
                [
                    (
                        constraint.name,
                        *utils.name_to_vector_tuple(constraint.name),
                    )
                    for constraint in sc
                ],
                columns=["constraint_name", "col_point", "row_point"],
            )
            order_col = natsort.natsorted(list(set(df["col_point"].tolist())))
            order_row = natsort.natsorted(list(set(df["row_point"].tolist())))
            df["row"] = df["row_point"].map(lambda x: order_row.index(x))
            df["col"] = df["col_point"].map(lambda x: order_col.index(x))
            df.attrs = {"order_row": order_row, "order_col": order_col}
            sc_df_dict[name] = df
        psd_name_dict = {}
        for name, psd in self.psd_dict.items():
            psd_name_dict[name] = psd.name
        return ProcessedConstraintData(self.func_or_oper, sc_df_dict, psd_name_dict)


@attrs.frozen
class ProcessedConstraintData:
    """
    A data class that stores the results of processing the data stored in a
    :class:`ConstraintData` object to prepare it for figure generation.

    Attributes:
        func_or_oper (:class:`Function` | :class:`Operator): The associated
            :class:`Function` or :class:`Operator.
        sc_df_dict (dict[str, pd.Dataframe)]): A dictionary in which
            the keys are the name of the groups of :class:`ScalarConstraint` objects
            and the values are a pd.Dataframe which holds organized data related to
            a list of :class:`ScalarConstraint`objects.
        psd_name_dict (dict[str, str]): A dictionary in which the key
            is the name of the type of the :class:`PSDConstraint` object and the value
            a :class:`PSDConstraint` object `name` attribute.
    """

    func_or_oper: Function | Operator
    sc_df_dict: dict[str, pd.DataFrame]
    psd_name_dict: dict[str, str]


def get_current_context() -> PEPContext | None:
    """
    Return the current global :class:`PEPContext`.

    Returns:
        :class:`PEPContext`: The current global :class:`PEPContext`.
    """
    return CURRENT_CONTEXT


def set_current_context(ctx: PEPContext | None):
    """
    Change the current global :class:`PEPContext`.

    Args:
        ctx (:class:`PEPContext`): The :class:`PEPContext` to set as the new
            global :class:`PEPContext`.
    """
    global CURRENT_CONTEXT
    assert ctx is None or isinstance(ctx, PEPContext)
    CURRENT_CONTEXT = ctx


def get_all_processed_constraint_data(
    ctx: PEPContext,
) -> list[ProcessedConstraintData]:
    from pepflow.operator import LinearOperatorTranspose

    list_of_pcd = []

    for func in ctx.triplets.keys():
        list_of_pcd.append(func.get_interpolation_constraints_by_group().process(ctx))

    for oper in ctx.duplets.keys():
        if isinstance(oper, LinearOperatorTranspose):
            continue
        list_of_pcd.append(oper.get_interpolation_constraints_by_group().process(ctx))

    return list_of_pcd


def get_processed_constraint_data(
    ctx: PEPContext, func_or_oper: Function | Operator
) -> ProcessedConstraintData:
    from pepflow.operator import LinearOperatorTranspose

    if (
        func_or_oper not in ctx.triplets.keys()
        and func_or_oper not in ctx.duplets.keys()
    ):
        raise ValueError(
            "This function or operator has no associated triplets or duplets for this given context."
        )
    if isinstance(func_or_oper, LinearOperatorTranspose):
        raise ValueError(
            "Do not pass in an object of the class LinearOperatorTranspose."
        )

    return func_or_oper.get_interpolation_constraints_by_group().process(ctx)


class PEPContext:
    """
    A :class:`PEPContext` object is a context manager which maintains
    the abstract mathematical objects of the Primal and Dual PEP.

    Attributes:
        name (str): The unique name of the :class:`PEPContext` object.
    """

    def __init__(self, name: str):
        self.name = name
        self.vectors: list[Vector] = []
        self.scalars: list[Scalar] = []
        self.triplets: dict[Function, list[Triplet]] = defaultdict(list)
        # self.triplets will contain all stationary_triplets. They are not mutually exclusive.
        self.stationary_triplets: dict[Function, list[Triplet]] = defaultdict(list)
        self.duplets: dict[Operator, list[Duplet]] = defaultdict(list)
        # self.duplets will contain all fixed_duplets and zero_duplets. They are not mutually exclusive.
        self.fixed_duplets: dict[Operator, list[Duplet]] = defaultdict(list)
        self.zero_duplets: dict[Operator, list[Duplet]] = defaultdict(list)

        GLOBAL_CONTEXT_DICT[name] = self

    def set_as_current(self) -> PEPContext:
        """
        Set this :class:`PEPContext` object as the global context.

        Returns:
            :class:`PEPContext`: This :class:`PEPContext` object.
        """
        set_current_context(self)
        return self

    def add_vector(self, vector: Vector):
        self.vectors.append(vector)

    def add_scalar(self, scalar: Scalar):
        self.scalars.append(scalar)

    def add_triplet(self, function: Function, triplet: Triplet):
        self.triplets[function].append(triplet)

    def add_stationary_triplet(self, function: Function, stationary_triplet: Triplet):
        self.stationary_triplets[function].append(stationary_triplet)

    def add_duplet(self, oper: Operator, duplet: Duplet):
        self.duplets[oper].append(duplet)

    def add_fixed_duplet(self, oper: Operator, duplet: Duplet):
        self.fixed_duplets[oper].append(duplet)

    def add_zero_duplet(self, oper: Operator, duplet: Duplet):
        self.zero_duplets[oper].append(duplet)

    def get_by_tag(self, tag: str) -> Vector | Scalar:
        """
        Under this :class:`PEPContext`, get the :class:`Vector` or
        :class:`Scalar` object associated with the provided `tag`.

        Args:
            tag (str): The tag of the :class:`Vector` or :class:`Scalar` object
                we want to retrieve.

        Returns:
            :class:`Vector` | :class:`Scalar`: The :class:`Vector` or
            :class:`Scalar` object associated with the provided `tag`.
        """
        for p in self.vectors:
            if tag in p.tags:
                return p
        for s in self.scalars:
            if tag in s.tags:
                return s
        raise ValueError("Cannot find the vector, scalar, or function of given tag.")

    def get_triplet_by_point_tag(
        self, point_or_tag: Vector | str, func: Function
    ) -> Triplet:
        """Returns a triplet of the given point or its tag in the function."""
        from pepflow.vector import Vector

        if func not in self.triplets:
            raise ValueError(
                f"Cannot find the triplets associated with {func=} in the context."
            )
        triplets = self.triplets[func]
        if isinstance(point_or_tag, Vector):
            for t in triplets:
                if t.point == point_or_tag:
                    return t
        else:
            for t in triplets:
                if point_or_tag in t.point.tags:
                    return t
        raise ValueError(f"Cannot find the triplet associated with {point_or_tag}")

    def clear(self):
        """Reset this :class:`PEPContext` object."""
        self.vectors.clear()
        self.scalars.clear()
        self.triplets.clear()
        self.stationary_triplets.clear()
        self.duplets.clear()
        self.fixed_duplets.clear()
        self.zero_duplets.clear()

    def tracked_point(self, func_or_oper: Function | Operator) -> list[Vector]:
        """
        Returns a list of the visited vectors :math:`\\{x_i\\}` associated with
        `func_or_oper` under this :class:`PEPContext`.

        Each function :math:`f` used in Primal and Dual PEP is associated with
        a set of triplets :math:`\\{x_i, f(x_i), \\nabla f(x_i)\\}` visited by
        the considered algorithm. We can also consider a subgradient
        :math:`\\widetilde{\\nabla} f(x)` instead of the gradient.

        Args:
            func_or_oper (:class:`Function` | :class:`Operator`): This is either
                the function associated with the set of triplets
                :math:`\\{x_i, f(x_i), \\nabla f(x_i)\\}` or the operator
                associated with the set of duplets :math:`\\{x_i, A(x_i)\\}`.

        Returns:
            list[:class:`Vector`]: The list of the visited vectors
            :math:`\\{x_i\\}`.
        """

        if (triplets := self.triplets.get(func_or_oper)) is not None:  # ty: ignore
            return natsort.natsorted(
                [t.point for t in triplets],
                key=lambda x: x.tag,
            )
        elif (duplets := self.duplets.get(func_or_oper)) is not None:  # ty: ignore
            return natsort.natsorted(
                [t.point for t in duplets],
                key=lambda x: x.tag,
            )
        raise ValueError(
            "The provided Function or Operator does not have any associated triplets or duplets in this context."
        )

    def tracked_grad(self, func: Function) -> list[Vector]:
        """
        This function returns a list of the visited
        gradients :math:`\\{\\nabla f(x_i)\\}` under this :class:`PEPContext`.

        Each function :math:`f` used in Primal and Dual PEP is associated with
        a set of triplets :math:`\\{x_i, f(x_i), \\nabla f(x_i)\\}` visited by
        the considered algorithm. We can also consider a subgradient
        :math:`\\widetilde{\\nabla} f(x)` instead of the gradient
        :math:`\\nabla f(x_i)`.

        Args:
            func (:class:`Function`): The function associated with the set
                of triplets :math:`\\{x_i, f(x_i), \\nabla f(x_i)\\}`.

        Returns:
            list[:class:`Vector`]: The list of the visited gradients
            :math:`\\{\\nabla f(x_i)\\}`.
        """
        if (triplets := self.triplets.get(func)) is not None:
            return natsort.natsorted([t.grad for t in triplets], key=lambda x: x.tag)
        raise ValueError(
            "The provided Function does not have any associated triplets in this context."
        )

    def tracked_func_val(self, func: Function) -> list[Scalar]:
        """
        This function returns a list of the visited
        function values :math:`\\{f(x_i)\\}` under this :class:`PEPContext`.

        Each function :math:`f` used in Primal and Dual PEP is associated with
        a set of triplets :math:`\\{x_i, f(x_i), \\nabla f(x_i)\\}` visited by
        the considered algorithm. We can also consider a subgradient
        :math:`\\widetilde{\\nabla} f(x)` instead of the gradient
        :math:`\\nabla f(x_i)`.

        Args:
            func (:class:`Function`): The function associated with the set of
                triplets :math:`\\{x_i, f(x_i), \\nabla f(x_i)\\}`.

        Returns:
            list[:class:`Scalar`]: The list of the visited function values
            :math:`\\{f(x_i)\\}`.
        """
        if (triplets := self.triplets.get(func)) is not None:
            return natsort.natsorted(
                [t.func_val for t in triplets], key=lambda x: x.tag
            )
        raise ValueError(
            "The provided Function does not have any associated triplets in this context."
        )

    def tracked_output(self, oper: Operator) -> list[Vector]:
        """
        This function returns a list of the visited
        outputs :math:`\\{A(x_i)\\}` under this :class:`PEPContext`.

        Each operator :math:`A` used in Primal and Dual PEP is associated with
        a set of duplets :math:`\\{x_i, A(x_i)\\}` visited by the considered
        algorithm.

        Args:
            oper (:class:`Operator`): The operator associated with the set
                of duplets :math:`\\{x_i, A(x_i)\\}`.

        Returns:
            list[:class:`Vector`]: The list of the visited outputs
            :math:`\\{A(x_i)\\}`.
        """
        if (duplets := self.duplets.get(oper)) is not None:
            return natsort.natsorted([t.output for t in duplets], key=lambda x: x.tag)
        raise ValueError(
            "The provided Operator does not have any associated duplets in this context."
        )

    def order_of_point(self, func_or_oper: Function | Operator) -> list[str]:
        if (triplets := self.triplets.get(func_or_oper)) is not None:  # ty: ignore
            return natsort.natsorted([t.point.tag for t in triplets])
        elif (duplets := self.duplets.get(func_or_oper)) is not None:  # ty: ignore
            return natsort.natsorted([t.point.tag for t in duplets])
        raise ValueError(
            "The provided Function or Operator does not have any associated triplets or duplets in this context."
        )

    def basis_vectors(self) -> list[Vector]:
        """
        Return a list of the basis :class:`Vector` objects managed by this
        :class:`PEPContext`.

        Returns:
            list[:class:`Vector`]: A list of the basis :class:`Vector` objects
            managed by this :class:`PEPContext`.
        """
        return [
            p for p in self.vectors if p.is_basis
        ]  # Note the order is always the same as added time

    def basis_scalars(self) -> list[Scalar]:
        """
        Return a list of the basis :class:`Scalar` objects managed by this
        :class:`PEPContext`.

        Returns:
            list[:class:`Scalar`]: A list of the basis :class:`Scalar` objects
            managed by this :class:`PEPContext`.
        """
        return [
            s for s in self.scalars if s.is_basis
        ]  # Note the order is always the same as added time

# Copyright: 2025 The PEPFlow Developers
#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from __future__ import annotations

import json
from collections.abc import Hashable
from typing import TYPE_CHECKING

import attrs
import dash
import dash_bootstrap_components as dbc
import numpy as np
import pandas as pd
import plotly
import plotly.graph_objects as go
from dash import ALL, MATCH, Dash, Input, Output, State, dcc, html

from pepflow import utils
from pepflow.constants import PSD_CONSTRAINT

if TYPE_CHECKING:
    from pepflow.function import Function
    from pepflow.operator import Operator
    from pepflow.pep import PEPBuilder, PEPResult
    from pepflow.pep_context import PEPContext


plotly.io.renderers.default = "colab+vscode"
plotly.io.templates.default = "plotly_white"


@attrs.frozen
class PrimalPlotData:
    func_or_oper: Function | Operator
    df_dict: dict[str, pd.DataFrame]
    fig_dict: dict[str, go.Figure]
    psd_dv_dict: dict[str, str]

    def dual_matrix_to_tab(self, name: str, df: pd.DataFrame) -> html.Pre:
        with np.printoptions(precision=3, linewidth=100, suppress=True):
            dual_value_tab = html.Pre(
                str(utils.get_matrix_of_dual_value(df)),
                id={
                    "type": "dual-value-display",
                    "index": f"{self.func_or_oper.tag}-{name}",
                },
                style={
                    "border": "1px solid lightgrey",
                    "padding": "10px",
                    "height": "60vh",
                    "overflowY": "auto",
                },
            )
        return dual_value_tab

    def make_list_of_scalar_constraint_tabs(self) -> list[dbc.Tab]:
        list_of_tabs = [
            dbc.Tab(
                html.Div(
                    [
                        html.P("Interactive Heat Map:"),
                        dcc.Graph(
                            id={
                                "type": "interactive-scatter",
                                "index": f"{self.func_or_oper.tag}-{name}",
                            },
                            figure=fig,
                        ),
                        html.P("Dual Value Matrix:"),
                        self.dual_matrix_to_tab(name, df),
                    ]
                ),
                label=f"{name}",
                tab_id=f"{self.func_or_oper.tag}-{name}-interactive-constraint-tab",
            )
            for (name, fig), (_, df) in zip(self.fig_dict.items(), self.df_dict.items())
        ]
        return list_of_tabs

    def make_list_of_psd_constraint_tabs(self) -> list[dbc.Tab]:
        list_of_tabs = [
            dbc.Tab(
                html.Div(
                    [
                        html.P("Dual Value Matrix:"),
                        html.Pre(
                            psd_dv,
                            id={
                                "type": "psd-display",
                                "index": f"{self.func_or_oper.tag}-{name}",
                            },
                        ),
                    ]
                ),
                label=f"{name}",
                tab_id=f"{self.func_or_oper.tag}-{name}-interactive-constraint-tab",
            )
            for name, psd_dv in self.psd_dv_dict.items()
        ]
        return list_of_tabs

    def plot_data_to_tab(self) -> dbc.Tab:
        list_sc_tabs = self.make_list_of_scalar_constraint_tabs()
        list_psd_tabs = self.make_list_of_psd_constraint_tabs()
        if len(list_sc_tabs) + len(list_psd_tabs) > 1:
            tabs = dbc.Tab(
                children=[
                    dbc.Tabs(
                        [
                            *self.make_list_of_scalar_constraint_tabs(),
                            *self.make_list_of_psd_constraint_tabs(),
                        ],
                    )
                ],
                label=f"{self.func_or_oper.tag} Interpolation Conditions",
            )
        else:
            tabs = dbc.Tab(
                children=[
                    html.Div(
                        [
                            *self.make_list_of_scalar_constraint_tabs(),
                            *self.make_list_of_psd_constraint_tabs(),
                        ],
                    )
                ],
                label=f"{self.func_or_oper.tag} Interpolation Conditions",
            )
        return tabs

    def df_dict_to_dcc_store_list(self) -> list[dcc.Store]:
        dcc_store_list = []
        for name, df in self.df_dict.items():
            dcc_store_list.append(
                dcc.Store(
                    id={
                        "type": "dataframe-store",
                        "index": f"{self.func_or_oper.tag}-{name}",
                    },
                    data=(self.func_or_oper.tag, df.to_dict("records"), df.attrs),
                )
            )
        return dcc_store_list

    def psd_dv_dict_to_dcc_store_list(self) -> list[dcc.Store]:
        dcc_store_list = []
        for name, psd_dv in self.psd_dv_dict.items():
            dcc_store_list.append(
                dcc.Store(
                    id={
                        "type": "psd-dv-store",
                        "index": f"{self.func_or_oper.tag}-{name}",
                    },
                    data=(
                        self.func_or_oper.tag,
                        psd_dv,
                    ),
                )
            )
        return dcc_store_list


def solve_primal_prob_and_get_plot_data(
    pep_builder: PEPBuilder,
    context: PEPContext,
    resolve_parameters: dict[str, utils.NUMERICAL_TYPE] | None = None,
) -> tuple[list[PrimalPlotData], PEPResult]:
    from pepflow.operator import LinearOperatorTranspose

    plot_data_list = []

    result = pep_builder.solve_primal(
        context=context, resolve_parameters=resolve_parameters
    )

    for f in context.triplets.keys():
        primal_plot_data = f.get_primal_plot_data_from_result(
            context, result, pep_builder
        )

        plot_data_list.append(primal_plot_data)

    for oper in context.duplets.keys():
        # Skip LinearOperator objects because they should not have interpolation conditions implemented.
        if isinstance(oper, LinearOperatorTranspose):
            continue
        primal_plot_data = oper.get_primal_plot_data_from_result(
            context, result, pep_builder
        )

        plot_data_list.append(primal_plot_data)
    return plot_data_list, result


def launch_primal_interactive(
    pep_builder: PEPBuilder,
    context: PEPContext,
    resolve_parameters: dict[str, utils.NUMERICAL_TYPE] | None = None,
    port: int = 8050,
):
    app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
    plot_data_list, result = solve_primal_prob_and_get_plot_data(
        pep_builder, context, resolve_parameters
    )
    display_row = dbc.Row(
        [
            # Column 1: The scatter plots of dual variables and buttons to relax or restore constraints.
            dbc.Col(
                [
                    dbc.Button(
                        "Relax All Constraints",
                        id="relax-all-constraints-button",
                        style={"margin-bottom": "5px", "margin-right": "5px"},
                    ),
                    dbc.Button(
                        "Restore All Constraints",
                        id="restore-all-constraints-button",
                        style={"margin-bottom": "5px"},
                        color="success",
                    ),
                    dbc.Tabs(
                        children=[
                            plot_data.plot_data_to_tab() for plot_data in plot_data_list
                        ],
                    ),
                ],
                width=5,
            ),
            # Column 2: The data display and area to add constraints to dual variables.
            dbc.Col(
                [
                    dbc.Button(
                        "Solve PEP Problem",
                        id="solve-button",
                        color="primary",
                        className="me-1",
                        style={"margin-bottom": "5px"},
                    ),
                    dcc.Loading(
                        dbc.Card(
                            id="result-card",
                            style={"height": "60vh", "overflow-y": "auto"},
                        )
                    ),
                ],
                width=7,
            ),
        ],
    )

    dcc_store_list = []
    for plot_data in plot_data_list:
        dcc_store_list.extend(plot_data.df_dict_to_dcc_store_list())
    for plot_data in plot_data_list:
        dcc_store_list.extend(plot_data.psd_dv_dict_to_dcc_store_list())

    # 3. Define the app layout.
    app.layout = html.Div(
        [
            html.H2("PEPFlow"),
            display_row,
            # For each function/operator interpolation group, store the corresponding
            # DataFrame/Dual Value Matrix as a dictionary in dcc.Store.
            *dcc_store_list,
        ]
    )

    @dash.callback(
        Output("result-card", "children"),
        Output({"type": "dual-value-display", "index": ALL}, "children"),
        Output({"type": "interactive-scatter", "index": ALL}, "figure"),
        Output({"type": "dataframe-store", "index": ALL}, "data"),
        Output({"type": "psd-dv-store", "index": ALL}, "data"),
        Input("solve-button", "n_clicks"),
    )
    def solve(_):
        plot_data_list, result = solve_primal_prob_and_get_plot_data(
            pep_builder, context, resolve_parameters
        )

        with np.printoptions(precision=3, linewidth=500, suppress=True):
            psd_dual_value = np.array(
                result.dual_var_manager.dual_value(PSD_CONSTRAINT)
            )
            result_card = dbc.CardBody(
                [
                    html.H3(f"Optimal Value: {result.primal_opt_value:.4g}"),
                    html.H3(f"Solver Status: {result.solver_status}"),
                    html.P("PSD Dual Variable:"),
                    html.Pre(str(psd_dual_value)),
                    html.P("Relaxed Constraints:"),
                    html.Div(
                        style={
                            "display": "flex",
                            "gap": "10px",
                            "flexDirection": "row",
                        },
                        children=[
                            html.Pre(
                                json.dumps(pep_builder.relaxed_constraints, indent=2),
                                id="relaxed-constraints",
                            ),
                            dcc.Clipboard(
                                id="relaxed-constraint-copy",
                                target_id="relaxed-constraints",
                                style={
                                    "fontSize": 20,
                                },
                            ),
                        ],
                    ),
                ]
            )
            dual_value_displays = []
            for plot_data in plot_data_list:
                for df in plot_data.df_dict.values():
                    dual_value_displays.append(str(utils.get_matrix_of_dual_value(df)))
        # List that stores all the corresponding figures from the list of plot_data.
        figs: list[go.Figure] = []
        # List that stores all the corresponding information related to the dataframes from the list of plot_data.
        # Specifically, it stores tuples of the form (func_or_oper.tag, df.to_dict("records"), df.attrs).
        # The df.attrs stores the order of the row and column points as a dictionary. Specifically,
        # it is of the form {"order_row": order_row, "order_col": order_col}.
        df_data: list[
            tuple[str, list[dict[str, str]], dict[Hashable, list[str]]]
        ] = []  #
        # List that stores all the corresponding information related to psd constraint from the list of plot_data.
        # Specifically, it stores tuples of the form (func_or_oper.tag, psd_dv).
        psd_dv_data: list[tuple[str, str]] = []
        for plot_data in plot_data_list:
            for fig in plot_data.fig_dict.values():
                figs.append(fig)
            for df in plot_data.df_dict.values():
                df_data.append(
                    (plot_data.func_or_oper.tag, df.to_dict("records"), df.attrs)
                )
            for psd_dv in plot_data.psd_dv_dict.values():
                psd_dv_data.append((plot_data.func_or_oper.tag, psd_dv))
        return result_card, dual_value_displays, figs, df_data, psd_dv_data

    @dash.callback(
        Output(
            {"type": "interactive-scatter", "index": ALL},
            "figure",
            allow_duplicate=True,
        ),
        Output({"type": "dataframe-store", "index": ALL}, "data", allow_duplicate=True),
        Input("restore-all-constraints-button", "n_clicks"),
        State({"type": "dataframe-store", "index": ALL}, "data"),
        prevent_initial_call=True,
    )
    def restore_all_constraints(_, list_previous_df_tuples):
        nonlocal pep_builder
        pep_builder.relaxed_constraints = []
        updated_figs = []
        df_data = []
        for previous_df_tuple in list_previous_df_tuples:
            tag, previous_df, df_attrs = previous_df_tuple
            df_updated = pd.DataFrame(previous_df)
            df_updated["constraint"] = "active"
            func_or_oper = pep_builder.get_func_or_oper_by_tag(tag)
            updated_figs.append(
                func_or_oper.get_primal_fig_from_df_and_order(df_updated, df_attrs)
            )
            df_data.append((tag, df_updated.to_dict("records"), df_attrs))
        return updated_figs, df_data

    @dash.callback(
        Output(
            {"type": "interactive-scatter", "index": ALL},
            "figure",
            allow_duplicate=True,
        ),
        Output({"type": "dataframe-store", "index": ALL}, "data", allow_duplicate=True),
        Input("relax-all-constraints-button", "n_clicks"),
        State({"type": "dataframe-store", "index": ALL}, "data"),
        prevent_initial_call=True,
    )
    def relax_all_constraints(_, list_previous_df_tuples):
        nonlocal pep_builder
        pep_builder.relaxed_constraints = []
        updated_figs = []
        df_data = []
        for previous_df_tuple in list_previous_df_tuples:
            tag, previous_df, df_attrs = previous_df_tuple
            df_updated = pd.DataFrame(previous_df)
            pep_builder.relaxed_constraints.extend(
                df_updated["constraint_name"].to_list()
            )
            df_updated["constraint"] = "inactive"
            func_or_oper = pep_builder.get_func_or_oper_by_tag(tag)
            updated_figs.append(
                func_or_oper.get_primal_fig_from_df_and_order(df_updated, df_attrs)
            )
            df_data.append((tag, df_updated.to_dict("records"), df_attrs))
        return updated_figs, df_data

    @dash.callback(
        Output(
            {"type": "interactive-scatter", "index": MATCH},
            "figure",
            allow_duplicate=True,
        ),
        Output(
            {"type": "dataframe-store", "index": MATCH}, "data", allow_duplicate=True
        ),
        Input({"type": "interactive-scatter", "index": MATCH}, "clickData"),
        State({"type": "dataframe-store", "index": MATCH}, "data"),
        prevent_initial_call=True,
    )
    def update_df_and_redraw(clickData, previous_df_tuple):
        nonlocal pep_builder
        if not clickData["points"][0]["customdata"]:
            return dash.no_update, dash.no_update

        clicked_name = clickData["points"][0]["customdata"][0]
        if clicked_name not in pep_builder.relaxed_constraints:
            pep_builder.relaxed_constraints.append(clicked_name)
        else:
            pep_builder.relaxed_constraints.remove(clicked_name)

        tag, previous_df, df_attrs = previous_df_tuple
        df_updated = pd.DataFrame(previous_df)
        df_updated["constraint"] = df_updated.constraint_name.map(
            lambda x: "inactive" if x in pep_builder.relaxed_constraints else "active"
        )
        func_or_oper = pep_builder.get_func_or_oper_by_tag(tag)
        return func_or_oper.get_primal_fig_from_df_and_order(df_updated, df_attrs), (
            tag,
            df_updated.to_dict("records"),
            df_attrs,
        )

    app.run(debug=True, port=port)

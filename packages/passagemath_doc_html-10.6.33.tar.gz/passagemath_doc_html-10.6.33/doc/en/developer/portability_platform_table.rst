.. |image-ubuntu-bionic-toolchain-gcc_9-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-minimal-with-system-packages

.. |image-ubuntu-bionic-toolchain-gcc_9-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-minimal-configured

.. |image-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets-pre

.. |image-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets

.. |image-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets-optional

.. |codespace-ubuntu-bionic-toolchain-gcc_9-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-bionic-toolchain-gcc_9-minimal%2Fdevcontainer.json

.. |image-ubuntu-bionic-toolchain-gcc_9-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-standard-with-system-packages

.. |image-ubuntu-bionic-toolchain-gcc_9-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-standard-configured

.. |image-ubuntu-bionic-toolchain-gcc_9-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-standard-with-targets-pre

.. |image-ubuntu-bionic-toolchain-gcc_9-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-standard-with-targets

.. |image-ubuntu-bionic-toolchain-gcc_9-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-standard-with-targets-optional

.. |codespace-ubuntu-bionic-toolchain-gcc_9-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-bionic-toolchain-gcc_9-standard%2Fdevcontainer.json

.. |image-ubuntu-bionic-toolchain-gcc_9-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-maximal-with-system-packages

.. |image-ubuntu-bionic-toolchain-gcc_9-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-maximal-configured

.. |image-ubuntu-bionic-toolchain-gcc_9-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-maximal-with-targets-pre

.. |image-ubuntu-bionic-toolchain-gcc_9-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-maximal-with-targets

.. |image-ubuntu-bionic-toolchain-gcc_9-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-maximal-with-targets-optional

.. |codespace-ubuntu-bionic-toolchain-gcc_9-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-bionic-toolchain-gcc_9-maximal%2Fdevcontainer.json

.. |image-ubuntu-focal-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-minimal-with-system-packages

.. |image-ubuntu-focal-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-minimal-configured

.. |image-ubuntu-focal-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-minimal-with-targets-pre

.. |image-ubuntu-focal-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-minimal-with-targets

.. |image-ubuntu-focal-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-minimal-with-targets-optional

.. |codespace-ubuntu-focal-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-focal-minimal%2Fdevcontainer.json

.. |image-ubuntu-focal-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-standard-with-system-packages

.. |image-ubuntu-focal-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-standard-configured

.. |image-ubuntu-focal-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-standard-with-targets-pre

.. |image-ubuntu-focal-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-standard-with-targets

.. |image-ubuntu-focal-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-standard-with-targets-optional

.. |codespace-ubuntu-focal-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-focal-standard%2Fdevcontainer.json

.. |image-ubuntu-focal-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-maximal-with-system-packages

.. |image-ubuntu-focal-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-maximal-configured

.. |image-ubuntu-focal-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-maximal-with-targets-pre

.. |image-ubuntu-focal-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-maximal-with-targets

.. |image-ubuntu-focal-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-focal-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-focal-maximal-with-targets-optional

.. |codespace-ubuntu-focal-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-focal-maximal%2Fdevcontainer.json

.. |image-ubuntu-jammy-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-minimal-with-system-packages

.. |image-ubuntu-jammy-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-minimal-configured

.. |image-ubuntu-jammy-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-minimal-with-targets-pre

.. |image-ubuntu-jammy-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-minimal-with-targets

.. |image-ubuntu-jammy-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-minimal-with-targets-optional

.. |codespace-ubuntu-jammy-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-jammy-minimal%2Fdevcontainer.json

.. |image-ubuntu-jammy-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-standard-with-system-packages

.. |image-ubuntu-jammy-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-standard-configured

.. |image-ubuntu-jammy-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-standard-with-targets-pre

.. |image-ubuntu-jammy-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-standard-with-targets

.. |image-ubuntu-jammy-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-standard-with-targets-optional

.. |codespace-ubuntu-jammy-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-jammy-standard%2Fdevcontainer.json

.. |image-ubuntu-jammy-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-maximal-with-system-packages

.. |image-ubuntu-jammy-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-maximal-configured

.. |image-ubuntu-jammy-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-maximal-with-targets-pre

.. |image-ubuntu-jammy-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-maximal-with-targets

.. |image-ubuntu-jammy-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-jammy-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-jammy-maximal-with-targets-optional

.. |codespace-ubuntu-jammy-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-jammy-maximal%2Fdevcontainer.json

.. |image-ubuntu-noble-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-minimal-with-system-packages

.. |image-ubuntu-noble-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-minimal-configured

.. |image-ubuntu-noble-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-minimal-with-targets-pre

.. |image-ubuntu-noble-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-minimal-with-targets

.. |image-ubuntu-noble-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-minimal-with-targets-optional

.. |codespace-ubuntu-noble-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-noble-minimal%2Fdevcontainer.json

.. |image-ubuntu-noble-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-standard-with-system-packages

.. |image-ubuntu-noble-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-standard-configured

.. |image-ubuntu-noble-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-standard-with-targets-pre

.. |image-ubuntu-noble-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-standard-with-targets

.. |image-ubuntu-noble-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-standard-with-targets-optional

.. |codespace-ubuntu-noble-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-noble-standard%2Fdevcontainer.json

.. |image-ubuntu-noble-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-maximal-with-system-packages

.. |image-ubuntu-noble-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-maximal-configured

.. |image-ubuntu-noble-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-maximal-with-targets-pre

.. |image-ubuntu-noble-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-maximal-with-targets

.. |image-ubuntu-noble-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-noble-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-noble-maximal-with-targets-optional

.. |codespace-ubuntu-noble-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-noble-maximal%2Fdevcontainer.json

.. |image-ubuntu-plucky-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-minimal-with-system-packages

.. |image-ubuntu-plucky-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-minimal-configured

.. |image-ubuntu-plucky-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-minimal-with-targets-pre

.. |image-ubuntu-plucky-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-minimal-with-targets

.. |image-ubuntu-plucky-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-minimal-with-targets-optional

.. |codespace-ubuntu-plucky-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-plucky-minimal%2Fdevcontainer.json

.. |image-ubuntu-plucky-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-standard-with-system-packages

.. |image-ubuntu-plucky-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-standard-configured

.. |image-ubuntu-plucky-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-standard-with-targets-pre

.. |image-ubuntu-plucky-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-standard-with-targets

.. |image-ubuntu-plucky-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-standard-with-targets-optional

.. |codespace-ubuntu-plucky-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-plucky-standard%2Fdevcontainer.json

.. |image-ubuntu-plucky-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-maximal-with-system-packages

.. |image-ubuntu-plucky-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-maximal-configured

.. |image-ubuntu-plucky-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-maximal-with-targets-pre

.. |image-ubuntu-plucky-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-maximal-with-targets

.. |image-ubuntu-plucky-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-plucky-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-plucky-maximal-with-targets-optional

.. |codespace-ubuntu-plucky-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-plucky-maximal%2Fdevcontainer.json

.. |image-ubuntu-questing-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-minimal-with-system-packages

.. |image-ubuntu-questing-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-minimal-configured

.. |image-ubuntu-questing-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-minimal-with-targets-pre

.. |image-ubuntu-questing-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-minimal-with-targets

.. |image-ubuntu-questing-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-minimal-with-targets-optional

.. |codespace-ubuntu-questing-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-questing-minimal%2Fdevcontainer.json

.. |image-ubuntu-questing-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-standard-with-system-packages

.. |image-ubuntu-questing-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-standard-configured

.. |image-ubuntu-questing-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-standard-with-targets-pre

.. |image-ubuntu-questing-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-standard-with-targets

.. |image-ubuntu-questing-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-standard-with-targets-optional

.. |codespace-ubuntu-questing-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-questing-standard%2Fdevcontainer.json

.. |image-ubuntu-questing-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-maximal-with-system-packages

.. |image-ubuntu-questing-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-maximal-configured

.. |image-ubuntu-questing-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-maximal-with-targets-pre

.. |image-ubuntu-questing-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-maximal-with-targets

.. |image-ubuntu-questing-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-questing-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-questing-maximal-with-targets-optional

.. |codespace-ubuntu-questing-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-questing-maximal%2Fdevcontainer.json

.. |image-debian-bullseye-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-minimal-with-system-packages

.. |image-debian-bullseye-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-minimal-configured

.. |image-debian-bullseye-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-minimal-with-targets-pre

.. |image-debian-bullseye-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-minimal-with-targets

.. |image-debian-bullseye-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-minimal-with-targets-optional

.. |codespace-debian-bullseye-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-bullseye-minimal%2Fdevcontainer.json

.. |image-debian-bullseye-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-standard-with-system-packages

.. |image-debian-bullseye-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-standard-configured

.. |image-debian-bullseye-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-standard-with-targets-pre

.. |image-debian-bullseye-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-standard-with-targets

.. |image-debian-bullseye-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-standard-with-targets-optional

.. |codespace-debian-bullseye-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-bullseye-standard%2Fdevcontainer.json

.. |image-debian-bullseye-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-maximal-with-system-packages

.. |image-debian-bullseye-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-maximal-configured

.. |image-debian-bullseye-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-maximal-with-targets-pre

.. |image-debian-bullseye-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-maximal-with-targets

.. |image-debian-bullseye-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-maximal-with-targets-optional

.. |codespace-debian-bullseye-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-bullseye-maximal%2Fdevcontainer.json

.. |image-debian-bookworm-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-minimal-with-system-packages

.. |image-debian-bookworm-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-minimal-configured

.. |image-debian-bookworm-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-minimal-with-targets-pre

.. |image-debian-bookworm-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-minimal-with-targets

.. |image-debian-bookworm-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-minimal-with-targets-optional

.. |codespace-debian-bookworm-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-bookworm-minimal%2Fdevcontainer.json

.. |image-debian-bookworm-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-standard-with-system-packages

.. |image-debian-bookworm-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-standard-configured

.. |image-debian-bookworm-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-standard-with-targets-pre

.. |image-debian-bookworm-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-standard-with-targets

.. |image-debian-bookworm-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-standard-with-targets-optional

.. |codespace-debian-bookworm-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-bookworm-standard%2Fdevcontainer.json

.. |image-debian-bookworm-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-maximal-with-system-packages

.. |image-debian-bookworm-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-maximal-configured

.. |image-debian-bookworm-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-maximal-with-targets-pre

.. |image-debian-bookworm-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-maximal-with-targets

.. |image-debian-bookworm-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bookworm-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bookworm-maximal-with-targets-optional

.. |codespace-debian-bookworm-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-bookworm-maximal%2Fdevcontainer.json

.. |image-debian-trixie-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-minimal-with-system-packages

.. |image-debian-trixie-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-minimal-configured

.. |image-debian-trixie-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-minimal-with-targets-pre

.. |image-debian-trixie-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-minimal-with-targets

.. |image-debian-trixie-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-minimal-with-targets-optional

.. |codespace-debian-trixie-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-trixie-minimal%2Fdevcontainer.json

.. |image-debian-trixie-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-standard-with-system-packages

.. |image-debian-trixie-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-standard-configured

.. |image-debian-trixie-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-standard-with-targets-pre

.. |image-debian-trixie-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-standard-with-targets

.. |image-debian-trixie-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-standard-with-targets-optional

.. |codespace-debian-trixie-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-trixie-standard%2Fdevcontainer.json

.. |image-debian-trixie-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-maximal-with-system-packages

.. |image-debian-trixie-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-maximal-configured

.. |image-debian-trixie-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-maximal-with-targets-pre

.. |image-debian-trixie-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-maximal-with-targets

.. |image-debian-trixie-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-trixie-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-trixie-maximal-with-targets-optional

.. |codespace-debian-trixie-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-trixie-maximal%2Fdevcontainer.json

.. |image-debian-forky-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-minimal-with-system-packages

.. |image-debian-forky-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-minimal-configured

.. |image-debian-forky-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-minimal-with-targets-pre

.. |image-debian-forky-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-minimal-with-targets

.. |image-debian-forky-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-minimal-with-targets-optional

.. |codespace-debian-forky-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-forky-minimal%2Fdevcontainer.json

.. |image-debian-forky-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-standard-with-system-packages

.. |image-debian-forky-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-standard-configured

.. |image-debian-forky-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-standard-with-targets-pre

.. |image-debian-forky-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-standard-with-targets

.. |image-debian-forky-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-standard-with-targets-optional

.. |codespace-debian-forky-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-forky-standard%2Fdevcontainer.json

.. |image-debian-forky-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-maximal-with-system-packages

.. |image-debian-forky-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-maximal-configured

.. |image-debian-forky-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-maximal-with-targets-pre

.. |image-debian-forky-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-maximal-with-targets

.. |image-debian-forky-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-forky-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-forky-maximal-with-targets-optional

.. |codespace-debian-forky-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-forky-maximal%2Fdevcontainer.json

.. |image-debian-sid-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-minimal-with-system-packages

.. |image-debian-sid-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-minimal-configured

.. |image-debian-sid-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-minimal-with-targets-pre

.. |image-debian-sid-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-minimal-with-targets

.. |image-debian-sid-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-minimal-with-targets-optional

.. |codespace-debian-sid-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-sid-minimal%2Fdevcontainer.json

.. |image-debian-sid-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-standard-with-system-packages

.. |image-debian-sid-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-standard-configured

.. |image-debian-sid-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-standard-with-targets-pre

.. |image-debian-sid-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-standard-with-targets

.. |image-debian-sid-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-standard-with-targets-optional

.. |codespace-debian-sid-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-sid-standard%2Fdevcontainer.json

.. |image-debian-sid-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-maximal-with-system-packages

.. |image-debian-sid-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-maximal-configured

.. |image-debian-sid-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-maximal-with-targets-pre

.. |image-debian-sid-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-maximal-with-targets

.. |image-debian-sid-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-sid-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-sid-maximal-with-targets-optional

.. |codespace-debian-sid-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-sid-maximal%2Fdevcontainer.json

.. |image-linuxmint-20.2-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-minimal-with-system-packages

.. |image-linuxmint-20.2-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-minimal-configured

.. |image-linuxmint-20.2-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-minimal-with-targets-pre

.. |image-linuxmint-20.2-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-minimal-with-targets

.. |image-linuxmint-20.2-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-minimal-with-targets-optional

.. |codespace-linuxmint-20.2-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-20.2-minimal%2Fdevcontainer.json

.. |image-linuxmint-20.2-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-standard-with-system-packages

.. |image-linuxmint-20.2-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-standard-configured

.. |image-linuxmint-20.2-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-standard-with-targets-pre

.. |image-linuxmint-20.2-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-standard-with-targets

.. |image-linuxmint-20.2-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-standard-with-targets-optional

.. |codespace-linuxmint-20.2-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-20.2-standard%2Fdevcontainer.json

.. |image-linuxmint-20.2-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-maximal-with-system-packages

.. |image-linuxmint-20.2-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-maximal-configured

.. |image-linuxmint-20.2-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-maximal-with-targets-pre

.. |image-linuxmint-20.2-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-maximal-with-targets

.. |image-linuxmint-20.2-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.2-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.2-maximal-with-targets-optional

.. |codespace-linuxmint-20.2-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-20.2-maximal%2Fdevcontainer.json

.. |image-linuxmint-20.3-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-minimal-with-system-packages

.. |image-linuxmint-20.3-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-minimal-configured

.. |image-linuxmint-20.3-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-minimal-with-targets-pre

.. |image-linuxmint-20.3-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-minimal-with-targets

.. |image-linuxmint-20.3-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-minimal-with-targets-optional

.. |codespace-linuxmint-20.3-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-20.3-minimal%2Fdevcontainer.json

.. |image-linuxmint-20.3-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-standard-with-system-packages

.. |image-linuxmint-20.3-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-standard-configured

.. |image-linuxmint-20.3-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-standard-with-targets-pre

.. |image-linuxmint-20.3-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-standard-with-targets

.. |image-linuxmint-20.3-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-standard-with-targets-optional

.. |codespace-linuxmint-20.3-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-20.3-standard%2Fdevcontainer.json

.. |image-linuxmint-20.3-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-maximal-with-system-packages

.. |image-linuxmint-20.3-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-maximal-configured

.. |image-linuxmint-20.3-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-maximal-with-targets-pre

.. |image-linuxmint-20.3-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-maximal-with-targets

.. |image-linuxmint-20.3-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-20.3-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-20.3-maximal-with-targets-optional

.. |codespace-linuxmint-20.3-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-20.3-maximal%2Fdevcontainer.json

.. |image-linuxmint-21-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-minimal-with-system-packages

.. |image-linuxmint-21-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-minimal-configured

.. |image-linuxmint-21-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-minimal-with-targets-pre

.. |image-linuxmint-21-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-minimal-with-targets

.. |image-linuxmint-21-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-minimal-with-targets-optional

.. |codespace-linuxmint-21-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21-minimal%2Fdevcontainer.json

.. |image-linuxmint-21-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-standard-with-system-packages

.. |image-linuxmint-21-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-standard-configured

.. |image-linuxmint-21-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-standard-with-targets-pre

.. |image-linuxmint-21-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-standard-with-targets

.. |image-linuxmint-21-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-standard-with-targets-optional

.. |codespace-linuxmint-21-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21-standard%2Fdevcontainer.json

.. |image-linuxmint-21-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-maximal-with-system-packages

.. |image-linuxmint-21-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-maximal-configured

.. |image-linuxmint-21-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-maximal-with-targets-pre

.. |image-linuxmint-21-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-maximal-with-targets

.. |image-linuxmint-21-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21-maximal-with-targets-optional

.. |codespace-linuxmint-21-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21-maximal%2Fdevcontainer.json

.. |image-linuxmint-21.1-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-minimal-with-system-packages

.. |image-linuxmint-21.1-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-minimal-configured

.. |image-linuxmint-21.1-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-minimal-with-targets-pre

.. |image-linuxmint-21.1-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-minimal-with-targets

.. |image-linuxmint-21.1-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-minimal-with-targets-optional

.. |codespace-linuxmint-21.1-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21.1-minimal%2Fdevcontainer.json

.. |image-linuxmint-21.1-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-standard-with-system-packages

.. |image-linuxmint-21.1-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-standard-configured

.. |image-linuxmint-21.1-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-standard-with-targets-pre

.. |image-linuxmint-21.1-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-standard-with-targets

.. |image-linuxmint-21.1-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-standard-with-targets-optional

.. |codespace-linuxmint-21.1-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21.1-standard%2Fdevcontainer.json

.. |image-linuxmint-21.1-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-maximal-with-system-packages

.. |image-linuxmint-21.1-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-maximal-configured

.. |image-linuxmint-21.1-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-maximal-with-targets-pre

.. |image-linuxmint-21.1-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-maximal-with-targets

.. |image-linuxmint-21.1-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.1-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.1-maximal-with-targets-optional

.. |codespace-linuxmint-21.1-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21.1-maximal%2Fdevcontainer.json

.. |image-linuxmint-21.2-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-minimal-with-system-packages

.. |image-linuxmint-21.2-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-minimal-configured

.. |image-linuxmint-21.2-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-minimal-with-targets-pre

.. |image-linuxmint-21.2-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-minimal-with-targets

.. |image-linuxmint-21.2-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-minimal-with-targets-optional

.. |codespace-linuxmint-21.2-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21.2-minimal%2Fdevcontainer.json

.. |image-linuxmint-21.2-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-standard-with-system-packages

.. |image-linuxmint-21.2-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-standard-configured

.. |image-linuxmint-21.2-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-standard-with-targets-pre

.. |image-linuxmint-21.2-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-standard-with-targets

.. |image-linuxmint-21.2-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-standard-with-targets-optional

.. |codespace-linuxmint-21.2-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21.2-standard%2Fdevcontainer.json

.. |image-linuxmint-21.2-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-maximal-with-system-packages

.. |image-linuxmint-21.2-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-maximal-configured

.. |image-linuxmint-21.2-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-maximal-with-targets-pre

.. |image-linuxmint-21.2-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-maximal-with-targets

.. |image-linuxmint-21.2-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.2-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.2-maximal-with-targets-optional

.. |codespace-linuxmint-21.2-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21.2-maximal%2Fdevcontainer.json

.. |image-linuxmint-21.3-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-minimal-with-system-packages

.. |image-linuxmint-21.3-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-minimal-configured

.. |image-linuxmint-21.3-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-minimal-with-targets-pre

.. |image-linuxmint-21.3-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-minimal-with-targets

.. |image-linuxmint-21.3-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-minimal-with-targets-optional

.. |codespace-linuxmint-21.3-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21.3-minimal%2Fdevcontainer.json

.. |image-linuxmint-21.3-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-standard-with-system-packages

.. |image-linuxmint-21.3-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-standard-configured

.. |image-linuxmint-21.3-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-standard-with-targets-pre

.. |image-linuxmint-21.3-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-standard-with-targets

.. |image-linuxmint-21.3-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-standard-with-targets-optional

.. |codespace-linuxmint-21.3-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21.3-standard%2Fdevcontainer.json

.. |image-linuxmint-21.3-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-maximal-with-system-packages

.. |image-linuxmint-21.3-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-maximal-configured

.. |image-linuxmint-21.3-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-maximal-with-targets-pre

.. |image-linuxmint-21.3-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-maximal-with-targets

.. |image-linuxmint-21.3-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-21.3-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-21.3-maximal-with-targets-optional

.. |codespace-linuxmint-21.3-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-21.3-maximal%2Fdevcontainer.json

.. |image-linuxmint-22-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-minimal-with-system-packages

.. |image-linuxmint-22-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-minimal-configured

.. |image-linuxmint-22-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-minimal-with-targets-pre

.. |image-linuxmint-22-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-minimal-with-targets

.. |image-linuxmint-22-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-minimal-with-targets-optional

.. |codespace-linuxmint-22-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-22-minimal%2Fdevcontainer.json

.. |image-linuxmint-22-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-standard-with-system-packages

.. |image-linuxmint-22-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-standard-configured

.. |image-linuxmint-22-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-standard-with-targets-pre

.. |image-linuxmint-22-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-standard-with-targets

.. |image-linuxmint-22-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-standard-with-targets-optional

.. |codespace-linuxmint-22-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-22-standard%2Fdevcontainer.json

.. |image-linuxmint-22-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-maximal-with-system-packages

.. |image-linuxmint-22-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-maximal-configured

.. |image-linuxmint-22-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-maximal-with-targets-pre

.. |image-linuxmint-22-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-maximal-with-targets

.. |image-linuxmint-22-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-linuxmint-22-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-linuxmint-22-maximal-with-targets-optional

.. |codespace-linuxmint-22-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-linuxmint-22-maximal%2Fdevcontainer.json

.. |image-fedora-30-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-minimal-with-system-packages

.. |image-fedora-30-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-minimal-configured

.. |image-fedora-30-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-minimal-with-targets-pre

.. |image-fedora-30-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-minimal-with-targets

.. |image-fedora-30-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-minimal-with-targets-optional

.. |codespace-fedora-30-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-30-minimal%2Fdevcontainer.json

.. |image-fedora-30-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-standard-with-system-packages

.. |image-fedora-30-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-standard-configured

.. |image-fedora-30-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-standard-with-targets-pre

.. |image-fedora-30-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-standard-with-targets

.. |image-fedora-30-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-standard-with-targets-optional

.. |codespace-fedora-30-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-30-standard%2Fdevcontainer.json

.. |image-fedora-30-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-maximal-with-system-packages

.. |image-fedora-30-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-maximal-configured

.. |image-fedora-30-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-maximal-with-targets-pre

.. |image-fedora-30-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-maximal-with-targets

.. |image-fedora-30-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-30-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-30-maximal-with-targets-optional

.. |codespace-fedora-30-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-30-maximal%2Fdevcontainer.json

.. |image-fedora-31-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-minimal-with-system-packages

.. |image-fedora-31-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-minimal-configured

.. |image-fedora-31-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-minimal-with-targets-pre

.. |image-fedora-31-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-minimal-with-targets

.. |image-fedora-31-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-minimal-with-targets-optional

.. |codespace-fedora-31-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-31-minimal%2Fdevcontainer.json

.. |image-fedora-31-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-standard-with-system-packages

.. |image-fedora-31-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-standard-configured

.. |image-fedora-31-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-standard-with-targets-pre

.. |image-fedora-31-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-standard-with-targets

.. |image-fedora-31-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-standard-with-targets-optional

.. |codespace-fedora-31-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-31-standard%2Fdevcontainer.json

.. |image-fedora-31-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-maximal-with-system-packages

.. |image-fedora-31-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-maximal-configured

.. |image-fedora-31-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-maximal-with-targets-pre

.. |image-fedora-31-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-maximal-with-targets

.. |image-fedora-31-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-31-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-31-maximal-with-targets-optional

.. |codespace-fedora-31-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-31-maximal%2Fdevcontainer.json

.. |image-fedora-32-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-minimal-with-system-packages

.. |image-fedora-32-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-minimal-configured

.. |image-fedora-32-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-minimal-with-targets-pre

.. |image-fedora-32-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-minimal-with-targets

.. |image-fedora-32-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-minimal-with-targets-optional

.. |codespace-fedora-32-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-32-minimal%2Fdevcontainer.json

.. |image-fedora-32-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-standard-with-system-packages

.. |image-fedora-32-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-standard-configured

.. |image-fedora-32-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-standard-with-targets-pre

.. |image-fedora-32-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-standard-with-targets

.. |image-fedora-32-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-standard-with-targets-optional

.. |codespace-fedora-32-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-32-standard%2Fdevcontainer.json

.. |image-fedora-32-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-maximal-with-system-packages

.. |image-fedora-32-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-maximal-configured

.. |image-fedora-32-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-maximal-with-targets-pre

.. |image-fedora-32-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-maximal-with-targets

.. |image-fedora-32-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-32-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-32-maximal-with-targets-optional

.. |codespace-fedora-32-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-32-maximal%2Fdevcontainer.json

.. |image-fedora-33-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-minimal-with-system-packages

.. |image-fedora-33-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-minimal-configured

.. |image-fedora-33-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-minimal-with-targets-pre

.. |image-fedora-33-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-minimal-with-targets

.. |image-fedora-33-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-minimal-with-targets-optional

.. |codespace-fedora-33-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-33-minimal%2Fdevcontainer.json

.. |image-fedora-33-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-standard-with-system-packages

.. |image-fedora-33-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-standard-configured

.. |image-fedora-33-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-standard-with-targets-pre

.. |image-fedora-33-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-standard-with-targets

.. |image-fedora-33-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-standard-with-targets-optional

.. |codespace-fedora-33-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-33-standard%2Fdevcontainer.json

.. |image-fedora-33-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-maximal-with-system-packages

.. |image-fedora-33-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-maximal-configured

.. |image-fedora-33-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-maximal-with-targets-pre

.. |image-fedora-33-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-maximal-with-targets

.. |image-fedora-33-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-33-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-33-maximal-with-targets-optional

.. |codespace-fedora-33-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-33-maximal%2Fdevcontainer.json

.. |image-fedora-34-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-minimal-with-system-packages

.. |image-fedora-34-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-minimal-configured

.. |image-fedora-34-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-minimal-with-targets-pre

.. |image-fedora-34-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-minimal-with-targets

.. |image-fedora-34-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-minimal-with-targets-optional

.. |codespace-fedora-34-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-34-minimal%2Fdevcontainer.json

.. |image-fedora-34-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-standard-with-system-packages

.. |image-fedora-34-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-standard-configured

.. |image-fedora-34-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-standard-with-targets-pre

.. |image-fedora-34-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-standard-with-targets

.. |image-fedora-34-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-standard-with-targets-optional

.. |codespace-fedora-34-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-34-standard%2Fdevcontainer.json

.. |image-fedora-34-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-maximal-with-system-packages

.. |image-fedora-34-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-maximal-configured

.. |image-fedora-34-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-maximal-with-targets-pre

.. |image-fedora-34-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-maximal-with-targets

.. |image-fedora-34-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-34-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-34-maximal-with-targets-optional

.. |codespace-fedora-34-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-34-maximal%2Fdevcontainer.json

.. |image-fedora-35-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-minimal-with-system-packages

.. |image-fedora-35-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-minimal-configured

.. |image-fedora-35-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-minimal-with-targets-pre

.. |image-fedora-35-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-minimal-with-targets

.. |image-fedora-35-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-minimal-with-targets-optional

.. |codespace-fedora-35-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-35-minimal%2Fdevcontainer.json

.. |image-fedora-35-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-standard-with-system-packages

.. |image-fedora-35-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-standard-configured

.. |image-fedora-35-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-standard-with-targets-pre

.. |image-fedora-35-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-standard-with-targets

.. |image-fedora-35-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-standard-with-targets-optional

.. |codespace-fedora-35-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-35-standard%2Fdevcontainer.json

.. |image-fedora-35-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-maximal-with-system-packages

.. |image-fedora-35-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-maximal-configured

.. |image-fedora-35-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-maximal-with-targets-pre

.. |image-fedora-35-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-maximal-with-targets

.. |image-fedora-35-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-35-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-35-maximal-with-targets-optional

.. |codespace-fedora-35-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-35-maximal%2Fdevcontainer.json

.. |image-fedora-36-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-minimal-with-system-packages

.. |image-fedora-36-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-minimal-configured

.. |image-fedora-36-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-minimal-with-targets-pre

.. |image-fedora-36-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-minimal-with-targets

.. |image-fedora-36-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-minimal-with-targets-optional

.. |codespace-fedora-36-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-36-minimal%2Fdevcontainer.json

.. |image-fedora-36-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-standard-with-system-packages

.. |image-fedora-36-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-standard-configured

.. |image-fedora-36-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-standard-with-targets-pre

.. |image-fedora-36-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-standard-with-targets

.. |image-fedora-36-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-standard-with-targets-optional

.. |codespace-fedora-36-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-36-standard%2Fdevcontainer.json

.. |image-fedora-36-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-maximal-with-system-packages

.. |image-fedora-36-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-maximal-configured

.. |image-fedora-36-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-maximal-with-targets-pre

.. |image-fedora-36-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-maximal-with-targets

.. |image-fedora-36-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-36-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-36-maximal-with-targets-optional

.. |codespace-fedora-36-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-36-maximal%2Fdevcontainer.json

.. |image-fedora-37-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-minimal-with-system-packages

.. |image-fedora-37-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-minimal-configured

.. |image-fedora-37-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-minimal-with-targets-pre

.. |image-fedora-37-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-minimal-with-targets

.. |image-fedora-37-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-minimal-with-targets-optional

.. |codespace-fedora-37-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-37-minimal%2Fdevcontainer.json

.. |image-fedora-37-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-standard-with-system-packages

.. |image-fedora-37-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-standard-configured

.. |image-fedora-37-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-standard-with-targets-pre

.. |image-fedora-37-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-standard-with-targets

.. |image-fedora-37-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-standard-with-targets-optional

.. |codespace-fedora-37-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-37-standard%2Fdevcontainer.json

.. |image-fedora-37-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-maximal-with-system-packages

.. |image-fedora-37-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-maximal-configured

.. |image-fedora-37-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-maximal-with-targets-pre

.. |image-fedora-37-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-maximal-with-targets

.. |image-fedora-37-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-37-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-37-maximal-with-targets-optional

.. |codespace-fedora-37-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-37-maximal%2Fdevcontainer.json

.. |image-fedora-38-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-minimal-with-system-packages

.. |image-fedora-38-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-minimal-configured

.. |image-fedora-38-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-minimal-with-targets-pre

.. |image-fedora-38-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-minimal-with-targets

.. |image-fedora-38-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-minimal-with-targets-optional

.. |codespace-fedora-38-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-38-minimal%2Fdevcontainer.json

.. |image-fedora-38-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-standard-with-system-packages

.. |image-fedora-38-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-standard-configured

.. |image-fedora-38-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-standard-with-targets-pre

.. |image-fedora-38-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-standard-with-targets

.. |image-fedora-38-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-standard-with-targets-optional

.. |codespace-fedora-38-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-38-standard%2Fdevcontainer.json

.. |image-fedora-38-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-maximal-with-system-packages

.. |image-fedora-38-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-maximal-configured

.. |image-fedora-38-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-maximal-with-targets-pre

.. |image-fedora-38-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-maximal-with-targets

.. |image-fedora-38-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-38-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-38-maximal-with-targets-optional

.. |codespace-fedora-38-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-38-maximal%2Fdevcontainer.json

.. |image-fedora-39-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-minimal-with-system-packages

.. |image-fedora-39-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-minimal-configured

.. |image-fedora-39-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-minimal-with-targets-pre

.. |image-fedora-39-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-minimal-with-targets

.. |image-fedora-39-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-minimal-with-targets-optional

.. |codespace-fedora-39-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-39-minimal%2Fdevcontainer.json

.. |image-fedora-39-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-standard-with-system-packages

.. |image-fedora-39-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-standard-configured

.. |image-fedora-39-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-standard-with-targets-pre

.. |image-fedora-39-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-standard-with-targets

.. |image-fedora-39-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-standard-with-targets-optional

.. |codespace-fedora-39-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-39-standard%2Fdevcontainer.json

.. |image-fedora-39-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-maximal-with-system-packages

.. |image-fedora-39-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-maximal-configured

.. |image-fedora-39-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-maximal-with-targets-pre

.. |image-fedora-39-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-maximal-with-targets

.. |image-fedora-39-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-39-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-39-maximal-with-targets-optional

.. |codespace-fedora-39-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-39-maximal%2Fdevcontainer.json

.. |image-fedora-40-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-minimal-with-system-packages

.. |image-fedora-40-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-minimal-configured

.. |image-fedora-40-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-minimal-with-targets-pre

.. |image-fedora-40-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-minimal-with-targets

.. |image-fedora-40-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-minimal-with-targets-optional

.. |codespace-fedora-40-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-40-minimal%2Fdevcontainer.json

.. |image-fedora-40-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-standard-with-system-packages

.. |image-fedora-40-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-standard-configured

.. |image-fedora-40-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-standard-with-targets-pre

.. |image-fedora-40-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-standard-with-targets

.. |image-fedora-40-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-standard-with-targets-optional

.. |codespace-fedora-40-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-40-standard%2Fdevcontainer.json

.. |image-fedora-40-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-maximal-with-system-packages

.. |image-fedora-40-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-maximal-configured

.. |image-fedora-40-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-maximal-with-targets-pre

.. |image-fedora-40-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-maximal-with-targets

.. |image-fedora-40-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-maximal-with-targets-optional

.. |codespace-fedora-40-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-40-maximal%2Fdevcontainer.json

.. |image-fedora-41-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-minimal-with-system-packages

.. |image-fedora-41-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-minimal-configured

.. |image-fedora-41-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-minimal-with-targets-pre

.. |image-fedora-41-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-minimal-with-targets

.. |image-fedora-41-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-minimal-with-targets-optional

.. |codespace-fedora-41-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-41-minimal%2Fdevcontainer.json

.. |image-fedora-41-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-standard-with-system-packages

.. |image-fedora-41-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-standard-configured

.. |image-fedora-41-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-standard-with-targets-pre

.. |image-fedora-41-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-standard-with-targets

.. |image-fedora-41-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-standard-with-targets-optional

.. |codespace-fedora-41-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-41-standard%2Fdevcontainer.json

.. |image-fedora-41-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-maximal-with-system-packages

.. |image-fedora-41-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-maximal-configured

.. |image-fedora-41-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-maximal-with-targets-pre

.. |image-fedora-41-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-maximal-with-targets

.. |image-fedora-41-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-maximal-with-targets-optional

.. |codespace-fedora-41-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-41-maximal%2Fdevcontainer.json

.. |image-fedora-42-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-minimal-with-system-packages

.. |image-fedora-42-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-minimal-configured

.. |image-fedora-42-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-minimal-with-targets-pre

.. |image-fedora-42-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-minimal-with-targets

.. |image-fedora-42-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-minimal-with-targets-optional

.. |codespace-fedora-42-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-42-minimal%2Fdevcontainer.json

.. |image-fedora-42-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-standard-with-system-packages

.. |image-fedora-42-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-standard-configured

.. |image-fedora-42-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-standard-with-targets-pre

.. |image-fedora-42-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-standard-with-targets

.. |image-fedora-42-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-standard-with-targets-optional

.. |codespace-fedora-42-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-42-standard%2Fdevcontainer.json

.. |image-fedora-42-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-maximal-with-system-packages

.. |image-fedora-42-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-maximal-configured

.. |image-fedora-42-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-maximal-with-targets-pre

.. |image-fedora-42-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-maximal-with-targets

.. |image-fedora-42-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-maximal-with-targets-optional

.. |codespace-fedora-42-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-42-maximal%2Fdevcontainer.json

.. |image-fedora-43-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-minimal-with-system-packages

.. |image-fedora-43-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-minimal-configured

.. |image-fedora-43-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-minimal-with-targets-pre

.. |image-fedora-43-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-minimal-with-targets

.. |image-fedora-43-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-minimal-with-targets-optional

.. |codespace-fedora-43-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-43-minimal%2Fdevcontainer.json

.. |image-fedora-43-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-standard-with-system-packages

.. |image-fedora-43-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-standard-configured

.. |image-fedora-43-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-standard-with-targets-pre

.. |image-fedora-43-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-standard-with-targets

.. |image-fedora-43-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-standard-with-targets-optional

.. |codespace-fedora-43-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-43-standard%2Fdevcontainer.json

.. |image-fedora-43-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-maximal-with-system-packages

.. |image-fedora-43-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-maximal-configured

.. |image-fedora-43-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-maximal-with-targets-pre

.. |image-fedora-43-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-maximal-with-targets

.. |image-fedora-43-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-maximal-with-targets-optional

.. |codespace-fedora-43-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-43-maximal%2Fdevcontainer.json

.. |image-centos-stream-9-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-minimal-with-system-packages

.. |image-centos-stream-9-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-minimal-configured

.. |image-centos-stream-9-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-minimal-with-targets-pre

.. |image-centos-stream-9-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-minimal-with-targets

.. |image-centos-stream-9-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-minimal-with-targets-optional

.. |codespace-centos-stream-9-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-centos-stream-9-minimal%2Fdevcontainer.json

.. |image-centos-stream-9-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-standard-with-system-packages

.. |image-centos-stream-9-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-standard-configured

.. |image-centos-stream-9-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-standard-with-targets-pre

.. |image-centos-stream-9-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-standard-with-targets

.. |image-centos-stream-9-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-standard-with-targets-optional

.. |codespace-centos-stream-9-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-centos-stream-9-standard%2Fdevcontainer.json

.. |image-centos-stream-9-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-maximal-with-system-packages

.. |image-centos-stream-9-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-maximal-configured

.. |image-centos-stream-9-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-maximal-with-targets-pre

.. |image-centos-stream-9-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-maximal-with-targets

.. |image-centos-stream-9-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-maximal-with-targets-optional

.. |codespace-centos-stream-9-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-centos-stream-9-maximal%2Fdevcontainer.json

.. |image-centos-stream-9-python3.12-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-minimal-with-system-packages

.. |image-centos-stream-9-python3.12-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-minimal-configured

.. |image-centos-stream-9-python3.12-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-minimal-with-targets-pre

.. |image-centos-stream-9-python3.12-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-minimal-with-targets

.. |image-centos-stream-9-python3.12-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-minimal-with-targets-optional

.. |codespace-centos-stream-9-python3.12-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-centos-stream-9-python3.12-minimal%2Fdevcontainer.json

.. |image-centos-stream-9-python3.12-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-standard-with-system-packages

.. |image-centos-stream-9-python3.12-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-standard-configured

.. |image-centos-stream-9-python3.12-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-standard-with-targets-pre

.. |image-centos-stream-9-python3.12-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-standard-with-targets

.. |image-centos-stream-9-python3.12-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-standard-with-targets-optional

.. |codespace-centos-stream-9-python3.12-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-centos-stream-9-python3.12-standard%2Fdevcontainer.json

.. |image-centos-stream-9-python3.12-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-maximal-with-system-packages

.. |image-centos-stream-9-python3.12-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-maximal-configured

.. |image-centos-stream-9-python3.12-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-maximal-with-targets-pre

.. |image-centos-stream-9-python3.12-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-maximal-with-targets

.. |image-centos-stream-9-python3.12-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-9-python3.12-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-9-python3.12-maximal-with-targets-optional

.. |codespace-centos-stream-9-python3.12-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-centos-stream-9-python3.12-maximal%2Fdevcontainer.json

.. |image-centos-stream-10-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-minimal-with-system-packages

.. |image-centos-stream-10-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-minimal-configured

.. |image-centos-stream-10-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-minimal-with-targets-pre

.. |image-centos-stream-10-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-minimal-with-targets

.. |image-centos-stream-10-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-minimal-with-targets-optional

.. |codespace-centos-stream-10-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-centos-stream-10-minimal%2Fdevcontainer.json

.. |image-centos-stream-10-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-standard-with-system-packages

.. |image-centos-stream-10-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-standard-configured

.. |image-centos-stream-10-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-standard-with-targets-pre

.. |image-centos-stream-10-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-standard-with-targets

.. |image-centos-stream-10-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-standard-with-targets-optional

.. |codespace-centos-stream-10-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-centos-stream-10-standard%2Fdevcontainer.json

.. |image-centos-stream-10-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-maximal-with-system-packages

.. |image-centos-stream-10-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-maximal-configured

.. |image-centos-stream-10-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-maximal-with-targets-pre

.. |image-centos-stream-10-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-maximal-with-targets

.. |image-centos-stream-10-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-centos-stream-10-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-centos-stream-10-maximal-with-targets-optional

.. |codespace-centos-stream-10-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-centos-stream-10-maximal%2Fdevcontainer.json

.. |image-almalinux-8-toolset-gcc_9-python3.12-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-minimal-with-system-packages

.. |image-almalinux-8-toolset-gcc_9-python3.12-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-minimal-configured

.. |image-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets-pre

.. |image-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets

.. |image-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets-optional

.. |codespace-almalinux-8-toolset-gcc_9-python3.12-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-almalinux-8-toolset-gcc_9-python3.12-minimal%2Fdevcontainer.json

.. |image-almalinux-8-toolset-gcc_9-python3.12-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-standard-with-system-packages

.. |image-almalinux-8-toolset-gcc_9-python3.12-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-standard-configured

.. |image-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets-pre

.. |image-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets

.. |image-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets-optional

.. |codespace-almalinux-8-toolset-gcc_9-python3.12-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-almalinux-8-toolset-gcc_9-python3.12-standard%2Fdevcontainer.json

.. |image-almalinux-8-toolset-gcc_9-python3.12-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-maximal-with-system-packages

.. |image-almalinux-8-toolset-gcc_9-python3.12-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-maximal-configured

.. |image-almalinux-8-toolset-gcc_9-python3.12-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-maximal-with-targets-pre

.. |image-almalinux-8-toolset-gcc_9-python3.12-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-maximal-with-targets

.. |image-almalinux-8-toolset-gcc_9-python3.12-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-8-toolset-gcc_9-python3.12-maximal-with-targets-optional

.. |codespace-almalinux-8-toolset-gcc_9-python3.12-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-almalinux-8-toolset-gcc_9-python3.12-maximal%2Fdevcontainer.json

.. |image-almalinux-9-python3.11-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-minimal-with-system-packages

.. |image-almalinux-9-python3.11-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-minimal-configured

.. |image-almalinux-9-python3.11-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-minimal-with-targets-pre

.. |image-almalinux-9-python3.11-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-minimal-with-targets

.. |image-almalinux-9-python3.11-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-minimal-with-targets-optional

.. |codespace-almalinux-9-python3.11-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-almalinux-9-python3.11-minimal%2Fdevcontainer.json

.. |image-almalinux-9-python3.11-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-standard-with-system-packages

.. |image-almalinux-9-python3.11-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-standard-configured

.. |image-almalinux-9-python3.11-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-standard-with-targets-pre

.. |image-almalinux-9-python3.11-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-standard-with-targets

.. |image-almalinux-9-python3.11-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-standard-with-targets-optional

.. |codespace-almalinux-9-python3.11-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-almalinux-9-python3.11-standard%2Fdevcontainer.json

.. |image-almalinux-9-python3.11-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-maximal-with-system-packages

.. |image-almalinux-9-python3.11-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-maximal-configured

.. |image-almalinux-9-python3.11-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-maximal-with-targets-pre

.. |image-almalinux-9-python3.11-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-maximal-with-targets

.. |image-almalinux-9-python3.11-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-almalinux-9-python3.11-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-almalinux-9-python3.11-maximal-with-targets-optional

.. |codespace-almalinux-9-python3.11-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-almalinux-9-python3.11-maximal%2Fdevcontainer.json

.. |image-alpine-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-minimal-with-system-packages

.. |image-alpine-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-minimal-configured

.. |image-alpine-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-minimal-with-targets-pre

.. |image-alpine-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-minimal-with-targets

.. |image-alpine-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-minimal-with-targets-optional

.. |codespace-alpine-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-alpine-minimal%2Fdevcontainer.json

.. |image-alpine-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-standard-with-system-packages

.. |image-alpine-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-standard-configured

.. |image-alpine-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-standard-with-targets-pre

.. |image-alpine-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-standard-with-targets

.. |image-alpine-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-standard-with-targets-optional

.. |codespace-alpine-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-alpine-standard%2Fdevcontainer.json

.. |image-alpine-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-maximal-with-system-packages

.. |image-alpine-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-maximal-configured

.. |image-alpine-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-maximal-with-targets-pre

.. |image-alpine-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-maximal-with-targets

.. |image-alpine-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-alpine-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-alpine-maximal-with-targets-optional

.. |codespace-alpine-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-alpine-maximal%2Fdevcontainer.json

.. |image-gentoo-python3.13-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-minimal-with-system-packages

.. |image-gentoo-python3.13-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-minimal-configured

.. |image-gentoo-python3.13-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-minimal-with-targets-pre

.. |image-gentoo-python3.13-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-minimal-with-targets

.. |image-gentoo-python3.13-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-minimal-with-targets-optional

.. |codespace-gentoo-python3.13-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-gentoo-python3.13-minimal%2Fdevcontainer.json

.. |image-gentoo-python3.13-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-standard-with-system-packages

.. |image-gentoo-python3.13-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-standard-configured

.. |image-gentoo-python3.13-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-standard-with-targets-pre

.. |image-gentoo-python3.13-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-standard-with-targets

.. |image-gentoo-python3.13-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-standard-with-targets-optional

.. |codespace-gentoo-python3.13-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-gentoo-python3.13-standard%2Fdevcontainer.json

.. |image-gentoo-python3.13-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-maximal-with-system-packages

.. |image-gentoo-python3.13-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-maximal-configured

.. |image-gentoo-python3.13-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-maximal-with-targets-pre

.. |image-gentoo-python3.13-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-maximal-with-targets

.. |image-gentoo-python3.13-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-gentoo-python3.13-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-gentoo-python3.13-maximal-with-targets-optional

.. |codespace-gentoo-python3.13-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-gentoo-python3.13-maximal%2Fdevcontainer.json

.. |image-archlinux-latest-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-minimal-with-system-packages

.. |image-archlinux-latest-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-minimal-configured

.. |image-archlinux-latest-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-minimal-with-targets-pre

.. |image-archlinux-latest-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-minimal-with-targets

.. |image-archlinux-latest-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-minimal-with-targets-optional

.. |codespace-archlinux-latest-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-archlinux-latest-minimal%2Fdevcontainer.json

.. |image-archlinux-latest-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-standard-with-system-packages

.. |image-archlinux-latest-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-standard-configured

.. |image-archlinux-latest-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-standard-with-targets-pre

.. |image-archlinux-latest-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-standard-with-targets

.. |image-archlinux-latest-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-standard-with-targets-optional

.. |codespace-archlinux-latest-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-archlinux-latest-standard%2Fdevcontainer.json

.. |image-archlinux-latest-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-maximal-with-system-packages

.. |image-archlinux-latest-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-maximal-configured

.. |image-archlinux-latest-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-maximal-with-targets-pre

.. |image-archlinux-latest-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-maximal-with-targets

.. |image-archlinux-latest-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-archlinux-latest-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-archlinux-latest-maximal-with-targets-optional

.. |codespace-archlinux-latest-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-archlinux-latest-maximal%2Fdevcontainer.json

.. |image-opensuse-15.6-gcc_11-python3.11-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-minimal-with-system-packages

.. |image-opensuse-15.6-gcc_11-python3.11-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-minimal-configured

.. |image-opensuse-15.6-gcc_11-python3.11-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-minimal-with-targets-pre

.. |image-opensuse-15.6-gcc_11-python3.11-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-minimal-with-targets

.. |image-opensuse-15.6-gcc_11-python3.11-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-minimal-with-targets-optional

.. |codespace-opensuse-15.6-gcc_11-python3.11-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-opensuse-15.6-gcc_11-python3.11-minimal%2Fdevcontainer.json

.. |image-opensuse-15.6-gcc_11-python3.11-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-standard-with-system-packages

.. |image-opensuse-15.6-gcc_11-python3.11-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-standard-configured

.. |image-opensuse-15.6-gcc_11-python3.11-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-standard-with-targets-pre

.. |image-opensuse-15.6-gcc_11-python3.11-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-standard-with-targets

.. |image-opensuse-15.6-gcc_11-python3.11-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-standard-with-targets-optional

.. |codespace-opensuse-15.6-gcc_11-python3.11-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-opensuse-15.6-gcc_11-python3.11-standard%2Fdevcontainer.json

.. |image-opensuse-15.6-gcc_11-python3.11-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-maximal-with-system-packages

.. |image-opensuse-15.6-gcc_11-python3.11-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-maximal-configured

.. |image-opensuse-15.6-gcc_11-python3.11-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-maximal-with-targets-pre

.. |image-opensuse-15.6-gcc_11-python3.11-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-maximal-with-targets

.. |image-opensuse-15.6-gcc_11-python3.11-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-15.6-gcc_11-python3.11-maximal-with-targets-optional

.. |codespace-opensuse-15.6-gcc_11-python3.11-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-opensuse-15.6-gcc_11-python3.11-maximal%2Fdevcontainer.json

.. |image-opensuse-tumbleweed-python3.10-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-minimal-with-system-packages

.. |image-opensuse-tumbleweed-python3.10-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-minimal-configured

.. |image-opensuse-tumbleweed-python3.10-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-minimal-with-targets-pre

.. |image-opensuse-tumbleweed-python3.10-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-minimal-with-targets

.. |image-opensuse-tumbleweed-python3.10-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-minimal-with-targets-optional

.. |codespace-opensuse-tumbleweed-python3.10-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-opensuse-tumbleweed-python3.10-minimal%2Fdevcontainer.json

.. |image-opensuse-tumbleweed-python3.10-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-standard-with-system-packages

.. |image-opensuse-tumbleweed-python3.10-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-standard-configured

.. |image-opensuse-tumbleweed-python3.10-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-standard-with-targets-pre

.. |image-opensuse-tumbleweed-python3.10-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-standard-with-targets

.. |image-opensuse-tumbleweed-python3.10-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-standard-with-targets-optional

.. |codespace-opensuse-tumbleweed-python3.10-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-opensuse-tumbleweed-python3.10-standard%2Fdevcontainer.json

.. |image-opensuse-tumbleweed-python3.10-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-maximal-with-system-packages

.. |image-opensuse-tumbleweed-python3.10-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-maximal-configured

.. |image-opensuse-tumbleweed-python3.10-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-maximal-with-targets-pre

.. |image-opensuse-tumbleweed-python3.10-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-maximal-with-targets

.. |image-opensuse-tumbleweed-python3.10-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-python3.10-maximal-with-targets-optional

.. |codespace-opensuse-tumbleweed-python3.10-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-opensuse-tumbleweed-python3.10-maximal%2Fdevcontainer.json

.. |image-opensuse-tumbleweed-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-minimal-with-system-packages

.. |image-opensuse-tumbleweed-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-minimal-configured

.. |image-opensuse-tumbleweed-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-minimal-with-targets-pre

.. |image-opensuse-tumbleweed-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-minimal-with-targets

.. |image-opensuse-tumbleweed-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-minimal-with-targets-optional

.. |codespace-opensuse-tumbleweed-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-opensuse-tumbleweed-minimal%2Fdevcontainer.json

.. |image-opensuse-tumbleweed-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-standard-with-system-packages

.. |image-opensuse-tumbleweed-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-standard-configured

.. |image-opensuse-tumbleweed-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-standard-with-targets-pre

.. |image-opensuse-tumbleweed-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-standard-with-targets

.. |image-opensuse-tumbleweed-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-standard-with-targets-optional

.. |codespace-opensuse-tumbleweed-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-opensuse-tumbleweed-standard%2Fdevcontainer.json

.. |image-opensuse-tumbleweed-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-maximal-with-system-packages

.. |image-opensuse-tumbleweed-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-maximal-configured

.. |image-opensuse-tumbleweed-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-maximal-with-targets-pre

.. |image-opensuse-tumbleweed-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-maximal-with-targets

.. |image-opensuse-tumbleweed-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-opensuse-tumbleweed-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-opensuse-tumbleweed-maximal-with-targets-optional

.. |codespace-opensuse-tumbleweed-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-opensuse-tumbleweed-maximal%2Fdevcontainer.json

.. |image-voidlinux-musl-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-minimal-with-system-packages

.. |image-voidlinux-musl-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-minimal-configured

.. |image-voidlinux-musl-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-minimal-with-targets-pre

.. |image-voidlinux-musl-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-minimal-with-targets

.. |image-voidlinux-musl-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-minimal-with-targets-optional

.. |codespace-voidlinux-musl-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-voidlinux-musl-minimal%2Fdevcontainer.json

.. |image-voidlinux-musl-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-standard-with-system-packages

.. |image-voidlinux-musl-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-standard-configured

.. |image-voidlinux-musl-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-standard-with-targets-pre

.. |image-voidlinux-musl-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-standard-with-targets

.. |image-voidlinux-musl-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-standard-with-targets-optional

.. |codespace-voidlinux-musl-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-voidlinux-musl-standard%2Fdevcontainer.json

.. |image-voidlinux-musl-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-maximal-with-system-packages

.. |image-voidlinux-musl-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-maximal-configured

.. |image-voidlinux-musl-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-maximal-with-targets-pre

.. |image-voidlinux-musl-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-maximal-with-targets

.. |image-voidlinux-musl-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-musl-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-musl-maximal-with-targets-optional

.. |codespace-voidlinux-musl-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-voidlinux-musl-maximal%2Fdevcontainer.json

.. |image-voidlinux-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-minimal-with-system-packages

.. |image-voidlinux-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-minimal-configured

.. |image-voidlinux-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-minimal-with-targets-pre

.. |image-voidlinux-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-minimal-with-targets

.. |image-voidlinux-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-minimal-with-targets-optional

.. |codespace-voidlinux-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-voidlinux-minimal%2Fdevcontainer.json

.. |image-voidlinux-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-standard-with-system-packages

.. |image-voidlinux-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-standard-configured

.. |image-voidlinux-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-standard-with-targets-pre

.. |image-voidlinux-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-standard-with-targets

.. |image-voidlinux-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-standard-with-targets-optional

.. |codespace-voidlinux-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-voidlinux-standard%2Fdevcontainer.json

.. |image-voidlinux-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-maximal-with-system-packages

.. |image-voidlinux-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-maximal-configured

.. |image-voidlinux-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-maximal-with-targets-pre

.. |image-voidlinux-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-maximal-with-targets

.. |image-voidlinux-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-voidlinux-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-voidlinux-maximal-with-targets-optional

.. |codespace-voidlinux-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-voidlinux-maximal%2Fdevcontainer.json

.. |image-conda-forge-python3.11-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-minimal-with-system-packages

.. |image-conda-forge-python3.11-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-minimal-configured

.. |image-conda-forge-python3.11-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-minimal-with-targets-pre

.. |image-conda-forge-python3.11-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-minimal-with-targets

.. |image-conda-forge-python3.11-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-minimal-with-targets-optional

.. |codespace-conda-forge-python3.11-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-conda-forge-python3.11-minimal%2Fdevcontainer.json

.. |image-conda-forge-python3.11-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-standard-with-system-packages

.. |image-conda-forge-python3.11-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-standard-configured

.. |image-conda-forge-python3.11-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-standard-with-targets-pre

.. |image-conda-forge-python3.11-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-standard-with-targets

.. |image-conda-forge-python3.11-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-standard-with-targets-optional

.. |codespace-conda-forge-python3.11-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-conda-forge-python3.11-standard%2Fdevcontainer.json

.. |image-conda-forge-python3.11-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-maximal-with-system-packages

.. |image-conda-forge-python3.11-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-maximal-configured

.. |image-conda-forge-python3.11-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-maximal-with-targets-pre

.. |image-conda-forge-python3.11-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-maximal-with-targets

.. |image-conda-forge-python3.11-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-conda-forge-python3.11-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-conda-forge-python3.11-maximal-with-targets-optional

.. |codespace-conda-forge-python3.11-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-conda-forge-python3.11-maximal%2Fdevcontainer.json

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-system-packages

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-minimal-configured

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets-pre

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets-optional

.. |codespace-ubuntu-bionic-toolchain-gcc_9-i386-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-bionic-toolchain-gcc_9-i386-minimal%2Fdevcontainer.json

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-system-packages

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-standard-configured

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets-pre

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets-optional

.. |codespace-ubuntu-bionic-toolchain-gcc_9-i386-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-bionic-toolchain-gcc_9-i386-standard%2Fdevcontainer.json

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-system-packages

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-maximal-configured

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-targets-pre

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-targets

.. |image-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-targets-optional

.. |codespace-ubuntu-bionic-toolchain-gcc_9-i386-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-ubuntu-bionic-toolchain-gcc_9-i386-maximal%2Fdevcontainer.json

.. |image-debian-bullseye-i386-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-minimal-with-system-packages

.. |image-debian-bullseye-i386-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-minimal-configured

.. |image-debian-bullseye-i386-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-minimal-with-targets-pre

.. |image-debian-bullseye-i386-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-minimal-with-targets

.. |image-debian-bullseye-i386-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-minimal-with-targets-optional

.. |codespace-debian-bullseye-i386-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-bullseye-i386-minimal%2Fdevcontainer.json

.. |image-debian-bullseye-i386-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-standard-with-system-packages

.. |image-debian-bullseye-i386-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-standard-configured

.. |image-debian-bullseye-i386-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-standard-with-targets-pre

.. |image-debian-bullseye-i386-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-standard-with-targets

.. |image-debian-bullseye-i386-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-standard-with-targets-optional

.. |codespace-debian-bullseye-i386-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-bullseye-i386-standard%2Fdevcontainer.json

.. |image-debian-bullseye-i386-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-maximal-with-system-packages

.. |image-debian-bullseye-i386-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-maximal-configured

.. |image-debian-bullseye-i386-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-maximal-with-targets-pre

.. |image-debian-bullseye-i386-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-maximal-with-targets

.. |image-debian-bullseye-i386-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-debian-bullseye-i386-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-debian-bullseye-i386-maximal-with-targets-optional

.. |codespace-debian-bullseye-i386-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-debian-bullseye-i386-maximal%2Fdevcontainer.json

.. |image-fedora-40-arm64v8-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-minimal-with-system-packages

.. |image-fedora-40-arm64v8-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-minimal-configured

.. |image-fedora-40-arm64v8-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-minimal-with-targets-pre

.. |image-fedora-40-arm64v8-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-minimal-with-targets

.. |image-fedora-40-arm64v8-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-minimal-with-targets-optional

.. |codespace-fedora-40-arm64v8-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-40-arm64v8-minimal%2Fdevcontainer.json

.. |image-fedora-40-arm64v8-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-standard-with-system-packages

.. |image-fedora-40-arm64v8-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-standard-configured

.. |image-fedora-40-arm64v8-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-standard-with-targets-pre

.. |image-fedora-40-arm64v8-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-standard-with-targets

.. |image-fedora-40-arm64v8-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-standard-with-targets-optional

.. |codespace-fedora-40-arm64v8-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-40-arm64v8-standard%2Fdevcontainer.json

.. |image-fedora-40-arm64v8-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-maximal-with-system-packages

.. |image-fedora-40-arm64v8-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-maximal-configured

.. |image-fedora-40-arm64v8-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-maximal-with-targets-pre

.. |image-fedora-40-arm64v8-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-maximal-with-targets

.. |image-fedora-40-arm64v8-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-40-arm64v8-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-40-arm64v8-maximal-with-targets-optional

.. |codespace-fedora-40-arm64v8-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-40-arm64v8-maximal%2Fdevcontainer.json

.. |image-fedora-41-arm64v8-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-minimal-with-system-packages

.. |image-fedora-41-arm64v8-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-minimal-configured

.. |image-fedora-41-arm64v8-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-minimal-with-targets-pre

.. |image-fedora-41-arm64v8-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-minimal-with-targets

.. |image-fedora-41-arm64v8-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-minimal-with-targets-optional

.. |codespace-fedora-41-arm64v8-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-41-arm64v8-minimal%2Fdevcontainer.json

.. |image-fedora-41-arm64v8-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-standard-with-system-packages

.. |image-fedora-41-arm64v8-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-standard-configured

.. |image-fedora-41-arm64v8-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-standard-with-targets-pre

.. |image-fedora-41-arm64v8-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-standard-with-targets

.. |image-fedora-41-arm64v8-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-standard-with-targets-optional

.. |codespace-fedora-41-arm64v8-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-41-arm64v8-standard%2Fdevcontainer.json

.. |image-fedora-41-arm64v8-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-maximal-with-system-packages

.. |image-fedora-41-arm64v8-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-maximal-configured

.. |image-fedora-41-arm64v8-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-maximal-with-targets-pre

.. |image-fedora-41-arm64v8-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-maximal-with-targets

.. |image-fedora-41-arm64v8-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-41-arm64v8-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-41-arm64v8-maximal-with-targets-optional

.. |codespace-fedora-41-arm64v8-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-41-arm64v8-maximal%2Fdevcontainer.json

.. |image-fedora-42-arm64v8-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-minimal-with-system-packages

.. |image-fedora-42-arm64v8-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-minimal-configured

.. |image-fedora-42-arm64v8-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-minimal-with-targets-pre

.. |image-fedora-42-arm64v8-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-minimal-with-targets

.. |image-fedora-42-arm64v8-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-minimal-with-targets-optional

.. |codespace-fedora-42-arm64v8-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-42-arm64v8-minimal%2Fdevcontainer.json

.. |image-fedora-42-arm64v8-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-standard-with-system-packages

.. |image-fedora-42-arm64v8-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-standard-configured

.. |image-fedora-42-arm64v8-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-standard-with-targets-pre

.. |image-fedora-42-arm64v8-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-standard-with-targets

.. |image-fedora-42-arm64v8-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-standard-with-targets-optional

.. |codespace-fedora-42-arm64v8-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-42-arm64v8-standard%2Fdevcontainer.json

.. |image-fedora-42-arm64v8-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-maximal-with-system-packages

.. |image-fedora-42-arm64v8-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-maximal-configured

.. |image-fedora-42-arm64v8-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-maximal-with-targets-pre

.. |image-fedora-42-arm64v8-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-maximal-with-targets

.. |image-fedora-42-arm64v8-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-42-arm64v8-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-42-arm64v8-maximal-with-targets-optional

.. |codespace-fedora-42-arm64v8-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-42-arm64v8-maximal%2Fdevcontainer.json

.. |image-fedora-43-arm64v8-minimal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-minimal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-minimal-with-system-packages

.. |image-fedora-43-arm64v8-minimal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-minimal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-minimal-configured

.. |image-fedora-43-arm64v8-minimal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-minimal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%23677895
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-minimal-with-targets-pre

.. |image-fedora-43-arm64v8-minimal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-minimal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%236686c1
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-minimal-with-targets

.. |image-fedora-43-arm64v8-minimal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-minimal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%236495ed
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-minimal-with-targets-optional

.. |codespace-fedora-43-arm64v8-minimal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-43-arm64v8-minimal%2Fdevcontainer.json

.. |image-fedora-43-arm64v8-standard-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-standard-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-standard-with-system-packages

.. |image-fedora-43-arm64v8-standard-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-standard-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-standard-configured

.. |image-fedora-43-arm64v8-standard-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-standard-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%235d8a4c
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-standard-with-targets-pre

.. |image-fedora-43-arm64v8-standard-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-standard-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%2350ab2e
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-standard-with-targets

.. |image-fedora-43-arm64v8-standard-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-standard-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%2344cc11
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-standard-with-targets-optional

.. |codespace-fedora-43-arm64v8-standard| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-43-arm64v8-standard%2Fdevcontainer.json

.. |image-fedora-43-arm64v8-maximal-with-system-packages| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-maximal-with-system-packages/size?tag=dev&label=with-system-packages&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-maximal-with-system-packages

.. |image-fedora-43-arm64v8-maximal-configured| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-maximal-configured/latest_tag?ignore=latest,dev,*-failed&label=configured&color=%23696969
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-maximal-configured

.. |image-fedora-43-arm64v8-maximal-with-targets-pre| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-maximal-with-targets-pre/latest_tag?ignore=latest,dev,*-failed&label=with-targets-pre&color=%238f6b8d
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-maximal-with-targets-pre

.. |image-fedora-43-arm64v8-maximal-with-targets| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-maximal-with-targets/latest_tag?ignore=latest,dev,*-failed&label=with-targets&color=%23b46eb2
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-maximal-with-targets

.. |image-fedora-43-arm64v8-maximal-with-targets-optional| image:: https://ghcr-badge.egpl.dev/passagemath/passagemath/sage-fedora-43-arm64v8-maximal-with-targets-optional/latest_tag?ignore=latest,dev,*-failed&label=with-targets-optional&color=%23da70d6
   :target: https://ghcr.io/passagemath/passagemath/sage-fedora-43-arm64v8-maximal-with-targets-optional

.. |codespace-fedora-43-arm64v8-maximal| image:: https://github.com/codespaces/badge.svg
   :target: https://codespaces.new/passagemath/passagemath?devcontainer_path=.devcontainer%2Fportability-fedora-43-arm64v8-maximal%2Fdevcontainer.json

.. list-table::
   :widths: 50 50 40
   :header-rows: 1
   :stub-columns: 0

   * - Platform
     - Images
     - 
   * - **ubuntu**-bionic-toolchain-gcc_9 
       
          ‑*minimal*
     - |image-ubuntu-bionic-toolchain-gcc_9-minimal-with-system-packages| |image-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets-pre| |image-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets| |image-ubuntu-bionic-toolchain-gcc_9-minimal-with-targets-optional|
     - |codespace-ubuntu-bionic-toolchain-gcc_9-minimal|
   * -    ‑*standard*
     - |image-ubuntu-bionic-toolchain-gcc_9-standard-with-system-packages| |image-ubuntu-bionic-toolchain-gcc_9-standard-with-targets-pre| |image-ubuntu-bionic-toolchain-gcc_9-standard-with-targets| |image-ubuntu-bionic-toolchain-gcc_9-standard-with-targets-optional|
     - |codespace-ubuntu-bionic-toolchain-gcc_9-standard|
   * -    ‑*maximal*
     - |image-ubuntu-bionic-toolchain-gcc_9-maximal-with-system-packages| |image-ubuntu-bionic-toolchain-gcc_9-maximal-with-targets-pre|
     -
   * - **ubuntu**-focal 
       
          ‑*minimal*
     - |image-ubuntu-focal-minimal-with-system-packages| |image-ubuntu-focal-minimal-with-targets-pre| |image-ubuntu-focal-minimal-with-targets| |image-ubuntu-focal-minimal-with-targets-optional|
     - |codespace-ubuntu-focal-minimal|
   * -    ‑*standard*
     - |image-ubuntu-focal-standard-with-system-packages| |image-ubuntu-focal-standard-with-targets-pre| |image-ubuntu-focal-standard-with-targets| |image-ubuntu-focal-standard-with-targets-optional|
     - |codespace-ubuntu-focal-standard|
   * -    ‑*maximal*
     - |image-ubuntu-focal-maximal-with-system-packages| |image-ubuntu-focal-maximal-with-targets-pre|
     -
   * - **ubuntu**-jammy 
       
          ‑*minimal*
     - |image-ubuntu-jammy-minimal-with-system-packages| |image-ubuntu-jammy-minimal-with-targets-pre| |image-ubuntu-jammy-minimal-with-targets| |image-ubuntu-jammy-minimal-with-targets-optional|
     - |codespace-ubuntu-jammy-minimal|
   * -    ‑*standard*
     - |image-ubuntu-jammy-standard-with-system-packages| |image-ubuntu-jammy-standard-with-targets-pre| |image-ubuntu-jammy-standard-with-targets| |image-ubuntu-jammy-standard-with-targets-optional|
     - |codespace-ubuntu-jammy-standard|
   * -    ‑*maximal*
     - |image-ubuntu-jammy-maximal-with-system-packages| |image-ubuntu-jammy-maximal-with-targets-pre|
     -
   * - **ubuntu**-noble 
       
          ‑*minimal*
     - |image-ubuntu-noble-minimal-with-system-packages| |image-ubuntu-noble-minimal-with-targets-pre| |image-ubuntu-noble-minimal-with-targets| |image-ubuntu-noble-minimal-with-targets-optional|
     - |codespace-ubuntu-noble-minimal|
   * -    ‑*standard*
     - |image-ubuntu-noble-standard-with-system-packages| |image-ubuntu-noble-standard-with-targets-pre| |image-ubuntu-noble-standard-with-targets| |image-ubuntu-noble-standard-with-targets-optional|
     - |codespace-ubuntu-noble-standard|
   * -    ‑*maximal*
     - |image-ubuntu-noble-maximal-with-system-packages| |image-ubuntu-noble-maximal-with-targets-pre|
     -
   * - **ubuntu**-plucky 
       
          ‑*minimal*
     - |image-ubuntu-plucky-minimal-with-system-packages| |image-ubuntu-plucky-minimal-with-targets-pre| |image-ubuntu-plucky-minimal-with-targets| |image-ubuntu-plucky-minimal-with-targets-optional|
     - |codespace-ubuntu-plucky-minimal|
   * -    ‑*standard*
     - |image-ubuntu-plucky-standard-with-system-packages| |image-ubuntu-plucky-standard-with-targets-pre| |image-ubuntu-plucky-standard-with-targets| |image-ubuntu-plucky-standard-with-targets-optional|
     - |codespace-ubuntu-plucky-standard|
   * -    ‑*maximal*
     - |image-ubuntu-plucky-maximal-with-system-packages| |image-ubuntu-plucky-maximal-with-targets-pre|
     -
   * - **ubuntu**-questing 
       
          ‑*minimal*
     - |image-ubuntu-questing-minimal-with-system-packages| |image-ubuntu-questing-minimal-with-targets-pre| |image-ubuntu-questing-minimal-with-targets| |image-ubuntu-questing-minimal-with-targets-optional|
     - |codespace-ubuntu-questing-minimal|
   * -    ‑*standard*
     - |image-ubuntu-questing-standard-with-system-packages| |image-ubuntu-questing-standard-with-targets-pre| |image-ubuntu-questing-standard-with-targets| |image-ubuntu-questing-standard-with-targets-optional|
     - |codespace-ubuntu-questing-standard|
   * -    ‑*maximal*
     - |image-ubuntu-questing-maximal-with-system-packages| |image-ubuntu-questing-maximal-with-targets-pre|
     -
   * - **debian**-bullseye 
       
          ‑*minimal*
     - |image-debian-bullseye-minimal-with-system-packages| |image-debian-bullseye-minimal-with-targets-pre| |image-debian-bullseye-minimal-with-targets| |image-debian-bullseye-minimal-with-targets-optional|
     - |codespace-debian-bullseye-minimal|
   * -    ‑*standard*
     - |image-debian-bullseye-standard-with-system-packages| |image-debian-bullseye-standard-with-targets-pre| |image-debian-bullseye-standard-with-targets| |image-debian-bullseye-standard-with-targets-optional|
     - |codespace-debian-bullseye-standard|
   * -    ‑*maximal*
     - |image-debian-bullseye-maximal-with-system-packages| |image-debian-bullseye-maximal-with-targets-pre|
     -
   * - **debian**-bookworm 
       
          ‑*minimal*
     - |image-debian-bookworm-minimal-with-system-packages| |image-debian-bookworm-minimal-with-targets-pre| |image-debian-bookworm-minimal-with-targets| |image-debian-bookworm-minimal-with-targets-optional|
     - |codespace-debian-bookworm-minimal|
   * -    ‑*standard*
     - |image-debian-bookworm-standard-with-system-packages| |image-debian-bookworm-standard-with-targets-pre| |image-debian-bookworm-standard-with-targets| |image-debian-bookworm-standard-with-targets-optional|
     - |codespace-debian-bookworm-standard|
   * -    ‑*maximal*
     - |image-debian-bookworm-maximal-with-system-packages| |image-debian-bookworm-maximal-with-targets-pre|
     -
   * - **debian**-trixie 
       
          ‑*minimal*
     - |image-debian-trixie-minimal-with-system-packages| |image-debian-trixie-minimal-with-targets-pre| |image-debian-trixie-minimal-with-targets| |image-debian-trixie-minimal-with-targets-optional|
     - |codespace-debian-trixie-minimal|
   * -    ‑*standard*
     - |image-debian-trixie-standard-with-system-packages| |image-debian-trixie-standard-with-targets-pre| |image-debian-trixie-standard-with-targets| |image-debian-trixie-standard-with-targets-optional|
     - |codespace-debian-trixie-standard|
   * -    ‑*maximal*
     - |image-debian-trixie-maximal-with-system-packages| |image-debian-trixie-maximal-with-targets-pre|
     -
   * - **debian**-forky 
       
          ‑*minimal*
     - |image-debian-forky-minimal-with-system-packages| |image-debian-forky-minimal-with-targets-pre| |image-debian-forky-minimal-with-targets| |image-debian-forky-minimal-with-targets-optional|
     - |codespace-debian-forky-minimal|
   * -    ‑*standard*
     - |image-debian-forky-standard-with-system-packages| |image-debian-forky-standard-with-targets-pre| |image-debian-forky-standard-with-targets| |image-debian-forky-standard-with-targets-optional|
     - |codespace-debian-forky-standard|
   * -    ‑*maximal*
     - |image-debian-forky-maximal-with-system-packages| |image-debian-forky-maximal-with-targets-pre|
     -
   * - **debian**-sid 
       
          ‑*minimal*
     - |image-debian-sid-minimal-with-system-packages| |image-debian-sid-minimal-with-targets-pre| |image-debian-sid-minimal-with-targets| |image-debian-sid-minimal-with-targets-optional|
     - |codespace-debian-sid-minimal|
   * -    ‑*standard*
     - |image-debian-sid-standard-with-system-packages| |image-debian-sid-standard-with-targets-pre| |image-debian-sid-standard-with-targets| |image-debian-sid-standard-with-targets-optional|
     - |codespace-debian-sid-standard|
   * -    ‑*maximal*
     - |image-debian-sid-maximal-with-system-packages| |image-debian-sid-maximal-with-targets-pre|
     -
   * - **linuxmint**-20.2 
       
          ‑*minimal*
     - |image-linuxmint-20.2-minimal-with-system-packages| |image-linuxmint-20.2-minimal-with-targets-pre| |image-linuxmint-20.2-minimal-with-targets| |image-linuxmint-20.2-minimal-with-targets-optional|
     - |codespace-linuxmint-20.2-minimal|
   * -    ‑*standard*
     - |image-linuxmint-20.2-standard-with-system-packages| |image-linuxmint-20.2-standard-with-targets-pre| |image-linuxmint-20.2-standard-with-targets| |image-linuxmint-20.2-standard-with-targets-optional|
     - |codespace-linuxmint-20.2-standard|
   * -    ‑*maximal*
     - |image-linuxmint-20.2-maximal-with-system-packages| |image-linuxmint-20.2-maximal-with-targets-pre|
     -
   * - **linuxmint**-20.3 
       
          ‑*minimal*
     - |image-linuxmint-20.3-minimal-with-system-packages| |image-linuxmint-20.3-minimal-with-targets-pre| |image-linuxmint-20.3-minimal-with-targets| |image-linuxmint-20.3-minimal-with-targets-optional|
     - |codespace-linuxmint-20.3-minimal|
   * -    ‑*standard*
     - |image-linuxmint-20.3-standard-with-system-packages| |image-linuxmint-20.3-standard-with-targets-pre| |image-linuxmint-20.3-standard-with-targets| |image-linuxmint-20.3-standard-with-targets-optional|
     - |codespace-linuxmint-20.3-standard|
   * -    ‑*maximal*
     - |image-linuxmint-20.3-maximal-with-system-packages| |image-linuxmint-20.3-maximal-with-targets-pre|
     -
   * - **linuxmint**-21 
       
          ‑*minimal*
     - |image-linuxmint-21-minimal-with-system-packages| |image-linuxmint-21-minimal-with-targets-pre| |image-linuxmint-21-minimal-with-targets| |image-linuxmint-21-minimal-with-targets-optional|
     - |codespace-linuxmint-21-minimal|
   * -    ‑*standard*
     - |image-linuxmint-21-standard-with-system-packages| |image-linuxmint-21-standard-with-targets-pre| |image-linuxmint-21-standard-with-targets| |image-linuxmint-21-standard-with-targets-optional|
     - |codespace-linuxmint-21-standard|
   * -    ‑*maximal*
     - |image-linuxmint-21-maximal-with-system-packages| |image-linuxmint-21-maximal-with-targets-pre|
     -
   * - **linuxmint**-21.1 
       
          ‑*minimal*
     - |image-linuxmint-21.1-minimal-with-system-packages| |image-linuxmint-21.1-minimal-with-targets-pre| |image-linuxmint-21.1-minimal-with-targets| |image-linuxmint-21.1-minimal-with-targets-optional|
     - |codespace-linuxmint-21.1-minimal|
   * -    ‑*standard*
     - |image-linuxmint-21.1-standard-with-system-packages| |image-linuxmint-21.1-standard-with-targets-pre| |image-linuxmint-21.1-standard-with-targets| |image-linuxmint-21.1-standard-with-targets-optional|
     - |codespace-linuxmint-21.1-standard|
   * -    ‑*maximal*
     - |image-linuxmint-21.1-maximal-with-system-packages| |image-linuxmint-21.1-maximal-with-targets-pre|
     -
   * - **linuxmint**-21.2 
       
          ‑*minimal*
     - |image-linuxmint-21.2-minimal-with-system-packages| |image-linuxmint-21.2-minimal-with-targets-pre| |image-linuxmint-21.2-minimal-with-targets| |image-linuxmint-21.2-minimal-with-targets-optional|
     - |codespace-linuxmint-21.2-minimal|
   * -    ‑*standard*
     - |image-linuxmint-21.2-standard-with-system-packages| |image-linuxmint-21.2-standard-with-targets-pre| |image-linuxmint-21.2-standard-with-targets| |image-linuxmint-21.2-standard-with-targets-optional|
     - |codespace-linuxmint-21.2-standard|
   * -    ‑*maximal*
     - |image-linuxmint-21.2-maximal-with-system-packages| |image-linuxmint-21.2-maximal-with-targets-pre|
     -
   * - **linuxmint**-21.3 
       
          ‑*minimal*
     - |image-linuxmint-21.3-minimal-with-system-packages| |image-linuxmint-21.3-minimal-with-targets-pre| |image-linuxmint-21.3-minimal-with-targets| |image-linuxmint-21.3-minimal-with-targets-optional|
     - |codespace-linuxmint-21.3-minimal|
   * -    ‑*standard*
     - |image-linuxmint-21.3-standard-with-system-packages| |image-linuxmint-21.3-standard-with-targets-pre| |image-linuxmint-21.3-standard-with-targets| |image-linuxmint-21.3-standard-with-targets-optional|
     - |codespace-linuxmint-21.3-standard|
   * -    ‑*maximal*
     - |image-linuxmint-21.3-maximal-with-system-packages| |image-linuxmint-21.3-maximal-with-targets-pre|
     -
   * - **linuxmint**-22 
       
          ‑*minimal*
     - |image-linuxmint-22-minimal-with-system-packages| |image-linuxmint-22-minimal-with-targets-pre| |image-linuxmint-22-minimal-with-targets| |image-linuxmint-22-minimal-with-targets-optional|
     - |codespace-linuxmint-22-minimal|
   * -    ‑*standard*
     - |image-linuxmint-22-standard-with-system-packages| |image-linuxmint-22-standard-with-targets-pre| |image-linuxmint-22-standard-with-targets| |image-linuxmint-22-standard-with-targets-optional|
     - |codespace-linuxmint-22-standard|
   * -    ‑*maximal*
     - |image-linuxmint-22-maximal-with-system-packages| |image-linuxmint-22-maximal-with-targets-pre|
     -
   * - **fedora**-30 
       
          ‑*minimal*
     - |image-fedora-30-minimal-with-system-packages| |image-fedora-30-minimal-with-targets-pre| |image-fedora-30-minimal-with-targets| |image-fedora-30-minimal-with-targets-optional|
     - |codespace-fedora-30-minimal|
   * -    ‑*standard*
     - |image-fedora-30-standard-with-system-packages| |image-fedora-30-standard-with-targets-pre| |image-fedora-30-standard-with-targets| |image-fedora-30-standard-with-targets-optional|
     - |codespace-fedora-30-standard|
   * -    ‑*maximal*
     - |image-fedora-30-maximal-with-system-packages| |image-fedora-30-maximal-with-targets-pre|
     -
   * - **fedora**-31 
       
          ‑*minimal*
     - |image-fedora-31-minimal-with-system-packages| |image-fedora-31-minimal-with-targets-pre| |image-fedora-31-minimal-with-targets| |image-fedora-31-minimal-with-targets-optional|
     - |codespace-fedora-31-minimal|
   * -    ‑*standard*
     - |image-fedora-31-standard-with-system-packages| |image-fedora-31-standard-with-targets-pre| |image-fedora-31-standard-with-targets| |image-fedora-31-standard-with-targets-optional|
     - |codespace-fedora-31-standard|
   * -    ‑*maximal*
     - |image-fedora-31-maximal-with-system-packages| |image-fedora-31-maximal-with-targets-pre|
     -
   * - **fedora**-32 
       
          ‑*minimal*
     - |image-fedora-32-minimal-with-system-packages| |image-fedora-32-minimal-with-targets-pre| |image-fedora-32-minimal-with-targets| |image-fedora-32-minimal-with-targets-optional|
     - |codespace-fedora-32-minimal|
   * -    ‑*standard*
     - |image-fedora-32-standard-with-system-packages| |image-fedora-32-standard-with-targets-pre| |image-fedora-32-standard-with-targets| |image-fedora-32-standard-with-targets-optional|
     - |codespace-fedora-32-standard|
   * -    ‑*maximal*
     - |image-fedora-32-maximal-with-system-packages| |image-fedora-32-maximal-with-targets-pre|
     -
   * - **fedora**-33 
       
          ‑*minimal*
     - |image-fedora-33-minimal-with-system-packages| |image-fedora-33-minimal-with-targets-pre| |image-fedora-33-minimal-with-targets| |image-fedora-33-minimal-with-targets-optional|
     - |codespace-fedora-33-minimal|
   * -    ‑*standard*
     - |image-fedora-33-standard-with-system-packages| |image-fedora-33-standard-with-targets-pre| |image-fedora-33-standard-with-targets| |image-fedora-33-standard-with-targets-optional|
     - |codespace-fedora-33-standard|
   * -    ‑*maximal*
     - |image-fedora-33-maximal-with-system-packages| |image-fedora-33-maximal-with-targets-pre|
     -
   * - **fedora**-34 
       
          ‑*minimal*
     - |image-fedora-34-minimal-with-system-packages| |image-fedora-34-minimal-with-targets-pre| |image-fedora-34-minimal-with-targets| |image-fedora-34-minimal-with-targets-optional|
     - |codespace-fedora-34-minimal|
   * -    ‑*standard*
     - |image-fedora-34-standard-with-system-packages| |image-fedora-34-standard-with-targets-pre| |image-fedora-34-standard-with-targets| |image-fedora-34-standard-with-targets-optional|
     - |codespace-fedora-34-standard|
   * -    ‑*maximal*
     - |image-fedora-34-maximal-with-system-packages| |image-fedora-34-maximal-with-targets-pre|
     -
   * - **fedora**-35 
       
          ‑*minimal*
     - |image-fedora-35-minimal-with-system-packages| |image-fedora-35-minimal-with-targets-pre| |image-fedora-35-minimal-with-targets| |image-fedora-35-minimal-with-targets-optional|
     - |codespace-fedora-35-minimal|
   * -    ‑*standard*
     - |image-fedora-35-standard-with-system-packages| |image-fedora-35-standard-with-targets-pre| |image-fedora-35-standard-with-targets| |image-fedora-35-standard-with-targets-optional|
     - |codespace-fedora-35-standard|
   * -    ‑*maximal*
     - |image-fedora-35-maximal-with-system-packages| |image-fedora-35-maximal-with-targets-pre|
     -
   * - **fedora**-36 
       
          ‑*minimal*
     - |image-fedora-36-minimal-with-system-packages| |image-fedora-36-minimal-with-targets-pre| |image-fedora-36-minimal-with-targets| |image-fedora-36-minimal-with-targets-optional|
     - |codespace-fedora-36-minimal|
   * -    ‑*standard*
     - |image-fedora-36-standard-with-system-packages| |image-fedora-36-standard-with-targets-pre| |image-fedora-36-standard-with-targets| |image-fedora-36-standard-with-targets-optional|
     - |codespace-fedora-36-standard|
   * -    ‑*maximal*
     - |image-fedora-36-maximal-with-system-packages| |image-fedora-36-maximal-with-targets-pre|
     -
   * - **fedora**-37 
       
          ‑*minimal*
     - |image-fedora-37-minimal-with-system-packages| |image-fedora-37-minimal-with-targets-pre| |image-fedora-37-minimal-with-targets| |image-fedora-37-minimal-with-targets-optional|
     - |codespace-fedora-37-minimal|
   * -    ‑*standard*
     - |image-fedora-37-standard-with-system-packages| |image-fedora-37-standard-with-targets-pre| |image-fedora-37-standard-with-targets| |image-fedora-37-standard-with-targets-optional|
     - |codespace-fedora-37-standard|
   * -    ‑*maximal*
     - |image-fedora-37-maximal-with-system-packages| |image-fedora-37-maximal-with-targets-pre|
     -
   * - **fedora**-38 
       
          ‑*minimal*
     - |image-fedora-38-minimal-with-system-packages| |image-fedora-38-minimal-with-targets-pre| |image-fedora-38-minimal-with-targets| |image-fedora-38-minimal-with-targets-optional|
     - |codespace-fedora-38-minimal|
   * -    ‑*standard*
     - |image-fedora-38-standard-with-system-packages| |image-fedora-38-standard-with-targets-pre| |image-fedora-38-standard-with-targets| |image-fedora-38-standard-with-targets-optional|
     - |codespace-fedora-38-standard|
   * -    ‑*maximal*
     - |image-fedora-38-maximal-with-system-packages| |image-fedora-38-maximal-with-targets-pre|
     -
   * - **fedora**-39 
       
          ‑*minimal*
     - |image-fedora-39-minimal-with-system-packages| |image-fedora-39-minimal-with-targets-pre| |image-fedora-39-minimal-with-targets| |image-fedora-39-minimal-with-targets-optional|
     - |codespace-fedora-39-minimal|
   * -    ‑*standard*
     - |image-fedora-39-standard-with-system-packages| |image-fedora-39-standard-with-targets-pre| |image-fedora-39-standard-with-targets| |image-fedora-39-standard-with-targets-optional|
     - |codespace-fedora-39-standard|
   * -    ‑*maximal*
     - |image-fedora-39-maximal-with-system-packages| |image-fedora-39-maximal-with-targets-pre|
     -
   * - **fedora**-40 
       
          ‑*minimal*
     - |image-fedora-40-minimal-with-system-packages| |image-fedora-40-minimal-with-targets-pre| |image-fedora-40-minimal-with-targets| |image-fedora-40-minimal-with-targets-optional|
     - |codespace-fedora-40-minimal|
   * -    ‑*standard*
     - |image-fedora-40-standard-with-system-packages| |image-fedora-40-standard-with-targets-pre| |image-fedora-40-standard-with-targets| |image-fedora-40-standard-with-targets-optional|
     - |codespace-fedora-40-standard|
   * -    ‑*maximal*
     - |image-fedora-40-maximal-with-system-packages| |image-fedora-40-maximal-with-targets-pre|
     -
   * - **fedora**-41 
       
          ‑*minimal*
     - |image-fedora-41-minimal-with-system-packages| |image-fedora-41-minimal-with-targets-pre| |image-fedora-41-minimal-with-targets| |image-fedora-41-minimal-with-targets-optional|
     - |codespace-fedora-41-minimal|
   * -    ‑*standard*
     - |image-fedora-41-standard-with-system-packages| |image-fedora-41-standard-with-targets-pre| |image-fedora-41-standard-with-targets| |image-fedora-41-standard-with-targets-optional|
     - |codespace-fedora-41-standard|
   * -    ‑*maximal*
     - |image-fedora-41-maximal-with-system-packages| |image-fedora-41-maximal-with-targets-pre|
     -
   * - **fedora**-42 
       
          ‑*minimal*
     - |image-fedora-42-minimal-with-system-packages| |image-fedora-42-minimal-with-targets-pre| |image-fedora-42-minimal-with-targets| |image-fedora-42-minimal-with-targets-optional|
     - |codespace-fedora-42-minimal|
   * -    ‑*standard*
     - |image-fedora-42-standard-with-system-packages| |image-fedora-42-standard-with-targets-pre| |image-fedora-42-standard-with-targets| |image-fedora-42-standard-with-targets-optional|
     - |codespace-fedora-42-standard|
   * -    ‑*maximal*
     - |image-fedora-42-maximal-with-system-packages| |image-fedora-42-maximal-with-targets-pre|
     -
   * - **fedora**-43 
       
          ‑*minimal*
     - |image-fedora-43-minimal-with-system-packages| |image-fedora-43-minimal-with-targets-pre| |image-fedora-43-minimal-with-targets| |image-fedora-43-minimal-with-targets-optional|
     - |codespace-fedora-43-minimal|
   * -    ‑*standard*
     - |image-fedora-43-standard-with-system-packages| |image-fedora-43-standard-with-targets-pre| |image-fedora-43-standard-with-targets| |image-fedora-43-standard-with-targets-optional|
     - |codespace-fedora-43-standard|
   * -    ‑*maximal*
     - |image-fedora-43-maximal-with-system-packages| |image-fedora-43-maximal-with-targets-pre|
     -
   * - **centos**-stream-9 
       
          ‑*minimal*
     - |image-centos-stream-9-minimal-with-system-packages| |image-centos-stream-9-minimal-with-targets-pre| |image-centos-stream-9-minimal-with-targets| |image-centos-stream-9-minimal-with-targets-optional|
     - |codespace-centos-stream-9-minimal|
   * -    ‑*standard*
     - |image-centos-stream-9-standard-with-system-packages| |image-centos-stream-9-standard-with-targets-pre| |image-centos-stream-9-standard-with-targets| |image-centos-stream-9-standard-with-targets-optional|
     - |codespace-centos-stream-9-standard|
   * -    ‑*maximal*
     - |image-centos-stream-9-maximal-with-system-packages| |image-centos-stream-9-maximal-with-targets-pre|
     -
   * - **centos**-stream-9-python3.12 
       
          ‑*minimal*
     - |image-centos-stream-9-python3.12-minimal-with-system-packages| |image-centos-stream-9-python3.12-minimal-with-targets-pre| |image-centos-stream-9-python3.12-minimal-with-targets| |image-centos-stream-9-python3.12-minimal-with-targets-optional|
     - |codespace-centos-stream-9-python3.12-minimal|
   * -    ‑*standard*
     - |image-centos-stream-9-python3.12-standard-with-system-packages| |image-centos-stream-9-python3.12-standard-with-targets-pre| |image-centos-stream-9-python3.12-standard-with-targets| |image-centos-stream-9-python3.12-standard-with-targets-optional|
     - |codespace-centos-stream-9-python3.12-standard|
   * -    ‑*maximal*
     - |image-centos-stream-9-python3.12-maximal-with-system-packages| |image-centos-stream-9-python3.12-maximal-with-targets-pre|
     -
   * - **centos**-stream-10 
       
          ‑*minimal*
     - |image-centos-stream-10-minimal-with-system-packages| |image-centos-stream-10-minimal-with-targets-pre| |image-centos-stream-10-minimal-with-targets| |image-centos-stream-10-minimal-with-targets-optional|
     - |codespace-centos-stream-10-minimal|
   * -    ‑*standard*
     - |image-centos-stream-10-standard-with-system-packages| |image-centos-stream-10-standard-with-targets-pre| |image-centos-stream-10-standard-with-targets| |image-centos-stream-10-standard-with-targets-optional|
     - |codespace-centos-stream-10-standard|
   * -    ‑*maximal*
     - |image-centos-stream-10-maximal-with-system-packages| |image-centos-stream-10-maximal-with-targets-pre|
     -
   * - **almalinux**-8-toolset-gcc_9-python3.12 
       
          ‑*minimal*
     - |image-almalinux-8-toolset-gcc_9-python3.12-minimal-with-system-packages| |image-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets-pre| |image-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets| |image-almalinux-8-toolset-gcc_9-python3.12-minimal-with-targets-optional|
     - |codespace-almalinux-8-toolset-gcc_9-python3.12-minimal|
   * -    ‑*standard*
     - |image-almalinux-8-toolset-gcc_9-python3.12-standard-with-system-packages| |image-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets-pre| |image-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets| |image-almalinux-8-toolset-gcc_9-python3.12-standard-with-targets-optional|
     - |codespace-almalinux-8-toolset-gcc_9-python3.12-standard|
   * -    ‑*maximal*
     - |image-almalinux-8-toolset-gcc_9-python3.12-maximal-with-system-packages| |image-almalinux-8-toolset-gcc_9-python3.12-maximal-with-targets-pre|
     -
   * - **almalinux**-9-python3.11 
       
          ‑*minimal*
     - |image-almalinux-9-python3.11-minimal-with-system-packages| |image-almalinux-9-python3.11-minimal-with-targets-pre| |image-almalinux-9-python3.11-minimal-with-targets| |image-almalinux-9-python3.11-minimal-with-targets-optional|
     - |codespace-almalinux-9-python3.11-minimal|
   * -    ‑*standard*
     - |image-almalinux-9-python3.11-standard-with-system-packages| |image-almalinux-9-python3.11-standard-with-targets-pre| |image-almalinux-9-python3.11-standard-with-targets| |image-almalinux-9-python3.11-standard-with-targets-optional|
     - |codespace-almalinux-9-python3.11-standard|
   * -    ‑*maximal*
     - |image-almalinux-9-python3.11-maximal-with-system-packages| |image-almalinux-9-python3.11-maximal-with-targets-pre|
     -
   * - **alpine** 
       
          ‑*minimal*
     - |image-alpine-minimal-with-system-packages| |image-alpine-minimal-with-targets-pre| |image-alpine-minimal-with-targets| |image-alpine-minimal-with-targets-optional|
     - |codespace-alpine-minimal|
   * -    ‑*standard*
     - |image-alpine-standard-with-system-packages| |image-alpine-standard-with-targets-pre| |image-alpine-standard-with-targets| |image-alpine-standard-with-targets-optional|
     - |codespace-alpine-standard|
   * -    ‑*maximal*
     - |image-alpine-maximal-with-system-packages| |image-alpine-maximal-with-targets-pre|
     -
   * - **gentoo**-python3.13 
       
          ‑*minimal*
     - |image-gentoo-python3.13-minimal-with-system-packages| |image-gentoo-python3.13-minimal-with-targets-pre| |image-gentoo-python3.13-minimal-with-targets| |image-gentoo-python3.13-minimal-with-targets-optional|
     - |codespace-gentoo-python3.13-minimal|
   * -    ‑*standard*
     - |image-gentoo-python3.13-standard-with-system-packages| |image-gentoo-python3.13-standard-with-targets-pre| |image-gentoo-python3.13-standard-with-targets| |image-gentoo-python3.13-standard-with-targets-optional|
     - |codespace-gentoo-python3.13-standard|
   * -    ‑*maximal*
     - |image-gentoo-python3.13-maximal-with-system-packages| |image-gentoo-python3.13-maximal-with-targets-pre|
     -
   * - **archlinux**-latest 
       
          ‑*minimal*
     - |image-archlinux-latest-minimal-with-system-packages| |image-archlinux-latest-minimal-with-targets-pre| |image-archlinux-latest-minimal-with-targets| |image-archlinux-latest-minimal-with-targets-optional|
     - |codespace-archlinux-latest-minimal|
   * -    ‑*standard*
     - |image-archlinux-latest-standard-with-system-packages| |image-archlinux-latest-standard-with-targets-pre| |image-archlinux-latest-standard-with-targets| |image-archlinux-latest-standard-with-targets-optional|
     - |codespace-archlinux-latest-standard|
   * -    ‑*maximal*
     - |image-archlinux-latest-maximal-with-system-packages| |image-archlinux-latest-maximal-with-targets-pre|
     -
   * - **opensuse**-15.6-gcc_11-python3.11 
       
          ‑*minimal*
     - |image-opensuse-15.6-gcc_11-python3.11-minimal-with-system-packages| |image-opensuse-15.6-gcc_11-python3.11-minimal-with-targets-pre| |image-opensuse-15.6-gcc_11-python3.11-minimal-with-targets| |image-opensuse-15.6-gcc_11-python3.11-minimal-with-targets-optional|
     - |codespace-opensuse-15.6-gcc_11-python3.11-minimal|
   * -    ‑*standard*
     - |image-opensuse-15.6-gcc_11-python3.11-standard-with-system-packages| |image-opensuse-15.6-gcc_11-python3.11-standard-with-targets-pre| |image-opensuse-15.6-gcc_11-python3.11-standard-with-targets| |image-opensuse-15.6-gcc_11-python3.11-standard-with-targets-optional|
     - |codespace-opensuse-15.6-gcc_11-python3.11-standard|
   * -    ‑*maximal*
     - |image-opensuse-15.6-gcc_11-python3.11-maximal-with-system-packages| |image-opensuse-15.6-gcc_11-python3.11-maximal-with-targets-pre|
     -
   * - **opensuse**-tumbleweed-python3.10 
       
          ‑*minimal*
     - |image-opensuse-tumbleweed-python3.10-minimal-with-system-packages| |image-opensuse-tumbleweed-python3.10-minimal-with-targets-pre| |image-opensuse-tumbleweed-python3.10-minimal-with-targets| |image-opensuse-tumbleweed-python3.10-minimal-with-targets-optional|
     - |codespace-opensuse-tumbleweed-python3.10-minimal|
   * -    ‑*standard*
     - |image-opensuse-tumbleweed-python3.10-standard-with-system-packages| |image-opensuse-tumbleweed-python3.10-standard-with-targets-pre| |image-opensuse-tumbleweed-python3.10-standard-with-targets| |image-opensuse-tumbleweed-python3.10-standard-with-targets-optional|
     - |codespace-opensuse-tumbleweed-python3.10-standard|
   * -    ‑*maximal*
     - |image-opensuse-tumbleweed-python3.10-maximal-with-system-packages| |image-opensuse-tumbleweed-python3.10-maximal-with-targets-pre|
     -
   * - **opensuse**-tumbleweed 
       
          ‑*minimal*
     - |image-opensuse-tumbleweed-minimal-with-system-packages| |image-opensuse-tumbleweed-minimal-with-targets-pre| |image-opensuse-tumbleweed-minimal-with-targets| |image-opensuse-tumbleweed-minimal-with-targets-optional|
     - |codespace-opensuse-tumbleweed-minimal|
   * -    ‑*standard*
     - |image-opensuse-tumbleweed-standard-with-system-packages| |image-opensuse-tumbleweed-standard-with-targets-pre| |image-opensuse-tumbleweed-standard-with-targets| |image-opensuse-tumbleweed-standard-with-targets-optional|
     - |codespace-opensuse-tumbleweed-standard|
   * -    ‑*maximal*
     - |image-opensuse-tumbleweed-maximal-with-system-packages| |image-opensuse-tumbleweed-maximal-with-targets-pre|
     -
   * - **voidlinux**-musl 
       
          ‑*minimal*
     - |image-voidlinux-musl-minimal-with-system-packages| |image-voidlinux-musl-minimal-with-targets-pre| |image-voidlinux-musl-minimal-with-targets| |image-voidlinux-musl-minimal-with-targets-optional|
     - |codespace-voidlinux-musl-minimal|
   * -    ‑*standard*
     - |image-voidlinux-musl-standard-with-system-packages| |image-voidlinux-musl-standard-with-targets-pre| |image-voidlinux-musl-standard-with-targets| |image-voidlinux-musl-standard-with-targets-optional|
     - |codespace-voidlinux-musl-standard|
   * -    ‑*maximal*
     - |image-voidlinux-musl-maximal-with-system-packages| |image-voidlinux-musl-maximal-with-targets-pre|
     -
   * - **voidlinux** 
       
          ‑*minimal*
     - |image-voidlinux-minimal-with-system-packages| |image-voidlinux-minimal-with-targets-pre| |image-voidlinux-minimal-with-targets| |image-voidlinux-minimal-with-targets-optional|
     - |codespace-voidlinux-minimal|
   * -    ‑*standard*
     - |image-voidlinux-standard-with-system-packages| |image-voidlinux-standard-with-targets-pre| |image-voidlinux-standard-with-targets| |image-voidlinux-standard-with-targets-optional|
     - |codespace-voidlinux-standard|
   * -    ‑*maximal*
     - |image-voidlinux-maximal-with-system-packages| |image-voidlinux-maximal-with-targets-pre|
     -
   * - **conda**-forge-python3.11 
       
          ‑*standard*
     - |image-conda-forge-python3.11-standard-with-system-packages| |image-conda-forge-python3.11-standard-with-targets-pre| |image-conda-forge-python3.11-standard-with-targets| |image-conda-forge-python3.11-standard-with-targets-optional|
     - |codespace-conda-forge-python3.11-standard|
   * -    ‑*maximal*
     - |image-conda-forge-python3.11-maximal-with-system-packages| |image-conda-forge-python3.11-maximal-with-targets-pre|
     -
   * - **ubuntu**-bionic-toolchain-gcc_9-i386 
       
          ‑*minimal*
     - |image-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-system-packages| |image-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets-pre| |image-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets| |image-ubuntu-bionic-toolchain-gcc_9-i386-minimal-with-targets-optional|
     - |codespace-ubuntu-bionic-toolchain-gcc_9-i386-minimal|
   * -    ‑*standard*
     - |image-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-system-packages| |image-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets-pre| |image-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets| |image-ubuntu-bionic-toolchain-gcc_9-i386-standard-with-targets-optional|
     - |codespace-ubuntu-bionic-toolchain-gcc_9-i386-standard|
   * -    ‑*maximal*
     - |image-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-system-packages| |image-ubuntu-bionic-toolchain-gcc_9-i386-maximal-with-targets-pre|
     -
   * - **debian**-bullseye-i386 
       
          ‑*minimal*
     - |image-debian-bullseye-i386-minimal-with-system-packages| |image-debian-bullseye-i386-minimal-with-targets-pre| |image-debian-bullseye-i386-minimal-with-targets| |image-debian-bullseye-i386-minimal-with-targets-optional|
     - |codespace-debian-bullseye-i386-minimal|
   * -    ‑*standard*
     - |image-debian-bullseye-i386-standard-with-system-packages| |image-debian-bullseye-i386-standard-with-targets-pre| |image-debian-bullseye-i386-standard-with-targets| |image-debian-bullseye-i386-standard-with-targets-optional|
     - |codespace-debian-bullseye-i386-standard|
   * -    ‑*maximal*
     - |image-debian-bullseye-i386-maximal-with-system-packages| |image-debian-bullseye-i386-maximal-with-targets-pre|
     -
   * - **fedora**-40-arm64v8 
       
          ‑*minimal*
     - |image-fedora-40-arm64v8-minimal-with-system-packages| |image-fedora-40-arm64v8-minimal-with-targets-pre| |image-fedora-40-arm64v8-minimal-with-targets| |image-fedora-40-arm64v8-minimal-with-targets-optional|
     - |codespace-fedora-40-arm64v8-minimal|
   * -    ‑*standard*
     - |image-fedora-40-arm64v8-standard-with-system-packages| |image-fedora-40-arm64v8-standard-with-targets-pre| |image-fedora-40-arm64v8-standard-with-targets| |image-fedora-40-arm64v8-standard-with-targets-optional|
     - |codespace-fedora-40-arm64v8-standard|
   * -    ‑*maximal*
     - |image-fedora-40-arm64v8-maximal-with-system-packages| |image-fedora-40-arm64v8-maximal-with-targets-pre|
     -
   * - **fedora**-41-arm64v8 
       
          ‑*minimal*
     - |image-fedora-41-arm64v8-minimal-with-system-packages| |image-fedora-41-arm64v8-minimal-with-targets-pre| |image-fedora-41-arm64v8-minimal-with-targets| |image-fedora-41-arm64v8-minimal-with-targets-optional|
     - |codespace-fedora-41-arm64v8-minimal|
   * -    ‑*standard*
     - |image-fedora-41-arm64v8-standard-with-system-packages| |image-fedora-41-arm64v8-standard-with-targets-pre| |image-fedora-41-arm64v8-standard-with-targets| |image-fedora-41-arm64v8-standard-with-targets-optional|
     - |codespace-fedora-41-arm64v8-standard|
   * -    ‑*maximal*
     - |image-fedora-41-arm64v8-maximal-with-system-packages| |image-fedora-41-arm64v8-maximal-with-targets-pre|
     -
   * - **fedora**-42-arm64v8 
       
          ‑*minimal*
     - |image-fedora-42-arm64v8-minimal-with-system-packages| |image-fedora-42-arm64v8-minimal-with-targets-pre| |image-fedora-42-arm64v8-minimal-with-targets| |image-fedora-42-arm64v8-minimal-with-targets-optional|
     - |codespace-fedora-42-arm64v8-minimal|
   * -    ‑*standard*
     - |image-fedora-42-arm64v8-standard-with-system-packages| |image-fedora-42-arm64v8-standard-with-targets-pre| |image-fedora-42-arm64v8-standard-with-targets| |image-fedora-42-arm64v8-standard-with-targets-optional|
     - |codespace-fedora-42-arm64v8-standard|
   * -    ‑*maximal*
     - |image-fedora-42-arm64v8-maximal-with-system-packages| |image-fedora-42-arm64v8-maximal-with-targets-pre|
     -
   * - **fedora**-43-arm64v8 
       
          ‑*minimal*
     - |image-fedora-43-arm64v8-minimal-with-system-packages| |image-fedora-43-arm64v8-minimal-with-targets-pre| |image-fedora-43-arm64v8-minimal-with-targets| |image-fedora-43-arm64v8-minimal-with-targets-optional|
     - |codespace-fedora-43-arm64v8-minimal|
   * -    ‑*standard*
     - |image-fedora-43-arm64v8-standard-with-system-packages| |image-fedora-43-arm64v8-standard-with-targets-pre| |image-fedora-43-arm64v8-standard-with-targets| |image-fedora-43-arm64v8-standard-with-targets-optional|
     - |codespace-fedora-43-arm64v8-standard|
   * -    ‑*maximal*
     - |image-fedora-43-arm64v8-maximal-with-system-packages| |image-fedora-43-arm64v8-maximal-with-targets-pre|
     -

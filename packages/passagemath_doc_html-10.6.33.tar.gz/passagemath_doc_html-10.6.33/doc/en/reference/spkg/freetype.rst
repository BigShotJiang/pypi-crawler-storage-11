.. _spkg_freetype:

freetype: A free, high-quality, and portable font engine
========================================================

Description
-----------

From the documentation:

FreeType is a software font engine that is designed to be small,
efficient, highly customizable, and portable while capable of
producing high-quality output (glyph images). It can be used in
graphics libraries, display servers, font conversion tools, text image
generation tools, and many other products as well.

Note that FreeType is a font service and doesn't provide APIs to
perform higher-level features like text layout or graphics processing
(e.g., colored text rendering, ‘hollowing’, etc.). However, it greatly
simplifies these tasks by providing a simple, easy to use, and uniform
interface to access the content of font files.

Please note that ‘FreeType’ is also called ‘FreeType 2’, to
distinguish it from the old, deprecated ‘FreeType 1’ library, a
predecessor no longer maintained and supported.

The package in Sage is called freetype (in lowercase).

License
-------

-  FreeType (BSD-like)
-  GNU Public License v2

From the documentation:

FreeType is released under two open-source licenses: our own BSD-like
FreeType License and the GNU Public License, Version 2. It can thus
be used by any kind of projects, be they proprietary or not.


Upstream Contact
----------------

-  home: https://www.freetype.org
-  repo:

   -  official: http://git.savannah.gnu.org/cgit/freetype
   -  mirror: https://github.com/aseprite/freetype2/


Type
----

standard


Dependencies
------------

- :ref:`spkg_bzip2`
- :ref:`spkg_libpng`

Version Information
-------------------

package-version.txt::

    2.10.4

See https://repology.org/project/freetype/versions

Installation commands
---------------------

.. tab:: Sage distribution:

   .. CODE-BLOCK:: bash

       $ sage -i freetype

.. tab:: Alpine:

   .. CODE-BLOCK:: bash

       $ apk add freetype-dev

.. tab:: conda-forge:

   .. CODE-BLOCK:: bash

       $ conda install freetype

.. tab:: Debian/Ubuntu:

   .. CODE-BLOCK:: bash

       $ sudo apt-get install libfreetype-dev

.. tab:: FreeBSD:

   .. CODE-BLOCK:: bash

       $ sudo pkg install print/freetype2

.. tab:: Homebrew:

   .. CODE-BLOCK:: bash

       $ brew install freetype

.. tab:: MacPorts:

   No package needed

.. tab:: mingw-w64:

   .. CODE-BLOCK:: bash

       $ sudo pacman -S -freetype

.. tab:: Nixpkgs:

   .. CODE-BLOCK:: bash

       $ nix-env -f \'\<nixpkgs\>\' --install --attr freetype

.. tab:: openSUSE:

   .. CODE-BLOCK:: bash

       $ sudo zypper install pkgconfig\(freetype2\)

.. tab:: Slackware:

   .. CODE-BLOCK:: bash

       $ sudo slackpkg install freetype harfbuzz glib glib2

.. tab:: Void Linux:

   .. CODE-BLOCK:: bash

       $ sudo xbps-install freetype-devel


If the system package is installed, ``./configure`` will check if it can be used.

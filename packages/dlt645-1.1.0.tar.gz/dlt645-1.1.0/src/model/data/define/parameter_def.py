from typing import List

from ....model.data.define.energy_def import DIMap
from ....model.types.data_type import DataItem

# 根据长度补0
def pad_with_zeros(length: int) -> str:
    return "0" * length

def init_parameter_def(ParaMeterTypes: List[DataItem]):
    for date_type in ParaMeterTypes:
        DIMap[date_type.di] = DataItem(
            di=date_type.di,
            name=date_type.name,
            data_format=date_type.data_format,
            value=pad_with_zeros(len(date_type.data_format)),
            unit=date_type.unit,
        )

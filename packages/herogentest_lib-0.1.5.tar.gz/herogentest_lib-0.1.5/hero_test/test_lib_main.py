from herogentest_lib.controller.team import router as teams_router
from herogentest_lib.controller.hero import router as heroes_router
from herogentest_lib.util.database import init_db
from fastapi import FastAPI

app = FastAPI(title="FastAPI + SQLModel - MVC + Repository")

init_db()

app.include_router(heroes_router)
app.include_router(teams_router)

@app.get("/")
def health():
    return {"status": "ok"}
"""Zombie-squirrel: caching and synchronization for AIND metadata.

Provides functions to fetch and cache project names, subject IDs, and asset
metadata from the AIND metadata database with support for multiple backends."""

__version__ = "0.4.2"

from zombie_squirrel.squirrels import (  # noqa: F401
    asset_basics,
    raw_to_derived,
    source_data,
    unique_project_names,
    unique_subject_ids,
)

"""Slingshot API client."""

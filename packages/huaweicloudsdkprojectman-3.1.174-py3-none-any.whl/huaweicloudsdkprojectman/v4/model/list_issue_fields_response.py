# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListIssueFieldsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'page': 'PageVO',
        'result': 'list[FieldVO]'
    }

    attribute_map = {
        'page': 'page',
        'result': 'result'
    }

    def __init__(self, page=None, result=None):
        r"""ListIssueFieldsResponse

        The model defined in huaweicloud sdk

        :param page: 
        :type page: :class:`huaweicloudsdkprojectman.v4.PageVO`
        :param result: 返回数据
        :type result: list[:class:`huaweicloudsdkprojectman.v4.FieldVO`]
        """
        
        super().__init__()

        self._page = None
        self._result = None
        self.discriminator = None

        if page is not None:
            self.page = page
        if result is not None:
            self.result = result

    @property
    def page(self):
        r"""Gets the page of this ListIssueFieldsResponse.

        :return: The page of this ListIssueFieldsResponse.
        :rtype: :class:`huaweicloudsdkprojectman.v4.PageVO`
        """
        return self._page

    @page.setter
    def page(self, page):
        r"""Sets the page of this ListIssueFieldsResponse.

        :param page: The page of this ListIssueFieldsResponse.
        :type page: :class:`huaweicloudsdkprojectman.v4.PageVO`
        """
        self._page = page

    @property
    def result(self):
        r"""Gets the result of this ListIssueFieldsResponse.

        返回数据

        :return: The result of this ListIssueFieldsResponse.
        :rtype: list[:class:`huaweicloudsdkprojectman.v4.FieldVO`]
        """
        return self._result

    @result.setter
    def result(self, result):
        r"""Sets the result of this ListIssueFieldsResponse.

        返回数据

        :param result: The result of this ListIssueFieldsResponse.
        :type result: list[:class:`huaweicloudsdkprojectman.v4.FieldVO`]
        """
        self._result = result

    def to_dict(self):
        import warnings
        warnings.warn("ListIssueFieldsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListIssueFieldsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

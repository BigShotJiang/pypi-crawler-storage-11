# Caki

Auto is a Python tool that automatically installs pip packages if you try to run them and they are missing.  

## Example

```bash
caki black --version

## This should either log black's version, or install then log
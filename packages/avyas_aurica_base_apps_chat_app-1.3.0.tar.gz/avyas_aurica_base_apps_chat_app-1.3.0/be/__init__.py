"""Chat app backend module."""

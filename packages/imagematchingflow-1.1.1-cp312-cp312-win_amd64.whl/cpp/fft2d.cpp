/****************************************************************************
NAME:				FFT2d

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
1.0	 8/92	D. Steinwand 

ALGORITHM DESCRIPTION:

FFT2D replaces DATA by its 2 dimensional discrete Fourier Transform,
if ISIGN = 1.  Each dimension must be a power of 2.  DATA is an array of 
type float, twice the length of the product of these lengths in which the 
data are stored as in a multidimensional complex array:  real and imaginary 
parts of each element are in consecutive locations, and the rightmost index 
of the array increases most rapidly as one proceeds along DATA.  This is 
equivalent to storing the array by rows (the C-way; FORTRAN stores by 
columns!).  IF ISIGN = -1, DATA is replaced by its inverse transform times 
the product of the lengths of all dimensions.

REFERENCES:
This routine was derrived from a multi-dimensional FFT in "Numerical 
Recipes in C", by Press, FLannery, Teukolsky, and Vetterling, 
Cambridge University Press, 1988.
*****************************************************************************/
#include "immatch.h"
#define SWAP(a,b) tempr=(a);(a)=(b);(b)=tempr

/* Prototypes */
void fftnd
(
 float data[],
 int nn[],
 int ndim,
 int isign
 );


void fft2d
(
 float *data,
 long nrows,
 long ncols,
 long isign
 )
{
	int dim[3];
	data--;
	dim[1] = (int)nrows;
	dim[2] = (int)ncols;
	fftnd(data, dim, 2, isign);	/* Call generic n-d FFT */
	return;
}


/* Generic N-d FFT
---------------*/
void fftnd
(
 float data[],
 int nn[],
 int ndim,
 int isign
 )
{
	int i1,i2,i3,i2rev,i3rev,ip1,ip2,ip3,ifp1,ifp2;
	int ibit,idim,k1,k2,n,nprev,nrem,ntot;
	float tempi,tempr;
	double theta,wi,wpi,wpr,wr,wtemp;	/* Double for trig recurrences */

	ntot=1;
	for (idim=1;idim<=ndim;idim++) ntot *= nn[idim];  /* Calc no of complex vals */
	nprev=1;
	for (idim=ndim;idim>=1;idim--) 
	{
		n=nn[idim];
		nrem=ntot/(n*nprev);
		ip1=nprev << 1;
		ip2=ip1*n;
		ip3=ip2*nrem;
		i2rev=1;
		for (i2=1;i2<=ip2;i2+=ip1) 		/* Perfrom bit reversal */
		{
			if (i2 < i2rev) 
			{
				for (i1=i2;i1<=i2+ip1-2;i1+=2) 
				{
					for (i3=i1;i3<=ip3;i3+=ip2) 
					{
						i3rev=i2rev+i3-i2;
						SWAP(data[i3],data[i3rev]);
						SWAP(data[i3+1],data[i3rev+1]);
					}
				}
			}
			ibit=ip2 >> 1;
			while (ibit >= ip1 && i2rev > ibit) 
			{
				i2rev -= ibit;
				ibit >>= 1;
			}
			i2rev += ibit;
		}
		ifp1=ip1;				/* Danielson-Lanczos section */
		while (ifp1 < ip2) 
		{
			ifp2=ifp1 << 1;
			theta=isign*6.28318530717959/(ifp2/ip1);  /* Init. trig recurrence */
			wtemp=sin(0.5*theta);
			wpr = -2.0*wtemp*wtemp;
			wpi=sin(theta);
			wr=1.0; wi=0.0;
			for (i3=1;i3<=ifp1;i3+=ip1) 
			{
				for (i1=i3;i1<=i3+ip1-2;i1+=2) 
				{
					for (i2=i1;i2<=ip3;i2+=ifp2) 
					{
						k1=i2;
						k2=k1+ifp1;
						tempr=wr*data[k2]-wi*data[k2+1];
						tempi=wr*data[k2+1]+wi*data[k2];
						data[k2]=data[k1]-tempr;
						data[k2+1]=data[k1+1]-tempi;
						data[k1] += tempr;
						data[k1+1] += tempi;
					}
				}
				wr+=(wtemp=wr)*wpr-wi*wpi;  /* Trig recurrence */
				wi+=wi*wpr+wtemp*wpi;
			}
			ifp1=ifp2;
		}
		nprev *= n;
	}
}
#undef SWAP


#include "pybind11/pybind11.h"

namespace py = pybind11;

#include "ImageMatchCpp.h"
#include "CppWrapper.h"

PYBIND11_MODULE(IMFlow, m)
{



    m.def("SelectedMatch", &SelectedMatch, 
        "Image matchign with a selected pixel", py::arg("image1"), py::arg("image2"), py::arg("row"), py::arg("col"), py::arg("params"));

    py::class_<ImageMatchCpp::LineSeg>(m, "LineSeg")
        .def(py::init<>())
        .def("set_coors", &ImageMatchCpp::LineSeg::SetCoors)
        .def("get_length", &ImageMatchCpp::LineSeg::get_Length)
        .def_readwrite("strength", &ImageMatchCpp::LineSeg::strength_)
        .def_readwrite("displacement", &ImageMatchCpp::LineSeg::displacement_)
        .def_readwrite("rms_1", &ImageMatchCpp::LineSeg::rms_1)
        .def_readwrite("rms_2", &ImageMatchCpp::LineSeg::rms_2)
        .def_readwrite("x1", &ImageMatchCpp::LineSeg::x1_)
        .def_readwrite("y1", &ImageMatchCpp::LineSeg::y1_)
        .def_readwrite("x2", &ImageMatchCpp::LineSeg::x2_)
        .def_readwrite("y2", &ImageMatchCpp::LineSeg::y2_)
        .def_readwrite("active", &ImageMatchCpp::LineSeg::active_)
        //printing function for these parameters
       .def("__repr__",
            [](const ImageMatchCpp::LineSeg &a) {
                return "<LineSeg x1: " + std::to_string(a.x1_) + 
                       ", y1: " + std::to_string(a.y1_) + 
                       ", x2: " + std::to_string(a.x2_) + 
                       ", y2: " + std::to_string(a.y2_) + 
                       ", length: " + std::to_string(a.get_Length()) +
                       ", strength: " + std::to_string(a.strength_) +
                       ", displacement: " + std::to_string(a.displacement_) +
                       ", rms_1: " + std::to_string(a.rms_1) +
                       ", rms_2: " + std::to_string(a.rms_2) +
                       ", active: " + std::to_string(a.active_) +
                       ">";
            }
        )
        .def("__str__", 
            [](const ImageMatchCpp::LineSeg &a) {
                return "<LineSeg x1: " + std::to_string(a.x1_) + 
                       ", y1: " + std::to_string(a.y1_) + 
                       ", x2: " + std::to_string(a.x2_) + 
                       ", y2: " + std::to_string(a.y2_) + 
                       ", length: " + std::to_string(a.get_Length()) +
                       ", strength: " + std::to_string(a.strength_) +
                       ", displacement: " + std::to_string(a.displacement_) +
                       ", rms_1: " + std::to_string(a.rms_1) +
                       ", rms_2: " + std::to_string(a.rms_2) +
                       ", active: " + std::to_string(a.active_) +
                       ">";
            }
        )
        .def(py::pickle(
            [](const ImageMatchCpp::LineSeg &a) { // __getstate__
                return py::make_tuple(a.x1_, a.y1_, a.x2_, a.y2_, 
                                      a.strength_, a.displacement_,
                                      a.rms_1, a.rms_2, a.active_);
            },
            [](py::tuple t) { // __setstate__
                if (t.size() != 9)
                    throw std::runtime_error("Invalid state!");

                ImageMatchCpp::LineSeg a;
                a.SetCoors(t[0].cast<double>(), t[1].cast<double>(),
                           t[2].cast<double>(), t[3].cast<double>());
                a.strength_ = t[4].cast<float>();
                a.displacement_ = t[5].cast<float>();
                a.rms_1 = t[6].cast<float>();
                a.rms_2 = t[7].cast<float>();
                a.active_ = t[8].cast<int>();
                return a;
            }
        )
        );

    py::class_<MatchingParams>(m, "MatchingParams")
        .def(py::init<>())
        .def_readwrite("peakmethod_", &MatchingParams::peakmethod_)
        .def_readwrite("ref_cellsize_", &MatchingParams::ref_cellsize_)
        .def_readwrite("srch_cellsize_", &MatchingParams::srch_cellsize_)
        .def_readwrite("corrtype_", &MatchingParams::corrtype_)
        .def_readwrite("maxdiff_", &MatchingParams::maxdiff_)
        .def_readwrite("mincorr_", &MatchingParams::mincorr_)
        .def_readwrite("start_row_", &MatchingParams::start_row_)
        .def_readwrite("start_col_", &MatchingParams::start_col_)
        .def_readwrite("srch_xll_", &MatchingParams::srch_xll_)
        .def_readwrite("srch_yll_", &MatchingParams::srch_yll_)
        .def_readwrite("ref_xll_", &MatchingParams::ref_xll_)
        .def_readwrite("ref_yll_", &MatchingParams::ref_yll_)
        .def_readwrite("chipwidth_", &MatchingParams::chipwidth_)
        .def_readwrite("chipheight_", &MatchingParams::chipheight_)
        .def_readwrite("hoffset_", &MatchingParams::hoffset_)
        .def_readwrite("voffset_", &MatchingParams::voffset_)
        .def_readwrite("row_interval_", &MatchingParams::row_interval_)
        .def_readwrite("col_interval_", &MatchingParams::col_interval_)
        .def_readwrite("row_offset_", &MatchingParams::row_offset_)
        .def_readwrite("col_offset_", &MatchingParams::col_offset_)
        .def(py::pickle(
            [](const MatchingParams &p) { // __getstate__
                return py::make_tuple(
                    p.peakmethod_,
                    p.ref_cellsize_,
                    p.srch_cellsize_,
                    p.corrtype_,
                    p.maxdiff_,
                    p.mincorr_,
                    p.start_row_,
                    p.start_col_,
                    p.srch_xll_,
                    p.srch_yll_,
                    p.ref_xll_,
                    p.ref_yll_,
                    p.chipwidth_,
                    p.chipheight_,
                    p.hoffset_,
                    p.voffset_,
                    p.row_interval_,
                    p.col_interval_,
                    p.row_offset_,
                    p.col_offset_
                );
            },
            [](py::tuple t) { // __setstate__
                if (t.size() != 20)
                    throw std::runtime_error("Invalid state!");

                MatchingParams p;
                p.peakmethod_ = t[0].cast<int>();
                p.ref_cellsize_ = t[1].cast<double>();
                p.srch_cellsize_ = t[2].cast<double>();
                p.corrtype_ = t[3].cast<int>();
                p.maxdiff_ = t[4].cast<double>();
                p.mincorr_ = t[5].cast<double>();
                p.start_row_ = t[6].cast<int>();
                p.start_col_ = t[7].cast<int>();
                p.srch_xll_ = t[8].cast<double>();
                p.srch_yll_ = t[9].cast<double>();
                p.ref_xll_ = t[10].cast<double>();
                p.ref_yll_ = t[11].cast<double>();
                p.chipwidth_ = t[12].cast<int>();
                p.chipheight_ = t[13].cast<int>();
                p.hoffset_ = t[14].cast<int>();
                p.voffset_ = t[15].cast<int>();
                p.row_interval_ = t[16].cast<int>();
                p.col_interval_ = t[17].cast<int>();
                p.row_offset_ = t[18].cast<int>();
                p.col_offset_ = t[19].cast<int>();
                return p;
            }
        )
        );
    m.doc() = "Image matching using C++ and pybind11"; // optional module docstring

    // Expose version info on the module, synchronized with setup.py/pyproject via VERSION file
    #ifdef VERSION_INFO
        m.attr("__version__") = VERSION_INFO;
        m.attr("version") = VERSION_INFO; // optional alias without underscores
    #else
        m.attr("__version__") = "0.0.0";
        m.attr("version") = "0.0.0";
    #endif
}

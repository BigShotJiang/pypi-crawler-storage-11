/****************************************************************************
NAME:				grey_corr

PURPOSE:  Performs grey (cross) correlation for a tie point

VERSION		DATE	AUTHOR
-------		----	------	
1.0	        8/92	D. Steinwand

*****************************************************************************/
#include "immatch.h"
/* Prototypes */
void gcorr
(
 float *images,	/* Search subimage 				     */
 float *imager,	/* Reference subimage 				     */
 float *npls,	/* Actual size of search subimage:  samps,lines      */
 float *nplr,	/* Actual size of reference subimage: samps,lines    */
 float csmin,	/* Minimum acceptable correlation strength 	     */
 long mfit,		/* Surface Fit Method:  1 - Elliptical paraboloid 
				2 - Elliptical Gaussian 
				3 - Reciprocal Paraboloid 
				4 - Round to nearest int     */
				float ddmx,		/* Maximum allowed diagonal displacement from nominal 
								tiepoint loc to location found by correlation    */
								float *ioffrq,	/* Requested maximum horiz & vert search offsets     */
								float *nomoff,	/* Nominal horiz & vert offsets of UL corner of 
												reference subimage relative to search subimage    */
												long *iacrej,	/* Accept/Reject code 				     */
												float *streng,	/* Strength of correlation 			     */
												float *bfoffs,	/* Best-fit horiz & vert offsets of correlation peak */
												float *tlerrs,	/* Est horiz error, vert error, and h-v cross term in 
																best-fit offsets 			     */
																float *ddact	/* Actual diagonal displacement from nominal tiepoint 
																				location to location found by correlation 	     */
																				);

void gnorm
(
 float *imager,	/* Reference subimage 				     */
 float *images,	/* Search subimage 				     */
 float *nplr,	/* Actual size of reference subimage--samps/lines    */
 float *npls,	/* Actual size of search subimage--samps/lines       */
 float *unormc,	/* Array of raw cross product sums 		     */
 float *ccnorm,	/* Array of norm xcorr coeffs 			     */
 float *pkval,	/* Table of top 32 normalized values 		     */
 long *ipkcol,	/* Table of column numbers for top 32 values 	     */
 long *ipkrow,	/* Table of row numbers for top 32 values 	     */
 float *sums		/* Sum of all normalized values, and sum of squares  */
 );


void grey_corr
(
struct TPLDATA *tpl,	/* Tie point location data record 	*/
struct CORRPAR *corr,	/* Correlation parameters 		*/
	float *ref,			/* Reference subimage 			*/
	float *srch,		/* Search subimage 			*/
	long *nominal		/* Nominal horizontal and vertical offsets*/
	)
{
	float mincorr;			/* Minimum acceptable correlation strength   */
	float maxdis;			/* Maximum displacement from nominal allowed */
	float disp;			/* Actual displacement from nominal  	     */
	float est_err[3];		/* Estimated correlation errors 	     */
	float best_fit[2];		/* Best fit offsets from correlation peak    */
	float npls[2];			/* Size of search subimage 		     */
	float nplr[2];			/* Size of reference subimage 		     */
	float ioffrq[2];		/* Requested max horiz & vert search offsets */
	float nomoff[2];		/* Nominal offsets 			     */
	float strength;			/* Strength of correlation 		     */
	long status;

	/* Assign values of C structure to individual variables 
	----------------------------------------------------*/
	npls[0] = (float)tpl->sea_size[0]; //samples
	npls[1] = (float)tpl->sea_size[1];  //lines
	nplr[0] = (float)tpl->ref_size[0];  //samples
	nplr[1] = (float)tpl->ref_size[1];  //lines
	mincorr = (float)corr->mincorr;
	maxdis = (float)corr->maxdiff;
	ioffrq[0] = (float)tpl->offsets[0];  //horizontal
	ioffrq[1] = (float)tpl->offsets[1]; //vertical
	nomoff[0] = (float)nominal[0]; //horizontal
	nomoff[1] = (float)nominal[1]; //vertical

	/* Perform grey level (cross) correlation
	--------------------------------------*/
	disp = 0.0;
	gcorr(srch, ref, npls, nplr, mincorr, corr->fitmeth, maxdis, ioffrq,
		nomoff, &status, &strength, best_fit, est_err, &disp);

	tpl->active = status;
	tpl->displacement = (double)disp;
	tpl->strength = (double)strength;

	if (tpl->active == 1)
	{
		tpl->sea_coord[0] = tpl->nominal[0] + best_fit[1]; //row
		tpl->sea_coord[1] = tpl->nominal[1] + best_fit[0]; //column
		//debugging info
		// cout<<"Best fit offsets: "<< best_fit[0] << ", " << best_fit[1] << endl;
		// cout << "Nominal row, col: " << tpl->nominal[0] << ", " << tpl->nominal[1] << endl;
		// cout << "Best fit row, col: " << tpl->sea_coord[0] << ", " << tpl->sea_coord[1] << endl;
		tpl->rms_error[0] = est_err[0]; //horizontal error
		tpl->rms_error[1] = est_err[1]; //vertical error
	}
	else
	{
		tpl->sea_coord[0] = tpl->nominal[0];
		tpl->sea_coord[1] = tpl->nominal[1];
		tpl->rms_error[0] = 0.0;
		tpl->rms_error[1] = 0.0;
	}
}


/****************************************************************************
NAME:				GCORR

PURPOSE:  Correlate a reference subimage with a search subimage and evaluate 
the results

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
1.0	 8/92	D. Steinwand 

REFERENCES:

1.  LAS 4.0 GREYCORR by R. White 6/83
*****************************************************************************/
void gcorr
(
 float *images,	/* Search subimage 				     */
 float *imager,	/* Reference subimage 				     */
 float *npls,	/* Actual size of search subimage:  samps,lines      */
 float *nplr,	/* Actual size of reference subimage: samps,lines    */
 float csmin,	/* Minimum acceptable correlation strength 	     */
 long mfit,		/* Surface Fit Method:  1 - Elliptical paraboloid 
				2 - Elliptical Gaussian 
				3 - Reciprocal Paraboloid 
				4 - Round to nearest int     */
				float ddmx,		/* Maximum allowed diagonal displacement from nominal 
								tiepoint loc to location found by correlation    */
								float *ioffrq,	/* Requested maximum horiz & vert search offsets     */
								float *nomoff,	/* Nominal horiz & vert offsets of UL corner of 
												reference subimage relative to search subimage    */
												long *iacrej,	/* Accept/Reject code 				     */
												float *streng,	/* Strength of correlation 			     */
												float *bfoffs,	/* Best-fit horiz & vert offsets of correlation peak */
												float *tlerrs,	/* Est horiz error, vert error, and h-v cross term in 
																best-fit offsets 			     */
																float *ddact	/* Actual diagonal displacement from nominal tiepoint 
																				location to location found by correlation 	     */
																				)
{
	long ipkcol[32];	/* Col number for each of top 32 correlation values  */
	long ipkrow[32];	/* Row number for each of top 32 correlation values  */
	long ncol;              /* Number of columns of search alignments 	     */
	long nrow;              /* Number of rows of search alignments 		     */
	float ccnorm[16641];	/* Normalized xcorr coefs for each search alignment  */
	float cpval[25];	/* 5 by 5 array of xcorr values, in std dev 	     */
	float pkoffs[2];	/* Fractional horiz & vert offsets of best-fit peak  */
	float pkval[32];	/* Largest 32 values of normalized xcorr coefs 	     */
	float sums[2];		/* Sum and sum of squares of all xcorr values 	     */
	float unormc[16641];	/* Unnormalized cross-product sum for each alignment */


	/* Compute raw cross-product sums
	------------------------------*/
	cross(images, imager, npls, nplr, unormc);

	/* Compute normalized cross-correlation values and compile statistics
	------------------------------------------------------------------*/
	gnorm(imager, images, nplr, npls, unormc, ccnorm, pkval, ipkcol, ipkrow, sums);

	/* Evaluate strength of correlation peak
	-------------------------------------*/
	ncol=(long)(npls[0]+0.5) - (long)(nplr[0]+0.5) + 1;
	nrow=(long)(npls[1]+0.5) - (long)(nplr[1]+0.5) + 1;
	eval(ncol,nrow,ccnorm,pkval,ipkcol,ipkrow,sums,csmin,streng,iacrej,cpval);

	/* Determine offsets of peak relative to nominal location
	------------------------------------------------------*/
	if (*iacrej==1)
	{
		if (mfit!=4)
		{
			fitreg(cpval, mfit, pkoffs, tlerrs);
			bfoffs[0] = (float)ipkcol[0] - nomoff[0] + pkoffs[0];
			bfoffs[1] = (float)ipkrow[0] - nomoff[1] + pkoffs[1];
		}
		else
		{
			bfoffs[0] = (float)ipkcol[0] - nomoff[0];
			bfoffs[1] = (float)ipkrow[0] - nomoff[1];
			tlerrs[0] = 0.5;
			tlerrs[1] = 0.5;
		}

		/* Determine diagonal displacement from nominal and check against maximum 
		acceptable value
		----------------*/
		*ddact = sqrt(bfoffs[0]*bfoffs[0] + bfoffs[1]*bfoffs[1]);
		if (ddmx<=0.0)
			ddmx=ioffrq[0] < ioffrq[1] ? ioffrq[0]-2.0 : ioffrq[1]-2.0;
		if (*ddact>ddmx)
			*iacrej = 5;
	}
}


/****************************************************************************
NAME:				CROSS

PURPOSE:  Compute the unnormalized (raw) sum of pixel-by-pixel cross products 
between the reference and search images for every combination of 
horizontal and vertical offsets of the reference relative to the 
search image

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
1.0	 8/92	D. Steinwand 

REFERENCES:

1.  LAS 4.0 GREYCORR by R. White & G. Neal 8/83
*****************************************************************************/
void cross
(
 float *images,	/* Search subimage 				  */
 float *imager,	/* Reference subimage 				  */
 float *npls,	/* Actual size of search subimage:  samps/lines   */
 float *nplr,	/* Actual size of reference subimage: samps/lines */
 float *unormc	/* Array of unnormalized (raw) counts of edge 
				coincidences for each alignment of reference image 
				relative to search image 			  */
				)
{
	float membfr[65536];	/* Buffer in which reference subimage is properly 
							aligned and zero padded 			  */
	float* membfs = new float[65536];	/* Buffer for aligning and padding search subimage*/
	long imgptr;		/* Pointer into subimage arrays 		  */
	long line;		/* Loop index:  current buffer line 		  */
	long lncont;		/* Pointer to start of next segment of line 	  */
	long lnstrt;		/* Pointer to first segment of line 		  */
	long memptr;		/* Loop index:  pointer into AP transfer buffers  */
	long ncol;		/* Number of columns in cross-product sums array  */
	long ndxout;		/* Pointer into array for correlation output 	  */
	long nrow;		/* Number of rows in cross-product sums array 	  */
	long nsnew[2];
	long nrnew[2];
	long memdim[2];         /* Power-of-2 dimensions for AP arrays 		  */
	long i,j;               /* Loop counters 				  */
	float denom;
	float tempim;
	COMPLEX* cser = new COMPLEX[65536];    /* Complex of search subimage 			  */
	COMPLEX* cref = new COMPLEX[65536];    /* Complex of reference subimage 		  */

	nsnew[0] = (long)npls[0];
	nsnew[1] = (long)npls[1];
	nrnew[0] = (long)nplr[0];
	nrnew[1] = (long)nplr[1];

	/* Zero extend search image to next higher power of 2
	--------------------------------------------------*/
	for(i=0;i<2;i++)
	{
		memdim[i]=64;
		for(;;)
		{
			if (nsnew[i] <= memdim[i]) break;
			memdim[i] *= 2;
		}
	}

	/* Fix for incorrect handling of non-square arrays
	-----------------------------------------------*/
	memdim[0] = memdim[0] > memdim[1] ? memdim[0] : memdim[1];
	memdim[1] = memdim[0];
	for(lnstrt = 0,imgptr = 0,line=0;line<memdim[1];line++)
	{
		if (line < nsnew[1])
		{
			lncont = lnstrt + nsnew[0];
			for(memptr=lnstrt;memptr<lncont;imgptr++,memptr++)
				membfs[memptr]=images[imgptr];
		}
		else lncont = lnstrt;
		lnstrt += memdim[0];
		if (lncont<lnstrt)
			for(memptr=lncont;memptr<lnstrt;memptr++) membfs[memptr] = 0.0;
	}

	/* Make comlex 2-d of search data
	------------------------------*/
	for(memptr=0, i=0; i<memdim[1]; i++)
		for(j=0; j<memdim[0]; j++, memptr++)
		{
			cser[j*memdim[1]+i].re = membfs[memptr];
			cser[j*memdim[1]+i].im = 0.0;
		}

		/* Now zero extend reference image
		-------------------------------*/
		for(lnstrt=0, imgptr=0, line=0; line<memdim[1]; line++)
		{
			if (line < nrnew[1]) 
			{
				lncont = lnstrt + nrnew[0];
				for(memptr=lnstrt;memptr<lncont;imgptr++,memptr++)
					membfr[memptr]=imager[imgptr];
			}
			else lncont = lnstrt;
			lnstrt += memdim[0];
			if (lncont<lnstrt) 
				for(memptr=lncont;memptr<lnstrt;memptr++) membfr[memptr] = 0.0;
		}

		/* Make comlex 2-d of refrence data
		--------------------------------*/
		for(memptr=0, i=0; i<memdim[1]; i++)
			for(j=0; j<memdim[0]; j++, memptr++)
			{
				cref[j*memdim[1]+i].re = membfr[memptr];
				cref[j*memdim[1]+i].im = 0.0;
			}

			/* Take fft of search and refrence data
			------------------------------------*/
			fft2d((float *)cser,memdim[1],memdim[0],1);
			fft2d((float *)cref,memdim[1],memdim[0],1);

			/* Make point by multiplication of search subimage ft with conjogate of 
			refrence subimage ft
			--------------------*/
			for(i=0; i<memdim[0]*memdim[1]; i++)
			{
				tempim = cref[i].re*cser[i].im-cref[i].im*cser[i].re;
				cser[i].re = cref[i].re*cser[i].re+cref[i].im*cser[i].im;
				cser[i].im = tempim;
			}

			/* Take inverse fft of cser
			------------------------*/
			fft2d((float *)cser,memdim[1],memdim[0],-1);

			/* Extract part of correlation array which is valid
			------------------------------------------------*/
			ncol = (long)(nsnew[0] - nrnew[0] + 1.5);
			nrow = (long)(nsnew[1] - nrnew[1] + 1.5);
			denom = (float)(memdim[0]*memdim[1]);
			ndxout = 0;
			for(i=0;i<nrow;i++)
				for(j=0;j<ncol;j++,ndxout++)unormc[ndxout] = cser[j*memdim[1]+i].re / denom;
			delete []membfs;
			delete []cser;
			delete []cref;
}

/****************************************************************************
NAME:				GNORM

PURPOSE:  Convert raw cross-product sums to normalized cross-correlation 
coefficients, while tabulating statistics needed for subsequent 
evaluation

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
1.0	 8/92	D. Steinwand 

REFERENCES:

1.  LAS 4.0 GREYCORR by R. White 8/83 and Y. Jun 7/84
*****************************************************************************/
void gnorm
(
 float *imager,	/* Reference subimage 				     */
 float *images,	/* Search subimage 				     */
 float *nplr,	/* Actual size of reference subimage--samps/lines    */
 float *npls,	/* Actual size of search subimage--samps/lines       */
 float *unormc,	/* Array of raw cross product sums 		     */
 float *ccnorm,	/* Array of norm xcorr coeffs 			     */
 float *pkval,	/* Table of top 32 normalized values 		     */
 long *ipkcol,	/* Table of column numbers for top 32 values 	     */
 long *ipkrow,	/* Table of row numbers for top 32 values 	     */
 float *sums		/* Sum of all normalized values, and sum of squares  */
 )
{
	long iptr[32];		/* Index to values in location arrays 		     */
	long ixcol[32];		/* Col locals of 32 largest values 		     */
	long nsnew[2];		
	long nrnew[2];
	long ixrow[32];		/* Row locations of 32 largest values 		     */
	long i,j,k;		/* Loop counters 				     */
	long ipfree;		/* Index to element freed by deleting 32-nd smallest */
	long ipt;		/* Index to image array 			     */
	long jstart;		/* Pointer to first element in current row 	     */
	long jstop;		/* Pointer to last element in current row 	     */
	long kol;		/* Loop counter 				     */
	long koladd;		/* #search chip col added 			     */
	long kolsub;		/* #search chip col subtracted 			     */
	long line;		/* Loop counter 				     */
	long lnadd;		/* #search chip line added 			     */
	long lnsub;		/* #search chip line subtracted 		     */
	long ncol;		/* #cols in cross-product sum array 		     */
	long nrow;		/* #rows in cross-product sum array 		     */
	long nrtot;		/* Number of pixels in reference image chip 	     */
	float igl;
	float iglnew;
	float iglold;
	float colsqr[256];	/* Sum of squares of search (current overlain area)  */
	float colsum[256];	/* Col sum of search chip (currently overlain area)  */
	float xval[32];		/* Temp storage array 				     */
	float refsum;		/* Sum of all reference-subimage pixel values 	     */
	float refsqr;		/* Sum of squares of reference-subimage pixels 	     */
	float rho;		/* Temp storage for xcorr coeffs 		     */
	float rmean;		/* Mean of reference-subimage pixel values 	     */
	float rsigma;		/* Std Dev about mean of ref chip pixel values 	     */
	float rtotal;		/* Number of pixels in reference subimage 	     */
	float sigma1;		/* Val after 1st iter of Newton's method to app sqrt */
	float sigmas;		/* STD DEV mult by rtotal--inital est for next row   */
	float srchsm;		/* Sum of pixel vals for search subarea 	     */
	float srchsq;		/* Sum of squares of search subarea pixels 	     */
	float temp;		/* Temp var for search subarea STD DEV calc 	     */
	float tempmn;		/* Min val of temp--avoids divide by small values    */

	/* Compute pixel-value statistics for reference subimage
	-----------------------------------------------------*/
	nsnew[0] = (long)(npls[0]+0.5);
	nsnew[1] = (long)(npls[1]+0.5);
	nrnew[0] = (long)(nplr[0]+0.5);
	nrnew[1] = (long)(nplr[1]+0.5);
	refsum = refsqr = 0;
	nrtot = nrnew[0] * nrnew[1];
	for(ipt=0; ipt<nrtot; ipt++)
	{
		igl = imager[ipt];
		refsum += igl;
		refsqr += igl*igl;
	}
	rtotal = (float)nrtot;
	tempmn = 0.01 * rtotal * rtotal;
	rmean = refsum/rtotal;
	rsigma = refsqr/rtotal - rmean*rmean;
	rsigma = rsigma>0.01?rsigma:0.01;
	rsigma = sqrt(rsigma);

	/* Clear sums and sums of squares of normalized correlation values
	---------------------------------------------------------------*/
	sums[0] = sums[1] = 0.0;
	for(k=0; k<32; k++) { xval[k] = -1.0; iptr[k] = k; }
	ncol = nsnew[0] - nrnew[0] + 1;
	nrow = nsnew[1] - nrnew[1] + 1;

	/* Compute normalized cross-corr values for one row of alignemnts at a time
	------------------------------------------------------------------------*/
	/* Get column sums and sums of squares for portion of search subimage overlain 
	by reference in current row of alignments
	-----------------------------------------*/
	for(jstart=0, jstop=ncol, i=0; i< nrow; i++, jstart += ncol, jstop += ncol)
	{
		if (i == 0) 
		{
			for(kol=0; kol<nsnew[0]; kol++) colsum[kol] = colsqr[kol] = 0.0;
			for(ipt=0,line=0; line<nrnew[1]; line++)
				for(kol=0; kol<nsnew[0]; kol++, ipt++)
				{igl=images[ipt];colsum[kol]+=igl;colsqr[kol]+=igl*igl;}
		}
		else
		{
			lnsub = (i - 1) * nsnew[0];
			lnadd = lnsub + nsnew[0]*nrnew[1];
			for(kol=0; kol<nsnew[0]; kol++)
			{
				iglnew = images[lnadd+kol];
				iglold = images[lnsub+kol];
				colsum[kol] = colsum[kol] + iglnew - iglold;
				colsqr[kol] = colsqr[kol] + iglnew*iglnew - iglold*iglold;
			}
		}

		/* Complete comutation of search-subarea pixel statistics
		------------------------------------------------------*/
		for(j=jstart; j<jstop; j++)
		{
			if (j == jstart) 
			{
				srchsm = srchsq = 0.0;
				for(kol=0;kol<nrnew[0];kol++)
				{srchsm+=colsum[kol];srchsq+=colsqr[kol];}
				temp = rtotal*srchsq - srchsm*srchsm;
				temp = tempmn>temp?tempmn:temp;
				sigmas = sqrt(temp);
			}
			else
			{
				kolsub = (j - jstart) - 1;
				koladd = kolsub + nrnew[0];
				srchsm = srchsm + colsum[koladd] - colsum[kolsub];
				srchsq = srchsq + colsqr[koladd] - colsqr[kolsub];
				temp = rtotal*srchsq - srchsm*srchsm;
				temp = tempmn>temp?tempmn:temp;
				sigma1 = 0.5 * (sigmas + temp/sigmas);
				sigmas = 0.5 * (sigma1 + temp/sigma1);
			}

			/* Compute normalized cross-correlation value
			------------------------------------------*/
			rho = (unormc[j] - rmean*srchsm) / (rsigma*sigmas);
			ccnorm[j] = rho;
			sums[0] += rho;
			sums[1] += rho*rho;

			/* Check whether value among top 32
			--------------------------------*/
			if (rho > xval[iptr[31]]) 
			{
				k = 31;
				ipfree = iptr[31];
				for(;;k--)
				{
					if((k<=0)||(rho<=xval[iptr[k-1]]))break;
					iptr[k] = iptr[k-1];
				}
				iptr[k] = ipfree;
				xval[ipfree] = rho;
				ixcol[ipfree] = j - jstart;
				ixrow[ipfree] = i;
			}
		}
	}

	/* Copy peak values and coordinates in correct sequence
	----------------------------------------------------*/
	for(k=0; k<32; k++)
	{
		pkval[k] = xval[iptr[k]];
		ipkcol[k] = ixcol[iptr[k]];
		ipkrow[k] = ixrow[iptr[k]];
	}
}

/****************************************************************************
NAME:				edge_corr

PURPOSE:  Performs edge correlation of a tie point 

VERSION		DATE	AUTHOR
-------		----	------
  1.0	        8/92	D. Steinwand

*****************************************************************************/
#include "immatch.h"

/* Prototypes */
void ecorr
(
    short *imgbns,	/* Binary edge image from search subimage   	    */
    short *imgbnr,	/* Binary edge image from reference image 	    */
    float *npls,	/* Actual size of search subimage:  samps,lines     */
    float *nplr,	/* Actual size of reference subimage: samps,lines   */
    float nshrnk,	/* #lines and columns by which filtering "shrinks" 
			   the subimages; one less than dimension of filter */
    float edenr,	/* Density of edges in reference image 		    */
    float *edens,	/* Density of search-image edges for each relative 
			   alignment of reference image 		    */
    float csmin,	/* Minimum acceptable correlation strength 	    */
    long mfit,		/* Method of fitting surface: 1-Elliptical paraboloid 
						      2-Elliptical Gaussian 
                                                      3-Reciprocal Paraboloid 
                                                      4-Round to nearest int*/
    float ddmx,		/* Maximum allowed diagonal displacement from nominal 
			   tiepoint location to location found by corr 	    */
    float *ioffrq,	/* Requested max horiz and vertical search offsets  */
    float *nomoff,	/* Nominal horiz and vert offsets of upper left 
			   corner of reference chip relative to search chip */
    long *iacrej,	/* Accept/Reject code 				    */
    float *streng,	/* Strength of correlation 		    	    */
    float *bfoffs,	/* Best-fit horiz (pixel) and vert (line) offsets 
			   of correlation peak relative to nominal location */
    float *tlerrs,	/* Estimated horizontal error, vertical error, and h-v 
			   cross term in best-fit offsets 		    */
    float *ddact	/* Actual diagonal displacement from nominal tiepoint 
			   location to location found by correlation 	    */
);
void coinc
(
    short *imgbns,		/* Binary edge image from search subimage */
    short *imgbnr,		/* Binary edge image from reference subimage */
    float *npls,		/* Actual size of search chip: samps,lines */
    float *nplr,		/* Actual size of ref chip: samps,lines */
    float nshrnk,		/* Number of cols in coincidence-count array */
    long *ncol,			/* Number of cols in coincidence-count array */
    long *nrow,			/* Number of rows in coincidence-count array */
    float *unormc		/* Array of unnormalized (raw) counts of edge 
                                   coincidences for each alignment of ref 
                                   image relative to search image */
);
void enorm
(
    long nrtot,		/* Total number of pixels in binary reference image */
    long ncol,		/* Number of columns in coincidence-count array */
    long nrow,		/* Number of rows in coincindence-count array 	*/
    float *unormc,	/* Array of unnormalized (raw) edge coincidences 
			   for each alignment of reference image relative to 
			   search image 				*/
    float edenr,	/* Density of edges in reference image 		*/
    float *edens,	/* Density of search-image edges for each relative 
		           alignment of reference image 		*/
    float *ccnorm,	/* Array of normalized cross-corr coefficients for 
		           each alignment of reference edge image relative to 
			   search edge image 				*/
    float *pkval,	/* Table of top 32 normalized values 		*/
    long *ipkcol,	/* Table of column numbers for top 32 values 	*/
    long *ipkrow,	/* Table of row numbers for top 32 values 	*/
    float *sums		/* Sum of all normalized values, and sum of squares */
);
void extbin
(
    float *imggls,	/* Grey-level subimage array from search image 	*/
    float *imgglr,	/* Grey-level subimage array from reference image */
    float *npls,	/* Actual size of search chip 			*/
    float *nplr,	/* Actual size of reference chip 		*/
    long *nscale,	/* #bits to scale (right shift) edginess filter */
    float efract,	/* Fraction of pixels to be classified as edges */
    float *nshrnk,	/* #lines/samps by which filtering "shrinks" chips */
    short *imgbns,	/* Binary edge image from search subimage 	*/
    short *imgbnr,	/* Binary edge image from reference image 	*/
    float *edens,	/* Density of search edges for rel align of ref */
    float *edenr,	/* Density of edges in reference image 		*/
    float threshold	/* Cloud cover threshold value			*/
);
void edgfil
(
    float *image,	/* Grey-level image 				*/
    float npixel,	/* Number of pixels per image line 		*/
    float nline,	/* Number of lines in image 			*/
    long nshift,	/* # bits to right-shift to get edge value 	*/
    short *iedge,	/* Array of edge values 			*/
    float *nshrnk,	/* Num of lines/samps that filtering "shrinks" chips */
    long *ihist,	/* Histogram of edginess values 		*/
    float threshold 	/* cloud cover threshold value			*/
);
void edge
(
    long *ihist,	/* Histogram of edginess values 		*/
    float ntotal,	/* Total number of values in histogram 		*/
    float efract,	/* Fraction of pixels to be classified as edges */
    long *ithrsh,	/* Threshold value 				*/
    float *edgden	/* Density of edges in image 			*/
);
void flgedg
(
    short *iedge,		/* Array of edge values 		*/
    float npixel,		/* Number of samples 			*/
    float nline,		/* Number of lines 			*/
    long ithrsh,		/* Edge threshold value 		*/
    short *ibin		        /* Array of edginess values 		*/
);
void dense
(
    short *imgbns,   /* Binary edge image from search subimage 	            */
    float *npls,     /* Size of search chip--#samps, #lines 	            */
    float *nplr,     /* Size of reference chip--#samps, #lines 	            */ 
    float nshrnk,    /* Number of lines/samps which filtering shrinks chips */
    float *edens     /* Density of search edges per rel. alignment of ref   */
);
long shift
(
    long a1,
    long a2
);


void edge_corr
(
    struct TPLDATA *tpl,	/* Tie point location data record 	*/
    struct CORRPAR *corr,	/* Correlation parameters 		*/
    float *ref,			/* Reference subimage 			*/
    float *srch,		/* Search subimage 			*/
    long *nominal,		/* Nominal horizontal, vertical offsets	*/
    long *nscale,		/* Scale parameter 			*/
    short *bsrch,		/* Binary edge search subimage 		*/
    short *bref,		/* Binary edge reference subimage 	*/
    float *edens,		/* Array of edge densities 		*/
    float threshold		/* Cloud cover threshold value		*/
)
{
float edenr;			/* Density of edges in reference subimage */
float shrink;			/* # of lines & samps that filtering shrinks */
float efract;			/* Fraction of pixels classified as edges    */
float mincorr;			/* Minimum acceptable correlation strength   */
float maxdis;			/* Maximum displacement from nominal allowed */
float disp=0.0;			/* Displacement from nominal coordinate */
float est_err[3];		/* Estimated error of fit 		*/
float best_fit[2];		/* Best fit offsets of correlation peak */
float npls[2];			/* Size of search subimage 		*/
float nplr[2];			/* Size of reference subimage 		*/
float ioffrq[2];		/* Requested max horiz & vert search offsets */
float nomoff[2];		/* Nominal horizontal & vertical offsets */
float strength;			/* Strength of correlation 		*/

/* Assign values of C structure to individual variables
  ----------------------------------------------------*/
 npls[0] = (float)tpl->sea_size[0]; //samples
 npls[1] = (float)tpl->sea_size[1]; //lines
 nplr[0] = (float)tpl->ref_size[0]; //samples
 nplr[1] = (float)tpl->ref_size[1];  //lines
mincorr = (float)corr->mincorr;
maxdis = (float)corr->maxdiff;
 ioffrq[0] = (float)tpl->offsets[0]; //horizontal
 ioffrq[1] = (float)tpl->offsets[1]; //vertical
 nomoff[0] = (float)nominal[0]; //horizontal
 nomoff[1] = (float)nominal[1]; //vertical
efract = (float)corr->edgeval;

/* Extract binary edge from subimage
  ---------------------------------*/
extbin(srch, ref, npls, nplr, nscale, efract, &shrink, bsrch, bref, 
       edens, &edenr, threshold);

/* Perform correlation
  -------------------*/
ecorr(bsrch, bref, npls, nplr, shrink, edenr, edens, mincorr, 
      corr->fitmeth, maxdis, ioffrq, nomoff, &tpl->active, &strength, 
      best_fit, est_err, &disp);

tpl->displacement = (double)disp;
tpl->strength = (double)strength;

if (tpl->active == 1)
   {
   tpl->sea_coord[0] = tpl->nominal[0] + best_fit[1] +
                       tpl->ref_coord[0] - tpl->ref_coord[0];
   tpl->sea_coord[1] = tpl->nominal[1] + best_fit[0] +
                        tpl->ref_coord[1] - tpl->ref_coord[1];
   tpl->rms_error[0] = est_err[0];
   tpl->rms_error[1] = est_err[1];
   }
else
   {
   tpl->sea_coord[0] = tpl->nominal[0];
   tpl->sea_coord[1] = tpl->nominal[1];
   tpl->rms_error[0] = 0.0;
   tpl->rms_error[1] = 0.0;
   }
}

/****************************************************************************
NAME:				ECORR

PURPOSE:  Correlate the edge images and evaluate the results

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
  1.0	 8/92	D. Steinwand 

REFERENCES:

1.  LAS 4.0 EDGECORR by R. White 6/83
*****************************************************************************/
void ecorr
(
    short *imgbns,	/* Binary edge image from search subimage   	    */
    short *imgbnr,	/* Binary edge image from reference image 	    */
    float *npls,	/* Actual size of search subimage:  samps,lines     */
    float *nplr,	/* Actual size of reference subimage: samps,lines   */
    float nshrnk,	/* #lines and columns by which filtering "shrinks" 
			   the subimages; one less than dimension of filter */
    float edenr,	/* Density of edges in reference image 		    */
    float *edens,	/* Density of search-image edges for each relative 
			   alignment of reference image 		    */
    float csmin,	/* Minimum acceptable correlation strength 	    */
    long mfit,		/* Method of fitting surface: 1-Elliptical paraboloid 
						      2-Elliptical Gaussian 
                                                      3-Reciprocal Paraboloid 
                                                      4-Round to nearest int*/
    float ddmx,		/* Maximum allowed diagonal displacement from nominal 
			   tiepoint location to location found by corr 	    */
    float *ioffrq,	/* Requested max horiz and vertical search offsets  */
    float *nomoff,	/* Nominal horiz and vert offsets of upper left 
			   corner of reference chip relative to search chip */
    long *iacrej,	/* Accept/Reject code 				    */
    float *streng,	/* Strength of correlation 		    	    */
    float *bfoffs,	/* Best-fit horiz (pixel) and vert (line) offsets 
			   of correlation peak relative to nominal location */
    float *tlerrs,	/* Estimated horizontal error, vertical error, and h-v 
			   cross term in best-fit offsets 		    */
    float *ddact	/* Actual diagonal displacement from nominal tiepoint 
			   location to location found by correlation 	    */
)
{
long ipkcol[32];	/* Col number for each of top 32 correlation values */
long ipkrow[32];	/* Row number for each of top 32 correlation values */
long ncol;		/* Number of columns of search alignments 	    */
long nrow;		/* Number of rows of search alignments 		    */
long nrtot;		/* Total number of pixels in binary reference image */
float ccnorm[16641];	/* Normalized xcorr coef for each search alignment  */
float cpval[25];	/* 5 by 5 array of xcorr values, in std dev 	    */
float pkoffs[2];	/* Fractional horiz and vert offsets of best-fit 
			   peak location from nearest integer location 	    */
float pkval[32];	/* Largest 32 values of normalized xcorr coefs 	    */
float sums[2];		/* Sum and sum of squares of all xcorr values 	    */
float unormc[16641];	/* Unnormalized edge-coincidence count 		    */

/* Compute raw edge-coincidence counts
  -----------------------------------*/
coinc(imgbns, imgbnr, npls, nplr, nshrnk, &ncol, &nrow, unormc);

/* Compute normalized cross-correlation values and compile statistics
  ------------------------------------------------------------------*/
nrtot = (long)(((nplr[0] - nshrnk) * (nplr[1] - nshrnk)) + 0.5);
enorm(nrtot,ncol,nrow,unormc,edenr,edens,ccnorm,pkval,ipkcol,ipkrow,sums);

/* Evaluate strength of correlation peak
  -------------------------------------*/
eval(ncol,nrow,ccnorm,pkval,ipkcol,ipkrow,sums,csmin,streng,iacrej,cpval);

/* Determine offsets of peak relative to nominal location
  ------------------------------------------------------*/
if (*iacrej==1)
   {
   if (mfit!=4)
      {
      fitreg(cpval, mfit, pkoffs, tlerrs);
      bfoffs[0] = (float)ipkcol[0] - nomoff[0] + pkoffs[0];
      bfoffs[1] = (float)ipkrow[0] - nomoff[1] + pkoffs[1];
      }
   else
      {
      bfoffs[0] = (float)ipkcol[0] - nomoff[0];
      bfoffs[1] = (float)ipkrow[0] - nomoff[1];
      tlerrs[0] = 0.5;
      tlerrs[1] = 0.5;
      }

/* Determine diagonal displacement from nominal and check against maximum 
   acceptable value
  ----------------*/
    *ddact = sqrt(bfoffs[0]*bfoffs[0] + bfoffs[1]*bfoffs[1]);
    if (ddmx<=0.0)ddmx=ioffrq[0]<ioffrq[1]?ioffrq[0]-2.0 :ioffrq[1]-2.0;
    if (*ddact>ddmx) *iacrej = 5;
    }
}

/****************************************************************************
NAME:				COINC

PURPOSE:  Compute the unnormalized (raw) number of edge coincidences between 
          the reference and search images for every combination of horizontal 
          and vertical offsets of the reference realtive to the search image

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
  1.0	 8/92	D. Steinwand 

REFERENCES:

1. LAS 4.0 EDGECORR by R. White & G. Neal 6/83
*****************************************************************************/
void coinc
(
    short *imgbns,		/* Binary edge image from search subimage */
    short *imgbnr,		/* Binary edge image from reference subimage */
    float *npls,		/* Actual size of search chip: samps,lines */
    float *nplr,		/* Actual size of ref chip: samps,lines */
    float nshrnk,		/* Number of cols in coincidence-count array */
    long *ncol,			/* Number of cols in coincidence-count array */
    long *nrow,			/* Number of rows in coincidence-count array */
    float *unormc		/* Array of unnormalized (raw) counts of edge 
                                   coincidences for each alignment of ref 
                                   image relative to search image */
)
{
long membfr[65536];
long membfs[65536];
long imgptr;			/* Pointer into binary edge image arrays */
long line;			/* Loop index:  current buffer line */
long lncont;			/* Pointer to start of next segment of line */
long lnstrt;			/* Pointer to first segment of line */
long memptr;			/* Loop index */
long ndxout;			/* Pointer into array for correlation output */
long nlrbin;			/* Number of lines in binary reference image */
long nlsbin;			/* Number of lines in binary search image */
long nprbin;			/* # of pixels per line in binary ref image */
long npsbin;			/* Number of pixels per line in search image */
long memdim[2];			/* Power-of-2 dimensions for AP arrays */
long nplsbn[2];			/* Dimensions of binary search image */
long i,j;			/* Loop counters */
float denom;
float tempim;
COMPLEX cser[65536];		/* Complex of search subimage */
COMPLEX cref[65536];		/* Complex of reference subimage */

/* Zero extend binary search image to next higher power of 2
  ---------------------------------------------------------*/
nplsbn[0]=npsbin = (long)((npls[0] - nshrnk) + 0.5);
nplsbn[1]=nlsbin = (long)((npls[1] - nshrnk) + 0.5);
for(i=0;i<2;i++)
   {
   memdim[i]=64;
   for(;;)
      {
      if (nplsbn[i] <= memdim[i]) break;
      memdim[i] *= 2;
      }
   }

/* Fix for incorrect handling of non-square arrays
  -----------------------------------------------*/
memdim[0] = memdim[0] > memdim[1] ? memdim[0] : memdim[1];
memdim[1] = memdim[0];
for (lnstrt = 0,imgptr = 0,line = 0; line < memdim[1]; line++)
   {
   if (line < nlsbin)
      {
      lncont = lnstrt + npsbin;
      for (memptr = lnstrt; memptr < lncont; imgptr++,memptr++)
           membfs[memptr] = imgbns[imgptr];
      }
   else 
      lncont = lnstrt;
   lnstrt += memdim[0];
   if (lncont < lnstrt)
      for (memptr = lncont; memptr < lnstrt; memptr++) membfs[memptr] = 0;
   }

/* Make comlex 2-d of search data
  ------------------------------*/
for(memptr=0, i=0; i<memdim[1]; i++)
   for(j=0; j<memdim[0]; j++, memptr++)
       {
       cser[j*memdim[1]+i].re = (float)membfs[memptr];
       cser[j*memdim[1]+i].im = 0.0;
       }

/* Now zero extend binary reference image
  --------------------------------------*/
nprbin = (long)((nplr[0] - nshrnk) + 0.5);
nlrbin = (long)((nplr[1] - nshrnk) + 0.5);
for (lnstrt=0, imgptr=0, line=0; line<memdim[1]; line++)
   {
   if (line < nlrbin) 
      {
      lncont = lnstrt + nprbin;
      for (memptr = lnstrt; memptr < lncont; imgptr++,memptr++)
	   membfr[memptr] = imgbnr[imgptr];
      }
   else 
      lncont = lnstrt;
   lnstrt += memdim[0];
   if (lncont < lnstrt) 
      for (memptr = lncont; memptr < lnstrt; memptr++) membfr[memptr] = 0;
   }

/* Make comlex 2-d of refrence data
  --------------------------------*/
for(memptr=0, i=0; i<memdim[1]; i++)
   for(j=0; j<memdim[0]; j++, memptr++)
      {
      cref[j*memdim[1]+i].re = (float)membfr[memptr];
      cref[j*memdim[1]+i].im = 0.0;
      }

/* Take fft of search and refrence data
  ------------------------------------*/
fft2d((float *)cser,memdim[1],memdim[0],1);
fft2d((float *)cref,memdim[1],memdim[0],1);

/* Make point by multiplication of search chip ft with conjogate of refrence 
   chip ft
  -------*/
for(i=0; i<memdim[0]*memdim[1]; i++)
   {
   tempim = cref[i].re*cser[i].im-cref[i].im*cser[i].re;
   cser[i].re = cref[i].re*cser[i].re+cref[i].im*cser[i].im;
   cser[i].im = tempim;
   }

/* Take inverse fft of cser
  ------------------------*/
fft2d((float *)cser,memdim[1],memdim[0],-1);

/* Extract part of correlation array which is valid
  ------------------------------------------------*/
*ncol = (long)(npls[0] - nplr[0] + 1.5);
*nrow = (long)(npls[1] - nplr[1] + 1.5);
denom = (float)(memdim[0]*memdim[1]);
ndxout = 0;
for(i=0;i<*nrow;i++)
   for(j=0;j<*ncol;j++,ndxout++)unormc[ndxout]=cser[j*memdim[1]+i].re/denom;
}

/****************************************************************************
NAME:				ENORM

PURPOSE:  Convert raw edge-coincidence counts to normalized cross-correlation 
	  coefficients, while tabulating statistics needed for subsequent 
          evaluation

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
  1.0	 8/92	D. Steinwand 

REFERENCES:

1.  LAS 4.0 EDGECORR by R. White 6/83
*****************************************************************************/
void enorm
(
    long nrtot,		/* Total number of pixels in binary reference image */
    long ncol,		/* Number of columns in coincidence-count array */
    long nrow,		/* Number of rows in coincindence-count array 	*/
    float *unormc,	/* Array of unnormalized (raw) edge coincidences 
			   for each alignment of reference image relative to 
			   search image 				*/
    float edenr,	/* Density of edges in reference image 		*/
    float *edens,	/* Density of search-image edges for each relative 
		           alignment of reference image 		*/
    float *ccnorm,	/* Array of normalized cross-corr coefficients for 
		           each alignment of reference edge image relative to 
			   search edge image 				*/
    float *pkval,	/* Table of top 32 normalized values 		*/
    long *ipkcol,	/* Table of column numbers for top 32 values 	*/
    long *ipkrow,	/* Table of row numbers for top 32 values 	*/
    float *sums		/* Sum of all normalized values, and sum of squares */
)
{
long iptr[32];		/* Pointers to value and location arrays 	*/
long ixcol[32];		/* Col locations of 32 largest values--seq by IPTR */
long ixrow[32];		/* Row locations of 32 largest values 		*/
long i;			/* Loop index:  pointer to current row of alignments */
long ipfree;		/* Index to elements in value and loc arrays which are 
			   freed by deleting 32-nd smallest 		*/
long j;			/* Loop index to element in cur row of alignments */
long jstart;		/* Pointer to first element in current row 	*/
long jstop;		/* Pointer to last element in current row 	*/
long k;			/* Loop index:  pointer into table of peak values */
float xval[32];		/* Temp storage for largest values--seq in IPTR */
float rho;
float temp;		
float a;		/* Coefficient ... 				*/
float redget;		/* Total edge pixels in reference image 	*/
float sigma0;		/* 1st approx to std dev of search chip overlain by 
			   reference image in current alignment 	*/
float sigma1;		/* Second approximation to search-subarea std dev */

/* Clear sums and compute constants
  --------------------------------*/
for(sums[0]=sums[1]=0.0,k=0;k<32;k++)
   { xval[k] = -1.0; iptr[k] = k; }
redget = (float)nrtot*edenr;
a = 1.0/(nrtot*sqrt(edenr*(1.0 - edenr)));
sigma0 = sqrt(0.67*edenr*(1.0 - 0.67*edenr));

/* Compute normalized coincidence values
  -------------------------------------*/
for( jstart = 0, jstop = ncol, i=0; i<nrow; i++)
   {
   for(j=jstart; j<jstop; j++)
      {
      temp = edens[j]*(1.0 - edens[j]);
      sigma1 = (temp + sigma0*sigma0)/(2.0*sigma0);
      rho = (a*2.0*sigma1/(temp+sigma1*sigma1))*(unormc[j]-redget*edens[j]);
      ccnorm[j] = rho;
      sums[0] += rho;
      sums[1] += rho*rho;

/* Check whether value among top 32
  --------------------------------*/
      if (rho>xval[iptr[31]])
         {
	 k = 31;
	 ipfree = iptr[31];
	 for(;;)
	    {
	    if((k<=0)||(rho<=xval[iptr[k-1]])) break;
	    iptr[k]=iptr[k-1];
	    k--;
	    }

         iptr[k] = ipfree;
         xval[ipfree] = rho;
	 ixcol[ipfree] = j - jstart;
	 ixrow[ipfree] = i;
         }
      }
   jstart += ncol;
   jstop += ncol;
   }

/* Copy peak values and coordinates in correct sequence
  ----------------------------------------------------*/
for(k=0; k<32; k++)
   {
   pkval[k] = xval[iptr[k]];
   ipkcol[k] = ixcol[iptr[k]];
   ipkrow[k] = ixrow[iptr[k]];
   }
}

/****************************************************************************
NAME:				EXTBIN

PURPOSE:  Extract binary edge images from the grey-level search and reference 
	  subimages

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
  1.0	 8/92	D. Steinwand 

REFERENCES:

1.0  LAS 4.0 EDGECORR by R. White 6/83 and S. Kondal 7/84
*****************************************************************************/
void extbin
(
    float *imggls,	/* Grey-level subimage array from search image 	*/
    float *imgglr,	/* Grey-level subimage array from reference image */
    float *npls,	/* Actual size of search chip 			*/
    float *nplr,	/* Actual size of reference chip 		*/
    long *nscale,	/* #bits to scale (right shift) edginess filter */
    float efract,	/* Fraction of pixels to be classified as edges */
    float *nshrnk,	/* #lines/samps by which filtering "shrinks" chips */
    short *imgbns,	/* Binary edge image from search subimage 	*/
    short *imgbnr,	/* Binary edge image from reference image 	*/
    float *edens,	/* Density of search edges for rel align of ref */
    float *edenr,	/* Density of edges in reference image 		*/
    float threshold	/* Cloud cover threshold value			*/
)
{
short iedge[65536];	/* Edginess values produced by filter 		*/
long ihist[32768];	/* Histogram of edginess values 		*/
long ithrsh;		/* Threshold at which a pixel is classified as edge */

/* Filter search subimage
  -----------------------*/
edgfil(imggls,npls[0],npls[1],nscale[0],iedge,nshrnk,ihist,threshold);
edge(ihist, ((npls[0]-*nshrnk)*(npls[1]-*nshrnk)), efract, &ithrsh, &edens[0]);
flgedg(iedge, npls[0]-*nshrnk, npls[1]-*nshrnk, ithrsh, imgbns);

/* Filter reference subimage
  --------------------------*/
edgfil(imgglr,nplr[0],nplr[1],nscale[1],iedge,nshrnk,ihist,threshold);
edge(ihist, ((nplr[0]-*nshrnk)*(nplr[1]-*nshrnk)), efract, &ithrsh, edenr);
flgedg(iedge, nplr[0]-*nshrnk, nplr[1]-*nshrnk, ithrsh, imgbnr);

/* Compute search-subarea edge densities for each alignment
  ---------------------------------------------------------*/
dense(imgbns, npls, nplr, *nshrnk, edens);
}

/****************************************************************************
NAME:				EDGFIL

PURPOSE:  Applies edge filter to grey-level image array and compile histogram 
          of edge values

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
  1.0	 8/92	D. Steinwand 

REFERENCES:

1.  LAS 4.0 EDGECORR by R. White 6/83 and S. Kondal 7/84
*****************************************************************************/
void edgfil
(
    float *image,	/* Grey-level image 				*/
    float npixel,	/* Number of pixels per image line 		*/
    float nline,	/* Number of lines in image 			*/
    long nshift,	/* # bits to right-shift to get edge value 	*/
    short *iedge,	/* Array of edge values 			*/
    float *nshrnk,	/* Num of lines/samps that filtering "shrinks" chips */
    long *ihist,	/* Histogram of edginess values 		*/
    float threshold 	/* cloud cover threshold value			*/
)
{
long i,j;		/* Loop counters 				*/
long iedgpt;		/* Index to next location in edginess array 	*/
long ifilt;		/* Filter output for one location 		*/
long imgpt;		/* Index to start of next image-array line 	*/
long jpt;		/* Index to UL pixel for computing 1 filtered value */
long lshift;		/* Left shift count (negative) 			*/
long nl;		/* Number of lines in edge array 		*/
long np;		/* Number of samples in edge array 		*/
long npix2;		/* Twice number of samples 			*/
long nround;		/* Rounding term to add before right shift 	*/
long pixnew;

/* Initialize array dimensions and histogram
  ------------------------------------------*/
*nshrnk = 2.0;
np = (long)((npixel - *nshrnk)+0.5);
nl = (long)((nline - *nshrnk)+0.5);
npix2 = (long)(2.0*npixel);
pixnew=(long)(npixel);

for(i=0;i<32768;i++)ihist[i]=0;
imgpt = 0;
iedgpt = 0;

/* Compute edginess values without scaling
  ---------------------------------------*/
if (nshift == 0) for(i=0;i<nl;i++)
   {
   jpt = imgpt;
   for(j=0;j<np;j++)
      {
      if ((image[jpt+npix2+2] > threshold) || (image[jpt] > threshold) ||
          (image[jpt+npix2+1] > threshold) || (image[jpt+1] > threshold) ||
	  (image[jpt+npix2] > threshold) || (image[jpt+2] > threshold) ||
          (image[jpt+pixnew+2] > threshold) || (image[jpt+pixnew] > threshold))
          ifilt = 0;
      else
          ifilt = (long)(fabs(image[jpt+npix2+2] - image[jpt]) 
            + fabs(image[jpt+npix2+1] - image[jpt+1])
	    + fabs(image[jpt+npix2] - image[jpt+2])
            + fabs(image[jpt+pixnew+2] - image[jpt+pixnew]));
      iedge[iedgpt] = (short)ifilt;
      ihist[ifilt]++; jpt++; iedgpt++;
      }
   imgpt += pixnew;
   }

/* Compute edginess with scaling
  ------------------------------*/
else
   {
   nround = (long)pow(2.0, (double)(nshift - 1));
   lshift = nshift;
   for(i=0;i<nl;i++)
      {
      jpt = imgpt;
      for(j=0;j<np;j++)
         {
         if ((image[jpt+npix2+2] > threshold) || (image[jpt] > threshold) ||
           (image[jpt+npix2+1] > threshold) || (image[jpt+1] > threshold) ||
           (image[jpt+npix2] > threshold) || (image[jpt+2] > threshold) ||
           (image[jpt+pixnew+2] > threshold) || (image[jpt+pixnew] > threshold))
           ifilt = 0; 
         else 
	   ifilt = (long)(fabs(image[jpt+npix2+2] - image[jpt])
               + fabs(image[jpt+npix2+1] - image[jpt+1])
               + fabs(image[jpt+npix2] - image[jpt+2])
               + fabs(image[jpt+pixnew+2] - image[jpt+pixnew]));
         ifilt = shift(ifilt + nround, lshift);
         if (ifilt > 32769)
            {
	      printf("Too many bins: correlate-bins!\n");
	      exit(-1);
            }
         iedge[iedgpt] = (short)ifilt;
         ihist[ifilt]++; jpt++; iedgpt++;
         } 
      imgpt += pixnew;
      } 
   }
return;
}

/****************************************************************************
NAME:				EDGE

PURPOSE:  Determine the edginess value which will yield a percentage of edge 
          pixels not more than, but as close as possible to, the user
          specified edge fraction

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
  1.0	 8/92	D. Steinwand 

REFERENCES:

1.  LAS 4.0 EDGECORR by R. White 6/83 and S. Kondal 7/84
*****************************************************************************/
void edge
(
    long *ihist,	/* Histogram of edginess values 		*/
    float ntotal,	/* Total number of values in histogram 		*/
    float efract,	/* Fraction of pixels to be classified as edges */
    long *ithrsh,	/* Threshold value 				*/
    float *edgden	/* Density of edges in image 			*/
)
{
long kbin;		/* Current histogram bin 			*/
long mincnt;		/* Target minimum number of non-edge pixels 	*/
long nonedg;		/* Actual number of non-edge pixels 		*/
float edgcnt;		/* Number of pixels with edges !< threshold 	*/

/* Compute minimum number of non-edge pixels
  ------------------------------------------*/
mincnt = (long)(ntotal*(1.0 - efract));

/* Find threshold histogram bin
  -----------------------------*/
nonedg = 0;
kbin = 0;

for(;;)
   {
   if (nonedg >= mincnt) break;
   nonedg += ihist[kbin];
   kbin++;
   }
if ((nonedg - ihist[kbin-1]/2) >= mincnt) 
   {
   kbin--;
   nonedg -= ihist[kbin];
   }

/* Compute values to be returned to caller
   ---------------------------------------*/
*ithrsh = kbin;
edgcnt = ntotal - (float)nonedg;
*edgden = edgcnt/ntotal;
}

/****************************************************************************
NAME:				FLGEDG

PURPOSE:  Classify each pixel in edginess array as edge or non-edge

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
  1.0	 8/92	D. Steinwand 

REFERENCES:

1.  LAS 4.0 EDGECORR by R. White 6/83 and S. KONDAL 7/84
*****************************************************************************/
void flgedg
(
    short *iedge,		/* Array of edge values 		*/
    float npixel,		/* Number of samples 			*/
    float nline,		/* Number of lines 			*/
    long ithrsh,		/* Edge threshold value 		*/
    short *ibin		        /* Array of edginess values 		*/
)
{
long i;			/* Loop counter 			*/
long stop;		/* Number of pixels to check 		*/

/* Compare one pixel at a time with threshold
  -------------------------------------------*/
stop = (long)(nline*npixel+0.5);
for (i = 0; i < stop; i++)
   if (iedge[i] >= ithrsh) 
      ibin[i] = 1;
   else 
      ibin[i] = 0;
}

/****************************************************************************
NAME:				DENSE

PURPOSE:  Computes the density of edge images of the search image chip 
          overlayed by the reference image chip for each combination of 
          translational offsets

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
  1.0	 8/92	D. Steinwand 

REFERENCES:

 1.  LAS 4.0 EDGECORR by R. White 6/83 and S. KONDAL 7/84
******************************************************************************/
void dense
(
    short *imgbns,   /* Binary edge image from search subimage 	            */
    float *npls,     /* Size of search chip--#samps, #lines 	            */
    float *nplr,     /* Size of reference chip--#samps, #lines 	            */ 
    float nshrnk,    /* Number of lines/samps which filtering shrinks chips */
    float *edens     /* Density of search edges per rel. alignment of ref   */
)
{
long imax;		/* Max index of bin chip that contributes to col sum */
long index;		/* Loop index into binary search chip 		*/
long iroff;		/* Index offset for tops of columns 		*/
long kcol;		/* Loop index--current column of search image 	*/
long khalgn;		/* Loop index--current horizontal search alignment */
long kvalgn;		/* Loop index--current vertical search alignment */
long lroff;		/* Index offset for bottoms of columns 		*/
long ncolr;		/* Number of columns in binary reference image 	*/
long ncols;		/* Number of columns in binary search image 	*/
long ndxden;		/* Index into edge-density array 		*/
long nedge;		/* Total # of edge pixels for particular alignment */
long nhalgn;		/* Number of horizontal search alignments 	*/
long nrowr;		/* Number of rows in binary reference image 	*/
long nrows;		/* Number of rows in binary search image 	*/
long nvalgn;		/* Number of vertical search alignments 	*/
long kolsum[256];	/* Edge pixel sums in partial cols of binary chip */
float totrpx;		/* Total pixels in binary reference image 	*/

/* Compute sizes of arrays
  ------------------------*/
ncolr = (long)((nplr[0] - nshrnk)+0.5);
nrowr = (long)((nplr[1] - nshrnk)+0.5);
ncols = (long)((npls[0] - nshrnk)+0.5);
nrows = (long)((npls[1] - nshrnk)+0.5);
totrpx = (float)(ncolr*nrowr);
nhalgn = ncols - ncolr + 1;
nvalgn = nrows - nrowr + 1;

/* Clear column sums
  ------------------*/
for(kcol=0;kcol<ncols;kcol++) kolsum[kcol] = 0;

imax = ncols*nrowr;
iroff = -(ncols);
lroff = iroff + imax;
ndxden = 0;

for(kvalgn=0;kvalgn<nvalgn;kvalgn++)
   {

/* Get number of edge pixels in each partial column of search image
  -----------------------------------------------------------------*/
   for(kcol=0;kcol<ncols;kcol++)
      {
      if (kvalgn == 0) 
         for (index = kcol; index < imax ; index += ncols) 
	    kolsum[kcol] += imgbns[index];
      else 
	 kolsum[kcol] = kolsum[kcol] - imgbns[iroff+kcol] + imgbns[lroff+kcol];
      }

   iroff += ncols;
   lroff += ncols;

/* Add up column sums for each alignment and compute density
  ----------------------------------------------------------*/
   nedge = 0;
   for(khalgn=0;khalgn<nhalgn;khalgn++)
      {
      if (khalgn == 0) for(kcol=0;kcol<ncolr;kcol++) nedge += kolsum[kcol];
      else nedge = nedge - kolsum[khalgn-1] + kolsum[khalgn+ncolr-1];
      edens[ndxden] = (float)nedge/totrpx;
      ndxden++; 
      }
   }
return;
}


/* Shift performs a logical bit shift of a value input
  ---------------------------------------------------*/
long shift
(
    long a1,
    long a2
)
{
  return(a1>>a2);
}

// This is the main DLL file.

// #include <fstream>
#include "immatch.h"
#include "ImageMatchCpp.h"
#include <sstream>

namespace ImageMatchCpp
{
	using namespace std;

	TPLDATA& ImageMatch::matchGrey(float* ref_chip, long ref_size[2],
		float* srch_chip, long srch_size[2], long offsets[2], long nominal[2])
	{
		TPLDATA tpl_data;
		CORRPAR corr; /* Correlation parameters 		*/
		corr.mincorr = mincorr_; // correlation threshold
		corr.maxdiff = maxdiff_; // maximum difference between nominal and refined coordinates in pixels
		corr.edgeval = edgeval_; // edge threshold value
		corr.fitmeth = peakmethod_; // peak fitting method
		int i, j;
		float maxval, minval;
		// string::size_type idx, begIdx, endIdx;
		tpl_data.ref_size[0] = ref_size[0];  //samples
		tpl_data.ref_size[1] = ref_size[1];  //lines
		tpl_data.sea_size[0] = srch_size[0];  //samples
		tpl_data.sea_size[1] = srch_size[1];  //
		tpl_data.offsets[0] = offsets[0];  //horizontal
		tpl_data.offsets[1] = offsets[1]; //vertical
		tpl_data.nominal[0] = nominal[0]; //horizontal
		tpl_data.nominal[1] = nominal[1]; //vertical

		grey_corr(&tpl_data, &corr, ref_chip, srch_chip, offsets);
		return tpl_data;
	}

	void ImageMatch::greySimpleMatch(const std::vector<std::vector<unsigned char>> &refImg,
										const std::vector<std::vector<unsigned char>> &srcImg,
										LineSeg& outLine,
										const std::vector<int>& row,
										const std::vector<int>& col)
	{
		// Implementation of greySimpleMatch
		float *ref_chip;  /* Reference chip buffer 		*/
		float *srch_chip; /* Search chip buffer 			*/
		long refstart[2];
		long srcstart[2] = {0l, 0l};   /*start line and sample of search chip in the full search image*/
		long chip_size[2];
		chip_size[0] = chipwidth_;	// in samples
		chip_size[1] = chipheight_; // in lines
		long offsets[2]; //search offset in addition to the chip size coverage in the search image (e.g. if chip size is 64*64, and offsets are 16*16, then the search image size is 96*96)
		offsets[0] = hoffset_; //horizontal
		offsets[1] = voffset_; //vertical
		srch_chip = new float[(chip_size[0] + 2 * offsets[0]) * (chip_size[1] + 2 * offsets[1])];
		ref_chip = new float[(chip_size[0] * chip_size[1])];
		double src_geocoord[2];		   /* Geographic coordinates (x,y) of the tie point in search image */
		double ref_geocoord[2];		   /* Geographic coordinates (x,y) of the tie point in reference image */
		long ref_coord[2];		   /* Image location of the tie point in line, sample in the reference image */
		ref_coord[0] = row[0]; //line
		ref_coord[1] = col[0]; //sample
		long src_coord[2];       /* Refined search image location of the tie point in line, sample in the full search image */
		
		src_coord[0] = row[1]; //row
		src_coord[1] = col[1]; //sample
		long sea_size[2];      /* Size of the search subimage in line, sample */
		sea_size[0] = chip_size[0] + 2 * offsets[0];
		sea_size[1] = chip_size[1] + 2 * offsets[1];
		


		int status = extract_buffer(refImg, ref_coord, chip_size, REF_MIN, REF_MAX, ref_chip, refstart);
		if (status != E_SUCC)
		{
#ifdef DEBUG
			cout << "Error in extracting reference chip, error code: " << status << endl;
#endif
			error_code_ = status;
			delete[] ref_chip;
			delete[] srch_chip;
			return;
		}


		status = extract_buffer(srcImg, src_coord, sea_size, SRCH_MIN, SRCH_MAX, srch_chip, srcstart);
		if (status != E_SUCC)
		{
#ifdef DEBUG
			cout << "Error in extracting search chip, error code: " << status << endl;
#endif
			error_code_ = status;
			delete[] ref_chip;
			delete[] srch_chip;
			return;
		}


		//setting the geographical cooordinates of the class based on the class variables



		



		TPLDATA tpl_data = matchGrey(ref_chip, chip_size, srch_chip, sea_size, offsets, src_coord);
		//debugging for the y geographic coordinate calculation

		src_geocoord[0] = srch_xll_ + srch_cellsize_ * tpl_data.sea_coord[1];
		double srch_uly = srch_yll_ + (srch_nr_ - 1) * srch_cellsize_; //compute the upper left y coordinate of the source image
		src_geocoord[1] = srch_uly - srch_cellsize_ * tpl_data.sea_coord[0];
		ref_geocoord[0] = ref_xll_ + ref_cellsize_ * ref_coord[1];
		double ref_uly = ref_yll_ + (ref_nr_ - 1) * ref_cellsize_; //compute the upper left y coordinate of the reference image
		ref_geocoord[1] = ref_uly - ref_cellsize_ * ref_coord[0];
		outLine.SetCoors(ref_geocoord[0], ref_geocoord[1],
						 src_geocoord[0], src_geocoord[1]);
		outLine.strength_ = tpl_data.strength;
		outLine.displacement_ = tpl_data.displacement;
		outLine.active_ = tpl_data.active;
		outLine.rms_1 = tpl_data.rms_error[0];
		outLine.rms_2 = tpl_data.rms_error[1];
		/***************************
		tpl_data.active
		case 1:  Successfully correlated
		case 2:  Correlation peak too near edge of search image
		case 3:  Subsidiary peak comparable in strength to main peak
		case 4:  Strength of peak below minimum specified by user
		case 5:  Diagonal displacement exceeds maximum specified
		case 6: FAIL
		case 7: Size of image and chip do not match
		case 8: Tie point outside image
		case 9: FAIL;
		**********/
		
		//clean up and return
		error_code_ = tpl_data.active;
		delete[] ref_chip;
		delete[] srch_chip;

	}

	long ImageMatch::extract(
		const std::vector<std::vector<unsigned char>> &image, /* Full image matrix                            */
		long *tp,											  /* Tie point (l,s)                              */
		long *size,											  /* Size of chip--nl,ns                          */
		long minval,										  /* Minimum chip size                            */
		long maxval,										  /* Maximum chip size                            */
		float *buffer,										  /* Chip buffer                                  */
		long *start											  /* Start line and sample                        */
	)
	{
		long i, j, k; /* Loop counters */
		long sl, ss;  /* Starting line and sample of chip */

		/* Extract chips from full image
		-----------------------------*/
		/* Check validity of chip size
		---------------------------*/
		if ((size[0] < minval) || (size[0] > maxval) ||
			(size[1] < minval) || (size[1] > maxval))
			return (BAD_SIZE);

		/* Determine image coordinates at which to extract chips
		-----------------------------------------------------*/
		sl = start[0] = (long)(tp[0] - (size[1] / 2.0) + 1.0);
		ss = start[1] = (long)(tp[1] - (size[0] / 2.0) + 1.0);

		/* Check window coordinates against image size
		-------------------------------------------*/
		if ((sl < 0) || (ss < 0) || ((sl + size[1]) > image.size()) || ((ss + size[0]) > image[0].size()))
			return (OUTSIDE_IMAGE);

		/* Extract window from full image
		------------------------------*/

		k = 0;
		// assuming buffer is alreay allocated. Check if buffer is a valid memory block
		if (buffer == nullptr)
			return (BAD_BUFFER);

		for (i = sl; i < sl + size[1]; i++)
			for (j = ss; j < ss + size[0]; j++)
			{

				buffer[k] = float(image[i][j]);
				k++;
			}

		return (E_SUCC);
	}

	long ImageMatch::extract_buffer(
		const std::vector<std::vector<unsigned char>> &data, /* Full image matrix                            */
		long *tp,											 /* Tie point (l,s)                              */
		long *size,											 /* Size of chip--nl,ns                          */
		long minval,										 /* Minimum chip size                            */
		long maxval,										 /* Maximum chip size                            */
		float *buffer,										 /* Chip buffer                                  */
		long *start											 /* Start line and sample                        */
	)
	{
		long i, j, k; /* Loop counters */
		long sl, ss;  /* Starting line and sample of chip */

		/* Extract chips from full image
		-----------------------------*/
		/* Check validity of chip size
		---------------------------*/
		if ((size[0] < minval) || (size[0] > maxval) ||
			(size[1] < minval) || (size[1] > maxval))
			return (BAD_SIZE);

		/* Determine image coordinates at which to extract chips
		-----------------------------------------------------*/
		sl = start[0] = (long)(tp[0] - (size[1] / 2.0) + 1.0);
		ss = start[1] = (long)(tp[1] - (size[0] / 2.0) + 1.0);

		/* Check window coordinates against image size
		-------------------------------------------*/
		int ncols = data[0].size();
		int nrows = data.size();
		if ((sl < 0) || (ss < 0) || ((sl + size[1]) > nrows) || ((ss + size[0]) > ncols))
			return (OUTSIDE_IMAGE);

		/* Extract window from full image
		------------------------------*/
		// test the code

		k = 0;
		// assuming buffer is alreay allocated. Check if buffer is a valid memory block
		if (buffer == nullptr)
			return (BAD_BUFFER);
		//print the start row, col and the end row col for debugging
		//build with a flag -DDEBUG to enable the debugging output
#ifdef DEBUG
		cout << "Extracting chip at (row: " << sl << ", col: " << ss << ") with size (rows: " << size[1] << ", cols: " << size[0] << ")" << endl;
#endif
		for (i = sl; i < sl + size[1]; i++)
		{
			for (j = ss; j < ss + size[0]; j++)
			{								   // i is the row index, j is the column index
				buffer[k] = float(data[i][j]); // assuming (row, col) layout for the data matrix
				k++;
			}
		}
		return (E_SUCC);
	}

}
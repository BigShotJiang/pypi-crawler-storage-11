/****************************************************************************
NAME:				EVAL

PURPOSE:  Evaluate various measures of correlation validity and extract a 
	  subarea of the cross correlation array centered on the peak

VERSION	 DATE	AUTHOR	  
-------	 ----	------	   
  1.0	 8/92	D. Steinwand 

REFERENCES:

1.0  LAS 4.0 GREYCORR and EDGECORR by R. White 6/83
*****************************************************************************/
#include "immatch.h"

void eval
(
    long ncol,		/* Number of columns in coincidence-count array */
    long nrow,		/* Number of rows in coincidence-count array 	*/
    float *ccnorm,	/* Array of norm xcorr coeffs 			*/
    float *pkval,	/* Table of top 32 normalized values 		*/
    long *ipkcol,	/* Table of column numbers for top 32 values 	*/
    long *ipkrow,	/* Table of row numbers for top 32 values 	*/
    float *sums,	/* Sum of all normalized values and sum of squares */
    float csmin,	/* Minimum acceptable correlation strength 	*/
    float *streng,	/* Strength of correlation 			*/
    long *iacrej,	/* Accept/Reject code (see geompak.h) 		*/
    float *cpval	/* 5 by 5 array of xcorr vals in std dev 	*/
)
{
long ipt5[2];		/* Highest 2 vals > 2 cols or rows from peak value */
long i,j;		/* Loop counters 				*/
long icol;		/* Initial col in 9 by 9 neighborhood of corr peak */
long idist;		/* Max horiz or vert distance from array peak 	*/
long iptr;		/* Index to 5 by 5 array of output values 	*/
long ipt7;		/* Index of largest val > 3 cols or rows from peak */
long irow;		/* Initial row in 9 by 9 neighborhood 		*/
long krbase;		/* Offset to beginning of current row in array 	*/
long lcol;		/* Last col in 9 by 9 area centered on peak 	*/
long lrow;		/* Last row in 9 by 9 neighborhood 		*/
long npts;		/* #array values outside 9 by 9 neighborhood 	*/
long n5;		/* #large values outside 5 by 5 neighborhood of peak */
long n7;		/* #large values outside 7 x 7 neighborhood of peak  */
float bmean;		/* Mean of background cross-correlation values 	*/
float bsigma;		/* Standard deviation of background about mean 	*/
long tempa,tempb;





/* Initialize accept/reject code, strength, and outlier pointers
  -------------------------------------------------------------*/
*iacrej = 1;
*streng = 0.0;
ipt5[0] = 31;
ipt5[1] = 31;
ipt7 = 0;

/* Check for peak value within two rows or columns of edge
  -------------------------------------------------------*/
if ((ipkcol[0]<=1) || (ipkcol[0]>=(ncol-2)) ||
    (ipkrow[0]<=1) || (ipkrow[0]>=(nrow-2)))
   {
   *iacrej = 2;
   return;
   }

/* Find largest values outside 5 by 5 and 7 by 7 neighborhoods of peak
  -------------------------------------------------------------------*/
n5 = 0; n7 = 0; i = 1;
//by Lei Wang 2013, added a peak to peak ratio to aid the decion making
//float peak_to_peak_ratio = 1.5;
for(;;)
   {
	   //if(pkval[0] / pkval[i] > peak_to_peak_ratio) break;
   if ((n5>1)||(i>31))
      break;
   tempa=labs(ipkcol[0]-ipkcol[i]);
   tempb=labs(ipkrow[0]-ipkrow[i]);
   idist = tempa>tempb?tempa:tempb;
   if (idist>2)
      {
      ipt5[n5] = i;
      n5++;
      if ((n7==0)&&(idist>3))
         {
         ipt7 = i;
         n7 = 1;
         }
      }
   i++;
   }
if ((ipt5[0]<=2) || (ipt5[1]<=4)) {*iacrej = 3; return;}

/* Find edges of 9 by 9 array centered on peak
  -------------------------------------------*/
icol = 0>(ipkcol[0]-4) ? 0 : ipkcol[0]-4;
irow = 0>(ipkrow[0]-4) ? 0 : ipkrow[0]-4;
lcol = (ncol-1)<(ipkcol[0]+4) ? ncol-1 : ipkcol[0]+4;
lrow = (nrow-1)<(ipkrow[0]+4) ? nrow-1 : ipkrow[0]+4;

/* Eliminate points within 9 by 9 array from background statistics
  ---------------------------------------------------------------*/
krbase = ncol*irow;
for(i=irow;i<=lrow;i++)
   {
   for(j=icol;j<=lcol;j++)
      {
      sums[0] -= ccnorm[krbase+j];
      sums[1] -= ccnorm[krbase+j]*ccnorm[krbase+j];
      }
   krbase += ncol;
   }

/* Compute background mean and standard deviation
  ----------------------------------------------*/
npts = ncol*nrow - (lcol - icol + 1) * (lrow - irow + 1);
bmean = sums[0]/(float)npts;
bsigma = sqrt(sums[1]/(float)npts - bmean*bmean);

/* Compute correlation strength and check against minimum.  Note that the LAS 
   4.x version of this code contains an error...it often tries to access pkval 
   array element zero when there are no signifcant subsidiary peaks, resulting 
   in unpredictable results
  ------------------------*/
if (n7 == 0) *streng = 2 * ((pkval[0] - bmean)/bsigma) - 0.2;
else 
   *streng=(pkval[0]-bmean)/bsigma+(pkval[0]-pkval[ipt7])/bsigma+0.2*(n7-1.0);

if (*streng<csmin) { *iacrej = 4; return;}

/* Convert 5 by 5 neighborhood of peak to standard deviations above mean
  ---------------------------------------------------------------------*/
krbase = ncol*(ipkrow[0] - 2);
for(iptr=0,i=0; i<5; i++, krbase+=ncol)
   for(j=ipkcol[0]-2; j<=ipkcol[0]+2; j++, iptr++)
      cpval[iptr] = (ccnorm[krbase+j] - bmean)/bsigma;
}

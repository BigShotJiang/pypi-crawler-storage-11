#include "tamuio.h"
void
Header::reEvaluate()
{

  if(bits_status[NCOLS]){
    if(!bits_status[XLLCORNER]&&!bits_status[XLLCENTER]
       &&!bits_status[ULXMAP]&&!bits_status[CELLSIZE])
      {                
        xllcenter = xllcorner + 0.5*xdim;
        ulxmap=xllcenter;
                
      }//if any other variables are not changing
      
  }//changed ncols
 
  if(bits_status[NROWS]){
    if(!bits_status[YLLCORNER]&&!bits_status[YLLCENTER]
       &&!bits_status[ULYMAP]&&!bits_status[CELLSIZE])
      {                
        yllcenter = yllcorner + 0.5*ydim;
        ulymap=yllcenter+(nrows-1)*cellsize;
                
      }//if any other variables are not changing

  }//changed nrows
  if(bits_status[CELLSIZE]){
    xdim = ydim = cellsize;
    if(!bits_status[XLLCORNER]&&!bits_status[XLLCENTER]&&!bits_status[ULXMAP]){
      xllcenter = xllcorner + 0.5*xdim;
      ulxmap=xllcenter;
    }//if any other variables are not changing
    if(!bits_status[YLLCORNER]&&!bits_status[YLLCENTER]&&!bits_status[ULYMAP]){
      yllcenter = yllcorner + 0.5*ydim;
      ulymap=yllcenter+(nrows-1)*cellsize;
    }//if any other variables are not changing
    bits_status.reset(XDIM);
    bits_status.reset(YDIM);
  }//cellsize
    
  if(bits_status[XDIM]){
    cellsize=xdim;
    if(!bits_status[XLLCORNER]&&!bits_status[XLLCENTER]&&!bits_status[ULXMAP]){
      xllcenter = xllcorner + 0.5*xdim;
      ulxmap=xllcenter;
    }//if any other variables are not changing
  }//xdim
    
  if(bits_status[YDIM]){
    cellsize=ydim;
    if(!bits_status[YLLCORNER]&&!bits_status[YLLCENTER]&&!bits_status[ULYMAP]){
      yllcenter = yllcorner + 0.5*ydim;
      ulymap=yllcenter+(nrows-1)*cellsize;
    }//if any other variables are not changing        
  }//ydim

    
  if(bits_status[XLLCORNER]){
    xllcenter = xllcorner + 0.5*xdim;
    ulxmap=xllcenter;
    bits_status.reset(XLLCENTER);
    bits_status.reset(ULXMAP);
  }//changed xllcorner
    
  if(bits_status[YLLCORNER]){
    yllcenter=yllcorner+0.5*cellsize;
    ulymap=yllcenter+(nrows-1)*cellsize;
    bits_status.reset(YLLCENTER);
    bits_status.reset(ULYMAP);

  }//changed yllcorner    
  if(bits_status[NBITS]){
    bandrowbytes = ncols* nbits/8;
    if(nbits==-1){
      bandrowbytes = ncols*32/8;
    }
  }//changed nbits
   
  if(bits_status[ULXMAP]){
    xllcenter=ulxmap;
    xllcorner=ulxmap-0.5*cellsize;
    bits_status.reset(XLLCENTER);
  }//ulxmap
     
  if(bits_status[ULYMAP]){
    yllcenter=ulymap-(nrows-1)*cellsize;
    yllcorner=ulymap-0.5*cellsize;
    bits_status.reset(YLLCENTER);

  }//ulymap
    
  if(bits_status[XLLCENTER]){
    ulxmap=xllcenter;
    xllcorner=ulxmap-0.5*cellsize;
  }//xllcenter
    
  if(bits_status[YLLCENTER]){
    ulymap=yllcenter+(nrows-1)*cellsize;
    yllcorner=yllcenter-0.5*cellsize;
        
  }//yllcenter
    
  if(bits_status[IMG_BYTE_ORDER]){
    if(imgbyteorder==std::string("i")){
      floatbyteorder.assign("lsbfirst");
    }
    else{
      floatbyteorder.assign("msbfirst");
    }
  }//IMG_BYTE_ORDER
  if(bits_status[FLOAT_BYTE_ORDER]){
    if(floatbyteorder==std::string("lsbfirst")){
      imgbyteorder.assign("i");      
    }
    else{
      imgbyteorder.assign("m");
    }
  }
  if(bits_status[TYPE]){
    if(ftype==GRID){
#ifdef GRID_IO_LIBRARY
      grid_type=CELLFLOAT;
#endif
    } 
    else if(ftype==BSQ){
      layout="BSQ";
    }       
    else if(ftype==BIL){
      layout="BIL";
    }
  }
#ifdef GRID_IO_LIBRARY
  bnd_box[0]=xllcorner;
  bnd_box[1]=yllcorner;
  bnd_box[2]=xllcorner+cellsize*ncols;
  bnd_box[3]=yllcorner+cellsize*nrows;
  fcellsize=(float)cellsize;
#endif
  bits_status.reset();

}//reEvaluate

void 
Header::setCols(int nc)
{
  ncols=nc;
  bits_status.set(NCOLS);
  reEvaluate();
    
}
void 
Header::setRows(int nr)
{
  nrows=nr;
  bits_status.set(NROWS);
  reEvaluate();
    
}

void
Header::setXll(double xll)
{
  xllcorner=xll;
  bits_status.set(XLLCORNER);
  reEvaluate();

}
void
Header:: setYll(double yll)
{   
  yllcorner=yll;
  bits_status.set(YLLCORNER);
  reEvaluate();


}
void
Header:: setCellSize(double cell_s)
{
  cellsize=cell_s;
  bits_status.set(CELLSIZE);
  reEvaluate();

}
void
Header::setType(fileType ft)
{
  ftype=ft;
  bits_status.set(TYPE);
  reEvaluate();
   
}
Header::Header() 
{
  ftype=NO_TYPE;
  nrows=0;
  ncols=0;
  nbits=8;
  nbands=1;
  bandrowbytes=0;
  xllcenter=0.5;
  yllcenter=0.5;
  xllcorner=0.0;
  yllcorner=0.0;
  ulxmap=-9999.0;
  ulymap=-9999.0;
  cellsize=1.0;
  xdim=1.0;
  ydim=1.0;
  NODATA_value = -9999; /* value representing no data */
  layout.assign("bsq");
  imgbyteorder.assign("m");
  floatbyteorder.assign("msbfirst");
  
};

Header::Header(const Header& hd) 
{
  ftype=NO_TYPE;
  nrows=hd.nrows;
  ncols=hd.ncols;
  nbits=hd.nbits;
  nbands=hd.nbands;
  bandrowbytes=hd.bandrowbytes;
  xllcenter=hd.xllcenter;
  yllcenter=hd.yllcenter;
  xllcorner=hd.xllcorner;
  yllcorner=hd.yllcorner;
  ulxmap=hd.ulxmap;
  ulymap=hd.ulymap;
  cellsize=hd.cellsize;
  xdim=hd.xdim;
  ydim=hd.ydim;
  NODATA_value = hd.NODATA_value; /* value representing no data */
  layout=hd.layout;
  imgbyteorder=hd.imgbyteorder;
  floatbyteorder=hd.floatbyteorder;
#ifdef GRID_IO_LIBRARY  
  grid_type=hd.grid_type;
  for(int i=0;i<4;i++){
    bnd_box[i]=hd.bnd_box[i];
  }

  fcellsize=hd.fcellsize;
#endif
}//Header(const Header& hd)

std::ostream&
operator<< (std::ostream& c, const Header& hd) 
{
  std::cout<<"writing the header "<<endl;
  switch(hd.ftype){
  case Header::BIL:    //image BIL
    c<<"ncols   "<<hd.ncols<<std::endl
     <<"nrows   "<<hd.nrows<<std::endl
     <<"nbands  "<<hd.nbands<<std::endl
     <<"nbits   "<<hd.nbits<<std::endl
     <<"ulxmap  "<<hd.ulxmap<<std::endl
     <<"ulymap  "<<hd.ulymap<<std::endl
     <<"xdim    "<<hd.xdim<<std::endl
     <<"ydim    "<<hd.ydim<<std::endl
     <<"layout  "<<hd.layout<<std::endl
     <<"byteorder "<<hd.imgbyteorder<<std::endl;
    break;
  case Header::BSQ://image BSQ
    c<<"ncols   "<<hd.ncols<<std::endl
     <<"nrows   "<<hd.nrows<<std::endl
     <<"nbands  "<<hd.nbands<<std::endl
     <<"nbits   "<<hd.nbits<<std::endl
     <<"ulxmap  "<<hd.ulxmap<<std::endl
     <<"ulymap  "<<hd.ulymap<<std::endl
     <<"xdim    "<<hd.xdim<<std::endl
     <<"ydim    "<<hd.ydim<<std::endl
     <<"layout  "<<hd.layout<<std::endl
     <<"byteorder "<<hd.imgbyteorder<<std::endl;
    break;
  case Header::FLOAT://float binary

    c<<"ncols   "<<hd.ncols<<std::endl
     <<"nrows   "<<hd.nrows<<std::endl
     <<"xllcorner  "<<hd.xllcorner<<std::endl
     <<"yllcorner   "<<hd.yllcorner<<std::endl
     <<"cellsize  "<<hd.cellsize<<std::endl
     <<"NODATA_value    "<<hd.NODATA_value<<std::endl
     <<"byteorder "<<hd.floatbyteorder<<std::endl;
    break;
  case Header::ASCII://arcinfo ascii 

    c<<"ncols   "<<hd.ncols<<std::endl
     <<"nrows   "<<hd.nrows<<std::endl
     <<"xllcorner  "<<hd.xllcorner<<std::endl
     <<"yllcorner   "<<hd.yllcorner<<std::endl
     <<"cellsize  "<<hd.cellsize<<std::endl
     <<"NODATA_value    "<<hd.NODATA_value<<std::endl;
    break;
  case Header::GRID://grid
 
    c<<"ncols   "<<hd.ncols<<std::endl
     <<"nrows   "<<hd.nrows<<std::endl
     <<"xllcorner  "<<hd.xllcorner<<std::endl
     <<"yllcorner   "<<hd.yllcorner<<std::endl
     <<"cellsize  "<<hd.cellsize<<std::endl;
    break;
  default:
    std::cout<<"The format: "<<hd.ftype<<" is not suppported to write header information"<<std::endl;
    break;
  }
  return c;

}//operator <<header

std::istream&
operator>> (std::istream &c, Header&hd)
{
  std::string::size_type idx;
  std::string buffer_line,tmpstr;
  while(!c.eof()){
    std::getline(c,buffer_line);

    if(!buffer_line.empty()) {
      std:: transform(buffer_line.begin(),buffer_line.end(),
	      buffer_line.begin(),
	      ::tolower);//transform all characters to lower case
      if((idx=buffer_line.rfind("nrows")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("nrows").length());
        hd.nrows=atoi(tmpstr.c_str());
        hd.setBitStatus(Header::NROWS);
      }//nrows
      else if((idx=buffer_line.rfind("ncols")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("ncols").length());
        hd.ncols=atoi(tmpstr.c_str());
        hd.setBitStatus(Header::NCOLS);
      }//ncols
      else if((idx=buffer_line.rfind("nbands")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("nbands").length());
        hd.nbands=atoi(tmpstr.c_str());
      }//nbands
      else if((idx=buffer_line.rfind("nbits")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("nbits").length());
        hd.nbits=atoi(tmpstr.c_str());
        hd.setBitStatus(Header::NBITS);
      }//nbits
      else if((idx=buffer_line.rfind("layout")) != std::string::npos) {
        //skip blank characters
        idx+=std::string("layout").length();
        for(;idx<buffer_line.length();idx++){
          if(hd.isnumalp(buffer_line[idx])) break;
        }
        string::size_type last_letter,index;
        for(index=idx;index<buffer_line.length();index++){
          if(hd.isnumalp(buffer_line[index])){
            last_letter=index;
          }
        }
        hd.layout=buffer_line.substr(idx,last_letter);
      }//layout
      else if((idx=buffer_line.rfind("ulxmap")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("ulxmap").length());
        hd.ulxmap=atof(tmpstr.c_str());
        hd.setBitStatus(Header::ULXMAP);
      }//ulxmap        
      else if((idx=buffer_line.rfind("ulymap")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("ulymap").length());
        hd.ulymap=atof(tmpstr.c_str());
        hd.setBitStatus(Header::ULYMAP);

      }//ulymap
      else if((idx=buffer_line.rfind("xllcorner")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("xllcorner").length());
        hd.xllcorner=atof(tmpstr.c_str());
        hd.setBitStatus(Header::XLLCORNER);
      }//xllcorner             
      else if((idx=buffer_line.rfind("yllcorner")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("yllcorner").length());
        hd.yllcorner=atof(tmpstr.c_str());
        hd.setBitStatus(Header::YLLCORNER);
      }//yllcorner             
      else if((idx=buffer_line.rfind("xllcenter")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("xllcenter").length());
        hd.xllcenter=atof(tmpstr.c_str());
        hd.setBitStatus(Header::XLLCENTER);
      }//xllcenter 
      else if((idx=buffer_line.rfind("yllcenter")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("yllcenter").length());
        hd.yllcenter=atof(tmpstr.c_str());
        hd.setBitStatus(Header::YLLCENTER);
      }//yllcenter  
      else if((idx=buffer_line.rfind("cellsize")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("cellsize").length());
        hd.cellsize=atof(tmpstr.c_str());
        hd.setBitStatus(Header::CELLSIZE);
      }//cellsize    
                     
      else if((idx=buffer_line.rfind("xdim")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("xdim").length());
        hd.xdim=atof(tmpstr.c_str());
        hd.setBitStatus(Header::XDIM);
      }//xdim   
      else if((idx=buffer_line.rfind("ydim")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("ydim").length());
        hd.ydim=atof(tmpstr.c_str());
        hd.setBitStatus(Header::YDIM);
      }//ydim
      else if((idx=buffer_line.rfind("bandrowbytes")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("bandrowbytes").length());
        hd.bandrowbytes=atoi(tmpstr.c_str());
      }//bandrowbytes
      else if((idx=buffer_line.rfind("byteorder")) != std::string::npos) {
                    
        idx+=std::string("byteorder").length();
        for(;idx<buffer_line.length();idx++){
          if(hd.isnumalp(buffer_line[idx])) break;
        }
        string::size_type last_letter,index;
        for(index=idx;index<buffer_line.length();index++){
          if(hd.isnumalp(buffer_line[index])){
            last_letter=index;
          }
        }//removing blank characters
        if(hd.ftype==Header::BSQ||hd.ftype==Header::BIL){
          hd.imgbyteorder=buffer_line.substr(idx,last_letter);
          hd.setBitStatus(Header::IMG_BYTE_ORDER);
        }
        else if(hd.ftype==Header::FLOAT){
          hd.floatbyteorder=buffer_line.substr(idx,last_letter);
          hd.setBitStatus(Header::FLOAT_BYTE_ORDER);
        }
                    
    	            
      }//imgbyteorder&floatbyteorder
      else if((idx=buffer_line.rfind("nodata_value")) != std::string::npos) {
        tmpstr=buffer_line.substr(idx+std::string("nodata_value").length());
        hd.NODATA_value=atof(tmpstr.c_str());
      }//NODATA_value
      else{
        std::cout << "unrecognized information: " << buffer_line << std::endl;
      }
    }
  }//while
  hd.reEvaluate();
  return c;

}//ostream operator>>

void
Header::read(const std::string &in_file, fileType f_type)
{
  int i;
  std::string::size_type idx;
  std::string f_name;
  fname=in_file;
  ftype=f_type;
  std::ifstream headFpt;
  std::string buffer,buffer_line;
  std::istringstream stringstr;
    
#ifdef GRID_IO_LIBRARY
  MyGridIO<float> input_grid;
#endif
  /************************************
		       reading data from input file 
  *********************************/
  switch(f_type){
  case Header::BIL:
    
    idx=in_file.find(".");
    if (idx==std::string::npos){
      f_name=in_file + ".hdr";                
    }//no extension name is found 
    else{
      f_name=in_file.substr(0,idx) + std::string(".hdr");
      std::cout << "Assume " << in_file
	<< " is in Integer Binary BIL format (one/two byte integer)"
	<< std::endl;
      std::cout<< "Also assume input header file " 
               << f_name << " exist." << std::endl;

    }
    //Read header file
    headFpt.open(f_name.c_str(), std::ios::in);
    if(!headFpt){
      std::cerr << "Fatal error, could not open header file:" << f_name << std::endl;
      exit(-1);
    }
    headFpt>>(*this);
    headFpt.close();
    break;//BIL Header
  case Header::BSQ:

    idx=in_file.find(".");
    if (idx==std::string::npos){
      f_name=in_file + ".hdr";                
    }//no extension name is found 
    else{
      f_name=in_file.substr(0,idx) + std::string(".hdr");
      std::cout << "Assume " << in_file
	<< " is in Integer Binary BSQ format (one/two byte integer)"
	<< std::endl;
      std::cout<< "Also assume input header file " 
               << f_name << " exist." << std::endl;

    }
        


    //Read header file
    headFpt.open(f_name.c_str(), std::ios::in);
    if(!headFpt){
      std::cerr << "Fatal error, could not open header file:" << f_name << std::endl;
      exit(-1);
    }
    headFpt>>(*this);
    headFpt.close();
    break;
  case Header::FLOAT: /*Float Binary BSQ format*/
    idx=in_file.find(".");
    if (idx==std::string::npos){
      f_name=in_file + ".hdr";                
    }//no extension name is found 
    else{
      f_name=in_file.substr(0,idx) + std::string(".hdr");
      std::cout << "Assume " << in_file
	<< " is in Float Binary BSQ format (real/float)"
	<< std::endl;
      std::cout<< "Also assume input header file " 
               << f_name << " exist." << std::endl;

    }
    //Read header file
    headFpt.open(f_name.c_str(), std::ios::in);
    if(!headFpt){
      std::cerr << "Fatal error, could not open header file:" << f_name << std::endl;
      exit(-1);
    }
    headFpt>>(*this);
    headFpt.close();
    break;
  case Header::ASCII: /*ArcInfo ASCII format*/
    f_name=in_file;
    std::cout << "Assume " << in_file << " is in ArcInfo ASCII format" << std::endl;
    std::cout << "Also assume header section in the ASCII file: " << f_name << std::endl;
    //Read header file
    headFpt.open(f_name.c_str(), std::ios::in);
    if(!headFpt) {
      std::cerr << "Could not open file:" << f_name << std::endl;
      exit(-1);
    }

    for(i=0;i<6;i++) {
      std::getline(headFpt, buffer_line);
      buffer+=(buffer_line+string("\n"));
    }
    stringstr.str(buffer);
    stringstr>>(*this);
    headFpt.close();
    break;
  case Header::GRID: //Arcinfo GRID format
#ifdef GRID_IO_LIBRARY //going to use GRIDIO library
    std::cout<<"Reading Grid format header"<<std::endl;
    input_grid.open(in_file.c_str(),READONLY,NULL);
    if(!input_grid){
      std::cout<<"cannot open grid for reading"<<std::endl;
      return;
    }
    fname=in_file;
    nrows=input_grid.getRows();
    ncols=input_grid.getCols();
    double *bnd;
    bnd=input_grid.getBndBox();
    for(i=0;i<4;i++){
      bnd_box[i]=bnd[i];
    }
    xllcorner=bnd_box[0];
    yllcorner=bnd_box[1];
    fcellsize=cellsize=input_grid.getCellSize();
    grid_type=input_grid.getType();
    input_grid.close();

#else //No GRIDIO libary is configured
    std::cout<<"Arcinfo grid is not supported here, please define GRID_IO_LIBRARY"<<std::endl;
        
             
                
#endif    
    break;
  case Header::LAS:
    std::cout<<"las format is not supported in this version"<<std::endl;
    exit(-1);
    break;
  default:
    std::cout << "unknown input file format!" << std::endl;
    exit(-1);
    break;
  }//swicth
  /***************************************
		          assign values for unfilled header info
  ***********************/
  if(nrows<1){
    std::cout << "Fatal error: no information about nrows in header file:" << fname << std::endl;
    exit (-1);
  }
  if(ncols<1){
    std::cout << "Fatal error: no information about ncols in header file:" << fname << std::endl;
    exit (-1);
  }
  if(nbits != -1 && nbits != 8 && nbits != 16 && nbits !=  32){
    std::cout << "This program cannot handle " << nbits << " bits pixel depth image!" << std::endl;
    exit (-1);
  }
  bandrowbytes = ncols* nbits/8;
  if(nbits==-1){
    bandrowbytes = ncols*32/8;
  }//float number in las


}//Header::read()

void
Header::write(const std::string &out_file,fileType ft)
{
  if(ft!=Header::NO_TYPE){
    this->setType(ft);
  }
  std::string::size_type idx=out_file.find(".");
  std::string f_name;
  if (idx==std::string::npos){
    f_name=out_file + ".hdr";                
  }//no extension name is found 
  else{
    f_name=out_file;
  }
  std::ofstream out_header_file(f_name.c_str(),std::ios::out);
  if(!out_header_file){
    std::cerr<<"No access to file: "<<f_name<<std::endl;
    exit(-1);
  }
  out_header_file<<(*this);
        
}//Header::write()

time_t cur_time;
void StartWatch()
{
   cur_time = time(NULL);
  
}

void StopWatch()
{
  cout << "Total wall clock time = " << long(time(NULL) - cur_time) << " seconds.\n\n";
}
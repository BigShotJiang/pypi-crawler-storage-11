/*****************************************************************************
NAME:				PHASE_CORR

PURPOSE:  Subroutine to match a 32 x 32 reference sub-image to a (up to)
          128 x 128 search sub-image.  Phase correlation is used.

VERSION		DATE	AUTHOR		
-------		----	------	
  1.0		8/92	D. Steinwand

*****************************************************************************/
#include "immatch.h"
/* Prototypes */
int phase
(
    float *ref,			/* 32 x 32 reference chip, stored by rows    */
    float *search,		/* Search subimage, stored by rows 	     */
    long size,			/* Size of search subimage 	             */
    long inc,			/* Stepping increment 			     */
    float alpha,
    float *peak,		/* Correlation peak 			     */
    float *line,		/* Line in srch subimage corr. to ref center */
    float *samp			/* Samp in srch subimage corr. to ref center */
);


void phase_corr
(
    struct TPLDATA *tpl,            /* Tie point location data record 	*/
    struct CORRPAR *corr,           /* Correlation parameters 		*/
    float *ref,                     /* Reference subimage 		*/
    float *srch,                    /* Search subimage 			*/
    long ssize,
    long inc,
    float alpha
)
{
long status;
float line,samp;
float peak;
float diffx,diffy;

status=phase(ref, srch, ssize, inc, alpha, &peak, &line, &samp);
line = line - (float)(ssize/2);
samp = samp - (float)(ssize/2);
if (status != OK) tpl->active = 2;
tpl->strength = peak;
tpl->rms_error[0] = 0.0;
tpl->rms_error[1] = 0.0;
if (tpl->active == 1)
   {
   tpl->sea_coord[0] = tpl->nominal[0] + line +
       			tpl->ref_coord[0] - tpl->ref_coord[0];
   tpl->sea_coord[1] = tpl->nominal[1] + samp +
       			tpl->ref_coord[1] - tpl->ref_coord[1];
   diffy = tpl->sea_coord[0] - tpl->nominal[0];
   diffx = tpl->sea_coord[1] - tpl->nominal[1];
   tpl->displacement = sqrt(diffx * diffx + diffy * diffy);
   if(tpl->displacement > corr->maxdiff) tpl->active = 5;
   if(corr->mincorr > tpl->strength) tpl->active = 4;
   }
else
   {
   tpl->displacement = 0.0;
   tpl->sea_coord[0] = tpl->nominal[0];
   tpl->sea_coord[1] = tpl->nominal[1];
   }
}


/*****************************************************************************
NAME:                           PHASE_CORR

PURPOSE:  Subroutine to match a 32 x 32 reference sub-image to a (up to)
          128 x 128 search sub-image.  Phase correlation is used.

VERSION         DATE    AUTHOR
-------         ----    ------
  1.0           8/92    D. Steinwand

*****************************************************************************/
int phase
(
    float *ref,			/* 32 x 32 reference chip, stored by rows    */
    float *search,		/* Search subimage, stored by rows 	     */
    long size,			/* Size of search subimage 	             */
    long inc,			/* Stepping increment 			     */
    float alpha,
    float *peak,		/* Correlation peak 			     */
    float *line,		/* Line in srch subimage corr. to ref center */
    float *samp			/* Samp in srch subimage corr. to ref center */
)
{
long i,j,k,l,m;			/* Loop counters 			     */
COMPLEX buf[1024];		/* Complex buffer for reference subimage     */
COMPLEX srch[1024];		/* Complex buffer for search subimage        */
COMPLEX sr[1024];		/* Complex buffer for correlation results    */
long sl;			/* Pointer to start of search sub-chip 	     */
long kl,kl16;			/* Misc indeces 			     */
long stop;			/* Upper increment 			     */
float temp;			/* Temporary variable in re-arrangement      */
float rv,srmax;			/* Max peak location variables 		     */
long kmax,lmax;			/* Location of max peak 		     */
double corr[9];			/* Array for correlation peak & 8 neighbors  */
long iloc,jloc;			/* Correlation peak locations 		     */
float maxpeak;			/* Maximum correlation peak 		     */
double magnitude;		/* Phase of point--temp variable 	     */
double H;
double Hmag;
double A[54];			/* A matrix for sub-pixel calculation 	     */
double v[9];			/* Work-space vector for sub-pixel calc      */
double x0,y0,b2a;		/* Sub-pixel offsets & work variable 	     */

/* Take fft of the reference window
  --------------------------------*/
for(i=0; i<1024; i++) { buf[i].re=ref[i]; buf[i].im=0.0;}
fft2d((float *)buf,32,32,1);

/* Step thru search window extracting a 32 x 32 sub-chip and take its FFT
  ----------------------------------------------------------------------*/
stop=(size-32)+1;
maxpeak = -1e20;
for(i=0; i<stop; i+=inc)
   for(j=0; j<stop; j+=inc)
      {
      sl=i*size+j;
      for(m=0,k=0; k<32; k++, sl+=size)
         for(l=0; l<32; l++,m++) 
            { srch[m].re=search[sl+l]; srch[m].im=0.0; }
      fft2d((float *)
srch,32,32,1);

/* Take complex conj of two chips
  ------------------------------*/
      for(k=0; k<1024; k++)
         {
         sr[k].im=buf[k].re*srch[k].im-buf[k].im*srch[k].re;
         sr[k].re=buf[k].re*srch[k].re+buf[k].im*srch[k].im;

/* Calculate "phase" correlation
  -----------------------------*/
         magnitude=sqrt(sr[k].re*sr[k].re+sr[k].im*sr[k].im);
         if (magnitude < 1.0e-6) magnitude=1.0e-6;
         H = pow(magnitude,alpha);
         Hmag = H / magnitude;
         sr[k].re *= Hmag;
         sr[k].im *= Hmag;
         }

/* Take inverse transform of correlation windows
  ---------------------------------------------*/
      fft2d((float *)sr,32,32,-1);

/* Rearrange chips to center
  -------------------------*/
      for(k=0; k<16; k++)
         for(l=0; l<16; l++)
            {
            kl=k*32+l; kl16=(k+16)*32+l+16;
            temp=sr[kl].re; sr[kl].re=sr[kl16].re; sr[kl16].re=temp;
            kl=(k+16)*32+l; kl16=k*32+l+16;
            temp=sr[kl].re; sr[kl].re=sr[kl16].re; sr[kl16].re=temp;
            }

/* Find peaks
  ----------*/
      srmax = -1e20;
      for(k=7; k<25; k++)
         for(l=7; l<25; l++)
            {
            rv=sr[l*32+k].re;
            if(rv>srmax) { srmax=rv; kmax=k; lmax=l; }
            }

/* Check correlation strength against other windows.  Store the "strongest."
  ------------------------------------------------------------------------*/
      if (srmax>maxpeak)
         {
         maxpeak=srmax;
         iloc=(lmax-16)+i;
         jloc=(kmax-16)+j;
         }
      }

/* Refine at max
  -------------*/
if(iloc<0)iloc=0;
if(jloc<0)jloc=0;
if(iloc>95)iloc=95;
if(jloc>95)jloc=95;

sl=iloc*size+jloc;
for(m=0,k=0; k<32; k++,sl+=size)
   for(l=0; l<32; l++,m++)
      { srch[m].re=search[sl+l]; srch[m].im=0.0; }
fft2d((float *)srch,32,32,1);

/* Take complex conj of two chips
  ------------------------------*/
for(k=0; k<1024; k++)
   {
   sr[k].im=buf[k].re*srch[k].im-buf[k].im*srch[k].re;
   sr[k].re=buf[k].re*srch[k].re+buf[k].im*srch[k].im;

/* Calculate "phase" correlation
  -----------------------------*/
   magnitude=sqrt(sr[k].re*sr[k].re+sr[k].im*sr[k].im);
   if (magnitude < 1.0e-6) magnitude=1.0e-6;
   H = pow(magnitude,alpha);
   Hmag = H / magnitude;
   sr[k].re *= Hmag;
   sr[k].im *= Hmag;
   }
   
/* Take inverse transform of correlation windows
  ---------------------------------------------*/
fft2d((float *)sr,32,32,-1);

/* Rearrange chips to center
  -------------------------*/
for(k=0; k<16; k++)
   for(l=0; l<16; l++)
      {
      kl=k*32+l; kl16=(k+16)*32+l+16;
      temp=sr[kl].re; sr[kl].re=sr[kl16].re; sr[kl16].re=temp;
      kl=(k+16)*32+l; kl16=k*32+l+16;
      temp=sr[kl].re; sr[kl].re=sr[kl16].re; sr[kl16].re=temp;
      }

/* Find peak
  ---------*/
*peak = -1e20;
for(k=7; k<25; k++)
   for(l=7; l<25; l++)
      {
      rv=sr[l*32+k].re;
      if(rv>*peak) { *peak=rv; kmax=k; lmax=l; }
      }

/* Store peak & 8 neighbors
  ------------------------*/
for(m=0,k=0; k<3; k++)
   for(l=0; l<3; l++,m++) corr[m]=sr[(lmax+l-1)*32+(kmax+k-1)].re;

/* Fit quadratic to peak and its neighbors to determine sub-pixel location
  -----------------------------------------------------------------------*/
for(m=0,k=1; k<=3; k++)
   for(l=1; l<=3; l++,m++) A[m]=(double)(l*l);
for(k=1; k<=3; k++)
   for(l=1; l<=3; l++,m++) A[m]=(double)(k*l);
for(k=1; k<=3; k++)
   for(l=1; l<=3; l++,m++) A[m]=(double)(k*k);
for(k=1; k<=3; k++)
   for(l=1; l<=3; l++,m++) A[m]=(double)l;
for(k=1; k<=3; k++)
   for(l=1; l<=3; l++,m++) A[m]=(double)k;
for(k=1; k<=9; m++,k++) A[m]=1.0;

c_qrdecomp(A, 9, 6, v,0);
c_qrsolve(A, 9, 6, v, corr, 0);

if(fabs(corr[0]) < 1.0e-7) y0=x0=0.0;
else
   {
   b2a=corr[1]/(corr[0]*2.0);
   y0=(b2a*corr[3]-corr[4]) / (2.0*corr[2]-b2a*corr[1])-2.0;
   x0= -b2a*(y0+2.0)-corr[3]/(corr[0]*2.0)-2.0;
   if (y0*y0+x0*x0>4.0) y0=x0=0.0;
   }

/* Calculate search image coordinate corresponding to reference chip center
  ------------------------------------------------------------------------*/
*line=iloc+lmax+y0;
*samp=jloc+kmax+x0;
return(OK);
}

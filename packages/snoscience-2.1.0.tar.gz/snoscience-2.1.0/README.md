# SnoScience

The source code, documentation, and CI/CD scripts for the SnoScience package are stored in this repository.

## Installation

1. Clone the repository with the following command:
    
    ```shell
    git clone https://snomax@dev.azure.com/snomax/SnoScience/_git/SnoScience
    ```

2. Install poetry:
    
    ```shell
    pip install poetry
    ```

3. Install the package:
    
    ```shell
    poetry install
    ```

## Documentation

Both the user and developer documentation can be found [here](https://thesecondsnomax.github.io/SnoScience).

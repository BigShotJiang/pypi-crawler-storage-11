"""
This module contains the implementations of the layer interfaces.
"""

from numpy import array, ndarray, sum as numpy_sum, zeros
from numpy.typing import NDArray
from snoparallel import Manager

from snoscience._interfaces import (
    HiddenOutputLayer,
    InputLossLayer,
    Neuron,
    NeuronDataType,
)


class SimpleInputLossLayer(InputLossLayer):
    """
    Implementation of the InputLossLayer class which stores the values directly into variables.
    """

    def __init__(self) -> None:
        super().__init__()

        self._y = array(object=[], dtype=NeuronDataType)
        self._y_prime = array(object=[], dtype=NeuronDataType)

        self.previous = None
        self.next = None

    @property
    def y(self) -> NDArray[NeuronDataType]:
        return self._y

    @y.setter
    def y(self, value: NDArray[NeuronDataType]) -> None:
        self._y = value

    @property
    def y_prime(self) -> NDArray[NeuronDataType]:
        return self._y_prime

    @y_prime.setter
    def y_prime(self, value: NDArray[NeuronDataType]) -> None:
        self._y_prime = value


class MultiInputLossLayer(InputLossLayer):
    """
    Implementation of the InputLossLayer class which stores the values into memory with variables as a reference.
    """

    def __init__(self, outputs: int, samples: int, manager: Manager) -> None:
        """
        Args:
            outputs: Number of outputs per sample.
            samples: Number of samples in the dataset.
            manager: snoparallel.Manager instance to request the variables with.
        """
        super().__init__()

        self._y = manager.request_variable(value=zeros(shape=(samples, outputs), dtype=NeuronDataType))
        self._y_prime = manager.request_variable(value=zeros(shape=(samples, outputs), dtype=NeuronDataType))

        self.previous = None
        self.next = None

    @property
    def y(self) -> ndarray:
        return self._y.read()

    @y.setter
    def y(self, value: ndarray) -> None:
        self._y.write(value=value)

    @property
    def y_prime(self) -> ndarray:
        return self._y_prime.read()

    @y_prime.setter
    def y_prime(self, value: ndarray) -> None:
        self._y_prime.write(value=value)

    def update(self) -> None:
        """
        Update the values in memory.
        """
        self._y.update()
        self._y_prime.update()


class RecursiveLayer(HiddenOutputLayer):
    """
    Implementation of the HiddenOutputLayer class which uses recursion to calculate the total derivatives.
    """

    def __init__(self, activation: str) -> None:
        """
        Args:
            activation: Applied activation functions for neurons in this layer.
        """
        super().__init__(activation=activation)

        self.previous: InputLossLayer | RecursiveLayer = SimpleInputLossLayer()
        self.next: InputLossLayer | RecursiveLayer = SimpleInputLossLayer()

    def calculate_total(self, neuron: Neuron) -> tuple[ndarray, NeuronDataType]:
        """
        Calculate the total derivative vector for the neuron's weights, and the total derivative float for the neuron's
        bias.

        Args:
            neuron: Neuron to calculate the total derivatives for.

        Returns:
            Total derivatives.
        """
        total = self.calculate_total_neuron(neuron=neuron, start=neuron, position=neuron.position)
        previous = self.previous.y

        total_weights = numpy_sum(total * previous, axis=0).reshape(-1, 1)
        total_bias = numpy_sum(total)

        return total_weights, total_bias

    def calculate_total_neuron(self, neuron: Neuron, start: Neuron, position: int) -> ndarray:
        """
        Calculate the total derivative vector for the neuron. This is used by the "calculate_total" method to start
        recursion through the network, and by the "calculate_total_layer" method to continue recursion.

        Args:
            neuron: Neuron whose total derivative needs to be calculated.
            start: Neuron from which the recursion is started.
            position: Position of the neuron in this layer.

        Returns:
            Total derivative for the neuron.
        """
        if start != neuron:
            first = neuron.y_prime * neuron.weights[position, 0]
        else:
            first = neuron.y_prime

        if isinstance(self.next, InputLossLayer):
            second = self.next.y_prime[:, neuron.position].reshape(-1, 1)
        else:
            second = self.next.calculate_total_layer(start=start, position=neuron.position)

        return first * second

    def calculate_total_layer(self, start: Neuron, position: int) -> ndarray:
        """
        Calculate the partial derivative vectors for each neuron in this layer and sum them. This is used by the
        "calculate_total_neuron" method to continue recursion through the network.

        Args:
            start: Neuron from which the recursion is started.
            position: Position of the neuron in this layer.

        Returns:
            Summed neuron partial derivatives.
        """
        total = zeros(shape=start.x.shape, dtype=NeuronDataType)

        for neuron in self.neurons:
            total = total + self.calculate_total_neuron(neuron=neuron, start=start, position=position)

        return total

"""
This mmodule contains the implementations of the neuron interfaces.
"""

from numpy import array, ndarray, zeros
from snoparallel import Manager

from snoscience._interfaces import HiddenOutputLayer, Neuron, NeuronDataType


class NeuronSimple(Neuron):
    """
    Implementation of the Neuron class which stores the calculations directly into variables.
    """

    def __init__(self, layer: HiddenOutputLayer, position: int, inputs: int) -> None:
        """
        Args:
            layer: Layer in which the neuron is located.
            position: Position of the neuron in this layer.
            inputs: Number of weights to add to the neuron.
        """
        super().__init__(layer=layer, position=position)

        self._x = array(object=[], dtype=NeuronDataType)
        self._y = array(object=[], dtype=NeuronDataType)
        self._y_prime = array(object=[], dtype=NeuronDataType)

        self._weights = array(object=[], dtype=NeuronDataType)
        self._bias = NeuronDataType()

        self._randomise(inputs=(inputs, 1))

    @property
    def x(self) -> ndarray:
        return self._x

    @x.setter
    def x(self, value: ndarray) -> None:
        self._x = value

    @property
    def y(self) -> ndarray:
        return self._y

    @y.setter
    def y(self, value: ndarray) -> None:
        self._y = value

    @property
    def y_prime(self) -> ndarray:
        return self._y_prime

    @y_prime.setter
    def y_prime(self, value: ndarray) -> None:
        self._y_prime = value

    @property
    def weights(self) -> ndarray:
        return self._weights

    @weights.setter
    def weights(self, value: ndarray) -> None:
        self._weights = value

    @property
    def bias(self) -> NeuronDataType:
        return self._bias

    @bias.setter
    def bias(self, value: NeuronDataType) -> None:
        self._bias = value


class NeuronMulti(Neuron):
    """
    Implementation of the Neuron class which stores the computations into memory with variables as a reference.
    """

    def __init__(self, layer: HiddenOutputLayer, position: int, inputs: int, samples: int, manager: Manager) -> None:
        """
        Args:
            layer: Layer in which the neuron is located.
            position: Position of the neuron in this layer.
            inputs: Number of weights to add to the neuron.
            samples: Number of samples in the dataset.
            manager: snoparallel.Manager instance to request the variables with.
        """
        super().__init__(layer=layer, position=position)

        self._x = manager.request_variable(value=zeros(shape=(samples, 1), dtype=NeuronDataType))
        self._y = manager.request_variable(value=zeros(shape=(samples, 1), dtype=NeuronDataType))
        self._y_prime = manager.request_variable(value=zeros(shape=(samples, 1), dtype=NeuronDataType))

        self._weights = manager.request_variable(value=zeros(shape=(inputs, 1), dtype=NeuronDataType))
        self._bias = manager.request_variable(value=NeuronDataType())

        self._randomise(inputs=(inputs, 1))

    @property
    def x(self) -> ndarray:
        return self._x.read()

    @x.setter
    def x(self, value: ndarray) -> None:
        self._x.write(value=value)

    @property
    def y(self) -> ndarray:
        return self._y.read()

    @y.setter
    def y(self, value: ndarray) -> None:
        self._y.write(value=value)

    @property
    def y_prime(self) -> ndarray:
        return self._y_prime.read()

    @y_prime.setter
    def y_prime(self, value: ndarray) -> None:
        self._y_prime.write(value=value)

    @property
    def weights(self) -> ndarray:
        return self._weights.read()

    @weights.setter
    def weights(self, value: ndarray) -> None:
        self._weights.write(value=value)

    @property
    def bias(self) -> NeuronDataType:
        return self._bias.read()

    @bias.setter
    def bias(self, value: NeuronDataType) -> None:
        self._bias.write(value=value)

    def update(self) -> None:
        """
        Update the values in memory.
        """
        self._x.update()
        self._y.update()
        self._y_prime.update()
        self._weights.update()
        self._bias.update()

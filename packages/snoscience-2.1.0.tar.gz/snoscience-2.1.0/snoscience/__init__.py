"""
A package optimised for building small neural networks fast.
"""

from snoscience._interfaces import NeuronDataType
from snoscience.metrics import calculate_accuracy, calculate_mse
from snoscience.networks import SimpleNeuralNetwork

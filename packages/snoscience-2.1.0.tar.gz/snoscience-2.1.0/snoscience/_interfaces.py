"""
This mmodule contains the neural network interfaces.
"""

from abc import ABC, abstractmethod
from typing import Optional

from numpy import (
    arange,
    argmax,
    array,
    float32,
    hstack,
    matmul,
    ndarray,
    random,
    round as numpy_round,
    zeros,
)
from numpy.typing import NDArray

from snoscience._activation import sigmoid, sigmoid_prime
from snoscience._loss import mse_prime

NeuronDataType = float32

SUPPORTED = {"activation": ["sigmoid"], "loss": ["mse"], "optimiser": ["sgd"]}
LOSS = {"mse": mse_prime}


class Neuron(ABC):
    """
    Neuron base class.
    """

    def __init__(self, layer: "HiddenOutputLayer", position: int) -> None:
        """
        Args:
            layer: Layer in which the neuron is located.
            position: Position of the neuron in this layer.
        """
        self._activation = {"sigmoid": {"function": sigmoid, "derivative": sigmoid_prime}}
        self._optimiser = {"sgd": self._sgd}

        self._layer = layer
        self._position = position

        self._total_weights: NDArray[NeuronDataType] = array(object=[], dtype=NeuronDataType)
        self._total_bias = NeuronDataType()

    def _randomise(self, inputs: tuple[int, int]) -> None:
        """
        Randomise the neuron weights and bias values between 0 and 0.01.

        Args:
            inputs: Number of weights to add to the neuron.
        """
        rng = random.default_rng()

        self.weights = 0.01 * rng.random(size=inputs, dtype=NeuronDataType)
        self.bias = NeuronDataType(0.01 * rng.random(size=None))

    def calculate_x(self, previous: NDArray[NeuronDataType]) -> None:
        """
        Calculate the neuron input vector based on the output of the previous layer.

        Args:
            previous: Output from the previous layer.
        """
        self.x = matmul(previous, self.weights) + self.bias

    def calculate_y(self, activation: str) -> None:
        """
        Calculate the neuron output vector based on its current input.

        Args:
            activation: Activation function to be used.
        """
        self.y = self._activation[activation]["function"](x=self.x)

    def calculate_y_prime(self, activation: str) -> None:
        """
        Calculate the neuron output derivative vector based on its current input.

        Args:
            activation: Activation function to be used.
        """
        self.y_prime = self._activation[activation]["derivative"](x=self.x)

    def train(self, optimiser: str, **kwargs) -> None:
        """
        Train the neuron with the given optimiser.

        Args:
            optimiser: Optimiser to train the neuron with.
            kwargs: Optimiser hyperparameters as keyword arguments.
        """
        self._total_weights, self._total_bias = self._layer.calculate_total(neuron=self)
        self._optimiser[optimiser](**kwargs)

    def _sgd(self, rate: NeuronDataType) -> None:
        """
        Train the neuron based on the stochastic gradient descent method.

        Args:
            rate: Learning rate.
        """
        self.bias = self.bias - (rate * self._total_bias)
        self.weights = self.weights - (rate * self._total_weights)

    @property
    def position(self) -> int:
        """
        Get the neuron position in its layer.
        """
        return self._position

    @property
    @abstractmethod
    def x(self) -> NDArray[NeuronDataType]:
        """
        Get the neuron input vector.
        """

    @x.setter
    @abstractmethod
    def x(self, value: NDArray[NeuronDataType]) -> None:
        """
        Set the neuron input vector.
        """

    @property
    @abstractmethod
    def y(self) -> NDArray[NeuronDataType]:
        """
        Get the neuron output vector.
        """

    @y.setter
    @abstractmethod
    def y(self, value: NDArray[NeuronDataType]) -> None:
        """
        Set the neuron output vector.
        """

    @property
    @abstractmethod
    def y_prime(self) -> NDArray[NeuronDataType]:
        """
        Get the neuron output derivative vector.
        """

    @y_prime.setter
    @abstractmethod
    def y_prime(self, value: NDArray[NeuronDataType]) -> None:
        """
        Set the neuron output derivative vector.
        """

    @property
    @abstractmethod
    def weights(self) -> NDArray[NeuronDataType]:
        """
        Get the neuron weights vector.
        """

    @weights.setter
    @abstractmethod
    def weights(self, value: NDArray[NeuronDataType]) -> None:
        """
        Set the neuron weights vector.
        """

    @property
    @abstractmethod
    def bias(self) -> NeuronDataType:
        """
        Get the neuron bias.
        """

    @bias.setter
    @abstractmethod
    def bias(self, value: NeuronDataType) -> None:
        """
        Set the neuron bias.
        """


class InputLossLayer(ABC):
    """
    Layer base class used for input and loss layers.
    """

    def __init__(self) -> None:
        self.previous: Optional[HiddenOutputLayer]
        self.next: Optional[HiddenOutputLayer]

    @property
    @abstractmethod
    def y(self) -> NDArray[NeuronDataType]:
        """
        Get the layer output matrix.
        """

    @y.setter
    @abstractmethod
    def y(self, value: NDArray[NeuronDataType]) -> None:
        """
        Set the layer output matrix.
        """

    @property
    @abstractmethod
    def y_prime(self) -> NDArray[NeuronDataType]:
        """
        Get the layer output matrix.
        """

    @y_prime.setter
    @abstractmethod
    def y_prime(self, value: NDArray[NeuronDataType]) -> None:
        """
        Set the layer output derivative matrix.
        """


class HiddenOutputLayer(ABC):
    """
    Layer base class used for hidden and output layers.
    """

    def __init__(self, activation: str) -> None:
        """
        Args:
            activation: Applied activation functions for neurons in this layer.
        """
        super().__init__()

        self.previous: InputLossLayer | HiddenOutputLayer
        self.next: InputLossLayer | HiddenOutputLayer

        self.activation = activation
        self.neurons: list[Neuron] = []

    @property
    def y(self) -> NDArray[NeuronDataType]:
        """
        Get the layer output matrix.
        """
        return hstack(tup=[neuron.y for neuron in self.neurons])

    @abstractmethod
    def calculate_total(self, neuron: "Neuron") -> tuple[NDArray[NeuronDataType], NeuronDataType]:
        """
        Calculate the total derivative vector for the given neuron.
        """


class NeuralNetwork(ABC):
    """
    Sequential feed-forward neural network consisting of HiddenOutputLayer instances.
    """

    def __init__(self, loss: str = "mse", optimiser: str = "sgd") -> None:
        """
        Args:
            loss: Loss function to use when training the network.
            optimiser: Optimiser to use when training the network.

        Raises:
            ValueError: Loss function is not supported.
            ValueError: Optimiser is not supported.
        """
        if loss not in SUPPORTED["loss"]:
            raise ValueError("Loss function is not supported.")

        if optimiser not in SUPPORTED["optimiser"]:
            raise ValueError("Optimiser is not supported.")

        self._layers: list[HiddenOutputLayer] = []
        self._layers_dict: list[dict] = []

        self._inputs = int()
        self._outputs = int()

        self._loss = LOSS[loss]
        self._optimiser = optimiser
        self._trained = False

    def add_layer(self, neurons: int, activation: str = "sigmoid") -> None:
        """
        Add a layer to the neural network.

        Args:
            neurons: Number of neurons to add to the layer.
            activation: Activation function to use in the layer.

        Raises:
            ValueError: Activation function is not supported.
        """
        if activation not in SUPPORTED["activation"]:
            raise ValueError("Activation function is not supported.")

        self._layers_dict.append({"neurons": neurons, "activation": activation})
        self._trained = False

    @abstractmethod
    def train(self, x: ndarray, y: ndarray, epochs: int, samples: int, **kwargs) -> None:
        """
        Train the neural network with the given parameters.
        """

    @abstractmethod
    def predict(self, x: ndarray, classify: bool) -> ndarray:
        """
        Let the neural network predict the outputs from the given inputs.
        """

    @staticmethod
    def _convert_prediction(regression: ndarray) -> ndarray:
        """
        Convert a floating point regression array into a binary classification array.

        Args:
            regression: Array containing floating point values between 0 and 1.

        Returns:
            Array with one true index per row.

        Examples:
            - [[0.4], [0.5], [0.6]] is converted to [[0], [0], [1]].
            - [[0.1, 0.2, 0.7], [0.4, 0.4, 0.2], [0.3, 0.3, 0.4]] is converted to [[0, 0, 1], [1, 0, 0], [0, 0, 1]].
        """
        if regression.shape[-1] > 1:
            maximums = argmax(regression, axis=1)

            classification = zeros(shape=regression.shape)
            classification[arange(classification.shape[0]), maximums] = 1

        else:
            classification = numpy_round(regression)

        return classification

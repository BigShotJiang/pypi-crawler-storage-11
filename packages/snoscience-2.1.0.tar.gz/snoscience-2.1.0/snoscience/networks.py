"""
This module contains the implementations of the neural network interfaces.
"""

from numpy import ndarray, random

from snoscience._interfaces import NeuralNetwork
from snoscience._layers import RecursiveLayer
from snoscience._neurons import NeuronSimple


class SimpleNeuralNetwork(NeuralNetwork):
    """
    Single-process sequential feed-forward neural network.
    """

    def __init__(self, loss: str = "mse", optimiser: str = "sgd") -> None:
        """
        Args:
            loss: Loss function to use when training the network.
            optimiser: Optimiser to use when training the network.

        Raises:
            ValueError: Loss function is not supported.
            ValueError: Optimiser is not supported.
        """
        super().__init__(loss=loss, optimiser=optimiser)

        self._layers: list[RecursiveLayer] = []  # type: ignore

    def _create_network(self, inputs: int) -> None:
        """
        Create the neural network from the added layers.

        Args:
            inputs: Number of inputs per sample.
        """
        self._inputs = inputs

        for layer_dict in self._layers_dict:
            layer = RecursiveLayer(activation=layer_dict["activation"])

            if self._layers:
                layer.previous = self._layers[-1]
                inputs = len(self._layers[-1].neurons)

            for i in range(layer_dict["neurons"]):
                neuron = NeuronSimple(inputs=inputs, layer=layer, position=i)
                layer.neurons.append(neuron)

            layer.previous.next = layer

            self._layers.append(layer)

        self._outputs = len(self._layers[-1].neurons)

    def train(self, x: ndarray, y: ndarray, epochs: int, samples: int, **kwargs) -> None:
        """
        Train the neural network with the given parameters.

        Args:
            x: Input samples to train the network with.
            y: Output samples to train the network with.
            epochs: Number of training iterations.
            samples: Number of samples taken from the dataset per iteration.
            kwargs: Optimiser hyperparameters as keyword arguments.

        Raises:
            ValueError: Number of samples in the input array do not match with the output array.
            ValueError: No layers are present in the network.
            ValueError: Outputs per sample do not match with the number of neurons in the output layer.
            ValueError: Number of samples per epoch is larger than the dataset.
            KeyError: Hyperparameters required for optimiser are not given as kwargs.
        """
        samples_x, inputs = x.shape
        samples_y, outputs = y.shape

        if not self._trained:
            self._create_network(inputs=inputs)

        if samples_x != samples_y:
            raise ValueError("Number of samples in the input array do not match with the output array.")
        if not self._layers:
            raise ValueError("No layers are present in the network.")
        if outputs != self._outputs:
            raise ValueError("Outputs per sample do not match with the number of neurons in the output layer.")
        if samples > len(x):
            raise ValueError("Number of samples per epoch is larger than the dataset.")
        if self._optimiser == "sgd" and "rate" not in kwargs:
            raise KeyError("Hyperparameters required for optimiser are not given as kwargs.")

        for _ in range(epochs):
            section = random.choice(len(x), size=samples, replace=False)
            section_x = x[section, :]
            section_y = y[section, :]

            self._set_input_layer(x=section_x)

            for layer in self._layers:
                for neuron in layer.neurons:
                    neuron.calculate_x(previous=layer.previous.y)

                for neuron in layer.neurons:
                    neuron.calculate_y(activation=layer.activation)
                    neuron.calculate_y_prime(activation=layer.activation)

            self._set_loss_layer(y=section_y)

            for layer in self._layers:
                for neuron in layer.neurons:
                    neuron.train(optimiser=self._optimiser, **kwargs)

        self._trained = True

    def _get_output_layer(self) -> ndarray:
        """
        Get the output from the output layer.

        Returns:
            Outputs from the network.
        """
        return self._layers[-1].y

    def _set_input_layer(self, x: ndarray) -> None:
        """
        Set the output for the input layer.

        Args:
            x: Inputs for the network.
        """
        input_layer = self._layers[0].previous
        input_layer.y = x  # type: ignore

    def _set_loss_layer(self, y: ndarray) -> None:
        """
        Set the output derivative for the loss layer.

        Args:
            y: Output samples to train the network with.
        """
        loss_layer = self._layers[-1].next
        loss_layer.y_prime = self._loss(calc=self._get_output_layer(), true=y)  # type: ignore

    def predict(self, x: ndarray, classify: bool) -> ndarray:
        """
        Let the neural network predict the outputs from the given inputs.

        Args:
            x: Inputs for the network.
            classify: Create classification from output layer, otherwise keep regression.

        Returns:
            Predictions from the network.

        Raises:
            ValueError: Size of the input array does not match with the network inputs.
            ValueError: No layers are present in the network.
            ValueError: Network is not trained.
        """
        if x.shape[-1] != self._inputs:
            raise ValueError("Size of the input array does not match with the network inputs.")
        if not self._layers:
            raise ValueError("No layers are present in the network.")
        if not self._trained:
            raise ValueError("Network is not trained.")

        self._set_input_layer(x=x)

        for layer in self._layers:
            for neuron in layer.neurons:
                neuron.calculate_x(previous=layer.previous.y)

            for neuron in layer.neurons:
                neuron.calculate_y(activation=layer.activation)

        regression = self._get_output_layer()

        if classify:
            return self._convert_prediction(regression=regression)

        return regression

Display facts about cats.

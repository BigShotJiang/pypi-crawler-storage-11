"""
Custom utility endpoint in a subdirectory structure.
"""
from fastapi import Request


async def handler(request: Request):
    """
    Example of a deeply nested API endpoint.
    This demonstrates that any Python file in the app structure
    can be used as an API endpoint.
    """
    
    return {
        "message": "This is a custom utility endpoint",
        "path": "dashboard-app/utils/helpers/custom",
        "note": "Any Python file with a handler() function can be an API endpoint!",
        "request_method": request.method,
        "url": str(request.url)
    }

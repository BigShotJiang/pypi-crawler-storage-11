"""
Statistics API endpoint for dashboard-app.
"""
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from typing import Dict, Any, Optional
from datetime import datetime

# Import Aurica Auth SDK
try:
    from src.aurica_auth import protected, public, optional, get_current_user
except ImportError:
    # Fallback if running in different context
    print("⚠️  Warning: Could not import aurica_auth SDK")
    def protected(func):
        return func
    def public(func):
        return func
    def optional(func):
        return func
    def get_current_user(request, required=True):
        return type('User', (), {"username": "unknown", "user_id": "unknown", "email": None, "token_type": "unknown"})()


router = APIRouter()


class Stats(BaseModel):
    """Statistics model."""
    total_users: int
    active_sessions: int
    total_requests: int
    success_rate: str


class StatsResponse(BaseModel):
    """Statistics response model."""
    stats: Stats
    timestamp: str


@router.get("/", response_model=StatsResponse, summary="Get dashboard statistics", tags=["dashboard"])
@protected
async def get_stats(request: Request):
    """
    Retrieve current dashboard statistics.
    Requires authentication - automatically validated by @protected decorator.
    
    Returns:
        StatsResponse with current system statistics including user info
    """
    # Get the authenticated user (guaranteed to exist because of @protected)
    user = get_current_user(request)
    
    print(f"📊 Dashboard stats requested by user: {user.username} (ID: {user.user_id})")
    
    # TODO: Replace with actual data sources when available:
    # - User database for total_users
    # - Session manager for active_sessions
    # - Analytics/logging system for total_requests
    # - Monitoring system for success_rate
    
    # Return sample statistics for now
    stats = Stats(
        total_users=42,
        active_sessions=7,
        total_requests=15234,
        success_rate="98.5%"
    )
    
    return StatsResponse(
        stats=stats,
        timestamp=datetime.utcnow().isoformat()
    )


@router.get("/public-info", summary="Get public dashboard info (no auth required)", tags=["dashboard"])
@public
async def get_public_info():
    """
    Get public information about the dashboard.
    This endpoint does NOT require authentication.
    
    Returns:
        Public information about the dashboard
    """
    return {
        "app_name": "Dashboard App",
        "version": "1.0.13",
        "description": "Analytics and statistics dashboard",
        "features": ["stats", "analytics", "reporting"],
        "auth_required": False
    }


@router.get("/personalized-info", summary="Get personalized dashboard info (optional auth)", tags=["dashboard"])
@optional
async def get_personalized_info(request: Request):
    """
    Get dashboard information, personalized if user is authenticated.
    Authentication is optional - works for both authenticated and anonymous users.
    
    Returns:
        Dashboard info, personalized if user is logged in
    """
    user = get_current_user(request, required=False)
    
    if user:
        return {
            "message": f"Welcome back, {user.username}!",
            "user_id": user.user_id,
            "personalized": True,
            "recent_activity": "You viewed 5 dashboards this week",
            "recommendations": ["Sales Report", "User Growth", "Revenue Analysis"]
        }
    else:
        return {
            "message": "Welcome to the dashboard!",
            "personalized": False,
            "hint": "Login to see personalized recommendations"
        }


@router.get("/user-profile", summary="Get current user profile", tags=["dashboard"])
@protected
async def get_user_profile(request: Request):
    """
    Get the current user's profile information.
    Requires authentication - demonstrates easy access to user info.
    
    Returns:
        Current user's profile
    """
    user = get_current_user(request)
    
    return {
        "user_id": user.user_id,
        "username": user.username,
        "email": user.email or 'N/A',
        "auth_type": user.token_type,
        "profile_complete": True,
        "last_login": datetime.utcnow().isoformat()
    }

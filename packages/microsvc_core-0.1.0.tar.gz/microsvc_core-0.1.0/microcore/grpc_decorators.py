"""
gRPC 调用装饰器

提供通用的 gRPC 调用装饰器，消除重复代码
"""

import grpc
from functools import wraps
from typing import Callable, Optional, Any, Type, get_origin, get_args
from loguru import logger
from pydantic import BaseModel


def grpc_call(
    service_name: str,
    stub_class: type,
    method_name: str,
    response_model: Optional[Type[BaseModel]] = None,
    timeout: int = 5
):
    """
    gRPC 调用装饰器
    
    Args:
        service_name: 服务名称，如 "system-service"
        stub_class: gRPC Stub 类
        method_name: gRPC 方法名
        response_model: Pydantic 模型类，用于自动解析响应
        timeout: 超时时间（秒）
    
    Returns:
        装饰器函数
    
    Example:
        @classmethod
        @grpc_call("system-service", SystemServiceStub, "GetUser", response_model=UserVo)
        def get_by_id(cls, user_id: int):
            return system_pb2.GetUserRequest(user_id=user_id)
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*wrapper_args, **wrapper_kwargs) -> Optional[Any]:
            try:
                # 1. 提取 cls 参数（类方法的第一个参数）
                cls = wrapper_args[0]
                method_args = wrapper_args[1:]
                
                # 2. 获取 gRPC 客户端
                client = cls._get_client()
                
                # 3. 创建 stub
                stub = stub_class(client.channel)
                
                # 4. 调用原函数获取 request
                request = func(cls, *method_args, **wrapper_kwargs)
                
                # 5. 执行 gRPC 调用
                grpc_method = getattr(stub, method_name)
                response = grpc_method(request, timeout=timeout)
                
                # 6. 处理响应
                if hasattr(response, 'code') and response.code == 200:
                    logger.debug(f"{method_name} 调用成功")
                    
                    # 如果指定了 response_model，自动转换
                    if response_model:
                        return _parse_response_with_model(response, response_model, method_name)
                    else:
                        # 没有指定模型，返回原始响应
                        return response
                else:
                    message = getattr(response, 'message', '未知错误')
                    logger.warning(f"{method_name} 失败: {message}")
                    return None
                    
            except grpc.RpcError as e:
                logger.error(f"gRPC 调用失败 [{method_name}]: {e.code()}, {e.details()}")
                return None
            except Exception as e:
                logger.error(f"{method_name} 异常: {e}")
                return None
        
        return wrapper
    return decorator


def _parse_response_with_model(response, response_model: Type[BaseModel], method_name: str) -> Any:
    """
    使用 Pydantic 模型解析响应
    
    Args:
        response: gRPC 响应对象
        response_model: Pydantic 模型类或 List[模型类]
        method_name: 方法名（用于日志）
    
    Returns:
        Pydantic 模型实例或模型列表
    """
    try:
        # 检查是否是 List[Model] 类型
        origin = get_origin(response_model)
        if origin is list:
            # 获取列表中的模型类型
            args = get_args(response_model)
            if args:
                item_model = args[0]
                # 查找响应中的列表字段
                data_list = _extract_list_from_response(response, method_name)
                if data_list is not None:
                    return [item_model.model_validate(item, from_attributes=True) for item in data_list]
            return []
        else:
            # 单个对象
            data_obj = _extract_object_from_response(response, method_name)
            if data_obj is not None:
                return response_model.model_validate(data_obj, from_attributes=True)
            return None
            
    except Exception as e:
        logger.error(f"解析响应失败 [{method_name}]: {e}")
        return None


def _extract_object_from_response(response, method_name: str):
    """
    从响应中提取单个对象
    
    常见的字段名: user, member, data, result 等
    """
    # 尝试常见的字段名
    for field_name in ['user', 'member', 'data', 'result', 'item']:
        if hasattr(response, field_name):
            return getattr(response, field_name)
    
    # 如果没有找到，记录警告并返回响应本身
    logger.warning(f"[{method_name}] 未找到数据字段，返回响应本身")
    return response


def _extract_list_from_response(response, method_name: str):
    """
    从响应中提取列表
    
    常见的字段名: users, members, data, results, items, list 等
    """
    # 尝试常见的列表字段名
    for field_name in ['users', 'members', 'data', 'results', 'items', 'list']:
        if hasattr(response, field_name):
            return getattr(response, field_name)
    
    # 如果没有找到，记录警告
    logger.warning(f"[{method_name}] 未找到列表字段")
    return None

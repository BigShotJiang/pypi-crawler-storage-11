"""
通用工具模块

提供IP获取、地址解析等工具函数。
"""

import socket



def get_local_ip() -> str:
    """
    获取本机IP地址，支持fallback到127.0.0.1

    Returns:
        str: 本机IP地址
    """
    try:
        # 尝试连接外部地址来获取本机IP
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            return ip
    except (OSError, socket.error):
        try:
            # 备用方案：获取主机名对应的IP
            hostname = socket.gethostname()
            ip = socket.gethostbyname(hostname)
            # 如果获取到的是127.0.0.1，尝试其他方法
            if ip.startswith("127."):
                # 获取所有网络接口IP
                for interface in [socket.gethostbyname_ex(host)[2]
                                  for host in socket.gethostbyname_ex(socket.gethostname())[2]]:
                    for addr in interface:
                        if not addr.startswith("127.") and not addr.startswith("169.254."):
                            return addr
                return "127.0.0.1"
            return ip
        except (OSError, socket.error):
            return "127.0.0.1"


def is_valid_port(port: int) -> bool:
    """
    检查端口号是否有效

    Args:
        port: 端口号

    Returns:
        bool: 是否有效
    """
    return 1 <= port <= 65535


def is_valid_ip(ip: str) -> bool:
    """
    检查IP地址是否有效

    Args:
        ip: IP地址

    Returns:
        bool: 是否有效
    """
    try:
        socket.inet_aton(ip)
        return True
    except socket.error:
        return False


def resolve_address(address: str) -> tuple[str, int]:
    """
    解析地址字符串为IP和端口

    Args:
        address: 地址字符串，格式为 "ip:port"

    Returns:
        tuple[str, int]: (ip, port)
    """
    if ":" not in address:
        raise ValueError(f"无效地址格式: {address}, 期望格式: ip:port")

    ip, port_str = address.rsplit(":", 1)

    try:
        port = int(port_str)
    except ValueError:
        raise ValueError(f"无效端口号: {port_str}")

    if not is_valid_ip(ip):
        raise ValueError(f"无效IP地址: {ip}")

    if not is_valid_port(port):
        raise ValueError(f"端口号超出范围: {port}")

    return ip, port

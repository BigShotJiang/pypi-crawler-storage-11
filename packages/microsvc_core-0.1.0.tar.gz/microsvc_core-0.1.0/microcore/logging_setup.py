"""
日志配置模块（Loguru 版本）

提供统一的日志配置和输出。
"""

import logging
import sys
from loguru import logger


class InterceptHandler(logging.Handler):
    """将 Python 标准日志重定向到 Loguru"""

    def emit(self, record: logging.LogRecord):
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno
        # 定位原始调用位置
        frame, depth = logging.currentframe(), 2
        while frame and frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back  # type: ignore
            depth += 1
        logger.opt(depth=depth, exception=record.exc_info).log(
            level, record.getMessage()
        )


def setup_logging(log_level: str = "DEBUG", log_file: str = "logs/app.log") -> None:
    """
    配置 Loguru 日志系统

    Args:
        log_file: 日志文件路径，默认 'app.log'
        log_level:
    """
    # 移除 Loguru 默认处理器
    logger.remove()

    # 定义日志输出格式
    log_format = (
        "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
        "<level>{level: <8}</level> | "
        "<cyan>{module}</cyan>.<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
        "<level>{message}</level>"
    )

    # 输出到控制台
    logger.add(sys.stdout, format=log_format, level="DEBUG")

    # 输出到日志文件（每天轮转 + 压缩）
    logger.add(
        log_file,
        format=log_format,
        level=log_level,
        rotation="00:00",  # 每天午夜轮转
        retention="7 days",  # 保留7天
        compression="zip",  # 压缩旧日志
        encoding="utf-8",
        enqueue=True,  # 异步写入，防止 I/O 阻塞
    )

    # 接管标准库日志
    logging.basicConfig(handlers=[InterceptHandler()], level=0, force=True)

    # 接管 Uvicorn / FastAPI 内部日志
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access", "fastapi"):
        lib_logger = logging.getLogger(name)
        lib_logger.handlers = [InterceptHandler()]
        lib_logger.propagate = False


def get_logger(name: str = None):
    """
    获取 Loguru 日志记录器

    Args:
        name: 模块名或日志名称（可选）

    Returns:
        logger: Loguru 日志对象
    """
    if name:
        return logger.bind(module=name)
    return logger

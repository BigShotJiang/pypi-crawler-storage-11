
"""
微服务应用服务管理器

提供统一的服务启动、注册、生命周期管理等功能。
支持FastAPI和gRPC在同一进程中并发运行。
"""

import asyncio
import signal
from typing import Optional, Type
from datetime import datetime
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI
from colorama import Fore, Style

from microcore.config import MicroCoreConfig
from microcore.config_loader import ConfigLoader
from microcore.nacos_registrar import NacosRegistrar
from microcore.grpc_server import GrpcServerBase
from microcore.logging_setup import setup_logging, get_logger

logger = get_logger(__name__)

class AppService:
    """
    微服务应用服务管理器
    
    提供统一的服务启动、注册、生命周期管理等功能。
    支持FastAPI和gRPC在同一进程中并发运行。
    """

    def __init__(
        self,
        fastapi_app: FastAPI,
        grpc_server: Optional[GrpcServerBase] = None,
        config: Optional[MicroCoreConfig] = None,
        config_class: Type[MicroCoreConfig] = MicroCoreConfig  # 新增参数,用于注入自定义配置类
    ):
        """
        初始化应用服务管理器
        
        Args:
            fastapi_app: FastAPI应用实例
            grpc_server: gRPC服务器实例 (可选)
            config: 配置对象 (可选,不提供则自动加载)
            config_class: 用于解析配置的Pydantic模型类 (可选)
        """
        self.fastapi_app = fastapi_app
        self.grpc_server = grpc_server
        self.config = config
        # 将config_class传递给ConfigLoader
        self.config_loader = ConfigLoader(config_class=config_class)
        self.nacos_registrar: Optional[NacosRegistrar] = None
        self._shutdown_event = asyncio.Event()
        self._uvicorn_server: Optional[uvicorn.Server] = None

    async def initialize(self):
        """初始化服务"""
        try:
            # 1. 加载配置
            if not self.config:
                logger.info("📋 开始加载配置...")
                self.config = await self.config_loader.load_config()
            
            # 2. 设置日志
            setup_logging(self.config.app.logLevel)
            
            # 3. 将配置保存到 FastAPI state 中，供路由使用
            if hasattr(self.fastapi_app, 'state'):
                # 使用 model_dump() 以确保所有嵌套模型都被正确转换为字典
                self.fastapi_app.state.config = self.config
            
            # 4. 初始化 Nacos 注册器
            if self.config.nacos.host:
                self.nacos_registrar = NacosRegistrar(self.config)
            
            logger.info("✅ 服务初始化完成")
            
        except Exception as e:
            logger.error(f"服务初始化失败: {e}")
            raise

    async def start(self):
        """启动服务"""
        try:
            # 1. 初始化
            await self.initialize()
            
            # 2. 注册到 Nacos
            if self.nacos_registrar:
                try:
                    await self.nacos_registrar.register_instance()
                except Exception as e:
                    logger.warning(f"Nacos服务注册失败: {e}, 继续启动服务")
            
            # 3. 启动配置监听 (热更新)
            if self.config_loader.nacos_config_manager:
                await self.config_loader.start_watch()
            
            # 4. 注册信号处理
            self._register_signal_handlers()
            
            # 5. 打印启动成功信息
            self._print_startup_banner()
            
            # 6. 并发启动 FastAPI + gRPC
            await self._start_servers()
            
        except Exception as e:
            logger.error(f"服务启动失败: {e}")
            await self.shutdown()
            raise

    async def _start_servers(self):
        """并发启动 FastAPI 和 gRPC 服务器"""
        tasks = []
        
        # 启动 FastAPI
        fastapi_task = asyncio.create_task(self._run_fastapi())
        tasks.append(fastapi_task)
        
        # 启动 gRPC (如果配置了)
        if self.grpc_server:
            grpc_task = asyncio.create_task(self._run_grpc())
            tasks.append(grpc_task)
        
        # 等待关闭信号
        shutdown_task = asyncio.create_task(self._shutdown_event.wait())
        tasks.append(shutdown_task)
        
        # 等待任意任务完成
        done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        
        # 取消其他任务
        for task in pending:
            task.cancel()
        
        # 优雅关闭
        await self.shutdown()

    async def _run_fastapi(self):
        """运行 FastAPI 服务器"""
        try:
            config = uvicorn.Config(
                self.fastapi_app,
                host="0.0.0.0",
                port=self.config.server.servicePort,
                log_config=None,  # 使用自定义日志
                loop="asyncio"
            )
            self._uvicorn_server = uvicorn.Server(config)
            await self._uvicorn_server.serve()
        except asyncio.CancelledError:
            logger.info("FastAPI服务器任务已取消")
        except Exception as e:
            logger.error(f"FastAPI服务器异常: {e}")
            self._shutdown_event.set()

    async def _run_grpc(self):
        """运行 gRPC 服务器"""
        try:
            await self.grpc_server.start()
            await self.grpc_server.wait_for_termination()
        except asyncio.CancelledError:
            logger.info("gRPC服务器任务已取消")
        except Exception as e:
            logger.error(f"gRPC服务器异常: {e}")
            self._shutdown_event.set()

    def _register_signal_handlers(self):
        """注册信号处理器"""
        def handle_signal(signum, _frame):
            logger.info(f"收到信号 {signum}, 开始优雅关闭...")
            self._shutdown_event.set()
        
        signal.signal(signal.SIGINT, handle_signal)
        signal.signal(signal.SIGTERM, handle_signal)

    async def shutdown(self):
        """优雅关闭"""
        logger.info("🛑 开始关闭服务...")
        
        try:
            # 1. 从 Nacos 注销
            if self.nacos_registrar:
                await self.nacos_registrar.deregister_instance()
            
            # 2. 停止 gRPC 服务器
            if self.grpc_server:
                await self.grpc_server.stop(grace_period=10)
            
            # 3. 停止 FastAPI 服务器
            if self._uvicorn_server:
                self._uvicorn_server.should_exit = True
            
            # 4. 关闭配置加载器
            if self.config_loader:
                await self.config_loader.shutdown()
            
            logger.info("✅ 服务已关闭")
            
        except Exception as e:
            logger.error(f"关闭服务时出错: {e}")

    def _print_startup_banner(self):
        """打印启动成功信息"""
        start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        print(Fore.GREEN + "─────────────────────────────────────────────")
        print(Fore.CYAN + f"🚀 {self.config.app.name} 启动成功！")
        print(Fore.YELLOW + "─────────────────────────────────────────────")
        print(f"🧩 环境：{self.config.app.env}")
        print(f"🌐 HTTP服务：{self.config.server.ip}:{self.config.server.servicePort}")
        print(f"📚 API文档：http://{self.config.server.ip}:{self.config.server.servicePort}/docs")
        
        if self.grpc_server:
            print(f"⚡ gRPC服务：{self.config.server.ip}:{self.config.server.grpcPort}")
        
        if self.config.nacos.host:
            print(f"📦 注册中心：{self.config.nacos.host}:{self.config.nacos.port}")
        
        print(f"🕒 启动时间：{start_time}")
        print(Fore.GREEN + "─────────────────────────────────────────────" + Style.RESET_ALL)


# create_lifespan 已不再需要, AppService的启动逻辑已经简化
# 保留一个空函数或者直接移除,取决于是否还有其他地方依赖它
# 为了安全起见,暂时保留一个空实现
def create_lifespan(*args, **kwargs):
    """此函数已废弃,请直接使用AppService().start()"""
    logger.warning("create_lifespan 已废弃,请直接使用 AppService().start() 来启动服务")
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        logger.info("Lifespan 启动")
        yield
        logger.info("Lifespan 关闭")
    return lifespan

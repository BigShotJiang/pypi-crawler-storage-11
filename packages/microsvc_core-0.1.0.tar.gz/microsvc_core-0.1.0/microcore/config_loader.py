
"""
配置加载器

支持多层配置加载和合并,实现配置优先级机制。
优先级: 环境变量 > Nacos配置中心 > 本地YAML文件
"""

import os
import yaml
from pathlib import Path
from typing import Optional, Callable, List, Type, TypeVar
import __main__

from microcore.config import MicroCoreConfig
from microcore.nacos_config_manager import NacosConfigManager
from microcore.utils import get_local_ip
from microcore.logging_setup import get_logger

logger = get_logger(__name__)

# 定义一个类型变量,它必须是MicroCoreConfig或其子类
T = TypeVar('T', bound=MicroCoreConfig)

class ConfigLoadError(Exception):
    """配置加载异常"""
    pass

class ConfigLoader:
    """
    配置加载器
    
    支持多层配置加载和合并:
    1. 加载本地 YAML 文件 (基础配置)
    2. 从 Nacos 配置中心拉取配置 (覆盖本地配置)
    3. 读取环境变量 (最终覆盖)
    
    支持配置热更新和变更监听。
    """

    def __init__(self, config_class: Type[T] = MicroCoreConfig):
        """
        初始化配置加载器
        
        Args:
            config_class: 用于解析配置的Pydantic模型类,默认为MicroCoreConfig
        """
        self.config_model: Type[T] = config_class
        self.config: Optional[T] = None
        self.nacos_config_manager: Optional[NacosConfigManager] = None
        self.config_change_listeners: List[Callable] = []  # 配置变更监听器

    async def load_config(self) -> T:
        """
        加载配置 (按优先级)
        
        Returns:
            加载后的配置对象
        """
        try:
            # 1. 加载本地 YAML 配置
            logger.info("📄 加载本地YAML配置...")
            config = self._load_yaml_config()
            
            # 2. 从 Nacos 拉取配置并合并
            if config.nacos.host:
                logger.info("☁️  从Nacos配置中心拉取配置...")
                nacos_config_dict = await self._load_nacos_config(config)
                if nacos_config_dict:
                    config = self._merge_config(config, nacos_config_dict)
                    logger.info("✅ Nacos配置合并成功")
            
            # 3. 环境变量覆盖
            logger.info("🔧 应用环境变量覆盖...")
            config = self._apply_env_overrides(config)
            
            # 4. 后处理
            config = self._post_process_config(config)
            
            self.config = config
            logger.info("✅ 配置加载完成")
            return config
            
        except Exception as e:
            logger.error(f"配置加载失败: {e}")
            raise ConfigLoadError(f"配置加载失败: {e}")

    def _load_yaml_config(self) -> T:
        """
        加载本地 YAML 配置文件
        
        Returns:
            配置对象
        """
        env = os.getenv("APP_ENV", "dev").lower()

        # 获取当前执行脚本路径
        main_path = Path(os.path.abspath(__main__.__file__))
        service_root = main_path.parent

        # 拼接配置文件路径
        config_path = service_root / "config" / f"config_{env}.yaml"

        if not config_path.exists():
            raise ConfigLoadError(f"配置文件不存在: {config_path}")

        with open(config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        # 使用传入的config_model进行解析
        config = self.config_model(**data)
        logger.info(f"本地配置加载成功: {config_path}")
        return config

    async def _load_nacos_config(self, base_config: T) -> Optional[dict]:
        """
        从 Nacos 配置中心拉取配置
        
        Args:
            base_config: 基础配置 (用于连接Nacos)
            
        Returns:
            Nacos配置字典,失败返回None
        """
        try:
            # 初始化 Nacos 配置管理器
            from v2.nacos import ClientConfigBuilder
            
            client_config = (
                ClientConfigBuilder()
                .username(base_config.nacos.username)
                .password(base_config.nacos.password)
                .server_address(f'{base_config.nacos.host}:{base_config.nacos.port}')
                .namespace_id(base_config.nacos.namespace if base_config.nacos.namespace else "public")
                .log_level('INFO')
                .build()
            )
            
            self.nacos_config_manager = NacosConfigManager(client_config)
            success = await self.nacos_config_manager.initialize()
            if not success:
                logger.warning("使用本地配置")
                return None
            
            # 拉取配置 (使用服务名作为 data_id)
            data_id = base_config.app.name
            group = base_config.nacos.groupName
            
            content = await self.nacos_config_manager.get_config(
                data_id=data_id,
                group=group
            )
            
            if content:
                # 解析 YAML 配置
                nacos_config = yaml.safe_load(content)
                logger.info(f"Nacos配置拉取成功: data_id={data_id}, group={group}")
                return nacos_config
            else:
                logger.warning(f"Nacos配置不存在: data_id={data_id}, group={group}")
                return None
                
        except Exception as e:
            logger.error(f"从Nacos拉取配置失败: {e}")
            return None

    def _merge_config(self, base: T, override: dict) -> T:
        """
        合并配置 (深度合并)
        
        Args:
            base: 基础配置对象
            override: 覆盖配置字典
            
        Returns:
            合并后的配置对象
        """
        # 将基础配置转为字典
        base_dict = base.model_dump()
        
        # 深度合并
        merged_dict = self._deep_merge(base_dict, override)
        
        # 转回配置对象
        return self.config_model(**merged_dict)

    def _deep_merge(self, base: dict, override: dict) -> dict:
        """
        深度合并字典
        
        Args:
            base: 基础字典
            override: 覆盖字典
            
        Returns:
            合并后的字典
        """
        result = base.copy()
        
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                # 递归合并嵌套字典
                result[key] = self._deep_merge(result[key], value)
            else:
                # 直接覆盖
                result[key] = value
        
        return result

    def _apply_env_overrides(self, config: T) -> T:
        """
        应用环境变量覆盖
        
        支持的环境变量:
        - APP_NAME, APP_ENV, APP_LOG_LEVEL
        - SERVICE_PORT, GRPC_PORT, SERVER_IP
        - NACOS_HOST, NACOS_PORT, NACOS_NAMESPACE, NACOS_USERNAME, NACOS_PASSWORD
        - DATABASE_URL
        
        Args:
            config: 配置对象
            
        Returns:
            应用环境变量后的配置对象
        """
        # App 配置
        if os.getenv("APP_NAME"):
            config.app.name = os.getenv("APP_NAME")
        if os.getenv("APP_ENV"):
            config.app.env = os.getenv("APP_ENV")
        if os.getenv("APP_LOG_LEVEL"):
            config.app.logLevel = os.getenv("APP_LOG_LEVEL")

        # Server 配置
        if os.getenv("SERVER_IP"):
            config.server.ip = os.getenv("SERVER_IP")
        if os.getenv("SERVICE_PORT"):
            config.server.servicePort = int(os.getenv("SERVICE_PORT"))
        if os.getenv("GRPC_PORT"):
            config.server.grpcPort = int(os.getenv("GRPC_PORT"))

        # Nacos 配置
        if os.getenv("NACOS_HOST"):
            config.nacos.host = os.getenv("NACOS_HOST")
        if os.getenv("NACOS_PORT"):
            config.nacos.port = int(os.getenv("NACOS_PORT"))
        if os.getenv("NACOS_NAMESPACE"):
            config.nacos.namespace = os.getenv("NACOS_NAMESPACE")
        if os.getenv("NACOS_USERNAME"):
            config.nacos.username = os.getenv("NACOS_USERNAME")
        if os.getenv("NACOS_PASSWORD"):
            config.nacos.password = os.getenv("NACOS_PASSWORD")

        # Database 配置
        if os.getenv("DATABASE_URL"):
            config.database.url = os.getenv("DATABASE_URL")

        return config

    def _post_process_config(self, config: T) -> T:
        """
        配置后处理
        
        Args:
            config: 配置对象
            
        Returns:
            处理后的配置对象
        """
        # 自动获取本机IP
        if not config.server.ip:
            config.server.ip = get_local_ip()
            logger.info(f"自动获取本机IP: {config.server.ip}")

        return config

    async def start_watch(self):
        """
        启动配置监听 (热更新)
        
        监听Nacos配置变更,自动重新加载配置并通知监听器。
        """
        if not self.nacos_config_manager or not self.config:
            logger.warning("Nacos配置管理器未初始化,无法启动配置监听")
            return

        try:
            data_id = self.config.app.name
            group = self.config.nacos.groupName
            
            await self.nacos_config_manager.add_listener(
                data_id=data_id,
                group=group,
                listener=self._on_config_change
            )
            
            logger.info(f"✅ 配置监听已启动: data_id={data_id}, group={group}")
            
        except Exception as e:
            logger.error(f"启动配置监听失败: {e}")

    async def _on_config_change(self, tenant: str, data_id: str, group: str, content: str):
        """
        配置变更回调
        
        Args:
            tenant: 租户ID
            data_id: 配置ID
            group: 配置组
            content: 新配置内容
        """
        logger.info(f"🔄 检测到配置变更: data_id={data_id}, group={group}")
        
        try:
            # 重新加载配置
            new_config = await self.load_config()
            
            # 通知所有监听器
            for listener in self.config_change_listeners:
                try:
                    await listener(new_config)
                except Exception as e:
                    logger.error(f"配置变更监听器执行失败: {e}")
            
            logger.info("✅ 配置热更新完成")
            
        except Exception as e:
            logger.error(f"配置热更新失败: {e}")

    def add_config_change_listener(self, listener: Callable):
        """
        添加配置变更监听器
        
        Args:
            listener: 监听器函数 (new_config) -> None
        """
        self.config_change_listeners.append(listener)

    async def shutdown(self):
        """关闭配置加载器"""
        if self.nacos_config_manager:
            await self.nacos_config_manager.shutdown()

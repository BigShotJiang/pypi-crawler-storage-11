"""
Base gRPC Client

提供 gRPC 客户端的基类，封装客户端创建、连接管理、连接池等通用逻辑
"""

from typing import Dict, ClassVar
from loguru import logger

from microcore.grpc_client import GrpcClientBase
from microcore.service_registry import ServiceRegistry


class BaseGrpcClient:
    """
    gRPC 客户端基类
    
    封装了客户端创建、连接管理、连接池等通用逻辑，避免在每个客户端类中重复编写
    
    使用方式:
        class SystemUserServiceGrpc(BaseGrpcClient):
            _service_name = "system-service"  # 设置服务名
            
            @classmethod
            @grpc_call(...)
            def get_by_id(cls, user_id: int):
                return system_pb2.GetUserRequest(user_id=user_id)
    
    特性:
        - 自动管理客户端连接池
        - 自动从服务注册表获取服务配置
        - 支持多个服务地址的连接复用
        - 提供统一的连接关闭方法
    """
    
    # 类级别的连接池，所有子类共享
    _client_pool: ClassVar[Dict[str, GrpcClientBase]] = {}
    
    # 服务名称，子类必须设置
    _service_name: ClassVar[str] = ""
    
    @classmethod
    def _get_client(cls) -> GrpcClientBase:
        """
        获取或创建 gRPC 客户端
        
        从服务注册表获取服务配置，创建或复用客户端连接
        
        Returns:
            GrpcClientBase: gRPC 客户端实例
            
        Raises:
            ValueError: 如果子类未设置 _service_name
        """
        if not cls._service_name:
            raise ValueError(f"{cls.__name__} 必须设置 _service_name 类属性")
        
        # 从服务注册表获取服务配置
        service_config = ServiceRegistry.get_service_config(cls._service_name)
        host = service_config.get('host', 'localhost')
        port = service_config.get('grpc_port', 9002)
        
        # 使用 host:port 作为连接池的 key
        key = f"{host}:{port}"
        
        # 如果连接池中没有该连接，则创建新连接
        if key not in cls._client_pool:
            client = GrpcClientBase(host=host, port=port, timeout=5)
            client.connect()
            cls._client_pool[key] = client
            logger.debug(f"创建 {cls._service_name} gRPC 客户端: {key}")
        
        return cls._client_pool[key]
    
    @classmethod
    def close_all(cls):
        """
        关闭所有客户端连接
        
        遍历连接池，关闭所有客户端连接并清空连接池
        通常在应用关闭时调用
        """
        for key, client in cls._client_pool.items():
            try:
                client.close()
                logger.debug(f"关闭 gRPC 客户端: {key}")
            except Exception as e:
                logger.error(f"关闭客户端 {key} 失败: {e}")
        
        cls._client_pool.clear()
        logger.info("所有 gRPC 客户端连接已关闭")

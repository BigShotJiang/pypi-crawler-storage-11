"""
MicroCore - Python微服务框架核心库

提供微服务开发的核心功能:
- 配置管理 (支持多环境、Nacos集成、热更新)
- 服务生命周期管理 (FastAPI + gRPC 双协议支持)
- 服务注册与发现 (Nacos集成)
- gRPC客户端/服务端基类
- 日志管理
"""

__version__ = "0.1.0"
__author__ = "Your Team"

from microcore.config import MicroCoreConfig, AppConfig, ServerConfig, NacosConfig, DatabaseConfig
from microcore.config_loader import ConfigLoader
from microcore.app_service import AppService
from microcore.grpc_server import GrpcServerBase
from microcore.base_grpc_client import BaseGrpcClient
from microcore.service_registry import ServiceRegistry
from microcore.logging_setup import setup_logging, get_logger

__all__ = [
    "MicroCoreConfig",
    "AppConfig",
    "ServerConfig",
    "NacosConfig",
    "DatabaseConfig",
    "ConfigLoader",
    "AppService",
    "GrpcServerBase",
    "BaseGrpcClient",
    "ServiceRegistry",
    "setup_logging",
    "get_logger",
]

import json
import os
from pathlib import Path
from typing import Optional, Dict, Any

from pydantic import Field, BaseModel, ConfigDict

from pydantic_settings import BaseSettings
import yaml
import __main__

from microcore.utils import get_local_ip


class AppConfig(BaseModel):
    name: str = Field(..., description="应用名称")
    env: str = Field(..., description="运行环境")
    logLevel: str = Field(default="INFO", description="日志级别")


class ServerConfig(BaseModel):
    ip: str = Field(default="", description="服务IP")
    servicePort: int = Field(..., description="服务端口")
    grpcPort: int = Field(..., description="gRPC端口")


class NacosConfig(BaseModel):
    host: Optional[str] = Field(default="127.0.0.1", description="Nacos服务地址")
    port: Optional[int] = Field(default=8848, description="Nacos服务端口")
    groupName: Optional[str] = Field(default="DEFAULT_GROUP", description="Nacos服务组名")
    heartbeatInterval: Optional[int] = Field(default=5, description="心跳间隔")
    namespace: Optional[str] = Field(default="", description="Nacos命名空间")
    username: Optional[str] = Field(default="", description="Nacos用户名")
    password: Optional[str] = Field(default="", description="Nacos密码")


class DatabaseConfig(BaseModel):
    url: str


class MicroCoreConfig(BaseSettings):
    """微服务核心配置"""
    # 允许服务在config.yaml中添加自定义配置字段,microcore会原样保留它们
    model_config = ConfigDict(extra='allow')
    
    app: AppConfig = AppConfig(name="service", env="dev")
    server: ServerConfig = ServerConfig(servicePort=8001, grpcPort=8002)
    nacos: NacosConfig = NacosConfig()
    database: DatabaseConfig = DatabaseConfig(url="")
    services: Optional[Dict[str, Any]] = Field(default_factory=dict, description="服务发现配置")


def load_config():
    """自动加载当前服务下的 config/config_<env>.yaml 文件"""
    env = os.getenv("APP_ENV", "dev")

    # 获取当前执行脚本路径
    main_path = Path(os.path.abspath(__main__.__file__))
    service_root = main_path.parent

    # 拼接配置文件路径
    config_path = service_root / "config" / f"config_{env}.yaml"

    if not config_path.exists():
        raise FileNotFoundError(f"❌ 配置文件不存在: {config_path}")

    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    config = MicroCoreConfig(**data)

    service_port = os.getenv("SERVICE_PORT", config.server.servicePort)
    config.server.servicePort = int(service_port)

    if not config.server.ip:
        config.server.ip = get_local_ip()

    return config

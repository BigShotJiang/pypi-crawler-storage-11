"""
gRPC 服务器基类

提供gRPC服务器的基础功能,包括启动、停止、优雅关闭等。
"""

import grpc.aio
from abc import ABC, abstractmethod
from typing import Optional

from microcore.config import MicroCoreConfig
from microcore.logging_setup import get_logger

logger = get_logger(__name__)


class GrpcServerBase(ABC):
    """
    gRPC 服务器基类
    
    提供gRPC服务器的基础功能,子类需要实现 register_services 方法
    来注册具体的gRPC服务。
    """

    def __init__(self, config: MicroCoreConfig):
        """
        初始化gRPC服务器
        
        Args:
            config: 微服务核心配置
        """
        self.config = config
        self.server: Optional[grpc.aio.Server] = None

    @abstractmethod
    def register_services(self, server: grpc.aio.Server):
        """
        注册gRPC服务 (子类必须实现)
        
        Args:
            server: gRPC服务器实例
        """
        pass

    async def start(self):
        """启动gRPC服务器"""
        try:
            # 创建gRPC服务器
            self.server = grpc.aio.server(
                options=[
                    # 最大接收消息长度 (100MB)
                    ('grpc.max_receive_message_length', 100 * 1024 * 1024),
                    # 最大发送消息长度 (100MB)
                    ('grpc.max_send_message_length', 100 * 1024 * 1024),
                    # 保活时间 (60秒)
                    ('grpc.keepalive_time_ms', 60 * 1000),
                    # 保活超时 (20秒)
                    ('grpc.keepalive_timeout_ms', 20 * 1000),
                ]
            )

            # 注册服务 (由子类实现)
            self.register_services(self.server)

            # 绑定端口
            listen_addr = f'[::]:{self.config.server.grpcPort}'
            self.server.add_insecure_port(listen_addr)

            # 启动服务器
            await self.server.start()
            logger.info(
                f"✅ gRPC服务器启动成功: {self.config.server.ip}:{self.config.server.grpcPort}"
            )

        except Exception as e:
            logger.error(f"gRPC服务器启动失败: {e}")
            raise

    async def stop(self, grace_period: int = 30):
        """
        停止gRPC服务器
        
        Args:
            grace_period: 优雅关闭等待时间(秒)
        """
        if self.server:
            try:
                logger.info(f"正在停止gRPC服务器 (等待{grace_period}秒)...")
                await self.server.stop(grace_period)
                logger.info("✅ gRPC服务器已停止")
            except Exception as e:
                logger.error(f"停止gRPC服务器失败: {e}")

    async def wait_for_termination(self):
        """等待服务器终止"""
        if self.server:
            await self.server.wait_for_termination()

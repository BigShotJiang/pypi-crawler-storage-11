"""
Nacos 服务注册器

提供服务注册、发现、心跳等功能,支持HTTP和gRPC端口同时注册。
"""

from typing import Optional
from v2.nacos import (
    ClientConfigBuilder, 
    NacosNamingService, 
    RegisterInstanceParam,
    DeregisterInstanceParam
)

from microcore.config import MicroCoreConfig
from microcore.logging_setup import get_logger

logger = get_logger(__name__)


class NacosRegistrationError(Exception):
    """Nacos注册异常"""
    pass


class NacosDiscoveryError(Exception):
    """Nacos发现异常"""
    pass


class NacosRegistrar:
    """
    Nacos 服务注册与发现器
    
    提供服务注册、发现、心跳等功能。
    支持同时注册HTTP端口和gRPC端口。
    """

    def __init__(self, config: MicroCoreConfig):
        """
        初始化Nacos注册器
        
        Args:
            config: 微服务核心配置
        """
        if not config:
            raise NacosRegistrationError("未提供有效的配置")

        self.config = config
        
        # Nacos客户端配置
        self.client_config = (
            ClientConfigBuilder()
            .username(config.nacos.username)
            .password(config.nacos.password)
            .server_address(f'{config.nacos.host}:{config.nacos.port}')
            .namespace_id(config.nacos.namespace if config.nacos.namespace else "public")
            .log_level('INFO')
            .build()
        )

        # Nacos命名服务客户端
        self.nacos_client: Optional[NacosNamingService] = None

    async def register_instance(self):
        """
        注册服务实例
        
        同时注册HTTP服务和gRPC服务(如果配置了gRPC端口)。
        """
        try:
            # 创建命名服务客户端
            self.nacos_client = await NacosNamingService.create_naming_service(
                self.client_config
            )
            
            # 注册HTTP服务
            await self._register_http_service()
            
            # 注册gRPC服务 (如果配置了gRPC端口)
            if self.config.server.grpcPort:
                await self._register_grpc_service()
                
        except Exception as e:
            logger.warning(f"服务注册失败: {e}")
            # 不抛出异常,允许服务在Nacos不可用时继续运行

    async def _register_http_service(self):
        """注册HTTP服务"""
        try:
            response = await self.nacos_client.register_instance(
                RegisterInstanceParam(
                    service_name=self.config.app.name,
                    group_name=self.config.nacos.groupName,
                    ip=self.config.server.ip,
                    port=self.config.server.servicePort,
                    metadata={
                        "env": self.config.app.env,
                        "protocol": "http",
                        "version": "1.0.0",
                        "service_name": self.config.app.name,
                        "service_group": self.config.nacos.groupName,
                    },
                    enabled=True,
                    healthy=True,
                    ephemeral=True  # 临时实例,支持心跳
                )
            )
            
            if response:
                logger.info(
                    f"✅ HTTP服务注册成功: {self.config.app.name} "
                    f"({self.config.server.ip}:{self.config.server.servicePort})"
                )
            else:
                logger.error(f"❌ HTTP服务注册失败: {self.config.app.name}")
                
        except Exception as e:
            logger.error(f"HTTP服务注册异常: {e}")
            raise

    async def _register_grpc_service(self):
        """注册gRPC服务"""
        try:
            grpc_service_name = f"{self.config.app.name}-grpc"
            
            response = await self.nacos_client.register_instance(
                RegisterInstanceParam(
                    service_name=grpc_service_name,
                    group_name=self.config.nacos.groupName,
                    ip=self.config.server.ip,
                    port=self.config.server.grpcPort,
                    metadata={
                        "env": self.config.app.env,
                        "protocol": "grpc",
                        "version": "1.0.0",
                        "service_name": grpc_service_name,
                        "service_group": self.config.nacos.groupName,
                    },
                    enabled=True,
                    healthy=True,
                    ephemeral=True  # 临时实例,支持心跳
                )
            )
            
            if response:
                logger.info(
                    f"✅ gRPC服务注册成功: {grpc_service_name} "
                    f"({self.config.server.ip}:{self.config.server.grpcPort})"
                )
            else:
                logger.error(f"❌ gRPC服务注册失败: {grpc_service_name}")
                
        except Exception as e:
            logger.error(f"gRPC服务注册异常: {e}")
            raise

    async def deregister_instance(self):
        """
        注销服务实例
        
        从Nacos注销HTTP服务和gRPC服务。
        """
        if not self.nacos_client:
            logger.warning("Nacos客户端未初始化,无需注销")
            return

        try:
            # 注销HTTP服务
            await self._deregister_http_service()
            
            # 注销gRPC服务
            if self.config.server.grpcPort:
                await self._deregister_grpc_service()
                
            logger.info("✅ 服务注销成功")
            
        except Exception as e:
            logger.error(f"服务注销失败: {e}")

    async def _deregister_http_service(self):
        """注销HTTP服务"""
        try:
            await self.nacos_client.deregister_instance(
                DeregisterInstanceParam(
                    service_name=self.config.app.name,
                    group_name=self.config.nacos.groupName,
                    ip=self.config.server.ip,
                    port=self.config.server.servicePort,
                    ephemeral=True
                )
            )
            logger.info(f"HTTP服务注销成功: {self.config.app.name}")
        except Exception as e:
            logger.error(f"HTTP服务注销失败: {e}")

    async def _deregister_grpc_service(self):
        """注销gRPC服务"""
        try:
            grpc_service_name = f"{self.config.app.name}-grpc"
            await self.nacos_client.deregister_instance(
                DeregisterInstanceParam(
                    service_name=grpc_service_name,
                    group_name=self.config.nacos.groupName,
                    ip=self.config.server.ip,
                    port=self.config.server.grpcPort,
                    ephemeral=True
                )
            )
            logger.info(f"gRPC服务注销成功: {grpc_service_name}")
        except Exception as e:
            logger.error(f"gRPC服务注销失败: {e}")

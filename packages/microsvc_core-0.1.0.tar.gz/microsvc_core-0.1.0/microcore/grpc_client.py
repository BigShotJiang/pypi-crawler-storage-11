"""
gRPC 客户端基类

提供通用的 gRPC 客户端功能，包括连接管理、超时控制、错误处理等。
"""

import grpc
from typing import Optional
from loguru import logger


class GrpcClientBase:
    """
    gRPC 客户端基类
    
    提供通用的 gRPC 客户端功能。
    """
    
    def __init__(
        self,
        host: str,
        port: int,
        timeout: int = 5,
        max_retries: int = 3
    ):
        """
        初始化 gRPC 客户端
        
        Args:
            host: 服务器地址
            port: 服务器端口
            timeout: 请求超时时间(秒)
            max_retries: 最大重试次数
        """
        self.host = host
        self.port = port
        self.timeout = timeout
        self.max_retries = max_retries
        self.address = f"{host}:{port}"
        self._channel: Optional[grpc.Channel] = None
        
    def connect(self):
        """建立 gRPC 连接"""
        if self._channel is None:
            self._channel = grpc.insecure_channel(self.address)
            logger.info(f"gRPC客户端连接成功: {self.address}")
        return self._channel
    
    def close(self):
        """关闭 gRPC 连接"""
        if self._channel:
            self._channel.close()
            self._channel = None
            logger.info(f"gRPC客户端连接已关闭: {self.address}")
    
    @property
    def channel(self) -> grpc.Channel:
        """获取 gRPC 通道"""
        if self._channel is None:
            self.connect()
        return self._channel
    
    def __enter__(self):
        """上下文管理器入口"""
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器退出"""
        self.close()
        return False

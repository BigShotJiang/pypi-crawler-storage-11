"""
Nacos 配置管理器

提供配置中心的封装操作,包括配置拉取、发布、删除、监听等功能。
"""

from typing import Optional, Callable
from v2.nacos import NacosConfigService, ClientConfigBuilder, ConfigParam

from microcore.logging_setup import get_logger

logger = get_logger(__name__)


class NacosConfigError(Exception):
    """Nacos配置异常"""
    pass


class NacosConfigManager:
    """
    Nacos 配置管理器
    
    封装 Nacos 配置中心操作,提供配置拉取、发布、删除、监听等功能。
    支持配置缓存和容灾。
    """

    def __init__(self, client_config):
        """
        初始化配置管理器
        
        Args:
            client_config: Nacos客户端配置
        """
        self.client_config = client_config
        self.config_client: Optional[NacosConfigService] = None
        self._listeners = {}  # 存储监听器 {(data_id, group): [listeners]}

    async def initialize(self):
        """初始化配置客户端"""
        try:
            self.config_client = await NacosConfigService.create_config_service(
                self.client_config
            )
            logger.info("Nacos配置客户端初始化成功")
            return True
        except Exception as e:
            logger.warning(f"Nacos配置客户端初始化失败: {e}")
            return False

    async def get_config(
        self, 
        data_id: str, 
        group: str = "DEFAULT_GROUP"
    ) -> Optional[str]:
        """
        获取配置
        
        优先级策略:
        1. 从本地failover目录读取
        2. 从服务端获取 (成功后保存到快照)
        3. 从快照目录读取
        
        Args:
            data_id: 配置的Data ID
            group: 配置分组名称
            
        Returns:
            配置内容,失败返回None
        """
        if not self.config_client:
            logger.error("配置客户端未初始化")
            return None

        try:
            content = await self.config_client.get_config(
                ConfigParam(data_id=data_id, group=group)
            )
            if content:
                logger.info(f"获取配置成功: data_id={data_id}, group={group}")
            else:
                logger.warning(f"配置不存在: data_id={data_id}, group={group}")
            return content
        except Exception as e:
            logger.error(f"获取配置失败: data_id={data_id}, group={group}, error={e}")
            return None

    async def publish_config(
        self, 
        data_id: str, 
        group: str, 
        content: str
    ) -> bool:
        """
        发布配置
        
        若配置不存在则创建,若存在则更新内容。
        
        Args:
            data_id: 配置的Data ID
            group: 配置分组名称
            content: 配置内容
            
        Returns:
            成功返回True,失败返回False
        """
        if not self.config_client:
            logger.error("配置客户端未初始化")
            return False

        try:
            result = await self.config_client.publish_config(
                ConfigParam(data_id=data_id, group=group, content=content)
            )
            if result:
                logger.info(f"发布配置成功: data_id={data_id}, group={group}")
            else:
                logger.error(f"发布配置失败: data_id={data_id}, group={group}")
            return result
        except Exception as e:
            logger.error(f"发布配置异常: data_id={data_id}, group={group}, error={e}")
            return False

    async def remove_config(
        self, 
        data_id: str, 
        group: str = "DEFAULT_GROUP"
    ) -> bool:
        """
        删除配置
        
        Args:
            data_id: 配置的Data ID
            group: 配置分组名称
            
        Returns:
            成功返回True,失败返回False
        """
        if not self.config_client:
            logger.error("配置客户端未初始化")
            return False

        try:
            result = await self.config_client.remove_config(
                ConfigParam(data_id=data_id, group=group)
            )
            if result:
                logger.info(f"删除配置成功: data_id={data_id}, group={group}")
            else:
                logger.error(f"删除配置失败: data_id={data_id}, group={group}")
            return result
        except Exception as e:
            logger.error(f"删除配置异常: data_id={data_id}, group={group}, error={e}")
            return False

    async def add_listener(
        self, 
        data_id: str, 
        group: str, 
        listener: Callable
    ):
        """
        添加配置监听器
        
        配置变更或删除时触发回调。若配置已存在则立即触发一次回调。
        
        Args:
            data_id: 配置的Data ID
            group: 配置分组名称
            listener: 配置监听回调函数 (tenant, data_id, group, content) -> None
        """
        if not self.config_client:
            logger.error("配置客户端未初始化")
            return

        try:
            await self.config_client.add_listener(
                data_id=data_id,
                group=group,
                listener=listener
            )
            
            # 记录监听器
            key = (data_id, group)
            if key not in self._listeners:
                self._listeners[key] = []
            self._listeners[key].append(listener)
            
            logger.info(f"添加配置监听器成功: data_id={data_id}, group={group}")
        except Exception as e:
            logger.error(f"添加配置监听器失败: data_id={data_id}, group={group}, error={e}")

    async def remove_listener(
        self, 
        data_id: str, 
        group: str, 
        listener: Callable
    ):
        """
        移除配置监听器
        
        Args:
            data_id: 配置的Data ID
            group: 配置分组名称
            listener: 配置监听回调函数
        """
        if not self.config_client:
            logger.error("配置客户端未初始化")
            return

        try:
            await self.config_client.remove_listener(
                data_id=data_id,
                group=group,
                listener=listener
            )
            
            # 移除记录
            key = (data_id, group)
            if key in self._listeners and listener in self._listeners[key]:
                self._listeners[key].remove(listener)
            
            logger.info(f"移除配置监听器成功: data_id={data_id}, group={group}")
        except Exception as e:
            logger.error(f"移除配置监听器失败: data_id={data_id}, group={group}, error={e}")

    async def shutdown(self):
        """关闭配置客户端"""
        if self.config_client:
            try:
                await self.config_client.shutdown()
                logger.info("Nacos配置客户端已关闭")
            except Exception as e:
                logger.error(f"关闭配置客户端失败: {e}")

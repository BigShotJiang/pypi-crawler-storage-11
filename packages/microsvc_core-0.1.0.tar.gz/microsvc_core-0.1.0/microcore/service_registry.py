"""
服务注册表

统一管理所有微服务的配置和客户端。
"""

from typing import Dict, Any, Optional
from loguru import logger


class ServiceRegistry:
    """
    服务注册表
    
    提供全局的服务配置管理，供gRPC客户端使用。
    """
    
    _config: Optional[Dict[str, Any]] = None
    _services: Dict[str, Dict[str, Any]] = {}
    
    @classmethod
    def init(cls, config: Any):
        """
        初始化服务注册表
        
        Args:
            config: 配置对象或字典
        """
        if hasattr(config, 'dict'):
            cls._config = config.dict()
        else:
            cls._config = config
        
        # 加载服务配置
        cls._services = cls._config.get('services', {})
        
        logger.info(f"服务注册表初始化完成，已注册 {len(cls._services)} 个服务")
    
    @classmethod
    def get_service_config(cls, service_name: str) -> Dict[str, Any]:
        """
        获取服务配置
        
        Args:
            service_name: 服务名称 (如 'system-service')
            
        Returns:
            服务配置字典，包含 host 和 grpc_port
        """
        if cls._config is None:
            raise RuntimeError("服务注册表未初始化，请先调用 ServiceRegistry.init(config)")
        
        # 尝试直接查找，如果找不到则尝试转换
        service_config = cls._services.get(service_name, {})
        
        if not service_config:
            # 尝试将 system-service 转换为 system_service
            service_key = service_name.replace('-', '_')
            service_config = cls._services.get(service_key, {})
        
        if not service_config:
            logger.warning(f"服务 {service_name} 未在配置中找到，使用默认配置")
            return {
                'host': 'localhost',
                'grpc_port': 9000
            }
        
        return service_config
    
    @classmethod
    def get_all_services(cls) -> Dict[str, Dict[str, Any]]:
        """获取所有服务配置"""
        return cls._services.copy()
    
    @classmethod
    def is_initialized(cls) -> bool:
        """检查注册表是否已初始化"""
        return cls._config is not None

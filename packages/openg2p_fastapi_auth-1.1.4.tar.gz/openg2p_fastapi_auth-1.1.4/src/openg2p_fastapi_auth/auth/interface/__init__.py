from .interface import AuthInterface

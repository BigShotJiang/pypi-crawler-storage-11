"""Tests for akipy package"""

from .domjudge import DomJudgeAPI

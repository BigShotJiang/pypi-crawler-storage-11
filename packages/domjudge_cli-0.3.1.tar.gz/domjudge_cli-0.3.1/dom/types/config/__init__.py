from .processed import DomConfig

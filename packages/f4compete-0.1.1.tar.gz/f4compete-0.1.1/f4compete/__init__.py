from .core import shuffle, read_file, save_file, save_self

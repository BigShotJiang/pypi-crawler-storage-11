# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ExportPrivateKeyResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'keypair': 'ExportPrivateKeyKeypairBean'
    }

    attribute_map = {
        'keypair': 'keypair'
    }

    def __init__(self, keypair=None):
        r"""ExportPrivateKeyResponse

        The model defined in huaweicloud sdk

        :param keypair: 
        :type keypair: :class:`huaweicloudsdkkps.v3.ExportPrivateKeyKeypairBean`
        """
        
        super().__init__()

        self._keypair = None
        self.discriminator = None

        if keypair is not None:
            self.keypair = keypair

    @property
    def keypair(self):
        r"""Gets the keypair of this ExportPrivateKeyResponse.

        :return: The keypair of this ExportPrivateKeyResponse.
        :rtype: :class:`huaweicloudsdkkps.v3.ExportPrivateKeyKeypairBean`
        """
        return self._keypair

    @keypair.setter
    def keypair(self, keypair):
        r"""Sets the keypair of this ExportPrivateKeyResponse.

        :param keypair: The keypair of this ExportPrivateKeyResponse.
        :type keypair: :class:`huaweicloudsdkkps.v3.ExportPrivateKeyKeypairBean`
        """
        self._keypair = keypair

    def to_dict(self):
        import warnings
        warnings.warn("ExportPrivateKeyResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ExportPrivateKeyResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

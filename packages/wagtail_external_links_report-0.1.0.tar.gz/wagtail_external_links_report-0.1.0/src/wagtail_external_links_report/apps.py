from django.apps import AppConfig


class WagtailExternalLinksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wagtail_external_links_report'
    verbose_name = "Wagtail External Links Report"

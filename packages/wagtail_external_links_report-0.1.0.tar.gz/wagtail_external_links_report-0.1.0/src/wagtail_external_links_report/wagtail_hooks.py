from django.conf import settings
from django.urls import reverse, path
from django.utils.module_loading import import_string
from wagtail import hooks
from wagtail.admin.menu import MenuItem

from wagtail_external_links_report.views import ExternalLinksReportView


def get_external_links_report_class():
    """
    Resolve the report class from settings.

    settings.EXTERNAL_LINKS_REPORT_CLASS can be:
      - dotted string path: 'myapp.reports.CustomExternalLinksReportView'
      - class object itself
      - not set: fallback to ExternalLinksReportView
    """
    cls_setting = getattr(settings, "EXTERNAL_LINKS_REPORT_CLASS", None)

    if isinstance(cls_setting, str):
        return import_string(cls_setting)

    if isinstance(cls_setting, type):
        return cls_setting

    return ExternalLinksReportView

@hooks.register("register_reports_menu_item")
def register_external_links_report():
    report_class = get_external_links_report_class()
    return MenuItem(
        report_class.page_title,
        reverse("external_links_report"),
        icon_name="link",
        order=1400,
    )

@hooks.register('register_admin_urls')
def register_page_views_report_url():
    report_class = get_external_links_report_class()
    return [
        path("reports/external-links/", report_class.as_view(), name="external_links_report",)
    ]

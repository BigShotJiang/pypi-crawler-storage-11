# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- **Ticket 13E — CI Auto-Fail & Benchmark Regression Integration:**
  - **CI Quality Gate Workflow**: New `.github/workflows/quality-gate.yml` for automated quality checks
    - Triggers on every PR and push to main
    - Runs benchmark quality report generation (CSV/JSON/HTML)
    - Executes quality gate checks with automatic pass/fail/warn status
    - Uploads artifacts: benchmark reports and quality gate summaries
    - Posts/updates single PR comment with quality status and artifact links
  - **Helper Script**: New `tools/ci_quality_gate.py` for robust exit code mapping
    - Maps exit codes: 0 (PASS), 10 (WARN), 20 (FAIL), 2 (NO DATA), 1 (ERROR)
    - Loads and displays regression.json data with deltas vs baseline
    - Writes quality_gate.txt summary for CI artifact upload
    - Handles missing/empty batch_out gracefully (NO DATA status)
    - Color-coded terminal output with ANSI formatting
  - **PR Comment Integration**: Automated single-comment updates via actions/github-script@v7
    - Displays status emoji (✅/⚠️/❌/⚪) and exit code
    - Links to downloadable benchmark-report artifact
    - Shows quality gate summary with current vs baseline metrics
    - Updates in-place on re-runs (deduped via HTML comment marker)
  - **Documentation Updates**:
    - README: New "Automated Quality Gate Workflow" section with exit code table
    - CLAUDE.md: Updated CI/CD pipeline notes with quality-gate.yml details
    - Includes local reproduction examples and PR comment behavior
  - **Exit Code Behavior**:
    - Job fails on FAIL (20) and ERROR (1) status
    - Job passes on PASS (0), WARN (10), and NO DATA (2)
    - WARN surfaces in PR comment but doesn't block merge (configurable)

## [0.10.13] — 2025-11-01

### Added

- **Ticket 13D — Regression Trend Tracking & Auto-Gating:**
  - **Automated Quality Tracking**: Each sync/batch run now appends quality metrics to `quality_history.json`
    - Tracks: P90 residual, PPM drift, inlier fraction, FPS, optional CPU/GPU metrics
    - Timestamped records with run ID for audit trail
    - Automatically capped at 2000 most recent records (memory-safe)
  - **Rolling Baseline Computation**: Computes median from last N runs (default 50)
    - Requires ≥10 runs for reliable gating ("learning" mode until then)
    - Separate history per root directory (batch_out, etc.)
  - **Regression Detection**: Compares current run against baseline with configurable thresholds
    - **OK**: All metrics within thresholds
    - **WARN**: Minor regression (1× threshold exceeded)
    - **FAIL**: Severe regression (2× threshold exceeded)
    - **LEARNING**: Insufficient history (<10 runs)
  - **Default Thresholds** (all configurable via CLI):
    - P90: +25% or +0.25s (warn), +50% or +0.50s (fail)
    - PPM: +25% or +150 ppm (warn), +50% or +300 ppm (fail)
    - Inlier Fraction: -15% or -0.05 (warn), -30% or -0.10 (fail)
  - **CLI Integration**:
    - `sync` and `batch` commands: Automatic regression tracking (enabled by default)
      - `--regression-off`: Disable tracking
      - `--fail-on-regression`: Exit code 20 on severe regression
      - `--reg-window N`: Baseline window size (default 50)
      - `--reg-p90-pct/abs`, `--reg-ppm-pct/abs`, `--reg-inlier-pct/abs`: Custom thresholds
      - Prints color-coded status after run (green=OK, yellow=WARN, red=FAIL, cyan=LEARNING)
      - Writes `regression.json` with detailed status and deltas
    - New `quality-check` command for standalone regression checking:
      - `mtbsync quality-check --root ./batch_out`
      - Displays formatted table with baseline vs current metrics
      - Supports same threshold flags as sync/batch
      - Exit codes: `0` (OK/learning), `10` (warn), `20` (fail), `2` (no history), `1` (error)
  - **Dashboard Integration**:
    - New `/api/regression` endpoint provides current regression status
    - New "Regression" card in dashboard HTML with:
      - Color-coded status badge (green/yellow/red/cyan/gray)
      - Interactive table showing P90, PPM, Inlier Fraction deltas
      - Regression reasons and baseline window info
      - Auto-updates with other dashboard data
  - **Data Model**:
    - `quality_history.json`: Rolling ledger of quality records (ISO8601 timestamps, metrics)
    - `regression.json`: Latest regression evaluation result (status, reasons, deltas, thresholds)
  - **Configurable Thresholds**: All gates can be tuned per-environment:
    - Permissive (development): Default values
    - Strict (production): Lower percentages, tighter absolute limits
    - Use OR logic: threshold = max(baseline × pct, baseline + abs)
  - **Use Cases**:
    - Continuous monitoring: Detect quality drift early
    - CI/CD gates: Fail builds on severe regressions
    - Parameter tuning: Validate config changes don't degrade quality
    - Performance tracking: Monitor FPS, CPU, GPU trends
  - **New module**: `src/mtbsync/regression.py` (280 lines, stdlib only)
    - Functions: `load_quality_history()`, `append_quality_record()`, `compute_baseline()`, `evaluate_regression()`, `default_thresholds()`, `create_quality_record()`
  - **Helper function**: `_track_regression()` in CLI for automatic integration
  - **Batch integration**: `_track_batch_regression()` in batch.py for per-pair tracking

### Tests

- New: `tests/test_regression.py` (31 comprehensive tests, all passing ✅)
  - Default thresholds validation
  - History loading with filtering and sorting
  - Atomic append with validation
  - Baseline computation (empty, insufficient, sufficient history)
  - Median calculation with window limiting and None handling
  - Regression evaluation (ok/warn/fail states)
  - Custom threshold overrides
  - Delta computation and formatting
  - Quality record creation with optional fields
  - End-to-end workflow integration test

### Documentation

- README.md: Added comprehensive "Regression & Auto-Gating" section with:
  - Quick start examples
  - How it works (4-step process)
  - Default thresholds table
  - CLI command reference (sync/batch/quality-check)
  - Dashboard integration
  - CI/CD integration example
  - Quality history management
  - Interpreting results with example output
  - When to use and tuning guidelines
- CLAUDE.md: Added Ticket 13D implementation notes (pending)
- All 31 regression tests passing

### Notes

- Regression tracking is **enabled by default** for sync/batch commands (use `--regression-off` to disable)
- Threshold calculation uses **OR logic**: `max(baseline × pct, baseline + abs)` for maximum flexibility
- Fail threshold is **2× warn threshold** by default (configurable via `severe_multiplier` in code)
- History files are **automatically capped at 2000 records** to prevent unbounded growth
- **Graceful degradation**: All regression tracking is best-effort and never crashes the pipeline

## [0.10.12] — 2025-11-01

### Added

- **Ticket 13C — Quick Benchmark Integration:**
  - **CI Workflow**: New `.github/workflows/benchmark.yml` for continuous quality reporting
    - Triggers automatically on push to `main` and pull requests
    - Runs `mtbsync benchmark-quality` with strict gates (500 item limit)
    - Creates empty `batch_out` directory if missing (prevents exit code 1 failures)
    - Gracefully handles exit code 2 (no runs found) without failing job
    - Uploads `benchmark_out/**` as downloadable artifact named `benchmark-report`
    - Provides consistent quality visibility for all PRs and commits
  - **README Quick QA**: Added "Quick QA (local)" section with one-liner command
    - `./examples/run_benchmark.sh ./batch_out ./benchmark_out && open ./benchmark_out/report.html`
    - Includes note for Linux users to use `xdg-open` instead of `open`
  - **Dashboard Integration**: Benchmark report auto-linking in Telemetry card
    - New `_find_benchmark_report()` helper checks for `benchmark_out/report.html`
    - Displays "Open Benchmark Report" button when report exists
    - Opens in new tab, hidden when absent (best-effort, non-blocking)
    - Correct URL path: `/benchmark_out/report.html` (matches SimpleHTTPRequestHandler)

### Fixed

- Dashboard benchmark link URL corrected (removed incorrect `/files/` prefix)
- CI workflow now creates `batch_out` directory before running benchmark (prevents missing directory errors)

### Documentation

- CLAUDE.md: Added CI/CD integration notes for benchmark workflow
- README.md: Added Quick QA section for local benchmark generation

## [0.10.11] — 2025-11-01

### Added

- **Ticket 13B — Benchmark Quality Reporting:**
  - New `mtbsync benchmark-quality` command for evaluating sync quality across many runs
  - Aggregates metrics from `timewarp.json`, `perf.json`, and `pairs.csv` artefacts
  - Features:
    - Discovers run folders under specified root (sorted by mtime, newest first)
    - Loads time-warp quality metrics: `ppm`, `inlier_frac`, `res_mae`, `res_p90`
    - Extracts performance metrics: `fps`, `cpu_pct`, `gpu_util`, `gpu_mem_mb`, `rss_mb`
    - Evaluates strict quality gates: `inlier_frac ≥ 0.50`, `p90 ≤ 1.0s`, `ppm ≤ 500`
    - Generates CSV/JSON/HTML reports with KPIs and inline SVG charts
  - Output formats:
    - **CSV**: Detailed table with all metrics per run
    - **JSON**: Machine-readable format for automation
    - **HTML**: Self-contained report with KPI dashboard and distribution histograms
  - HTML report includes:
    - Summary KPIs: Total runs, OK%, Strict OK%, Mean P90, Mean PPM
    - Inline SVG charts: P90 and PPM distribution histograms
    - Sortable detailed results table
    - Zero external dependencies (pure stdlib + inline SVG)
  - CLI options:
    - `--root` (required): Directory containing run folders
    - `--pattern`: Glob pattern for run directories (default: `*`)
    - `--out`: Output directory (default: `benchmark_out`)
    - `--limit`: Max runs to process (default: 2000)
    - `--fields`: Extra perf fields to extract (comma-separated)
    - `--strict`: Show strict evaluation in summary
    - `--csv/--no-csv`, `--json/--no-json`, `--html`: Control output formats
    - `--quiet`: Reduce console output
  - Exit codes: `0` (success), `1` (error), `2` (no runs discovered)
  - Robust error handling: gracefully handles missing artefacts, partial data
  - Use cases: QA workflows, parameter tuning, CI/CD quality gates, performance analysis
  - New module: `src/mtbsync/benchmark.py` (zero hard dependencies, stdlib only)
  - Helper script: `examples/run_benchmark.sh` for common workflows

### Tests

- New: `tests/test_benchmark.py` (7 comprehensive tests)
  - Discovery, sorting, and limit enforcement
  - Loader error handling (missing files, invalid JSON)
  - Strict evaluation thresholds
  - Aggregation with mixed good/weak runs
  - CSV/JSON/HTML output validation
  - End-to-end CLI testing
  - Exit code verification

## [0.10.10] — 2025-11-01

### Added

- **Ticket 13A — Side-by-side video comparison UI:**
  - New `mtbsync compare-ui` command launches interactive comparison interface
  - Features:
    - Dual video panes (reference + new) for visual comparison
    - Marker overlay with interactive timeline visualization (Plotly)
    - Delta summary statistics (MAE, P90, median, count)
    - Search and filter markers by ID or label
    - Annotation system: add notes and labels to selected markers
    - Export annotations to CSV or JSON via download buttons
    - Session-based annotation storage with edit/delete capabilities
    - **Environment variable pre-population**: CLI args auto-fill sidebar fields via `MTB_COMPARE_*` env vars
  - Core helpers module: `compare_core.py`
    - `load_markers_csv()` - Load and validate marker files (supports both t_ref and t_new)
    - `load_timewarp_json()` - Load affine warp parameters
    - `predict_new_times_from_warp()` - Compute predicted times from warp
    - `compute_deltas()` - Calculate time deltas (measured vs predicted)
    - `summarise_quality()` - Generate delta statistics (MAE, P90, etc.)
  - Optional dependency: new `[compare]` extra with streamlit and plotly
  - Install with: `pip install "mtbsync[compare]"`
  - CLI integration: `compare-ui` command with --ref, --new, --ref-markers, --new-markers, --timewarp-json, --root, --port flags
  - Helps validate sync quality and document QA findings
  - **Production-safe import**: Raises `ImportError` (not `sys.exit()`) when streamlit missing

### Fixed

- **compare-ui import safety**: Module no longer calls `sys.exit(2)` at import time
  - Now raises catchable `ImportError` for graceful failure handling
  - Allows tests and other code to safely import even if streamlit missing

### Tests

- New: `tests/test_compare_core.py` (23 comprehensive unit tests)
- New: `tests/test_compare_ui.py` (8 tests including env wiring and import guard verification)

## [0.10.9] — 2025-11-01

### Added

- **Ticket 12C — Streamlit telemetry dashboard:**
  - New `mtbsync telemetry-ui` command launches interactive Streamlit dashboard
  - Features:
    - Overview metrics panel (total runs, avg FPS/CPU/GPU/RAM)
    - Interactive time-series charts for FPS, CPU%, GPU%, VRAM MB, RSS MB
    - Filtering controls: time-range slider (by index), recent N runs selector
    - Smoothing toggle: rolling mean with configurable window
    - CSV export of filtered telemetry data via download button
    - Optional live updates (experimental): polls directory every 2s
    - Clean sidebar layout with metric multiselect widget
  - Optional dependency: moved streamlit to `[telemetry]` extra
  - Install with: `pip install "mtbsync[telemetry]"`
  - CLI integration: `telemetry-ui` command with --root, --port flags
  - Complements built-in HTML dashboard with richer interactivity
- **Version command:** New `mtbsync version` command for convenient version checking
  - Uses importlib.metadata for accurate version lookup
  - Formatted output with rich console colors

### Changed

- **Dependencies:** streamlit moved from core to optional `[telemetry]` extra

### Fixed

- **Live updates termination:** Replaced infinite while loop with single-pass rerun pattern
  - Checkbox state is now re-evaluated on each script execution
  - Users can disable live updates by unchecking the box without killing the session
  - Addresses Codex review feedback on PR #25

### Tests

- Total tests: 157 passing (up from 145)
- New: `tests/test_streamlit_app.py` (12 comprehensive tests)

## [0.10.7] — 2025-11-01

### Added

- **Ticket 12B — Time-series charts (inline SVG) and `/api/perf/history` endpoint:**
  - Dashboard displays five inline SVG charts: FPS, CPU%, GPU%, VRAM MB, RSS MB
  - New `/api/perf/history` endpoint aggregates last 500 perf.json files (configurable via query)
  - Data ordered oldest→newest for temporal visualisation
  - Charts handle null values gracefully (skip gaps in data)
  - FPS fallback: computed from `frames_processed / retrieval_sec` when not present
  - Zero external dependencies (pure stdlib + inline SVG)
  - Tests: `tests/test_timeseries.py` (5 comprehensive tests)

### Tests

- Total tests: 145 passing (up from 140)

## [0.10.6] — 2025-11-01

### Added

- **Ticket 12A — Telemetry retention:**
  - CLI command `prune-perf` to keep newest N `perf.json` files (mtime-based).
  - Dashboard POST `/api/perf/prune` (enabled with `--allow-write`) and UI button.
  - Safety: path validation confines deletions under `--root`.
- **Production-ready helper scripts:**
  - `examples/visual_diagnostic.sh` - Generate alignment overlay PNG with quality interpretation
  - `examples/diagnose_alignment.sh` - Parse timewarp.json and assess quality
  - `examples/resync_strict.sh` - Re-run sync with strict quality parameters (CI/CD exit codes)
  - `examples/dashboard_cleanup.sh` - Interactive telemetry cleanup
  - CI/CD documentation with GitHub Actions and GitLab CI examples
  - All scripts use portable `#!/usr/bin/env bash` and `set -euo pipefail`
- **Documentation:**
  - `QUICK_VISUAL_DIAGNOSTIC.md` - Quick reference for visual diagnostics
  - `examples/CI_CD_INTEGRATION.md` - Complete CI/CD integration guide with exit code handling
  - `examples/interpret_overlay.md` - Visual pattern interpretation guide
  - README troubleshooting section with quality tuning guidelines
- **Package distribution:**
  - `MANIFEST.in` ensures helper scripts and documentation ship with PyPI package
  - All examples/ scripts and markdown files included in sdist and wheel

### Tests

- `tests/test_retention.py` covers newest-keep logic and safety guard (5 tests).
- Total tests: 140 passing.

## [0.10.5] — 2025-11-01

### Added

- **GPU & Extended Metrics Telemetry (Ticket 11D)**
  - psutil integration for CPU percent and RSS memory tracking
  - optional NVML (pynvml) support for GPU utilisation and VRAM metrics
  - extended metrics stored in `perf.json` and surfaced in `/api/perf` and live SSE events
  - dashboard gauge bars for CPU/GPU util with colour thresholds (green <60%, amber <85%, red ≥85%)
  - `--no-gpu` flag for both `sync` and `batch` commands to disable GPU probes
  - README updated with "GPU & Extended Telemetry" section

### Changed

- batch runner respects `--no-gpu` and disables NVML calls when set
- telemetry collector uses graceful fallback if psutil/pynvml missing (no runtime errors)
- dashboard table now shows: idx, cmd, fps, wall, cpu, gpu, vram_mb, rss_mb, file

### Tests

- new tests: `test_telemetry_gpu.py` (6 tests), `test_batch_no_gpu.py` (2 tests)
- total tests: 141 passing

## [0.10.4] — 2025-11-01

### Added

- **Live Telemetry SSE Stream (Ticket 11C)**
  - `/api/perf/stream` Server-Sent Events endpoint for real-time telemetry
  - `_iter_perf_events()` polls perf.json files and yields SSE events on change
  - Dashboard frontend connects to SSE stream and appends rows live
  - ThreadingHTTPServer replaces HTTPServer for concurrent request handling
  - Live connection status indicators: "Live: connected", "Live: disconnected"

- **Telemetry & Profiling Dashboard (Ticket 11B)**
  - TelemetryRecorder context manager for CPU/memory/wall time metrics
  - perf.json artefacts written per sync/batch run
  - `/api/perf` endpoint aggregates telemetry (capped to 200 items)
  - Dashboard UI card with telemetry table (cmd, fps, wall, retrieval)
  - Optional psutil dependency with graceful fallback
  - Best-effort pattern: telemetry won't crash pipeline on failure

### Changed

- Dashboard now uses ThreadingHTTPServer with `daemon_threads=True` for safe shutdown
- SSE connections no longer block other API endpoints (concurrent access supported)
- Fixed datetime.utcnow() deprecation warning (→ datetime.now(timezone.utc))
- retrieval.py now adds `frames_processed` to timings dict for FPS calculation
- Dashboard performance: `/api/perf` endpoint caps to 200 most recent items sorted by mtime

### Tests

- 4 new telemetry tests (perf_json_written, dashboard_perf_endpoint, perf_stream_once, sse_non_blocking)
- Total 127 tests passing

## [0.10.3] — 2025-11-01

### Added

- **Trusted Publisher Enhancements (Ticket 11A)**
  - OIDC trusted publishing for PyPI releases (no long-lived API tokens)
  - SLSA provenance attestations via Sigstore/Fulcio
  - SBOM generation (CycloneDX JSON format) via Anchore Syft
  - Environment gate: `release` environment requires manual approval

### Changed

- release.yml workflow now uses `pypa/gh-action-pypi-publish@release/v1` with `attestations: true`
- Added `id-token: write` permission for OIDC authentication
- SBOM uploaded as workflow artifact for supply-chain visibility

### Security

- Removed long-lived `PYPI_API_TOKEN` secret (replaced with OIDC)
- Cryptographic attestations for all published artifacts
- Build provenance verifiable via Sigstore

## [0.10.2] — 2025-11-01

### Added

- **CI/CD Pipeline (Ticket 10C)**
  - GitHub Actions matrix testing (Python 3.11, 3.12)
  - Automated PyPI publishing on version tags
  - Coverage reporting to Codecov
  - Test infrastructure for CI environments

### Changed

- opencv-python-headless used in CI for headless compatibility

## [0.10.1] — 2025-11-01

### Added

- **NLE Importers (Ticket 10B)**
  - `import_edl()` for CMX-3600 EDL files (timecode → seconds)
  - `import_xml()` for FCPXML, Premiere XML, FCP7 XML (auto-detection)
  - CLI: `mtbsync import-markers timeline.fcpxml --out imported_markers.csv`
  - Preset system: custom export presets via `~/.mtbsync/config.toml`
  - Round-trip support: import → modify → export maintains data integrity

### Changed

- Premiere XML import now handles both new (separate markers) and old (container) formats

### Tests

- 8 new tests for EDL/XML import across all supported formats
- Total 123 tests passing

## [0.10.0] — 2025-11-01

### Added

- **FCPXML/Premiere XML Exports (Ticket 10A)**
  - Modern FCPXML 1.8+ export with rational time (frames/fps)
  - Adobe Premiere Pro xmeml export with frame-based timing
  - Dynamic fps handling: FFVideoFormat1080p24/25/30/60
  - Preset system: `--preset fcpxml`, `--preset premiere`, `--preset resolve-edl`
  - CLI: `mtbsync export-markers new_markers.csv --preset fcpxml`

### Changed

- export_markers() now supports `fcpxml` and `premiere` formats
- EDL export validates reel names (2-8 chars, warns on non-standard fps)

### Tests

- 6 new tests for FCPXML/Premiere XML export
- Total 115 tests passing

## [0.9.1] — 2025-10-31

### Added

- Dashboard enhancements:
  - `/api/marker-list` + UI dropdown to select marker files
  - Inline SVG sparklines for `retrieval_sec` and `warp_sec` from `batch_summary.csv`
  - `POST /api/export-json` (guarded by `--allow-write`)

### CLI

- `mtbsync dashboard --allow-write` enables server-side CSV→JSON export

### Tests

- `tests/test_dashboard_enhancements.py` (4 tests) — passing

## [0.9.0] — 2025-10-31

### Added

- Zero-dependency web dashboard:
  - JSON endpoints: /api/timewarp, /api/batch, /api/markers, /api/files
  - Embedded HTML UI, static file downloads
- CLI: `mtbsync dashboard --root ./batch_out --port 8000`

### Tests

- test_dashboard_poc.py (JSON endpoint smoke) — passing

## [0.8.1] — 2025-10-31

### Added

- Threaded retrieval with `--threads` (parallel coarse matching)
- Per-stage timings (gps/retrieval/warp/markers/total) emitted to artefacts and batch summary
- `--fast` preset for large jobs (threads≥4, relaxed warp RANSAC iters/thresholds)
- Performance test suite (`tests/test_perf_parallel.py`)
- Vectorized GPS time estimation (~768× speedup on large inputs)
- Profiling harness (`tools/profile_sync.py`)

### Changed

- `retrieve_coarse_pairs()` now returns `(dataframe, timings_dict)` tuple
- `BatchResult` dataclass extended with timing fields
- CLI displays per-stage timing information after sync

### Tests

- 2 new performance tests
- Total 100 tests passing

## [0.8.0] — 2025-10-31

### Added

- Marker transfer module (`src/mtbsync/match/marker_transfer.py`)
  - CSV→CSV/JSON mapping using affine time-warp parameters
  - Metadata preservation for extra columns
  - Visual overlay PNG generation for QA
- CLI command `transfer-markers`
  - Options: `--out`, `--label`, `--vis-json`, `--plot-overlay`
  - Standalone marker transfer from reference to new timeline
- Retrieval auto-export integration
  - Automatic marker transfer when `ref_markers.csv` exists
  - Outputs to `new_markers_auto.csv` after time-warp gating
- 4 comprehensive test suites for marker transfer functionality

### Known Issues

- 2 legacy CLI parsing tests (unrelated to this feature)

## [0.7.0] — 2025-10-31

### Added

- Robust affine Time-Warp fitting (`src/mtbsync/match/timewarp.py`)
  - RANSAC + IRLS (Huber) algorithm
  - Deterministic RNG and graceful fallbacks
- Integration into retrieval pipeline (runs after GPS gating)
- `timewarp.json` artefact with fit diagnostics
- 7 new CLI options (`--warp-*`)
- 5 deterministic unit tests

### Fixed

- None

### Known Issues

- 2 pre-existing CLI parse test failures (unrelated)

## [0.6.0] - 2025-10-31

### Added
- **GPS Alignment (Ticket 6)**
  - GPX file parsing and GPS-based time estimation
  - Distance-based alignment using haversine formula
  - GPS-constrained visual retrieval with configurable time windows
  - CLI options for GPS input (`--ref-gpx`, `--new-gpx`)
  - Comprehensive GPS utility tests

## [0.5.0] - 2025-10-31

### Added
- **Local Refinement with RANSAC (Ticket 5)**
  - RANSAC-based homography/affine refinement for frame pairs
  - Confidence scoring based on inlier count and reprojection error
  - Temporal window refinement (±N keyframes)
  - CLI options for refinement control (`--no-refine`, `--refine-window`, `--ransac-reproj`, `--min-inliers`)
  - Extended test coverage for refinement pipeline

## [0.4.0] - 2025-10-31

### Added
- **Coarse Retrieval (Ticket 4)**
  - Visual keyframe retrieval using BFMatcher with Hamming distance
  - Top-K candidate selection with Lowe ratio test
  - Coarse pairs output (`pairs_raw.csv`)
  - CLI `sync` command wiring for end-to-end pipeline
  - Comprehensive retrieval tests

## [0.3.0] - 2025-10-31

### Added
- **ORB Descriptor Extraction (Ticket 3)**
  - ORB feature detection with CLAHE preprocessing
  - Reference index format (`.npz` with timestamps, keypoints, descriptors)
  - Configurable ORB parameters (n_features, CLAHE toggle)
  - Deterministic feature extraction
  - Test suite for descriptor computation

## [0.2.0] - 2025-10-31

### Added
- **Video I/O & Keyframes (Ticket 2)**
  - Timestamp-based keyframe extraction (VFR-safe)
  - Aspect-preserving frame resizing
  - ffmpeg-python integration for robust video I/O
  - CLI options for FPS and feature extraction
  - Video I/O test suite

## [0.1.0] - 2025-10-31

### Added
- **Repository Scaffold (Ticket 0)**
  - Initial project structure
  - Typer CLI framework with Rich output
  - pyproject.toml with editable install
  - Basic test infrastructure with pytest
  - README with project overview
  - Development guide (CLAUDE.md)

[0.9.1]: https://github.com/markg72/goprosync/compare/v0.9.0...v0.9.1
[0.9.0]: https://github.com/markg72/goprosync/compare/v0.8.1...v0.9.0
[0.8.1]: https://github.com/markg72/goprosync/compare/v0.8.0...v0.8.1
[0.8.0]: https://github.com/markg72/goprosync/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/markg72/goprosync/compare/v0.6.0...v0.7.0
[0.6.0]: https://github.com/markg72/goprosync/compare/v0.5.0...v0.6.0
[0.5.0]: https://github.com/markg72/goprosync/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/markg72/goprosync/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/markg72/goprosync/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/markg72/goprosync/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/markg72/goprosync/releases/tag/v0.1.0

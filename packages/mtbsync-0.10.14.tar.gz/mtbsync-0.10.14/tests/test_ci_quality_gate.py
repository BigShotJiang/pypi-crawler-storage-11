"""
Tests for tools/ci_quality_gate.py
"""

import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# Import the module under test
sys.path.insert(0, str(Path(__file__).parent.parent / "tools"))
import ci_quality_gate


class TestExitCodes:
    """Test exit code constants are correct."""

    def test_exit_codes(self):
        assert ci_quality_gate.EXIT_PASS == 0
        assert ci_quality_gate.EXIT_WARN == 10
        assert ci_quality_gate.EXIT_FAIL == 20
        assert ci_quality_gate.EXIT_NO_DATA == 2
        assert ci_quality_gate.EXIT_ERROR == 1


class TestStatusLabels:
    """Test status labels mapping."""

    def test_all_exit_codes_have_labels(self):
        assert ci_quality_gate.EXIT_PASS in ci_quality_gate.STATUS_LABELS
        assert ci_quality_gate.EXIT_WARN in ci_quality_gate.STATUS_LABELS
        assert ci_quality_gate.EXIT_FAIL in ci_quality_gate.STATUS_LABELS
        assert ci_quality_gate.EXIT_NO_DATA in ci_quality_gate.STATUS_LABELS
        assert ci_quality_gate.EXIT_ERROR in ci_quality_gate.STATUS_LABELS


class TestBatchOutCheck:
    """Test batch_out directory existence checks."""

    def test_check_batch_out_missing(self, tmp_path, monkeypatch):
        """Test handling of missing batch_out directory."""
        nonexistent = tmp_path / "nonexistent"
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: nonexistent)
        assert ci_quality_gate.check_batch_out_exists() is False

    def test_check_batch_out_empty(self, tmp_path, monkeypatch):
        """Test handling of empty batch_out directory."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: empty_dir)
        assert ci_quality_gate.check_batch_out_exists() is False

    def test_check_batch_out_with_file(self, tmp_path, monkeypatch):
        """Test batch_out with only files (no subdirectories)."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        (batch_dir / "file.txt").write_text("test")
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)
        assert ci_quality_gate.check_batch_out_exists() is False

    def test_check_batch_out_with_subdirs(self, tmp_path, monkeypatch):
        """Test batch_out with subdirectories (pairs)."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        (batch_dir / "pair1").mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)
        assert ci_quality_gate.check_batch_out_exists() is True


class TestQualityCheckExecution:
    """Test running mtbsync quality-check command."""

    def test_quality_check_success(self, monkeypatch, tmp_path):
        """Test successful quality check execution."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Status: OK"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            exit_code, stdout, stderr = ci_quality_gate.run_quality_check()

        assert exit_code == 0
        assert stdout == "Status: OK"
        assert stderr == ""
        mock_run.assert_called_once()

    def test_quality_check_warn(self, monkeypatch, tmp_path):
        """Test quality check returning WARN."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)

        mock_result = MagicMock()
        mock_result.returncode = 10
        mock_result.stdout = "Status: WARN"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result):
            exit_code, stdout, stderr = ci_quality_gate.run_quality_check()

        assert exit_code == 10

    def test_quality_check_fail(self, monkeypatch, tmp_path):
        """Test quality check returning FAIL."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)

        mock_result = MagicMock()
        mock_result.returncode = 20
        mock_result.stdout = "Status: FAIL"
        mock_result.stderr = "Severe regression detected"

        with patch("subprocess.run", return_value=mock_result):
            exit_code, stdout, stderr = ci_quality_gate.run_quality_check()

        assert exit_code == 20
        assert "FAIL" in stdout

    def test_quality_check_command_not_found(self, monkeypatch, tmp_path):
        """Test handling of missing mtbsync command."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)

        with patch("subprocess.run", side_effect=FileNotFoundError):
            exit_code, stdout, stderr = ci_quality_gate.run_quality_check()

        assert exit_code == ci_quality_gate.EXIT_ERROR
        assert "not found" in stderr

    def test_quality_check_timeout(self, monkeypatch, tmp_path):
        """Test handling of timeout."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)

        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="test", timeout=300)):
            exit_code, stdout, stderr = ci_quality_gate.run_quality_check()

        assert exit_code == ci_quality_gate.EXIT_ERROR
        assert "timed out" in stderr


class TestRegressionLoading:
    """Test loading regression.json data."""

    def test_load_regression_missing(self, tmp_path, monkeypatch):
        """Test loading when regression.json doesn't exist."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)

        data = ci_quality_gate.load_regression_json()
        assert data is None

    def test_load_regression_valid(self, tmp_path, monkeypatch):
        """Test loading valid regression.json."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        regression_file = batch_dir / "regression.json"

        regression_data = {
            "severity": "warn",
            "current": {"p90_sec": 1.5, "ppm": 250},
            "baseline": {"p90_sec": 1.0, "ppm": 200},
            "deltas": {"p90_sec": 0.5, "ppm": 50},
        }
        regression_file.write_text(json.dumps(regression_data))

        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)

        data = ci_quality_gate.load_regression_json()
        assert data is not None
        assert data["severity"] == "warn"
        assert data["current"]["p90_sec"] == 1.5

    def test_load_regression_invalid_json(self, tmp_path, monkeypatch, capsys):
        """Test handling of invalid JSON."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        regression_file = batch_dir / "regression.json"
        regression_file.write_text("invalid json {")

        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)

        data = ci_quality_gate.load_regression_json()
        assert data is None

        captured = capsys.readouterr()
        assert "Warning: Failed to load regression.json" in captured.err


class TestSummaryGeneration:
    """Test summary generation."""

    def test_summary_pass(self):
        """Test summary for PASS status."""
        summary = ci_quality_gate.generate_summary(ci_quality_gate.EXIT_PASS, None)
        assert "PASS" in summary
        assert "Quality check passed" in summary

    def test_summary_warn_with_data(self):
        """Test summary for WARN status with regression data."""
        regression_data = {
            "severity": "warn",
            "current": {"p90_sec": 1.5, "ppm": 250, "inlier_frac": 0.7},
            "baseline": {"p90_sec": 1.0, "ppm": 200, "inlier_frac": 0.75},
            "deltas": {"p90_sec": 0.5, "ppm": 50, "inlier_frac": -0.05},
            "thresholds": {"fail_p90_delta": 1.0, "warn_p90_delta": 0.5},
        }

        summary = ci_quality_gate.generate_summary(ci_quality_gate.EXIT_WARN, regression_data)
        assert "WARN" in summary
        assert "1.50s" in summary  # current p90
        assert "1.00s" in summary  # baseline p90
        assert "+0.50s" in summary  # delta

    def test_summary_fail(self):
        """Test summary for FAIL status."""
        regression_data = {
            "severity": "fail",
            "current": {"p90_sec": 2.0, "ppm": 350, "inlier_frac": 0.6},
            "baseline": {"p90_sec": 1.0, "ppm": 200, "inlier_frac": 0.75},
            "deltas": {"p90_sec": 1.0, "ppm": 150, "inlier_frac": -0.15},
        }

        summary = ci_quality_gate.generate_summary(ci_quality_gate.EXIT_FAIL, regression_data)
        assert "FAIL" in summary
        assert "regression detected" in summary

    def test_summary_no_data(self):
        """Test summary for NO DATA status."""
        summary = ci_quality_gate.generate_summary(ci_quality_gate.EXIT_NO_DATA, None)
        assert "NO DATA" in summary
        assert "No regression data available" in summary

    def test_summary_error(self):
        """Test summary for ERROR status."""
        summary = ci_quality_gate.generate_summary(ci_quality_gate.EXIT_ERROR, None)
        assert "ERROR" in summary
        assert "Error running quality check" in summary


class TestFormatting:
    """Test formatting helper functions."""

    def test_format_delta_positive(self):
        """Test formatting positive delta."""
        result = ci_quality_gate.format_delta(0.5, "s", sign=True)
        assert result == "+0.50s"

    def test_format_delta_negative(self):
        """Test formatting negative delta."""
        result = ci_quality_gate.format_delta(-0.3, "s", sign=True)
        assert result == "-0.30s"

    def test_format_delta_no_sign(self):
        """Test formatting delta without sign."""
        result = ci_quality_gate.format_delta(0.5, "s", sign=False)
        assert result == "0.50s"

    def test_format_delta_none(self):
        """Test formatting None delta."""
        result = ci_quality_gate.format_delta(None, "s")
        assert result == "N/A"

    def test_format_status_pass(self):
        """Test status formatting for PASS."""
        result = ci_quality_gate.format_status(ci_quality_gate.EXIT_PASS)
        assert "PASS" in result

    def test_format_status_warn(self):
        """Test status formatting for WARN."""
        result = ci_quality_gate.format_status(ci_quality_gate.EXIT_WARN)
        assert "WARN" in result

    def test_format_status_fail(self):
        """Test status formatting for FAIL."""
        result = ci_quality_gate.format_status(ci_quality_gate.EXIT_FAIL)
        assert "FAIL" in result


class TestSummaryFileWrite:
    """Test writing quality_gate.txt summary file."""

    def test_write_summary_file(self, tmp_path, monkeypatch):
        """Test writing summary file successfully."""
        monkeypatch.chdir(tmp_path)

        summary = "Test summary\nLine 2"
        ci_quality_gate.write_summary_file(summary, ci_quality_gate.EXIT_PASS)

        output_file = tmp_path / "quality_gate.txt"
        assert output_file.exists()
        content = output_file.read_text()
        assert "Test summary" in content
        assert "Line 2" in content

    def test_write_summary_strips_ansi(self, tmp_path, monkeypatch):
        """Test that ANSI color codes are stripped from file."""
        monkeypatch.chdir(tmp_path)

        summary = f"{ci_quality_gate.COLOR_GREEN}PASS{ci_quality_gate.COLOR_RESET}"
        ci_quality_gate.write_summary_file(summary, ci_quality_gate.EXIT_PASS)

        output_file = tmp_path / "quality_gate.txt"
        content = output_file.read_text()
        # ANSI codes should be stripped
        assert ci_quality_gate.COLOR_GREEN not in content
        assert ci_quality_gate.COLOR_RESET not in content
        assert "PASS" in content


class TestMainFunction:
    """Test main entry point."""

    def test_main_no_data(self, tmp_path, monkeypatch, capsys):
        """Test main with no batch_out data."""
        batch_dir = tmp_path / "batch_empty"
        batch_dir.mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)
        monkeypatch.chdir(tmp_path)

        exit_code = ci_quality_gate.main()
        assert exit_code == ci_quality_gate.EXIT_NO_DATA

        captured = capsys.readouterr()
        assert "NO DATA" in captured.err or "NO DATA" in captured.out

    def test_main_pass(self, tmp_path, monkeypatch, capsys):
        """Test main with passing quality check."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        (batch_dir / "pair1").mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)
        monkeypatch.chdir(tmp_path)

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Status: OK"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result):
            exit_code = ci_quality_gate.main()

        assert exit_code == ci_quality_gate.EXIT_PASS
        captured = capsys.readouterr()
        assert "PASS" in captured.err or "PASS" in captured.out

    def test_main_warn(self, tmp_path, monkeypatch):
        """Test main with WARN status (should not fail)."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        (batch_dir / "pair1").mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)
        monkeypatch.chdir(tmp_path)

        mock_result = MagicMock()
        mock_result.returncode = 10
        mock_result.stdout = "Status: WARN"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result):
            exit_code = ci_quality_gate.main()

        # WARN should return 10 but not fail the script
        assert exit_code == ci_quality_gate.EXIT_WARN

    def test_main_fail(self, tmp_path, monkeypatch):
        """Test main with FAIL status (should fail)."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        (batch_dir / "pair1").mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)
        monkeypatch.chdir(tmp_path)

        mock_result = MagicMock()
        mock_result.returncode = 20
        mock_result.stdout = "Status: FAIL"
        mock_result.stderr = "Severe regression"

        with patch("subprocess.run", return_value=mock_result):
            exit_code = ci_quality_gate.main()

        assert exit_code == ci_quality_gate.EXIT_FAIL

    def test_main_error(self, tmp_path, monkeypatch):
        """Test main with ERROR status (should fail)."""
        batch_dir = tmp_path / "batch"
        batch_dir.mkdir()
        (batch_dir / "pair1").mkdir()
        monkeypatch.setattr(ci_quality_gate, "get_batch_out_dir", lambda: batch_dir)
        monkeypatch.chdir(tmp_path)

        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "Error occurred"

        with patch("subprocess.run", return_value=mock_result):
            exit_code = ci_quality_gate.main()

        assert exit_code == ci_quality_gate.EXIT_ERROR

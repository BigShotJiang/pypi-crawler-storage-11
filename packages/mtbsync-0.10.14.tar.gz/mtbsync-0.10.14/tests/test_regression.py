"""
Tests for regression tracking module.
"""

import json
import pytest
from pathlib import Path
from mtbsync import regression


class TestDefaultThresholds:
    """Tests for default_thresholds function."""

    def test_returns_dict(self):
        thresholds = regression.default_thresholds()
        assert isinstance(thresholds, dict)

    def test_has_required_keys(self):
        thresholds = regression.default_thresholds()
        expected_keys = {
            "p90_reg_pct",
            "p90_reg_abs",
            "ppm_reg_pct",
            "ppm_reg_abs",
            "inlier_reg_pct",
            "inlier_reg_abs",
            "severe_multiplier",
        }
        assert set(thresholds.keys()) == expected_keys

    def test_values_are_floats(self):
        thresholds = regression.default_thresholds()
        for v in thresholds.values():
            assert isinstance(v, (int, float))


class TestLoadQualityHistory:
    """Tests for load_quality_history function."""

    def test_empty_when_file_missing(self, tmp_path):
        history = regression.load_quality_history(tmp_path)
        assert history == []

    def test_loads_valid_history(self, tmp_path):
        history_data = [
            {
                "ts": "2025-01-01T00:00:00Z",
                "run_id": "test1",
                "p90": 1.0,
                "ppm": 100,
                "inlier_frac": 0.8,
                "fps": 3.0,
            }
        ]
        history_path = tmp_path / "quality_history.json"
        with open(history_path, "w") as f:
            json.dump(history_data, f)

        history = regression.load_quality_history(tmp_path)
        assert len(history) == 1
        assert history[0]["run_id"] == "test1"

    def test_filters_invalid_records(self, tmp_path):
        history_data = [
            {"ts": "2025-01-01T00:00:00Z", "run_id": "valid", "p90": 1.0, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0},
            {"ts": "2025-01-01T00:00:00Z", "run_id": "missing_p90", "ppm": 100, "inlier_frac": 0.8, "fps": 3.0},  # Missing p90
            {"invalid": "record"},  # Missing all required fields
        ]
        history_path = tmp_path / "quality_history.json"
        with open(history_path, "w") as f:
            json.dump(history_data, f)

        history = regression.load_quality_history(tmp_path)
        assert len(history) == 1
        assert history[0]["run_id"] == "valid"

    def test_sorts_by_timestamp(self, tmp_path):
        history_data = [
            {"ts": "2025-01-03T00:00:00Z", "run_id": "third", "p90": 1.0, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0},
            {"ts": "2025-01-01T00:00:00Z", "run_id": "first", "p90": 1.0, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0},
            {"ts": "2025-01-02T00:00:00Z", "run_id": "second", "p90": 1.0, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0},
        ]
        history_path = tmp_path / "quality_history.json"
        with open(history_path, "w") as f:
            json.dump(history_data, f)

        history = regression.load_quality_history(tmp_path)
        assert len(history) == 3
        assert history[0]["run_id"] == "first"
        assert history[1]["run_id"] == "second"
        assert history[2]["run_id"] == "third"

    def test_limits_to_max_records(self, tmp_path):
        # Create more records than limit
        history_data = [
            {"ts": f"2025-01-01T{i:02d}:00:00Z", "run_id": f"run{i}", "p90": 1.0, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0}
            for i in range(100)
        ]
        history_path = tmp_path / "quality_history.json"
        with open(history_path, "w") as f:
            json.dump(history_data, f)

        history = regression.load_quality_history(tmp_path, limit=10)
        assert len(history) == 10
        # Should keep most recent 10
        assert history[-1]["run_id"] == "run99"

    def test_handles_malformed_json(self, tmp_path):
        history_path = tmp_path / "quality_history.json"
        with open(history_path, "w") as f:
            f.write("invalid json{")

        history = regression.load_quality_history(tmp_path)
        assert history == []


class TestAppendQualityRecord:
    """Tests for append_quality_record function."""

    def test_creates_new_history(self, tmp_path):
        record = {
            "ts": "2025-01-01T00:00:00Z",
            "run_id": "test1",
            "p90": 1.0,
            "ppm": 100,
            "inlier_frac": 0.8,
            "fps": 3.0,
        }

        regression.append_quality_record(tmp_path, record)

        history_path = tmp_path / "quality_history.json"
        assert history_path.exists()

        with open(history_path) as f:
            history = json.load(f)

        assert len(history) == 1
        assert history[0]["run_id"] == "test1"

    def test_appends_to_existing_history(self, tmp_path):
        # Create initial history
        record1 = {
            "ts": "2025-01-01T00:00:00Z",
            "run_id": "test1",
            "p90": 1.0,
            "ppm": 100,
            "inlier_frac": 0.8,
            "fps": 3.0,
        }
        regression.append_quality_record(tmp_path, record1)

        # Append second record
        record2 = {
            "ts": "2025-01-02T00:00:00Z",
            "run_id": "test2",
            "p90": 1.1,
            "ppm": 110,
            "inlier_frac": 0.75,
            "fps": 3.2,
        }
        regression.append_quality_record(tmp_path, record2)

        history = regression.load_quality_history(tmp_path)
        assert len(history) == 2
        assert history[0]["run_id"] == "test1"
        assert history[1]["run_id"] == "test2"

    def test_raises_on_missing_fields(self, tmp_path):
        record = {
            "ts": "2025-01-01T00:00:00Z",
            "run_id": "test1",
            # Missing p90, ppm, inlier_frac, fps
        }

        with pytest.raises(ValueError, match="missing required fields"):
            regression.append_quality_record(tmp_path, record)


class TestComputeBaseline:
    """Tests for compute_baseline function."""

    def test_empty_history(self):
        baseline = regression.compute_baseline([])
        assert baseline["n_used"] == 0
        assert baseline["sufficient"] is False
        assert baseline["p90_baseline"] is None

    def test_insufficient_history(self):
        history = [
            {"p90": 1.0, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0}
            for _ in range(5)
        ]
        baseline = regression.compute_baseline(history, window=50)
        assert baseline["n_used"] == 5
        assert baseline["sufficient"] is False

    def test_sufficient_history(self):
        history = [
            {"p90": float(i), "ppm": float(i * 100), "inlier_frac": 0.8, "fps": 3.0}
            for i in range(20)
        ]
        baseline = regression.compute_baseline(history, window=50)
        assert baseline["n_used"] == 20
        assert baseline["sufficient"] is True

    def test_computes_median_correctly(self):
        history = [
            {"p90": 1.0, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0},
            {"p90": 2.0, "ppm": 200, "inlier_frac": 0.9, "fps": 3.5},
            {"p90": 3.0, "ppm": 300, "inlier_frac": 0.7, "fps": 2.5},
        ]
        baseline = regression.compute_baseline(history, window=50)
        assert baseline["p90_baseline"] == 2.0  # Median of [1, 2, 3]
        assert baseline["ppm_baseline"] == 200.0
        assert baseline["inlier_baseline"] == 0.8
        assert baseline["fps_baseline"] == 3.0

    def test_window_limits_data(self):
        history = [
            {"p90": float(i), "ppm": float(i * 100), "inlier_frac": 0.8, "fps": 3.0}
            for i in range(100)
        ]
        baseline = regression.compute_baseline(history, window=10)
        assert baseline["n_used"] == 10
        # Should use last 10 values (90-99)
        assert baseline["p90_baseline"] == 94.5  # Median of [90, 91, ..., 99]

    def test_handles_none_values(self):
        history = [
            {"p90": 1.0, "ppm": None, "inlier_frac": 0.8, "fps": 3.0},
            {"p90": 2.0, "ppm": 200, "inlier_frac": None, "fps": 3.5},
            {"p90": 3.0, "ppm": 300, "inlier_frac": 0.7, "fps": None},
        ]
        baseline = regression.compute_baseline(history, window=50)
        assert baseline["p90_baseline"] == 2.0
        assert baseline["ppm_baseline"] == 250.0  # Median of [200, 300]
        assert baseline["inlier_baseline"] == 0.75  # Median of [0.8, 0.7]
        assert baseline["fps_baseline"] == 3.25  # Median of [3.0, 3.5]


class TestEvaluateRegression:
    """Tests for evaluate_regression function."""

    def test_insufficient_baseline(self):
        current = {"p90": 1.0, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0}
        baseline = {"n_used": 5, "sufficient": False}
        result = regression.evaluate_regression(current, baseline)
        assert result["status"] == "learning"

    def test_missing_current_metrics(self):
        current = {"p90": None, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0}
        baseline = {
            "n_used": 20,
            "sufficient": True,
            "p90_baseline": 1.0,
            "ppm_baseline": 100.0,
            "inlier_baseline": 0.8,
        }
        result = regression.evaluate_regression(current, baseline)
        assert result["status"] == "empty"

    def test_ok_status(self):
        current = {"p90": 1.0, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0}
        baseline = {
            "n_used": 20,
            "sufficient": True,
            "p90_baseline": 1.0,
            "ppm_baseline": 100.0,
            "inlier_baseline": 0.8,
        }
        result = regression.evaluate_regression(current, baseline)
        assert result["status"] == "ok"
        assert "All metrics within baseline thresholds" in result["reasons"]

    def test_warn_status_p90(self):
        current = {"p90": 1.5, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0}
        baseline = {
            "n_used": 20,
            "sufficient": True,
            "p90_baseline": 1.0,
            "ppm_baseline": 100.0,
            "inlier_baseline": 0.8,
        }
        result = regression.evaluate_regression(current, baseline)
        assert result["status"] == "warn"
        assert any("P90 regression" in r for r in result["reasons"])

    def test_fail_status_p90(self):
        current = {"p90": 2.0, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0}
        baseline = {
            "n_used": 20,
            "sufficient": True,
            "p90_baseline": 1.0,
            "ppm_baseline": 100.0,
            "inlier_baseline": 0.8,
        }
        result = regression.evaluate_regression(current, baseline)
        assert result["status"] == "fail"
        assert any("P90 regression (severe)" in r for r in result["reasons"])

    def test_warn_status_ppm(self):
        current = {"p90": 1.0, "ppm": 150, "inlier_frac": 0.8, "fps": 3.0}
        baseline = {
            "n_used": 20,
            "sufficient": True,
            "p90_baseline": 1.0,
            "ppm_baseline": 100.0,
            "inlier_baseline": 0.8,
        }
        thresholds = regression.default_thresholds()
        thresholds["ppm_reg_abs"] = 40.0  # Lower threshold for test
        result = regression.evaluate_regression(current, baseline, thresholds)
        assert result["status"] == "warn"

    def test_warn_status_inlier(self):
        current = {"p90": 1.0, "ppm": 100, "inlier_frac": 0.65, "fps": 3.0}
        baseline = {
            "n_used": 20,
            "sufficient": True,
            "p90_baseline": 1.0,
            "ppm_baseline": 100.0,
            "inlier_baseline": 0.8,
        }
        result = regression.evaluate_regression(current, baseline)
        assert result["status"] == "warn"
        assert any("Inlier fraction regression" in r for r in result["reasons"])

    def test_custom_thresholds(self):
        current = {"p90": 1.1, "ppm": 100, "inlier_frac": 0.8, "fps": 3.0}
        baseline = {
            "n_used": 20,
            "sufficient": True,
            "p90_baseline": 1.0,
            "ppm_baseline": 100.0,
            "inlier_baseline": 0.8,
        }
        thresholds = regression.default_thresholds()
        thresholds["p90_reg_pct"] = 0.05  # Very strict: 5%
        thresholds["p90_reg_abs"] = 0.05   # Also adjust absolute threshold
        result = regression.evaluate_regression(current, baseline, thresholds)
        assert result["status"] == "warn"

    def test_deltas_computed(self):
        current = {"p90": 1.2, "ppm": 120, "inlier_frac": 0.75, "fps": 3.0}
        baseline = {
            "n_used": 20,
            "sufficient": True,
            "p90_baseline": 1.0,
            "ppm_baseline": 100.0,
            "inlier_baseline": 0.8,
        }
        result = regression.evaluate_regression(current, baseline)
        deltas = result["deltas"]
        assert deltas["p90_delta"] == pytest.approx(0.2)
        assert deltas["p90_delta_pct"] == pytest.approx(0.2)
        assert deltas["ppm_delta"] == pytest.approx(20.0)
        assert deltas["inlier_delta"] == pytest.approx(-0.05)


class TestCreateQualityRecord:
    """Tests for create_quality_record function."""

    def test_creates_record_with_required_fields(self):
        record = regression.create_quality_record(
            run_id="test1",
            p90=1.0,
            ppm=100.0,
            inlier_frac=0.8,
            fps=3.0,
        )

        assert record["run_id"] == "test1"
        assert record["p90"] == 1.0
        assert record["ppm"] == 100.0
        assert record["inlier_frac"] == 0.8
        assert record["fps"] == 3.0
        assert "ts" in record
        # Timestamp should be ISO8601 format
        assert "T" in record["ts"]

    def test_creates_record_with_optional_fields(self):
        record = regression.create_quality_record(
            run_id="test1",
            p90=1.0,
            ppm=100.0,
            inlier_frac=0.8,
            fps=3.0,
            cpu_pct=50.0,
            gpu_util=75.0,
        )

        assert record["cpu_pct"] == 50.0
        assert record["gpu_util"] == 75.0

    def test_omits_none_optional_fields(self):
        record = regression.create_quality_record(
            run_id="test1",
            p90=1.0,
            ppm=100.0,
            inlier_frac=0.8,
            fps=3.0,
            cpu_pct=None,
            gpu_util=None,
        )

        assert "cpu_pct" not in record
        assert "gpu_util" not in record


class TestEndToEnd:
    """End-to-end integration tests."""

    def test_full_workflow(self, tmp_path):
        # Create 15 quality records
        for i in range(15):
            record = regression.create_quality_record(
                run_id=f"run{i}",
                p90=1.0 + i * 0.1,
                ppm=100 + i * 10,
                inlier_frac=0.8 - i * 0.01,
                fps=3.0,
            )
            regression.append_quality_record(tmp_path, record)

        # Load history
        history = regression.load_quality_history(tmp_path)
        assert len(history) == 15

        # Compute baseline
        baseline = regression.compute_baseline(history)
        assert baseline["sufficient"] is True

        # Evaluate last run (should be within thresholds)
        current = {
            "p90": history[-1]["p90"],
            "ppm": history[-1]["ppm"],
            "inlier_frac": history[-1]["inlier_frac"],
            "fps": history[-1]["fps"],
        }
        result = regression.evaluate_regression(current, baseline)
        assert result["status"] in ["ok", "warn"]  # Depending on threshold

"""
Regression tracking and auto-gating for quality metrics.

Maintains a rolling quality ledger (quality_history.json) with P90, PPM, inlier_frac, FPS per run.
Computes baseline from last N runs and flags regressions with warn/fail severity.
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


# Constants
MAX_HISTORY_RECORDS = 2000
DEFAULT_WINDOW = 50
QUALITY_HISTORY_FILE = "quality_history.json"
REGRESSION_RESULT_FILE = "regression.json"

# Required fields in quality records
REQUIRED_FIELDS = {"ts", "run_id", "p90", "ppm", "inlier_frac", "fps"}


def default_thresholds() -> Dict[str, float]:
    """
    Default regression thresholds for warn/fail gates.

    Returns:
        Dict with keys:
            p90_reg_pct, p90_reg_abs: P90 regression % and absolute (seconds)
            ppm_reg_pct, ppm_reg_abs: PPM regression % and absolute
            inlier_reg_pct, inlier_reg_abs: Inlier fraction regression % and absolute
            severe_multiplier: Factor for fail threshold (default 2×warn)
    """
    return {
        "p90_reg_pct": 0.25,      # +25%
        "p90_reg_abs": 0.25,      # +0.25s
        "ppm_reg_pct": 0.25,      # +25%
        "ppm_reg_abs": 150.0,     # +150 ppm
        "inlier_reg_pct": 0.15,   # -15%
        "inlier_reg_abs": 0.05,   # -0.05 (5 percentage points)
        "severe_multiplier": 2.0  # 2× threshold for fail
    }


def load_quality_history(root: Path, limit: int = MAX_HISTORY_RECORDS) -> List[Dict[str, Any]]:
    """
    Load quality_history.json from root directory.

    Args:
        root: Root directory containing quality_history.json
        limit: Maximum number of records to return (most recent)

    Returns:
        List of quality records sorted oldest→newest, limited to last N records.
        Empty list if file doesn't exist or is invalid.
    """
    history_path = root / QUALITY_HISTORY_FILE
    if not history_path.exists():
        return []

    try:
        with open(history_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            return []

        # Validate minimal schema and filter invalid records
        valid_records = []
        for record in data:
            if not isinstance(record, dict):
                continue
            # Check required fields exist (allow None values for robustness)
            if REQUIRED_FIELDS.issubset(record.keys()):
                valid_records.append(record)

        # Sort by timestamp (oldest→newest) and limit to most recent
        valid_records.sort(key=lambda r: r.get("ts", ""))
        return valid_records[-limit:]

    except (json.JSONDecodeError, IOError, OSError):
        # Best-effort: return empty on any error
        return []


def append_quality_record(root: Path, record: Dict[str, Any]) -> None:
    """
    Append a quality record to quality_history.json atomically.

    Args:
        root: Root directory containing quality_history.json
        record: Quality record dict with required fields (ts, run_id, p90, ppm, inlier_frac, fps)

    Raises:
        ValueError: If record missing required fields
    """
    # Validate record
    if not REQUIRED_FIELDS.issubset(record.keys()):
        missing = REQUIRED_FIELDS - set(record.keys())
        raise ValueError(f"Quality record missing required fields: {missing}")

    root.mkdir(parents=True, exist_ok=True)
    history_path = root / QUALITY_HISTORY_FILE

    # Load existing history
    history = load_quality_history(root, limit=MAX_HISTORY_RECORDS - 1)

    # Append new record
    history.append(record)

    # Write atomically (write to temp, then rename)
    temp_path = history_path.with_suffix(".tmp")
    try:
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2)
        temp_path.replace(history_path)
    except (IOError, OSError) as e:
        # Clean up temp file on error
        if temp_path.exists():
            temp_path.unlink()
        raise RuntimeError(f"Failed to write quality history: {e}") from e


def compute_baseline(history: List[Dict[str, Any]], window: int = DEFAULT_WINDOW) -> Dict[str, Any]:
    """
    Compute rolling baseline statistics from last N records.

    Args:
        history: List of quality records (oldest→newest)
        window: Number of most recent records to use for baseline

    Returns:
        Dict with keys:
            p90_baseline, ppm_baseline, inlier_baseline, fps_baseline: Median values
            n_used: Number of records used for baseline
            sufficient: True if n_used >= 10 (minimum for gating)
    """
    if not history:
        return {
            "p90_baseline": None,
            "ppm_baseline": None,
            "inlier_baseline": None,
            "fps_baseline": None,
            "n_used": 0,
            "sufficient": False
        }

    # Take last N records
    recent = history[-window:]
    n_used = len(recent)

    # Extract metrics (filter out None values)
    p90_values = [r["p90"] for r in recent if r.get("p90") is not None]
    ppm_values = [r["ppm"] for r in recent if r.get("ppm") is not None]
    inlier_values = [r["inlier_frac"] for r in recent if r.get("inlier_frac") is not None]
    fps_values = [r["fps"] for r in recent if r.get("fps") is not None]

    # Compute medians
    def median(values: List[float]) -> Optional[float]:
        if not values:
            return None
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        mid = n // 2
        if n % 2 == 0:
            return (sorted_vals[mid - 1] + sorted_vals[mid]) / 2.0
        else:
            return sorted_vals[mid]

    return {
        "p90_baseline": median(p90_values),
        "ppm_baseline": median(ppm_values),
        "inlier_baseline": median(inlier_values),
        "fps_baseline": median(fps_values),
        "n_used": n_used,
        "sufficient": n_used >= 10  # Minimum for reliable gating
    }


def evaluate_regression(
    current: Dict[str, Any],
    baseline: Dict[str, Any],
    thresholds: Optional[Dict[str, float]] = None
) -> Dict[str, Any]:
    """
    Evaluate current run against baseline with configurable thresholds.

    Args:
        current: Current run metrics (p90, ppm, inlier_frac, fps)
        baseline: Baseline metrics from compute_baseline()
        thresholds: Optional threshold overrides (uses default_thresholds() if None)

    Returns:
        Dict with keys:
            status: "ok" | "warn" | "fail" | "learning" | "empty"
            reasons: List of human-readable regression messages
            current: Echo of current metrics
            baseline: Echo of baseline metrics
            thresholds: Thresholds used for evaluation
            deltas: Dict with computed deltas (p90_delta, ppm_delta, etc.)
    """
    if thresholds is None:
        thresholds = default_thresholds()

    # Handle empty/insufficient baseline
    if not baseline.get("sufficient"):
        return {
            "status": "learning",
            "reasons": [f"Insufficient history for gating (n={baseline.get('n_used', 0)}, need ≥10)"],
            "current": current,
            "baseline": baseline,
            "thresholds": thresholds,
            "deltas": {}
        }

    # Extract current metrics
    p90_cur = current.get("p90")
    ppm_cur = current.get("ppm")
    inlier_cur = current.get("inlier_frac")

    # Extract baseline metrics
    p90_base = baseline.get("p90_baseline")
    ppm_base = baseline.get("ppm_baseline")
    inlier_base = baseline.get("inlier_baseline")

    # Check for missing data
    if p90_cur is None or ppm_cur is None or inlier_cur is None:
        return {
            "status": "empty",
            "reasons": ["Current run missing required metrics (p90/ppm/inlier_frac)"],
            "current": current,
            "baseline": baseline,
            "thresholds": thresholds,
            "deltas": {}
        }

    if p90_base is None or ppm_base is None or inlier_base is None:
        return {
            "status": "learning",
            "reasons": ["Baseline missing required metrics (likely all-fail history)"],
            "current": current,
            "baseline": baseline,
            "thresholds": thresholds,
            "deltas": {}
        }

    # Compute deltas
    p90_delta = p90_cur - p90_base
    ppm_delta = ppm_cur - ppm_base
    inlier_delta = inlier_cur - inlier_base

    p90_delta_pct = (p90_delta / p90_base) if p90_base > 0 else 0.0
    ppm_delta_pct = (ppm_delta / ppm_base) if abs(ppm_base) > 1e-6 else 0.0
    inlier_delta_pct = (inlier_delta / inlier_base) if inlier_base > 0 else 0.0

    deltas = {
        "p90_delta": p90_delta,
        "p90_delta_pct": p90_delta_pct,
        "ppm_delta": ppm_delta,
        "ppm_delta_pct": ppm_delta_pct,
        "inlier_delta": inlier_delta,
        "inlier_delta_pct": inlier_delta_pct
    }

    # Evaluate regressions
    reasons = []
    severity = "ok"  # ok < warn < fail

    # P90 regression (higher is worse)
    p90_warn_threshold = max(
        p90_base * (1 + thresholds["p90_reg_pct"]),
        p90_base + thresholds["p90_reg_abs"]
    )
    p90_fail_threshold = max(
        p90_base * (1 + thresholds["p90_reg_pct"] * thresholds["severe_multiplier"]),
        p90_base + thresholds["p90_reg_abs"] * thresholds["severe_multiplier"]
    )

    if p90_cur > p90_fail_threshold:
        reasons.append(f"P90 regression (severe): {p90_cur:.2f}s vs baseline {p90_base:.2f}s (+{p90_delta_pct*100:.1f}%)")
        severity = "fail"
    elif p90_cur > p90_warn_threshold:
        reasons.append(f"P90 regression: {p90_cur:.2f}s vs baseline {p90_base:.2f}s (+{p90_delta_pct*100:.1f}%)")
        if severity == "ok":
            severity = "warn"

    # PPM regression (higher is worse)
    ppm_warn_threshold = max(
        ppm_base * (1 + thresholds["ppm_reg_pct"]),
        ppm_base + thresholds["ppm_reg_abs"]
    )
    ppm_fail_threshold = max(
        ppm_base * (1 + thresholds["ppm_reg_pct"] * thresholds["severe_multiplier"]),
        ppm_base + thresholds["ppm_reg_abs"] * thresholds["severe_multiplier"]
    )

    if ppm_cur > ppm_fail_threshold:
        reasons.append(f"PPM regression (severe): {ppm_cur:.0f} vs baseline {ppm_base:.0f} (+{ppm_delta_pct*100:.1f}%)")
        severity = "fail"
    elif ppm_cur > ppm_warn_threshold:
        reasons.append(f"PPM regression: {ppm_cur:.0f} vs baseline {ppm_base:.0f} (+{ppm_delta_pct*100:.1f}%)")
        if severity == "ok":
            severity = "warn"

    # Inlier fraction regression (lower is worse)
    inlier_warn_threshold = min(
        inlier_base * (1 - thresholds["inlier_reg_pct"]),
        inlier_base - thresholds["inlier_reg_abs"]
    )
    inlier_fail_threshold = min(
        inlier_base * (1 - thresholds["inlier_reg_pct"] * thresholds["severe_multiplier"]),
        inlier_base - thresholds["inlier_reg_abs"] * thresholds["severe_multiplier"]
    )

    if inlier_cur < inlier_fail_threshold:
        reasons.append(f"Inlier fraction regression (severe): {inlier_cur:.2f} vs baseline {inlier_base:.2f} ({inlier_delta_pct*100:.1f}%)")
        severity = "fail"
    elif inlier_cur < inlier_warn_threshold:
        reasons.append(f"Inlier fraction regression: {inlier_cur:.2f} vs baseline {inlier_base:.2f} ({inlier_delta_pct*100:.1f}%)")
        if severity == "ok":
            severity = "warn"

    if severity == "ok":
        reasons.append("All metrics within baseline thresholds")

    return {
        "status": severity,
        "reasons": reasons,
        "current": current,
        "baseline": baseline,
        "thresholds": thresholds,
        "deltas": deltas
    }


def create_quality_record(
    run_id: str,
    p90: float,
    ppm: float,
    inlier_frac: float,
    fps: float,
    cpu_pct: Optional[float] = None,
    gpu_util: Optional[float] = None
) -> Dict[str, Any]:
    """
    Create a quality record dict with ISO8601 timestamp.

    Args:
        run_id: Unique identifier for this run (e.g., pair name, sync command)
        p90: P90 residual (seconds)
        ppm: Parts-per-million drift
        inlier_frac: Inlier fraction
        fps: Processing FPS
        cpu_pct: Optional CPU utilization %
        gpu_util: Optional GPU utilization %

    Returns:
        Quality record dict ready for append_quality_record()
    """
    record = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "run_id": run_id,
        "p90": p90,
        "ppm": ppm,
        "inlier_frac": inlier_frac,
        "fps": fps
    }

    if cpu_pct is not None:
        record["cpu_pct"] = cpu_pct
    if gpu_util is not None:
        record["gpu_util"] = gpu_util

    return record

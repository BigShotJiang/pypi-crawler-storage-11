from __future__ import annotations

import csv
import json
import os
import sys
import time
import threading
import webbrowser
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, Any, Optional
from urllib.parse import urlparse, parse_qs


def _safe_under_root(root: Path, candidate: Path) -> Optional[Path]:
    """Return candidate if it resolves under root; otherwise None."""
    try:
        c = (root / candidate).resolve() if not candidate.is_absolute() else candidate.resolve()
        r = root.resolve()
        return c if str(c).startswith(str(r) + os.sep) or c == r else None
    except Exception:
        return None


def _list_perf_files(root: Path) -> list[Path]:
    """List all perf.json paths under root (sorted newest→oldest)."""
    try:
        files = list(root.glob("**/perf.json"))
        files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return files
    except Exception:
        return []


def _prune_perf_files(root: Path, keep_newest: int) -> Dict[str, Any]:
    """
    Keep newest N perf.json files by mtime; delete older ones.
    Returns a summary dict {kept, deleted, total}.
    """
    root = root.resolve()
    files = _list_perf_files(root)
    total = len(files)
    if total <= keep_newest:
        return {"kept": total, "deleted": 0, "total": total}
    to_delete = files[keep_newest:]
    deleted = 0
    for p in to_delete:
        try:
            # Safety: ensure file is under root and is named perf.json
            if p.name != "perf.json":
                continue
            safe = _safe_under_root(root, p)
            if not safe:
                continue
            safe.unlink(missing_ok=True)
            deleted += 1
        except Exception:
            continue
    return {"kept": total - deleted, "deleted": deleted, "total": total}


def _find_benchmark_report(root: Path) -> Optional[str]:
    """
    Check if benchmark_out/report.html exists under root.
    Returns relative URL for dashboard file serving if found, else None.
    """
    try:
        p = root / "benchmark_out" / "report.html"
        if p.exists() and p.is_file():
            # Return relative URL served by dashboard (matches SimpleHTTPRequestHandler behavior)
            return "/benchmark_out/report.html"
        return None
    except Exception:
        return None


INDEX_HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>MTB Sync Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
  body { font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif; margin: 20px; }
  h1 { margin: 0 0 16px 0; }
  .cards { display: grid; gap: 12px; grid-template-columns: repeat(auto-fit,minmax(280px,1fr)); }
  .card { border: 1px solid #ddd; border-radius: 8px; padding: 12px; }
  table { border-collapse: collapse; width: 100%; }
  th, td { padding: 6px 8px; border-bottom: 1px solid #eee; text-align: left; font-size: 14px; }
  .muted { color: #555; font-size: 13px; }
  code { background: #f6f8fa; padding: 2px 4px; border-radius: 4px; }
  .sparkline { display: inline-block; margin-left: 8px; vertical-align: middle; }
  .controls { margin: 12px 0; }
  select, button { padding: 6px 10px; margin-right: 8px; font-size: 14px; }
  button { background: #0969da; color: white; border: none; border-radius: 6px; cursor: pointer; }
  button:hover { background: #0550ae; }
  button:disabled { background: #6c757d; cursor: not-allowed; }
  .gauge { height: 8px; background: #eee; position: relative; border-radius: 4px; overflow: hidden; }
  .gauge > span { display:block; height:100%; background:#8bc34a; }
  .gauge.warn > span { background:#ffc107; }
  .gauge.danger > span { background:#f44336; }
</style>
</head>
<body>
  <h1>MTB Sync — Dashboard</h1>
  <p class="muted">Browse alignment artefacts in <code id="rootSpan"></code></p>

  <div class="cards">
    <div class="card">
      <h3>Time-Warp</h3>
      <pre id="timewarpBox" class="muted">Loading...</pre>
    </div>
    <div class="card">
      <h3>Batch Summary</h3>
      <div id="batchBox" class="muted">Loading...</div>
    </div>
    <div class="card">
      <h3>Markers (first 10)
        <div class="controls">
          <select id="markerSelect" style="display:none;"></select>
          <button id="exportBtn" style="display:none;" onclick="exportJSON()">Export JSON</button>
        </div>
      </h3>
      <div id="markersBox" class="muted">Loading...</div>
    </div>
    <div class="card">
      <h3>Telemetry</h3>
      <div id="perfBox" class="muted">Loading...</div>
      <div id="perfLive" class="muted" style="margin-top:8px;"></div>
      <div style="margin-top:8px;">
        <label for="keepN">Keep newest</label>
        <input id="keepN" type="number" value="200" min="0" style="width:80px;" />
        <button id="pruneBtn">Prune perf.json</button>
        <span id="pruneMsg" class="muted"></span>
      </div>
      <!-- BENCHMARK_LINK -->
    </div>
    <div class="card">
      <h3>Regression</h3>
      <div id="regressionBox" class="muted">Loading...</div>
    </div>
    <div class="card">
      <h3>Time-series (last 500 runs)</h3>
      <div id="timeseriesBox" class="muted">Loading...</div>
    </div>
  </div>

  <h2 style="margin-top:20px;">Files</h2>
  <div id="filesBox" class="muted">Loading...</div>

<script>
const el = (sel) => document.querySelector(sel);
let currentMarkerFile = null;

async function loadJSON(path) {
  try {
    const r = await fetch(path);
    if (!r.ok) throw new Error(r.statusText);
    return await r.json();
  } catch (e) { return { error: String(e) }; }
}

function renderTable(headers, rows) {
  if (!rows || !rows.length) return "<p class='muted'>No rows.</p>";
  let thead = "<thead><tr>"+headers.map(h=>`<th>${h}</th>`).join("")+"</tr></thead>";
  let tbody = "<tbody>"+rows.map(r=>"<tr>"+headers.map(h=>`<td>${(r[h]??"")}</td>`).join("")+"</tr>").join("")+"</tbody>";
  return "<table>"+thead+tbody+"</table>";
}

function renderSparkline(values, width=60, height=20) {
  if (!values || !values.length) return "";
  const max = Math.max(...values, 0.01);
  const points = values.map((v,i) => {
    const x = (i / (values.length-1 || 1)) * width;
    const y = height - (v / max) * height;
    return `${x},${y}`;
  }).join(" ");
  return `<svg class="sparkline" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
    <polyline fill="none" stroke="#0969da" stroke-width="1.5" points="${points}"/>
  </svg>`;
}

function renderTimeSeriesChart(title, values, width=480, height=80) {
  // Filter out null/undefined values and create point pairs
  const validPoints = values.map((v, i) => ({ x: i, y: v }))
                             .filter(p => p.y !== null && p.y !== undefined && !isNaN(p.y));

  if (!validPoints.length) {
    return `<div style="margin-bottom:16px;">
      <div style="font-weight:500; margin-bottom:4px;">${title}</div>
      <div style="border:1px solid #ddd; padding:8px; background:#f9f9f9; text-align:center; color:#999;">
        (no data)
      </div>
    </div>`;
  }

  const yValues = validPoints.map(p => p.y);
  const yMin = Math.min(...yValues);
  const yMax = Math.max(...yValues);
  const yRange = yMax - yMin || 1; // Avoid division by zero for flat lines

  // Scale points to SVG coordinates
  const padding = 10;
  const plotWidth = width - 2 * padding;
  const plotHeight = height - 2 * padding;

  const points = validPoints.map(p => {
    const x = padding + (p.x / (values.length - 1 || 1)) * plotWidth;
    const y = padding + plotHeight - ((p.y - yMin) / yRange) * plotHeight;
    return `${x.toFixed(2)},${y.toFixed(2)}`;
  }).join(" ");

  return `<div style="margin-bottom:16px;">
    <div style="font-weight:500; margin-bottom:4px;">
      ${title}
      <span class="muted" style="font-size:12px; font-weight:400;">
        (min: ${yMin.toFixed(2)}, max: ${yMax.toFixed(2)})
      </span>
    </div>
    <svg width="${width}" height="${height}" style="border:1px solid #ddd; background:#fafafa;">
      <title>${title} time-series</title>
      <polyline fill="none" stroke="#0969da" stroke-width="2" points="${points}"/>
    </svg>
  </div>`;
}

async function loadMarkers(file) {
  const data = file ? await loadJSON(`/api/markers?file=${encodeURIComponent(file)}`) : await loadJSON("/api/markers");
  if (data && data.rows) {
    const headers = data.headers || Object.keys(data.rows[0] || {});
    const sample = data.rows.slice(0, 10);
    el("#markersBox").innerHTML = renderTable(headers, sample);
    currentMarkerFile = file || data.file || null;
  } else {
    el("#markersBox").textContent = JSON.stringify(data, null, 2);
  }
}

async function exportJSON() {
  if (!currentMarkerFile) {
    alert("No marker file selected");
    return;
  }
  try {
    const resp = await fetch("/api/export-json", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({in_csv: currentMarkerFile, out_json: currentMarkerFile.replace(".csv", ".json")})
    });
    const result = await resp.json();
    if (resp.ok) {
      alert(`Exported to ${result.path || "JSON file"}`);
    } else {
      alert(`Error: ${result.error || "Export failed"}`);
    }
  } catch (e) {
    alert(`Export error: ${e}`);
  }
}

async function init() {
  el("#rootSpan").textContent = window.location.pathname.replace(/\/$/,"") || "/";
  const [tw, batch, markerList, files, perf, history, regression] = await Promise.all([
    loadJSON("/api/timewarp"),
    loadJSON("/api/batch"),
    loadJSON("/api/marker-list"),
    loadJSON("/api/files"),
    loadJSON("/api/perf"),
    loadJSON("/api/perf/history?limit=500&fields=fps,cpu_pct,gpu_util,gpu_mem_mb,rss_mb"),
    loadJSON("/api/regression")
  ]);

  el("#timewarpBox").textContent = JSON.stringify(tw, null, 2);

  // Batch summary with sparklines
  if (batch && batch.rows) {
    const headers = batch.headers || Object.keys(batch.rows[0] || {});
    let html = renderTable(headers, batch.rows);

    // Add sparklines for timing columns
    if (batch.rows.length > 1) {
      const retrieval = batch.rows.map(r => parseFloat(r.retrieval_sec) || 0).filter(v => v > 0);
      const warp = batch.rows.map(r => parseFloat(r.warp_sec) || 0).filter(v => v > 0);
      if (retrieval.length) html += "<p class='muted'>Retrieval " + renderSparkline(retrieval) + "</p>";
      if (warp.length) html += "<p class='muted'>Warp " + renderSparkline(warp) + "</p>";
    }
    el("#batchBox").innerHTML = html;
  } else {
    el("#batchBox").textContent = JSON.stringify(batch, null, 2);
  }

  // Marker selector
  if (markerList && markerList.files && markerList.files.length) {
    const sel = el("#markerSelect");
    sel.innerHTML = markerList.files.map(f => `<option value="${f}">${f}</option>`).join("");
    sel.style.display = "inline-block";
    sel.onchange = () => loadMarkers(sel.value);
    el("#exportBtn").style.display = "inline-block";
    await loadMarkers(markerList.files[0]);
  } else {
    await loadMarkers(null);
  }

  // Files
  if (files && files.items) {
    const list = files.items.map(x => `<div><a href="${x.href}" download>${x.name}</a> <span class="muted">(${x.size} B)</span></div>`).join("");
    el("#filesBox").innerHTML = list || "<p class='muted'>No files</p>";
  } else {
    el("#filesBox").textContent = JSON.stringify(files, null, 2);
  }

  // Telemetry
  if (perf && perf.items) {
    const rows = perf.items.map((x,i) => ({
      idx: i+1,
      cmd: x.cmd || "",
      fps: (x.fps ?? (x.timings?.frames_processed && x.timings?.retrieval_sec ? (x.timings.frames_processed / x.timings.retrieval_sec).toFixed(2) : "")),
      wall: (x.timings?.total_sec ?? "").toString(),
      cpu: (x.cpu_pct ?? ""),
      gpu: (x.gpu_util ?? ""),
      vram_mb: (x.gpu_mem_mb ?? ""),
      rss_mb: x.rss_mb?.toFixed ? x.rss_mb.toFixed(1) : x.rss_mb,
      file: x._path || ""
    }));
    const headers = ["idx","cmd","fps","wall","cpu","gpu","vram_mb","rss_mb","file"];
    el("#perfBox").innerHTML = renderTable(headers, rows.slice(-10));
  } else {
    el("#perfBox").textContent = JSON.stringify(perf, null, 2);
  }

  // Live updates via SSE
  try {
    const es = new EventSource("/api/perf/stream");
    el("#perfLive").textContent = "Live: connected";
    es.addEventListener("perf", (ev) => {
      const x = JSON.parse(ev.data);
      // Append a tiny row to the existing table
      const cpu = (x.cpu_pct ?? "");
      const gpu = (x.gpu_util ?? "");
      const vram = (x.gpu_mem_mb ?? "");
      const r = { idx: "•", cmd: x.cmd||"", fps: x.fps ?? "", wall: x.wall ?? "", cpu: cpu, gpu: gpu, vram_mb: vram, rss_mb: x.rss_mb?.toFixed ? x.rss_mb.toFixed(1) : x.rss_mb, file: x.file||"" };
      const existing = el("#perfBox").querySelector("table tbody");
      if (existing) {
        const tr = document.createElement("tr");
        ["idx","cmd","fps","wall","cpu","gpu","vram_mb","rss_mb","file"].forEach(k=>{
          const td = document.createElement("td"); td.textContent = (r[k] ?? "").toString(); tr.appendChild(td);
        });
        existing.appendChild(tr);
      }
    });
    es.addEventListener("error", () => { el("#perfLive").textContent = "Live: disconnected"; });
  } catch (e) {
    el("#perfLive").textContent = "Live: unsupported";
  }

  // Prune button (requires --allow-write at server start)
  el("#pruneBtn").addEventListener("click", async () => {
    const n = parseInt(el("#keepN").value || "200", 10);
    el("#pruneMsg").textContent = "Pruning…";
    try {
      const res = await fetch("/api/perf/prune", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({keep: n})
      });
      const j = await res.json();
      if (j.ok) {
        el("#pruneMsg").textContent = `Deleted ${j.result.deleted}, kept ${j.result.kept}.`;
        // refresh table to reflect current state
        const perf = await loadJSON("/api/perf");
        if (perf && perf.items) {
          const rows = perf.items.map((x,i)=>({
            idx: i+1,
            cmd: x.cmd || "",
            fps: (x.fps ?? ""),
            wall: (x.run?.wall_sec ?? x.timings?.total_sec ?? "").toString(),
            cpu: x.cpu_pct ?? "",
            gpu: x.gpu_util ?? "",
            vram_mb: x.gpu_mem_mb ?? "",
            rss_mb: x.rss_mb ?? (x.run?.rss_bytes ? (x.run.rss_bytes/1e6).toFixed(1) : ""),
            file: x._path || ""
          }));
          const headers = ["idx","cmd","fps","wall","cpu","gpu","vram_mb","rss_mb","file"];
          el("#perfBox").innerHTML = renderTable(headers, rows.slice(-10));
        }
      } else {
        el("#pruneMsg").textContent = (j.error || "Failed");
      }
    } catch (err) {
      el("#pruneMsg").textContent = "Error";
    }
  });

  // Render CPU/GPU gauges for the latest row if present
  function gaugeHTML(val) {
    if (val === null || val === undefined || val === "") return "";
    const v = Math.max(0, Math.min(100, Number(val)));
    const cls = v < 60 ? "gauge" : (v < 85 ? "gauge warn" : "gauge danger");
    return `<div class="${cls}"><span style="width:${v}%;"></span></div>`;
  }
  // Replace numeric cpu/gpu cells with gauges on initial render
  setTimeout(() => {
    const rows = document.querySelectorAll("#perfBox table tbody tr");
    rows.forEach((tr) => {
      const cpuCell = tr.children[4]; const gpuCell = tr.children[5];
      if (cpuCell && cpuCell.textContent && !cpuCell.querySelector(".gauge")) cpuCell.innerHTML = gaugeHTML(cpuCell.textContent);
      if (gpuCell && gpuCell.textContent && !gpuCell.querySelector(".gauge")) gpuCell.innerHTML = gaugeHTML(gpuCell.textContent);
    });
  }, 50);

  // Time-series charts
  if (history && history.items && history.items.length) {
    const items = history.items;
    const fps = items.map(x => x.fps);
    const cpu = items.map(x => x.cpu_pct);
    const gpu = items.map(x => x.gpu_util);
    const vram = items.map(x => x.gpu_mem_mb);
    const rss = items.map(x => x.rss_mb);

    const charts = [
      renderTimeSeriesChart("FPS (frames/sec)", fps),
      renderTimeSeriesChart("CPU %", cpu),
      renderTimeSeriesChart("GPU Util %", gpu),
      renderTimeSeriesChart("VRAM (MB)", vram),
      renderTimeSeriesChart("RSS Memory (MB)", rss)
    ].join("");

    el("#timeseriesBox").innerHTML = charts;
  } else {
    el("#timeseriesBox").textContent = history?.error || "No history data available";
  }

  // Regression
  if (regression && regression.status) {
    const status = regression.status;
    const statusColors = {
      ok: "#22c55e",
      warn: "#eab308",
      fail: "#ef4444",
      learning: "#06b6d4",
      empty: "#9ca3af",
      error: "#f97316"
    };
    const color = statusColors[status] || "#9ca3af";
    const badge = `<span style="display:inline-block;padding:4px 8px;background:${color};color:white;border-radius:4px;font-weight:bold;margin-right:8px;">${status.toUpperCase()}</span>`;

    let content = badge;

    if (status === "ok" || status === "warn" || status === "fail") {
      const deltas = regression.deltas || {};
      const baseline = regression.baseline || {};
      const current = regression.current || {};

      const p90Cur = current.p90?.toFixed(2) || "N/A";
      const p90Base = baseline.p90_baseline?.toFixed(2) || "N/A";
      const p90Delta = deltas.p90_delta?.toFixed(2) || "0.00";
      const p90DeltaPct = deltas.p90_delta_pct ? (deltas.p90_delta_pct * 100).toFixed(1) : "0.0";

      const ppmCur = current.ppm?.toFixed(0) || "N/A";
      const ppmBase = baseline.ppm_baseline?.toFixed(0) || "N/A";
      const ppmDelta = deltas.ppm_delta?.toFixed(0) || "0";
      const ppmDeltaPct = deltas.ppm_delta_pct ? (deltas.ppm_delta_pct * 100).toFixed(1) : "0.0";

      const inlierCur = current.inlier_frac?.toFixed(2) || "N/A";
      const inlierBase = baseline.inlier_baseline?.toFixed(2) || "N/A";
      const inlierDelta = deltas.inlier_delta?.toFixed(2) || "0.00";
      const inlierDeltaPct = deltas.inlier_delta_pct ? (deltas.inlier_delta_pct * 100).toFixed(1) : "0.0";

      content += `
        <table style="margin-top:8px;">
          <thead><tr><th>Metric</th><th>Current</th><th>Baseline</th><th>Delta</th></tr></thead>
          <tbody>
            <tr><td>P90 (s)</td><td>${p90Cur}</td><td>${p90Base}</td><td>${p90Delta >= 0 ? '+' : ''}${p90Delta} (${p90DeltaPct >= 0 ? '+' : ''}${p90DeltaPct}%)</td></tr>
            <tr><td>PPM</td><td>${ppmCur}</td><td>${ppmBase}</td><td>${ppmDelta >= 0 ? '+' : ''}${ppmDelta} (${ppmDeltaPct >= 0 ? '+' : ''}${ppmDeltaPct}%)</td></tr>
            <tr><td>Inlier Frac</td><td>${inlierCur}</td><td>${inlierBase}</td><td>${inlierDelta >= 0 ? '+' : ''}${inlierDelta} (${inlierDeltaPct >= 0 ? '+' : ''}${inlierDeltaPct}%)</td></tr>
          </tbody>
        </table>
      `;

      const reasons = regression.reasons || [];
      if (reasons.length > 0) {
        content += `<div style="margin-top:8px;font-size:0.9em;">`;
        reasons.forEach(reason => {
          content += `<div>→ ${reason}</div>`;
        });
        content += `</div>`;
      }

      content += `<div style="margin-top:8px;font-size:0.9em;color:#6b7280;">Baseline window: ${regression.window || 0} runs (${regression.n_history || 0} total)</div>`;
    } else {
      const reasons = regression.reasons || ["No additional details"];
      content += `<div style="margin-top:8px;">${reasons[0]}</div>`;
    }

    el("#regressionBox").innerHTML = content;
  } else {
    el("#regressionBox").textContent = "No regression data available";
  }
}
init();
</script>
</body>
</html>
"""

def _read_batch_summary(root: Path) -> Dict[str, Any]:
    path = root / "batch_summary.csv"
    if not path.exists():
        return {"headers": [], "rows": []}
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    headers = reader.fieldnames or (rows[0].keys() if rows else [])
    return {"headers": list(headers), "rows": rows}

def _list_marker_files(root: Path) -> Dict[str, Any]:
    """List all new_markers*.csv files."""
    candidates = [p for p in root.glob("**/new_markers*.csv") if p.is_file()]
    files = [str(p.relative_to(root)) for p in sorted(candidates, key=lambda p: len(p.parts))]
    return {"files": files}

def _read_markers_any(root: Path, file: Optional[str] = None) -> Dict[str, Any]:
    """Read markers from specific file or auto-select first available."""
    if file:
        # Resolve and ensure the requested path stays within root
        try:
            req = Path(file)
            if req.is_absolute():
                return {"error": "Absolute paths not allowed"}
            path = (root / req).resolve()
            path.relative_to(root.resolve())
        except Exception:
            return {"error": "Invalid path"}
        if not path.exists() or not path.is_file():
            return {"error": f"File not found: {file}"}
    else:
        # Prefer new_markers.csv in root; otherwise list the first *new_markers*.csv found.
        candidates = [p for p in root.glob("**/new_markers*.csv") if p.is_file()]
        if not candidates:
            return {"headers": [], "rows": []}
        path = min(candidates, key=lambda p: len(p.parts))

    try:
        with open(path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        headers = reader.fieldnames or (rows[0].keys() if rows else [])
        return {"headers": list(headers), "rows": rows, "file": str(path.relative_to(root))}
    except Exception as e:
        return {"error": str(e)}

def _read_timewarp_any(root: Path) -> Dict[str, Any]:
    # Prefer timewarp.json in root; else first match underneath.
    candidates = [root / "timewarp.json"] + [p for p in root.glob("**/timewarp.json")]
    for path in candidates:
        if path.exists():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception as e:
                return {"error": str(e)}
    return {"ok": False, "error": "timewarp.json not found"}

def _read_perf_any(root: Path, max_items: int = 200) -> Dict[str, Any]:
    """Aggregate perf.json files under root (capped to last N by mtime for performance)."""
    items = []
    for p in root.glob("**/perf.json"):
        if p.is_file():
            try:
                obj = json.loads(p.read_text(encoding="utf-8"))
                obj["_path"] = str(p.relative_to(root))
                obj["_mtime"] = p.stat().st_mtime
                items.append(obj)
            except Exception:
                pass
    # Sort by mtime (newest first) and cap to prevent large responses
    items.sort(key=lambda x: x.get("_mtime", 0), reverse=True)
    items = items[:max_items]
    return {"count": len(items), "items": items}


def _read_regression(root: Path) -> Dict[str, Any]:
    """
    Load the most recent regression.json from root directory.

    Returns dict with regression status and metrics, or empty dict if no regression data found.
    """
    from mtbsync import regression as reg_module

    try:
        # Try loading regression.json directly from root
        regression_path = root / reg_module.REGRESSION_RESULT_FILE
        if regression_path.exists():
            with open(regression_path, "r", encoding="utf-8") as f:
                result = json.load(f)
            return result

        # Fallback: search for most recent regression.json in subdirectories
        regression_files = list(root.glob("**/regression.json"))
        if regression_files:
            # Sort by mtime (newest first)
            regression_files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            with open(regression_files[0], "r", encoding="utf-8") as f:
                result = json.load(f)
            return result

        # No regression data found - compute on-the-fly if history exists
        history = reg_module.load_quality_history(root)
        if not history:
            return {
                "status": "empty",
                "reasons": ["No quality history found"],
                "current": {},
                "baseline": {},
                "thresholds": {},
                "deltas": {},
                "n_history": 0,
                "window": 0
            }

        # Compute baseline and evaluate last run
        last_run = history[-1]
        baseline = reg_module.compute_baseline(history, window=50)
        thresholds = reg_module.default_thresholds()

        current_metrics = {
            "p90": last_run.get("p90"),
            "ppm": last_run.get("ppm"),
            "inlier_frac": last_run.get("inlier_frac"),
            "fps": last_run.get("fps"),
        }

        result = reg_module.evaluate_regression(current_metrics, baseline, thresholds)
        result["n_history"] = len(history)
        result["window"] = min(50, len(history))

        return result

    except Exception:
        # Best-effort: return empty on any error
        return {
            "status": "error",
            "reasons": ["Failed to load regression data"],
            "current": {},
            "baseline": {},
            "thresholds": {},
            "deltas": {},
            "n_history": 0,
            "window": 0
        }


def _perf_history(root: Path, limit: int = 500, fields: Optional[list[str]] = None) -> Dict[str, Any]:
    """
    Aggregate perf.json files as time-series data (oldest→newest).

    Args:
        root: Root directory to search
        limit: Max number of files to return (clamped to [1, 2000])
        fields: Optional list of field names to extract (e.g., ["fps", "cpu_pct"])

    Returns:
        Dict with "items" (list of dicts) and "count" (int).
        Each item has: _path, _ts (ISO8601), and requested fields (or None if missing).
    """
    limit = max(1, min(2000, limit))

    # Collect all perf.json files with mtime
    candidates = []
    for p in root.glob("**/perf.json"):
        if p.is_file():
            try:
                st = p.stat()
                candidates.append((p, st.st_mtime))
            except Exception:
                continue

    # Sort by mtime descending (newest first), then take last N and reverse to get oldest→newest
    candidates.sort(key=lambda x: x[1], reverse=True)
    candidates = candidates[:limit]
    candidates.reverse()  # Now oldest→newest

    items = []
    for p, mtime in candidates:
        try:
            obj = json.loads(p.read_text(encoding="utf-8"))

            # Build result item
            item: Dict[str, Any] = {
                "_path": str(p.relative_to(root)),
                "_ts": datetime.fromtimestamp(mtime, timezone.utc).isoformat(),
            }

            # Extract requested fields (or all common fields if not specified)
            if fields is None:
                fields = ["fps", "cpu_pct", "gpu_util", "gpu_mem_mb", "rss_mb"]

            for field in fields:
                # Direct lookup
                val = obj.get(field)

                # FPS fallback: compute from frames_processed / retrieval_sec
                if field == "fps" and val is None:
                    timings = obj.get("timings", {})
                    frames = timings.get("frames_processed")
                    retrieval = timings.get("retrieval_sec")
                    if frames is not None and retrieval is not None and retrieval > 0:
                        val = frames / retrieval

                # RSS MB fallback: convert from rss_bytes if needed
                if field == "rss_mb" and val is None:
                    run = obj.get("run", {})
                    if run and "rss_bytes" in run:
                        val = run["rss_bytes"] / 1e6

                item[field] = val

            items.append(item)
        except Exception:
            continue

    return {"items": items, "count": len(items)}

def _iter_perf_events(root: Path, interval: float = 0.5):
    """
    Poll perf.json files under root and yield SSE lines when a file is new/changed.
    Emits an 'init' event immediately with current count.
    """
    seen: Dict[str, float] = {}
    root = root.resolve()
    # Initial state
    yield f"event: init\ndata: {json.dumps({'time': datetime.now(timezone.utc).isoformat()})}\n\n"
    while True:
        changed = []
        for p in root.glob("**/perf.json"):
            try:
                st = p.stat()
                key = str(p.resolve())
                m = st.st_mtime
                if key not in seen or m > seen[key]:
                    # read a compact summary for the event payload
                    obj = json.loads(p.read_text(encoding="utf-8"))
                    payload = {
                        "file": str(p.relative_to(root)),
                        "cmd": obj.get("cmd"),
                        "fps": obj.get("fps"),
                        "wall": (obj.get("run", {}) or {}).get("wall_sec") or obj.get("timings", {}).get("total_sec"),
                        "rss_mb": obj.get("rss_mb") if obj.get("rss_mb") is not None else (((obj.get("run", {}) or {}).get("rss_bytes") or 0)/1e6),
                        "cpu_pct": obj.get("cpu_pct"),
                        "gpu_util": obj.get("gpu_util"),
                        "gpu_mem_mb": obj.get("gpu_mem_mb"),
                    }
                    changed.append(payload)
                    seen[key] = m
            except Exception:
                continue
        for item in changed:
            yield f"event: perf\ndata: {json.dumps(item)}\n\n"
        time.sleep(interval)

def _list_files(root: Path) -> Dict[str, Any]:
    items = []
    for p in root.glob("**/*"):
        if p.is_file():
            rel = p.relative_to(root)
            items.append({"name": str(rel), "href": f"/{rel.as_posix()}", "size": p.stat().st_size})
    items.sort(key=lambda x: x["name"])
    return {"items": items}

class _Handler(SimpleHTTPRequestHandler):
    allow_write = False  # Class variable set by factory

    def __init__(self, *args, directory: str | None = None, **kwargs):
        super().__init__(*args, directory=directory, **kwargs)

    def do_GET(self):
        root = Path(self.directory or ".").resolve()
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        if path == "/" or path == "/index.html":
            # Check for benchmark report and inject link if present
            report_url = _find_benchmark_report(root)
            if report_url:
                benchmark_link = f'''<div style="margin-top:8px;">
        <a href="{report_url}" target="_blank" style="text-decoration:none;border:1px solid #ccc;padding:6px 8px;border-radius:4px;display:inline-block;">
          Open Benchmark Report
        </a>
      </div>'''
            else:
                benchmark_link = ""
            html = INDEX_HTML.replace("<!-- BENCHMARK_LINK -->", benchmark_link)
            self._send_text(200, html, "text/html; charset=utf-8")
            return
        if path == "/api/timewarp":
            self._send_json(_read_timewarp_any(root))
            return
        if path == "/api/batch":
            self._send_json(_read_batch_summary(root))
            return
        if path == "/api/marker-list":
            self._send_json(_list_marker_files(root))
            return
        if path == "/api/markers":
            file_param = query.get("file", [None])[0]
            self._send_json(_read_markers_any(root, file=file_param))
            return
        if path == "/api/files":
            self._send_json(_list_files(root))
            return
        if path == "/api/perf":
            self._send_json(_read_perf_any(root))
            return
        if path == "/api/regression":
            self._send_json(_read_regression(root))
            return
        if path == "/api/perf/history":
            # Parse query params: limit (default 500) and fields (comma-separated)
            limit = int(query.get("limit", ["500"])[0])
            limit = max(1, min(2000, limit))  # Clamp to [1, 2000]
            fields_param = query.get("fields", [None])[0]
            fields = fields_param.split(",") if fields_param else None
            self._send_json(_perf_history(root, limit=limit, fields=fields))
            return
        if path == "/api/perf/stream":
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.end_headers()
            try:
                for chunk in _iter_perf_events(root):
                    self.wfile.write(chunk.encode("utf-8"))
                    self.wfile.flush()
            except BrokenPipeError:
                pass
            return

        # Fallback to static files served from root
        return super().do_GET()

    def do_POST(self):
        root = Path(self.directory or ".").resolve()
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/export-json":
            if not self.allow_write:
                self._send_json({"error": "Server export disabled (use --allow-write)"}, code=403)
                return

            try:
                content_length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(content_length).decode("utf-8")
                data = json.loads(body)
                in_csv = data.get("in_csv")
                out_json = data.get("out_json")

                if not in_csv or not out_json:
                    self._send_json({"error": "Missing in_csv or out_json"}, code=400)
                    return

                # Resolve and enforce both paths are inside root
                try:
                    in_req = Path(in_csv)
                    out_req = Path(out_json)
                    if in_req.is_absolute() or out_req.is_absolute():
                        self._send_json({"error": "Absolute paths not allowed"}, code=400)
                        return
                    csv_path = (root / in_req).resolve()
                    json_path = (root / out_req).resolve()
                    csv_path.relative_to(root)
                    json_path.relative_to(root)
                except Exception:
                    self._send_json({"error": "Invalid path"}, code=400)
                    return

                if not csv_path.exists():
                    self._send_json({"error": f"CSV file not found: {in_csv}"}, code=404)
                    return

                with open(csv_path, newline="", encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    rows = list(reader)

                json_path.parent.mkdir(parents=True, exist_ok=True)
                with open(json_path, "w", encoding="utf-8") as f:
                    json.dump({"markers": rows}, f, indent=2)

                self._send_json({"ok": True, "path": str(json_path.relative_to(root))})
            except Exception as e:
                self._send_json({"error": str(e)}, code=500)
            return

        if path == "/api/perf/prune":
            if not self.allow_write:
                self._send_json({"error": "Write disabled (use --allow-write)"}, code=403)
                return
            try:
                content_length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(content_length).decode("utf-8") if content_length else "{}"
                data = json.loads(body or "{}")
                keep = int(data.get("keep", 200))
                if keep < 0:
                    self._send_json({"error": "keep must be >= 0"}, code=400)
                    return
                result = _prune_perf_files(root, keep)
                self._send_json({"ok": True, "result": result})
            except Exception as e:
                self._send_json({"error": str(e)}, code=500)
            return

        self._send_json({"error": "Not found"}, code=404)

    def _send_json(self, obj: Dict[str, Any], code: int = 200):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_text(self, code: int, text: str, ctype: str = "text/plain; charset=utf-8"):
        data = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

def run_dashboard(root: str | Path = ".", host: str = "127.0.0.1", port: int = 8000, open_browser: bool = True, allow_write: bool = False) -> None:
    """
    Serve a simple dashboard rooted at `root`. Ctrl+C to stop.

    Args:
        root: Directory to serve
        host: Bind host
        port: Bind port
        open_browser: Open browser automatically
        allow_write: Allow server-side JSON export via POST /api/export-json
    """
    root = Path(root).resolve()
    if not root.exists():
        raise FileNotFoundError(f"Root not found: {root}")

    # Create handler class with allow_write flag
    class ConfiguredHandler(_Handler):
        pass
    ConfiguredHandler.allow_write = allow_write

    handler = lambda *args, **kwargs: ConfiguredHandler(*args, directory=str(root), **kwargs)  # noqa: E731
    # Use a threaded server so long-lived SSE connections don't block other endpoints.
    httpd = ThreadingHTTPServer((host, port), handler)
    # Ensure worker threads don't block interpreter shutdown on server_close().
    httpd.daemon_threads = True

    url = f"http://{host}:{port}/"
    write_msg = " (write enabled)" if allow_write else ""
    print(f"[Dashboard] Serving {root} at {url}{write_msg}")
    if open_browser:
        threading.Thread(target=lambda: (time.sleep(0.5), webbrowser.open(url)), daemon=True).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        print("[Dashboard] Stopped.")

"""This is an automatically generated stub for `management.capnp`."""

from __future__ import annotations

from collections.abc import Awaitable, Iterator, Sequence
from contextlib import contextmanager
from enum import Enum
from io import BufferedWriter
from typing import Any, BinaryIO, Literal, Protocol, overload

from capnp import _DynamicListBuilder

from .common_capnp import (
    Identifiable,
    IdInformation,
    IdInformationBuilder,
    IdInformationReader,
)
from .crop_capnp import Crop
from .date_capnp import Date, DateBuilder, DateReader
from .persistence_capnp import Persistent
from .registry_capnp import Registry

class EventType(Enum):
    sowing = "sowing"
    automaticSowing = "automaticSowing"
    harvest = "harvest"
    automaticHarvest = "automaticHarvest"
    irrigation = "irrigation"
    tillage = "tillage"
    organicFertilization = "organicFertilization"
    mineralFertilization = "mineralFertilization"
    nDemandFertilization = "nDemandFertilization"
    cutting = "cutting"
    setValue = "setValue"
    saveState = "saveState"

class PlantOrgan(Enum):
    root = "root"
    leaf = "leaf"
    shoot = "shoot"
    fruit = "fruit"
    strukt = "strukt"
    sugar = "sugar"

class Event:
    class ExternalType(Enum):
        sowing = "sowing"
        automaticSowing = "automaticSowing"
        harvest = "harvest"
        automaticHarvest = "automaticHarvest"
        irrigation = "irrigation"
        tillage = "tillage"
        organicFertilization = "organicFertilization"
        mineralFertilization = "mineralFertilization"
        nDemandFertilization = "nDemandFertilization"
        cutting = "cutting"

    class PhenoStage(Enum):
        emergence = "emergence"
        flowering = "flowering"
        anthesis = "anthesis"
        maturity = "maturity"

    class Type:
        @property
        def external(self) -> Event.ExternalType: ...
        @property
        def internal(self) -> Event.PhenoStage: ...
        def which(self) -> Literal["external", "internal"]: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Event.TypeReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.TypeReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            external: Event.ExternalType
            | Literal[
                "sowing",
                "automaticSowing",
                "harvest",
                "automaticHarvest",
                "irrigation",
                "tillage",
                "organicFertilization",
                "mineralFertilization",
                "nDemandFertilization",
                "cutting",
            ]
            | None = None,
            internal: Event.PhenoStage
            | Literal["emergence", "flowering", "anthesis", "maturity"]
            | None = None,
        ) -> Event.TypeBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.TypeReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.TypeReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class TypeReader(Event.Type):
        def as_builder(self) -> Event.TypeBuilder: ...

    class TypeBuilder(Event.Type):
        @property
        def external(self) -> Event.ExternalType: ...
        @external.setter
        def external(
            self,
            value: Event.ExternalType
            | Literal[
                "sowing",
                "automaticSowing",
                "harvest",
                "automaticHarvest",
                "irrigation",
                "tillage",
                "organicFertilization",
                "mineralFertilization",
                "nDemandFertilization",
                "cutting",
            ],
        ) -> None: ...
        @property
        def internal(self) -> Event.PhenoStage: ...
        @internal.setter
        def internal(
            self,
            value: Event.PhenoStage
            | Literal["emergence", "flowering", "anthesis", "maturity"],
        ) -> None: ...
        @staticmethod
        def from_dict(dictionary: dict[str, Any]) -> Event.TypeBuilder: ...
        def copy(self) -> Event.TypeBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Event.TypeReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class At:
        @property
        def date(self) -> Date: ...
        def init(self, name: Literal["date"]) -> Date: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Event.AtReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.AtReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            date: DateBuilder | dict[str, Any] | None = None,
        ) -> Event.AtBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.AtReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.AtReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class AtReader(Event.At):
        @property
        def date(self) -> DateReader: ...
        def as_builder(self) -> Event.AtBuilder: ...

    class AtBuilder(Event.At):
        @property
        def date(self) -> DateBuilder: ...
        @date.setter
        def date(
            self, value: Date | DateBuilder | DateReader | dict[str, Any]
        ) -> None: ...
        @staticmethod
        def from_dict(dictionary: dict[str, Any]) -> Event.AtBuilder: ...
        def init(self, name: Literal["date"]) -> DateBuilder: ...
        def copy(self) -> Event.AtBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Event.AtReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class Between:
        @property
        def earliest(self) -> Date: ...
        @property
        def latest(self) -> Date: ...
        @overload
        def init(self, name: Literal["earliest"]) -> Date: ...
        @overload
        def init(self, name: Literal["latest"]) -> Date: ...
        def init(self: Any, name: str, size: int = ...) -> Any: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Event.BetweenReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.BetweenReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            earliest: DateBuilder | dict[str, Any] | None = None,
            latest: DateBuilder | dict[str, Any] | None = None,
        ) -> Event.BetweenBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.BetweenReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.BetweenReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class BetweenReader(Event.Between):
        @property
        def earliest(self) -> DateReader: ...
        @property
        def latest(self) -> DateReader: ...
        def as_builder(self) -> Event.BetweenBuilder: ...

    class BetweenBuilder(Event.Between):
        @property
        def earliest(self) -> DateBuilder: ...
        @earliest.setter
        def earliest(
            self, value: Date | DateBuilder | DateReader | dict[str, Any]
        ) -> None: ...
        @property
        def latest(self) -> DateBuilder: ...
        @latest.setter
        def latest(
            self, value: Date | DateBuilder | DateReader | dict[str, Any]
        ) -> None: ...
        @staticmethod
        def from_dict(dictionary: dict[str, Any]) -> Event.BetweenBuilder: ...
        @overload
        def init(self: Any, name: Literal["earliest"]) -> DateBuilder: ...
        @overload
        def init(self: Any, name: Literal["latest"]) -> DateBuilder: ...
        def init(self: Any, name: str, size: int = ...) -> Any: ...
        def copy(self) -> Event.BetweenBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Event.BetweenReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class After:
        @property
        def event(self) -> Event.Type: ...
        @property
        def days(self) -> int: ...
        def init(self, name: Literal["event"]) -> Event.Type: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Event.AfterReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.AfterReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            event: Event.TypeBuilder | dict[str, Any] | None = None,
            days: int | None = None,
        ) -> Event.AfterBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.AfterReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Event.AfterReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class AfterReader(Event.After):
        @property
        def event(self) -> Event.TypeReader: ...
        def as_builder(self) -> Event.AfterBuilder: ...

    class AfterBuilder(Event.After):
        @property
        def event(self) -> Event.TypeBuilder: ...
        @event.setter
        def event(
            self,
            value: Event.Type | Event.TypeBuilder | Event.TypeReader | dict[str, Any],
        ) -> None: ...
        @property
        def days(self) -> int: ...
        @days.setter
        def days(self, value: int) -> None: ...
        @staticmethod
        def from_dict(dictionary: dict[str, Any]) -> Event.AfterBuilder: ...
        def init(self, name: Literal["event"]) -> Event.TypeBuilder: ...
        def copy(self) -> Event.AfterBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Event.AfterReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    @property
    def type(self) -> Event.ExternalType: ...
    @property
    def info(self) -> IdInformation: ...
    @property
    def at(self) -> Event.At: ...
    @property
    def between(self) -> Event.Between: ...
    @property
    def after(self) -> Event.After: ...
    @property
    def params(self) -> Any: ...
    @property
    def runAtStartOfDay(self) -> bool: ...
    def which(self) -> Literal["at", "between", "after"]: ...
    @overload
    def init(self, name: Literal["info"]) -> IdInformation: ...
    @overload
    def init(self, name: Literal["at"]) -> Event.At: ...
    @overload
    def init(self, name: Literal["between"]) -> Event.Between: ...
    @overload
    def init(self, name: Literal["after"]) -> Event.After: ...
    def init(self: Any, name: str, size: int = ...) -> Any: ...
    @staticmethod
    @contextmanager
    def from_bytes(
        data: bytes,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> Iterator[EventReader]: ...
    @staticmethod
    def from_bytes_packed(
        data: bytes,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> EventReader: ...
    @staticmethod
    def new_message(
        num_first_segment_words: int | None = None,
        allocate_seg_callable: Any = None,
        type: Event.ExternalType
        | Literal[
            "sowing",
            "automaticSowing",
            "harvest",
            "automaticHarvest",
            "irrigation",
            "tillage",
            "organicFertilization",
            "mineralFertilization",
            "nDemandFertilization",
            "cutting",
        ]
        | None = None,
        info: IdInformationBuilder | dict[str, Any] | None = None,
        at: Event.AtBuilder | dict[str, Any] | None = None,
        between: Event.BetweenBuilder | dict[str, Any] | None = None,
        after: Event.AfterBuilder | dict[str, Any] | None = None,
        params: Any | None = None,
        runAtStartOfDay: bool | None = None,
    ) -> EventBuilder: ...
    @staticmethod
    def read(
        file: BinaryIO,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> EventReader: ...
    @staticmethod
    def read_packed(
        file: BinaryIO,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> EventReader: ...
    def to_dict(self) -> dict[str, Any]: ...

class EventReader(Event):
    @property
    def info(self) -> IdInformationReader: ...
    @property
    def at(self) -> Event.AtReader: ...
    @property
    def between(self) -> Event.BetweenReader: ...
    @property
    def after(self) -> Event.AfterReader: ...
    def as_builder(self) -> EventBuilder: ...

class EventBuilder(Event):
    @property
    def type(self) -> Event.ExternalType: ...
    @type.setter
    def type(
        self,
        value: Event.ExternalType
        | Literal[
            "sowing",
            "automaticSowing",
            "harvest",
            "automaticHarvest",
            "irrigation",
            "tillage",
            "organicFertilization",
            "mineralFertilization",
            "nDemandFertilization",
            "cutting",
        ],
    ) -> None: ...
    @property
    def info(self) -> IdInformationBuilder: ...
    @info.setter
    def info(
        self,
        value: IdInformation
        | IdInformationBuilder
        | IdInformationReader
        | dict[str, Any],
    ) -> None: ...
    @property
    def at(self) -> Event.AtBuilder: ...
    @at.setter
    def at(
        self, value: Event.At | Event.AtBuilder | Event.AtReader | dict[str, Any]
    ) -> None: ...
    @property
    def between(self) -> Event.BetweenBuilder: ...
    @between.setter
    def between(
        self,
        value: Event.Between
        | Event.BetweenBuilder
        | Event.BetweenReader
        | dict[str, Any],
    ) -> None: ...
    @property
    def after(self) -> Event.AfterBuilder: ...
    @after.setter
    def after(
        self,
        value: Event.After | Event.AfterBuilder | Event.AfterReader | dict[str, Any],
    ) -> None: ...
    @property
    def params(self) -> Any: ...
    @params.setter
    def params(self, value: Any) -> None: ...
    @property
    def runAtStartOfDay(self) -> bool: ...
    @runAtStartOfDay.setter
    def runAtStartOfDay(self, value: bool) -> None: ...
    @staticmethod
    def from_dict(dictionary: dict[str, Any]) -> EventBuilder: ...
    @overload
    def init(self: Any, name: Literal["info"]) -> IdInformationBuilder: ...
    @overload
    def init(self: Any, name: Literal["at"]) -> Event.AtBuilder: ...
    @overload
    def init(self: Any, name: Literal["between"]) -> Event.BetweenBuilder: ...
    @overload
    def init(self: Any, name: Literal["after"]) -> Event.AfterBuilder: ...
    def init(self: Any, name: str, size: int = ...) -> Any: ...
    def copy(self) -> EventBuilder: ...
    def to_bytes(self) -> bytes: ...
    def to_bytes_packed(self) -> bytes: ...
    def to_segments(self) -> list[bytes]: ...
    def as_reader(self) -> EventReader: ...
    @staticmethod
    def write(file: BufferedWriter) -> None: ...
    @staticmethod
    def write_packed(file: BufferedWriter) -> None: ...

class Fertilizer(Identifiable, Persistent, Protocol):
    class NutrientsResult(Awaitable[NutrientsResult], Protocol):
        nutrients: Sequence[NutrientReader]

    class NutrientsResultsBuilder(Protocol):
        nutrients: Sequence[NutrientBuilder]

    class NutrientsCallContext(Protocol):
        results: Fertilizer.NutrientsResultsBuilder

    def nutrients(self) -> NutrientsResult: ...
    class NutrientsRequest(Protocol):
        def send(self) -> Fertilizer.NutrientsResult: ...

    def nutrients_request(self) -> NutrientsRequest: ...
    class ParametersResult(Awaitable[ParametersResult], Protocol):
        params: Any

    class ParametersResultsBuilder(Protocol):
        params: Any

    class ParametersCallContext(Protocol):
        results: Fertilizer.ParametersResultsBuilder

    def parameters(self) -> ParametersResult: ...
    class ParametersRequest(Protocol):
        def send(self) -> Fertilizer.ParametersResult: ...

    def parameters_request(self) -> ParametersRequest: ...
    @classmethod
    def _new_client(
        cls, server: Fertilizer.Server | Identifiable.Server | Persistent.Server
    ) -> Fertilizer: ...
    class Server(Identifiable.Server, Persistent.Server):
        def nutrients(
            self, _context: Fertilizer.NutrientsCallContext, **kwargs: Any
        ) -> Awaitable[Sequence[Nutrient]]: ...
        def parameters(
            self, _context: Fertilizer.ParametersCallContext, **kwargs: Any
        ) -> Awaitable[Any]: ...

class Nutrient:
    class Name(Enum):
        urea = "urea"
        ammonia = "ammonia"
        nitrate = "nitrate"
        phosphorus = "phosphorus"
        potassium = "potassium"
        sulfate = "sulfate"
        organicC = "organicC"
        organicN = "organicN"
        organicP = "organicP"
        organicNFast = "organicNFast"
        organicNSlow = "organicNSlow"

    class Unit(Enum):
        none = "none"
        fraction = "fraction"
        percent = "percent"

    @property
    def nutrient(self) -> Nutrient.Name: ...
    @property
    def value(self) -> float: ...
    @property
    def unit(self) -> Nutrient.Unit: ...
    @staticmethod
    @contextmanager
    def from_bytes(
        data: bytes,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> Iterator[NutrientReader]: ...
    @staticmethod
    def from_bytes_packed(
        data: bytes,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> NutrientReader: ...
    @staticmethod
    def new_message(
        num_first_segment_words: int | None = None,
        allocate_seg_callable: Any = None,
        nutrient: Nutrient.Name
        | Literal[
            "urea",
            "ammonia",
            "nitrate",
            "phosphorus",
            "potassium",
            "sulfate",
            "organicC",
            "organicN",
            "organicP",
            "organicNFast",
            "organicNSlow",
        ]
        | None = None,
        value: float | None = None,
        unit: Nutrient.Unit | Literal["none", "fraction", "percent"] | None = None,
    ) -> NutrientBuilder: ...
    @staticmethod
    def read(
        file: BinaryIO,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> NutrientReader: ...
    @staticmethod
    def read_packed(
        file: BinaryIO,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> NutrientReader: ...
    def to_dict(self) -> dict[str, Any]: ...

class NutrientReader(Nutrient):
    def as_builder(self) -> NutrientBuilder: ...

class NutrientBuilder(Nutrient):
    @property
    def nutrient(self) -> Nutrient.Name: ...
    @nutrient.setter
    def nutrient(
        self,
        value: Nutrient.Name
        | Literal[
            "urea",
            "ammonia",
            "nitrate",
            "phosphorus",
            "potassium",
            "sulfate",
            "organicC",
            "organicN",
            "organicP",
            "organicNFast",
            "organicNSlow",
        ],
    ) -> None: ...
    @property
    def value(self) -> float: ...
    @value.setter
    def value(self, value: float) -> None: ...
    @property
    def unit(self) -> Nutrient.Unit: ...
    @unit.setter
    def unit(
        self, value: Nutrient.Unit | Literal["none", "fraction", "percent"]
    ) -> None: ...
    @staticmethod
    def from_dict(dictionary: dict[str, Any]) -> NutrientBuilder: ...
    def copy(self) -> NutrientBuilder: ...
    def to_bytes(self) -> bytes: ...
    def to_bytes_packed(self) -> bytes: ...
    def to_segments(self) -> list[bytes]: ...
    def as_reader(self) -> NutrientReader: ...
    @staticmethod
    def write(file: BufferedWriter) -> None: ...
    @staticmethod
    def write_packed(file: BufferedWriter) -> None: ...

class Params:
    class Sowing:
        @property
        def cultivar(self) -> str: ...
        @property
        def plantDensity(self) -> int: ...
        @property
        def crop(self) -> Crop: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Params.SowingReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.SowingReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            cultivar: str | None = None,
            plantDensity: int | None = None,
            crop: Crop | Crop.Server | None = None,
        ) -> Params.SowingBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.SowingReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.SowingReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class SowingReader(Params.Sowing):
        def as_builder(self) -> Params.SowingBuilder: ...

    class SowingBuilder(Params.Sowing):
        @property
        def cultivar(self) -> str: ...
        @cultivar.setter
        def cultivar(self, value: str) -> None: ...
        @property
        def plantDensity(self) -> int: ...
        @plantDensity.setter
        def plantDensity(self, value: int) -> None: ...
        @property
        def crop(self) -> Crop: ...
        @crop.setter
        def crop(self, value: Crop | Crop.Server) -> None: ...
        @staticmethod
        def from_dict(dictionary: dict[str, Any]) -> Params.SowingBuilder: ...
        def copy(self) -> Params.SowingBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Params.SowingReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class AutomaticSowing:
        class AvgSoilTemp:
            @property
            def soilDepthForAveraging(self) -> float: ...
            @property
            def daysInSoilTempWindow(self) -> int: ...
            @property
            def sowingIfAboveAvgSoilTemp(self) -> float: ...
            @staticmethod
            @contextmanager
            def from_bytes(
                data: bytes,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Iterator[Params.AutomaticSowing.AvgSoilTempReader]: ...
            @staticmethod
            def from_bytes_packed(
                data: bytes,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Params.AutomaticSowing.AvgSoilTempReader: ...
            @staticmethod
            def new_message(
                num_first_segment_words: int | None = None,
                allocate_seg_callable: Any = None,
                soilDepthForAveraging: float | None = None,
                daysInSoilTempWindow: int | None = None,
                sowingIfAboveAvgSoilTemp: float | None = None,
            ) -> Params.AutomaticSowing.AvgSoilTempBuilder: ...
            @staticmethod
            def read(
                file: BinaryIO,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Params.AutomaticSowing.AvgSoilTempReader: ...
            @staticmethod
            def read_packed(
                file: BinaryIO,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Params.AutomaticSowing.AvgSoilTempReader: ...
            def to_dict(self) -> dict[str, Any]: ...

        class AvgSoilTempReader(Params.AutomaticSowing.AvgSoilTemp):
            def as_builder(self) -> Params.AutomaticSowing.AvgSoilTempBuilder: ...

        class AvgSoilTempBuilder(Params.AutomaticSowing.AvgSoilTemp):
            @property
            def soilDepthForAveraging(self) -> float: ...
            @soilDepthForAveraging.setter
            def soilDepthForAveraging(self, value: float) -> None: ...
            @property
            def daysInSoilTempWindow(self) -> int: ...
            @daysInSoilTempWindow.setter
            def daysInSoilTempWindow(self, value: int) -> None: ...
            @property
            def sowingIfAboveAvgSoilTemp(self) -> float: ...
            @sowingIfAboveAvgSoilTemp.setter
            def sowingIfAboveAvgSoilTemp(self, value: float) -> None: ...
            @staticmethod
            def from_dict(
                dictionary: dict[str, Any],
            ) -> Params.AutomaticSowing.AvgSoilTempBuilder: ...
            def copy(self) -> Params.AutomaticSowing.AvgSoilTempBuilder: ...
            def to_bytes(self) -> bytes: ...
            def to_bytes_packed(self) -> bytes: ...
            def to_segments(self) -> list[bytes]: ...
            def as_reader(self) -> Params.AutomaticSowing.AvgSoilTempReader: ...
            @staticmethod
            def write(file: BufferedWriter) -> None: ...
            @staticmethod
            def write_packed(file: BufferedWriter) -> None: ...

        @property
        def minTempThreshold(self) -> float: ...
        @property
        def daysInTempWindow(self) -> int: ...
        @property
        def minPercentASW(self) -> float: ...
        @property
        def maxPercentASW(self) -> float: ...
        @property
        def max3dayPrecipSum(self) -> float: ...
        @property
        def maxCurrentDayPrecipSum(self) -> float: ...
        @property
        def tempSumAboveBaseTemp(self) -> float: ...
        @property
        def baseTemp(self) -> float: ...
        @property
        def avgSoilTemp(self) -> Params.AutomaticSowing.AvgSoilTemp: ...
        @property
        def sowing(self) -> Params.Sowing: ...
        @overload
        def init(
            self, name: Literal["avgSoilTemp"]
        ) -> Params.AutomaticSowing.AvgSoilTemp: ...
        @overload
        def init(self, name: Literal["sowing"]) -> Params.Sowing: ...
        def init(self: Any, name: str, size: int = ...) -> Any: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Params.AutomaticSowingReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.AutomaticSowingReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            minTempThreshold: float | None = None,
            daysInTempWindow: int | None = None,
            minPercentASW: float | None = None,
            maxPercentASW: float | None = None,
            max3dayPrecipSum: float | None = None,
            maxCurrentDayPrecipSum: float | None = None,
            tempSumAboveBaseTemp: float | None = None,
            baseTemp: float | None = None,
            avgSoilTemp: Params.AutomaticSowing.AvgSoilTempBuilder
            | dict[str, Any]
            | None = None,
            sowing: Params.SowingBuilder | dict[str, Any] | None = None,
        ) -> Params.AutomaticSowingBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.AutomaticSowingReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.AutomaticSowingReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class AutomaticSowingReader(Params.AutomaticSowing):
        @property
        def avgSoilTemp(self) -> Params.AutomaticSowing.AvgSoilTempReader: ...
        @property
        def sowing(self) -> Params.SowingReader: ...
        def as_builder(self) -> Params.AutomaticSowingBuilder: ...

    class AutomaticSowingBuilder(Params.AutomaticSowing):
        @property
        def minTempThreshold(self) -> float: ...
        @minTempThreshold.setter
        def minTempThreshold(self, value: float) -> None: ...
        @property
        def daysInTempWindow(self) -> int: ...
        @daysInTempWindow.setter
        def daysInTempWindow(self, value: int) -> None: ...
        @property
        def minPercentASW(self) -> float: ...
        @minPercentASW.setter
        def minPercentASW(self, value: float) -> None: ...
        @property
        def maxPercentASW(self) -> float: ...
        @maxPercentASW.setter
        def maxPercentASW(self, value: float) -> None: ...
        @property
        def max3dayPrecipSum(self) -> float: ...
        @max3dayPrecipSum.setter
        def max3dayPrecipSum(self, value: float) -> None: ...
        @property
        def maxCurrentDayPrecipSum(self) -> float: ...
        @maxCurrentDayPrecipSum.setter
        def maxCurrentDayPrecipSum(self, value: float) -> None: ...
        @property
        def tempSumAboveBaseTemp(self) -> float: ...
        @tempSumAboveBaseTemp.setter
        def tempSumAboveBaseTemp(self, value: float) -> None: ...
        @property
        def baseTemp(self) -> float: ...
        @baseTemp.setter
        def baseTemp(self, value: float) -> None: ...
        @property
        def avgSoilTemp(self) -> Params.AutomaticSowing.AvgSoilTempBuilder: ...
        @avgSoilTemp.setter
        def avgSoilTemp(
            self,
            value: Params.AutomaticSowing.AvgSoilTemp
            | Params.AutomaticSowing.AvgSoilTempBuilder
            | Params.AutomaticSowing.AvgSoilTempReader
            | dict[str, Any],
        ) -> None: ...
        @property
        def sowing(self) -> Params.SowingBuilder: ...
        @sowing.setter
        def sowing(
            self,
            value: Params.Sowing
            | Params.SowingBuilder
            | Params.SowingReader
            | dict[str, Any],
        ) -> None: ...
        @staticmethod
        def from_dict(dictionary: dict[str, Any]) -> Params.AutomaticSowingBuilder: ...
        @overload
        def init(
            self: Any, name: Literal["avgSoilTemp"]
        ) -> Params.AutomaticSowing.AvgSoilTempBuilder: ...
        @overload
        def init(self: Any, name: Literal["sowing"]) -> Params.SowingBuilder: ...
        def init(self: Any, name: str, size: int = ...) -> Any: ...
        def copy(self) -> Params.AutomaticSowingBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Params.AutomaticSowingReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class Harvest:
        class CropUsage(Enum):
            greenManure = "greenManure"
            biomassProduction = "biomassProduction"

        class OptCarbonMgmtData:
            @property
            def optCarbonConservation(self) -> bool: ...
            @property
            def cropImpactOnHumusBalance(self) -> float: ...
            @property
            def cropUsage(self) -> Params.Harvest.CropUsage: ...
            @property
            def residueHeq(self) -> float: ...
            @property
            def organicFertilizerHeq(self) -> float: ...
            @property
            def maxResidueRecoverFraction(self) -> float: ...
            @staticmethod
            @contextmanager
            def from_bytes(
                data: bytes,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Iterator[Params.Harvest.OptCarbonMgmtDataReader]: ...
            @staticmethod
            def from_bytes_packed(
                data: bytes,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Params.Harvest.OptCarbonMgmtDataReader: ...
            @staticmethod
            def new_message(
                num_first_segment_words: int | None = None,
                allocate_seg_callable: Any = None,
                optCarbonConservation: bool | None = None,
                cropImpactOnHumusBalance: float | None = None,
                cropUsage: Params.Harvest.CropUsage
                | Literal["greenManure", "biomassProduction"]
                | None = None,
                residueHeq: float | None = None,
                organicFertilizerHeq: float | None = None,
                maxResidueRecoverFraction: float | None = None,
            ) -> Params.Harvest.OptCarbonMgmtDataBuilder: ...
            @staticmethod
            def read(
                file: BinaryIO,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Params.Harvest.OptCarbonMgmtDataReader: ...
            @staticmethod
            def read_packed(
                file: BinaryIO,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Params.Harvest.OptCarbonMgmtDataReader: ...
            def to_dict(self) -> dict[str, Any]: ...

        class OptCarbonMgmtDataReader(Params.Harvest.OptCarbonMgmtData):
            def as_builder(self) -> Params.Harvest.OptCarbonMgmtDataBuilder: ...

        class OptCarbonMgmtDataBuilder(Params.Harvest.OptCarbonMgmtData):
            @property
            def optCarbonConservation(self) -> bool: ...
            @optCarbonConservation.setter
            def optCarbonConservation(self, value: bool) -> None: ...
            @property
            def cropImpactOnHumusBalance(self) -> float: ...
            @cropImpactOnHumusBalance.setter
            def cropImpactOnHumusBalance(self, value: float) -> None: ...
            @property
            def cropUsage(self) -> Params.Harvest.CropUsage: ...
            @cropUsage.setter
            def cropUsage(
                self,
                value: Params.Harvest.CropUsage
                | Literal["greenManure", "biomassProduction"],
            ) -> None: ...
            @property
            def residueHeq(self) -> float: ...
            @residueHeq.setter
            def residueHeq(self, value: float) -> None: ...
            @property
            def organicFertilizerHeq(self) -> float: ...
            @organicFertilizerHeq.setter
            def organicFertilizerHeq(self, value: float) -> None: ...
            @property
            def maxResidueRecoverFraction(self) -> float: ...
            @maxResidueRecoverFraction.setter
            def maxResidueRecoverFraction(self, value: float) -> None: ...
            @staticmethod
            def from_dict(
                dictionary: dict[str, Any],
            ) -> Params.Harvest.OptCarbonMgmtDataBuilder: ...
            def copy(self) -> Params.Harvest.OptCarbonMgmtDataBuilder: ...
            def to_bytes(self) -> bytes: ...
            def to_bytes_packed(self) -> bytes: ...
            def to_segments(self) -> list[bytes]: ...
            def as_reader(self) -> Params.Harvest.OptCarbonMgmtDataReader: ...
            @staticmethod
            def write(file: BufferedWriter) -> None: ...
            @staticmethod
            def write_packed(file: BufferedWriter) -> None: ...

        @property
        def exported(self) -> bool: ...
        @property
        def optCarbMgmtData(self) -> Params.Harvest.OptCarbonMgmtData: ...
        def init(
            self, name: Literal["optCarbMgmtData"]
        ) -> Params.Harvest.OptCarbonMgmtData: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Params.HarvestReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.HarvestReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            exported: bool | None = None,
            optCarbMgmtData: Params.Harvest.OptCarbonMgmtDataBuilder
            | dict[str, Any]
            | None = None,
        ) -> Params.HarvestBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.HarvestReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.HarvestReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class HarvestReader(Params.Harvest):
        @property
        def optCarbMgmtData(self) -> Params.Harvest.OptCarbonMgmtDataReader: ...
        def as_builder(self) -> Params.HarvestBuilder: ...

    class HarvestBuilder(Params.Harvest):
        @property
        def exported(self) -> bool: ...
        @exported.setter
        def exported(self, value: bool) -> None: ...
        @property
        def optCarbMgmtData(self) -> Params.Harvest.OptCarbonMgmtDataBuilder: ...
        @optCarbMgmtData.setter
        def optCarbMgmtData(
            self,
            value: Params.Harvest.OptCarbonMgmtData
            | Params.Harvest.OptCarbonMgmtDataBuilder
            | Params.Harvest.OptCarbonMgmtDataReader
            | dict[str, Any],
        ) -> None: ...
        @staticmethod
        def from_dict(dictionary: dict[str, Any]) -> Params.HarvestBuilder: ...
        def init(
            self, name: Literal["optCarbMgmtData"]
        ) -> Params.Harvest.OptCarbonMgmtDataBuilder: ...
        def copy(self) -> Params.HarvestBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Params.HarvestReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class AutomaticHarvest:
        @property
        def minPercentASW(self) -> float: ...
        @property
        def maxPercentASW(self) -> float: ...
        @property
        def max3dayPrecipSum(self) -> float: ...
        @property
        def maxCurrentDayPrecipSum(self) -> float: ...
        @property
        def harvestTime(self) -> Event.PhenoStage: ...
        @property
        def harvest(self) -> Params.Harvest: ...
        def init(self, name: Literal["harvest"]) -> Params.Harvest: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Params.AutomaticHarvestReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.AutomaticHarvestReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            minPercentASW: float | None = None,
            maxPercentASW: float | None = None,
            max3dayPrecipSum: float | None = None,
            maxCurrentDayPrecipSum: float | None = None,
            harvestTime: Event.PhenoStage
            | Literal["emergence", "flowering", "anthesis", "maturity"]
            | None = None,
            harvest: Params.HarvestBuilder | dict[str, Any] | None = None,
        ) -> Params.AutomaticHarvestBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.AutomaticHarvestReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.AutomaticHarvestReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class AutomaticHarvestReader(Params.AutomaticHarvest):
        @property
        def harvest(self) -> Params.HarvestReader: ...
        def as_builder(self) -> Params.AutomaticHarvestBuilder: ...

    class AutomaticHarvestBuilder(Params.AutomaticHarvest):
        @property
        def minPercentASW(self) -> float: ...
        @minPercentASW.setter
        def minPercentASW(self, value: float) -> None: ...
        @property
        def maxPercentASW(self) -> float: ...
        @maxPercentASW.setter
        def maxPercentASW(self, value: float) -> None: ...
        @property
        def max3dayPrecipSum(self) -> float: ...
        @max3dayPrecipSum.setter
        def max3dayPrecipSum(self, value: float) -> None: ...
        @property
        def maxCurrentDayPrecipSum(self) -> float: ...
        @maxCurrentDayPrecipSum.setter
        def maxCurrentDayPrecipSum(self, value: float) -> None: ...
        @property
        def harvestTime(self) -> Event.PhenoStage: ...
        @harvestTime.setter
        def harvestTime(
            self,
            value: Event.PhenoStage
            | Literal["emergence", "flowering", "anthesis", "maturity"],
        ) -> None: ...
        @property
        def harvest(self) -> Params.HarvestBuilder: ...
        @harvest.setter
        def harvest(
            self,
            value: Params.Harvest
            | Params.HarvestBuilder
            | Params.HarvestReader
            | dict[str, Any],
        ) -> None: ...
        @staticmethod
        def from_dict(dictionary: dict[str, Any]) -> Params.AutomaticHarvestBuilder: ...
        def init(self, name: Literal["harvest"]) -> Params.HarvestBuilder: ...
        def copy(self) -> Params.AutomaticHarvestBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Params.AutomaticHarvestReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class Cutting:
        class CL(Enum):
            cut = "cut"
            left = "left"

        class Unit(Enum):
            percentage = "percentage"
            biomass = "biomass"
            lai = "lai"

        class Spec:
            @property
            def organ(self) -> PlantOrgan: ...
            @property
            def value(self) -> float: ...
            @property
            def unit(self) -> Params.Cutting.Unit: ...
            @property
            def cutOrLeft(self) -> Params.Cutting.CL: ...
            @property
            def exportPercentage(self) -> float: ...
            @staticmethod
            @contextmanager
            def from_bytes(
                data: bytes,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Iterator[Params.Cutting.SpecReader]: ...
            @staticmethod
            def from_bytes_packed(
                data: bytes,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Params.Cutting.SpecReader: ...
            @staticmethod
            def new_message(
                num_first_segment_words: int | None = None,
                allocate_seg_callable: Any = None,
                organ: PlantOrgan
                | Literal["root", "leaf", "shoot", "fruit", "strukt", "sugar"]
                | None = None,
                value: float | None = None,
                unit: Params.Cutting.Unit
                | Literal["percentage", "biomass", "lai"]
                | None = None,
                cutOrLeft: Params.Cutting.CL | Literal["cut", "left"] | None = None,
                exportPercentage: float | None = None,
            ) -> Params.Cutting.SpecBuilder: ...
            @staticmethod
            def read(
                file: BinaryIO,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Params.Cutting.SpecReader: ...
            @staticmethod
            def read_packed(
                file: BinaryIO,
                traversal_limit_in_words: int | None = ...,
                nesting_limit: int | None = ...,
            ) -> Params.Cutting.SpecReader: ...
            def to_dict(self) -> dict[str, Any]: ...

        class SpecReader(Params.Cutting.Spec):
            def as_builder(self) -> Params.Cutting.SpecBuilder: ...

        class SpecBuilder(Params.Cutting.Spec):
            @property
            def organ(self) -> PlantOrgan: ...
            @organ.setter
            def organ(
                self,
                value: PlantOrgan
                | Literal["root", "leaf", "shoot", "fruit", "strukt", "sugar"],
            ) -> None: ...
            @property
            def value(self) -> float: ...
            @value.setter
            def value(self, value: float) -> None: ...
            @property
            def unit(self) -> Params.Cutting.Unit: ...
            @unit.setter
            def unit(
                self,
                value: Params.Cutting.Unit | Literal["percentage", "biomass", "lai"],
            ) -> None: ...
            @property
            def cutOrLeft(self) -> Params.Cutting.CL: ...
            @cutOrLeft.setter
            def cutOrLeft(
                self, value: Params.Cutting.CL | Literal["cut", "left"]
            ) -> None: ...
            @property
            def exportPercentage(self) -> float: ...
            @exportPercentage.setter
            def exportPercentage(self, value: float) -> None: ...
            @staticmethod
            def from_dict(dictionary: dict[str, Any]) -> Params.Cutting.SpecBuilder: ...
            def copy(self) -> Params.Cutting.SpecBuilder: ...
            def to_bytes(self) -> bytes: ...
            def to_bytes_packed(self) -> bytes: ...
            def to_segments(self) -> list[bytes]: ...
            def as_reader(self) -> Params.Cutting.SpecReader: ...
            @staticmethod
            def write(file: BufferedWriter) -> None: ...
            @staticmethod
            def write_packed(file: BufferedWriter) -> None: ...

        @property
        def cuttingSpec(self) -> Sequence[Params.Cutting.Spec]: ...
        @property
        def cutMaxAssimilationRatePercentage(self) -> float: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Params.CuttingReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.CuttingReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            cuttingSpec: Sequence[Params.Cutting.SpecBuilder]
            | Sequence[dict[str, Any]]
            | None = None,
            cutMaxAssimilationRatePercentage: float | None = None,
        ) -> Params.CuttingBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.CuttingReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.CuttingReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class CuttingReader(Params.Cutting):
        @property
        def cuttingSpec(self) -> Sequence[Params.Cutting.SpecReader]: ...
        def as_builder(self) -> Params.CuttingBuilder: ...

    class CuttingBuilder(Params.Cutting):
        @property
        def cuttingSpec(self) -> Sequence[Params.Cutting.SpecBuilder]: ...
        @cuttingSpec.setter
        def cuttingSpec(
            self,
            value: Sequence[
                Params.Cutting.Spec
                | Params.Cutting.SpecBuilder
                | Params.Cutting.SpecReader
            ]
            | Sequence[dict[str, Any]],
        ) -> None: ...
        @property
        def cutMaxAssimilationRatePercentage(self) -> float: ...
        @cutMaxAssimilationRatePercentage.setter
        def cutMaxAssimilationRatePercentage(self, value: float) -> None: ...
        @staticmethod
        def from_dict(dictionary: dict[str, Any]) -> Params.CuttingBuilder: ...
        def init(
            self, name: Literal["cuttingSpec"], size: int = ...
        ) -> _DynamicListBuilder[Params.Cutting.SpecBuilder]: ...
        def copy(self) -> Params.CuttingBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Params.CuttingReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class MineralFertilization:
        @property
        def fertilizer(self) -> Fertilizer: ...
        @property
        def amount(self) -> float: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Params.MineralFertilizationReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.MineralFertilizationReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            fertilizer: Fertilizer | Fertilizer.Server | None = None,
            amount: float | None = None,
        ) -> Params.MineralFertilizationBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.MineralFertilizationReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.MineralFertilizationReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class MineralFertilizationReader(Params.MineralFertilization):
        def as_builder(self) -> Params.MineralFertilizationBuilder: ...

    class MineralFertilizationBuilder(Params.MineralFertilization):
        @property
        def fertilizer(self) -> Fertilizer: ...
        @fertilizer.setter
        def fertilizer(self, value: Fertilizer | Fertilizer.Server) -> None: ...
        @property
        def amount(self) -> float: ...
        @amount.setter
        def amount(self, value: float) -> None: ...
        @staticmethod
        def from_dict(
            dictionary: dict[str, Any],
        ) -> Params.MineralFertilizationBuilder: ...
        def copy(self) -> Params.MineralFertilizationBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Params.MineralFertilizationReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class NDemandFertilization:
        @property
        def nDemand(self) -> float: ...
        @property
        def fertilizer(self) -> Fertilizer: ...
        @property
        def depth(self) -> float: ...
        @property
        def stage(self) -> int: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Params.NDemandFertilizationReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.NDemandFertilizationReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            nDemand: float | None = None,
            fertilizer: Fertilizer | Fertilizer.Server | None = None,
            depth: float | None = None,
            stage: int | None = None,
        ) -> Params.NDemandFertilizationBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.NDemandFertilizationReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.NDemandFertilizationReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class NDemandFertilizationReader(Params.NDemandFertilization):
        def as_builder(self) -> Params.NDemandFertilizationBuilder: ...

    class NDemandFertilizationBuilder(Params.NDemandFertilization):
        @property
        def nDemand(self) -> float: ...
        @nDemand.setter
        def nDemand(self, value: float) -> None: ...
        @property
        def fertilizer(self) -> Fertilizer: ...
        @fertilizer.setter
        def fertilizer(self, value: Fertilizer | Fertilizer.Server) -> None: ...
        @property
        def depth(self) -> float: ...
        @depth.setter
        def depth(self, value: float) -> None: ...
        @property
        def stage(self) -> int: ...
        @stage.setter
        def stage(self, value: int) -> None: ...
        @staticmethod
        def from_dict(
            dictionary: dict[str, Any],
        ) -> Params.NDemandFertilizationBuilder: ...
        def copy(self) -> Params.NDemandFertilizationBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Params.NDemandFertilizationReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class OrganicFertilization:
        @property
        def fertilizer(self) -> Fertilizer: ...
        @property
        def amount(self) -> float: ...
        @property
        def incorporation(self) -> bool: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Params.OrganicFertilizationReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.OrganicFertilizationReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            fertilizer: Fertilizer | Fertilizer.Server | None = None,
            amount: float | None = None,
            incorporation: bool | None = None,
        ) -> Params.OrganicFertilizationBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.OrganicFertilizationReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.OrganicFertilizationReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class OrganicFertilizationReader(Params.OrganicFertilization):
        def as_builder(self) -> Params.OrganicFertilizationBuilder: ...

    class OrganicFertilizationBuilder(Params.OrganicFertilization):
        @property
        def fertilizer(self) -> Fertilizer: ...
        @fertilizer.setter
        def fertilizer(self, value: Fertilizer | Fertilizer.Server) -> None: ...
        @property
        def amount(self) -> float: ...
        @amount.setter
        def amount(self, value: float) -> None: ...
        @property
        def incorporation(self) -> bool: ...
        @incorporation.setter
        def incorporation(self, value: bool) -> None: ...
        @staticmethod
        def from_dict(
            dictionary: dict[str, Any],
        ) -> Params.OrganicFertilizationBuilder: ...
        def copy(self) -> Params.OrganicFertilizationBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Params.OrganicFertilizationReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class Tillage:
        @property
        def depth(self) -> float: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Params.TillageReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.TillageReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            depth: float | None = None,
        ) -> Params.TillageBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.TillageReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.TillageReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class TillageReader(Params.Tillage):
        def as_builder(self) -> Params.TillageBuilder: ...

    class TillageBuilder(Params.Tillage):
        @property
        def depth(self) -> float: ...
        @depth.setter
        def depth(self, value: float) -> None: ...
        @staticmethod
        def from_dict(dictionary: dict[str, Any]) -> Params.TillageBuilder: ...
        def copy(self) -> Params.TillageBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Params.TillageReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    class Irrigation:
        @property
        def amount(self) -> float: ...
        @property
        def nutrientConcentrations(self) -> Sequence[Nutrient]: ...
        @staticmethod
        @contextmanager
        def from_bytes(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Iterator[Params.IrrigationReader]: ...
        @staticmethod
        def from_bytes_packed(
            data: bytes,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.IrrigationReader: ...
        @staticmethod
        def new_message(
            num_first_segment_words: int | None = None,
            allocate_seg_callable: Any = None,
            amount: float | None = None,
            nutrientConcentrations: Sequence[NutrientBuilder]
            | Sequence[dict[str, Any]]
            | None = None,
        ) -> Params.IrrigationBuilder: ...
        @staticmethod
        def read(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.IrrigationReader: ...
        @staticmethod
        def read_packed(
            file: BinaryIO,
            traversal_limit_in_words: int | None = ...,
            nesting_limit: int | None = ...,
        ) -> Params.IrrigationReader: ...
        def to_dict(self) -> dict[str, Any]: ...

    class IrrigationReader(Params.Irrigation):
        @property
        def nutrientConcentrations(self) -> Sequence[NutrientReader]: ...
        def as_builder(self) -> Params.IrrigationBuilder: ...

    class IrrigationBuilder(Params.Irrigation):
        @property
        def amount(self) -> float: ...
        @amount.setter
        def amount(self, value: float) -> None: ...
        @property
        def nutrientConcentrations(self) -> Sequence[NutrientBuilder]: ...
        @nutrientConcentrations.setter
        def nutrientConcentrations(
            self,
            value: Sequence[Nutrient | NutrientBuilder | NutrientReader]
            | Sequence[dict[str, Any]],
        ) -> None: ...
        @staticmethod
        def from_dict(dictionary: dict[str, Any]) -> Params.IrrigationBuilder: ...
        def init(
            self, name: Literal["nutrientConcentrations"], size: int = ...
        ) -> _DynamicListBuilder[NutrientBuilder]: ...
        def copy(self) -> Params.IrrigationBuilder: ...
        def to_bytes(self) -> bytes: ...
        def to_bytes_packed(self) -> bytes: ...
        def to_segments(self) -> list[bytes]: ...
        def as_reader(self) -> Params.IrrigationReader: ...
        @staticmethod
        def write(file: BufferedWriter) -> None: ...
        @staticmethod
        def write_packed(file: BufferedWriter) -> None: ...

    @staticmethod
    @contextmanager
    def from_bytes(
        data: bytes,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> Iterator[ParamsReader]: ...
    @staticmethod
    def from_bytes_packed(
        data: bytes,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> ParamsReader: ...
    @staticmethod
    def new_message(
        num_first_segment_words: int | None = None, allocate_seg_callable: Any = None
    ) -> ParamsBuilder: ...
    @staticmethod
    def read(
        file: BinaryIO,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> ParamsReader: ...
    @staticmethod
    def read_packed(
        file: BinaryIO,
        traversal_limit_in_words: int | None = ...,
        nesting_limit: int | None = ...,
    ) -> ParamsReader: ...
    def to_dict(self) -> dict[str, Any]: ...

class ParamsReader(Params):
    def as_builder(self) -> ParamsBuilder: ...

class ParamsBuilder(Params):
    @staticmethod
    def from_dict(dictionary: dict[str, Any]) -> ParamsBuilder: ...
    def copy(self) -> ParamsBuilder: ...
    def to_bytes(self) -> bytes: ...
    def to_bytes_packed(self) -> bytes: ...
    def to_segments(self) -> list[bytes]: ...
    def as_reader(self) -> ParamsReader: ...
    @staticmethod
    def write(file: BufferedWriter) -> None: ...
    @staticmethod
    def write_packed(file: BufferedWriter) -> None: ...

class FertilizerService(Registry, Protocol):
    @classmethod
    def _new_client(
        cls, server: FertilizerService.Server | Identifiable.Server | Registry.Server
    ) -> FertilizerService: ...
    class Server(Registry.Server): ...

class Service(Identifiable, Protocol):
    class ManagementatResult(Awaitable[ManagementatResult], Protocol):
        mgmt: Sequence[EventReader]

    class ManagementatResultsBuilder(Protocol):
        mgmt: Sequence[EventBuilder]

    class ManagementatCallContext(Protocol):
        results: Service.ManagementatResultsBuilder

    def managementAt(self, lat: float, lon: float) -> ManagementatResult: ...
    class ManagementatRequest(Protocol):
        lat: float
        lon: float
        def send(self) -> Service.ManagementatResult: ...

    def managementAt_request(self) -> ManagementatRequest: ...
    @classmethod
    def _new_client(cls, server: Service.Server | Identifiable.Server) -> Service: ...
    class Server(Identifiable.Server):
        def managementAt(
            self,
            lat: float,
            lon: float,
            _context: Service.ManagementatCallContext,
            **kwargs: Any,
        ) -> Awaitable[Sequence[Event]]: ...

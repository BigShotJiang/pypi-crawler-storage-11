############
PyDocX-Fork
############

**Note:** This is a forked and maintained version of the original PyDocX project.

Original project: https://github.com/CenterForOpenScience/pydocx

This fork includes bug fixes and improvements for continued maintenance.

.. image:: https://travis-ci.org/CenterForOpenScience/pydocx.png?branch=master
   :align: left
   :target: https://travis-ci.org/CenterForOpenScience/pydocx

* `Installation <https://pydocx.readthedocs.org/en/latest/installation.html>`_
* `Documentation <https://pydocx.readthedocs.org>`_
* `Release Notes <https://pydocx.readthedocs.org/en/latest/release_notes.html>`_
* `Github Page <https://github.com/Medemus/pydocx>`_
* `Issue Tracking <https://github.com/Medemus/pydocx/issues>`_

PyDocX is a tool
that can export
MS Word documents (Office Open XML)
into different markup languages.
Currently,
only HTML is supported.
You can extend
any of the available exporters
to customize it to your needs.
This includes extending
the base exporter
to add support
for a markup language
or format
that is not supported.

To get started using PyDocX,
see the `Usage <https://pydocx.readthedocs.org/en/latest/usage.html>`_
guide
and also
`Extending PyDocX <https://pydocx.readthedocs.org/en/latest/extending.html>`_.

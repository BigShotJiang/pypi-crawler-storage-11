# TalentSavvy ImproveTeam

Data extraction scripts for development tools (CSV mode)

## Installation

Install the package using pip:

```bash
pip install talentsavvy-improveteam
```

That's it! The package is published on PyPI, so no special index URLs or authentication is required.

This will automatically install all required dependencies:
- paramiko
- pytz
- python-dateutil
- pandas
- requests
- urllib3
- python-dotenv

## Configuration

Update the `.env` file in your working directory with the environment variables for the data sources you want to extract from.

The package includes a sample `.env` file. Update it with your specific configuration values for each data source you plan to use.

Refer to each extraction script's documentation for the specific environment variables it requires.

## Usage

After installing the package, you can run the data extraction scripts from the command line.

### Running Data Extraction Scripts

Each extraction script can be run with the following syntax:

```bash
extract_<source> -s <start_date>
```

Where `<source>` is one of:
- `jira` - Jira work item events
- `gitlab` - GitLab code events
- `github` - GitHub pull request events
- `github_actions` - GitHub Actions workflow events
- `jenkins` - Jenkins build events
- `azuredevops_boards` - Azure DevOps work item events
- `azuredevops_pipelines` - Azure DevOps pipeline events
- `azuredevops_repos` - Azure DevOps repository events
- `bitbucket_repos` - Bitbucket repository events
- `bitbucket_pipelines` - Bitbucket pipeline events
- `octopus` - Octopus Deploy deployment events

And `<start_date>` is optional and should be in `YYYY-MM-DD` format.

### Examples

**Extract Jira work items:**
```bash
extract_jira -s 2025-04-01
```

**Extract GitLab code events:**
```bash
extract_gitlab -s 2025-04-01
```

**Extract Jenkins builds:**
```bash
extract_jenkins -s 2025-04-01
```

If no start date is provided, the scripts will use the last checkpoint date (if available) or a default date.

### Output

The extracted data will be saved as CSV files in the directory specified by the `EXPORT_PATH` environment variable (default: `./export` directory).

Each script maintains a checkpoint file to track the last extraction timestamp, allowing for incremental extractions on subsequent runs.

### SFTP Upload

After extraction, you can upload the CSV files to an SFTP server:

```bash
sftp_upload
```

This will upload all CSV files from the export directory to the configured SFTP server and delete them locally after successful upload.



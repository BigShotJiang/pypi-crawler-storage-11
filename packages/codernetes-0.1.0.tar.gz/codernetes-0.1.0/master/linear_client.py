"""
Linear API GraphQL 클라이언트

Linear API를 사용하여 팀, 이슈 정보를 가져옵니다.
"""

import logging
import time
from copy import deepcopy
from typing import Any, ClassVar

import aiohttp

LOGGER = logging.getLogger(__name__)


class LinearClient:
    """Linear GraphQL API 클라이언트"""

    _issues_cache: ClassVar[dict[tuple[Any, ...], tuple[float, list[dict[str, Any]]]]] = {}
    _issues_cache_ttl: ClassVar[float] = 30.0  # seconds
    _issues_prefetch_limit: ClassVar[int] = 250

    def __init__(self, api_key: str):
        """
        Args:
            api_key: Linear API 키
        """
        self.api_key = api_key
        self.api_url = "https://api.linear.app/graphql"
        self.headers = {
            "Authorization": api_key,
            "Content-Type": "application/json",
        }

    async def _execute_query(self, query: str, variables: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        GraphQL 쿼리 실행

        Args:
            query: GraphQL 쿼리 문자열
            variables: 쿼리 변수

        Returns:
            API 응답 데이터

        Raises:
            Exception: API 요청 실패 시
        """
        payload = {"query": query}
        if variables:
            payload["variables"] = variables

        async with aiohttp.ClientSession() as session:
            async with session.post(self.api_url, json=payload, headers=self.headers) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"Linear API 요청 실패: {response.status} - {error_text}")

                data = await response.json()
                if "errors" in data:
                    raise Exception(f"Linear GraphQL 오류: {data['errors']}")

                return data.get("data", {})

    async def get_teams(self) -> list[dict[str, Any]]:
        """
        팀 목록 가져오기

        Returns:
            팀 목록 [{"id": "team-id", "name": "Team Name", "key": "TEAM"}]
        """
        query = """
        query {
            teams {
                nodes {
                    id
                    name
                    key
                    description
                }
            }
        }
        """

        try:
            data = await self._execute_query(query)
            teams = data.get("teams", {}).get("nodes", [])
            LOGGER.info("Linear 팀 %d개 가져오기 완료", len(teams))
            return teams
        except Exception as exc:
            LOGGER.error("Linear 팀 목록 가져오기 실패: %s", exc)
            raise

    async def search_issues(
        self,
        query: str,
        limit: int = 50,
        *,
        team_ids: list[str] | None = None,
        include_completed: bool = False,
    ) -> list[dict[str, Any]]:
        """
        이슈 검색 (identifier 또는 제목으로) - 캐시된 목록 기반 필터링

        Args:
            query: 검색어 (예: "ENG-123" 또는 "bug fix")
            limit: 최대 이슈 개수
            team_ids: 팀 ID 필터
            include_completed: 완료/취소된 이슈 포함 여부

        Returns:
            검색된 이슈 목록
        """
        normalized = query.strip().lower()
        if not normalized:
            return []

        normalized_compact = normalized.replace("-", "")

        issues = await self.get_issues(
            team_ids=team_ids,
            limit=max(limit, self._issues_prefetch_limit),
            include_completed=include_completed,
        )

        def _matches(issue: dict[str, Any]) -> bool:
            identifier = issue.get("identifier", "")
            title = issue.get("title", "")

            identifier_lower = identifier.lower()
            identifier_compact = identifier_lower.replace("-", "")

            if normalized and identifier_lower.startswith(normalized):
                return True
            if normalized_compact and identifier_compact.startswith(normalized_compact):
                return True
            if normalized in identifier_lower:
                return True
            if normalized in title.lower():
                return True
            return False

        filtered = [issue for issue in issues if _matches(issue)]
        LOGGER.info("Linear 이슈 검색 완료: %d개 (쿼리: %s)", len(filtered[:limit]), query)
        return [deepcopy(issue) for issue in filtered[:limit]]

    async def get_issues(
        self,
        team_ids: list[str] | None = None,
        limit: int = 50,
        *,
        include_completed: bool = False,
        refresh_cache: bool = False,
    ) -> list[dict[str, Any]]:
        """
        이슈 목록 가져오기

        Args:
            team_ids: 팀 ID 목록 (None이면 모든 팀)
            limit: 최대 이슈 개수
            include_completed: 완료/취소된 이슈 포함 여부
            refresh_cache: 캐시 무시 여부

        Returns:
            이슈 목록
        """
        cache_key = self._build_issue_cache_key(team_ids, include_completed)
        cached = None
        if not refresh_cache:
            cached = self._issues_cache.get(cache_key)
            if cached:
                cached_ts, cached_issues = cached
                if time.monotonic() - cached_ts <= self._issues_cache_ttl:
                    LOGGER.info("Linear 이슈 캐시 사용 (key=%s)", cache_key)
                    return [deepcopy(issue) for issue in cached_issues[:limit]]

        fetch_amount = max(limit, self._issues_prefetch_limit)

        args = [f"first: {fetch_amount}"]
        if team_ids:
            sanitized_team_ids = [tid.replace('"', '\\"') for tid in team_ids]
            team_filters = [f'{{team: {{id: {{eq: "{tid}"}}}}}}' for tid in sanitized_team_ids]
            args.append(f'filter: {{or: [{", ".join(team_filters)}]}}')
        args_str = ", ".join(args)

        query = f"""
        query {{
            issues({args_str}) {{
                nodes {{
                    id
                    identifier
                    title
                    description
                    priority
                    state {{
                        id
                        name
                        color
                        type
                    }}
                    team {{
                        id
                        name
                        key
                    }}
                    project {{
                        id
                        name
                    }}
                    assignee {{
                        id
                        name
                        email
                    }}
                    createdAt
                    updatedAt
                    completedAt
                    canceledAt
                    archivedAt
                    url
                }}
            }}
        }}
        """

        try:
            data = await self._execute_query(query)
            issues = data.get("issues", {}).get("nodes", [])
            filtered = [
                issue
                for issue in issues
                if include_completed or not self._is_issue_completed(issue)
            ]
            self._issues_cache[cache_key] = (time.monotonic(), deepcopy(filtered))
            LOGGER.info(
                "Linear 이슈 %d개 가져오기 완료 (필터 적용 후 %d개)",
                len(issues),
                len(filtered),
            )
            return [deepcopy(issue) for issue in filtered[:limit]]
        except Exception as exc:
            LOGGER.error("Linear 이슈 목록 가져오기 실패: %s", exc)
            raise

    async def get_issue(self, issue_id: str) -> dict[str, Any] | None:
        """
        이슈 상세 정보 가져오기

        Args:
            issue_id: 이슈 ID

        Returns:
            이슈 상세 정보 또는 None
        """
        query = """
        query($id: String!) {
            issue(id: $id) {
                id
                identifier
                title
                description
                priority
                state {
                    id
                    name
                    color
                }
                team {
                    id
                    name
                    key
                }
                assignee {
                    id
                    name
                    email
                }
                labels {
                    nodes {
                        id
                        name
                        color
                    }
                }
                comments {
                    nodes {
                        id
                        body
                        user {
                            name
                        }
                        createdAt
                    }
                }
                createdAt
                updatedAt
                url
            }
        }
        """

        try:
            data = await self._execute_query(query, {"id": issue_id})
            issue = data.get("issue")
            if issue:
                LOGGER.info("Linear 이슈 %s 가져오기 완료", issue_id)
            else:
                LOGGER.warning("Linear 이슈 %s를 찾을 수 없음", issue_id)
            return issue
        except Exception as exc:
            LOGGER.error("Linear 이슈 가져오기 실패: %s", exc)
            raise

    @staticmethod
    def _is_issue_completed(issue: dict[str, Any]) -> bool:
        if issue.get("archivedAt"):
            return True
        if issue.get("canceledAt"):
            return True
        if issue.get("completedAt"):
            return True

        state = issue.get("state") or {}
        state_type = (state.get("type") or "").lower()
        if state_type in {"completed", "canceled"}:
            return True

        state_name = (state.get("name") or "").lower()
        return state_name in {"done", "완료", "completed", "취소됨", "cancelled"}

    @staticmethod
    def _build_issue_cache_key(
        team_ids: list[str] | None,
        include_completed: bool,
    ) -> tuple[Any, ...]:
        team_key: tuple[str, ...]
        if team_ids:
            team_key = tuple(sorted(team_ids))
        else:
            team_key = ()
        return (team_key, include_completed)

    async def create_comment(self, issue_id: str, body: str) -> dict[str, Any] | None:
        """
        이슈에 코멘트 추가

        Args:
            issue_id: 이슈 ID
            body: 코멘트 내용

        Returns:
            생성된 코멘트 정보
        """
        query = """
        mutation($issueId: String!, $body: String!) {
            commentCreate(input: {issueId: $issueId, body: $body}) {
                success
                comment {
                    id
                    body
                    createdAt
                }
            }
        }
        """

        try:
            data = await self._execute_query(query, {"issueId": issue_id, "body": body})
            result = data.get("commentCreate", {})
            if result.get("success"):
                LOGGER.info("Linear 이슈 %s에 코멘트 추가 완료", issue_id)
                return result.get("comment")
            else:
                LOGGER.error("Linear 코멘트 추가 실패")
                return None
        except Exception as exc:
            LOGGER.error("Linear 코멘트 추가 실패: %s", exc)
            raise

"""REST API 라우트."""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import asdict, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from aiohttp import web

from .models import Job, JobStatus, RepositorySpec, User
from .storage import Storage
from .preset_manager import PresetManager, PresetConfig, PresetType
from . import auth

LOGGER = logging.getLogger(__name__)


class ApiHandler:
    def __init__(self, storage: Storage, cancel_job_callback: Any = None) -> None:
        self._storage = storage
        self._artifacts_root = Path("var/artifacts")
        self._artifacts_root.mkdir(parents=True, exist_ok=True)
        self._cancel_job_callback = cancel_job_callback
        self._preset_manager = PresetManager()

    def routes(self) -> tuple[web.RouteDef, ...]:
        return (
            web.get("/api/jobs", self.list_jobs),
            web.get("/api/jobs/{job_id}", self.get_job),
            web.post("/api/jobs", self.create_job),
            web.post("/api/jobs/{job_id}/status", self.update_job_status),
            web.post("/api/jobs/{job_id}/cancel", self.cancel_job),
            web.get("/api/jobs/{job_id}/logs", self.list_job_logs),
            web.post("/api/jobs/{job_id}/artifacts", self.upload_job_artifact),
            web.get("/api/jobs/{job_id}/artifacts", self.list_job_artifacts),
            web.get("/api/jobs/{job_id}/artifacts/{artifact_name}", self.download_job_artifact),
            web.get("/api/nodes", self.list_nodes),
            web.post("/api/nodes/register", self.register_node),
            web.delete("/api/nodes/{node_id}", self.delete_node),
            # User management routes
            web.post("/api/users/register", self.register_user),
            web.post("/api/auth/verify", self.verify_user_auth),
            web.get("/api/users", self.list_users),
            web.get("/api/users/{user_id}", self.get_user),
            web.put("/api/users/{user_id}", self.update_user),
            web.post("/api/github/token", self.set_github_token),
            web.get("/api/github/repos", self.list_github_repos),
            web.get("/api/github/issues", self.list_github_issues),
            web.get("/api/github/repos/{owner}/{repo}/issues/{issue_number}", self.get_github_issue),
            web.get("/api/github/repos/{owner}/{repo}/branches", self.list_github_branches),
            # V2 Delegated GitHub routes (via node)
            web.get("/api/v2/github/repos", self.list_github_repos_v2),
            web.get("/api/v2/github/issues", self.list_github_issues_v2),
            web.get("/api/v2/github/repos/{owner}/{repo}/issues/{issue_number}", self.get_github_issue_v2),
            web.get("/api/v2/github/repos/{owner}/{repo}/branches", self.list_github_branches_v2),
            # Linear API routes
            web.post("/api/linear/token", self.set_linear_token),
            web.get("/api/linear/teams", self.list_linear_teams),
            web.get("/api/linear/issues/search", self.search_linear_issues),
            web.get("/api/linear/issues", self.list_linear_issues),
            web.get("/api/linear/issues/{issue_id}", self.get_linear_issue),
            # V2 Delegated Linear routes (via node)
            web.get("/api/v2/linear/teams", self.list_linear_teams_v2),
            web.get("/api/v2/linear/issues/search", self.search_linear_issues_v2),
            web.get("/api/v2/linear/issues", self.list_linear_issues_v2),
            web.get("/api/v2/linear/issues/{issue_id}", self.get_linear_issue_v2),
            # Preset management routes
            web.get("/api/presets", self.list_presets),
            web.get("/api/presets/{preset_id}", self.get_preset),
            web.post("/api/presets", self.create_preset),
            web.put("/api/presets/{preset_id}", self.update_preset),
            web.delete("/api/presets/{preset_id}", self.delete_preset),
            # API usage monitoring
            web.get("/api/usage/{provider}", self.get_api_usage),
            web.get("/api/usage/nodes", self.get_node_usage_summary),
            web.post("/api/nodes/{node_id}/usage", self.report_node_usage),
        )

    async def list_jobs(self, request: web.Request) -> web.Response:
        status_param = request.query.get("status")
        status = JobStatus(status_param) if status_param else None
        jobs = self._storage.list_jobs(limit=100, status=status)
        payload = [self._job_to_dict(job) for job in jobs]
        return web.json_response({"jobs": payload})

    async def get_job(self, request: web.Request) -> web.Response:
        job_id = request.match_info["job_id"]
        job = self._storage.get_job(job_id)
        if job is None:
            raise web.HTTPNotFound(text="job not found")
        return web.json_response({"job": self._job_to_dict(job)})

    async def create_job(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:  # noqa: BLE001
            raise web.HTTPBadRequest(text="invalid json") from None

        prompt = str(data.get("prompt", "")).strip()
        if not prompt:
            raise web.HTTPBadRequest(text="prompt is required")
        if len(prompt) < 10:
            raise web.HTTPBadRequest(text="prompt must be at least 10 characters")

        repositories = [
            RepositorySpec(url=str(repo.get("url")), branch=repo.get("branch"), subdirectory=repo.get("subdirectory"))
            for repo in data.get("repositories", [])
            if repo.get("url")
        ]
        requested_tags = [tag.strip() for tag in data.get("requested_tags", []) if tag.strip()]
        target_node = str(data.get("target_node_id")) if data.get("target_node_id") else None
        if target_node:
            node = self._storage.get_node(target_node)
            if node is None:
                raise web.HTTPBadRequest(text=f"target node '{target_node}' not found")
            if node.status not in {"online"}:
                raise web.HTTPBadRequest(text=f"target node '{target_node}' is not available (status={node.status})")

        max_retries_raw = data.get("max_retries", 0)
        try:
            max_retries = int(max_retries_raw or 0)
        except (TypeError, ValueError) as exc:
            raise web.HTTPBadRequest(text="max_retries must be an integer") from exc
        if max_retries < 0:
            raise web.HTTPBadRequest(text="max_retries must be >= 0")
        if max_retries > 5:
            raise web.HTTPBadRequest(text="max_retries must be <= 5")

        verification_commands: list[str] = []
        raw_verification = data.get("verification_commands")
        if raw_verification is not None:
            if not isinstance(raw_verification, list):
                raise web.HTTPBadRequest(text="verification_commands must be a list")
            for item in raw_verification:
                if not isinstance(item, str):
                    raise web.HTTPBadRequest(text="verification_commands must contain strings")
                stripped = item.strip()
                if stripped:
                    verification_commands.append(stripped)

        metadata_payload: dict[str, Any] = {
            "origin": data.get("origin", "api"),
        }
        extra_metadata = data.get("metadata")
        if isinstance(extra_metadata, dict):
            metadata_payload.update(extra_metadata)
        if verification_commands:
            metadata_payload["verification_commands"] = verification_commands

        # GitHub Integration Fields
        repo_owner = data.get("repo_owner")
        repo_name = data.get("repo_name")
        issue_number = data.get("issue_number")
        issue_title = data.get("issue_title")
        issue_body = data.get("issue_body")
        agent_type = data.get("agent_type", "claude-code")

        # User who created this job
        creator_user_id = data.get("creator_user_id")

        # Branch name (for Linear/GitHub integration)
        branch_name = data.get("branch_name")

        # Node password (for password-protected nodes)
        node_password = data.get("node_password")
        if node_password:
            metadata_payload["node_password"] = str(node_password).strip()
            LOGGER.info(f"Job creation: node_password provided (length={len(str(node_password).strip())}), target_node={target_node}")
        else:
            LOGGER.warning(f"Job creation: NO node_password provided, target_node={target_node}")

        # GitHub repo 정보를 URL에서 추출 (선택 사항)
        if repositories and (not repo_owner or not repo_name):
            first_repo = repositories[0]
            repo_url = first_repo.url
            owner, name = self._parse_github_repo(repo_url)
            if owner and name:
                repo_owner = repo_owner or owner
                repo_name = repo_name or name

        job = Job(
            job_id=str(uuid.uuid4()),
            prompt=prompt,
            created_at=datetime.now(timezone.utc),
            status=JobStatus.QUEUED if target_node else JobStatus.PENDING,
            target_node_id=target_node,
            requested_tags=requested_tags,
            repositories=repositories,
            metadata=metadata_payload,
            max_retries=max_retries,
            creator_user_id=creator_user_id,
            # GitHub Integration
            repo_owner=repo_owner,
            repo_name=repo_name,
            issue_number=issue_number,
            issue_title=issue_title,
            issue_body=issue_body,
            agent_type=agent_type,
            branch_name=branch_name,
        )
        self._storage.upsert_job(job)
        return web.json_response({"job": self._job_to_dict(job)}, status=201)

    async def update_job_status(self, request: web.Request) -> web.Response:
        job_id = request.match_info["job_id"]
        try:
            data = await request.json()
        except Exception:  # noqa: BLE001
            raise web.HTTPBadRequest(text="invalid json") from None

        status_value = data.get("status")
        if not status_value:
            raise web.HTTPBadRequest(text="status is required")

        try:
            status = JobStatus(status_value)
        except ValueError as exc:
            raise web.HTTPBadRequest(text="invalid status") from exc

        retry_count_value = None
        if data.get("retry_count") is not None:
            try:
                retry_count_value = int(data.get("retry_count"))
            except (TypeError, ValueError) as exc:
                raise web.HTTPBadRequest(text="retry_count must be an integer") from exc
            if retry_count_value < 0:
                raise web.HTTPBadRequest(text="retry_count must be >= 0")

        self._storage.update_job_status(
            job_id,
            status,
            log_path=data.get("log_path"),
            result_summary=data.get("result_summary"),
            error_message=data.get("error_message"),
            retry_count=retry_count_value,
        )
        job = self._storage.get_job(job_id)
        if job is None:
            raise web.HTTPNotFound(text="job not found")
        return web.json_response({"job": self._job_to_dict(job)})

    async def cancel_job(self, request: web.Request) -> web.Response:
        """Cancel a running job"""
        job_id = request.match_info["job_id"]
        job = self._storage.get_job(job_id)
        if job is None:
            raise web.HTTPNotFound(text="job not found")

        # Check if job is in cancellable state
        cancellable_statuses = {
            JobStatus.PENDING,
            JobStatus.QUEUED,
            JobStatus.RUNNING,
            JobStatus.ACCEPTED,
            JobStatus.CLONING,
            JobStatus.AGENT_WORKING,
            JobStatus.COMMITTING,
            JobStatus.PUSHING,
            JobStatus.PR_CREATING,
        }

        if job.status not in cancellable_statuses:
            raise web.HTTPBadRequest(
                text=f"job cannot be cancelled in status: {job.status.value}"
            )

        # Update job status to cancelled
        self._storage.update_job_status(
            job_id,
            JobStatus.CANCELLED,
            result_summary="Job cancelled by user",
        )

        # If job is running on a node, send cancellation message via WebSocket
        if job.target_node_id and self._cancel_job_callback:
            try:
                await self._cancel_job_callback(job_id, job.target_node_id)
            except Exception as e:  # noqa: BLE001
                # Log error but don't fail the cancellation
                pass

        job = self._storage.get_job(job_id)
        return web.json_response({"job": self._job_to_dict(job)})

    async def list_nodes(self, _: web.Request) -> web.Response:
        nodes = self._storage.list_nodes()
        payload = [
            {
                "node_id": node.node_id,
                "display_name": node.display_name,
                "tags": node.tags,
                "capabilities": node.capabilities,
                "status": node.status,
                "resources": node.resources,
                "last_seen": node.last_seen.isoformat(),
                "last_hello": node.last_hello.isoformat() if node.last_hello else None,
                "user_id": node.user_id,
                "machine_name": node.machine_name,
                "password_protected": node.password_protected,
            }
            for node in nodes
        ]
        return web.json_response({"nodes": payload})

    async def register_node(self, request: web.Request) -> web.Response:
        """Register a new node via HTTP API (for c8s CLI)."""
        try:
            data = await request.json()
        except Exception:  # noqa: BLE001
            raise web.HTTPBadRequest(text="invalid json") from None

        # Validate required fields
        name = data.get("name", "").strip()
        host = data.get("host", "").strip()
        port = data.get("port")

        if not name:
            raise web.HTTPBadRequest(text="name is required")
        if not host:
            raise web.HTTPBadRequest(text="host is required")
        if not port or not isinstance(port, int) or port < 1 or port > 65535:
            raise web.HTTPBadRequest(text="valid port is required")

        # Extract optional fields
        tags = data.get("tags", [])
        notes = data.get("notes", "")
        capabilities = data.get("capabilities", {})
        resources = data.get("resources", {})

        if not isinstance(tags, list):
            tags = []
        if not isinstance(capabilities, dict):
            capabilities = {}
        if not isinstance(resources, dict):
            resources = {}

        # Create node metadata
        node_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc)

        metadata = NodeMetadata(
            node_id=node_id,
            display_name=name,
            tags=tags,
            capabilities=capabilities,
            resources=resources,
            last_seen=now,
            status="registered",  # Will become "online" when node connects
            last_hello=None,
        )

        # Save to storage
        self._storage.upsert_node(metadata)

        return web.json_response({
            "status": "registered",
            "node": {
                "node_id": node_id,
                "display_name": name,
                "host": host,
                "port": port,
                "tags": tags,
                "capabilities": capabilities,
                "resources": resources,
                "status": "registered",
            },
            "connection_info": {
                "websocket_url": f"ws://{host}:{port}",
                "note": "Node will show as 'online' when daemon connects to master",
            },
        }, status=201)

    async def delete_node(self, request: web.Request) -> web.Response:
        """Delete a node by ID."""
        node_id = request.match_info["node_id"]

        node = self._storage.get_node(node_id)
        if not node:
            raise web.HTTPNotFound(text="node not found")

        # Delete from storage
        self._storage.delete_node(node_id)

        return web.json_response({
            "status": "deleted",
            "node_id": node_id,
        })

    # ------------------------------------------------------------------
    # User Management API
    # ------------------------------------------------------------------

    async def register_user(self, request: web.Request) -> web.Response:
        """Register a new user (admin only)."""
        try:
            data = await request.json()
        except Exception:  # noqa: BLE001
            raise web.HTTPBadRequest(text="invalid json") from None

        # Verify admin token
        admin_token = data.get("admin_token", "").strip()
        if not auth.verify_admin_token(admin_token):
            raise web.HTTPForbidden(text="Admin access required")

        # Validate required fields
        user_id = data.get("user_id", "").strip()
        password = data.get("password", "").strip()

        if not user_id:
            raise web.HTTPBadRequest(text="user_id is required")
        if not password:
            raise web.HTTPBadRequest(text="password is required")
        if len(password) < 8:
            raise web.HTTPBadRequest(text="password must be at least 8 characters")

        # Check if user already exists
        existing_user = self._storage.get_user(user_id)
        if existing_user:
            raise web.HTTPBadRequest(text=f"User '{user_id}' already exists")

        # Hash password and create user
        password_hash = auth.hash_password(password)
        user = User(
            user_id=user_id,
            password_hash=password_hash,
            display_name=data.get("display_name"),
            email=data.get("email"),
            created_at=datetime.now(timezone.utc),
            is_active=True,
        )

        self._storage.create_user(user)

        return web.json_response({
            "status": "created",
            "user_id": user_id,
            "display_name": user.display_name,
            "email": user.email,
        }, status=201)

    async def verify_user_auth(self, request: web.Request) -> web.Response:
        """Verify user credentials (for node authentication)."""
        try:
            data = await request.json()
        except Exception:  # noqa: BLE001
            raise web.HTTPBadRequest(text="invalid json") from None

        user_id = data.get("user_id", "").strip()
        password = data.get("password", "").strip()

        if not user_id or not password:
            raise web.HTTPBadRequest(text="user_id and password are required")

        # Get user
        user = self._storage.get_user(user_id)
        if not user or not user.is_active:
            raise web.HTTPUnauthorized(text="Invalid credentials")

        # Verify password
        if not auth.verify_password(password, user.password_hash):
            raise web.HTTPUnauthorized(text="Invalid credentials")

        return web.json_response({
            "status": "ok",
            "user_id": user_id,
            "display_name": user.display_name,
        })

    async def list_users(self, request: web.Request) -> web.Response:
        """List all users (admin only)."""
        # Verify admin token
        admin_token = request.query.get("admin_token", "").strip()
        if not auth.verify_admin_token(admin_token):
            raise web.HTTPForbidden(text="Admin access required")

        users = self._storage.list_users()
        payload = [
            {
                "user_id": user.user_id,
                "display_name": user.display_name,
                "email": user.email,
                "created_at": user.created_at.isoformat(),
                "is_active": user.is_active,
            }
            for user in users
        ]
        return web.json_response({"users": payload})

    async def get_user(self, request: web.Request) -> web.Response:
        """Get user details."""
        user_id = request.match_info["user_id"]

        # Users can view their own info, admins can view any user
        requesting_user_id = request.query.get("requesting_user_id", "").strip()
        admin_token = request.query.get("admin_token", "").strip()

        is_admin = auth.verify_admin_token(admin_token)
        if not is_admin and requesting_user_id != user_id:
            raise web.HTTPForbidden(text="Cannot view other user's information")

        user = self._storage.get_user(user_id)
        if not user:
            raise web.HTTPNotFound(text="User not found")

        return web.json_response({
            "user_id": user.user_id,
            "display_name": user.display_name,
            "email": user.email,
            "created_at": user.created_at.isoformat(),
            "is_active": user.is_active,
        })

    async def update_user(self, request: web.Request) -> web.Response:
        """Update user information."""
        user_id = request.match_info["user_id"]

        try:
            data = await request.json()
        except Exception:  # noqa: BLE001
            raise web.HTTPBadRequest(text="invalid json") from None

        # Check authorization
        requesting_user_id = data.get("requesting_user_id", "").strip()
        admin_token = data.get("admin_token", "").strip()

        is_admin = auth.verify_admin_token(admin_token)
        if not is_admin and requesting_user_id != user_id:
            raise web.HTTPForbidden(text="Cannot update other user's information")

        # Get existing user
        user = self._storage.get_user(user_id)
        if not user:
            raise web.HTTPNotFound(text="User not found")

        # Prepare updates
        updates = {}

        if "display_name" in data:
            updates["display_name"] = data["display_name"]

        if "email" in data:
            updates["email"] = data["email"]

        # Only admin can change is_active
        if "is_active" in data and is_admin:
            updates["is_active"] = 1 if data["is_active"] else 0

        # Password change requires current password or admin
        if "new_password" in data:
            new_password = data["new_password"].strip()
            if not new_password:
                raise web.HTTPBadRequest(text="new_password cannot be empty")
            if len(new_password) < 8:
                raise web.HTTPBadRequest(text="new_password must be at least 8 characters")

            if not is_admin:
                # Verify current password
                current_password = data.get("current_password", "").strip()
                if not current_password or not auth.verify_password(current_password, user.password_hash):
                    raise web.HTTPUnauthorized(text="Current password is incorrect")

            updates["password_hash"] = auth.hash_password(new_password)

        if not updates:
            raise web.HTTPBadRequest(text="No valid update fields provided")

        # Apply updates
        self._storage.update_user(user_id, **updates)

        # Get updated user
        updated_user = self._storage.get_user(user_id)

        return web.json_response({
            "status": "updated",
            "user_id": updated_user.user_id,
            "display_name": updated_user.display_name,
            "email": updated_user.email,
            "is_active": updated_user.is_active,
        })

    async def list_job_logs(self, request: web.Request) -> web.Response:
        job_id = request.match_info["job_id"]
        job = self._storage.get_job(job_id)
        if job is None:
            raise web.HTTPNotFound(text="job not found")

        limit = min(int(request.query.get("limit", 200)), 1000)
        after_seq = request.query.get("after")
        after_value = int(after_seq) if after_seq is not None else None
        logs = self._storage.list_job_logs(job_id, limit=limit, after_seq=after_value)
        serialised_logs: list[dict[str, Any]] = []
        for log_entry in logs:
            entry = dict(log_entry)
            timestamp_value = entry.get("timestamp")
            if isinstance(timestamp_value, datetime):
                entry["timestamp"] = timestamp_value.isoformat()
            serialised_logs.append(entry)
        return web.json_response({"logs": serialised_logs})

    async def upload_job_artifact(self, request: web.Request) -> web.Response:
        job_id = request.match_info["job_id"]
        job = self._storage.get_job(job_id)
        if job is None:
            raise web.HTTPNotFound(text="job not found")

        reader = await request.multipart()
        file_part = None
        metadata_part = None

        while True:
            part = await reader.next()
            if part is None:
                break
            if part.name == "file":
                file_part = part
            elif part.name == "metadata":
                metadata_part = part

        if file_part is None:
            raise web.HTTPBadRequest(text="file field required")

        filename = file_part.filename or f"artifact-{uuid.uuid4().hex}.bin"
        safe_name = filename.replace("/", "_").replace("\\", "_")
        job_dir = self._artifacts_root / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        file_path = job_dir / safe_name

        with file_path.open("wb") as destination:
            while True:
                chunk = await file_part.read_chunk()
                if not chunk:
                    break
                destination.write(chunk)

        metadata_payload: dict[str, Any] = {}
        if metadata_part is not None:
            metadata_text = await metadata_part.text()
            if metadata_text:
                try:
                    metadata_payload = json.loads(metadata_text)
                except json.JSONDecodeError:
                    metadata_payload = {}

        download_url = f"/api/jobs/{job_id}/artifacts/{safe_name}"
        artifact_entry = {
            "name": safe_name,
            "size": file_path.stat().st_size,
            "download_url": download_url,
            "uploaded_at": datetime.now(timezone.utc).isoformat(),
            "contents": metadata_payload.get("contents", []),
            "source": metadata_payload.get("source", "node"),
        }

        metadata = dict(job.metadata)
        existing_artifacts = list(metadata.get("artifacts", []))
        existing_artifacts.append(artifact_entry)
        metadata["artifacts"] = existing_artifacts
        updated_job = replace(job, metadata=metadata)
        self._storage.upsert_job(updated_job)

        return web.json_response({"artifact": artifact_entry})

    async def list_job_artifacts(self, request: web.Request) -> web.Response:
        job_id = request.match_info["job_id"]
        job = self._storage.get_job(job_id)
        if job is None:
            raise web.HTTPNotFound(text="job not found")
        artifacts = job.metadata.get("artifacts", []) if isinstance(job.metadata, dict) else []
        return web.json_response({"artifacts": artifacts})

    async def download_job_artifact(self, request: web.Request) -> web.StreamResponse:
        job_id = request.match_info["job_id"]
        artifact_name = request.match_info["artifact_name"]
        job_dir = self._artifacts_root / job_id
        file_path = job_dir / artifact_name
        if not file_path.exists():
            raise web.HTTPNotFound(text="artifact not found")
        return web.FileResponse(file_path)

    async def set_github_token(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:  # noqa: BLE001
            raise web.HTTPBadRequest(text="invalid json") from None

        user_id = str(data.get("user_id", "")).strip()
        token = str(data.get("access_token", "")).strip()
        if not user_id or not token:
            raise web.HTTPBadRequest(text="user_id and access_token are required")

        refresh_token = data.get("refresh_token")
        expires_at_raw = data.get("expires_at")
        expires_at = None
        if expires_at_raw:
            try:
                expires_at = datetime.fromisoformat(str(expires_at_raw))
            except ValueError:
                pass

        metadata = {
            "scope": data.get("scope"),
            "token_type": data.get("token_type"),
        }
        self._storage.set_user_token(
            user_id,
            "github",
            access_token=token,
            refresh_token=refresh_token,
            expires_at=expires_at,
            metadata_payload=metadata,
        )
        return web.json_response({"status": "ok"})

    async def list_github_repos(self, request: web.Request) -> web.Response:
        """List GitHub repositories (v1 - deprecated, use v2)."""
        LOGGER.warning(
            "V1 GitHub repos endpoint called - deprecated, please migrate to /api/v2/github/repos"
        )
        user_id = request.query.get("user_id")
        org = request.query.get("org")
        user = request.query.get("user")

        # Get GitHub token
        token = None
        if user_id:
            token_entry = self._storage.get_user_token(user_id, "github")
            if token_entry is None:
                raise web.HTTPUnauthorized(text="GitHub token not found for user")
            token = token_entry["access_token"]

        try:
            from .github_client import get_github_client

            client = get_github_client(token)
            repos = client.list_repos(org=org, user=user, limit=100)

            repos_data = [
                {
                    "name": repo.name,
                    "full_name": repo.full_name,
                    "owner": repo.owner,
                    "url": repo.url,
                    "default_branch": repo.default_branch,
                    "description": repo.description,
                    "private": repo.private,
                }
                for repo in repos
            ]
            return web.json_response({"repos": repos_data})

        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to fetch repositories: {e}") from None

    async def list_github_issues(self, request: web.Request) -> web.Response:
        """List GitHub issues for a repository (v1 - deprecated, use v2)."""
        LOGGER.warning(
            "V1 GitHub issues endpoint called - deprecated, please migrate to /api/v2/github/issues"
        )
        owner = request.query.get("owner")
        repo = request.query.get("repo")
        state = request.query.get("state", "open")
        labels_str = request.query.get("labels")
        user_id = request.query.get("user_id")

        if not owner or not repo:
            raise web.HTTPBadRequest(text="owner and repo query parameters required")

        # Get GitHub token
        token = None
        if user_id:
            token_entry = self._storage.get_user_token(user_id, "github")
            if token_entry:
                token = token_entry["access_token"]

        try:
            from .github_client import get_github_client

            client = get_github_client(token)
            labels = [label.strip() for label in labels_str.split(",")] if labels_str else None
            issues = client.list_issues(owner=owner, repo=repo, state=state, labels=labels, limit=100)

            issues_data = [
                {
                    "number": issue.number,
                    "title": issue.title,
                    "body": issue.body,
                    "state": issue.state,
                    "labels": issue.labels,
                    "url": issue.url,
                    "repository": issue.repository,
                    "created_at": issue.created_at,
                    "updated_at": issue.updated_at,
                }
                for issue in issues
            ]
            return web.json_response({"issues": issues_data})

        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to fetch issues: {e}") from None

    async def get_github_issue(self, request: web.Request) -> web.Response:
        """Get a specific GitHub issue."""
        owner = request.match_info["owner"]
        repo = request.match_info["repo"]
        issue_number_str = request.match_info["issue_number"]
        user_id = request.query.get("user_id")

        try:
            issue_number = int(issue_number_str)
        except ValueError as exc:
            raise web.HTTPBadRequest(text="issue_number must be an integer") from exc

        # Get GitHub token
        token = None
        if user_id:
            token_entry = self._storage.get_user_token(user_id, "github")
            if token_entry:
                token = token_entry["access_token"]

        try:
            from .github_client import get_github_client

            client = get_github_client(token)
            issue = client.get_issue(owner=owner, repo=repo, issue_number=issue_number)

            issue_data = {
                "number": issue.number,
                "title": issue.title,
                "body": issue.body,
                "state": issue.state,
                "labels": issue.labels,
                "url": issue.url,
                "repository": issue.repository,
                "created_at": issue.created_at,
                "updated_at": issue.updated_at,
            }
            return web.json_response({"issue": issue_data})

        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to fetch issue: {e}") from None

    async def list_github_branches(self, request: web.Request) -> web.Response:
        """List branches for a GitHub repository (v1 - deprecated, use v2)."""
        LOGGER.warning(
            "V1 GitHub branches endpoint called - deprecated, please migrate to /api/v2/github/repos/{owner}/{repo}/branches"
        )
        owner = request.match_info["owner"]
        repo = request.match_info["repo"]
        user_id = request.query.get("user_id")

        # Get GitHub token
        token = None
        if user_id:
            token_entry = self._storage.get_user_token(user_id, "github")
            if token_entry:
                token = token_entry["access_token"]

        try:
            from .github_client import get_github_client

            client = get_github_client(token)
            branches = client.list_branches(owner=owner, repo=repo, limit=100)

            branches_data = [
                {
                    "name": branch.name,
                    "commit": branch.commit,
                }
                for branch in branches
            ]
            return web.json_response({"branches": branches_data})

        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to fetch branches: {e}") from None

    async def report_node_usage(self, request: web.Request) -> web.Response:
        """
        Receive usage report from Node

        POST /api/nodes/{node_id}/usage

        Body:
        {
            "node_id": "node-123",
            "timestamp": "2025-01-15T10:30:00",
            "period_start": "2025-01-15T10:25:00",
            "period_end": "2025-01-15T10:30:00",
            "claude": {
                "total_requests": 10,
                "total_tokens": 5000,
                "total_prompt_tokens": 2000,
                "total_completion_tokens": 3000,
                "total_cost_usd": 0.15,
                "jobs_count": 2
            },
            "codex": {
                "total_requests": 5,
                "total_tokens": 2000,
                ...
            }
        }
        """
        node_id = request.match_info["node_id"]

        try:
            data = await request.json()
        except Exception as e:
            return web.json_response(
                {"error": f"Invalid JSON: {str(e)}"}, status=400
            )

        # Validate node exists
        node = await self._storage.get_node(node_id)
        if not node:
            return web.json_response(
                {"error": f"Node not found: {node_id}"}, status=404
            )

        # Store usage data
        # TODO: Implement storage.store_node_usage()
        # For now, just log it
        timestamp = data.get("timestamp")
        claude_tokens = data.get("claude", {}).get("total_tokens", 0)
        codex_tokens = data.get("codex", {}).get("total_tokens", 0)
        total_tokens = claude_tokens + codex_tokens

        logger.info(
            f"Received usage report from {node_id}: "
            f"{total_tokens} tokens (Claude: {claude_tokens}, Codex: {codex_tokens})"
        )

        # TODO: Store in database
        # await self._storage.store_node_usage(node_id, data)

        return web.json_response(
            {
                "status": "success",
                "message": "Usage report received",
                "node_id": node_id,
                "timestamp": timestamp,
            },
            status=201,
        )

    async def get_api_usage(self, request: web.Request) -> web.Response:
        """
        Get API usage statistics for a specific provider (claude or codex)

        Query params:
            provider: 'claude' or 'codex'

        Returns:
            JSON with usage stats:
            {
                "total_requests": int,
                "total_tokens": int,
                "limit_requests": int | null,
                "limit_tokens": int | null
            }
        """
        provider = request.match_info.get("provider", "").lower()

        if provider not in ["claude", "codex"]:
            return web.json_response(
                {"error": f"Invalid provider: {provider}. Must be 'claude' or 'codex'"},
                status=400,
            )

        # TODO: Implement actual usage tracking
        # This is a placeholder implementation that returns mock data
        # In a real implementation, you would:
        # 1. Track API calls and tokens in the database
        # 2. Store limits from environment variables or config
        # 3. Aggregate usage statistics over time

        # Placeholder data
        usage_data = {
            "total_requests": 0,
            "total_tokens": 0,
            "limit_requests": None,
            "limit_tokens": None,
        }

        # Example: Read from environment variables (if set)
        import os

        if provider == "claude":
            usage_data["limit_tokens"] = int(os.getenv("CLAUDE_TOKEN_LIMIT", 0)) or None
            usage_data["limit_requests"] = int(os.getenv("CLAUDE_REQUEST_LIMIT", 0)) or None
        elif provider == "codex":
            usage_data["limit_tokens"] = int(os.getenv("CODEX_TOKEN_LIMIT", 0)) or None
            usage_data["limit_requests"] = int(os.getenv("CODEX_REQUEST_LIMIT", 0)) or None

        # In real implementation, query from database:
        # usage_data["total_requests"] = await self._storage.get_api_request_count(provider)
        # usage_data["total_tokens"] = await self._storage.get_api_token_count(provider)

        return web.json_response(usage_data)

    async def get_node_usage_summary(self, request: web.Request) -> web.Response:
        """
        Get aggregated usage summary across all nodes or specific node

        GET /api/usage/nodes?node_id=<optional>&provider=<optional>&period=<optional>

        Query params:
            node_id: Optional, filter by specific node
            provider: Optional, 'claude' or 'codex' (default: both)
            period: Optional, 'hour', 'day', 'week', 'month' (default: day)

        Returns:
            JSON with aggregated usage statistics
        """
        node_id = request.query.get("node_id")
        provider = request.query.get("provider")
        period = request.query.get("period", "day")

        # TODO: Implement actual database aggregation
        # For now, return placeholder data

        # In real implementation:
        # usage_data = await self._storage.get_aggregated_usage(
        #     node_id=node_id,
        #     provider=provider,
        #     period=period
        # )

        # Placeholder response
        usage_data = {
            "period": period,
            "provider": provider or "all",
            "node_filter": node_id,
            "total_nodes": 0,
            "total_requests": 0,
            "total_tokens": 0,
            "total_cost_usd": 0.0,
            "by_node": {},
            "by_provider": {
                "claude": {
                    "requests": 0,
                    "tokens": 0,
                    "cost_usd": 0.0,
                },
                "codex": {
                    "requests": 0,
                    "tokens": 0,
                    "cost_usd": 0.0,
                },
            },
            "note": "Usage aggregation will be implemented when storage.store_node_usage() is added",
        }

        return web.json_response(usage_data)

    def _job_to_dict(self, job: Job) -> dict[str, Any]:
        return {
            "job_id": job.job_id,
            "prompt": job.prompt,
            "status": job.status.value,
            "target_node_id": job.target_node_id,
            "requested_tags": job.requested_tags,
            "repositories": [asdict(repo) for repo in job.repositories],
            "metadata": job.metadata,
            "log_path": job.log_path,
            "result_summary": job.result_summary,
            "error_message": job.error_message,
            "created_at": job.created_at.isoformat(),
            "finished_at": job.finished_at.isoformat() if job.finished_at else None,
            "retry_count": job.retry_count,
            "max_retries": job.max_retries,
            "creator_user_id": job.creator_user_id,
            # GitHub Integration Fields
            "repo_owner": job.repo_owner,
            "repo_name": job.repo_name,
            "issue_number": job.issue_number,
            "issue_title": job.issue_title,
            "issue_body": job.issue_body,
            "pr_number": job.pr_number,
            "pr_url": job.pr_url,
            "agent_type": job.agent_type,
            "branch_name": job.branch_name,
            "work_dir": job.work_dir,
        }

    @staticmethod
    def _parse_github_repo(url: str | None) -> tuple[str | None, str | None]:
        if not url:
            return None, None
        try:
            parsed = urlparse(url)
            hostname = parsed.hostname or ""
            if "github.com" not in hostname:
                return None, None
            segments = [segment for segment in parsed.path.strip("/").split("/") if segment]
            if len(segments) < 2:
                return None, None
            owner = segments[0]
            name = segments[1].removesuffix(".git")
            if not owner or not name:
                return None, None
            return owner, name
        except Exception:  # noqa: BLE001
            return None, None

    # Linear API handlers

    async def set_linear_token(self, request: web.Request) -> web.Response:
        """Set Linear API token for a user."""
        try:
            data = await request.json()
        except Exception:  # noqa: BLE001
            raise web.HTTPBadRequest(text="invalid json") from None

        user_id = str(data.get("user_id", "")).strip()
        token = str(data.get("api_key", "")).strip()
        if not user_id or not token:
            raise web.HTTPBadRequest(text="user_id and api_key are required")

        metadata = data.get("metadata", {})
        self._storage.set_user_token(
            user_id,
            "linear",
            access_token=token,
            refresh_token=None,
            expires_at=None,
            metadata_payload=metadata,
        )
        return web.json_response({"status": "ok"})

    async def list_linear_teams(self, request: web.Request) -> web.Response:
        """List Linear teams (v1 - deprecated, use v2)."""
        LOGGER.warning(
            "V1 Linear teams endpoint called - deprecated, please migrate to /api/v2/linear/teams"
        )
        import os

        user_id = request.query.get("user_id")

        # If no user_id provided, try to use default from environment
        if not user_id or not user_id.strip():
            user_id = os.getenv("LINEAR_USER_ID", "").strip()
            if not user_id:
                raise web.HTTPBadRequest(text="user_id is required or LINEAR_USER_ID environment variable must be set")

        # Get Linear API key from database
        token = None
        token_entry = self._storage.get_user_token(user_id, "linear")
        if token_entry is not None:
            token = token_entry.get("access_token")

        # If no token in database, try environment variable
        if not token:
            token = os.getenv("LINEAR_API_KEY", "").strip()
            if not token:
                raise web.HTTPUnauthorized(text="Linear API key not found. Please add your Linear API key in Settings or set LINEAR_API_KEY environment variable.")

        try:
            from .linear_client import LinearClient

            client = LinearClient(token)
            teams = await client.get_teams()

            return web.json_response({"teams": teams})

        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to fetch teams from Linear API: {e}") from None

    async def list_linear_issues(self, request: web.Request) -> web.Response:
        """List Linear issues (v1 - deprecated, use v2)."""
        LOGGER.warning(
            "V1 Linear issues endpoint called - deprecated, please migrate to /api/v2/linear/issues"
        )
        import os

        team_ids_str = request.query.get("teamIds")
        limit_str = request.query.get("limit", "200")
        state_filter = (request.query.get("state") or "open").strip().lower()
        user_id = request.query.get("user_id")

        # If no user_id provided, try to use default from environment
        if not user_id or not user_id.strip():
            user_id = os.getenv("LINEAR_USER_ID", "").strip()
            if not user_id:
                raise web.HTTPBadRequest(text="user_id is required or LINEAR_USER_ID environment variable must be set")

        # Parse team IDs
        team_ids = None
        if team_ids_str:
            team_ids = [tid.strip() for tid in team_ids_str.split(",") if tid.strip()]

        # Parse limit
        try:
            limit = int(limit_str)
        except ValueError:
            limit = 50

        # Get Linear API key from database
        token = None
        token_entry = self._storage.get_user_token(user_id, "linear")
        if token_entry is not None:
            token = token_entry.get("access_token")

        # If no token in database, try environment variable
        if not token:
            token = os.getenv("LINEAR_API_KEY", "").strip()
            if not token:
                raise web.HTTPUnauthorized(text="Linear API key not found. Please add your Linear API key in Settings or set LINEAR_API_KEY environment variable.")

        include_completed = state_filter in {"all", "completed", "any"}

        try:
            from .linear_client import LinearClient

            client = LinearClient(token)
            issues = await client.get_issues(
                team_ids=team_ids,
                limit=limit,
                include_completed=include_completed,
            )

            return web.json_response({"issues": issues})

        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to fetch issues from Linear API: {e}") from None

    async def search_linear_issues(self, request: web.Request) -> web.Response:
        """Search Linear issues by query (v1 - deprecated, use v2)."""
        LOGGER.warning(
            "V1 Linear search issues endpoint called - deprecated, please migrate to /api/v2/linear/issues/search"
        )
        import os

        query = request.query.get("q", "").strip()
        limit_str = request.query.get("limit", "50")
        team_ids_str = request.query.get("teamIds")
        user_id = request.query.get("user_id")

        if not query:
            raise web.HTTPBadRequest(text="query parameter 'q' is required")

        # If no user_id provided, try to use default from environment
        if not user_id or not user_id.strip():
            user_id = os.getenv("LINEAR_USER_ID", "").strip()
            if not user_id:
                raise web.HTTPBadRequest(text="user_id is required or LINEAR_USER_ID environment variable must be set")

        # Parse limit
        try:
            limit = int(limit_str)
        except ValueError:
            limit = 50

        # Get Linear API key from database
        token = None
        token_entry = self._storage.get_user_token(user_id, "linear")
        if token_entry is not None:
            token = token_entry.get("access_token")

        # If no token in database, try environment variable
        if not token:
            token = os.getenv("LINEAR_API_KEY", "").strip()
            if not token:
                raise web.HTTPUnauthorized(text="Linear API key not found. Please add your Linear API key in Settings or set LINEAR_API_KEY environment variable.")

        team_ids = None
        if team_ids_str:
            team_ids = [tid.strip() for tid in team_ids_str.split(",") if tid.strip()]

        try:
            from .linear_client import LinearClient

            client = LinearClient(token)
            issues = await client.search_issues(
                query=query,
                limit=limit,
                team_ids=team_ids,
            )

            return web.json_response({"issues": issues})

        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to search issues from Linear API: {e}") from None

    async def get_linear_issue(self, request: web.Request) -> web.Response:
        """Get a specific Linear issue (v1 - deprecated, use v2)."""
        LOGGER.warning(
            "V1 Linear get issue endpoint called - deprecated, please migrate to /api/v2/linear/issues/{issue_id}"
        )
        import os

        issue_id = request.match_info["issue_id"]
        user_id = request.query.get("user_id")

        # If no user_id provided, try to use default from environment
        if not user_id or not user_id.strip():
            user_id = os.getenv("LINEAR_USER_ID", "").strip()
            if not user_id:
                raise web.HTTPBadRequest(text="user_id is required or LINEAR_USER_ID environment variable must be set")

        # Get Linear API key from database
        token = None
        token_entry = self._storage.get_user_token(user_id, "linear")
        if token_entry is not None:
            token = token_entry.get("access_token")

        # If no token in database, try environment variable
        if not token:
            token = os.getenv("LINEAR_API_KEY", "").strip()
            if not token:
                raise web.HTTPUnauthorized(text="Linear API key not found. Please add your Linear API key in Settings or set LINEAR_API_KEY environment variable.")

        try:
            from .linear_client import LinearClient

            client = LinearClient(token)
            issue = await client.get_issue(issue_id)

            if issue is None:
                raise web.HTTPNotFound(text="Issue not found")

            return web.json_response({"issue": issue})

        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to fetch issue from Linear API: {e}") from None

    # Preset Management Methods
    async def list_presets(self, request: web.Request) -> web.Response:
        """List all presets with optional filtering."""
        preset_type = request.query.get("type")
        tags = request.query.getall("tag")

        try:
            # Parse preset type if provided
            if preset_type:
                preset_type = PresetType(preset_type)

            # Get presets
            presets = self._preset_manager.list_presets(
                preset_type=preset_type,
                tags=tags if tags else None,
            )

            # Convert to JSON-serializable format
            result = []
            for preset_id, preset in presets:
                preset_dict = asdict(preset)
                preset_dict["type"] = preset.type.value
                preset_dict["id"] = preset_id
                result.append(preset_dict)

            return web.json_response({"presets": result})

        except ValueError as e:
            raise web.HTTPBadRequest(text=str(e)) from None
        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to list presets: {e}") from None

    async def get_preset(self, request: web.Request) -> web.Response:
        """Get a specific preset by ID."""
        preset_id = request.match_info["preset_id"]

        try:
            preset = self._preset_manager.get_preset(preset_id)

            if not preset:
                raise web.HTTPNotFound(text=f"Preset '{preset_id}' not found")

            preset_dict = asdict(preset)
            preset_dict["type"] = preset.type.value
            preset_dict["id"] = preset_id

            return web.json_response(preset_dict)

        except web.HTTPException:
            raise
        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to get preset: {e}") from None

    async def create_preset(self, request: web.Request) -> web.Response:
        """Create a new preset."""
        try:
            data = await request.json()

            # Validate required fields
            if "id" not in data:
                raise web.HTTPBadRequest(text="Preset ID is required")
            if "name" not in data:
                raise web.HTTPBadRequest(text="Preset name is required")
            if "type" not in data:
                raise web.HTTPBadRequest(text="Preset type is required")

            preset_id = data.pop("id")

            # Convert type string to enum
            try:
                data["type"] = PresetType(data["type"])
            except ValueError:
                raise web.HTTPBadRequest(text=f"Invalid preset type: {data['type']}")

            # Set defaults for optional fields
            data.setdefault("description", "")
            data.setdefault("instructions", "")
            data.setdefault("testing_required", True)
            data.setdefault("auto_merge", False)
            data.setdefault("priority", 5)
            data.setdefault("tags", [])

            # Add user info if available
            user_id = request.query.get("user_id", "api")
            data["created_by"] = user_id

            # Create preset
            preset = PresetConfig(**data)
            created_preset = self._preset_manager.create_preset(preset_id, preset)

            # Return created preset
            preset_dict = asdict(created_preset)
            preset_dict["type"] = created_preset.type.value
            preset_dict["id"] = preset_id

            return web.json_response(preset_dict, status=201)

        except web.HTTPException:
            raise
        except ValueError as e:
            raise web.HTTPBadRequest(text=str(e)) from None
        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to create preset: {e}") from None

    async def update_preset(self, request: web.Request) -> web.Response:
        """Update an existing preset."""
        preset_id = request.match_info["preset_id"]

        try:
            data = await request.json()

            # Convert type string to enum if provided
            if "type" in data:
                try:
                    data["type"] = PresetType(data["type"])
                except ValueError:
                    raise web.HTTPBadRequest(text=f"Invalid preset type: {data['type']}")

            # Remove id from data if present
            data.pop("id", None)

            # Update preset
            updated_preset = self._preset_manager.update_preset(preset_id, data)

            # Return updated preset
            preset_dict = asdict(updated_preset)
            preset_dict["type"] = updated_preset.type.value
            preset_dict["id"] = preset_id

            return web.json_response(preset_dict)

        except web.HTTPException:
            raise
        except ValueError as e:
            raise web.HTTPBadRequest(text=str(e)) from None
        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to update preset: {e}") from None

    async def delete_preset(self, request: web.Request) -> web.Response:
        """Delete a preset."""
        preset_id = request.match_info["preset_id"]

        try:
            deleted = self._preset_manager.delete_preset(preset_id)

            if not deleted:
                raise web.HTTPNotFound(text=f"Preset '{preset_id}' not found")

            return web.json_response({"success": True, "message": f"Preset '{preset_id}' deleted"})

        except web.HTTPException:
            raise
        except Exception as e:  # noqa: BLE001
            raise web.HTTPInternalServerError(text=f"Failed to delete preset: {e}") from None

    # ==================================================================
    # V2 API Handlers - Node Delegation
    # ==================================================================

    async def _route_to_node(
        self,
        request: web.Request,
        capability: str,
        handler_method: str,
        **kwargs
    ) -> web.Response:
        """
        Route request to node with capability.

        Args:
            request: Original request
            capability: Required capability (github_api, linear_api)
            handler_method: Method name to call on node client
            **kwargs: Additional arguments for handler method

        Returns:
            Response from node
        """
        from .node_client import NodeHttpClient

        user_id = request.query.get("user_id")
        node_id = request.query.get("node_id")
        # Extract password from query or header
        node_password = request.query.get("password") or request.headers.get("X-Node-Password")

        # Find appropriate node
        if node_id:
            node = self._storage.get_node(node_id)
            if not node or node.status != "online":
                # Fallback to master direct
                return await getattr(self, handler_method.replace("_v2", ""))(request)
        else:
            # Find node with capability
            nodes = self._storage.get_nodes_with_capability(capability)
            node = nodes[0] if nodes else None

        if not node:
            # Fallback to master direct
            LOGGER.info(f"No node with {capability} capability, falling back to master")
            return await getattr(self, handler_method.replace("_v2", ""))(request)

        # Route to node
        try:
            client = NodeHttpClient(node)
            method = getattr(client, handler_method.replace("_v2", ""))
            # Add password to kwargs
            kwargs["password"] = node_password
            # Filter out None values to avoid aiohttp parameter errors
            filtered_kwargs = {k: v for k, v in kwargs.items() if v is not None}
            result = await method(**filtered_kwargs)
            return web.json_response(result)
        except Exception as e:
            LOGGER.error(f"Node delegation failed: {e}, falling back to master")
            return await getattr(self, handler_method.replace("_v2", ""))(request)

    async def list_github_repos_v2(self, request: web.Request) -> web.Response:
        """List GitHub repos via node delegation."""
        return await self._route_to_node(
            request,
            capability="github_api",
            handler_method="list_github_repos_v2",
            org=request.query.get("org"),
            user=request.query.get("user"),
        )

    async def list_github_issues_v2(self, request: web.Request) -> web.Response:
        """List GitHub issues via node delegation."""
        return await self._route_to_node(
            request,
            capability="github_api",
            handler_method="list_github_issues_v2",
            owner=request.query.get("owner"),
            repo=request.query.get("repo"),
            state=request.query.get("state", "open"),
            labels=request.query.get("labels"),
        )

    async def get_github_issue_v2(self, request: web.Request) -> web.Response:
        """Get GitHub issue via node delegation."""
        owner = request.match_info["owner"]
        repo = request.match_info["repo"]
        issue_number = int(request.match_info["issue_number"])

        return await self._route_to_node(
            request,
            capability="github_api",
            handler_method="get_github_issue_v2",
            owner=owner,
            repo=repo,
            issue_number=issue_number,
        )

    async def list_github_branches_v2(self, request: web.Request) -> web.Response:
        """List GitHub branches via node delegation."""
        owner = request.match_info["owner"]
        repo = request.match_info["repo"]

        return await self._route_to_node(
            request,
            capability="github_api",
            handler_method="list_github_branches_v2",
            owner=owner,
            repo=repo,
        )

    async def list_linear_teams_v2(self, request: web.Request) -> web.Response:
        """List Linear teams via node delegation."""
        return await self._route_to_node(
            request,
            capability="linear_api",
            handler_method="list_linear_teams_v2",
        )

    async def search_linear_issues_v2(self, request: web.Request) -> web.Response:
        """Search Linear issues via node delegation."""
        return await self._route_to_node(
            request,
            capability="linear_api",
            handler_method="search_linear_issues_v2",
            query=request.query.get("query", ""),
            team_id=request.query.get("team_id"),
        )

    async def list_linear_issues_v2(self, request: web.Request) -> web.Response:
        """List Linear issues via node delegation."""
        return await self._route_to_node(
            request,
            capability="linear_api",
            handler_method="list_linear_issues_v2",
            team_id=request.query.get("team_id"),
            state=request.query.get("state"),
        )

    async def get_linear_issue_v2(self, request: web.Request) -> web.Response:
        """Get Linear issue via node delegation."""
        issue_id = request.match_info["issue_id"]

        return await self._route_to_node(
            request,
            capability="linear_api",
            handler_method="get_linear_issue_v2",
            issue_id=issue_id,
        )

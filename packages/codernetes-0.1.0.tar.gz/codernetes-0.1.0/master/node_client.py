"""HTTP client to call node APIs."""

from __future__ import annotations

import logging
from typing import Any

import aiohttp

from .models import NodeMetadata

LOGGER = logging.getLogger(__name__)


class NodeHttpClient:
    """HTTP client to call node APIs."""

    def __init__(self, node: NodeMetadata):
        """
        Initialize node HTTP client.

        Args:
            node: Node metadata containing HTTP endpoint info
        """
        http_host = node.capabilities.get("http_host", "localhost")
        http_port = node.capabilities.get("http_port", 8082)
        self._base_url = f"http://{http_host}:{http_port}"
        self._timeout = aiohttp.ClientTimeout(total=30)

    async def list_github_repos(self, password: str | None = None, **params) -> dict[str, Any]:
        """
        List GitHub repositories.

        Args:
            password: Optional node password for authentication
            **params: Query parameters

        Returns:
            Response JSON
        """
        headers = {}
        if password:
            headers["Authorization"] = f"Bearer {password}"
        
        async with aiohttp.ClientSession(timeout=self._timeout) as session:
            async with session.get(
                f"{self._base_url}/api/github/repos",
                params=params,
                headers=headers
            ) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def list_github_issues(self, password: str | None = None, **params) -> dict[str, Any]:
        """
        List GitHub issues.

        Args:
            password: Optional node password for authentication
            **params: Query parameters

        Returns:
            Response JSON
        """
        headers = {}
        if password:
            headers["Authorization"] = f"Bearer {password}"
        
        async with aiohttp.ClientSession(timeout=self._timeout) as session:
            async with session.get(
                f"{self._base_url}/api/github/issues",
                params=params,
                headers=headers
            ) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def get_github_issue(self, owner: str, repo: str, issue_number: int, password: str | None = None) -> dict[str, Any]:
        """
        Get a specific GitHub issue.

        Args:
            owner: Repository owner
            repo: Repository name
            issue_number: Issue number
            password: Optional node password for authentication

        Returns:
            Response JSON
        """
        headers = {}
        if password:
            headers["Authorization"] = f"Bearer {password}"
        
        async with aiohttp.ClientSession(timeout=self._timeout) as session:
            async with session.get(
                f"{self._base_url}/api/github/repos/{owner}/{repo}/issues/{issue_number}",
                headers=headers
            ) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def list_github_branches(self, owner: str, repo: str, password: str | None = None) -> dict[str, Any]:
        """
        List GitHub branches.

        Args:
            owner: Repository owner
            repo: Repository name
            password: Optional node password for authentication

        Returns:
            Response JSON
        """
        headers = {}
        if password:
            headers["Authorization"] = f"Bearer {password}"
        
        async with aiohttp.ClientSession(timeout=self._timeout) as session:
            async with session.get(
                f"{self._base_url}/api/github/repos/{owner}/{repo}/branches",
                headers=headers
            ) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def list_linear_teams(self, password: str | None = None) -> dict[str, Any]:
        """
        List Linear teams.

        Args:
            password: Optional node password for authentication

        Returns:
            Response JSON
        """
        headers = {}
        if password:
            headers["Authorization"] = f"Bearer {password}"
        
        async with aiohttp.ClientSession(timeout=self._timeout) as session:
            async with session.get(
                f"{self._base_url}/api/linear/teams",
                headers=headers
            ) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def search_linear_issues(self, password: str | None = None, **params) -> dict[str, Any]:
        """
        Search Linear issues.

        Args:
            password: Optional node password for authentication
            **params: Query parameters

        Returns:
            Response JSON
        """
        headers = {}
        if password:
            headers["Authorization"] = f"Bearer {password}"
        
        async with aiohttp.ClientSession(timeout=self._timeout) as session:
            async with session.get(
                f"{self._base_url}/api/linear/issues/search",
                params=params,
                headers=headers
            ) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def list_linear_issues(self, password: str | None = None, **params) -> dict[str, Any]:
        """
        List Linear issues.

        Args:
            password: Optional node password for authentication
            **params: Query parameters

        Returns:
            Response JSON
        """
        headers = {}
        if password:
            headers["Authorization"] = f"Bearer {password}"
        
        async with aiohttp.ClientSession(timeout=self._timeout) as session:
            async with session.get(
                f"{self._base_url}/api/linear/issues",
                params=params,
                headers=headers
            ) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def get_linear_issue(self, issue_id: str, password: str | None = None) -> dict[str, Any]:
        """
        Get a specific Linear issue.

        Args:
            issue_id: Issue ID
            password: Optional node password for authentication

        Returns:
            Response JSON
        """
        headers = {}
        if password:
            headers["Authorization"] = f"Bearer {password}"
        
        async with aiohttp.ClientSession(timeout=self._timeout) as session:
            async with session.get(
                f"{self._base_url}/api/linear/issues/{issue_id}",
                headers=headers
            ) as resp:
                resp.raise_for_status()
                return await resp.json()

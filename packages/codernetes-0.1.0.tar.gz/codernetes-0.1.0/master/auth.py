"""Authentication utilities for Codernetes multi-tenant system."""

from __future__ import annotations

import hmac
import hashlib
import os
import time
from typing import Tuple

try:
    import bcrypt
    HAS_BCRYPT = True
except ImportError:
    HAS_BCRYPT = False
    import hashlib as _fallback_hashlib


def hash_password(password: str) -> str:
    """
    Hash a password for secure storage.

    Uses bcrypt if available, falls back to PBKDF2-SHA256.
    """
    if HAS_BCRYPT:
        salt = bcrypt.gensalt()
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')
    else:
        # Fallback to PBKDF2-SHA256 if bcrypt not available
        salt = os.urandom(32)
        key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
        return f"pbkdf2:sha256:100000${salt.hex()}${key.hex()}"


def verify_password(password: str, password_hash: str) -> bool:
    """
    Verify a password against its hash.

    Supports both bcrypt and PBKDF2-SHA256 hashes.
    """
    if password_hash.startswith("pbkdf2:"):
        # PBKDF2 hash format
        parts = password_hash.split("$")
        if len(parts) != 3:
            return False
        _, salt_hex, key_hex = parts
        salt = bytes.fromhex(salt_hex)
        expected_key = bytes.fromhex(key_hex)
        new_key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
        return hmac.compare_digest(new_key, expected_key)
    elif HAS_BCRYPT:
        # bcrypt hash
        try:
            return bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8'))
        except Exception:
            return False
    else:
        return False


def generate_auth_token(user_id: str, node_id: str) -> str:
    """
    Generate time-based authentication token for node connection.

    Token is valid for 5 minutes (300 seconds).

    Args:
        user_id: User identifier
        node_id: Node identifier

    Returns:
        HMAC-SHA256 token hex string
    """
    secret = os.getenv("NODE_AUTH_SECRET", "default-secret-change-in-production")
    timestamp = int(time.time() // 300)  # 5-minute window
    message = f"{user_id}:{node_id}:{timestamp}"
    return hmac.new(
        secret.encode(),
        message.encode(),
        hashlib.sha256
    ).hexdigest()


def verify_auth_token(user_id: str, node_id: str, token: str) -> bool:
    """
    Verify authentication token within time window.

    Args:
        user_id: User identifier
        node_id: Node identifier
        token: Token to verify

    Returns:
        True if token is valid, False otherwise
    """
    # Check current window
    current_token = generate_auth_token(user_id, node_id)
    if hmac.compare_digest(current_token, token):
        return True

    # Check previous window (for clock skew tolerance)
    secret = os.getenv("NODE_AUTH_SECRET", "default-secret-change-in-production")
    prev_timestamp = int(time.time() // 300) - 1
    prev_message = f"{user_id}:{node_id}:{prev_timestamp}"
    prev_token = hmac.new(
        secret.encode(),
        prev_message.encode(),
        hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(prev_token, token)


def generate_admin_token() -> str:
    """
    Generate a secure random admin token.

    This should be called once and stored in environment variables.

    Returns:
        Random hex string (64 characters)
    """
    return os.urandom(32).hex()


def verify_admin_token(token: str) -> bool:
    """
    Verify admin token against environment variable.

    Args:
        token: Token to verify

    Returns:
        True if token matches ADMIN_TOKEN env var
    """
    expected = os.getenv("ADMIN_TOKEN")
    if not expected:
        # No admin token configured - deny by default
        return False
    return hmac.compare_digest(token, expected)

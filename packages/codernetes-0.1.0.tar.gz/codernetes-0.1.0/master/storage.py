"""Database storage helpers for Codernetes."""

from __future__ import annotations

import json
import logging
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterator, Sequence, TypeVar

from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    Engine,
    Integer,
    MetaData,
    String,
    Table,
    Text,
    create_engine,
    func,
    insert,
    inspect,
    select,
    text,
    update,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.engine import URL, make_url
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from dataclasses import asdict

from .models import Job, JobStatus, NodeMetadata, RepositorySpec, User

try:  # SQLAlchemy 2.0 typing helper
    from sqlalchemy.engine.row import RowMapping as MappingRow
except ImportError:  # pragma: no cover
    from typing import Mapping as MappingRow  # type: ignore


def _json_type() -> JSON:
    """Return a JSON column type compatible with both Postgres and SQLite."""

    return JSON().with_variant(JSONB(astext_type=Text()), "postgresql")


metadata = MetaData()

LOGGER = logging.getLogger(__name__)


T = TypeVar("T")


def _coerce_json(value: Any, default: Callable[[], T]) -> T:
    if value in (None, ""):
        return default()
    if isinstance(value, str):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            LOGGER.debug("Failed to decode JSON column value: %s", value)
            return default()
    return value


jobs_table = Table(
    "jobs",
    metadata,
    Column("job_id", String(64), primary_key=True),
    Column("prompt", Text, nullable=False),
    Column("status", String(32), nullable=False, index=True),
    Column("target_node_id", String(128)),
    Column("requested_tags", _json_type(), nullable=False, default=list, server_default="[]"),
    Column("repositories", _json_type(), nullable=False, default=list, server_default="[]"),
    Column("metadata", _json_type(), nullable=False, default=dict, server_default="{}"),
    Column("log_path", Text),
    Column("result_summary", Text),
    Column("error_message", Text),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("finished_at", DateTime(timezone=True)),
    Column("retry_count", Integer, nullable=False, default=0, server_default="0"),
    Column("max_retries", Integer, nullable=False, default=0, server_default="0"),
    # GitHub Integration Columns
    Column("repo_owner", String(255)),
    Column("repo_name", String(255)),
    Column("issue_number", Integer),
    Column("issue_title", Text),
    Column("issue_body", Text),
    Column("pr_number", Integer),
    Column("pr_url", Text),
    Column("agent_type", String(64), nullable=False, default="claude-code", server_default="claude-code"),
    Column("branch_name", String(255)),
    Column("work_dir", Text),
    Column("creator_user_id", Text),
)


nodes_table = Table(
    "nodes",
    metadata,
    Column("node_id", String(128), primary_key=True),
    Column("display_name", String(255)),
    Column("tags", _json_type(), nullable=False, default=list, server_default="[]"),
    Column("capabilities", _json_type(), nullable=False, default=dict, server_default="{}"),
    Column("resources", _json_type(), nullable=False, default=dict, server_default="{}"),
    Column("status", String(32), nullable=False, default="offline", server_default="offline"),
    Column("last_seen", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("last_hello", DateTime(timezone=True)),
    Column("user_id", String(255)),
    Column("machine_name", String(255)),
    Column("password_protected", Integer, nullable=False, default=0, server_default="0"),
)


job_logs_table = Table(
    "job_logs",
    metadata,
    Column("job_id", String(64), primary_key=True),
    Column("seq", Integer, primary_key=True),
    Column("timestamp", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("level", String(16), nullable=False),
    Column("message", Text, nullable=False),
)


user_tokens_table = Table(
    "user_tokens",
    metadata,
    Column("user_id", String(128), primary_key=True),
    Column("provider", String(32), primary_key=True),
    Column("access_token", Text, nullable=False),
    Column("refresh_token", Text),
    Column("expires_at", DateTime(timezone=True)),
    Column("metadata", _json_type(), nullable=False, default=dict, server_default="{}"),
)


users_table = Table(
    "users",
    metadata,
    Column("user_id", String(255), primary_key=True),
    Column("password_hash", String(255), nullable=False),
    Column("display_name", String(255)),
    Column("email", String(255)),
    Column("github_token", Text),
    Column("linear_api_key", Text),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("is_active", Integer, nullable=False, default=1, server_default="1"),
)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Storage:
    """SQL database access layer."""

    def __init__(self, engine: Engine) -> None:
        self._engine = engine
        metadata.create_all(self._engine)
        self._ensure_schema()
        self._log_seq_cache: dict[str, int] = {}

    @contextmanager
    def _session(self) -> Iterator[Session]:
        with Session(self._engine, future=True) as session:
            yield session

    def close(self) -> None:
        self._engine.dispose()

    def _ensure_schema(self) -> None:
        """Apply lightweight migrations if new columns are missing."""

        inspector = inspect(self._engine)

        def _ensure_column(table: str, column: str, ddl_sql: str) -> None:
            existing = {col["name"] for col in inspector.get_columns(table)}
            if column in existing:
                return
            LOGGER.info("Applying schema patch on %s: adding column %s", table, column)
            with self._engine.begin() as conn:
                conn.execute(text(ddl_sql))

        if self._engine.dialect.name == "sqlite":
            # Nodes table - multi-tenant columns
            _ensure_column("nodes", "resources", "ALTER TABLE nodes ADD COLUMN resources TEXT DEFAULT '{}'" )
            _ensure_column("nodes", "last_hello", "ALTER TABLE nodes ADD COLUMN last_hello TEXT")
            _ensure_column("nodes", "user_id", "ALTER TABLE nodes ADD COLUMN user_id TEXT")
            _ensure_column("nodes", "machine_name", "ALTER TABLE nodes ADD COLUMN machine_name TEXT")
            _ensure_column("nodes", "password_protected", "ALTER TABLE nodes ADD COLUMN password_protected INTEGER DEFAULT 0")

            # Jobs table - multi-tenant and retry columns
            _ensure_column("jobs", "retry_count", "ALTER TABLE jobs ADD COLUMN retry_count INTEGER DEFAULT 0")
            _ensure_column("jobs", "max_retries", "ALTER TABLE jobs ADD COLUMN max_retries INTEGER DEFAULT 0")
            _ensure_column("jobs", "creator_user_id", "ALTER TABLE jobs ADD COLUMN creator_user_id TEXT")

            # GitHub Integration Columns
            _ensure_column("jobs", "repo_owner", "ALTER TABLE jobs ADD COLUMN repo_owner TEXT")
            _ensure_column("jobs", "repo_name", "ALTER TABLE jobs ADD COLUMN repo_name TEXT")
            _ensure_column("jobs", "issue_number", "ALTER TABLE jobs ADD COLUMN issue_number INTEGER")
            _ensure_column("jobs", "issue_title", "ALTER TABLE jobs ADD COLUMN issue_title TEXT")
            _ensure_column("jobs", "issue_body", "ALTER TABLE jobs ADD COLUMN issue_body TEXT")
            _ensure_column("jobs", "pr_number", "ALTER TABLE jobs ADD COLUMN pr_number INTEGER")
            _ensure_column("jobs", "pr_url", "ALTER TABLE jobs ADD COLUMN pr_url TEXT")
            _ensure_column("jobs", "agent_type", "ALTER TABLE jobs ADD COLUMN agent_type TEXT DEFAULT 'claude-code'")
            _ensure_column("jobs", "branch_name", "ALTER TABLE jobs ADD COLUMN branch_name TEXT")
            _ensure_column("jobs", "work_dir", "ALTER TABLE jobs ADD COLUMN work_dir TEXT")
        else:
            # Nodes table - multi-tenant columns
            _ensure_column(
                "nodes",
                "resources",
                "ALTER TABLE nodes ADD COLUMN resources JSONB DEFAULT '{}'::jsonb",
            )
            _ensure_column("nodes", "last_hello", "ALTER TABLE nodes ADD COLUMN last_hello TIMESTAMPTZ")
            _ensure_column("nodes", "user_id", "ALTER TABLE nodes ADD COLUMN user_id VARCHAR(255)")
            _ensure_column("nodes", "machine_name", "ALTER TABLE nodes ADD COLUMN machine_name VARCHAR(255)")
            _ensure_column("nodes", "password_protected", "ALTER TABLE nodes ADD COLUMN password_protected INTEGER DEFAULT 0")

            # Jobs table - multi-tenant and retry columns
            _ensure_column("jobs", "retry_count", "ALTER TABLE jobs ADD COLUMN retry_count INTEGER DEFAULT 0")
            _ensure_column("jobs", "max_retries", "ALTER TABLE jobs ADD COLUMN max_retries INTEGER DEFAULT 0")
            _ensure_column("jobs", "creator_user_id", "ALTER TABLE jobs ADD COLUMN creator_user_id VARCHAR(255)")

            # GitHub Integration Columns
            _ensure_column("jobs", "repo_owner", "ALTER TABLE jobs ADD COLUMN repo_owner VARCHAR(255)")
            _ensure_column("jobs", "repo_name", "ALTER TABLE jobs ADD COLUMN repo_name VARCHAR(255)")
            _ensure_column("jobs", "issue_number", "ALTER TABLE jobs ADD COLUMN issue_number INTEGER")
            _ensure_column("jobs", "issue_title", "ALTER TABLE jobs ADD COLUMN issue_title TEXT")
            _ensure_column("jobs", "issue_body", "ALTER TABLE jobs ADD COLUMN issue_body TEXT")
            _ensure_column("jobs", "pr_number", "ALTER TABLE jobs ADD COLUMN pr_number INTEGER")
            _ensure_column("jobs", "pr_url", "ALTER TABLE jobs ADD COLUMN pr_url TEXT")
            _ensure_column("jobs", "agent_type", "ALTER TABLE jobs ADD COLUMN agent_type VARCHAR(64) DEFAULT 'claude-code'")
            _ensure_column("jobs", "branch_name", "ALTER TABLE jobs ADD COLUMN branch_name VARCHAR(255)")
            _ensure_column("jobs", "work_dir", "ALTER TABLE jobs ADD COLUMN work_dir TEXT")

    # ------------------------------------------------------------------
    # Job CRUD
    # ------------------------------------------------------------------

    def upsert_job(self, job: Job) -> None:
        payload = {
            "job_id": job.job_id,
            "prompt": job.prompt,
            "status": job.status.value,
            "target_node_id": job.target_node_id,
            "requested_tags": job.requested_tags,
            "repositories": [asdict(repo) for repo in job.repositories],
            "metadata": job.metadata,
            "log_path": job.log_path,
            "result_summary": job.result_summary,
            "error_message": job.error_message,
            "created_at": job.created_at.astimezone(timezone.utc),
            "finished_at": job.finished_at.astimezone(timezone.utc) if job.finished_at else None,
            "retry_count": job.retry_count,
            "max_retries": job.max_retries,
            "creator_user_id": job.creator_user_id,
            # GitHub Integration Fields
            "repo_owner": job.repo_owner,
            "repo_name": job.repo_name,
            "issue_number": job.issue_number,
            "issue_title": job.issue_title,
            "issue_body": job.issue_body,
            "pr_number": job.pr_number,
            "pr_url": job.pr_url,
            "agent_type": job.agent_type,
            "branch_name": job.branch_name,
            "work_dir": job.work_dir,
        }

        with self._session() as session:
            exists = session.execute(
                select(jobs_table.c.job_id).where(jobs_table.c.job_id == job.job_id)
            ).scalar_one_or_none()
            if exists:
                session.execute(
                    update(jobs_table)
                    .where(jobs_table.c.job_id == job.job_id)
                    .values(**payload)
                )
            else:
                session.execute(insert(jobs_table).values(**payload))
            session.commit()

    def get_job(self, job_id: str) -> Job | None:
        with self._session() as session:
            row = session.execute(
                select(jobs_table).where(jobs_table.c.job_id == job_id)
            ).mappings().first()
            return self._row_to_job(row) if row else None

    def list_jobs(self, limit: int = 50, status: JobStatus | None = None) -> list[Job]:
        stmt = select(jobs_table).order_by(jobs_table.c.created_at.desc()).limit(limit)
        if status is not None:
            stmt = stmt.where(jobs_table.c.status == status.value)
        with self._session() as session:
            rows = session.execute(stmt).mappings().all()
        return [self._row_to_job(row) for row in rows]

    def list_jobs_by_status(self, statuses: Sequence[JobStatus], limit: int = 100) -> list[Job]:
        if not statuses:
            return []
        values = [status.value for status in statuses]
        stmt = (
            select(jobs_table)
            .where(jobs_table.c.status.in_(values))
            .order_by(jobs_table.c.created_at.asc())
            .limit(limit)
        )
        with self._session() as session:
            rows = session.execute(stmt).mappings().all()
        return [self._row_to_job(row) for row in rows]

    def update_job_status(
        self,
        job_id: str,
        status: JobStatus,
        *,
        log_path: str | None = None,
        result_summary: str | None = None,
        error_message: str | None = None,
        retry_count: int | None = None,
        pr_number: int | None = None,
        pr_url: str | None = None,
    ) -> None:
        updates: dict[str, Any] = {"status": status.value}
        if log_path is not None:
            updates["log_path"] = log_path
        if result_summary is not None:
            updates["result_summary"] = result_summary
        if error_message is not None:
            updates["error_message"] = error_message
        if retry_count is not None:
            updates["retry_count"] = retry_count
        if pr_number is not None:
            updates["pr_number"] = pr_number
        if pr_url is not None:
            updates["pr_url"] = pr_url
        if status in {JobStatus.SUCCEEDED, JobStatus.FAILED, JobStatus.CANCELLED}:
            updates["finished_at"] = _utcnow()

        with self._session() as session:
            session.execute(
                update(jobs_table).where(jobs_table.c.job_id == job_id).values(**updates)
            )
            session.commit()

    def mark_job_queued(self, job_id: str, node_id: str) -> None:
        with self._session() as session:
            session.execute(
                update(jobs_table)
                .where(
                    jobs_table.c.job_id == job_id,
                    jobs_table.c.status.in_([JobStatus.PENDING.value, JobStatus.QUEUED.value]),
                )
                .values(status=JobStatus.QUEUED.value, target_node_id=node_id)
            )
            session.commit()

    def assign_job(self, job_id: str, node_id: str) -> bool:
        with self._session() as session:
            result = session.execute(
                update(jobs_table)
                .where(
                    jobs_table.c.job_id == job_id,
                    jobs_table.c.status.in_([JobStatus.PENDING.value, JobStatus.QUEUED.value]),
                )
                .values(
                    status=JobStatus.RUNNING.value,
                    target_node_id=node_id,
                    result_summary="dispatched",
                )
            )
            session.commit()
            return result.rowcount > 0

    def dequeue_pending_job(self, candidate_node_id: str | None) -> Job | None:
        stmt = (
            select(jobs_table)
            .where(jobs_table.c.status == JobStatus.QUEUED.value)
            .order_by(jobs_table.c.created_at.asc())
            .limit(1)
        )
        with self._session() as session:
            row = session.execute(stmt).mappings().first()
            if not row:
                return None
            session.execute(
                update(jobs_table)
                .where(jobs_table.c.job_id == row["job_id"])
                .values(
                    status=JobStatus.RUNNING.value,
                    target_node_id=candidate_node_id or row.get("target_node_id"),
                )
            )
            session.commit()
        job = self._row_to_job(row)
        job.status = JobStatus.RUNNING
        job.target_node_id = candidate_node_id or job.target_node_id
        return job

    # ------------------------------------------------------------------
    # Job logs
    # ------------------------------------------------------------------

    def append_job_log(
        self,
        job_id: str,
        level: str,
        message: str,
        timestamp: datetime | None = None,
    ) -> None:
        seq = self._log_seq_cache.get(job_id)
        with self._session() as session:
            if seq is None:
                seq_row = session.execute(
                    select(func.max(job_logs_table.c.seq)).where(job_logs_table.c.job_id == job_id)
                ).scalar_one_or_none()
                seq = int(seq_row or 0)
            seq += 1
            session.execute(
                insert(job_logs_table).values(
                    job_id=job_id,
                    seq=seq,
                    timestamp=(timestamp or _utcnow()),
                    level=level,
                    message=message,
                )
            )
            session.commit()
        self._log_seq_cache[job_id] = seq

    def list_job_logs(
        self,
        job_id: str,
        *,
        limit: int = 200,
        after_seq: int | None = None,
    ) -> list[dict[str, Any]]:
        stmt = select(job_logs_table).where(job_logs_table.c.job_id == job_id)
        if after_seq is not None:
            stmt = stmt.where(job_logs_table.c.seq > after_seq)
        stmt = stmt.order_by(job_logs_table.c.seq.asc()).limit(limit)
        with self._session() as session:
            rows = session.execute(stmt).mappings().all()
        return [dict(row) for row in rows]

    # ------------------------------------------------------------------
    # User tokens
    # ------------------------------------------------------------------

    def set_user_token(
        self,
        user_id: str,
        provider: str,
        *,
        access_token: str,
        refresh_token: str | None = None,
        expires_at: datetime | None = None,
        metadata_payload: dict[str, Any] | None = None,
    ) -> None:
        payload = {
            "user_id": user_id,
            "provider": provider,
            "access_token": access_token,
            "refresh_token": refresh_token,
            "expires_at": expires_at.astimezone(timezone.utc) if expires_at else None,
            "metadata": metadata_payload or {},
        }
        with self._session() as session:
            exists = session.execute(
                select(user_tokens_table)
                .where(
                    user_tokens_table.c.user_id == user_id,
                    user_tokens_table.c.provider == provider,
                )
            ).first()
            if exists:
                session.execute(
                    update(user_tokens_table)
                    .where(
                        user_tokens_table.c.user_id == user_id,
                        user_tokens_table.c.provider == provider,
                    )
                    .values(**payload)
                )
            else:
                session.execute(insert(user_tokens_table).values(**payload))
            session.commit()

    def get_user_token(self, user_id: str, provider: str) -> dict[str, Any] | None:
        with self._session() as session:
            row = session.execute(
                select(user_tokens_table).where(
                    user_tokens_table.c.user_id == user_id,
                    user_tokens_table.c.provider == provider,
                )
            ).mappings().first()
        if not row:
            return None
        data = dict(row)
        metadata_payload = data.get("metadata")
        if isinstance(metadata_payload, str):
            data["metadata"] = json.loads(metadata_payload)
        return data

    # ------------------------------------------------------------------
    # Nodes
    # ------------------------------------------------------------------

    def upsert_node(self, node: NodeMetadata) -> None:
        payload = {
            "node_id": node.node_id,
            "display_name": node.display_name,
            "tags": node.tags,
            "capabilities": node.capabilities,
            "resources": node.resources,
            "status": node.status,
            "last_seen": node.last_seen.astimezone(timezone.utc),
            "last_hello": node.last_hello.astimezone(timezone.utc) if node.last_hello else None,
            "user_id": node.user_id,
            "machine_name": node.machine_name,
            "password_protected": 1 if node.password_protected else 0,
        }
        with self._session() as session:
            exists = session.execute(
                select(nodes_table.c.node_id).where(nodes_table.c.node_id == node.node_id)
            ).scalar_one_or_none()
            if exists:
                session.execute(
                    update(nodes_table)
                    .where(nodes_table.c.node_id == node.node_id)
                    .values(**payload)
                )
            else:
                session.execute(insert(nodes_table).values(**payload))
            session.commit()

    def list_nodes(self) -> list[NodeMetadata]:
        with self._session() as session:
            rows = session.execute(select(nodes_table).order_by(nodes_table.c.display_name)).mappings().all()
        return [self._row_to_node(row) for row in rows]

    def get_nodes_with_capability(self, capability: str) -> list[NodeMetadata]:
        """
        Get nodes that have specific capability.

        Args:
            capability: Capability name (e.g., 'github_api', 'linear_api')

        Returns:
            List of nodes with the capability, ordered by last_seen (most recent first)
        """
        with self._session() as session:
            rows = session.execute(
                select(nodes_table)
                .where(nodes_table.c.status == "online")
                .order_by(nodes_table.c.last_seen.desc())
            ).mappings().all()

        # Filter by capability in Python (JSON query is DB-specific)
        nodes_with_cap = []
        for row in rows:
            capabilities = _coerce_json(row.get("capabilities"), dict)
            if capabilities.get(capability):
                nodes_with_cap.append(self._row_to_node(row))

        return nodes_with_cap

    def get_node_for_user(self, user_id: str | None = None) -> NodeMetadata | None:
        """
        Get preferred node for user.

        Args:
            user_id: Optional user ID

        Returns:
            Node metadata or None if no suitable node found
        """
        # For now, just return first online node
        # In future, can implement user preferences
        with self._session() as session:
            row = session.execute(
                select(nodes_table)
                .where(nodes_table.c.status == "online")
                .order_by(nodes_table.c.last_seen.desc())
                .limit(1)
            ).mappings().first()

        return self._row_to_node(row) if row else None

    def get_node(self, node_id: str) -> NodeMetadata | None:
        with self._session() as session:
            row = session.execute(
                select(nodes_table).where(nodes_table.c.node_id == node_id)
            ).mappings().first()
        return self._row_to_node(row) if row else None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _row_to_job(self, row: MappingRow | dict[str, Any]) -> Job:
        repositories_raw = _coerce_json(row.get("repositories"), list)
        repositories = [RepositorySpec(**repo) for repo in repositories_raw]
        requested_tags = _coerce_json(row.get("requested_tags"), list)
        metadata_payload = _coerce_json(row.get("metadata"), dict)
        created_at = row.get("created_at")
        finished_at = row.get("finished_at")
        return Job(
            job_id=row["job_id"],
            prompt=row["prompt"],
            status=JobStatus(row["status"]),
            target_node_id=row.get("target_node_id"),
            requested_tags=requested_tags,
            repositories=repositories,
            metadata=metadata_payload,
            log_path=row.get("log_path"),
            result_summary=row.get("result_summary"),
            error_message=row.get("error_message"),
            created_at=created_at if isinstance(created_at, datetime) else datetime.fromisoformat(str(created_at)),
            finished_at=finished_at if not finished_at or isinstance(finished_at, datetime) else datetime.fromisoformat(str(finished_at)),
            retry_count=row.get("retry_count", 0),
            max_retries=row.get("max_retries", 0),
            creator_user_id=row.get("creator_user_id"),
            # GitHub Integration Fields
            repo_owner=row.get("repo_owner"),
            repo_name=row.get("repo_name"),
            issue_number=row.get("issue_number"),
            issue_title=row.get("issue_title"),
            issue_body=row.get("issue_body"),
            pr_number=row.get("pr_number"),
            pr_url=row.get("pr_url"),
            agent_type=row.get("agent_type", "claude-code"),
            branch_name=row.get("branch_name"),
            work_dir=row.get("work_dir"),
        )

    def _row_to_node(self, row: MappingRow | dict[str, Any]) -> NodeMetadata:
        last_seen = row.get("last_seen")
        last_hello = row.get("last_hello")
        return NodeMetadata(
            node_id=row["node_id"],
            display_name=row.get("display_name"),
            tags=_coerce_json(row.get("tags"), list),
            capabilities=_coerce_json(row.get("capabilities"), dict),
            resources=_coerce_json(row.get("resources"), dict),
            status=row.get("status", "offline"),
            last_seen=last_seen if isinstance(last_seen, datetime) else datetime.fromisoformat(str(last_seen)),
            last_hello=last_hello if not last_hello or isinstance(last_hello, datetime) else datetime.fromisoformat(str(last_hello)),
            user_id=row.get("user_id"),
            machine_name=row.get("machine_name"),
            password_protected=bool(row.get("password_protected", 0)),
        )

    # ------------------------------------------------------------------
    # User Management
    # ------------------------------------------------------------------

    def create_user(self, user: User) -> None:
        """Create a new user."""
        payload = {
            "user_id": user.user_id,
            "password_hash": user.password_hash,
            "display_name": user.display_name,
            "email": user.email,
            "github_token": user.github_token,
            "linear_api_key": user.linear_api_key,
            "created_at": user.created_at.astimezone(timezone.utc),
            "is_active": 1 if user.is_active else 0,
        }
        with self._session() as session:
            session.execute(insert(users_table).values(**payload))
            session.commit()

    def get_user(self, user_id: str) -> User | None:
        """Get user by ID."""
        with self._session() as session:
            row = session.execute(
                select(users_table).where(users_table.c.user_id == user_id)
            ).mappings().first()
            return self._row_to_user(row) if row else None

    def list_users(self) -> list[User]:
        """List all users."""
        with self._session() as session:
            rows = session.execute(
                select(users_table).order_by(users_table.c.created_at.desc())
            ).mappings().all()
        return [self._row_to_user(row) for row in rows]

    def update_user(self, user_id: str, **updates: Any) -> None:
        """Update user fields."""
        if not updates:
            return
        with self._session() as session:
            session.execute(
                update(users_table)
                .where(users_table.c.user_id == user_id)
                .values(**updates)
            )
            session.commit()

    def _row_to_user(self, row: MappingRow | dict[str, Any]) -> User:
        """Convert database row to User object."""
        created_at = row.get("created_at")
        return User(
            user_id=row["user_id"],
            password_hash=row["password_hash"],
            display_name=row.get("display_name"),
            email=row.get("email"),
            github_token=row.get("github_token"),
            linear_api_key=row.get("linear_api_key"),
            created_at=created_at if isinstance(created_at, datetime) else datetime.fromisoformat(str(created_at)),
            is_active=bool(row.get("is_active", True)),
        )


def init_storage(*, db_url: str | None = None, db_path: str | Path | None = None) -> Storage:
    """Initialise the Storage layer.

    Preference order:
      1. Explicit SQLAlchemy URL (``db_url``)
      2. Legacy SQLite path (``db_path``)
      3. Default to ``sqlite:///var/codernetes.db``
    """

    if db_url:
        url = make_url(db_url) if isinstance(db_url, str) else db_url
    elif db_path is not None:
        path = Path(db_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        url = f"sqlite:///{path.absolute()}"
    else:
        default_path = Path("var/codernetes.db")
        default_path.parent.mkdir(parents=True, exist_ok=True)
        url = f"sqlite:///{default_path.absolute()}"

    if isinstance(url, str) and url.startswith("sqlite:///") and not url.endswith(":memory:"):
        sqlite_path = Path(url.replace("sqlite:///", "", 1))
        sqlite_path.parent.mkdir(parents=True, exist_ok=True)

    engine = create_engine(
        str(url) if isinstance(url, URL) else url,
        echo=False,
        future=True,
        pool_pre_ping=True,
        json_serializer=lambda value: json.dumps(value, ensure_ascii=False),
        json_deserializer=lambda value: json.loads(value) if isinstance(value, str) else value,
    )
    return Storage(engine)

"""Codernetes 마스터 도메인 모델."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from enum import Enum


class JobStatus(str, Enum):
    """작업 상태."""

    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
    # GitHub Integration Statuses
    ACCEPTED = "accepted"
    CLONING = "cloning"
    AGENT_WORKING = "agent_working"
    COMMITTING = "committing"
    PUSHING = "pushing"
    PR_CREATING = "pr_creating"
    PR_CREATED = "pr_created"
    REVIEWING = "reviewing"


@dataclass(slots=True)
class RepositorySpec:
    """작업에 포함된 GitHub 레포지토리 명세."""

    url: str
    branch: str | None = None
    subdirectory: str | None = None  # Repo 내에서 작업할 경로


@dataclass(slots=True)
class Job:
    """Codernetes 작업 기본 모델."""

    job_id: str
    prompt: str
    created_at: datetime
    status: JobStatus = JobStatus.PENDING
    target_node_id: str | None = None
    requested_tags: list[str] = field(default_factory=list)
    repositories: list[RepositorySpec] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    log_path: str | None = None
    result_summary: str | None = None
    error_message: str | None = None
    finished_at: datetime | None = None
    retry_count: int = 0
    max_retries: int = 0
    # GitHub Integration Fields
    repo_owner: str | None = None
    repo_name: str | None = None
    issue_number: int | None = None
    issue_title: str | None = None
    issue_body: str | None = None
    pr_number: int | None = None
    pr_url: str | None = None
    agent_type: str | None = None  # None으로 설정하여 config 우선순위 적용
    branch_name: str | None = None
    work_dir: str | None = None
    creator_user_id: str | None = None  # User who created this job


@dataclass(slots=True)
class User:
    """사용자 정보."""

    user_id: str
    password_hash: str
    display_name: str | None = None
    email: str | None = None
    github_token: str | None = None  # Optional: encrypted
    linear_api_key: str | None = None  # Optional: encrypted
    created_at: datetime = field(default_factory=datetime.now)
    is_active: bool = True


@dataclass(slots=True)
class NodeMetadata:
    """노드 정보."""

    node_id: str
    display_name: str | None
    tags: list[str]
    capabilities: dict[str, Any]
    last_seen: datetime
    resources: dict[str, Any] = field(default_factory=dict)
    status: str = "online"
    last_hello: datetime | None = None
    user_id: str | None = None  # Owner of this node
    machine_name: str | None = None  # Machine identifier (e.g., "june-macbook-pro")
    password_protected: bool = False  # Whether this node requires password for job execution

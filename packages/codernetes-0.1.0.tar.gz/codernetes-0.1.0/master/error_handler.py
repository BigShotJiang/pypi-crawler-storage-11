"""
Error handling and retry logic for job execution.
"""

import asyncio
import logging
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class ErrorSeverity(Enum):
    """Error severity levels"""
    MINOR = "minor"  # Recoverable, can be retried
    MAJOR = "major"  # Serious but may be recoverable
    CRITICAL = "critical"  # Cannot be recovered, permanent failure


class ErrorCategory(Enum):
    """Error categories for classification"""
    NETWORK = "network"  # Network-related errors
    AUTHENTICATION = "authentication"  # Auth/permission errors
    RESOURCE = "resource"  # Resource unavailability
    VALIDATION = "validation"  # Input validation errors
    TIMEOUT = "timeout"  # Timeout errors
    AGENT = "agent"  # LLM agent execution errors
    GIT = "git"  # Git operation errors
    SYSTEM = "system"  # System/internal errors
    UNKNOWN = "unknown"  # Uncategorized errors


class JobError:
    """Structured error information"""

    def __init__(
        self,
        exception: Exception,
        category: ErrorCategory = ErrorCategory.UNKNOWN,
        severity: ErrorSeverity = ErrorSeverity.MAJOR,
        context: Optional[Dict[str, Any]] = None,
        retry_after: Optional[int] = None,
    ):
        self.exception = exception
        self.category = category
        self.severity = severity
        self.context = context or {}
        self.retry_after = retry_after
        self.timestamp = datetime.utcnow()

    def to_dict(self) -> dict:
        """Convert to dictionary for logging/storage"""
        return {
            "error_type": type(self.exception).__name__,
            "error_message": str(self.exception),
            "category": self.category.value,
            "severity": self.severity.value,
            "context": self.context,
            "retry_after": self.retry_after,
            "timestamp": self.timestamp.isoformat(),
        }


class JobErrorHandler:
    """Job execution error handling and recovery"""

    # Retry configuration by error category
    RETRY_CONFIG = {
        ErrorCategory.NETWORK: {
            "retryable": True,
            "max_retries": 3,
            "backoff_seconds": 5,
        },
        ErrorCategory.TIMEOUT: {
            "retryable": True,
            "max_retries": 2,
            "backoff_seconds": 10,
        },
        ErrorCategory.RESOURCE: {
            "retryable": True,
            "max_retries": 3,
            "backoff_seconds": 30,
        },
        ErrorCategory.AUTHENTICATION: {
            "retryable": False,
            "max_retries": 0,
            "backoff_seconds": 0,
        },
        ErrorCategory.VALIDATION: {
            "retryable": False,
            "max_retries": 0,
            "backoff_seconds": 0,
        },
        ErrorCategory.AGENT: {
            "retryable": True,
            "max_retries": 2,
            "backoff_seconds": 15,
        },
        ErrorCategory.GIT: {
            "retryable": True,
            "max_retries": 2,
            "backoff_seconds": 5,
        },
        ErrorCategory.SYSTEM: {
            "retryable": True,
            "max_retries": 2,
            "backoff_seconds": 10,
        },
        ErrorCategory.UNKNOWN: {
            "retryable": False,
            "max_retries": 0,
            "backoff_seconds": 0,
        },
    }

    def __init__(self, storage=None):
        """
        Initialize error handler

        Args:
            storage: Storage instance for persisting error logs
        """
        self.storage = storage

    def classify_error(self, error: Exception, context: Optional[Dict] = None) -> JobError:
        """
        Classify an error and determine its properties

        Args:
            error: The exception that occurred
            context: Additional context about the error

        Returns:
            JobError object with classification
        """
        error_msg = str(error).lower()
        error_type = type(error).__name__

        # Network errors
        if any(keyword in error_msg for keyword in ["connection", "network", "socket", "unreachable"]):
            return JobError(
                error,
                ErrorCategory.NETWORK,
                ErrorSeverity.MINOR,
                context,
                retry_after=5,
            )

        # Timeout errors
        if any(keyword in error_msg for keyword in ["timeout", "timed out"]):
            return JobError(
                error,
                ErrorCategory.TIMEOUT,
                ErrorSeverity.MINOR,
                context,
                retry_after=10,
            )

        # Authentication errors
        if any(keyword in error_msg for keyword in ["auth", "permission", "forbidden", "unauthorized"]):
            return JobError(
                error,
                ErrorCategory.AUTHENTICATION,
                ErrorSeverity.CRITICAL,
                context,
            )

        # Missing executable or configuration
        if "executable not found" in error_msg or "cli not found" in error_msg:
            return JobError(
                error,
                ErrorCategory.VALIDATION,
                ErrorSeverity.CRITICAL,
                context,
            )

        # Resource errors
        if any(keyword in error_msg for keyword in ["not found", "unavailable", "busy"]):
            return JobError(
                error,
                ErrorCategory.RESOURCE,
                ErrorSeverity.MAJOR,
                context,
                retry_after=30,
            )

        # Git errors
        if any(keyword in error_msg for keyword in ["git", "clone", "commit", "push"]) or \
           context and context.get("phase") in ["cloning", "committing", "pushing"]:
            return JobError(
                error,
                ErrorCategory.GIT,
                ErrorSeverity.MAJOR,
                context,
                retry_after=5,
            )

        # Agent errors
        if context and context.get("phase") == "agent_working":
            return JobError(
                error,
                ErrorCategory.AGENT,
                ErrorSeverity.MAJOR,
                context,
                retry_after=15,
            )

        # Default: unknown error
        return JobError(
            error,
            ErrorCategory.UNKNOWN,
            ErrorSeverity.MAJOR,
            context,
        )

    def is_retryable(self, job_error: JobError, current_retry_count: int = 0) -> bool:
        """
        Determine if an error is retryable

        Args:
            job_error: The classified error
            current_retry_count: Number of retries already attempted

        Returns:
            True if the error can be retried
        """
        config = self.RETRY_CONFIG.get(job_error.category)
        if not config or not config["retryable"]:
            return False

        # Check if we've exceeded max retries
        if current_retry_count >= config["max_retries"]:
            return False

        # Critical errors are not retryable
        if job_error.severity == ErrorSeverity.CRITICAL:
            return False

        return True

    def get_retry_delay(self, job_error: JobError, retry_count: int = 0) -> int:
        """
        Calculate retry delay with exponential backoff

        Args:
            job_error: The classified error
            retry_count: Number of retries already attempted

        Returns:
            Delay in seconds before retry
        """
        config = self.RETRY_CONFIG.get(job_error.category)
        if not config:
            return 0

        base_delay = config["backoff_seconds"]

        # Exponential backoff: delay = base * (2 ^ retry_count)
        delay = base_delay * (2 ** retry_count)

        # Cap at 5 minutes
        return min(delay, 300)

    async def handle_error(
        self,
        job_id: str,
        error: Exception,
        context: Optional[Dict[str, Any]] = None,
        current_retry_count: int = 0,
    ) -> Dict[str, Any]:
        """
        Handle a job error with logging, classification, and retry logic

        Args:
            job_id: The job that encountered the error
            error: The exception that occurred
            context: Additional context about the error
            current_retry_count: Number of retries already attempted

        Returns:
            Dictionary with handling result including:
            - should_retry: Whether to retry the job
            - retry_after: Delay before retry in seconds
            - error_info: Structured error information
        """
        # Classify the error
        job_error = self.classify_error(error, context)

        # Log the error
        await self.log_error(job_id, job_error)

        # Determine if retryable
        should_retry = self.is_retryable(job_error, current_retry_count)
        retry_delay = 0

        if should_retry:
            retry_delay = self.get_retry_delay(job_error, current_retry_count)
            logger.info(
                f"Job {job_id} error is retryable. "
                f"Scheduling retry {current_retry_count + 1} in {retry_delay}s"
            )
        else:
            logger.error(
                f"Job {job_id} encountered non-retryable error: "
                f"{job_error.category.value} - {str(error)}"
            )

        return {
            "should_retry": should_retry,
            "retry_after": retry_delay,
            "error_info": job_error.to_dict(),
        }

    async def log_error(self, job_id: str, job_error: JobError):
        """
        Log error information for debugging and analysis

        Args:
            job_id: The job that encountered the error
            job_error: The classified error
        """
        error_data = job_error.to_dict()
        error_data["job_id"] = job_id

        # Log to standard logging
        log_level = {
            ErrorSeverity.MINOR: logging.WARNING,
            ErrorSeverity.MAJOR: logging.ERROR,
            ErrorSeverity.CRITICAL: logging.CRITICAL,
        }.get(job_error.severity, logging.ERROR)

        logger.log(
            log_level,
            f"Job {job_id} error: {job_error.category.value} - {str(job_error.exception)}",
            extra={"error_data": error_data},
        )

        # TODO: Persist to storage if available
        # if self.storage:
        #     await self.storage.log_job_error(job_id, error_data)

    async def notify_user(
        self,
        job_id: str,
        error: Exception,
        status: str = "failed",
    ):
        """
        Notify user about job error (placeholder for future implementation)

        Args:
            job_id: The job that encountered the error
            error: The exception that occurred
            status: Current job status
        """
        # TODO: Implement user notification logic
        # This could involve:
        # - Sending WebSocket message to frontend
        # - Sending email/Slack notification
        # - Creating notification record in database
        logger.info(f"Notification placeholder: Job {job_id} {status}: {str(error)}")


# Global error handler instance
_error_handler: Optional[JobErrorHandler] = None


def get_error_handler(storage=None) -> JobErrorHandler:
    """Get or create the global error handler instance"""
    global _error_handler
    if _error_handler is None:
        _error_handler = JobErrorHandler(storage)
    return _error_handler

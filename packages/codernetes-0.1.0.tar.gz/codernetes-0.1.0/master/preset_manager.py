"""
Preset Manager for Codernetes

This module manages preset configurations for different types of tasks,
allowing users to define reusable configurations for common scenarios.
"""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass, asdict
from datetime import datetime
import json
import yaml
from pathlib import Path
from enum import Enum


class PresetType(Enum):
    """Types of presets"""
    BUG_FIX = "bug_fix"
    FEATURE = "feature"
    REFACTOR = "refactor"
    DOCUMENTATION = "documentation"
    PERFORMANCE = "performance"
    SECURITY = "security"
    TESTING = "testing"
    CUSTOM = "custom"


@dataclass
class PresetConfig:
    """Preset configuration"""
    name: str
    type: PresetType
    description: str
    instructions: str
    agent_type: Optional[str] = None
    system_prompt: Optional[str] = None
    workflow_phases: Optional[List[str]] = None
    testing_required: bool = True
    auto_merge: bool = False
    priority: int = 5
    tags: List[str] = None
    created_at: str = None
    updated_at: str = None
    created_by: str = None


class PresetManager:
    """Manages preset configurations"""

    def __init__(self, storage_path: Path = None):
        """Initialize preset manager

        Args:
            storage_path: Path to store preset configurations
        """
        if storage_path is None:
            storage_path = Path("var/presets")

        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)

        # Default presets file
        self.presets_file = self.storage_path / "presets.yaml"

        # Load default presets if not exists
        if not self.presets_file.exists():
            self._create_default_presets()

    def _create_default_presets(self):
        """Create default preset configurations"""
        default_presets = {
            "bug_fix_standard": PresetConfig(
                name="Standard Bug Fix",
                type=PresetType.BUG_FIX,
                description="Standard bug fix with testing",
                instructions="""
Focus on fixing the reported bug with minimal changes:
1. Identify the root cause of the bug
2. Implement the minimal fix required
3. Add or update tests to prevent regression
4. Ensure no side effects are introduced
5. Update relevant documentation if needed
                """.strip(),
                agent_type="claude-code",
                testing_required=True,
                auto_merge=False,
                priority=7,
                tags=["bug", "fix", "standard"],
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="system",
            ),

            "feature_implementation": PresetConfig(
                name="Feature Implementation",
                type=PresetType.FEATURE,
                description="New feature implementation with full workflow",
                instructions="""
Implement the requested feature following these guidelines:
1. Design the feature architecture first
2. Implement core functionality incrementally
3. Add comprehensive tests (unit and integration)
4. Update documentation and examples
5. Consider edge cases and error handling
6. Ensure backward compatibility where applicable
                """.strip(),
                agent_type="claude-code",
                workflow_phases=[
                    "problem_analysis",
                    "approach_exploration",
                    "solution_design",
                    "implementation",
                    "verification",
                    "feedback",
                ],
                testing_required=True,
                auto_merge=False,
                priority=5,
                tags=["feature", "new", "implementation"],
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="system",
            ),

            "refactor_clean_code": PresetConfig(
                name="Clean Code Refactoring",
                type=PresetType.REFACTOR,
                description="Refactor for better code quality",
                instructions="""
Refactor the code to improve quality and maintainability:
1. Apply SOLID principles where appropriate
2. Remove code duplication (DRY principle)
3. Improve naming clarity
4. Simplify complex logic
5. Add missing type hints/annotations
6. Ensure all tests still pass
7. Maintain backward compatibility
                """.strip(),
                agent_type="claude-code",
                testing_required=True,
                auto_merge=False,
                priority=4,
                tags=["refactor", "clean", "quality"],
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="system",
            ),

            "documentation_update": PresetConfig(
                name="Documentation Update",
                type=PresetType.DOCUMENTATION,
                description="Update or add documentation",
                instructions="""
Update documentation to be accurate and helpful:
1. Ensure all public APIs are documented
2. Add code examples where helpful
3. Update README if needed
4. Add inline comments for complex logic
5. Verify all examples work correctly
6. Use clear and concise language
                """.strip(),
                agent_type="claude-code",
                testing_required=False,
                auto_merge=False,
                priority=3,
                tags=["docs", "documentation", "readme"],
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="system",
            ),

            "performance_optimization": PresetConfig(
                name="Performance Optimization",
                type=PresetType.PERFORMANCE,
                description="Optimize code for better performance",
                instructions="""
Optimize performance following these steps:
1. Profile and identify bottlenecks
2. Apply algorithmic improvements where possible
3. Optimize database queries if applicable
4. Consider caching strategies
5. Reduce unnecessary computations
6. Add performance benchmarks/tests
7. Document performance improvements
                """.strip(),
                agent_type="claude-code",
                workflow_phases=[
                    "problem_analysis",
                    "approach_exploration",
                    "implementation",
                    "verification",
                ],
                testing_required=True,
                auto_merge=False,
                priority=6,
                tags=["performance", "optimization", "speed"],
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="system",
            ),

            "security_patch": PresetConfig(
                name="Security Patch",
                type=PresetType.SECURITY,
                description="Fix security vulnerabilities",
                instructions="""
Address security vulnerabilities with care:
1. Understand the security issue thoroughly
2. Apply the most secure fix available
3. Add security tests if possible
4. Review for any new vulnerabilities introduced
5. Update security documentation
6. Consider defense in depth principles
7. Validate all inputs and sanitize outputs
                """.strip(),
                agent_type="claude-code",
                testing_required=True,
                auto_merge=False,
                priority=9,
                tags=["security", "vulnerability", "patch"],
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="system",
            ),

            "test_coverage": PresetConfig(
                name="Test Coverage Improvement",
                type=PresetType.TESTING,
                description="Add or improve test coverage",
                instructions="""
Improve test coverage systematically:
1. Identify untested or poorly tested code
2. Add unit tests for individual functions/methods
3. Add integration tests for component interactions
4. Include edge cases and error conditions
5. Ensure tests are maintainable and clear
6. Use appropriate test fixtures and mocks
7. Aim for meaningful coverage, not just percentage
                """.strip(),
                agent_type="claude-code",
                testing_required=True,
                auto_merge=False,
                priority=5,
                tags=["testing", "coverage", "quality"],
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="system",
            ),
        }

        # Save default presets
        self._save_presets(default_presets)

    def _save_presets(self, presets: Dict[str, PresetConfig]):
        """Save presets to file"""
        # Convert to serializable format
        data = {}
        for key, preset in presets.items():
            preset_dict = asdict(preset)
            preset_dict["type"] = preset.type.value
            data[key] = preset_dict

        with open(self.presets_file, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    def load_presets(self) -> Dict[str, PresetConfig]:
        """Load all presets"""
        if not self.presets_file.exists():
            return {}

        with open(self.presets_file, "r") as f:
            data = yaml.safe_load(f) or {}

        presets = {}
        for key, preset_dict in data.items():
            # Convert type string back to enum
            preset_dict["type"] = PresetType(preset_dict["type"])
            presets[key] = PresetConfig(**preset_dict)

        return presets

    def get_preset(self, preset_id: str) -> Optional[PresetConfig]:
        """Get a specific preset by ID

        Args:
            preset_id: Preset identifier

        Returns:
            PresetConfig or None if not found
        """
        presets = self.load_presets()
        return presets.get(preset_id)

    def create_preset(self, preset_id: str, preset: PresetConfig) -> PresetConfig:
        """Create a new preset

        Args:
            preset_id: Unique identifier for the preset
            preset: PresetConfig object

        Returns:
            Created PresetConfig
        """
        presets = self.load_presets()

        if preset_id in presets:
            raise ValueError(f"Preset '{preset_id}' already exists")

        # Set timestamps
        preset.created_at = datetime.now().isoformat()
        preset.updated_at = datetime.now().isoformat()

        presets[preset_id] = preset
        self._save_presets(presets)

        return preset

    def update_preset(self, preset_id: str, updates: Dict[str, Any]) -> PresetConfig:
        """Update an existing preset

        Args:
            preset_id: Preset identifier
            updates: Dictionary of fields to update

        Returns:
            Updated PresetConfig
        """
        presets = self.load_presets()

        if preset_id not in presets:
            raise ValueError(f"Preset '{preset_id}' not found")

        preset = presets[preset_id]

        # Update fields
        for key, value in updates.items():
            if hasattr(preset, key):
                setattr(preset, key, value)

        # Update timestamp
        preset.updated_at = datetime.now().isoformat()

        presets[preset_id] = preset
        self._save_presets(presets)

        return preset

    def delete_preset(self, preset_id: str) -> bool:
        """Delete a preset

        Args:
            preset_id: Preset identifier

        Returns:
            True if deleted, False if not found
        """
        presets = self.load_presets()

        if preset_id not in presets:
            return False

        del presets[preset_id]
        self._save_presets(presets)

        return True

    def list_presets(
        self,
        preset_type: Optional[PresetType] = None,
        tags: Optional[List[str]] = None,
    ) -> List[tuple[str, PresetConfig]]:
        """List presets with optional filtering

        Args:
            preset_type: Filter by preset type
            tags: Filter by tags

        Returns:
            List of (preset_id, PresetConfig) tuples
        """
        presets = self.load_presets()
        results = []

        for preset_id, preset in presets.items():
            # Filter by type
            if preset_type and preset.type != preset_type:
                continue

            # Filter by tags
            if tags:
                preset_tags = preset.tags or []
                if not any(tag in preset_tags for tag in tags):
                    continue

            results.append((preset_id, preset))

        # Sort by priority (higher first) and name
        results.sort(key=lambda x: (-x[1].priority, x[1].name))

        return results

    def export_presets(self, output_path: Path):
        """Export presets to a file

        Args:
            output_path: Path to export file
        """
        presets = self.load_presets()

        # Convert to serializable format
        data = {}
        for key, preset in presets.items():
            preset_dict = asdict(preset)
            preset_dict["type"] = preset.type.value
            data[key] = preset_dict

        output_path = Path(output_path)

        if output_path.suffix == ".json":
            with open(output_path, "w") as f:
                json.dump(data, f, indent=2)
        else:
            with open(output_path, "w") as f:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    def import_presets(self, input_path: Path, overwrite: bool = False):
        """Import presets from a file

        Args:
            input_path: Path to import file
            overwrite: Whether to overwrite existing presets
        """
        input_path = Path(input_path)

        if input_path.suffix == ".json":
            with open(input_path, "r") as f:
                data = json.load(f)
        else:
            with open(input_path, "r") as f:
                data = yaml.safe_load(f)

        existing_presets = self.load_presets() if not overwrite else {}

        for key, preset_dict in data.items():
            if key in existing_presets and not overwrite:
                continue

            # Convert type string to enum
            preset_dict["type"] = PresetType(preset_dict["type"])
            existing_presets[key] = PresetConfig(**preset_dict)

        self._save_presets(existing_presets)
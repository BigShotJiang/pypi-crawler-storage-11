"""GitHub API integration client."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any

from github import Github, GithubException
from github.Issue import Issue as GithubIssue
from github.Repository import Repository as GithubRepo

LOGGER = logging.getLogger(__name__)


@dataclass
class Repository:
    """Simplified repository information."""

    name: str
    full_name: str
    owner: str
    url: str
    default_branch: str
    description: str | None = None
    private: bool = False


@dataclass
class Issue:
    """Simplified issue information."""

    number: int
    title: str
    body: str | None
    state: str
    labels: list[str]
    url: str
    repository: str  # full_name format: owner/repo
    created_at: str
    updated_at: str


@dataclass
class Branch:
    """Simplified branch information."""

    name: str
    commit: dict  # Contains 'sha' and 'url'


class GitHubClient:
    """GitHub API integration client using PyGithub."""

    def __init__(self, token: str | None = None):
        """
        Initialize GitHub client.

        Args:
            token: GitHub Personal Access Token or GitHub App token
                   If not provided, will attempt to read from GITHUB_TOKEN env var
        """
        self.token = token or os.getenv("GITHUB_TOKEN")
        if not self.token:
            raise ValueError("GitHub token is required. Set GITHUB_TOKEN environment variable or pass token parameter.")

        self._client = Github(self.token)
        LOGGER.info("GitHub client initialized")

    def test_connection(self) -> bool:
        """Test GitHub API connection and authentication."""
        try:
            user = self._client.get_user()
            LOGGER.info("GitHub connection successful. Authenticated as: %s", user.login)
            return True
        except GithubException as e:
            LOGGER.error("GitHub connection failed: %s", e)
            return False

    def list_repos(
        self,
        org: str | None = None,
        user: str | None = None,
        limit: int = 100,
    ) -> list[Repository]:
        """
        List repositories for an organization or user.

        Args:
            org: Organization name (takes precedence over user)
            user: User name
            limit: Maximum number of repos to return

        Returns:
            List of Repository objects
        """
        try:
            repos: list[GithubRepo] = []

            if org:
                LOGGER.info("Fetching repositories for organization: %s", org)
                org_obj = self._client.get_organization(org)
                repos = list(org_obj.get_repos()[:limit])
            elif user:
                LOGGER.info("Fetching repositories for user: %s", user)
                user_obj = self._client.get_user(user)
                repos = list(user_obj.get_repos()[:limit])
            else:
                # Get authenticated user's repos
                LOGGER.info("Fetching repositories for authenticated user")
                user_obj = self._client.get_user()
                repos = list(user_obj.get_repos()[:limit])

            return [self._convert_repo(repo) for repo in repos]

        except GithubException as e:
            LOGGER.error("Failed to list repositories: %s", e)
            raise

    def list_issues(
        self,
        owner: str,
        repo: str,
        state: str = "open",
        labels: list[str] | None = None,
        limit: int = 100,
    ) -> list[Issue]:
        """
        List issues for a repository.

        Args:
            owner: Repository owner (user or org)
            repo: Repository name
            state: Issue state ('open', 'closed', 'all')
            labels: Filter by label names
            limit: Maximum number of issues to return

        Returns:
            List of Issue objects
        """
        try:
            LOGGER.info("Fetching issues for %s/%s (state=%s)", owner, repo, state)
            repo_obj = self._client.get_repo(f"{owner}/{repo}")

            # Build query parameters
            kwargs: dict[str, Any] = {"state": state}
            if labels:
                kwargs["labels"] = labels

            issues = repo_obj.get_issues(**kwargs)
            issue_list = [self._convert_issue(issue, f"{owner}/{repo}") for issue in list(issues[:limit])]

            LOGGER.info("Found %d issues for %s/%s", len(issue_list), owner, repo)
            return issue_list

        except GithubException as e:
            LOGGER.error("Failed to list issues for %s/%s: %s", owner, repo, e)
            raise

    def get_issue(
        self,
        owner: str,
        repo: str,
        issue_number: int,
    ) -> Issue:
        """
        Get a specific issue.

        Args:
            owner: Repository owner
            repo: Repository name
            issue_number: Issue number

        Returns:
            Issue object
        """
        try:
            LOGGER.info("Fetching issue #%d from %s/%s", issue_number, owner, repo)
            repo_obj = self._client.get_repo(f"{owner}/{repo}")
            issue = repo_obj.get_issue(issue_number)
            return self._convert_issue(issue, f"{owner}/{repo}")
        except GithubException as e:
            LOGGER.error("Failed to get issue #%d from %s/%s: %s", issue_number, owner, repo, e)
            raise

    def list_branches(
        self,
        owner: str,
        repo: str,
        limit: int = 100,
    ) -> list[Branch]:
        """
        List branches for a repository.

        Args:
            owner: Repository owner (user or org)
            repo: Repository name
            limit: Maximum number of branches to return

        Returns:
            List of Branch objects
        """
        try:
            LOGGER.info("Fetching branches for %s/%s", owner, repo)
            repo_obj = self._client.get_repo(f"{owner}/{repo}")
            branches = repo_obj.get_branches()
            branch_list = [self._convert_branch(branch) for branch in list(branches[:limit])]

            LOGGER.info("Found %d branches for %s/%s", len(branch_list), owner, repo)
            return branch_list

        except GithubException as e:
            LOGGER.error("Failed to list branches for %s/%s: %s", owner, repo, e)
            raise

    def _convert_repo(self, repo: GithubRepo) -> Repository:
        """Convert PyGithub Repository to our Repository dataclass."""
        return Repository(
            name=repo.name,
            full_name=repo.full_name,
            owner=repo.owner.login,
            url=repo.html_url,
            default_branch=repo.default_branch,
            description=repo.description,
            private=repo.private,
        )

    def _convert_issue(self, issue: GithubIssue, repo_full_name: str) -> Issue:
        """Convert PyGithub Issue to our Issue dataclass."""
        return Issue(
            number=issue.number,
            title=issue.title,
            body=issue.body or "",
            state=issue.state,
            labels=[label.name for label in issue.labels],
            url=issue.html_url,
            repository=repo_full_name,
            created_at=issue.created_at.isoformat(),
            updated_at=issue.updated_at.isoformat(),
        )

    def _convert_branch(self, branch) -> Branch:
        """Convert PyGithub Branch to our Branch dataclass."""
        return Branch(
            name=branch.name,
            commit={
                "sha": branch.commit.sha,
                "url": branch.commit.html_url,
            },
        )


# Singleton instance management
_github_client: GitHubClient | None = None


def get_github_client(token: str | None = None) -> GitHubClient:
    """
    Get or create GitHub client instance.

    Args:
        token: Optional GitHub token. If not provided, uses cached instance or creates new one.

    Returns:
        GitHubClient instance
    """
    global _github_client

    if token:
        # Create new client with provided token
        _github_client = GitHubClient(token)
    elif _github_client is None:
        # Create new client with env token
        _github_client = GitHubClient()

    return _github_client

# Codernetes Documentation Index

문서들이 주제별로 정리되어 있습니다.

## 📚 Documentation Structure

### 🚀 [guides/](guides/) - User Guides & Getting Started
시작 가이드와 사용자 문서

- [getting_started.md](guides/getting_started.md) - Codernetes 시작하기
- [user_guide.md](guides/user_guide.md) - 사용자 가이드

### 🤖 [agents/](agents/) - Agent Configuration & Management
에이전트 설정 및 관리 문서

- [agent_configuration_guide.md](agents/agent_configuration_guide.md) - 에이전트 설정 가이드
- [agent_execution_troubleshooting.md](agents/agent_execution_troubleshooting.md) - 실행 문제 해결
- [agent_cli_troubleshooting.md](agents/agent_cli_troubleshooting.md) - CLI 문제 해결
- [enhanced_agent_system.md](agents/enhanced_agent_system.md) - 향상된 에이전트 시스템
- [node_capabilities.md](agents/node_capabilities.md) - Node 기능
- [node_execution_environment.md](agents/node_execution_environment.md) - 실행 환경

### 📊 [monitoring/](monitoring/) - Monitoring & Usage Tracking
모니터링 및 사용량 추적 문서

- [getting_started_monitoring.md](monitoring/getting_started_monitoring.md) - 모니터링 시작 가이드
- [MONITORING_QUICK_REFERENCE.md](monitoring/MONITORING_QUICK_REFERENCE.md) - 빠른 참조 카드
- [MONITORING_SYSTEM_COMPLETE.md](monitoring/MONITORING_SYSTEM_COMPLETE.md) - 전체 시스템 개요
- [node_usage_tracking.md](monitoring/node_usage_tracking.md) - Node 사용량 추적

### 🔌 [integrations/](integrations/) - External Integrations
외부 서비스 통합 문서

- [linear_integration.md](integrations/linear_integration.md) - Linear 통합
- [linear_workflow.md](integrations/linear_workflow.md) - Linear 워크플로우
- [azure_ai_setup.md](integrations/azure_ai_setup.md) - Azure AI 설정
- [azure_openai_integration_summary.md](integrations/azure_openai_integration_summary.md) - Azure OpenAI 통합
- [aider_azure_openai_setup.md](integrations/aider_azure_openai_setup.md) - Aider Azure OpenAI 설정
- [multi_tenant_authentication.md](integrations/multi_tenant_authentication.md) - 멀티 테넌트 인증

### 📖 [reference/](reference/) - API & CLI Reference
API 및 CLI 레퍼런스 문서

- [job_api.md](reference/job_api.md) - Job API 레퍼런스
- [c8s_cli_guide.md](reference/c8s_cli_guide.md) - c8s CLI 가이드
- [cli_agent_research.md](reference/cli_agent_research.md) - CLI 에이전트 연구
- [token_setup.md](reference/token_setup.md) - 토큰 설정
- [assets_documentation.md](reference/assets_documentation.md) - Assets 문서

### ⚙️ [operations/](operations/) - Operations & Testing
운영 및 테스트 문서

- [operations.md](operations/operations.md) - 운영 가이드
- [operations_checklist.md](operations/operations_checklist.md) - 운영 체크리스트
- [e2e_test_plan.md](operations/e2e_test_plan.md) - E2E 테스트 계획
- [e2e_smoketest.md](operations/e2e_smoketest.md) - 스모크 테스트

### 📋 [planning/](planning/) - Planning & Implementation
기획 및 구현 문서

- [implementation_plan.md](planning/implementation_plan.md) - 구현 계획
- [implementation_report.md](planning/implementation_report.md) - 구현 보고서
- [phase1_implementation_status.md](planning/phase1_implementation_status.md) - Phase 1 상태
- [ideation_questions.md](planning/ideation_questions.md) - 아이디어 질문
- [final_configuration_summary.md](planning/final_configuration_summary.md) - 최종 설정 요약
- [multi_llm_workflow.md](planning/multi_llm_workflow.md) - Multi-LLM 워크플로우

## 🔍 Quick Links

### Getting Started
- **처음 시작**: [guides/getting_started.md](guides/getting_started.md)
- **모니터링 시작**: [monitoring/getting_started_monitoring.md](monitoring/getting_started_monitoring.md)
- **CLI 가이드**: [reference/c8s_cli_guide.md](reference/c8s_cli_guide.md)

### Configuration
- **에이전트 설정**: [agents/agent_configuration_guide.md](agents/agent_configuration_guide.md)
- **토큰 설정**: [reference/token_setup.md](reference/token_setup.md)
- **인증 설정**: [integrations/multi_tenant_authentication.md](integrations/multi_tenant_authentication.md)

### Troubleshooting
- **에이전트 문제**: [agents/agent_execution_troubleshooting.md](agents/agent_execution_troubleshooting.md)
- **CLI 문제**: [agents/agent_cli_troubleshooting.md](agents/agent_cli_troubleshooting.md)
- **운영 체크리스트**: [operations/operations_checklist.md](operations/operations_checklist.md)

### Advanced
- **Node 기능**: [agents/node_capabilities.md](agents/node_capabilities.md)
- **사용량 추적**: [monitoring/node_usage_tracking.md](monitoring/node_usage_tracking.md)
- **Linear 통합**: [integrations/linear_integration.md](integrations/linear_integration.md)

## 📁 Directory Overview

```
context/
├── guides/          # 시작 가이드 및 사용자 문서 (2 files)
├── agents/          # 에이전트 설정 및 관리 (6 files)
├── monitoring/      # 모니터링 시스템 (4 files)
├── integrations/    # 외부 서비스 통합 (6 files)
├── reference/       # API 및 CLI 레퍼런스 (5 files)
├── operations/      # 운영 및 테스트 (4 files)
└── planning/        # 기획 및 구현 문서 (6 files)
```

**Total: 33 documentation files**

## 🗂️ Legacy Directories

기존에 있던 다른 context 디렉토리들:
- `node-credential-delegation/` - Node credential 위임 관련
- `codernetes-startup/` - 시작 관련 컨텍스트

# Codernetes E2E Tests

End-to-end tests for Codernetes using Playwright.

## Prerequisites

- Node.js 18+ installed
- Master server accessible at `http://localhost:8080`
- At least one Node connected to the master
- Python 3.12+ for running master/node

## Setup

```bash
# Navigate to E2E test directory
cd tests/e2e

# Install dependencies
npm install

# Install Playwright browsers
npx playwright install chromium
```

## Running Tests

### Run all tests
```bash
npm test
```

### Run tests in headed mode (with browser visible)
```bash
npm run test:headed
```

### Run tests in debug mode
```bash
npm run test:debug
```

### Run tests with UI mode (interactive)
```bash
npm run test:ui
```

### Run specific test suites
```bash
# Run only smoke tests
npm run test:smoke

# Run only critical tests
npm run test:critical

# Run specific test file
npx playwright test tests/01-basic-workflow.spec.ts
```

### View test report
```bash
npm run report
```

## Test Structure

```
tests/e2e/
├── tests/                      # Test files
│   ├── 01-basic-workflow.spec.ts
│   ├── 02-node-connection.spec.ts
│   ├── 03-job-cancellation.spec.ts
│   ├── 04-github-integration.spec.ts
│   ├── 05-error-handling.spec.ts
│   └── 06-workspace-cleanup.spec.ts
├── utils/                      # Test utilities
│   └── helpers.ts             # API and UI helper functions
├── fixtures/                   # Test data
│   └── jobs.json              # Job payload fixtures
├── playwright.config.ts        # Playwright configuration
├── package.json               # Dependencies
└── README.md                  # This file
```

## Test Categories

### P0 - Critical (Must Pass)
- ✅ Basic Workflow Test
- ✅ Node Connection Test
- ✅ Job Cancellation Test

### P1 - High Priority
- ⏳ GitHub Integration Test
- ⏳ Multiple Jobs Parallel Execution Test
- ⏳ Error Handling Test

### P2 - Medium Priority
- ⏳ Workspace Cleanup Test
- ⏳ Log Streaming Test
- ⏳ Artifact Download Test
- ⏳ UI Responsiveness Test

## Test Scenarios

### 1. Basic Workflow (01-basic-workflow.spec.ts)
Tests the complete job lifecycle:
- Create job via API
- Verify job appears in UI
- Monitor status changes
- Verify completion and artifacts
- Test job creation via UI
- Real-time log updates
- Multiple jobs display
- Page refresh handling

### 2. Node Connection (02-node-connection.spec.ts)
Tests node connectivity and health:
- Detect connected nodes
- Show node details in UI
- Maintain connection over time
- Assign jobs to nodes
- UI updates with node changes

### 3. Job Cancellation (03-job-cancellation.spec.ts)
Tests job cancellation feature:
- Cancel running job via API
- Cancel pending job
- Cancel job via UI button
- Reject cancellation of completed jobs
- Multiple rapid cancellations
- Workspace cleanup after cancellation

### 4. GitHub Integration (04-github-integration.spec.ts)
Tests GitHub PR creation workflow:
- Create GitHub issue resolution job
- Verify repository cloning
- Monitor agent progress
- Verify commit creation
- Verify PR creation
- Check PR details in UI

### 5. Error Handling (05-error-handling.spec.ts)
Tests error scenarios:
- Invalid job parameters
- Agent errors
- Node failures
- Error messages in UI
- System recovery

### 6. Workspace Cleanup (06-workspace-cleanup.spec.ts)
Tests automatic workspace management:
- Cleanup old directories
- Preserve active jobs
- Size-based cleanup
- Manual cleanup trigger

## Configuration

### Environment Variables

You can customize test behavior with environment variables:

```bash
# Custom master URL
BASE_URL=http://localhost:9000 npm test

# Enable CI mode (strict, no retry)
CI=true npm test

# Custom timeouts
TIMEOUT=60000 npm test
```

### Playwright Configuration

Edit `playwright.config.ts` to customize:

- Browser selection (chromium, firefox, webkit)
- Parallel execution
- Retry logic
- Screenshots and videos
- Test timeout
- Base URL

## Test Data

Test fixtures are defined in `fixtures/jobs.json`:

```json
{
  "simple_job": {
    "prompt": "Create a hello.py file",
    "max_iterations": 1
  },
  "long_running_job": {
    "prompt": "Long task...",
    "max_iterations": 1
  }
}
```

## Helper Functions

### ApiHelpers

API interaction utilities:

```typescript
const api = new ApiHelpers();

// Create job
await api.createJob(jobData);

// Get job status
const job = await api.getJob(jobId);

// Cancel job
await api.cancelJob(jobId);

// Wait for status
await api.waitForJobStatus(jobId, 'completed');

// Get nodes
const nodes = await api.getNodes();
```

### UiHelpers

UI interaction utilities:

```typescript
const ui = new UiHelpers(page);

// Navigate
await ui.goHome();

// Create job via UI
await ui.createJobViaUI({ prompt: '...', maxIterations: 1 });

// Select job
await ui.selectJob(jobId);

// Cancel job
await ui.cancelSelectedJob();

// Check status
const status = await ui.getJobStatus(jobId);
```

## Debugging Tests

### Run single test
```bash
npx playwright test tests/01-basic-workflow.spec.ts --grep "should complete full job lifecycle"
```

### Run with debug mode
```bash
npx playwright test --debug
```

### View test trace
```bash
# After a failed test
npx playwright show-trace trace.zip
```

### Generate screenshots
Tests automatically capture screenshots on failure. Find them in:
- `test-results/`

## CI/CD Integration

### GitHub Actions Example

```yaml
name: E2E Tests

on: [push, pull_request]

jobs:
  e2e:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Setup Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.12'

      - name: Setup Node
        uses: actions/setup-node@v3
        with:
          node-version: '18'

      - name: Install Python deps
        run: pip install -r requirements.txt

      - name: Start master server
        run: python -m master.server &

      - name: Start node
        run: python -m node.client &

      - name: Wait for services
        run: sleep 10

      - name: Install test deps
        run: |
          cd tests/e2e
          npm install
          npx playwright install chromium

      - name: Run E2E tests
        run: |
          cd tests/e2e
          npm test

      - name: Upload test report
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: playwright-report
          path: tests/e2e/playwright-report/
```

## Troubleshooting

### Master server not starting
```bash
# Check if port 8080 is already in use
lsof -i :8080

# Kill existing process
kill -9 <PID>
```

### Node not connecting
```bash
# Check master server logs
python -m master.server

# Check node logs
python -m node.client
```

### Tests timing out
- Increase timeout in `playwright.config.ts`
- Check system resources (CPU, memory)
- Verify network connectivity
- Check for long-running jobs

### Browser not found
```bash
# Reinstall Playwright browsers
npx playwright install
```

## Best Practices

1. **Use fixtures for test data**: Keep test data in `fixtures/jobs.json`
2. **Use helper functions**: Don't duplicate API/UI interaction code
3. **Add proper waits**: Use `waitForJobStatus()` instead of fixed timeouts
4. **Tag tests appropriately**: Use `@smoke`, `@critical`, `@slow` tags
5. **Clean up resources**: Let cleanup manager handle old workspaces
6. **Verify both API and UI**: Test that API changes reflect in UI
7. **Handle race conditions**: Jobs may complete faster than expected
8. **Log important events**: Use `console.log()` for debugging

## Contributing

When adding new tests:

1. Follow naming convention: `XX-feature-name.spec.ts`
2. Add test description at the top
3. Use appropriate priority tags
4. Update this README with new test description
5. Update test plan in `docs/e2e_test_plan.md`

## Support

For issues or questions:
- Check `docs/e2e_test_plan.md` for detailed test scenarios
- Review test output and logs
- Check Playwright documentation: https://playwright.dev

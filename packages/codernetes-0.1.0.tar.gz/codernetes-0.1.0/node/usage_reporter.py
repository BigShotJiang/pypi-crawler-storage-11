"""
Usage Reporter - Periodically report usage to Master

Reports local API usage to Master server for aggregation and monitoring.
"""

import asyncio
import aiohttp
from datetime import datetime, timedelta
from typing import Optional
import logging

from .usage_tracker import UsageTracker, get_tracker

logger = logging.getLogger(__name__)


class UsageReporter:
    """
    Periodically reports usage to Master server

    Usage:
        reporter = UsageReporter(
            master_url='http://localhost:8080',
            node_id='node-123',
            interval=300  # 5 minutes
        )

        await reporter.start()
        # ... runs in background ...
        await reporter.stop()
    """

    def __init__(
        self,
        master_url: str,
        node_id: str,
        interval: int = 300,  # 5 minutes default
        tracker: Optional[UsageTracker] = None,
    ):
        self.master_url = master_url.rstrip("/")
        self.node_id = node_id
        self.interval = interval
        self.tracker = tracker or get_tracker()
        self.running = False
        self.task: Optional[asyncio.Task] = None
        self.last_report_time: Optional[datetime] = None

    async def _send_report(self, report_data: dict) -> bool:
        """
        Send usage report to Master

        Args:
            report_data: Report data to send

        Returns:
            True if successful, False otherwise
        """
        url = f"{self.master_url}/api/nodes/{self.node_id}/usage"

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url, json=report_data, timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status in (200, 201):
                        logger.info(
                            f"Successfully reported usage to Master (status: {response.status})"
                        )
                        return True
                    else:
                        logger.error(
                            f"Failed to report usage: HTTP {response.status} - {await response.text()}"
                        )
                        return False

        except aiohttp.ClientError as e:
            logger.error(f"Network error reporting usage: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error reporting usage: {e}", exc_info=True)
            return False

    async def _report_loop(self):
        """Main reporting loop"""
        logger.info(
            f"Usage reporter started (interval: {self.interval}s, master: {self.master_url})"
        )

        while self.running:
            try:
                await self._do_report()
            except Exception as e:
                logger.error(f"Error in report loop: {e}", exc_info=True)

            # Wait for next interval
            await asyncio.sleep(self.interval)

        logger.info("Usage reporter stopped")

    async def _do_report(self):
        """Perform a single report"""
        if not self.tracker:
            logger.warning("No usage tracker available, skipping report")
            return

        # Determine time range for this report
        now = datetime.now()
        since = self.last_report_time or (now - timedelta(seconds=self.interval))

        # Get summary for reporting period
        claude_summary = self.tracker.get_summary(provider="claude", since=since)
        codex_summary = self.tracker.get_summary(provider="codex", since=since)

        # Export detailed records (optional, for debugging)
        # records = self.tracker.export_records(since=since)

        report_data = {
            "node_id": self.node_id,
            "timestamp": now.isoformat(),
            "period_start": since.isoformat(),
            "period_end": now.isoformat(),
            "claude": {
                "total_requests": claude_summary["total_requests"],
                "total_tokens": claude_summary["total_tokens"],
                "total_prompt_tokens": claude_summary["total_prompt_tokens"],
                "total_completion_tokens": claude_summary["total_completion_tokens"],
                "total_cost_usd": claude_summary["total_cost_usd"],
                "jobs_count": claude_summary["jobs_count"],
            },
            "codex": {
                "total_requests": codex_summary["total_requests"],
                "total_tokens": codex_summary["total_tokens"],
                "total_prompt_tokens": codex_summary["total_prompt_tokens"],
                "total_completion_tokens": codex_summary["total_completion_tokens"],
                "total_cost_usd": codex_summary["total_cost_usd"],
                "jobs_count": codex_summary["jobs_count"],
            },
            # Optionally include detailed records
            # "records": records,
        }

        # Log summary
        total_requests = (
            claude_summary["total_requests"] + codex_summary["total_requests"]
        )
        total_tokens = claude_summary["total_tokens"] + codex_summary["total_tokens"]

        if total_requests > 0:
            logger.info(
                f"Reporting usage: {total_requests} requests, {total_tokens} tokens "
                f"(Claude: {claude_summary['total_tokens']}, Codex: {codex_summary['total_tokens']})"
            )
        else:
            logger.debug("No usage to report for this period")

        # Send report
        success = await self._send_report(report_data)

        if success:
            self.last_report_time = now

    async def start(self):
        """Start the reporter"""
        if self.running:
            logger.warning("Reporter is already running")
            return

        if not self.tracker:
            logger.error("Cannot start reporter: no usage tracker available")
            return

        self.running = True
        self.task = asyncio.create_task(self._report_loop())

        # Send initial report immediately
        await self._do_report()

    async def stop(self):
        """Stop the reporter"""
        if not self.running:
            logger.warning("Reporter is not running")
            return

        logger.info("Stopping usage reporter...")
        self.running = False

        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass

        # Send final report
        logger.info("Sending final usage report...")
        await self._do_report()

    async def report_now(self) -> bool:
        """
        Trigger an immediate report (outside of regular schedule)

        Returns:
            True if successful
        """
        logger.info("Triggering immediate usage report...")
        await self._do_report()
        return self.last_report_time is not None


# Global reporter instance
_global_reporter: Optional[UsageReporter] = None


def init_reporter(master_url: str, node_id: str, interval: int = 300) -> UsageReporter:
    """Initialize global reporter"""
    global _global_reporter
    _global_reporter = UsageReporter(
        master_url=master_url, node_id=node_id, interval=interval
    )
    logger.info(
        f"Initialized usage reporter for node {node_id} (interval: {interval}s)"
    )
    return _global_reporter


def get_reporter() -> Optional[UsageReporter]:
    """Get global reporter instance"""
    return _global_reporter


async def start_reporter():
    """Start global reporter"""
    reporter = get_reporter()
    if reporter:
        await reporter.start()
    else:
        logger.warning("Usage reporter not initialized")


async def stop_reporter():
    """Stop global reporter"""
    reporter = get_reporter()
    if reporter:
        await reporter.stop()

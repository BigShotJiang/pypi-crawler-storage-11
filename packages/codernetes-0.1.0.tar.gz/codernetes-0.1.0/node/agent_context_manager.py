"""
Agent Context Manager for Codernetes

This module manages the .codernetes/ directory structure for each repository,
providing context persistence, session management, and workflow phases.
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, asdict
import yaml
from enum import Enum


class WorkflowPhase(Enum):
    """Agent workflow phases"""
    PROBLEM_ANALYSIS = "problem_analysis"
    APPROACH_EXPLORATION = "approach_exploration"
    SOLUTION_DESIGN = "solution_design"
    IMPLEMENTATION = "implementation"
    VERIFICATION = "verification"
    FEEDBACK = "feedback"
    COMPLETION = "completion"


@dataclass
class WorkflowState:
    """Represents the current state of the workflow"""
    phase: WorkflowPhase
    progress: Dict[str, Any]
    decisions: List[Dict[str, Any]]
    artifacts: List[str]
    timestamp: str
    session_id: str
    error_recovery: Optional[Dict[str, Any]] = None


@dataclass
class AgentContext:
    """Agent context for a specific repository/task"""
    repository: str
    issue_number: Optional[int]
    issue_title: str
    issue_body: str
    preset: Optional[str]
    workflow_state: Optional[WorkflowState]
    session_history: List[Dict[str, Any]]
    repository_context: Dict[str, Any]


class AgentContextManager:
    """Manages agent context and workflow state"""

    def __init__(self, work_dir: Path):
        """Initialize context manager for a repository

        Args:
            work_dir: Repository working directory
        """
        self.work_dir = Path(work_dir)
        self.context_dir = self.work_dir / ".codernetes"
        self.context_dir.mkdir(exist_ok=True)

        # Define context file paths
        self.paths = {
            "config": self.context_dir / "agent.md",
            "context": self.context_dir / "context.yaml",
            "workflow": self.context_dir / "workflow.yaml",
            "sessions": self.context_dir / "sessions.json",
            "presets": self.context_dir / "presets.yaml",
            "repository_info": self.context_dir / "repository_info.md",
            "phase_artifacts": self.context_dir / "phases",
        }

        # Create phase artifacts directory
        self.paths["phase_artifacts"].mkdir(exist_ok=True)

    def initialize_context(
        self,
        repository: str,
        issue_number: Optional[int] = None,
        issue_title: str = "",
        issue_body: str = "",
        preset: Optional[str] = None,
    ) -> AgentContext:
        """Initialize or load agent context

        Args:
            repository: Repository name (owner/repo)
            issue_number: GitHub issue number
            issue_title: Issue title
            issue_body: Issue description
            preset: Preset configuration name

        Returns:
            AgentContext object
        """
        # Load or create context
        if self.paths["context"].exists():
            with open(self.paths["context"], "r") as f:
                context_data = yaml.safe_load(f) or {}
        else:
            context_data = {}

        # Load session history
        sessions = self._load_sessions()

        # Load repository context
        repo_context = self._load_repository_context()

        # Create new context
        context = AgentContext(
            repository=repository,
            issue_number=issue_number,
            issue_title=issue_title,
            issue_body=issue_body,
            preset=preset,
            workflow_state=None,
            session_history=sessions,
            repository_context=repo_context,
        )

        # Save context
        self._save_context(context)

        return context

    def _load_sessions(self) -> List[Dict[str, Any]]:
        """Load session history"""
        if self.paths["sessions"].exists():
            with open(self.paths["sessions"], "r") as f:
                return json.load(f)
        return []

    def _load_repository_context(self) -> Dict[str, Any]:
        """Load repository-specific context"""
        context = {
            "structure": self._analyze_repository_structure(),
            "technologies": self._detect_technologies(),
            "conventions": self._detect_conventions(),
        }

        # Save as markdown for human readability
        self._save_repository_info(context)

        return context

    def _analyze_repository_structure(self) -> Dict[str, Any]:
        """Analyze repository structure"""
        structure = {
            "directories": [],
            "key_files": [],
            "test_locations": [],
            "doc_locations": [],
        }

        # Find key directories
        for item in self.work_dir.iterdir():
            if item.is_dir() and not item.name.startswith('.'):
                structure["directories"].append(item.name)

                # Identify test directories
                if "test" in item.name.lower():
                    structure["test_locations"].append(str(item.relative_to(self.work_dir)))

                # Identify documentation directories
                if item.name.lower() in ["docs", "documentation"]:
                    structure["doc_locations"].append(str(item.relative_to(self.work_dir)))

        # Find key files
        key_patterns = ["README*", "package.json", "pyproject.toml", "requirements*.txt", "Dockerfile"]
        for pattern in key_patterns:
            for file in self.work_dir.glob(pattern):
                if file.is_file():
                    structure["key_files"].append(file.name)

        return structure

    def _detect_technologies(self) -> Dict[str, List[str]]:
        """Detect technologies used in the repository"""
        tech = {
            "languages": [],
            "frameworks": [],
            "tools": [],
        }

        # Check for Python
        if any(self.work_dir.glob("*.py")) or (self.work_dir / "pyproject.toml").exists():
            tech["languages"].append("Python")

            # Check for specific Python frameworks
            if (self.work_dir / "requirements.txt").exists():
                req_content = (self.work_dir / "requirements.txt").read_text()
                if "fastapi" in req_content.lower():
                    tech["frameworks"].append("FastAPI")
                if "django" in req_content.lower():
                    tech["frameworks"].append("Django")
                if "flask" in req_content.lower():
                    tech["frameworks"].append("Flask")

        # Check for JavaScript/TypeScript
        if (self.work_dir / "package.json").exists():
            tech["languages"].append("JavaScript/TypeScript")

            pkg_content = json.loads((self.work_dir / "package.json").read_text())
            deps = {**pkg_content.get("dependencies", {}), **pkg_content.get("devDependencies", {})}

            if "react" in deps:
                tech["frameworks"].append("React")
            if "vue" in deps:
                tech["frameworks"].append("Vue")
            if "@angular/core" in deps:
                tech["frameworks"].append("Angular")
            if "vite" in deps:
                tech["tools"].append("Vite")

        # Check for Docker
        if (self.work_dir / "Dockerfile").exists():
            tech["tools"].append("Docker")

        return tech

    def _detect_conventions(self) -> Dict[str, Any]:
        """Detect coding conventions"""
        conventions = {
            "formatting": [],
            "linting": [],
            "testing": [],
        }

        # Check for formatters
        if (self.work_dir / ".prettierrc").exists() or (self.work_dir / ".prettierrc.json").exists():
            conventions["formatting"].append("Prettier")
        if (self.work_dir / ".black").exists() or (self.work_dir / "pyproject.toml").exists():
            conventions["formatting"].append("Black")

        # Check for linters
        if (self.work_dir / ".eslintrc.js").exists() or (self.work_dir / ".eslintrc.json").exists():
            conventions["linting"].append("ESLint")
        if (self.work_dir / ".pylintrc").exists():
            conventions["linting"].append("Pylint")
        if (self.work_dir / "pyproject.toml").exists():
            content = (self.work_dir / "pyproject.toml").read_text()
            if "[tool.ruff]" in content:
                conventions["linting"].append("Ruff")

        # Check for test frameworks
        if (self.work_dir / "pytest.ini").exists() or (self.work_dir / "pyproject.toml").exists():
            conventions["testing"].append("pytest")
        if (self.work_dir / "package.json").exists():
            pkg = json.loads((self.work_dir / "package.json").read_text())
            if "jest" in pkg.get("devDependencies", {}):
                conventions["testing"].append("Jest")
            if "vitest" in pkg.get("devDependencies", {}):
                conventions["testing"].append("Vitest")

        return conventions

    def _save_repository_info(self, context: Dict[str, Any]):
        """Save repository information as markdown"""
        info = ["# Repository Context\n"]
        info.append(f"Generated: {datetime.now().isoformat()}\n")

        # Structure
        info.append("## Repository Structure\n")
        info.append(f"**Directories**: {', '.join(context['structure']['directories'])}\n")
        info.append(f"**Key Files**: {', '.join(context['structure']['key_files'])}\n")
        if context['structure']['test_locations']:
            info.append(f"**Test Locations**: {', '.join(context['structure']['test_locations'])}\n")
        if context['structure']['doc_locations']:
            info.append(f"**Documentation**: {', '.join(context['structure']['doc_locations'])}\n")
        info.append("\n")

        # Technologies
        info.append("## Technologies\n")
        if context['technologies']['languages']:
            info.append(f"**Languages**: {', '.join(context['technologies']['languages'])}\n")
        if context['technologies']['frameworks']:
            info.append(f"**Frameworks**: {', '.join(context['technologies']['frameworks'])}\n")
        if context['technologies']['tools']:
            info.append(f"**Tools**: {', '.join(context['technologies']['tools'])}\n")
        info.append("\n")

        # Conventions
        info.append("## Conventions\n")
        if context['conventions']['formatting']:
            info.append(f"**Formatting**: {', '.join(context['conventions']['formatting'])}\n")
        if context['conventions']['linting']:
            info.append(f"**Linting**: {', '.join(context['conventions']['linting'])}\n")
        if context['conventions']['testing']:
            info.append(f"**Testing**: {', '.join(context['conventions']['testing'])}\n")

        with open(self.paths["repository_info"], "w") as f:
            f.write("".join(info))

    def _save_context(self, context: AgentContext):
        """Save agent context"""
        # Convert to dict for YAML
        context_dict = {
            "repository": context.repository,
            "issue_number": context.issue_number,
            "issue_title": context.issue_title,
            "issue_body": context.issue_body,
            "preset": context.preset,
            "repository_context": context.repository_context,
        }

        with open(self.paths["context"], "w") as f:
            yaml.dump(context_dict, f, default_flow_style=False)

    def start_workflow(self, session_id: str) -> WorkflowState:
        """Start a new workflow"""
        state = WorkflowState(
            phase=WorkflowPhase.PROBLEM_ANALYSIS,
            progress={},
            decisions=[],
            artifacts=[],
            timestamp=datetime.now().isoformat(),
            session_id=session_id,
        )

        self._save_workflow_state(state)
        return state

    def update_workflow_phase(
        self,
        phase: WorkflowPhase,
        progress: Optional[Dict[str, Any]] = None,
        decision: Optional[Dict[str, Any]] = None,
        artifact: Optional[str] = None,
    ) -> WorkflowState:
        """Update workflow phase and state"""
        state = self.load_workflow_state()

        if not state:
            raise ValueError("No active workflow found")

        state.phase = phase
        state.timestamp = datetime.now().isoformat()

        if progress:
            state.progress.update(progress)

        if decision:
            state.decisions.append(decision)

        if artifact:
            state.artifacts.append(artifact)

        self._save_workflow_state(state)
        self._save_phase_artifact(phase, state)

        return state

    def _save_phase_artifact(self, phase: WorkflowPhase, state: WorkflowState):
        """Save phase-specific artifact as markdown"""
        artifact_path = self.paths["phase_artifacts"] / f"{phase.value}.md"

        content = [f"# Phase: {phase.value.replace('_', ' ').title()}\n"]
        content.append(f"Session: {state.session_id}\n")
        content.append(f"Timestamp: {state.timestamp}\n\n")

        if state.progress:
            content.append("## Progress\n")
            for key, value in state.progress.items():
                content.append(f"- **{key}**: {value}\n")
            content.append("\n")

        if state.decisions:
            content.append("## Decisions\n")
            for decision in state.decisions:
                content.append(f"- {decision.get('description', 'Decision')}: {decision.get('choice', 'N/A')}\n")
                if 'reasoning' in decision:
                    content.append(f"  - Reasoning: {decision['reasoning']}\n")
            content.append("\n")

        if state.artifacts:
            content.append("## Artifacts\n")
            for artifact in state.artifacts:
                content.append(f"- {artifact}\n")

        with open(artifact_path, "w") as f:
            f.write("".join(content))

    def load_workflow_state(self) -> Optional[WorkflowState]:
        """Load current workflow state"""
        if not self.paths["workflow"].exists():
            return None

        with open(self.paths["workflow"], "r") as f:
            data = yaml.safe_load(f)

        if not data:
            return None

        return WorkflowState(
            phase=WorkflowPhase(data["phase"]),
            progress=data.get("progress", {}),
            decisions=data.get("decisions", []),
            artifacts=data.get("artifacts", []),
            timestamp=data["timestamp"],
            session_id=data["session_id"],
            error_recovery=data.get("error_recovery"),
        )

    def _save_workflow_state(self, state: WorkflowState):
        """Save workflow state"""
        data = {
            "phase": state.phase.value,
            "progress": state.progress,
            "decisions": state.decisions,
            "artifacts": state.artifacts,
            "timestamp": state.timestamp,
            "session_id": state.session_id,
            "error_recovery": state.error_recovery,
        }

        with open(self.paths["workflow"], "w") as f:
            yaml.dump(data, f, default_flow_style=False)

    def save_session(self, session_data: Dict[str, Any]):
        """Save session information"""
        sessions = self._load_sessions()
        sessions.append({
            **session_data,
            "timestamp": datetime.now().isoformat(),
        })

        # Keep last 10 sessions
        sessions = sessions[-10:]

        with open(self.paths["sessions"], "w") as f:
            json.dump(sessions, f, indent=2)

    def load_presets(self) -> Dict[str, Any]:
        """Load preset configurations"""
        if not self.paths["presets"].exists():
            return {}

        with open(self.paths["presets"], "r") as f:
            return yaml.safe_load(f) or {}

    def save_preset(self, name: str, preset_config: Dict[str, Any]):
        """Save a preset configuration"""
        presets = self.load_presets()
        presets[name] = preset_config

        with open(self.paths["presets"], "w") as f:
            yaml.dump(presets, f, default_flow_style=False)
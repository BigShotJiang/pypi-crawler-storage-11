"""
Azure OpenAI 클라이언트 - OpenAI SDK 직접 사용

Azure OpenAI 서비스를 통해 GPT 모델에 접근합니다.
"""

import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)


class AzureOpenAIClient:
    """Azure OpenAI 클라이언트 래퍼"""

    def __init__(self):
        """Azure OpenAI 클라이언트 초기화

        환경 변수:
            AZURE_OPENAI_ENDPOINT: Azure OpenAI 엔드포인트
                예: https://your-resource.openai.azure.com/
            MODEL_DEPLOYMENT_NAME: 배포된 모델 이름 (기본: gpt-4.1-mini)
            AZURE_API_VERSION: API 버전 (기본: 2024-02-15-preview)
            AZURE_API_KEY: Azure OpenAI API 키
        """
        self.endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.model_deployment = os.getenv("MODEL_DEPLOYMENT_NAME", "gpt-4.1-mini")
        self.api_version = os.getenv("AZURE_API_VERSION", "2024-02-15-preview")
        self.api_key = os.getenv("AZURE_API_KEY")

        if not self.endpoint:
            raise ValueError(
                "AZURE_OPENAI_ENDPOINT environment variable is required. "
                "Example: https://your-resource.openai.azure.com/"
            )

        if not self.api_key:
            raise ValueError(
                "AZURE_API_KEY environment variable is required for Azure OpenAI."
            )

        logger.info(f"Initializing Azure OpenAI client with endpoint: {self.endpoint}")
        logger.info(f"Using model deployment: {self.model_deployment}")

        # OpenAI SDK 가져오기
        try:
            from openai import AsyncAzureOpenAI
        except ImportError:
            raise ImportError(
                "OpenAI SDK is not installed. Please install it using 'pip install openai'"
            )

        # Azure OpenAI 클라이언트 생성
        self.client = AsyncAzureOpenAI(
            azure_endpoint=self.endpoint,
            api_key=self.api_key,
            api_version=self.api_version,
        )

    async def create_completion(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        """채팅 completion 생성

        Args:
            prompt: 사용자 프롬프트
            system_prompt: 시스템 프롬프트 (선택)
            temperature: 생성 온도 (0.0-1.0)
            max_tokens: 최대 토큰 수 (선택)

        Returns:
            생성된 텍스트 응답

        Raises:
            Exception: Azure OpenAI API 호출 실패 시
        """
        messages = []

        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })

        messages.append({
            "role": "user",
            "content": prompt
        })

        try:
            # Azure OpenAI 호출
            response = await self.client.chat.completions.create(
                model=self.model_deployment,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )

            # 응답 텍스트 추출
            if response.choices:
                return response.choices[0].message.content or ""
            else:
                return ""

        except Exception as e:
            logger.error(f"Azure OpenAI API call failed: {e}")
            raise Exception(f"Azure OpenAI API call failed: {e}")

    async def analyze_code_task(
        self,
        task_description: str,
        code_context: Optional[str] = None,
        temperature: float = 0.3,
    ) -> str:
        """코드 작업 분석

        Args:
            task_description: 수행할 작업 설명
            code_context: 현재 코드 컨텍스트 (선택)
            temperature: 생성 온도 (기본값: 0.3으로 더 일관된 응답)

        Returns:
            분석된 작업 계획 또는 코드 제안
        """
        system_prompt = (
            "You are an expert software engineer and code analyst. "
            "Analyze the given task and provide clear, actionable instructions or code. "
            "Focus on best practices, maintainability, and clean code principles. "
            "Be concise but thorough."
        )

        prompt = f"Task: {task_description}"

        if code_context:
            prompt += f"\n\nCurrent code context:\n{code_context}"

        prompt += "\n\nProvide your analysis and implementation approach:"

        return await self.create_completion(
            prompt=prompt,
            system_prompt=system_prompt,
            temperature=temperature,
        )

    async def generate_code(
        self,
        task: str,
        language: str = "python",
        context: Optional[str] = None,
    ) -> str:
        """코드 생성

        Args:
            task: 코드 생성 작업 설명
            language: 프로그래밍 언어 (기본: python)
            context: 추가 컨텍스트 정보

        Returns:
            생성된 코드
        """
        system_prompt = (
            f"You are an expert {language} developer. "
            "Generate clean, efficient, and well-documented code. "
            "Follow best practices and include appropriate error handling."
        )

        prompt = f"Generate {language} code for: {task}"

        if context:
            prompt += f"\n\nAdditional context:\n{context}"

        return await self.create_completion(
            prompt=prompt,
            system_prompt=system_prompt,
            temperature=0.2,  # 낮은 temperature로 더 일관된 코드 생성
        )
"""Codernetes 마스터 서버에 접속하는 간단한 노드 클라이언트."""

from __future__ import annotations

import argparse
import asyncio
import asyncio.subprocess
import contextlib
import json
import logging
import os
import platform
import shlex
import shutil
import sys
from datetime import datetime, timezone
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence
from urllib.parse import urlparse

import aiohttp
import websockets
from dotenv import load_dotenv
from zipfile import ZIP_DEFLATED, ZipFile

from .config import NodeConfig

LOGGER = logging.getLogger(__name__)


def _parse_key_value_pairs(raw: str) -> dict[str, Any]:
    if not raw:
        return {}
    result: dict[str, Any] = {}
    for chunk in raw.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "=" not in chunk:
            result[chunk] = True
            continue
        key, value = chunk.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        lowered = value.lower()
        if lowered in {"true", "false"}:
            parsed: Any = lowered == "true"
        else:
            try:
                parsed = int(value)
            except ValueError:
                try:
                    parsed = float(value)
                except ValueError:
                    parsed = value
        result[key] = parsed
    return result


@dataclass
class NodeContext:
    display_name: str | None
    tags: list[str]
    workdir_root: Path
    codernetes_command: list[str]
    github_token: str | None
    preserve_workdir: bool
    cleanup_delay: float
    capabilities: dict[str, Any]
    resources: dict[str, Any]
    master_http_host: str | None
    master_http_port: int | None
    user_id: str | None = None
    auth_token: str | None = None
    machine_name: str | None = None
    authenticated: bool = False
    credentials: dict[str, dict[str, Any]] = None  # provider -> {token, expires_at} for credential delegation
    http_port: int | None = None  # Port for node HTTP API server
    node_password: str | None = None  # Password for node access control (optional)
    diff_path: Path | None = None
    diff_summary: str | None = None
    client_id: str | None = None
    metadata_sent: bool = False
    # Changed: Support multiple concurrent jobs
    active_jobs: dict[str, dict[str, Any]] = None  # job_id -> {task, log_path, work_dir}
    max_concurrent_jobs: int = 5
    current_log_path: Path | None = None  # For backward compatibility with _send_job_log

    def __post_init__(self):
        if self.active_jobs is None:
            self.active_jobs = {}
        if self.credentials is None:
            self.credentials = {}

    def mark_busy(self, job_id: str, task: asyncio.Task | None = None, work_dir: Path | None = None, log_path: Path | None = None) -> None:
        """Mark a job as active"""
        self.active_jobs[job_id] = {
            'task': task,
            'work_dir': work_dir,
            'log_path': log_path,
            'started_at': datetime.now(timezone.utc).isoformat(),
        }
        # Set current_log_path for backward compatibility
        self.current_log_path = log_path

    def mark_idle(self, job_id: str | None = None) -> None:
        """Mark a job as completed and remove from active jobs"""
        if job_id and job_id in self.active_jobs:
            del self.active_jobs[job_id]
        # Clear current_log_path if no jobs remain
        if not self.active_jobs:
            self.current_log_path = None

    def is_busy(self) -> bool:
        """Check if node is at capacity"""
        return len(self.active_jobs) >= self.max_concurrent_jobs

    def get_active_job_ids(self) -> list[str]:
        """Get list of currently active job IDs"""
        return list(self.active_jobs.keys())

    def get_job_log_path(self, job_id: str) -> Path | None:
        """Get log path for a specific job"""
        if job_id in self.active_jobs:
            return self.active_jobs[job_id].get('log_path')
        return None


async def _receiver(websocket, context: NodeContext) -> None:
    async for message in websocket:
        try:
            payload = json.loads(message)
        except json.JSONDecodeError:
            LOGGER.warning("수신한 메시지를 JSON으로 파싱할 수 없습니다: %s", message)
            continue

        msg_type = payload.get("type")
        if msg_type == "welcome":
            context.client_id = payload.get("client_id")
            print(f"[master] {payload.get('message')}")
            print(f"Node ID: {context.client_id}")
            await _send_node_hello(websocket, context)
        elif msg_type == "auth_response":
            await _handle_auth_response(websocket, context, payload)
        elif msg_type == "job.assign":
            await _handle_job_assign(websocket, context, payload)
        elif msg_type == "job.cancel":
            await _handle_job_cancel(websocket, context, payload)
        elif msg_type == "message":
            sender = payload.get("from", "unknown")
            print(f"[{sender}] {payload.get('payload')}")
        else:
            print(f"[unknown] {payload}")


async def _send_node_hello(websocket, context: NodeContext) -> None:
    if context.metadata_sent or not context.client_id:
        return

    # Debug log for password protection
    password_protected = context.node_password is not None
    LOGGER.info(f"Sending hello message: password_protected={password_protected}, node_password={'***' if context.node_password else 'None'}")

    message = {
        "type": "node.hello",
        "node_id": context.client_id,
        "display_name": context.display_name,
        "tags": context.tags,
        "capabilities": context.capabilities,
        "resources": context.resources,
        "protocol_version": 1,
        # Authentication fields
        "user_id": context.user_id,
        "auth_token": context.auth_token,
        "machine_name": context.machine_name,
        # Access control
        "password_protected": password_protected,
        # HTTP API endpoint (for delegation)
        "http_port": context.http_port,
    }
    await websocket.send(json.dumps(message))
    context.metadata_sent = True


async def _handle_auth_response(websocket, context: NodeContext, payload: dict[str, object]) -> None:
    """Handle authentication response from master."""
    status = payload.get("status")
    if status == "success" or status == "authenticated":
        context.authenticated = True
        message = payload.get("message", "")
        print(f"✅ [auth] {message}")
        LOGGER.info("Node authenticated successfully")
    else:
        error = payload.get("error", "Unknown authentication error")
        print(f"❌ [auth] Authentication failed: {error}")
        LOGGER.error("Authentication failed: %s", error)
        # Close connection on auth failure
        await websocket.close(code=1008, reason="Authentication failed")
        sys.exit(1)


async def _handle_job_cancel(websocket, context: NodeContext, payload: dict[str, object]) -> None:
    """Handle job cancellation request"""
    job_id = payload.get("job_id")
    if not job_id:
        LOGGER.warning("job.cancel payload에 job_id가 없습니다: %s", payload)
        return

    LOGGER.info("Job cancellation requested: %s", job_id)
    print(f"[job {job_id}] 작업 취소 요청을 수신했습니다.")

    # Check if this job is active
    if job_id not in context.active_jobs:
        LOGGER.warning(
            "Cannot cancel job %s: not active (active jobs: %s)", job_id, context.get_active_job_ids()
        )
        await websocket.send(
            json.dumps(
                {
                    "type": "job.status",
                    "job_id": job_id,
                    "status": "cancelled",
                    "error_message": "job not active on this node",
                }
            )
        )
        return

    # Cancel the running task
    job_info = context.active_jobs.get(job_id)
    if job_info and job_info['task'] and not job_info['task'].done():
        job_info['task'].cancel()
        print(f"[job {job_id}] 작업을 취소하는 중...")

    # Update job status to cancelled
    await websocket.send(
        json.dumps(
            {
                "type": "job.status",
                "job_id": job_id,
                "status": "cancelled",
                "result_summary": "Job cancelled by user",
            }
        )
    )
    await _send_job_log(websocket, job_id, "Job cancelled by user", level="warning", context=context)

    # Mark context as idle
    context.mark_idle(job_id)
    print(f"[job {job_id}] 작업이 취소되었습니다.")


async def _handle_job_assign(websocket, context: NodeContext, payload: dict[str, object]) -> None:
    job_id = payload.get("job_id")
    if not job_id:
        LOGGER.warning("job.assign payload에 job_id가 없습니다: %s", payload)
        return

    # Verify node password if this node is password-protected
    if context.node_password:
        metadata = payload.get("metadata", {}) if isinstance(payload.get("metadata"), dict) else {}
        provided_password = metadata.get("node_password")

        if provided_password != context.node_password:
            LOGGER.warning(f"작업 {job_id} 거절: 잘못된 노드 비밀번호")
            await websocket.send(
                json.dumps(
                    {
                        "type": "job.status",
                        "job_id": job_id,
                        "status": "failed",
                        "error_message": "Invalid node password - access denied",
                    }
                )
            )
            return

    # Check if node is at capacity
    if context.is_busy():
        active_jobs = context.get_active_job_ids()
        LOGGER.warning(f"노드가 최대 용량입니다 ({len(active_jobs)}/{context.max_concurrent_jobs}). 작업 {job_id} 거절.")
        await websocket.send(
            json.dumps(
                {
                    "type": "job.status",
                    "job_id": job_id,
                    "status": "failed",
                    "error_message": f"node is at capacity ({len(active_jobs)}/{context.max_concurrent_jobs} jobs)",
                }
            )
        )
        return

    prompt = payload.get("prompt", "")
    repositories = payload.get("repositories", [])
    http_endpoint = payload.get("http_endpoint") if isinstance(payload.get("http_endpoint"), dict) else None
    if http_endpoint:
        host = http_endpoint.get("host")
        port = http_endpoint.get("port")
        if isinstance(host, str) and host.strip():
            context.master_http_host = host.strip()
        if isinstance(port, int):
            context.master_http_port = port

    # Check if this is a GitHub-integrated job
    repo_owner = payload.get("repo_owner")
    repo_name = payload.get("repo_name")
    issue_number = payload.get("issue_number")

    print(f"[job {job_id}] 작업을 수신했습니다. 프롬프트: {prompt}")
    if repo_owner and repo_name:
        print(f"  - GitHub: {repo_owner}/{repo_name}")
        if issue_number:
            print(f"  - Issue: #{issue_number}")
    if isinstance(repositories, list) and repositories:
        for repo in repositories:
            repo_url = repo.get("url") if isinstance(repo, dict) else repo
            print(f"  - repo: {repo_url}")

    # Create and store the task
    if repo_owner and repo_name:
        task = asyncio.create_task(_execute_github_job(websocket, context, payload))
    else:
        task = asyncio.create_task(_execute_job(websocket, context, payload))

    context.mark_busy(job_id, task)
    await websocket.send(
        json.dumps(
            {
                "type": "job.status",
                "job_id": job_id,
                "status": "running",
                "result_summary": "job started",
            }
        )
    )


async def _execute_github_job(websocket, context: NodeContext, payload: dict[str, object]) -> None:
    """Execute a GitHub-integrated job using JobExecutor"""
    from datetime import datetime, timezone
    from master.models import Job, JobStatus, RepositorySpec
    from node.job_executor import JobExecutor

    job_id = str(payload.get("job_id"))

    try:
        # Construct Job object from payload
        prompt = str(payload.get("prompt", ""))
        repositories_data = payload.get("repositories", []) if isinstance(payload.get("repositories"), list) else []
        repositories = [
            RepositorySpec(
                url=str(repo.get("url")),
                branch=repo.get("branch"),
                subdirectory=repo.get("subdirectory")
            )
            for repo in repositories_data
            if isinstance(repo, dict) and repo.get("url")
        ]

        job = Job(
            job_id=job_id,
            prompt=prompt,
            created_at=datetime.now(timezone.utc),
            status=JobStatus.RUNNING,
            repositories=repositories,
            metadata=payload.get("metadata", {}),
            repo_owner=str(payload.get("repo_owner", "")),
            repo_name=str(payload.get("repo_name", "")),
            issue_number=int(payload.get("issue_number")) if payload.get("issue_number") else None,
            issue_title=str(payload.get("issue_title", "")) if payload.get("issue_title") else None,
            issue_body=str(payload.get("issue_body", "")) if payload.get("issue_body") else None,
            agent_type=str(payload.get("agent_type", "claude-code")),
        )

        await _send_job_log(websocket, job_id, "Starting GitHub-integrated workflow", context=context)

        # Status update callback
        async def status_callback(job_id: str, status: JobStatus):
            await websocket.send(
                json.dumps(
                    {
                        "type": "job.status",
                        "job_id": job_id,
                        "status": status.value,
                    }
                )
            )
            await _send_job_log(
                websocket,
                job_id,
                f"Status updated: {status.value}",
                context=context
            )

        # Execute job with JobExecutor
        executor = JobExecutor(
            jobs_work_dir=str(context.workdir_root),
            github_token=context.github_token,
            fallback_command=context.codernetes_command if context.codernetes_command else None,
        )

        result = await executor.execute_job(job, status_callback)

        # Send final status
        if result.success:
            # Use result_summary from executor if available, otherwise construct from PR info
            final_summary = result.result_summary if result.result_summary else (
                f"PR created: {result.pr_url}\\nFiles changed: {result.files_changed}" if result.pr_url
                else f"Job completed. Files changed: {result.files_changed}"
            )

            await websocket.send(
                json.dumps(
                    {
                        "type": "job.status",
                        "job_id": job_id,
                        "status": "succeeded",
                        "result_summary": final_summary,
                        "pr_number": result.pr_number,
                        "pr_url": result.pr_url,
                    }
                )
            )
            await _send_job_log(
                websocket,
                job_id,
                f"Job completed successfully. PR: {result.pr_url}",
                level="info",
                context=context,
            )
        else:
            await websocket.send(
                json.dumps(
                    {
                        "type": "job.status",
                        "job_id": job_id,
                        "status": "failed",
                        "error_message": result.error_message or "Job execution failed",
                    }
                )
            )
            await _send_job_log(
                websocket,
                job_id,
                f"Job failed: {result.error_message}",
                level="error",
                context=context,
            )

    except Exception as exc:
        LOGGER.exception("GitHub job %s execution failed", job_id)
        await websocket.send(
            json.dumps(
                {
                    "type": "job.status",
                    "job_id": job_id,
                    "status": "failed",
                    "error_message": str(exc),
                }
            )
        )
        await _send_job_log(websocket, job_id, f"Error: {exc}", level="error", context=context)
    finally:
        context.mark_idle(job_id)


async def _execute_job(websocket, context: NodeContext, payload: dict[str, object]) -> None:
    job_id = str(payload.get("job_id"))
    workdir = context.workdir_root / job_id
    prompt = str(payload.get("prompt", ""))
    repositories = payload.get("repositories", []) if isinstance(payload.get("repositories"), list) else []
    metadata = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
    verification_commands: list[str] = []
    if isinstance(metadata, dict):
        raw_verify = metadata.get("verification_commands")
        if isinstance(raw_verify, list):
            verification_commands = [str(item) for item in raw_verify if isinstance(item, str) and item.strip()]

    try:
        if workdir.exists():
            shutil.rmtree(workdir)
        workdir.mkdir(parents=True, exist_ok=True)
        context.current_log_path = workdir / "job.log"
        await _send_job_log(websocket, job_id, f"작업 디렉터리 생성: {workdir}", context=context)

        prompt_path = workdir / "prompt.txt"
        prompt_path.write_text(prompt, encoding="utf-8")
        await _send_job_log(websocket, job_id, "프롬프트 파일 저장 완료", context=context)

        if repositories:
            for repo_spec in repositories:
                if not isinstance(repo_spec, dict):
                    continue
                url = str(repo_spec.get("url", "")).strip()
                if not url:
                    continue
                branch = repo_spec.get("branch")
                subdirectory = repo_spec.get("subdirectory")
                await _send_job_log(websocket, job_id, f"레포지토리 클론: {url}", context=context)
                ok = await _clone_repository(websocket, job_id, url, branch, workdir, context)
                if not ok:
                    raise RuntimeError(f"failed to clone {url}")
                if subdirectory:
                    await _send_job_log(websocket, job_id, f"서브디렉터리 지정: {subdirectory}", context=context)

        if context.codernetes_command:
            await _send_job_log(websocket, job_id, "Codernetes 명령 실행 시작", context=context)
            env = os.environ.copy()
            env["CODERNETES_PROMPT"] = prompt
            env["CODERNETES_PROMPT_FILE"] = str(prompt_path)
            success = await _run_command(
                websocket,
                job_id,
                context.codernetes_command,
                cwd=workdir,
                env=env,
                context=context,
            )
            if not success:
                raise RuntimeError("codernetes command failed")
        else:
            await _send_job_log(websocket, job_id, "Codernetes 명령이 정의되지 않아 실행을 건너뜁니다.", context=context)

        diff_summary = await _collect_diff_summary(workdir, repositories if isinstance(repositories, list) else [], context)
        verify_success, verify_summary = await _run_verification_commands(
            websocket,
            context,
            job_id,
            verification_commands,
            workdir,
        )
        if not verify_success:
            artifacts = _package_artifacts(workdir, context)
            uploaded_artifacts = await _upload_artifacts(context, job_id, artifacts)
            await websocket.send(
                json.dumps(
                    {
                        "type": "job.status",
                        "job_id": job_id,
                        "status": "failed",
                        "error_message": verify_summary,
                        "result_summary": diff_summary,
                        "artifacts": uploaded_artifacts,
                    }
                )
            )
            await _send_job_log(websocket, job_id, verify_summary, level="error", context=context)
            return

        summary_parts = [diff_summary]
        if verification_commands:
            summary_parts.append(verify_summary)
        result_summary = "\n".join(part for part in summary_parts if part)

        artifacts = _package_artifacts(workdir, context)
        uploaded_artifacts = await _upload_artifacts(context, job_id, artifacts)
        await websocket.send(
            json.dumps(
                {
                    "type": "job.status",
                    "job_id": job_id,
                    "status": "succeeded",
                    "result_summary": result_summary or "job completed successfully",
                    "artifacts": uploaded_artifacts,
                }
            )
        )
        await _send_job_log(websocket, job_id, "작업 완료", level="info", context=context)
    except Exception as exc:  # noqa: BLE001
        LOGGER.exception("Job %s 실행 중 오류", job_id)
        try:
            diff_summary = await _collect_diff_summary(workdir, repositories if isinstance(repositories, list) else [], context)
        except Exception:  # noqa: BLE001
            diff_summary = ""
        artifacts = _package_artifacts(workdir, context)
        uploaded_artifacts = await _upload_artifacts(context, job_id, artifacts)
        await websocket.send(
            json.dumps(
                {
                    "type": "job.status",
                    "job_id": job_id,
                    "status": "failed",
                    "error_message": str(exc),
                    "result_summary": diff_summary,
                    "artifacts": uploaded_artifacts,
                }
            )
        )
        await _send_job_log(websocket, job_id, f"오류: {exc}", level="error", context=context)
    finally:
        context.mark_idle(job_id)
        if not context.preserve_workdir:
            asyncio.create_task(_cleanup_workdir(workdir, context.cleanup_delay))


async def _send_job_log(
    websocket,
    job_id: str,
    message: str,
    *,
    level: str = "info",
    context: NodeContext | None = None,
) -> None:
    if context and context.current_log_path is not None:
        with context.current_log_path.open("a", encoding="utf-8") as fp:
            fp.write(f"[{level}] {message}\n")
    await websocket.send(
        json.dumps(
            {
                "type": "job.log",
                "job_id": job_id,
                "level": level,
                "message": message,
            }
        )
    )


async def _clone_repository(
    websocket,
    job_id: str,
    url: str,
    branch: str | None,
    workdir: Path,
    context: NodeContext,
) -> bool:
    repo_name = _derive_repo_name(url)
    target = workdir / repo_name
    cmd = ["git", "clone", "--depth", "1"]
    if branch:
        cmd += ["--branch", str(branch)]
    clone_url = _inject_token(url, context.github_token)
    masked_url = _mask_token(clone_url, context.github_token)
    await _send_job_log(websocket, job_id, f"git clone {masked_url}", context=context)
    cmd += [clone_url, str(target)]
    return await _run_command(websocket, job_id, cmd, cwd=workdir, context=context)


def _derive_repo_name(url: str) -> str:
    parsed = urlparse(url)
    path = parsed.path or url
    name = Path(path.rstrip("/")).name
    if name.endswith(".git"):
        name = name[:-4]
    return name or "repository"


def _inject_token(url: str, token: str | None) -> str:
    if not token:
        return url
    parsed = urlparse(url)
    if parsed.scheme not in {"https"}:
        return url
    safe_token = token.replace("@", "%40")
    netloc = f"{safe_token}@{parsed.hostname}"
    if parsed.port:
        netloc += f":{parsed.port}"
    return parsed._replace(netloc=netloc).geturl()


def _mask_token(url: str, token: str | None) -> str:
    if not token:
        return url
    return url.replace(token, "****")


async def _run_command(
    websocket,
    job_id: str,
    cmd: list[str],
    *,
    cwd: Path,
    env: dict[str, str] | None = None,
    context: NodeContext | None = None,
) -> bool:
    display_cmd = ' '.join(cmd)
    if context and context.github_token:
        display_cmd = display_cmd.replace(context.github_token, "****")
    await _send_job_log(websocket, job_id, f"명령 실행: {display_cmd}", context=context)
    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=str(cwd),
        env=env,
    )

    async def _pipe(stream: asyncio.StreamReader, level: str) -> None:
        while True:
            line = await stream.readline()
            if not line:
                break
            await _send_job_log(
                websocket,
                job_id,
                line.decode(errors="replace").rstrip(),
                level=level,
                context=context,
            )

    await asyncio.gather(_pipe(process.stdout, "info"), _pipe(process.stderr, "error"))
    return_code = await process.wait()
    await _send_job_log(websocket, job_id, f"명령 종료 코드: {return_code}", context=context)
    return return_code == 0


async def _cleanup_workdir(workdir: Path, delay: float) -> None:
    try:
        if delay > 0:
            await asyncio.sleep(delay)
        shutil.rmtree(workdir, ignore_errors=True)
        LOGGER.info("작업 디렉터리를 정리했습니다: %s", workdir)
    except Exception as exc:  # noqa: BLE001
        LOGGER.warning("작업 디렉터리 정리 실패(%s): %s", workdir, exc)


def _package_artifacts(workdir: Path, context: NodeContext) -> list[dict[str, Any]]:
    artifacts: list[dict[str, Any]] = []
    try:
        log_path = context.current_log_path
        prompt_path = workdir / "prompt.txt"
        diff_path = context.diff_path
        attachments: list[tuple[Path, str]] = []
        if log_path and log_path.exists():
            attachments.append((log_path, "logs/job.log"))
        if prompt_path.exists():
            attachments.append((prompt_path, "prompt.txt"))
        if diff_path and diff_path.exists():
            attachments.append((diff_path, "diff.txt"))

        if not attachments:
            return artifacts

        zip_path = workdir / "codernetes_artifacts.zip"
        with ZipFile(zip_path, "w", compression=ZIP_DEFLATED) as zip_file:
            for source, arcname in attachments:
                zip_file.write(source, arcname)

        if zip_path.exists():
            artifacts.append(
                {
                    "path": str(zip_path),
                    "size": zip_path.stat().st_size,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "contents": [arcname for _, arcname in attachments],
                }
            )
    except Exception as exc:  # noqa: BLE001
        LOGGER.warning("아티팩트 패키징 실패(%s): %s", workdir, exc)
    return artifacts


async def _capture_command(cmd: list[str], *, cwd: Path) -> str:
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=str(cwd),
    )
    stdout, stderr = await proc.communicate()
    combined = b"".join([stdout or b"", stderr or b""])
    return combined.decode(errors="replace").strip()


async def _collect_diff_summary(workdir: Path, repositories: list[dict[str, object]], context: NodeContext) -> str:
    summary_lines: list[str] = []
    diff_lines: list[str] = []
    for repo_spec in repositories:
        if not isinstance(repo_spec, dict):
            continue
        url = str(repo_spec.get("url", ""))
        if not url:
            continue
        repo_name = _derive_repo_name(url)
        repo_dir = workdir / repo_name
        if not repo_dir.exists():
            continue
        status_output = await _capture_command(["git", "status", "-sb"], cwd=repo_dir)
        diffstat_output = await _capture_command(["git", "diff", "--stat"], cwd=repo_dir)
        summary_lines.append(f"{repo_name}: {status_output or 'no changes'}")
        if diffstat_output:
            diff_lines.append(f"## {repo_name}\n{diffstat_output}\n")
        else:
            diff_lines.append(f"## {repo_name}\n(no diff)\n")

    summary_text = "\n".join(summary_lines) if summary_lines else "변경 사항이 감지되지 않았습니다."
    if diff_lines:
        diff_path = workdir / "diff.txt"
        diff_path.write_text("\n".join(diff_lines), encoding="utf-8")
        context.diff_path = diff_path
    context.diff_summary = summary_text
    return summary_text


async def _run_verification_commands(
    websocket,
    context: NodeContext,
    job_id: str,
    commands: list[str],
    workdir: Path,
) -> tuple[bool, str]:
    if not commands:
        return True, "검증 명령이 정의되지 않았습니다."
    for raw_command in commands:
        cmd = shlex.split(raw_command)
        await _send_job_log(websocket, job_id, f"검증 명령 실행: {raw_command}", context=context)
        success = await _run_command(websocket, job_id, cmd, cwd=workdir, context=context)
        if not success:
            return False, f"검증 명령 실패: {raw_command}"
    return True, "모든 검증 명령이 성공했습니다."


async def _upload_artifacts(context: NodeContext, job_id: str, artifacts: list[dict[str, Any]]) -> list[dict[str, Any]]:
    host = context.master_http_host
    port = context.master_http_port
    if not artifacts or not host or port is None:
        return artifacts

    base_url = f"http://{host}:{port}/api/jobs/{job_id}/artifacts"
    uploaded: list[dict[str, Any]] = []
    async with aiohttp.ClientSession() as session:
        for artifact in artifacts:
            path_value = artifact.get("path")
            if not isinstance(path_value, str):
                continue
            file_path = Path(path_value)
            if not file_path.exists():
                continue
            metadata = {
                "contents": artifact.get("contents", []),
                "source": "node",
            }
            form = aiohttp.FormData()
            form.add_field(
                "file",
                file_path.open("rb"),
                filename=file_path.name,
                content_type="application/zip",
            )
            form.add_field("metadata", json.dumps(metadata), content_type="application/json")
            try:
                async with session.post(base_url, data=form) as response:
                    if response.status == 200:
                        data = await response.json()
                        uploaded_artifact = data.get("artifact")
                        if isinstance(uploaded_artifact, dict):
                            uploaded.append(uploaded_artifact)
                        else:
                            uploaded.append(artifact)
                    else:
                        error_text = await response.text()
                        LOGGER.warning("아티팩트 업로드 실패(%s): %s", file_path, error_text)
                        uploaded.append(artifact)
            except Exception as exc:  # noqa: BLE001
                LOGGER.warning("아티팩트 업로드 예외(%s): %s", file_path, exc)
                uploaded.append(artifact)
    return uploaded


async def _sender(websocket) -> None:
    loop = asyncio.get_running_loop()
    while True:
        try:
            user_input = await loop.run_in_executor(None, input, "> ")
        except (EOFError, KeyboardInterrupt):
            print("입력을 종료합니다.")
            await websocket.close(code=1000, reason="Client exit")
            break

        trimmed = user_input.strip()
        if not trimmed:
            continue

        await websocket.send(trimmed)


async def _run_client(
    host: str,
    port: int,
    *,
    display_name: str | None,
    tags: list[str],
    workdir_root: Path,
    codernetes_command: list[str],
    github_token: str | None,
    preserve_workdir: bool,
    cleanup_delay: float,
    capabilities: dict[str, Any],
    resources: dict[str, Any],
    user_id: str | None = None,
    auth_token: str | None = None,
    machine_name: str | None = None,
    max_concurrent_jobs: int = 5,
    credentials: dict[str, dict[str, Any]] | None = None,
    http_port: int | None = None,
    node_password: str | None = None,
) -> None:
    uri = f"ws://{host}:{port}"
    LOGGER.info("Connecting to %s", uri)
    workdir_root.mkdir(parents=True, exist_ok=True)
    context = NodeContext(
        display_name=display_name,
        tags=tags,
        workdir_root=workdir_root,
        codernetes_command=codernetes_command,
        github_token=github_token,
        preserve_workdir=preserve_workdir,
        cleanup_delay=cleanup_delay,
        capabilities=capabilities,
        resources=resources,
        master_http_host=None,
        master_http_port=None,
        user_id=user_id,
        auth_token=auth_token,
        machine_name=machine_name,
        max_concurrent_jobs=max_concurrent_jobs,
        credentials=credentials or {},
        http_port=http_port,
        node_password=node_password,
    )

    if context.codernetes_command:
        LOGGER.info("Configured fallback command: %s", " ".join(context.codernetes_command))
    else:
        LOGGER.info(
            "Fallback 명령이 설정되지 않았습니다. CLI 에이전트가 없으면 작업이 실패합니다 (CLAUDE_CODE_PATH 또는 CODERNETES_COMMAND 설정 필요)."
        )

    # Initialize and start workspace cleanup manager
    from node.cleanup import WorkspaceCleanup
    cleanup_mgr = WorkspaceCleanup(
        workdir_root=workdir_root,
        max_age_hours=48,  # 48시간 이상 된 디렉토리 정리
        max_size_gb=10.0,  # 전체 10GB 초과 시 오래된 것부터 정리
        cleanup_interval_hours=1.0,  # 1시간마다 정리 실행
    )
    await cleanup_mgr.start()

    # Initialize credential store and load credentials from context
    from node.credential_store import CredentialStore
    from node.api_server import NodeApiHandler
    from aiohttp import web as aiohttp_web

    credential_store = CredentialStore()
    credential_store.load_from_dict(context.credentials)

    if credential_store.list_providers():
        LOGGER.info("Initialized credential store with: %s", ", ".join(credential_store.list_providers()))

    # Start node HTTP API server if credentials are available
    api_server = None
    api_runner = None
    if credential_store.list_providers() and context.http_port:
        try:
            api_handler = NodeApiHandler(credential_store, node_password=context.node_password)
            api_app = aiohttp_web.Application()
            api_app.add_routes(api_handler.routes())

            api_runner = aiohttp_web.AppRunner(api_app)
            await api_runner.setup()

            api_site = aiohttp_web.TCPSite(api_runner, "0.0.0.0", context.http_port)
            await api_site.start()

            LOGGER.info("Node HTTP API server started on port %d", context.http_port)
        except Exception as exc:  # noqa: BLE001
            LOGGER.warning("Failed to start node HTTP API server: %s", exc)

    try:
        async with websockets.connect(uri) as websocket:
            receiver = asyncio.create_task(_receiver(websocket, context))
            sender = asyncio.create_task(_sender(websocket))
            done, pending = await asyncio.wait(
                {receiver, sender}, return_when=asyncio.FIRST_COMPLETED
            )

            for task in pending:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task

            for task in done:
                exc = task.exception()
                if exc:
                    raise exc
    finally:
        # Stop API server if running
        if api_runner:
            await api_runner.cleanup()
            LOGGER.info("Node HTTP API server stopped")

        # Stop cleanup manager when client disconnects
        await cleanup_mgr.stop()


async def _run_with_reconnect(
    host: str,
    port: int,
    *,
    display_name: str | None,
    tags: list[str],
    workdir_root: Path,
    codernetes_command: list[str],
    github_token: str | None,
    preserve_workdir: bool,
    cleanup_delay: float,
    capabilities: dict[str, Any],
    resources: dict[str, Any],
    reconnect_delay: float,
    user_id: str | None = None,
    auth_token: str | None = None,
    machine_name: str | None = None,
    max_concurrent_jobs: int = 5,
    credentials: dict[str, dict[str, Any]] | None = None,
    http_port: int | None = None,
    node_password: str | None = None,
) -> None:
    while True:
        try:
            await _run_client(
                host,
                port,
                display_name=display_name,
                tags=tags,
                workdir_root=workdir_root,
                codernetes_command=codernetes_command,
                github_token=github_token,
                preserve_workdir=preserve_workdir,
                cleanup_delay=cleanup_delay,
                capabilities=capabilities,
                resources=resources,
                user_id=user_id,
                auth_token=auth_token,
                machine_name=machine_name,
                max_concurrent_jobs=max_concurrent_jobs,
                credentials=credentials,
                http_port=http_port,
                node_password=node_password,
            )
        except KeyboardInterrupt:
            raise
        except Exception as exc:  # noqa: BLE001
            LOGGER.warning("마스터 연결이 끊어졌습니다: %s", exc)
        LOGGER.info("%s초 후 재연결을 시도합니다.", reconnect_delay)
        await asyncio.sleep(max(1.0, reconnect_delay))


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Codernetes 노드 클라이언트")
    parser.add_argument("--host", default="127.0.0.1", help="마스터 호스트")
    parser.add_argument("--port", type=int, default=8765, help="마스터 포트")
    parser.add_argument("--verbose", action="store_true", help="디버그 로그 출력")
    parser.add_argument("--name", "--display-name", dest="display_name", default=None, help="노드 표시 이름 (예: 'dev-machine', 'production-1')")
    parser.add_argument(
        "--tags",
        default="",
        help="노드 태그 목록(콤마 구분)",
    )
    parser.add_argument(
        "--workdir-root",
        default="/tmp/codernetes-jobs",
        help="작업 디렉터리 루트 경로",
    )
    parser.add_argument(
        "--codernetes-command",
        dest="codernetes_command",
        default=None,
        help="Codernetes 실행 명령 (예: 'python -m codernetes run'). 미지정 시 CODERNETES_COMMAND 환경변수를 사용합니다.",
    )
    parser.add_argument(
        "--github-token",
        default=None,
        help="GitHub 토큰 값 (환경 변수 사용 권장)",
    )
    parser.add_argument(
        "--github-token-file",
        default=None,
        help="GitHub 토큰이 저장된 파일 경로",
    )
    parser.add_argument(
        "--preserve-workdir",
        action="store_true",
        help="작업 완료 후 디렉터리를 삭제하지 않습니다.",
    )
    parser.add_argument(
        "--cleanup-delay",
        type=float,
        default=0.0,
        help="작업 완료 후 디렉터리 삭제까지 지연할 시간(초). preserve-workdir 사용 시 무시",
    )
    parser.add_argument(
        "--capabilities",
        default="",
        help="노드 기능/환경 정보를 key=value 형태로 지정 (예: python=3.11,docker=true)",
    )
    parser.add_argument(
        "--resources",
        default="",
        help="노드 리소스 스펙을 key=value 형태로 지정 (예: cpu=8,ram_gb=16)",
    )
    parser.add_argument(
        "--reconnect-delay",
        type=float,
        default=float(os.getenv("CODERNETES_NODE_RECONNECT", "5")),
        help="재연결 대기 시간(초)",
    )
    parser.add_argument(
        "--http-port",
        type=int,
        default=8766,
        help="Node HTTP API server port for credential delegation (default: 8766)",
    )
    parser.add_argument(
        "--password",
        action="store_true",
        help="Prompt for node password (access control for job execution)",
    )
    parser.add_argument(
        "--no-password",
        action="store_true",
        help="Disable node password protection (allow unrestricted job execution)",
    )
    parser.add_argument(
        "--node-password",
        dest="node_password_arg",
        default=None,
        help="Node password for access control (can also use NODE_PASSWORD env var)",
    )
    parser.add_argument(
        "-f",
        "--config-file",
        dest="config_file",
        default=None,
        help="Path to node configuration YAML file",
    )
    return parser.parse_args(argv)


def _configure_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(level=level, format="[%(asctime)s] %(levelname)s: %(message)s")


def main(argv: Sequence[str] | None = None) -> None:
    # Load environment variables from .env file
    load_dotenv()

    args = parse_args(argv)
    _configure_logging(args.verbose)

    # Load node configuration
    config = NodeConfig()

    # Check if node is configured for authentication
    if not config.is_configured():
        print("=" * 60)
        print("⚠️  Node not configured for authentication")
        print("=" * 60)
        print()
        print("This node requires authentication credentials to connect.")
        print("Please run the setup wizard first:")
        print()
        print("  python -m node.setup")
        print()
        print("=" * 60)
        sys.exit(1)

    try:
        # Tags: prioritize CLI args, then config, then empty list
        if args.tags:
            tag_list = [tag.strip() for tag in str(args.tags).split(",") if tag.strip()]
        else:
            tag_list = config.node_tags

        # GitHub token: prioritize CLI args/file, then config
        github_token = None
        if args.github_token_file:
            try:
                github_token = Path(args.github_token_file).read_text(encoding="utf-8").strip()
            except OSError as exc:
                LOGGER.error("GitHub 토큰 파일을 읽을 수 없습니다: %s", exc)
        if not github_token and args.github_token:
            github_token = args.github_token.strip()
        if not github_token and config.github_token:
            github_token = config.github_token

        command_source = args.codernetes_command or os.getenv("CODERNETES_COMMAND", "").strip()
        codernetes_command = shlex.split(command_source) if command_source else []
        if not codernetes_command:
            LOGGER.warning(
                "Codernetes 기본 명령이 설정되지 않았습니다. CLI 에이전트가 없을 경우 작업이 실패할 수 있습니다."
            )
        base_capabilities: dict[str, Any] = {
            "python_version": platform.python_version(),
            "platform": platform.platform(),
        }
        base_resources: dict[str, Any] = {
            "cpu_count": os.cpu_count() or 0,
        }

        # Load capabilities from node-config.yaml if NODE_CONFIG_FILE is set
        config_file_capabilities: dict[str, Any] = {}
        config_file_resources: dict[str, Any] = {}
        config_file_credentials: dict[str, dict[str, Any]] = {}
        node_config_file = os.getenv("NODE_CONFIG_FILE")
        if node_config_file and Path(node_config_file).exists():
            try:
                import yaml
                import re

                with open(node_config_file, "r") as f:
                    node_yaml = yaml.safe_load(f)

                if node_yaml:
                    # Substitute environment variables in the loaded YAML
                    def substitute_env_vars(data: Any) -> Any:
                        """Recursively substitute ${VAR_NAME} with environment variables."""
                        if isinstance(data, dict):
                            return {k: substitute_env_vars(v) for k, v in data.items()}
                        elif isinstance(data, list):
                            return [substitute_env_vars(item) for item in data]
                        elif isinstance(data, str):
                            # Pattern: ${VAR_NAME} or ${VAR_NAME:-default}
                            pattern = r"\$\{([^}:]+)(?::-(.*?))?\}"
                            def replace_var(match):
                                var_name = match.group(1)
                                default_value = match.group(2) if match.group(2) is not None else ""
                                value = os.getenv(var_name)
                                if value is None:
                                    return default_value if default_value else match.group(0)
                                return value
                            return re.sub(pattern, replace_var, data)
                        return data

                    node_yaml = substitute_env_vars(node_yaml)
                    config_file_capabilities = node_yaml.get("capabilities", {})
                    config_file_resources = node_yaml.get("resources", {})

                    # Extract max_concurrent_jobs from config file
                    max_concurrent_jobs_from_config = node_yaml.get("max_concurrent_jobs", 5)

                    # Extract node_password from config file
                    node_password_from_config = node_yaml.get("node_password")
                    if node_password_from_config and node_password_from_config.strip() and not node_password_from_config.startswith("${"):
                        node_password_from_config = node_password_from_config.strip()
                    else:
                        node_password_from_config = None

                    # Extract authentication fields from config file (override NodeConfig)
                    config_user_id = node_yaml.get("user_id")
                    if config_user_id and config_user_id.strip() and not config_user_id.startswith("${"):
                        config.user_id = config_user_id.strip()
                        LOGGER.info("Using user_id from config file: %s", config.user_id)

                    config_auth_token = node_yaml.get("auth_token")
                    if config_auth_token and config_auth_token.strip() and not config_auth_token.startswith("${"):
                        config.auth_token = config_auth_token.strip()
                        LOGGER.info("Using auth_token from config file")

                    config_machine_name = node_yaml.get("machine_name")
                    if config_machine_name and config_machine_name.strip() and not config_machine_name.startswith("${"):
                        config.machine_name = config_machine_name.strip()
                        LOGGER.info("Using machine_name from config file: %s", config.machine_name)

                    # Extract display_name from config file
                    config_display_name = node_yaml.get("display_name")
                    if config_display_name and config_display_name.strip() and not config_display_name.startswith("${"):
                        display_name_from_config = config_display_name.strip()
                    else:
                        display_name_from_config = None

                    # Extract credentials from capabilities
                    for provider in ["github", "linear"]:
                        provider_config = config_file_capabilities.get(provider, {})
                        if isinstance(provider_config, dict):
                            token = provider_config.get("token")
                            # Only add if token exists and is not an empty/unresolved env var
                            if token and token.strip() and not token.startswith("${"):
                                config_file_credentials[provider] = {"access_token": token}

                    LOGGER.info("Loaded capabilities from: %s", node_config_file)
                    if config_file_credentials:
                        LOGGER.info("Loaded credentials for: %s", ", ".join(config_file_credentials.keys()))
            except Exception as exc:
                LOGGER.warning("Failed to load node config file %s: %s", node_config_file, exc)
                max_concurrent_jobs_from_config = 5  # Default if config load fails
                node_password_from_config = None
                display_name_from_config = None
        else:
            max_concurrent_jobs_from_config = 5  # Default if no config file
            node_password_from_config = None
            display_name_from_config = None

        capabilities = {**base_capabilities, **config_file_capabilities, **_parse_key_value_pairs(args.capabilities)}
        resources = {**base_resources, **config_file_resources, **_parse_key_value_pairs(args.resources)}

        # Extract master URL from config (override with CLI if provided differently)
        config_master_url = config.master_url or ""
        if config_master_url and not (args.host != "127.0.0.1" or args.port != 8765):
            # Use config master URL if CLI args are default
            from urllib.parse import urlparse
            parsed = urlparse(config_master_url if config_master_url.startswith("http") else f"http://{config_master_url}")
            master_host = parsed.hostname or args.host
            master_port = parsed.port or args.port
        else:
            master_host = args.host
            master_port = args.port

        reconnect_delay = max(1.0, float(args.reconnect_delay))

        # Merge credentials: config_file_credentials takes priority over config.credentials
        merged_credentials = {**config.credentials, **config_file_credentials}

        # Add API capability flags based on available credentials
        if "github" in merged_credentials:
            capabilities["github_api"] = True
        if "linear" in merged_credentials:
            capabilities["linear_api"] = True

        # Handle display_name priority: CLI > env var > config file
        display_name = None
        if args.display_name:
            # CLI argument has highest priority
            display_name = args.display_name.strip()
        elif os.getenv("NODE_DISPLAY_NAME"):
            # Environment variable has middle priority
            display_name = os.getenv("NODE_DISPLAY_NAME", "").strip()
        elif display_name_from_config:
            # Config file has lowest priority
            display_name = display_name_from_config

        # Handle node password (access control) with three-tier priority
        node_password = None
        if args.no_password:
            # Explicitly disable password protection
            node_password = None
            LOGGER.info("Password protection disabled via --no-password")
        elif args.password:
            # Prompt for password interactively
            import getpass
            node_password = getpass.getpass("Enter node password (for access control): ").strip()
            if not node_password:
                LOGGER.warning("Empty password provided, disabling password protection")
                node_password = None
            else:
                LOGGER.info("Password set via interactive prompt")
        elif args.node_password_arg:
            # CLI argument has highest priority (after --password prompt)
            node_password = args.node_password_arg.strip()
            LOGGER.info(f"Password set via --node-password argument (length={len(node_password)})")
        elif os.getenv("NODE_PASSWORD"):
            # Environment variable has second priority
            node_password = os.getenv("NODE_PASSWORD", "").strip()
            LOGGER.info(f"Password set via NODE_PASSWORD env var (length={len(node_password)})")
        elif node_password_from_config:
            # Config file has lowest priority
            node_password = node_password_from_config
            LOGGER.info(f"Password set via config file (length={len(node_password)})")
        else:
            LOGGER.info("No password protection configured")
        # else: node_password remains None (no protection)

        print("=" * 60)
        print("🚀 Starting Codernetes Node")
        print("=" * 60)
        print(f"User: {config.user_id}")
        print(f"Machine: {config.machine_name}")
        if display_name:
            print(f"Display Name: {display_name}")
        print(f"Master: {master_host}:{master_port}")
        print(f"Tags: {', '.join(tag_list) if tag_list else '(none)'}")
        if node_password:
            print("🔒 Access Control: Password protected")
            LOGGER.debug(f"node_password value: {node_password[:3]}***")
        else:
            print("⚠️  Access Control: No password (unrestricted)")
        if merged_credentials:
            print(f"Credentials: {', '.join(merged_credentials.keys())}")
            print(f"HTTP API: 0.0.0.0:{args.http_port}")
        print("=" * 60)
        print()

        asyncio.run(
            _run_with_reconnect(
                master_host,
                master_port,
                display_name=display_name,
                tags=tag_list,
                workdir_root=Path(args.workdir_root).expanduser(),
                codernetes_command=codernetes_command,
                github_token=github_token,
                preserve_workdir=bool(args.preserve_workdir),
                cleanup_delay=max(0.0, float(args.cleanup_delay)),
                capabilities=capabilities,
                resources=resources,
                reconnect_delay=reconnect_delay,
                user_id=config.user_id,
                auth_token=config.auth_token,
                machine_name=config.machine_name,
                max_concurrent_jobs=max_concurrent_jobs_from_config,
                credentials=merged_credentials,
                http_port=args.http_port,
                node_password=node_password,
            )
        )
    except KeyboardInterrupt:
        LOGGER.info("클라이언트 종료")


if __name__ == "__main__":
    main(sys.argv[1:])

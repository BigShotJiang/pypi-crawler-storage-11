"""
Agent 설정 파서 모듈

.codernetes/agent.md 파일을 파싱하여 레포지토리별 정책을 로드합니다.
"""

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class TestingPolicy:
    """테스트 정책"""

    required: bool = False
    command: Optional[str] = None
    coverage_threshold: Optional[int] = None
    pre_commit: bool = False


@dataclass
class CodeStyle:
    """코드 스타일 설정"""

    linter: Optional[str] = None
    formatter: Optional[str] = None
    max_line_length: int = 100
    auto_format: bool = True


@dataclass
class AgentConfig:
    """Agent 설정"""

    # 기본 설정
    agent_type: str = "claude-code"
    auto_commit: bool = True
    commit_message_template: str = "Fix: {issue_title}"

    # 코드 스타일
    code_style: CodeStyle = field(default_factory=CodeStyle)

    # 테스트 정책
    testing: TestingPolicy = field(default_factory=TestingPolicy)

    # 보호된 파일/디렉토리
    protected_paths: list[str] = field(default_factory=list)

    # 제외할 파일/디렉토리
    exclude_paths: list[str] = field(default_factory=list)

    # 추가 프롬프트
    system_prompt: Optional[str] = None

    @classmethod
    def from_file(cls, config_path: str | Path) -> "AgentConfig":
        """파일에서 설정 로드

        Args:
            config_path: .codernetes/agent.md 파일 경로

        Returns:
            AgentConfig 인스턴스

        Raises:
            FileNotFoundError: 파일이 없는 경우
        """
        config_path = Path(config_path)

        if not config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")

        logger.info(f"Loading agent config from: {config_path}")

        with open(config_path, "r", encoding="utf-8") as f:
            content = f.read()

        return cls._parse_markdown(content)

    @classmethod
    def from_directory(cls, repo_dir: str | Path) -> Optional["AgentConfig"]:
        """레포지토리 디렉토리에서 설정 로드

        Args:
            repo_dir: 레포지토리 루트 디렉토리

        Returns:
            AgentConfig 인스턴스 또는 None (설정 파일이 없는 경우)
        """
        config_path = Path(repo_dir) / ".codernetes" / "agent.md"

        if not config_path.exists():
            logger.info(f"No agent config found in: {repo_dir}, using defaults")
            return cls()  # 기본 설정 반환

        return cls.from_file(config_path)

    @classmethod
    def _parse_markdown(cls, content: str) -> "AgentConfig":
        """Markdown 형식의 설정 파일 파싱

        지원하는 섹션:
        - ## Agent Configuration
        - ## Code Style
        - ## Testing Policy
        - ## Protected Files
        - ## Exclude Paths
        - ## System Prompt

        Args:
            content: Markdown 파일 내용

        Returns:
            AgentConfig 인스턴스
        """
        config = cls()

        # 섹션별로 파싱
        sections = cls._split_sections(content)

        # Agent Configuration 섹션
        if "agent configuration" in sections:
            config._parse_agent_section(sections["agent configuration"])

        # Code Style 섹션
        if "code style" in sections:
            config._parse_code_style(sections["code style"])

        # Testing Policy 섹션
        if "testing policy" in sections:
            config._parse_testing_policy(sections["testing policy"])

        # Protected Files 섹션
        if "protected files" in sections:
            config.protected_paths = cls._parse_list(sections["protected files"])

        # Exclude Paths 섹션
        if "exclude paths" in sections:
            config.exclude_paths = cls._parse_list(sections["exclude paths"])

        # System Prompt 섹션
        if "system prompt" in sections:
            config.system_prompt = sections["system prompt"].strip()

        return config

    @staticmethod
    def _split_sections(content: str) -> dict[str, str]:
        """Markdown을 섹션별로 분리

        Args:
            content: Markdown 파일 내용

        Returns:
            섹션 이름 -> 섹션 내용 매핑
        """
        sections = {}
        current_section = None
        current_content = []

        for line in content.split("\n"):
            # ## 헤더 감지
            if line.startswith("##"):
                # 이전 섹션 저장
                if current_section:
                    sections[current_section] = "\n".join(current_content)

                # 새 섹션 시작
                current_section = line.lstrip("#").strip().lower()
                current_content = []
            elif current_section:
                current_content.append(line)

        # 마지막 섹션 저장
        if current_section:
            sections[current_section] = "\n".join(current_content)

        return sections

    def _parse_agent_section(self, content: str) -> None:
        """Agent Configuration 섹션 파싱"""
        # agent_type 파싱
        agent_type_match = re.search(r"agent[_\s]type:\s*([^\n]+)", content, re.IGNORECASE)
        if agent_type_match:
            self.agent_type = agent_type_match.group(1).strip()

        # auto_commit 파싱
        auto_commit_match = re.search(r"auto[_\s]commit:\s*(true|false|yes|no)", content, re.IGNORECASE)
        if auto_commit_match:
            self.auto_commit = auto_commit_match.group(1).lower() in ["true", "yes"]

        # commit_message_template 파싱
        commit_msg_match = re.search(r"commit[_\s]message:\s*[`\"']([^`\"']+)[`\"']", content, re.IGNORECASE)
        if commit_msg_match:
            self.commit_message_template = commit_msg_match.group(1).strip()

    def _parse_code_style(self, content: str) -> None:
        """Code Style 섹션 파싱"""
        # linter 파싱
        linter_match = re.search(r"linter:\s*([^\n]+)", content, re.IGNORECASE)
        if linter_match:
            self.code_style.linter = linter_match.group(1).strip()

        # formatter 파싱
        formatter_match = re.search(r"formatter:\s*([^\n]+)", content, re.IGNORECASE)
        if formatter_match:
            self.code_style.formatter = formatter_match.group(1).strip()

        # max_line_length 파싱
        max_line_match = re.search(r"max[_\s]line[_\s]length:\s*(\d+)", content, re.IGNORECASE)
        if max_line_match:
            self.code_style.max_line_length = int(max_line_match.group(1))

        # auto_format 파싱
        auto_format_match = re.search(r"auto[_\s]format:\s*(true|false|yes|no)", content, re.IGNORECASE)
        if auto_format_match:
            self.code_style.auto_format = auto_format_match.group(1).lower() in ["true", "yes"]

    def _parse_testing_policy(self, content: str) -> None:
        """Testing Policy 섹션 파싱"""
        # required 파싱
        required_match = re.search(r"required:\s*(true|false|yes|no)", content, re.IGNORECASE)
        if required_match:
            self.testing.required = required_match.group(1).lower() in ["true", "yes"]

        # command 파싱
        command_match = re.search(r"command:\s*[`\"']([^`\"']+)[`\"']", content, re.IGNORECASE)
        if command_match:
            self.testing.command = command_match.group(1).strip()

        # coverage_threshold 파싱
        coverage_match = re.search(r"coverage[_\s]threshold:\s*(\d+)", content, re.IGNORECASE)
        if coverage_match:
            self.testing.coverage_threshold = int(coverage_match.group(1))

        # pre_commit 파싱
        pre_commit_match = re.search(r"pre[_\s]commit:\s*(true|false|yes|no)", content, re.IGNORECASE)
        if pre_commit_match:
            self.testing.pre_commit = pre_commit_match.group(1).lower() in ["true", "yes"]

    @staticmethod
    def _parse_list(content: str) -> list[str]:
        """리스트 형식 파싱

        지원 형식:
        - item1
        - item2
        또는
        * item1
        * item2

        Args:
            content: 섹션 내용

        Returns:
            파싱된 리스트
        """
        items = []
        for line in content.split("\n"):
            line = line.strip()
            # - 또는 * 로 시작하는 라인
            if line.startswith(("-", "*")):
                item = line.lstrip("-*").strip()
                if item:
                    items.append(item)
        return items

    def get_commit_message(self, issue_title: str, issue_number: Optional[int] = None) -> str:
        """커밋 메시지 생성

        Args:
            issue_title: 이슈 제목
            issue_number: 이슈 번호 (선택)

        Returns:
            포맷된 커밋 메시지
        """
        message = self.commit_message_template.format(
            issue_title=issue_title, issue_number=issue_number or ""
        )
        return message

    def is_path_protected(self, file_path: str) -> bool:
        """파일이 보호된 경로에 있는지 확인

        Args:
            file_path: 파일 경로

        Returns:
            보호된 파일이면 True
        """
        for pattern in self.protected_paths:
            if re.match(pattern, file_path):
                return True
        return False

    def is_path_excluded(self, file_path: str) -> bool:
        """파일이 제외된 경로에 있는지 확인

        Args:
            file_path: 파일 경로

        Returns:
            제외된 파일이면 True
        """
        for pattern in self.exclude_paths:
            if re.match(pattern, file_path):
                return True
        return False

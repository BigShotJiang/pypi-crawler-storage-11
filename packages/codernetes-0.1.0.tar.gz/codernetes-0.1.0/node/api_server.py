"""HTTP API server for node to serve delegated API requests."""

from __future__ import annotations

import logging
from typing import Any

from aiohttp import web

from .credential_store import CredentialStore
from .github_client import get_github_client_from_store
from .linear_client import get_linear_client_from_store

LOGGER = logging.getLogger(__name__)


class NodeApiHandler:
    """HTTP API handler for node-delegated requests."""

    def __init__(self, credential_store: CredentialStore, node_password: str | None = None):
        """
        Initialize node API handler.

        Args:
            credential_store: Credential store instance
            node_password: Optional password for node access control
        """
        self._cred_store = credential_store
        self._node_password = node_password

    def _verify_password(self, request: web.Request) -> None:
        """
        Verify node password from request.
        
        Args:
            request: HTTP request
            
        Raises:
            web.HTTPUnauthorized: If password is required but not provided or incorrect
        """
        if not self._node_password:
            # No password protection
            return
        
        # Check for password in Authorization header (Bearer token)
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            provided_password = auth_header[7:]  # Remove "Bearer " prefix
        else:
            # Fallback to query parameter
            provided_password = request.query.get("password", "")
        
        if not provided_password:
            raise web.HTTPUnauthorized(text="Node password required")
        
        if provided_password != self._node_password:
            raise web.HTTPUnauthorized(text="Invalid node password")

    def routes(self) -> tuple:
        """
        Define HTTP routes for node API.

        Returns:
            Tuple of route definitions
        """
        return (
            # GitHub API routes
            web.get("/api/github/repos", self.list_github_repos),
            web.get("/api/github/issues", self.list_github_issues),
            web.get("/api/github/repos/{owner}/{repo}/issues/{issue_number}", self.get_github_issue),
            web.get("/api/github/repos/{owner}/{repo}/branches", self.list_github_branches),
            # Linear API routes
            web.get("/api/linear/teams", self.list_linear_teams),
            web.get("/api/linear/issues/search", self.search_linear_issues),
            web.get("/api/linear/issues", self.list_linear_issues),
            web.get("/api/linear/issues/{issue_id}", self.get_linear_issue),
            # Health check
            web.get("/health", self.health_check),
        )

    async def health_check(self, request: web.Request) -> web.Response:
        """Health check endpoint."""
        return web.json_response({
            "status": "ok",
            "capabilities": {
                "github_api": self._cred_store.has_token("github"),
                "linear_api": self._cred_store.has_token("linear"),
            },
        })

    # ===== GitHub API Handlers =====

    async def list_github_repos(self, request: web.Request) -> web.Response:
        """List GitHub repositories."""
        self._verify_password(request)
        
        org = request.query.get("org")
        user = request.query.get("user")

        try:
            client = get_github_client_from_store(self._cred_store)
            repos = client.list_repos(org=org, user=user, limit=100)

            repos_data = [
                {
                    "name": repo.name,
                    "full_name": repo.full_name,
                    "owner": repo.owner,
                    "url": repo.url,
                    "default_branch": repo.default_branch,
                    "description": repo.description,
                    "private": repo.private,
                }
                for repo in repos
            ]
            return web.json_response({"repos": repos_data})

        except ValueError as e:
            raise web.HTTPUnauthorized(text=str(e)) from None
        except Exception as e:  # noqa: BLE001
            LOGGER.error("Failed to fetch repositories: %s", e)
            raise web.HTTPInternalServerError(text=f"Failed to fetch repositories: {e}") from None

    async def list_github_issues(self, request: web.Request) -> web.Response:
        """List GitHub issues for a repository."""
        self._verify_password(request)
        
        owner = request.query.get("owner")
        repo = request.query.get("repo")
        state = request.query.get("state", "open")
        labels_str = request.query.get("labels")

        if not owner or not repo:
            raise web.HTTPBadRequest(text="owner and repo query parameters required")

        try:
            client = get_github_client_from_store(self._cred_store)
            labels = [label.strip() for label in labels_str.split(",")] if labels_str else None
            issues = client.list_issues(owner=owner, repo=repo, state=state, labels=labels, limit=100)

            issues_data = [
                {
                    "number": issue.number,
                    "title": issue.title,
                    "body": issue.body,
                    "state": issue.state,
                    "labels": issue.labels,
                    "url": issue.url,
                    "repository": issue.repository,
                    "created_at": issue.created_at,
                    "updated_at": issue.updated_at,
                }
                for issue in issues
            ]
            return web.json_response({"issues": issues_data})

        except ValueError as e:
            raise web.HTTPUnauthorized(text=str(e)) from None
        except Exception as e:  # noqa: BLE001
            LOGGER.error("Failed to fetch issues: %s", e)
            raise web.HTTPInternalServerError(text=f"Failed to fetch issues: {e}") from None

    async def get_github_issue(self, request: web.Request) -> web.Response:
        """Get a specific GitHub issue."""
        self._verify_password(request)
        
        owner = request.match_info["owner"]
        repo = request.match_info["repo"]
        issue_number_str = request.match_info["issue_number"]

        try:
            issue_number = int(issue_number_str)
        except ValueError as exc:
            raise web.HTTPBadRequest(text="issue_number must be an integer") from exc

        try:
            client = get_github_client_from_store(self._cred_store)
            issue = client.get_issue(owner=owner, repo=repo, issue_number=issue_number)

            issue_data = {
                "number": issue.number,
                "title": issue.title,
                "body": issue.body,
                "state": issue.state,
                "labels": issue.labels,
                "url": issue.url,
                "repository": issue.repository,
                "created_at": issue.created_at,
                "updated_at": issue.updated_at,
            }
            return web.json_response({"issue": issue_data})

        except ValueError as e:
            raise web.HTTPUnauthorized(text=str(e)) from None
        except Exception as e:  # noqa: BLE001
            LOGGER.error("Failed to fetch issue: %s", e)
            raise web.HTTPInternalServerError(text=f"Failed to fetch issue: {e}") from None

    async def list_github_branches(self, request: web.Request) -> web.Response:
        """List branches for a GitHub repository."""
        self._verify_password(request)
        
        owner = request.match_info["owner"]
        repo = request.match_info["repo"]

        try:
            client = get_github_client_from_store(self._cred_store)
            branches = client.list_branches(owner=owner, repo=repo, limit=100)

            branches_data = [
                {
                    "name": branch.name,
                    "commit": branch.commit,
                }
                for branch in branches
            ]
            return web.json_response({"branches": branches_data})

        except ValueError as e:
            raise web.HTTPUnauthorized(text=str(e)) from None
        except Exception as e:  # noqa: BLE001
            LOGGER.error("Failed to fetch branches: %s", e)
            raise web.HTTPInternalServerError(text=f"Failed to fetch branches: {e}") from None

    # ===== Linear API Handlers =====

    async def list_linear_teams(self, request: web.Request) -> web.Response:
        """List Linear teams."""
        self._verify_password(request)
        
        try:
            client = get_linear_client_from_store(self._cred_store)
            teams = await client.list_teams()

            return web.json_response({"teams": teams})

        except ValueError as e:
            raise web.HTTPUnauthorized(text=str(e)) from None
        except Exception as e:  # noqa: BLE001
            LOGGER.error("Failed to fetch teams: %s", e)
            raise web.HTTPInternalServerError(text=f"Failed to fetch teams: {e}") from None

    async def search_linear_issues(self, request: web.Request) -> web.Response:
        """Search Linear issues."""
        self._verify_password(request)
        
        query = request.query.get("query", "")
        team_id = request.query.get("team_id")

        try:
            client = get_linear_client_from_store(self._cred_store)
            issues = await client.search_issues(query=query, team_id=team_id, limit=50)

            return web.json_response({"issues": issues})

        except ValueError as e:
            raise web.HTTPUnauthorized(text=str(e)) from None
        except Exception as e:  # noqa: BLE001
            LOGGER.error("Failed to search issues: %s", e)
            raise web.HTTPInternalServerError(text=f"Failed to search issues: {e}") from None

    async def list_linear_issues(self, request: web.Request) -> web.Response:
        """List Linear issues."""
        self._verify_password(request)

        team_id = request.query.get("team_id")
        state = request.query.get("state")

        try:
            client = get_linear_client_from_store(self._cred_store)
            # Use get_issues instead of list_issues
            team_ids = [team_id] if team_id else None
            issues = await client.get_issues(team_ids=team_ids, limit=50, include_completed=(state == "all"))

            return web.json_response({"issues": issues})

        except ValueError as e:
            raise web.HTTPUnauthorized(text=str(e)) from None
        except Exception as e:  # noqa: BLE001
            LOGGER.error("Failed to fetch issues: %s", e)
            raise web.HTTPInternalServerError(text=f"Failed to fetch issues: {e}") from None

    async def get_linear_issue(self, request: web.Request) -> web.Response:
        """Get a specific Linear issue."""
        self._verify_password(request)
        
        issue_id = request.match_info["issue_id"]

        try:
            client = get_linear_client_from_store(self._cred_store)
            issue = await client.get_issue(issue_id)

            return web.json_response({"issue": issue})

        except ValueError as e:
            raise web.HTTPUnauthorized(text=str(e)) from None
        except Exception as e:  # noqa: BLE001
            LOGGER.error("Failed to fetch issue: %s", e)
            raise web.HTTPInternalServerError(text=f"Failed to fetch issue: {e}") from None


async def create_node_api_app(credential_store: CredentialStore) -> web.Application:
    """
    Create node API application.

    Args:
        credential_store: Credential store instance

    Returns:
        Configured aiohttp application
    """
    app = web.Application()
    handler = NodeApiHandler(credential_store)
    app.add_routes(handler.routes())

    LOGGER.info("Node API application created")
    return app

"""
Job 실행 오케스트레이터 모듈

Git 워크플로우, Agent 실행, PR 생성 등 전체 Job 실행을 관리합니다.

Note: For enhanced functionality with context management and workflow phases,
use job_executor_enhanced.py which provides:
- Repository context analysis
- Structured workflow phases
- Session persistence and recovery
- Preset configurations
- Enhanced prompt generation
"""

import asyncio
import logging
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from master.error_handler import get_error_handler, JobError
from master.models import Job, JobStatus
from node.agent_config import AgentConfig
from node.agent_executor import AgentExecutor, AgentResult
from node.git_workflow import GitWorkflow
from node.pr_manager import PRManager

logger = logging.getLogger(__name__)


@dataclass
class JobExecutionResult:
    """Job 실행 결과"""

    success: bool
    job_id: str
    status: JobStatus
    pr_number: Optional[int] = None
    pr_url: Optional[str] = None
    commit_sha: Optional[str] = None
    files_changed: int = 0
    error_message: Optional[str] = None
    error_info: Optional[dict] = None  # Structured error information from error handler
    should_retry: bool = False  # Whether the error is retryable
    retry_after: int = 0  # Suggested retry delay in seconds
    work_dir: Optional[str] = None
    result_summary: Optional[str] = None  # Agent output or summary


class JobExecutor:
    """Job 실행 오케스트레이터"""

    def __init__(
        self,
        jobs_work_dir: Optional[str] = None,
        github_token: Optional[str] = None,
        fallback_command: Optional[list[str]] = None,
    ):
        """
        Args:
            jobs_work_dir: Jobs 작업 디렉토리 (기본값: /tmp/codernetes-jobs)
            github_token: GitHub 토큰
            fallback_command: 우선순위 에이전트 실패 시 사용할 커스텀 명령
        """
        self.jobs_work_dir = Path(jobs_work_dir or os.getenv("JOBS_WORK_DIR", "/tmp/codernetes-jobs"))
        self.jobs_work_dir.mkdir(parents=True, exist_ok=True)

        self.github_token = github_token or os.getenv("GITHUB_TOKEN")
        if not self.github_token:
            logger.warning("GitHub token not provided, PR creation will fail")

        self.pr_manager = PRManager(self.github_token) if self.github_token else None
        self.fallback_command = [arg for arg in (fallback_command or []) if arg]
        if self.fallback_command:
            logger.info("Fallback command registered: %s", " ".join(self.fallback_command))

        logger.info(f"JobExecutor initialized with work_dir: {self.jobs_work_dir}")

    async def execute_job(
        self, job: Job, status_callback: Optional[callable] = None
    ) -> JobExecutionResult:
        """Job 실행

        Args:
            job: 실행할 Job 객체
            status_callback: 상태 업데이트 콜백 함수 (async)

        Returns:
            JobExecutionResult 객체
        """
        logger.info(f"Starting job execution: {job.job_id}")

        # 작업 디렉토리 결정 (job.work_dir이 있으면 사용, 없으면 기본 경로)
        if job.work_dir:
            work_dir = Path(job.work_dir)
            logger.info(f"Using job-specified work directory: {work_dir}")
        else:
            work_dir = self.jobs_work_dir / job.job_id
            logger.info(f"Using default work directory: {work_dir}")
        work_dir.mkdir(parents=True, exist_ok=True)

        git_workflow: Optional[GitWorkflow] = None
        current_phase = "initializing"

        try:
            # 상태: ACCEPTED
            current_phase = "accepted"
            await self._update_status(JobStatus.ACCEPTED, job, status_callback)

            # 1. Git Clone (또는 기존 디렉토리 사용)
            current_phase = "cloning"
            await self._update_status(JobStatus.CLONING, job, status_callback)

            # work_dir이 이미 설정되어 있고 존재하면 clone 건너뛰기
            if job.work_dir and Path(job.work_dir) == work_dir and work_dir.exists() and (work_dir / ".git").exists():
                logger.info(f"Using existing work directory: {work_dir}")
                from node.git_workflow import GitWorkflow
                from git import Repo
                git_workflow = GitWorkflow(work_dir)
                # 기존 repo 초기화
                git_workflow.repo = Repo(work_dir)
            elif not job.repositories or len(job.repositories) == 0:
                # repositories가 없어도 work_dir이 이미 git 저장소면 사용
                if work_dir.exists() and (work_dir / ".git").exists():
                    logger.info(f"No repositories specified, but using existing git directory: {work_dir}")
                    from node.git_workflow import GitWorkflow
                    from git import Repo
                    git_workflow = GitWorkflow(work_dir)
                    # 기존 repo 초기화
                    git_workflow.repo = Repo(work_dir)
                else:
                    raise ValueError("No repository specified and no existing git directory found")
            else:
                git_workflow = await self._clone_repository(job, work_dir)

            # 2. Branch 생성
            current_phase = "creating_branch"
            branch_name = self._generate_branch_name(job)
            await git_workflow.create_branch(branch_name)

            # 3. Agent 설정 로드
            current_phase = "loading_config"
            config = AgentConfig.from_directory(work_dir)
            logger.info(f"Agent config loaded: {config.agent_type}")

            # 4. LLM Agent 실행
            current_phase = "agent_working"
            await self._update_status(JobStatus.AGENT_WORKING, job, status_callback)
            agent_result = await self._execute_agent(job, work_dir, config)

            if not agent_result.success:
                if self.fallback_command:
                    logger.warning(
                        "Primary agent failed (%s). Trying fallback command.",
                        agent_result.error_message,
                    )
                    agent_result = await self._execute_fallback_command(
                        job, work_dir, git_workflow, config
                    )
                if not agent_result.success:
                    raise Exception(
                        f"Agent execution failed: {agent_result.error_message}"
                    )

            # 5. 변경사항 커밋 (변경사항이 있는 경우만)
            current_phase = "committing"
            commit_sha = None
            has_changes = False

            try:
                # Check if there are changes to commit
                files_changed = agent_result.files_changed if hasattr(agent_result, 'files_changed') else []
                if files_changed:
                    await self._update_status(JobStatus.COMMITTING, job, status_callback)
                    commit_sha = await self._commit_changes(job, git_workflow, config)
                    has_changes = True
                else:
                    logger.info("No file changes detected, skipping commit/push/PR steps")
            except ValueError as e:
                if "No changes to commit" in str(e):
                    logger.info("Agent completed but no changes to commit. Skipping commit/push/PR steps.")
                else:
                    raise

            pr_info = None

            # 6. Push (변경사항이 있는 경우만)
            if has_changes and commit_sha:
                current_phase = "pushing"
                await self._update_status(JobStatus.PUSHING, job, status_callback)
                await git_workflow.push(branch_name)

                # 7. PR 생성 (가능한 경우)
                if self.pr_manager and job.repo_owner and job.repo_name:
                    current_phase = "pr_creating"
                    await self._update_status(JobStatus.PR_CREATING, job, status_callback)
                    pr_info = await self._create_pull_request(
                        job, branch_name, agent_result.files_changed, commit_sha
                    )
                    final_status = JobStatus.PR_CREATED
                    logger.info(
                        f"Job {job.job_id} completed successfully. PR: {pr_info['url']}"
                    )
                else:
                    logger.info(
                        "Skipping PR creation (missing GitHub token or repository information)"
                    )
                    final_status = JobStatus.SUCCEEDED
            else:
                # No changes case - just show agent output
                logger.info("Job completed with agent response only (no code changes)")
                final_status = JobStatus.SUCCEEDED

            # 8. 완료
            current_phase = "completed"
            await self._update_status(final_status, job, status_callback)

            # Prepare result summary (agent stdout if no changes, or PR info)
            result_summary = None
            if not has_changes and hasattr(agent_result, 'stdout'):
                # No changes case - include agent's response
                result_summary = agent_result.stdout.strip() if agent_result.stdout else None
            elif pr_info:
                result_summary = f"PR created: {pr_info['url']}"

            return JobExecutionResult(
                success=True,
                job_id=job.job_id,
                status=final_status,
                pr_number=pr_info["number"] if pr_info else None,
                pr_url=pr_info["url"] if pr_info else None,
                commit_sha=commit_sha,
                files_changed=len(agent_result.files_changed) if hasattr(agent_result, 'files_changed') else 0,
                work_dir=str(work_dir),
                result_summary=result_summary,
            )

        except Exception as e:
            logger.exception(f"Job {job.job_id} failed at phase: {current_phase}")

            # Use error handler to classify and handle the error
            error_handler = get_error_handler()
            error_context = {
                "phase": current_phase,
                "work_dir": str(work_dir),
                "job_id": job.job_id,
            }

            # Get current retry count (would come from job state in real implementation)
            current_retry_count = getattr(job, 'retry_count', 0)

            # Handle the error
            handling_result = await error_handler.handle_error(
                job_id=job.job_id,
                error=e,
                context=error_context,
                current_retry_count=current_retry_count,
            )

            # 상태: FAILED (only if not retryable)
            if not handling_result["should_retry"]:
                await self._update_status(JobStatus.FAILED, job, status_callback)

            return JobExecutionResult(
                success=False,
                job_id=job.job_id,
                status=JobStatus.FAILED,
                error_message=str(e),
                error_info=handling_result["error_info"],
                should_retry=handling_result["should_retry"],
                retry_after=handling_result["retry_after"],
                work_dir=str(work_dir),
            )

        finally:
            # 정리 (선택적)
            if git_workflow:
                try:
                    # 작업 디렉토리 보존 (디버깅용)
                    # await git_workflow.cleanup()
                    pass
                except Exception as e:
                    logger.warning(f"Failed to cleanup: {e}")

    async def _clone_repository(self, job: Job, work_dir: Path) -> GitWorkflow:
        """저장소 클론

        Args:
            job: Job 객체
            work_dir: 작업 디렉토리

        Returns:
            GitWorkflow 인스턴스

        Raises:
            Exception: 클론 실패 시
        """
        # 저장소 URL 확인
        if not job.repositories or len(job.repositories) == 0:
            raise ValueError("No repository specified in job")

        first_repo = job.repositories[0]
        repo_url = getattr(first_repo, "url", None)
        if not repo_url and isinstance(first_repo, dict):
            repo_url = first_repo.get("url")
        if not repo_url:
            raise ValueError("Repository URL not found")

        repo_branch = getattr(first_repo, "branch", None)
        if not repo_branch and isinstance(first_repo, dict):
            repo_branch = first_repo.get("branch")

        # Git 워크플로우 초기화
        git = GitWorkflow(work_dir)

        # 저장소 클론
        await git.clone_repo(
            repo_url=repo_url,
            branch=repo_branch or "main",  # TODO: 기본 브랜치 감지
            github_token=self.github_token,
        )

        logger.info(f"Repository cloned: {repo_url}")
        return git

    def _generate_branch_name(self, job: Job) -> str:
        """브랜치 이름 생성

        Args:
            job: Job 객체

        Returns:
            브랜치 이름
        """
        # Use branch_name from job if provided (e.g., from Linear integration)
        if job.branch_name:
            return job.branch_name

        if job.issue_number:
            return f"codernetes/issue-{job.issue_number}"
        else:
            return f"codernetes/job-{job.job_id[:8]}"

    async def _execute_agent(
        self, job: Job, work_dir: Path, config: AgentConfig
    ) -> object:
        """LLM Agent 실행

        Args:
            job: Job 객체
            work_dir: 작업 디렉토리
            config: Agent 설정

        Returns:
            AgentResult 객체

        Raises:
            Exception: Agent 실행 실패 시
        """
        # Agent 타입 결정 (우선순위: job > config > env > default)
        default_agent = os.getenv("DEFAULT_AGENT_TYPE", "azure-ai")  # 기본값을 azure-ai로

        # 명시적으로 우선순위 적용
        if job.agent_type:
            agent_type = job.agent_type
            logger.info(f"Using agent type from job: {agent_type}")
        elif config and config.agent_type:
            agent_type = config.agent_type
            logger.info(f"Using agent type from config: {agent_type}")
        elif default_agent:
            agent_type = default_agent
            logger.info(f"Using agent type from environment: {agent_type}")
        else:
            agent_type = "azure-ai"  # 최종 fallback
            logger.info(f"Using default agent type: {agent_type}")

        # Agent 실행기 초기화
        executor = AgentExecutor(agent_type=agent_type)

        # 프롬프트 준비
        prompt = self._prepare_prompt(job, config)

        # Agent 실행
        result = await executor.execute(
            work_dir=work_dir,
            prompt=prompt,
            config=config,
            timeout=3600,  # 1시간
        )

        if not result.success:
            logger.error(f"Agent execution failed: {result.error_message}")

        return result

    def _prepare_prompt(self, job: Job, config: AgentConfig) -> str:
        """프롬프트 준비

        Args:
            job: Job 객체
            config: Agent 설정

        Returns:
            최종 프롬프트
        """
        prompt_parts = []

        # Workflow 가이드 (중요!)
        prompt_parts.append("# Codernetes Automated Workflow")
        prompt_parts.append("This is an automated job execution system. Follow these steps:")
        prompt_parts.append("")
        prompt_parts.append("1. **Implement the required changes** to the codebase")
        prompt_parts.append("2. After you complete your changes, the system will:")
        prompt_parts.append("   - Automatically commit your changes")
        prompt_parts.append("   - Push to a new branch")
        prompt_parts.append("   - Create a Pull Request on GitHub")
        prompt_parts.append("")
        prompt_parts.append("**Your job**: Make the code changes. The system handles git operations and PR creation.")
        prompt_parts.append("")
        prompt_parts.append("---")
        prompt_parts.append("")

        # 시스템 프롬프트 (있으면)
        if config.system_prompt:
            prompt_parts.append("# System Instructions")
            prompt_parts.append(config.system_prompt)
            prompt_parts.append("")

        # Job 프롬프트
        prompt_parts.append("# Task")
        prompt_parts.append(job.prompt)
        prompt_parts.append("")

        # 이슈 정보 (있으면)
        if job.issue_number and job.issue_title:
            prompt_parts.append(f"# Resolving Issue #{job.issue_number}")
            prompt_parts.append(f"**Title**: {job.issue_title}")
            if job.issue_body:
                prompt_parts.append(f"**Description**: {job.issue_body}")
            prompt_parts.append("")

        # 테스트 정책 (있으면)
        if config.testing.required and config.testing.command:
            prompt_parts.append("# Testing Requirements")
            prompt_parts.append(
                f"- Run tests with: `{config.testing.command}`"
            )
            if config.testing.coverage_threshold:
                prompt_parts.append(
                    f"- Coverage threshold: {config.testing.coverage_threshold}%"
                )
            prompt_parts.append("")

        # 보호된 파일 경고 (있으면)
        if config.protected_paths:
            prompt_parts.append("# Protected Files (DO NOT MODIFY)")
            for path in config.protected_paths:
                prompt_parts.append(f"- {path}")
            prompt_parts.append("")

        return "\n".join(prompt_parts)

    async def _execute_fallback_command(
        self,
        job: Job,
        work_dir: Path,
        git: GitWorkflow,
        config: AgentConfig,
    ) -> AgentResult:
        """설정된 커스텀 명령을 실행하여 에이전트 동작을 대체"""
        if not self.fallback_command:
            return AgentResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr="",
                files_changed=[],
                error_message="Fallback command not configured",
            )

        prompt_path = work_dir / "prompt.txt"
        prompt_path.write_text(job.prompt, encoding="utf-8")

        env = os.environ.copy()
        env["CODERNETES_PROMPT"] = job.prompt
        env["CODERNETES_PROMPT_FILE"] = str(prompt_path)
        if job.repo_owner:
            env["CODERNETES_REPO_OWNER"] = job.repo_owner
        if job.repo_name:
            env["CODERNETES_REPO_NAME"] = job.repo_name
        if job.issue_number:
            env["CODERNETES_ISSUE_NUMBER"] = str(job.issue_number)
        if job.issue_title:
            env["CODERNETES_ISSUE_TITLE"] = job.issue_title
        if job.issue_body:
            env["CODERNETES_ISSUE_BODY"] = job.issue_body

        logger.info("Executing fallback command: %s", " ".join(self.fallback_command))

        try:
            process = await asyncio.create_subprocess_exec(
                *self.fallback_command,
                cwd=work_dir,
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_data, stderr_data = await process.communicate()
            stdout = stdout_data.decode("utf-8", errors="replace")
            stderr = stderr_data.decode("utf-8", errors="replace")
            exit_code = process.returncode

            files_changed = await git.get_changed_files()

            success = exit_code == 0
            error_message = None if success else (stderr or f"Fallback command exited with {exit_code}")

            return AgentResult(
                success=success,
                exit_code=exit_code,
                stdout=stdout,
                stderr=stderr,
                files_changed=files_changed,
                error_message=error_message,
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("Fallback command execution failed")
            return AgentResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr="",
                files_changed=[],
                error_message=str(exc),
            )

    async def _commit_changes(
        self, job: Job, git: GitWorkflow, config: AgentConfig
    ) -> str:
        """변경사항 커밋

        Args:
            job: Job 객체
            git: GitWorkflow 인스턴스
            config: Agent 설정

        Returns:
            커밋 SHA

        Raises:
            Exception: 커밋 실패 시
        """
        # 커밋 메시지 생성
        commit_message = config.get_commit_message(
            issue_title=job.issue_title or job.prompt[:50],
            issue_number=job.issue_number,
        )

        # 커밋
        commit_sha = await git.commit(
            message=commit_message,
            author_name="Codernetes Agent",
            author_email="noreply@codernetes.io",
        )

        logger.info(f"Changes committed: {commit_sha[:8]}")
        return commit_sha

    async def _create_pull_request(
        self,
        job: Job,
        branch_name: str,
        files_changed: list[str],
        commit_sha: str,
    ) -> dict:
        """Pull Request 생성

        Args:
            job: Job 객체
            branch_name: 브랜치 이름
            files_changed: 변경된 파일 목록
            commit_sha: 커밋 SHA

        Returns:
            PR 정보 딕셔너리

        Raises:
            Exception: PR 생성 실패 시
        """
        if not self.pr_manager:
            raise ValueError("PR Manager not initialized (GitHub token missing)")

        if not job.repo_owner or not job.repo_name:
            raise ValueError("Repository owner/name not specified in job")

        # PR 제목
        title = f"Fix: {job.issue_title}" if job.issue_title else job.prompt[:100]

        # Linear 메타데이터 추출
        linear_metadata = None
        if job.metadata:
            linear_keys = ['linear_issue_id', 'linear_issue_identifier', 'linear_issue_title',
                          'linear_issue_description', 'linear_url']
            if any(key in job.metadata for key in linear_keys):
                linear_metadata = job.metadata

        # PR 본문 생성
        body = self.pr_manager.generate_pr_body(
            issue_number=job.issue_number,
            issue_title=job.issue_title,
            issue_body=job.issue_body,
            agent_type=job.agent_type or "claude-code",
            files_changed=files_changed,
            commit_sha=commit_sha,
            linear_metadata=linear_metadata,
        )

        # PR 생성
        pr_info = await self.pr_manager.create_pr(
            owner=job.repo_owner,
            repo=job.repo_name,
            title=title,
            body=body,
            head=branch_name,
            base="main",  # TODO: 기본 브랜치 감지
            draft=False,
        )

        logger.info(f"PR created: #{pr_info['number']} - {pr_info['url']}")
        return pr_info

    async def _update_status(
        self, status: JobStatus, job: Job, callback: Optional[callable]
    ):
        """상태 업데이트

        Args:
            status: 새 상태
            job: Job 객체
            callback: 상태 업데이트 콜백 함수
        """
        logger.info(f"Job {job.job_id} status: {status.value}")

        if callback:
            try:
                await callback(job.job_id, status)
            except Exception as e:
                logger.warning(f"Status callback failed: {e}")

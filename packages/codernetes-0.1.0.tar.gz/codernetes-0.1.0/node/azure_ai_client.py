"""
Azure AI Projects SDK 클라이언트

Azure AI Foundry를 통해 OpenAI 모델에 직접 접근합니다.
"""

import logging
import os
from typing import Optional

from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential

logger = logging.getLogger(__name__)


class AzureAIClient:
    """Azure AI Projects 클라이언트 래퍼"""

    def __init__(self):
        """Azure AI 클라이언트 초기화

        환경 변수:
            PROJECT_ENDPOINT: Azure AI Foundry 프로젝트 엔드포인트
                예: https://your-resource.ai.azure.com/api/projects/project-name
            MODEL_DEPLOYMENT_NAME: 사용할 모델 deployment 이름 (기본: gpt-4o)
            AZURE_API_VERSION: API 버전 (기본: 2024-10-21)
        """
        self.endpoint = os.getenv("PROJECT_ENDPOINT")
        self.model_deployment = os.getenv("MODEL_DEPLOYMENT_NAME", "gpt-4o")
        self.api_version = os.getenv("AZURE_API_VERSION", "2024-10-21")

        if not self.endpoint:
            raise ValueError(
                "PROJECT_ENDPOINT environment variable is required. "
                "Example: https://your-resource.ai.azure.com/api/projects/project-name"
            )

        logger.info(f"Initializing Azure AI client with endpoint: {self.endpoint}")
        logger.info(f"Using model deployment: {self.model_deployment}")

        # Azure AI Project 클라이언트 생성
        self.project = AIProjectClient(
            endpoint=self.endpoint,
            credential=DefaultAzureCredential(),
        )

        # OpenAI 클라이언트 가져오기
        self.openai_client = self.project.get_openai_client(
            api_version=self.api_version
        )

    async def create_completion(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        """채팅 completion 생성

        Args:
            prompt: 사용자 프롬프트
            system_prompt: 시스템 프롬프트 (선택)
            temperature: 생성 온도 (0.0-1.0)
            max_tokens: 최대 토큰 수 (선택)

        Returns:
            생성된 텍스트 응답

        Raises:
            Exception: Azure AI API 호출 실패 시
        """
        messages = []

        # 시스템 프롬프트 추가
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        # 사용자 프롬프트 추가
        messages.append({"role": "user", "content": prompt})

        logger.info(f"Creating completion with {len(messages)} messages")
        logger.debug(f"Prompt: {prompt[:100]}...")

        try:
            # 채팅 completion 생성
            response = self.openai_client.chat.completions.create(
                model=self.model_deployment,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )

            # 응답 추출
            content = response.choices[0].message.content

            logger.info(f"Completion successful, response length: {len(content)} chars")
            logger.debug(f"Response: {content[:200]}...")

            return content

        except Exception as e:
            logger.error(f"Failed to create completion: {e}")
            raise

    async def create_streaming_completion(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        """스트리밍 채팅 completion 생성

        Args:
            prompt: 사용자 프롬프트
            system_prompt: 시스템 프롬프트 (선택)
            temperature: 생성 온도 (0.0-1.0)
            max_tokens: 최대 토큰 수 (선택)

        Yields:
            생성된 텍스트 청크

        Raises:
            Exception: Azure AI API 호출 실패 시
        """
        messages = []

        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        messages.append({"role": "user", "content": prompt})

        logger.info(f"Creating streaming completion with {len(messages)} messages")

        try:
            # 스트리밍 채팅 completion 생성
            stream = self.openai_client.chat.completions.create(
                model=self.model_deployment,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
            )

            # 스트림 청크 yield
            for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content

        except Exception as e:
            logger.error(f"Failed to create streaming completion: {e}")
            raise

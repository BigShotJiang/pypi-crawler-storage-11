"""
PR 관리자 모듈

GitHub Pull Request 생성 및 관리를 담당합니다.
"""

import asyncio
import logging
import os
from typing import Optional

from github import Github
from github.GithubException import GithubException
from github.PullRequest import PullRequest

logger = logging.getLogger(__name__)


class PRManager:
    """GitHub PR 생성 및 관리"""

    def __init__(self, github_token: Optional[str] = None):
        """
        Args:
            github_token: GitHub 토큰 (None이면 환경 변수에서 로드)
        """
        self.token = github_token or os.getenv("GITHUB_TOKEN")
        if not self.token:
            raise ValueError("GitHub token not provided and GITHUB_TOKEN env var not set")

        self.github = Github(self.token)
        logger.info("PRManager initialized")

    async def create_pr(
        self,
        owner: str,
        repo: str,
        title: str,
        body: str,
        head: str,
        base: str = "main",
        draft: bool = False,
    ) -> dict:
        """PR 생성

        Args:
            owner: 저장소 소유자
            repo: 저장소 이름
            title: PR 제목
            body: PR 본문
            head: PR 브랜치 (source)
            base: 타겟 브랜치 (기본값: main)
            draft: Draft PR 여부

        Returns:
            PR 정보 딕셔너리

        Raises:
            GithubException: GitHub API 오류
        """
        logger.info(f"Creating PR: {owner}/{repo} ({head} -> {base})")

        # 비동기 실행을 위해 run_in_executor 사용
        loop = asyncio.get_event_loop()

        def _create_pr():
            try:
                repository = self.github.get_repo(f"{owner}/{repo}")

                # PR 생성
                pr = repository.create_pull(
                    title=title, body=body, head=head, base=base, draft=draft
                )

                logger.info(f"PR created successfully: #{pr.number}")

                return {
                    "number": pr.number,
                    "url": pr.html_url,
                    "state": pr.state,
                    "title": pr.title,
                    "draft": pr.draft,
                }

            except GithubException as e:
                logger.error(f"Failed to create PR: {e}")
                raise

        return await loop.run_in_executor(None, _create_pr)

    async def update_pr(
        self,
        owner: str,
        repo: str,
        pr_number: int,
        title: Optional[str] = None,
        body: Optional[str] = None,
        state: Optional[str] = None,
    ) -> dict:
        """PR 업데이트

        Args:
            owner: 저장소 소유자
            repo: 저장소 이름
            pr_number: PR 번호
            title: 새 제목 (선택)
            body: 새 본문 (선택)
            state: 새 상태 (open/closed) (선택)

        Returns:
            업데이트된 PR 정보

        Raises:
            GithubException: GitHub API 오류
        """
        logger.info(f"Updating PR #{pr_number}: {owner}/{repo}")

        loop = asyncio.get_event_loop()

        def _update_pr():
            try:
                repository = self.github.get_repo(f"{owner}/{repo}")
                pr = repository.get_pull(pr_number)

                # PR 업데이트
                if title is not None:
                    pr.edit(title=title)
                if body is not None:
                    pr.edit(body=body)
                if state is not None:
                    pr.edit(state=state)

                logger.info(f"PR #{pr_number} updated successfully")

                return {
                    "number": pr.number,
                    "url": pr.html_url,
                    "state": pr.state,
                    "title": pr.title,
                }

            except GithubException as e:
                logger.error(f"Failed to update PR #{pr_number}: {e}")
                raise

        return await loop.run_in_executor(None, _update_pr)

    async def add_pr_comment(
        self, owner: str, repo: str, pr_number: int, comment: str
    ) -> dict:
        """PR에 코멘트 추가

        Args:
            owner: 저장소 소유자
            repo: 저장소 이름
            pr_number: PR 번호
            comment: 코멘트 내용

        Returns:
            코멘트 정보

        Raises:
            GithubException: GitHub API 오류
        """
        logger.info(f"Adding comment to PR #{pr_number}: {owner}/{repo}")

        loop = asyncio.get_event_loop()

        def _add_comment():
            try:
                repository = self.github.get_repo(f"{owner}/{repo}")
                pr = repository.get_pull(pr_number)

                # 코멘트 추가
                issue_comment = pr.create_issue_comment(comment)

                logger.info(f"Comment added to PR #{pr_number}")

                return {
                    "id": issue_comment.id,
                    "body": issue_comment.body,
                    "created_at": issue_comment.created_at.isoformat(),
                }

            except GithubException as e:
                logger.error(f"Failed to add comment to PR #{pr_number}: {e}")
                raise

        return await loop.run_in_executor(None, _add_comment)

    async def get_pr(self, owner: str, repo: str, pr_number: int) -> dict:
        """PR 정보 조회

        Args:
            owner: 저장소 소유자
            repo: 저장소 이름
            pr_number: PR 번호

        Returns:
            PR 정보

        Raises:
            GithubException: GitHub API 오류
        """
        logger.info(f"Fetching PR #{pr_number}: {owner}/{repo}")

        loop = asyncio.get_event_loop()

        def _get_pr():
            try:
                repository = self.github.get_repo(f"{owner}/{repo}")
                pr = repository.get_pull(pr_number)

                return {
                    "number": pr.number,
                    "url": pr.html_url,
                    "state": pr.state,
                    "title": pr.title,
                    "body": pr.body,
                    "draft": pr.draft,
                    "mergeable": pr.mergeable,
                    "merged": pr.merged,
                    "head": {"ref": pr.head.ref, "sha": pr.head.sha},
                    "base": {"ref": pr.base.ref, "sha": pr.base.sha},
                    "created_at": pr.created_at.isoformat(),
                    "updated_at": pr.updated_at.isoformat(),
                }

            except GithubException as e:
                logger.error(f"Failed to fetch PR #{pr_number}: {e}")
                raise

        return await loop.run_in_executor(None, _get_pr)

    async def close_pr(self, owner: str, repo: str, pr_number: int) -> dict:
        """PR 닫기

        Args:
            owner: 저장소 소유자
            repo: 저장소 이름
            pr_number: PR 번호

        Returns:
            닫힌 PR 정보

        Raises:
            GithubException: GitHub API 오류
        """
        return await self.update_pr(owner, repo, pr_number, state="closed")

    async def merge_pr(
        self,
        owner: str,
        repo: str,
        pr_number: int,
        commit_message: Optional[str] = None,
        merge_method: str = "merge",
    ) -> dict:
        """PR 병합

        Args:
            owner: 저장소 소유자
            repo: 저장소 이름
            pr_number: PR 번호
            commit_message: 병합 커밋 메시지 (선택)
            merge_method: 병합 방법 (merge, squash, rebase)

        Returns:
            병합 결과 정보

        Raises:
            GithubException: GitHub API 오류
        """
        logger.info(f"Merging PR #{pr_number}: {owner}/{repo} (method: {merge_method})")

        loop = asyncio.get_event_loop()

        def _merge_pr():
            try:
                repository = self.github.get_repo(f"{owner}/{repo}")
                pr = repository.get_pull(pr_number)

                # PR 병합
                merge_result = pr.merge(
                    commit_message=commit_message, merge_method=merge_method
                )

                logger.info(f"PR #{pr_number} merged successfully")

                return {
                    "merged": merge_result.merged,
                    "sha": merge_result.sha,
                    "message": merge_result.message,
                }

            except GithubException as e:
                logger.error(f"Failed to merge PR #{pr_number}: {e}")
                raise

        return await loop.run_in_executor(None, _merge_pr)

    def generate_pr_body(
        self,
        issue_number: Optional[int],
        issue_title: Optional[str],
        issue_body: Optional[str],
        agent_type: str,
        files_changed: list[str],
        commit_sha: str,
        linear_metadata: Optional[dict] = None,
    ) -> str:
        """PR 본문 생성

        Args:
            issue_number: 이슈 번호
            issue_title: 이슈 제목
            issue_body: 이슈 본문
            agent_type: Agent 타입
            files_changed: 변경된 파일 목록
            commit_sha: 커밋 SHA
            linear_metadata: Linear 이슈 메타데이터 (optional)

        Returns:
            PR 본문 텍스트
        """
        body_parts = []

        # Linear 이슈 정보 (우선순위)
        if linear_metadata:
            linear_identifier = linear_metadata.get("linear_issue_identifier")
            linear_title = linear_metadata.get("linear_issue_title")
            linear_url = linear_metadata.get("linear_url")

            if linear_identifier and linear_title:
                body_parts.append(f"## Resolves {linear_identifier}")
                body_parts.append("")
                body_parts.append(f"**Linear Issue**: [{linear_identifier}]({linear_url})")
                body_parts.append(f"**Title**: {linear_title}")
                body_parts.append("")

                linear_description = linear_metadata.get("linear_issue_description")
                if linear_description:
                    body_parts.append("### Issue Description")
                    body_parts.append(linear_description[:500])
                    if len(linear_description) > 500:
                        body_parts.append("...")
                    body_parts.append("")
        # GitHub 이슈 정보 (Linear가 없을 때)
        elif issue_number and issue_title:
            body_parts.append(f"## Resolves #{issue_number}")
            body_parts.append("")
            body_parts.append(f"**Issue**: {issue_title}")
            body_parts.append("")

            if issue_body:
                body_parts.append("### Issue Description")
                body_parts.append(issue_body[:500])  # 처음 500자만
                if len(issue_body) > 500:
                    body_parts.append("...")
                body_parts.append("")

        # 변경사항
        body_parts.append("## Changes")
        body_parts.append("")

        if files_changed:
            body_parts.append(f"**Files changed**: {len(files_changed)}")
            body_parts.append("")
            body_parts.append("```")
            for file in files_changed[:20]:  # 처음 20개만
                body_parts.append(file)
            if len(files_changed) > 20:
                body_parts.append(f"... and {len(files_changed) - 20} more files")
            body_parts.append("```")
            body_parts.append("")

        # Agent 정보
        body_parts.append("## Generated by")
        body_parts.append(f"- **Agent**: {agent_type}")
        body_parts.append(f"- **Commit**: {commit_sha[:8]}")
        body_parts.append("- **Platform**: Codernetes")
        body_parts.append("")

        # 리뷰 요청
        body_parts.append("## Review Checklist")
        body_parts.append("- [ ] Code changes are correct and complete")
        body_parts.append("- [ ] Tests pass (if applicable)")
        body_parts.append("- [ ] No unintended side effects")
        body_parts.append("- [ ] Ready to merge")

        return "\n".join(body_parts)

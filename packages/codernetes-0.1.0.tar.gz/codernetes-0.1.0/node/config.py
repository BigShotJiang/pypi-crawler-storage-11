"""Node configuration management."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


class NodeConfig:
    """Node configuration manager."""

    def __init__(self, config_path: str | None = None):
        """Initialize configuration manager.

        Args:
            config_path: Path to configuration file. Defaults to ~/.codernetes/node.json
        """
        if config_path is None:
            config_dir = Path.home() / ".codernetes"
            config_dir.mkdir(parents=True, exist_ok=True)
            config_path = str(config_dir / "node.json")

        self.config_path = config_path
        self._config: dict[str, Any] = {}
        self.load()

    def load(self) -> None:
        """Load configuration from file."""
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, encoding="utf-8") as f:
                    self._config = json.load(f)
            except Exception as e:
                print(f"Warning: Failed to load config from {self.config_path}: {e}")
                self._config = {}
        else:
            self._config = {}

    def save(self) -> None:
        """Save configuration to file."""
        try:
            config_dir = Path(self.config_path).parent
            config_dir.mkdir(parents=True, exist_ok=True)

            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self._config, f, indent=2)

            # Set restrictive permissions (owner read/write only)
            os.chmod(self.config_path, 0o600)
        except Exception as e:
            print(f"Error: Failed to save config to {self.config_path}: {e}")
            raise

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value."""
        return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Set configuration value."""
        self._config[key] = value

    def delete(self, key: str) -> None:
        """Delete configuration value."""
        if key in self._config:
            del self._config[key]

    def clear(self) -> None:
        """Clear all configuration."""
        self._config = {}

    @property
    def master_url(self) -> str | None:
        """Get master server URL."""
        return self.get("master_url")

    @master_url.setter
    def master_url(self, value: str) -> None:
        """Set master server URL."""
        self.set("master_url", value)

    @property
    def user_id(self) -> str | None:
        """Get user ID."""
        return self.get("user_id")

    @user_id.setter
    def user_id(self, value: str) -> None:
        """Set user ID."""
        self.set("user_id", value)

    @property
    def auth_token(self) -> str | None:
        """Get authentication token."""
        return self.get("auth_token")

    @auth_token.setter
    def auth_token(self, value: str) -> None:
        """Set authentication token."""
        self.set("auth_token", value)

    @property
    def machine_name(self) -> str | None:
        """Get machine name."""
        return self.get("machine_name")

    @machine_name.setter
    def machine_name(self, value: str) -> None:
        """Set machine name."""
        self.set("machine_name", value)

    @property
    def node_tags(self) -> list[str]:
        """Get node tags."""
        return self.get("node_tags", [])

    @node_tags.setter
    def node_tags(self, value: list[str]) -> None:
        """Set node tags."""
        self.set("node_tags", value)

    @property
    def github_token(self) -> str | None:
        """Get GitHub token (stored locally on node)."""
        return self.get("github_token")

    @github_token.setter
    def github_token(self, value: str) -> None:
        """Set GitHub token."""
        self.set("github_token", value)

    @property
    def linear_api_key(self) -> str | None:
        """Get Linear API key (stored locally on node)."""
        return self.get("linear_api_key")

    @linear_api_key.setter
    def linear_api_key(self, value: str) -> None:
        """Set Linear API key."""
        self.set("linear_api_key", value)

    @property
    def max_concurrent_jobs(self) -> int:
        """Get maximum concurrent jobs."""
        return self.get("max_concurrent_jobs", 5)

    @max_concurrent_jobs.setter
    def max_concurrent_jobs(self, value: int) -> None:
        """Set maximum concurrent jobs."""
        self.set("max_concurrent_jobs", value)

    @property
    def credentials(self) -> dict[str, dict[str, Any]]:
        """Get credentials dictionary for delegation to node.

        Returns:
            Dictionary mapping provider name to credential data.
            Example: {"github": {"access_token": "ghp_..."}, "linear": {"access_token": "lin_..."}}
        """
        creds: dict[str, dict[str, Any]] = {}

        if self.github_token:
            creds["github"] = {"access_token": self.github_token}

        if self.linear_api_key:
            creds["linear"] = {"access_token": self.linear_api_key}

        return creds

    def is_configured(self) -> bool:
        """Check if node is properly configured."""
        return all([
            self.master_url,
            self.user_id,
            self.auth_token,
            self.machine_name,
        ])

    def __repr__(self) -> str:
        """String representation."""
        return f"NodeConfig(path={self.config_path}, configured={self.is_configured()})"

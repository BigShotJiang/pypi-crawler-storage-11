"""
LLM Agent 실행기 모듈

Claude Code, Codex LLM Agent CLI를 실행합니다.
"""

import asyncio
import logging
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class AgentResult:
    """Agent 실행 결과"""

    success: bool
    exit_code: int
    stdout: str
    stderr: str
    files_changed: list[str]
    error_message: Optional[str] = None


class AgentExecutor:
    """LLM Agent CLI 실행기"""

    def __init__(self, agent_type: str = "claude-code"):
        """
        Args:
            agent_type: Agent 타입 (claude-code, codex, aider, azure-ai)
        """
        self.agent_type = agent_type
        self.executable_path = self._get_executable_path()
        self.azure_ai_client = None

    def _get_executable_path(self) -> Optional[str]:
        """Agent 실행 파일 경로 조회

        Returns:
            실행 파일 경로 또는 None (환경 변수로 지정된 경우)

        Raises:
            FileNotFoundError: 실행 파일을 찾을 수 없는 경우
        """
        # azure-ai는 SDK 기반이라 실행 파일 불필요
        if self.agent_type == "azure-ai":
            logger.info("Using Azure AI SDK (no executable required)")
            return None

        # 환경 변수에서 경로 확인
        env_var_map = {
            "claude-code": "CLAUDE_CODE_PATH",
            "codex": "CODEX_PATH",
            "aider": "AIDER_PATH",
        }

        fallback_names = {
            "claude-code": ["claude", "claude-code"],  # 'claude'가 실제 바이너리 이름
            "codex": ["codex"],  # 커스텀 래퍼 스크립트
            "aider": ["aider"],  # aider CLI
        }

        env_var = env_var_map.get(self.agent_type)
        if env_var and os.getenv(env_var):
            path = os.getenv(env_var)
            logger.info(f"Using {self.agent_type} from environment variable: {path}")
            return path

        # PATH에서 실행 파일 찾기
        for name in fallback_names.get(self.agent_type, [self.agent_type]):
            executable_path = shutil.which(name)
            if executable_path:
                logger.info(f"Found {self.agent_type} executable '{name}' in PATH: {executable_path}")
                return executable_path

        # 찾지 못한 경우 경고 (실행 시 오류 발생)
        logger.warning(
            f"Could not find {self.agent_type} executable. "
            f"Set {env_var} environment variable or ensure it's in PATH."
        )
        return None

    async def execute(
        self,
        work_dir: str | Path,
        prompt: str,
        config: Optional[object] = None,
        timeout: int = 3600,
    ) -> AgentResult:
        """Agent 실행

        Args:
            work_dir: 작업 디렉토리
            prompt: Agent에게 전달할 프롬프트
            config: Agent 설정 (AgentConfig 객체)
            timeout: 실행 타임아웃 (초)

        Returns:
            AgentResult 객체

        Raises:
            ValueError: 지원하지 않는 agent_type
            FileNotFoundError: 실행 파일을 찾을 수 없는 경우
        """
        work_dir = Path(work_dir)

        if not work_dir.exists():
            raise FileNotFoundError(f"Work directory not found: {work_dir}")

        logger.info(f"Executing {self.agent_type} in {work_dir}")
        logger.debug(f"Prompt: {prompt[:100]}...")

        # Agent 타입에 따라 실행 메서드 선택
        if self.agent_type == "claude-code":
            return await self._execute_claude_code(work_dir, prompt, config, timeout)
        elif self.agent_type == "codex":
            return await self._execute_codex(work_dir, prompt, config, timeout)
        elif self.agent_type == "aider":
            return await self._execute_aider(work_dir, prompt, config, timeout)
        elif self.agent_type == "azure-ai":
            return await self._execute_azure_ai(work_dir, prompt, config, timeout)
        else:
            raise ValueError(f"Unsupported agent type: {self.agent_type}. Use 'claude-code', 'codex', 'aider', or 'azure-ai'.")

    async def _execute_claude_code(
        self,
        work_dir: Path,
        prompt: str,
        config: Optional[object],
        timeout: int,
    ) -> AgentResult:
        """Claude Code CLI 실행

        Claude Code는 --print 플래그로 비대화형 실행을 지원하며,
        --append-system-prompt로 시스템 프롬프트를 추가할 수 있습니다.
        
        공식 문서: https://docs.claude.com/en/docs/claude-code/cli-reference
        
        올바른 사용법:
        - claude --print -p "prompt"
        - claude --print --append-system-prompt "system" -p "prompt"

        Args:
            work_dir: 작업 디렉토리
            prompt: 프롬프트
            config: Agent 설정
            timeout: 타임아웃

        Returns:
            AgentResult 객체
        """
        executable = self.executable_path or shutil.which("claude")
        if not executable:
            logger.error(
                "claude 실행 파일을 찾을 수 없습니다. CLAUDE_CODE_PATH 환경 변수 또는 PATH를 확인하세요."
            )
            return AgentResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr="",
                files_changed=[],
                error_message="claude executable not found",
            )

        # 자동화를 위한 시스템 프롬프트
        system_prompt = (
            "You are running in automated mode. "
            "IMPORTANT: Do NOT ask questions or request confirmation. "
            "Execute the requested task immediately and completely. "
            "If you need to make decisions, use best practices and common sense. "
            "After completing the task, respond with 'DONE' and exit. "
            "Do not ask for next steps or additional work."
        )

        # 프롬프트 개선: 명확한 지시 추가
        enhanced_prompt = (
            f"{prompt}\n\n"
            "Execute this task completely without asking questions. "
            "Make necessary decisions yourself based on best practices. "
            "When finished, respond with 'DONE'."
        )

        # Claude Code 명령어 구성
        # 공식 문서 기준: claude --print --append-system-prompt "system" -p "prompt"
        cmd = [
            executable,
            "--print",  # Non-interactive mode
            "--dangerously-skip-permissions",
            "--append-system-prompt",
            system_prompt,
            enhanced_prompt,  # The actual prompt - no -p flag needed
        ]

        # 환경 변수 설정
        env = os.environ.copy()

        # Anthropic API 키 확인 (선택적 - claude CLI가 이미 인증되어 있을 수 있음)
        if not env.get("ANTHROPIC_API_KEY"):
            logger.warning("ANTHROPIC_API_KEY not set in environment, assuming claude CLI is already authenticated")
            # claude CLI가 이미 인증되어 있을 수 있으므로 계속 진행

        logger.info("Running Claude Code with automated system prompt")
        logger.debug(f"Command: {' '.join(cmd[:5])}... (prompt truncated)")

        # 실행
        return await self._run_subprocess(cmd, work_dir, env, timeout)

    async def _execute_codex(
        self,
        work_dir: Path,
        prompt: str,
        config: Optional[object],
        timeout: int,
    ) -> AgentResult:
        """Codex CLI 실행

        OpenAI Codex CLI: https://github.com/openai/codex
        - 설치: npm install -g @openai/codex
        - 인증: ChatGPT Plus/Pro/Team/Enterprise 또는 OpenAI API Key
        - Non-interactive mode: codex exec 사용

        Args:
            work_dir: 작업 디렉토리
            prompt: 프롬프트
            config: Agent 설정
            timeout: 타임아웃

        Returns:
            AgentResult 객체
        """
        executable = self.executable_path or shutil.which("codex")
        if not executable:
            logger.error(
                "codex 실행 파일을 찾을 수 없습니다. "
                "설치: npm install -g @openai/codex 또는 brew install --cask codex"
            )
            return AgentResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr="",
                files_changed=[],
                error_message="codex executable not found. Install: npm install -g @openai/codex",
            )

        # Codex 명령어 구성 (non-interactive mode)
        # codex exec을 사용하여 비대화형 실행
        cmd = [
            executable,
            "exec",
            prompt,
        ]

        # 환경 변수 설정
        env = os.environ.copy()

        # OpenAI API 키 확인 (선택사항 - ChatGPT 계정으로도 가능)
        if not env.get("OPENAI_API_KEY"):
            logger.warning(
                "OPENAI_API_KEY not set. "
                "Codex will use ChatGPT account authentication. "
                "Ensure you're logged in with Plus/Pro/Team/Enterprise plan."
            )

        logger.info("Running Codex with 'exec' command for non-interactive execution")

        # 실행
        return await self._run_subprocess(cmd, work_dir, env, timeout)

    async def _execute_aider(
        self,
        work_dir: Path,
        prompt: str,
        config: Optional[object],
        timeout: int,
    ) -> AgentResult:
        """Aider CLI 실행

        Aider는 Azure OpenAI를 포함한 다양한 LLM 제공자를 지원합니다.
        
        공식 문서: https://aider.chat/docs/
        Azure OpenAI 설정: https://aider.chat/docs/config/azure.html
        
        Azure OpenAI 환경 변수 (AZURE_ 접두사 사용):
        - AZURE_API_BASE=https://your-endpoint.openai.azure.com/
        - AZURE_API_VERSION=2024-02-15-preview
        - AZURE_API_KEY=your-azure-key
        - Model: azure/deployment-name 형식으로 지정

        Args:
            work_dir: 작업 디렉토리
            prompt: 프롬프트
            config: Agent 설정
            timeout: 타임아웃

        Returns:
            AgentResult 객체
        """
        executable = self.executable_path or shutil.which("aider")
        if not executable:
            logger.error(
                "aider 실행 파일을 찾을 수 없습니다. "
                "설치: pip install aider-chat"
            )
            return AgentResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr="",
                files_changed=[],
                error_message="aider executable not found. Install: pip install aider-chat",
            )

        # 환경 변수 설정
        env = os.environ.copy()

        # Azure OpenAI 설정 확인 및 적용
        # config 객체에서 Azure 설정을 가져올 수 있다면 사용
        azure_model = None
        if config and hasattr(config, 'azure_openai'):
            azure_config = config.azure_openai
            if azure_config:
                # Azure OpenAI 환경 변수 설정 (AZURE_ 접두사 사용)
                env["AZURE_API_BASE"] = azure_config.get("endpoint", "")
                env["AZURE_API_VERSION"] = azure_config.get("api_version", "2024-02-15-preview")
                env["AZURE_API_KEY"] = azure_config.get("key", "")
                # 모델명: azure/deployment-name 형식
                deployment = azure_config.get("deployment", "")
                if deployment:
                    azure_model = f"azure/{deployment}"
                logger.info("Using Azure OpenAI configuration from agent config")
        
        # 환경 변수에서 Azure OpenAI 설정 확인 (AZURE_ 접두사)
        if not azure_model and env.get("AZURE_API_BASE"):
            # 환경 변수에서 deployment 추출
            deployment_id = env.get("OPENAI_API_DEPLOYMENT_ID") or env.get("AZURE_DEPLOYMENT_ID")
            if deployment_id:
                azure_model = f"azure/{deployment_id}"
        
        # Aider 명령어 구성
        # --yes-always: 모든 확인 자동 수락
        # --no-auto-commits: Codernetes가 커밋 관리
        # --message: 실행할 작업 지시
        # --model: Azure OpenAI 모델 지정 (azure/deployment-name 형식)
        cmd = [
            executable,
            "--yes-always",           # 자동 확인
            "--no-auto-commits",      # 자동 커밋 비활성화
        ]
        
        # Azure 모델 지정
        if azure_model:
            cmd.extend(["--model", azure_model])
        
        cmd.extend([
            "--message",              # 프롬프트 전달
            prompt,
        ])

        # API 키 확인
        if not env.get("AZURE_API_KEY") and not env.get("OPENAI_API_KEY"):
            logger.error(
                "Azure OpenAI API key not set. "
                "Set AZURE_API_KEY environment variable. "
                "Example: AZURE_API_BASE=https://....openai.azure.com/, "
                "AZURE_API_VERSION=2024-02-15-preview, "
                "AZURE_API_KEY=your-key"
            )
            return AgentResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr="",
                files_changed=[],
                error_message="AZURE_API_KEY not set",
            )

        logger.info("Running Aider with automated mode (--yes-always)")
        if env.get("AZURE_API_BASE"):
            logger.info(f"Using Azure OpenAI endpoint: {env.get('AZURE_API_BASE')}")
            logger.info(f"Using Azure model: {azure_model}")
        
        # 실행
        return await self._run_subprocess(cmd, work_dir, env, timeout)

    async def _execute_azure_ai(
        self,
        work_dir: Path,
        prompt: str,
        config: Optional[object],
        timeout: int,
    ) -> AgentResult:
        """Azure OpenAI SDK를 사용한 직접 실행

        Azure OpenAI 서비스를 통해 GPT 모델에 직접 접근합니다.
        CLI 도구 없이 OpenAI SDK를 사용합니다.

        공식 문서: https://learn.microsoft.com/azure/ai-services/openai/

        환경 변수:
        - AZURE_OPENAI_ENDPOINT: Azure OpenAI 엔드포인트
          예: https://your-resource.openai.azure.com/
        - MODEL_DEPLOYMENT_NAME: 모델 deployment 이름 (기본: gpt-4.1-mini)
        - AZURE_API_VERSION: API 버전 (기본: 2024-02-15-preview)
        - AZURE_API_KEY: Azure OpenAI API 키

        Args:
            work_dir: 작업 디렉토리
            prompt: 프롬프트
            config: Agent 설정
            timeout: 타임아웃 (현재 미사용 - API 호출용)

        Returns:
            AgentResult 객체
        """
        try:
            # Azure OpenAI 클라이언트 초기화 (필요시)
            if not self.azure_ai_client:
                from node.azure_openai_client import AzureOpenAIClient

                logger.info("Initializing Azure OpenAI client")
                try:
                    self.azure_ai_client = AzureOpenAIClient()
                except Exception as e:
                    logger.error(f"Failed to initialize Azure OpenAI client: {e}")
                    return AgentResult(
                        success=False,
                        exit_code=-1,
                        stdout="",
                        stderr="",
                        files_changed=[],
                        error_message=f"Azure OpenAI client initialization failed: {e}",
                    )

            # 시스템 프롬프트 구성
            system_prompt = (
                "You are an AI coding assistant. "
                "Analyze the task and provide clear, actionable instructions or code. "
                "Be concise and focused on solving the problem."
            )

            logger.info("Creating completion with Azure OpenAI")
            logger.debug(f"Prompt: {prompt[:200]}...")

            # Azure OpenAI를 통한 completion 생성
            try:
                response = await self.azure_ai_client.create_completion(
                    prompt=prompt,
                    system_prompt=system_prompt,
                    temperature=0.7,
                )
            except Exception as e:
                logger.error(f"Azure OpenAI completion failed: {e}")
                return AgentResult(
                    success=False,
                    exit_code=-1,
                    stdout="",
                    stderr=str(e),
                    files_changed=[],
                    error_message=f"Azure OpenAI API call failed: {e}",
                )

            logger.info(f"Azure OpenAI completion successful, response length: {len(response)} chars")
            logger.debug(f"Response preview: {response[:200]}...")

            # 응답을 stdout으로 반환
            stdout = response

            # 변경된 파일 목록 (Git으로 확인)
            # Note: Azure OpenAI는 직접 파일을 수정하지 않으므로,
            # 응답을 기반으로 사용자가 파일을 수정해야 함
            files_changed = await self._get_changed_files(work_dir)

            return AgentResult(
                success=True,
                exit_code=0,
                stdout=stdout,
                stderr="",
                files_changed=files_changed,
                error_message=None,
            )

        except Exception as e:
            logger.exception(f"Failed to execute Azure OpenAI agent")
            return AgentResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr="",
                files_changed=[],
                error_message=str(e),
            )

    async def _run_subprocess(
        self,
        cmd: list[str],
        work_dir: Path,
        env: dict[str, str],
        timeout: int,
    ) -> AgentResult:
        """서브프로세스 실행

        Args:
            cmd: 실행할 명령어 리스트
            work_dir: 작업 디렉토리
            env: 환경 변수
            timeout: 타임아웃

        Returns:
            AgentResult 객체
        """
        logger.info(f"Running command: {' '.join(cmd)}")

        try:
            # 서브프로세스 실행
            process = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=work_dir,
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            # 타임아웃과 함께 대기
            try:
                stdout_data, stderr_data = await asyncio.wait_for(
                    process.communicate(), timeout=timeout
                )
            except asyncio.TimeoutError:
                logger.error(f"Process timeout after {timeout} seconds")
                process.kill()
                await process.wait()
                return AgentResult(
                    success=False,
                    exit_code=-1,
                    stdout="",
                    stderr="",
                    files_changed=[],
                    error_message=f"Timeout after {timeout} seconds",
                )

            # 결과 디코딩
            stdout = stdout_data.decode("utf-8", errors="replace")
            stderr = stderr_data.decode("utf-8", errors="replace")
            exit_code = process.returncode

            logger.info(f"Process exited with code: {exit_code}")
            
            # stdout/stderr 로깅 (디버깅용)
            if stdout:
                logger.info(f"Agent stdout: {stdout[:500]}")  # 처음 500자만
            if stderr:
                logger.error(f"Agent stderr: {stderr[:500]}")  # 처음 500자만

            # 성공 여부 판단
            success = exit_code == 0

            # 변경된 파일 목록 (Git으로 확인)
            files_changed = await self._get_changed_files(work_dir)

            # 에러 메시지 추출
            error_message = None
            if not success:
                # stderr가 있으면 그것을, 없으면 exit code를
                error_message = stderr if stderr else f"Exit code: {exit_code}"
                logger.error(f"Agent failed with: {error_message[:200]}")

            return AgentResult(
                success=success,
                exit_code=exit_code,
                stdout=stdout,
                stderr=stderr,
                files_changed=files_changed,
                error_message=error_message,
            )

        except Exception as e:
            logger.exception(f"Failed to execute {self.agent_type}")
            return AgentResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr="",
                files_changed=[],
                error_message=str(e),
            )

    async def _get_changed_files(self, work_dir: Path) -> list[str]:
        """Git으로 변경된 파일 목록 조회

        Args:
            work_dir: 작업 디렉토리

        Returns:
            변경된 파일 목록
        """
        try:
            # git status --porcelain 실행
            process = await asyncio.create_subprocess_exec(
                "git",
                "status",
                "--porcelain",
                cwd=work_dir,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            stdout_data, _ = await process.communicate()
            output = stdout_data.decode("utf-8", errors="replace")

            # 변경된 파일 파싱
            files = []
            for line in output.split("\n"):
                if line.strip():
                    # 앞 2자(상태) 제거
                    file_path = line[3:].strip()
                    if file_path:
                        files.append(file_path)

            return files

        except Exception as e:
            logger.warning(f"Failed to get changed files: {e}")
            return []

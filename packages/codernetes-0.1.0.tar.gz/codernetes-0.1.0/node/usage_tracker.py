"""
API Usage Tracker for Node

Tracks Claude Code and Codex API usage locally during job execution.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import logging
from threading import Lock

logger = logging.getLogger(__name__)


@dataclass
class UsageRecord:
    """Single usage record"""

    timestamp: datetime
    provider: str  # 'claude' or 'codex'
    job_id: str
    operation: str  # e.g., 'chat', 'completion'
    tokens_prompt: int = 0
    tokens_completion: int = 0
    tokens_total: int = 0
    cost_usd: float = 0.0
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        """Convert to dictionary for storage/transmission"""
        return {
            "timestamp": self.timestamp.isoformat(),
            "provider": self.provider,
            "job_id": self.job_id,
            "operation": self.operation,
            "tokens_prompt": self.tokens_prompt,
            "tokens_completion": self.tokens_completion,
            "tokens_total": self.tokens_total,
            "cost_usd": self.cost_usd,
            "metadata": self.metadata,
        }


class UsageTracker:
    """
    Thread-safe usage tracker for API calls

    Usage:
        tracker = UsageTracker()

        # Record usage
        tracker.record(
            provider='claude',
            job_id='job-123',
            operation='chat',
            tokens_prompt=100,
            tokens_completion=200
        )

        # Get summary
        summary = tracker.get_summary()

        # Get records for reporting
        records = tracker.get_records_since(last_report_time)

        # Clear old records
        tracker.clear_old_records(days=7)
    """

    def __init__(self, node_id: str):
        self.node_id = node_id
        self.records: List[UsageRecord] = []
        self._lock = Lock()

    def record(
        self,
        provider: str,
        job_id: str,
        operation: str,
        tokens_prompt: int = 0,
        tokens_completion: int = 0,
        tokens_total: int = 0,
        cost_usd: float = 0.0,
        metadata: Optional[Dict] = None,
    ):
        """
        Record a single API usage event

        Args:
            provider: 'claude' or 'codex'
            job_id: Job ID this usage is associated with
            operation: Type of operation (e.g., 'chat', 'completion')
            tokens_prompt: Prompt tokens used
            tokens_completion: Completion tokens used
            tokens_total: Total tokens (if not calculated from prompt+completion)
            cost_usd: Estimated cost in USD
            metadata: Additional metadata
        """
        if tokens_total == 0:
            tokens_total = tokens_prompt + tokens_completion

        record = UsageRecord(
            timestamp=datetime.now(),
            provider=provider,
            job_id=job_id,
            operation=operation,
            tokens_prompt=tokens_prompt,
            tokens_completion=tokens_completion,
            tokens_total=tokens_total,
            cost_usd=cost_usd,
            metadata=metadata or {},
        )

        with self._lock:
            self.records.append(record)

        logger.debug(
            f"Recorded {provider} usage: {tokens_total} tokens for job {job_id}"
        )

    def get_summary(
        self, provider: Optional[str] = None, since: Optional[datetime] = None
    ) -> Dict:
        """
        Get usage summary

        Args:
            provider: Filter by provider ('claude' or 'codex'), None for all
            since: Only include records since this time, None for all time

        Returns:
            Dict with aggregated usage stats
        """
        with self._lock:
            filtered_records = self.records

            if provider:
                filtered_records = [
                    r for r in filtered_records if r.provider == provider
                ]

            if since:
                filtered_records = [r for r in filtered_records if r.timestamp >= since]

            total_requests = len(filtered_records)
            total_tokens = sum(r.tokens_total for r in filtered_records)
            total_prompt_tokens = sum(r.tokens_prompt for r in filtered_records)
            total_completion_tokens = sum(r.tokens_completion for r in filtered_records)
            total_cost = sum(r.cost_usd for r in filtered_records)

            # Group by job
            jobs = {}
            for record in filtered_records:
                if record.job_id not in jobs:
                    jobs[record.job_id] = {
                        "requests": 0,
                        "tokens": 0,
                        "cost": 0.0,
                    }
                jobs[record.job_id]["requests"] += 1
                jobs[record.job_id]["tokens"] += record.tokens_total
                jobs[record.job_id]["cost"] += record.cost_usd

            return {
                "node_id": self.node_id,
                "provider": provider or "all",
                "period_start": since.isoformat() if since else None,
                "period_end": datetime.now().isoformat(),
                "total_requests": total_requests,
                "total_tokens": total_tokens,
                "total_prompt_tokens": total_prompt_tokens,
                "total_completion_tokens": total_completion_tokens,
                "total_cost_usd": round(total_cost, 4),
                "jobs_count": len(jobs),
                "jobs": jobs,
            }

    def get_records_since(self, since: datetime) -> List[UsageRecord]:
        """Get all records since a given time"""
        with self._lock:
            return [r for r in self.records if r.timestamp >= since]

    def get_records_for_job(self, job_id: str) -> List[UsageRecord]:
        """Get all records for a specific job"""
        with self._lock:
            return [r for r in self.records if r.job_id == job_id]

    def clear_old_records(self, days: int = 7):
        """Clear records older than specified days"""
        cutoff = datetime.now() - timedelta(days=days)

        with self._lock:
            old_count = len(self.records)
            self.records = [r for r in self.records if r.timestamp >= cutoff]
            new_count = len(self.records)

        removed = old_count - new_count
        if removed > 0:
            logger.info(f"Cleared {removed} old usage records (older than {days} days)")

    def export_records(
        self, since: Optional[datetime] = None, provider: Optional[str] = None
    ) -> List[Dict]:
        """
        Export records as list of dicts for transmission to Master

        Args:
            since: Only export records since this time
            provider: Only export records for this provider

        Returns:
            List of record dicts
        """
        with self._lock:
            records = self.records

            if since:
                records = [r for r in records if r.timestamp >= since]

            if provider:
                records = [r for r in records if r.provider == provider]

            return [r.to_dict() for r in records]

    def get_current_stats(self) -> Dict:
        """
        Get current session stats (quick overview)

        Returns summary for current session (last 24 hours)
        """
        since = datetime.now() - timedelta(hours=24)

        claude_summary = self.get_summary(provider="claude", since=since)
        codex_summary = self.get_summary(provider="codex", since=since)

        return {
            "node_id": self.node_id,
            "session_start": since.isoformat(),
            "claude": {
                "requests": claude_summary["total_requests"],
                "tokens": claude_summary["total_tokens"],
                "cost_usd": claude_summary["total_cost_usd"],
            },
            "codex": {
                "requests": codex_summary["total_requests"],
                "tokens": codex_summary["total_tokens"],
                "cost_usd": codex_summary["total_cost_usd"],
            },
            "total": {
                "requests": claude_summary["total_requests"]
                + codex_summary["total_requests"],
                "tokens": claude_summary["total_tokens"]
                + codex_summary["total_tokens"],
                "cost_usd": claude_summary["total_cost_usd"]
                + codex_summary["total_cost_usd"],
            },
        }


# Global tracker instance (singleton pattern)
_global_tracker: Optional[UsageTracker] = None


def init_tracker(node_id: str) -> UsageTracker:
    """Initialize global tracker"""
    global _global_tracker
    _global_tracker = UsageTracker(node_id)
    logger.info(f"Initialized usage tracker for node {node_id}")
    return _global_tracker


def get_tracker() -> Optional[UsageTracker]:
    """Get global tracker instance"""
    return _global_tracker


def record_usage(
    provider: str,
    job_id: str,
    operation: str,
    tokens_prompt: int = 0,
    tokens_completion: int = 0,
    **kwargs,
):
    """
    Convenience function to record usage to global tracker

    Usage:
        from node.usage_tracker import record_usage

        record_usage(
            provider='claude',
            job_id=current_job_id,
            operation='chat',
            tokens_prompt=100,
            tokens_completion=200
        )
    """
    tracker = get_tracker()
    if tracker:
        tracker.record(
            provider=provider,
            job_id=job_id,
            operation=operation,
            tokens_prompt=tokens_prompt,
            tokens_completion=tokens_completion,
            **kwargs,
        )
    else:
        logger.warning("Usage tracker not initialized, skipping record")

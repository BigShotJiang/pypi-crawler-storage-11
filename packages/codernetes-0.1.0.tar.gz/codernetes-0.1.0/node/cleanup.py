"""
작업 디렉토리 정리 유틸리티

오래된 작업 디렉토리를 자동으로 정리합니다.
"""

import asyncio
import logging
import shutil
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class WorkspaceCleanup:
    """작업 디렉토리 자동 정리 관리자"""

    def __init__(
        self,
        workdir_root: Path,
        max_age_hours: int = 48,
        max_size_gb: float = 10.0,
        cleanup_interval_hours: float = 1.0,
    ):
        """
        Args:
            workdir_root: 작업 디렉토리 루트
            max_age_hours: 디렉토리 최대 보존 시간 (시간)
            max_size_gb: 전체 작업 디렉토리 최대 크기 (GB)
            cleanup_interval_hours: 정리 실행 주기 (시간)
        """
        self.workdir_root = Path(workdir_root)
        self.max_age_hours = max_age_hours
        self.max_age_seconds = max_age_hours * 3600
        self.max_size_bytes = int(max_size_gb * 1024 * 1024 * 1024)
        self.cleanup_interval_seconds = cleanup_interval_hours * 3600
        self._cleanup_task: Optional[asyncio.Task] = None
        self._running = False

    async def start(self):
        """정리 작업 시작"""
        if self._running:
            logger.warning("Cleanup already running")
            return

        self._running = True
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        logger.info(
            "Workspace cleanup started: max_age=%dh, max_size=%.1fGB, interval=%.1fh",
            self.max_age_hours,
            self.max_size_bytes / (1024**3),
            self.cleanup_interval_seconds / 3600,
        )

    async def stop(self):
        """정리 작업 중지"""
        if not self._running:
            return

        self._running = False
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        logger.info("Workspace cleanup stopped")

    async def _cleanup_loop(self):
        """정리 작업 루프"""
        try:
            while self._running:
                try:
                    await self.cleanup_once()
                except Exception as e:
                    logger.exception("Error during cleanup: %s", e)

                await asyncio.sleep(self.cleanup_interval_seconds)
        except asyncio.CancelledError:
            logger.debug("Cleanup loop cancelled")

    async def cleanup_once(self):
        """한 번의 정리 작업 실행"""
        if not self.workdir_root.exists():
            logger.debug("Workdir root does not exist: %s", self.workdir_root)
            return

        current_time = time.time()
        total_size = 0
        job_dirs: list[tuple[Path, float, int]] = []  # (path, mtime, size)

        # 모든 작업 디렉토리 스캔
        for job_dir in self.workdir_root.iterdir():
            if not job_dir.is_dir():
                continue

            try:
                mtime = job_dir.stat().st_mtime
                size = self._get_dir_size(job_dir)
                job_dirs.append((job_dir, mtime, size))
                total_size += size
            except Exception as e:
                logger.warning("Failed to stat directory %s: %s", job_dir, e)

        logger.debug(
            "Found %d job directories, total size: %.2f GB",
            len(job_dirs),
            total_size / (1024**3),
        )

        # 정리 대상 수집
        dirs_to_remove: list[Path] = []

        # 1. 오래된 디렉토리 수집
        for job_dir, mtime, size in job_dirs:
            age = current_time - mtime
            if age > self.max_age_seconds:
                dirs_to_remove.append(job_dir)
                logger.info(
                    "Marking old directory for removal: %s (age: %.1f hours)",
                    job_dir.name,
                    age / 3600,
                )

        # 2. 전체 크기가 초과하면 오래된 것부터 제거
        if total_size > self.max_size_bytes and len(job_dirs) > 0:
            # mtime 기준 오름차순 정렬 (오래된 것부터)
            sorted_dirs = sorted(job_dirs, key=lambda x: x[1])

            for job_dir, mtime, size in sorted_dirs:
                if job_dir in dirs_to_remove:
                    continue

                if total_size <= self.max_size_bytes:
                    break

                dirs_to_remove.append(job_dir)
                total_size -= size
                age = current_time - mtime
                logger.info(
                    "Marking directory for size limit: %s (age: %.1f hours, size: %.2f MB)",
                    job_dir.name,
                    age / 3600,
                    size / (1024**2),
                )

        # 디렉토리 제거
        removed_count = 0
        removed_size = 0
        for job_dir in dirs_to_remove:
            try:
                dir_size = self._get_dir_size(job_dir)
                await asyncio.to_thread(shutil.rmtree, job_dir)
                removed_count += 1
                removed_size += dir_size
                logger.info("Removed directory: %s", job_dir.name)
            except Exception as e:
                logger.error("Failed to remove directory %s: %s", job_dir.name, e)

        if removed_count > 0:
            logger.info(
                "Cleanup complete: removed %d directories, freed %.2f GB",
                removed_count,
                removed_size / (1024**3),
            )

    def _get_dir_size(self, path: Path) -> int:
        """디렉토리 크기 계산"""
        total_size = 0
        try:
            for item in path.rglob("*"):
                if item.is_file():
                    try:
                        total_size += item.stat().st_size
                    except Exception:
                        pass
        except Exception as e:
            logger.warning("Error calculating size for %s: %s", path, e)
        return total_size

    async def cleanup_specific_job(self, job_id: str):
        """특정 작업 디렉토리 정리"""
        job_dir = self.workdir_root / job_id
        if not job_dir.exists():
            logger.debug("Job directory does not exist: %s", job_id)
            return

        try:
            dir_size = self._get_dir_size(job_dir)
            await asyncio.to_thread(shutil.rmtree, job_dir)
            logger.info(
                "Removed job directory: %s (size: %.2f MB)",
                job_id,
                dir_size / (1024**2),
            )
        except Exception as e:
            logger.error("Failed to remove job directory %s: %s", job_id, e)

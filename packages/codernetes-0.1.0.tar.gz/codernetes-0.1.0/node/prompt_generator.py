"""
Enhanced Prompt Generator for Codernetes

This module generates intelligent, context-aware prompts for LLM agents
based on issue content, repository context, and workflow phase.
"""

from typing import Dict, Any, List, Optional
from pathlib import Path
from node.agent_context_manager import (
    AgentContext,
    WorkflowPhase,
    WorkflowState,
    AgentContextManager,
)
from models import Job, AgentConfig
import re


class PromptGenerator:
    """Generates enhanced prompts for LLM agents"""

    def __init__(self, context_manager: AgentContextManager):
        """Initialize prompt generator

        Args:
            context_manager: AgentContextManager instance
        """
        self.context_manager = context_manager

    def generate_prompt(
        self,
        job: Job,
        config: AgentConfig,
        context: AgentContext,
        workflow_state: Optional[WorkflowState] = None,
    ) -> str:
        """Generate an enhanced prompt based on context and workflow phase

        Args:
            job: Job object
            config: Agent configuration
            context: Agent context
            workflow_state: Current workflow state

        Returns:
            Enhanced prompt string
        """
        if not workflow_state:
            # Initial prompt for problem analysis
            return self._generate_initial_prompt(job, config, context)

        # Generate phase-specific prompt
        phase_generators = {
            WorkflowPhase.PROBLEM_ANALYSIS: self._generate_problem_analysis_prompt,
            WorkflowPhase.APPROACH_EXPLORATION: self._generate_approach_exploration_prompt,
            WorkflowPhase.SOLUTION_DESIGN: self._generate_solution_design_prompt,
            WorkflowPhase.IMPLEMENTATION: self._generate_implementation_prompt,
            WorkflowPhase.VERIFICATION: self._generate_verification_prompt,
            WorkflowPhase.FEEDBACK: self._generate_feedback_prompt,
            WorkflowPhase.COMPLETION: self._generate_completion_prompt,
        }

        generator = phase_generators.get(workflow_state.phase, self._generate_default_prompt)
        return generator(job, config, context, workflow_state)

    def _generate_initial_prompt(
        self,
        job: Job,
        config: AgentConfig,
        context: AgentContext,
    ) -> str:
        """Generate initial prompt for starting the workflow"""
        prompt_parts = []

        # System context
        prompt_parts.append("# Codernetes Agent Task")
        prompt_parts.append("")
        prompt_parts.append("You are a Codernetes agent tasked with solving a GitHub issue.")
        prompt_parts.append("This is a structured workflow that will proceed through multiple phases.")
        prompt_parts.append("")

        # Repository context
        prompt_parts.append("## Repository Context")
        prompt_parts.append(f"**Repository**: {context.repository}")

        if context.repository_context:
            tech = context.repository_context.get("technologies", {})
            if tech.get("languages"):
                prompt_parts.append(f"**Languages**: {', '.join(tech['languages'])}")
            if tech.get("frameworks"):
                prompt_parts.append(f"**Frameworks**: {', '.join(tech['frameworks'])}")

            conventions = context.repository_context.get("conventions", {})
            if conventions.get("testing"):
                prompt_parts.append(f"**Test Frameworks**: {', '.join(conventions['testing'])}")
        prompt_parts.append("")

        # Issue information
        if job.issue_number:
            prompt_parts.append(f"## Issue #{job.issue_number}: {job.issue_title}")
        else:
            prompt_parts.append(f"## Task: {job.issue_title or job.prompt}")

        if job.issue_body:
            prompt_parts.append("")
            prompt_parts.append("### Description")
            prompt_parts.append(job.issue_body)
        prompt_parts.append("")

        # Enhanced issue analysis
        prompt_parts.append("## Initial Analysis Required")
        prompt_parts.append("")
        prompt_parts.append("Please analyze this issue and provide:")
        prompt_parts.append("1. **Problem Understanding**: What is the core problem to solve?")
        prompt_parts.append("2. **Impact Assessment**: What parts of the system will be affected?")
        prompt_parts.append("3. **Technical Requirements**: What technical changes are needed?")
        prompt_parts.append("4. **Success Criteria**: How will we know the issue is resolved?")
        prompt_parts.append("5. **Potential Challenges**: What difficulties might we encounter?")
        prompt_parts.append("")

        # Apply preset if configured
        if context.preset:
            preset = self.context_manager.load_presets().get(context.preset)
            if preset:
                prompt_parts.append("## Preset Instructions")
                prompt_parts.append(preset.get("instructions", ""))
                prompt_parts.append("")

        # System prompt from config
        if config.system_prompt:
            prompt_parts.append("## Additional Instructions")
            prompt_parts.append(config.system_prompt)
            prompt_parts.append("")

        return "\n".join(prompt_parts)

    def _generate_problem_analysis_prompt(
        self,
        job: Job,
        config: AgentConfig,
        context: AgentContext,
        workflow_state: WorkflowState,
    ) -> str:
        """Generate prompt for problem analysis phase"""
        prompt_parts = []

        prompt_parts.append("# Phase 1: Problem Analysis")
        prompt_parts.append("")
        prompt_parts.append("Based on the issue description, let's thoroughly analyze the problem.")
        prompt_parts.append("")

        # Include previous context if resuming
        if workflow_state.progress:
            prompt_parts.append("## Previous Analysis")
            for key, value in workflow_state.progress.items():
                prompt_parts.append(f"- **{key}**: {value}")
            prompt_parts.append("")

        # Specific analysis questions
        prompt_parts.append("## Analysis Tasks")
        prompt_parts.append("")
        prompt_parts.append("1. **Root Cause**: What is causing this issue?")
        prompt_parts.append("2. **Scope**: Which files and components need modification?")
        prompt_parts.append("3. **Dependencies**: What other parts of the system interact with these components?")
        prompt_parts.append("4. **Edge Cases**: What edge cases should we consider?")
        prompt_parts.append("5. **Testing Strategy**: How should we test the solution?")
        prompt_parts.append("")

        # Extract technical keywords from issue
        keywords = self._extract_technical_keywords(job.issue_body or job.prompt)
        if keywords:
            prompt_parts.append("## Detected Technical Elements")
            prompt_parts.append(f"Focus on these technical aspects: {', '.join(keywords)}")
            prompt_parts.append("")

        return "\n".join(prompt_parts)

    def _generate_approach_exploration_prompt(
        self,
        job: Job,
        config: AgentConfig,
        context: AgentContext,
        workflow_state: WorkflowState,
    ) -> str:
        """Generate prompt for approach exploration phase"""
        prompt_parts = []

        prompt_parts.append("# Phase 2: Approach Exploration")
        prompt_parts.append("")
        prompt_parts.append("Let's explore different approaches to solve this problem.")
        prompt_parts.append("")

        # Include decisions from problem analysis
        if workflow_state.decisions:
            prompt_parts.append("## Problem Analysis Summary")
            for decision in workflow_state.decisions[-3:]:  # Last 3 decisions
                prompt_parts.append(f"- {decision.get('description', 'Decision')}: {decision.get('choice', 'N/A')}")
            prompt_parts.append("")

        prompt_parts.append("## Approach Evaluation")
        prompt_parts.append("")
        prompt_parts.append("Consider and evaluate multiple approaches:")
        prompt_parts.append("1. **Approach A**: [Describe the first approach]")
        prompt_parts.append("   - Pros: [List advantages]")
        prompt_parts.append("   - Cons: [List disadvantages]")
        prompt_parts.append("   - Effort: [Low/Medium/High]")
        prompt_parts.append("")
        prompt_parts.append("2. **Approach B**: [Describe alternative approach]")
        prompt_parts.append("   - Pros: [List advantages]")
        prompt_parts.append("   - Cons: [List disadvantages]")
        prompt_parts.append("   - Effort: [Low/Medium/High]")
        prompt_parts.append("")
        prompt_parts.append("3. **Recommendation**: Which approach should we take and why?")
        prompt_parts.append("")

        return "\n".join(prompt_parts)

    def _generate_solution_design_prompt(
        self,
        job: Job,
        config: AgentConfig,
        context: AgentContext,
        workflow_state: WorkflowState,
    ) -> str:
        """Generate prompt for solution design phase"""
        prompt_parts = []

        prompt_parts.append("# Phase 3: Solution Design")
        prompt_parts.append("")
        prompt_parts.append("Design the detailed solution based on the chosen approach.")
        prompt_parts.append("")

        # Include chosen approach
        if workflow_state.decisions:
            latest_decision = workflow_state.decisions[-1]
            prompt_parts.append("## Selected Approach")
            prompt_parts.append(f"{latest_decision.get('description', 'Approach')}: {latest_decision.get('choice', 'N/A')}")
            if 'reasoning' in latest_decision:
                prompt_parts.append(f"Reasoning: {latest_decision['reasoning']}")
            prompt_parts.append("")

        prompt_parts.append("## Design Specification")
        prompt_parts.append("")
        prompt_parts.append("Provide a detailed design including:")
        prompt_parts.append("1. **Component Changes**: List each component/file to be modified")
        prompt_parts.append("2. **Data Flow**: How data will flow through the system")
        prompt_parts.append("3. **API Changes**: Any API modifications needed")
        prompt_parts.append("4. **Database Changes**: Schema or query modifications")
        prompt_parts.append("5. **Error Handling**: How errors will be handled")
        prompt_parts.append("6. **Testing Plan**: Specific test cases to implement")
        prompt_parts.append("")

        return "\n".join(prompt_parts)

    def _generate_implementation_prompt(
        self,
        job: Job,
        config: AgentConfig,
        context: AgentContext,
        workflow_state: WorkflowState,
    ) -> str:
        """Generate prompt for implementation phase"""
        prompt_parts = []

        prompt_parts.append("# Phase 4: Implementation")
        prompt_parts.append("")
        prompt_parts.append("Implement the solution according to the design specification.")
        prompt_parts.append("")

        # Include design summary
        if workflow_state.artifacts:
            prompt_parts.append("## Design Artifacts")
            for artifact in workflow_state.artifacts[-3:]:  # Last 3 artifacts
                prompt_parts.append(f"- {artifact}")
            prompt_parts.append("")

        prompt_parts.append("## Implementation Guidelines")
        prompt_parts.append("")

        # Add technology-specific guidelines
        if context.repository_context:
            tech = context.repository_context.get("technologies", {})
            if "Python" in tech.get("languages", []):
                prompt_parts.append("### Python Guidelines")
                prompt_parts.append("- Follow PEP 8 style guide")
                prompt_parts.append("- Use type hints where appropriate")
                prompt_parts.append("- Include docstrings for functions and classes")
                prompt_parts.append("")

            if "JavaScript/TypeScript" in tech.get("languages", []):
                prompt_parts.append("### JavaScript/TypeScript Guidelines")
                prompt_parts.append("- Use ES6+ features")
                prompt_parts.append("- Maintain consistent code style")
                prompt_parts.append("- Add JSDoc comments for functions")
                prompt_parts.append("")

        prompt_parts.append("## Implementation Steps")
        prompt_parts.append("")
        prompt_parts.append("1. Create/modify the necessary files")
        prompt_parts.append("2. Implement the core functionality")
        prompt_parts.append("3. Add error handling and validation")
        prompt_parts.append("4. Write or update tests")
        prompt_parts.append("5. Update documentation if needed")
        prompt_parts.append("")

        # Protected paths warning
        if config.protected_paths:
            prompt_parts.append("## Protected Paths (DO NOT MODIFY)")
            for path in config.protected_paths:
                prompt_parts.append(f"- {path}")
            prompt_parts.append("")

        return "\n".join(prompt_parts)

    def _generate_verification_prompt(
        self,
        job: Job,
        config: AgentConfig,
        context: AgentContext,
        workflow_state: WorkflowState,
    ) -> str:
        """Generate prompt for verification phase"""
        prompt_parts = []

        prompt_parts.append("# Phase 5: Verification")
        prompt_parts.append("")
        prompt_parts.append("Verify that the implementation solves the original issue.")
        prompt_parts.append("")

        prompt_parts.append("## Verification Checklist")
        prompt_parts.append("")
        prompt_parts.append("- [ ] Original issue requirements are met")
        prompt_parts.append("- [ ] All tests pass")
        prompt_parts.append("- [ ] No regression in existing functionality")
        prompt_parts.append("- [ ] Code follows project conventions")
        prompt_parts.append("- [ ] Documentation is updated")
        prompt_parts.append("")

        # Testing requirements
        if config.testing.required:
            prompt_parts.append("## Testing Requirements")
            if config.testing.command:
                prompt_parts.append(f"Run tests with: `{config.testing.command}`")
            if config.testing.coverage_threshold:
                prompt_parts.append(f"Coverage threshold: {config.testing.coverage_threshold}%")
            prompt_parts.append("")

        prompt_parts.append("## Verification Steps")
        prompt_parts.append("")
        prompt_parts.append("1. Run the test suite")
        prompt_parts.append("2. Manually test the specific issue scenario")
        prompt_parts.append("3. Check for any unintended side effects")
        prompt_parts.append("4. Validate code quality and style")
        prompt_parts.append("")

        return "\n".join(prompt_parts)

    def _generate_feedback_prompt(
        self,
        job: Job,
        config: AgentConfig,
        context: AgentContext,
        workflow_state: WorkflowState,
    ) -> str:
        """Generate prompt for feedback phase"""
        prompt_parts = []

        prompt_parts.append("# Phase 6: Feedback Collection")
        prompt_parts.append("")
        prompt_parts.append("Collect feedback and prepare for review.")
        prompt_parts.append("")

        prompt_parts.append("## Self-Assessment")
        prompt_parts.append("")
        prompt_parts.append("1. **Solution Quality**: How well does this solve the problem? (1-10)")
        prompt_parts.append("2. **Code Quality**: How maintainable is the code? (1-10)")
        prompt_parts.append("3. **Test Coverage**: How comprehensive are the tests? (1-10)")
        prompt_parts.append("4. **Documentation**: How well documented is the change? (1-10)")
        prompt_parts.append("")

        prompt_parts.append("## Areas for Improvement")
        prompt_parts.append("")
        prompt_parts.append("List any areas that could be improved:")
        prompt_parts.append("- [ ] [Improvement area 1]")
        prompt_parts.append("- [ ] [Improvement area 2]")
        prompt_parts.append("")

        prompt_parts.append("## Pull Request Description")
        prompt_parts.append("")
        prompt_parts.append("Generate a comprehensive PR description including:")
        prompt_parts.append("- Problem statement")
        prompt_parts.append("- Solution approach")
        prompt_parts.append("- Changes made")
        prompt_parts.append("- Testing performed")
        prompt_parts.append("- Any breaking changes or considerations")
        prompt_parts.append("")

        return "\n".join(prompt_parts)

    def _generate_completion_prompt(
        self,
        job: Job,
        config: AgentConfig,
        context: AgentContext,
        workflow_state: WorkflowState,
    ) -> str:
        """Generate prompt for completion phase"""
        prompt_parts = []

        prompt_parts.append("# Phase 7: Completion")
        prompt_parts.append("")
        prompt_parts.append("Final review and completion of the task.")
        prompt_parts.append("")

        prompt_parts.append("## Final Checklist")
        prompt_parts.append("")
        prompt_parts.append("- [ ] All changes are committed")
        prompt_parts.append("- [ ] Code is properly formatted")
        prompt_parts.append("- [ ] Tests are passing")
        prompt_parts.append("- [ ] Documentation is complete")
        prompt_parts.append("- [ ] PR description is comprehensive")
        prompt_parts.append("")

        prompt_parts.append("## Summary")
        prompt_parts.append("")
        prompt_parts.append("Provide a final summary of:")
        prompt_parts.append("1. What was accomplished")
        prompt_parts.append("2. Key decisions made")
        prompt_parts.append("3. Any remaining considerations")
        prompt_parts.append("4. Recommendations for future improvements")
        prompt_parts.append("")

        return "\n".join(prompt_parts)

    def _generate_default_prompt(
        self,
        job: Job,
        config: AgentConfig,
        context: AgentContext,
        workflow_state: WorkflowState,
    ) -> str:
        """Generate default prompt for unknown phases"""
        prompt_parts = []

        prompt_parts.append(f"# Workflow Phase: {workflow_state.phase.value}")
        prompt_parts.append("")
        prompt_parts.append("Continue with the task based on the current workflow state.")
        prompt_parts.append("")

        if workflow_state.progress:
            prompt_parts.append("## Current Progress")
            for key, value in workflow_state.progress.items():
                prompt_parts.append(f"- **{key}**: {value}")
            prompt_parts.append("")

        # Add original task
        prompt_parts.append("## Original Task")
        prompt_parts.append(job.prompt)
        prompt_parts.append("")

        return "\n".join(prompt_parts)

    def _extract_technical_keywords(self, text: str) -> List[str]:
        """Extract technical keywords from issue text"""
        if not text:
            return []

        # Common technical patterns
        patterns = [
            r'\b(API|REST|GraphQL|HTTP|HTTPS|WebSocket)\b',
            r'\b(React|Vue|Angular|Next\.js|Node\.js|Express|FastAPI|Django)\b',
            r'\b(Docker|Kubernetes|CI/CD|GitHub|GitLab)\b',
            r'\b(PostgreSQL|MySQL|MongoDB|Redis|SQLite)\b',
            r'\b(authentication|authorization|JWT|OAuth|SSO)\b',
            r'\b(async|await|promise|callback|observable)\b',
            r'\b(component|service|controller|model|view)\b',
            r'\b(test|spec|unit|integration|e2e)\b',
        ]

        keywords = set()
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            keywords.update(matches)

        return list(keywords)
"""Credential storage and management for node API clients."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

LOGGER = logging.getLogger(__name__)


class CredentialStore:
    """Manage API credentials for the node."""

    def __init__(self):
        """Initialize credential store."""
        self._credentials: dict[str, dict[str, Any]] = {}

    def get_token(self, provider: str) -> str | None:
        """
        Get access token for provider.

        Args:
            provider: Provider name (github, linear, etc.)

        Returns:
            Access token string or None if not found
        """
        cred = self._credentials.get(provider)
        if not cred:
            return None

        # Check expiry if available
        expires_at = cred.get("expires_at")
        if expires_at:
            try:
                expiry = datetime.fromisoformat(expires_at)
                if expiry < datetime.now(timezone.utc):
                    LOGGER.warning(f"Token for {provider} has expired")
                    return None
            except (ValueError, TypeError):
                pass

        return cred.get("access_token")

    def set_token(
        self,
        provider: str,
        access_token: str,
        refresh_token: str | None = None,
        expires_at: str | None = None,
        **kwargs,
    ):
        """
        Store token for provider.

        Args:
            provider: Provider name (github, linear, etc.)
            access_token: Access token string
            refresh_token: Optional refresh token
            expires_at: Optional expiry timestamp (ISO format)
            **kwargs: Additional metadata
        """
        self._credentials[provider] = {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "expires_at": expires_at,
            "updated_at": datetime.now(timezone.utc).isoformat(),
            **kwargs,
        }
        LOGGER.info(f"Stored credentials for {provider}")

    def has_token(self, provider: str) -> bool:
        """
        Check if token exists for provider.

        Args:
            provider: Provider name

        Returns:
            True if valid token exists, False otherwise
        """
        return self.get_token(provider) is not None

    def remove_token(self, provider: str):
        """
        Remove token for provider.

        Args:
            provider: Provider name
        """
        if provider in self._credentials:
            del self._credentials[provider]
            LOGGER.info(f"Removed credentials for {provider}")

    def list_providers(self) -> list[str]:
        """
        List all providers with stored credentials.

        Returns:
            List of provider names
        """
        return list(self._credentials.keys())

    def load_from_env(self):
        """Load credentials from environment variables."""
        import os

        # GitHub token
        github_token = os.getenv("NODE_GITHUB_TOKEN") or os.getenv("GITHUB_TOKEN")
        if github_token:
            self.set_token("github", github_token)
            LOGGER.info("Loaded GitHub token from environment")

        # Linear token
        linear_token = os.getenv("NODE_LINEAR_TOKEN") or os.getenv("LINEAR_TOKEN")
        if linear_token:
            self.set_token("linear", linear_token)
            LOGGER.info("Loaded Linear token from environment")

    def load_from_dict(self, credentials: dict[str, dict[str, Any]]):
        """
        Load credentials from dictionary.

        Args:
            credentials: Dictionary of provider -> credential data
        """
        for provider, cred_data in credentials.items():
            if isinstance(cred_data, dict) and "access_token" in cred_data:
                self.set_token(
                    provider=provider,
                    access_token=cred_data["access_token"],
                    refresh_token=cred_data.get("refresh_token"),
                    expires_at=cred_data.get("expires_at"),
                )

    def to_dict(self) -> dict[str, dict[str, Any]]:
        """
        Export credentials as dictionary.

        Returns:
            Dictionary of provider -> credential data
        """
        return dict(self._credentials)

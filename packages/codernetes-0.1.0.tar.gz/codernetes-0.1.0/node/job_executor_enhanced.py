"""
Enhanced Job Executor with Context Management and Workflow Phases

This is an enhanced version of JobExecutor that integrates with the
AgentContextManager and PromptGenerator for better task execution.
"""

import os
import asyncio
import uuid
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime
import logging

from models import Job, JobStatus, JobExecutionResult, AgentConfig
from node.git_workflow import GitWorkflow
from node.agent_executor import AgentExecutor
from node.pr_manager import PRManager
from node.agent_context_manager import (
    AgentContextManager,
    WorkflowPhase,
    WorkflowState,
)
from node.prompt_generator import PromptGenerator
from master.error_handler import get_error_handler

logger = logging.getLogger(__name__)


class EnhancedJobExecutor:
    """Enhanced job executor with context management and workflow phases"""

    def __init__(
        self,
        jobs_work_dir: Path = None,
        github_token: str = None,
        fallback_command: str = None,
        enable_workflow_phases: bool = True,
    ):
        """Initialize enhanced job executor

        Args:
            jobs_work_dir: Directory for job workspaces
            github_token: GitHub personal access token
            fallback_command: Fallback command if agent fails
            enable_workflow_phases: Enable structured workflow phases
        """
        # Default work directory
        if jobs_work_dir is None:
            jobs_work_dir = Path("var/jobs")
        self.jobs_work_dir = Path(jobs_work_dir)
        self.jobs_work_dir.mkdir(parents=True, exist_ok=True)

        # GitHub token
        self.github_token = github_token or os.getenv("GITHUB_TOKEN")

        # PR Manager (if GitHub token available)
        self.pr_manager = PRManager(self.github_token) if self.github_token else None
        self.fallback_command = fallback_command

        # Workflow phases feature flag
        self.enable_workflow_phases = enable_workflow_phases

    async def execute_job(
        self,
        job: Job,
        status_callback: Optional[callable] = None,
        resume_session: bool = False,
    ) -> JobExecutionResult:
        """Execute job with enhanced context management

        Args:
            job: Job object to execute
            status_callback: Status update callback function (async)
            resume_session: Whether to resume a previous session

        Returns:
            JobExecutionResult object
        """
        logger.info(f"Starting enhanced job execution: {job.job_id}")

        # Create work directory
        work_dir = self.jobs_work_dir / job.job_id
        work_dir.mkdir(parents=True, exist_ok=True)

        git_workflow: Optional[GitWorkflow] = None
        context_manager: Optional[AgentContextManager] = None
        current_phase = "initializing"
        session_id = str(uuid.uuid4())

        try:
            # Status: ACCEPTED
            current_phase = "accepted"
            await self._update_status(JobStatus.ACCEPTED, job, status_callback)

            # 1. Git Clone
            current_phase = "cloning"
            await self._update_status(JobStatus.CLONING, job, status_callback)
            git_workflow = await self._clone_repository(job, work_dir)

            # 2. Create branch
            current_phase = "creating_branch"
            branch_name = self._generate_branch_name(job)
            await git_workflow.create_branch(branch_name)

            # 3. Initialize context manager
            current_phase = "initializing_context"
            context_manager = AgentContextManager(work_dir)

            # Load or create context
            context = context_manager.initialize_context(
                repository=f"{job.repo_owner}/{job.repo_name}",
                issue_number=job.issue_number,
                issue_title=job.issue_title or job.prompt[:100],
                issue_body=job.issue_body or job.prompt,
                preset=job.preset if hasattr(job, 'preset') else None,
            )

            # 4. Load agent config
            current_phase = "loading_config"
            config = AgentConfig.from_directory(work_dir)
            logger.info(f"Agent config loaded: {config.agent_type}")

            # 5. Execute with workflow phases or direct execution
            if self.enable_workflow_phases and not job.direct_mode:
                result = await self._execute_with_workflow(
                    job, work_dir, config, context_manager, context, session_id, status_callback
                )
            else:
                result = await self._execute_direct(
                    job, work_dir, config, context_manager, context, status_callback
                )

            if not result.success:
                if self.fallback_command:
                    logger.warning(
                        "Primary agent failed (%s). Trying fallback command.",
                        result.error_message,
                    )
                    result = await self._execute_fallback_command(
                        job, work_dir, git_workflow, config
                    )
                if not result.success:
                    raise Exception(f"Agent execution failed: {result.error_message}")

            # 6. Commit changes
            current_phase = "committing"
            await self._update_status(JobStatus.COMMITTING, job, status_callback)
            commit_sha = await self._commit_changes(job, git_workflow, config)

            pr_info = None

            # 7. Push
            current_phase = "pushing"
            await self._update_status(JobStatus.PUSHING, job, status_callback)
            await git_workflow.push(branch_name)

            # 8. Create PR (if possible)
            if self.pr_manager and job.repo_owner and job.repo_name:
                current_phase = "pr_creating"
                await self._update_status(JobStatus.PR_CREATING, job, status_callback)
                pr_info = await self._create_pull_request(
                    job, branch_name, result.files_changed, commit_sha
                )
                final_status = JobStatus.PR_CREATED
                logger.info(f"Job {job.job_id} completed successfully. PR: {pr_info['url']}")
            else:
                logger.info("Skipping PR creation (missing GitHub token or repository information)")
                final_status = JobStatus.SUCCEEDED

            # 9. Complete
            current_phase = "completed"
            await self._update_status(final_status, job, status_callback)

            # Save final session
            if context_manager:
                context_manager.save_session({
                    "job_id": job.job_id,
                    "session_id": session_id,
                    "status": "completed",
                    "pr_url": pr_info["url"] if pr_info else None,
                    "commit_sha": commit_sha,
                })

            return JobExecutionResult(
                success=True,
                job_id=job.job_id,
                status=final_status,
                pr_number=pr_info["number"] if pr_info else None,
                pr_url=pr_info["url"] if pr_info else None,
                commit_sha=commit_sha,
                files_changed=len(result.files_changed),
                work_dir=str(work_dir),
            )

        except Exception as e:
            logger.exception(f"Job {job.job_id} failed at phase: {current_phase}")

            # Save error session
            if context_manager:
                context_manager.save_session({
                    "job_id": job.job_id,
                    "session_id": session_id,
                    "status": "failed",
                    "error": str(e),
                    "phase": current_phase,
                })

            # Use error handler
            error_handler = get_error_handler()
            error_context = {
                "phase": current_phase,
                "work_dir": str(work_dir),
                "job_id": job.job_id,
            }

            current_retry_count = getattr(job, 'retry_count', 0)

            handling_result = await error_handler.handle_error(
                job_id=job.job_id,
                error=e,
                context=error_context,
                current_retry_count=current_retry_count,
            )

            if not handling_result["should_retry"]:
                await self._update_status(JobStatus.FAILED, job, status_callback)

            return JobExecutionResult(
                success=False,
                job_id=job.job_id,
                status=JobStatus.FAILED,
                error_message=str(e),
                error_info=handling_result["error_info"],
                should_retry=handling_result["should_retry"],
                retry_after=handling_result["retry_after"],
                work_dir=str(work_dir),
            )

        finally:
            # Cleanup (optional)
            if git_workflow:
                try:
                    # Keep work directory for debugging
                    pass
                except Exception as e:
                    logger.warning(f"Failed to cleanup: {e}")

    async def _execute_with_workflow(
        self,
        job: Job,
        work_dir: Path,
        config: AgentConfig,
        context_manager: AgentContextManager,
        context,
        session_id: str,
        status_callback: Optional[callable] = None,
    ):
        """Execute job with structured workflow phases"""
        logger.info(f"Executing job {job.job_id} with workflow phases")

        # Initialize workflow
        workflow_state = context_manager.start_workflow(session_id)

        # Initialize prompt generator
        prompt_gen = PromptGenerator(context_manager)

        # Phases to execute
        phases = [
            WorkflowPhase.PROBLEM_ANALYSIS,
            WorkflowPhase.APPROACH_EXPLORATION,
            WorkflowPhase.SOLUTION_DESIGN,
            WorkflowPhase.IMPLEMENTATION,
            WorkflowPhase.VERIFICATION,
            WorkflowPhase.FEEDBACK,
            WorkflowPhase.COMPLETION,
        ]

        # Agent executor
        agent_type = job.agent_type or config.agent_type or "claude-code"
        executor = AgentExecutor(agent_type=agent_type)

        accumulated_changes = []
        phase_results = {}

        for phase in phases:
            logger.info(f"Executing phase: {phase.value}")

            # Update workflow phase
            workflow_state = context_manager.update_workflow_phase(
                phase=phase,
                progress={"status": "started"},
            )

            # Generate phase-specific prompt
            prompt = prompt_gen.generate_prompt(job, config, context, workflow_state)

            # Execute agent with phase prompt
            result = await executor.execute(
                work_dir=work_dir,
                prompt=prompt,
                config=config,
                timeout=1800,  # 30 minutes per phase
            )

            # Save phase result
            phase_results[phase.value] = {
                "success": result.success,
                "files_changed": result.files_changed,
                "stdout": result.stdout[:1000] if result.stdout else None,  # First 1000 chars
                "error": result.error_message,
            }

            # Update workflow with result
            context_manager.update_workflow_phase(
                phase=phase,
                progress={"status": "completed", "success": result.success},
                decision={
                    "description": f"Phase {phase.value} execution",
                    "choice": "completed" if result.success else "failed",
                    "reasoning": result.stdout[:500] if result.stdout else result.error_message,
                },
                artifact=f"phase_{phase.value}_result.json",
            )

            # Accumulate file changes
            if result.files_changed:
                accumulated_changes.extend(result.files_changed)

            # Update status for key phases
            if phase == WorkflowPhase.IMPLEMENTATION:
                await self._update_status(JobStatus.AGENT_WORKING, job, status_callback)

            # Stop on critical phase failures
            if not result.success and phase in [
                WorkflowPhase.PROBLEM_ANALYSIS,
                WorkflowPhase.IMPLEMENTATION,
            ]:
                logger.error(f"Critical phase {phase.value} failed")
                return result

        # Return combined result
        return type('AgentResult', (), {
            'success': all(r["success"] for r in phase_results.values()),
            'files_changed': list(set(accumulated_changes)),
            'error_message': next(
                (r["error"] for r in phase_results.values() if not r["success"]),
                None
            ),
            'stdout': "\n".join(
                f"[{p}]: {r.get('stdout', 'No output')[:200]}"
                for p, r in phase_results.items()
            ),
        })

    async def _execute_direct(
        self,
        job: Job,
        work_dir: Path,
        config: AgentConfig,
        context_manager: AgentContextManager,
        context,
        status_callback: Optional[callable] = None,
    ):
        """Execute job directly without workflow phases"""
        logger.info(f"Executing job {job.job_id} in direct mode")

        # Initialize prompt generator
        prompt_gen = PromptGenerator(context_manager)

        # Generate enhanced prompt
        prompt = prompt_gen.generate_prompt(job, config, context, None)

        # Agent executor
        agent_type = job.agent_type or config.agent_type or "claude-code"
        executor = AgentExecutor(agent_type=agent_type)

        # Update status
        await self._update_status(JobStatus.AGENT_WORKING, job, status_callback)

        # Execute agent
        result = await executor.execute(
            work_dir=work_dir,
            prompt=prompt,
            config=config,
            timeout=3600,  # 1 hour
        )

        if not result.success:
            logger.error(f"Agent execution failed: {result.error_message}")

        return result

    async def _clone_repository(self, job: Job, work_dir: Path) -> GitWorkflow:
        """Clone repository"""
        git_workflow = GitWorkflow(work_dir)

        repo_url = job.repo_url
        if not repo_url and job.repo_owner and job.repo_name:
            if self.github_token:
                repo_url = f"https://{self.github_token}@github.com/{job.repo_owner}/{job.repo_name}.git"
            else:
                repo_url = f"https://github.com/{job.repo_owner}/{job.repo_name}.git"

        if not repo_url:
            raise ValueError("Repository URL not provided and cannot be constructed")

        await git_workflow.clone(repo_url)
        logger.info(f"Repository cloned: {repo_url}")

        return git_workflow

    def _generate_branch_name(self, job: Job) -> str:
        """Generate branch name"""
        # Use branch_name from job if provided (e.g., from Linear integration)
        if job.branch_name:
            return job.branch_name

        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")

        if job.issue_number:
            branch_name = f"codernetes/issue-{job.issue_number}-{timestamp}"
        else:
            short_id = job.job_id.split('-')[0]
            branch_name = f"codernetes/job-{short_id}-{timestamp}"

        return branch_name

    async def _commit_changes(
        self, job: Job, git_workflow: GitWorkflow, config: AgentConfig
    ) -> str:
        """Commit changes"""
        if config.auto_commit:
            message = config.commit_message.format(
                issue_number=job.issue_number or "N/A",
                issue_title=job.issue_title or job.prompt[:50],
            )
        else:
            if job.issue_number and job.issue_title:
                message = f"Fix #{job.issue_number}: {job.issue_title}"
            else:
                message = f"Codernetes: {job.prompt[:100]}"

        commit_sha = await git_workflow.commit(message)
        logger.info(f"Changes committed: {commit_sha}")

        return commit_sha

    async def _create_pull_request(
        self,
        job: Job,
        branch_name: str,
        files_changed: list,
        commit_sha: str,
    ) -> Dict[str, Any]:
        """Create pull request"""
        if job.issue_number and job.issue_title:
            pr_title = f"Fix #{job.issue_number}: {job.issue_title}"
        else:
            pr_title = f"Codernetes: {job.prompt[:100]}"

        pr_body_parts = []

        if job.issue_number:
            pr_body_parts.append(f"Fixes #{job.issue_number}")
            pr_body_parts.append("")

        pr_body_parts.append("## Description")
        pr_body_parts.append(job.issue_body or job.prompt)
        pr_body_parts.append("")

        pr_body_parts.append("## Changes")
        if files_changed:
            for file_path in files_changed[:10]:
                pr_body_parts.append(f"- Modified: `{file_path}`")
            if len(files_changed) > 10:
                pr_body_parts.append(f"- ... and {len(files_changed) - 10} more files")
        pr_body_parts.append("")

        pr_body_parts.append("## Metadata")
        pr_body_parts.append(f"- Job ID: {job.job_id}")
        pr_body_parts.append(f"- Commit: {commit_sha}")
        pr_body_parts.append(f"- Agent: {job.agent_type or 'default'}")
        pr_body_parts.append("")
        pr_body_parts.append("---")
        pr_body_parts.append("*This PR was automatically generated by Codernetes*")

        pr_body = "\n".join(pr_body_parts)

        pr_info = await self.pr_manager.create_pr(
            owner=job.repo_owner,
            repo=job.repo_name,
            title=pr_title,
            body=pr_body,
            head=branch_name,
            base=job.base_branch or "main",
        )

        logger.info(f"PR created: {pr_info['url']}")
        return pr_info

    async def _execute_fallback_command(
        self,
        job: Job,
        work_dir: Path,
        git_workflow: GitWorkflow,
        config: AgentConfig,
    ) -> object:
        """Execute fallback command"""
        logger.info(f"Executing fallback command: {self.fallback_command}")

        import subprocess

        try:
            # Prepare command
            command = self.fallback_command.format(
                prompt=job.prompt,
                issue_number=job.issue_number or "",
                issue_title=job.issue_title or "",
            )

            # Execute command
            process = await asyncio.create_subprocess_shell(
                command,
                cwd=work_dir,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=3600)

            # Get changed files
            files_changed = await git_workflow.get_changed_files()

            success = process.returncode == 0

            return type('AgentResult', (), {
                'success': success,
                'stdout': stdout.decode("utf-8") if stdout else "",
                'stderr': stderr.decode("utf-8") if stderr else "",
                'files_changed': files_changed,
                'exit_code': process.returncode,
                'error_message': stderr.decode("utf-8") if not success else None,
            })

        except asyncio.TimeoutError:
            logger.error("Fallback command timed out")
            return type('AgentResult', (), {
                'success': False,
                'error_message': "Fallback command timed out",
                'files_changed': [],
            })
        except Exception as e:
            logger.exception("Fallback command failed")
            return type('AgentResult', (), {
                'success': False,
                'error_message': str(e),
                'files_changed': [],
            })

    async def _update_status(
        self,
        status: JobStatus,
        job: Job,
        status_callback: Optional[callable] = None,
    ):
        """Update job status"""
        if status_callback:
            try:
                await status_callback(job.job_id, status)
            except Exception as e:
                logger.warning(f"Failed to update status: {e}")
        else:
            logger.info(f"Job {job.job_id} status: {status.value}")
"""Node setup CLI for configuring authentication."""

from __future__ import annotations

import asyncio
import getpass
import socket
import sys
from typing import Any

import aiohttp

from .config import NodeConfig


async def verify_credentials(master_url: str, user_id: str, password: str) -> dict[str, Any] | None:
    """Verify user credentials with master server.

    Args:
        master_url: Master server URL
        user_id: User ID
        password: User password

    Returns:
        Response data with auth_token if successful, None otherwise
    """
    verify_url = f"{master_url.rstrip('/')}/api/auth/verify"

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                verify_url,
                json={"user_id": user_id, "password": password},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as response:
                if response.status == 200:
                    return await response.json()
                elif response.status == 401:
                    print("❌ Authentication failed: Invalid credentials")
                    return None
                elif response.status == 403:
                    print("❌ Authentication failed: User account is inactive")
                    return None
                else:
                    text = await response.text()
                    print(f"❌ Server error: {response.status} - {text}")
                    return None
    except aiohttp.ClientError as e:
        print(f"❌ Connection error: {e}")
        return None
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return None


def get_machine_name() -> str:
    """Get current machine hostname."""
    return socket.gethostname()


async def setup_node() -> int:
    """Interactive node setup CLI.

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    print("=" * 60)
    print("🚀 Codernetes Node Setup")
    print("=" * 60)
    print()

    # Load existing config
    config = NodeConfig()

    # Step 1: Master server URL
    print("Step 1: Master Server Configuration")
    print("-" * 60)
    default_url = config.master_url or "http://localhost:8080"
    master_url = input(f"Master server URL [{default_url}]: ").strip() or default_url
    config.master_url = master_url
    print()

    # Step 2: User authentication
    print("Step 2: User Authentication")
    print("-" * 60)
    default_user = config.user_id or ""
    user_id = input(f"User ID{f' [{default_user}]' if default_user else ''}: ").strip() or default_user

    if not user_id:
        print("❌ User ID is required")
        return 1

    password = getpass.getpass("Password: ")

    if not password:
        print("❌ Password is required")
        return 1

    print("\n⏳ Verifying credentials...")
    result = await verify_credentials(master_url, user_id, password)

    if not result:
        return 1

    auth_token = result.get("auth_token")
    if not auth_token:
        print("❌ No authentication token received from server")
        return 1

    print("✅ Authentication successful!")
    print()

    # Step 3: Machine identification
    print("Step 3: Machine Identification")
    print("-" * 60)
    default_machine = config.machine_name or get_machine_name()
    machine_name = input(f"Machine name [{default_machine}]: ").strip() or default_machine
    print()

    # Step 4: Optional configuration
    print("Step 4: Optional Configuration")
    print("-" * 60)

    # Node tags
    default_tags = ",".join(config.node_tags) if config.node_tags else ""
    tags_input = input(f"Node tags (comma-separated){f' [{default_tags}]' if default_tags else ''}: ").strip()
    if tags_input:
        node_tags = [tag.strip() for tag in tags_input.split(",") if tag.strip()]
    elif default_tags:
        node_tags = config.node_tags
    else:
        node_tags = []

    print()

    # GitHub token (optional, stored locally)
    print("GitHub Integration (optional, stored locally on this node)")
    print("Press Enter to skip or keep existing token")
    github_token_input = getpass.getpass("GitHub token: ")
    if github_token_input:
        github_token = github_token_input
    else:
        github_token = config.github_token

    print()

    # Linear API key (optional, stored locally)
    print("Linear Integration (optional, stored locally on this node)")
    print("Press Enter to skip or keep existing key")
    linear_key_input = getpass.getpass("Linear API key: ")
    if linear_key_input:
        linear_api_key = linear_key_input
    else:
        linear_api_key = config.linear_api_key

    print()

    # Save configuration
    print("Step 5: Saving Configuration")
    print("-" * 60)
    config.user_id = user_id
    config.auth_token = auth_token
    config.machine_name = machine_name
    config.node_tags = node_tags

    if github_token:
        config.github_token = github_token
    if linear_api_key:
        config.linear_api_key = linear_api_key

    try:
        config.save()
        print(f"✅ Configuration saved to: {config.config_path}")
        print()
        print("=" * 60)
        print("🎉 Node setup completed successfully!")
        print("=" * 60)
        print()
        print("Configuration summary:")
        print(f"  Master URL: {config.master_url}")
        print(f"  User ID: {config.user_id}")
        print(f"  Machine: {config.machine_name}")
        print(f"  Tags: {', '.join(config.node_tags) if config.node_tags else '(none)'}")
        print(f"  GitHub: {'configured' if config.github_token else 'not configured'}")
        print(f"  Linear: {'configured' if config.linear_api_key else 'not configured'}")
        print()
        print("You can now start the node with: python -m node.client")
        return 0
    except Exception as e:
        print(f"❌ Failed to save configuration: {e}")
        return 1


def main() -> None:
    """CLI entry point."""
    try:
        exit_code = asyncio.run(setup_node())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n⚠️  Setup cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

"""
Git 워크플로우 관리 모듈

Git clone, branch 생성, commit, push 등의 Git 작업을 처리합니다.
"""

import asyncio
import logging
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from git import Repo
from git.exc import GitCommandError

logger = logging.getLogger(__name__)


@dataclass
class DiffStats:
    """Git diff 통계"""

    files_changed: int
    insertions: int
    deletions: int
    diff_text: str


class GitWorkflow:
    """Git 작업을 처리하는 클래스"""

    def __init__(self, work_dir: str | Path):
        """
        Args:
            work_dir: 작업 디렉토리 경로
        """
        self.work_dir = Path(work_dir)
        self.repo: Optional[Repo] = None

    async def clone_repo(
        self,
        repo_url: str,
        branch: str = "main",
        github_token: Optional[str] = None,
    ) -> str:
        """저장소 클론

        Args:
            repo_url: Git 저장소 URL
            branch: 체크아웃할 브랜치 (기본값: main)
            github_token: GitHub 토큰 (private 저장소용)

        Returns:
            클론된 저장소 경로

        Raises:
            GitCommandError: Git 명령 실패 시
        """
        logger.info(f"Cloning repository: {repo_url} (branch: {branch})")

        # 작업 디렉토리 생성
        self.work_dir.mkdir(parents=True, exist_ok=True)

        # GitHub 토큰이 있으면 URL에 인증 정보 추가
        clone_url = repo_url
        if github_token and "github.com" in repo_url:
            # https://github.com/owner/repo.git -> https://token@github.com/owner/repo.git
            clone_url = repo_url.replace("https://", f"https://{github_token}@")

        # 비동기 실행을 위해 run_in_executor 사용
        loop = asyncio.get_event_loop()
        self.repo = await loop.run_in_executor(
            None,
            lambda: Repo.clone_from(
                clone_url,
                self.work_dir,
                branch=branch,
                depth=1,  # shallow clone for faster cloning
            ),
        )

        logger.info(f"Repository cloned successfully: {self.work_dir}")
        return str(self.work_dir)

    async def create_branch(self, branch_name: str) -> str:
        """새 브랜치 생성 및 체크아웃

        Args:
            branch_name: 생성할 브랜치 이름

        Returns:
            생성된 브랜치 이름

        Raises:
            ValueError: repo가 초기화되지 않은 경우
            GitCommandError: Git 명령 실패 시
        """
        if not self.repo:
            raise ValueError("Repository not initialized. Call clone_repo first.")

        logger.info(f"Creating branch: {branch_name}")

        # 브랜치 생성 및 체크아웃
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            None, lambda: self.repo.git.checkout("-b", branch_name)
        )

        logger.info(f"Branch created and checked out: {branch_name}")
        return branch_name

    async def get_changed_files(self) -> list[str]:
        """변경된 파일 목록 조회

        Returns:
            변경된 파일 경로 목록
        """
        if not self.repo:
            raise ValueError("Repository not initialized. Call clone_repo first.")

        loop = asyncio.get_event_loop()

        # Untracked files
        untracked = await loop.run_in_executor(None, lambda: self.repo.untracked_files)

        # Modified and staged files
        diff_index = await loop.run_in_executor(
            None, lambda: self.repo.index.diff(None)
        )
        modified = [item.a_path for item in diff_index]

        # Staged files
        staged_diff = await loop.run_in_executor(
            None, lambda: self.repo.index.diff("HEAD")
        )
        staged = [item.a_path for item in staged_diff]

        all_changed = list(set(untracked + modified + staged))
        return all_changed

    async def commit(
        self, message: str, author_name: Optional[str] = None, author_email: Optional[str] = None
    ) -> str:
        """변경사항 커밋

        Args:
            message: 커밋 메시지
            author_name: 커밋 작성자 이름 (선택)
            author_email: 커밋 작성자 이메일 (선택)

        Returns:
            커밋 SHA

        Raises:
            ValueError: repo가 초기화되지 않은 경우 또는 변경사항이 없는 경우
            GitCommandError: Git 명령 실패 시
        """
        if not self.repo:
            raise ValueError("Repository not initialized. Call clone_repo first.")

        logger.info(f"Committing changes: {message[:50]}...")

        loop = asyncio.get_event_loop()

        # 모든 변경사항을 스테이징
        await loop.run_in_executor(None, lambda: self.repo.git.add("-A"))

        # 변경사항 확인
        if not self.repo.is_dirty(untracked_files=False):
            logger.warning("No changes to commit")
            raise ValueError("No changes to commit")

        # 커밋 설정
        commit_kwargs = {}
        if author_name and author_email:
            from git import Actor
            commit_kwargs["author"] = Actor(author_name, author_email)

        # 커밋 실행
        commit = await loop.run_in_executor(
            None, lambda: self.repo.index.commit(message, **commit_kwargs)
        )

        commit_sha = commit.hexsha
        logger.info(f"Changes committed: {commit_sha[:8]}")
        return commit_sha

    async def push(self, branch_name: str, force: bool = False) -> None:
        """브랜치를 원격 저장소에 푸시

        Args:
            branch_name: 푸시할 브랜치 이름
            force: 강제 푸시 여부 (기본값: False)

        Raises:
            ValueError: repo가 초기화되지 않은 경우
            GitCommandError: Git 명령 실패 시
        """
        if not self.repo:
            raise ValueError("Repository not initialized. Call clone_repo first.")

        logger.info(f"Pushing branch: {branch_name} (force: {force})")

        loop = asyncio.get_event_loop()

        # Disable git askpass to prevent interactive password prompts
        env = os.environ.copy()
        env['GIT_ASKPASS'] = ''
        env['GIT_TERMINAL_PROMPT'] = '0'

        # 원격 저장소 설정 (origin)
        origin = self.repo.remote("origin")

        # 푸시 인자 준비
        push_args = [branch_name]
        if force:
            push_args.insert(0, "--force")

        # 푸시 실행 with environment variables to disable askpass
        def _push():
            with self.repo.git.custom_environment(**env):
                return origin.push(*push_args)

        await loop.run_in_executor(None, _push)

        logger.info(f"Branch pushed successfully: {branch_name}")

    async def get_diff_stats(self, staged: bool = False) -> DiffStats:
        """변경 통계 조회

        Args:
            staged: True면 staged 변경사항, False면 전체 변경사항

        Returns:
            DiffStats 객체

        Raises:
            ValueError: repo가 초기화되지 않은 경우
        """
        if not self.repo:
            raise ValueError("Repository not initialized. Call clone_repo first.")

        loop = asyncio.get_event_loop()

        if staged:
            # Staged 변경사항
            diff_index = await loop.run_in_executor(
                None, lambda: self.repo.index.diff("HEAD")
            )
        else:
            # 전체 변경사항 (untracked 포함)
            diff_index = await loop.run_in_executor(
                None, lambda: self.repo.index.diff(None)
            )

        files_changed = len(diff_index)
        insertions = sum(diff.diff.decode("utf-8", errors="ignore").count("+") for diff in diff_index if diff.diff)
        deletions = sum(diff.diff.decode("utf-8", errors="ignore").count("-") for diff in diff_index if diff.diff)

        # Diff 텍스트 생성
        diff_text = await loop.run_in_executor(
            None, lambda: self.repo.git.diff(staged=staged)
        )

        return DiffStats(
            files_changed=files_changed,
            insertions=insertions,
            deletions=deletions,
            diff_text=diff_text,
        )

    async def get_current_branch(self) -> str:
        """현재 브랜치 이름 조회

        Returns:
            브랜치 이름

        Raises:
            ValueError: repo가 초기화되지 않은 경우
        """
        if not self.repo:
            raise ValueError("Repository not initialized. Call clone_repo first.")

        return str(self.repo.active_branch)

    async def cleanup(self) -> None:
        """작업 디렉토리 정리

        저장소를 닫고 작업 디렉토리를 삭제합니다.
        """
        if self.repo:
            self.repo.close()
            self.repo = None

        if self.work_dir.exists():
            logger.info(f"Cleaning up work directory: {self.work_dir}")
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, lambda: shutil.rmtree(self.work_dir))

    def __del__(self):
        """소멸자 - repo 닫기"""
        if self.repo:
            self.repo.close()

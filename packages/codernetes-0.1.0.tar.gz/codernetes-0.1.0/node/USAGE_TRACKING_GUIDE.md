# Node Usage Tracking Integration Guide

Complete guide for integrating usage tracking into Codernetes Node.

## Overview

The Node usage tracking system consists of two components:

1. **UsageTracker**: Locally tracks API calls (Claude, Codex)
2. **UsageReporter**: Periodically sends usage data to Master

## Architecture

```
Agent Execution
    ↓
record_usage() ← Manual instrumentation
    ↓
UsageTracker (thread-safe local storage)
    ↓
UsageReporter (periodic background task)
    ↓
Master API POST /api/nodes/{node_id}/usage
    ↓
Master Storage (aggregation)
    ↓
c8s monitor (monitoring system)
```

## Integration Steps

### 1. Initialize Tracker and Reporter

In your Node client initialization (e.g., `client.py`):

```python
from node.usage_tracker import init_tracker
from node.usage_reporter import init_reporter, start_reporter

# During node startup
async def initialize_node(node_id: str, master_url: str):
    # Initialize usage tracker
    tracker = init_tracker(node_id)

    # Initialize reporter (5 minute interval)
    reporter = init_reporter(
        master_url=master_url,
        node_id=node_id,
        interval=300  # seconds
    )

    # Start reporting in background
    await start_reporter()
```

### 2. Instrument Agent Execution

#### For Claude Code

In `agent_executor.py` or wherever Claude Code is called:

```python
from node.usage_tracker import record_usage

async def execute_with_claude(job_id: str, prompt: str):
    # ... execute Claude Code ...

    # After execution, record usage
    # You'll need to parse Claude's output for token usage
    record_usage(
        provider='claude',
        job_id=job_id,
        operation='code_generation',
        tokens_prompt=estimated_prompt_tokens,
        tokens_completion=estimated_completion_tokens,
        metadata={
            'model': 'claude-sonnet-4',
            'task': 'code_generation'
        }
    )
```

#### For Codex / Other LLMs

```python
from node.usage_tracker import record_usage

async def execute_with_codex(job_id: str, prompt: str):
    # ... execute Codex ...

    # Record usage (if API returns token counts)
    record_usage(
        provider='codex',
        job_id=job_id,
        operation='completion',
        tokens_prompt=response.usage.prompt_tokens,
        tokens_completion=response.usage.completion_tokens,
        cost_usd=calculate_cost(response.usage),
    )
```

### 3. Handle Node Shutdown

Ensure final report is sent on shutdown:

```python
from node.usage_reporter import stop_reporter

async def shutdown_node():
    # Stop reporter (sends final report)
    await stop_reporter()

    # ... other shutdown tasks ...
```

## Token Estimation

If your LLM doesn't return token counts, you'll need to estimate:

### Method 1: Character-based Estimation

```python
def estimate_tokens(text: str) -> int:
    """Rough estimation: ~4 characters per token"""
    return len(text) // 4
```

### Method 2: tiktoken (for OpenAI-compatible)

```python
import tiktoken

def count_tokens(text: str, model: str = "gpt-4") -> int:
    encoding = tiktoken.encoding_for_model(model)
    return len(encoding.encode(text))
```

### Method 3: API Response Parsing

Many LLMs return token counts in response metadata:

```python
# Example for OpenAI-style API
response = await client.chat.completions.create(...)
tokens_prompt = response.usage.prompt_tokens
tokens_completion = response.usage.completion_tokens
```

## Cost Estimation

Calculate approximate costs based on provider pricing:

```python
# Example cost calculation for Claude (as of 2025)
CLAUDE_PRICING = {
    'claude-sonnet-4': {
        'prompt': 3.00 / 1_000_000,  # $3 per 1M tokens
        'completion': 15.00 / 1_000_000,  # $15 per 1M tokens
    }
}

def calculate_claude_cost(
    tokens_prompt: int,
    tokens_completion: int,
    model: str = 'claude-sonnet-4'
) -> float:
    pricing = CLAUDE_PRICING.get(model, CLAUDE_PRICING['claude-sonnet-4'])
    cost = (
        tokens_prompt * pricing['prompt'] +
        tokens_completion * pricing['completion']
    )
    return round(cost, 6)

# Usage
cost = calculate_claude_cost(1000, 2000)
record_usage(
    provider='claude',
    job_id=job_id,
    operation='chat',
    tokens_prompt=1000,
    tokens_completion=2000,
    cost_usd=cost
)
```

## Complete Example

Here's a complete integration example:

```python
# node/client.py (or similar)

import asyncio
import logging
from typing import Optional

from node.usage_tracker import init_tracker, record_usage, get_tracker
from node.usage_reporter import init_reporter, start_reporter, stop_reporter

logger = logging.getLogger(__name__)


class CodeernetesNode:
    def __init__(self, node_id: str, master_url: str):
        self.node_id = node_id
        self.master_url = master_url
        self.tracker = None
        self.reporter = None

    async def start(self):
        """Start the node"""
        logger.info(f"Starting node {self.node_id}")

        # Initialize usage tracking
        self.tracker = init_tracker(self.node_id)
        self.reporter = init_reporter(
            master_url=self.master_url,
            node_id=self.node_id,
            interval=300  # 5 minutes
        )

        # Start background reporter
        await start_reporter()

        logger.info("Usage tracking initialized")

    async def execute_job(self, job_id: str, prompt: str, agent: str):
        """Execute a job with the specified agent"""
        logger.info(f"Executing job {job_id} with {agent}")

        try:
            if agent == 'claude-code':
                await self._execute_claude_code(job_id, prompt)
            elif agent == 'aider':
                await self._execute_aider(job_id, prompt)
            else:
                raise ValueError(f"Unknown agent: {agent}")

        except Exception as e:
            logger.error(f"Job execution failed: {e}")
            raise

    async def _execute_claude_code(self, job_id: str, prompt: str):
        """Execute with Claude Code"""
        # Estimate prompt tokens
        prompt_tokens = len(prompt) // 4

        # Execute (simplified)
        # result = await run_claude_code(prompt)
        result = "CODE RESULT"  # placeholder

        # Estimate completion tokens
        completion_tokens = len(result) // 4

        # Record usage
        record_usage(
            provider='claude',
            job_id=job_id,
            operation='code_generation',
            tokens_prompt=prompt_tokens,
            tokens_completion=completion_tokens,
            metadata={'agent': 'claude-code'}
        )

        logger.info(
            f"Recorded Claude usage for job {job_id}: "
            f"{prompt_tokens + completion_tokens} tokens"
        )

    async def _execute_aider(self, job_id: str, prompt: str):
        """Execute with Aider"""
        # Similar to Claude Code
        # Aider typically uses Claude or GPT-4
        # Record based on which model it actually uses

        # Example: if using Claude via Aider
        record_usage(
            provider='claude',
            job_id=job_id,
            operation='code_edit',
            tokens_prompt=len(prompt) // 4,
            tokens_completion=1000,  # estimate
            metadata={'agent': 'aider', 'model': 'claude-3.5-sonnet'}
        )

    async def stop(self):
        """Stop the node"""
        logger.info("Stopping node...")

        # Stop reporter (sends final report)
        await stop_reporter()

        # Print final stats
        if self.tracker:
            stats = self.tracker.get_current_stats()
            logger.info(f"Final usage stats: {stats}")

        logger.info("Node stopped")


# Usage example
async def main():
    node = CodeernetesNode(
        node_id='node-gpu-1',
        master_url='http://localhost:8080'
    )

    try:
        await node.start()

        # Execute some jobs
        await node.execute_job('job-1', 'Fix the auth bug', 'claude-code')
        await node.execute_job('job-2', 'Add tests', 'aider')

        # Keep running...
        await asyncio.sleep(3600)

    finally:
        await node.stop()


if __name__ == '__main__':
    asyncio.run(main())
```

## Viewing Usage Data

### On Node (Local)

```python
from node.usage_tracker import get_tracker

tracker = get_tracker()

# Get current session stats
stats = tracker.get_current_stats()
print(stats)

# Get detailed summary
summary = tracker.get_summary(provider='claude')
print(summary)

# Get job-specific usage
job_records = tracker.get_records_for_job('job-123')
for record in job_records:
    print(f"  {record.timestamp}: {record.tokens_total} tokens")
```

### On Master (via c8s monitor)

```bash
# View aggregated usage across all nodes
c8s monitor now

# Or check logs
tail -f /tmp/c8s-monitor.log | grep usage
```

### Via Master API

```bash
# Get aggregated usage
curl http://localhost:8080/api/usage/claude

# Response:
{
  "total_requests": 150,
  "total_tokens": 450000,
  "limit_requests": null,
  "limit_tokens": 2000000
}
```

## Configuration

### Reporter Interval

Adjust reporting frequency in `init_reporter()`:

```python
# More frequent (every minute)
init_reporter(master_url, node_id, interval=60)

# Less frequent (every 15 minutes)
init_reporter(master_url, node_id, interval=900)

# Default (every 5 minutes)
init_reporter(master_url, node_id, interval=300)
```

### Record Retention

Clear old records periodically:

```python
from node.usage_tracker import get_tracker

# Clean up records older than 7 days
tracker = get_tracker()
tracker.clear_old_records(days=7)
```

## Troubleshooting

### No Usage Being Recorded

1. Check tracker is initialized:
   ```python
   from node.usage_tracker import get_tracker
   tracker = get_tracker()
   if not tracker:
       print("Tracker not initialized!")
   ```

2. Check record calls are being made:
   ```python
   # Add logging
   import logging
   logging.getLogger('node.usage_tracker').setLevel(logging.DEBUG)
   ```

### Reports Not Reaching Master

1. Check Master API is accessible:
   ```bash
   curl -X POST http://localhost:8080/api/nodes/test-node/usage \
     -H "Content-Type: application/json" \
     -d '{"node_id":"test","timestamp":"2025-01-15T10:00:00",...}'
   ```

2. Check reporter logs:
   ```python
   import logging
   logging.getLogger('node.usage_reporter').setLevel(logging.DEBUG)
   ```

3. Verify reporter is running:
   ```python
   from node.usage_reporter import get_reporter
   reporter = get_reporter()
   if reporter and reporter.running:
       print("Reporter is running")
   else:
       print("Reporter not running!")
   ```

## Best Practices

1. **Initialize Early**: Initialize tracker and reporter during node startup
2. **Record Consistently**: Record usage for every LLM call
3. **Include Metadata**: Add job_id and other context for debugging
4. **Handle Errors**: Don't let tracking errors break job execution
5. **Clean Up**: Stop reporter gracefully on shutdown
6. **Monitor Logs**: Watch for "usage report" messages in node logs

## Next Steps

1. Implement actual token counting (instead of estimation)
2. Add cost tracking with real pricing
3. Store usage data in Master database
4. Add usage analytics and dashboards
5. Set up alerts for unusual usage patterns

## References

- `node/usage_tracker.py` - Local tracking implementation
- `node/usage_reporter.py` - Reporting implementation
- `master/api.py` - `report_node_usage` endpoint
- `c8s/monitor/` - Master-level monitoring system

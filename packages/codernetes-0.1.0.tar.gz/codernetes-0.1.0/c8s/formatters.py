"""
Output formatting utilities for c8s CLI
"""

import json
from typing import List, Any


def format_table(headers: List[str], rows: List[List[Any]]) -> str:
    """
    Format data as ASCII table

    Args:
        headers: Column headers
        rows: Data rows (each row is a list of column values)

    Returns:
        Formatted table string

    Example:
        >>> headers = ["NAME", "STATUS", "HOST"]
        >>> rows = [["node-1", "online", "192.168.1.10"], ["node-2", "offline", "192.168.1.11"]]
        >>> print(format_table(headers, rows))
        NAME    STATUS   HOST
        node-1  online   192.168.1.10
        node-2  offline  192.168.1.11
    """
    if not rows:
        return ""

    # Convert all values to strings
    str_headers = [str(h) for h in headers]
    str_rows = [[str(cell) for cell in row] for row in rows]

    # Calculate column widths
    col_widths = [len(h) for h in str_headers]
    for row in str_rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(cell))

    # Build format string
    format_str = "  ".join(f"{{:<{w}}}" for w in col_widths)

    # Format header
    lines = [format_str.format(*str_headers)]

    # Format rows
    for row in str_rows:
        lines.append(format_str.format(*row))

    return "\n".join(lines)


def format_json(data: Any, indent: int = 2) -> str:
    """
    Format data as pretty-printed JSON

    Args:
        data: Data to format
        indent: Indentation level

    Returns:
        JSON string
    """
    return json.dumps(data, indent=indent, ensure_ascii=False)

"""
API client for Codernetes master server
"""

import aiohttp
from typing import Dict, Any, Optional


class APIClient:
    """Async HTTP client for Codernetes master API"""

    def __init__(self, base_url: str, timeout: int = 30):
        """
        Initialize API client

        Args:
            base_url: Master server URL (e.g., http://localhost:8080)
            timeout: Request timeout in seconds
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = aiohttp.ClientTimeout(total=timeout)

    async def _request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Make an HTTP request

        Args:
            method: HTTP method (GET, POST, DELETE, etc.)
            path: API path (will be appended to base_url)
            json: JSON payload for POST/PUT requests
            params: Query parameters

        Returns:
            Response JSON data

        Raises:
            aiohttp.ClientError: On network errors
            ValueError: On invalid JSON response
        """
        url = f"{self.base_url}{path}"

        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.request(
                method, url, json=json, params=params
            ) as response:
                response.raise_for_status()
                return await response.json()

    # Node operations
    async def register_node(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Register a new Codernetes node"""
        return await self._request("POST", "/api/nodes/register", json=payload)

    async def list_nodes(self) -> Dict[str, Any]:
        """List all registered nodes"""
        return await self._request("GET", "/api/nodes")

    async def delete_node(self, node_id: str) -> Dict[str, Any]:
        """Delete a registered node"""
        return await self._request("DELETE", f"/api/nodes/{node_id}")

    # Job operations
    async def submit_job(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Submit a new job"""
        return await self._request("POST", "/api/jobs", json=payload)

    async def list_jobs(self) -> Dict[str, Any]:
        """List all jobs"""
        return await self._request("GET", "/api/jobs")

    async def get_job(self, job_id: str) -> Dict[str, Any]:
        """Get detailed job information"""
        return await self._request("GET", f"/api/jobs/{job_id}")

    async def get_job_logs(self, job_id: str) -> Dict[str, Any]:
        """Get job logs"""
        return await self._request("GET", f"/api/jobs/{job_id}/logs")

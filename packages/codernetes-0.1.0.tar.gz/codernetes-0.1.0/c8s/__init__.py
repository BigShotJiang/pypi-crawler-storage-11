"""
Codernetes CLI (c8s) - Kubernetes-inspired command-line interface
"""

__version__ = "0.1.0"

# c8s - Codernetes CLI

Kubernetes-inspired command-line interface for managing Codernetes nodes and jobs.

## Installation

Install from the project root:

```bash
pip install -e .
```

This will install the `c8s` command globally.

## Quick Start

### 1. Configure Master Server

Set up your master server URL:

```bash
c8s config set-context --master http://localhost:8080 --name local
```

View current configuration:

```bash
c8s config view
```

### 2. Node Management

Register a new node (daemon):

```bash
c8s node register --name gpu-node-1 --host 192.168.1.10 --tags gpu,prod
```

List all registered nodes:

```bash
c8s node list
c8s node list --status online
c8s node list -o json
```

Get node details:

```bash
c8s node get <node-id>
```

Delete a node:

```bash
c8s node delete <node-id>
```

### 3. Job Management

Submit a new job:

```bash
c8s job submit -p "Fix authentication bug" -r https://github.com/user/repo.git
c8s job submit -p "Add tests" -r repo1 -r repo2 --agent azure-ai
c8s job submit -p "Update docs" -r myrepo --tags gpu,staging
```

List jobs:

```bash
c8s job list
c8s job list --status running
c8s job list --limit 50 -o wide
```

Get job details:

```bash
c8s job get <job-id>
```

View job logs:

```bash
c8s job logs <job-id>
c8s job logs <job-id> --tail 50
```

## Configuration Management

### Multiple Contexts

Create different contexts for different environments:

```bash
c8s config set-context --master http://localhost:8080 --name local
c8s config set-context --master http://prod.example.com --name production
```

Switch between contexts:

```bash
c8s config use-context production
c8s config current-context
```

### Command-line Override

Override config with command-line flags:

```bash
c8s --master http://other-server:5001 node list
```

## Output Formats

Most commands support multiple output formats:

- `table` (default): Human-readable table format
- `wide`: Extended table with more columns
- `json`: Machine-readable JSON format
- `yaml`: YAML-like format (where applicable)

Examples:

```bash
c8s node list -o json
c8s node list -o wide
c8s job get <job-id> -o yaml
```

## Command Structure

Following kubectl patterns:

```
c8s [global-options] <resource> <action> [options]
```

Global options:
- `-c, --config`: Path to config file (default: ~/.c8s/config.json)
- `-m, --master`: Master server URL (overrides config)
- `--version`: Show version

## Examples

### Node Registration

```bash
# Register development node
c8s node register --name dev-node --host localhost --port 8765

# Register production node with tags
c8s node register --name prod-gpu-1 --host 192.168.1.50 --tags gpu,prod

# Register with notes
c8s node register --name staging-1 --host 10.0.0.5 --notes "Staging environment"
```

### Job Submission

```bash
# Simple job
c8s job submit -p "Fix login bug" -r https://github.com/myorg/backend.git

# Multi-repository job
c8s job submit -p "Sync auth changes" \
  -r https://github.com/myorg/frontend.git \
  -r https://github.com/myorg/backend.git

# Target specific node
c8s job submit -p "GPU training" -r ml-repo --node gpu-node-1

# Require specific tags
c8s job submit -p "Production deploy" -r webapp --tags prod,deploy

# With retries
c8s job submit -p "Flaky test fix" -r tests --retries 3
```

### Job Monitoring

```bash
# List recent jobs
c8s job list --limit 10

# Filter by status
c8s job list --status running
c8s job list --status failed

# Watch logs (planned feature)
c8s job logs <job-id> --follow

# Get full job details
c8s job get <job-id> -o json
```

### 4. System Monitoring

Monitor Codernetes system metrics and receive alerts via Slack, Telegram, or Discord.

#### Initialize Monitoring Configuration

```bash
c8s monitor init
```

This will guide you through an interactive setup:
- Master server URL
- Monitoring interval (seconds)
- Notification channels (Slack/Telegram/Discord)
- Alert thresholds

#### Start Monitoring

```bash
# Run in foreground (for testing)
c8s monitor start

# Run as background daemon
c8s monitor start --daemon

# With custom config
c8s monitor start --config ~/.c8s/monitor-config.json --daemon
```

#### Check Status

```bash
c8s monitor status
```

#### One-time Metrics Check

```bash
c8s monitor now
```

Output example:
```
📊 Codernetes System Status

*Claude API Usage:*
  • Tokens: 1,234,567 / 2,000,000 (61.7%)
  • Requests: 456 / 1,000 (45.6%)

*Codex API Usage:*
  • Tokens: 789,012 / 1,500,000 (52.6%)
  • Requests: 234 / 800 (29.3%)

*Jobs:*
  • Total: 125
  • Running: 3
  • Pending: 5
  • Completed: 115
  • Failed: 2

*Nodes:*
  • Total: 4
  • Active: 4
  • Busy: 3
  • Inactive: 0
```

#### Stop Monitoring

```bash
c8s monitor stop
```

#### Monitoring Alerts

The system will automatically send alerts when:
- **Claude API** usage exceeds 80% (warning) or 90% (critical)
- **Codex API** usage exceeds 80% (warning) or 90% (critical)
- **Failed jobs** exceed configured threshold (default: 5)
- **Pending jobs** exceed configured threshold (default: 20)
- **Active nodes** drop below minimum (default: 1)

Alerts are sent to all configured notification channels with appropriate severity levels.

## Configuration File Format

### Main Configuration

`~/.c8s/config.json`:

```json
{
  "contexts": {
    "local": {
      "master_url": "http://localhost:8080"
    },
    "production": {
      "master_url": "http://prod.example.com:8080"
    }
  },
  "current_context": "local",
  "monitor": {
    "interval": 300,
    "master_url": "http://localhost:8080",
    "notifiers": [
      {
        "type": "slack",
        "enabled": true,
        "webhook_url": "https://hooks.slack.com/services/YOUR/WEBHOOK/URL"
      },
      {
        "type": "telegram",
        "enabled": true,
        "bot_token": "YOUR_BOT_TOKEN",
        "chat_id": "YOUR_CHAT_ID"
      },
      {
        "type": "discord",
        "enabled": false,
        "webhook_url": "https://discord.com/api/webhooks/YOUR/WEBHOOK"
      }
    ],
    "thresholds": {
      "claude_api_warning": 80.0,
      "claude_api_critical": 90.0,
      "codex_api_warning": 80.0,
      "codex_api_critical": 90.0,
      "max_failed_jobs": 5,
      "max_pending_jobs": 20,
      "min_active_nodes": 1
    },
    "monitor_claude_api": true,
    "monitor_codex_api": true,
    "monitor_jobs": true,
    "monitor_nodes": true
  }
}
```

### Notification Setup

#### Slack
1. Create a Slack Incoming Webhook:
   - Go to https://api.slack.com/messaging/webhooks
   - Create a new webhook for your workspace
   - Copy the webhook URL

2. Add to config:
```json
{
  "type": "slack",
  "enabled": true,
  "webhook_url": "https://hooks.slack.com/services/YOUR/WEBHOOK/URL"
}
```

#### Telegram
1. Create a Telegram Bot:
   - Talk to [@BotFather](https://t.me/botfather)
   - Create a new bot with `/newbot`
   - Copy the bot token

2. Get your Chat ID:
   - Start a chat with your bot
   - Visit `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
   - Find your `chat.id` in the response

3. Add to config:
```json
{
  "type": "telegram",
  "enabled": true,
  "bot_token": "1234567890:ABCdefGHIjklMNOpqrsTUVwxyz",
  "chat_id": "123456789"
}
```

#### Discord
1. Create a Discord Webhook:
   - Go to your Discord server settings
   - Navigate to Integrations → Webhooks
   - Create a new webhook
   - Copy the webhook URL

2. Add to config:
```json
{
  "type": "discord",
  "enabled": true,
  "webhook_url": "https://discord.com/api/webhooks/YOUR/WEBHOOK"
}
```

## API Endpoints

The CLI uses the following REST API endpoints:

### Nodes
- `POST /api/register` - Register node
- `GET /api/list` - List nodes
- `DELETE /api/remote/<id>` - Delete node

### Jobs
- `POST /api/jobs` - Submit job
- `GET /api/jobs` - List jobs
- `GET /api/jobs/<id>` - Get job details
- `GET /api/jobs/<id>/logs` - Get job logs

## Development

The CLI is built with:
- **Click** - Command-line interface framework
- **aiohttp** - Async HTTP client
- **asyncio** - Async execution

Module structure:
```
c8s/
├── __init__.py
├── cli.py              # Main CLI entry point
├── api_client.py       # API client for master server
├── formatters.py       # Output formatting utilities
├── commands/
│   ├── __init__.py
│   ├── node.py         # Node management commands
│   ├── job.py          # Job management commands
│   ├── config.py       # Configuration commands
│   └── monitor.py      # Monitoring commands
└── monitor/
    ├── __init__.py
    ├── config.py       # Monitoring configuration
    ├── daemon.py       # Background monitoring daemon
    ├── collectors.py   # Metrics collection
    ├── notifiers.py    # Alert notifications
    └── config.example.json  # Example config
```

## Planned Features

- [x] System monitoring with alerts
- [x] Multi-channel notifications (Slack, Telegram, Discord)
- [x] API usage tracking (Claude, Codex)
- [ ] Job log streaming (`--follow` flag)
- [ ] Job deletion/cancellation
- [ ] Node health monitoring
- [ ] Bash completion
- [ ] Colored output
- [ ] Interactive mode
- [ ] Job templates
- [ ] Bulk operations

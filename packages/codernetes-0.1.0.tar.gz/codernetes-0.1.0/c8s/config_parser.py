"""
Node configuration file parser with environment variable substitution
"""

import os
import re
import yaml
from pathlib import Path
from typing import Dict, Any, Optional


def load_env_file(env_path: Path) -> Dict[str, str]:
    """
    Load environment variables from .env file

    Args:
        env_path: Path to .env file

    Returns:
        Dictionary of environment variables
    """
    env_vars = {}
    if not env_path.exists():
        return env_vars

    with open(env_path, "r") as f:
        for line in f:
            line = line.strip()
            # Skip comments and empty lines
            if not line or line.startswith("#"):
                continue

            # Parse KEY=VALUE
            if "=" in line:
                key, value = line.split("=", 1)
                env_vars[key.strip()] = value.strip()

    return env_vars


def substitute_env_vars(data: Any, env_vars: Optional[Dict[str, str]] = None) -> Any:
    """
    Recursively substitute environment variables in data structure

    Supports ${VAR_NAME} and ${VAR_NAME:-default} syntax

    Args:
        data: Data structure (dict, list, str, etc.)
        env_vars: Optional environment variables dict (uses os.environ if None)

    Returns:
        Data with environment variables substituted
    """
    if env_vars is None:
        env_vars = dict(os.environ)

    if isinstance(data, dict):
        return {k: substitute_env_vars(v, env_vars) for k, v in data.items()}
    elif isinstance(data, list):
        return [substitute_env_vars(item, env_vars) for item in data]
    elif isinstance(data, str):
        # Pattern: ${VAR_NAME} or ${VAR_NAME:-default_value}
        pattern = r"\$\{([^}:]+)(?::-(.*?))?\}"

        def replace_var(match):
            var_name = match.group(1)
            default_value = match.group(2) if match.group(2) is not None else ""

            # Look in provided env_vars first, then os.environ
            value = env_vars.get(var_name) or os.environ.get(var_name)

            if value is None:
                if default_value:
                    return default_value
                else:
                    # Keep the variable as-is if not found and no default
                    return match.group(0)

            return value

        return re.sub(pattern, replace_var, data)
    else:
        return data


def parse_node_config(config_path: Path, env_path: Optional[Path] = None) -> Dict[str, Any]:
    """
    Parse node configuration file

    Args:
        config_path: Path to YAML configuration file
        env_path: Optional path to .env file for additional variables

    Returns:
        Parsed configuration dictionary with environment variables substituted

    Raises:
        FileNotFoundError: If config file doesn't exist
        yaml.YAMLError: If YAML parsing fails
    """
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    # Load .env file if provided
    env_vars = {}
    if env_path:
        env_vars = load_env_file(env_path)

    # Merge with os.environ (os.environ takes precedence)
    env_vars.update(os.environ)

    # Parse YAML
    with open(config_path, "r") as f:
        config_data = yaml.safe_load(f)

    if not config_data:
        raise ValueError(f"Empty configuration file: {config_path}")

    # Substitute environment variables
    config_data = substitute_env_vars(config_data, env_vars)

    return config_data


def validate_node_config(config: Dict[str, Any]) -> None:
    """
    Validate node configuration structure

    Args:
        config: Configuration dictionary

    Raises:
        ValueError: If configuration is invalid
    """
    required_fields = ["name", "host", "port"]
    for field in required_fields:
        if field not in config:
            raise ValueError(f"Missing required field: {field}")

    # Validate port
    port = config["port"]
    if not isinstance(port, int) or port < 1 or port > 65535:
        raise ValueError(f"Invalid port number: {port}")

    # Validate capabilities structure if present
    if "capabilities" in config:
        capabilities = config["capabilities"]
        if not isinstance(capabilities, dict):
            raise ValueError("capabilities must be a dictionary")

        # Check each capability has enabled field
        for cap_name, cap_config in capabilities.items():
            if not isinstance(cap_config, dict):
                raise ValueError(f"Capability '{cap_name}' must be a dictionary")
            if "enabled" not in cap_config:
                raise ValueError(f"Capability '{cap_name}' missing 'enabled' field")


def config_to_register_payload(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert node configuration to registration API payload

    Args:
        config: Node configuration dictionary

    Returns:
        Registration payload for API
    """
    payload = {
        "name": config["name"],
        "host": config["host"],
        "port": config["port"],
        "tags": config.get("tags", []),
        "notes": config.get("notes", ""),
        "capabilities": config.get("capabilities", {}),
        "resources": config.get("resources", {}),
    }

    return payload


def get_capability_summary(config: Dict[str, Any]) -> str:
    """
    Generate a human-readable summary of enabled capabilities

    Args:
        config: Node configuration dictionary

    Returns:
        Summary string
    """
    if "capabilities" not in config:
        return "No capabilities configured"

    capabilities = config["capabilities"]
    enabled = []

    for cap_name, cap_config in capabilities.items():
        if cap_config.get("enabled", False):
            features = cap_config.get("features", [])
            if features:
                enabled.append(f"{cap_name} ({', '.join(features)})")
            else:
                enabled.append(cap_name)

    if not enabled:
        return "No capabilities enabled"

    return ", ".join(enabled)

#!/usr/bin/env python3
"""
c8s - Codernetes CLI tool
Kubernetes-inspired command-line interface for managing Codernetes nodes and jobs
"""

import click
import json
import sys
from pathlib import Path
from typing import Optional

# Import subcommands
from c8s.commands import node, job, config, monitor


@click.group()
@click.version_option(version="0.1.0", prog_name="c8s")
@click.option(
    "--config",
    "-c",
    type=click.Path(exists=True),
    default=None,
    help="Path to config file (default: ~/.c8s/config.json)",
)
@click.option(
    "--master",
    "-m",
    default=None,
    help="Master server URL (overrides config)",
)
@click.pass_context
def cli(ctx, config: Optional[str], master: Optional[str]):
    """
    c8s - Codernetes CLI

    Manage Codernetes nodes, jobs, and configuration.
    Inspired by kubectl for Kubernetes.

    Examples:
        c8s node register --name my-node --host localhost
        c8s job submit --prompt "Fix bug in auth.py"
        c8s job logs <job-id>
    """
    # Ensure ctx.obj exists
    ctx.ensure_object(dict)

    # Load configuration
    config_path = Path(config) if config else Path.home() / ".c8s" / "config.json"
    ctx.obj["config_path"] = config_path

    if config_path.exists():
        with open(config_path, "r") as f:
            config_data = json.load(f)

            # Handle new context-based config format
            if "contexts" in config_data:
                current = config_data.get("current_context")
                if current and current in config_data["contexts"]:
                    ctx.obj["config"] = config_data["contexts"][current]
                else:
                    ctx.obj["config"] = {}
            else:
                # Legacy format (direct master_url)
                ctx.obj["config"] = config_data
    else:
        ctx.obj["config"] = {}

    # Override with command-line flags
    if master:
        ctx.obj["config"]["master_url"] = master


# Register subcommands
cli.add_command(node)
cli.add_command(job)
cli.add_command(config)
cli.add_command(monitor)


def main():
    """Entry point for c8s CLI"""
    try:
        cli(obj={})
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()

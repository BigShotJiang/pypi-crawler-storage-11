"""
Monitor management commands
"""

import click
import asyncio
import sys
from pathlib import Path
from typing import Optional

from ..monitor.config import MonitorConfig, NotifierConfig, ThresholdConfig
from ..monitor.daemon import run_daemon
from ..monitor.collectors import (
    MetricsCollector,
    StandaloneAPICollector,
    CLIAPICollector,
    SystemMetrics,
    format_metrics_summary,
)


@click.group()
def monitor():
    """
    Monitor Codernetes system metrics and send alerts

    Track API usage (Claude, Codex), job execution, and node status.
    Send notifications via Slack, Telegram, or Discord.
    """
    pass


@monitor.command()
@click.option(
    "--config",
    "-c",
    type=click.Path(exists=True),
    default=None,
    help="Path to config file (default: ~/.c8s/config.json)",
)
@click.option(
    "--daemon",
    "-d",
    is_flag=True,
    help="Run in background as daemon",
)
def start(config: Optional[str], daemon: bool):
    """Start monitoring daemon"""
    config_path = Path(config) if config else Path.home() / ".c8s" / "config.json"

    if not config_path.exists():
        click.echo(f"❌ Config file not found: {config_path}", err=True)
        click.echo("Run 'c8s monitor init' to create a config file", err=True)
        sys.exit(1)

    try:
        monitor_config = MonitorConfig.from_file(config_path)
    except Exception as e:
        click.echo(f"❌ Failed to load config: {e}", err=True)
        sys.exit(1)

    # Validate config
    errors = monitor_config.validate()
    if errors:
        click.echo("❌ Configuration errors:", err=True)
        for error in errors:
            click.echo(f"  - {error}", err=True)
        sys.exit(1)

    if daemon:
        # Run as background daemon
        click.echo("🚀 Starting monitoring daemon in background...")
        click.echo(f"PID file: {monitor_config.pid_file}")
        click.echo(f"Log file: {monitor_config.log_file}")

        # Fork to background
        import os

        pid = os.fork()
        if pid > 0:
            click.echo(f"✅ Daemon started with PID {pid}")
            sys.exit(0)

        # Child process continues
        run_daemon(config_path)
    else:
        # Run in foreground
        click.echo("🚀 Starting monitoring (press Ctrl+C to stop)...")
        try:
            run_daemon(config_path)
        except KeyboardInterrupt:
            click.echo("\n⏹️ Monitoring stopped")


@monitor.command()
@click.option(
    "--config",
    "-c",
    type=click.Path(exists=True),
    default=None,
    help="Path to config file (default: ~/.c8s/config.json)",
)
def stop(config: Optional[str]):
    """Stop monitoring daemon"""
    config_path = Path(config) if config else Path.home() / ".c8s" / "config.json"

    if not config_path.exists():
        click.echo(f"❌ Config file not found: {config_path}", err=True)
        sys.exit(1)

    try:
        monitor_config = MonitorConfig.from_file(config_path)
    except Exception as e:
        click.echo(f"❌ Failed to load config: {e}", err=True)
        sys.exit(1)

    pid_file = Path(monitor_config.pid_file)

    if not pid_file.exists():
        click.echo("⚠️ Monitoring daemon is not running")
        sys.exit(0)

    try:
        pid = int(pid_file.read_text())
        import os
        import signal

        os.kill(pid, signal.SIGTERM)
        click.echo(f"✅ Stopped monitoring daemon (PID {pid})")

        # Wait a bit and check if it stopped
        import time

        time.sleep(1)

        try:
            os.kill(pid, 0)  # Check if still running
            click.echo("⚠️ Daemon may still be shutting down...")
        except ProcessLookupError:
            click.echo("✅ Daemon stopped successfully")

    except (ValueError, ProcessLookupError) as e:
        click.echo(f"⚠️ Could not stop daemon: {e}", err=True)
        # Clean up stale PID file
        pid_file.unlink()
        sys.exit(1)


@monitor.command()
@click.option(
    "--config",
    "-c",
    type=click.Path(exists=True),
    default=None,
    help="Path to config file (default: ~/.c8s/config.json)",
)
def status(config: Optional[str]):
    """Show monitoring daemon status"""
    config_path = Path(config) if config else Path.home() / ".c8s" / "config.json"

    if not config_path.exists():
        click.echo(f"❌ Config file not found: {config_path}", err=True)
        sys.exit(1)

    try:
        monitor_config = MonitorConfig.from_file(config_path)
    except Exception as e:
        click.echo(f"❌ Failed to load config: {e}", err=True)
        sys.exit(1)

    pid_file = Path(monitor_config.pid_file)

    if not pid_file.exists():
        click.echo("⏹️ Monitoring daemon is not running")
        return

    try:
        pid = int(pid_file.read_text())
        import os

        os.kill(pid, 0)  # Check if process exists
        click.echo(f"✅ Monitoring daemon is running (PID {pid})")
        click.echo(f"   Interval: {monitor_config.interval}s")
        click.echo(f"   Master: {monitor_config.master_url}")
        click.echo(f"   Log file: {monitor_config.log_file}")

    except (ValueError, ProcessLookupError, OSError):
        click.echo("⚠️ Daemon PID file exists but process is not running")
        click.echo("   (cleaning up stale PID file)")
        pid_file.unlink()


@monitor.command()
@click.option(
    "--config",
    "-c",
    type=click.Path(exists=True),
    default=None,
    help="Path to config file (default: ~/.c8s/config.json)",
)
@click.pass_context
def now(ctx, config: Optional[str]):
    """Collect and display current metrics (one-time check)"""
    config_path = Path(config) if config else Path.home() / ".c8s" / "config.json"

    if not config_path.exists():
        # Try to get master URL from main config
        master_url = ctx.obj.get("config", {}).get(
            "master_url", "http://localhost:8080"
        )
        monitor_config = None
    else:
        try:
            monitor_config = MonitorConfig.from_file(config_path)
            master_url = monitor_config.master_url
        except Exception as e:
            click.echo(f"❌ Failed to load config: {e}", err=True)
            sys.exit(1)

    async def collect():
        metrics = SystemMetrics()

        # Check if standalone mode is configured
        if monitor_config and monitor_config.standalone_mode:
            click.echo("📊 Collecting metrics in STANDALONE mode...\n")

            # Collect API usage
            standalone_collector = StandaloneAPICollector()
            if monitor_config.monitor_claude_api and monitor_config.anthropic_api_key:
                metrics.claude_api = await standalone_collector.collect_anthropic_usage(
                    monitor_config.anthropic_api_key
                )

            if monitor_config.monitor_codex_api and monitor_config.openai_api_key:
                metrics.codex_api = await standalone_collector.collect_openai_usage(
                    monitor_config.openai_api_key
                )

            # Collect CLI usage
            cli_collector = CLIAPICollector()
            metrics.claude_code_cli = await cli_collector.collect_claude_code_usage()
            metrics.codex_cli = await cli_collector.collect_codex_usage()

        else:
            # Integrated mode: Master API calls
            click.echo(f"📊 Collecting metrics from {master_url}...\n")
            collector = MetricsCollector(master_url)
            metrics = await collector.collect_all()

            # Also collect CLI usage in integrated mode
            cli_collector = CLIAPICollector()
            metrics.claude_code_cli = await cli_collector.collect_claude_code_usage()
            metrics.codex_cli = await cli_collector.collect_codex_usage()

        return metrics

    try:
        metrics = asyncio.run(collect())
        summary = format_metrics_summary(metrics)
        click.echo(summary)
    except Exception as e:
        click.echo(f"❌ Error collecting metrics: {e}", err=True)
        sys.exit(1)


@monitor.command()
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    default=None,
    help="Output path (default: ~/.c8s/config.json)",
)
@click.option(
    "--master",
    "-m",
    default="http://localhost:8080",
    help="Master server URL",
)
@click.option(
    "--interval",
    "-i",
    type=int,
    default=300,
    help="Monitoring interval in seconds (default: 300)",
)
def init(output: Optional[str], master: str, interval: int):
    """Initialize monitoring configuration with interactive setup"""
    output_path = Path(output) if output else Path.home() / ".c8s" / "config.json"

    click.echo("🔧 Codernetes Monitor Configuration\n")

    # Basic settings
    click.echo(f"Master URL: {master}")
    click.echo(f"Interval: {interval}s\n")

    # Notifier setup
    notifiers = []

    if click.confirm("Configure Slack notifications?", default=False):
        webhook = click.prompt("Slack Webhook URL")
        notifiers.append(
            NotifierConfig(
                type="slack",
                enabled=True,
                webhook_url=webhook,
            )
        )

    if click.confirm("Configure Telegram notifications?", default=False):
        bot_token = click.prompt("Telegram Bot Token")
        chat_id = click.prompt("Telegram Chat ID")
        notifiers.append(
            NotifierConfig(
                type="telegram",
                enabled=True,
                bot_token=bot_token,
                chat_id=chat_id,
            )
        )

    if click.confirm("Configure Discord notifications?", default=False):
        webhook = click.prompt("Discord Webhook URL")
        notifiers.append(
            NotifierConfig(
                type="discord",
                enabled=True,
                webhook_url=webhook,
            )
        )

    if not notifiers:
        click.echo("⚠️ No notifiers configured. You won't receive alerts!")

    # Thresholds
    click.echo("\n⚙️ Alert Thresholds")
    thresholds = ThresholdConfig(
        claude_api_warning=click.prompt(
            "Claude API warning threshold (%)", default=80.0, type=float
        ),
        claude_api_critical=click.prompt(
            "Claude API critical threshold (%)", default=90.0, type=float
        ),
        codex_api_warning=click.prompt(
            "Codex API warning threshold (%)", default=80.0, type=float
        ),
        codex_api_critical=click.prompt(
            "Codex API critical threshold (%)", default=90.0, type=float
        ),
        max_failed_jobs=click.prompt(
            "Max failed jobs before alert", default=5, type=int
        ),
        min_active_nodes=click.prompt("Min active nodes required", default=1, type=int),
    )

    # Create config
    config = MonitorConfig(
        interval=interval,
        master_url=master,
        notifiers=notifiers,
        thresholds=thresholds,
    )

    # Save
    try:
        config.save(output_path)
        click.echo(f"\n✅ Configuration saved to {output_path}")
        click.echo("\nNext steps:")
        click.echo("  1. Review the config file")
        click.echo("  2. Start monitoring: c8s monitor start --daemon")
        click.echo("  3. Check status: c8s monitor status")
    except Exception as e:
        click.echo(f"\n❌ Failed to save config: {e}", err=True)
        sys.exit(1)

"""
Node management commands
"""

import click
import json
import asyncio
from pathlib import Path
from typing import Optional
from c8s.api_client import APIClient
from c8s.formatters import format_table, format_json
from c8s.config_parser import (
    parse_node_config,
    validate_node_config,
    config_to_register_payload,
    get_capability_summary,
)


@click.group()
def node():
    """Manage Codernetes nodes"""
    pass


@node.command("register")
@click.option("--config", "-f", type=click.Path(exists=True), help="Path to node configuration file (YAML)")
@click.option("--env", type=click.Path(exists=True), help="Path to .env file with credentials")
@click.option("--name", help="Node display name (overrides config)")
@click.option("--host", help="Node host address (overrides config)")
@click.option("--port", type=int, help="Node WebSocket port (overrides config)")
@click.option("--tags", help="Comma-separated tags (overrides config)")
@click.option("--notes", help="Optional notes about this node (overrides config)")
@click.option("-o", "--output", type=click.Choice(["json", "yaml", "table"]), default="table", help="Output format")
@click.pass_context
def register_node(
    ctx,
    config: Optional[str],
    env: Optional[str],
    name: Optional[str],
    host: Optional[str],
    port: Optional[int],
    tags: Optional[str],
    notes: Optional[str],
    output: str,
):
    """
    Register a new Codernetes node (daemon)

    Can register using a configuration file or command-line options.
    Configuration file provides full control over capabilities and credentials.

    Examples:
        # Using configuration file
        c8s node register -f examples/node-config.yaml --env .env

        # Using command-line options
        c8s node register --name gpu-node-1 --host 192.168.1.10 --tags gpu,prod

        # Mix of both (CLI options override config file)
        c8s node register -f node-config.yaml --name custom-name
    """
    client = APIClient(ctx.obj["config"].get("master_url", "http://localhost:8080"))

    # Parse configuration file if provided
    if config:
        try:
            config_path = Path(config)
            env_path = Path(env) if env else None
            config_data = parse_node_config(config_path, env_path)
            validate_node_config(config_data)

            # Override with command-line options if provided
            if name:
                config_data["name"] = name
            if host:
                config_data["host"] = host
            if port:
                config_data["port"] = port
            if tags:
                config_data["tags"] = [t.strip() for t in tags.split(",") if t.strip()]
            if notes:
                config_data["notes"] = notes

            payload = config_to_register_payload(config_data)

        except Exception as e:
            click.echo(f"✗ Failed to parse configuration: {e}", err=True)
            raise click.Abort()

    else:
        # Use command-line options only
        if not name or not host:
            click.echo("✗ --name and --host are required when not using --config", err=True)
            raise click.Abort()

        tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []

        payload = {
            "name": name,
            "host": host,
            "port": port or 8765,
            "tags": tag_list,
            "notes": notes or "",
            "capabilities": {},
            "resources": {},
        }

    try:
        result = asyncio.run(client.register_node(payload))

        if output == "json":
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo(f"✓ Node registered successfully")
            click.echo(f"  ID: {result.get('remote', {}).get('id', 'N/A')}")
            click.echo(f"  Name: {payload['name']}")
            click.echo(f"  Address: {payload['host']}:{payload['port']}")
            if payload.get("tags"):
                click.echo(f"  Tags: {', '.join(payload['tags'])}")
            if payload.get("capabilities"):
                cap_summary = get_capability_summary({"capabilities": payload["capabilities"]})
                click.echo(f"  Capabilities: {cap_summary}")

    except Exception as e:
        click.echo(f"✗ Failed to register node: {e}", err=True)
        raise click.Abort()


@node.command("list")
@click.option("-o", "--output", type=click.Choice(["json", "yaml", "table", "wide"]), default="table", help="Output format")
@click.option("--status", type=click.Choice(["online", "offline", "all"]), default="all", help="Filter by status")
@click.pass_context
def list_nodes(ctx, output: str, status: str):
    """
    List all registered nodes

    Examples:
        c8s node list
        c8s node list --status online
        c8s node list -o json
    """
    client = APIClient(ctx.obj["config"].get("master_url", "http://localhost:8080"))

    try:
        result = asyncio.run(client.list_nodes())
        nodes = result.get("nodes", [])

        # Filter by status
        if status != "all":
            nodes = [n for n in nodes if n.get("status") == status]

        if output == "json":
            click.echo(json.dumps(nodes, indent=2))
        elif output == "wide":
            headers = ["ID", "NAME", "STATUS", "TAGS", "CAPABILITIES", "LAST SEEN"]
            rows = []
            for n in nodes:
                # Get capability summary
                caps = n.get("capabilities", {})
                enabled_caps = [k for k, v in caps.items() if isinstance(v, dict) and v.get("enabled")]
                cap_str = ", ".join(enabled_caps) if enabled_caps else "none"

                rows.append([
                    n.get("node_id", "")[:12],
                    n.get("display_name", ""),
                    n.get("status", ""),
                    ", ".join(n.get("tags", [])),
                    cap_str[:30] + ("..." if len(cap_str) > 30 else ""),
                    n.get("last_seen", ""),
                ])
            click.echo(format_table(headers, rows))
        else:
            headers = ["NAME", "STATUS", "TAGS", "CAPABILITIES"]
            rows = []
            for n in nodes:
                # Get capability summary
                caps = n.get("capabilities", {})
                enabled_caps = [k for k, v in caps.items() if isinstance(v, dict) and v.get("enabled")]
                cap_str = ", ".join(enabled_caps) if enabled_caps else "none"

                rows.append([
                    n.get("display_name", ""),
                    n.get("status", ""),
                    ", ".join(n.get("tags", [])),
                    cap_str[:40] + ("..." if len(cap_str) > 40 else ""),
                ])
            click.echo(format_table(headers, rows))

    except Exception as e:
        click.echo(f"✗ Failed to list nodes: {e}", err=True)
        raise click.Abort()


@node.command("get")
@click.argument("node_id")
@click.option("-o", "--output", type=click.Choice(["json", "yaml"]), default="json", help="Output format")
@click.pass_context
def get_node(ctx, node_id: str, output: str):
    """
    Get detailed information about a specific node

    Examples:
        c8s node get abc123
        c8s node get abc123 -o yaml
    """
    client = APIClient(ctx.obj["config"].get("master_url", "http://localhost:8080"))

    try:
        result = asyncio.run(client.list_nodes())
        nodes = result.get("nodes", [])

        node = next((n for n in nodes if n.get("node_id", "").startswith(node_id)), None)

        if not node:
            click.echo(f"✗ Node not found: {node_id}", err=True)
            raise click.Abort()

        if output == "json":
            click.echo(json.dumps(node, indent=2))
        else:
            # YAML-like output
            click.echo(f"node_id: {node.get('node_id')}")
            click.echo(f"display_name: {node.get('display_name')}")
            click.echo(f"status: {node.get('status')}")
            if node.get('tags'):
                click.echo(f"tags:")
                for tag in node.get('tags', []):
                    click.echo(f"  - {tag}")
            if node.get('capabilities'):
                click.echo(f"capabilities:")
                for cap_name, cap_config in node.get('capabilities', {}).items():
                    enabled = cap_config.get("enabled") if isinstance(cap_config, dict) else False
                    click.echo(f"  {cap_name}:")
                    click.echo(f"    enabled: {enabled}")
                    if isinstance(cap_config, dict) and cap_config.get("features"):
                        click.echo(f"    features: {', '.join(cap_config.get('features', []))}")
            if node.get('resources'):
                click.echo(f"resources:")
                for res_name, res_value in node.get('resources', {}).items():
                    click.echo(f"  {res_name}: {res_value}")
            click.echo(f"last_seen: {node.get('last_seen')}")

    except Exception as e:
        click.echo(f"✗ Failed to get node: {e}", err=True)
        raise click.Abort()


@node.command("delete")
@click.argument("node_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
@click.pass_context
def delete_node(ctx, node_id: str, yes: bool):
    """
    Delete a registered node

    Examples:
        c8s node delete abc123
        c8s node delete abc123 -y
    """
    client = APIClient(ctx.obj["config"].get("master_url", "http://localhost:8080"))

    if not yes:
        click.confirm(f"Are you sure you want to delete node {node_id}?", abort=True)

    try:
        asyncio.run(client.delete_node(node_id))
        click.echo(f"✓ Node {node_id} deleted successfully")

    except Exception as e:
        click.echo(f"✗ Failed to delete node: {e}", err=True)
        raise click.Abort()


@node.command("setup")
def setup_node():
    """
    Configure node authentication credentials

    This interactive wizard will guide you through setting up your node
    with user authentication credentials. You'll need:
    - Master server URL
    - User ID and password
    - Machine name (optional, auto-detected)
    - Node tags (optional)
    - GitHub/Linear tokens (optional, stored locally)

    Examples:
        c8s node setup
    """
    import subprocess
    import sys

    try:
        click.echo("=" * 60)
        click.echo("🚀 Codernetes Node Setup")
        click.echo("=" * 60)
        click.echo()

        # Run the node setup module
        result = subprocess.run([sys.executable, "-m", "node.setup"], check=False)
        sys.exit(result.returncode)

    except KeyboardInterrupt:
        click.echo("\n\n⚠️  Setup cancelled by user")
        sys.exit(1)
    except Exception as e:
        click.echo(f"\n✗ Failed to run setup: {e}", err=True)
        sys.exit(1)


@node.command("run")
@click.option("--host", help="Master server host (default: from config or 127.0.0.1)")
@click.option("--port", type=int, help="Master server WebSocket port (default: from config or 8765)")
@click.option("--name", "--display-name", "display_name", help="Node display name")
@click.option("--tags", help="Comma-separated node tags")
@click.option("--workdir-root", help="Job working directory root path")
@click.option("--config", "-f", type=click.Path(exists=True), help="Node configuration file (YAML)")
@click.option("--node-password", help="Node password for access control")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
@click.pass_context
def run_node(
    ctx,
    host: Optional[str],
    port: Optional[int],
    display_name: Optional[str],
    tags: Optional[str],
    workdir_root: Optional[str],
    config: Optional[str],
    node_password: Optional[str],
    verbose: bool,
):
    """
    Run a Codernetes node client

    This command starts a node client that connects to the master server
    and executes assigned jobs. Authentication is required - run 'python -m node.setup'
    first to configure your node credentials.

    Examples:
        # Run with default configuration from ~/.codernetes/node.json
        c8s node run

        # Override master server
        c8s node run --host master.company.com --port 8765

        # Use custom configuration file
        c8s node run -f node-config.yaml

        # Add tags for job routing
        c8s node run --tags python,docker,gpu
    """
    import subprocess
    import sys
    import os

    # Build command arguments
    cmd = [sys.executable, "-m", "node.client"]

    # Add master server options
    if host:
        cmd.extend(["--host", host])
    elif ctx.obj["config"].get("master_url"):
        # Parse master URL from config
        from urllib.parse import urlparse
        parsed = urlparse(ctx.obj["config"]["master_url"])
        if parsed.hostname:
            cmd.extend(["--host", parsed.hostname])
        if parsed.port:
            cmd.extend(["--port", str(parsed.port)])

    if port:
        cmd.extend(["--port", str(port)])

    # Add node options
    if display_name:
        cmd.extend(["--name", display_name])

    if tags:
        cmd.extend(["--tags", tags])

    if workdir_root:
        cmd.extend(["--workdir-root", workdir_root])

    if node_password:
        cmd.extend(["--node-password", node_password])

    if verbose:
        cmd.append("--verbose")

    # Set environment variable for config file if provided
    env = os.environ.copy()
    if config:
        env["NODE_CONFIG_FILE"] = str(Path(config).absolute())
        click.echo(f"Using node configuration: {config}")

    try:
        click.echo("=" * 60)
        click.echo("🚀 Starting Codernetes Node")
        click.echo("=" * 60)
        click.echo()

        # Run the node client
        result = subprocess.run(cmd, env=env, check=False)
        sys.exit(result.returncode)

    except KeyboardInterrupt:
        click.echo("\n\n⚠️  Node stopped by user")
        sys.exit(0)
    except Exception as e:
        click.echo(f"\n✗ Failed to start node: {e}", err=True)
        sys.exit(1)

"""
Job management commands
"""

import click
import json
import asyncio
from typing import Optional
from c8s.api_client import APIClient
from c8s.formatters import format_table


@click.group()
def job():
    """Manage Codernetes jobs"""
    pass


@job.command("submit")
@click.option("--prompt", "-p", required=True, help="Job prompt/instruction")
@click.option("--repo", "-r", multiple=True, help="Repository URL (can be specified multiple times)")
@click.option("--agent", "-a", default="azure-ai", help="Agent type (azure-ai, claude-code, codex)")
@click.option("--node", "-n", default=None, help="Target node ID (auto-select if not specified)")
@click.option("--tags", default="", help="Comma-separated required tags")
@click.option("--retries", type=int, default=0, help="Maximum retry attempts")
@click.option("-o", "--output", type=click.Choice(["json", "table"]), default="table", help="Output format")
@click.pass_context
def submit_job(ctx, prompt: str, repo: tuple, agent: str, node: Optional[str], tags: str, retries: int, output: str):
    """
    Submit a new job to Codernetes

    Examples:
        c8s job submit -p "Fix auth bug" -r https://github.com/user/repo.git
        c8s job submit -p "Add tests" -r repo1 -r repo2 --agent claude-code
        c8s job submit -p "Update docs" -r myrepo --tags gpu,staging
    """
    client = APIClient(ctx.obj["config"].get("master_url", "http://localhost:8080"))

    if not repo:
        click.echo("✗ At least one repository is required (--repo)", err=True)
        raise click.Abort()

    tag_list = [t.strip() for t in tags.split(",") if t.strip()]

    payload = {
        "prompt": prompt,
        "repositories": [{"url": r} for r in repo],
        "agent_type": agent,
        "target_node_id": node or "",
        "requested_tags": tag_list,
        "max_retries": retries,
        "origin": "cli",
    }

    try:
        result = asyncio.run(client.submit_job(payload))
        job_data = result.get("job", {})

        if output == "json":
            click.echo(json.dumps(job_data, indent=2))
        else:
            click.echo(f"✓ Job submitted successfully")
            click.echo(f"  Job ID: {job_data.get('job_id')}")
            click.echo(f"  Status: {job_data.get('status')}")
            click.echo(f"  Agent: {job_data.get('agent_type', agent)}")
            if node:
                click.echo(f"  Target Node: {node}")
            else:
                click.echo(f"  Target Node: auto-select")
            click.echo(f"\n  Use 'c8s job logs {job_data.get('job_id')}' to view logs")

    except Exception as e:
        click.echo(f"✗ Failed to submit job: {e}", err=True)
        raise click.Abort()


@job.command("list")
@click.option("--status", default=None, help="Filter by status")
@click.option("--limit", "-l", type=int, default=20, help="Number of jobs to show")
@click.option("-o", "--output", type=click.Choice(["json", "table", "wide"]), default="table", help="Output format")
@click.pass_context
def list_jobs(ctx, status: Optional[str], limit: int, output: str):
    """
    List jobs

    Examples:
        c8s job list
        c8s job list --status running
        c8s job list --limit 50 -o wide
    """
    client = APIClient(ctx.obj["config"].get("master_url", "http://localhost:8080"))

    try:
        result = asyncio.run(client.list_jobs())
        jobs = result.get("jobs", [])

        # Filter by status
        if status:
            jobs = [j for j in jobs if j.get("status") == status]

        # Limit
        jobs = jobs[:limit]

        if output == "json":
            click.echo(json.dumps(jobs, indent=2))
        elif output == "wide":
            headers = ["JOB ID", "STATUS", "PROMPT", "AGENT", "NODE", "CREATED"]
            rows = []
            for j in jobs:
                rows.append([
                    j.get("job_id", "")[:12],
                    j.get("status", ""),
                    j.get("prompt", "")[:50] + ("..." if len(j.get("prompt", "")) > 50 else ""),
                    j.get("agent_type", ""),
                    j.get("target_node_id", "auto")[:12],
                    j.get("created_at", ""),
                ])
            click.echo(format_table(headers, rows))
        else:
            headers = ["JOB ID", "STATUS", "PROMPT"]
            rows = []
            for j in jobs:
                rows.append([
                    j.get("job_id", "")[:12],
                    j.get("status", ""),
                    j.get("prompt", "")[:60] + ("..." if len(j.get("prompt", "")) > 60 else ""),
                ])
            click.echo(format_table(headers, rows))

    except Exception as e:
        click.echo(f"✗ Failed to list jobs: {e}", err=True)
        raise click.Abort()


@job.command("get")
@click.argument("job_id")
@click.option("-o", "--output", type=click.Choice(["json", "yaml"]), default="json", help="Output format")
@click.pass_context
def get_job(ctx, job_id: str, output: str):
    """
    Get detailed information about a specific job

    Examples:
        c8s job get abc123
        c8s job get abc123 -o yaml
    """
    client = APIClient(ctx.obj["config"].get("master_url", "http://localhost:8080"))

    try:
        result = asyncio.run(client.get_job(job_id))
        job_data = result.get("job", {})

        if output == "json":
            click.echo(json.dumps(job_data, indent=2))
        else:
            # YAML-like output
            click.echo(f"job_id: {job_data.get('job_id')}")
            click.echo(f"status: {job_data.get('status')}")
            click.echo(f"prompt: |")
            for line in job_data.get('prompt', '').split('\n'):
                click.echo(f"  {line}")
            click.echo(f"agent_type: {job_data.get('agent_type')}")
            click.echo(f"target_node_id: {job_data.get('target_node_id', 'auto')}")
            click.echo(f"created_at: {job_data.get('created_at')}")
            if job_data.get('finished_at'):
                click.echo(f"finished_at: {job_data.get('finished_at')}")
            if job_data.get('repositories'):
                click.echo(f"repositories:")
                for repo in job_data.get('repositories', []):
                    click.echo(f"  - {repo.get('url')}")

    except Exception as e:
        click.echo(f"✗ Failed to get job: {e}", err=True)
        raise click.Abort()


@job.command("logs")
@click.argument("job_id")
@click.option("--follow", "-f", is_flag=True, help="Stream logs in real-time")
@click.option("--tail", "-n", type=int, default=None, help="Number of lines to show from the end")
@click.pass_context
def job_logs(ctx, job_id: str, follow: bool, tail: Optional[int]):
    """
    View job logs

    Examples:
        c8s job logs abc123
        c8s job logs abc123 --follow
        c8s job logs abc123 --tail 50
    """
    client = APIClient(ctx.obj["config"].get("master_url", "http://localhost:8080"))

    try:
        if follow:
            # TODO: Implement log streaming
            click.echo("Log streaming not yet implemented. Use --tail instead.", err=True)
            raise click.Abort()

        result = asyncio.run(client.get_job_logs(job_id))
        logs = result.get("logs", [])

        if tail:
            logs = logs[-tail:]

        for log in logs:
            timestamp = log.get("timestamp", "")
            level = log.get("level", "INFO").upper()
            message = log.get("message", "")
            click.echo(f"[{timestamp}] [{level}] {message}")

        if not logs:
            click.echo("No logs available yet.")

    except Exception as e:
        click.echo(f"✗ Failed to get logs: {e}", err=True)
        raise click.Abort()


@job.command("delete")
@click.argument("job_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
@click.pass_context
def delete_job(ctx, job_id: str, yes: bool):
    """
    Delete a job (cancels if running)

    Examples:
        c8s job delete abc123
        c8s job delete abc123 -y
    """
    if not yes:
        click.confirm(f"Are you sure you want to delete job {job_id}?", abort=True)

    click.echo("Job deletion not yet implemented.", err=True)
    raise click.Abort()

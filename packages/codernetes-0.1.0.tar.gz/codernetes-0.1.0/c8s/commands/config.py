"""
Configuration management commands
"""

import click
import json
from pathlib import Path
from typing import Optional


@click.group()
def config():
    """Manage c8s configuration"""
    pass


@config.command("set-context")
@click.option("--master", "-m", required=True, help="Master server URL")
@click.option("--name", "-n", default="default", help="Context name")
@click.pass_context
def set_context(ctx, master: str, name: str):
    """
    Set or create a configuration context

    Examples:
        c8s config set-context --master http://localhost:8080
        c8s config set-context --master http://prod.example.com:8080 --name production
    """
    config_path = ctx.obj["config_path"]

    # Ensure config directory exists
    config_path.parent.mkdir(parents=True, exist_ok=True)

    # Load or create config
    if config_path.exists():
        with open(config_path, "r") as f:
            config_data = json.load(f)
    else:
        config_data = {"contexts": {}, "current_context": None}

    # Update context
    config_data["contexts"][name] = {"master_url": master}
    config_data["current_context"] = name

    # Save config
    with open(config_path, "w") as f:
        json.dump(config_data, f, indent=2)

    click.echo(f"✓ Context '{name}' set")
    click.echo(f"  Master URL: {master}")
    click.echo(f"  Config: {config_path}")


@config.command("view")
@click.option("-o", "--output", type=click.Choice(["json", "yaml"]), default="yaml", help="Output format")
@click.pass_context
def view_config(ctx, output: str):
    """
    View current configuration

    Examples:
        c8s config view
        c8s config view -o json
    """
    config_path = ctx.obj["config_path"]

    if not config_path.exists():
        click.echo("No configuration file found.", err=True)
        click.echo(f"Create one with: c8s config set-context --master <url>", err=True)
        raise click.Abort()

    with open(config_path, "r") as f:
        config_data = json.load(f)

    if output == "json":
        click.echo(json.dumps(config_data, indent=2))
    else:
        # YAML-like output
        click.echo(f"config_file: {config_path}")
        click.echo(f"current_context: {config_data.get('current_context', 'none')}")
        click.echo("contexts:")
        for name, ctx_data in config_data.get("contexts", {}).items():
            click.echo(f"  {name}:")
            click.echo(f"    master_url: {ctx_data.get('master_url')}")


@config.command("current-context")
@click.pass_context
def current_context(ctx):
    """
    Show current context

    Examples:
        c8s config current-context
    """
    config_path = ctx.obj["config_path"]

    if not config_path.exists():
        click.echo("No configuration file found.", err=True)
        raise click.Abort()

    with open(config_path, "r") as f:
        config_data = json.load(f)

    current = config_data.get("current_context")
    if not current:
        click.echo("No context set.", err=True)
        raise click.Abort()

    contexts = config_data.get("contexts", {})
    if current not in contexts:
        click.echo(f"Context '{current}' not found.", err=True)
        raise click.Abort()

    ctx_data = contexts[current]
    click.echo(f"Current context: {current}")
    click.echo(f"Master URL: {ctx_data.get('master_url')}")


@config.command("use-context")
@click.argument("name")
@click.pass_context
def use_context(ctx, name: str):
    """
    Switch to a different context

    Examples:
        c8s config use-context production
        c8s config use-context default
    """
    config_path = ctx.obj["config_path"]

    if not config_path.exists():
        click.echo("No configuration file found.", err=True)
        raise click.Abort()

    with open(config_path, "r") as f:
        config_data = json.load(f)

    contexts = config_data.get("contexts", {})
    if name not in contexts:
        click.echo(f"✗ Context '{name}' not found.", err=True)
        available = ", ".join(contexts.keys()) if contexts else "none"
        click.echo(f"Available contexts: {available}", err=True)
        raise click.Abort()

    config_data["current_context"] = name

    with open(config_path, "w") as f:
        json.dump(config_data, f, indent=2)

    click.echo(f"✓ Switched to context '{name}'")
    click.echo(f"  Master URL: {contexts[name].get('master_url')}")

"""
Metric collectors for monitoring
"""

import aiohttp
import asyncio
import json
from typing import Dict, Any, Optional
from dataclasses import dataclass
import logging
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class CLIUsageMetrics:
    """CLI usage metrics from Claude Code and Codex"""

    provider: str  # 'claude-code' or 'codex'

    # For Claude Code
    session_percent: Optional[float] = None
    weekly_all_percent: Optional[float] = None
    weekly_opus_percent: Optional[float] = None

    # For Codex
    hourly_5h_percent: Optional[float] = None
    weekly_percent: Optional[float] = None

    # Reset times
    session_reset: Optional[str] = None
    weekly_reset: Optional[str] = None
    opus_reset: Optional[str] = None
    hourly_reset: Optional[str] = None


@dataclass
class APIUsageMetrics:
    """API usage metrics"""

    provider: str  # 'claude' or 'codex'
    total_requests: int = 0
    total_tokens: int = 0
    limit_requests: Optional[int] = None
    limit_tokens: Optional[int] = None

    @property
    def request_usage_percent(self) -> Optional[float]:
        """Calculate request usage percentage"""
        if self.limit_requests and self.limit_requests > 0:
            return (self.total_requests / self.limit_requests) * 100
        return None

    @property
    def token_usage_percent(self) -> Optional[float]:
        """Calculate token usage percentage"""
        if self.limit_tokens and self.limit_tokens > 0:
            return (self.total_tokens / self.limit_tokens) * 100
        return None


@dataclass
class JobMetrics:
    """Job execution metrics"""

    total: int = 0
    pending: int = 0
    running: int = 0
    completed: int = 0
    failed: int = 0
    cancelled: int = 0


@dataclass
class NodeMetrics:
    """Node status metrics"""

    total: int = 0
    active: int = 0
    inactive: int = 0
    busy: int = 0


@dataclass
class SystemMetrics:
    """Complete system metrics"""

    claude_api: Optional[APIUsageMetrics] = None
    codex_api: Optional[APIUsageMetrics] = None
    claude_code_cli: Optional[CLIUsageMetrics] = None
    codex_cli: Optional[CLIUsageMetrics] = None
    jobs: Optional[JobMetrics] = None
    nodes: Optional[NodeMetrics] = None


class MetricsCollector:
    """Collects metrics from Codernetes Master API"""

    def __init__(self, master_url: str, timeout: int = 10):
        self.master_url = master_url.rstrip("/")
        self.timeout = aiohttp.ClientTimeout(total=timeout)

    async def _get(self, endpoint: str) -> Optional[Dict[str, Any]]:
        """Make GET request to Master API"""
        url = f"{self.master_url}{endpoint}"

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=self.timeout) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        logger.error(f"API request failed: {url} - {response.status}")
                        return None
        except Exception as e:
            logger.error(f"Error fetching {url}: {e}")
            return None

    async def collect_api_usage(self, provider: str) -> Optional[APIUsageMetrics]:
        """
        Collect API usage metrics for Claude or Codex

        Note: This requires the Master API to expose usage endpoints.
        The endpoint format is: /api/usage/{provider}
        """
        data = await self._get(f"/api/usage/{provider}")

        if not data:
            logger.warning(f"Could not fetch {provider} API usage")
            return None

        return APIUsageMetrics(
            provider=provider,
            total_requests=data.get("total_requests", 0),
            total_tokens=data.get("total_tokens", 0),
            limit_requests=data.get("limit_requests"),
            limit_tokens=data.get("limit_tokens"),
        )

    async def collect_job_metrics(self) -> Optional[JobMetrics]:
        """Collect job execution metrics"""
        data = await self._get("/api/jobs")

        if not data:
            logger.warning("Could not fetch job metrics")
            return None

        jobs = data.get("jobs", [])

        metrics = JobMetrics(total=len(jobs))

        for job in jobs:
            status = job.get("status", "").lower()

            if status == "pending":
                metrics.pending += 1
            elif status == "running":
                metrics.running += 1
            elif status == "completed":
                metrics.completed += 1
            elif status == "failed":
                metrics.failed += 1
            elif status == "cancelled":
                metrics.cancelled += 1

        return metrics

    async def collect_node_metrics(self) -> Optional[NodeMetrics]:
        """Collect node status metrics"""
        data = await self._get("/api/nodes")

        if not data:
            logger.warning("Could not fetch node metrics")
            return None

        nodes = data.get("nodes", [])

        metrics = NodeMetrics(total=len(nodes))

        for node in nodes:
            status = node.get("status", "").lower()

            if status == "active":
                metrics.active += 1
            elif status == "inactive":
                metrics.inactive += 1

            # Check if node is currently processing a job
            if node.get("current_job"):
                metrics.busy += 1

        return metrics

    async def collect_all(
        self,
        collect_claude: bool = True,
        collect_codex: bool = True,
        collect_jobs: bool = True,
        collect_nodes: bool = True,
    ) -> SystemMetrics:
        """Collect all metrics"""
        metrics = SystemMetrics()

        if collect_claude:
            metrics.claude_api = await self.collect_api_usage("claude")

        if collect_codex:
            metrics.codex_api = await self.collect_api_usage("codex")

        if collect_jobs:
            metrics.jobs = await self.collect_job_metrics()

        if collect_nodes:
            metrics.nodes = await self.collect_node_metrics()

        return metrics


class StandaloneAPICollector:
    """Collects API usage metrics directly from Anthropic and OpenAI APIs"""

    def __init__(self, timeout: int = 10):
        self.timeout = aiohttp.ClientTimeout(total=timeout)

    async def collect_anthropic_usage(
        self, api_key: str
    ) -> Optional[APIUsageMetrics]:
        """
        Collect Claude API usage from Anthropic response headers

        Strategy: Make a minimal API call to get rate limit headers
        - anthropic-ratelimit-requests-limit
        - anthropic-ratelimit-requests-remaining
        - anthropic-ratelimit-tokens-limit
        - anthropic-ratelimit-tokens-remaining

        Usage calculation:
        - used_requests = limit - remaining
        - used_tokens = limit - remaining
        - usage_percent = (used / limit) * 100
        """
        url = "https://api.anthropic.com/v1/messages"

        headers = {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }

        # Minimal request to get headers with lowest cost
        # Using count_tokens would be better but messages endpoint works too
        payload = {
            "model": "claude-3-haiku-20240307",  # Cheapest model
            "max_tokens": 1,  # Minimal tokens
            "messages": [{"role": "user", "content": "hi"}],  # Shortest message
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url, headers=headers, json=payload, timeout=self.timeout
                ) as response:
                    # Parse rate limit headers
                    headers_dict = response.headers

                    # Request limits
                    req_limit = headers_dict.get("anthropic-ratelimit-requests-limit")
                    req_remaining = headers_dict.get(
                        "anthropic-ratelimit-requests-remaining"
                    )

                    # Token limits
                    token_limit = headers_dict.get("anthropic-ratelimit-tokens-limit")
                    token_remaining = headers_dict.get(
                        "anthropic-ratelimit-tokens-remaining"
                    )

                    # Convert to integers
                    try:
                        req_limit = int(req_limit) if req_limit else None
                        req_remaining = int(req_remaining) if req_remaining else None
                        token_limit = int(token_limit) if token_limit else None
                        token_remaining = (
                            int(token_remaining) if token_remaining else None
                        )
                    except (ValueError, TypeError):
                        logger.error(
                            "Failed to parse Anthropic rate limit headers as integers"
                        )
                        return None

                    # Calculate usage
                    if req_limit and req_remaining is not None:
                        total_requests = req_limit - req_remaining
                    else:
                        total_requests = 0

                    if token_limit and token_remaining is not None:
                        total_tokens = token_limit - token_remaining
                    else:
                        total_tokens = 0

                    if response.status == 200:
                        logger.info(
                            f"Anthropic usage collected: {total_requests}/{req_limit} requests, "
                            f"{total_tokens}/{token_limit} tokens"
                        )

                        return APIUsageMetrics(
                            provider="claude",
                            total_requests=total_requests,
                            total_tokens=total_tokens,
                            limit_requests=req_limit,
                            limit_tokens=token_limit,
                        )
                    elif response.status == 401:
                        logger.error(
                            "Anthropic API authentication failed. Check your API key."
                        )
                        return None
                    else:
                        # Even on error, if we got headers, use them
                        if req_limit or token_limit:
                            logger.warning(
                                f"Anthropic API returned {response.status}, but headers available"
                            )
                            return APIUsageMetrics(
                                provider="claude",
                                total_requests=total_requests,
                                total_tokens=total_tokens,
                                limit_requests=req_limit,
                                limit_tokens=token_limit,
                            )

                        logger.error(
                            f"Anthropic API request failed: {response.status}"
                        )
                        return None

        except Exception as e:
            logger.error(f"Error fetching Anthropic usage: {e}")
            return None

    async def collect_openai_usage(self, api_key: str) -> Optional[APIUsageMetrics]:
        """
        Collect Codex API usage directly from OpenAI

        Endpoint discovered from openai/codex repository:
        - GET /api/codex/usage
        - Returns rate limit information with usage percentages
        - Authentication: Bearer token

        Response structure:
        {
          "plan_type": "free|plus|pro|team|enterprise|...",
          "rate_limit": {
            "primary_window": {
              "used_percent": 45,
              "limit_window_seconds": 3600,
              "reset_after_seconds": 1200,
              "reset_at": 1730534400
            }
          }
        }
        """
        url = "https://api.openai.com/api/codex/usage"

        headers = {
            "Authorization": f"Bearer {api_key}",
            "User-Agent": "c8s-monitor",
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url, headers=headers, timeout=self.timeout
                ) as response:
                    if response.status == 200:
                        data = await response.json()

                        # Extract rate limit data from Codex API response
                        rate_limit = data.get("rate_limit", {})
                        primary_window = rate_limit.get("primary_window") or {}

                        used_percent = primary_window.get("used_percent", 0)
                        reset_at = primary_window.get("reset_at")

                        # Note: Codex API provides percentage, not absolute numbers
                        # We'll store used_percent as a pseudo-metric
                        return APIUsageMetrics(
                            provider="codex",
                            total_requests=0,  # Not provided by Codex API
                            total_tokens=used_percent,  # Store percentage as tokens for now
                            limit_requests=None,
                            limit_tokens=100,  # Percentage limit is always 100
                        )
                    elif response.status == 401:
                        logger.error(
                            "OpenAI API authentication failed. Check your API key."
                        )
                        return None
                    elif response.status == 404:
                        logger.warning(
                            "Codex usage endpoint not found. Your API key may not have access."
                        )
                        return None
                    else:
                        logger.error(
                            f"OpenAI Codex usage API request failed: {response.status}"
                        )
                        text = await response.text()
                        logger.debug(f"Response: {text}")
                        return None
        except Exception as e:
            logger.error(f"Error fetching OpenAI Codex usage: {e}")
            return None


class CLIAPICollector:
    """Collects CLI usage via direct API calls (not CLI automation)"""

    def __init__(self, timeout: int = 10):
        self.timeout = timeout

    async def collect_claude_code_usage_from_usage_command(self) -> Optional[CLIUsageMetrics]:
        """
        Collect Claude Code usage by executing /usage command via tmux

        This method:
        1. Creates a tmux session
        2. Runs claude CLI
        3. Sends /usage command
        4. Captures and parses output
        5. Returns exact percentages from Claude

        This provides EXACT usage matching the /usage command.
        """
        try:
            import subprocess
            import re
            import time
            import random

            # Generate unique session name
            session_name = f"claude_usage_{random.randint(10000, 99999)}"

            # Create detached tmux session with claude
            subprocess.run(
                ['/usr/bin/tmux', 'new-session', '-d', '-s', session_name, 'claude'],
                check=True,
                capture_output=True
            )

            # Wait for claude to start
            await asyncio.sleep(2)

            # Type partial command
            subprocess.run(
                ['/usr/bin/tmux', 'send-keys', '-t', session_name, '/usa'],
                check=True
            )
            await asyncio.sleep(0.3)

            # Press Tab to autocomplete
            subprocess.run(
                ['/usr/bin/tmux', 'send-keys', '-t', session_name, 'Tab'],
                check=True
            )
            await asyncio.sleep(0.3)

            # Press Enter to execute
            subprocess.run(
                ['/usr/bin/tmux', 'send-keys', '-t', session_name, 'Enter'],
                check=True
            )

            # Wait for usage screen to render
            await asyncio.sleep(5)

            # Capture pane content
            result = subprocess.run(
                ['/usr/bin/tmux', 'capture-pane', '-t', session_name, '-p'],
                capture_output=True,
                text=True,
                check=True
            )
            output = result.stdout

            # Clean up tmux session
            subprocess.run(
                ['/usr/bin/tmux', 'kill-session', '-t', session_name],
                check=False  # Don't fail if session already closed
            )

            # Parse percentages
            session_match = re.search(r'Current session.*?(\d+)% used', output, re.DOTALL)
            weekly_all_match = re.search(r'Current week \(all models\).*?(\d+)% used', output, re.DOTALL)
            weekly_opus_match = re.search(r'Current week \(Opus\).*?(\d+)% used', output, re.DOTALL)

            # Parse reset times
            session_reset_match = re.search(r'Current session.*?Resets ([^\n]+)', output, re.DOTALL)
            weekly_reset_match = re.search(r'Current week \(all models\).*?Resets ([^\n]+)', output, re.DOTALL)
            opus_reset_match = re.search(r'Current week \(Opus\).*?Resets ([^\n]+)', output, re.DOTALL)

            if session_match or weekly_all_match or weekly_opus_match:
                session_percent = float(session_match.group(1)) if session_match else None
                weekly_all_percent = float(weekly_all_match.group(1)) if weekly_all_match else None
                weekly_opus_percent = float(weekly_opus_match.group(1)) if weekly_opus_match else None

                session_reset = session_reset_match.group(1).strip() if session_reset_match else None
                weekly_reset = weekly_reset_match.group(1).strip() if weekly_reset_match else None
                opus_reset = opus_reset_match.group(1).strip() if opus_reset_match else None

                logger.info(
                    f"Claude Code usage (from /usage command): "
                    f"session={session_percent}% (resets {session_reset}), "
                    f"weekly_all={weekly_all_percent}% (resets {weekly_reset}), "
                    f"weekly_opus={weekly_opus_percent}% (resets {opus_reset})"
                )

                return CLIUsageMetrics(
                    provider="claude-code",
                    session_percent=session_percent,
                    weekly_all_percent=weekly_all_percent,
                    weekly_opus_percent=weekly_opus_percent,
                    session_reset=session_reset,
                    weekly_reset=weekly_reset,
                    opus_reset=opus_reset,
                )
            else:
                logger.warning("Failed to parse /usage output")
                logger.debug(f"Output was: {output}")
                return None

        except Exception as e:
            logger.error(f"Error collecting Claude Code usage from /usage command: {e}")
            import traceback
            logger.debug(traceback.format_exc())
            return None

    async def collect_claude_code_usage(self) -> Optional[CLIUsageMetrics]:
        """
        Collect Claude Code usage - tries /usage command first, falls back to JSONL

        Primary method: Execute /usage command via tmux (exact percentages)
        Fallback method: Parse JSONL files (estimated percentages)
        """
        # Try tmux-based /usage command first (exact)
        result = await self.collect_claude_code_usage_from_usage_command()
        if result:
            return result

        # Fallback to JSONL parsing (estimated)
        logger.info("Falling back to JSONL parsing for Claude Code usage")
        return await self.collect_claude_code_usage_from_jsonl()

    async def collect_claude_code_usage_from_jsonl(self) -> Optional[CLIUsageMetrics]:
        """
        Collect Claude Code usage by parsing local JSONL files

        Source: ~/.claude/projects/**/*.jsonl
        Method: Session-block based calculation matching external projects

        This implementation follows the approach used by:
        - https://github.com/Maciek-roboblog/Claude-Code-Usage-Monitor
        - https://github.com/ryoppippi/ccusage

        Key features:
        1. Timestamps are floored to UTC hour (e.g., 14:37 → 14:00)
        2. Sessions are 5-hour blocks starting from floored hour
        3. Current session = block with last activity within 5h AND now < block end
        4. Weekly usage = sum of all sessions in last 7 days

        Cache tokens (cache_creation/cache_read) are excluded from
        usage calculations as they don't count toward rate limits.

        Note: This provides ESTIMATED usage (±30% variance from /usage command)
        """
        try:
            from pathlib import Path
            from datetime import datetime, timedelta, timezone
            from typing import List, Dict, Any

            # Plan limits (tokens per session)
            PLAN_LIMITS = {
                "pro": {"session": 19_000, "weekly": 19_000 * 7},
                "max": {"session": 88_000, "weekly": 88_000 * 7},  # Max5
                "max5": {"session": 88_000, "weekly": 88_000 * 7},
                "max20": {"session": 220_000, "weekly": 220_000 * 7},
            }

            SESSION_DURATION_HOURS = 5

            def floor_to_hour(dt: datetime) -> datetime:
                """Floor timestamp to UTC hour (e.g., 14:37 → 14:00)"""
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                elif dt.tzinfo != timezone.utc:
                    dt = dt.astimezone(timezone.utc)
                return dt.replace(minute=0, second=0, microsecond=0)

            # Read plan from credentials
            auth_path = Path.home() / ".claude" / ".credentials.json"
            if not auth_path.exists():
                logger.warning(f"Claude credentials not found at {auth_path}")
                return None

            with open(auth_path) as f:
                auth_data = json.load(f)

            plan_type = auth_data.get("claudeAiOauth", {}).get("subscriptionType", "max")
            plan_limits = PLAN_LIMITS.get(plan_type.lower(), PLAN_LIMITS["max"])

            # Find all JSONL files in projects
            projects_dir = Path.home() / ".claude" / "projects"
            if not projects_dir.exists():
                logger.warning(f"Claude projects directory not found: {projects_dir}")
                return None

            # Collect all entries with timestamps
            all_entries: List[Dict[str, Any]] = []

            for jsonl_file in projects_dir.rglob("*.jsonl"):
                try:
                    with open(jsonl_file, "r") as f:
                        for line in f:
                            if not line.strip():
                                continue

                            try:
                                entry = json.loads(line)
                            except json.JSONDecodeError:
                                continue

                            # Extract usage from assistant messages
                            if entry.get("type") == "assistant" and "message" in entry:
                                message = entry["message"]
                                usage = message.get("usage", {})
                                timestamp_str = entry.get("timestamp")

                                if not timestamp_str:
                                    continue

                                # Parse timestamp
                                try:
                                    timestamp = datetime.fromisoformat(
                                        timestamp_str.replace("Z", "+00:00")
                                    )
                                except (ValueError, AttributeError):
                                    continue

                                # Calculate total tokens (excluding cache for usage limits)
                                tokens = (
                                    usage.get("input_tokens", 0)
                                    + usage.get("output_tokens", 0)
                                )

                                if tokens > 0:
                                    all_entries.append({
                                        "timestamp": timestamp,
                                        "tokens": tokens,
                                        "model": message.get("model", ""),
                                    })

                except Exception as e:
                    logger.debug(f"Error reading {jsonl_file}: {e}")

            if not all_entries:
                logger.warning("No usage entries found in JSONL files")
                return None

            # Sort entries by timestamp
            all_entries.sort(key=lambda e: e["timestamp"])

            now = datetime.now(timezone.utc)
            session_duration = timedelta(hours=SESSION_DURATION_HOURS)
            week_ago = now - timedelta(days=7)

            # Group entries into session blocks
            session_blocks: List[Dict[str, Any]] = []
            current_block = None

            for entry in all_entries:
                entry_time = entry["timestamp"]

                if current_block is None:
                    # Start first block (floored to hour)
                    block_start = floor_to_hour(entry_time)
                    current_block = {
                        "start": block_start,
                        "end": block_start + session_duration,
                        "entries": [entry],
                        "tokens": entry["tokens"],
                        "opus_tokens": entry["tokens"] if "opus" in entry["model"].lower() else 0,
                        "last_activity": entry_time,
                    }
                else:
                    # Check if entry fits in current block
                    time_since_block_start = entry_time - current_block["start"]
                    time_since_last_entry = entry_time - current_block["last_activity"]

                    if (time_since_block_start > session_duration or
                        time_since_last_entry > session_duration):
                        # Close current block and start new one
                        session_blocks.append(current_block)

                        block_start = floor_to_hour(entry_time)
                        current_block = {
                            "start": block_start,
                            "end": block_start + session_duration,
                            "entries": [entry],
                            "tokens": entry["tokens"],
                            "opus_tokens": entry["tokens"] if "opus" in entry["model"].lower() else 0,
                            "last_activity": entry_time,
                        }
                    else:
                        # Add to current block
                        current_block["entries"].append(entry)
                        current_block["tokens"] += entry["tokens"]
                        if "opus" in entry["model"].lower():
                            current_block["opus_tokens"] += entry["tokens"]
                        current_block["last_activity"] = entry_time

            # Don't forget the last block
            if current_block:
                session_blocks.append(current_block)

            # Find current active session
            # Active = last activity within 5h AND now < block end
            active_session = None
            for block in reversed(session_blocks):
                time_since_last = now - block["last_activity"]
                if time_since_last < session_duration and now < block["end"]:
                    active_session = block
                    break

            # Calculate session tokens
            session_tokens = active_session["tokens"] if active_session else 0

            # Calculate weekly tokens (all sessions in last 7 days)
            weekly_tokens = 0
            opus_weekly_tokens = 0
            for block in session_blocks:
                if block["start"] >= week_ago:
                    weekly_tokens += block["tokens"]
                    opus_weekly_tokens += block["opus_tokens"]

            # Calculate percentages
            session_percent = (
                (session_tokens / plan_limits["session"]) * 100
                if plan_limits["session"] > 0
                else 0
            )
            weekly_percent = (
                (weekly_tokens / plan_limits["weekly"]) * 100
                if plan_limits["weekly"] > 0
                else 0
            )
            opus_weekly_percent = (
                (opus_weekly_tokens / plan_limits["weekly"]) * 100
                if plan_limits["weekly"] > 0
                else 0
            )

            logger.info(
                f"Claude Code usage (session-block method): "
                f"session={session_tokens} tokens ({session_percent:.1f}%), "
                f"weekly={weekly_tokens} tokens ({weekly_percent:.1f}%), "
                f"opus_weekly={opus_weekly_tokens} tokens ({opus_weekly_percent:.1f}%), "
                f"total_blocks={len(session_blocks)}, "
                f"active_session={active_session is not None}"
            )

            return CLIUsageMetrics(
                provider="claude-code",
                session_percent=float(session_percent),
                weekly_all_percent=float(weekly_percent),
                weekly_opus_percent=float(opus_weekly_percent),
            )

        except Exception as e:
            logger.error(f"Error collecting Claude Code usage from JSONL: {e}")
            return None

    async def collect_codex_usage(self) -> Optional[CLIUsageMetrics]:
        """
        Collect Codex usage from ChatGPT API

        Uses the endpoint: https://chatgpt.com/backend-api/wham/usage
        Authentication: Bearer token from ~/.codex/auth.json
        """
        try:
            # Read auth token
            from pathlib import Path
            import json

            auth_path = Path.home() / ".codex" / "auth.json"
            if not auth_path.exists():
                logger.warning(f"Codex auth file not found at {auth_path}")
                return None

            with open(auth_path) as f:
                auth_data = json.load(f)

            if "tokens" not in auth_data or "access_token" not in auth_data["tokens"]:
                logger.warning("Codex auth file missing tokens.access_token")
                return None

            access_token = auth_data["tokens"]["access_token"]

            # Call API
            url = "https://chatgpt.com/backend-api/wham/usage"
            headers = {
                "Authorization": f"Bearer {access_token}",
                "User-Agent": "Codernetes-Monitor/1.0",
            }

            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url, headers=headers, timeout=aiohttp.ClientTimeout(total=self.timeout)
                ) as response:
                    response.raise_for_status()
                    data = await response.json()

            # Parse response
            rate_limit = data.get("rate_limit", {})
            primary = rate_limit.get("primary_window", {})
            secondary = rate_limit.get("secondary_window", {})

            hourly_percent = primary.get("used_percent")
            weekly_percent = secondary.get("used_percent")

            if hourly_percent is not None or weekly_percent is not None:
                logger.info(f"Codex usage: 5h={hourly_percent}%, weekly={weekly_percent}%")

                return CLIUsageMetrics(
                    provider="codex",
                    hourly_5h_percent=float(hourly_percent) if hourly_percent is not None else None,
                    weekly_percent=float(weekly_percent) if weekly_percent is not None else None,
                )
            else:
                logger.warning("Codex API response missing usage data")
                return None

        except FileNotFoundError as e:
            logger.warning(f"Codex auth file not found: {e}")
            return None
        except aiohttp.ClientError as e:
            logger.error(f"Codex API request failed: {e}")
            return None
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse Codex API response: {e}")
            return None
        except Exception as e:
            logger.error(f"Error collecting Codex usage: {e}")
            return None


def create_progress_bar(percent: float, width: int = 30) -> str:
    """Create a Unicode progress bar

    Args:
        percent: Percentage (0-100)
        width: Total width of the bar in characters

    Returns:
        Progress bar string using █ for filled and ░ for empty

    Example:
        >>> create_progress_bar(72, 30)
        '█████████████████████░░░░░░░░░'
    """
    if percent < 0:
        percent = 0
    if percent > 100:
        percent = 100

    filled = int(width * percent / 100)
    empty = width - filled

    return '█' * filled + '░' * empty


def format_metrics_summary(metrics: SystemMetrics) -> str:
    """Format metrics into human-readable summary with progress bars"""
    lines = ["```"]  # Start code block for fixed-width font

    # Claude Code CLI
    if metrics.claude_code_cli:
        cli = metrics.claude_code_cli
        lines.append("*Claude Code Usage:*")

        if cli.session_percent is not None:
            bar = create_progress_bar(cli.session_percent)
            reset_info = f" (resets {cli.session_reset})" if cli.session_reset else ""
            lines.append(f"  Session{reset_info:45s} {bar} {cli.session_percent:3.0f}%")

        if cli.weekly_all_percent is not None:
            bar = create_progress_bar(cli.weekly_all_percent)
            reset_info = f" (resets {cli.weekly_reset})" if cli.weekly_reset else ""
            lines.append(f"  Weekly all{reset_info:42s} {bar} {cli.weekly_all_percent:3.0f}%")

        if cli.weekly_opus_percent is not None:
            bar = create_progress_bar(cli.weekly_opus_percent)
            reset_info = f" (resets {cli.opus_reset})" if cli.opus_reset else ""
            lines.append(f"  Weekly Opus{reset_info:41s} {bar} {cli.weekly_opus_percent:3.0f}%")

        lines.append("")

    # Codex CLI
    if metrics.codex_cli:
        cli = metrics.codex_cli
        lines.append("*Codex Usage:*")

        if cli.hourly_5h_percent is not None:
            bar = create_progress_bar(cli.hourly_5h_percent)
            reset_info = f" (resets {cli.hourly_reset})" if cli.hourly_reset else ""
            lines.append(f"  5h limit{reset_info:46s} {bar} {cli.hourly_5h_percent:3.0f}%")

        if cli.weekly_percent is not None:
            bar = create_progress_bar(cli.weekly_percent)
            reset_info = f" (resets {cli.weekly_reset})" if cli.weekly_reset else ""
            lines.append(f"  Weekly{reset_info:48s} {bar} {cli.weekly_percent:3.0f}%")

        lines.append("")

    # Claude API
    if metrics.claude_api:
        lines.append("*Claude API Usage:*")
        api = metrics.claude_api

        if api.token_usage_percent is not None:
            lines.append(
                f"  • Tokens: {api.total_tokens:,} / {api.limit_tokens:,} ({api.token_usage_percent:.1f}%)"
            )
        else:
            lines.append(f"  • Tokens: {api.total_tokens:,}")

        if api.request_usage_percent is not None:
            lines.append(
                f"  • Requests: {api.total_requests:,} / {api.limit_requests:,} ({api.request_usage_percent:.1f}%)"
            )
        else:
            lines.append(f"  • Requests: {api.total_requests:,}")

        lines.append("")

    # Codex API
    if metrics.codex_api:
        lines.append("*Codex API Usage:*")
        api = metrics.codex_api

        if api.token_usage_percent is not None:
            lines.append(
                f"  • Tokens: {api.total_tokens:,} / {api.limit_tokens:,} ({api.token_usage_percent:.1f}%)"
            )
        else:
            lines.append(f"  • Tokens: {api.total_tokens:,}")

        if api.request_usage_percent is not None:
            lines.append(
                f"  • Requests: {api.total_requests:,} / {api.limit_requests:,} ({api.request_usage_percent:.1f}%)"
            )
        else:
            lines.append(f"  • Requests: {api.total_requests:,}")

        lines.append("")

    # Jobs
    if metrics.jobs:
        jobs = metrics.jobs
        lines.append("*Jobs:*")
        lines.append(f"  • Total: {jobs.total}")
        lines.append(f"  • Running: {jobs.running}")
        lines.append(f"  • Pending: {jobs.pending}")
        lines.append(f"  • Completed: {jobs.completed}")
        lines.append(f"  • Failed: {jobs.failed}")
        lines.append("")

    # Nodes
    if metrics.nodes:
        nodes = metrics.nodes
        lines.append("*Nodes:*")
        lines.append(f"  • Total: {nodes.total}")
        lines.append(f"  • Active: {nodes.active}")
        lines.append(f"  • Busy: {nodes.busy}")
        lines.append(f"  • Inactive: {nodes.inactive}")

    lines.append("```")  # Close code block
    return "\n".join(lines)

"""
Background monitoring daemon
"""

import asyncio
import signal
import sys
import logging
from pathlib import Path
from typing import Optional
from datetime import datetime

from .config import MonitorConfig
from .collectors import (
    MetricsCollector,
    StandaloneAPICollector,
    CLIAPICollector,
    SystemMetrics,
    format_metrics_summary,
)
from .notifiers import NotifierManager

logger = logging.getLogger(__name__)


class MonitorDaemon:
    """Background monitoring daemon"""

    def __init__(self, config: MonitorConfig):
        self.config = config

        # Choose collector based on mode
        if config.standalone_mode:
            logger.info("Initializing in STANDALONE mode (direct API monitoring)")
            self.standalone_collector = StandaloneAPICollector()
            self.collector = None
        else:
            logger.info("Initializing in INTEGRATED mode (Master API monitoring)")
            self.collector = MetricsCollector(config.master_url)
            self.standalone_collector = None

        # CLI collector works in both modes
        self.cli_collector = CLIAPICollector()

        self.notifier = NotifierManager(
            [
                n.to_dict() if hasattr(n, "to_dict") else n.__dict__
                for n in config.notifiers
            ]
        )
        self.running = False
        self.report_task: Optional[asyncio.Task] = None
        self.threshold_task: Optional[asyncio.Task] = None

        # Setup logging
        self._setup_logging()

        # Track last alert times to avoid spam
        self.last_alerts: dict = {}

    def _setup_logging(self):
        """Setup logging to file"""
        log_file = Path(self.config.log_file)
        log_file.parent.mkdir(parents=True, exist_ok=True)

        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(sys.stdout),
            ],
        )

    def _write_pid(self):
        """Write PID file"""
        import os
        pid_file = Path(self.config.pid_file)
        pid_file.parent.mkdir(parents=True, exist_ok=True)
        pid_file.write_text(str(os.getpid()))

    def _remove_pid(self):
        """Remove PID file"""
        pid_file = Path(self.config.pid_file)
        if pid_file.exists():
            pid_file.unlink()

    async def _collect_metrics(self) -> SystemMetrics:
        """Collect metrics based on mode (standalone or integrated)"""
        metrics = SystemMetrics()

        if self.config.standalone_mode:
            # Standalone mode: Direct API calls
            if self.config.monitor_claude_api and self.config.anthropic_api_key:
                metrics.claude_api = await self.standalone_collector.collect_anthropic_usage(
                    self.config.anthropic_api_key
                )

            if self.config.monitor_codex_api and self.config.openai_api_key:
                metrics.codex_api = await self.standalone_collector.collect_openai_usage(
                    self.config.openai_api_key
                )

            # Jobs and Nodes are not available in standalone mode
            metrics.jobs = None
            metrics.nodes = None

        else:
            # Integrated mode: Master API calls
            metrics = await self.collector.collect_all(
                collect_claude=self.config.monitor_claude_api,
                collect_codex=self.config.monitor_codex_api,
                collect_jobs=self.config.monitor_jobs,
                collect_nodes=self.config.monitor_nodes,
            )

        # Collect CLI usage (works in both standalone and integrated modes)
        logger.info("Collecting CLI usage metrics...")
        metrics.claude_code_cli = await self.cli_collector.collect_claude_code_usage()
        metrics.codex_cli = await self.cli_collector.collect_codex_usage()

        return metrics

    async def _check_thresholds(self, metrics: SystemMetrics):
        """Check metrics against thresholds and send alerts"""
        alerts = []
        severity = "info"

        # Check Claude API usage
        if metrics.claude_api and self.config.monitor_claude_api:
            api = metrics.claude_api

            if api.token_usage_percent is not None:
                if (
                    api.token_usage_percent
                    >= self.config.thresholds.claude_api_critical
                ):
                    alerts.append(
                        f"🚨 *CRITICAL*: Claude API token usage at {api.token_usage_percent:.1f}% "
                        f"({api.total_tokens:,} / {api.limit_tokens:,})"
                    )
                    severity = "critical"
                elif (
                    api.token_usage_percent >= self.config.thresholds.claude_api_warning
                ):
                    alerts.append(
                        f"⚠️ *WARNING*: Claude API token usage at {api.token_usage_percent:.1f}% "
                        f"({api.total_tokens:,} / {api.limit_tokens:,})"
                    )
                    if severity != "critical":
                        severity = "warning"

        # Check Codex API usage
        if metrics.codex_api and self.config.monitor_codex_api:
            api = metrics.codex_api

            if api.token_usage_percent is not None:
                if api.token_usage_percent >= self.config.thresholds.codex_api_critical:
                    alerts.append(
                        f"🚨 *CRITICAL*: Codex API token usage at {api.token_usage_percent:.1f}% "
                        f"({api.total_tokens:,} / {api.limit_tokens:,})"
                    )
                    severity = "critical"
                elif (
                    api.token_usage_percent >= self.config.thresholds.codex_api_warning
                ):
                    alerts.append(
                        f"⚠️ *WARNING*: Codex API token usage at {api.token_usage_percent:.1f}% "
                        f"({api.total_tokens:,} / {api.limit_tokens:,})"
                    )
                    if severity != "critical":
                        severity = "warning"

        # Check job failures
        if metrics.jobs and self.config.monitor_jobs:
            if metrics.jobs.failed >= self.config.thresholds.max_failed_jobs:
                alerts.append(f"⚠️ *WARNING*: {metrics.jobs.failed} jobs have failed")
                if severity == "info":
                    severity = "warning"

            if metrics.jobs.pending >= self.config.thresholds.max_pending_jobs:
                alerts.append(
                    f"⚠️ *WARNING*: {metrics.jobs.pending} jobs are pending (possible bottleneck)"
                )
                if severity == "info":
                    severity = "warning"

        # Check node availability
        if metrics.nodes and self.config.monitor_nodes:
            if metrics.nodes.active < self.config.thresholds.min_active_nodes:
                alerts.append(
                    f"🚨 *CRITICAL*: Only {metrics.nodes.active} active nodes "
                    f"(minimum required: {self.config.thresholds.min_active_nodes})"
                )
                severity = "critical"

        # Send alerts if any
        if alerts:
            # Check if we recently sent this alert (avoid spam)
            alert_key = "".join(alerts)
            now = datetime.now().timestamp()

            if alert_key in self.last_alerts:
                last_time = self.last_alerts[alert_key]
                # Don't resend same alert within 30 minutes
                if now - last_time < 1800:
                    logger.info("Skipping duplicate alert (sent recently)")
                    return

            self.last_alerts[alert_key] = now

            message = "\n".join(alerts)
            await self.notifier.send_all(message, severity)

    async def _report_loop(self):
        """Regular status report loop (12 hours)"""
        logger.info("Report loop started")

        while self.running:
            try:
                if not self.config.send_regular_reports:
                    logger.info("Regular reports disabled, skipping")
                    await asyncio.sleep(self.config.report_interval)
                    continue

                # Collect metrics (mode-aware)
                logger.info("Collecting metrics for regular report...")
                metrics = await self._collect_metrics()

                # Send regular status report
                summary = format_metrics_summary(metrics)
                await self.notifier.send_all(summary, "info")

                logger.info("Regular report sent")

            except Exception as e:
                logger.error(f"Error in report loop: {e}", exc_info=True)

            # Wait for next interval
            await asyncio.sleep(self.config.report_interval)

        logger.info("Report loop stopped")

    async def _threshold_check_loop(self):
        """Threshold monitoring loop (10 minutes)"""
        logger.info("Threshold check loop started")

        while self.running:
            try:
                # Collect metrics (mode-aware)
                logger.info("Collecting metrics for threshold check...")
                metrics = await self._collect_metrics()

                # Check thresholds and send alerts if needed
                await self._check_thresholds(metrics)

                # Log summary
                summary = format_metrics_summary(metrics)
                logger.info(f"Threshold check completed:\n{summary}")

            except Exception as e:
                logger.error(f"Error in threshold check loop: {e}", exc_info=True)

            # Wait for next interval
            await asyncio.sleep(self.config.threshold_check_interval)

        logger.info("Threshold check loop stopped")

    async def start(self):
        """Start the monitoring daemon"""
        if self.running:
            logger.warning("Daemon is already running")
            return

        self.running = True
        self._write_pid()

        # Setup signal handlers
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, lambda: asyncio.create_task(self.stop()))

        # Start both monitoring loops
        self.report_task = asyncio.create_task(self._report_loop())
        self.threshold_task = asyncio.create_task(self._threshold_check_loop())

        # Send startup notification
        mode_label = "Standalone" if self.config.standalone_mode else "Integrated"
        startup_msg = (
            f"✅ Codernetes monitoring started ({mode_label} Mode)\n"
            f"Report interval: {self.config.report_interval}s ({self.config.report_interval // 3600}h)\n"
            f"Threshold check interval: {self.config.threshold_check_interval}s ({self.config.threshold_check_interval // 60}m)\n"
        )

        if self.config.standalone_mode:
            monitored = []
            if self.config.monitor_claude_api:
                monitored.append("Claude API")
            if self.config.monitor_codex_api:
                monitored.append("Codex API")
            startup_msg += f"Monitoring: {', '.join(monitored)}"
        else:
            startup_msg += f"Master: {self.config.master_url}"

        await self.notifier.send_all(startup_msg, "info")

        try:
            # Wait for both tasks
            await asyncio.gather(self.report_task, self.threshold_task)
        except asyncio.CancelledError:
            logger.info("Monitor tasks cancelled")

    async def stop(self):
        """Stop the monitoring daemon"""
        if not self.running:
            logger.warning("Daemon is not running")
            return

        logger.info("Stopping daemon...")
        self.running = False

        # Cancel both tasks
        tasks_to_cancel = []
        if self.report_task:
            self.report_task.cancel()
            tasks_to_cancel.append(self.report_task)
        if self.threshold_task:
            self.threshold_task.cancel()
            tasks_to_cancel.append(self.threshold_task)

        # Wait for all tasks to complete
        if tasks_to_cancel:
            try:
                await asyncio.gather(*tasks_to_cancel, return_exceptions=True)
            except asyncio.CancelledError:
                pass

        # Send shutdown notification
        await self.notifier.send_all("⏹️ Codernetes monitoring stopped", "info")

        self._remove_pid()

    async def status(self) -> dict:
        """Get daemon status"""
        pid_file = Path(self.config.pid_file)

        if not pid_file.exists():
            return {"running": False}

        try:
            pid = int(pid_file.read_text())
            # Check if process is actually running
            import os

            os.kill(pid, 0)  # Doesn't kill, just checks if process exists
            return {"running": True, "pid": pid}
        except (ValueError, ProcessLookupError, OSError):
            return {"running": False}


def run_daemon(config_path: Optional[Path] = None):
    """
    Run monitoring daemon (entry point)

    Args:
        config_path: Path to config file (default: ~/.c8s/config.json)
    """
    if config_path is None:
        config_path = Path.home() / ".c8s" / "config.json"

    try:
        config = MonitorConfig.from_file(config_path)
    except Exception as e:
        logger.error(f"Failed to load config: {e}")
        sys.exit(1)

    # Validate config
    errors = config.validate()
    if errors:
        logger.error("Configuration errors:")
        for error in errors:
            logger.error(f"  - {error}")
        sys.exit(1)

    # Create and run daemon
    daemon = MonitorDaemon(config)

    try:
        asyncio.run(daemon.start())
    except KeyboardInterrupt:
        logger.info("Received interrupt signal")
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)

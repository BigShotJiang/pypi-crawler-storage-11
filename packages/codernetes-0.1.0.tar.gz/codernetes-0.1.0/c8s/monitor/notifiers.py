"""
Notification senders for different platforms
"""

import asyncio
import aiohttp
import time
from typing import Dict, Any
from abc import ABC, abstractmethod
import logging

logger = logging.getLogger(__name__)


class Notifier(ABC):
    """Base class for all notifiers"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.enabled = config.get("enabled", True)

    @abstractmethod
    async def send(self, message: str, severity: str = "info") -> bool:
        """
        Send notification message

        Args:
            message: Message to send
            severity: 'info', 'warning', or 'critical'

        Returns:
            True if successful, False otherwise
        """
        pass


class SlackNotifier(Notifier):
    """Slack webhook notifier"""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.webhook_url = config.get("webhook_url")
        self.username = config.get("username", "Codernetes Monitor")
        self.icon_emoji = config.get("icon_emoji", ":robot_face:")

    async def send(self, message: str, severity: str = "info") -> bool:
        if not self.enabled or not self.webhook_url:
            return False

        # Color coding based on severity
        color_map = {
            "info": "#36a64f",  # Green
            "warning": "#ff9900",  # Orange
            "critical": "#ff0000",  # Red
        }
        color = color_map.get(severity, "#808080")

        payload = {
            "username": self.username,
            "icon_emoji": self.icon_emoji,
            "attachments": [
                {
                    "color": color,
                    "text": message,
                    "footer": "Codernetes Monitoring",
                    "ts": int(time.time()),
                }
            ]
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.webhook_url,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as response:
                    if response.status == 200:
                        logger.info("Slack notification sent successfully")
                        return True
                    else:
                        logger.error(f"Slack notification failed: {response.status}")
                        return False
        except Exception as e:
            logger.error(f"Error sending Slack notification: {e}")
            return False


class TelegramNotifier(Notifier):
    """Telegram bot notifier"""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.bot_token = config.get("bot_token")
        self.chat_id = config.get("chat_id")

    async def send(self, message: str, severity: str = "info") -> bool:
        if not self.enabled or not self.bot_token or not self.chat_id:
            return False

        # Emoji based on severity
        emoji_map = {
            "info": "ℹ️",
            "warning": "⚠️",
            "critical": "🚨",
        }
        emoji = emoji_map.get(severity, "🤖")

        formatted_message = f"{emoji} *Codernetes Monitor*\n\n{message}"

        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": formatted_message,
            "parse_mode": "Markdown",
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url, json=payload, timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status == 200:
                        logger.info("Telegram notification sent successfully")
                        return True
                    else:
                        logger.error(f"Telegram notification failed: {response.status}")
                        return False
        except Exception as e:
            logger.error(f"Error sending Telegram notification: {e}")
            return False


class DiscordNotifier(Notifier):
    """Discord webhook notifier"""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.webhook_url = config.get("webhook_url")

    async def send(self, message: str, severity: str = "info") -> bool:
        if not self.enabled or not self.webhook_url:
            return False

        # Color coding based on severity (Discord uses decimal color values)
        color_map = {
            "info": 3066993,  # Green
            "warning": 16750899,  # Orange
            "critical": 16711680,  # Red
        }
        color = color_map.get(severity, 8421504)

        # Emoji based on severity
        emoji_map = {
            "info": "ℹ️",
            "warning": "⚠️",
            "critical": "🚨",
        }
        emoji = emoji_map.get(severity, "🤖")

        payload = {
            "embeds": [
                {
                    "title": f"{emoji} Codernetes Monitor Alert",
                    "description": message,
                    "color": color,
                    "footer": {"text": "Codernetes Monitoring"},
                }
            ]
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.webhook_url,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as response:
                    if response.status in (200, 204):
                        logger.info("Discord notification sent successfully")
                        return True
                    else:
                        logger.error(f"Discord notification failed: {response.status}")
                        return False
        except Exception as e:
            logger.error(f"Error sending Discord notification: {e}")
            return False


class NotifierManager:
    """Manages multiple notifiers"""

    def __init__(self, notifier_configs: list):
        self.notifiers = []

        for config in notifier_configs:
            notifier_type = config.get("type", "").lower()

            if notifier_type == "slack":
                self.notifiers.append(SlackNotifier(config))
            elif notifier_type == "telegram":
                self.notifiers.append(TelegramNotifier(config))
            elif notifier_type == "discord":
                self.notifiers.append(DiscordNotifier(config))
            else:
                logger.warning(f"Unknown notifier type: {notifier_type}")

    async def send_all(self, message: str, severity: str = "info") -> int:
        """
        Send message to all enabled notifiers

        Returns:
            Number of successful sends
        """
        if not self.notifiers:
            logger.warning("No notifiers configured")
            return 0

        tasks = [notifier.send(message, severity) for notifier in self.notifiers]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        success_count = sum(1 for r in results if r is True)
        logger.info(f"Sent to {success_count}/{len(self.notifiers)} notifiers")

        return success_count

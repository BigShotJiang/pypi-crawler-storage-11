# Codernetes Monitoring Guide

Complete guide for setting up and using the Codernetes monitoring system.

## Overview

The Codernetes monitoring system provides:
- **Real-time metrics collection**: Claude API, Codex API, Jobs, Nodes
- **Intelligent alerting**: Threshold-based alerts with configurable severity
- **Multi-channel notifications**: Slack, Telegram, Discord
- **Background daemon**: Runs continuously in the background
- **Flexible configuration**: JSON-based config with easy customization

## Quick Start

### 1. Initialize Configuration

```bash
c8s monitor init
```

Follow the interactive prompts to configure:
- Master server URL (default: http://localhost:8080)
- Monitoring interval in seconds (default: 300 = 5 minutes)
- Notification channels (Slack, Telegram, Discord)
- Alert thresholds

### 2. Start Monitoring

```bash
# Run as background daemon
c8s monitor start --daemon

# Or run in foreground for testing
c8s monitor start
```

### 3. Check Status

```bash
c8s monitor status
```

### 4. View Current Metrics

```bash
c8s monitor now
```

### 5. Stop Monitoring

```bash
c8s monitor stop
```

## Configuration Details

### Config File Location

Default: `~/.c8s/config.json`

The monitoring configuration is stored under the `monitor` key:

```json
{
  "monitor": {
    "interval": 300,
    "master_url": "http://localhost:8080",
    "notifiers": [...],
    "thresholds": {...},
    "monitor_claude_api": true,
    "monitor_codex_api": true,
    "monitor_jobs": true,
    "monitor_nodes": true,
    "pid_file": "/tmp/c8s-monitor.pid",
    "log_file": "/tmp/c8s-monitor.log"
  }
}
```

### Monitoring Interval

The `interval` setting controls how often metrics are collected (in seconds):

- **60-180s**: High-frequency monitoring (more API calls)
- **300-600s**: Balanced monitoring (recommended)
- **900-1800s**: Low-frequency monitoring (fewer API calls)

### Thresholds

Configure when alerts are triggered:

```json
"thresholds": {
  "claude_api_warning": 80.0,      // % usage for warning
  "claude_api_critical": 90.0,     // % usage for critical alert
  "codex_api_warning": 80.0,
  "codex_api_critical": 90.0,
  "max_failed_jobs": 5,            // Alert if N jobs failed
  "max_pending_jobs": 20,          // Alert if N jobs pending
  "min_active_nodes": 1            // Alert if fewer than N nodes active
}
```

## Notification Setup

### Slack

1. **Create Incoming Webhook:**
   - Go to https://api.slack.com/messaging/webhooks
   - Click "Create New App" → "From scratch"
   - Name your app (e.g., "Codernetes Monitor")
   - Select your workspace
   - Navigate to "Incoming Webhooks" and activate
   - Click "Add New Webhook to Workspace"
   - Select channel and authorize
   - Copy the webhook URL

2. **Add to config:**
   ```json
   {
     "type": "slack",
     "enabled": true,
     "webhook_url": "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXX"
   }
   ```

### Telegram

1. **Create Bot:**
   - Open Telegram and search for [@BotFather](https://t.me/botfather)
   - Send `/newbot` command
   - Follow prompts to name your bot
   - Copy the bot token (format: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`)

2. **Get Chat ID:**
   - Start a chat with your bot
   - Send any message
   - Visit: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
   - Find `"chat":{"id":123456789}` in the JSON response
   - Copy the chat ID

3. **Add to config:**
   ```json
   {
     "type": "telegram",
     "enabled": true,
     "bot_token": "1234567890:ABCdefGHIjklMNOpqrsTUVwxyz",
     "chat_id": "123456789"
   }
   ```

### Discord

1. **Create Webhook:**
   - Open Discord server settings
   - Go to "Integrations" → "Webhooks"
   - Click "New Webhook"
   - Name it (e.g., "Codernetes Monitor")
   - Select channel
   - Copy webhook URL

2. **Add to config:**
   ```json
   {
     "type": "discord",
     "enabled": true,
     "webhook_url": "https://discord.com/api/webhooks/1234567890/XXXXXXXXXXXXXXXXXXXX"
   }
   ```

## Alert Severity Levels

### Info (🟢)
- Monitoring started/stopped
- Regular status updates (if enabled)

### Warning (🟡)
- API usage 80-89%
- Failed jobs exceed threshold
- Pending jobs exceed threshold

### Critical (🔴)
- API usage ≥90%
- Active nodes below minimum
- System health degradation

## Metrics Collected

### Claude API Usage
- Total requests made
- Total tokens used
- Request limit (if available)
- Token limit (if available)
- Usage percentages

### Codex API Usage
- Total requests made
- Total tokens used
- Request limit (if available)
- Token limit (if available)
- Usage percentages

### Job Statistics
- Total jobs
- Running jobs
- Pending jobs
- Completed jobs
- Failed jobs
- Cancelled jobs

### Node Status
- Total registered nodes
- Active nodes
- Busy nodes (currently processing jobs)
- Inactive nodes

## Master API Requirements

The monitoring system requires the following API endpoints on the Master server:

### Usage Endpoints (NEW)
```
GET /api/usage/claude
GET /api/usage/codex
```

Response format:
```json
{
  "total_requests": 1234,
  "total_tokens": 567890,
  "limit_requests": 10000,
  "limit_tokens": 2000000
}
```

### Existing Endpoints
```
GET /api/jobs      # List all jobs
GET /api/nodes     # List all nodes
```

**Note**: If usage endpoints are not implemented, the monitor will log warnings but continue collecting job and node metrics.

## Troubleshooting

### Monitor Won't Start

1. **Check config file exists:**
   ```bash
   ls ~/.c8s/config.json
   ```

2. **Validate config:**
   ```bash
   c8s monitor init  # Re-run to fix issues
   ```

3. **Check logs:**
   ```bash
   tail -f /tmp/c8s-monitor.log
   ```

### Notifications Not Received

1. **Check notifier config:**
   - Verify webhook URLs are correct
   - Ensure `enabled: true` is set
   - Test webhook manually:
     ```bash
     # Slack
     curl -X POST -H 'Content-type: application/json' \
       --data '{"text":"Test message"}' \
       YOUR_WEBHOOK_URL

     # Discord
     curl -X POST -H 'Content-type: application/json' \
       --data '{"content":"Test message"}' \
       YOUR_WEBHOOK_URL
     ```

2. **Check thresholds:**
   - Lower thresholds temporarily for testing
   - Run `c8s monitor now` to see current values

3. **Check logs:**
   ```bash
   grep -i "notification\|alert" /tmp/c8s-monitor.log
   ```

### High Memory/CPU Usage

1. **Increase monitoring interval:**
   ```json
   "interval": 900  // 15 minutes instead of 5
   ```

2. **Disable unused metrics:**
   ```json
   "monitor_claude_api": false,  // If not using Claude
   "monitor_codex_api": false    // If not using Codex
   ```

### Stale PID File

If daemon won't start due to stale PID:
```bash
rm /tmp/c8s-monitor.pid
c8s monitor start --daemon
```

## Best Practices

1. **Start with default settings** and adjust based on your needs
2. **Test notifications** before relying on them in production
3. **Monitor the monitor** - check logs periodically
4. **Set appropriate thresholds** - too low = alert fatigue, too high = missed issues
5. **Use multiple notification channels** for critical alerts
6. **Adjust interval** based on your API usage patterns
7. **Review and update** configuration as your system evolves

## Advanced Usage

### Custom Config Location

```bash
c8s monitor start --config /path/to/custom-config.json --daemon
```

### Integration with systemd

Create `/etc/systemd/system/c8s-monitor.service`:

```ini
[Unit]
Description=Codernetes Monitoring Service
After=network.target

[Service]
Type=simple
User=youruser
ExecStart=/usr/local/bin/c8s monitor start
Restart=on-failure
RestartSec=30

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable c8s-monitor
sudo systemctl start c8s-monitor
sudo systemctl status c8s-monitor
```

### Multiple Environments

Use separate configs for different environments:

```bash
# Development
c8s monitor start --config ~/.c8s/monitor-dev.json --daemon

# Production
c8s monitor start --config ~/.c8s/monitor-prod.json --daemon
```

## Example Alert Messages

### Warning: High API Usage
```
⚠️ WARNING: Claude API token usage at 85.3% (1,706,000 / 2,000,000)
```

### Critical: No Active Nodes
```
🚨 CRITICAL: Only 0 active nodes (minimum required: 1)
```

### Info: System Status
```
📊 Codernetes System Status

*Claude API Usage:*
  • Tokens: 1,234,567 / 2,000,000 (61.7%)
  • Requests: 456 / 1,000 (45.6%)

*Jobs:*
  • Total: 125
  • Running: 3
  • Pending: 5
  • Completed: 115
  • Failed: 2

*Nodes:*
  • Total: 4
  • Active: 4
```

## Support

For issues or questions:
1. Check this guide
2. Review logs: `/tmp/c8s-monitor.log`
3. Run `c8s monitor now` to debug metrics collection
4. Check Master API health: `curl http://localhost:8080/api/jobs`

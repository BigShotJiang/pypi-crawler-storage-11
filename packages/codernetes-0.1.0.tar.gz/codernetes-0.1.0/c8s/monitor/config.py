"""
Monitoring configuration management
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from pathlib import Path
import json


@dataclass
class NotifierConfig:
    """Configuration for notification channels"""

    type: str  # 'slack', 'telegram', 'discord'
    enabled: bool = True

    # Slack
    webhook_url: Optional[str] = None
    username: Optional[str] = None
    icon_emoji: Optional[str] = None

    # Telegram
    bot_token: Optional[str] = None
    chat_id: Optional[str] = None

    def validate(self) -> bool:
        """Validate configuration based on notifier type"""
        if not self.enabled:
            return True

        if self.type == "slack":
            return bool(self.webhook_url)
        elif self.type == "telegram":
            return bool(self.bot_token and self.chat_id)
        elif self.type == "discord":
            return bool(self.webhook_url)
        return False


@dataclass
class ThresholdConfig:
    """Alert threshold configuration"""

    # API Usage thresholds (percentage)
    claude_api_warning: float = 80.0
    claude_api_critical: float = 90.0
    codex_api_warning: float = 80.0
    codex_api_critical: float = 90.0

    # Job-related thresholds
    max_failed_jobs: int = 5  # Alert if more than N jobs failed in interval
    max_pending_jobs: int = 20  # Alert if too many jobs are pending

    # Node-related thresholds
    min_active_nodes: int = 1  # Alert if fewer than N nodes are active


@dataclass
class MonitorConfig:
    """Main monitoring configuration"""

    # Monitoring interval in seconds (default: 5 minutes)
    # DEPRECATED: Use report_interval and threshold_check_interval instead
    interval: int = 300

    # Regular report interval in seconds (default: 12 hours)
    report_interval: int = 43200  # 12 hours

    # Threshold check interval in seconds (default: 10 minutes)
    threshold_check_interval: int = 600  # 10 minutes

    # Enable regular status reports
    send_regular_reports: bool = True

    # Standalone mode: Monitor Claude/Codex APIs directly without Master server
    standalone_mode: bool = False

    # API Keys for standalone mode
    anthropic_api_key: Optional[str] = None
    openai_api_key: Optional[str] = None

    # Master server URL (not used in standalone mode)
    master_url: str = "http://localhost:8080"

    # Notifiers
    notifiers: List[NotifierConfig] = field(default_factory=list)

    # Thresholds
    thresholds: ThresholdConfig = field(default_factory=ThresholdConfig)

    # Enable/disable specific metrics
    monitor_claude_api: bool = True
    monitor_codex_api: bool = True
    monitor_jobs: bool = True  # Ignored in standalone mode
    monitor_nodes: bool = True  # Ignored in standalone mode

    # Daemon settings
    pid_file: str = "/tmp/c8s-monitor.pid"
    log_file: str = "/tmp/c8s-monitor.log"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MonitorConfig":
        """Create config from dictionary"""
        notifiers_data = data.pop("notifiers", [])
        thresholds_data = data.pop("thresholds", {})

        notifiers = [NotifierConfig(**n) for n in notifiers_data]
        thresholds = ThresholdConfig(**thresholds_data)

        return cls(notifiers=notifiers, thresholds=thresholds, **data)

    @classmethod
    def from_file(cls, path: Path) -> "MonitorConfig":
        """Load config from JSON file"""
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")

        with open(path, "r") as f:
            data = json.load(f)

        # Handle nested monitor config if it exists
        if "monitor" in data:
            data = data["monitor"]

        return cls.from_dict(data)

    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary"""
        return {
            "interval": self.interval,
            "report_interval": self.report_interval,
            "threshold_check_interval": self.threshold_check_interval,
            "send_regular_reports": self.send_regular_reports,
            "standalone_mode": self.standalone_mode,
            "anthropic_api_key": self.anthropic_api_key,
            "openai_api_key": self.openai_api_key,
            "master_url": self.master_url,
            "notifiers": [
                {
                    "type": n.type,
                    "enabled": n.enabled,
                    "webhook_url": n.webhook_url,
                    "username": n.username,
                    "icon_emoji": n.icon_emoji,
                    "bot_token": n.bot_token,
                    "chat_id": n.chat_id,
                }
                for n in self.notifiers
            ],
            "thresholds": {
                "claude_api_warning": self.thresholds.claude_api_warning,
                "claude_api_critical": self.thresholds.claude_api_critical,
                "codex_api_warning": self.thresholds.codex_api_warning,
                "codex_api_critical": self.thresholds.codex_api_critical,
                "max_failed_jobs": self.thresholds.max_failed_jobs,
                "max_pending_jobs": self.thresholds.max_pending_jobs,
                "min_active_nodes": self.thresholds.min_active_nodes,
            },
            "monitor_claude_api": self.monitor_claude_api,
            "monitor_codex_api": self.monitor_codex_api,
            "monitor_jobs": self.monitor_jobs,
            "monitor_nodes": self.monitor_nodes,
            "pid_file": self.pid_file,
            "log_file": self.log_file,
        }

    def save(self, path: Path):
        """Save config to JSON file"""
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump({"monitor": self.to_dict()}, f, indent=2)

    def validate(self) -> List[str]:
        """Validate configuration and return list of errors"""
        errors = []

        if self.interval < 60:
            errors.append("Interval must be at least 60 seconds")

        if self.report_interval < 60:
            errors.append("Report interval must be at least 60 seconds")

        if self.threshold_check_interval < 60:
            errors.append("Threshold check interval must be at least 60 seconds")

        # Standalone mode validation
        if self.standalone_mode:
            if self.monitor_claude_api and not self.anthropic_api_key:
                errors.append("Anthropic API key is required in standalone mode when monitoring Claude API")
            if self.monitor_codex_api and not self.openai_api_key:
                errors.append("OpenAI API key is required in standalone mode when monitoring Codex API")
        else:
            # Integrated mode validation
            if not self.master_url:
                errors.append("Master URL is required in integrated mode")

        if not self.notifiers:
            errors.append("At least one notifier must be configured")

        for i, notifier in enumerate(self.notifiers):
            if not notifier.validate():
                errors.append(
                    f"Notifier {i} ({notifier.type}) is not properly configured"
                )

        return errors

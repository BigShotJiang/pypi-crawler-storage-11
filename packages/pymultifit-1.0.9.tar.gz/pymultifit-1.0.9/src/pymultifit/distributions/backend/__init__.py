"""Created on Aug 03 22:06:14 2024"""

from .baseDistribution import BaseDistribution
from .polynomial_d import LineFunction, QuadraticFunction, CubicFunction

from rest_framework import permissions, viewsets

from marinerg_test_access.models import ApplicationField, ApplicationFieldValue
from marinerg_test_access.serializers import (
    ApplicationFieldListSerializer,
    ApplicationFieldCreateSerializer,
    ApplicationFieldValueSerializer,
)


class ApplicationFieldViewSet(viewsets.ModelViewSet):
    queryset = ApplicationField.objects.all()
    serializer_class = ApplicationFieldListSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        permissions.DjangoModelPermissions,
    ]

    def get_queryset(self):
        queryset = ApplicationField.objects.all()
        return queryset

    serializers = {
        "retrieve": ApplicationFieldListSerializer,
        "list": ApplicationFieldListSerializer,
        "create": ApplicationFieldCreateSerializer,
        "update": ApplicationFieldListSerializer,
        "partial_update": ApplicationFieldListSerializer,
    }


class ApplicationFieldValueViewSet(viewsets.ModelViewSet):
    queryset = ApplicationFieldValue.objects.all()
    serializer_class = ApplicationFieldValueSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        permissions.DjangoModelPermissions,
    ]

    def get_queryset(self):
        queryset = ApplicationFieldValue.objects.all()
        return queryset

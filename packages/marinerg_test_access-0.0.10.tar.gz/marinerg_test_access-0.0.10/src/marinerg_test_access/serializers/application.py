from rest_framework import serializers

from ichec_django_core.serializers.core import SERIALIZER_BASE_FIELDS

from marinerg_test_access.models import AccessApplication


class AccessApplicationSerializer(serializers.HyperlinkedModelSerializer):

    call_title = serializers.CharField(
        source="call.title", required=False, read_only=True
    )
    applicant_username = serializers.CharField(
        source="applicant.username", required=False, read_only=True
    )

    class Meta:
        model = AccessApplication
        fields = SERIALIZER_BASE_FIELDS + (
            "facilities",
            "chosen_facility",
            "request_start_date",
            "request_end_date",
            "dates_flexible",
            "summary_url",
            "applicant",
            "call",
            "submitted",
            "status",
            "call_title",
            "applicant_username",
            "field_values",
        )
        read_only_fields = SERIALIZER_BASE_FIELDS + (
            "submitted",
            "applicant",
            "call_title",
            "summary_url",
            "applicant_username",
        )

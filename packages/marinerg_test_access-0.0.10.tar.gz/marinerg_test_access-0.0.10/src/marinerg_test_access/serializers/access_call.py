from rest_framework import serializers

from ichec_django_core.serializers import NestedHyperlinkedModelSerializer

from marinerg_test_access.models import (
    AccessCall,
    AccessCallFacilityReview,
    ApplicationField,
)

from .application_fields import (
    ApplicationFieldCreateNestedSerializer,
    ApplicationFieldListSerializer,
)


class AccessCallBaseSerializer(NestedHyperlinkedModelSerializer):

    class Meta:
        model = AccessCall
        fields = NestedHyperlinkedModelSerializer.base_fields + (
            "title",
            "description",
            "status",
            "closing_date",
            "coordinator",
            "board_chair",
            "board_members",
            "application_fields",
            "selectable_facilities",
        )
        read_only_fields = NestedHyperlinkedModelSerializer.base_fields


class AccessCallDetailSerializer(AccessCallBaseSerializer):

    application_fields = ApplicationFieldListSerializer(many=True)
    applications_summary = serializers.HyperlinkedIdentityField(
        read_only=True, view_name="application_summaries"
    )

    class Meta:
        model = AccessCall
        fields = AccessCallBaseSerializer.Meta.fields + ("applications_summary",)
        read_only_fields = AccessCallBaseSerializer.Meta.read_only_fields + (
            "applications_summary",
        )

    def to_representation(self, instance):
        rep = super().to_representation(instance)
        if not instance.applications_summary:
            rep["applications_summary"] = None
        return rep


class AccessCallCreateSerializer(AccessCallBaseSerializer):

    application_fields = ApplicationFieldCreateNestedSerializer(many=True)

    def create(self, validated_data):
        application_fields = validated_data.pop("application_fields")

        instance = super().create(validated_data)

        ApplicationField.objects.bulk_create(
            [
                ApplicationField(access_call=instance, **field)
                for field in application_fields
            ]
        )
        return instance

    def to_representation(self, instance):
        return AccessCallDetailSerializer(context=self.context).to_representation(
            instance
        )


class AccessCallListSerializer(AccessCallBaseSerializer):

    pass


class AccessCallFacilityReviewSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = AccessCallFacilityReview
        fields = ["decision", "comments", "call", "facility"]

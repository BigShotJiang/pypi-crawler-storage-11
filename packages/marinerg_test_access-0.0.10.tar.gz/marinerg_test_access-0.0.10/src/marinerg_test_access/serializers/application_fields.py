from rest_framework import serializers

from ichec_django_core.serializers.core import SERIALIZER_BASE_FIELDS

from marinerg_test_access.models import ApplicationField, ApplicationFieldValue


class ApplicationFieldBaseSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = ApplicationField
        fields = SERIALIZER_BASE_FIELDS + (
            "name",
            "required",
            "description",
            "template",
            "options",
            "default",
            "field_type",
            "order",
            "group",
        )
        read_only_fields = SERIALIZER_BASE_FIELDS + ("url", "id")


class ApplicationFieldCreateSerializer(ApplicationFieldBaseSerializer):

    class Meta:
        model = ApplicationField
        fields = ApplicationFieldBaseSerializer.Meta.fields + ("access_call",)


class ApplicationFieldCreateNestedSerializer(ApplicationFieldBaseSerializer):
    pass


class ApplicationFieldListSerializer(ApplicationFieldBaseSerializer):

    class Meta:
        model = ApplicationField
        fields = ApplicationFieldBaseSerializer.Meta.fields + ("access_call",)


class ApplicationFieldValueSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = ApplicationFieldValue
        fields = ["url", "id", "value", "field", "application"]

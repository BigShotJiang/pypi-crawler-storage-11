from django.db import models

import functools

from ichec_django_core.models import TimesStampMixin, content_file_name

from .access_call import AccessCall
from .application import AccessApplication


class ApplicationFieldType(models.TextChoices):

    BOOLEAN = "BOOLEAN", "Boolean"
    CHAR = "CHAR", "Short Text"
    TEXT = "TEXT", "Long Text"
    RICH_TEXT = "RICH_TEXT", "Rich Text"
    SELECTION = "SELECTION", "Selection"
    INTEGER = "INTEGER", "Integer"
    FILE = "FILE", "File"


class ApplicationField(TimesStampMixin):

    class Meta:
        verbose_name = "Application Field"
        verbose_name_plural = "Application Fields"

    name = models.CharField(max_length=200)
    required = models.BooleanField(default=False)
    description = models.TextField(blank=True)
    template = models.FileField(
        null=True,
        upload_to=functools.partial(content_file_name, "application_field_template"),
    )
    options = models.CharField(max_length=200, null=True)
    default = models.CharField(max_length=500, blank=True)
    field_type = models.CharField(
        max_length=10,
        choices=ApplicationFieldType.choices,
        default=ApplicationFieldType.CHAR,
    )
    access_call = models.ForeignKey(
        AccessCall, on_delete=models.CASCADE, related_name="application_fields"
    )
    order = models.IntegerField(default=0)
    group = models.IntegerField(default=0)

    def __str__(self):
        return self.name


class ApplicationFieldValue(models.Model):

    class Meta:
        verbose_name = "Application Field Value"
        verbose_name_plural = "Application Field Value"

    value = models.CharField(max_length=500)
    asset = models.FileField(
        null=True,
        upload_to=functools.partial(content_file_name, "application_field_value"),
    )
    field = models.ForeignKey(
        ApplicationField, on_delete=models.CASCADE, related_name="values"
    )

    application = models.ForeignKey(
        AccessApplication, on_delete=models.CASCADE, related_name="field_values"
    )

    def __str__(self):
        return self.value

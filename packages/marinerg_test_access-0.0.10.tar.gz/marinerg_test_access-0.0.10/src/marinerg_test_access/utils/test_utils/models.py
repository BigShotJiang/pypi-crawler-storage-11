from datetime import datetime

from pydantic import BaseModel
from ichec_django_core.utils.test_utils.models import (
    Identifiable,
    Timestamped,
    register_types,
)


class ApplicationFieldBase(BaseModel, frozen=True):

    name: str
    field_type: str
    required: bool = False
    description: str = ""
    default: str | None = None
    options: str | None = None
    order: int = 0
    group: int = 0


class ApplicationFieldCreate(ApplicationFieldBase, frozen=True):

    template: str | None = None


class ApplicationFieldDetail(Timestamped, ApplicationFieldBase, frozen=True):

    access_call: str
    template: str | None = None


class AccessCallBase(BaseModel, frozen=True):

    title: str
    description: str
    status: str
    closing_date: datetime
    coordinator: str
    board_chair: str
    board_members: list[str] = []
    selectable_facilities: list[str] = []


class AccessCallCreate(AccessCallBase, frozen=True):

    application_fields: list[ApplicationFieldCreate] = []


class AccessCallDetail(Timestamped, AccessCallBase, frozen=True):

    application_fields: list[ApplicationFieldDetail] = []


class AccessCallList(Timestamped, AccessCallBase, frozen=True):

    application_fields: list[str] = []


class ApplicationFieldValueBase(BaseModel, frozen=True):

    value: str
    field: str
    asset: str | None = None


class ApplicationFieldValueCreate(ApplicationFieldValueBase, frozen=True):
    pass


class ApplicationFieldValueDetail(Identifiable, ApplicationFieldValueBase, frozen=True):
    pass


class AccessApplicationBase(BaseModel, frozen=True):
    call: str
    facilities: list[str] = []
    chosen_facility: str | None = None
    request_start_date: datetime | None = None
    request_end_date: datetime | None = None
    dates_flexible: bool = True
    status: str = "SUBMITTED"


class AccessApplicationCreate(AccessApplicationBase, frozen=True):
    field_values: list[ApplicationFieldValueCreate] = []


class AccessApplicationDetail(Timestamped, AccessApplicationBase, frozen=True):
    applicant: str
    submitted: datetime | None = None
    field_values: list[ApplicationFieldValueDetail] = []


register_types(
    "access_calls",
    {"create": AccessCallCreate, "detail": AccessCallDetail, "list": AccessCallList},
)

register_types(
    "access_applications",
    {"create": AccessApplicationCreate, "detail": AccessApplicationDetail},
)

from datetime import datetime

from ichec_django_core.utils.test_utils.models import MemberDetail

from marinerg_facility.utils.test_utils.models import FacilityDetail

from .models import (
    AccessCallCreate,
    AccessCallDetail,
    ApplicationFieldCreate,
    AccessApplicationCreate,
)


def create_access_calls(
    count: int = 10,
    offset: int = 0,
    members: tuple[MemberDetail, ...] = (),
    selectable_facilities: tuple[FacilityDetail, ...] = (),
) -> list[AccessCallCreate]:

    contents = []
    for idx in range(offset, count + offset):
        fields = [
            ApplicationFieldCreate(
                name="Support Needed?",
                field_type="BOOLEAN",
                required=False,
                default="false",
                description="Do you need support?",
            ),
            ApplicationFieldCreate(
                name="Description of Device",
                field_type="TEXT",
                required=True,
                default="",
                description="Give a detailed description of the device",
            ),
        ]

        contents.append(
            AccessCallCreate(
                title=f"Access Call {idx}",
                description=f"Description of Access Call {idx}",
                status="OPEN",
                closing_date=datetime.now(),
                coordinator=members[0].url,
                board_chair=members[1].url,
                board_members=[members[2].url, members[3].url, members[4].url],
                selectable_facilities=[f.url for f in selectable_facilities],
                application_fields=fields,
            )
        )
    return contents


def create_applications(call: AccessCallDetail, count: int = 10, offset: int = 0):

    contents = []
    for idx in range(offset, count + offset):
        contents.append(AccessApplicationCreate(call=call.url))
    return contents

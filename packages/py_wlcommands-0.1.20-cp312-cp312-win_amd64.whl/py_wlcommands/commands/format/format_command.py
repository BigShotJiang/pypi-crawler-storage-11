"""
Format code command.
"""

from pathlib import Path

from ...commands import Command, register_command, validate_command_args
from .python_formatter import (
    _run_format_command,
    format_examples,
    format_tools_scripts,
    format_with_python_tools,
    generate_type_stubs,
)
from .rust_formatter import format_rust_code


@register_command("format")
class FormatCommand(Command):
    """Command to format code."""

    @property
    def name(self) -> str:
        return "format"

    @property
    def help(self) -> str:
        return "Format code with ruff and cargo fmt"

    @classmethod
    def add_arguments(cls, parser):
        """Add command-specific arguments."""
        parser.add_argument(
            "-q", "--quiet", action="store_true", help="Suppress detailed output"
        )
        parser.add_argument(
            "--unsafe", action="store_true", help="Enable ruff's unsafe fixes"
        )
        parser.add_argument(
            "--report",
            action="store_true",
            help="Generate format report in todos folder",
        )
        parser.add_argument(
            "paths",
            nargs="*",
            help="Paths to format (default: src, tools, examples, rust)",
        )

    def _format_specified_paths(self, paths, env, quiet, unsafe=False):
        """Format specified paths."""
        import os
        from pathlib import Path

        from ...utils.logging import log_info

        for path in paths:
            path_obj = Path(path)
            if path_obj.exists():
                if path_obj.is_file() and path_obj.suffix == ".py":
                    # Format individual Python file with ruff only
                    try:
                        ruff_check_cmd = ["uv", "run", "ruff", "check", "--fix"]
                        if unsafe:
                            ruff_check_cmd.append("--unsafe-fixes")
                        ruff_check_cmd.append(str(path_obj))

                        _run_format_command(
                            ruff_check_cmd, env, quiet, passthrough=not quiet
                        )

                        # Also run ruff format for code formatting
                        _run_format_command(
                            [
                                "uv",
                                "run",
                                "ruff",
                                "format",
                                str(path_obj),
                            ],
                            env,
                            quiet,
                            passthrough=not quiet,
                        )
                    except Exception as e:
                        if not quiet:
                            print(f"Warning: Failed to format {path}: {e}")
                        else:
                            print(f"Warning: Failed to format {path}: {e}")
                elif path_obj.is_dir():
                    # Format directory with ruff only
                    format_with_python_tools(str(path_obj), env, quiet, unsafe)
            else:
                if not quiet:
                    print(f"Warning: Path {path} does not exist")
                else:
                    print(f"Warning: Path {path} does not exist")

    def _format_python_directory(
        self, directory: str, env: dict, quiet: bool, unsafe: bool = False
    ) -> None:
        """Format Python directory with ruff only."""
        from pathlib import Path

        from ...utils.logging import log_info

        # Check if directory exists before attempting to format
        dir_path = Path(directory)
        if not dir_path.exists():
            if not quiet:
                print(f"Directory {directory} does not exist, skipping...")
            else:
                print(f"Directory {directory} does not exist, skipping...")
            return

        format_with_python_tools(directory, env, quiet, unsafe)

    def _format_default_paths(self, project_root, env, quiet, unsafe=False):
        """Format default paths."""
        from pathlib import Path

        # Format source code with ruff only
        format_with_python_tools(str(project_root / "src"), env, quiet, unsafe)

        # Format tools scripts if directory exists
        tools_dir = project_root / "tools"
        if tools_dir.exists():
            format_with_python_tools(str(tools_dir), env, quiet, unsafe)

        # Format examples if directory exists
        examples_dir = project_root / "examples"
        if examples_dir.exists():
            format_with_python_tools(str(examples_dir), env, quiet, unsafe)

        # Generate type stubs
        generate_type_stubs(
            str(project_root / "src"), str(project_root / "typings"), env, quiet
        )

    def _find_project_root(self) -> Path:
        """
        Find the project root directory by looking for pyproject.toml file.
        通过查找 pyproject.toml 文件来确定项目根目录。
        """
        from py_wlcommands.utils.project_root import find_project_root

        return find_project_root()

    def _generate_report(self, project_root: Path, quiet: bool) -> None:
        """Generate format report."""
        import subprocess
        import sys

        todos_dir = project_root / "todos"
        todos_dir.mkdir(exist_ok=True)

        # Run ruff check to get formatting issues
        try:
            ruff_check_result = subprocess.run(
                ["uv", "run", "ruff", "check", "."],
                cwd=str(project_root),
                capture_output=True,
                text=True,
                encoding="utf-8" if sys.platform.startswith("win") else None,
            )

            report_file = todos_dir / "format_report.md"
            with open(report_file, "w", encoding="utf-8") as f:
                f.write("# Format Report\n\n")
                if ruff_check_result.stdout:
                    f.write("## Issues Found\n\n")
                    f.write("```\n")
                    f.write(ruff_check_result.stdout)
                    f.write("```\n")
                else:
                    f.write("No format issues found.\n")

                if ruff_check_result.stderr:
                    f.write("\n## Errors\n\n")
                    f.write("```\n")
                    f.write(ruff_check_result.stderr)
                    f.write("```\n")

            if not quiet:
                from ...utils.logging import log_info

                log_info(f"Format report generated at {report_file}", lang="en")
                log_info(f"格式化报告已生成到 {report_file}", lang="zh")
        except Exception as e:
            if not quiet:
                print(f"Warning: Failed to generate format report: {e}")

    @validate_command_args()
    def execute(
        self,
        quiet: bool = False,
        unsafe: bool = True,
        report: bool = False,
        paths: list | None = None,
    ) -> None:
        """
        Execute the format command.
        执行格式化命令。

        Args:
            quiet (bool): Whether to suppress output. 是否静默执行
            unsafe (bool): Whether to apply unsafe fixes. 是否应用不安全修复
            report (bool): Whether to generate a report. 是否生成报告
            paths (list): List of paths to format. 要格式化的路径列表
        """
        import os
        import subprocess
        import sys
        from pathlib import Path

        from ...utils.logging import log_info

        if not quiet:
            print("Formatting code...")

        try:
            # Set environment variables to handle encoding issues
            # 设置环境变量以处理编码问题
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"

            # Get project root directory
            project_root = self._find_project_root()

            if paths:
                # Format specified paths
                self._format_specified_paths(paths, env, quiet, unsafe)
            else:
                # Format default paths
                self._format_default_paths(project_root, env, quiet, unsafe)

            # Format Rust code (only if no custom paths or rust path is specified)
            # 格式化 Rust 代码
            if not paths:
                # When no paths are specified, always format the rust directory
                # This is the expected behavior based on the existing tests
                rust_dir = project_root / "rust"
                print("Formatting Rust code with cargo fmt...")
                format_rust_code(str(rust_dir), env, quiet)
            elif any("rust" in path for path in paths):
                # When "rust" is in the specified paths, format the rust directory
                rust_dir = project_root / "rust"
                print("Formatting Rust code with cargo fmt...")
                format_rust_code(str(rust_dir), env, quiet)

            # Generate report if requested
            if report:
                self._generate_report(project_root, quiet)

            if not quiet:
                print("Code formatting completed successfully!")
        except Exception as e:
            if not quiet:
                print(f"Error formatting code: {e}")
            sys.exit(1)

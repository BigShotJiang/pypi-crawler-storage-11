"""
Project root utilities for WL Commands.
"""

import os
from pathlib import Path


def find_project_root(start_path: Path | None = None) -> Path:
    """
    Find the project root directory by looking for pyproject.toml file.

    Args:
        start_path: Path to start searching from. If None, starts from the current working directory.

    Returns:
        Path to the project root directory.

    Raises:
        RuntimeError: If unable to determine project root directory.
    """
    try:
        # Start from the provided path or the current working directory
        current_path = start_path or Path.cwd()

        # Verify that start path exists if provided
        if start_path and not start_path.exists():
            raise ValueError(f"Start path does not exist: {start_path}")

        # Traverse up the directory tree
        while current_path.parent != current_path:
            # Check if pyproject.toml exists in this directory
            try:
                pyproject_path = current_path / "pyproject.toml"
                if pyproject_path.exists() and pyproject_path.is_file():
                    return current_path.resolve()
            except OSError:
                # Handle potential file system access issues gracefully
                pass

            current_path = current_path.parent

        # If we can't find pyproject.toml, fall back to a reasonable default
        # This is a fallback for development environments or unusual setups
        if start_path:
            # If we were given a start path, return it as a last resort
            return start_path.resolve()
        else:
            # As a last resort, try to go up several levels from this file
            fallback_path = Path(__file__).parent.parent.parent.parent.parent
            if fallback_path.exists():
                return fallback_path.resolve()

        # If all else fails, return current working directory
        return Path.cwd()

    except Exception as e:
        # Final fallback - return current working directory
        try:
            return Path.cwd()
        except Exception:
            # If we can't even get the current working directory, re-raise the original exception
            raise RuntimeError(
                f"Unable to determine project root directory: {e}"
            ) from e

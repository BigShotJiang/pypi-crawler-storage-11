from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Any, Dict, List, Optional


def _to_int(value: Any, default: Optional[int] = None) -> Optional[int]:
    """Best-effort safe int conversion with type narrowing."""
    if value is None:
        return default
    if isinstance(value, bool):
        # Avoid bool being treated as int
        return default
    if isinstance(value, int):
        return value
    if isinstance(value, (float,)):
        try:
            return int(value)
        except (ValueError, TypeError):
            return default
    if isinstance(value, (str, bytes, bytearray)):
        try:
            return int(value)
        except (ValueError, TypeError):
            return default
    return default


@dataclass
class Book:
    id: int
    title: str
    subtitle: Optional[str] = None
    description: Optional[str] = None
    pages: Optional[int] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Book":
        return cls(
            id=_to_int(data.get("id"), 0) or 0,
            title=str(data.get("title") or ""),
            subtitle=data.get("subtitle"),
            description=data.get("description"),
            pages=_to_int(data.get("pages"), None),
        )


@dataclass
class Author:
    id: int
    name: str
    bio: Optional[str] = None
    website: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Author":
        return cls(
            id=_to_int(data.get("id"), 0) or 0,
            name=str(data.get("name") or ""),
            bio=data.get("bio"),
            website=data.get("website"),
        )


class ReadingStatus(IntEnum):
    """Best-effort mapping for user book reading statuses."""

    UNKNOWN = 0
    WANT_TO_READ = 1
    READING = 2
    READ = 3
    DROPPED = 5


@dataclass
class User:
    id: int
    username: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "User":
        return cls(
            id=_to_int(data.get("id"), 0) or 0,
            username=str(data.get("username") or ""),
        )


@dataclass
class UserBook:
    id: int
    status_id: int
    book: Book

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "UserBook":
        return cls(
            id=_to_int(data.get("id"), 0) or 0,
            status_id=_to_int(data.get("status_id"), 0) or 0,
            book=Book.from_dict(data.get("book", {})),
        )

    @property
    def status(self) -> ReadingStatus:
        """Convenience mapping from status_id to ReadingStatus.

        Falls back to ReadingStatus.UNKNOWN for unrecognized ids.
        """
        try:
            return ReadingStatus(int(self.status_id))
        except Exception:
            return ReadingStatus.UNKNOWN


def parse_books(items: List[Dict[str, Any]]) -> List[Book]:
    return [Book.from_dict(item) for item in items or []]


def parse_user_books(items: List[Dict[str, Any]]) -> List[UserBook]:
    return [UserBook.from_dict(item) for item in items or []]

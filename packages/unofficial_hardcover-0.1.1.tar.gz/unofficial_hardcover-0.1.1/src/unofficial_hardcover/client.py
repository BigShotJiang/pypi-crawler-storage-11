import asyncio
import logging
import os
import random
import time
from collections import deque
from typing import Any, Deque, Dict, List, Optional

import httpx

from . import __version__
from .exceptions import HardcoverAPIError, HardcoverGraphQLError, HardcoverHTTPError
from .models import Author, Book, User, UserBook, parse_user_books


class HardcoverClient:
    """
    Wrapper for the Hardcover GraphQL API.
    """

    def __init__(
        self,
        api_token: Optional[str] = None,
        base_url: str = "https://api.hardcover.app/v1/graphql",
        user_agent: str = f"UnofficialHardcoverClient/{__version__}",
        timeout: int = 30,
        debug: bool = False,
        # Optional client-side rate limiting (requests per window)
        rate_limit_per_minute: Optional[int] = None,
        rate_limit_window_seconds: float = 60.0,
        # Automatic retry/backoff for 429 Too Many Requests
        retry_429_max: int = 3,
        retry_429_backoff_base: float = 0.5,
        retry_429_backoff_cap: float = 2.0,
        retry_429_jitter: float = 0.1,
    ):

        token = api_token or os.getenv("HARDCOVER_API_TOKEN")
        if not token:
            raise HardcoverAPIError(
                "Missing API token. Set HARDCOVER_API_TOKEN in your .env."
            )

        self.api_token = token
        self.BASE_URL = base_url
        self.timeout = timeout
        self.user_agent = user_agent
        self.debug = debug
        self.retry_429_max = max(0, int(retry_429_max))
        self.retry_429_backoff_base = max(0.0, float(retry_429_backoff_base))
        self.retry_429_backoff_cap = max(0.0, float(retry_429_backoff_cap))
        self.retry_429_jitter = max(0.0, float(retry_429_jitter))

        # Optional rate limiter state
        self.rate_limit_per_minute = rate_limit_per_minute
        self.rate_limit_window_seconds = float(rate_limit_window_seconds)
        self._rate_limit_timestamps: Deque[float] = deque()
        self._rate_limit_lock = asyncio.Lock()

        # Set up logging
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        if self.debug:
            self.logger.setLevel(logging.DEBUG)
            if not self.logger.handlers:
                handler = logging.StreamHandler()
                formatter = logging.Formatter(
                    "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
                )
                handler.setFormatter(formatter)
                self.logger.addHandler(handler)

        # Timeout guard: the server may cap timeouts at 30s
        if self.timeout > 30:
            # Use WARNING level so it shows up even if not in debug in typical logger setups
            self.logger.warning(
                "Configured timeout (%ss) exceeds server max of 30s; server may cap requests.",
                self.timeout,
            )

        self._client = httpx.AsyncClient(
            base_url=self.BASE_URL,
            headers={
                "Authorization": f"Bearer {self.api_token}",
                "Content-Type": "application/json",
                "User-Agent": self.user_agent,
            },
            timeout=self.timeout,
        )

    @classmethod
    def from_env(cls, debug: bool = False, **kwargs) -> "HardcoverClient":
        """Create client instance using environment variables.

        Additional keyword arguments are forwarded to the constructor, e.g.,
        timeout, rate_limit_per_minute, rate_limit_window_seconds, retry settings, etc.
        """
        return cls(api_token=os.getenv("HARDCOVER_API_TOKEN"), debug=debug, **kwargs)

    def __repr__(self) -> str:
        """Debug representation of the client."""
        return f"<HardcoverClient user_agent='{self.user_agent}' base_url='{self.BASE_URL}' debug={self.debug}>"

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        await self.close()

    # --------------------------------------------------
    # Core GraphQL request
    # --------------------------------------------------
    def _handle_graphql_response(self, response_data: Dict[str, Any]) -> Dict[str, Any]:
        """Centralize GraphQL error handling and clean data extraction."""
        if "errors" in response_data:
            if self.debug:
                self.logger.error(f"GraphQL Errors: {response_data['errors']}")
            raise HardcoverGraphQLError(response_data["errors"])
        return response_data.get("data", {})

    async def _rate_limit_wait(self) -> None:
        """Respect optional client-side rate limit using a sliding window."""
        if not self.rate_limit_per_minute or self.rate_limit_per_minute <= 0:
            return

        now = time.monotonic()
        window = self.rate_limit_window_seconds
        limit = int(self.rate_limit_per_minute)

        async with self._rate_limit_lock:
            # Drop timestamps outside window
            while (
                self._rate_limit_timestamps
                and (now - self._rate_limit_timestamps[0]) > window
            ):
                self._rate_limit_timestamps.popleft()

            if len(self._rate_limit_timestamps) < limit:
                # We can proceed immediately
                self._rate_limit_timestamps.append(now)
                return

            # Need to wait until the oldest request falls out of window
            sleep_for = (self._rate_limit_timestamps[0] + window) - now
            if self.debug:
                self.logger.debug(
                    f"Rate limit reached ({limit}/{int(window)}s), sleeping for {sleep_for:.3f}s"
                )

        # Sleep outside the lock to avoid blocking others from computing their waits
        if sleep_for > 0:
            await asyncio.sleep(sleep_for)
        # After sleeping, record this request timestamp
        async with self._rate_limit_lock:
            now2 = time.monotonic()
            while (
                self._rate_limit_timestamps
                and (now2 - self._rate_limit_timestamps[0]) > window
            ):
                self._rate_limit_timestamps.popleft()
            self._rate_limit_timestamps.append(now2)

    async def _post(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Perform a POST request with optional rate limiting and 429 retries."""
        if self.debug:
            self.logger.debug(f"GraphQL Request: {payload}")

        # Rate limiter (optional)
        await self._rate_limit_wait()

        attempt = 0
        while True:
            try:
                response = await self._client.post("", json=payload)
            except httpx.RequestError as e:
                if self.debug:
                    self.logger.error(f"Network error: {e}")
                raise HardcoverHTTPError(f"Network error: {e}") from e

            if self.debug:
                self.logger.debug(
                    f"HTTP Response: {response.status_code} - {response.headers.get('content-type', 'unknown')}"
                )

            # Handle 429 with retry/backoff
            if response.status_code == 429 and attempt < self.retry_429_max:
                # Determine backoff duration
                retry_after = response.headers.get("Retry-After")
                sleep_for: float
                if retry_after is not None:
                    try:
                        sleep_for = float(retry_after)
                    except ValueError:
                        sleep_for = 0.0
                else:
                    sleep_for = self.retry_429_backoff_base * (2**attempt)

                # Cap and add jitter
                if self.retry_429_backoff_cap > 0:
                    sleep_for = min(sleep_for, self.retry_429_backoff_cap)
                if self.retry_429_jitter > 0:
                    sleep_for += random.uniform(0, self.retry_429_jitter)

                if self.debug:
                    self.logger.debug(
                        f"HTTP 429 received, retrying in {sleep_for:.3f}s (attempt {attempt+1}/{self.retry_429_max})"
                    )
                await asyncio.sleep(max(0.0, sleep_for))
                attempt += 1
                # Loop to retry
                continue

            if not response.is_success:
                error_msg = f"{response.text}"
                if self.debug:
                    self.logger.error(f"HTTP {response.status_code}: {error_msg}")
                raise HardcoverHTTPError(error_msg, status_code=response.status_code)

            data = response.json()

            if self.debug:
                self.logger.debug(f"GraphQL Response: {data}")

            return self._handle_graphql_response(data)

    # --------------------------------------------------
    # Public raw query
    # --------------------------------------------------
    async def query(
        self, query: str, variables: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"query": query}
        if variables:
            payload["variables"] = variables
        return await self._post(payload)

    # --------------------------------------------------
    # Convenience methods
    # --------------------------------------------------
    async def get_me(self) -> Dict[str, Any]:
        """Fetch current user info."""
        query = """
          query {
            me {
                id
                username
            }
          }
        """
        data = await self.query(query)
        me_list = data.get("me")
        if isinstance(me_list, list) and me_list:
            return me_list[0]
        return {}

    async def get_me_model(self) -> Optional[User]:
        """Typed variant of get_me returning a User model or None."""
        me_dict = await self.get_me()
        if not me_dict:
            return None
        return User.from_dict(me_dict)

    # --------------------------------------------------
    # Books
    # --------------------------------------------------
    async def get_book(self, book_id: str) -> Dict[str, Any]:
        """Get detailed info about a book."""
        query = """
        query ($id: Int!) {
          books_by_pk(id: $id) {
            id
            title
            subtitle
            description
            pages
          }
        }
        """
        # Convert string ID to integer
        try:
            int_id = int(book_id)
        except ValueError:
            return {}

        data = await self.query(query, {"id": int_id})
        book = data.get("books_by_pk")
        return book if book else {}

    async def get_book_model(self, book_id: str) -> Optional[Book]:
        """Typed variant of get_book returning a Book model or None."""
        raw = await self.get_book(book_id)
        if not raw:
            return None
        return Book.from_dict(raw)

    # --------------------------------------------------
    # Authors
    # --------------------------------------------------
    async def get_author(self, author_id: str) -> Dict[str, Any]:
        """Get detailed info about an author using the authors_by_pk endpoint."""
        query = """
        query ($id: Int!) {
          authors_by_pk(id: $id) {
            id
            name
            bio
          }
        }
        """
        # Convert string ID to integer
        try:
            int_id = int(author_id)
        except ValueError:
            return {}

        data = await self.query(query, {"id": int_id})
        author = data.get("authors_by_pk")
        return author if author else {}

    async def get_author_model(self, author_id: str) -> Optional[Author]:
        """Typed variant of get_author returning an Author model or None."""
        raw = await self.get_author(author_id)
        if not raw:
            return None
        return Author.from_dict(raw)

    # --------------------------------------------------
    # Shelves
    # --------------------------------------------------
    async def get_shelves(self) -> List[Dict[str, Any]]:
        """Fetch user's books (acts as shelves)."""
        query = """
          query {
            me {
              user_books {
                id
                status_id
                book {
                  title
                }
              }
            }
          }
        """
        data = await self.query(query)
        me_list = data.get("me")
        if isinstance(me_list, list) and me_list:
            return me_list[0].get("user_books", [])
        return []

    async def get_user_books_models(self) -> List[UserBook]:
        """Typed helper to fetch user's books with stable shape."""
        query = """
          query {
            me {
              user_books {
                id
                status_id
                book {
                  id
                  title
                  subtitle
                  description
                  pages
                }
              }
            }
          }
        """
        data = await self.query(query)
        me_list = data.get("me")
        items: List[Dict[str, Any]] = []
        if isinstance(me_list, list) and me_list:
            items = me_list[0].get("user_books", []) or []
        return parse_user_books(items)

    # --------------------------------------------------
    # Developer Tools
    # --------------------------------------------------
    async def get_schema(self) -> Dict[str, Any]:
        """Introspect the API schema for development purposes."""
        introspection_query = """
        query IntrospectionQuery {
          __schema {
            types {
              name
              kind
              fields {
                name
                type {
                  name
                }
              }
            }
          }
        }
        """
        data = await self.query(introspection_query)
        return data.get("__schema", {})

    async def close(self):
        """Close async client."""
        await self._client.aclose()

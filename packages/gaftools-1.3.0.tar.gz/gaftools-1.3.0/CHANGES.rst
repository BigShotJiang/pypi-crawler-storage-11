Changes
=======

v1.3.0 (06/11/2025)
-------------------

* Minor updates to :code:`find_path` for improved error handling when given paths are invalid.
* Fixed timer issue in :code:`gfa2rgfa` subcommand. Now reports more accurate time.
* Minor fixes to :code:`gfa2rgfa` regarding parsing of S lines and handling of temporary files.
* Major addition to :code:`order_gfa` subcommand to allow handling of branched graphs. Now users can provide :code:`--ignore-branching` flag to create a ordering even when the graph has a branched structure.
* Addition of :code:`--output-scaffold` flag in :code:`order_gfa` subcommand to output the scaffold graph in GFA format. This graph has bubbles collapsed into single nodes to better visualise the scaffold structure.

v1.2.1 (08/09/2025)
-------------------

* Updated :code:`gaftools gfa2rgfa` subcommand to no longer require :code:`seqfile` by default. The default behaviour is to use the order of assemblies as given in the GFA file.
* Fixing the time logger issue with :code:`gaftools realign` subcommand.
* Bug fix in the index file created by :code:`gaftools sort` subcommand. The index file was incorrectly skipping the first alignment record.
* Minor updates to documentation regarding :code:`seqfile` in :code:`gaftools gfa2rgfa` subcommand.

v1.2.0 (03/07/2025)
-------------------

* Version push intended for manuscript revision submission.
* Minor updates to documentation includes better explanation of sort and view index structure, and minor error handling changes to :code:`order_gfa`.
* Better error handling regarding the :code:`--chromosome-order` option in :code:`order_gfa`.
* Fixed error in sort index creation when sorted GAF file is directed to standard output.

v1.1.3 (30/05/2025)
-------------------

* Minor updates to documentation.
* Due to the CI/CD issues, this version just consists of minor documentation changes which were implemented in the previous version (v1.1.2). Due to PyPI restrictions regarding version names, the documentation are being released as a new version release.

v1.1.2 (30/05/2025)
-------------------

* Better BGZF compatibility for all subcommands.
* Formatting updates with logger.
* :issue:`34`: Added subcommand :code:`gfa2rgfa` to convert GFA to rGFA format. Tested with HPRC Minigraph-Cactus Graph (v1.1).
* Updated documentation to include :code:`gfa2rgfa` subcommand.
* Fixing :issue:`38` regarding GitHub CI/CD (that is why this version's date has been changed to 30/05/2025).
* Updating python requirement to >=3.9 and adding SPDX expression for MIT license.


v1.1.1 (23/01/2025)
-------------------

* Updated documentation to include conda installation instructions.
* Updated documentation to include preprint link and citation text.
* :issue:`33`: Fixed error when viewing regions spanning multiple nodes.
* :issue:`32`: Fixed error when trying to extract whole chromosomes.


v1.1.0 (09/10/2024)
-------------------

* Adding :code:`find_path` subcommand to take node path information as input and outputting the sequences.
* Updated :code:`order_gfa` subcommand to output chromosome-wise graphs only with :code:`--by-chrom` flag.
* Bug fix in :code:`view` subcommand and minor changes to make it faster.
* Updated documentation.


v1.0.0 (24/06/2024)
-------------------

* Initial commit.

"""
Nacos Service Registrar

Provides service registration, discovery, heartbeat, and other functionalities,
supporting simultaneous registration of HTTP and gRPC ports.
"""

import asyncio
from typing import Optional
from v2.nacos import (
    ClientConfigBuilder,
    NacosNamingService,
    RegisterInstanceParam,
    DeregisterInstanceParam,
)

from microcorex.config.config import MicroCoreConfig
from microcorex.log.logging_setup import get_logger

logger = get_logger(__name__)


class NacosRegistrationError(Exception):
    """Nacos registration exception"""

    pass


class NacosDiscoveryError(Exception):
    """Nacos discovery exception"""

    pass


class NacosRegistrar:
    """
    Nacos Service Registrar and Discovery

    Provides service registration, discovery, heartbeat, and other functionalities.
    Supports simultaneous registration of HTTP and gRPC ports.
    """

    def __init__(self, config: MicroCoreConfig):
        """
        Initialize Nacos registrar

        Args:
            config: Microservice core configuration
        """
        if not config:
            raise NacosRegistrationError("No valid configuration provided")

        self.config = config

        # Nacos client configuration
        self.client_config = (
            ClientConfigBuilder()
            .username(config.nacos.username)
            .password(config.nacos.password)
            .server_address(f"{config.nacos.host}:{config.nacos.port}")
            .namespace_id(
                config.nacos.namespace if config.nacos.namespace else "public"
            )
            .log_level("INFO")
            .build()
        )

        # Nacos naming service client
        self.nacos_client: Optional[NacosNamingService] = None

    async def register_instance(self):
        """
        Register service instance

        Simultaneously registers HTTP service and gRPC service (if gRPC port is configured).

        Raises:
            NacosRegistrationError: If service registration fails
        """
        # 尝试注册，带重试机制
        success = await self.register_with_retry(
            max_retries=5, initial_delay=1.0, max_delay=30.0, backoff_factor=2.0
        )

        if not success:
            raise NacosRegistrationError(
                "Failed to register service after multiple retries"
            )

    async def register_with_retry(
        self,
        max_retries: int = 5,
        initial_delay: float = 1.0,
        max_delay: float = 30.0,
        backoff_factor: float = 2.0,
    ) -> bool:
        """
        注册服务实例（带重试机制）

        Args:
            max_retries: 最大重试次数
            initial_delay: 初始延迟（秒）
            max_delay: 最大延迟（秒）
            backoff_factor: 退避因子

        Returns:
            bool: 注册是否成功
        """
        delay = initial_delay

        for attempt in range(max_retries + 1):
            try:
                await self._do_register()
                logger.info(
                    f"✅ Service registered successfully (attempt {attempt + 1})"
                )
                return True
            except Exception as e:
                if attempt < max_retries:
                    logger.warning(
                        f"⚠️ Failed to register service (attempt {attempt + 1}/{max_retries + 1}): {e}. "
                        f"Retrying in {delay}s..."
                    )
                    await asyncio.sleep(delay)
                    delay = min(delay * backoff_factor, max_delay)
                else:
                    logger.error(
                        f"❌ Failed to register service after {max_retries + 1} attempts: {e}"
                    )
                    # 最后一次失败后清理客户端
                    await self._cleanup_client()
                    return False

        return False

    async def _do_register(self):
        """执行实际的注册逻辑"""
        registration_results = []

        # Create naming service client if not exists
        if self.nacos_client is None:
            self.nacos_client = await NacosNamingService.create_naming_service(
                self.client_config
            )

        # Register HTTP service
        http_result = await self._register_http_service()
        registration_results.append(("HTTP", http_result))

        # Register gRPC service (if gRPC port is configured)
        if self.config.server.grpcPort:
            grpc_result = await self._register_grpc_service()
            registration_results.append(("gRPC", grpc_result))

        # Check overall registration status
        failed_services = [
            service for service, success in registration_results if not success
        ]
        if failed_services:
            raise NacosRegistrationError(
                f"Failed to register services: {', '.join(failed_services)}"
            )

    async def _register_http_service(self) -> bool:
        """
        Register HTTP service

        Returns:
            bool: True if registration successful, False otherwise
        """
        try:
            response = await self.nacos_client.register_instance(
                RegisterInstanceParam(
                    service_name=self.config.app.name,
                    group_name=self.config.nacos.groupName,
                    ip=self.config.server.ip,
                    port=self.config.server.servicePort,
                    metadata={
                        "env": self.config.app.env,
                        "protocol": "http",
                        "version": "1.0.0",
                        "service_name": self.config.app.name,
                        "service_group": self.config.nacos.groupName,
                        "registration_time": str(asyncio.get_event_loop().time()),
                    },
                    enabled=True,
                    healthy=True,
                    ephemeral=True,  # Ephemeral instance, supports heartbeat
                )
            )

            if response:
                logger.info(
                    f"✅ HTTP service registered successfully: {self.config.app.name} "
                    f"({self.config.server.ip}:{self.config.server.servicePort})"
                )
                return True
            else:
                logger.error(
                    f"❌ HTTP service registration failed: {self.config.app.name}"
                )
                return False

        except Exception as e:
            logger.error(f"HTTP service registration exception: {e}")
            return False

    async def _register_grpc_service(self) -> bool:
        """
        Register gRPC service

        Returns:
            bool: True if registration successful, False otherwise
        """
        try:
            grpc_service_name = f"{self.config.app.name}-grpc"

            response = await self.nacos_client.register_instance(
                RegisterInstanceParam(
                    service_name=grpc_service_name,
                    group_name=self.config.nacos.groupName,
                    ip=self.config.server.ip,
                    port=self.config.server.grpcPort,
                    metadata={
                        "env": self.config.app.env,
                        "protocol": "grpc",
                        "version": "1.0.0",
                        "service_name": grpc_service_name,
                        "service_group": self.config.nacos.groupName,
                        "registration_time": str(asyncio.get_event_loop().time()),
                    },
                    enabled=True,
                    healthy=True,
                    ephemeral=True,  # Ephemeral instance, supports heartbeat
                )
            )

            if response:
                logger.info(
                    f"✅ gRPC service registered successfully: {grpc_service_name} "
                    f"({self.config.server.ip}:{self.config.server.grpcPort})"
                )
                return True
            else:
                logger.error(
                    f"❌ gRPC service registration failed: {grpc_service_name}"
                )
                return False

        except Exception as e:
            logger.error(f"gRPC service registration exception: {e}")
            return False

    async def deregister_instance(self):
        """
        Deregister service instance

        Deregisters HTTP service and gRPC service from Nacos.
        """
        if not self.nacos_client:
            logger.warning("Nacos client not initialized, no need to deregister")
            return

        try:
            # Deregister HTTP service
            await self._deregister_http_service()

            # Deregister gRPC service
            if self.config.server.grpcPort:
                await self._deregister_grpc_service()

            logger.info("✅ Service deregistration completed")

        except Exception as e:
            logger.error(f"Service deregistration failed: {e}")
        finally:
            # Clean up client regardless of deregistration outcome
            await self._cleanup_client()

    async def _deregister_http_service(self):
        """Deregister HTTP service"""
        try:
            await self.nacos_client.deregister_instance(
                DeregisterInstanceParam(
                    service_name=self.config.app.name,
                    group_name=self.config.nacos.groupName,
                    ip=self.config.server.ip,
                    port=self.config.server.servicePort,
                    ephemeral=True,
                )
            )
            logger.info(
                f"HTTP service deregistered successfully: {self.config.app.name}"
            )
        except Exception as e:
            logger.error(f"HTTP service deregistration failed: {e}")

    async def _deregister_grpc_service(self):
        """Deregister gRPC service"""
        try:
            grpc_service_name = f"{self.config.app.name}-grpc"
            await self.nacos_client.deregister_instance(
                DeregisterInstanceParam(
                    service_name=grpc_service_name,
                    group_name=self.config.nacos.groupName,
                    ip=self.config.server.ip,
                    port=self.config.server.grpcPort,
                    ephemeral=True,
                )
            )
            logger.info(f"gRPC service deregistered successfully: {grpc_service_name}")
        except Exception as e:
            logger.error(f"gRPC service deregistration failed: {e}")

    async def _cleanup_client(self):
        """Clean up Nacos client resources"""
        if self.nacos_client:
            try:
                # 显式调用 shutdown() 方法关闭 gRPC 连接
                await self.nacos_client.shutdown()
                logger.debug("Nacos client shutdown successfully")
            except Exception as e:
                logger.warning(f"Error during Nacos client shutdown: {e}")
            finally:
                self.nacos_client = None

    async def is_registered(self) -> bool:
        """
        Check if services are currently registered with Nacos

        Returns:
            bool: True if client exists and was initialized, False otherwise
        """
        return self.nacos_client is not None

"""
Nacos Configuration Manager

Provides encapsulated operations for configuration center, including configuration
pulling, publishing, deletion, and monitoring functionalities.
"""

import asyncio
from typing import Optional, Callable
from functools import wraps
from v2.nacos import NacosConfigService, ConfigParam

from microcorex.log.logging_setup import get_logger

logger = get_logger(__name__)


class NacosConfigError(Exception):
    """Nacos configuration exception"""

    pass


class NacosConfigManager:
    """
    Nacos Configuration Manager

    Encapsulates Nacos Configuration Center operations, providing configuration
    pulling, publishing, deletion, and monitoring functionalities.
    Supports configuration caching and disaster recovery.
    """

    def __init__(self, client_config):
        """
        Initialize configuration manager

        Args:
            client_config: Nacos client configuration
        """
        self.client_config = client_config
        self.config_client: Optional[NacosConfigService] = None
        self._listeners = {}  # Store listeners {(data_id, group): [listeners]}

    async def initialize(self):
        """Initialize configuration client"""
        try:
            self.config_client = await NacosConfigService.create_config_service(
                self.client_config
            )
            logger.info("Nacos configuration client initialized successfully")
            return True
        except Exception as e:
            logger.warning(f"Nacos configuration client initialization failed: {e}")
            return False

    async def get_config(
        self, data_id: str, group: str = "DEFAULT_GROUP", silent: bool = False
    ) -> Optional[str]:
        """
        Get configuration

        Priority strategy:
        1. Read from local failover directory
        2. Get from server (save to snapshot after success)
        3. Read from snapshot directory

        Args:
            data_id: Configuration Data ID
            group: Configuration group name
            silent: 是否静默模式，减少日志输出（用于定时同步）

        Returns:
            Configuration content, returns None on failure
        """
        if not self.config_client:
            if not silent:
                logger.error("Configuration client not initialized")
            return None

        try:
            content = await self.config_client.get_config(
                ConfigParam(data_id=data_id, group=group)
            )
            if content:
                if not silent:
                    logger.info(
                        f"Configuration retrieved successfully: data_id={data_id}, group={group}"
                    )
            else:
                if not silent:
                    logger.warning(
                        f"Configuration does not exist: data_id={data_id}, group={group}"
                    )
            return content
        except Exception as e:
            if not silent:
                logger.error(
                    f"Failed to get configuration: data_id={data_id}, group={group}, error={e}"
                )
            return None

    async def publish_config(self, data_id: str, group: str, content: str) -> bool:
        """
        Publish configuration

        Creates configuration if it doesn't exist, updates content if it exists.

        Args:
            data_id: Configuration Data ID
            group: Configuration group name
            content: Configuration content

        Returns:
            Returns True on success, False on failure
        """
        if not self.config_client:
            logger.error("Configuration client not initialized")
            return False

        try:
            result = await self.config_client.publish_config(
                ConfigParam(data_id=data_id, group=group, content=content)
            )
            if result:
                logger.info(
                    f"Configuration published successfully: data_id={data_id}, group={group}"
                )
            else:
                logger.error(
                    f"Configuration publishing failed: data_id={data_id}, group={group}"
                )
            return result
        except Exception as e:
            logger.error(
                f"Configuration publishing exception: data_id={data_id}, group={group}, error={e}"
            )
            return False

    async def remove_config(self, data_id: str, group: str = "DEFAULT_GROUP") -> bool:
        """
        Remove configuration

        Args:
            data_id: Configuration Data ID
            group: Configuration group name

        Returns:
            Returns True on success, False on failure
        """
        if not self.config_client:
            logger.error("Configuration client not initialized")
            return False

        try:
            result = await self.config_client.remove_config(
                ConfigParam(data_id=data_id, group=group)
            )
            if result:
                logger.info(
                    f"Configuration removed successfully: data_id={data_id}, group={group}"
                )
            else:
                logger.error(
                    f"Configuration removal failed: data_id={data_id}, group={group}"
                )
            return result
        except Exception as e:
            logger.error(
                f"Configuration removal exception: data_id={data_id}, group={group}, error={e}"
            )
            return False

    def _safe_callback(self, callback: Callable, data_id: str, group: str) -> Callable:
        """
        包装回调函数，捕获异常防止监听器失效

        Args:
            callback: 原始回调函数
            data_id: 配置 Data ID
            group: 配置组名

        Returns:
            包装后的回调函数
        """

        @wraps(callback)
        async def wrapper(*args, **kwargs):
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(*args, **kwargs)
                else:
                    callback(*args, **kwargs)
            except Exception as e:
                logger.error(
                    f"⚠️ Error in config listener callback for {group}:{data_id}: {e}",
                    exc_info=True,
                )

        return wrapper

    async def add_listener(
        self, data_id: str, group: str, listener: Callable, safe_mode: bool = True
    ):
        """
        Add configuration listener

        Triggers callback when configuration changes or is deleted. If configuration exists,
        triggers callback immediately.

        Args:
            data_id: Configuration Data ID
            group: Configuration group name
            listener: Configuration monitoring callback function (tenant, data_id, group, content) -> None
            safe_mode: 是否启用安全模式（捕获回调异常）
        """
        if not self.config_client:
            logger.error("Configuration client not initialized")
            return

        try:
            # 如果启用安全模式，包装回调函数
            wrapped_listener = (
                self._safe_callback(listener, data_id, group) if safe_mode else listener
            )

            await self.config_client.add_listener(
                data_id=data_id, group=group, listener=wrapped_listener
            )

            # Record listener (记录原始 listener 以便后续删除)
            key = (data_id, group)
            if key not in self._listeners:
                self._listeners[key] = []
            self._listeners[key].append(listener)

            logger.info(
                f"✅ Configuration listener added successfully: data_id={data_id}, group={group}"
            )
        except Exception as e:
            logger.error(
                f"❌ Failed to add configuration listener: data_id={data_id}, group={group}, error={e}"
            )

    async def remove_listener(self, data_id: str, group: str, listener: Callable):
        """
        Remove configuration listener

        Args:
            data_id: Configuration Data ID
            group: Configuration group name
            listener: Configuration monitoring callback function
        """
        if not self.config_client:
            logger.error("Configuration client not initialized")
            return

        try:
            await self.config_client.remove_listener(
                data_id=data_id, group=group, listener=listener
            )

            # Remove record
            key = (data_id, group)
            if key in self._listeners and listener in self._listeners[key]:
                self._listeners[key].remove(listener)

            logger.info(
                f"Configuration listener removed successfully: data_id={data_id}, group={group}"
            )
        except Exception as e:
            logger.error(
                f"Failed to remove configuration listener: data_id={data_id}, group={group}, error={e}"
            )

    async def shutdown(self):
        """Shutdown configuration client and cleanup all listeners"""
        if self.config_client:
            try:
                # Remove all listeners to prevent memory leaks
                await self._remove_all_listeners()

                # Shutdown the client
                await self.config_client.shutdown()
                logger.info("Nacos configuration client closed")

            except Exception as e:
                logger.error(f"Failed to close configuration client: {e}")

        # Clear internal listener tracking
        self._listeners.clear()

    async def _remove_all_listeners(self):
        """
        Remove all registered listeners to prevent memory leaks
        """
        try:
            # Create a copy of the listeners dictionary to avoid modification during iteration
            listeners_copy = self._listeners.copy()

            for (data_id, group), listeners in listeners_copy.items():
                for listener in listeners:
                    try:
                        await self.config_client.remove_listener(
                            data_id=data_id, group=group, listener=listener
                        )
                    except Exception as e:
                        # Log error but continue with cleanup
                        logger.debug(
                            f"Failed to remove listener during shutdown: data_id={data_id}, group={group}, error={e}"
                        )

            logger.info(f"Cleaned up {len(listeners_copy)} listener groups")

        except Exception as e:
            logger.error(f"Error during listener cleanup: {e}")


    async def start_polling_listener(
        self,
        data_id: str,
        group: str,
        listener: Callable,
        interval: int = 5,
    ):
        """
        启动轮询监听器 (替代官方监听器的可靠方案)
        
        由于 Nacos Python SDK v2 的 add_listener 存在已知 Bug (监听器不触发),
        此方法通过定期轮询配置的 MD5 值来检测配置变更,实现配置热更新。
        
        Args:
            data_id: 配置 Data ID
            group: 配置组名
            listener: 配置变更回调函数 (tenant, data_id, group, content) -> None
            interval: 轮询间隔(秒), 默认 5 秒
        
        Returns:
            asyncio.Task: 轮询任务对象,可用于取消任务
        """
        if not self.config_client:
            logger.error("Configuration client not initialized")
            return None
        
        # 初始化 MD5 缓存
        key = (data_id, group)
        if not hasattr(self, '_md5_cache'):
            self._md5_cache = {}
        if not hasattr(self, '_polling_tasks'):
            self._polling_tasks = {}
        
        # 获取初始配置和 MD5
        try:
            initial_content = await self.get_config(data_id, group, silent=True)
            if initial_content:
                import hashlib
                self._md5_cache[key] = hashlib.md5(initial_content.encode('utf-8')).hexdigest()
                logger.info(
                    f"📌 Initial config MD5 cached: data_id={data_id}, group={group}, md5={self._md5_cache[key][:8]}..."
                )
        except Exception as e:
            logger.warning(f"Failed to get initial config for polling: {e}")
            self._md5_cache[key] = None
        
        # 定义轮询任务
        async def polling_task():
            """轮询任务:定期检查配置 MD5 是否变化"""
            logger.info(
                f"🔄 Polling listener started: data_id={data_id}, group={group}, interval={interval}s"
            )
            
            while True:
                try:
                    await asyncio.sleep(interval)

                    # 获取当前配置（静默模式，减少日志输出）
                    current_content = await self.get_config(data_id, group, silent=True)
                    if current_content is None:
                        continue
                    
                    # 计算当前 MD5
                    import hashlib
                    current_md5 = hashlib.md5(current_content.encode('utf-8')).hexdigest()
                    
                    # 与缓存的 MD5 对比
                    if self._md5_cache.get(key) != current_md5:
                        logger.info(
                            f"🔔 Config change detected: data_id={data_id}, group={group}, "
                            f"old_md5={self._md5_cache.get(key, 'None')[:8]}..., "
                            f"new_md5={current_md5[:8]}..."
                        )
                        
                        # 更新 MD5 缓存
                        self._md5_cache[key] = current_md5
                        
                        # 触发回调函数
                        try:
                            # 获取 namespace (tenant)
                            namespace = getattr(self.client_config, 'namespace_id', 'public')
                            
                            # 调用回调函数
                            if asyncio.iscoroutinefunction(listener):
                                await listener(namespace, data_id, group, current_content)
                            else:
                                listener(namespace, data_id, group, current_content)
                        except Exception as e:
                            logger.error(
                                f"⚠️ Error in polling listener callback for {group}:{data_id}: {e}",
                                exc_info=True,
                            )
                
                except asyncio.CancelledError:
                    logger.info(
                        f"🛑 Polling listener stopped: data_id={data_id}, group={group}"
                    )
                    break
                except Exception as e:
                    logger.error(
                        f"⚠️ Error in polling task for {group}:{data_id}: {e}",
                        exc_info=True,
                    )
                    # 继续轮询,不中断
                    continue
        
        # 启动轮询任务
        task = asyncio.create_task(polling_task())
        self._polling_tasks[key] = task
        
        logger.info(
            f"✅ Polling listener registered: data_id={data_id}, group={group}, interval={interval}s"
        )
        
        return task
    
    async def stop_polling_listener(self, data_id: str, group: str):
        """
        停止轮询监听器
        
        Args:
            data_id: 配置 Data ID
            group: 配置组名
        """
        if not hasattr(self, '_polling_tasks'):
            return
        
        key = (data_id, group)
        if key in self._polling_tasks:
            task = self._polling_tasks[key]
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            
            del self._polling_tasks[key]
            logger.info(
                f"✅ Polling listener stopped: data_id={data_id}, group={group}"
            )
    
    async def stop_all_polling_listeners(self):
        """停止所有轮询监听器"""
        if not hasattr(self, '_polling_tasks'):
            return
        
        tasks = list(self._polling_tasks.values())
        for task in tasks:
            task.cancel()
        
        # 等待所有任务取消完成
        await asyncio.gather(*tasks, return_exceptions=True)
        
        self._polling_tasks.clear()
        logger.info("✅ All polling listeners stopped")

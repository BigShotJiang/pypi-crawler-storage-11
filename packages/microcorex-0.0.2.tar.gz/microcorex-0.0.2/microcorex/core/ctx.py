import contextvars

CTX_LANG: contextvars.ContextVar[str | None] = contextvars.ContextVar("lang", default=None)

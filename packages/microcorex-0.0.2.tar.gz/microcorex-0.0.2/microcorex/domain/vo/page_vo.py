from typing import List, Generic, TypeVar, Optional

from pydantic import BaseModel

T = TypeVar('T')

class PageVo(BaseModel, Generic[T]):
    """
    统一分页响应模型
    - rows: 当前页数据列表
    - total: 总记录数
    """
    rows: List[T]
    total: int

    def __init__(self, rows: Optional[List[T]], total: int = 0):
        super().__init__(rows=rows or [], total=total)

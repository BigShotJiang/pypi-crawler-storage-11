from http import HTTPStatus
from typing import Generic, TypeVar, Optional, Any

from pydantic import BaseModel, Field

# 定义泛型类型 T，表示 data 字段可以是任意类型
T = TypeVar('T')


class R(BaseModel, Generic[T]):
    """
    通用API响应模型
    - code: 状态码
    - msg: 响应消息
    - data: 响应数据
    - success: 是否操作成功
    """
    code: int = Field(default=HTTPStatus.OK.value, description="状态码")
    msg: str = Field(default="success", description="响应消息")
    data: Optional[T] = Field(description="响应数据")
    success: bool = Field(default=True, description="是否操作成功")

    @classmethod
    def ok(
            cls,
            data: Optional[T] = None,
            code: int = HTTPStatus.OK.value,
            msg: str = "success"
    ) -> "R[T]":
        """
        创建成功响应（带数据）
        :param data: 返回数据
        :param code: 状态码，默认 200
        :param msg: 提示信息，默认 "success"
        """
        return cls(code=code, msg=msg, data=data, success=True)

    @classmethod
    def success_with_code(
            cls,
            code: int,
            data: Optional[T] = None
    ) -> "R[T]":
        """
        创建带自定义状态码的成功响应
        :param code: 自定义状态码
        :param data: 返回数据
        """
        return cls(code=code, msg="success", data=data, success=True)

    @classmethod
    def fail(
            cls,
            code: int = HTTPStatus.INTERNAL_SERVER_ERROR.value,
            msg: str = "fail",
            data: Optional[T] = None
    ) -> "R[T]":
        """
        创建失败响应
        :param code: 状态码，默认 500
        :param msg: 错误信息
        :param data: 附加错误数据
        """
        return cls(code=code, msg=msg, data=data, success=False)

    @classmethod
    def fail_with_detail(
            cls,
            code: int,
            msg: str,
            data: Optional[T] = None
    ) -> "R[T]":
        """
        创建带详细错误信息的失败响应
        :param code: 状态码
        :param msg: 详细错误信息
        :param data: 附加错误数据
        """
        return cls(code=code, msg=msg, data=data, success=False)

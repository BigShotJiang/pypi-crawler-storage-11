from pydantic import Field, BaseModel


class PageQo(BaseModel):
    """
    统一分页参数
    - pageNum: 页码
    - pageSize: 每页数量
    """
    pageNum: int = Field(default=1, description="当前页", gt=0)
    pageSize: int = Field(default=10, description="每页数量", gt=0)

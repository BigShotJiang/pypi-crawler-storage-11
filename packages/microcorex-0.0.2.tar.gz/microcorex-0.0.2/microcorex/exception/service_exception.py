from http import HTTPStatus


class ServiceException(Exception):
    def __init__(self, code: int | None = HTTPStatus.BAD_REQUEST.value, msg: str = 'fail'):
        self.code = code
        self.msg = msg

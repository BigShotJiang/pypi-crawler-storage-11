import sys
import traceback
from http import HTTPStatus
from typing import Any, List

from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from sqlalchemy.exc import IntegrityError
from starlette.exceptions import HTTPException
from starlette.requests import Request
from starlette.responses import JSONResponse

from microcorex.log.logging_setup import get_logger
from microcorex.domain.vo.r import R
from microcorex.exception.security_exception import SecurityException
from microcorex.exception.service_exception import ServiceException

logger = get_logger(__name__)


def init_exception(app: FastAPI):
    """
    全局异常处理
    """

    # HTTPException 异常
    app.add_exception_handler(HTTPException, http_exception_handler)

    # 业务异常
    app.add_exception_handler(ServiceException, service_exception_handler)

    # 参数校验异常
    app.add_exception_handler(RequestValidationError, validation_exception_handler)

    # 权限异常
    app.add_exception_handler(SecurityException, security_exception_handler)

    # 数据库完整性异常处理器
    app.add_exception_handler(IntegrityError, integrity_error_handler)

    # 兜底处理
    app.add_exception_handler(Exception, global_exception_handler)

    logger.info("✅ Initialize global exception catcher")


async def http_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    if isinstance(exc, HTTPException):
        logger.error(f"HTTPException: {exc.detail}", exc_info=True)
        return JSONResponse(R.fail_with_detail(exc.status_code, exc.detail).model_dump())
    return JSONResponse(R.fail().model_dump())


async def service_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    if isinstance(exc, ServiceException):
        exc_type, _, exc_tb = sys.exc_info()
        simplified_tb = traceback.format_list(traceback.extract_tb(exc_tb)[-3:])
        error_info = (
            f"业务异常: {exc.msg}\n"
            f"异常类型: {exc_type.__name__}\n"
            f"关键堆栈:\n{''.join(simplified_tb)}"
        )
        logger.error(error_info)
        return JSONResponse(R.fail_with_detail(exc.code, exc.msg).model_dump())
    return JSONResponse(R.fail().model_dump())


async def validation_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    if isinstance(exc, RequestValidationError):
        errors = []
        for error in exc.errors():
            error_info = {
                "field": ".".join(str(loc) for loc in error["loc"]),
                "msg": error["msg"],
                "type": error["type"],
            }
            errors.append(error_info)
        return JSONResponse(
            R[List[Any]].fail(code=HTTPStatus.BAD_REQUEST.value, msg='参数错误', data=errors).model_dump())
    return JSONResponse(R.fail(code=HTTPStatus.BAD_REQUEST.value, msg="参数错误").model_dump())


async def security_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    if isinstance(exc, SecurityException):
        return JSONResponse(R.fail_with_detail(exc.code, exc.msg).model_dump())
    return JSONResponse(R.fail().model_dump())


async def integrity_error_handler(request: Request, exc: Exception) -> JSONResponse:
    if not isinstance(exc, IntegrityError):
        return JSONResponse(R.fail().model_dump())

    error_msg = str(exc.orig).lower()
    # 判断是否为唯一性约束冲突
    if "unique constraint" in error_msg or "duplicate key" in error_msg:
        # 从原始异常中提取详细信息（如果存在）
        detail = getattr(exc.orig, 'detail', '数据已存在，请检查后重试')
        logger.warning(f"数据库唯一性约束冲突: {detail}")
        return JSONResponse(
            content=R.fail(code=HTTPStatus.CONFLICT.value, msg=detail).model_dump()
        )
    # 如果是其他类型的 IntegrityError (如外键约束失败)
    logger.error("数据库完整性异常", exc_info=exc)
    return JSONResponse(
        content=R.fail(code=HTTPStatus.BAD_REQUEST.value, msg="数据不符合要求，操作失败").model_dump()
    )


async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.error(f"系统发生未知异常", exc_info=True)
    return JSONResponse(R.fail(msg='系统异常，请稍后再试').model_dump())

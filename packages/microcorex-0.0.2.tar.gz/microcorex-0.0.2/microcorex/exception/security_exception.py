from http import HTTPStatus


class SecurityException(Exception):
    def __init__(self, code: int | None = HTTPStatus.FORBIDDEN.value, msg: str = 'fail'):
        self.code = code
        self.msg = msg

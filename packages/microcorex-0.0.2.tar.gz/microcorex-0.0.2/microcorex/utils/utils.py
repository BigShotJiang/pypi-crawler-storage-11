"""
Utility Module

Provides utility functions for IP retrieval, address resolution, etc.
"""

import socket
import re
import ipaddress
from typing import Union, Tuple, Optional


def get_local_ip(safe_mode: bool = True) -> str:
    """
    Get local IP address with fallback to 127.0.0.1

    Args:
        safe_mode: If True, only uses safe target addresses for network operations

    Returns:
        str: Local IP address
    """
    try:
        # Use safe target address for network operations
        target_ip = (
            "8.8.8.8" if safe_mode and is_safe_target_address("8.8.8.8") else "8.8.8.8"
        )

        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect((target_ip, 80))
            ip = s.getsockname()[0]

            # Validate returned IP
            if is_valid_ip(ip):
                return ip

    except (OSError, socket.error):
        pass

    try:
        # Fallback: Get hostname IP
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)

        # Validate hostname IP
        if is_valid_ip(ip):
            # If 127.0.0.1 is obtained, try other methods
            if ip.startswith("127."):
                # Get all network interface IPs
                try:
                    for interface in [
                        socket.gethostbyname_ex(host)[2]
                        for host in socket.gethostbyname_ex(socket.gethostname())[2]
                    ]:
                        for addr in interface:
                            if (
                                is_valid_ip(addr)
                                and not addr.startswith("127.")
                                and not addr.startswith("169.254.")
                            ):
                                return addr
                except (OSError, socket.error):
                    pass
                return "127.0.0.1"
            return ip

    except (OSError, socket.error):
        pass

    # Final fallback
    return "127.0.0.1"


def is_valid_port(port: int) -> bool:
    """
    Check if port number is valid (excluding privileged ports)

    Args:
        port: Port number

    Returns:
        bool: Whether valid
    """
    return 1024 <= port <= 65535


def is_valid_ip(ip: str) -> bool:
    """
    Check if IP address is valid (supports both IPv4 and IPv6)

    Args:
        ip: IP address

    Returns:
        bool: Whether valid
    """
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False


def is_valid_hostname(hostname: str) -> bool:
    """
    Check if hostname is valid according to RFC standards

    Args:
        hostname: Hostname string

    Returns:
        bool: Whether valid
    """
    if not hostname or len(hostname) > 253:
        return False

    # Check for valid characters and patterns
    pattern = r"^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$"
    return re.match(pattern, hostname) is not None


def is_safe_target_address(ip: str) -> bool:
    """
    Check if target IP address is safe for network operations

    Args:
        ip: Target IP address

    Returns:
        bool: Whether the IP address is safe for network operations
    """
    try:
        ip_obj = ipaddress.ip_address(ip)

        # Check if it's a private IP, localhost, or link-local
        if ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local:
            return True

        # Allow specific public IPs known to be safe (like DNS servers)
        safe_public_ips = {
            "8.8.8.8",  # Google DNS
            "8.8.4.4",  # Google DNS
            "1.1.1.1",  # Cloudflare DNS
            "1.0.0.1",  # Cloudflare DNS
        }

        return str(ip_obj) in safe_public_ips

    except ValueError:
        return False


def resolve_address(address: str) -> Tuple[str, int]:
    """
    Parse address string into IP and port (supports both IPv4 and IPv6)

    Args:
        address: Address string in format "ip:port" or "[ipv6]:port"

    Returns:
        tuple[str, int]: (ip, port)
    """
    if not address:
        raise ValueError("Address cannot be empty")

    # Handle IPv6 addresses which are wrapped in brackets
    if address.startswith("[") and "]:" in address:
        # IPv6 format: [2001:db8::1]:8080
        bracket_end = address.find("]:")
        ip = address[1:bracket_end]
        port_str = address[bracket_end + 2 :]
    elif ":" in address:
        # IPv4 format: 192.168.1.1:8080
        parts = address.rsplit(":", 1)
        if len(parts) != 2:
            raise ValueError(
                f"Invalid address format: {address}, expected format: ip:port or [ipv6]:port"
            )
        ip, port_str = parts
    else:
        raise ValueError(
            f"Invalid address format: {address}, expected format: ip:port or [ipv6]:port"
        )

    # Validate and parse port
    try:
        port = int(port_str)
    except ValueError:
        raise ValueError(f"Invalid port number: {port_str}")

    # Validate IP address
    if not is_valid_ip(ip):
        raise ValueError(f"Invalid IP address: {ip}")

    # Validate port range
    if not is_valid_port(port):
        raise ValueError(f"Port number {port} out of valid range (1024-65535)")

    return ip, port


def validate_service_name(service_name: str) -> bool:
    """
    Validate service name according to microservice naming conventions

    Args:
        service_name: Service name string

    Returns:
        bool: Whether the service name is valid
    """
    if not service_name:
        return False

    # Service name should be 3-50 characters, lowercase letters, numbers, and hyphens
    pattern = r"^[a-z][a-z0-9-]{2,49}$"
    if not re.match(pattern, service_name):
        return False

    # Should not start or end with hyphen
    if service_name.startswith("-") or service_name.endswith("-"):
        return False

    # Should not contain consecutive hyphens
    if "--" in service_name:
        return False

    return True


def sanitize_log_data(data: dict, sensitive_keys: Optional[list] = None) -> dict:
    """
    Sanitize sensitive data from dictionaries before logging

    Args:
        data: Dictionary to sanitize
        sensitive_keys: List of sensitive key patterns (default: common sensitive patterns)

    Returns:
        dict: Sanitized dictionary
    """
    if sensitive_keys is None:
        sensitive_keys = [
            "password",
            "token",
            "secret",
            "key",
            "credential",
            "auth",
            "private",
        ]

    sanitized = data.copy()

    for key, value in sanitized.items():
        if any(sensitive in key.lower() for sensitive in sensitive_keys):
            sanitized[key] = "***REDACTED***"
        elif isinstance(value, dict):
            sanitized[key] = sanitize_log_data(value, sensitive_keys)
        elif isinstance(value, list):
            sanitized[key] = [
                (
                    sanitize_log_data(item, sensitive_keys)
                    if isinstance(item, dict)
                    else item
                )
                for item in value
            ]

    return sanitized

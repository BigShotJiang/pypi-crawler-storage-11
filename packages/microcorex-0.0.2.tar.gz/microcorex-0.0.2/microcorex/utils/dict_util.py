from typing import List, Dict, Any, Set


def models_to_dicts(models: List[Any], exclude: Set[str] = None) -> List[Dict[str, Any]]:
    """
    模型实例列表转换为字典列表
    Args:
        models: SQLAlchemy模型实例的列表。
        exclude: 一个包含要从字典中排除的字段名的集合。例如: {'_sa_instance_state'}
    Returns:
        一个字典列表。
    """
    if not models:
        return []

    # 调用 models_to_dict 来处理列表中的每一个元素
    return [models_to_dict(model, exclude) for model in models]


def models_to_dict(model: Any, exclude: Set[str] = None) -> Dict[str, Any]:
    """
    模型实例转换为字典
    Args:
        model: SQLAlchemy模型实例
        exclude: 一个包含要从字典中排除的字段名的集合。例如: {'_sa_instance_state'}
    Returns:
        字典
    """
    if not model:
        return {}

    # 准备要排除的键集合
    keys_to_exclude = {'_sa_instance_state'}
    if exclude:
        keys_to_exclude.update(exclude)

    # 使用字典推导式从模型的 __dict__ 属性创建字典，并排除指定的键
    return {
        key: value
        for key, value in model.__dict__.items()
        if key not in keys_to_exclude
    }

def decimal_to_chinese_uppercase(value):
    # 定义数字对应的大写中文
    digit_map = {
        '0': '零',
        '1': '壹',
        '2': '贰',
        '3': '叁',
        '4': '肆',
        '5': '伍',
        '6': '陆',
        '7': '柒',
        '8': '捌',
        '9': '玖'
    }

    # 定义单位
    integer_units = ['', '拾', '佰', '仟', '万', '拾', '佰', '仟', '亿', '拾', '佰', '仟', '兆']
    decimal_units = ['角', '分']

    # 处理负数
    if value < 0:
        return '负' + decimal_to_chinese_uppercase(abs(value))

    # 转换为字符串并分割整数和小数部分
    str_value = str(value)
    if '.' in str_value:
        integer_part, decimal_part = str_value.split('.')
        decimal_part = decimal_part[:2]  # 只保留两位小数
    else:
        integer_part = str_value
        decimal_part = ''

    # 处理整数部分
    result = []
    integer_len = len(integer_part)

    for i, digit in enumerate(integer_part):
        if digit == '0':
            # 处理连续的零和亿/万位的零
            if (integer_len - i) % 4 == 1 and result and result[-1] != '零':
                result.append('零')
        else:
            result.append(digit_map[digit])
            unit_pos = integer_len - i - 1
            if unit_pos < len(integer_units):
                result.append(integer_units[unit_pos])

    # 处理小数部分
    if decimal_part:
        for i, digit in enumerate(decimal_part[:2]):  # 最多处理两位小数
            if digit != '0':
                result.append(digit_map[digit])
                if i < len(decimal_units):
                    result.append(decimal_units[i])

    # 处理结果中的"零零"等情况
    chinese_str = ''.join(result)

    # 替换连续的零
    while '零零' in chinese_str:
        chinese_str = chinese_str.replace('零零', '零')

    # 处理零万、零亿等情况
    for unit in ['亿', '万']:
        chinese_str = chinese_str.replace(f'零{unit}', f'{unit}')

    # 去除末尾的零
    if chinese_str.endswith('零'):
        chinese_str = chinese_str[:-1]

    # 如果没有小数部分，添加"整"
    if not decimal_part or all(d == '0' for d in decimal_part):
        chinese_str += '元整'
    else:
        chinese_str += '元'

    return chinese_str

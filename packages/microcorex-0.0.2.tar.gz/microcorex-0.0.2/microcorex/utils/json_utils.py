import enum
import json
import types
from typing import Any


def to_json_string(obj: Any, is_remove_none: bool = False) -> str:
    def remove_none(o: Any) -> Any:
        if isinstance(o, dict):
            return {k: remove_none(v) for k, v in o.items() if v is not None}
        elif isinstance(o, list):
            return [remove_none(i) for i in o if i is not None]
        elif isinstance(o, types.MappingProxyType):
            return remove_none(dict(o))
        elif isinstance(o, enum.Enum):  # 处理 Enum
            return o.value
        elif hasattr(o, "__dict__"):  # 普通对象
            return remove_none(vars(o))
        else:
            return o

    clean_obj = remove_none(obj)

    return json.dumps(clean_obj, ensure_ascii=False)

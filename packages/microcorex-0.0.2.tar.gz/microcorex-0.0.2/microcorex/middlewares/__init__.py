from microcorex.middlewares.i18n_middleware import I18nMiddleware
from starlette.middleware import Middleware

from microcorex.middlewares.logging_middleware import LoggingMiddleware
from microcorex.middlewares.security_middleware import SecurityMiddleware


def load_i18n_middleware():
    return Middleware(I18nMiddleware)


def load_logging_middleware():
    return Middleware(LoggingMiddleware)


def load_security_middleware():
    return Middleware(SecurityMiddleware)

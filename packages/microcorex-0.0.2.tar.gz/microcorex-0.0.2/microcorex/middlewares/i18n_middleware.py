from starlette.middleware.base import BaseHTTPMiddleware
from fastapi import Request

from microcorex.log.logging_setup import get_logger
from microcorex.core.ctx import CTX_LANG

logger = get_logger(__name__)


class I18nMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # 从 header 或 query 参数取语言
        lang = request.headers.get("Accept-Language") or request.query_params.get("lang") or "en_US"
        lang = lang.replace("-", "_")  # 兼容 zh-CN -> zh_CN
        request.state.lang = lang
        CTX_LANG.set(lang)
        logger.info(f"[I18nMiddleware] lang: {lang}")
        response = await call_next(request)
        return response

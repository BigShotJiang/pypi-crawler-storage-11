import json
import time
from typing import Dict, Any, Optional

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

from microcorex.log.logging_setup import get_logger

logger = get_logger(__name__)

SENSITIVE_FIELDS = {"password", "token", "id_card", "credit_card", "phone"}


def filter_sensitive_data(data: Any, sensitive_fields: set) -> Any:
    """递归过滤敏感数据"""
    if isinstance(data, dict):
        return {
            key: "***" if key in sensitive_fields else filter_sensitive_data(value, sensitive_fields)
            for key, value in data.items()
        }
    elif isinstance(data, list):
        return [filter_sensitive_data(item, sensitive_fields) for item in data]
    return data


class LoggingMiddleware(BaseHTTPMiddleware):
    """安全的请求日志中间件（兼容流式响应）"""

    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        method = request.method
        path = request.url.path
        client_ip = request.client.host if request.client else "unknown"
        query_params = dict(request.query_params)
        path_params = request.path_params

        # print(request.app.state.config.test)

        # 安全地收集请求体（不干扰流式处理）
        request_body: Optional[Any] = None
        content_type = request.headers.get("content-type", "")

        # 仅处理非流式、非文件上传的小型请求体
        if (
                method in ("POST", "PUT", "PATCH")
                and "multipart/form-data" not in content_type
                and "application/octet-stream" not in content_type
        ):
            try:
                content_length = int(request.headers.get("content-length", 0))
                if 0 < content_length < 1024 * 1024:  # 1MB限制
                    # 创建请求体副本而不修改原始请求
                    body_bytes = await request.body()

                    # 尝试解析JSON
                    try:
                        request_body = filter_sensitive_data(
                            json.loads(body_bytes.decode("utf-8")),
                            SENSITIVE_FIELDS
                        )
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        request_body = "<binary or non-json data>"
            except Exception as e:
                request_body = f"<body read error: {str(e)}>"
        else:
            request_body = "<stream or large body skipped>"

        # 构建日志数据
        log_data: Dict[str, Any] = {
            "method": method,
            "path": path,
            "ip": client_ip,
            "query_params": query_params,
            "path_params": path_params,
            "request_body": request_body,
            "start_time": start_time
        }

        # 处理请求
        response = None
        try:
            response = await call_next(request)
        except Exception as exc:
            # 异常处理
            log_data.update({
                "status": 500,
                "error": str(exc),
                "process_time": time.time() - start_time
            })
            logger.error("Request error", extra=log_data, exc_info=True)
            raise exc from None

        # 记录响应信息
        process_time = time.time() - start_time
        log_data.update({
            "status": response.status_code,
            "process_time": f"{process_time:.4f}s",
            "response_size": response.headers.get("content-length", "unknown")
        })

        pretty_log = json.dumps(log_data, ensure_ascii=False, indent=2)

        # 分级日志记录
        if response.status_code >= 500:
            logger.error(f"Server error \n {pretty_log}")
        elif response.status_code >= 400:
            logger.warning(f"Client error \n {pretty_log}")
        else:
            logger.info(f"Request processed \n {pretty_log}")

        return response

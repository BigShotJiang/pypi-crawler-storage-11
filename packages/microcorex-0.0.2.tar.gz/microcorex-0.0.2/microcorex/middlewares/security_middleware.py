import re
from typing import List, Pattern, Optional, Dict, Any
from http import HTTPStatus

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from microcorex.log.logging_setup import get_logger
from microcorex.jwt.jwt_manager import (
    get_jwt_manager,
    JWTError,
    InvalidTokenError,
    TokenExpiredError,
    InvalidTokenTypeError,
    JWTNotInitializedError
)
from microcorex.domain.vo.r import R

logger = get_logger(__name__)


class SecurityMiddleware(BaseHTTPMiddleware):
    """
    JWT安全中间件

    提供完整的访问控制功能：
    1. 白名单URL访问控制，支持多种匹配模式
    2. JWT令牌校验
    3. Bearer Token认证
    4. 自定义认证头支持

    白名单匹配模式：
    - 精确匹配：/api/health
    - 前缀匹配：/api/public/*
    - 正则匹配：regex:^/api/v\\d+/users/\\d+$
    - HTTP方法匹配：GET:/api/docs
    """

    def __init__(
            self,
            app,
            enabled: bool = True,
            jwt_required: bool = True,
            auth_header_name: str = "Authorization",
            token_prefix: str = "Bearer",
            skip_paths: Optional[List[str]] = None
    ):
        """
        初始化安全中间件

        Args:
            app: ASGI应用实例
            enabled: 是否启用安全中间件，默认为True
            jwt_required: 是否要求JWT认证，默认为True
            auth_header_name: 认证头名称，默认为"Authorization"
            token_prefix: Token前缀，默认为"Bearer"
            skip_paths: 跳过JWT认证的路径列表
        """
        super().__init__(app)
        self.enabled = enabled
        self.jwt_required = jwt_required
        self.auth_header_name = auth_header_name
        self.token_prefix = token_prefix
        self.skip_paths = skip_paths or []
        self._compiled_patterns: dict[str, Pattern] = {}

    async def dispatch(self, request: Request, call_next):
        """
        请求分发处理

        Args:
            request: HTTP请求对象
            call_next: 下一个中间件或路由处理器

        Returns:
            Response: HTTP响应对象
        """
        # 如果安全中间件被禁用，直接放行
        if not self.enabled:
            return await call_next(request)

        # 检查请求是否在白名单中
        if await self._is_whitelisted(request):
            logger.debug(f"请求在白名单中，允许访问: {request.method} {request.url.path}")
            return await call_next(request)

        # 检查是否跳过JWT认证
        if self._should_skip_jwt(request):
            logger.debug(f"跳过JWT认证: {request.method} {request.url.path}")
            return await call_next(request)

        # 如果不需要JWT认证，直接放行
        if not self.jwt_required:
            logger.debug(f"JWT认证未启用，允许访问: {request.method} {request.url.path}")
            return await call_next(request)

        # 执行JWT令牌校验
        user_data = await self._verify_jwt_token(request)
        if user_data:
            # 将用户信息存储到请求状态中，供后续使用
            if hasattr(request, 'state'):
                request.state.user = user_data
                logger.debug(f"JWT验证成功: {request.method} {request.url.path}, 用户: {user_data}")
            return await call_next(request)

        # JWT验证失败，返回401未授权
        logger.warning(f"JWT验证失败: {request.method} {request.url.path}")

        return self._create_unauthorized_response(request)

    async def _is_whitelisted(self, request: Request) -> bool:
        """
        检查请求是否在白名单中

        Args:
            request: HTTP请求对象

        Returns:
            bool: 是否在白名单中
        """
        try:
            white_urls = get_white_url_list(request)
            current_path = request.url.path
            current_method = request.method.upper()

            logger.debug(f"检查白名单: {current_method} {current_path}")
            logger.debug(f"白名单配置: {white_urls}")

            for white_url in white_urls:
                if self._match_url(white_url, current_path, current_method):
                    logger.debug(f"匹配白名单规则: {white_url}")
                    return True

            return False

        except Exception as e:
            logger.error(f"白名单检查失败: {e}")
            # 出错时默认拒绝访问，更安全
            return False

    def _match_url(self, pattern: str, path: str, method: str) -> bool:
        """
        匹配URL模式

        支持的匹配模式：
        1. 精确匹配：/api/health
        2. 前缀匹配：/api/public/*
        3. 正则匹配：regex:^/api/v\\d+/users/\\d+$
        4. HTTP方法匹配：GET:/api/docs 或 POST:/api/public/*

        Args:
            pattern: 白名单模式
            path: 请求路径
            method: HTTP方法

        Returns:
            bool: 是否匹配
        """
        try:
            # 解析模式，支持方法前缀
            if ':' in pattern and not pattern.startswith('regex:'):
                method_pattern, url_pattern = pattern.split(':', 1)
                # 检查HTTP方法是否匹配
                if method_pattern.upper() != method:
                    return False
            else:
                url_pattern = pattern

            # 正则表达式匹配
            if url_pattern.startswith('regex:'):
                regex_pattern = url_pattern[6:]  # 移除 'regex:' 前缀
                compiled_pattern = self._get_compiled_pattern(regex_pattern)
                return bool(compiled_pattern.match(path))

            # 通配符匹配（支持 * 和 **）
            elif '*' in url_pattern:
                # 将通配符转换为正则表达式
                regex_pattern = self._wildcard_to_regex(url_pattern)
                compiled_pattern = self._get_compiled_pattern(regex_pattern)
                return bool(compiled_pattern.match(path))

            # 精确匹配
            else:
                return url_pattern == path

        except Exception as e:
            logger.error(f"URL模式匹配失败: pattern={pattern}, path={path}, error={e}")
            return False

    def _wildcard_to_regex(self, pattern: str) -> str:
        """
        将通配符模式转换为正则表达式

        支持的通配符：
        * 匹配任意字符（除了路径分隔符）
        ** 匹配任意字符（包括路径分隔符）

        Args:
            pattern: 通配符模式

        Returns:
            str: 正则表达式
        """
        # 处理空模式
        if not pattern:
            return r'^$'

        # 转义特殊字符
        pattern = re.escape(pattern)

        # 恢复通配符
        pattern = pattern.replace(r'\\*\\*', '.*')  # ** 匹配任意字符
        pattern = pattern.replace(r'\\*', '[^/]*')  # * 匹配除/外的任意字符

        # 确保完全匹配
        return f'^{pattern}$'

    def _get_compiled_pattern(self, pattern: str) -> Pattern:
        """
        获取编译后的正则表达式模式（带缓存）

        Args:
            pattern: 正则表达式模式

        Returns:
            Pattern: 编译后的正则表达式对象
        """
        if pattern not in self._compiled_patterns:
            self._compiled_patterns[pattern] = re.compile(pattern)
        return self._compiled_patterns[pattern]

    def _get_token(self, request: Request) -> Optional[str]:
        """
        从请求中提取JWT令牌

        Args:
            request: HTTP请求对象

        Returns:
            Optional[str]: JWT令牌，如果未找到则返回None
        """
        # 方法1: 从Authorization头中提取（Bearer Token）
        auth_header = request.headers.get(self.auth_header_name)
        if auth_header:
            # 处理 "Bearer <token>" 格式
            if auth_header.startswith(f"{self.token_prefix} "):
                token = auth_header[len(f"{self.token_prefix} "):].strip()
                if token:
                    logger.debug(f"从{self.auth_header_name}头提取到令牌")
                    return token
            # 处理直接令牌格式
            elif not self.token_prefix or auth_header == self.token_prefix:
                token = auth_header.strip()
                if token:
                    logger.debug(f"从{self.auth_header_name}头提取到令牌（无前缀）")
                    return token

        # 方法2: 从查询参数中提取
        if "token" in request.query_params:
            token = request.query_params["token"]
            if token:
                logger.debug(f"从查询参数提取到令牌")
                return token

        # 方法3: 从Cookie中提取
        if "access_token" in request.cookies:
            token = request.cookies["access_token"]
            if token:
                logger.debug(f"从Cookie中提取到令牌")
                return token

        # 方法4: 从自定义头中提取
        if "X-Access-Token" in request.headers:
            token = request.headers["X-Access-Token"]
            if token:
                logger.debug(f"从X-Access-Token头提取到令牌")
                return token

        logger.debug("未找到JWT令牌")
        return None

    def _should_skip_jwt(self, request: Request) -> bool:
        """
        检查是否应该跳过JWT认证

        Args:
            request: HTTP请求对象

        Returns:
            bool: 是否应该跳过JWT认证
        """
        current_path = request.url.path

        # 检查配置的跳过路径
        for skip_path in self.skip_paths:
            if self._match_url(skip_path, current_path, request.method):
                return True

        # 检查默认跳过的路径（如健康检查、API文档等）
        default_skip_paths = [
            "/health",
            "/metrics",
            "/status",
            "/docs",
            "/redoc",
            "/openapi.json",
            "/favicon.ico",
            "/robots.txt",
        ]

        for skip_path in default_skip_paths:
            if current_path == skip_path or current_path.startswith(skip_path):
                return True

        return False

    async def _verify_jwt_token(self, request: Request) -> Optional[Dict[str, Any]]:
        """
        验证JWT令牌

        Args:
            request: HTTP请求对象

        Returns:
            Optional[Dict[str, Any]]: 用户信息，验证失败则返回None
        """
        try:
            # 提取令牌
            token = self._get_token(request)
            if not token:
                logger.debug("未找到JWT令牌")
                return None

            # 获取JWT管理器
            try:
                jwt_manager = get_jwt_manager()
            except JWTNotInitializedError as e:
                logger.error(f"JWT管理器未初始化: {e.message}")
                return None
            except Exception as e:
                logger.error(f"获取JWT管理器失败: {e}")
                return None

            # 验证令牌
            try:
                user_data = jwt_manager.verify_token(token, "access")
                logger.debug(f"JWT令牌验证成功: {user_data}")
                return user_data
            except TokenExpiredError as e:
                logger.warning(f"JWT令牌已过期: {e.message}")
                return None
            except InvalidTokenError as e:
                logger.warning(f"JWT令牌无效: {e.message}")
                return None
            except InvalidTokenTypeError as e:
                logger.warning(f"JWT令牌类型错误: {e.message}")
                return None
            except JWTError as e:
                logger.warning(f"JWT验证失败: {e.message}")
                return None
            except Exception as e:
                logger.error(f"JWT验证过程中发生未知错误: {e}")
                return None

        except Exception as e:
            logger.error(f"JWT验证过程异常: {e}")
            return None

    def _create_unauthorized_response(self, request: Request) -> JSONResponse:
        """
        创建未授权响应

        Args:
            request: HTTP请求对象

        Returns:
            JSONResponse: 401未授权响应
        """
        error_data = {
            "path": request.url.path,
            "method": request.method,
            "timestamp": self._get_current_timestamp(),
        }

        # 使用R类的fail_with_detail方法创建规范的响应
        response_data = R.fail_with_detail(
            code=HTTPStatus.UNAUTHORIZED.value,
            msg="未授权访问",
            data=error_data
        )

        return JSONResponse(
            status_code=HTTPStatus.UNAUTHORIZED,
            content=response_data.model_dump()
        )

    def _get_current_timestamp(self) -> int:
        """
        获取当前时间戳

        Returns:
            str: ISO格式的时间戳
        """
        import time
        return int(time.time())

    def set_user_to_request(self, request: Request, user_data: Dict[str, Any]):
        """
        将用户信息设置到请求中，供后续使用

        Args:
            request: HTTP请求对象
            user_data: 用户信息
        """
        if hasattr(request, 'state'):
            request.state.user = user_data
            request.state.user_id = user_data.get('user_id')
            request.state.username = user_data.get('username')
            request.state.roles = user_data.get('roles', [])


def get_white_url_list(request: Request) -> List[str]:
    """
    获取白名单URL列表

    Args:
        request: HTTP请求对象

    Returns:
        List[str]: 白名单URL列表
    """
    try:
        # 尝试从应用状态中获取安全配置
        if hasattr(request.app.state, 'config') and hasattr(request.app.state.config, 'security'):
            white_urls = request.app.state.config.security.whiteUrls
            if white_urls:
                logger.debug(f"从配置中获取到白名单URL: {white_urls}")
                return white_urls

        # 如果没有配置，返回默认白名单
        default_whitelist = get_default_whitelist()
        logger.debug(f"使用默认白名单URL: {default_whitelist}")
        return default_whitelist

    except Exception as e:
        logger.error(f"获取白名单URL失败: {e}")
        # 返回空列表，更安全
        return []


def get_default_whitelist() -> List[str]:
    """
    获取默认白名单URL列表

    Returns:
        List[str]: 默认白名单URL列表
    """
    return [
        # 健康检查
        "/health",
        "GET:/health",

        # API文档
        "/docs",
        "GET:/docs",
        "/redoc",
        "GET:/redoc",
        "/openapi.json",
        "GET:/openapi.json",

        # 根路径
        "/",
        "GET:/",

        # 静态资源（如果有的话）
        "/static/*",

        # 认证相关
        "POST:/api/auth/login",
        "POST:/api/auth/register",
        "POST:/api/auth/refresh",
    ]

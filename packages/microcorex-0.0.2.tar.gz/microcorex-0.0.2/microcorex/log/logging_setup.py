"""Logging Configuration Module (Loguru Version)

Provides unified logging configuration and output.
"""

import logging
import sys
import re
from loguru import logger


def sanitize_message(record):
    """脱敏日志消息中的敏感信息"""
    message = record["message"]

    # 定义需要脱敏的字段模式（不区分大小写）
    patterns = [
        (r'(password["\']?\s*[:=]\s*["\']?)([^"\'}\s]+)', r"\1***REDACTED***"),
        (r'(token["\']?\s*[:=]\s*["\']?)([^"\'}\s]+)', r"\1***REDACTED***"),
        (r'(secret["\']?\s*[:=]\s*["\']?)([^"\'}\s]+)', r"\1***REDACTED***"),
        (r'(key["\']?\s*[:=]\s*["\']?)([^"\'}\s]+)', r"\1***REDACTED***"),
        (r'(api[_-]?key["\']?\s*[:=]\s*["\']?)([^"\'}\s]+)', r"\1***REDACTED***"),
        (r'(access[_-]?key["\']?\s*[:=]\s*["\']?)([^"\'}\s]+)', r"\1***REDACTED***"),
        (r'(secret[_-]?key["\']?\s*[:=]\s*["\']?)([^"\'}\s]+)', r"\1***REDACTED***"),
    ]

    for pattern, replacement in patterns:
        message = re.sub(pattern, replacement, message, flags=re.IGNORECASE)

    record["message"] = message
    return True


def suppress_verbose_debug_logs(record):
    """
    抑制过于频繁的DEBUG日志输出

    主要抑制：
    1. gRPC底层的循环加载日志
    2. Nacos客户端的频繁DEBUG信息
    """
    # 如果不是DEBUG级别，直接通过
    if record["level"].name != "DEBUG":
        return True

    message = record["message"]
    module = record.get("module", "")

    # 抑制gRPC底层循环相关日志
    grpc_patterns = [
        r'\[_cygrpc\] Loaded running loop',
        r'\[_cygrpc\] .* loop',
        r'grpc.*loop.*',
    ]

    # 检查是否匹配需要抑制的模式
    all_patterns = grpc_patterns

    for pattern in all_patterns:
        if re.search(pattern, message, re.IGNORECASE):
            return False  # 抑制这条日志

    return True  # 允许输出这条日志


class InterceptHandler(logging.Handler):
    """Redirects Python standard logging to Loguru"""

    def emit(self, record: logging.LogRecord):
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno
        # Locate original call position
        frame, depth = logging.currentframe(), 2
        while frame and frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back  # type: ignore
            depth += 1
        logger.opt(depth=depth, exception=record.exc_info).log(
            level, record.getMessage()
        )


def setup_logging(log_level: str = "DEBUG", log_file: str = "logs/app.log") -> None:
    """
    Configure Loguru logging system

    Args:
        log_file: Log file path, defaults to 'app.log'
        log_level: Log level
    """
    # Remove Loguru default handler
    logger.remove()

    # Define log output format
    log_format = (
        "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
        "<level>{level: <8}</level> | "
        "<cyan>{module}</cyan>.<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
        "<level>{message}</level>"
    )

    # Output to console (添加脱敏过滤器 + DEBUG日志抑制过滤器)
    def combined_filter(record):
        """组合过滤器：先脱敏，再抑制过频繁的DEBUG日志"""
        # 先应用脱敏
        if not sanitize_message(record):
            return False
        # 再应用DEBUG日志抑制
        return suppress_verbose_debug_logs(record)

    logger.add(
        sys.stdout,
        format=log_format,
        level="DEBUG",
        filter=combined_filter,  # 添加组合过滤器
    )

    # Output to log file (daily rotation + compression + 脱敏)
    logger.add(
        log_file,
        format=log_format,
        level=log_level,
        rotation="00:00",  # Daily rotation at midnight
        retention="7 days",  # Keep for 7 days
        compression="zip",  # Compress old logs
        encoding="utf-8",
        enqueue=True,  # Async write to prevent I/O blocking
        filter=combined_filter,  # 添加组合过滤器
    )

    # Take over standard library logging
    logging.basicConfig(handlers=[InterceptHandler()], level=0, force=True)

    # Take over Uvicorn / FastAPI internal logging
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access", "fastapi"):
        lib_logger = logging.getLogger(name)
        lib_logger.handlers = [InterceptHandler()]
        lib_logger.propagate = False


def get_logger(name: str = None):
    """
    Get Loguru logger

    Args:
        name: Module name or logger name (optional)

    Returns:
        logger: Loguru logger object
    """
    if name:
        return logger.bind(module=name)
    return logger

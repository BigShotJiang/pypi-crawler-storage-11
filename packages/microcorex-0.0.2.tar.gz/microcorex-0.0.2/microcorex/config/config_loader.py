"""
Configuration Loader

Supports multi-layer configuration loading and merging with priority mechanism.
Priority: Environment Variables > Nacos Configuration Center > Local YAML Files
"""

import os
import asyncio
import weakref
import yaml
from pathlib import Path
from typing import Optional, Callable, List, Type, TypeVar
import __main__

from microcorex.config.config import MicroCoreConfig
from microcorex.nacos.nacos_config_manager import NacosConfigManager
from microcorex.utils.utils import get_local_ip
from microcorex.log.logging_setup import get_logger
from microcorex.error.error_handling import ErrorHandler, ErrorLevel, ConfigError

logger = get_logger(__name__)

# Define a type variable that must be MicroCoreConfig or its subclass
T = TypeVar("T", bound=MicroCoreConfig)


class ConfigLoadError(Exception):
    """Configuration loading exception"""

    pass


class PathSecurityValidator:
    """
    Path Security Validator for preventing path traversal attacks

    This class provides secure path validation and normalization methods
    to prevent directory traversal vulnerabilities.
    """

    @staticmethod
    def normalize_path(path: Path) -> Path:
        """
        Normalize a path and resolve all symbolic links and relative components

        Args:
            path: The path to normalize

        Returns:
            Normalized absolute path
        """
        try:
            # Convert to absolute path and resolve all symlinks and relative components
            normalized = path.resolve(strict=False)
            return normalized
        except (OSError, RuntimeError) as e:
            logger.warning(f"Path normalization failed for {path}: {e}")
            # Fallback to absolute path
            return path.absolute()

    @staticmethod
    def is_safe_path(path: Path, allowed_base_dirs: List[Path] = None) -> bool:
        """
        Check if a path is safe (doesn't traverse outside allowed directories)

        Args:
            path: The path to check
            allowed_base_dirs: List of allowed base directories

        Returns:
            True if path is safe, False otherwise
        """
        if allowed_base_dirs is None:
            # If no specific allowed dirs provided, use current working directory
            allowed_base_dirs = [Path.cwd()]

        try:
            # Normalize the path
            normalized_path = PathSecurityValidator.normalize_path(path)

            # Check each allowed base directory
            for base_dir in allowed_base_dirs:
                # Normalize base directory
                normalized_base = PathSecurityValidator.normalize_path(base_dir)

                try:
                    # Check if normalized path is within or equal to the base directory
                    relative_path = normalized_path.relative_to(normalized_base)
                    # Additional check: ensure relative path doesn't start with '.'
                    if not any(part.startswith("..") for part in relative_path.parts):
                        return True
                except ValueError:
                    # Path is not relative to this base directory
                    continue

            return False

        except Exception as e:
            logger.error(f"Path safety check failed for {path}: {e}")
            return False

    @staticmethod
    def validate_config_path(config_path: Path, service_root: Path = None) -> Path:
        """
        Validate configuration file path with security checks

        Args:
            config_path: The configuration file path to validate
            service_root: Service root directory (optional)

        Returns:
            Validated normalized path

        Raises:
            ConfigLoadError: If path is invalid or unsafe
        """
        if service_root is None:
            service_root = Path.cwd()

        # Normalize the config path
        normalized_path = PathSecurityValidator.normalize_path(config_path)

        # Define allowed directories for config files
        allowed_dirs = [
            service_root / "config",
            service_root,
            Path.cwd(),
            Path.cwd() / "config",
        ]

        # Security check: ensure path is within allowed directories
        if not PathSecurityValidator.is_safe_path(normalized_path, allowed_dirs):
            raise ConfigLoadError(
                f"Unsafe configuration path: {config_path}. "
                f"Path must be within allowed directories: {[str(d) for d in allowed_dirs]}"
            )

        # Additional validation: ensure it's a YAML file
        if normalized_path.suffix.lower() not in [".yaml", ".yml"]:
            raise ConfigLoadError(
                f"Configuration file must be a YAML file: {normalized_path}"
            )

        return normalized_path


class ConfigLoader:
    """
    Configuration Loader

    Supports multi-layer configuration loading and merging:
    1. Load local YAML file (base configuration)
    2. Pull configuration from Nacos Configuration Center (overrides local config)
    3. Read environment variables (final override)

    Supports configuration hot reloading and change monitoring.
    """

    def __init__(self, config_class: Type[T] = MicroCoreConfig):
        """
        Initialize configuration loader

        Args:
            config_class: Pydantic model class for parsing configuration, defaults to MicroCoreConfig
        """
        self.config_model: Type[T] = config_class
        self.config: Optional[T] = None
        self.nacos_config_manager: Optional[NacosConfigManager] = None

        # Configuration change listeners with weak reference tracking to prevent memory leaks
        self.config_change_listeners: List[Callable] = []
        self._listener_weak_refs: List[weakref.ref] = []  # Weak references to listeners
        self._listener_cleanup_task: Optional[asyncio.Task] = (
            None  # Periodic cleanup task
        )

        self.error_handler = ErrorHandler("ConfigLoader", enable_stack_traces=False)

    async def load_config(self) -> T:
        """
        Load configuration (by priority)

        Returns:
            Loaded configuration object
        """
        try:
            # 1. Load local YAML configuration
            logger.info("📄 Loading local YAML configuration...")
            config = self._load_yaml_config()

            # 2. Pull and merge configuration from Nacos
            if config.nacos.host:
                logger.info(
                    "☁️  Pulling configuration from Nacos Configuration Center..."
                )
                nacos_config_dict = await self._load_nacos_config(config)
                if nacos_config_dict:
                    config = self._merge_config(config, nacos_config_dict)
                    logger.info("✅ Nacos configuration merged successfully")

            # 3. Environment variable overrides
            logger.info("🔧 Applying environment variable overrides...")
            config = self._apply_env_overrides(config)

            # 4. Post-processing
            config = self._post_process_config(config)

            self.config = config
            logger.info("✅ Configuration loading completed")
            return config

        except Exception as e:
            self.error_handler.log_error(
                e, context={"operation": "config_loading"}, level=ErrorLevel.ERROR
            )
            raise ConfigError(
                f"Configuration loading failed: {self.error_handler.create_user_message(e)}"
            )

    def _load_yaml_config(self) -> T:
        """
        Load local YAML configuration file with security validation

        Returns:
            Configuration object

        Raises:
            ConfigLoadError: If configuration loading fails or path is unsafe
        """
        env = os.getenv("APP_ENV", "dev").lower()

        # Determine service root securely
        service_root = self._get_secure_service_root()

        # Construct configuration file path
        config_path = service_root / "config" / f"config_{env}.yaml"

        # Security validation: validate and normalize the path
        try:
            validated_config_path = PathSecurityValidator.validate_config_path(
                config_path, service_root
            )
            logger.debug(f"Configuration path validated: {validated_config_path}")
        except ConfigLoadError as e:
            raise ConfigLoadError(f"Configuration path validation failed: {e}")

        # Additional security check: ensure file exists and is a regular file
        if not validated_config_path.is_file():
            raise ConfigLoadError(
                f"Configuration file does not exist or is not a regular file: {validated_config_path}"
            )

        # Check file permissions (should be readable by owner)
        try:
            file_stat = validated_config_path.stat()
            if not (file_stat.st_mode & 0o400):  # Owner read permission
                raise ConfigLoadError(
                    f"Configuration file is not readable: {validated_config_path}"
                )
        except OSError as e:
            raise ConfigLoadError(
                f"Cannot access configuration file: {validated_config_path}, error: {e}"
            )

        # Load and parse the configuration
        try:
            with open(validated_config_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)

            if not isinstance(data, dict):
                raise ConfigLoadError(
                    f"Configuration file must contain a dictionary: {validated_config_path}"
                )

        except yaml.YAMLError as e:
            raise ConfigLoadError(f"Failed to parse YAML configuration: {e}")
        except UnicodeDecodeError as e:
            raise ConfigLoadError(f"Configuration file encoding error: {e}")
        except PermissionError as e:
            raise ConfigLoadError(
                f"Permission denied accessing configuration file: {e}"
            )
        except OSError as e:
            raise ConfigLoadError(f"System error accessing configuration file: {e}")

        # Parse configuration using Pydantic model
        try:
            config = self.config_model(**data)
        except Exception as e:
            raise ConfigLoadError(f"Configuration validation failed: {e}")

        logger.info(
            f"✅ Local configuration loaded successfully: {validated_config_path}"
        )
        return config

    def _get_secure_service_root(self) -> Path:
        """
        Securely determine the service root directory

        Returns:
            Path to service root directory

        Raises:
            ConfigLoadError: If service root cannot be determined securely
        """
        try:
            # Try to get the main module path
            if hasattr(__main__, "__file__") and __main__.__file__:
                main_path = Path(os.path.abspath(__main__.__file__))
                service_root = main_path.parent
            else:
                # Fallback to current working directory
                service_root = Path.cwd()
                logger.warning(
                    "Using current working directory as service root (main.__file__ not available)"
                )

            # Validate service root
            if not service_root.exists():
                raise ConfigLoadError(
                    f"Service root directory does not exist: {service_root}"
                )

            if not service_root.is_dir():
                raise ConfigLoadError(
                    f"Service root is not a directory: {service_root}"
                )

            # Normalize the service root path
            service_root = PathSecurityValidator.normalize_path(service_root)

            logger.debug(f"Service root determined securely: {service_root}")
            return service_root

        except Exception as e:
            raise ConfigLoadError(f"Failed to determine service root directory: {e}")

    async def _load_nacos_config(self, base_config: T) -> Optional[dict]:
        """
        Pull configuration from Nacos Configuration Center

        Args:
            base_config: Base configuration (for connecting to Nacos)

        Returns:
            Nacos configuration dictionary, returns None on failure
        """
        # Initialize variables for exception handling
        data_id = None
        group = None

        try:
            # Initialize Nacos Configuration Manager
            from v2.nacos import ClientConfigBuilder

            client_config = (
                ClientConfigBuilder()
                .username(base_config.nacos.username)
                .password(base_config.nacos.password)
                .server_address(f"{base_config.nacos.host}:{base_config.nacos.port}")
                .namespace_id(
                    base_config.nacos.namespace
                    if base_config.nacos.namespace
                    else "public"
                )
                .log_level("INFO")
                .build()
            )

            self.nacos_config_manager = NacosConfigManager(client_config)
            success = await self.nacos_config_manager.initialize()
            if not success:
                logger.warning("Using local configuration")
                return None

            # Pull configuration (using service name as data_id)
            data_id = base_config.app.name
            group = base_config.nacos.groupName

            content = await self.nacos_config_manager.get_config(
                data_id=data_id, group=group
            )

            if content:
                # Parse YAML configuration
                nacos_config = yaml.safe_load(content)
                logger.info(
                    f"Nacos configuration pulled successfully: data_id={data_id}, group={group}"
                )
                return nacos_config
            else:
                logger.warning(
                    f"Nacos configuration does not exist: data_id={data_id}, group={group}"
                )
                return None

        except Exception as e:
            self.error_handler.log_error(
                e,
                context={
                    "operation": "nacos_config_pull",
                    "data_id": data_id or "unknown",
                    "group": group or "unknown",
                },
                level=ErrorLevel.WARNING,
            )
            return None

    def _merge_config(self, base: T, override: dict) -> T:
        """
        Merge configuration (deep merge)

        Args:
            base: Base configuration object
            override: Override configuration dictionary

        Returns:
            Merged configuration object
        """
        # Convert base configuration to dictionary
        base_dict = base.model_dump()

        # Deep merge
        merged_dict = self._deep_merge(base_dict, override)

        # Convert back to configuration object
        return self.config_model(**merged_dict)

    def _deep_merge(self, base: dict, override: dict) -> dict:
        """
        Deep merge dictionaries

        Args:
            base: Base dictionary
            override: Override dictionary

        Returns:
            Merged dictionary
        """
        result = base.copy()

        for key, value in override.items():
            if (
                key in result
                and isinstance(result[key], dict)
                and isinstance(value, dict)
            ):
                # Recursively merge nested dictionaries
                result[key] = self._deep_merge(result[key], value)
            else:
                # Direct override
                result[key] = value

        return result

    def _apply_env_overrides(self, config: T) -> T:
        """
        Apply environment variable overrides

        Supported environment variables:
        - APP_NAME, APP_ENV, APP_LOG_LEVEL
        - SERVICE_PORT, GRPC_PORT, SERVER_IP
        - NACOS_HOST, NACOS_PORT, NACOS_NAMESPACE, NACOS_USERNAME, NACOS_PASSWORD
        - DATABASE_URL

        Args:
            config: Configuration object

        Returns:
            Configuration object with environment variables applied
        """
        # App configuration
        if os.getenv("APP_NAME"):
            config.app.name = os.getenv("APP_NAME")
        if os.getenv("APP_ENV"):
            config.app.env = os.getenv("APP_ENV")
        if os.getenv("APP_LOG_LEVEL"):
            config.app.logLevel = os.getenv("APP_LOG_LEVEL")

        # Server configuration
        if os.getenv("SERVER_IP"):
            config.server.ip = os.getenv("SERVER_IP")
        if os.getenv("SERVICE_PORT"):
            config.server.servicePort = int(os.getenv("SERVICE_PORT"))
        if os.getenv("GRPC_PORT"):
            config.server.grpcPort = int(os.getenv("GRPC_PORT"))

        # Nacos configuration
        if os.getenv("NACOS_HOST"):
            config.nacos.host = os.getenv("NACOS_HOST")
        if os.getenv("NACOS_PORT"):
            config.nacos.port = int(os.getenv("NACOS_PORT"))
        if os.getenv("NACOS_NAMESPACE"):
            config.nacos.namespace = os.getenv("NACOS_NAMESPACE")
        if os.getenv("NACOS_USERNAME"):
            config.nacos.username = os.getenv("NACOS_USERNAME")
        if os.getenv("NACOS_PASSWORD"):
            config.nacos.password = os.getenv("NACOS_PASSWORD")

        # Database configuration
        if os.getenv("DATABASE_URL"):
            config.database.url = os.getenv("DATABASE_URL")

        return config

    def _post_process_config(self, config: T) -> T:
        """
        Configuration post-processing

        Args:
            config: Configuration object

        Returns:
            Processed configuration object
        """
        # Automatically get local IP
        if not config.server.ip:
            config.server.ip = get_local_ip()
            logger.info(f"Automatically obtained local IP: {config.server.ip}")

        return config

    async def start_watch(self, strategy: str = "polling", polling_interval: int = 10):
        """
        Start configuration monitoring (hot reload)

        Monitors Nacos configuration changes, automatically reloads configuration and notifies listeners.
        
        Args:
            strategy: 监听策略, "listener" (官方监听器) 或 "polling" (轮询), 默认 "polling"
            polling_interval: 轮询间隔(秒), 仅当 strategy="polling" 时生效, 默认 10 秒
        
        Note:
            由于 Nacos Python SDK v2 的 add_listener 存在已知 Bug (监听器不触发),
            默认使用 "polling" 策略。待官方修复后,可切换为 "listener" 策略。
        """
        if not self.nacos_config_manager or not self.config:
            logger.warning(
                "Nacos configuration manager not initialized, cannot start configuration monitoring"
            )
            return

        try:
            data_id = self.config.app.name
            group = self.config.nacos.groupName

            if strategy == "listener":
                # 使用官方监听器 (待官方修复 Bug 后使用)
                await self.nacos_config_manager.add_listener(
                    data_id=data_id, group=group, listener=self._on_config_change
                )
                logger.info(
                    f"✅ Configuration monitoring started (strategy: listener): data_id={data_id}, group={group}"
                )
            else:
                # 使用轮询策略 (默认,更可靠)
                await self.nacos_config_manager.start_polling_listener(
                    data_id=data_id,
                    group=group,
                    listener=self._on_config_change,
                    interval=polling_interval,
                )
                logger.info(
                    f"✅ Configuration monitoring started (strategy: polling, interval: {polling_interval}s): data_id={data_id}, group={group}"
                )

        except Exception as e:
            logger.error(f"Failed to start configuration monitoring: {e}")

    async def _on_config_change(
        self, tenant: str, data_id: str, group: str, content: str
    ):
        """
        Configuration change callback

        Args:
            tenant: Tenant ID
            data_id: Configuration ID
            group: Configuration group
            content: New configuration content
        """
        logger.info(
            f"🔄 Configuration change detected: data_id={data_id}, group={group}"
        )

        try:
            # Reload configuration
            new_config = await self.load_config()

            # Notify all listeners
            for listener in self.config_change_listeners:
                try:
                    await listener(new_config)
                except Exception as e:
                    logger.error(f"Configuration change listener execution failed: {e}")

            logger.info("✅ Configuration hot reload completed")

        except Exception as e:
            logger.error(f"Configuration hot reload failed: {e}")

    def add_config_change_listener(self, listener: Callable):
        """
        Add configuration change listener with weak reference tracking to prevent memory leaks

        Args:
            listener: Listener function (new_config) -> None
        """
        # Add the listener to the main list
        self.config_change_listeners.append(listener)

        # Create a weak reference to track if the listener is still alive
        def listener_callback(ref):
            """Callback when listener is garbage collected"""
            self._cleanup_dead_listener(ref)

        weak_ref = weakref.ref(listener, listener_callback)
        self._listener_weak_refs.append(weak_ref)

        # Start periodic cleanup task if not already running
        if self._listener_cleanup_task is None:
            self._listener_cleanup_task = asyncio.create_task(
                self._periodic_listener_cleanup()
            )

    def remove_config_change_listener(self, listener: Callable):
        """
        Remove configuration change listener

        Args:
            listener: Listener function to remove
        """
        try:
            if listener in self.config_change_listeners:
                self.config_change_listeners.remove(listener)

            # Remove associated weak reference
            self._listener_weak_refs = [
                ref for ref in self._listener_weak_refs if ref() is not listener
            ]

            logger.info("Configuration change listener removed successfully")
        except Exception as e:
            logger.error(f"Failed to remove configuration change listener: {e}")

    def _cleanup_dead_listener(self, dead_ref: weakref.ref):
        """
        Clean up dead listener references

        Args:
            dead_ref: The dead weak reference to clean up
        """
        try:
            if dead_ref in self._listener_weak_refs:
                self._listener_weak_refs.remove(dead_ref)

            # Also remove any corresponding dead listeners from the main list
            self.config_change_listeners = [
                listener
                for listener in self.config_change_listeners
                if weakref.ref(listener)() is not None
            ]

            logger.debug("Dead listener reference cleaned up")
        except Exception as e:
            logger.error(f"Failed to cleanup dead listener: {e}")

    async def _periodic_listener_cleanup(self):
        """
        Periodically clean up dead listener references to prevent memory leaks
        """
        while True:
            try:
                # Sleep for 5 minutes between cleanup cycles
                await asyncio.sleep(300)

                # Clean up dead weak references
                dead_refs = [ref for ref in self._listener_weak_refs if ref() is None]
                for dead_ref in dead_refs:
                    self._cleanup_dead_listener(dead_ref)

                # Clean up main list of any dead listeners
                alive_listeners = []
                for listener in self.config_change_listeners:
                    try:
                        # Check if listener is still alive by creating a temporary weak reference
                        temp_ref = weakref.ref(listener)
                        if temp_ref() is not None:
                            alive_listeners.append(listener)
                    except Exception:
                        # Listener is no longer valid, skip it
                        continue

                dead_count = len(self.config_change_listeners) - len(alive_listeners)
                if dead_count > 0:
                    logger.info(f"Cleaned up {dead_count} dead configuration listeners")

                self.config_change_listeners = alive_listeners

            except asyncio.CancelledError:
                logger.debug("Periodic listener cleanup task cancelled")
                break
            except Exception as e:
                logger.error(f"Error in periodic listener cleanup: {e}")

    async def shutdown(self):
        """Shutdown configuration loader and cleanup resources"""
        try:
            # Cancel periodic cleanup task
            if self._listener_cleanup_task and not self._listener_cleanup_task.done():
                self._listener_cleanup_task.cancel()
                try:
                    await self._listener_cleanup_task
                except asyncio.CancelledError:
                    logger.debug("Listener cleanup task cancelled during shutdown")

            # Clear all listeners to prevent memory leaks
            self.config_change_listeners.clear()
            self._listener_weak_refs.clear()

            # Shutdown Nacos configuration manager
            if self.nacos_config_manager:
                await self.nacos_config_manager.shutdown()

            logger.info("Configuration loader shutdown completed successfully")

        except Exception as e:
            logger.error(f"Error during configuration loader shutdown: {e}")

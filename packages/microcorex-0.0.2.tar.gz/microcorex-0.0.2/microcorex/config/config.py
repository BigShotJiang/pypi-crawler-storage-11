import os
from pathlib import Path
from typing import Optional, Dict, Any

from pydantic import Field, BaseModel, ConfigDict

from pydantic_settings import BaseSettings
import yaml
import __main__

from microcorex.utils.utils import get_local_ip


class AppConfig(BaseModel):
    name: str = Field(..., description="Application name")
    env: str = Field(..., description="Runtime environment")
    logLevel: str = Field(default="INFO", description="Log level")

    model_config = ConfigDict(extra="allow")

    def validate_environment(self) -> bool:
        """Validate environment configuration"""
        valid_envs = [
            "dev",
            "development",
            "test",
            "testing",
            "staging",
            "prod",
            "production",
        ]
        if self.env.lower() not in valid_envs:
            raise ValueError(
                f"Invalid environment '{self.env}'. Must be one of: {valid_envs}"
            )
        return True


class ServerConfig(BaseModel):
    ip: str = Field(default="", description="Service IP address")
    servicePort: int = Field(..., description="HTTP service port", ge=1024, le=65535)
    grpcPort: int = Field(..., description="gRPC service port", ge=1024, le=65535)

    model_config = ConfigDict(extra="allow")

    def validate_ports(self) -> bool:
        """Validate port configuration"""
        if self.servicePort == self.grpcPort:
            raise ValueError("HTTP service port and gRPC port cannot be the same")
        return True

    def validate_ip(self) -> bool:
        """Validate IP address configuration"""
        if self.ip and self.ip not in ["", "0.0.0.0", "localhost"]:
            # Additional IP validation could be added here
            import ipaddress

            try:
                ipaddress.ip_address(self.ip)
            except ValueError:
                raise ValueError(f"Invalid IP address: {self.ip}")
        return True


class NacosConfig(BaseModel):
    host: Optional[str] = Field(default=None, description="Nacos server address")
    port: Optional[int] = Field(default=8848, description="Nacos server port")
    groupName: Optional[str] = Field(
        default="DEFAULT_GROUP", description="Nacos service group name"
    )
    heartbeatInterval: Optional[int] = Field(
        default=5, description="Heartbeat interval in seconds"
    )
    namespace: Optional[str] = Field(default="public", description="Nacos namespace")
    username: Optional[str] = Field(default=None, description="Nacos username")
    password: Optional[str] = Field(default=None, description="Nacos password")
    configWatchStrategy: Optional[str] = Field(
        default="polling", description="Config watch strategy: 'listener' or 'polling'"
    )
    pollingInterval: Optional[int] = Field(
        default=10, description="Polling interval in seconds (only for polling strategy)"
    )

    model_config = ConfigDict(extra="allow")

    def validate_credentials(self) -> bool:
        """Validate that credentials are properly configured for production use"""
        if self.host and self.host not in ["localhost", "127.0.0.1"]:
            # For non-local Nacos, require authentication
            if not self.username or not self.password:
                raise ValueError(
                    "Nacos username and password are required when connecting to remote Nacos server"
                )
        return True

    def get_sensitive_masked_dict(self) -> Dict[str, Any]:
        """Get configuration dictionary with sensitive values masked"""
        config_dict = self.model_dump()
        if config_dict.get("password"):
            config_dict["password"] = "***MASKED***"
        return config_dict


class DatabaseConfig(BaseModel):
    url: str

    model_config = ConfigDict(extra="allow")


class SecurityConfig(BaseModel):
    whiteUrls: Optional[list[str]] = Field(
        default=[],
        description="List of URLs that are allowed to access without authentication"
    )
    model_config = ConfigDict(extra="allow")


class JwtConfig(BaseModel):
    """JWT configuration"""
    secretKey: str = Field(
        default="your-super-secret-jwt-key-change-in-production",
        description="JWT secret key"
    )
    algorithm: str = Field(
        default="HS256",
        description="JWT algorithm"
    )
    accessTokenExpireMinutes: int = Field(
        default=30,
        description="Access token expiration time in minutes"
    )
    refreshTokenExpireDays: int = Field(
        default=7,
        description="Refresh token expiration time in days"
    )
    issuer: Optional[str] = Field(
        default=None,
        description="JWT issuer"
    )
    audience: Optional[str] = Field(
        default=None,
        description="JWT audience"
    )

    def validate_secret_key(self) -> bool:
        """Validate JWT secret key for production use"""
        if self.secretKey == "your-super-secret-jwt-key-change-in-production":
            import os

            # Only allow default key in development environment
            env = os.getenv("APP_ENV", "dev").lower()
            if env in ["prod", "production"]:
                raise ValueError(
                    "Default JWT secret key is not allowed in production. "
                    "Please set a secure secret key in configuration or environment variable"
                )
        return True

    def get_safe_config_dict(self) -> Dict[str, Any]:
        """Get configuration dictionary with sensitive values masked"""
        config_dict = self.model_dump()
        if config_dict.get("secretKey"):
            config_dict["secretKey"] = "***MASKED***"
        return config_dict

    model_config = ConfigDict(extra="allow")


class MicroCoreConfig(BaseSettings):
    """Microservice core configuration"""

    # Allow services to add custom configuration fields in config.yaml, microcore will preserve them as-is
    model_config = ConfigDict(extra="allow")

    app: AppConfig = AppConfig(name="service", env="dev")
    server: ServerConfig = ServerConfig(servicePort=8001, grpcPort=8002)
    nacos: NacosConfig = NacosConfig()
    database: DatabaseConfig = DatabaseConfig(url="")
    jwt: JwtConfig = JwtConfig()
    services: Optional[Dict[str, Any]] = Field(
        default_factory=dict, description="Service discovery configuration"
    )
    security: SecurityConfig = SecurityConfig(whiteUrls=[])

    def validate_all(self) -> bool:
        """Validate all configuration sections"""
        # Validate app configuration
        self.app.validate_environment()

        # Validate server configuration
        self.server.validate_ports()
        self.server.validate_ip()

        # Validate Nacos configuration if host is specified
        if self.nacos.host:
            self.nacos.validate_credentials()

        # Validate JWT configuration
        self.jwt.validate_secret_key()

        return True

    def get_safe_config_dict(self) -> Dict[str, Any]:
        """Get configuration dictionary with sensitive values masked"""
        config_dict = self.model_dump()
        if "nacos" in config_dict and config_dict["nacos"].get("password"):
            config_dict["nacos"]["password"] = "***MASKED***"
        if "database" in config_dict and "url" in config_dict["database"]:
            # Mask database URL to hide credentials
            db_url = config_dict["database"]["url"]
            if "://" in db_url and "@" in db_url:
                # Mask credentials in database URL
                parts = db_url.split("://")
                if len(parts) == 2:
                    scheme = parts[0]
                    rest = parts[1]
                    if "@" in rest:
                        cred_part, host_part = rest.split("@", 1)
                        config_dict["database"][
                            "url"
                        ] = f"{scheme}://***MASKED***@{host_part}"
        if "jwt" in config_dict and config_dict["jwt"].get("secretKey"):
            config_dict["jwt"]["secretKey"] = "***MASKED***"
        return config_dict


def load_config():
    """Automatically load config/config_<env>.yaml file from the current service directory"""
    env = os.getenv("APP_ENV", "dev")

    # Get current script path
    main_path = Path(os.path.abspath(__main__.__file__))
    service_root = main_path.parent

    # Build configuration file path
    config_path = service_root / "config" / f"config_{env}.yaml"

    if not config_path.exists():
        raise FileNotFoundError(f"❌ Configuration file not found: {config_path}")

    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    config = MicroCoreConfig(**data)

    # Validate all configuration sections
    config.validate_all()

    service_port = os.getenv("SERVICE_PORT", config.server.servicePort)
    config.server.servicePort = int(service_port)

    if not config.server.ip:
        config.server.ip = get_local_ip()

    return config

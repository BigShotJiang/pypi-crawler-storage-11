"""
Microservice Application Service Manager

Provides unified service startup, registration, and lifecycle management.
Supports concurrent operation of FastAPI and gRPC in the same process.
"""

import asyncio
import signal
from typing import Optional, Type
from datetime import datetime
import uvicorn
from fastapi import FastAPI
from colorama import Fore, Style

from microcorex.config.config import MicroCoreConfig
from microcorex.config.config_loader import ConfigLoader
from microcorex.exception import init_exception
from microcorex.nacos.nacos_registrar import NacosRegistrar
from microcorex.rpc.grpc_server import GrpcServerBase
from microcorex.log.logging_setup import setup_logging, get_logger
from microcorex.jwt.jwt_manager import init_jwt_manager

logger = get_logger(__name__)


class AppService:
    """
    Microservice Application Service Manager

    Provides unified service startup, registration, and lifecycle management.
    Supports concurrent operation of FastAPI and gRPC in the same process.
    """

    def __init__(
            self,
            fastapi_app: FastAPI,
            grpc_server: Optional[GrpcServerBase] = None,
            config: Optional[MicroCoreConfig] = None,
            config_class: Type[
                MicroCoreConfig
            ] = MicroCoreConfig,  # Parameter for injecting custom configuration class
            config_loader: Optional[ConfigLoader] = None,  # 支持传入外部 ConfigLoader 实例
    ):
        """
        Initialize the application service manager

        Args:
            fastapi_app: FastAPI application instance
            grpc_server: gRPC server instance (optional)
            config: Configuration object (optional, auto-loaded if not provided)
            config_class: Pydantic model class for parsing configuration (optional)
            config_loader: ConfigLoader instance (optional, 用于共享配置加载器实例)
        """
        self.fastapi_app = fastapi_app
        self.grpc_server = grpc_server
        self.config = config
        # 优先使用传入的 config_loader, 否则创建新实例
        if config_loader:
            self.config_loader = config_loader
        else:
            self.config_loader = ConfigLoader(config_class=config_class)
        self.nacos_registrar: Optional[NacosRegistrar] = None
        self.jwt_manager = None  # JWT管理器实例
        self._shutdown_event = asyncio.Event()
        self._shutdown_lock = asyncio.Lock()  # 用于保护 shutdown 方法的并发安全
        self._is_shutting_down = False  # shutdown 状态标志
        self._uvicorn_server: Optional[uvicorn.Server] = None

    async def initialize(self):
        """Initialize the service"""
        try:
            # 1. Load configuration
            if not self.config:
                logger.info("📋 Loading configuration...")
                self.config = await self.config_loader.load_config()

            # 2. Setup logging
            setup_logging(self.config.app.logLevel)

            # 3. Save configuration to FastAPI state for use by routes
            if hasattr(self.fastapi_app, "state"):
                # Use model_dump() to ensure all nested models are properly converted to dictionaries
                self.fastapi_app.state.config = self.config

            # 4. Initialize Nacos registrar
            if self.config.nacos.host:
                self.nacos_registrar = NacosRegistrar(self.config)

            # 5. Initialize JWT manager
            logger.info("🔐 Initializing JWT manager...")
            self.jwt_manager = init_jwt_manager(self.config.jwt)

            # Store JWT manager in FastAPI app state for easy access in routes
            if hasattr(self.fastapi_app, "state"):
                self.fastapi_app.state.jwt_manager = self.jwt_manager

            # Initialize global exception catcher
            init_exception(self.fastapi_app)

            logger.info("✅ Service initialization completed")

        except Exception as e:
            logger.error(f"Service initialization failed: {e}")
            raise

    async def _register_with_nacos_with_retry(self) -> bool:
        """
        Register with Nacos using exponential backoff retry mechanism

        Returns:
            bool: True if registration successful, False otherwise
        """
        import asyncio

        max_attempts = 3
        base_delay = 1.0  # seconds
        max_delay = 10.0  # seconds

        for attempt in range(max_attempts):
            try:
                logger.info(
                    f"Attempting Nacos service registration (attempt {attempt + 1}/{max_attempts})"
                )
                await self.nacos_registrar.register_instance()
                logger.info("✅ Nacos service registration successful")
                return True

            except Exception as e:
                if attempt < max_attempts - 1:
                    # Calculate exponential backoff delay with jitter
                    delay = min(base_delay * (2 ** attempt) + (0.1 * attempt), max_delay)
                    logger.warning(
                        f"Nacos service registration attempt {attempt + 1} failed: {e}. "
                        f"Retrying in {delay:.1f} seconds..."
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.error(
                        f"Nacos service registration failed after {max_attempts} attempts: {e}"
                    )

        return False

    async def _on_config_updated(self, new_config: MicroCoreConfig):
        """
        配置变更回调函数
        
        当 Nacos 配置更新时,同步更新 self.config 和 app.state.config
        
        Args:
            new_config: 新的配置对象
        """
        logger.info("🔄 Updating service configuration...")

        # 更新 self.config
        self.config = new_config

        # 同步更新 FastAPI state 中的配置
        if hasattr(self.fastapi_app, "state"):
            self.fastapi_app.state.config = new_config
            logger.info("✅ Service configuration updated successfully")

    async def start(self):
        """Start the service"""
        try:
            # 1. Initialize
            await self.initialize()

            # 2. Register with Nacos
            if self.nacos_registrar:
                registration_success = await self._register_with_nacos_with_retry()
                if not registration_success:
                    logger.warning(
                        "Service registration with Nacos failed, but service will continue running "
                        "in degraded mode. Service discovery functionality may be limited."
                    )

            # 3. Start configuration listening (hot reload)
            if self.config_loader.nacos_config_manager:
                # 从配置中获取监听策略和轮询间隔
                strategy = getattr(self.config.nacos, 'configWatchStrategy', 'polling')
                interval = getattr(self.config.nacos, 'pollingInterval', 10)

                await self.config_loader.start_watch(
                    strategy=strategy,
                    polling_interval=interval
                )
                # 注册配置变更监听器,同步更新 app.state.config
                self.config_loader.add_config_change_listener(self._on_config_updated)

            # 4. Register signal handlers
            self._register_signal_handlers()

            # 5. Print startup success information
            self._print_startup_banner()

            # 6. Start FastAPI + gRPC concurrently
            await self._start_servers()

        except Exception as e:
            logger.error(f"Service startup failed: {e}")
            await self.shutdown()
            raise

    async def _start_servers(self):
        """
        Start FastAPI and gRPC servers concurrently with improved error handling

        This method handles race conditions by properly managing task cancellation
        and ensuring that all server tasks are properly cleaned up.
        """
        tasks = []

        try:
            # Start FastAPI
            fastapi_task = asyncio.create_task(self._run_fastapi())
            tasks.append(fastapi_task)

            # Start gRPC (if configured)
            if self.grpc_server:
                grpc_task = asyncio.create_task(self._run_grpc())
                tasks.append(grpc_task)

            # Wait for shutdown signal
            shutdown_task = asyncio.create_task(self._shutdown_event.wait())
            tasks.append(shutdown_task)

            # Wait for any task to complete (shutdown signal or server failure)
            done, pending = await asyncio.wait(
                tasks, return_when=asyncio.FIRST_COMPLETED
            )

            # Check what caused the completion
            completed_task = next(iter(done))
            if completed_task == shutdown_task:
                logger.info("🛑 Shutdown signal received, stopping servers...")
            else:
                logger.warning(
                    f"⚠️ Server task completed unexpectedly: {completed_task}"
                )

            # Cancel pending tasks with timeout
            if pending:
                logger.info(f"Cancelling {len(pending)} pending tasks...")
                for task in pending:
                    task.cancel()

                # Wait for tasks to be cancelled with timeout
                try:
                    await asyncio.wait_for(
                        asyncio.gather(*pending, return_exceptions=True), timeout=5.0
                    )
                except asyncio.TimeoutError:
                    logger.warning("⚠️ Some tasks did not cancel gracefully")

            # Graceful shutdown
            await self.shutdown()

        except Exception as e:
            logger.error(f"❌ Critical error in _start_servers: {e}")
            # Emergency shutdown
            await self.shutdown()
            raise

    async def _run_fastapi(self):
        """Run FastAPI server"""
        try:
            config = uvicorn.Config(
                self.fastapi_app,
                host="0.0.0.0",
                port=self.config.server.servicePort,
                log_config=None,  # Use custom logging
                loop="asyncio",
            )
            self._uvicorn_server = uvicorn.Server(config)
            await self._uvicorn_server.serve()
        except asyncio.CancelledError:
            logger.info("FastAPI server task cancelled")
        except Exception as e:
            logger.error(f"FastAPI server exception: {e}")
            self._shutdown_event.set()

    async def _run_grpc(self):
        """Run gRPC server"""
        try:
            await self.grpc_server.start()
            await self.grpc_server.wait_for_termination()
        except asyncio.CancelledError:
            logger.info("gRPC server task cancelled")
        except Exception as e:
            logger.error(f"gRPC server exception: {e}")
            self._shutdown_event.set()

    def _register_signal_handlers(self):
        """Register signal handlers using asyncio event loop for thread safety"""
        try:
            # 尝试获取当前运行的事件循环
            # 注意：此方法必须在 async 上下文中调用
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                # 如果没有运行中的事件循环，尝试获取当前线程的事件循环
                loop = asyncio.get_event_loop()
                if loop is None or loop.is_closed():
                    raise RuntimeError("No valid event loop available")

            # Create async-safe signal handlers
            def _async_signal_handler(sig):
                """Async-safe signal handler that schedules shutdown"""
                logger.info(
                    f"Received signal {sig.name} ({sig.value}), starting graceful shutdown..."
                )
                # Schedule shutdown on the event loop
                if not self._shutdown_event.is_set():
                    loop.call_soon_threadsafe(self._shutdown_event.set)

            # Register signal handlers with the event loop
            loop.add_signal_handler(signal.SIGINT, _async_signal_handler, signal.SIGINT)
            loop.add_signal_handler(
                signal.SIGTERM, _async_signal_handler, signal.SIGTERM
            )

            logger.info(
                "✅ Async-safe signal handlers registered for SIGINT and SIGTERM"
            )

        except Exception as e:
            logger.warning(f"Failed to register async signal handlers: {e}")
            # Fallback to traditional signal handling with thread safety
            self._register_fallback_signal_handlers()

    def _register_fallback_signal_handlers(self):
        """Fallback signal handlers with thread safety"""

        def handle_signal(signum, _frame):
            try:
                logger.info(f"Received signal {signum}, starting graceful shutdown...")
                # Use call_soon_threadsafe for thread safety
                loop = asyncio.get_event_loop()
                loop.call_soon_threadsafe(self._shutdown_event.set)
            except Exception as e:
                logger.error(f"Error in fallback signal handler: {e}")
                # Emergency fallback - set the event directly
                self._shutdown_event.set()

        signal.signal(signal.SIGINT, handle_signal)
        signal.signal(signal.SIGTERM, handle_signal)
        logger.warning("⚠️ Using fallback signal handlers (may be less reliable)")

    async def shutdown(self):
        """
        Graceful shutdown with race condition protection

        This method is designed to be safe to call multiple times and from
        different contexts (signal handlers, exception handlers, etc.)

        使用 asyncio.Lock 保证并发安全，防止多个协程同时调用 shutdown
        """
        # 使用锁保证原子性，防止竞态条件
        async with self._shutdown_lock:
            # 检查是否已经在停机中
            if self._is_shutting_down:
                logger.debug("Shutdown already in progress, skipping duplicate call")
                return

            # 设置停机标志
            self._is_shutting_down = True
            logger.info("🛑 Starting graceful service shutdown...")

            try:
                # 1. Deregister from Nacos (with timeout)
                if self.nacos_registrar:
                    try:
                        await asyncio.wait_for(
                            self.nacos_registrar.deregister_instance(), timeout=5.0
                        )
                        logger.info("✅ Deregistered from Nacos")
                    except asyncio.TimeoutError:
                        logger.warning("⚠️ Nacos deregistration timeout")
                    except Exception as e:
                        logger.error(f"❌ Nacos deregistration failed: {e}")

                # 2. Stop gRPC server (with timeout)
                if self.grpc_server:
                    try:
                        await asyncio.wait_for(
                            self.grpc_server.stop(grace_period=10), timeout=15.0
                        )
                        logger.info("✅ gRPC server stopped")
                    except asyncio.TimeoutError:
                        logger.warning("⚠️ gRPC server stop timeout")
                    except Exception as e:
                        logger.error(f"❌ gRPC server stop failed: {e}")

                # 3. Stop FastAPI server (with timeout)
                if self._uvicorn_server:
                    try:
                        self._uvicorn_server.should_exit = True
                        # Give uvicorn time to shutdown gracefully
                        await asyncio.wait_for(
                            self._uvicorn_server.shutdown(), timeout=10.0
                        )
                        logger.info("✅ FastAPI server stopped")
                    except asyncio.TimeoutError:
                        logger.warning("⚠️ FastAPI server stop timeout")
                    except Exception as e:
                        logger.error(f"❌ FastAPI server stop failed: {e}")

                # 4. Close configuration loader (with timeout)
                if self.config_loader:
                    try:
                        await asyncio.wait_for(
                            self.config_loader.shutdown(), timeout=5.0
                        )
                        logger.info("✅ Configuration loader closed")
                    except asyncio.TimeoutError:
                        logger.warning("⚠️ Configuration loader shutdown timeout")
                    except Exception as e:
                        logger.error(f"❌ Configuration loader shutdown failed: {e}")

                # 5. Close gRPC client connections
                try:
                    from microcorex.rpc.base_grpc_client import BaseGrpcClient

                    BaseGrpcClient.close_all()
                    logger.info("✅ gRPC client connections closed")
                except Exception as e:
                    logger.error(f"❌ Failed to close gRPC client connections: {e}")

                logger.info("✅ Service shutdown completed successfully")

            except Exception as e:
                logger.error(f"❌ Critical error during service shutdown: {e}")
                raise
            finally:
                # Ensure shutdown flag is set even if errors occur
                self._shutdown_event.set()

    def _print_startup_banner(self):
        """Print startup success banner"""
        start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        print(Fore.GREEN + "─────────────────────────────────────────────")
        print(Fore.CYAN + f"🚀 {self.config.app.name} Started Successfully!")
        print(Fore.YELLOW + "─────────────────────────────────────────────")
        print(f"🧩 Environment: {self.config.app.env}")
        print(
            f"🌐 HTTP Service: {self.config.server.ip}:{self.config.server.servicePort}"
        )
        print(
            f"📚 API Docs: http://{self.config.server.ip}:{self.config.server.servicePort}/docs"
        )

        if self.grpc_server:
            print(
                f"⚡ gRPC Service: {self.config.server.ip}:{self.config.server.grpcPort}"
            )

        if self.config.nacos.host:
            print(f"📦 Registry: {self.config.nacos.host}:{self.config.nacos.port}")

        print(f"🕒 Start Time: {start_time}")
        print(
            Fore.GREEN
            + "─────────────────────────────────────────────"
            + Style.RESET_ALL
        )

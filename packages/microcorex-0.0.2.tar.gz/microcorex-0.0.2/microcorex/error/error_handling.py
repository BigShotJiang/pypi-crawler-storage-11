"""
Error Handling Module

Provides secure error handling utilities for MicroCoreX framework.
"""

import re
import traceback
from typing import Any, Dict, Optional
from enum import Enum


class ErrorLevel(Enum):
    """Error severity levels"""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class MicroCoreError(Exception):
    """Base exception for MicroCoreX framework"""

    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code or "UNKNOWN_ERROR"
        self.details = details or {}


class ConfigError(MicroCoreError):
    """Configuration related errors"""

    def __init__(self, message: str, config_key: Optional[str] = None, **kwargs):
        super().__init__(message, error_code="CONFIG_ERROR", **kwargs)
        self.config_key = config_key


class ServiceRegistryError(MicroCoreError):
    """Service registry related errors"""

    def __init__(self, message: str, service_name: Optional[str] = None, **kwargs):
        super().__init__(message, error_code="SERVICE_REGISTRY_ERROR", **kwargs)
        self.service_name = service_name


class GrpcError(MicroCoreError):
    """gRPC related errors"""

    def __init__(self, message: str, method: Optional[str] = None, **kwargs):
        super().__init__(message, error_code="GRPC_ERROR", **kwargs)
        self.method = method


class NacosError(MicroCoreError):
    """Nacos related errors"""

    def __init__(self, message: str, nacos_operation: Optional[str] = None, **kwargs):
        super().__init__(message, error_code="NACOS_ERROR", **kwargs)
        self.nacos_operation = nacos_operation


class SecurityError(MicroCoreError):
    """Security related errors"""

    def __init__(self, message: str, **kwargs):
        super().__init__(message, error_code="SECURITY_ERROR", **kwargs)


class ErrorSanitizer:
    """Sanitizes error messages to prevent information disclosure"""

    # Patterns that might reveal sensitive information
    SENSITIVE_PATTERNS = [
        r'password["\']?\s*[:=]\s*["\']?([^"\'>\s]+)',  # Passwords
        r'token["\']?\s*[:=]\s*["\']?([^"\'>\s]+)',  # Tokens
        r'secret["\']?\s*[:=]\s*["\']?([^"\'>\s]+)',  # Secrets
        r'key["\']?\s*[:=]\s*["\']?([^"\'>\s]+)',  # Keys
        r'auth["\']?\s*[:=]\s*["\']?([^"\'>\s]+)',  # Auth credentials
        r'credential["\']?\s*[:=]\s*["\']?([^"\'>\s]+)',  # Credentials
        r"/[^/\s]+/[^/\s]+",  # File paths
        r"\b(?:\d{1,3}\.){3}\d{1,3}\b",  # IP addresses
        r"@\w+\.\w+",  # Email addresses
        r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",  # Better email pattern
    ]

    # Patterns to replace with
    REPLACEMENTS = {
        "password": "***REDACTED***",
        "token": "***REDACTED***",
        "secret": "***REDACTED***",
        "key": "***REDACTED***",
        "auth": "***REDACTED***",
        "credential": "***REDACTED***",
        "file_path": "[REDACTED_PATH]",
        "ip_address": "[REDACTED_IP]",
        "email": "[REDACTED_EMAIL]",
    }

    @classmethod
    def sanitize_error_message(
        cls, message: str, level: ErrorLevel = ErrorLevel.ERROR
    ) -> str:
        """
        Sanitize error message to prevent information disclosure

        Args:
            message: Original error message
            level: Error level (affects sanitization strictness)

        Returns:
            str: Sanitized error message
        """
        if not message:
            return "Unknown error occurred"

        sanitized = message

        # Remove or replace sensitive information
        for pattern in cls.SENSITIVE_PATTERNS:
            matches = re.findall(pattern, sanitized, re.IGNORECASE)
            for match in matches:
                if "password" in pattern.lower():
                    sanitized = re.sub(
                        pattern,
                        "password: ***REDACTED***",
                        sanitized,
                        flags=re.IGNORECASE,
                    )
                elif "token" in pattern.lower():
                    sanitized = re.sub(
                        pattern, "token: ***REDACTED***", sanitized, flags=re.IGNORECASE
                    )
                elif "secret" in pattern.lower():
                    sanitized = re.sub(
                        pattern,
                        "secret: ***REDACTED***",
                        sanitized,
                        flags=re.IGNORECASE,
                    )
                elif "key" in pattern.lower():
                    sanitized = re.sub(
                        pattern, "key: ***REDACTED***", sanitized, flags=re.IGNORECASE
                    )
                elif pattern.startswith(r"/"):
                    sanitized = re.sub(pattern, "[REDACTED_PATH]", sanitized)
                elif pattern.startswith(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"):
                    sanitized = re.sub(pattern, "[REDACTED_IP]", sanitized)
                elif "@" in pattern:
                    sanitized = re.sub(pattern, "[REDACTED_EMAIL]", sanitized)

        # Remove stack traces in production environments
        if level in [ErrorLevel.ERROR, ErrorLevel.CRITICAL]:
            # Keep the first line of the error but remove detailed trace
            lines = sanitized.split("\n")
            if len(lines) > 1:
                sanitized = lines[0] + " [Stack trace hidden for security]"

        # Limit message length to prevent log injection
        max_length = 500
        if len(sanitized) > max_length:
            sanitized = sanitized[:max_length] + "... [truncated]"

        return sanitized

    @classmethod
    def sanitize_exception_data(
        cls, exception: Exception, include_traceback: bool = False
    ) -> Dict[str, Any]:
        """
        Create safe exception data dictionary for logging

        Args:
            exception: Exception object
            include_traceback: Whether to include traceback (only for debugging)

        Returns:
            dict: Safe exception data
        """
        exception_type = type(exception).__name__
        message = str(exception)

        safe_data = {
            "type": exception_type,
            "message": cls.sanitize_error_message(message),
            "error_code": getattr(exception, "error_code", "UNKNOWN_ERROR"),
        }

        # Add specific error details if available
        if hasattr(exception, "details"):
            safe_data["details"] = cls._sanitize_dict(exception.details)

        # Add context information
        if hasattr(exception, "config_key"):
            safe_data["config_key"] = exception.config_key
        if hasattr(exception, "service_name"):
            safe_data["service_name"] = exception.service_name
        if hasattr(exception, "method"):
            safe_data["method"] = exception.method
        if hasattr(exception, "nacos_operation"):
            safe_data["nacos_operation"] = exception.nacos_operation

        # Include traceback only in debug mode
        if include_traceback:
            safe_data["traceback"] = traceback.format_exc()

        return safe_data

    @classmethod
    def _sanitize_dict(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        """Recursively sanitize dictionary values"""
        if not isinstance(data, dict):
            return data

        sanitized = {}
        for key, value in data.items():
            if isinstance(value, dict):
                sanitized[key] = cls._sanitize_dict(value)
            elif isinstance(value, str):
                # Check if key might be sensitive
                if any(
                    sensitive in key.lower()
                    for sensitive in ["password", "token", "secret", "key", "auth"]
                ):
                    sanitized[key] = "***REDACTED***"
                else:
                    sanitized[key] = cls.sanitize_error_message(value)
            else:
                sanitized[key] = value

        return sanitized


class ErrorHandler:
    """Centralized error handling for MicroCoreX"""

    def __init__(self, component_name: str, enable_stack_traces: bool = False):
        self.component_name = component_name
        self.enable_stack_traces = enable_stack_traces

    def handle_exception(
        self,
        exception: Exception,
        context: Optional[Dict[str, Any]] = None,
        level: ErrorLevel = ErrorLevel.ERROR,
    ) -> Dict[str, Any]:
        """
        Handle and sanitize exception for logging

        Args:
            exception: Exception to handle
            context: Additional context information
            level: Error level

        Returns:
            dict: Safe error data for logging
        """
        error_data = ErrorSanitizer.sanitize_exception_data(
            exception, include_traceback=self.enable_stack_traces
        )

        error_data.update(
            {
                "component": self.component_name,
                "level": level.value,
                "context": context or {},
            }
        )

        # Sanitize context
        if error_data["context"]:
            error_data["context"] = ErrorSanitizer._sanitize_dict(error_data["context"])

        return error_data

    def create_user_message(self, exception: Exception) -> str:
        """
        Create user-friendly error message

        Args:
            exception: Exception to create message for

        Returns:
            str: User-friendly error message
        """
        if isinstance(exception, ConfigError):
            return f"Configuration error: {exception.message}. Please check your configuration settings."
        elif isinstance(exception, ServiceRegistryError):
            return (
                f"Service registry error: {exception.message}. Please try again later."
            )
        elif isinstance(exception, GrpcError):
            return f"Communication error: {exception.message}. Please try again later."
        elif isinstance(exception, NacosError):
            return f"Configuration service error: {exception.message}. Please contact support."
        elif isinstance(exception, SecurityError):
            return "Security validation failed. Please check your permissions and credentials."
        else:
            return "An unexpected error occurred. Please try again later or contact support if the problem persists."

    def log_error(
        self,
        exception: Exception,
        context: Optional[Dict[str, Any]] = None,
        logger=None,
        level: ErrorLevel = ErrorLevel.ERROR,
    ):
        """
        Log error with sanitized information

        Args:
            exception: Exception to log
            context: Additional context
            logger: Logger instance (optional)
            level: Error level
        """
        error_data = self.handle_exception(exception, context, level)

        # Import here to avoid circular import
        from microcorex.log.logging_setup import get_logger

        if logger is None:
            logger = get_logger(self.component_name)

        log_message = f"[{error_data['error_code']}] {error_data['message']}"

        if level == ErrorLevel.DEBUG:
            logger.debug(log_message, extra=error_data)
        elif level == ErrorLevel.INFO:
            logger.info(log_message, extra=error_data)
        elif level == ErrorLevel.WARNING:
            logger.warning(log_message, extra=error_data)
        elif level == ErrorLevel.ERROR:
            logger.error(log_message, extra=error_data)
        elif level == ErrorLevel.CRITICAL:
            logger.critical(log_message, extra=error_data)

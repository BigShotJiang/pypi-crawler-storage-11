import json
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import jwt

from microcorex.config.config import JwtConfig


class JWTError(Exception):
    """JWT相关异常的基类"""
    def __init__(self, message: str, error_code: str = "JWT_ERROR"):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)


class InvalidTokenError(JWTError):
    """无效令牌异常"""
    def __init__(self, message: str = "无效的JWT令牌"):
        super().__init__(message, "INVALID_TOKEN")


class TokenExpiredError(JWTError):
    """令牌过期异常"""
    def __init__(self, message: str = "JWT令牌已过期"):
        super().__init__(message, "TOKEN_EXPIRED")


class InvalidTokenTypeError(JWTError):
    """无效令牌类型异常"""
    def __init__(self, expected_type: str, actual_type: str = None):
        if actual_type:
            message = f"无效的令牌类型，期望: {expected_type}，实际: {actual_type}"
        else:
            message = f"无效的令牌类型，期望: {expected_type}"
        super().__init__(message, "INVALID_TOKEN_TYPE")


class JWTNotInitializedError(JWTError):
    """JWT管理器未初始化异常"""
    def __init__(self):
        super().__init__("JWT管理器未初始化。请先调用 init_jwt_manager() 或在 AppService 中初始化。", "JWT_NOT_INITIALIZED")


class JwtManager:
    """
    JWT管理器，提供令牌创建、验证和密码管理功能
    """

    def __init__(self, config: JwtConfig):
        """
        初始化JWT管理器

        Args:
            config: JWT配置对象
        """
        self.config = config
        self._secret_key = config.secretKey
        self._algorithm = config.algorithm
        self._issuer = config.issuer
        self._audience = config.audience

    def create_access_token(
            self,
            sub: dict,
            expires_delta: Optional[timedelta] = None
    ) -> str:
        """
        创建访问令牌

        Args:
            sub: 主题数据（用户信息等）
            expires_delta: 自定义过期时间，默认使用配置中的时间

        Returns:
            str: JWT令牌
        """
        if expires_delta:
            expire = datetime.now(timezone.utc) + expires_delta
        else:
            expire = datetime.now(timezone.utc) + timedelta(
                minutes=self.config.accessTokenExpireMinutes
            )

        payload = {
            "sub": json.dumps(sub),
            "exp": expire,
            "iat": datetime.now(timezone.utc),
            "type": "access"
        }

        # 添加可选的声明
        if self._issuer:
            payload["iss"] = self._issuer
        if self._audience:
            payload["aud"] = self._audience

        encoded_jwt = jwt.encode(
            payload,
            key=self._secret_key,
            algorithm=self._algorithm
        )

        return encoded_jwt

    def create_refresh_token(
            self,
            sub: dict,
            expires_delta: Optional[timedelta] = None
    ) -> str:
        """
        创建刷新令牌

        Args:
            sub: 主题数据（用户信息等）
            expires_delta: 自定义过期时间，默认使用配置中的时间

        Returns:
            str: JWT刷新令牌
        """
        if expires_delta:
            expire = datetime.now(timezone.utc) + expires_delta
        else:
            expire = datetime.now(timezone.utc) + timedelta(
                days=self.config.refreshTokenExpireDays
            )

        payload = {
            "sub": json.dumps(sub),
            "exp": expire,
            "iat": datetime.now(timezone.utc),
            "type": "refresh"
        }

        # 添加可选的声明
        if self._issuer:
            payload["iss"] = self._issuer
        if self._audience:
            payload["aud"] = self._audience

        encoded_jwt = jwt.encode(
            payload,
            key=self._secret_key,
            algorithm=self._algorithm
        )

        return encoded_jwt

    def create_token(
            self,
            sub: dict,
            expires_delta: Optional[timedelta] = None
    ) -> str:
        """
        创建令牌（向后兼容方法）

        Args:
            sub: 主题数据
            expires_delta: 过期时间
            :return: token
        """
        return self.create_access_token(sub, expires_delta)

    def verify_token(self, token: str, token_type: str = "access") -> Any:
        """
        验证令牌

        Args:
            token: JWT令牌
            token_type: 令牌类型 ("access" 或 "refresh")

        Returns:
            Any: 令牌中的主题数据

        Raises:
            InvalidTokenError: 令牌格式无效
            TokenExpiredError: 令牌已过期
            InvalidTokenTypeError: 令牌类型不匹配
        """
        try:
            options = {
                "verify_signature": True,
                "verify_aud": self._audience is not None,  # 只有配置了audience才验证
                "verify_exp": True,
                "verify_iss": self._issuer is not None   # 只有配置了issuer才验证
            }

            decode_data = jwt.decode(
                token,
                key=self._secret_key,
                algorithms=[self._algorithm],
                options=options,
                issuer=self._issuer,
                audience=self._audience
            )

            # 验证令牌类型
            actual_type = decode_data.get("type")
            if actual_type != token_type:
                raise InvalidTokenTypeError(token_type, actual_type)

            # 解析用户数据
            try:
                return json.loads(decode_data["sub"])
            except (json.JSONDecodeError, KeyError) as e:
                raise InvalidTokenError(f"令牌中的用户数据格式无效: {str(e)}")

        except jwt.ExpiredSignatureError:
            raise TokenExpiredError()
        except jwt.DecodeError:
            raise InvalidTokenError("JWT令牌格式无效或签名验证失败")
        except jwt.InvalidIssuerError:
            raise InvalidTokenError("无效的JWT签发者")
        except jwt.InvalidAudienceError:
            raise InvalidTokenError("无效的JWT受众")
        except jwt.InvalidKeyError:
            raise InvalidTokenError("无效的JWT密钥")
        except jwt.InvalidAlgorithmError:
            raise InvalidTokenError("无效的JWT算法")
        except jwt.InvalidTokenError:
            raise InvalidTokenError("JWT令牌无效")
        except InvalidTokenTypeError:
            # 重新抛出我们自己定义的异常
            raise
        except Exception as e:
            # 其他未预期的异常
            raise InvalidTokenError(f"令牌验证过程中发生未知错误: {str(e)}")

    def create_token_pair(self, sub: dict) -> dict:
        """
        创建访问令牌和刷新令牌对

        Args:
            sub: 主题数据

        Returns:
            dict: 包含访问令牌和刷新令牌的字典
        """
        access_token = self.create_access_token(sub)
        refresh_token = self.create_refresh_token(sub)

        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "expires_in": self.config.accessTokenExpireMinutes * 60  # 秒
        }


# 全局JWT管理器实例
_global_jwt_manager: Optional[JwtManager] = None


def init_jwt_manager(config: JwtConfig) -> JwtManager:
    """
    初始化全局JWT管理器

    Args:
        config: JWT配置

    Returns:
        JwtManager: JWT管理器实例
    """
    global _global_jwt_manager
    _global_jwt_manager = JwtManager(config)
    return _global_jwt_manager


def get_jwt_manager() -> JwtManager:
    """
    获取全局JWT管理器

    Returns:
        JwtManager: JWT管理器实例

    Raises:
        JWTNotInitializedError: 如果JWT管理器未初始化
    """
    if _global_jwt_manager is None:
        raise JWTNotInitializedError()
    return _global_jwt_manager

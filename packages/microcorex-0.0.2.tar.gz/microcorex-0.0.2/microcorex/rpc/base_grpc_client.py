"""
Base gRPC Client

Provides base class for gRPC clients, encapsulating common logic for client creation,
enhanced connection management, thread-safe connection pooling, and other utilities.
"""

import threading
import time
from typing import Dict, ClassVar, Optional
from collections import OrderedDict
from loguru import logger

from microcorex.rpc.grpc_client import GrpcClientBase
from microcorex.service.service_registry import ServiceRegistry


class ConnectionPool:
    """
    Enhanced connection pool with LRU eviction, health monitoring, and thread safety

    Features:
        - LRU (Least Recently Used) eviction policy
        - Connection health monitoring
        - Thread-safe operations
        - Automatic cleanup of unhealthy connections
        - Configurable pool size limits
        - Connection reuse optimization
    """

    def __init__(self, max_connections: int = 100, max_idle_time: int = 300):
        """
        Initialize connection pool

        Args:
            max_connections: Maximum number of connections in pool
            max_idle_time: Maximum idle time before eviction (seconds)
        """
        self.max_connections = max_connections
        self.max_idle_time = max_idle_time
        self._connections: OrderedDict[str, Dict] = OrderedDict()
        self._lock = threading.RLock()
        self._cleanup_thread: Optional[threading.Thread] = None
        self._shutdown_event = threading.Event()

        # Start cleanup thread
        self._start_cleanup_thread()

    def _start_cleanup_thread(self):
        """Start background cleanup thread"""
        if self._cleanup_thread is None or not self._cleanup_thread.is_alive():
            self._cleanup_thread = threading.Thread(
                target=self._cleanup_loop, daemon=True
            )
            self._cleanup_thread.start()
            logger.debug("Connection pool cleanup thread started")

    def _cleanup_loop(self):
        """Background cleanup loop for idle and unhealthy connections"""
        while not self._shutdown_event.is_set():
            try:
                self._cleanup_idle_and_unhealthy()
                self._shutdown_event.wait(60)  # Check every minute
            except Exception as e:
                logger.error(f"Connection pool cleanup error: {e}")
                self._shutdown_event.wait(60)

    def _cleanup_idle_and_unhealthy(self):
        """Clean up idle and unhealthy connections"""
        with self._lock:
            current_time = time.time()
            keys_to_remove = []

            for key, conn_info in self._connections.items():
                client = conn_info["client"]
                last_access = conn_info["last_access"]

                # Check if connection is idle or unhealthy
                is_idle = (current_time - last_access) > self.max_idle_time
                is_unhealthy = not client.is_healthy

                if is_idle or is_unhealthy:
                    if is_unhealthy:
                        logger.info(f"Removing unhealthy connection: {key}")
                    else:
                        logger.info(
                            f"Removing idle connection: {key} (idle for {current_time - last_access:.1f}s)"
                        )

                    keys_to_remove.append(key)

                    # Close the connection
                    try:
                        client.close()
                    except Exception as e:
                        logger.error(f"Error closing connection {key}: {e}")

            # Remove from pool
            for key in keys_to_remove:
                self._connections.pop(key, None)

    def get_client(self, host: str, port: int, **kwargs) -> GrpcClientBase:
        """
        Get or create a gRPC client connection

        Args:
            host: Server host
            port: Server port
            **kwargs: Additional client configuration

        Returns:
            GrpcClientBase: Client instance
        """
        key = f"{host}:{port}"
        current_time = time.time()

        with self._lock:
            # Check if connection exists and is healthy
            if key in self._connections:
                conn_info = self._connections[key]
                client = conn_info["client"]

                # Update last access time
                conn_info["last_access"] = current_time

                # Move to end (mark as recently used)
                self._connections.move_to_end(key)

                if client.is_healthy:
                    logger.debug(f"Reusing existing connection: {key}")
                    return client
                else:
                    # Remove unhealthy connection
                    logger.warning(f"Removing unhealthy connection: {key}")
                    try:
                        client.close()
                    except Exception as e:
                        logger.error(f"Error closing unhealthy connection {key}: {e}")
                    del self._connections[key]

            # Check pool size limit
            if len(self._connections) >= self.max_connections:
                # Evict least recently used connection
                oldest_key, oldest_conn = self._connections.popitem(last=False)
                logger.info(f"Evicting LRU connection: {oldest_key}")
                try:
                    oldest_conn["client"].close()
                except Exception as e:
                    logger.error(f"Error closing evicted connection {oldest_key}: {e}")

            # Create new connection
            logger.info(f"Creating new connection: {key}")
            # 从 kwargs 中提取 config，如果没有则使用默认配置
            config = kwargs.pop("../config", None)
            if config is None and kwargs:
                # 如果有其他 kwargs，说明是旧代码，需要转换
                from microcorex.rpc.grpc_client_config import GrpcClientConfig

                config = GrpcClientConfig.from_dict(kwargs)
            client = GrpcClientBase(host=host, port=port, config=config)
            client.connect()

            # Add to pool
            self._connections[key] = {
                "client": client,
                "created_at": current_time,
                "last_access": current_time,
                "access_count": 0,
            }

            # Move to end (most recently used)
            self._connections.move_to_end(key)

            return client

    def get_connection_stats(self) -> Dict:
        """Get connection pool statistics"""
        with self._lock:
            stats = {
                "total_connections": len(self._connections),
                "max_connections": self.max_connections,
                "max_idle_time": self.max_idle_time,
                "connections": [],
            }

            for key, conn_info in self._connections.items():
                client = conn_info["client"]
                stats["connections"].append(
                    {
                        "address": key,
                        "state": client.state.name,
                        "is_healthy": client.is_healthy,
                        "created_at": conn_info["created_at"],
                        "last_access": conn_info["last_access"],
                        "access_count": conn_info["access_count"],
                        "idle_time": time.time() - conn_info["last_access"],
                    }
                )

            return stats

    def close_all(self):
        """Close all connections and shutdown pool"""
        with self._lock:
            logger.info("Closing all connection pool connections")

            for key, conn_info in self._connections.items():
                try:
                    conn_info["client"].close()
                    logger.debug(f"Closed connection: {key}")
                except Exception as e:
                    logger.error(f"Error closing connection {key}: {e}")

            self._connections.clear()

        # Shutdown cleanup thread
        self._shutdown_event.set()
        if self._cleanup_thread and self._cleanup_thread.is_alive():
            self._cleanup_thread.join(timeout=5.0)

        logger.info("Connection pool shutdown complete")

    def remove_connection(self, host: str, port: int):
        """Remove specific connection from pool"""
        key = f"{host}:{port}"
        with self._lock:
            if key in self._connections:
                conn_info = self._connections.pop(key)
                try:
                    conn_info["client"].close()
                    logger.info(f"Removed connection: {key}")
                except Exception as e:
                    logger.error(f"Error removing connection {key}: {e}")


class BaseGrpcClient:
    """
    Enhanced Base gRPC Client Class

    Encapsulates common logic for client creation, enhanced connection management,
    thread-safe connection pooling, and connection lifecycle management.

    Features:
        - Thread-safe connection pool with LRU eviction
        - Connection health monitoring and automatic cleanup
        - Service discovery integration
        - Connection reuse optimization
        - Configurable pool parameters
        - Graceful shutdown handling

    Usage:
        class SystemUserServiceGrpc(BaseGrpcClient):
            _service_name = "system-service"  # Set service name

            @classmethod
            @grpc_call(...)
            def get_by_id(cls, user_id: int):
                return system_pb2.GetUserRequest(user_id=user_id)

    Configuration:
        - POOL_MAX_CONNECTIONS: Maximum connections in pool (default: 100)
        - POOL_MAX_IDLE_TIME: Maximum idle time before eviction (default: 300s)
        - CLIENT_TIMEOUT: Default client timeout (default: 5s)
    """

    # Shared connection pool instance for all subclasses
    _connection_pool: ClassVar[Optional[ConnectionPool]] = None
    _pool_lock: ClassVar[threading.Lock] = threading.Lock()

    # Service name, must be set by subclasses
    _service_name: ClassVar[str] = ""

    # Pool configuration
    _pool_max_connections: ClassVar[int] = 100
    _pool_max_idle_time: ClassVar[int] = 300
    _client_timeout: ClassVar[int] = 5

    @classmethod
    def _get_pool(cls) -> ConnectionPool:
        """Get or create shared connection pool"""
        if cls._connection_pool is None:
            with cls._pool_lock:
                if cls._connection_pool is None:
                    cls._connection_pool = ConnectionPool(
                        max_connections=cls._pool_max_connections,
                        max_idle_time=cls._pool_max_idle_time,
                    )
                    logger.info(
                        f"Created gRPC connection pool (max={cls._pool_max_connections}, idle={cls._pool_max_idle_time}s)"
                    )
        return cls._connection_pool

    @classmethod
    def _get_client(cls) -> GrpcClientBase:
        """
        Get or create gRPC client with enhanced connection management

        Retrieves service configuration from service registry, creates or reuses
        client connection from the connection pool.

        Returns:
            GrpcClientBase: gRPC client instance

        Raises:
            ValueError: If subclass has not set _service_name
            RuntimeError: If service configuration is invalid
        """
        if not cls._service_name:
            raise ValueError(f"{cls.__name__} must set _service_name class attribute")

        try:
            # Get service configuration from service registry
            service_config = ServiceRegistry.get_service_config(cls._service_name)
            host = service_config.get("host", "localhost")
            port = int(service_config.get("grpc_port", 9002))

            # Validate configuration
            if not host or port <= 0 or port > 65535:
                raise RuntimeError(
                    f"Invalid service configuration for {cls._service_name}: host={host}, port={port}"
                )

            # Get client from connection pool
            pool = cls._get_pool()
            client = pool.get_client(
                host=host,
                port=port,
                timeout=cls._client_timeout,
                connect_timeout_ms=5000,
                keepalive_time_ms=30000,
                keepalive_timeout_ms=5000,
                health_check_interval=30,
                enable_reconnect=True,
            )

            logger.debug(f"Retrieved {cls._service_name} gRPC client: {host}:{port}")
            return client

        except Exception as e:
            logger.error(f"Failed to get gRPC client for {cls._service_name}: {e}")
            raise

    @classmethod
    def get_connection_stats(cls) -> Dict:
        """
        Get connection pool statistics

        Returns:
            Dict: Connection pool statistics
        """
        pool = cls._get_pool()
        return pool.get_connection_stats()

    @classmethod
    def remove_service_connection(cls, host: str = None, port: int = None):
        """
        Remove specific service connection from pool

        Args:
            host: Service host (if None, uses service registry)
            port: Service port (if None, uses service registry)
        """
        try:
            if host is None or port is None:
                service_config = ServiceRegistry.get_service_config(cls._service_name)
                host = host or service_config.get("host", "localhost")
                port = port or int(service_config.get("grpc_port", 9002))

            pool = cls._get_pool()
            pool.remove_connection(host, port)
            logger.info(f"Removed connection for {cls._service_name}: {host}:{port}")

        except Exception as e:
            logger.error(f"Failed to remove connection for {cls._service_name}: {e}")

    @classmethod
    def close_all(cls):
        """
        Close all client connections and shutdown connection pool

        This should be called during application shutdown to ensure
        proper cleanup of all resources.
        """
        try:
            if cls._connection_pool:
                cls._connection_pool.close_all()
                cls._connection_pool = None
                logger.info("All gRPC client connections closed and pool shutdown")
            else:
                logger.info("Connection pool already closed")
        except Exception as e:
            logger.error(f"Error during connection pool shutdown: {e}")

    @classmethod
    def configure_pool(
        cls,
        max_connections: int = None,
        max_idle_time: int = None,
        client_timeout: int = None,
    ):
        """
        Configure connection pool parameters

        Args:
            max_connections: Maximum number of connections in pool
            max_idle_time: Maximum idle time before eviction (seconds)
            client_timeout: Default client timeout (seconds)
        """
        if max_connections is not None:
            cls._pool_max_connections = max_connections
        if max_idle_time is not None:
            cls._pool_max_idle_time = max_idle_time
        if client_timeout is not None:
            cls._client_timeout = client_timeout

        # Recreate pool with new configuration if it exists
        if cls._connection_pool is not None:
            with cls._pool_lock:
                old_pool = cls._connection_pool
                cls._connection_pool = None
                old_pool.close_all()

            logger.info(
                f"Connection pool reconfigured (max={cls._pool_max_connections}, idle={cls._pool_max_idle_time}s, timeout={cls._client_timeout}s)"
            )

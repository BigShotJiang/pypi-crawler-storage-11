"""
gRPC Server Base Class

Provides basic functionality for gRPC servers, including startup, shutdown, and graceful termination.
"""

import grpc.aio
from abc import ABC, abstractmethod
from typing import Optional

from microcorex.config.config import MicroCoreConfig
from microcorex.log.logging_setup import get_logger

logger = get_logger(__name__)


class GrpcServerBase(ABC):
    """
    gRPC Server Base Class

    Provides basic functionality for gRPC servers. Subclasses need to implement the register_services method
    to register specific gRPC services.
    """

    def __init__(self, config: MicroCoreConfig):
        """
        Initialize gRPC server

        Args:
            config: Microservice core configuration
        """
        self.config = config
        self.server: Optional[grpc.aio.Server] = None

    @abstractmethod
    def register_services(self, server: grpc.aio.Server):
        """
        Register gRPC services (must be implemented by subclasses)

        Args:
            server: gRPC server instance
        """
        pass

    async def start(self):
        """Start gRPC server"""
        try:
            # Create gRPC server with comprehensive QoS configuration
            self.server = grpc.aio.server(
                options=[
                    # Message size limits (prevent memory exhaustion)
                    ("grpc.max_receive_message_length", 100 * 1024 * 1024),  # 100MB
                    ("grpc.max_send_message_length", 100 * 1024 * 1024),  # 100MB
                    # Concurrent request control (prevent resource exhaustion)
                    ("grpc.max_concurrent_rpcs", 1000),  # Limit concurrent requests
                    # Enhanced keepalive configuration
                    ("grpc.keepalive_time_ms", 60 * 1000),  # 60 seconds
                    ("grpc.keepalive_timeout_ms", 20 * 1000),  # 20 seconds
                    (
                        "grpc.keepalive_permit_without_calls",
                        True,
                    ),  # Allow keepalive without active calls
                    ("grpc.http2.max_pings_without_data", 0),  # Allow unlimited pings
                    (
                        "grpc.http2.min_time_between_pings_ms",
                        10 * 1000,
                    ),  # Minimum 10s between pings
                    (
                        "grpc.http2.min_ping_interval_without_data_ms",
                        300 * 1000,
                    ),  # 5 minutes
                    # Connection and flow control
                    (
                        "grpc.client_channel_timeout_in_ms",
                        30 * 1000,
                    ),  # Client connection timeout
                    ("grpc.http2.bdp_probe", 1),  # Enable bandwidth detection
                    ("grpc.http2.max_frame_size", 1024 * 1024),  # 1MB max frame size
                    # Performance tuning
                    ("grpc.so_reuseport", 1),  # Enable port reuse for load balancing
                    (
                        "grpc.default_compression_algorithm",
                        2,
                    ),  # Enable gzip compression
                    ("grpc.default_compression_level", 2),  # Medium compression level
                ]
            )

            # Register services (implemented by subclass)
            self.register_services(self.server)

            # Bind port
            listen_addr = f"[::]:{self.config.server.grpcPort}"
            self.server.add_insecure_port(listen_addr)

            # Start server
            await self.server.start()
            logger.info(
                f"✅ gRPC server started successfully: {self.config.server.ip}:{self.config.server.grpcPort}"
            )

        except Exception as e:
            logger.error(f"gRPC server startup failed: {e}")
            raise

    async def stop(self, grace_period: int = 30):
        """
        Stop gRPC server

        Args:
            grace_period: Graceful shutdown wait time in seconds
        """
        if self.server:
            try:
                logger.info(f"Stopping gRPC server (waiting {grace_period} seconds)...")
                await self.server.stop(grace_period)
                logger.info("✅ gRPC server stopped")
            except Exception as e:
                logger.error(f"Failed to stop gRPC server: {e}")

    async def wait_for_termination(self):
        """Wait for server termination"""
        if self.server:
            await self.server.wait_for_termination()

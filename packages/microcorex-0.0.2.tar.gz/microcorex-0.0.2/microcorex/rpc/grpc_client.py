"""
gRPC Client Base Class

Provides common gRPC client functionality, including connection management,
timeout control, error handling, connection pooling, and health monitoring.
"""

import grpc
import threading
import time
from typing import Optional, Dict, Any, Callable
from enum import Enum
from loguru import logger
from microcorex.rpc.grpc_client_config import GrpcClientConfig


class ChannelState(Enum):
    """gRPC Channel States"""

    IDLE = 0
    CONNECTING = 1
    READY = 2
    TRANSIENT_FAILURE = 3
    SHUTDOWN = 4


class GrpcClientBase:
    """
    Enhanced gRPC Client Base Class

    Provides comprehensive gRPC client functionality with:
    - Proper channel configuration with timeouts and keepalive
    - Connection state monitoring and health checks
    - Thread-safe connection management
    - Automatic reconnection with exponential backoff
    - Performance optimization per gRPC best practices
    """

    def __init__(self, host: str, port: int, config: Optional[GrpcClientConfig] = None):
        """
        Initialize enhanced gRPC client with comprehensive configuration

        Args:
            host: Server address
            port: Server port
            config: GrpcClientConfig 配置对象，如为 None 则使用默认配置

        Example:
            # 使用默认配置
            >>> client = GrpcClientBase("localhost", 50051)

            # 使用自定义配置
            >>> config = GrpcClientConfig(timeout=10, maxRetries=5)
            >>> client = GrpcClientBase("localhost", 50051, config=config)

            # 使用预设配置
            >>> from microcorex.grpc_client_config import GrpcClientConfigPresets
            >>> config = GrpcClientConfigPresets.fast()
            >>> client = GrpcClientBase("localhost", 50051, config=config)
        """
        self.host = host
        self.port = port
        self.address = f"{host}:{port}"

        # 使用配置对象，如为 None 则使用默认配置
        if config is None:
            config = GrpcClientConfig()

        # 从配置对象中读取所有参数
        self.timeout = config.timeout
        self.max_retries = config.maxRetries

        # Channel configuration
        self.connect_timeout_ms = config.connectTimeoutMs
        self.keepalive_time_ms = config.keepaliveTimeMs
        self.keepalive_timeout_ms = config.keepaliveTimeoutMs
        self.keepalive_permit_without_calls = config.keepalivePermitWithoutCalls
        self.max_receive_message_length = config.maxReceiveMessageLength
        self.max_send_message_length = config.maxSendMessageLength
        self.http2_max_pings_without_data = config.http2MaxPingsWithoutData
        self.http2_min_time_between_pings_ms = config.http2MinTimeBetweenPingsMs
        self.http2_min_ping_interval_without_data_ms = (
            config.http2MinPingIntervalWithoutDataMs
        )

        # Health check and reconnection
        self.health_check_interval = config.healthCheckInterval
        self.enable_reconnect = config.enableReconnect
        self.reconnect_backoff_factor = config.reconnectBackoffFactor
        self.reconnect_max_backoff = config.reconnectMaxBackoff

        # Connection state
        self._channel: Optional[grpc.Channel] = None
        self._state = ChannelState.IDLE
        self._lock = threading.RLock()
        self._shutdown_event = threading.Event()
        self._health_check_thread: Optional[threading.Thread] = None
        self._reconnect_attempt = 0
        self._last_connect_time = 0

        # Callbacks
        self._state_callbacks: list[Callable[[ChannelState], None]] = []

    def _create_channel_options(self) -> Dict[str, Any]:
        """Create gRPC channel options with optimal configuration"""
        options = [
            ("grpc.connect_timeout_ms", self.connect_timeout_ms),
            ("grpc.keepalive_time_ms", self.keepalive_time_ms),
            ("grpc.keepalive_timeout_ms", self.keepalive_timeout_ms),
            (
                "grpc.keepalive_permit_without_calls",
                self.keepalive_permit_without_calls,
            ),
            ("grpc.max_receive_message_length", self.max_receive_message_length),
            ("grpc.max_send_message_length", self.max_send_message_length),
            ("grpc.http2.max_pings_without_data", self.http2_max_pings_without_data),
            (
                "grpc.http2.min_time_between_pings_ms",
                self.http2_min_time_between_pings_ms,
            ),
            (
                "grpc.http2.min_ping_interval_without_data_ms",
                self.http2_min_ping_interval_without_data_ms,
            ),
            ("grpc.enable_retries", 1),
            ("grpc.per_rpc_retry_buffer_size", 1024 * 1024),  # 1MB buffer
        ]
        return options

    def _update_state(self, new_state: ChannelState):
        """Update channel state and notify callbacks"""
        with self._lock:
            old_state = self._state
            self._state = new_state

        if old_state != new_state:
            logger.debug(
                f"gRPC channel state changed: {old_state.name} -> {new_state.name} for {self.address}"
            )

            # Notify state callbacks
            for callback in self._state_callbacks:
                try:
                    callback(new_state)
                except Exception as e:
                    logger.error(f"Error in state callback: {e}")

    def _health_check_loop(self):
        """Background health check loop"""
        logger.debug(f"Health check thread started for {self.address}")

        while not self._shutdown_event.is_set():
            try:
                if self._channel is not None:
                    # Check channel connectivity state
                    try:
                        grpc.channel_ready_future(self._channel).result(timeout=2.0)
                        if self._state != ChannelState.READY:
                            self._update_state(ChannelState.READY)
                            self._reconnect_attempt = (
                                0  # Reset reconnect attempt on success
                            )
                    except grpc.FutureTimeoutError:
                        self._update_state(ChannelState.TRANSIENT_FAILURE)
                        if self.enable_reconnect:
                            self._schedule_reconnect()

                # Wait for next health check or shutdown
                self._shutdown_event.wait(self.health_check_interval)

            except Exception as e:
                logger.error(f"Health check error for {self.address}: {e}")
                self._update_state(ChannelState.TRANSIENT_FAILURE)
                self._shutdown_event.wait(min(self.health_check_interval, 5))

    def _schedule_reconnect(self):
        """Schedule reconnection with exponential backoff"""
        if not self.enable_reconnect:
            return

        # Calculate backoff time
        backoff_time = min(
            self.reconnect_backoff_factor**self._reconnect_attempt,
            self.reconnect_max_backoff,
        )

        self._reconnect_attempt += 1
        logger.warning(
            f"Scheduling reconnection to {self.address} in {backoff_time:.1f}s (attempt {self._reconnect_attempt})"
        )

        # Schedule reconnection
        def reconnect():
            if not self._shutdown_event.is_set():
                try:
                    self._attempt_reconnect()
                except Exception as e:
                    logger.error(f"Reconnection failed for {self.address}: {e}")

        # Use threading.Timer for delayed execution
        timer = threading.Timer(backoff_time, reconnect)
        timer.daemon = True
        timer.start()

    def _attempt_reconnect(self):
        """Attempt to reconnect"""
        with self._lock:
            if self._shutdown_event.is_set():
                return

            logger.info(f"Attempting to reconnect to {self.address}")

            # Close existing channel
            if self._channel:
                try:
                    self._channel.close()
                except Exception as e:
                    logger.error(f"Error closing channel during reconnection: {e}")

            # Create new channel
            try:
                self._channel = grpc.insecure_channel(
                    self.address, self._create_channel_options()
                )
                self._update_state(ChannelState.CONNECTING)
                self._last_connect_time = time.time()

                # Verify connection
                grpc.channel_ready_future(self._channel).result(timeout=5.0)
                self._update_state(ChannelState.READY)
                logger.info(f"Successfully reconnected to {self.address}")

            except Exception as e:
                self._update_state(ChannelState.TRANSIENT_FAILURE)
                raise

    def connect(self):
        """Establish gRPC connection with enhanced error handling"""
        with self._lock:
            if self._shutdown_event.is_set():
                raise RuntimeError("Client is shutting down")

            if self._channel is not None:
                return self._channel

            try:
                self._update_state(ChannelState.CONNECTING)
                logger.info(f"Connecting to gRPC server: {self.address}")

                # Create channel with optimized options
                options = self._create_channel_options()
                self._channel = grpc.insecure_channel(self.address, options)

                # Wait for connection with timeout
                try:
                    grpc.channel_ready_future(self._channel).result(
                        timeout=self.timeout
                    )
                    self._update_state(ChannelState.READY)
                    self._last_connect_time = time.time()
                    logger.info(f"gRPC client connected successfully: {self.address}")

                except grpc.FutureTimeoutError:
                    self._update_state(ChannelState.TRANSIENT_FAILURE)
                    raise grpc.RpcError(f"Connection timeout to {self.address}")

                # Start health check thread
                if self.health_check_interval > 0 and self._health_check_thread is None:
                    self._health_check_thread = threading.Thread(
                        target=self._health_check_loop, daemon=True
                    )
                    self._health_check_thread.start()

                return self._channel

            except Exception as e:
                self._update_state(ChannelState.TRANSIENT_FAILURE)
                logger.error(f"Failed to connect to {self.address}: {e}")
                raise

    def close(self):
        """Close gRPC connection and cleanup resources"""
        with self._lock:
            if self._channel is None:
                return

            logger.info(f"Closing gRPC connection to {self.address}")

            # Signal shutdown
            self._shutdown_event.set()

            # Close channel
            try:
                self._channel.close()
            except Exception as e:
                logger.error(f"Error closing channel: {e}")
            finally:
                self._channel = None

            # Update state
            self._update_state(ChannelState.SHUTDOWN)

            # Wait for health check thread to finish
            if self._health_check_thread and self._health_check_thread.is_alive():
                self._health_check_thread.join(timeout=5.0)
                if self._health_check_thread.is_alive():
                    logger.warning("Health check thread did not terminate gracefully")

            logger.info(f"gRPC client connection closed: {self.address}")

    @property
    def channel(self) -> grpc.Channel:
        """Get gRPC channel with lazy connection"""
        if self._channel is None:
            self.connect()
        return self._channel

    @property
    def state(self) -> ChannelState:
        """Get current channel state"""
        return self._state

    @property
    def is_healthy(self) -> bool:
        """Check if channel is healthy and ready"""
        return self._state == ChannelState.READY

    def add_state_callback(self, callback: Callable[[ChannelState], None]):
        """Add callback for state changes"""
        with self._lock:
            self._state_callbacks.append(callback)

    def remove_state_callback(self, callback: Callable[[ChannelState], None]):
        """Remove state change callback"""
        with self._lock:
            if callback in self._state_callbacks:
                self._state_callbacks.remove(callback)

    def get_connection_info(self) -> Dict[str, Any]:
        """Get connection information and statistics"""
        return {
            "address": self.address,
            "state": self._state.name,
            "is_healthy": self.is_healthy,
            "connect_timeout_ms": self.connect_timeout_ms,
            "keepalive_time_ms": self.keepalive_time_ms,
            "max_receive_message_length": self.max_receive_message_length,
            "max_send_message_length": self.max_send_message_length,
            "reconnect_attempt": self._reconnect_attempt,
            "last_connect_time": self._last_connect_time,
            "health_check_interval": self.health_check_interval,
        }

    def __enter__(self):
        """Context manager entry"""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()
        return False

    def __del__(self):
        """Destructor to ensure cleanup"""
        try:
            self.close()
        except Exception:
            pass  # Ignore errors during cleanup

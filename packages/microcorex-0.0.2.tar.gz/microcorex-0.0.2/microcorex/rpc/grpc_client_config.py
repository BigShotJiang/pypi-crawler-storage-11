"""
gRPC Client Configuration

提供 gRPC 客户端的配置类，封装所有配置参数，简化客户端初始化。
使用小驼峰命名规范（camelCase）。
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class GrpcClientConfig:
    """
    gRPC 客户端配置类

    封装所有 gRPC 客户端配置参数，使用小驼峰命名规范。
    提供合理的默认值，符合 gRPC 官方最佳实践。

    Attributes:
        timeout: 请求超时时间（秒）
        maxRetries: 最大重试次数
        connectTimeoutMs: 连接超时时间（毫秒）
        keepaliveTimeMs: Keepalive 时间（毫秒）
        keepaliveTimeoutMs: Keepalive 超时时间（毫秒）
        keepalivePermitWithoutCalls: 是否允许无活跃调用时发送 keepalive
        maxReceiveMessageLength: 最大接收消息大小（字节）
        maxSendMessageLength: 最大发送消息大小（字节）
        http2MaxPingsWithoutData: HTTP/2 最大无数据 ping 次数
        http2MinTimeBetweenPingsMs: HTTP/2 最小 ping 间隔（毫秒）
        http2MinPingIntervalWithoutDataMs: HTTP/2 无数据时最小 ping 间隔（毫秒）
        healthCheckInterval: 健康检查间隔（秒）
        enableReconnect: 是否启用自动重连
        reconnectBackoffFactor: 重连退避因子
        reconnectMaxBackoff: 最大退避时间（秒）

    Example:
        >>> config = GrpcClientConfig(timeout=10, maxRetries=5)
        >>> client = GrpcClientBase("localhost", 50051, config=config)
    """

    # 基础配置
    timeout: int = 5
    maxRetries: int = 3

    # 连接配置
    connectTimeoutMs: int = 5000

    # Keepalive 配置（根据 gRPC 最佳实践）
    keepaliveTimeMs: int = 30000  # 30秒
    keepaliveTimeoutMs: int = 5000  # 5秒
    keepalivePermitWithoutCalls: bool = True

    # 消息大小限制
    maxReceiveMessageLength: int = 4 * 1024 * 1024  # 4MB
    maxSendMessageLength: int = 4 * 1024 * 1024  # 4MB

    # HTTP/2 配置
    http2MaxPingsWithoutData: int = 0
    http2MinTimeBetweenPingsMs: int = 10000  # 10秒
    http2MinPingIntervalWithoutDataMs: int = 300000  # 5分钟

    # 健康检查和重连
    healthCheckInterval: int = 30  # 30秒
    enableReconnect: bool = True
    reconnectBackoffFactor: float = 2.0
    reconnectMaxBackoff: float = 60.0  # 60秒

    def to_dict(self) -> dict:
        """
        将配置转换为字典格式

        Returns:
            dict: 配置字典
        """
        return {
            "timeout": self.timeout,
            "max_retries": self.maxRetries,
            "connect_timeout_ms": self.connectTimeoutMs,
            "keepalive_time_ms": self.keepaliveTimeMs,
            "keepalive_timeout_ms": self.keepaliveTimeoutMs,
            "keepalive_permit_without_calls": self.keepalivePermitWithoutCalls,
            "max_receive_message_length": self.maxReceiveMessageLength,
            "max_send_message_length": self.maxSendMessageLength,
            "http2_max_pings_without_data": self.http2MaxPingsWithoutData,
            "http2_min_time_between_pings_ms": self.http2MinTimeBetweenPingsMs,
            "http2_min_ping_interval_without_data_ms": self.http2MinPingIntervalWithoutDataMs,
            "health_check_interval": self.healthCheckInterval,
            "enable_reconnect": self.enableReconnect,
            "reconnect_backoff_factor": self.reconnectBackoffFactor,
            "reconnect_max_backoff": self.reconnectMaxBackoff,
        }

    @classmethod
    def from_dict(cls, config_dict: dict) -> "GrpcClientConfig":
        """
        从字典创建配置对象

        Args:
            config_dict: 配置字典（支持下划线命名）

        Returns:
            GrpcClientConfig: 配置对象
        """
        # 映射下划线命名到小驼峰命名
        mapping = {
            "timeout": "timeout",
            "max_retries": "maxRetries",
            "connect_timeout_ms": "connectTimeoutMs",
            "keepalive_time_ms": "keepaliveTimeMs",
            "keepalive_timeout_ms": "keepaliveTimeoutMs",
            "keepalive_permit_without_calls": "keepalivePermitWithoutCalls",
            "max_receive_message_length": "maxReceiveMessageLength",
            "max_send_message_length": "maxSendMessageLength",
            "http2_max_pings_without_data": "http2MaxPingsWithoutData",
            "http2_min_time_between_pings_ms": "http2MinTimeBetweenPingsMs",
            "http2_min_ping_interval_without_data_ms": "http2MinPingIntervalWithoutDataMs",
            "health_check_interval": "healthCheckInterval",
            "enable_reconnect": "enableReconnect",
            "reconnect_backoff_factor": "reconnectBackoffFactor",
            "reconnect_max_backoff": "reconnectMaxBackoff",
        }

        camel_dict = {}
        for snake_key, camel_key in mapping.items():
            if snake_key in config_dict:
                camel_dict[camel_key] = config_dict[snake_key]

        return cls(**camel_dict)


# 预定义的配置模板


@dataclass
class GrpcClientConfigPresets:
    """gRPC 客户端配置预设模板"""

    @staticmethod
    def default() -> GrpcClientConfig:
        """默认配置"""
        return GrpcClientConfig()

    @staticmethod
    def fast() -> GrpcClientConfig:
        """快速响应配置（低延迟场景）"""
        return GrpcClientConfig(
            timeout=3,
            maxRetries=2,
            connectTimeoutMs=3000,
            keepaliveTimeMs=10000,  # 10秒
            healthCheckInterval=10,
        )

    @staticmethod
    def reliable() -> GrpcClientConfig:
        """可靠配置（高可用场景）"""
        return GrpcClientConfig(
            timeout=10,
            maxRetries=5,
            connectTimeoutMs=10000,
            keepaliveTimeMs=60000,  # 60秒
            healthCheckInterval=60,
            reconnectMaxBackoff=120.0,
        )

    @staticmethod
    def large_message() -> GrpcClientConfig:
        """大消息配置（需要传输大数据）"""
        return GrpcClientConfig(
            timeout=30,
            maxReceiveMessageLength=100 * 1024 * 1024,  # 100MB
            maxSendMessageLength=100 * 1024 * 1024,  # 100MB
            connectTimeoutMs=15000,
        )

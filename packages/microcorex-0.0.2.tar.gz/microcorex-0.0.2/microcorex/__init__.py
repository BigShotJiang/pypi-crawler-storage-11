"""
MicroCoreX - Python Microservices Framework Core Library

Provides core functionality for microservices development:
- Configuration management (multi-environment support, Nacos integration, hot reload)
- Service lifecycle management (FastAPI + gRPC dual protocol support)
- Service registration and discovery (Nacos integration)
- gRPC client/server base classes
- Logging management
- JWT authentication and security middleware
- Domain objects and utilities
"""

__version__ = "0.1.0"
__author__ = "xiaoke"

# Configuration
from microcorex.config.config import (
    MicroCoreConfig,
    AppConfig,
    ServerConfig,
    NacosConfig,
    DatabaseConfig,
    JwtConfig,
    SecurityConfig,
)
from microcorex.config.config_loader import ConfigLoader

# Core Services
from microcorex.app_service import AppService
from microcorex.service.service_registry import ServiceRegistry

# gRPC Components
from microcorex.rpc.grpc_server import GrpcServerBase
from microcorex.rpc.base_grpc_client import BaseGrpcClient
from microcorex.rpc.grpc_client import GrpcClientBase
from microcorex.rpc.grpc_client_config import GrpcClientConfig, GrpcClientConfigPresets

# JWT and Security
from microcorex.jwt.jwt_manager import (
    JwtManager,
    init_jwt_manager,
    get_jwt_manager,
    JWTError,
    InvalidTokenError,
    TokenExpiredError,
    InvalidTokenTypeError,
    JWTNotInitializedError
)
from microcorex.middlewares.security_middleware import (
    SecurityMiddleware,
    get_white_url_list,
    get_default_whitelist,
)
from microcorex.middlewares.i18n_middleware import I18nMiddleware
from microcorex.middlewares.logging_middleware import LoggingMiddleware, filter_sensitive_data

# Logging
from microcorex.log.logging_setup import setup_logging, get_logger, InterceptHandler

# Domain Objects
from microcorex.domain.vo.r import R
from microcorex.domain.vo.page_vo import PageVo
from microcorex.domain.qo.page_qo import PageQo

# Context
from microcorex.core.ctx import CTX_LANG

# Nacos Integration
from microcorex.nacos.nacos_config_manager import NacosConfigManager, NacosConfigError
from microcorex.nacos.nacos_registrar import NacosRegistrar, NacosRegistrationError, NacosDiscoveryError

# Error Handling
from microcorex.error.error_handling import (
    ErrorLevel,
    MicroCoreError,
    ConfigError,
    ServiceRegistryError,
    GrpcError,
    NacosError,
    SecurityError,
    ErrorSanitizer,
    ErrorHandler
)

# Exceptions
from microcorex.exception.service_exception import ServiceException
from microcorex.exception.security_exception import SecurityException

# Utilities
from microcorex.utils.utils import (
    get_local_ip,
    is_valid_port,
    is_valid_ip,
    is_valid_hostname,
    is_safe_target_address,
    resolve_address,
    validate_service_name,
    sanitize_log_data
)
from microcorex.utils.dict_util import models_to_dicts, models_to_dict
from microcorex.utils.json_utils import to_json_string
from microcorex.utils.decimal_utils import decimal_to_chinese_uppercase

# middlewares
from microcorex.middlewares import load_i18n_middleware, load_logging_middleware, load_security_middleware

__all__ = [
    # Version
    "__version__",
    "__author__",

    # Configuration
    "MicroCoreConfig",
    "AppConfig",
    "ServerConfig",
    "NacosConfig",
    "DatabaseConfig",
    "JwtConfig",
    "SecurityConfig",
    "ConfigLoader",

    # Core Services
    "AppService",
    "ServiceRegistry",

    # gRPC Components
    "GrpcServerBase",
    "BaseGrpcClient",
    "GrpcClientBase",
    "GrpcClientConfig",
    "GrpcClientConfigPresets",

    # JWT and Security
    "JwtManager",
    "init_jwt_manager",
    "get_jwt_manager",
    "JWTError",
    "InvalidTokenError",
    "TokenExpiredError",
    "InvalidTokenTypeError",
    "JWTNotInitializedError",
    "SecurityMiddleware",
    "get_white_url_list",
    "get_default_whitelist",
    "I18nMiddleware",
    "LoggingMiddleware",
    "filter_sensitive_data",

    # Logging
    "setup_logging",
    "get_logger",
    "InterceptHandler",

    # Domain Objects
    "R",
    "PageVo",
    "PageQo",

    # Context
    "CTX_LANG",

    # Nacos Integration
    "NacosConfigManager",
    "NacosConfigError",
    "NacosRegistrar",
    "NacosRegistrationError",
    "NacosDiscoveryError",

    # Error Handling
    "ErrorLevel",
    "MicroCoreError",
    "ConfigError",
    "ServiceRegistryError",
    "GrpcError",
    "NacosError",
    "SecurityError",
    "ErrorSanitizer",
    "ErrorHandler",

    # Exceptions
    "ServiceException",
    "SecurityException",

    # Utilities
    "get_local_ip",
    "is_valid_port",
    "is_valid_ip",
    "is_valid_hostname",
    "is_safe_target_address",
    "resolve_address",
    "validate_service_name",
    "sanitize_log_data",
    "models_to_dicts",
    "models_to_dict",
    "to_json_string",
    "decimal_to_chinese_uppercase",

    # Middlewares
    "load_i18n_middleware",
    "load_logging_middleware",
    "load_security_middleware",
]

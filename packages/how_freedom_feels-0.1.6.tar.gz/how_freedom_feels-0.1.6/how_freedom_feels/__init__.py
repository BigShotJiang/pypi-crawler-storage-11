from .core import FreedomConnect

"""
How Freedom Feels - VPN Connection Manager
"""

__version__ = "0.1.6"
__all__ = ["FreedomConnect"]

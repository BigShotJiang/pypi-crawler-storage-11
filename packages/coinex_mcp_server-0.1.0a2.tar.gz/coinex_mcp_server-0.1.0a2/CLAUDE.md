# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

这是一个 CoinEx MCP (Model Context Protocol) 服务器，允许 AI 代理与 CoinEx 加密货币交易所交互。该项目使用 FastMCP 框架构建，支持现货和期货市场的数据查询与交易操作。

## 核心架构

### 主要组件
- `main.py` - MCP 服务器入口点，定义所有工具和传输配置
- `coinex_client.py` - CoinEx API 客户端，统一封装现货/期货 API 调用
- `bench/test_public_methods.py` - 公开接口测试脚本
- `deploy/` - Nginx 和 Supervisor 部署配置

### 技术栈
- **FastMCP 2.x** - MCP 服务器框架
- **httpx** - HTTP 客户端
- **pydantic** - 数据验证
- **python-dotenv** - 环境变量管理

## 开发命令

### 安装依赖
```bash
uv sync
```

### 运行服务器
```bash
# 默认 stdio 模式
python main.py

# HTTP 模式
python main.py --transport http --host 0.0.0.0 --port 8000 --enable-http-auth

# 查看帮助
python main.py --help
```

### 测试公开接口
```bash
cd tests
pytest test_public_methods.py
```

### 开发工具
```bash
# 代码格式化
black .

# 类型检查
mypy main.py coinex_client.py

# 运行测试
pytest
```

## 关键设计模式

### 认证处理
- **stdio 模式**: 从环境变量读取 API 凭据
- **HTTP/SSE 模式**: 通过请求头传递凭据 (`X-CoinEx-Access-Id`, `X-CoinEx-Secret-Key`)
- 使用 `get_secret_client_from_request()` 动态创建客户端实例

### 工具标签系统
- `tags={"public"}`: 公开市场数据查询，无需认证
- `tags={"auth"}`: 账户和交易功能，需要 API 凭据
- HTTP 模式默认只暴露 public 工具，需 `--enable-http-auth` 启用 auth 工具

### 参数标准化
- `symbol`: 支持 `BTCUSDT`/`BTC/USDT`/`btc` 格式，自动规范化
- `market_type`: `"spot"`(默认) 或 `"futures"`
- `period`: K线周期，有白名单验证

### 错误处理
- 所有 API 调用返回统一格式: `{code: int, message: str, data: any}`
- 错误情况记录日志但不抛异常，返回原始 API 响应

## 环境配置

### 必需的环境变量
```bash
# API 凭据 (stdio 模式)
COINEX_ACCESS_ID=your_access_id
COINEX_SECRET_KEY=your_secret_key

# 可选配置
HTTP_AUTH_ENABLED=true  # 启用 HTTP 认证
API_TOKEN=bearer_token  # Bearer 令牌保护
```

### 配置文件
- `.env` - 本地开发环境变量
- `deploy/nginx/coinex_mcp.conf` - Nginx 反向代理配置
- `deploy/supervisor/coinex_mcp.conf` - Supervisor 进程管理

## 部署注意事项

1. **安全**: HTTP 模式下的凭据传递仅适用于内网环境
2. **HTTPS**: 生产环境必须使用 HTTPS 保护 API 凭据
3. **日志**: 确保反向代理不记录敏感头信息
4. **工作进程**: 可通过 `--workers` 参数配置多进程

## 开发约定

- 使用 f-string 进行字符串格式化
- API 方法使用 async/await 模式
- 工具函数遵循 FastMCP 装饰器规范
- 错误处理优先返回结构化响应而非抛异常

## 输出
- 项目文档和注释都用英文，但问答的时候，请使用中文描述
# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AddSecurityGroupsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'request_id': 'str',
        'port': 'Port'
    }

    attribute_map = {
        'request_id': 'request_id',
        'port': 'port'
    }

    def __init__(self, request_id=None, port=None):
        r"""AddSecurityGroupsResponse

        The model defined in huaweicloud sdk

        :param request_id: 请求ID
        :type request_id: str
        :param port: 
        :type port: :class:`huaweicloudsdkvpc.v3.Port`
        """
        
        super().__init__()

        self._request_id = None
        self._port = None
        self.discriminator = None

        if request_id is not None:
            self.request_id = request_id
        if port is not None:
            self.port = port

    @property
    def request_id(self):
        r"""Gets the request_id of this AddSecurityGroupsResponse.

        请求ID

        :return: The request_id of this AddSecurityGroupsResponse.
        :rtype: str
        """
        return self._request_id

    @request_id.setter
    def request_id(self, request_id):
        r"""Sets the request_id of this AddSecurityGroupsResponse.

        请求ID

        :param request_id: The request_id of this AddSecurityGroupsResponse.
        :type request_id: str
        """
        self._request_id = request_id

    @property
    def port(self):
        r"""Gets the port of this AddSecurityGroupsResponse.

        :return: The port of this AddSecurityGroupsResponse.
        :rtype: :class:`huaweicloudsdkvpc.v3.Port`
        """
        return self._port

    @port.setter
    def port(self, port):
        r"""Sets the port of this AddSecurityGroupsResponse.

        :param port: The port of this AddSecurityGroupsResponse.
        :type port: :class:`huaweicloudsdkvpc.v3.Port`
        """
        self._port = port

    def to_dict(self):
        import warnings
        warnings.warn("AddSecurityGroupsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AddSecurityGroupsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

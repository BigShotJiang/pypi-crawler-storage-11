"""IDE configuration templates."""

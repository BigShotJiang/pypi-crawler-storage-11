from mcp_mini_deepresearch.server import main

if __name__ == "__main__":
    main()
#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   search_agent.py
@Time    :   2025/10/27 16:21:47
@Author  :   Anderson Huang 
@Version :   1.0
@Contact :   huanganfa66@163.com
@Desc    :   搜索代理
'''

# here put the import lib
import os
import asyncio
from agents import Agent, Runner, WebSearchTool
from agents.model_settings import ModelSettings

SEARCH_PROMPT = (
    "You are a research assistant. Given a search term, you search the web for that term and "
    "produce a concise summary of the results. The summary must 2-3 paragraphs and less than 300 "
    "words. Capture the main points. Write succinctly, no need to have complete sentences or good "
    "grammar. This will be consumed by someone synthesizing a report, so its vital you capture the "
    "essence and ignore any fluff. Do not include any additional commentary other than the summary "
    "itself."
)

search_agent = Agent(
    name="SearchAgent",
    instructions=SEARCH_PROMPT,
    model=os.getenv("MODEL"),
    tools=[WebSearchTool()], 
    model_settings=ModelSettings(tool_choice="required"), # 必须使用WebSearchTool
)

async def main():
    result = await Runner.run(starting_agent=search_agent, input="What is the capital of France?")
    print(result.final_output)

if __name__ == "__main__":
    asyncio.run(main())
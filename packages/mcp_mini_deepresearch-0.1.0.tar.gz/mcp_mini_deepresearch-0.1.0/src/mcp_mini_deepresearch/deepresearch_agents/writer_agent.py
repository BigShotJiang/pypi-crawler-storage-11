#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   writer_agent.py
@Time    :   2025/10/27 16:22:12
@Author  :   Anderson Huang 
@Version :   1.0
@Contact :   huanganfa66@163.com
@Desc    :   编写代理
'''

# here put the import lib
import os
import asyncio
from pydantic import BaseModel
from agents import Agent, Runner

WRITER_PROMPT = (
    "You are a senior researcher tasked with writing a cohesive report for a research query. "
    "You will be provided with the original query, and some initial research done by a research "
    "assistant.\n"
    "You should first come up with an outline for the report that describes the structure and "
    "flow of the report. Then, generate the report and return that as your final output.\n"
    "The final output should be in markdown format, and it should be lengthy and detailed. Aim "
    "for 5-10 pages of content, at least 1000 words.\n"
    "最终结果请用中文输出。"
)

class ReportData(BaseModel):
    short_summary: str
    """A short 2-3 sentence summary of the findings."""

    markdown_report: str
    """The final report"""

    follow_up_questions: list[str]
    """Suggested topics to research further"""

writer_agent = Agent(
    name="WriterAgent",
    instructions=WRITER_PROMPT,
    model=os.getenv("MODEL"),
    output_type=ReportData
)

async def main():
    result = await Runner.run(starting_agent=writer_agent, input="What is the capital of France?")
    print(result.final_output)

if __name__ == "__main__":
    asyncio.run(main())
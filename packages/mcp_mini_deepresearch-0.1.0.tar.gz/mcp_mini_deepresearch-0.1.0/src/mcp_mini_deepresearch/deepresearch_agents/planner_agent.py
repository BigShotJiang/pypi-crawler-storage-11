#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   planner_agent.py
@Time    :   2025/10/27 16:21:22
@Author  :   Anderson Huang 
@Version :   1.0
@Contact :   huanganfa66@163.com
@Desc    :   计划代理
'''

# here put the import lib
import os
import asyncio
from typing import List
from pydantic import BaseModel
from agents import Agent, Runner

PLANNER_PROMPT = (
    "You are a helpful research assistant. Given a query, come up with a set of web searches "
    "to perform to best answer the query. Output between 5 and 20 terms to query for."
)

class WebSearchItem(BaseModel):
    reason: str
    "Your reasoning for why this search is important to the query."

    query: str
    "The search term to use for the web search."

class WebSearchPlan(BaseModel):
    items: List[WebSearchItem]
    "The list of web searches to perform."

planner_agent = Agent(
    name="PlannerAgent",
    instructions=PLANNER_PROMPT,
    model=os.getenv("MODEL"),
    output_type=WebSearchPlan
)

async def main():
    result = await Runner.run(starting_agent=planner_agent, input="What is the capital of France?")
    print(result.final_output)

if __name__ == "__main__":
    asyncio.run(main())


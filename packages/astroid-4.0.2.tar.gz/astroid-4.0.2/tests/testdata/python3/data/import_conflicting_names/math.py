import math

print(math)

"""
Get NL Config endpoint - retrieves configuration for a specific NL app.
"""
from fastapi import APIRouter, HTTPException, Path as PathParam, Query, Request
from pydantic import BaseModel
from typing import Dict, Any, Optional

# Import the new universal authentication helper
try:
    from src.aurica_auth import protected, get_current_user
except ImportError:
    # Fallback if running in different context
    print("⚠️  Warning: Could not import universal_auth, authentication may not work")
    def auth_required(func):
        return func
    def get_current_user(request, required=True):
        return {"username": "unknown", "user_id": "unknown"}

router = APIRouter()


class NLConfigResponse(BaseModel):
    """Response model for NL configuration."""
    app_name: str
    config: Dict[str, Any]
    nl_file: str


@router.get("/", response_model=NLConfigResponse, summary="Get NL app configuration (query param)", tags=["generator"])
@protected
async def get_nl_config_query(request: Request, app_name: str = Query(..., description="Name of the app")):
    """
    Get the natural language configuration for a specific app using query parameter.
    
    Args:
        request: FastAPI request object
        app_name: Name of the app (query parameter)
        
    Returns:
        NLConfigResponse with the app.nl.json configuration
    """
    user = get_current_user(request)
    print(f"⚙️  User {user.username} getting NL config for: {app_name}")
    
    # Import here to avoid circular dependency
    from src.main import nl_generator
    
    nl_config = await nl_generator.load_nl_config(app_name)
    
    if not nl_config:
        raise HTTPException(status_code=404, detail=f"No NL configuration found for app '{app_name}'")
    
    return NLConfigResponse(
        app_name=app_name,
        config=nl_config,
        nl_file=f"apps/{app_name}/app.nl.json"
    )


@router.get("/{app_name}", response_model=NLConfigResponse, summary="Get NL app configuration", tags=["generator"])
@protected
async def get_nl_config(request: Request, app_name: str = PathParam(..., description="Name of the app")):
    """
    Get the natural language configuration for a specific app.
    
    Args:
        request: FastAPI request object
        app_name: Name of the app
        
    Returns:
        NLConfigResponse with the app.nl.json configuration
    """
    user = get_current_user(request)
    print(f"⚙️  User {user.username} getting NL config for: {app_name}")
    
    # Import here to avoid circular dependency
    from src.main import nl_generator
    
    nl_config = await nl_generator.load_nl_config(app_name)
    
    if not nl_config:
        raise HTTPException(status_code=404, detail=f"No NL configuration found for app '{app_name}'")
    
    return NLConfigResponse(
        app_name=app_name,
        config=nl_config,
        nl_file=f"apps/{app_name}/app.nl.json"
    )

"""
List NL Apps endpoint - lists all apps with natural language definitions.
"""
from fastapi import APIRouter, Request
from pydantic import BaseModel
from typing import Dict, Any
from pathlib import Path
import sys

# Add parent directory to path to import the generator
sys.path.insert(0, str(Path(__file__).parent.parent))
from nl_app_generator import NLAppGenerator

# Import the new universal authentication helper
try:
    from src.aurica_auth import protected, get_current_user
except ImportError:
    # Fallback if running in different context
    print("⚠️  Warning: Could not import universal_auth, authentication may not work")
    def auth_required(func):
        return func
    def get_current_user(request, required=True):
        return {"username": "unknown", "user_id": "unknown"}

router = APIRouter()


class NLAppInfo(BaseModel):
    """Information about a natural language app."""
    title: str
    description: str
    endpoints_count: int
    has_ui: bool
    nl_file: str


class NLAppsResponse(BaseModel):
    """Response model for listing NL apps."""
    nl_apps: Dict[str, NLAppInfo]
    total: int


@router.get("/", response_model=NLAppsResponse, summary="List all NL apps", tags=["generator"])
@protected
async def list_nl_apps(request: Request):
    """
    Get a list of all apps that have natural language definitions.
    
    Returns:
        NLAppsResponse with dictionary of apps that have app.nl.json files
    """
    user = get_current_user(request)
    print(f"📋 User {user.username} listing NL apps")
    
    # Initialize the NL generator
    apps_dir = Path(__file__).parent.parent.parent.parent / "apps"
    nl_generator = NLAppGenerator(apps_dir)
    
    nl_apps = await nl_generator.discover_nl_apps()
    
    apps_info = {}
    for app_name in nl_apps:
        nl_config = await nl_generator.load_nl_config(app_name)
        if nl_config:
            apps_info[app_name] = NLAppInfo(
                title=nl_config.get("title", app_name),
                description=nl_config.get("description", ""),
                endpoints_count=len(nl_config.get("endpoints", [])),
                has_ui=nl_config.get("generate_ui", False),
                nl_file=f"apps/{app_name}/app.nl.json"
            )
    
    return NLAppsResponse(
        nl_apps=apps_info,
        total=len(nl_apps)
    )

# Pipeline Registry Example


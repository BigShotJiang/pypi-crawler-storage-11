"""
Executor configuration DTOs.

This module defines the configuration classes for the Executor service,
including validation and default values.
"""

from typing import Optional, Dict, Any
from pydantic import BaseModel, Field, validator
from pathlib import Path
import os
from utils.platform import resolve_library_paths, resolve_library_path, get_executable_extension, get_platform_info

# Get platform-specific paths
platform_paths = resolve_library_paths()
platform_info = get_platform_info()


class ExecutorConfig(BaseModel):
    """Configuration for the Executor service."""
    
    # Required paths with platform-specific defaults
    # Use shared REGISTRY_BASE_PATH if set; otherwise platform defaults to executor-specific base
    base_path: str = Field(
        default=os.getenv("REGISTRY_BASE_PATH", ("C\\\\opt\\\\executor" if get_platform_info().os.value == "windows" else "/opt/executor")),
        description="Base path for executor operations"
    )
    bridge_lib_path: str = Field(default=platform_paths['bridge_lib_path'], description="Path to the executor bridge library")
    
    # Optional paths with platform-specific defaults
    executor_path: Optional[str] = Field(
        default=platform_paths['executor_path'] + get_executable_extension(), 
        description="Path to executor CLI binary"
    )
    working_directory: Optional[str] = Field(
        default=os.getcwd(),
        description="Default working directory"
    )
    log_directory: Optional[str] = Field(
        default=os.getenv("REGISTRY_LOG_DIR", platform_paths['log_directory']),
        description="Default log directory"
    )
    
    # Execution options
    timeout: int = Field(
        default=300,
        ge=1,
        description="Default timeout in seconds"
    )
    debug: bool = Field(
        default=False,
        description="Enable debug logging"
    )
    pretty: bool = Field(
        default=False,
        description="Enable pretty printing"
    )
    use_ffi: bool = Field(
        default=True,
        description="Use FFI bridge instead of CLI"
    )
    
    # Bridge configuration
    bridge_lib_key: str = Field(
        default="executor_bridge",
        description="FFI bridge library key"
    )
    
    class Config:
        validate_by_name = True
        extra = "forbid"
    
    @validator('base_path')
    def validate_base_path(cls, v):
        """Ensure base path exists; if creation fails, fall back to project-local tmp path."""
        p = Path(v).absolute()
        try:
            p.mkdir(parents=True, exist_ok=True)
            return str(p)
        except Exception:
            fallback = Path(os.getcwd()) / 'tmp' / 'executor'
            fallback.mkdir(parents=True, exist_ok=True)
            return str(fallback.absolute())
    
    @validator('bridge_lib_path')
    def validate_bridge_lib_path(cls, v):
        """Validate bridge library path exists."""
        # Try to resolve library path if not found
        if not Path(v).exists():
            resolved_path = resolve_library_path('executor_bridge')
            if resolved_path:
                return resolved_path
        return str(Path(v).absolute())
    
    @validator('executor_path')
    def validate_executor_path(cls, v):
        """Validate executor path if provided."""
        if v is not None:
            # Try to resolve executor path if not found
            if not Path(v).exists():
                resolved_path = resolve_library_path('executor_cli')
                if resolved_path:
                    return resolved_path
            return str(Path(v).absolute())
        return v
    
    def model_dump_for_bridge(self) -> Dict[str, Any]:
        """Get configuration data suitable for bridge operations."""
        return {
            "basePath": self.base_path,
            "executorPath": self.executor_path,
            "workingDirectory": self.working_directory,
            "logDirectory": self.log_directory,
            "timeout": self.timeout,
            "debug": self.debug,
            "pretty": self.pretty,
            "useFfi": self.use_ffi,
            "bridgeLibPath": self.bridge_lib_path,
            "bridgeLibKey": self.bridge_lib_key
        }
"""
Custom logger for Pipeline Registry operations.

This module provides a debug-aware logger that can be controlled
by the debug configuration flag.
"""

import logging
from typing import Dict, Any


class DebugAwareLogger:
    """Logger that respects debug configuration."""
    
    def __init__(self, debug: bool = False):
        """
        Initialize the logger.
        
        Args:
            debug: Whether to enable debug logging
        """
        self._debug = debug
        self._logger = logging.getLogger(__name__)
        
        if debug:
            self._logger.setLevel(logging.DEBUG)
            if not self._logger.handlers:
                handler = logging.StreamHandler()
                formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')
                handler.setFormatter(formatter)
                self._logger.addHandler(handler)
        else:
            self._logger.setLevel(logging.CRITICAL)  # Suppress all logs
    
    def debug(self, message: str, extra: Dict[str, Any] = None) -> None:
        """Log debug message."""
        if self._debug:
            if extra:
                self._logger.debug(f"{message} {extra}")
            else:
                self._logger.debug(message)
    
    def info(self, message: str, extra: Dict[str, Any] = None) -> None:
        """Log info message."""
        if self._debug:
            if extra:
                self._logger.info(f"{message} {extra}")
            else:
                self._logger.info(message)
    
    def warning(self, message: str, extra: Dict[str, Any] = None) -> None:
        """Log warning message."""
        if self._debug:
            if extra:
                self._logger.warning(f"{message} {extra}")
            else:
                self._logger.warning(message)
    
    def error(self, message: str, extra: Dict[str, Any] = None) -> None:
        """Log error message."""
        if self._debug:
            if extra:
                self._logger.error(f"{message} {extra}")
            else:
                self._logger.error(message)


def create_logger(debug: bool = False) -> DebugAwareLogger:
    """
    Create a debug-aware logger.
    
    Args:
        debug: Whether to enable debug logging
        
    Returns:
        DebugAwareLogger instance
    """
    return DebugAwareLogger(debug)

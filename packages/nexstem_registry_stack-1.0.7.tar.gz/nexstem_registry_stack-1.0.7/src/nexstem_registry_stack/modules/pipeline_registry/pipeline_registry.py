"""
Pipeline Registry service implementation.

This module provides the main PipelineRegistry class for managing pipelines
in the SW Registry Stack.
"""

import asyncio
from typing import Optional, Union, Dict, Any, overload
from .dto import (
    PipelineRegistryConfig,
    PipelineListOptions,
    PipelineInfoOptions,
    PipelinePushOptions,
    PipelinePullOptions,
    PipelineRemoveOptions,
    PipelineStatusOptions,
    LocalPipelineListResponse,
    RemotePipelineListResponse,
    RemotePipelineVersionsResponse,
    PipelineListResponse,
    PipelineInfoResponse,
    PipelinePushResponse,
    PipelinePullResponse,
    PipelineRemoveResponse,
    PipelineStatusResponse,
    Pipeline,
    PipelineInfo,
    PipelineInstallData,
    PipelineRemoveData,
    PipelinePushData,
    PipelinePullData,
    PipelineStatusData,
)
from .bridge import PipelineRegistryBridge
from exceptions import (
    SdkError,
    ValidationError,
    FfiBridgeError,
    ConfigurationError,
)
from shared.dto.common import ResponseStatus
from .utils.logger import create_logger


class PipelineRegistry:
    """Main Pipeline Registry service class."""
    
    def __init__(self, config: Union[PipelineRegistryConfig, Dict[str, Any]]):
        """
        Initialize the Pipeline Registry.
        
        Args:
            config: Configuration for the Pipeline Registry
            
        Raises:
            ConfigurationError: If configuration is invalid
        """
        try:
            if isinstance(config, dict):
                self.config = PipelineRegistryConfig(**config)
            else:
                self.config = config
                
            self.bridge = PipelineRegistryBridge(self.config.bridge_lib_path)
            self.logger = create_logger(self.config.debug)
            self._is_initialized = False
            
        except Exception as e:
            raise ConfigurationError(f"Failed to initialize Pipeline Registry: {e}")
    
    async def initialize(self) -> None:
        """
        Initialize the Pipeline Registry bridge.
        
        Raises:
            FfiBridgeError: If bridge initialization fails
        """
        try:
            self.bridge.load()
            self._is_initialized = True
        except Exception as e:
            raise FfiBridgeError(f"Failed to initialize Pipeline Registry bridge: {e}")
    
    async def close(self) -> None:
        """
        Close the Pipeline Registry bridge.
        
        Raises:
            FfiBridgeError: If bridge cleanup fails
        """
        try:
            if self._is_initialized:
                self.bridge.unload()
                self._is_initialized = False
        except Exception as e:
            raise FfiBridgeError(f"Failed to close Pipeline Registry bridge: {e}")
    
    @overload
    async def list(
        self, 
        options: Optional[PipelineListOptions] = None
    ) -> LocalPipelineListResponse: ...

    @overload
    async def list(
        self, 
        options: PipelineListOptions
    ) -> Union[RemotePipelineListResponse, RemotePipelineVersionsResponse]: ...

    async def list(
        self, 
        options: Optional[PipelineListOptions] = None
    ) -> Union[LocalPipelineListResponse, RemotePipelineListResponse, RemotePipelineVersionsResponse]:
        """
        List pipelines.
        
        Args:
            options: Options for listing pipelines
            
        Returns:
            Pipeline list response
            
        Raises:
            ValidationError: If validation fails
            FfiBridgeError: If bridge operation fails
        """
        if not self._is_initialized:
            await self.initialize()
        
        try:
            if options is None:
                options = PipelineListOptions()
            
            # Validate options
            if options.page and options.page < 1:
                raise ValidationError("Page must be >= 1")
            if options.page_size and options.page_size < 1:
                raise ValidationError("Page size must be >= 1")
            
            self.logger.debug("PipelineRegistry.list: start", {
                "base_path": self.config.base_path,
                "options": options.dict() if hasattr(options, 'dict') else options
            })
            
            # Call bridge
            if options.remote or options.pipeline or options.versions or options.page or options.page_size:
                result = await self.bridge.list_pipelines_with_options(
                    base_path=self.config.base_path,
                    remote=options.remote or False,
                    page=options.page or 1,
                    page_size=options.page_size or 10,
                    pipeline_id=options.pipeline,
                    versions=options.versions or False
                )
            else:
                result = await self.bridge.list_pipelines(self.config.base_path)
            
            # Parse response based on options
            if result.get("status") == "success":
                data = result.get("data", {})
                
                # Determine response type based on options
                if options.remote and options.versions and options.pipeline:
                    # Remote versions response
                    from .dto.responses import RemotePipelineVersionsData
                    versions = data.get("versions", [])
                    count = data.get("count", len(versions))
                    response_data = RemotePipelineVersionsData(count=count, versions=versions)
                    return RemotePipelineVersionsResponse(
                        data=response_data,
                        error=None,
                        message=result.get("message", "Pipeline versions listed successfully"),
                        status="success"
                    )
                elif options.remote:
                    # Remote list response
                    from .dto.responses import RemotePipelineListData
                    pipelines = data.get("pipelines", [])
                    count = data.get("count", len(pipelines))
                    response_data = RemotePipelineListData(count=count, pipelines=pipelines)
                    return RemotePipelineListResponse(
                        data=response_data,
                        error=None,
                        message=result.get("message", "Pipelines listed successfully"),
                        status="success"
                    )
                else:
                    # Local list response
                    from .dto.responses import LocalPipelineListData
                    # Handle the case where count might not be in the response
                    pipelines = data.get("pipelines", [])
                    count = data.get("count", len(pipelines))
                    response_data = LocalPipelineListData(count=count, pipelines=pipelines)
                    return LocalPipelineListResponse(
                        data=response_data,
                        error=None,
                        message=result.get("message", "Pipelines listed successfully"),
                        status="success"
                    )
            else:
                # Error response
                from .dto.responses import LocalPipelineListData
                return LocalPipelineListResponse(
                    data=LocalPipelineListData(count=0, pipelines=[]),
                    error=result.get("error"),
                    message=result.get("message", "Failed to list pipelines"),
                    status="error"
                )
                
        except ValidationError:
            raise
        except Exception as e:
            self.logger.error("PipelineRegistry.list: error", {
                "base_path": self.config.base_path,
                "options": options.dict() if hasattr(options, 'dict') else options,
                "error": str(e)
            })
            raise FfiBridgeError(f"Pipeline list operation failed: {e}")
    
    @overload
    async def info(
        self,
        name: str,
        version: str,
        options: Optional[PipelineInfoOptions] = None
    ) -> PipelineInfoResponse:
        """Get pipeline information using separate name and version parameters."""
        ...

    @overload
    async def info(
        self,
        pipeline_id_version: str,
        options: Optional[PipelineInfoOptions] = None
    ) -> PipelineInfoResponse:
        """Get pipeline information using name@version format."""
        ...

    async def info(
        self,
        arg1: str,
        arg2: Optional[str] = None,
        options: Optional[PipelineInfoOptions] = None
    ) -> PipelineInfoResponse:
        """
        Get pipeline information.
        
        Args:
            arg1: Pipeline name@version or pipeline name
            arg2: Pipeline version (if arg1 is name) or options (if arg1 is name@version)
            options: Info options (only used when arg1 is name@version)
            
        Returns:
            Pipeline info response
            
        Raises:
            ValidationError: If validation fails
            FfiBridgeError: If bridge operation fails
        """
        if not self._is_initialized:
            await self.initialize()
        
        try:
            if options is None:
                options = PipelineInfoOptions()
            
            # Determine calling pattern
            if arg2 is None or isinstance(arg2, dict):
                # Combined format: info(name@version, options?)
                pipeline_id_version = arg1
                if '@' not in pipeline_id_version:
                    raise ValidationError(
                        "Invalid name@version format",
                        field="pipeline_id_version",
                        value=pipeline_id_version
                    )
                info_options = arg2 if isinstance(arg2, dict) else options
            else:
                # Separate format: info(name, version, options?)
                pipeline_id_version = f"{arg1}@{arg2}"
                info_options = options
            
            # Validate options
            if info_options.extend and not info_options.remote:
                raise ValidationError("Extend option requires remote to be true")
            
            self.logger.debug("PipelineRegistry.info: start", {
                "base_path": self.config.base_path,
                "pipeline_id_version": pipeline_id_version,
                "options": info_options.dict() if hasattr(info_options, 'dict') else info_options
            })
            
            # Parse pipeline ID and version
            pipeline_id, version = pipeline_id_version.split("@", 1)
            if not pipeline_id or not version:
                raise ValidationError("Pipeline ID and version cannot be empty")
            
            # Call bridge
            result = await self.bridge.get_pipeline_info(
                base_path=self.config.base_path,
                pipeline_id=pipeline_id,
                version=version,
                remote=info_options.remote or False,
                extend=info_options.extend or False
            )
            
            # Parse response
            if result.get("status") == "success":
                data = PipelineInfo(**result.get("data", {}))
                return PipelineInfoResponse(
                    data=data,
                    error=None,
                    message=result.get("message", "Pipeline info retrieved successfully"),
                    status="success"
                )
            else:
                return PipelineInfoResponse(
                    data=None,
                    error=result.get("error"),
                    message=result.get("message", "Failed to get pipeline info"),
                    status="error"
                )
                
        except ValidationError:
            raise
        except Exception as e:
            self.logger.error("PipelineRegistry.info: error", {
                "base_path": self.config.base_path,
                "pipeline_id_version": pipeline_id_version if 'pipeline_id_version' in locals() else arg1,
                "options": info_options.dict() if hasattr(info_options, 'dict') else info_options if 'info_options' in locals() else options,
                "error": str(e)
            })
            raise FfiBridgeError(f"Pipeline info operation failed: {e}")
    
    @overload
    async def install(
        self,
        name: str,
        version: str,
        options: Optional[PipelinePullOptions] = None
    ) -> PipelinePullResponse:
        """Install (pull) a pipeline using separate name and version parameters."""
        ...

    @overload
    async def install(
        self,
        pipeline_id_version: str,
        options: Optional[PipelinePullOptions] = None
    ) -> PipelinePullResponse:
        """Install (pull) a pipeline using name@version format."""
        ...

    async def install(
        self,
        arg1: str,
        arg2: Optional[str] = None,
        options: Optional[PipelinePullOptions] = None
    ) -> PipelinePullResponse:
        """
        Install (pull) a pipeline.
        
        Args:
            arg1: Pipeline name@version or pipeline name
            arg2: Pipeline version (if arg1 is name) or options (if arg1 is name@version)
            options: Install options (only used when arg1 is name@version)
            
        Returns:
            Pipeline install response
            
        Raises:
            ValidationError: If validation fails
            FfiBridgeError: If bridge operation fails
        """
        if not self._is_initialized:
            await self.initialize()
        
        try:
            if options is None:
                options = PipelinePullOptions()
            
            # Determine calling pattern
            if arg2 is None or isinstance(arg2, dict):
                # Combined format: install(name@version, options?)
                pipeline_id_version = arg1
                if '@' not in pipeline_id_version:
                    raise ValidationError(
                        "Invalid name@version format",
                        field="pipeline_id_version",
                        value=pipeline_id_version
                    )
                install_options = arg2 if isinstance(arg2, dict) else options
            else:
                # Separate format: install(name, version, options?)
                pipeline_id_version = f"{arg1}@{arg2}"
                install_options = options
            
            # Parse pipeline ID and version
            pipeline_id, version = pipeline_id_version.split("@", 1)
            if not pipeline_id or not version:
                raise ValidationError("Pipeline ID and version cannot be empty")
            
            self.logger.debug("PipelineRegistry.install: start", {
                "base_path": self.config.base_path,
                "pipeline_id_version": pipeline_id_version,
                "options": install_options.dict() if hasattr(install_options, 'dict') else install_options
            })
            
            # Call bridge
            result = await self.bridge.install_pipeline(
                base_path=self.config.base_path,
                pipeline_id=pipeline_id,
                version=version,
                force=install_options.force or False
            )
            
            # Parse response
            if result.get("status") == "success":
                data = PipelinePullData(**result.get("data", {}))
                return PipelinePullResponse(
                    data=data,
                    error=None,
                    message=result.get("message", "Pipeline installed successfully"),
                    status="success"
                )
            else:
                # Handle error case - data might be None or empty
                data_dict = result.get("data", {})
                if data_dict:
                    data = PipelinePullData(**data_dict)
                else:
                    data = None
                
                return PipelinePullResponse(
                    data=data,
                    error=result.get("error"),
                    message=result.get("message", "Failed to install pipeline"),
                    status="error"
                )
                
        except ValidationError:
            raise
        except Exception as e:
            self.logger.error("PipelineRegistry.install: error", {
                "base_path": self.config.base_path,
                "pipeline_id_version": pipeline_id_version if 'pipeline_id_version' in locals() else arg1,
                "options": install_options.dict() if hasattr(install_options, 'dict') else install_options if 'install_options' in locals() else options,
                "error": str(e)
            })
            raise FfiBridgeError(f"Pipeline install operation failed: {e}")
    
    @overload
    async def remove(
        self,
        name: str,
        version: str,
        options: Optional[PipelineRemoveOptions] = None
    ) -> PipelineRemoveResponse:
        """Remove a pipeline using separate name and version parameters."""
        ...

    @overload
    async def remove(
        self,
        pipeline_id_version: str,
        options: Optional[PipelineRemoveOptions] = None
    ) -> PipelineRemoveResponse:
        """Remove a pipeline using name@version format."""
        ...

    async def remove(
        self,
        arg1: str,
        arg2: Optional[str] = None,
        options: Optional[PipelineRemoveOptions] = None
    ) -> PipelineRemoveResponse:
        """
        Remove a pipeline.
        
        Args:
            pipeline_id_version: Pipeline ID and version in format "id@version"
            options: Options for removing pipeline
            
        Returns:
            Pipeline remove response
            
        Raises:
            ValidationError: If validation fails
            FfiBridgeError: If bridge operation fails
        """
        if not self._is_initialized:
            await self.initialize()
        
        try:
            if options is None:
                options = PipelineRemoveOptions()
            
            # Determine calling pattern
            if arg2 is None or isinstance(arg2, dict):
                # Combined format: remove(name@version, options?)
                pipeline_id_version = arg1
                if '@' not in pipeline_id_version:
                    raise ValidationError(
                        "Invalid name@version format",
                        field="pipeline_id_version",
                        value=pipeline_id_version
                    )
                remove_options = arg2 if isinstance(arg2, dict) else options
            else:
                # Separate format: remove(name, version, options?)
                pipeline_id_version = f"{arg1}@{arg2}"
                remove_options = options
            
            # Parse pipeline ID and version
            pipeline_id, version = pipeline_id_version.split("@", 1)
            if not pipeline_id or not version:
                raise ValidationError("Pipeline ID and version cannot be empty")
            
            self.logger.debug("PipelineRegistry.remove: start", {
                "base_path": self.config.base_path,
                "pipeline_id_version": pipeline_id_version,
                "options": remove_options.dict() if hasattr(remove_options, 'dict') else remove_options
            })
            
            # Call bridge
            result = await self.bridge.uninstall_pipeline(
                base_path=self.config.base_path,
                pipeline_id=pipeline_id,
                version=version
            )
            
            # Parse response
            if result.get("status") == "success":
                data = PipelineRemoveData(**result.get("data", {}))
                return PipelineRemoveResponse(
                    data=data,
                    error=None,
                    message=result.get("message", "Pipeline removed successfully"),
                    status="success"
                )
            else:
                # Handle error case - data might be None or empty
                data_dict = result.get("data", {})
                if data_dict:
                    data = PipelineRemoveData(**data_dict)
                else:
                    data = None
                
                return PipelineRemoveResponse(
                    data=data,
                    error=result.get("error"),
                    message=result.get("message", "Failed to remove pipeline"),
                    status="error"
                )
                
        except ValidationError:
            raise
        except Exception as e:
            self.logger.error("PipelineRegistry.remove: error", {
                "base_path": self.config.base_path,
                "pipeline_id_version": pipeline_id_version if 'pipeline_id_version' in locals() else arg1,
                "options": remove_options.dict() if hasattr(remove_options, 'dict') else remove_options if 'remove_options' in locals() else options,
                "error": str(e)
            })
            raise FfiBridgeError(f"Pipeline remove operation failed: {e}")
    
    # async def push(
    #     self,
    #     pipeline_id_version: str,
    #     tar_path: str,
    #     options: Optional[PipelinePushOptions] = None
    # ) -> PipelinePushResponse:
    #     """
    #     Push a pipeline.
    #     
    #     Args:
    #         pipeline_id_version: Pipeline ID and version in format "id@version"
    #         tar_path: Path to the pipeline tar file
    #         options: Options for pushing pipeline
    #         
    #     Returns:
    #         Pipeline push response
    #         
    #     Raises:
    #         ValidationError: If validation fails
    #         FfiBridgeError: If bridge operation fails
    #     """
    #     if not self._is_initialized:
    #         await self.initialize()
    #     
    #     try:
    #         if options is None:
    #             options = PipelinePushOptions()
    #         
    #         # Parse pipeline ID and version
    #         if "@" not in pipeline_id_version:
    #             raise ValidationError("Pipeline ID must be in format 'id@version'")
    #         
    #         pipeline_id, version = pipeline_id_version.split("@", 1)
    #         if not pipeline_id or not version:
    #             raise ValidationError("Pipeline ID and version cannot be empty")
    #         
    #         if not tar_path:
    #             raise ValidationError("Tar path cannot be empty")
    #         
    #         # Call bridge
    #         result = await self.bridge.push_pipeline(
    #             base_path=self.config.base_path,
    #             pipeline_id=pipeline_id,
    #             version=version,
    #             tar_path=tar_path,
    #             local_only=options.local or False
    #         )
    #         
    #         # Parse response
    #         if result.get("status") == "success":
    #             data = PipelinePushData(**result.get("data", {}))
    #             return PipelinePushResponse(
    #                 status=ResponseStatus.SUCCESS,
    #                 message=result.get("message", "Pipeline pushed successfully"),
    #                 data=data
    #             )
    #         else:
    #             return PipelinePushResponse(
    #                 status=ResponseStatus.ERROR,
    #                 message=result.get("message", "Failed to push pipeline"),
    #                 data=None,
    #                 error=result.get("error")
    #             )
    #             
    #     except ValidationError:
    #         raise
    #     except Exception as e:
    #         raise FfiBridgeError(f"Pipeline push operation failed: {e}")
    
    # async def status(self) -> PipelineStatusResponse:
    #     """
    #     Get pipeline registry status.
    #     
    #     Returns:
    #         Pipeline status response
    #         
    #     Raises:
    #         FfiBridgeError: If bridge operation fails
    #     """
    #     if not self._is_initialized:
    #         await self.initialize()
    #     
    #     try:
    #         # For now, we'll use a simple status check
    #         # This could be enhanced to check actual registry status
    #         return PipelineStatusResponse(
    #             status=ResponseStatus.SUCCESS,
    #             message="Pipeline registry is operational",
    #             data=PipelineStatusData(
    #                 id="registry",
    #                 version="1.0.0",
    #                 status="operational"
    #             )
    #         )
    #             
    #     except Exception as e:
    #         raise FfiBridgeError(f"Pipeline status operation failed: {e}")
    
    def get_config(self) -> PipelineRegistryConfig:
        """
        Get the current configuration.
        
        Returns:
            Current configuration
        """
        return self.config
    
    def update_config(self, config: Union[PipelineRegistryConfig, Dict[str, Any]]) -> None:
        """
        Update the configuration.
        
        Args:
            config: New configuration
            
        Raises:
            ConfigurationError: If configuration is invalid
        """
        try:
            if isinstance(config, dict):
                self.config = PipelineRegistryConfig(**config)
            else:
                self.config = config
        except Exception as e:
            raise ConfigurationError(f"Failed to update configuration: {e}")

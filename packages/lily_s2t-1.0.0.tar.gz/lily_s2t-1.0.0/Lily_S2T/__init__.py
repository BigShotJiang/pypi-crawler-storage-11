from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from os import getcwd

def setup_driver():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--use-fake-ui-for-media-stream")
    chrome_options.add_argument("--auto-accept-camera-microphone-capture")
    chrome_options.add_argument("--headless=new")
    
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

def listen():
    driver=None
    try:
        website=f"{getcwd()}\\index.html"
        driver=setup_driver()
        driver.get(website)

        try:
            start_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "startButton")))
        except Exception as e:
            print(f"❌ Could not find required elements: {e}")
            return
        start_button.click()
        print("Listening... Please speak into your microphone.")
        output_text=""
        is_second_click=False
        while True:
            print("Listening...",end="",flush=True)
            print( end="\r", flush=True)
            output_element= WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "output")))
            current_text=output_element.text.strip()
            if "Start Listening" in start_button.text and is_second_click:
                if output_text:
                    is_second_click=False
            elif "Listening..." in start_button.text:
                is_second_click=True
            if current_text != output_text:
                output_text=current_text
                rec_file=f"{getcwd()}\\input.txt"
                with open(rec_file, "w") as f:
                    f.write(output_text.lower())
                    print("Mr.Tanmay: "+output_text)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print("An error occurred:", e)
    finally:
        if driver:
            driver.quit()

from setuptools import setup, find_packages

setup(
    name="Lily_S2T",
    version="1.0.0",
    author="Aditya Patel",
    author_email="adityakumarpatel2416@gmail.com",
    description="A speech-to-text package using Selenium and WebDriver",
)
packages=find_packages(),
install_requirements=['selenium', 'webdriver-manager']
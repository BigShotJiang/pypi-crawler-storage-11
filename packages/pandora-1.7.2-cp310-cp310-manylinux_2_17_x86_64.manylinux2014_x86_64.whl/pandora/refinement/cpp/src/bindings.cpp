/* Copyright (c) 2025 Centre National d'Etudes Spatiales (CNES).
 *
 * This file is part of PANDORA
 *
 *     https://github.com/CNES/Pandora
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <pybind11/pybind11.h>
#include "refinement.hpp"
#include "vfit.hpp"
#include "quadratic.hpp"

namespace py = pybind11;

PYBIND11_MODULE(refinement_cpp, m) {
    m.doc() = "Refinement functions implemented in C++ with Pybind11";

    m.def(
        "loop_refinement", 
        &loop_refinement, 
        ""
    );
    
    m.def(
        "loop_approximate_refinement", 
        &loop_approximate_refinement, 
        ""
    );

    m.def(
        "vfit_refinement_method", 
        &vfit_refinement_method,
        ""
    );
    
    m.def(
        "quadratic_refinement_method", 
        &quadratic_refinement_method,
        ""
    );

}
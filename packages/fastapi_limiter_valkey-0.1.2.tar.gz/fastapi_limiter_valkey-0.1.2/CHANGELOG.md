# ChangeLog

## 0.1

### 0.1.1

Minor improvements.

"""Flash Attention installation utilities."""

import os
import sys
import platform
import subprocess


def install_fa2():
    """
    Install Flash Attention 2 from pre-built wheels.

    Automatically detects system configuration (Python version, PyTorch version,
    CUDA version, etc.) and installs the appropriate pre-built wheel from the
    flash-attention GitHub releases.

    Raises:
        ImportError: If torch is not installed
        subprocess.CalledProcessError: If pip installation fails
    """
    try:
        import torch
    except ImportError:
        raise ImportError(
            "PyTorch must be installed before installing flash-attention. "
            "Install it with: pip install torch"
        )

    # --- Step 1: Detect system info ---
    py_version = f"cp{sys.version_info.major}{sys.version_info.minor}"
    torch_version = torch.__version__.split("+")[0]  # e.g., '2.6.0'
    cuda_version = torch.version.cuda or "cpu"
    cxx11abi = "FALSE" if torch._C._GLIBCXX_USE_CXX11_ABI == 0 else "TRUE"
    system = platform.system().lower()
    arch = platform.machine()

    # --- Step 2: Normalize CUDA and torch version formatting ---
    if cuda_version != "cpu":
        # Extract only major.minor (e.g., 12.1 -> 12)
        cuda_major = cuda_version.split(".")[0]
        cuda_tag = f"cu{cuda_major}"
    else:
        cuda_tag = "cpu"

    # Use only torch major.minor (e.g., 2.6.0 -> 2.6)
    torch_tag = torch_version[:3]

    # --- Step 3: Build the wheel URL ---
    base_url = "https://github.com/Dao-AILab/flash-attention/releases/download"
    release_tag = "v2.7.4.post1"

    wheel_name = (
        f"flash_attn-2.7.4.post1+{cuda_tag}torch{torch_tag}"
        f"cxx11abi{cxx11abi}-"
        f"{py_version}-{py_version}-linux_x86_64.whl"
    )

    wheel_url = f"{base_url}/{release_tag}/{wheel_name}"

    print(f"🔥 Installing FlashAttention wheel:\n{wheel_url}\n")

    # --- Step 4: Install it ---
    env = dict(**os.environ, FLASH_ATTENTION_SKIP_CUDA_BUILD="TRUE")

    subprocess.run(
        ["pip", "install", wheel_url, "--no-build-isolation"],
        env=env,
        check=True,
    )

    print("✅ Flash Attention 2 installed successfully!")

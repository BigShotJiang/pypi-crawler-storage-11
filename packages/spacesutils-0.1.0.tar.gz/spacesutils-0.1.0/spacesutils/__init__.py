"""spacesutils - Utilities for ZeroGPU spaces on Hugging Face Spaces."""

from .flash_attention import install_fa2

__version__ = "0.1.0"
__all__ = ["install_fa2"]

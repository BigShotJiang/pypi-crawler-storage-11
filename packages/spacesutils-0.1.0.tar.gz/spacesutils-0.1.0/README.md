# spacesutils

Utilities for ZeroGPU spaces on Hugging Face Spaces.

## Installation

Just add the following to your `requirements.txt` file:

```
spacesutils
```

## Features

### Flash Attention 2 Installation

```python
from spacesutils import install_fa2

install_fa2()
```

More features coming soon...

## License

MIT License

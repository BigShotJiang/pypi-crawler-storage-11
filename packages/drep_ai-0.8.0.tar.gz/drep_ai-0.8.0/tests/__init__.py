"""Test suite for drep."""

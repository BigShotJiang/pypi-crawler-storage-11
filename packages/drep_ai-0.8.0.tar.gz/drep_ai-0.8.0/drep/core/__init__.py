"""Core business logic components."""

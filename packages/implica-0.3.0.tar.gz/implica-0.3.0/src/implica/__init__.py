"""
Guanciale - Implicational Logic Graph Library

A Python package for working with graphs representing minimal implicational
logic models. This library provides tools for constructing and manipulating
type systems based on combinatory logic, with support for transactional
graph operations.

Import as 'gil' for a clean, concise API:
    import guanciale as gil

    graph = gil.Graph()
    A = gil.var("A")
    B = gil.var("B")

    with graph.connect() as conn:
        conn.add_node(gil.node(A))
        conn.add_node(gil.node(B))
"""

from .core import *
from .graph import Node, Edge, node, edge, Graph, Connection
from . import mutations


__all__ = [
    "BaseType",
    "Variable",
    "Application",
    "var",
    "app",
    "Combinator",
    "S",
    "K",
    "Node",
    "Edge",
    "node",
    "edge",
    "Graph",
    "Connection",
    "mutations",
]

__version__ = "0.3.0"

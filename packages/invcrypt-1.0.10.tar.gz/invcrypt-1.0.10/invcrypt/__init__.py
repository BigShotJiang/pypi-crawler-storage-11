"""
InvCrypt – Quantum-safe local encryption CLI
Community Edition (Development)
"""

# Canonical identifiers
__version__="1.0.10"
__edition__ = "Community (Pub)"

# Aliases for internal references
VERSION = __version__
EDITION = __edition__

## Typing stubs for webencodings

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`webencodings`](https://github.com/gsnedders/python-webencodings) package. It can be used by type checkers
to check code that uses `webencodings`. This version of
`types-webencodings` aims to provide accurate annotations for
`webencodings==0.5.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/webencodings`](https://github.com/python/typeshed/tree/main/stubs/webencodings)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.18.2
* [pyright](https://github.com/microsoft/pyright) 1.1.407

It was generated from typeshed commit
[`b3787bc6d45b9f8c00697ca512ef37cfd4434cad`](https://github.com/python/typeshed/commit/b3787bc6d45b9f8c00697ca512ef37cfd4434cad).
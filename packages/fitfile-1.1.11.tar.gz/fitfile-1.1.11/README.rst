=======
fitfile
=======

Fit file parser.

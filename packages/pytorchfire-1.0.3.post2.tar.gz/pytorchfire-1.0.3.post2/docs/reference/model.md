# Model

::: pytorchfire.WildfireModel

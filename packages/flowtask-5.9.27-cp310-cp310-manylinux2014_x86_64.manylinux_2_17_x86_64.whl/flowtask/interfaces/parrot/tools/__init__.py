from .store import StoreInfo

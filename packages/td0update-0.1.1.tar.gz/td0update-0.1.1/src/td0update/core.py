
def td_update(v_s, reward, v_next, alpha, gamma):
    '''
    One-step TD(0) update.
    V(s) <- V(s) + alpha * (reward + gamma*V(s') - V(s))
    '''
    return v_s + alpha * (reward + gamma * v_next - v_s)

import typer
from rich.console import Console
from rich.table import Table
import keyring
from agent import get_agent
from rich.console import Console
from rich.spinner import Spinner
from time import sleep

console = Console()
app = typer.Typer(help="Mavi Companion CLI - Coding assistant with model selection & key management.")

models = [["qwen2::0.5b", "LOCAL"], ["gemini-2.5-flash", "CLOUD"]]
KEYRING_PREFIX = "MAVI_COMPANION_MODEL_"

def add_key(model: str) -> None:
    model_type = next((m[1] for m in models if m[0] == model), None)
    if model_type != "CLOUD":
        console.print(f"[yellow]No API key required for local model '{model}'.[/yellow]")
        return

    existing = keyring.get_password(f"{KEYRING_PREFIX}{model}", model)
    if existing:
        console.print(f"[red]API key for '{model}' already exists.[/red]")
        return

    key = typer.prompt(f"Enter API key for '{model}'", hide_input=True)
    if key:
        keyring.set_password(f"{KEYRING_PREFIX}{model}", model, key)
        console.print(f"[green]Saved API key for '{model}'.[/green]")
    else:
        console.print("[red]No key entered. Nothing saved.[/red]")


def get_key(model: str) -> str | None:
    model_type = next((m[1] for m in models if m[0] == model), None)
    if model_type != "CLOUD":
        return None
    return keyring.get_password(f"{KEYRING_PREFIX}{model}", model)


def delete_key(model: str) -> None:
    model_type = next((m[1] for m in models if m[0] == model), None)
    if model_type != "CLOUD":
        console.print(f"[yellow]No API key stored for local model '{model}'.[/yellow]")
        return

    try:
        keyring.delete_password(f"{KEYRING_PREFIX}{model}", model)
        console.print(f"[green]Deleted API key for '{model}'.[/green]")
    except keyring.errors.PasswordDeleteError:
        console.print(f"[red]No API key found for '{model}'.[/red]")


def select_model() -> str:
    console.print("\n[bold cyan]Available Models:[/bold cyan]")
    for idx, (name, mtype) in enumerate(models, start=1):
        console.print(f"{idx}. {name} [{mtype}]")

    while True:
        choice = typer.prompt("Select a model by number or name", default=models[0][0])
        if choice.isdigit() and 1 <= int(choice) <= len(models):
            return models[int(choice) - 1][0]
        elif choice in [m[0] for m in models]:
            return choice
        else:
            console.print("[red]Invalid choice. Try again.[/red]")

@app.command(help="Start an interactive coding assistant session.")
def chat():
    console.print('''
███╗   ███╗ █████╗ ██╗   ██╗██╗                                             
████╗ ████║██╔══██╗██║   ██║██║                                             
██╔████╔██║███████║██║   ██║██║                                             
██║╚██╔╝██║██╔══██║╚██╗ ██╔╝██║                                             
██║ ╚═╝ ██║██║  ██║ ╚████╔╝ ██║                                             
╚═╝     ╚═╝╚═╝  ╚═╝  ╚═══╝  ╚═╝                                             
    ''')

    agent = None
    model = None
    while not agent:
        model = select_model()
        console.print(f"\n[bold cyan]Initializing model:[/bold cyan] {model}\n")
        agent = get_agent(model)
        if not agent:
            console.print(f"[red]Failed to initialize model '{model}'. Try again.[/red]")

    console.print(f"[green]Model '{model}' is ready![/green]")
    console.print("Type '--model' anytime to switch models.")
    console.print("Type 'exit' or 'quit' to leave.\n")

    messages = []

    while True:
        user_input = typer.prompt("You")

        if user_input.lower() in ["exit", "quit"]:
            console.print('\n[bold red]Goodbye![/bold red]')
            break

        if user_input.strip().lower() == "--model":
            agent = None
            while not agent:
                model = select_model()
                console.print(f"\n[bold cyan]Reinitializing model:[/bold cyan] {model}\n")
                agent = get_agent(model)
                if not agent:
                    console.print(f"[red]Failed to initialize model '{model}'. Try again.[/red]")
            console.print(f"[green]Switched to model '{model}'.[/green]\n")
            continue

        messages.append({"role": "user", "content": user_input})

        payload = {"messages": messages}

        assistant_response = ""

        try:
            with console.status("[bold blue]Bot is thinking...[/bold blue]", spinner="dots"):
                response = agent.invoke(payload)
                latest_msg = response["messages"][-1]
                assistant_response = getattr(latest_msg, "content", None) if hasattr(latest_msg, "content") else latest_msg.get("content", "")

            console.print(f"[bold blue]Bot:[/bold blue] {assistant_response}\n")

            if assistant_response:
                messages.append({"role": "assistant", "content": assistant_response})

        except Exception as e:
            console.print(f"[red]Error:[/red] {e}\n")


@app.command(help="Manage API keys for cloud models.")
def keys(
    set_key: bool = typer.Option(False, "--set", help="Set an API key"),
    delete: bool = typer.Option(False, "--delete", help="Delete an API key"),
):
    if set_key:
        console.print("Available cloud models:\n")
        for name, mtype in models:
            if mtype == "CLOUD":
                console.print(f"- {name}")
        model = typer.prompt("Enter model name")
        add_key(model)
        raise typer.Exit()

    if delete:
        console.print("Available cloud models:\n")
        for name, mtype in models:
            if mtype == "CLOUD":
                console.print(f"- {name}")
        model = typer.prompt("Enter model name")
        delete_key(model)
        raise typer.Exit()

    table = Table(title="Model API Key Status", show_lines=True)
    table.add_column("Model", style="bold cyan")
    table.add_column("Type", style="magenta")
    table.add_column("Key Status", style="yellow")

    for name, mtype in models:
        key = get_key(name)
        status = "[green]Available[/green]" if key else "[red]Missing[/red]"
        table.add_row(name, mtype, status)

    console.print(table)


@app.command(help="Ask a single coding question directly.")
def ask(query: str):
    agent = None
    model = None

    while not agent:
        model = select_model()
        console.print(f"\n[bold cyan]Initializing model:[/bold cyan] {model}\n")
        agent = get_agent(model)
        if not agent:
            console.print(f"[red]Failed to initialize model '{model}'. Try again.[/red]")

    try:
        payload = {"messages": [{"role": "user", "content": query}]}
        response = agent.invoke(payload)
        output = str(response["messages"][-1].content if isinstance(response, dict) else response)
        console.print(f"[bold blue]Bot:[/bold blue] {output}")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")


if __name__ == "__main__":
    app()

.. -*- mode: rst -*-

.. |PyPI version| image:: https://badge.fury.io/py/chainladder.svg
   :target: https://badge.fury.io/py/chainladder

.. |Build Status| image:: https://github.com/casact/chainladder-python/workflows/Unit%20Tests/badge.svg

.. |Documentation Status| image:: https://readthedocs.org/projects/chainladder-python/badge/?version=latest
   :target: https://chainladder-python.readthedocs.io/en/latest/?badge=latest

.. |codecov io| image:: https://codecov.io/gh/casact/chainladder-python/branch/master/graphs/badge.svg
   :target: https://codecov.io/github/casact/chainladder-python?branch=latest

chainladder (python)
====================

|PyPI version| |Build Status| |codecov io| |Documentation Status|

chainladder: Property and Casualty Loss Reserving in Python
------------------------------------------------------------

Welcome! The chainladder package was built to be able to handle all of your actuarial needs in python. It consists of popular actuarial tools, such as triangle data manipulation, link ratios calculation, and IBNR estimates with both deterministic and stochastic models. We build this package so you no longer have to rely on outdated softwares and tools when performing actuarial pricing or reserving indications.

This package strives to be minimalistic in needing its own API. The syntax mimics popular packages `pandas`_ for data manipulation and `scikit-learn`_ for model
construction. An actuary that is already familiar with these tools will be able to pick up this package with ease. You will be able to save your mental energy for actual actuarial work.

Chainladder is built by a group of volunteers, and we need YOUR help!

This package is written in Python, if you are looking for a similar package written in R, please visit `chainladder`_.

.. _pandas: https://pandas.pydata.org/
.. _scikit-learn: https://scikit-learn.org/stable/
.. _chainladder: https://github.com/mages/ChainLadder


Dedicated Documentation Site
----------------------------

We have a dedicated documentation website, where you can find installation instructions, tutorials, example galleries, sample datasets,  API references, change log history, and more.

Visit `Chainladder-Python on Read the Docs`_.

.. _Chainladder-Python on Read the Docs: https://chainladder-python.readthedocs.io/

Contributors Working Group
----------------------------

We also have a Contributors Working Group that meets approximately every two weeks for one hour. The current meeting time is **Fridays from 9:00–10:00 AM PT / 12:00–1:00 PM ET**. During these meetings, we discuss milestones, package design philosophies, outstanding issues, and other behind-the-scenes topics related to our work on GitHub. If you're interested in joining, please contact one of the core developers. We welcome contributors of all skill levels and encourage your involvement.

Licenses
-------------------
This package is released under `Mozilla Public License 2.0`_.

.. _Mozilla Public License 2.0: https://github.com/casact/chainladder-python/blob/master/LICENSE

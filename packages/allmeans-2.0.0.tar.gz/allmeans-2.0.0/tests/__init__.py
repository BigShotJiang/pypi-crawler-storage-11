"""Tests for AllMeans."""

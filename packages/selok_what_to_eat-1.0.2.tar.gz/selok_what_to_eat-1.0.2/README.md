# Meal Suggestions CLI

This project provides a command-line interface (CLI) tool that suggests meals based on predefined options. It is designed to help users decide what to eat easily.

## Installation

To install the package, you can use pip. Clone the repository and run the following command:

```bash
pip install .
```

Alternatively, you can install it directly from PyPI (once published):

```bash
pip install what-to-eat
```

## Usage

After installation, you can use the command `what-to-eat` in your terminal to get meal suggestions. 

```bash
what-to-eat
```

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue for any suggestions or improvements.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.
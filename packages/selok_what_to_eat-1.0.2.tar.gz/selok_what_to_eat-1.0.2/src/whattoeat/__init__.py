"""
This file initializes the whattoeat package.
"""

__version__ = "1.0.2"

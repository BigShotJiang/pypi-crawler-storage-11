def main():
    meal_suggestions = [
        "Spaghetti Bolognese",
        "Chicken Caesar Salad",
        "Vegetable Stir Fry",
        "Tacos",
        "Grilled Salmon with Asparagus",
        "Mushroom Risotto",
        "Beef Tacos",
        "Quinoa Salad",
        "Pasta Primavera",
        "Stuffed Bell Peppers"
    ]
    
    import random
    suggestion = random.choice(meal_suggestions)
    print(f"How about: {suggestion}")

if __name__ == "__main__":
    main()
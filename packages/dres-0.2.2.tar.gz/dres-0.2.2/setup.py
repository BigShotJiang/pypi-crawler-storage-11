import setuptools

# Read the long description from the README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    # --- Core Package Information ---
    name="DRES",
    version="0.2.2",
    author="Danish",
    author_email="askthedanish@gmail.com",
    # --- Descriptions ---
    # A short, one-sentence description of the package
    description="A pure-Python hybrid cryptosystem featuring a novel Evolving-Key Chaining (EKC) mode.",
    # The long description read from the README.md file
    long_description=long_description,
    long_description_content_type="text/markdown",
    # --- Project Links ---
    # The main project homepage URL
    url="https://github.com/1Danish-00/",  # IMPORTANT: I've assumed a repo name. Change if needed.
    # NEW: Add a dictionary of other useful project URLs.
    # This adds professional-looking links to your PyPI sidebar.
    # project_urls={
    #     "Bug Tracker": "https://github.com/1Danish-00/DRES/issues",
    #     "Source Code": "https://github.com/1Danish-00/DRES",
    # },
    # --- Discoverability ---
    # NEW: Add keywords to help users find your package on PyPI.
    keywords=[
        "cryptography",
        "encryption",
        "security",
        "hybrid encryption",
        "aes",
        "diffie-hellman",
        "hmac",
        "hkdf",
        "pure-python",
        "ekc",
        "aes-ekc",
    ],
    # --- Packaging ---
    # Automatically find all packages in the directory
    packages=setuptools.find_packages(),
    # --- Metadata (Classifiers) ---
    # A list of classifiers to categorize the project on PyPI
    # See: https://pypi.org/classifiers/
    classifiers=[
        # Maturity
        "Development Status :: 4 - Beta",
        # Audience
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Intended Audience :: Science/Research",
        # Topics
        "Topic :: Security :: Cryptography",
        "Topic :: Education",
        # License
        "License :: OSI Approved :: MIT License",
        # Python version support
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        # OS
        "Operating System :: OS Independent",
    ],
    # --- Dependencies ---
    # The minimum version of Python required
    python_requires=">=3.6",
    # If you had external dependencies, you would add them here:
    # install_requires=[
    #     'requests',
    # ],
)

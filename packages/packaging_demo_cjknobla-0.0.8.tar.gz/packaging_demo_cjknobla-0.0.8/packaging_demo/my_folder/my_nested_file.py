CONSTANT = 'hello'

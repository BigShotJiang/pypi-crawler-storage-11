"""Regression tests for diagnostics bugs found in real-world usage.

Bug 1: get_diagnostics could return empty diagnostics if diagnostics_version < 0 wasn't checked
Bug 2: is_line_range_complete returned True for newly opened files with empty current_processing
"""

import pytest
import time


@pytest.mark.integration
def test_diagnostics_version_checked_in_wait_logic(clean_lsp_client, test_file_path):
    """Newly opened files should have diagnostics_version=-1 and wait for diagnostics."""
    assert test_file_path not in clean_lsp_client.opened_files

    clean_lsp_client.open_file(test_file_path)
    state = clean_lsp_client.opened_files[test_file_path]

    assert state.diagnostics_version == -1
    assert not state.complete

    diagnostics = clean_lsp_client.get_diagnostics(
        test_file_path, inactivity_timeout=10.0
    )

    state = clean_lsp_client.opened_files[test_file_path]
    assert state.diagnostics_version >= 0
    assert len(diagnostics) > 0


@pytest.mark.integration
def test_is_line_range_complete_checks_diagnostics_version(
    clean_lsp_client, test_env_dir
):
    """is_line_range_complete should return False for files without diagnostics yet."""
    test_file = "LineRangeTest.lean"
    with open(test_env_dir + test_file, "w") as f:
        f.write("theorem test : 1 = 1 := by rfl\n")

    clean_lsp_client.open_file(test_file)
    state = clean_lsp_client.opened_files[test_file]

    assert state.diagnostics_version == -1
    assert not state.is_line_range_complete(0, 10)

    clean_lsp_client.get_diagnostics(test_file, inactivity_timeout=10.0)

    assert state.is_line_range_complete(0, 10)

    clean_lsp_client.close_files([test_file])


@pytest.mark.integration
def test_fresh_file_with_line_range(clean_lsp_client, test_env_dir):
    """get_diagnostics with line range should wait on freshly opened files."""
    test_file = "RangeTest.lean"
    test_content = """
-- Line 1
-- Line 2
-- Line 3
-- Line 4
theorem test : 1 = 2 := by sorry  -- Line 5, has error
-- Line 6
"""
    with open(test_env_dir + test_file, "w") as f:
        f.write(test_content)

    assert test_file not in clean_lsp_client.opened_files

    start_time = time.time()
    diagnostics = clean_lsp_client.get_diagnostics(
        test_file, start_line=3, end_line=7, inactivity_timeout=10.0
    )
    elapsed = time.time() - start_time

    assert elapsed > 0.01, f"Returned too quickly ({elapsed:.3f}s)"
    assert len(diagnostics) > 0

    clean_lsp_client.close_files([test_file])


@pytest.mark.integration
def test_open_then_immediate_get_diagnostics_no_sleep(clean_lsp_client, test_env_dir):
    """open_file() + immediate get_diagnostics() should work without manual sleep."""
    test_file = "ImmediateTest.lean"
    with open(test_env_dir + test_file, "w") as f:
        f.write("theorem broken : 1 = 2 := by\n  sorry\n")

    clean_lsp_client.open_file(test_file)
    diagnostics = clean_lsp_client.get_diagnostics(test_file, inactivity_timeout=10.0)

    assert len(diagnostics) > 0
    assert any("sorry" in d.get("message", "").lower() for d in diagnostics)

    clean_lsp_client.close_files([test_file])


@pytest.mark.integration
def test_line_range_partial_file_processing(clean_lsp_client, test_env_dir):
    """Line range filtering should work correctly across different ranges."""
    test_file = "PartialTest.lean"
    test_content = """
-- Line 0
theorem early : 1 = 2 := by sorry  -- Line 1

-- Some space

-- Line 5
theorem middle : 1 = 2 := by sorry  -- Line 6

-- More space

-- Line 10
theorem late : 1 = 2 := by sorry  -- Line 11
"""
    with open(test_env_dir + test_file, "w") as f:
        f.write(test_content)

    clean_lsp_client.open_file(test_file)
    all_diags = clean_lsp_client.get_diagnostics(test_file, inactivity_timeout=10.0)

    early_diags = clean_lsp_client.get_diagnostics(test_file, start_line=0, end_line=3)
    middle_diags = clean_lsp_client.get_diagnostics(test_file, start_line=4, end_line=8)
    late_diags = clean_lsp_client.get_diagnostics(test_file, start_line=9, end_line=12)

    assert len(early_diags) >= 1
    assert len(middle_diags) >= 1
    assert len(late_diags) >= 1

    total_filtered = len(early_diags) + len(middle_diags) + len(late_diags)
    assert total_filtered == len(all_diags)

    clean_lsp_client.close_files([test_file])


@pytest.mark.integration
def test_diagnostics_version_tracking(clean_lsp_client, test_file_path):
    """diagnostics_version should be -1 initially and >= 0 after diagnostics arrive."""
    clean_lsp_client.open_file(test_file_path)
    clean_lsp_client.get_diagnostics(test_file_path, inactivity_timeout=10.0)

    state = clean_lsp_client.opened_files[test_file_path]
    assert state.diagnostics_version >= 0
    assert len(state.diagnostics) > 0


@pytest.mark.integration
def test_empty_file_returns_quickly(clean_lsp_client, test_env_dir):
    """Clean files should still return quickly with the fix."""
    test_file = "CleanFile.lean"
    with open(test_env_dir + test_file, "w") as f:
        f.write("-- Just a comment\n-- Another comment\n")

    start_time = time.time()
    diagnostics = clean_lsp_client.get_diagnostics(test_file, inactivity_timeout=5.0)
    elapsed = time.time() - start_time

    assert elapsed < 2.0, f"Clean file took too long: {elapsed:.3f}s"
    assert diagnostics == []

    clean_lsp_client.close_files([test_file])


@pytest.mark.integration
def test_get_diagnostics_idempotent(clean_lsp_client, test_file_path):
    """Repeated get_diagnostics calls should return cached results immediately."""
    diag1 = clean_lsp_client.get_diagnostics(test_file_path, inactivity_timeout=10.0)

    start_time = time.time()
    diag2 = clean_lsp_client.get_diagnostics(test_file_path, inactivity_timeout=10.0)
    elapsed = time.time() - start_time

    assert elapsed < 0.01, f"Cached diagnostics took too long: {elapsed:.3f}s"
    assert diag1 == diag2


@pytest.mark.integration
def test_open_ended_range_start_only(clean_lsp_client, test_env_dir):
    """start_line without end_line should filter from start_line to end of file."""
    test_file = "OpenEndedStart.lean"
    test_content = """
-- Line 0
theorem early : 1 = 2 := by sorry  -- Line 1
-- Line 2
-- Line 3
-- Line 4
theorem late : 1 = 2 := by sorry  -- Line 5
-- Line 6
"""
    with open(test_env_dir + test_file, "w") as f:
        f.write(test_content)

    clean_lsp_client.open_file(test_file)
    all_diags = clean_lsp_client.get_diagnostics(test_file, inactivity_timeout=10.0)

    # Get diagnostics from line 4 to end (should only include line 5)
    from_line_4 = clean_lsp_client.get_diagnostics(test_file, start_line=4)

    # Should have fewer diagnostics than full file
    assert len(from_line_4) < len(all_diags)
    # Should have at least the error on line 5
    assert len(from_line_4) >= 1

    clean_lsp_client.close_files([test_file])


@pytest.mark.integration
def test_open_ended_range_end_only(clean_lsp_client, test_env_dir):
    """end_line without start_line should filter from beginning to end_line."""
    test_file = "OpenEndedEnd.lean"
    test_content = """
-- Line 0
theorem early : 1 = 2 := by sorry  -- Line 1
-- Line 2
-- Line 3
-- Line 4
theorem late : 1 = 2 := by sorry  -- Line 5
-- Line 6
"""
    with open(test_env_dir + test_file, "w") as f:
        f.write(test_content)

    clean_lsp_client.open_file(test_file)
    all_diags = clean_lsp_client.get_diagnostics(test_file, inactivity_timeout=10.0)

    # Get diagnostics from beginning to line 3 (should only include line 1)
    to_line_3 = clean_lsp_client.get_diagnostics(test_file, end_line=3)

    # Should have fewer diagnostics than full file
    assert len(to_line_3) < len(all_diags)
    # Should have at least the error on line 1
    assert len(to_line_3) >= 1

    clean_lsp_client.close_files([test_file])

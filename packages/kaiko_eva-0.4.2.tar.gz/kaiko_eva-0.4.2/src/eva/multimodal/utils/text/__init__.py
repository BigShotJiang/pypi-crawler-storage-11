"""Multimodal text utilities API."""

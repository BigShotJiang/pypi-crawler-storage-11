"""API for LLM prompting."""

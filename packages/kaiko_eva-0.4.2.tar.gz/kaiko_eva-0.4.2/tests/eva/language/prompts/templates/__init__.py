"""Tests for prompt templates."""

"""Raw template tests."""

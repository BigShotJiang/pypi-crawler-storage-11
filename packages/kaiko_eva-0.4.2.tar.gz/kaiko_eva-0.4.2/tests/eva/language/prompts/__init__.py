"""Tests for prompts."""

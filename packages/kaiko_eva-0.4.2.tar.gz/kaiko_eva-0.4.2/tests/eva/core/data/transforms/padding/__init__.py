"""Tests for padding transforms."""

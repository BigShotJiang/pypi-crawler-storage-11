"""Tests default metric groups."""

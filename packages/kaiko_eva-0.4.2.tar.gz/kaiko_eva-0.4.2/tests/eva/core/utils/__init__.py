"""Tests the core utilities."""

# Copyright 2021 Red Hat
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Abstractions around system binaries."""

from __future__ import annotations

import logging
import os
from abc import ABC, abstractmethod
from collections import Counter
from pathlib import Path

import requests
from semver import VersionInfo

from sretoolbox.utils import run

LOG = logging.getLogger(__name__)


class CommandNotFoundError(Exception):
    """Used when a binary is not available in the system."""


class Binary(ABC):
    """Represents a binary in the system.

    Tries to find the system binary on the $PATH, in the specified version.
    When the binary is not available locally, tries to download it.

    :param version: the semantic version of the binary
    :param download_path: the path where to download the binary to,
                          in case we have to download it.

    :type version: str
    :type download_path: Path or str
    """

    binary_template = ""
    download_url_template = ""

    def __init__(self, version: str, download_path: Path | str) -> None:
        # Making sure that the version contains
        # valid minor and patch elements
        counter = Counter(version)
        if counter["."] == 0:
            version += ".0.0"
        elif counter["."] == 1:
            version += ".0"

        self.expected_version = VersionInfo.parse(version=version)
        LOG.debug("Expected %s version: %s", self.binary, self.expected_version)

        self.download_path = Path(download_path)

        downloaded = False
        # First try to get the path from the system
        self._command = self._get_command_path(self.binary)

        if self._command is None:
            # First try to download the binary
            downloaded_file = self._download()
            self._command = self.process_download(path=downloaded_file)
            downloaded = True

        # No luck. Binary is not on the system and it also can't
        # be downloaded.
        if self._command is None:
            raise CommandNotFoundError(
                f"Not able to find or download "
                f"{self.binary} version "
                f"{self.expected_version}"
            )

        # Checking if we have the right version
        result = run(cmd=self.get_version_command())
        self._command_version = self.parse_version(version=result)
        if not self._compare(
            expected=self.expected_version, actual=self._command_version
        ):
            if downloaded:
                # If even after download, the version doesn't match,
                # we are done trying.
                raise CommandNotFoundError(
                    f"Downloaded version of "
                    f"{self.binary} did not match "
                    f"the expected version "
                    f"{self.expected_version}"
                )

            # Version doesn't match and we didn't try to download
            # so far. Downloading.
            downloaded_file = self._download()
            self._command = self.process_download(path=downloaded_file)
            if self._command is None:
                raise CommandNotFoundError(f"Not able to download {self.binary}")

            # Checking if we have the right version after download
            result = run(cmd=self.get_version_command())
            self._command_version = self.parse_version(version=result)
            if not self._compare(
                expected=self.expected_version, actual=self._command_version
            ):
                raise CommandNotFoundError(
                    f"Downloaded version of "
                    f"{self.binary} did not match "
                    f"the expected version "
                    f"{self.expected_version}"
                )

    @property
    def command(self) -> str:
        """The binary command full path."""
        assert self._command is not None
        return self._command

    @property
    def version(self) -> VersionInfo:
        """The binary VersionInfo object instance."""
        return self._command_version

    @property
    def binary(self) -> str:
        """The binary name."""
        return self.binary_template.format(version=self.expected_version)

    @property
    def download_url(self) -> str:
        """The download URL."""
        return self.download_url_template.format(
            major=self.expected_version.major,
            minor=self.expected_version.minor,
            patch=self.expected_version.patch,
            prerelease=self.expected_version.prerelease,
            build=self.expected_version.build,
        )

    def run(self, *args: str) -> str:
        """Runs binary with arbitrary options."""
        cmd = [self.command, *args]
        return run(cmd)

    @staticmethod
    def _compare(expected: VersionInfo, actual: VersionInfo) -> bool:
        """Compares the not None fields from a VersionInfo object.

        :param expected: the expected version.
        :param actual: the actual version

        :type expected: VersionInfo
        :type actual: VersionInfo

        :return: True if the versions match.
        :rtype: bool
        """
        expected_version_dict = expected.to_dict()
        actual_version_dict = actual.to_dict()
        for item, value in expected_version_dict.items():
            if value is None:
                continue
            if actual_version_dict[item] != value:
                LOG.debug("Version mismatch: %s != %s", expected, actual)
                return False
        LOG.debug("Version match: %s == %s", expected, actual)
        return True

    def _get_command_path(self, cmd: str, check_exec: bool = True) -> str | None:
        """Find a given command in the system.

        :param cmd: The command name.
        :param check_exec: Whether to check if the command is executable.

        :type cmd: str
        :type check_exec: bool

        :return: The command full path, when found.
        :rtype: string
        """
        bin_paths = [self.download_path]
        os_path = os.environ.get("PATH")
        if os_path is not None:
            bin_paths.extend([Path(item) for item in os_path.split(":")])

        for dir_path in bin_paths:
            cmd_path = dir_path / cmd
            if cmd_path.is_file():
                if check_exec and not os.access(cmd_path, os.R_OK | os.X_OK):
                    continue
                LOG.debug("Found %s", cmd_path)
                return str(cmd_path.resolve())

        return None

    @abstractmethod
    def get_version_command(self) -> list[str]:
        """
        Gets the command and its option(s) to check the version.

        :return: version command
        :rtype: list
        """

    @abstractmethod
    def parse_version(self, version: str) -> VersionInfo:
        """Parses version string as returned by the command execution to a VersionInfo.

        :param version: the return from the version command
        :type version: str

        :return: the parsed version as a VersionInfo object
        :rtype: VersionInfo
        """

    @abstractmethod
    def process_download(self, path: str) -> str | None:
        """Processes a downloaded file and returns the executable binary path.

        :param path: The downloaded file path
        :return: The executable binary path.
        """

    def _download(self) -> str:
        """Gets the binary from the internet in a specific version.

        :return: the command full path after downloaded
        :rtype: str or None
        """
        LOG.debug("Downloading %s", self.download_url)
        response = requests.get(self.download_url, allow_redirects=True, timeout=60)
        if response.status_code >= 300:
            if response.status_code == 404:
                LOG.debug(
                    "%s not found for the current system and architecture",
                    self.binary,
                )
            raise requests.exceptions.HTTPError(
                f"Error downloading {self.download_url}: {response.reason}"
            )

        bin_path = self.download_path / self.binary
        bin_path.write_bytes(response.content)
        LOG.debug("Downloaded %s", bin_path)
        return str(bin_path)

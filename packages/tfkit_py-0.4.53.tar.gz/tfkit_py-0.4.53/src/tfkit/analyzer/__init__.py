"""Terraform project analysis module."""

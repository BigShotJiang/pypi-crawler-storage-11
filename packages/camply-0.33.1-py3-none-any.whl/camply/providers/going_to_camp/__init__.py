"""
GoingToCamp __init__
"""

__author__ = "Lukas Mahler"
__version__ = "0.6.1"
__date__ = "02.11.2025"
__email__ = "m@hler.eu"
__status__ = "Development"

from cs2pattern.check import PatternInfo, check_rare, get_pattern_dict
from cs2pattern.modular import *

__all__ = [
    'PatternInfo',
    'check_rare',
    'get_pattern_dict',
    'abyss',
    'berries',
    'blaze',
    'fade',
    'fire_and_ice',
    'gem_black',
    'gem_blue',
    'gem_diamond',
    'gem_gold',
    'gem_green',
    'gem_pink',
    'gem_purple',
    'gem_white',
    'grinder',
    'hive_blue',
    'hive_orange',
    'moonrise',
    'nocts',
    'paw',
    'phoenix',
    'pussy',
]


if __name__ == '__main__':
    exit(1)

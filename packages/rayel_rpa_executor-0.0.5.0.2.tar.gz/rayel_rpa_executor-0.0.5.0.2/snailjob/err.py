class SnailJobError(RuntimeError):
    pass

"""SHACL validation package."""

__version__ = "0.3.0"
__homepage__ = "https://pygments-styles.org/"
__author__ = "Hsiaoming Yang <me@lepture.com>"
__license__ = "BSD-3-Clause"

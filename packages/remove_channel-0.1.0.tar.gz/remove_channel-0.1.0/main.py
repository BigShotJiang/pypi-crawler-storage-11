def main():
    print("Hello from remove-channel-lib!")


if __name__ == "__main__":
    main()

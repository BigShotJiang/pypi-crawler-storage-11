"""Utility functions for filename generation and image saving."""

import uuid
from pathlib import Path
from PIL import Image


def generate_random_filename(original_filename):
    """
    Generate a random filename preserving the original extension.

    Args:
        original_filename: The original filename (e.g., 'image.jpg')

    Returns:
        str: Random filename with same extension (e.g., 'a1b2c3d4-e5f6-7890-abcd-ef1234567890.jpg')
    """
    # Get the file extension
    ext = Path(original_filename).suffix

    # Generate a random UUID-based filename
    random_name = str(uuid.uuid4())

    return f"{random_name}{ext}"


def save_image(image, output_dir, filename):
    """
    Save a PIL Image to the specified directory.

    Args:
        image: PIL Image object to save
        output_dir: Directory path to save the image
        filename: Filename to use

    Returns:
        Path: Full path to the saved image

    Raises:
        Exception: If the image cannot be saved
    """
    try:
        # Ensure output directory exists
        output_path = Path(output_dir) / filename
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Save the image
        image.save(output_path)

        return output_path

    except Exception as e:
        raise Exception(f"Failed to save image: {e}")

"""Remove color channels from images using PIL."""

__version__ = "0.1.0"

"""Main CLI entry point for remove-channel utility."""

import argparse
import sys
from pathlib import Path

from remove_channel.processor import remove_channel
from remove_channel.utils import generate_random_filename, save_image


def main():
    """Main entry point for the remove-channel command."""
    parser = argparse.ArgumentParser(
        description="Remove a color channel from an image using PIL",
        epilog="Examples:\n"
        "  %(prog)s image.jpg red\n"
        "  %(prog)s photo.png green\n"
        "  %(prog)s picture.tiff blue\n",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument(
        "image_path",
        help="Path to the input image file"
    )

    parser.add_argument(
        "channel",
        choices=["red", "green", "blue", "rgb"],
        help="Channel to remove: red, green, blue, or all (rgb)"
    )

    parser.add_argument(
        "-o", "--output-dir",
        help="Output directory (default: same as input image)"
    )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Show verbose output"
    )

    args = parser.parse_args()

    # Validate image path
    image_path = Path(args.image_path)
    if not image_path.exists():
        print(f"Error: Image file '{args.image_path}' does not exist.", file=sys.stderr)
        sys.exit(1)

    if not image_path.is_file():
        print(f"Error: '{args.image_path}' is not a file.", file=sys.stderr)
        sys.exit(1)

    # Determine output directory
    output_dir = Path(args.output_dir) if args.output_dir else image_path.parent

    try:
        # Process the image
        processed_image = remove_channel(image_path, args.channel)

        # Generate random filename
        output_filename = generate_random_filename(image_path.name)

        # Save the image
        output_path = save_image(processed_image, output_dir, output_filename)

        # Output result
        print(f"✓ Successfully removed {args.channel} channel from {image_path.name}")
        print(f"✓ Saved to: {output_path}")

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

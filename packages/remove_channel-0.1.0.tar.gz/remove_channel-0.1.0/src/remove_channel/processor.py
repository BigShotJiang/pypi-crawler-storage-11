"""Image processing functionality to remove color channels."""

from PIL import Image
import numpy as np


def remove_channel(image_path, channel):
    """
    Remove a specified color channel from an image.

    Args:
        image_path: Path to the input image file
        channel: Channel to remove ('red', 'green', 'blue', or 'rgb')

    Returns:
        PIL.Image: The processed image with the channel removed

    Raises:
        ValueError: If an invalid channel is specified
        Exception: For any other processing errors
    """
    try:
        # Open the image
        with Image.open(image_path) as img:
            # Convert to RGB if not already (handles RGBA, grayscale, etc.)
            if img.mode != 'RGB':
                img = img.convert('RGB')

            # Convert to numpy array for easier manipulation
            img_array = np.array(img)

            # Remove the specified channel(s)
            if channel.lower() == 'red':
                # Set red channel to 0
                img_array[:, :, 0] = 0
            elif channel.lower() == 'green':
                # Set green channel to 0
                img_array[:, :, 1] = 0
            elif channel.lower() == 'blue':
                # Set blue channel to 0
                img_array[:, :, 2] = 0
            elif channel.lower() == 'rgb':
                # Remove all color channels (set all to 0)
                img_array[:, :, :] = 0
            else:
                raise ValueError(f"Invalid channel: {channel}. Must be 'red', 'green', 'blue', or 'rgb'")

            # Convert back to PIL Image
            result_img = Image.fromarray(img_array, 'RGB')

            return result_img

    except Exception as e:
        raise Exception(f"Failed to process image: {e}")

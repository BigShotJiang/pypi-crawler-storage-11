"""Utility functions to extract metadata"""

from typing import Any, Literal, Optional

import nibabel as nib, numpy as np

from ._exceptions import IncorrectSliceDimension
from ._decorators import check_all_none
from .io import get_nifti_header
from .logger import setup_logger

LGR = setup_logger(__name__)


@check_all_none(parameter_names=["nifti_file_or_img", "nifti_header"])
def determine_slice_dim(
    nifti_file_or_img: Optional[str | nib.nifti1.Nifti1Image] = None,
    nifti_header: Optional[nib.nifti1.Nifti1Header] = None,
) -> int:
    """
    Determine the slice dimension

    Uses "slice_end" plus one to determine the likely slice dimension.

    Parameters
    ----------
    nifti_file_or_img: :obj:`str` or :obj:`Nifti1Image`, default=None
        Path to the NIfTI file or a NIfTI image. Must be specified
        if ``nifti_header`` is None.

    nifti_header: :obj:`Nifti1Header`, default=None
        Path to the NIfTI file or a NIfTI image. Must be specified
        if ``nifti_file_or_img`` is None.

    Returns
    -------
    int
        A number representing the slice dimension.
    """
    kwargs = {"nifti_file_or_img": nifti_file_or_img, "nifti_header": nifti_header}
    slice_end, hdr = get_hdr_metadata(
        **kwargs, metadata_name="slice_end", return_header=True
    )
    if not slice_end or np.isnan(slice_end):
        raise ValueError("'slice_end' metadata field not set.")

    n_slices = int(slice_end) + 1
    dims = np.array(hdr.get_data_shape()[:3])

    return np.where(dims == n_slices)[0][0]


@check_all_none(parameter_names=["nifti_file_or_img", "nifti_header"])
def get_hdr_metadata(
    metadata_name: str,
    nifti_file_or_img: Optional[str | nib.nifti1.Nifti1Image] = None,
    nifti_header: Optional[nib.nifti1.Nifti1Header] = None,
    return_header: bool = False,
) -> Any | tuple[Any, nib.nifti1.Nifti1Header]:
    """
    Get metadata from a NIfTI header.

    Parameters
    ----------
    metadata_name: :obj:`str`
        Name of the metadata field to return.

    nifti_file_or_img: :obj:`str` or :obj:`Nifti1Image`, default=None
        Path to the NIfTI file or a NIfTI image. Must be specified
        if ``nifti_header`` is None.

    nifti_header: :obj:`Nifti1Header`, default=None
        Path to the NIfTI file or a NIfTI image. Must be specified
        if ``nifti_file_or_img`` is None.

    return_header: :obj:`bool`
        Returns the NIfTI header

    Returns
    -------
    Any or tuple[Any, nibabel.nifti1.Nifti1Header]
        If ``return_header`` is False, only returns the associated
        value of the metadata. If ``return_header`` is True returns
        a tuple containing the assoicated value of the metadata
        and the NIfTI header.
    """
    hdr = nifti_header if nifti_header else get_nifti_header(nifti_file_or_img)
    metadata_value = hdr.get(metadata_name)

    return metadata_value if not return_header else (metadata_value, hdr)


def get_n_slices(
    nifti_file_or_img: str | nib.nifti1.Nifti1Image,
    slice_dim: Optional[Literal["x", "y", "z"]] = None,
) -> int:
    """
    Gets the number of slices from the header of a NIfTI image.

    Parameters
    ----------
    nifti_file_or_img: :obj:`str` or :obj:`Nifti1Image`
        Path to the NIfTI file or a NIfTI image.

    slice_dim: :obj:`Literal["x", "y", "z"]` or :obj:`None`, default=None
        Dimension the image slices were collected in. If None,
        determines the slice dimension using metadata ("slice_end")
        from the NIfTI header.

    Returns
    -------
    int
        The number of slices.
    """
    slice_dim_map = {"x": 0, "y": 1, "z": 2}

    hdr = get_nifti_header(nifti_file_or_img)
    if slice_dim:
        n_slices = hdr.get_data_shape()[slice_dim_map[slice_dim]]
        if slice_end := get_hdr_metadata(nifti_header=hdr, metadata_name="slice_end"):
            if not np.isnan(slice_end) and n_slices != slice_end + 1:
                raise IncorrectSliceDimension(slice_dim, n_slices, slice_end)

        slice_dim_indx = slice_dim_map[slice_dim]
    else:
        slice_dim_indx = determine_slice_dim(nifti_header=hdr)

    reversed_slice_dim_map = {v: k for v, k in slice_dim_map.items()}

    n_slices = hdr.get_data_shape()[slice_dim_indx]
    LGR.info(
        f"Number of slices based on "
        f"{reversed_slice_dim_map.get(slice_dim_indx)}: {n_slices}"
    )

    return n_slices


def get_tr(nifti_file_or_img: str | nib.nifti1.Nifti1Image) -> float:
    """
    Get the Repetition Time from the header of a NIfTI image.

    Parameters
    ----------
    nifti_file_or_img: :obj:`str` or :obj:`Nifti1Image`
        Path to the NIfTI file or a NIfTI image.

    Returns
    -------
    float
        The repetition time.
    """
    hdr = get_nifti_header(nifti_file_or_img)

    if not (tr := hdr.get_zooms()[3]):
        raise ValueError(f"Suspicious repetition time: {tr}.")

    LGR.info(f"Repetition Time: {tr}.")

    return tr


def flip_slice_order(slice_order, ascending: bool) -> list[int]:
    """
    Flip slice order.

    Parameters
    ----------
    slice_order: :obj:`list[int]`
        List containing integer values representing the slices.

    ascending: :obj:`bool`, default=True
        If slices were collected in ascending order (True) or descending
        order (False).

    Returns
    -------
    list[int]
        The order of the slices.
    """
    return np.flip(slice_order) if not ascending else slice_order


def create_sequential_order(n_slices: int, ascending: bool = True) -> list[int]:
    """
    Create index ordering for sequential acquisition method.

    Parameters
    ----------
    n_slices: :obj:`int`
        The number of slices.

    ascending: :obj:`bool`, default=True
        If slices were collected in ascending order (True) or descending
        order (False).

    Returns
    -------
    list[int]
        The order of the slices.
    """
    slice_order = list(range(0, n_slices))

    return flip_slice_order(slice_order, ascending)


def create_interleaved_order(
    n_slices: int,
    ascending: bool = True,
    interleaved_order: Literal["even_first", "odd_first"] = "odd_first",
) -> list[int]:
    """
    Create index ordering for interleaved acquisition method.

    Parameters
    ----------
    n_slices: :obj:`int`
        The number of slices.

    ascending: :obj:`bool`, default=True
        If slices were collected in ascending order (True) or descending
        order (False).

    interleaved_order: :obj:`Literal["even_first", "odd_first"]`, default="odd_first"
        If slices for interleaved acquisition were collected
        by acquiring the "even_first" or "odd_first" slices first.

    Returns
    -------
    list[int]
        The order of the slices.
    """
    if interleaved_order == "odd_first":
        slice_order = list(range(0, n_slices, 2)) + list(range(1, n_slices, 2))
    else:
        slice_order = list(range(1, n_slices, 2)) + list(range(0, n_slices, 2))

    return flip_slice_order(slice_order, ascending)


def create_slice_timing(
    nifti_file_or_img: str | nib.nifti1.Nifti1Image,
    slice_acquisition_method: Literal["sequential", "interleaved"],
    ascending: bool = True,
    interleaved_order: Literal["even_first", "odd_first"] = "odd_first",
) -> dict[int, float]:
    """
    Parameters
    ----------
    nifti_file_or_img: :obj:`str` or :obj:`Nifti1Image`
        Path to the NIfTI file or a NIfTI image.

    slice_acquisition_method: :obj:`Literal["sequential", "interleaved"]`
        Method used for acquiring slices.

    ascending: :obj:`bool`, default=True
        If slices were collected in ascending order (True) or descending
        order (False).

    interleaved_order: :obj:`Literal["even_first", "odd_first"]`, default="odd_first"
        If slices for interleaved acquisition were collected
        by acquiring the "even_first" or "odd_first" slices first.

    Returns
    -------
    dict[int, float]
        Dictionary mapping the slice number to the time the slice was aquired.
    """
    slice_ordering_func = {
        "sequential": create_sequential_order,
        "interleaved": create_interleaved_order,
    }

    tr = get_tr(nifti_file_or_img)
    n_slices = get_n_slices(nifti_file_or_img)

    slice_duration = tr / n_slices
    kwargs = {"n_slices": n_slices, "ascending": ascending}

    if slice_acquisition_method == "interleaved":
        kwargs.update({"interleaved_order": interleaved_order})

    slice_order = slice_ordering_func[slice_acquisition_method](**kwargs)
    slice_timing = np.linspace(0, tr - slice_duration, n_slices)

    # Pair slice with timing then sort dict
    return dict(
        sorted({k: v for k, v in zip(slice_order, slice_timing.tolist())}.items())
    )


def is_3d_img(nifti_file_or_img: str | nib.nifti1.Nifti1Image) -> bool:
    """
    Determines if ``nifti_file_or_img`` is a 3D image.

    Parameters
    ----------
    nifti_file_or_img: :obj:`str` or :obj:`Nifti1Image`
        Path to the NIfTI file or a NIfTI image.

    Returns
    -------
    bool
        True if ``nifti_file_or_img`` is a 3D image.
    """
    return len(get_nifti_header(nifti_file_or_img).get_zooms()) == 3


def get_scanner_info(
    nifti_file_or_img: str | nib.nifti1.Nifti1Image,
) -> tuple[str, str]:
    """
    Determines the manufacturer and model namne of scanner.

    .. important::
        Assumes this information is in the "descrip" of the NIfTI
        header, which can contain any information.


    Parameters
    ----------
    nifti_file_or_img: :obj:`str` or :obj:`Nifti1Image`
        Path to the NIfTI file or a NIfTI image.

    Returns
    -------
    tuple[str, str]
        The manufacturer and model name for the scanner.
    """
    if not (
        scanner_info := get_hdr_metadata(
            nifti_file_or_img=nifti_file_or_img,
            metadata_name="descrip",
            return_header=False,
        )
    ):
        raise ValueError("No scanner information in NIfTI header.")

    scanner_info = str(scanner_info.astype(str)).rstrip(" ")
    manufacturer_name, _, model_name = scanner_info.partition(" ")

    return manufacturer_name, model_name

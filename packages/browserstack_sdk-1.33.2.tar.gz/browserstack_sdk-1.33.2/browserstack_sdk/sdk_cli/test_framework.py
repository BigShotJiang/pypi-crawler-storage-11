# coding: UTF-8
import sys
bstackl_opy_ = sys.version_info [0] == 2
bstack11l1_opy_ = 2048
bstack11ll_opy_ = 7
def bstack1111ll_opy_ (bstack1llllll1_opy_):
    global bstack1l111l1_opy_
    bstack11lllll_opy_ = ord (bstack1llllll1_opy_ [-1])
    bstack11llll_opy_ = bstack1llllll1_opy_ [:-1]
    bstack1ll1ll1_opy_ = bstack11lllll_opy_ % len (bstack11llll_opy_)
    bstack1ll1111_opy_ = bstack11llll_opy_ [:bstack1ll1ll1_opy_] + bstack11llll_opy_ [bstack1ll1ll1_opy_:]
    if bstackl_opy_:
        bstack111ll_opy_ = unicode () .join ([unichr (ord (char) - bstack11l1_opy_ - (bstack11l11_opy_ + bstack11lllll_opy_) % bstack11ll_opy_) for bstack11l11_opy_, char in enumerate (bstack1ll1111_opy_)])
    else:
        bstack111ll_opy_ = str () .join ([chr (ord (char) - bstack11l1_opy_ - (bstack11l11_opy_ + bstack11lllll_opy_) % bstack11ll_opy_) for bstack11l11_opy_, char in enumerate (bstack1ll1111_opy_)])
    return eval (bstack111ll_opy_)
import logging
from enum import Enum
import os
import threading
import traceback
from typing import Dict, List, Any, Callable, Tuple, Union
import abc
from datetime import datetime, timezone
from dataclasses import dataclass
from browserstack_sdk.sdk_cli.bstack1llllllll1l_opy_ import bstack1llllllll11_opy_
from browserstack_sdk.sdk_cli.bstack1llll1l1111_opy_ import bstack1llll1l1lll_opy_, bstack1llllll1111_opy_
class bstack1lll1l111ll_opy_(Enum):
    PRE = 0
    POST = 1
    def __repr__(self) -> str:
        return bstack1111ll_opy_ (u"ࠥࡘࡪࡹࡴࡉࡱࡲ࡯ࡘࡺࡡࡵࡧ࠱ࡿࢂࠨᗜ").format(self.name)
class bstack1ll1l11lll1_opy_(Enum):
    NONE = 0
    BEFORE_ALL = 1
    LOG = 2
    SETUP_FIXTURE = 3
    INIT_TEST = 4
    BEFORE_EACH = 5
    AFTER_EACH = 6
    TEST = 7
    STEP = 8
    LOG_REPORT = 9
    AFTER_ALL = 10
    def __eq__(self, other):
        if self.__class__ is other.__class__:
            return self.value == other.value
        return NotImplemented
    def __lt__(self, other):
        if self.__class__ is other.__class__:
            return self.value < other.value
        return NotImplemented
    def __repr__(self) -> str:
        return bstack1111ll_opy_ (u"࡙ࠦ࡫ࡳࡵࡈࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡗࡹࡧࡴࡦ࠰ࡾࢁࠧᗝ").format(self.name)
class bstack1lll1llllll_opy_(bstack1llll1l1lll_opy_):
    bstack1ll11l111ll_opy_: List[str]
    bstack1l111l111ll_opy_: Dict[str, str]
    state: bstack1ll1l11lll1_opy_
    bstack1lllll1ll11_opy_: datetime
    bstack1llll1ll1ll_opy_: datetime
    def __init__(
        self,
        context: bstack1llllll1111_opy_,
        bstack1ll11l111ll_opy_: List[str],
        bstack1l111l111ll_opy_: Dict[str, str],
        state=bstack1ll1l11lll1_opy_.NONE,
    ):
        super().__init__(context)
        self.bstack1ll11l111ll_opy_ = bstack1ll11l111ll_opy_
        self.bstack1l111l111ll_opy_ = bstack1l111l111ll_opy_
        self.state = state
        self.bstack1lllll1ll11_opy_ = datetime.now(tz=timezone.utc)
        self.bstack1llll1ll1ll_opy_ = datetime.now(tz=timezone.utc)
    def bstack1lllll111ll_opy_(self, bstack1llllll11ll_opy_: bstack1ll1l11lll1_opy_):
        bstack1lllllll111_opy_ = bstack1ll1l11lll1_opy_(bstack1llllll11ll_opy_).name
        if not bstack1lllllll111_opy_:
            return False
        if bstack1llllll11ll_opy_ == self.state:
            return False
        self.state = bstack1llllll11ll_opy_
        self.bstack1llll1ll1ll_opy_ = datetime.now(tz=timezone.utc)
        return True
@dataclass
class bstack1l111l1111l_opy_:
    test_framework_name: str
    test_framework_version: str
    platform_index: int
@dataclass
class bstack1ll1l1l1111_opy_:
    kind: str
    message: str
    level: Union[None, str] = None
    timestamp: Union[None, datetime] = datetime.now(tz=timezone.utc)
    fileName: str = None
    bstack1l1l1lllll1_opy_: int = None
    bstack1l1l1ll11ll_opy_: str = None
    bstack1ll1ll_opy_: str = None
    bstack1lll11l111_opy_: str = None
    bstack1l1ll1lll1l_opy_: str = None
    bstack1l111111111_opy_: str = None
class TestFramework(abc.ABC):
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    bstack1ll111l1lll_opy_ = bstack1111ll_opy_ (u"ࠧࡺࡥࡴࡶࡢࡹࡺ࡯ࡤࠣᗞ")
    bstack1l11111l1ll_opy_ = bstack1111ll_opy_ (u"ࠨࡴࡦࡵࡷࡣ࡮ࡪࠢᗟ")
    bstack1ll11111l1l_opy_ = bstack1111ll_opy_ (u"ࠢࡵࡧࡶࡸࡤࡴࡡ࡮ࡧࠥᗠ")
    bstack1l1111lllll_opy_ = bstack1111ll_opy_ (u"ࠣࡶࡨࡷࡹࡥࡦࡪ࡮ࡨࡣࡵࡧࡴࡩࠤᗡ")
    bstack1l11111l111_opy_ = bstack1111ll_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡵࡣࡪࡷࠧᗢ")
    bstack1l11lll111l_opy_ = bstack1111ll_opy_ (u"ࠥࡸࡪࡹࡴࡠࡴࡨࡷࡺࡲࡴࠣᗣ")
    bstack1l1ll111ll1_opy_ = bstack1111ll_opy_ (u"ࠦࡹ࡫ࡳࡵࡡࡵࡩࡸࡻ࡬ࡵࡡࡤࡸࠧᗤ")
    bstack1l1l1lll11l_opy_ = bstack1111ll_opy_ (u"ࠧࡺࡥࡴࡶࡢࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠢᗥ")
    bstack1l1ll1l11ll_opy_ = bstack1111ll_opy_ (u"ࠨࡴࡦࡵࡷࡣࡪࡴࡤࡦࡦࡢࡥࡹࠨᗦ")
    bstack1l11111111l_opy_ = bstack1111ll_opy_ (u"ࠢࡵࡧࡶࡸࡤࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠢᗧ")
    bstack1ll111lll11_opy_ = bstack1111ll_opy_ (u"ࠣࡶࡨࡷࡹࡥࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡱࡥࡲ࡫ࠢᗨ")
    bstack1l1l1ll1111_opy_ = bstack1111ll_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡺࡪࡸࡳࡪࡱࡱࠦᗩ")
    bstack1l111l1lll1_opy_ = bstack1111ll_opy_ (u"ࠥࡸࡪࡹࡴࡠࡥࡲࡨࡪࠨᗪ")
    bstack1l1l11l1l11_opy_ = bstack1111ll_opy_ (u"ࠦࡹ࡫ࡳࡵࡡࡵࡩࡷࡻ࡮ࡠࡰࡤࡱࡪࠨᗫ")
    bstack1ll11ll1l11_opy_ = bstack1111ll_opy_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳ࡟ࡪࡰࡧࡩࡽࠨᗬ")
    bstack1l11lll1l11_opy_ = bstack1111ll_opy_ (u"ࠨࡴࡦࡵࡷࡣ࡫ࡧࡩ࡭ࡷࡵࡩࠧᗭ")
    bstack1l1111ll111_opy_ = bstack1111ll_opy_ (u"ࠢࡵࡧࡶࡸࡤ࡬ࡡࡪ࡮ࡸࡶࡪࡥࡴࡺࡲࡨࠦᗮ")
    bstack11llll1ll1l_opy_ = bstack1111ll_opy_ (u"ࠣࡶࡨࡷࡹࡥ࡬ࡰࡩࡶࠦᗯ")
    bstack1l1111lll1l_opy_ = bstack1111ll_opy_ (u"ࠤࡷࡩࡸࡺ࡟࡮ࡧࡷࡥࠧᗰ")
    bstack11llll11l1l_opy_ = bstack1111ll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡵࡦࡳࡵ࡫ࡳࠨᗱ")
    bstack1l11l11l11l_opy_ = bstack1111ll_opy_ (u"ࠦࡦࡻࡴࡰ࡯ࡤࡸࡪࡥࡳࡦࡵࡶ࡭ࡴࡴ࡟࡯ࡣࡰࡩࠧᗲ")
    bstack11lllll1111_opy_ = bstack1111ll_opy_ (u"ࠧ࡫ࡶࡦࡰࡷࡣࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠣᗳ")
    bstack1l1111l11l1_opy_ = bstack1111ll_opy_ (u"ࠨࡥࡷࡧࡱࡸࡤ࡫࡮ࡥࡧࡧࡣࡦࡺࠢᗴ")
    bstack1l1111lll11_opy_ = bstack1111ll_opy_ (u"ࠢࡩࡱࡲ࡯ࡤ࡯ࡤࠣᗵ")
    bstack1l111111lll_opy_ = bstack1111ll_opy_ (u"ࠣࡪࡲࡳࡰࡥࡲࡦࡵࡸࡰࡹࠨᗶ")
    bstack11llllll1l1_opy_ = bstack1111ll_opy_ (u"ࠤ࡫ࡳࡴࡱ࡟࡭ࡱࡪࡷࠧᗷ")
    bstack1l111l111l1_opy_ = bstack1111ll_opy_ (u"ࠥ࡬ࡴࡵ࡫ࡠࡰࡤࡱࡪࠨᗸ")
    bstack1l111l11lll_opy_ = bstack1111ll_opy_ (u"ࠦࡱࡵࡧࡴࠤᗹ")
    bstack1l111ll11l1_opy_ = bstack1111ll_opy_ (u"ࠧࡩࡵࡴࡶࡲࡱࡤࡳࡥࡵࡣࡧࡥࡹࡧࠢᗺ")
    bstack11llll1l1ll_opy_ = bstack1111ll_opy_ (u"ࠨࡰࡦࡰࡧ࡭ࡳ࡭ࠢᗻ")
    bstack11llllll111_opy_ = bstack1111ll_opy_ (u"ࠢࡱࡧࡱࡨ࡮ࡴࡧࠣᗼ")
    bstack1l1l1ll111l_opy_ = bstack1111ll_opy_ (u"ࠣࡖࡈࡗ࡙ࡥࡓࡄࡔࡈࡉࡓ࡙ࡈࡐࡖࠥᗽ")
    bstack1l1l1l1lll1_opy_ = bstack1111ll_opy_ (u"ࠤࡗࡉࡘ࡚࡟ࡍࡑࡊࠦᗾ")
    bstack1l1lll111ll_opy_ = bstack1111ll_opy_ (u"ࠥࡘࡊ࡙ࡔࡠࡃࡗࡘࡆࡉࡈࡎࡇࡑࡘࠧᗿ")
    bstack1llllll111l_opy_: Dict[str, bstack1lll1llllll_opy_] = dict()
    bstack11lll1ll1ll_opy_: Dict[str, List[Callable]] = dict()
    bstack1ll11l111ll_opy_: List[str]
    bstack1l111l111ll_opy_: Dict[str, str]
    def __init__(
        self,
        bstack1ll11l111ll_opy_: List[str],
        bstack1l111l111ll_opy_: Dict[str, str],
        bstack1llllllll1l_opy_: bstack1llllllll11_opy_
    ):
        self.bstack1ll11l111ll_opy_ = bstack1ll11l111ll_opy_
        self.bstack1l111l111ll_opy_ = bstack1l111l111ll_opy_
        self.bstack1llllllll1l_opy_ = bstack1llllllll1l_opy_
    def track_event(
        self,
        context: bstack1l111l1111l_opy_,
        test_framework_state: bstack1ll1l11lll1_opy_,
        test_hook_state: bstack1lll1l111ll_opy_,
        *args,
        **kwargs,
    ):
        self.logger.debug(bstack1111ll_opy_ (u"ࠦࡹࡸࡡࡤ࡭ࡢࡩࡻ࡫࡮ࡵ࠼ࠣࡸࡪࡹࡴࡠࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸࡺࡡࡵࡧࡀࡿࢂࠦࡴࡦࡵࡷࡣ࡭ࡵ࡯࡬ࡡࡶࡸࡦࡺࡥ࠾ࡽࢀࠤࡦࡸࡧࡴ࠿ࡾࢁࠥࡱࡷࡢࡴࡪࡷࡂࢁࡽࠣᘀ").format(test_framework_state,test_hook_state,args,kwargs))
    def bstack1l111l11111_opy_(
        self,
        instance: bstack1lll1llllll_opy_,
        bstack1llll1lll1l_opy_: Tuple[bstack1ll1l11lll1_opy_, bstack1lll1l111ll_opy_],
        *args,
        **kwargs,
    ):
        bstack1l111lll111_opy_ = TestFramework.bstack1l11l111111_opy_(bstack1llll1lll1l_opy_)
        if not bstack1l111lll111_opy_ in TestFramework.bstack11lll1ll1ll_opy_:
            return
        self.logger.debug(bstack1111ll_opy_ (u"ࠧ࡯࡮ࡷࡱ࡮࡭ࡳ࡭ࠠࡼࡿࠣࡧࡦࡲ࡬ࡣࡣࡦ࡯ࡸࠨᘁ").format(len(TestFramework.bstack11lll1ll1ll_opy_[bstack1l111lll111_opy_])))
        for callback in TestFramework.bstack11lll1ll1ll_opy_[bstack1l111lll111_opy_]:
            try:
                callback(self, instance, bstack1llll1lll1l_opy_, *args, **kwargs)
            except Exception as e:
                self.logger.error(bstack1111ll_opy_ (u"ࠨࡥࡳࡴࡲࡶࠥ࡯࡮ࡷࡱ࡮࡭ࡳ࡭ࠠࡤࡣ࡯ࡰࡧࡧࡣ࡬࠼ࠣࡿࢂࠨᘂ").format(e))
                traceback.print_exc()
    @abc.abstractmethod
    def bstack1l1l1l1111l_opy_(self):
        return
    @abc.abstractmethod
    def bstack1l1ll1ll111_opy_(self, instance, bstack1llll1lll1l_opy_):
        return
    @abc.abstractmethod
    def bstack1l1ll11ll1l_opy_(self, instance, bstack1llll1lll1l_opy_):
        return
    @staticmethod
    def bstack1lllll11111_opy_(target: object, strict=True):
        if target is None:
            return None
        ctx = bstack1llll1l1lll_opy_.create_context(target)
        instance = TestFramework.bstack1llllll111l_opy_.get(ctx.id, None)
        if instance and instance.bstack1lllll111l1_opy_(target):
            return instance
        return instance if instance and not strict else None
    @staticmethod
    def bstack1l1ll1l1111_opy_(reverse=True) -> List[bstack1lll1llllll_opy_]:
        thread_id = threading.get_ident()
        process_id = os.getpid()
        return sorted(
            filter(
                lambda t: t.context.thread_id == thread_id
                and t.context.process_id == process_id,
                TestFramework.bstack1llllll111l_opy_.values(),
            ),
            key=lambda t: t.bstack1lllll1ll11_opy_,
            reverse=reverse,
        )
    @staticmethod
    def bstack1llll11lll1_opy_(ctx: bstack1llllll1111_opy_, reverse=True) -> List[bstack1lll1llllll_opy_]:
        return sorted(
            filter(
                lambda t: t.context.thread_id == ctx.thread_id
                and t.context.process_id == ctx.process_id,
                TestFramework.bstack1llllll111l_opy_.values(),
            ),
            key=lambda t: t.bstack1lllll1ll11_opy_,
            reverse=reverse,
        )
    @staticmethod
    def bstack1lllll1ll1l_opy_(instance: bstack1lll1llllll_opy_, key: str):
        return instance and key in instance.data
    @staticmethod
    def bstack1llllll1lll_opy_(instance: bstack1lll1llllll_opy_, key: str, default_value=None):
        return instance.data.get(key, default_value) if instance else default_value
    @staticmethod
    def bstack1lllll111ll_opy_(instance: bstack1lll1llllll_opy_, key: str, value: Any):
        TestFramework.logger.debug(bstack1111ll_opy_ (u"ࠢࡴࡧࡷࡣࡸࡺࡡࡵࡧ࠽ࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࡃࡻࡾࠢ࡮ࡩࡾࡃࡻࡾࠢࡹࡥࡱࡻࡥ࠾ࡽࢀࠦᘃ").format(instance.ref(),key,value))
        instance.data[key] = value
        return True
    @staticmethod
    def bstack1l1111l1ll1_opy_(instance: bstack1lll1llllll_opy_, entries: Dict[str, Any]):
        TestFramework.logger.debug(bstack1111ll_opy_ (u"ࠣࡵࡨࡸࡤࡹࡴࡢࡶࡨࡣࡪࡴࡴࡳ࡫ࡨࡷ࠿ࠦࡩ࡯ࡵࡷࡥࡳࡩࡥ࠾ࡽࢀࠤࡪࡴࡴࡳ࡫ࡨࡷࡂࢁࡽࠣᘄ").format(instance.ref(),entries,))
        instance.data.update(entries)
        return True
    @staticmethod
    def bstack11lll1l1l1l_opy_(instance: bstack1ll1l11lll1_opy_, key: str, value: Any):
        TestFramework.logger.debug(bstack1111ll_opy_ (u"ࠤࡸࡴࡩࡧࡴࡦࡡࡶࡸࡦࡺࡥ࠻ࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࡁࢀࢃࠠ࡬ࡧࡼࡁࢀࢃࠠࡷࡣ࡯ࡹࡪࡃࡻࡾࠤᘅ").format(instance.ref(),key,value))
        instance.data.update(key, value)
        return True
    @staticmethod
    def get_data(key: str, target: object, strict=True, default_value=None):
        instance = TestFramework.bstack1lllll11111_opy_(target, strict)
        return TestFramework.bstack1llllll1lll_opy_(instance, key, default_value)
    @staticmethod
    def set_data(key: str, value: Any, target: object, strict=True):
        instance = TestFramework.bstack1lllll11111_opy_(target, strict)
        if not instance:
            return False
        instance.data[key] = value
        return True
    @staticmethod
    def bstack11llll1lll1_opy_(instance: bstack1lll1llllll_opy_, key: str, value: object):
        if instance == None:
            return
        instance.data[key] = value
    @staticmethod
    def bstack1l111l1l1l1_opy_(instance: bstack1lll1llllll_opy_, key: str):
        return instance.data[key]
    @staticmethod
    def bstack1l11l111111_opy_(bstack1llll1lll1l_opy_: Tuple[bstack1ll1l11lll1_opy_, bstack1lll1l111ll_opy_]):
        return bstack1111ll_opy_ (u"ࠥ࠾ࠧᘆ").join((bstack1ll1l11lll1_opy_(bstack1llll1lll1l_opy_[0]).name, bstack1lll1l111ll_opy_(bstack1llll1lll1l_opy_[1]).name))
    @staticmethod
    def bstack1ll111ll1l1_opy_(bstack1llll1lll1l_opy_: Tuple[bstack1ll1l11lll1_opy_, bstack1lll1l111ll_opy_], callback: Callable):
        bstack1l111lll111_opy_ = TestFramework.bstack1l11l111111_opy_(bstack1llll1lll1l_opy_)
        TestFramework.logger.debug(bstack1111ll_opy_ (u"ࠦࡸ࡫ࡴࡠࡪࡲࡳࡰࡥࡣࡢ࡮࡯ࡦࡦࡩ࡫࠻ࠢ࡫ࡳࡴࡱ࡟ࡳࡧࡪ࡭ࡸࡺࡲࡺࡡ࡮ࡩࡾࡃࡻࡾࠤᘇ").format(bstack1l111lll111_opy_))
        if not bstack1l111lll111_opy_ in TestFramework.bstack11lll1ll1ll_opy_:
            TestFramework.bstack11lll1ll1ll_opy_[bstack1l111lll111_opy_] = []
        TestFramework.bstack11lll1ll1ll_opy_[bstack1l111lll111_opy_].append(callback)
    @staticmethod
    def bstack1l1ll1ll1l1_opy_(o):
        klass = o.__class__
        module = klass.__module__
        if module == bstack1111ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡷ࡭ࡳࡹࠢᘈ"):
            return klass.__qualname__
        return module + bstack1111ll_opy_ (u"ࠨ࠮ࠣᘉ") + klass.__qualname__
    @staticmethod
    def bstack1l1ll1l1lll_opy_(obj, keys, default_value=None):
        return {k: getattr(obj, k, default_value) for k in keys}
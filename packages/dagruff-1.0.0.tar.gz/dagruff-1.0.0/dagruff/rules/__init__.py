"""DAG file checking rules."""

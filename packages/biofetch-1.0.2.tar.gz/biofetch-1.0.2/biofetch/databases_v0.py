# Database configuration and metadata definitions
"""
Database configurations and URL generators
"""

SUPPORTED_DATABASES = {
    'sra': {
        'name': 'Sequence Read Archive (NCBI)',
        'base_url': 'https://trace.ncbi.nlm.nih.gov/Traces/sra-reads-be/fastq',
        'file_extension': '.fastq',
        'validation_prefixes': ['SRR', 'ERR', 'DRR'],
        'example_ids': ['SRR000001', 'SRR000002'],
        'description': 'Raw sequencing data from high-throughput sequencing instruments'
    },
    'genbank': {
        'name': 'GenBank (NCBI)',
        'base_url': 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi',
        'file_extension': '.fasta',
        'validation_prefixes': ['NC_', 'NT_', 'NW_', 'NZ_', 'AC_', 'NM_', 'NR_', 'XM_', 'XR_'],
        'example_ids': ['NC_045512', 'NC_000001'],
        'description': 'Nucleotide sequences and annotations'
    },
    'ena': {
        'name': 'European Nucleotide Archive',
        'base_url': 'https://www.ebi.ac.uk/ena/browser/api/fasta',
        'file_extension': '.fasta',
        'validation_prefixes': ['ERR', 'SRR', 'DRR'],
        'example_ids': ['ERR000001', 'SRR000001'],
        'description': 'Comprehensive record of nucleotide sequencing information'
    },
    'uniprot': {
        'name': 'Universal Protein Resource',
        'base_url': 'https://rest.uniprot.org/uniprotkb',
        'file_extension': '.fasta',
        'validation_prefixes': ['P', 'Q', 'O', 'A', 'B', 'C'],
        'example_ids': ['P04637', 'Q9Y261'],
        'description': 'Comprehensive protein sequence and functional information'
    },
    'pdb': {
        'name': 'Protein Data Bank',
        'base_url': 'https://files.rcsb.org/download',
        'file_extension': '.pdb',
        'validation_prefixes': [],
        'example_ids': ['1A0O', '3J3Q', '7BV2'],
        'description': '3D structural data of biological macromolecules'
    },
    'geo': {
        'name': 'Gene Expression Omnibus',
        'base_url': 'https://ftp.ncbi.nlm.nih.gov/geo',
        'file_extension': '.txt',
        'validation_prefixes': ['GSE', 'GSM', 'GPL', 'GDS'],
        'example_ids': ['GSE000001', 'GSM000001'],
        'description': 'Gene expression and genomics data repository'
    }
}


def get_download_url(accession: str, database: str) -> str:
    """
    Generate download URL for given accession
    
    Args:
        accession: Accession ID
        database: Database name
    
    Returns:
        Download URL string
    """
    if database not in SUPPORTED_DATABASES:
        return None
    
    config = SUPPORTED_DATABASES[database]
    
    if database == 'genbank':
        return f"{config['base_url']}?db=nucleotide&id={accession}&rettype=fasta&retmode=text"
    
    elif database == 'uniprot':
        return f"{config['base_url']}/{accession}.fasta"
    
    elif database == 'pdb':
        return f"{config['base_url']}/{accession.upper()}.pdb"
    
    elif database == 'ena':
        return f"{config['base_url']}/{accession}"
    
    elif database == 'sra':
        return f"{config['base_url']}?acc={accession}"
    
    elif database == 'geo':
        # GEO series matrix files
        series_dir = accession[:5] + 'nnn'
        return f"{config['base_url']}/series/{series_dir}/{accession}/matrix/{accession}_series_matrix.txt.gz"
    
    return None


def get_metadata_url(accession: str, database: str) -> str:
    """Get metadata URL for accession"""
    if database == 'genbank':
        return f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=nucleotide&id={accession}&retmode=json"
    elif database == 'uniprot':
        return f"https://rest.uniprot.org/uniprotkb/{accession}.json"
    elif database == 'pdb':
        return f"https://data.rcsb.org/rest/v1/core/entry/{accession}"
    return None


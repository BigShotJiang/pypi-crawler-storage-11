"""
BioFetch - Unified Bioinformatics Data Downloader
A Python package and CLI tool for downloading data from biological databases
"""

__version__ = "1.0.2"
__author__ = "Ananaya-J"
__email__ = "ananayajain2024@gmail.com"

from .downloader import BioFetchDownloader
from .databases import SUPPORTED_DATABASES
from .validators import validate_accession

__all__ = [
    'BioFetchDownloader',
    'SUPPORTED_DATABASES',
    'validate_accession',
]

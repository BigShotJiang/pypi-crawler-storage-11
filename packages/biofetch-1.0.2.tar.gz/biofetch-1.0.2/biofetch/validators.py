"""
Validation functions for accession IDs
"""

import re
from typing import Tuple
from .databases import SUPPORTED_DATABASES


def validate_accession(accession: str, database: str) -> bool:
    """
    Validate accession ID format for given database
    
    Args:
        accession: Accession ID to validate
        database: Database name
    
    Returns:
        True if valid, False otherwise
    """
    if database not in SUPPORTED_DATABASES:
        return False
    
    prefixes = SUPPORTED_DATABASES[database]['validation_prefixes']
    
    # If no prefixes defined, accept any non-empty string
    if not prefixes:
        return len(accession.strip()) > 0
    
    # Special handling for ENA - it accepts many formats
    if database == 'ena':
        # Accept if it matches any prefix OR if it's 6+ alphanumeric characters
        matches_prefix = any(accession.upper().startswith(prefix.upper()) for prefix in prefixes)
        is_valid_format = bool(re.match(r'^[A-Z0-9]{6,}$', accession.upper()))
        return matches_prefix or is_valid_format
    
    # Check if accession starts with any valid prefix
    return any(accession.upper().startswith(prefix.upper()) for prefix in prefixes)


def validate_accession_strict(accession: str, database: str) -> Tuple[bool, str]:
    """
    Strict validation with detailed error messages
    
    Args:
        accession: Accession ID to validate
        database: Database name
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not accession or not accession.strip():
        return False, "Accession ID cannot be empty"
    
    if database not in SUPPORTED_DATABASES:
        return False, f"Unsupported database: {database}"
    
    prefixes = SUPPORTED_DATABASES[database]['validation_prefixes']
    
    if not prefixes:
        return True, ""
    
    # Special handling for ENA
    if database == 'ena':
        matches_prefix = any(accession.upper().startswith(prefix.upper()) for prefix in prefixes)
        is_valid_format = bool(re.match(r'^[A-Z0-9]{6,}$', accession.upper()))
        if matches_prefix or is_valid_format:
            return True, ""
        return False, "Invalid ENA accession format (need 6+ alphanumeric characters)"
    
    if not any(accession.upper().startswith(prefix.upper()) for prefix in prefixes):
        valid_prefixes = ", ".join(prefixes)
        return False, f"Invalid prefix. Expected one of: {valid_prefixes}"
    
    # Database-specific validation rules
    if database == 'sra':
        if not re.match(r'^[EDS]RR\d{6,}$', accession):
            return False, "SRA accessions should be in format: SRR/ERR/DRR followed by 6+ digits"
    
    elif database == 'genbank':
        if not re.match(r'^[A-Z]{2}_\d+(\.\d+)?$', accession):
            return False, "GenBank accessions should be in format: XX_######"
    
    elif database == 'pdb':
        if not re.match(r'^[0-9][A-Z0-9]{3}$', accession):
            return False, "PDB IDs should be 4 characters (digit + 3 alphanumeric)"
    
    return True, ""

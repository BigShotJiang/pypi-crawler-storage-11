# Entry point for CLI commands
# ============================================================================
# FILE: biofetch/cli.py
# COPY THIS ENTIRE SECTION TO: biofetch/cli.py
# ============================================================================
#!/usr/bin/env python3
"""
BioFetch CLI - Command Line Interface
"""

import sys
import argparse
from pathlib import Path
from typing import Optional, List
import logging

from .downloader import BioFetchDownloader
from .databases import SUPPORTED_DATABASES
from .config import BioFetchConfig
from . import __version__

try:
    from rich.console import Console
    from rich.table import Table
    RICH_AVAILABLE = True
    console = Console()
except ImportError:
    RICH_AVAILABLE = False
    console = None


def setup_logging(verbose: bool = False):
    """Setup logging configuration"""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )


def print_success(message: str):
    """Print success message"""
    if RICH_AVAILABLE:
        console.print(f"✅ {message}", style="bold green")
    else:
        print(f"✅ {message}")


def print_error(message: str):
    """Print error message"""
    if RICH_AVAILABLE:
        console.print(f"❌ {message}", style="bold red")
    else:
        print(f"❌ {message}")


def print_info(message: str):
    """Print info message"""
    if RICH_AVAILABLE:
        console.print(f"ℹ️  {message}", style="bold blue")
    else:
        print(f"ℹ️  {message}")


def list_databases_command():
    """List all supported databases"""
    if RICH_AVAILABLE:
        table = Table(title="Supported Databases", show_header=True, header_style="bold magenta")
        table.add_column("ID", style="cyan", width=12)
        table.add_column("Name", style="green")
        table.add_column("Example IDs", style="yellow")
        table.add_column("Prefixes", style="blue")
        
        for db_id, info in SUPPORTED_DATABASES.items():
            table.add_row(
                db_id,
                info['name'],
                ", ".join(info['example_ids'][:2]),
                ", ".join(info['validation_prefixes']) if info['validation_prefixes'] else "Any"
            )
        
        console.print(table)
    else:
        print("\n" + "="*80)
        print("SUPPORTED DATABASES")
        print("="*80)
        for db_id, info in SUPPORTED_DATABASES.items():
            print(f"\n{db_id:12} - {info['name']}")
            print(f"  Examples: {', '.join(info['example_ids'][:2])}")
            if info['validation_prefixes']:
                print(f"  Prefixes: {', '.join(info['validation_prefixes'])}")


def download_command(args):
    """Download single file"""
    setup_logging(args.verbose)
    
    downloader = BioFetchDownloader(
        output_dir=args.output,
        num_retries=args.retries,
        timeout=args.timeout
    )
    
    print_info(f"Downloading {args.accession} from {args.database}...")
    
    try:
        result = downloader.download(
            accession=args.accession,
            database=args.database,
            validate=not args.no_validate
        )
        
        if result['success']:
            print_success(f"Downloaded successfully!")
            print(f"  File: {result['file_path']}")
            print(f"  Size: {result['file_size']:,} bytes")
            print(f"  MD5: {result['checksum']}")
        else:
            print_error(f"Download failed: {result.get('error', 'Unknown error')}")
            sys.exit(1)
            
    except Exception as e:
        print_error(f"Error: {str(e)}")
        sys.exit(1)


def batch_download_command(args):
    """Download multiple files"""
    setup_logging(args.verbose)
    
    if args.file:
        with open(args.file, 'r') as f:
            accessions = [line.strip() for line in f if line.strip()]
    else:
        accessions = args.accessions
    
    if not accessions:
        print_error("No accession IDs provided")
        sys.exit(1)
    
    downloader = BioFetchDownloader(
        output_dir=args.output,
        num_retries=args.retries,
        timeout=args.timeout
    )
    
    print_info(f"Batch downloading {len(accessions)} files from {args.database}...")
    
    try:
        results = downloader.batch_download(
            accessions=accessions,
            database=args.database,
            parallel=args.parallel,
            validate=not args.no_validate
        )
        
        success_count = sum(1 for r in results if r['success'])
        failed_count = len(results) - success_count
        
        print("\n" + "="*80)
        print_success(f"Batch download complete!")
        print(f"  Successful: {success_count}/{len(accessions)}")
        print(f"  Failed: {failed_count}/{len(accessions)}")
        
        if failed_count > 0:
            print("\nFailed downloads:")
            for r in results:
                if not r['success']:
                    print(f"  ❌ {r['accession']}: {r.get('error', 'Unknown error')}")
        
        sys.exit(0 if failed_count == 0 else 1)
        
    except Exception as e:
        print_error(f"Batch download error: {str(e)}")
        sys.exit(1)


def config_command(args):
    """Manage configuration"""
    config = BioFetchConfig()
    
    if args.config_action == 'show':
        print("\nCurrent Configuration:")
        print("="*50)
        for key, value in config.get_all().items():
            print(f"  {key}: {value}")
    
    elif args.config_action == 'set':
        config.set(args.key, args.value)
        print_success(f"Set {args.key} = {args.value}")
    
    elif args.config_action == 'get':
        value = config.get(args.key)
        print(f"{args.key}: {value}")
    
    elif args.config_action == 'reset':
        config.reset()
        print_success("Configuration reset to defaults")


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        prog='biofetch',
        description='BioFetch - Unified Bioinformatics Data Downloader',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  biofetch download NC_045512 --db genbank
  biofetch batch --file accessions.txt --db sra
  biofetch list-databases
  biofetch config set output_dir ~/data

Supported databases: sra, genbank, ena, uniprot, pdb, geo
        """
    )
    
    parser.add_argument('--version', action='version', version=f'BioFetch {__version__}')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Download command
    download_parser = subparsers.add_parser('download', help='Download single file')
    download_parser.add_argument('accession', help='Accession ID')
    download_parser.add_argument('--db', '--database', dest='database', required=True,
                                help='Database name')
    download_parser.add_argument('-o', '--output', default='./biofetch_data',
                                help='Output directory')
    download_parser.add_argument('--no-validate', action='store_true',
                                help='Skip format validation')
    download_parser.add_argument('--retries', type=int, default=3,
                                help='Number of retry attempts')
    download_parser.add_argument('--timeout', type=int, default=300,
                                help='Timeout in seconds')
    
    # Batch download command
    batch_parser = subparsers.add_parser('batch', help='Batch download multiple files')
    batch_parser.add_argument('accessions', nargs='*', help='Accession IDs')
    batch_parser.add_argument('-f', '--file', help='File containing accession IDs (one per line)')
    batch_parser.add_argument('--db', '--database', dest='database', required=True,
                             help='Database name')
    batch_parser.add_argument('-o', '--output', default='./biofetch_data',
                             help='Output directory')
    batch_parser.add_argument('--parallel', type=int, default=1,
                             help='Number of parallel downloads')
    batch_parser.add_argument('--no-validate', action='store_true',
                             help='Skip format validation')
    batch_parser.add_argument('--retries', type=int, default=3,
                             help='Number of retry attempts')
    batch_parser.add_argument('--timeout', type=int, default=300,
                             help='Timeout in seconds')
    
    # List databases command
    subparsers.add_parser('list-databases', help='List supported databases')
    
    # Config command
    config_parser = subparsers.add_parser('config', help='Manage configuration')
    config_parser.add_argument('config_action', choices=['show', 'set', 'get', 'reset'],
                              help='Configuration action')
    config_parser.add_argument('key', nargs='?', help='Configuration key')
    config_parser.add_argument('value', nargs='?', help='Configuration value')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(0)
    
    if args.command == 'download':
        download_command(args)
    elif args.command == 'batch':
        batch_download_command(args)
    elif args.command == 'list-databases':
        list_databases_command()
    elif args.command == 'config':
        config_command(args)


if __name__ == '__main__':
    main()

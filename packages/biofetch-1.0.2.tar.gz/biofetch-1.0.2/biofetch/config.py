# Handles user and default configuration
"""
Configuration management
"""

import json
from pathlib import Path
from typing import Dict, Any, Optional


class BioFetchConfig:
    """Manage BioFetch configuration"""
    
    DEFAULT_CONFIG = {
        'output_dir': './biofetch_data',
        'num_retries': 3,
        'timeout': 300,
        'parallel_downloads': 1,
        'validate_format': True,
        'compute_checksum': True,
        'log_level': 'INFO'
    }
    
    def __init__(self, config_file: Optional[Path] = None):
        """
        Initialize configuration
        
        Args:
            config_file: Path to config file (default: ~/.biofetch/config.json)
        """
        if config_file is None:
            config_dir = Path.home() / '.biofetch'
            config_dir.mkdir(exist_ok=True)
            config_file = config_dir / 'config.json'
        
        self.config_file = Path(config_file)
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    return {**self.DEFAULT_CONFIG, **json.load(f)}
            except Exception:
                return self.DEFAULT_CONFIG.copy()
        return self.DEFAULT_CONFIG.copy()
    
    def _save_config(self):
        """Save configuration to file"""
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_file, 'w') as f:
            json.dump(self.config, f, indent=2)
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value"""
        return self.config.get(key, default)
    
    def set(self, key: str, value: Any):
        """Set configuration value"""
        self.config[key] = value
        self._save_config()
    
    def get_all(self) -> Dict[str, Any]:
        """Get all configuration"""
        return self.config.copy()
    
    def reset(self):
        """Reset configuration to defaults"""
        self.config = self.DEFAULT_CONFIG.copy()
        self._save_config()

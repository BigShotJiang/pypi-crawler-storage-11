"""
BioFetch Downloader - Core download functionality with auto-decompression
"""

import asyncio
import hashlib
import logging
import gzip
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

import requests

from .databases import get_download_url, SUPPORTED_DATABASES
from .validators import validate_accession
from .utils import format_size

logger = logging.getLogger(__name__)


class BioFetchDownloader:
    """Main downloader class for BioFetch"""
    
    def __init__(
        self,
        output_dir: str = "./biofetch_data",
        num_retries: int = 3,
        timeout: int = 300,
        chunk_size: int = 8192
    ):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.num_retries = num_retries
        self.timeout = timeout
        self.chunk_size = chunk_size
        self.metadata_file = self.output_dir / "metadata.json"
    
    def download(
        self,
        accession: str,
        database: str,
        validate: bool = True,
        on_progress: Optional[Callable] = None
    ) -> Dict:
        """Download single file"""
        if database not in SUPPORTED_DATABASES:
            return {
                'success': False,
                'accession': accession,
                'error': f'Unsupported database: {database}'
            }
        
        if validate and not validate_accession(accession, database):
            return {
                'success': False,
                'accession': accession,
                'error': f'Invalid accession format for {database}'
            }
        
        url = get_download_url(accession, database)
        if not url:
            return {
                'success': False,
                'accession': accession,
                'error': 'Could not generate download URL'
            }
        
        ext = SUPPORTED_DATABASES[database]['file_extension']
        file_path = self.output_dir / f"{accession}{ext}"
        
        logger.info(f"Downloading {accession} from {database}")
        
        # Download with retry
        for attempt in range(self.num_retries):
            try:
                success = self._download_file(url, file_path, on_progress)
                if success:
                    # Auto-decompress if it's a gzipped file
                    file_path = self._auto_decompress(file_path)
                    
                    checksum = self._compute_checksum(file_path)
                    file_size = file_path.stat().st_size
                    
                    logger.info(f"Download completed: {accession} ({format_size(file_size)})")
                    
                    return {
                        'success': True,
                        'accession': accession,
                        'database': database,
                        'file_path': str(file_path),
                        'file_size': file_size,
                        'checksum': checksum
                    }
                
            except Exception as e:
                logger.warning(f"Download attempt {attempt + 1} failed: {str(e)}")
                if attempt < self.num_retries - 1:
                    wait_time = 2 ** attempt
                    logger.info(f"Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
        
        return {
            'success': False,
            'accession': accession,
            'error': f'Download failed after {self.num_retries} attempts'
        }
    
    def _auto_decompress(self, file_path: Path) -> Path:
        """Auto-decompress gzipped files"""
        try:
            # Check if file is gzipped by reading first bytes
            with open(file_path, 'rb') as f:
                magic = f.read(2)
            
            if magic == b'\x1f\x8b':  # Gzip magic number
                logger.info(f"Detected gzipped file, decompressing...")
                
                # Create decompressed filename
                if file_path.suffix == '.gz':
                    output_path = file_path.with_suffix('')
                else:
                    output_path = file_path.parent / f"{file_path.stem}_decompressed{file_path.suffix}"
                
                # Decompress
                with gzip.open(file_path, 'rb') as f_in:
                    with open(output_path, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
                
                # Remove compressed file
                file_path.unlink()
                
                logger.info(f"Decompressed to: {output_path}")
                return output_path
        
        except Exception as e:
            logger.warning(f"Could not decompress file: {str(e)}")
        
        return file_path
    
    def _download_file(
        self,
        url: str,
        file_path: Path,
        on_progress: Optional[Callable] = None
    ) -> bool:
        """Download file from URL"""
        try:
            response = requests.get(url, stream=True, timeout=self.timeout)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            with open(file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=self.chunk_size):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        if on_progress and total_size > 0:
                            on_progress(downloaded, total_size)
            
            return True
            
        except Exception as e:
            logger.error(f"Download error: {str(e)}")
            if file_path.exists():
                file_path.unlink()
            raise
    
    def batch_download(
        self,
        accessions: List[str],
        database: str,
        parallel: int = 1,
        validate: bool = True
    ) -> List[Dict]:
        """Download multiple files"""
        logger.info(f"Starting batch download: {len(accessions)} files from {database}")
        
        results = []
        
        if parallel == 1:
            for accession in accessions:
                result = self.download(accession, database, validate=validate)
                results.append(result)
        else:
            with ThreadPoolExecutor(max_workers=parallel) as executor:
                futures = {
                    executor.submit(self.download, acc, database, validate): acc
                    for acc in accessions
                }
                
                for future in as_completed(futures):
                    result = future.result()
                    results.append(result)
        
        success_count = sum(1 for r in results if r['success'])
        logger.info(f"Batch download complete: {success_count}/{len(accessions)} successful")
        
        return results
    
    async def async_download(
        self,
        accession: str,
        database: str,
        validate: bool = True
    ) -> Dict:
        """Asynchronous download"""
        try:
            import aiohttp
            import aiofiles
        except ImportError:
            return {
                'success': False,
                'accession': accession,
                'error': 'aiohttp and aiofiles required for async downloads'
            }
        
        if database not in SUPPORTED_DATABASES:
            return {'success': False, 'accession': accession, 'error': f'Unsupported database: {database}'}
        
        if validate and not validate_accession(accession, database):
            return {'success': False, 'accession': accession, 'error': f'Invalid accession format'}
        
        url = get_download_url(accession, database)
        if not url:
            return {'success': False, 'accession': accession, 'error': 'Could not generate URL'}
        
        ext = SUPPORTED_DATABASES[database]['file_extension']
        file_path = self.output_dir / f"{accession}{ext}"
        
        try:
            success = await self._async_download_file(url, file_path, aiohttp, aiofiles)
            
            if success:
                file_path = self._auto_decompress(file_path)
                checksum = self._compute_checksum(file_path)
                file_size = file_path.stat().st_size
                
                return {
                    'success': True,
                    'accession': accession,
                    'database': database,
                    'file_path': str(file_path),
                    'file_size': file_size,
                    'checksum': checksum
                }
        
        except Exception as e:
            logger.error(f"Async download failed for {accession}: {str(e)}")
        
        return {'success': False, 'accession': accession, 'error': 'Download failed'}
    
    async def _async_download_file(self, url: str, file_path: Path, aiohttp, aiofiles) -> bool:
        """Asynchronous file download"""
        try:
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url) as response:
                    if response.status != 200:
                        return False
                    
                    async with aiofiles.open(file_path, 'wb') as f:
                        async for chunk in response.content.iter_chunked(self.chunk_size):
                            await f.write(chunk)
            
            return True
            
        except Exception as e:
            logger.error(f"Async download error: {str(e)}")
            if file_path.exists():
                file_path.unlink()
            return False
    
    def _compute_checksum(self, file_path: Path) -> str:
        """Compute MD5 checksum"""
        md5 = hashlib.md5()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                md5.update(chunk)
        return md5.hexdigest()
    
    def get_metadata(self, accession: str) -> Optional[Dict]:
        """Get metadata for downloaded file"""
        pass
    
    def validate_file(self, file_path: Path, expected_checksum: Optional[str] = None) -> bool:
        """Validate downloaded file"""
        if not file_path.exists():
            return False
        
        if file_path.stat().st_size == 0:
            return False
        
        if expected_checksum:
            actual_checksum = self._compute_checksum(file_path)
            return actual_checksum == expected_checksum
        
        return True

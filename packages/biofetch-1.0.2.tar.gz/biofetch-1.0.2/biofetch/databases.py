"""
Database configurations and URL generators
"""

SUPPORTED_DATABASES = {
    'sra': {
        'name': 'Sequence Read Archive (NCBI)',
        'base_url': 'https://trace.ncbi.nlm.nih.gov/Traces/sra-reads-be/fastq',
        'file_extension': '.fastq',
        'validation_prefixes': ['SRR', 'ERR', 'DRR'],
        'example_ids': ['SRR000001', 'SRR000002'],
        'description': 'Raw sequencing data'
    },
    'genbank': {
        'name': 'GenBank (NCBI)',
        'base_url': 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi',
        'file_extension': '.fasta',
        'validation_prefixes': ['NC_', 'NT_', 'NW_', 'NZ_', 'AC_', 'NM_'],
        'example_ids': ['NC_045512', 'NC_000001'],
        'description': 'Nucleotide sequences'
    },
    'ena': {
        'name': 'European Nucleotide Archive',
        'base_url': 'https://www.ebi.ac.uk/ena/browser/api/fasta',
        'file_extension': '.fasta',
        'validation_prefixes': ['ERR', 'SRR', 'DRR', 'ERZ', 'SRZ'],
        'example_ids': ['A00145', 'U00096'],  # Changed to working examples
        'description': 'Nucleotide archive'
    },
    'uniprot': {
        'name': 'Universal Protein Resource',
        'base_url': 'https://rest.uniprot.org/uniprotkb',
        'file_extension': '.fasta',
        'validation_prefixes': ['P', 'Q', 'O', 'A', 'B', 'C'],
        'example_ids': ['P04637', 'Q9Y261'],
        'description': 'Protein sequences'
    },
    'pdb': {
        'name': 'Protein Data Bank',
        'base_url': 'https://files.rcsb.org/download',
        'file_extension': '.pdb',
        'validation_prefixes': [],
        'example_ids': ['1A0O', '3J3Q', '7BV2'],
        'description': 'Protein structures'
    },
    'geo': {
        'name': 'Gene Expression Omnibus',
        'base_url': 'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi',
        'file_extension': '.txt',
        'validation_prefixes': ['GSE', 'GSM', 'GPL', 'GDS'],
        'example_ids': ['GSE68849', 'GSE10072'],  # Changed to working examples
        'description': 'Gene expression data'
    }
}


def get_download_url(accession: str, database: str) -> str:
    """Generate download URL for given accession"""
    if database not in SUPPORTED_DATABASES:
        return None
    
    config = SUPPORTED_DATABASES[database]
    
    if database == 'genbank':
        return f"{config['base_url']}?db=nucleotide&id={accession}&rettype=fasta&retmode=text"
    
    elif database == 'uniprot':
        return f"{config['base_url']}/{accession}.fasta"
    
    elif database == 'pdb':
        return f"{config['base_url']}/{accession.upper()}.pdb"
    
    elif database == 'ena':
        # ENA direct download - try multiple endpoints
        return f"https://www.ebi.ac.uk/ena/browser/api/fasta/{accession}?download=true"
    
    elif database == 'sra':
        return f"{config['base_url']}?acc={accession}"
    
    elif database == 'geo':
        # GEO downloads - handle different types
        if accession.startswith('GSE'):
            # Series - download SOFT family file (it's gzipped)
            series_num = accession[3:]
            folder_num = series_num[:-3] + 'nnn'
            return f"https://ftp.ncbi.nlm.nih.gov/geo/series/GSE{folder_num}/{accession}/soft/{accession}_family.soft.gz"
        else:
            # Sample or Platform
            return f"{config['base_url']}?acc={accession}&targ=self&form=text&view=brief"
    
    return None
       


from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="biofetch",
    version="1.0.2",
    author="Ananaya",
    author_email="jainananaya1@gmail.com",
    description="Unified Bioinformatics Data Downloader - CLI and Python Package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Ananaya-J/Biofetch",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
        ],
        "all": [
            "rich>=13.0.0",  # Beautiful terminal output
            "tqdm>=4.65.0",  # Progress bars
        ],
    },
    entry_points={
        "console_scripts": [
            "biofetch=biofetch.cli:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)

import asyncio
import logging
import pyudev
from evdev import InputDevice, categorize, ecodes

# --------------------------------------------------------------------------
# LOGGING CONFIG
# --------------------------------------------------------------------------
logger = logging.getLogger(__name__)
if not logger.hasHandlers():
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )


class MultiInputDeviceMonitor:
    def __init__(self):
        self.filters = []  # Each filter is a dict of filter criteria + callback
        self.active_tasks = {}
        self.context = pyudev.Context()
        self.loop = None
        self.monitor = None
        self.monitor_task = None

    # --------------------------------------------------------------------------
    # DEVICE FILTER MANAGEMENT
    # --------------------------------------------------------------------------
    def add_device_filter(self, *, vendor_id=None, product_id=None, mac=None, name=None, callback=None):
        """
        Register a new device filter with an optional callback.
        callback(dev, key_event) is invoked for key events.
        """
        logger.debug("Adding device filter vendor_id=%s, product_id=%s, mac=%s name=%s", vendor_id, product_id, mac, name)
        self.filters.append({
            "vendor_id": vendor_id.lower() if vendor_id else None,
            "product_id": product_id.lower() if product_id else None,
            "mac": mac.lower().replace(":", "_") if mac else None,
            "name": name.lower() if name else None,
            "callback": callback,
        })

    def _matches_filter(self, dev: InputDevice, udev_device):
        """Return callback if device matches a registered filter"""
        vendor = f"{dev.info.vendor:04x}"
        product = f"{dev.info.product:04x}"
        mac = udev_device.sys_path.lower()
        name = dev.name.lower()
        logger.debug("Checking if device matches filter - vendor: %s, product: %s, mac: %s, name: %s", vendor, product, mac, name)
        for f in self.filters:
            if f["vendor_id"] and vendor != f["vendor_id"]:
                continue
            if f["product_id"] and product != f["product_id"]:
                continue
            if f["mac"] and f["mac"] not in mac:
                continue
            if f["name"] and f["name"] not in name:
                continue
            logger.debug("Device match found")
            return f["callback"]  # Matched all applicable fields
        logger.debug("Device not matched")
        return None

    def _is_allowed_device(self, udev_device):
        """Check if device matches any registered filter"""
        if not udev_device.device_node:
            logger.warning("Device node %s not found.", udev_device)
            return None

        try:
            dev = InputDevice(udev_device.device_node)
        except (OSError, FileNotFoundError):
            logger.exception("Could not find device %s", udev_device.device_node)
            return None

        return self._matches_filter(dev, udev_device)

    # --------------------------------------------------------------------------
    # EVENT HANDLERS
    # --------------------------------------------------------------------------
    async def _read_keys(self, path, callback):
        """Async reader for key events"""
        try:
            dev = InputDevice(path)
            logger.info("Listening on %s (%s)", dev.name, dev.path)

            async for event in dev.async_read_loop():
                if event.type == ecodes.EV_KEY:
                    key_event = categorize(event)
                    logger.debug("%s: %s", dev.name, key_event)
                    if callback:
                        result = callback(dev, key_event)
                        if asyncio.iscoroutine(result):
                            await result
        except OSError:
            logger.warning("Device %s disconnected", path)
        except asyncio.CancelledError:
            logger.info(f"Stopped listening on %s",path)
        finally:
            # Clean up when task ends
            self.active_tasks.pop(path, None)

    # --------------------------------------------------------------------------
    # DEVICE ATTACH / REMOVE
    # --------------------------------------------------------------------------
    def _attach_existing_devices(self):
        """Attach to already-connected matching devices"""
        for device in self.context.list_devices(subsystem="input"):
            logger.info("Attaching %s", device.device_node)
            callback = self._is_allowed_device(device)
            if callback:
                path = device.device_node
                if path not in self.active_tasks:
                    task = asyncio.create_task(self._read_keys(path, callback))
                    self.active_tasks[path] = task
                    logger.info("Found existing input: %s", path)
                else:
                    logger.info("Device is already being monitored %s", device.name)
            else:
                logger.info("No call back found for device %s", device.device_node)

    async def _monitor_udev_events(self):
        """Async loop to monitor udev events"""
        while True:
            # Use run_in_executor to poll without blocking
            device = await self.loop.run_in_executor(None, self.monitor.poll, 1)
            
            if device is not None and device.device_node:
                path = device.device_node
                logger.debug("Device (%s) message", path)

                if device.action == "add":
                    logger.info("Adding device %s", path)
                    # Wait up to 2s for device to be ready, trying every 0.1s
                    callback = None
                    for _ in range(20):
                        callback = self._is_allowed_device(device)
                        if callback:
                            break
                        await asyncio.sleep(0.1)

                    if callback and path not in self.active_tasks:
                        logger.info(f"Device added: {path}")
                        task = asyncio.create_task(self._read_keys(path, callback))
                        self.active_tasks[path] = task
                    else:
                        logger.info("No call back found for device %s", path)

                elif device.action == "remove":
                    logger.info("Device removed: %s", path)
                    task = self.active_tasks.pop(path, None)
                    if task:
                        task.cancel()
                else:
                    logger.debug("Unknown action %s", device.action)

    # --------------------------------------------------------------------------
    # MAIN LOOP
    # --------------------------------------------------------------------------
    async def run(self):
        """Run the main async loop"""
        self.loop = asyncio.get_running_loop()
        self._attach_existing_devices()

        self.monitor = pyudev.Monitor.from_netlink(self.context)
        self.monitor.filter_by(subsystem="input")
        self.monitor.start()

        # Start the monitoring task
        self.monitor_task = asyncio.create_task(self._monitor_udev_events())

        logger.info("Monitoring all registered devices...")
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            pass
        finally:
            if self.monitor_task:
                self.monitor_task.cancel()
                try:
                    await self.monitor_task
                except asyncio.CancelledError:
                    pass
            
            tasks_to_cancel = list(self.active_tasks.values())
            for task in tasks_to_cancel:
                task.cancel()
            
            # Wait for all tasks to complete
            if tasks_to_cancel:
                await asyncio.gather(*tasks_to_cancel, return_exceptions=True)
            
            logger.info("Stopped monitoring.")

# --------------------------------------------------------------------------
# MAIN TEST / EXAMPLE
# --------------------------------------------------------------------------
if __name__ == "__main__":
    def k400_callback(dev, key_event):
        logger.info(f"[K400] {key_event.keycode} {key_event.keystate}")

    async def presenter_callback(dev, key_event):
        await asyncio.sleep(0.01)  # simulate async work
        logger.info(f"[Presenter] {key_event.keycode} {key_event.keystate}")

    monitor = MultiInputDeviceMonitor()
    monitor.add_device_filter(vendor_id="046d", product_id="c52b", name="K400", callback=k400_callback)
    monitor.add_device_filter(name="AR Keyboard", callback=presenter_callback)

    asyncio.run(monitor.run())

import{c as e}from"./index-tD243MzK.js";const t=[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]],a=e("calendar",t);export{a as C};
//# sourceMappingURL=calendar-By3PkG2x.js.map

"""Core vMCP functionality."""

git clean -fx

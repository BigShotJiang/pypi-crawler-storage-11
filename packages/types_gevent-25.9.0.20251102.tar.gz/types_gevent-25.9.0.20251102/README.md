## Typing stubs for gevent

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`gevent`](https://github.com/gevent/gevent) package. It can be used by type checkers
to check code that uses `gevent`. This version of
`types-gevent` aims to provide accurate annotations for
`gevent==25.9.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/gevent`](https://github.com/python/typeshed/tree/main/stubs/gevent)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.18.2
* [pyright](https://github.com/microsoft/pyright) 1.1.407

It was generated from typeshed commit
[`8aaa86f6a4b5f518734973884d14bf4da0f6f399`](https://github.com/python/typeshed/commit/8aaa86f6a4b5f518734973884d14bf4da0f6f399).
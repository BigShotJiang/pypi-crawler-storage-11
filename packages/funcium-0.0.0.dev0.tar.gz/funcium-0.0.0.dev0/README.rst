=======
funcium
=======

Overview
--------

funcium

Installation
------------

To install ``funcium``, you can use ``pip``. Open your terminal and run:

.. code-block:: bash

    pip install funcium

License
-------

This project is licensed under the MIT License.

Links
-----

* `Download <https://pypi.org/project/funcium/#files>`_
* `Index <https://pypi.org/project/funcium/>`_
* `Source <https://github.com/johannes-programming/funcium/>`_

Credits
-------

* Author: Johannes
* Email: `johannes.programming@gmail.com <mailto:johannes.programming@gmail.com>`_

Thank you for using ``funcium``!
from funcium.core import *
from funcium.tests import *

if __name__ == "__main__":
    main()

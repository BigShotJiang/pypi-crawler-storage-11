#!/usr/bin/env bash

VERSION="0.0.12"
python3 -m build
python3 -m twine upload dist/ccda_to_omop-${VERSION}-py3-none-any.whl dist/ccda_to_omop-${VERSION}.tar.gz

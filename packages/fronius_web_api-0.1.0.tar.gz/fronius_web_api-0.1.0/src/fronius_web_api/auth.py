import hashlib
import os
import time
from urllib.parse import urlparse

import requests
from requests.auth import HTTPDigestAuth

class HTTPFroniusDigestAuth(HTTPDigestAuth):
    def __init__(self, username, password):
        super().__init__(username, password)

    def build_digest_header(self, method, url):
        realm = self._thread_local.chal["realm"]
        nonce = self._thread_local.chal["nonce"]
        qop = self._thread_local.chal.get("qop")
        algorithm = self._thread_local.chal.get("algorithm")
        opaque = self._thread_local.chal.get("opaque")
        hash_utf8 = None

        if algorithm is None:
            algorithm_normalized = "MD5"
        else:
            # FRONIUS: Support hash algorithm names without dashes
            algorithm_normalized = algorithm.upper().replace("-", "")
        # lambdas assume digest modules are imported at the top level
        def md5_utf8(x):
            if isinstance(x, str):
                x = x.encode("utf-8")
            return hashlib.md5(x).hexdigest()
        if algorithm_normalized == "MD5" or algorithm_normalized == "MD5-SESS":
            hash_utf8 = md5_utf8
        elif algorithm_normalized == "SHA":

            def sha_utf8(x):
                if isinstance(x, str):
                    x = x.encode("utf-8")
                return hashlib.sha1(x).hexdigest()

            hash_utf8 = sha_utf8
        elif algorithm_normalized == "SHA256":

            def sha256_utf8(x):
                if isinstance(x, str):
                    x = x.encode("utf-8")
                return hashlib.sha256(x).hexdigest()

            hash_utf8 = sha256_utf8
        elif algorithm_normalized == "SHA512":

            def sha512_utf8(x):
                if isinstance(x, str):
                    x = x.encode("utf-8")
                return hashlib.sha512(x).hexdigest()

            hash_utf8 = sha512_utf8

        KD = lambda s, d: hash_utf8(f"{s}:{d}")  # noqa:E731

        if hash_utf8 is None:
            return None

        p_parsed = urlparse(url)
        #: path is request-uri defined in RFC 2616 which should not be empty
        path = p_parsed.path or "/"
        if p_parsed.query:
            path += f"?{p_parsed.query}"

        A1 = f"{self.username}:{realm}:{self.password}"
        A2 = f"{method}:{path}"

        # FRONIUS: Fronius always uses MD5 hash for the first part
        HA1 = md5_utf8(A1)
        HA2 = hash_utf8(A2)

        if nonce == self._thread_local.last_nonce:
            self._thread_local.nonce_count += 1
        else:
            self._thread_local.nonce_count = 1
        ncvalue = f"{self._thread_local.nonce_count:08x}"
        s = str(self._thread_local.nonce_count).encode("utf-8")
        s += nonce.encode("utf-8")
        s += time.ctime().encode("utf-8")
        s += os.urandom(8)

        cnonce = hashlib.sha1(s).hexdigest()[:16]
        if algorithm_normalized == "MD5-SESS":
            HA1 = hash_utf8(f"{HA1}:{nonce}:{cnonce}")

        if not qop:
            respdig = KD(HA1, f"{nonce}:{HA2}")
        elif qop == "auth" or "auth" in qop.split(","):
            noncebit = f"{nonce}:{ncvalue}:{cnonce}:auth:{HA2}"
            respdig = KD(HA1, noncebit)
        else:
            # XXX handle auth-int.
            return None

        self._thread_local.last_nonce = nonce

        # XXX should the partial digests be encoded too?
        base = (
            f'username="{self.username}", realm="{realm}", nonce="{nonce}", '
            f'uri="{path}", response="{respdig}"'
        )
        if opaque:
            base += f', opaque="{opaque}"'
        if algorithm:
            base += f', algorithm="{algorithm}"'
        if qop:
            base += f', qop=auth, nc={ncvalue}, cnonce="{cnonce}"'

        return f"Digest {base}"

    def handle_401(self, r, **kwargs):
        """
        Takes the given response and tries digest-auth, if needed.

        :rtype: requests.Response
        """

        # FRONIUS: Support "X-WWW-Authenticate" header
        if "X-WWW-Authenticate" in r.headers and "WWW-Authenticate" not in r.headers:
            r.headers["WWW-Authenticate"] = r.headers.get("X-WWW-Authenticate", "")
        return HTTPDigestAuth.handle_401(self, r, **kwargs)

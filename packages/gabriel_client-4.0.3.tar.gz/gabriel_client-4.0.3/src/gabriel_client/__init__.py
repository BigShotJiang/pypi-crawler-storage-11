"""Gabriel client module."""

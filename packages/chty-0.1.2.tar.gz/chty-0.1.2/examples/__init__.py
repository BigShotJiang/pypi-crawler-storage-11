"""Examples for chty."""

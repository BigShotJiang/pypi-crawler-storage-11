"""Generated code from chty."""

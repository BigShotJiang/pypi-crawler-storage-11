# Status of this document

This document is the product of the [Common Workflow Language working
group](https://www.commonwl.org/).  The
source for the latest version of this document is available at

https://github.com/common-workflow-language/cwl-v1.2/

The products of the CWL working group (including this document) are made available
under the terms of the Apache License, version 2.0.

<!--ToC-->

# Introduction

The Common Workflow Language (CWL) working group is an informal, multi-vendor
working group consisting of various organizations and individuals that have an
interest in portability of data analysis workflows.  The goal is to create
specifications like this one that enable data scientists to describe analysis
tools and workflows that are powerful, easy to use, portable, and support
reproducibility.

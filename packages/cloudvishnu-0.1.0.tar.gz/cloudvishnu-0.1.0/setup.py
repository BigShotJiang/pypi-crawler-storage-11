from setuptools import setup, find_packages

setup(
    name="cloudvishnu",
    version="0.1.0",
    author="Vishnu",
    author_email="sathishdhuda25@gmail.com",
    description="Vishnu Scammer",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)

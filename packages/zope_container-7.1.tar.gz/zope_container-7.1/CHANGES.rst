=========
 Changes
=========

7.1 (2025-11-06)
================

- Add support for Python 3.14.

- Drop support for Python 3.9.


7.0 (2025-09-12)
================

- Replace ``pkg_resources`` namespace with PEP 420 native namespace.

- Drop support for Python 3.8.

- Add preliminary support for Python 3.14.

- Update docs config to ``Sphinx >=8``.


6.1 (2024-09-18)
================

- Add final support for Python 3.13.

- Update to ``persistent`` 6.0 API usage


6.0 (2024-05-29)
================

- Drop support for Python 3.7.

- Build Windows wheels on GHA.

- Add preliminary support for Python 3.13 as of 3.13a6.


5.2 (2023-10-05)
================

- Add support for Python 3.12.


5.1 (2023-04-24)
================

- Drop using ``setup_requires`` due to constant problems on GHA.

- Add preliminary support for Python 3.12a7.


5.0 (2023-01-24)
================

- Build Linux binary wheels for Python 3.11.

- Drop support for Python 2.7, 3.5, 3.6.


4.10 (2022-11-17)
=================

- Release to rebuild a full set of binary wheels.


4.9 (2022-11-16)
================

- Add support for building arm64 wheels on macOS.

4.8 (2022-11-06)
================

- Add support for final Python 3.11 release.


4.7 (2022-09-15)
================

- Disable unsafe math optimizations in C code.  See `pull request 46
  <https://github.com/zopefoundation/zope.container/pull/46>`_.


4.6 (2022-07-14)
================

- Add support for Python 3.11 (as of 3.11.0b3).


4.5.0 (2021-11-19)
==================

- Add support for Python 3.9 and 3.10.


4.4.0 (2020-04-02)
==================

- Support the ``PURE_PYTHON`` environment variable at runtime instead
  of just at wheel build time. A value of 0 forces the C extensions to
  be used failing if they aren't present. Any other value forces the
  Python implementation to be used, ignoring the C extensions.

- Drop support for the deprecated ``python setup.py test`` command.

- Ensure all objects have consistent interface resolution orders. This
  may slightly change the order of interfaces for ``ContainedProxy``
  objects. See `issue 34 <https://github.com/zopefoundation/zope.container/issues/34>`_.

- Stop including outdated versions of ``zope.proxy`` (implementation)
  and ``persistent`` headers. Instead, locate and use the installed
  versions. See `issue 32
  <https://github.com/zopefoundation/zope.container/issues/32>`_.

  .. note::

     This adds those two dependencies to ``setup_requires``.


4.3.0 (2019-11-11)
==================

- Add support for Python 3.8.

- Drop support for Python 3.4.


4.2.2 (2018-08-10)
==================

- Add a dependency on ``zope.cachedescriptors``, previously removed in
  3.11. ``zope.cachedescriptors`` is a lightweight package, and the
  copied code had diverged from the source. See
  https://github.com/zopefoundation/zope.container/issues/16

- Fix the possibility of a rare crash in the C extension when deallocating items. See
  https://github.com/zopefoundation/zope.container/issues/24

- Add support for Python 3.7.


4.2.1 (2017-08-02)
==================

- Make ``OrderedContainer.updateOrder`` normalize and store text keys
  the same way that ``__setitem__`` does. Fixes
  https://github.com/zopefoundation/zope.container/issues/21


4.2.0 (2017-07-31)
==================

- Add support for Python 3.5 and 3.6.

- Drop support for Python 2.6 and 3.3.

- Make ``OrderedContainer`` properly store the decoded text keys for
  maintaining order instead of the raw bytes. Also make it able to
  accept raw bytes under Python 3 in the first place. Fixes
  https://github.com/zopefoundation/zope.container/issues/17

- Fix ``OrderedContainer`` becoming inconsistent if an event
  subscriber threw an exception when adding an item. See
  https://github.com/zopefoundation/zope.container/issues/18

- Attain 100% test coverage. See
  https://github.com/zopefoundation/zope.container/issues/15

- Make the default ``NameChooser`` always decode bytes using ASCII instead of
  whatever the current system codec happens to be.

- Make the default ``NameChooser`` stop catching ``KeyboardInterrupt``
  and other ``BaseException`` types when it potentially calls
  user-defined code to convert a name to a text string. Instead, just
  catch ``Exception``.

- Respect the ``PURE_PYTHON`` environment variable at runtime in
  addition to build time. This makes it possible to use the
  pure-Python implementation of the container proxy on CPython for
  ease of debugging. See https://github.com/zopefoundation/zope.container/issues/13

4.1.0 (2015-05-22)
==================

- Make ``zope.container._proxy.PyContainedProxyBase`` inherit
  directly from ``zope.proxy.AbstractProxyBase`` as well as
  ``persistent.Persistent``, removing a bunch of redundant code, and
  fixing bugs in interaction with pure-Python persistence. See:
  https://github.com/zopefoundation/zope.container/pull/4

- Add direct dependencies on ``zope.proxy`` and ``persistent`` since we
  import from them; pin them to the versions needed for pure-Python.

- Drop deprecated BBB imports module, ``zope.container.dependency``.

4.0.0 (2014-03-19)
==================

- Add support for Python 3.4.

- Add support for PyPy.


4.0.0a3 (2013-02-28)
====================

- Restore ``Folder`` pickle forward/backward compatibility with
  version 3.12.0 after making it inherit from ``BTreeContainer.``


4.0.0a2 (2013-02-21)
====================

- Allow testing without checkouts of unreleased ``zope.publisher`` and
  ``ZODB``.

- Add Python 3 Trove classifiers.


4.0.0a1 (2013-02-20)
====================

- Add support for Python 3.3.

- Make ``Folder`` class inherit from ``BTreeContainer`` class, so that the
  IContainer interface does not need to be re-implemented. Added a ``data``
  attribute for BBB.

- Replace deprecated ``zope.component.adapts`` usage with equivalent
  ``zope.component.adapter`` decorator.

- Replace deprecated ``zope.interface.implements`` usage with equivalent
  ``zope.interface.implementer`` decorator.

- Drop support for Python 2.4 and 2.5.

- Send ``IContainerModifiedEvent`` *after* the container is modified
  (LP#705600).

- Preserve the original exception traceback in
  ``OrderedContainer.__setitem__``.

- Handle Broken Objects more gracefully

- Fix a bug that made it impossible to store None values in containers
  (LP#1070719).


3.12.0 (2010-12-14)
===================

- Fix detection of moving folders into itself or a subfolder of itself.
  (LP#118088)

- Fix ZCML-related tests and dependencies.

- Add ``zcml`` extra dependencies.

3.11.1 (2010-04-30)
===================

- Prefer the standard libraries doctest module to the one from ``zope.testing``.

- Add compatibility with ZODB3 3.10 by importing the ``IBroken`` interface
  from it directly. Once we can rely on the new ZODB3 version exclusively,
  we can remove the dependency onto the ``zope.broken`` distribution.

- Never fail if the suggested name is in a wrong type (#227617)

- ``checkName`` first checks the parameter type before the emptiness.

3.11.0 (2009-12-31)
===================

- Copy two trivial classes from ``zope.cachedescriptors`` into this package,
  which allows us to remove that dependency. We didn't actually use any
  caching properties as the dependency suggested.

3.10.1 (2009-12-29)
===================

- Move ``zope.copypastemove`` related tests into that package.

- Remove no longer used zcml prefix from the configure file.

- Stop importing DocTestSuite from ``zope.testing.doctestunit``. Fixes
  compatibility problems with ``zope.testing`` 3.8.4.

3.10.0 (2009-12-15)
===================

- Break testing dependency on ``zope.app.testing``.

- Break testing dependency on ``zope.app.dependable`` by moving the code and
  tests into that package.

- Import ``ISite`` from ``zope.component`` after it was moved there from
  ``zope.location``.

3.9.1 (2009-10-18)
==================

- Rerelease 3.9.0 as it had a broken Windows 2.6 egg.

- Mark this project as part of the ZTK.

3.9.0 (2009-08-28)
==================

- Previous releases should be versioned 3.9.0 as they are not pure bugfix
  releases and worth a "feature" release, increasing feature version.

  Packages that depend on any changes introduced in version 3.8.2 or 3.8.3
  should depend on version 3.9 or greater.

3.8.3 (2009-08-27)
==================

- Move ``IXMLRPCPublisher`` ZCML registrations for containers from
  ``zope.app.publisher.xmlrpc`` to ``zope.container`` for now.

3.8.2 (2009-05-17)
==================

- Rid ourselves of ``IContained`` interface.  This interface was moved
  to ``zope.location.interfaces``.  A b/w compat import still exists
  to keep old code running.  Depend on ``zope.location``>=3.5.4.

- Rid ourselves of the implementations of ``IObjectMovedEvent``,
  ``IObjectAddedEvent``, ``IObjectRemovedEvent`` interfaces and
  ``ObjectMovedEvent``, ``ObjectAddedEvent`` and
  ``ObjectRemovedEvent`` classes.  B/w compat imports still exist.
  All of these were moved to ``zope.lifecycleevent``. Depend on
  ``zope.lifecycleevent``>=3.5.2.

- Fix a bug in ``OrderedContainer`` where trying to set the value for a
  key that already exists (duplication error) would actually delete the
  key from the order, leaving a dangling reference.

- Partially break dependency on ``zope.traversing`` by disusing
  ``zope.traversing.api.getPath`` in favor of using
  ``ILocationInfo(object).getPath()``.  The rest of the runtime
  dependencies on ``zope.traversing`` are currently interface
  dependencies.

- Break runtime dependency on ``zope.app.dependable`` by using a zcml
  condition on the subscriber ZCML directive that registers the
  ``CheckDependency`` handler for ``IObjectRemovedEvent``.  If
  ``zope.app.dependable`` is not installed, this subscriber will never
  be registered.  ``zope.app.dependable`` is now a testing dependency
  only.

3.8.1 (2009-04-03)
==================

- Fix misspackaged 3.8.0


3.8.0 (2009-04-03)
==================

- Change ``configure.zcml`` to not depend on ``zope.app.component``.
  Fixes: https://bugs.launchpad.net/bugs/348329

- Move the declaration of ``IOrderedContainer.updateOrder``  to a new, basic
  ``IOrdered`` interface and let ``IOrderedContainer`` inherit it. This allows
  easier reuse of the declaration.

3.7.2 (2009-03-12)
==================

- Fix: added missing ``ComponentLookupError``, missing since revision 95429
  and missing in last release.

- Adapt to the move of IDefaultViewName from ``zope.component.interfaces``
  to ``zope.publisher.interfaces``.

- Add support for reserved names for containers. To specify reserved
  names for some container, you need to provide an adapter from the
  container to the ``zope.container.interfaces.IReservedNames`` interface.
  The default ``NameChooser`` is now also aware of reserved names.

3.7.1 (2009-02-05)
==================

- Raise more "Pythonic" errors from ``__setitem__``, losing the dependency
  on ``zope.exceptions``:

  o ``zope.exceptions.DuplicationError`` -> ``KeyError``

  o ``zope.exceptions.UserError`` -> ``ValueError``

- Move import of ``IBroken`` interface to use new ``zope.broken``
  package, which has no dependencies beyond ``zope.interface``.

- Make ``test`` part pull in the extra test requirements of this package.

- Split the ``z3c.recipe.compattest`` configuration out into a new file,
  ``compat.cfg``, to reduce the burden of doing standard unit tests.

- Strip out bogus develop eggs from ``buildout.cfg``.

3.7.0 (2009-01-31)
==================

- Split this package off ``zope.app.container``. This package is
  intended to have far less dependencies than ``zope.app.container``.

- This package also contains the container implementation that
  used to be in ``zope.app.folder``.

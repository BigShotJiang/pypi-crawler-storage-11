"""
Chat API endpoints for managing conversations.
Timestamp: 2025-11-02 20:15
"""
from fastapi import APIRouter, HTTPException, Request, Depends
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import uuid
import os

# Import Aurica Auth SDK
try:
    from src.aurica_auth import protected, get_current_user, public
except ImportError:
    # Fallback if running in different context
    print("⚠️  Warning: Could not import aurica_auth SDK")
    def protected(func):
        return func
    def get_current_user(request, required=True):
        return type('User', (), {"username": "unknown", "user_id": "unknown"})()
    def public(func):
        return func

# Import Digital Twin client
import sys
from pathlib import Path

# Add parent directory to path for imports
chat_be_dir = Path(__file__).parent.parent
if str(chat_be_dir) not in sys.path:
    sys.path.insert(0, str(chat_be_dir))

try:
    from dt_client import create_dt_client, DigitalTwinClient
    print("✅ Imported DT client successfully")
except ImportError as e:
    print(f"❌ Failed to import DT client: {e}")
    print(f"   sys.path: {sys.path[:3]}")
    print(f"   Looking in: {chat_be_dir}")
    create_dt_client = None
    DigitalTwinClient = None

# Import storage
from storage import get_storage

router = APIRouter()

# Configuration
# TEMPORARY: Hardcoded to True for testing - check .env file
DIGITAL_TWIN_ENABLED = True  # os.getenv("DIGITAL_TWIN_ENABLED", "false").lower() == "true"

# Debug: Print DT status at module load
print(f"🤖 Chat App: DIGITAL_TWIN_ENABLED = {DIGITAL_TWIN_ENABLED}")
print(f"   Environment value: {os.getenv('DIGITAL_TWIN_ENABLED', 'NOT SET')}")


class Message(BaseModel):
    """Message model."""
    id: str
    conversation_id: str
    content: str
    sender: str
    timestamp: str
    

class Conversation(BaseModel):
    """Conversation model."""
    id: str
    title: str
    created_at: str
    updated_at: str


class SendMessageRequest(BaseModel):
    """Request model for sending a message."""
    conversation_id: Optional[str] = None
    content: str
    sender: str = "user"


class CreateConversationRequest(BaseModel):
    """Request model for creating a conversation."""
    title: str = "New Conversation"


@router.post("/conversations")
@protected
async def create_conversation(request: Request, req: CreateConversationRequest):
    """Create a new conversation."""
    user = get_current_user(request)
    storage = get_storage()
    
    conversation_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    conversation = {
        "id": conversation_id,
        "title": req.title,
        "created_at": now,
        "updated_at": now,
        "owner": user.user_id  # Track conversation owner
    }
    
    # Save to persistent storage
    storage.save_conversation(conversation_id, conversation)
    
    print(f"💬 User {user.username} created conversation: {conversation_id}")
    
    return conversation


@router.get("/conversations")
@protected
async def list_conversations(request: Request):
    """List all conversations for the authenticated user."""
    user = get_current_user(request)
    storage = get_storage()
    
    print(f"💬 User {user.username} listing conversations")
    
    # Get conversations for this user
    user_conversations = storage.get_conversations(user_id=user.user_id)
    
    return {"conversations": list(user_conversations.values())}


@router.get("/conversations/{conversation_id}")
@protected
async def get_conversation(conversation_id: str, request: Request):
    """Get a specific conversation."""
    user = get_current_user(request)
    storage = get_storage()
    
    conversation = storage.get_conversation(conversation_id)
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    # Check ownership
    if conversation.get("owner") != user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    print(f"💬 User {user.username} viewing conversation: {conversation_id}")
    
    return conversation


@router.delete("/conversations/{conversation_id}")
@protected
async def delete_conversation(conversation_id: str, request: Request):
    """Delete a conversation."""
    user = get_current_user(request)
    storage = get_storage()
    
    conversation = storage.get_conversation(conversation_id)
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    # Check ownership
    if conversation.get("owner") != user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    storage.delete_conversation(conversation_id)
    
    return {"message": "Conversation deleted successfully"}


@router.post("/send")
@protected
async def send_message(request: Request, req: SendMessageRequest):
    """Send a message in a conversation."""
    user = get_current_user(request)
    storage = get_storage()
    conversation_id = req.conversation_id
    
    # Create new conversation if none specified
    if not conversation_id:
        conversation_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()
        conversation = {
            "id": conversation_id,
            "title": "New Conversation",
            "created_at": now,
            "updated_at": now,
            "owner": user.user_id
        }
        storage.save_conversation(conversation_id, conversation)
    
    # Check if conversation exists
    conversation = storage.get_conversation(conversation_id)
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    # Check ownership
    if conversation.get("owner") != user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Create user message
    message_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    user_message = {
        "id": message_id,
        "conversation_id": conversation_id,
        "content": req.content,
        "sender": user.username,  # Use authenticated user's username
        "timestamp": now
    }
    
    # Save user message to persistent storage
    storage.add_message(conversation_id, user_message)
    
    print(f"💬 User {user.username} sent message in conversation: {conversation_id}")
    
    # Digital Twin Integration
    dt_response_message = None
    dt_status = {"active": False}
    
    if DIGITAL_TWIN_ENABLED and create_dt_client:
        print(f"🤖 Routing to Digital Twin for user {user.username}")
        
        # Get auth token
        auth_token = request.headers.get("authorization", "").replace("Bearer ", "")
        
        # Get conversation history from storage (last 20 messages)
        history = storage.get_messages(conversation_id)[-20:]
        
        # SMART ROUTING:
        # 1. Try direct local connection (best)
        # 2. Fall back to cloud DT (always works)
        
        dt_client = create_dt_client(user.user_id)
        health = await dt_client.check_health()
        
        if health.get("reachable"):
            # Direct local connection available - use it!
            print("🏠 Using direct local connection")
            dt_result = await dt_client.think(
                user_input=req.content,
                conversation_id=conversation_id,
                history=history,
                user_id=user.user_id,
                auth_token=auth_token
            )
            
            # Create DT response message
            if dt_result.get("dt_active"):
                dt_message_id = str(uuid.uuid4())
                dt_response_message = {
                    "id": dt_message_id,
                    "conversation_id": conversation_id,
                    "content": dt_result.get("response", "I'm processing your request..."),
                    "sender": "digital_twin",
                    "timestamp": datetime.utcnow().isoformat(),
                    "metadata": {
                        "dt_active": True,
                        "thought_process": dt_result.get("thought_process"),
                        "tools_used": dt_result.get("tools_used", []),
                        "autonomous": dt_result.get("autonomous_action", False),
                        "confidence": dt_result.get("dt_confidence", 1.0)
                    }
                }
                # Save DT response to persistent storage
                storage.add_message(conversation_id, dt_response_message)
                
                dt_status = {
                    "active": True,
                    "confidence": dt_result.get("dt_confidence", 1.0),
                    "tools_used": dt_result.get("tools_used", [])
                }
                
                print(f"🤖 Digital Twin responded (tools used: {dt_result.get('tools_used', [])})")
        else:
            # Direct local not available - check discovery service
            print("🔍 Checking discovery service for execution node...")
            
            import httpx
            try:
                async with httpx.AsyncClient(timeout=5.0) as client:
                    # Check if execution node is registered
                    discovery_response = await client.get(
                        f"{request.base_url}digital-twin/api/direct_connection/discover/{user.user_id}"
                    )
                    
                    # Handle discovery response
                    if discovery_response.status_code == 200:
                        discovery_data = discovery_response.json()
                        
                        if discovery_data.get("found"):
                            # Node is registered but health check failed
                            # This means network issue or node just starting up
                            print(f"⚠️ Execution node registered but not reachable: {discovery_data.get('local_url')}")
                            
                            error_message_id = str(uuid.uuid4())
                            dt_response_message = {
                                "id": error_message_id,
                                "conversation_id": conversation_id,
                                "content": "⚠️ Your Digital Twin (execution node) is registered but temporarily unreachable. Please ensure:\n\n1. Your local server is running\n2. You're on the same network (or have port forwarding set up)\n3. CORS is enabled on your execution node\n\nTry refreshing the page to reconnect.",
                                "sender": "system",
                                "timestamp": datetime.utcnow().isoformat(),
                                "metadata": {
                                    "dt_active": False,
                                    "error": "node_unreachable",
                                    "node_url": discovery_data.get("local_url"),
                                    "discovery_info": discovery_data
                                }
                            }
                        else:
                            # Node not registered at all
                            print("❌ Execution node not registered")
                            
                            error_message_id = str(uuid.uuid4())
                            dt_response_message = {
                                "id": error_message_id,
                                "conversation_id": conversation_id,
                                "content": "🏠 Your Digital Twin (execution node) is not currently running.\n\nTo use your Digital Twin:\n1. Start your local Aurica server\n2. Log in (auto-registration will happen)\n3. Your node will be available for peer-to-peer connections\n\n💡 The Digital Twin runs on YOUR computer for maximum privacy and capability!",
                                "sender": "system",
                                "timestamp": datetime.utcnow().isoformat(),
                                "metadata": {
                                    "dt_active": False,
                                    "error": "node_not_registered"
                                }
                            }
                    elif discovery_response.status_code == 404:
                        # Discovery service not available on this server
                        print("❌ Discovery service not found (404) - digital-twin app not deployed to API server")
                        
                        error_message_id = str(uuid.uuid4())
                        dt_response_message = {
                            "id": error_message_id,
                            "conversation_id": conversation_id,
                            "content": "🏠 Your Digital Twin (execution node) is not currently running.\n\nTo use your Digital Twin:\n1. Start your local Aurica server\n2. Log in (auto-registration will happen)\n3. Your node will be available for peer-to-peer connections\n\n💡 The Digital Twin runs on YOUR computer for maximum privacy and capability!",
                            "sender": "system",
                            "timestamp": datetime.utcnow().isoformat(),
                            "metadata": {
                                "dt_active": False,
                                "error": "discovery_service_unavailable"
                            }
                        }
                    elif discovery_response.status_code == 401:
                        # Discovery service requires auth but shouldn't (configuration issue)
                        print("❌ Discovery service returned 401 - endpoint not marked as public (deploy issue)")
                        
                        error_message_id = str(uuid.uuid4())
                        dt_response_message = {
                            "id": error_message_id,
                            "conversation_id": conversation_id,
                            "content": "🏠 Your Digital Twin (execution node) is not currently running.\n\nTo use your Digital Twin:\n1. Start your local Aurica server\n2. Log in (auto-registration will happen)\n3. Your node will be available for peer-to-peer connections\n\n💡 The Digital Twin runs on YOUR computer for maximum privacy and capability!",
                            "sender": "system",
                            "timestamp": datetime.utcnow().isoformat(),
                            "metadata": {
                                "dt_active": False,
                                "error": "discovery_service_auth_issue"
                            }
                        }
                    else:
                        # Other error (422, 500, etc.)
                        print(f"❌ Discovery service error: {discovery_response.status_code}")
                        print(f"   Response: {discovery_response.text[:200]}")
                        
                        error_message_id = str(uuid.uuid4())
                        dt_response_message = {
                            "id": error_message_id,
                            "conversation_id": conversation_id,
                            "content": "🏠 Your Digital Twin (execution node) is not currently running.\n\nTo use your Digital Twin:\n1. Start your local Aurica server\n2. Log in (auto-registration will happen)\n3. Your node will be available for peer-to-peer connections\n\n💡 The Digital Twin runs on YOUR computer for maximum privacy and capability!",
                            "sender": "system",
                            "timestamp": datetime.utcnow().isoformat(),
                            "metadata": {
                                "dt_active": False,
                                "error": "discovery_service_error",
                                "status_code": discovery_response.status_code
                            }
                        }
                        
                # Save error message to persistent storage
                storage.add_message(conversation_id, dt_response_message)
                        
            except Exception as e:
                print(f"❌ Discovery service error: {e}")
                # Fallback to simple response
                error_message_id = str(uuid.uuid4())
                dt_response_message = {
                    "id": error_message_id,
                    "conversation_id": conversation_id,
                    "content": "I'm currently experiencing difficulties connecting to your Digital Twin. Please try again in a moment.",
                    "sender": "system",
                    "timestamp": datetime.utcnow().isoformat(),
                    "metadata": {
                        "dt_active": False,
                        "error": "discovery_failed"
                    }
                }
                # Save error message to persistent storage
                storage.add_message(conversation_id, dt_response_message)
                
                dt_status = {
                    "active": False,
                    "error": "cloud_dt_failed",
                    "message": str(e)
                }
    else:
        # DT disabled - simple echo or placeholder response
        print("💬 Digital Twin disabled, using simple response")
        
    return {
        "message": user_message,
        "dt_response": dt_response_message,
        "conversation_id": conversation_id,
        "dt_status": dt_status
    }


@router.get("/conversations/{conversation_id}/messages")
@protected
async def get_messages(conversation_id: str, request: Request):
    """Get all messages in a conversation."""
    user = get_current_user(request)
    storage = get_storage()
    
    conversation = storage.get_conversation(conversation_id)
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    # Check ownership
    if conversation.get("owner") != user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    print(f"💬 User {user.username} viewing messages in conversation: {conversation_id}")
    
    messages = storage.get_messages(conversation_id)
    
    return {
        "conversation_id": conversation_id,
        "messages": messages
    }


@router.get("/dt/status")
@protected
async def get_dt_status(request: Request):
    """
    Get Digital Twin status and capabilities.
    
    This endpoint allows the UI to check if the user's Digital Twin
    is reachable and what it can do.
    """
    user = get_current_user(request)
    
    if not DIGITAL_TWIN_ENABLED or not create_dt_client:
        return {
            "dt_enabled": False,
            "message": "Digital Twin integration is not enabled"
        }
    
    auth_token = request.headers.get("authorization", "").replace("Bearer ", "")
    dt_client = create_dt_client(user.user_id)
    
    # Check health
    health = await dt_client.check_health()
    
    if not health.get("reachable"):
        return {
            "dt_enabled": True,
            "reachable": False,
            "error": health.get("error"),
            "message": health.get("message")
        }
    
    # Get capabilities
    capabilities = await dt_client.get_capabilities(auth_token)
    
    # Get state
    state = await dt_client.get_state(auth_token)
    
    return {
        "dt_enabled": True,
        "reachable": True,
        "health": health.get("status", {}),
        "capabilities": capabilities,
        "state": state
    }

"""
SwiftBot - Ultra-Fast Telegram Bot Framework
Copyright (c) 2025 Arjun-M/SwiftBot
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="swiftbot",
    version="1.0.1", # Incrementing version for new release
    author="Arjun-M",
    author_email="",
    description="A blazing-fast Telegram bot framework built for performance and simplicity.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Arjun-M/SwiftBot",
    packages=find_packages(), # This will now correctly find the 'swiftbot' package
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Communications :: Chat",
        "Framework :: AsyncIO",
        "Topic :: Internet :: WWW/HTTP :: WSGI :: Application"
    ],
    keywords=[
        "telegram",
        "bot",
        "framework",
        "asyncio",
        "high performance",
        "fast",
        "chat",
        "api",
        "telegram-bot-api"
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "webhook": ["aiohttp>=3.9.0,<4.0.0"]
    },
)

"""Tests for provider adapters."""


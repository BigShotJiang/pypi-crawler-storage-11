"""Agent specification and packaging."""









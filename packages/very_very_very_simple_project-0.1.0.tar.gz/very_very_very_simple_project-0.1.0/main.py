def main():
    print("Hello from very-very-very-simple-project!")


if __name__ == "__main__":
    main()

"""MQTT Hass tests."""

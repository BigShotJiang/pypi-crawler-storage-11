"""MQTT Hass base."""

from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_an_access_link_response_200 import DeleteAnAccessLinkResponse200
from ...types import Response


def _get_kwargs(
    record_id: str,
    link_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/api/records/{record_id}/access/links/{link_id}".format(
            record_id=record_id,
            link_id=link_id,
        ),
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, DeleteAnAccessLinkResponse200]]:
    if response.status_code == 200:
        response_200 = DeleteAnAccessLinkResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if response.status_code == 403:
        response_403 = cast(Any, None)
        return response_403

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 500:
        response_500 = cast(Any, None)
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, DeleteAnAccessLinkResponse200]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    record_id: str,
    link_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Union[Any, DeleteAnAccessLinkResponse200]]:
    """Delete an access link

    Args:
        record_id (str):
        link_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, DeleteAnAccessLinkResponse200]]
    """

    kwargs = _get_kwargs(
        record_id=record_id,
        link_id=link_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    record_id: str,
    link_id: str,
    *,
    client: AuthenticatedClient,
) -> Optional[Union[Any, DeleteAnAccessLinkResponse200]]:
    """Delete an access link

    Args:
        record_id (str):
        link_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, DeleteAnAccessLinkResponse200]
    """

    return sync_detailed(
        record_id=record_id,
        link_id=link_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    record_id: str,
    link_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Union[Any, DeleteAnAccessLinkResponse200]]:
    """Delete an access link

    Args:
        record_id (str):
        link_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, DeleteAnAccessLinkResponse200]]
    """

    kwargs = _get_kwargs(
        record_id=record_id,
        link_id=link_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    record_id: str,
    link_id: str,
    *,
    client: AuthenticatedClient,
) -> Optional[Union[Any, DeleteAnAccessLinkResponse200]]:
    """Delete an access link

    Args:
        record_id (str):
        link_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, DeleteAnAccessLinkResponse200]
    """

    return (
        await asyncio_detailed(
            record_id=record_id,
            link_id=link_id,
            client=client,
        )
    ).parsed

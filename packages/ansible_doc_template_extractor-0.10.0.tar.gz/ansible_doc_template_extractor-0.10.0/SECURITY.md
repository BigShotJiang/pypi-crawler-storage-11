# Security Policy

## Supported Versions

This project supports its released versions as follows:

- The [latest released version on Pypi](https://pypi.org/project/ansible-doc-template-extractor/)
  gets fixes, including security fixes.
- Earlier versions are not fixed anymore.

## Reporting a Vulnerability

Please report vulnerabilities via the
[Security Advisories](https://github.com/andy-maier/ansible-doc-template-extractor/security/advisories)
page of this project. This ensures that they are passed on to the maintainers
privately.

Do not report them as issues or pull requests, since that would reveal the
vulnerability before the maintainers have a chance to fix it. Note that even
with a pull request that fixes the vulnerability perfectly, it is revealed
publicly before a new version of the package can be released to Pypi.

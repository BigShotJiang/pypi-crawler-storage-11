# Role role_with_inparams -- Ensure that a host on a storage system exists and has host WWPNs.

## Synopsis

Ensure that a host on a storage system exists and has host WWPNs\.

This role is idempotent\.


## Input Parameters

Input parameters for the role\.


* **log_file** (str):

  Path name of log file\.


  Optional\.

* **sar_type** (str):

  Type of the storage system\.


  Required\.

  Choices\: ds8k\, fs9k\.

* **sar_hostname** (str):

  IP address or hostname of the storage system for logging in\.


  Required\.

* **sar_username** (str):

  Username on the storage system\.


  Required\.

* **sar_password** (str):

  Password on the storage system\.


  Required\.

* **host_name** (str):

  Name of the host to be created\.


  Required\.

* **host_wwpns** (list of str):

  WWPNs for the host\, in <code>hh\:hh\.\.\.</code> or <code>hhhh\.\.\.</code> format\.


  Required\.


## Output Parameters

Output parameters for the role\.

Their values are the names of variables to be set upon return from the role\.


* **host_info** (str):

  Properties of the host \(specific to <code>sar\_type</code>\)\.

  Type\: dict


  Optional\.


## Authors

* Andreas Maier

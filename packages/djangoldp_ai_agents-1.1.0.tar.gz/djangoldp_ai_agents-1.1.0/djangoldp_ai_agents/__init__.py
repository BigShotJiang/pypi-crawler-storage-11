__version__ = "1.1.0"
name = "djangoldp_ai_agents"

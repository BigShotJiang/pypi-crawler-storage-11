import unittest
import torch
from chatterbox import ChatterboxMultilingualTTS

class TestChatterboxTTS(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.device = "cuda" if torch.cuda.is_available() else "cpu"
        cls.tts = ChatterboxMultilingualTTS.from_local(device=cls.device)

    def test_synthesis(self):
        # Test basic synthesis
        sample_rate, audio = self.tts.synthesize(
            text="This is a test.",
            language="en",
            temperature=0.7,
            cfg_scale=0.5,
            exaggeration=0.5
        )
        
        self.assertIsInstance(audio, (list, tuple, type(None)))
        if audio is not None:
            self.assertGreater(len(audio), 0)
        self.assertIsInstance(sample_rate, int)
        self.assertGreater(sample_rate, 0)

if __name__ == "__main__":
    unittest.main()

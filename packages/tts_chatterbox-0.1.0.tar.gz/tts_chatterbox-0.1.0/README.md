---
title: Chatterbox-Multilingual-TTS
emoji: 🌎
colorFrom: indigo
colorTo: blue
sdk: gradio
sdk_version: 5.29.0
app_file: app.py
pinned: false
short_description: Chatterbox TTS supporting 23 languages
---

# Chatterbox TTS

A high-quality Multilingual Text-to-Speech (TTS) library with voice cloning capabilities, supporting 23 languages.

## Features

- 🗣️ Support for 23 languages
- 🎙️ Voice cloning from reference audio
- 🚀 Fast inference with PyTorch
- 🎯 High-quality, natural-sounding speech
- 🔌 Simple Python API

## Installation

```bash
pip install chatterbox-tts
```

**Note:** This package requires PyTorch. For optimal performance, install the appropriate version for your system from [PyTorch's official website](https://pytorch.org/get-started/locally/).

## Quick Start

```python
from chatterbox import ChatterboxMultilingualTTS, SUPPORTED_LANGUAGES
import torch

# Check available languages
print("Supported languages:", list(SUPPORTED_LANGUAGES.keys()))

# Initialize the TTS model
device = "cuda" if torch.cuda.is_available() else "cpu"
tts = ChatterboxMultilingualTTS.from_local(device=device)

# Generate speech from text
text = "Hello, this is a test of the Chatterbox TTS system."
language = "en"  # English

# Generate audio
sample_rate, audio = tts.synthesize(
    text=text,
    language=language,
    temperature=0.8,
    cfg_scale=0.5,
    exaggeration=0.5
)

# Save to file
import soundfile as sf
sf.write("output.wav", audio, sample_rate)
```

## Advanced Usage

### Voice Cloning

```python
# Generate speech in the style of a reference audio
reference_audio = "path/to/reference_audio.wav"
sample_rate, audio = tts.synthesize(
    text="This will sound like the reference speaker.",
    language="en",
    reference_audio=reference_audio,
    temperature=0.7,
    cfg_scale=0.7
)
```

## Available Languages

Chatterbox TTS supports the following languages:

- English (en)
- Spanish (es)
- French (fr)
- German (de)
- Italian (it)
- Portuguese (pt)
- Polish (pl)
- Russian (ru)
- Japanese (ja)
- Korean (ko)
- Chinese (zh)
- And more... (23 languages total)

## License

MIT
class SerialNeoPixel:
    """
    A wrapper class that treats a contiguous segment of a NeoPixel strip as an
    independent addressable unit.

    This allows multiple SerialNeoPixel instances to manage different sections
    of the same physical strip, enabling modular pixel control without managing
    global indices.

    Args:
        strip: The parent NeoPixel strip object
        pixel_start: Starting index in the parent strip (0-based)
        pixel_count: Number of pixels in this segment

    Example:
        >>> import board
        >>> import neopixel
        >>> strip = neopixel.NeoPixel(board.D18, 30)
        >>> segment1 = SerialNeoPixel(strip, 0, 10)
        >>> segment2 = SerialNeoPixel(strip, 10, 20)
        >>> segment1[0] = (255, 0, 0)  # First pixel of segment1
        >>> segment2[0] = (0, 255, 0)  # First pixel of segment2 (strip index 10)
    """

    def __init__(self, strip, pixel_start, pixel_count):
        self.strip = strip
        self.pixel_start = pixel_start
        self.pixel_count = pixel_count

    def _normalize_index(self, index):
        """
        Normalize an index to handle negative indices.

        Args:
            index: The index to normalize (can be negative)

        Returns:
            The normalized positive index

        Raises:
            RuntimeError: If the index is out of range
        """
        if index < 0:
            index = self.pixel_count + index

        if index < 0 or index >= self.pixel_count:
            raise RuntimeError("index out of range")

        return index

    def fill(self, color):
        """
        Set all pixels in this segment to the same color.

        Args:
            color: RGB or RGBW color tuple, e.g., (255, 0, 0) for red

        Example:
            >>> segment.fill((0, 0, 255))  # Fill segment with blue
        """
        start = self.pixel_start
        end = self.pixel_start + self.pixel_count

        for i in range(start, end):
            self.strip[i] = color

    def __repr__(self):
        return f"SerialNeoPixel(start={self.pixel_start}, count={self.pixel_count})"

    def __len__(self):
        """Return the number of pixels in this segment."""
        return self.pixel_count

    def __setitem__(self, index, color):
        """
        Set the color of a pixel or slice of pixels in this segment.

        Supports both single index and slice assignment, including negative indices.

        Args:
            index: Integer index or slice object
            color: RGB/RGBW tuple for single index, or sequence of tuples for slice

        Examples:
            >>> segment[0] = (255, 0, 0)           # Set first pixel
            >>> segment[-1] = (0, 255, 0)          # Set last pixel
            >>> segment[0:3] = [(255,0,0)] * 3     # Set first three pixels
        """
        if isinstance(index, slice):
            # Handle slice assignment
            start, stop, step = index.indices(self.pixel_count)
            indices = range(start, stop, step)

            # Check if color is a single value or a sequence
            try:
                # Try to iterate over color as a sequence of colors
                color_iter = iter(color)
                for i, c in zip(indices, color_iter):
                    self.strip[self.pixel_start + i] = c
            except TypeError:
                # color is a single color tuple, apply to all pixels in slice
                for i in indices:
                    self.strip[self.pixel_start + i] = color
        else:
            # Handle single index
            normalized_index = self._normalize_index(index)
            self.strip[self.pixel_start + normalized_index] = color

    def __getitem__(self, index):
        """
        Get the color of a pixel or slice of pixels in this segment.

        Supports both single index and slice access, including negative indices.

        Args:
            index: Integer index or slice object

        Returns:
            RGB/RGBW tuple for single index, or list of tuples for slice

        Examples:
            >>> color = segment[0]        # Get first pixel
            >>> color = segment[-1]       # Get last pixel
            >>> colors = segment[0:3]     # Get first three pixels
        """
        if isinstance(index, slice):
            # Handle slice access
            start, stop, step = index.indices(self.pixel_count)
            indices = range(start, stop, step)
            return [self.strip[self.pixel_start + i] for i in indices]
        else:
            # Handle single index
            normalized_index = self._normalize_index(index)
            return self.strip[self.pixel_start + normalized_index]

    @property
    def brightness(self):
        """
        Get the brightness of the parent strip.

        Note: This property affects the ENTIRE parent strip, not just this segment.
        All segments sharing the same parent strip will be affected.

        Returns:
            Float value between 0.0 (off) and 1.0 (full brightness)
        """
        return self.strip.brightness

    @brightness.setter
    def brightness(self, value):
        """
        Set the brightness of the parent strip.

        Warning: This affects the ENTIRE parent strip, not just this segment.
        All segments sharing the same parent strip will be affected.

        Args:
            value: Float between 0.0 (off) and 1.0 (full brightness)
        """
        self.strip.brightness = value

    def show(self):
        """
        Update the physical LED strip to display current pixel colors.

        Note: This updates the ENTIRE parent strip, not just this segment.
        """
        self.strip.show()

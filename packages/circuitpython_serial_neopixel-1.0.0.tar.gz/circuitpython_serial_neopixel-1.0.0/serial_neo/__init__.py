"""
CircuitPython Serial NeoPixel

A CircuitPython library for managing segments of NeoPixel LED strips as
independent addressable units.
"""

from .serial_neo import SerialNeoPixel

__version__ = "0.1.0"
__all__ = ["SerialNeoPixel"]

__version__ = "1.8.1"

from .clsp import CLSP

__all__ = [
    "CLSP",
    "__version__"
]

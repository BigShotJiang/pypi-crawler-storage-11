# SQLTy

Type-safe SQL queries for Python with automatic stub generation and runtime validation.

[![Python 3.14+](https://img.shields.io/badge/python-3.14+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview

SQLTy provides type-safe SQL query execution with automatic type inference and stub generation. Write SQL queries with explicit type casts, and let SQLTy generate precise type stubs for full mypy integration.

```python
from sqlty import SQLRegistry

class Query(SQLRegistry):
    pass

sql = Query.sql

# Type-safe query with automatic inference
query = sql("SELECT id::INTEGER, name::TEXT FROM users")
# Type: SQL[tuple[int, str]]

# Execute with full type safety
from sqlty.drivers.psycopg import execute
result = execute(conn, query, {})
# Type: Iterator[tuple[int, str]]

# Full mypy support
for user_id, name in result:
    print(f"User {user_id}: {name}")
```

## Features

- 🔒 **Type Safety**: Full mypy integration with precise type inference
- 🚀 **Automatic Stub Generation**: Analyze code and generate `.pyi` files automatically
- 🎯 **SQL Type Casts**: Use PostgreSQL-style `::TYPE` casts for explicit typing
- 📦 **Multi-Registry Support**: Organize queries into multiple registries
- 🔍 **Source Tracking**: Generated stubs include source location comments
- 🌐 **Multiple SQL Dialects**: Support for PostgreSQL, MySQL, SQLite, and more via sqlglot

## Quick Start

**Install:**

```bash
pip install sqlty
```

**Write queries:**


See [docs/advanced-usage.md](docs/advanced-usage.md) for:

- Multi-registry and multiple schema support
- Configuration via pyproject.toml
- Full package example with stub generation and usage
```

```python
# queries.py
from sqlty import SQLRegistry

class Query(SQLRegistry):
    pass

sql = Query.sql
```

```python
# app.py
from queries import sql
from sqlty.drivers.psycopg import execute

query = sql("SELECT id::INTEGER, name::TEXT FROM users WHERE id = :id")
# Type: SQL[tuple[int, str]]

result = execute(conn, query, {"id": 123})
# Type: Iterator[tuple[int, str]]
```

**Generate stubs:**

```bash
sqlty . --mode=full
```

**Type check:**

```bash
mypy .
# Success: no issues found
```

## Documentation

📚 **[Complete Documentation](docs/README.md)**

### Quick Links

- **[Installation Guide](docs/installation.md)** - Setup instructions for pip, uv, poetry, and more
- **[User Guide](docs/index.md)** - Complete guide with basic and advanced usage
- **[API Reference](docs/api.md)** - Detailed API documentation for all classes and methods
- **[Examples](docs/index.md#examples)** - Real-world usage patterns

### Pre-commit Hook

Automatically generate stubs on commit by adding to your `.pre-commit-config.yaml`:

```yaml
repos:
  - repo: https://github.com/jirikuncar/sqlty
    rev: v0.1.0  # Use the latest version
    hooks:
      - id: sqlty
        # Optional: customize with args
        # args: [".", "--mode=full", "--schema=schema.sql"]
```

### Key Topics

- [Basic Usage](docs/index.md#basic-usage) - Creating registries, writing queries, generating stubs
- [Multi-Registry Pattern](docs/index.md#multi-registry-pattern) - Organizing queries for large applications
- [Type Inference](docs/index.md#type-inference) - How SQLTy infers Python types from SQL
- [Internals](docs/index.md#internals) - Architecture and implementation details

## Development

This project uses [uv](https://docs.astral.sh/uv/) for dependency management.

### Setup

Install dependencies:

```bash
uv sync
```

### Type Checking

Run mypy type checking on the source code and examples:

```bash
make typecheck
```


Or directly:

```bash
uv run mypy src/sqlty examples
```

### Generating Type Stubs

The `sqlty` tool analyzes your Python code to automatically generate `.pyi` stub files with `@overload` declarations. It infers return types from:

1. **SQL Analysis**: Uses [sqlglot](https://sqlglot.com) to parse SQL queries and extract column types from explicit type casts (e.g., `column::INTEGER`)
2. **Schema Files**: Optionally load database schema (via `--schema` option) for enhanced type inference

Generate stub files:

```bash
make generate-stubs
```

Or directly:

```bash
uv run sqlty <source_file_or_directory> [options]
```

Options:
- `-o, --output`: Output .pyi file path (auto-detected based on imports by default)
- `--dialect`: SQL dialect for analysis (default: postgres). Supports: postgres, mysql, sqlite, bigquery, snowflake, and [more](https://sqlglot.com/sqlglot.html#supported-dialects)
- `--mode=incremental`: Add new overloads to existing stub instead of replacing
- `--mode=full`: Remove overloads for queries that no longer exist (auto-enabled for directory mode)
- `--schema PATH` or `--schema registry:PATH`: Provide schema files to improve type inference. Repeat `--schema` for multiple registry mappings. Precedence: registry-specific > global > `__schema_path__` on the registry class.

Example:

```bash
# Single file mode - generates stub alongside source
uv run sqlty examples/query/query.py

# Directory mode - scans all files and generates central stub
uv run sqlty examples/query/ --mode=full

# Incremental mode - add new queries without regenerating everything
uv run sqlty examples/query/new_queries.py --mode=incremental
```

### Optional: Auto-format generated stubs

You can have SQLTy pipe the generated stub content through an external formatter.
The generator writes the stub text to the formatter's stdin and expects the formatted
result on stdout. The command must include `{filename}` placeholder;
this expands to the target stub path and is useful for tools that use the filename
for configuration or heuristics.

Ruff example (recommended):

```toml
[tool.sqlty]
# ... your other settings (dialect, schemas, etc.)
format-command = "ruff format --stdin-filename {filename} -"

```

Black example:

```toml
[tool.sqlty]
format-command = "black -q --stdin-filename {filename} -"

```

**SQL-Based Type Inference Example:**

```python
# Your code with explicit SQL type casts
user_query = sql("""
    SELECT id::INTEGER, name::TEXT FROM users WHERE id = :id
""")

# Generator automatically infers: SQL[tuple[int, str]]
```
uv run sqlty examples/query/query.py
The generator will analyze the SQL query, detect the `::INTEGER` and `::TEXT` type casts, and generate:

```python
uv run sqlty examples/query/ --mode=full
def sql(
    query: Literal["SELECT id::INTEGER, name::TEXT FROM users WHERE id = :id"],
) -> SQL[tuple[int, str]]: ...
uv run sqlty examples/query/new_queries.py --mode=incremental

This means mypy will enforce that you handle the result as `tuple[int, str]`!

**Automatic Stub Generation:**

For development convenience, you can enable automatic stub generation by setting the `SQLTY_AUTO_GENERATE` environment variable:

```bash
export SQLTY_AUTO_GENERATE=1
python my_app.py  # Stubs will be auto-generated on first import
```

This will automatically generate or update stub files whenever a `SQLRegistry` subclass is imported. The feature uses incremental mode by default, so it won't overwrite your existing stubs but will add new queries as they're discovered.

**Note:** Auto-generation is intended for development only. In production, generate stubs once and commit them to your repository for faster startup times.

### Running Examples

```bash
uv run examples/query/query.py
```

Or:

```bash
make run-example
```

## Examples

See the `examples/` directory for usage examples:

- **Basic registry:** See `examples/query/`
- **Multi-registry:** See `examples/multi_registry/`
- **Schema-based:** See `examples/schema-based/` (uses `schema.sql` for type inference)

## TODO / Roadmap

### 📊 Example Priority Ranking

Based on user value and implementation effort:

1. **Schema-based** (High Value, Low Effort)
   - Many users want to avoid explicit casts
   - Schema files are common in real projects
   - Demonstrates --schema flag

2. **Auto-generate** (High Value, Low Effort)
   - Improves developer experience
   - Already implemented, just needs example
   - Shows SQLTY_AUTO_GENERATE env var

3. **Incremental** (Medium Value, Low Effort)
   - Important for large codebases
   - Shows --mode=incremental workflow
   - Relatively simple to demonstrate

4. **Migration** (High Value, Medium Effort)
   - Real-world use case
   - Helps adoption
   - Requires more setup/explanation

5. **Dialect-specific** (Low Value, Medium Effort)
   - Niche use case
   - Already documented in CLI
   - Can be added later

## TODO

- [ ] Automatically add new @overload entries on `sql(...)` calls when SQLTY_AUTO_GENERATE=1 is set. Ensure minimal overhead and file locking to prevent race conditions.
- [ ] Support more psycopg query types (Composed, Nested, etc.)
- [ ] Support UUID type mapping
- [ ] Support datetime and interval type mappings
- [ ] Ensure locking is in place for concurrent stub generation in multi-threaded environments or multiple processes (file locks)
- [x] Allow composable flags --mode=incremental,prune or --mode=full
  - [x] Implemented --mode flag with incremental, full, and prune options
  - [x] Removed legacy --mode=incremental and --mode=full flags (breaking change)
  - [x] Updated API: generate_stub_file now uses mode parameter instead of boolean flags
  - [ ] Configure it to run on changed files in examples
  - [ ] Prune implementation (remove overloads for queries that no longer exist)
- [x] Create pre-commit plugin for automatic stub generation
- [ ] Register project on PyPI without release (package ready but not uploaded)
- [ ] Make sure everything works with both `ty` and `mypy`.
- [x] Move _auto_generate_stub from __init__.py to a separate module (e.g., _auto_generator.py) for better organization as function.
- [x] Unify --schema and --schema-map options into a single --schema that supports both single and multiple mappings. Use : instead of = (registry_name=path/to/schema.sql -> registry_name:path/to/schema.sql). Allow --schema to be specified multiple times for multiple mappings.
- [ ] Make sub-commands or parameters to check pyi files for missing or outdated stubs.
- [ ] Add bootstrap sub-command to generate registry skeleton, detect schema if available in repo, and suggests configuration for pyproject.toml and pre-commit if present.

### Ideas

- [ ] Support more psycopg query types (e.g. Composed, Nested, ...)

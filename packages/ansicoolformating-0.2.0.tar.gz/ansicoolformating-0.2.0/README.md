# ANSI-COLORS
## All the ansi colors you need in a simple package
***Here Is An Example :***

```py
from ANSI-COLORS import foregroundColors
print(f"{foregroundColors.GREEN} Hello, World")
```
### This Package's colors can also be used for "customTraceback" Traceback text to add even more flavour into your tracebacks :D
**Have Colorful Time!**
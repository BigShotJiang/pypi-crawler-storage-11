from setuptools import setup, find_packages

setup(
    name="modernctkmessagebox",  # PyPI'de görünecek isim (boşluk vs. olmasın)
    version="1.1.0",  # 👈 her güncellemede değiştir
    author="Demir",  # senin adın
    author_email="email@adresin.com",  # opsiyonel
    description="A modern CustomTkinter MessageBox with input and response features.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/seninhesabin/modernctkmessagebox",  # varsa GitHub linki
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "customtkinter",
        "Pillow"
    ],
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)

"""
CTkMessagebox Package
---------------------
A modern CustomTkinter messagebox with input support, icons, and window customization.

Author: Demir
Version: 1.1.0
"""

from .messagebox import CTkMessagebox  # Ana sınıfı dışa aktar

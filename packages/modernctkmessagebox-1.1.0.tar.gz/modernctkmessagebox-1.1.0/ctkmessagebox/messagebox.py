"""
CustomTkinter Messagebox
Enhanced with Input Field Support
Author: Akash Bora, modified by Demir
Version: 2.8
"""

import customtkinter
from PIL import Image, ImageTk
import os
import sys
import time
from typing import Literal


class CTkMessagebox(customtkinter.CTkToplevel):
    ICONS = {"check": None, "cancel": None, "info": None, "question": None, "warning": None}
    ICON_BITMAP = {}

    def __init__(self,
                 master: any = None,
                 width: int = 400,
                 height: int = 200,
                 title: str = "CTkMessagebox",
                 message: str = "This is a CTkMessagebox!",
                 option_1: str = "OK",
                 option_2: str = None,
                 option_3: str = None,
                 options: list = [],
                 border_width: int = 1,
                 border_color: str = "default",
                 button_color: str = "default",
                 bg_color: str = "default",
                 fg_color: str = "default",
                 text_color: str = "default",
                 title_color: str = "default",
                 button_text_color: str = "default",
                 button_width: int = None,
                 button_height: int = None,
                 cancel_button_color: str = None,
                 cancel_button: str = None,
                 button_hover_color: str = "default",
                 icon: str = "info",
                 icon_size: tuple = None,
                 corner_radius: int = 15,
                 justify: str = "right",
                 font: tuple = None,
                 header: bool = False,
                 topmost: bool = True,
                 fade_in_duration: int = 0,
                 sound: bool = False,
                 wraplength: int = 0,
                 option_focus: Literal[1, 2, 3] = None,
                 # --- new input options ---
                 input_mode: bool = False,
                 input_placeholder: str = "",
                 input_password: bool = False,
                 input_multiline: bool = False,
                 window_icon: str = None):

        super().__init__()
        self.master_window = master
        self.width = max(250, width)
        self.height = max(150, height)
        self.input_mode = input_mode
        self.input_password = input_password
        self.input_multiline = input_multiline
        self.input_placeholder = input_placeholder
        self._response = None

        # Window icon support
        if window_icon:
            try:
                self.iconbitmap(window_icon)
            except Exception:
                pass

        # Position
        if self.master_window is None:
            self.spawn_x = int((self.winfo_screenwidth() - self.width) / 2)
            self.spawn_y = int((self.winfo_screenheight() - self.height) / 2)
        else:
            self.spawn_x = int(
                self.master_window.winfo_width() * .5 + self.master_window.winfo_x() - .5 * self.width + 7)
            self.spawn_y = int(
                self.master_window.winfo_height() * .5 + self.master_window.winfo_y() - .5 * self.height + 20)

        self.geometry(f"{self.width}x{self.height}+{self.spawn_x}+{self.spawn_y}")
        self.title(title)
        self.resizable(False, False)
        self.fade = fade_in_duration
        self.event = None

        if self.fade:
            self.fade = 20 if self.fade < 20 else self.fade
            self.attributes("-alpha", 0)

        if not header:
            self.overrideredirect(1)
        if topmost:
            self.attributes("-topmost", True)
        else:
            self.transient(self.master_window)

        self.protocol("WM_DELETE_WINDOW", self.button_event)

        # --- main frame ---
        self.frame_top = customtkinter.CTkFrame(self, corner_radius=corner_radius,
                                                fg_color=fg_color if fg_color != "default" else None)
        self.frame_top.pack(expand=True, fill="both", padx=2, pady=2)

        # --- title label ---
        self.title_label = customtkinter.CTkLabel(self.frame_top, text=title, font=font, text_color=title_color)
        self.title_label.pack(pady=(10, 5))

        # --- message ---
        self.message_label = customtkinter.CTkLabel(self.frame_top, text=message, wraplength=width - 100,
                                                    justify="center")
        self.message_label.pack(padx=20, pady=(5, 10))

        # --- optional input field ---
        if input_mode:
            if input_multiline:
                self.input_field = customtkinter.CTkTextbox(self.frame_top, height=70)
                if input_placeholder:
                    self.input_field.insert("0.0", input_placeholder)
                    self.input_field.configure(text_color=("gray50", "gray70"))
            else:
                self.input_field = customtkinter.CTkEntry(self.frame_top, placeholder_text=input_placeholder,
                                                          show="•" if input_password else None)
            self.input_field.pack(pady=(0, 15), padx=20, fill="x")
        else:
            self.input_field = None

        # --- buttons ---
        button_frame = customtkinter.CTkFrame(self.frame_top, fg_color="transparent")
        button_frame.pack(pady=(0, 10))

        self.buttons = []
        for text in (option_1, option_2, option_3):
            if text:
                btn = customtkinter.CTkButton(button_frame, text=text,
                                              command=lambda t=text: self.button_event(t),
                                              width=button_width if button_width else 80,
                                              height=button_height if button_height else 28)
                btn.pack(side="left", padx=8)
                self.buttons.append(btn)

        if self.fade:
            self.fade_in()
        if self.sound:
            self.bell()
        self.grab_set()
        self.focus_force()

    def fade_in(self):
        for i in range(0, 110, 10):
            if not self.winfo_exists():
                break
            self.attributes("-alpha", i / 100)
            self.update()
            time.sleep(1 / self.fade)

    def fade_out(self):
        for i in range(100, 0, -10):
            if not self.winfo_exists():
                break
            self.attributes("-alpha", i / 100)
            self.update()
            time.sleep(1 / self.fade)

    def button_event(self, event=None):
        if self.input_field:
            if isinstance(self.input_field, customtkinter.CTkTextbox):
                value = self.input_field.get("0.0", "end").strip()
            else:
                value = self.input_field.get().strip()
        else:
            value = None

        self._response = {"button": event, "input": value}
        if self.fade:
            self.fade_out()
        self.grab_release()
        self.destroy()

    def get(self):
        self.wait_window()
        return self._response


# Example usage
if __name__ == "__main__":
    msg = CTkMessagebox(title="Giriş", message="Adınızı girin:",
                        input_mode=True, input_placeholder="Adınız...",
                        option_1="Tamam", option_2="İptal",
                        fade_in_duration=25)
    result = msg.get()
    print(result)

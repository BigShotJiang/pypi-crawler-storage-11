
from setuptools import setup

setup(package_data={'simple_websocket-stubs': ['__init__.pyi', 'aiows.pyi', 'asgi.pyi', 'errors.pyi', 'ws.pyi', 'METADATA.toml', 'py.typed']})

import React from 'react'
import { Link, router } from '@inertiajs/react'
import Layout from '../components/Layout'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Heart, MapPin } from 'lucide-react'
import type { BrowsePageProps, Cat } from '../types'

interface CatCardProps {
  cat: Cat
  onToggleFavorite: (catId: number) => void
}

function CatCard({ cat, onToggleFavorite }: CatCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="aspect-square overflow-hidden bg-gray-100">
        <img
          src={cat.photo}
          alt={cat.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
      </div>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-xl">{cat.name}</CardTitle>
            <CardDescription className="flex items-center gap-1 mt-1">
              <MapPin className="h-3 w-3" />
              {cat.shelter_city}
            </CardDescription>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className={cat.is_favorited ? 'text-red-500' : 'text-gray-400'}
            onClick={() => onToggleFavorite(cat.id)}
          >
            <Heart className={cat.is_favorited ? 'fill-current' : ''} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-1 mb-3">
          {cat.personality.slice(0, 3).map((trait) => (
            <Badge key={trait} variant="secondary" className="text-xs">
              {trait}
            </Badge>
          ))}
        </div>
        <p className="text-sm text-muted-foreground line-clamp-2">
          {cat.short_description}
        </p>
        <div className="mt-3 flex items-center justify-between text-sm">
          <span className="text-muted-foreground">
            {cat.age} {cat.age === 1 ? 'year' : 'years'} old
          </span>
          <span className="font-semibold">${cat.adoption_fee}</span>
        </div>
      </CardContent>
      <CardFooter>
        <Button asChild className="w-full">
          <Link href={`/cats/${cat.id}`}>
            View Profile
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

export default function Browse({ title, cats, total, page, perPage }: BrowsePageProps) {
  const totalPages = Math.ceil(total / perPage)
  const hasNextPage = page < totalPages
  const hasPrevPage = page > 1

  const handleToggleFavorite = (catId: number) => {
    // Use partial reloads to only update the cats list
    // This prevents a full page reload and feels instant!
    router.visit(`/favorites/${catId}/toggle`, {
      method: 'post',
      preserveScroll: true,
      only: ['cats'],
    })
  }

  return (
    <Layout title={title}>
      <div className="mb-6">
        <p className="text-muted-foreground">
          Showing {cats.length} of {total} adorable cats available for adoption
        </p>
      </div>

      {/* Cat Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {cats.map((cat) => (
          <CatCard key={cat.id} cat={cat} onToggleFavorite={handleToggleFavorite} />
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center gap-2">
          <Button
            variant="outline"
            disabled={!hasPrevPage}
            asChild={hasPrevPage}
          >
            {hasPrevPage ? (
              <Link href={`/browse?page=${page - 1}`}>Previous</Link>
            ) : (
              <span>Previous</span>
            )}
          </Button>
          
          <div className="flex items-center gap-2 px-4">
            <span className="text-sm text-muted-foreground">
              Page {page} of {totalPages}
            </span>
          </div>

          <Button
            variant="outline"
            disabled={!hasNextPage}
            asChild={hasNextPage}
          >
            {hasNextPage ? (
              <Link href={`/browse?page=${page + 1}`}>Next</Link>
            ) : (
              <span>Next</span>
            )}
          </Button>
        </div>
      )}

      {/* Empty State */}
      {cats.length === 0 && (
        <div className="text-center py-12">
          <p className="text-lg text-muted-foreground">No cats found. Try adjusting your filters!</p>
        </div>
      )}
    </Layout>
  )
}

"""
Package to handle data redction at AMOR instrument to be used by __main__.py script.
"""

__version__ = '3.0.5'
__date__    = '2025-11-04'

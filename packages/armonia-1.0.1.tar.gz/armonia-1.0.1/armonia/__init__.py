"""
Armonia - A Python library for theming and color management.

Built on top of polychromos for advanced color manipulation.
"""

from armonia import serialization
from armonia.theme import Theme

__version__ = "1.0.1"

__all__ = ["__version__", "Theme", "serialization"]

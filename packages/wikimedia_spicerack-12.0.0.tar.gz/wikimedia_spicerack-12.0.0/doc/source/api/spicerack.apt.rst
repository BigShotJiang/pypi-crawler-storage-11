apt
===

.. automodule:: spicerack.apt

service
=======

.. automodule:: spicerack.service

confctl
=======

.. automodule:: spicerack.confctl

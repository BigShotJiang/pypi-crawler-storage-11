interactive
===========

.. automodule:: spicerack.interactive

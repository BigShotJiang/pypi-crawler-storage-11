"""Class API Test Cookbooks."""

"""
Email Verification model
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from datetime import datetime, timedelta
from fastapi_core_database.database import Base

class EmailVerification(Base):
    """Email verification tokens for user registration"""
    __tablename__ = 'email_verifications'
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    token = Column(String, unique=True, index=True, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    used = Column(Boolean, default=False, nullable=False)
    verified_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    def is_expired(self) -> bool:
        """Check if token has expired"""
        return datetime.utcnow() > self.expires_at
    
    def is_valid(self) -> bool:
        """Check if token is valid (not used and not expired)"""
        return not self.used and not self.is_expired()
    
    @staticmethod
    def create_expiration(minutes: int = 30) -> datetime:
        """Create expiration datetime (default 30 minutes from now)"""
        return datetime.utcnow() + timedelta(minutes=minutes)
    
    def __repr__(self):
        return f"<EmailVerification(user_id={self.user_id}, token='{self.token[:8]}...', expires_at='{self.expires_at}')>"

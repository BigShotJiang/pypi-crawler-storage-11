# rodrigo0000-fastapi-core-middleware

Middleware components for FastAPI applications.

## Features

- CORS middleware configuration
- Request logging middleware
- Request tracing and ID generation
- Security headers middleware
- Error handling middleware

## Installation

```bash
pip install rodrigo0000-fastapi-core-middleware
```

## Usage

```python
from rodrigo0000_fastapi_core_middleware import setup_middleware
from fastapi import FastAPI

app = FastAPI()
setup_middleware(app)
```

## Components

- **CORS Middleware**: Cross-Origin Resource Sharing configuration
- **Logging Middleware**: Request/response logging
- **Tracing Middleware**: Request ID generation and tracking
- **Security Middleware**: Security headers (CSP, HSTS, etc.)
- **Error Handler**: Centralized error handling

## Requirements

- Python >= 3.8
- FastAPI >= 0.104.0
- Starlette >= 0.27.0

## License

MIT License

## Author

R Firm - Professional SaaS Development

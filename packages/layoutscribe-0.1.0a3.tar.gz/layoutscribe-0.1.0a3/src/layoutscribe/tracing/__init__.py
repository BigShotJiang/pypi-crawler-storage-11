"""Tracing utilities (stubs)."""



"""General utilities (stubs)."""



"""Helpers for FERRET dynamic bucket variants."""

from __future__ import annotations

from typing import Optional


FERRET_VARIANTS = {
    "MAX": None,
    "EIGHTH": "eighth",
    "QUARTER": "quarter",
    "HALF": "half",
    "2": 2,
}


def resolve_variant(value: Optional[str | int]) -> Optional[str | int]:
    """Map a user-facing variant name to dynamic bucket configuration."""

    if value is None:
        return None

    if isinstance(value, int):
        return max(1, value)

    key = value.upper().replace("FERRET-", "")
    if key in FERRET_VARIANTS:
        return FERRET_VARIANTS[key]

    lowered = value.lower()
    if lowered in {"max", "none"}:
        return None
    return lowered

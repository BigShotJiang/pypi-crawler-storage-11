"""Factories for building training components."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

from transformers import TrainingArguments

from ferret.config.models import OptimizerConfig, RunConfig, TrainingConfig


@dataclass
class TrainerArtifacts:
    training_arguments: TrainingArguments


def build_training_arguments(
    training: TrainingConfig, optimizer: OptimizerConfig
) -> TrainingArguments:
    args_kwargs: Dict[str, Any] = {
        "output_dir": training.output_dir,
        "num_train_epochs": training.num_train_epochs,
        "per_device_train_batch_size": training.per_device_train_batch_size,
        "per_device_eval_batch_size": training.per_device_eval_batch_size,
        "gradient_accumulation_steps": training.gradient_accumulation_steps,
        "gradient_checkpointing": training.gradient_checkpointing,
        "optim": optimizer.optim,
        "logging_steps": training.logging_steps,
        "save_strategy": training.save_strategy,
        "learning_rate": optimizer.learning_rate,
        "weight_decay": optimizer.weight_decay,
        "fp16": training.fp16,
        "bf16": training.bf16,
        "max_grad_norm": optimizer.max_grad_norm,
        "max_steps": training.max_steps,
        "warmup_ratio": optimizer.warmup_ratio,
        "group_by_length": training.group_by_length,
        "lr_scheduler_type": optimizer.lr_scheduler_type,
        "report_to": training.report_to,
    }
    if training.save_steps is not None:
        args_kwargs["save_steps"] = training.save_steps
    if training.save_total_limit is not None:
        args_kwargs["save_total_limit"] = training.save_total_limit

    return TrainingArguments(**args_kwargs)


def prepare_trainer_artifacts(config: RunConfig) -> TrainerArtifacts:
    training_args = build_training_arguments(config.training, config.optimizer)
    return TrainerArtifacts(training_arguments=training_args)

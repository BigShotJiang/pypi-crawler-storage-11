"""Membership inference utilities."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Optional, Tuple

import numpy as np
import torch
from datasets import Dataset
from torch.utils.data import DataLoader
from transformers import PreTrainedModel, PreTrainedTokenizerBase
from sklearn.linear_model import LogisticRegressionCV
from sklearn.metrics import average_precision_score, roc_auc_score, roc_curve

from ferret.experiments.metrics import sequence_nll


@dataclass
class AttackMetrics:
    roc_auc: float
    advantage: float
    tpr_at_1: float
    tpr_at_5: float
    tpr_at_10: float
    pr_auc: float


def _tpr_at_fpr(fpr: np.ndarray, tpr: np.ndarray, target: float) -> float:
    if target <= fpr[0]:
        return 0.0
    if target >= fpr[-1]:
        return float(tpr[-1])
    idx = np.searchsorted(fpr, target, side="right")
    x0, x1, y0, y1 = fpr[idx - 1], fpr[idx], tpr[idx - 1], tpr[idx]
    return float(y0 + (y1 - y0) * (target - x0) / (x1 - x0))


@torch.no_grad()
def extract_confidence_features(
    dataset: Dataset,
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizerBase,
    *,
    batch_size: int = 8,
    max_length: int = 512,
    text_field: str = "text",
) -> np.ndarray:
    """Extract margin, max_prob, entropy, and NLL features from model outputs."""

    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    feats = []

    model.eval()
    for batch in loader:
        texts = batch[text_field] if isinstance(batch, dict) else batch
        enc = tokenizer(
            texts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=max_length,
        ).to(model.device)

        logits = model(**enc).logits
        probs = torch.softmax(logits, dim=-1)
        top2 = torch.topk(probs, k=2, dim=-1).values
        top1, top2_vals = top2[..., 0], top2[..., 1]

        max_prob = top1.mean(dim=1)
        margin = (top1 - top2_vals).mean(dim=1)
        entropy = (-(probs * torch.log(probs + 1e-12)).sum(dim=-1)).mean(dim=1)
        nll = sequence_nll(logits, enc["input_ids"], tokenizer.pad_token_id)

        feats.append(torch.stack([margin, max_prob, entropy, nll], dim=1).cpu())

    return torch.cat(feats, dim=0).numpy()


@torch.no_grad()
def extract_reference_features(
    dataset: Dataset,
    reference_model: PreTrainedModel,
    tokenizer: PreTrainedTokenizerBase,
    *,
    batch_size: int = 8,
    max_length: int = 512,
    text_field: str = "text",
) -> np.ndarray:
    """Return negative log-likelihood features for a reference model."""

    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    feats = []
    reference_model.eval()

    for batch in loader:
        texts = batch[text_field] if isinstance(batch, dict) else batch
        enc = tokenizer(
            texts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=max_length,
        ).to(reference_model.device)

        logits = reference_model(**enc).logits
        nll = sequence_nll(logits, enc["input_ids"], tokenizer.pad_token_id)
        feats.append(nll.unsqueeze(1).cpu())

    return torch.cat(feats, dim=0).numpy()


def combine_features(target_features: np.ndarray, reference_features: Optional[np.ndarray]) -> np.ndarray:
    if reference_features is None:
        return target_features
    nll_gap = reference_features[:, 0] - target_features[:, 3]
    return np.column_stack([target_features[:, :3], target_features[:, 3], nll_gap])


def run_advanced_attack(
    target_features: np.ndarray,
    reference_features: Optional[np.ndarray],
    membership_labels: np.ndarray,
    *,
    cv_folds: int = 5,
) -> Tuple[np.ndarray, AttackMetrics, LogisticRegressionCV]:
    combined = combine_features(target_features, reference_features)
    return run_confidence_attack(combined, membership_labels, cv_folds=cv_folds)


def run_confidence_attack(
    features: np.ndarray,
    membership_labels: np.ndarray,
    *,
    cv_folds: int = 5,
) -> Tuple[np.ndarray, AttackMetrics, LogisticRegressionCV]:
    model = LogisticRegressionCV(
        Cs=20,
        cv=cv_folds,
        penalty="l2",
        scoring="roc_auc",
        solver="liblinear",
        max_iter=1000,
        n_jobs=-1,
    )
    model.fit(features, membership_labels)
    scores = model.predict_proba(features)[:, 1]

    roc_auc = roc_auc_score(membership_labels, scores)
    fpr, tpr, _ = roc_curve(membership_labels, scores)
    advantage = float(np.max(tpr - fpr))
    metrics = AttackMetrics(
        roc_auc=roc_auc,
        advantage=advantage,
        tpr_at_1=_tpr_at_fpr(fpr, tpr, 0.01),
        tpr_at_5=_tpr_at_fpr(fpr, tpr, 0.05),
        tpr_at_10=_tpr_at_fpr(fpr, tpr, 0.10),
        pr_auc=average_precision_score(membership_labels, scores),
    )
    return scores, metrics, model

"""Result persistence utilities."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from ferret.utils.logging import get_logger


LOGGER = get_logger(__name__)


@dataclass
class ResultStore:
    base_dir: Path

    def __post_init__(self) -> None:
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def _write_json(self, path: Path, payload: Mapping[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
        LOGGER.info("Wrote results", extra={"path": str(path)})

    def save_metrics(self, experiment_id: str, metrics: Mapping[str, Any]) -> Path:
        path = self.base_dir / experiment_id / "metrics.json"
        self._write_json(path, metrics)
        return path

    def save_metadata(self, experiment_id: str, metadata: Mapping[str, Any]) -> Path:
        path = self.base_dir / experiment_id / "meta.json"
        self._write_json(path, metadata)
        return path

    def save_samples(self, experiment_id: str, samples: Iterable[Mapping[str, Any]]) -> Path:
        path = self.base_dir / experiment_id / "samples.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        data = samples if isinstance(samples, list) else list(samples)
        with path.open("w", encoding="utf-8") as handle:
            for sample in data:
                json.dump(sample, handle, ensure_ascii=False)
                handle.write("\n")
        LOGGER.info("Wrote samples", extra={"path": str(path), "count": len(data)})
        return path

"""PyTorch helper utilities."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Iterable, Iterator, List

import torch


@contextmanager
def freeze_parameters(parameters: Iterable[torch.nn.Parameter]) -> Iterator[None]:
    """Temporarily disable gradients for the provided parameters."""

    params: List[torch.nn.Parameter] = list(parameters)
    requires_grad = [p.requires_grad for p in params]
    try:
        for param in params:
            param.requires_grad = False
        yield
    finally:
        for param, flag in zip(params, requires_grad):
            param.requires_grad = flag


def flatten_parameters(params: Iterable[torch.nn.Parameter]) -> torch.Tensor:
    """Return a flattened tensor containing all parameter values."""

    flats = [param.reshape(-1) for param in params]
    return torch.cat(flats) if flats else torch.empty(0)

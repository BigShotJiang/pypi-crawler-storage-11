"""Deterministic seeding helpers."""

from __future__ import annotations

import random
from typing import Optional

import numpy as np
import torch


def seed_everything(seed: int, *, deterministic_torch: bool = False) -> None:
    """Seed Python, NumPy, and PyTorch RNGs."""

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if deterministic_torch:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def make_torch_generator(seed: int, device: Optional[torch.device] = None) -> torch.Generator:
    """Create a ``torch.Generator`` seeded with ``seed``."""

    gen = torch.Generator(device=device if device is not None else "cpu")
    gen.manual_seed(seed)
    return gen

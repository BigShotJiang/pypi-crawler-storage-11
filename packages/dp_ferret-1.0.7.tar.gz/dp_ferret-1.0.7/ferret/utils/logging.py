"""Logging helpers for FERRET."""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Iterator, Optional

from rich.console import Console
from rich.logging import RichHandler

_LOGGER_NAME = "ferret"


def _build_rich_handler() -> RichHandler:
    console = Console(force_terminal=True, highlight=False, width=140)
    handler = RichHandler(
        console=console,
        rich_tracebacks=True,
        show_time=True,
        show_level=False,
        show_path=False,
        markup=True,
        log_time_format="[%m/%d/%y %H:%M:%S]",
    )
    handler.setFormatter(logging.Formatter("%(message)s"))
    return handler


def configure_logging(level: int = logging.INFO, *, force: bool = False) -> logging.Logger:
    """Configure and return the package logger with Rich formatting."""

    logger = logging.getLogger(_LOGGER_NAME)
    if force:
        for handler in list(logger.handlers):
            logger.removeHandler(handler)

    if not logger.handlers:
        logger.addHandler(_build_rich_handler())

    logger.setLevel(level)
    logger.propagate = False

    # quiet noisy third-party loggers
    for name in ("transformers", "datasets", "accelerate", "urllib3"):
        logging.getLogger(name).setLevel(logging.WARNING)

    return logger


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """Return a child logger scoped under the package logger."""

    base = logging.getLogger(_LOGGER_NAME)
    if not base.handlers:
        configure_logging()
    return base.getChild(name) if name else base


@contextmanager
def rich_status(message: str) -> Iterator[None]:
    """Context manager that shows a Rich status spinner."""

    console = Console(force_terminal=True, highlight=False, width=140)
    with console.status(message):
        yield

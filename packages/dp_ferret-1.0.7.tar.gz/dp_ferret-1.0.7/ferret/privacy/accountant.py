"""Privacy accountant for the FERRET mechanism."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, Mapping, MutableMapping, Optional, Sequence, Union

import torch

from ferret.utils.logging import get_logger


LOGGER = get_logger(__name__)

DynamicBuckets = Union[int, str, None]


@dataclass
class AccountantStats:
    """Snapshot of privacy accounting state."""

    epsilon_midp_basic: float
    epsilon_midp_basic_bits: float
    expected_midp_basic: float
    epsilon_target: float
    effective_steps: int
    info_per_update: float
    sampling_rate: float
    total_dim: int
    update_counts: Mapping[str, int] = field(default_factory=dict)
    p_values: Mapping[str, float] = field(default_factory=dict)


class FERRETPrivacyAccountant:
    """Privacy accountant implementing Eq. (8) of the FERRET paper."""

    def __init__(
        self,
        *,
        model: torch.nn.Module,
        total_steps: int,
        epsilon_target: float,
        batch_size: int,
        dataset_size: int,
        clipping_norm: float,
        gradient_accumulation_steps: int = 1,
        param_norm_bound: float = 1.0,
        dependency_matrix: Optional[torch.Tensor] = None,
        max_p_value: Optional[float] = None,
        dynamic_buckets: DynamicBuckets = None,
    ) -> None:
        self.model = model
        self.total_steps = max(1, total_steps)
        self.epsilon_target = epsilon_target
        self.batch_size = batch_size
        self.dataset_size = max(1, dataset_size)
        self.clipping_norm = clipping_norm
        self.gradient_accumulation_steps = max(1, gradient_accumulation_steps)
        self.param_norm_bound = param_norm_bound
        self.dependency_matrix = dependency_matrix
        self.max_p_value = max_p_value

        self.info_per_update = math.log(2.0)
        self.sampling_rate = min(1.0, self.batch_size / self.dataset_size)

        self.param_groups = self._group_parameters()
        self.group_dimensions = {
            name: sum(param.numel() for param in params)
            for name, params in self.param_groups.items()
        }

        self.dynamic_buckets = self._resolve_dynamic_buckets(dynamic_buckets)
        self.update_counts: MutableMapping[str, int] = self._init_update_counts()
        self.current_step = 0
        self.accumulation_counter = 0

        self.p_values = self._compute_p_values()

        LOGGER.info(
            "Initialized FERRETPrivacyAccountant",
            extra={
                "groups": len(self.param_groups),
                "dynamic_buckets": self.dynamic_buckets,
                "total_dim": sum(self.group_dimensions.values()),
                "sampling_rate": self.sampling_rate,
                "epsilon_target": self.epsilon_target,
                "p_average": sum(self.p_values.values()) / max(len(self.p_values), 1),
            },
        )
        self.log_pre_training_diagnostics()

    # ------------------------------------------------------------------
    # grouping & setup
    # ------------------------------------------------------------------
    def _group_parameters(self) -> Dict[str, list[torch.nn.Parameter]]:
        groups: Dict[str, list[torch.nn.Parameter]] = {}
        seen: set[int] = set()

        for module_name, module in self.model.named_modules():
            raw_params = [p for p in module.parameters(recurse=False) if id(p) not in seen]
            if not raw_params:
                continue
            seen.update(map(id, raw_params))

            trainable = [p for p in raw_params if p.requires_grad]
            if not trainable:
                continue
            group_name = f"group_{module_name.replace('.', '_') or 'root'}"
            groups[group_name] = trainable

        all_params = list(self.model.parameters())
        if len(seen) != len(all_params):
            missing = [p for p in all_params if id(p) not in seen]
            raise RuntimeError(
                f"Parameter grouping mismatch: {len(missing)} parameters unmapped."
            )

        return groups

    def _resolve_dynamic_buckets(self, spec: DynamicBuckets) -> Optional[int]:
        if spec is None:
            return None
        trainable_count = sum(1 for p in self.model.parameters() if p.requires_grad)
        if isinstance(spec, int):
            limit = trainable_count if trainable_count > 0 else spec
            return max(1, min(spec, limit))

        spec_lower = spec.lower()
        param_count = trainable_count
        if spec_lower == "half":
            return max(1, param_count // 2)
        if spec_lower == "quarter":
            return max(1, param_count // 4)
        if spec_lower == "eighth":
            return max(1, param_count // 8)
        raise ValueError(f"Unsupported dynamic bucket spec: {spec}")

    def _init_update_counts(self) -> MutableMapping[str, int]:
        if self.dynamic_buckets is not None:
            return {f"dyn_{i}": 0 for i in range(self.dynamic_buckets)}
        return {name: 0 for name in self.param_groups}

    # ------------------------------------------------------------------
    # probability computation
    # ------------------------------------------------------------------
    def _compute_p_values(self) -> Dict[str, float]:
        group_count = (
            self.dynamic_buckets if self.dynamic_buckets is not None else len(self.param_groups)
        )
        if group_count == 0:
            raise ValueError("No parameter groups detected for FERRET accountant.")

        numerator = self.epsilon_target
        denominator = self.info_per_update * self.total_steps * self.sampling_rate * group_count
        if denominator <= 0:
            raise ValueError("Invalid denominator when computing FERRET p-values.")
        if numerator > denominator:
            raise ValueError(
                "Requested privacy budget is infeasible: epsilon must be \n"
                "≤ G · T · s · ln 2."
            )

        p_star = max(numerator / denominator, 1e-8)
        p_star = min(p_star, 1.0)
        if self.max_p_value is not None:
            p_star = min(self.max_p_value, p_star)

        if self.dynamic_buckets is not None:
            return {f"dyn_{i}": p_star for i in range(self.dynamic_buckets)}
        return {name: p_star for name in self.param_groups}

    # ------------------------------------------------------------------
    # public API
    # ------------------------------------------------------------------
    def sample_probability(self, group_name: str) -> float:
        return self.p_values[group_name]

    def record_updates(self, updated_group_names: Sequence[str]) -> None:
        for group_name in updated_group_names:
            if group_name not in self.update_counts:
                raise KeyError(f"Group '{group_name}' is not tracked by the accountant.")
            self.update_counts[group_name] += 1

    def step(self, updated_group_names: Sequence[str]) -> None:
        self.accumulation_counter += 1
        boundary = self.accumulation_counter >= self.gradient_accumulation_steps
        if boundary:
            self.current_step += 1
            self.accumulation_counter = 0
            self.record_updates(updated_group_names)

    def compute_expected_midp(self) -> float:
        return self.info_per_update * self.total_steps * self.sampling_rate * sum(self.p_values.values())

    def compute_actual_midp(self) -> float:
        return self.info_per_update * self.sampling_rate * sum(self.update_counts.values())

    def stats(self) -> AccountantStats:
        epsilon_midp = self.compute_actual_midp()
        expected_midp = self.info_per_update * self.total_steps * self.sampling_rate * sum(
            self.p_values.values()
        )
        return AccountantStats(
            epsilon_midp_basic=epsilon_midp,
            epsilon_midp_basic_bits=epsilon_midp / self.info_per_update,
            expected_midp_basic=expected_midp,
            epsilon_target=self.epsilon_target,
            effective_steps=self.current_step,
            info_per_update=self.info_per_update,
            sampling_rate=self.sampling_rate,
            total_dim=sum(self.group_dimensions.values()),
            update_counts=dict(self.update_counts),
            p_values=dict(self.p_values),
        )

    def reset(self) -> None:
        self.update_counts = self._init_update_counts()
        self.current_step = 0
        self.accumulation_counter = 0

    # ------------------------------------------------------------------
    # diagnostics
    # ------------------------------------------------------------------
    def pre_training_diagnostics(self) -> Dict[str, float | int | Optional[int]]:
        expected_midp = self.info_per_update * self.total_steps * self.sampling_rate * sum(
            self.p_values.values()
        )
        expected_updates = self.total_steps * sum(self.p_values.values())
        return {
            "epsilon_target": self.epsilon_target,
            "total_steps": self.total_steps,
            "batch_size": self.batch_size,
            "group_count": self.dynamic_buckets if self.dynamic_buckets is not None else len(self.param_groups),
            "total_parameters": sum(self.group_dimensions.values()),
            "sampling_rate": self.sampling_rate,
            "expected_midp": expected_midp,
            "expected_updates": expected_updates,
            "average_p": sum(self.p_values.values()) / max(len(self.p_values), 1),
        }

    def post_training_diagnostics(self) -> Dict[str, float | int]:
        stats = self.stats()
        total_updates = sum(stats.update_counts.values())
        return {
            "epsilon_target": stats.epsilon_target,
            "epsilon_midp": stats.epsilon_midp_basic,
            "effective_steps": stats.effective_steps,
            "total_updates": total_updates,
            "sampling_rate": stats.sampling_rate,
            "budget_usage_pct": (stats.epsilon_midp_basic / stats.epsilon_target * 100)
            if stats.epsilon_target > 0
            else 0.0,
        }

    def log_pre_training_diagnostics(self) -> None:
        data = self.pre_training_diagnostics()
        message = (
            "🔐 [bold cyan]FERRET privacy (pre)[/bold cyan] "
            f"εᵗ={data['epsilon_target']:.3f} | steps={data['total_steps']} | batch={data['batch_size']} | "
            f"groups={data['group_count']} | "
            f"s={data['sampling_rate']:.4f} | ε_expected={data['expected_midp']:.3f} | updates≈{data['expected_updates']:.0f} | "
            f"avg(p)={data['average_p']:.4e}"
        )
        LOGGER.info(message)

    def log_post_training_diagnostics(self) -> None:
        data = self.post_training_diagnostics()
        message = (
            "✅ [bold green]FERRET privacy (post)[/bold green] "
            f"εᵗ={data['epsilon_target']:.3f} | ε_spent={data['epsilon_midp']:.3f} | steps={data['effective_steps']} | "
            f"updates={data['total_updates']} | s={data['sampling_rate']:.4f} | budget={data['budget_usage_pct']:.2f}%"
        )
        LOGGER.info(message)

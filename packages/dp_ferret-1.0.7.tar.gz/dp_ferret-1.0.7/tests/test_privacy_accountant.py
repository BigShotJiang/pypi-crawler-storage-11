from __future__ import annotations

import torch
import pytest

from ferret.privacy.accountant import FERRETPrivacyAccountant


class SmallModel(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.layer1 = torch.nn.Linear(4, 4)
        self.layer2 = torch.nn.Linear(4, 2)


def test_accountant_computes_p_star() -> None:
    model = SmallModel()
    accountant = FERRETPrivacyAccountant(
        model=model,
        total_steps=10,
        epsilon_target=0.1,
        batch_size=5,
        dataset_size=100,
        clipping_norm=1.0,
    )

    p_values = list(accountant.p_values.values())
    assert len(p_values) > 0

    expected_p = accountant.epsilon_target / (
        accountant.info_per_update
        * accountant.total_steps
        * accountant.sampling_rate
        * len(p_values)
    )

    assert pytest.approx(p_values[0], rel=1e-6) == expected_p


def test_infeasible_epsilon_raises() -> None:
    model = SmallModel()
    with pytest.raises(ValueError):
        FERRETPrivacyAccountant(
            model=model,
            total_steps=10,
            epsilon_target=10.0,
            batch_size=5,
            dataset_size=100,
            clipping_norm=1.0,
        )


def test_accountant_records_updates() -> None:
    model = SmallModel()
    accountant = FERRETPrivacyAccountant(
        model=model,
        total_steps=10,
        epsilon_target=0.1,
        batch_size=5,
        dataset_size=100,
        clipping_norm=1.0,
    )

    groups = list(accountant.p_values.keys())
    accountant.step(groups[:1])
    accountant.step(groups[:1])

    stats = accountant.stats()
    assert stats.effective_steps == 2
    assert stats.update_counts[groups[0]] == 2

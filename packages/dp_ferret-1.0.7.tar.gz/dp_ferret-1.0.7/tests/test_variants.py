from ferret.training.variants import resolve_variant


def test_resolve_variant_handles_named_options() -> None:
    assert resolve_variant("EIGHTH") == "eighth"
    assert resolve_variant("ferret-max") is None
    assert resolve_variant("2") == 2
    assert resolve_variant(4) == 4
    assert resolve_variant(None) is None

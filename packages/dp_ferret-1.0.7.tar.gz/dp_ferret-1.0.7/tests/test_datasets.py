from ferret.data.datasets import _format_prompt_response


def test_format_prompt_response_full() -> None:
    result = _format_prompt_response("Hello", "Hi there")
    assert "Human:" in result and "Assistant:" in result
    assert "Hello" in result and "Hi there" in result


def test_format_prompt_response_response_only() -> None:
    result = _format_prompt_response(None, "Only response")
    assert result.startswith("Assistant:")


def test_format_prompt_response_prompt_only() -> None:
    result = _format_prompt_response("Only prompt", None)
    assert result.startswith("Human:") or result == "Only prompt"

from __future__ import annotations

from typing import List

import torch

from ferret.experiments.sampling import SamplingConfig, generate_text_samples
from ferret.experiments.storage import ResultStore


class DummyTokenizer:
    pad_token_id = 0

    def __init__(self) -> None:
        self._last_batch: List[str] = []

    def __call__(self, prompts, return_tensors=None, padding=None, truncation=None):
        self._last_batch = list(prompts)
        batch_size = len(prompts)
        input_ids = torch.ones((batch_size, 3), dtype=torch.long)
        attention_mask = torch.ones_like(input_ids)
        return {"input_ids": input_ids, "attention_mask": attention_mask}

    def batch_decode(self, outputs, skip_special_tokens=True):
        decoded = []
        for prompt in self._last_batch:
            decoded.append(f"{prompt} ::completion::")
        return decoded


class DummyModel:
    def __init__(self) -> None:
        self.device = torch.device("cpu")

    def eval(self) -> None:
        return None

    def generate(
        self,
        input_ids,
        attention_mask=None,
        max_new_tokens=50,
        temperature=0.8,
        top_p=0.95,
        do_sample=True,
        pad_token_id=None,
    ):
        batch_size = input_ids.size(0)
        seq_len = input_ids.size(1) + max_new_tokens
        return torch.ones((batch_size, seq_len), dtype=torch.long)


def test_generate_text_samples_hf_fallback() -> None:
    prompts = ["Sample prompt 1", "Sample prompt 2"]
    model = DummyModel()
    tokenizer = DummyTokenizer()
    config = SamplingConfig(
        num_samples=len(prompts),
        max_new_tokens=4,
        temperature=0.7,
        top_p=0.9,
        batch_size=2,
        use_vllm=False,
    )
    samples = generate_text_samples(
        prompts,
        model_path=None,
        model=model,
        tokenizer=tokenizer,
        config=config,
    )
    assert len(samples) == len(prompts)
    for prompt, sample in zip(prompts, samples):
        assert sample["prompt"] == prompt
        assert "::completion::" in sample["completion"]


def test_generate_text_samples_vllm_guard(monkeypatch) -> None:
    prompts = ["Prompt"]
    model = DummyModel()
    tokenizer = DummyTokenizer()
    config = SamplingConfig(num_samples=1, use_vllm=True, batch_size=1, max_new_tokens=2)

    from ferret.experiments import sampling as sampling_mod

    # Force HAS_VLLM False to trigger HF fallback path even when use_vllm=True
    monkeypatch.setattr(sampling_mod, "HAS_VLLM", False, raising=False)

    samples = sampling_mod.generate_text_samples(
        prompts,
        model_path="dummy-path",
        model=model,
        tokenizer=tokenizer,
        config=config,
    )
    assert samples[0]["prompt"] == prompts[0]


def test_result_store_save_samples(tmp_path) -> None:
    store = ResultStore(tmp_path)
    samples = [{"prompt": "Hi", "completion": "there"}]
    path = store.save_samples("experiment", samples)
    assert path.exists()
    contents = path.read_text(encoding="utf-8").strip().splitlines()
    assert len(contents) == 1


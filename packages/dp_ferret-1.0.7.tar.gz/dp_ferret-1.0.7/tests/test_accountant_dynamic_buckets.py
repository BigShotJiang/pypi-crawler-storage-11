from __future__ import annotations

import torch

from ferret.privacy.accountant import FERRETPrivacyAccountant


class TinyStack(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.layers = torch.nn.ModuleList(
            [torch.nn.Linear(4, 4) for _ in range(16)]  # 32 parameter tensors
        )


def test_dynamic_bucket_eighth_maps_to_expected_count() -> None:
    model = TinyStack()
    accountant = FERRETPrivacyAccountant(
        model=model,
        total_steps=10,
        epsilon_target=0.05,
        batch_size=4,
        dataset_size=400,
        clipping_norm=1.0,
        dynamic_buckets="eighth",
    )

    param_tensors = sum(1 for p in model.parameters() if p.requires_grad)
    expected_buckets = max(1, param_tensors // 8)

    assert accountant.dynamic_buckets == expected_buckets
    assert len(accountant.update_counts) == expected_buckets
    assert len(accountant.p_values) == expected_buckets

from typing import Callable
import aiohttp
from faststream.rabbit import RabbitBroker, RabbitExchange
from sqlalchemy.ext.asyncio import AsyncSession, AsyncEngine

from cattle_grid.config.application import ApplicationConfig


application_config: ApplicationConfig | None = None

broker: RabbitBroker | None = None

internal_exchange: RabbitExchange | None = None
activity_exchange: RabbitExchange | None = None
account_exchange: RabbitExchange | None = None

engine: AsyncEngine | None = None
async_session_maker: Callable[[], AsyncSession] | None = None
session: aiohttp.ClientSession | None = None

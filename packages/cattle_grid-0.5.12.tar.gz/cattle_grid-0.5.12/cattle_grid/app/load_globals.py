import logging

from dynaconf import Dynaconf
from faststream.rabbit import RabbitExchange, ExchangeType

from cattle_grid.config.application import ApplicationConfig
from cattle_grid.app import app_globals

logger = logging.getLogger(__name__)


def set_exchanges(config: Dynaconf):
    account_exchange_name = config.activity_pub.account_exchange  # type: ignore

    durable = True if account_exchange_name == "amq.topic" else False

    app_globals.account_exchange = RabbitExchange(
        account_exchange_name, type=ExchangeType.TOPIC, durable=durable
    )  # type: ignore

    app_globals.activity_exchange = RabbitExchange(
        config.activity_pub.exchange,  # type: ignore
        type=ExchangeType.TOPIC,
    )

    app_globals.internal_exchange = RabbitExchange(
        config.activity_pub.internal_exchange,  # type: ignore
        type=ExchangeType.TOPIC,
    )


def load(config: Dynaconf):
    if app_globals.application_config is not None:
        logger.warning("globals.load called multiple times")

    app_globals.application_config = ApplicationConfig.from_settings(config)

    set_exchanges(config)

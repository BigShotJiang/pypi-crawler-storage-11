from dynaconf import Dynaconf


from .application import ApplicationConfig
from .validators import all_validators


def test_application_config_empty():
    settings = Dynaconf(validators=all_validators)

    ApplicationConfig.from_settings(settings)

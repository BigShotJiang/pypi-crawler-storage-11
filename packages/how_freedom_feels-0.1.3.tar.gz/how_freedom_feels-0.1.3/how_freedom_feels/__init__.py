from .core import FreedomConnect

"""
How Freedom Feels - VPN Connection Manager
"""

__version__ = "0.1.3"
__all__ = ["FreedomConnect"]

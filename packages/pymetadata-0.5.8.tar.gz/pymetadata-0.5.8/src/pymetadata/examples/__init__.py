"""Examples for pymetadata."""

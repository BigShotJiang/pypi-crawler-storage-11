# Lab Programs

This package installs sample lab programs into the current folder.

## Usage

```bash
pip install labprograms
labprograms

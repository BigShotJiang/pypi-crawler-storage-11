from setuptools import setup, find_packages

setup(
    name='adwaithamadhu',
    version='1.0.1',  # incremented version
    packages=find_packages(),
    include_package_data=True,
    author='Jubin T Joseph',
    description='Auto-installer for lab programs',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    entry_points={
        'console_scripts': [
            'labprograms=labprograms.installer:install_files',  # users can just run "labprograms"
        ],
    },
    python_requires='>=3.6',
)

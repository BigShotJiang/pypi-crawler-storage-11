# app.py

import streamlit as st
import cv2
import numpy as np
from PIL import Image
from utils import score_roundness

st.set_page_config(page_title="Chapathi Roundness Scorecard 🍽️", layout="centered")
st.title("Chapathi Roundness Scorecard 🍽️")
st.markdown("Upload a photo of your chapathi and find out how round it is!")

uploaded_file = st.file_uploader("Upload Image", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
    image = cv2.imdecode(file_bytes, 1)
    processed_img, score = score_roundness(image.copy())

    st.image(cv2.cvtColor(image, cv2.COLOR_BGR2RGB), caption="Original Image", use_container_width=True)
    st.image(cv2.cvtColor(processed_img, cv2.COLOR_BGR2RGB), caption=f"Scored Image - Roundness: {score}%", use_container_width=True)

    if score > 90:
        st.success("🔥 Almost perfectly round! Grandma would be proud!")
    elif score > 75:
        st.info("🥲 Pretty round, but could use a bit more practice!")
    elif score > 50:
        st.warning("😬 Not bad, but definitely some jagged edges there.")
    else:
        st.error("💀 That's a tortilla murder scene, not a chapathi.")

    st.markdown(f"### Final Score: **{score}% Round**")

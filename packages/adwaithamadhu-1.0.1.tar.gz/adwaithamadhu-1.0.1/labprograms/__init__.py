from .installer import install_files
install_files()

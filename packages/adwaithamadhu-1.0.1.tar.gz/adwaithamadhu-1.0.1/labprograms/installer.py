import shutil
from pathlib import Path
import importlib.resources as resources
import traceback

def install_files():
    print("Installing lab programs...")

    dest = Path.cwd()  # copy to current working directory

    try:
        # Use importlib.resources.files() for modern Python
        programs_dir = resources.files("labprograms.programs")

        for file in programs_dir.iterdir():
            if file.is_file():
                # Read and write safely even if it's inside a zip
                data = file.read_bytes()
                (dest / file.name).write_bytes(data)
                print(f"Copied {file.name} → {dest}")

        print("✅ All lab programs installed successfully!")

    except Exception as e:
        print("❌ Error while copying:")
        traceback.print_exc()

if __name__ == "__main__":
    install_files()

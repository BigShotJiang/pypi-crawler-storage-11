"""Tests for CLI port configuration and browser behavior."""

import os
from unittest.mock import patch, MagicMock
import pytest
from typer.testing import CliRunner

from mtbsync.cli import app


runner = CliRunner()


class TestDashboardPortPrecedence:
    """Test port precedence for dashboard command."""

    def test_default_port_8760(self, tmp_path):
        """Dashboard should use 8760 as default port."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()
        (test_root / "timewarp.json").write_text("{}")

        with patch("mtbsync.dashboard.run_dashboard") as mock_run:
            result = runner.invoke(app, ["dashboard", "--root", str(test_root)])

            # Should be called with port 8760
            mock_run.assert_called_once()
            call_kwargs = mock_run.call_args.kwargs
            assert call_kwargs["port"] == 8760
            assert result.exit_code == 0

    def test_env_var_overrides_default(self, tmp_path, monkeypatch):
        """MTB_DASHBOARD_PORT env var should override default."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()
        (test_root / "timewarp.json").write_text("{}")

        monkeypatch.setenv("MTB_DASHBOARD_PORT", "9000")

        with patch("mtbsync.dashboard.run_dashboard") as mock_run:
            result = runner.invoke(app, ["dashboard", "--root", str(test_root)])

            # Should use env var port
            mock_run.assert_called_once()
            call_kwargs = mock_run.call_args.kwargs
            assert call_kwargs["port"] == 9000
            assert result.exit_code == 0

    def test_cli_flag_overrides_env(self, tmp_path, monkeypatch):
        """--port flag should override env var."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()
        (test_root / "timewarp.json").write_text("{}")

        monkeypatch.setenv("MTB_DASHBOARD_PORT", "9000")

        with patch("mtbsync.dashboard.run_dashboard") as mock_run:
            result = runner.invoke(app, ["dashboard", "--root", str(test_root), "--port", "9500"])

            # Should use CLI flag port
            mock_run.assert_called_once()
            call_kwargs = mock_run.call_args.kwargs
            assert call_kwargs["port"] == 9500
            assert result.exit_code == 0


class TestTelemetryUIPortPrecedence:
    """Test port precedence for telemetry-ui command."""

    def test_default_port_8761(self, tmp_path):
        """Telemetry UI should use 8761 as default port."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, ["telemetry-ui", "--root", str(test_root)])

            # Check that subprocess.run was called with port 8761
            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            assert "--server.port" in call_args
            port_idx = call_args.index("--server.port")
            assert call_args[port_idx + 1] == "8761"

    def test_env_var_overrides_default(self, tmp_path, monkeypatch):
        """MTB_TELEMETRY_PORT env var should override default."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()

        monkeypatch.setenv("MTB_TELEMETRY_PORT", "9001")

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, ["telemetry-ui", "--root", str(test_root)])

            # Should use env var port
            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            port_idx = call_args.index("--server.port")
            assert call_args[port_idx + 1] == "9001"

    def test_cli_flag_overrides_env(self, tmp_path, monkeypatch):
        """--port flag should override env var."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()

        monkeypatch.setenv("MTB_TELEMETRY_PORT", "9001")

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, ["telemetry-ui", "--root", str(test_root), "--port", "9500"])

            # Should use CLI flag port
            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            port_idx = call_args.index("--server.port")
            assert call_args[port_idx + 1] == "9500"


class TestCompareUIPortPrecedence:
    """Test port precedence for compare-ui command."""

    def test_default_port_8762(self, tmp_path):
        """Compare UI should use 8762 as default port."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, ["compare-ui", "--root", str(test_root)])

            # Check that subprocess.run was called with port 8762
            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            assert "--server.port" in call_args
            port_idx = call_args.index("--server.port")
            assert call_args[port_idx + 1] == "8762"

    def test_env_var_overrides_default(self, tmp_path, monkeypatch):
        """MTB_COMPARE_PORT env var should override default."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()

        monkeypatch.setenv("MTB_COMPARE_PORT", "9002")

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, ["compare-ui", "--root", str(test_root)])

            # Should use env var port
            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            port_idx = call_args.index("--server.port")
            assert call_args[port_idx + 1] == "9002"

    def test_cli_flag_overrides_env(self, tmp_path, monkeypatch):
        """--port flag should override env var."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()

        monkeypatch.setenv("MTB_COMPARE_PORT", "9002")

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, ["compare-ui", "--root", str(test_root), "--port", "9500"])

            # Should use CLI flag port
            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            port_idx = call_args.index("--server.port")
            assert call_args[port_idx + 1] == "9500"


class TestBrowserBehavior:
    """Test browser auto-open behavior."""

    def test_dashboard_no_auto_open_by_default(self, tmp_path):
        """Dashboard should not auto-open browser by default."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()
        (test_root / "timewarp.json").write_text("{}")

        with patch("mtbsync.dashboard.run_dashboard") as mock_run:
            result = runner.invoke(app, ["dashboard", "--root", str(test_root)])

            # open_browser should be False
            mock_run.assert_called_once()
            call_kwargs = mock_run.call_args.kwargs
            assert call_kwargs["open_browser"] is False
            assert result.exit_code == 0

    def test_dashboard_open_browser_explicit(self, tmp_path):
        """Dashboard should open browser when --open-browser is set."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()
        (test_root / "timewarp.json").write_text("{}")

        with patch("mtbsync.dashboard.run_dashboard") as mock_run:
            result = runner.invoke(app, ["dashboard", "--root", str(test_root), "--open-browser"])

            # open_browser should be True
            mock_run.assert_called_once()
            call_kwargs = mock_run.call_args.kwargs
            assert call_kwargs["open_browser"] is True
            assert result.exit_code == 0

    def test_telemetry_ui_headless_by_default(self, tmp_path):
        """Telemetry UI should use headless mode (no browser open)."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, ["telemetry-ui", "--root", str(test_root)])

            # Should have --server.headless true
            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            assert "--server.headless" in call_args
            headless_idx = call_args.index("--server.headless")
            assert call_args[headless_idx + 1] == "true"

    def test_compare_ui_headless_by_default(self, tmp_path):
        """Compare UI should use headless mode (no browser open)."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, ["compare-ui", "--root", str(test_root)])

            # Should have --server.headless true
            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            assert "--server.headless" in call_args
            headless_idx = call_args.index("--server.headless")
            assert call_args[headless_idx + 1] == "true"


class TestURLPrinting:
    """Test that UIs print their URLs on startup."""

    def test_dashboard_prints_url(self, tmp_path):
        """Dashboard should print URL with resolved port."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()
        (test_root / "timewarp.json").write_text("{}")

        with patch("mtbsync.dashboard.run_dashboard"):
            result = runner.invoke(app, ["dashboard", "--root", str(test_root), "--port", "9000"])

            # Should print the URL
            assert "http://127.0.0.1:9000/" in result.output
            assert result.exit_code == 0

    def test_telemetry_ui_prints_url(self, tmp_path):
        """Telemetry UI should print URL with resolved port."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, ["telemetry-ui", "--root", str(test_root), "--port", "9001"])

            # Should print the URL
            assert "http://127.0.0.1:9001/" in result.output

    def test_compare_ui_prints_url(self, tmp_path):
        """Compare UI should print URL with resolved port."""
        test_root = tmp_path / "test_root"
        test_root.mkdir()

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = runner.invoke(app, ["compare-ui", "--root", str(test_root), "--port", "9002"])

            # Should print the URL
            assert "http://127.0.0.1:9002/" in result.output

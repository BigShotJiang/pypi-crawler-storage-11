.. _metadata-command:

Metadata Command
================

.. argparse::
    :module: anemoi.inference.__main__
    :func: create_parser
    :prog: anemoi-inference
    :path: metadata

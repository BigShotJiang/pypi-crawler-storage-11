"""Tests for Hydroqc."""

set logscale x
set logscale y          # Add this if you want log scale on y-axis too
set xlabel "k"
set ylabel "Value"
set title "Functions vs k (log scale)"
set grid
set key top left       # Position of legend
plot "test.txt" using 1:2 with lines linewidth 2 title "a(k)", \
     "test.txt" using 1:3 with points pointtype 7 title "k^(mu+1) exp(-k^2/2)"

The gamma function has poles when evaluated at negative integers, account for that in the code

"""Tests for envwizard."""

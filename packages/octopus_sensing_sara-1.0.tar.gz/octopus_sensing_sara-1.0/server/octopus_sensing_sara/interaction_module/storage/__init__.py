"""Database and storage layer."""

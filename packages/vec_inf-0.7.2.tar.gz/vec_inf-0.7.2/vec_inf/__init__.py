"""vec_inf package."""

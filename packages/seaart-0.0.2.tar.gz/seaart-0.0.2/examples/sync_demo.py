from seaart import SyncClient, APIError


def sync_demo() -> None:
    try:
        with SyncClient() as client:
            # High-level helper: simple ping check
            status = client.ping()
            print(f"Ping OK: {status.msg}")

            # Log in and authenticate the client
            login = client.login("email@example.com", "password")
            print(f"Logged in as {login.email}")

            # High-level helper: fetch account details
            account = client.get_my_account()
            print(f"Hello, {account.name}!")

            # --- Low-level example ---
            # If the library doesn't provide a helper for some endpoint,
            # you can call it directly using `client.request()`.
            resp = client.request("POST", "ping")
            print(f"Manual request: {resp.status.msg}")

    except APIError as e:
        print(f"APIError: {e.msg} (code={e.code}, status={e.http_status})")


if __name__ == "__main__":
    sync_demo()

from __future__ import annotations


class SeaArtError(Exception):
    """Base exception for all SeaArt client errors."""

    pass


class APIError(SeaArtError):
    """Generic API error raised for HTTP or logic failures.

    Attributes:
        http_status: Raw HTTP status code.
        code: Optional API error code.
        msg: Optional message returned by the API.
        body: Raw response body as bytes.
    """

    def __init__(
        self,
        status: int,
        body: bytes,
        *,
        code: int | None = None,
        msg: str | None = None,
    ):
        self.http_status = status
        self.code = code
        self.msg = msg
        self.body = body
        super().__init__(f"HTTP {status}, code={code}, msg={msg}")


class AuthError(APIError):
    """Base class for authentication-related API errors."""

    pass


class AccountNotFoundError(AuthError):
    """Raised when the specified account does not exist."""

    pass


class InvalidPasswordError(AuthError):
    """Raised when an incorrect password is provided."""

    pass


class AuthTokenInvalidError(AuthError):
    """Raised when an authentication token is missing or invalid."""

    pass

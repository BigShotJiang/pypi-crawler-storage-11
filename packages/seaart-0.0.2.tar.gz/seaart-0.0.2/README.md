<div align="center">

# 🌀 SeaArt Python SDK

**Lightweight, typed, and async-ready Python client for the SeaArt.ai API.**

[![PyPI](https://img.shields.io/pypi/v/seaart?color=%2300E5FF&label=PyPI%20version)](https://pypi.org/project/seaart/)
[![Python](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-green)](./LICENSE)

</div>

---

## 🚀 Installation

```bash
pip install seaart
````

## ⚙️ Quick Start

```python
from seaart import SyncClient

with SyncClient() as client:
    login = client.login("email@example.com", "password")
    print(f"Logged in as {login.email}")
```
or
```python
from seaart import AsyncClient

async with AsyncClient() as client:
    login = await client.login("email@example.com", "password")
    print(f"Logged in as {login.email}")
```
🔹 See more examples in [`examples/`](./examples/)

---

## 💎 Highlights

* ⚡ Built on **curl-cffi** — fast, modern, and supports HTTP/2 + HTTP/3
* 🔄 Unified sync & async interfaces with identical APIs
* 🧱 Clean architecture built on `BaseClient`
* 🧩 Fully typed Pydantic v2 models
* 🧠 Low-level `request()` access for custom endpoints
* 💥 Meaningful, structured exceptions
* 🧪 Safe context manager support (`with` / `async with`)

---

## 📘 Documentation

Full documentation is coming soon.

For now, check out:

* [examples/](./examples/)
* Docstrings inside [`src/seaart/_client.py`](./src/seaart/_client.py)
* Quick Start section above

---

## 🧩 TODO

Planned improvements and upcoming features:

* [ ] Add full **API coverage** (more endpoints, account & content methods)
* [ ] Implement detailed **logging** and debug mode
* [ ] Add **unit tests** and CI pipeline
* [ ] Improve **exception handling** and error messages
* [ ] Write **comprehensive** SDK documentation
* [ ] Add **CLI tool** for quick testing
* [ ] Add **rate limiting** and **retry logic**
* [ ] Enhance **response models** (more Pydantic schemas)

> Want to contribute? Fork and open a PR — every improvement helps 💙

## Requirements

Python 3.11 or higher.

---

<div align="center">

<sub><i>Made with ❤️ by <b>DeLaFault</b></i></sub>

</div>

---
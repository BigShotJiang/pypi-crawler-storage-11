from __future__ import annotations

import csv
import logging
import time
from collections.abc import Sequence
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Callable

from mosaic_materials.monte_carlo.adapt import MoveSpec

if TYPE_CHECKING:
    from mosaic_materials.monte_carlo.driver import MCDriver

DriverCallback = Callable[
    [
        "MCDriver", # main driver
        int,        # step
        MoveSpec,   # which move‐spec was used
        bool,       # accepted?
        float,      # χ²
        float,      # U
        float,      # V
    ],
    None,
]


def summary_logger(
    path: str | Path,
    *,
    interval: int = 100,
    include_constraints: bool = True,
    include_temperature: bool = True,
    include_beta: bool = False,
    include_pressure: bool = True,
    include_volume: bool = True,
):
    """
    Append one row every `interval` steps with:

      - step
      - timestamp (local ISO8601)
      - [temperature_K], [beta], [pressure], [volume]
      - total_accepted, total_rejected
      - [per-constraint costs]
      - avg_time_per_step
    """
    path = Path(path)
    start_perf = time.perf_counter()
    total_accept = 0
    total_reject = 0

    header_written = False
    fieldnames: list[str] = []

    def _logger(driver, step, spec, accepted, chi2, U, V):
        nonlocal total_accept, total_reject, header_written, fieldnames

        if accepted:
            total_accept += 1
        else:
            total_reject += 1

        if step % interval != 0:
            return

        now_iso = datetime.now().astimezone().isoformat()
        elapsed = time.perf_counter() - start_perf

        if not header_written:
            fieldnames = ["step", "timestamp"]
            if include_temperature:
                fieldnames.append("temperature_K")
            if include_beta:
                fieldnames.append("beta")
            if include_pressure:
                fieldnames.append("pressure")
            if include_volume:
                fieldnames.append("volume")

            fieldnames += [
                "total_accepted",
                "total_rejected",
                "avg_time_per_step",
            ]
            if include_constraints:
                # fixed order so downstream parsing is stable
                fieldnames.extend(sorted(driver.state.costs.keys()))

            with open(path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()

            header_written = True

        row = {
            "step": step,
            "timestamp": now_iso,
            "total_accepted": total_accept,
            "total_rejected": total_reject,
            "avg_time_per_step": elapsed / step,
        }

        if include_temperature:
            row["temperature_K"] = float(driver.temperature)
        if include_beta:
            row["beta"] = float(driver.beta)
        if include_pressure:
            row["pressure"] = (
                "" if driver.pressure is None else float(driver.pressure)
            )
        if include_volume:
            row["volume"] = float(V)

        if include_constraints:
            for name in fieldnames:
                if name in driver.state.costs:
                    row[name] = driver.state.costs[name]

        with open(path, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writerow(row)

    return _logger


def move_magnitude_tuning_logger(
    move_specs: Sequence[MoveSpec],
    logger: logging.Logger | None = None,
):
    """Log when a MoveSpec changes any of its tuned parameters."""

    logger = logger or logging.getLogger(__name__)

    last_values: dict[tuple[str, str], float | None] = {}
    for spec in move_specs:
        for pname in getattr(spec, "_param_names", []):
            last_values[(spec.name, pname)] = spec.kwargs.get(pname)

    def tuning_logger(
        driver,
        step: int,
        spec: MoveSpec,
        accepted: bool,
        chi2: float,
        U: float,
        V: float,
    ):

        param_names = getattr(spec, "_param_names", [])
        if not param_names:
            return

        for pname in param_names:
            key = (spec.name, pname)
            prev = last_values.get(key)
            current = spec.kwargs[pname]

            # first time or unchanged → skip
            if prev is None or current == prev:
                last_values[key] = current
                continue

            arrow = "↑" if current > prev else "↓"
            logger.info(
                f"[step {step:6d}] {spec.name}.{pname}: "
                f"{prev:.4g} {arrow} {current:.4g}"
            )
            last_values[key] = current

    return tuning_logger


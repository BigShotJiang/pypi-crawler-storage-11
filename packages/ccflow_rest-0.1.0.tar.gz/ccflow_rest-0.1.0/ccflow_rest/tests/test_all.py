from ccflow_rest import *  # noqa


def test_all():
    assert True

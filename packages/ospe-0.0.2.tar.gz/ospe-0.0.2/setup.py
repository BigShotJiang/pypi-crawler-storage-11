from setuptools import setup, find_packages

setup(
    name="ospe",
    version="0.0.2",
    author="xyz",
    packages=find_packages(),
    python_requires=">=3.8",
)

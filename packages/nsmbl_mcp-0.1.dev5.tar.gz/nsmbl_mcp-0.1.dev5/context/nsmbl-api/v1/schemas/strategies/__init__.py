# Strategy schemas package

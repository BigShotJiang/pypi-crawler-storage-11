# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import json
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from types import MethodType
from typing import Any, cast

import pytest

try:
    from tests.adapters._test_stubs import (
        DummyChoice,
        DummyMessage,
        DummyOpenAIClient,
        DummyResponse,
        DummyToolCall,
        RecordingCompletion,
        ResponseType,
        ToolParams,
        ToolPayload,
    )
except ModuleNotFoundError:  # pragma: no cover - fallback for direct invocation
    from ._test_stubs import (
        DummyChoice,
        DummyMessage,
        DummyOpenAIClient,
        DummyResponse,
        DummyToolCall,
        RecordingCompletion,
        ResponseType,
        ToolParams,
        ToolPayload,
    )

from weakincentives.events import InProcessEventBus, ToolInvoked
from weakincentives.prompt import MarkdownSection, Prompt, Tool, ToolResult
from weakincentives.prompt._types import SupportsDataclass
from weakincentives.session import DataEvent, Session, replace_latest, select_latest
from weakincentives.tools import ToolValidationError


@dataclass
class AdapterHarness:
    """Factory wrapper that builds adapters and exposes recorded requests."""

    name: str
    build: Callable[[Sequence[ResponseType]], tuple[Any, list[dict[str, object]]]]


@pytest.fixture(params=("openai", "litellm"))
def adapter_harness(request: pytest.FixtureRequest) -> AdapterHarness:
    if request.param == "openai":
        from weakincentives.adapters import openai as openai_module

        def build(
            responses: Sequence[ResponseType],
        ) -> tuple[Any, list[dict[str, object]]]:
            client = DummyOpenAIClient(responses)
            adapter = openai_module.OpenAIAdapter(
                model="gpt-test", client=cast(Any, client)
            )
            return adapter, client.completions.requests

        return AdapterHarness(name="openai", build=build)

    from weakincentives.adapters import litellm as litellm_module

    def build(responses: Sequence[ResponseType]) -> tuple[Any, list[dict[str, object]]]:
        completion = RecordingCompletion(responses)
        adapter = litellm_module.LiteLLMAdapter(
            model="gpt-test", completion=cast(Any, completion)
        )
        return adapter, completion.requests

    return AdapterHarness(name="litellm", build=build)


def _build_prompt(
    harness: AdapterHarness, tool: Tool[ToolParams, ToolPayload]
) -> Prompt[Any]:
    return Prompt(
        ns=f"tests/adapters/{harness.name}",
        key=f"{harness.name}-shared-tool-execution",
        name="search",
        sections=[
            MarkdownSection[ToolParams](
                title="Task",
                key="task",
                template="Look up ${query}",
                tools=[tool],
            )
        ],
    )


def _build_responses(
    *,
    tool_call: DummyToolCall,
    final_message: DummyMessage,
) -> list[DummyResponse]:
    first = DummyResponse(
        [DummyChoice(DummyMessage(content="thinking", tool_calls=[tool_call]))]
    )
    second = DummyResponse([DummyChoice(final_message)])
    return [first, second]


def _record_tool_events(bus: InProcessEventBus) -> list[ToolInvoked]:
    events: list[ToolInvoked] = []

    def capture(event: object) -> None:
        assert isinstance(event, ToolInvoked)
        events.append(event)

    bus.subscribe(ToolInvoked, capture)
    return events


def _second_tool_message(requests: list[dict[str, object]]) -> dict[str, object]:
    assert len(requests) >= 2
    messages = cast(list[dict[str, object]], requests[1]["messages"])
    return messages[-1]


def test_adapter_tool_execution_success(adapter_harness: AdapterHarness) -> None:
    def handler(params: ToolParams) -> ToolResult[ToolPayload]:
        return ToolResult(
            message="completed",
            value=ToolPayload(answer=params.query),
        )

    tool = Tool[ToolParams, ToolPayload](
        name="search_notes",
        description="Search stored notes.",
        handler=handler,
    )
    prompt = _build_prompt(adapter_harness, tool)
    tool_call = DummyToolCall(
        call_id="call_1",
        name="search_notes",
        arguments=json.dumps({"query": "policies"}),
    )
    responses = _build_responses(
        tool_call=tool_call,
        final_message=DummyMessage(content="All done", tool_calls=None),
    )
    adapter, requests = adapter_harness.build(responses)

    bus = InProcessEventBus()
    events = _record_tool_events(bus)

    result = adapter.evaluate(  # type: ignore[call-arg]
        prompt,
        ToolParams(query="policies"),
        bus=bus,
    )

    assert len(events) == 1
    invocation = events[0]
    assert invocation.result.message == "completed"
    assert invocation.result.success is True
    assert invocation.result.value == ToolPayload(answer="policies")
    assert invocation is result.tool_results[0]

    tool_message = _second_tool_message(requests)
    content_raw = cast(str, tool_message["content"])
    content = json.loads(content_raw)
    assert content["message"] == "completed"
    assert content["success"] is True
    assert content["payload"] == {"answer": "policies"}


def test_adapter_tool_execution_validation_error(
    adapter_harness: AdapterHarness,
) -> None:
    def handler(_: ToolParams) -> ToolResult[ToolPayload]:
        raise ToolValidationError("invalid query")

    tool = Tool[ToolParams, ToolPayload](
        name="search_notes",
        description="Search stored notes.",
        handler=handler,
    )
    prompt = _build_prompt(adapter_harness, tool)
    tool_call = DummyToolCall(
        call_id="call_1",
        name="search_notes",
        arguments=json.dumps({"query": "invalid"}),
    )
    responses = _build_responses(
        tool_call=tool_call,
        final_message=DummyMessage(
            content="Please provide a different query.", tool_calls=None
        ),
    )
    adapter, requests = adapter_harness.build(responses)

    bus = InProcessEventBus()
    events = _record_tool_events(bus)

    result = adapter.evaluate(  # type: ignore[call-arg]
        prompt,
        ToolParams(query="invalid"),
        bus=bus,
    )

    assert len(events) == 1
    invocation = events[0]
    assert invocation.result.message == "Tool validation failed: invalid query"
    assert invocation.result.success is False
    assert invocation.result.value is None
    assert invocation is result.tool_results[0]

    tool_message = _second_tool_message(requests)
    content_raw = cast(str, tool_message["content"])
    content = json.loads(content_raw)
    assert content["message"] == "Tool validation failed: invalid query"
    assert content["success"] is False
    assert "payload" not in content


def test_adapter_tool_execution_unexpected_exception(
    adapter_harness: AdapterHarness,
) -> None:
    def handler(_: ToolParams) -> ToolResult[ToolPayload]:
        raise RuntimeError("handler crash")

    tool = Tool[ToolParams, ToolPayload](
        name="search_notes",
        description="Search stored notes.",
        handler=handler,
    )
    prompt = _build_prompt(adapter_harness, tool)
    tool_call = DummyToolCall(
        call_id="call_1",
        name="search_notes",
        arguments=json.dumps({"query": "policies"}),
    )
    responses = _build_responses(
        tool_call=tool_call,
        final_message=DummyMessage(content="Unable to use the tool.", tool_calls=None),
    )
    adapter, requests = adapter_harness.build(responses)

    bus = InProcessEventBus()
    events = _record_tool_events(bus)

    result = adapter.evaluate(  # type: ignore[call-arg]
        prompt,
        ToolParams(query="policies"),
        bus=bus,
    )

    assert len(events) == 1
    invocation = events[0]
    assert (
        invocation.result.message
        == "Tool 'search_notes' execution failed: handler crash"
    )
    assert invocation.result.success is False
    assert invocation.result.value is None
    assert invocation is result.tool_results[0]

    tool_message = _second_tool_message(requests)
    content_raw = cast(str, tool_message["content"])
    content = json.loads(content_raw)
    assert content["message"] == "Tool 'search_notes' execution failed: handler crash"
    assert content["success"] is False
    assert "payload" not in content


def test_adapter_tool_execution_rolls_back_session(
    adapter_harness: AdapterHarness,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def handler(params: ToolParams) -> ToolResult[ToolPayload]:
        return ToolResult(
            message="completed",
            value=ToolPayload(answer=params.query),
        )

    tool = Tool[ToolParams, ToolPayload](
        name="search_notes",
        description="Search stored notes.",
        handler=handler,
    )
    prompt = _build_prompt(adapter_harness, tool)
    tool_call = DummyToolCall(
        call_id="call_1",
        name="search_notes",
        arguments=json.dumps({"query": "policies"}),
    )
    responses = _build_responses(
        tool_call=tool_call,
        final_message=DummyMessage(content="All done", tool_calls=None),
    )
    adapter, requests = adapter_harness.build(responses)

    bus = InProcessEventBus()
    session = Session(bus=bus)
    session.register_reducer(ToolPayload, replace_latest)
    session.seed_slice(ToolPayload, (ToolPayload(answer="baseline"),))

    original_dispatch = session._dispatch_data_event

    def failing_dispatch(
        self: Session,
        data_type: type[SupportsDataclass],
        event: DataEvent,
    ) -> None:
        original_dispatch(data_type, event)
        raise RuntimeError("Reducer crashed")

    monkeypatch.setattr(
        session,
        "_dispatch_data_event",
        MethodType(failing_dispatch, session),
    )

    events = _record_tool_events(bus)

    result = adapter.evaluate(  # type: ignore[call-arg]
        prompt,
        ToolParams(query="policies"),
        bus=bus,
        session=session,
    )

    assert len(events) == 1
    invocation = events[0]
    assert invocation.result.message.startswith(
        "Reducer errors prevented applying tool result:"
    )
    assert invocation.result.success is True
    assert invocation.result.value == ToolPayload(answer="policies")
    assert invocation is result.tool_results[0]

    latest_payload = select_latest(session, ToolPayload)
    assert latest_payload == ToolPayload(answer="baseline")

    tool_message = _second_tool_message(requests)
    content_raw = cast(str, tool_message["content"])
    content = json.loads(content_raw)
    assert content["message"] == invocation.result.message
    assert content["success"] is True
    assert content["payload"] == {"answer": "policies"}

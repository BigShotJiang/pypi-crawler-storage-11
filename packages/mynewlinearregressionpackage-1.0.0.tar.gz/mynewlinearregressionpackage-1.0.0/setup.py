from setuptools import setup

setup(
   name='myNewLinearRegressionPackage',
   version='1.0.0',
   author='Achouri Youcef',
   author_email='yi.achouri@esi-sba.dz',
   packages=['myNewLinearRegressionPackage'],
   url='http://pypi.python.org/pypi/myNewLinearRegressionPackage/',
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['myNewLinearRegressionPackage']
)
# Contributing to Auric

Thank you for your interest in contributing to Auric! We appreciate contributions of all kinds, from bug reports to feature implementations.

## Quick Links

- **[Development Workflow](WORKFLOW.md)** - Publishing and release process
- **GitHub Issues** - Bug reports and feature requests
- **GitHub Discussions** - Questions and community help

## How to Contribute

### Reporting Bugs

Found a bug? Help us improve by reporting it:

1. **Check existing issues** to avoid duplicates
2. **Use the bug report template** when creating a new issue
3. **Include details**:
   - Python version
   - Auric version
   - Minimal code to reproduce
   - Expected vs actual behavior
   - Error messages and stack traces

### Suggesting Features

Have an idea for a new feature?

1. **Search existing issues** to see if it's already been suggested
2. **Open a feature request** with:
   - Clear description of the feature
   - Use cases and examples
   - Why it would be valuable
   - Potential API design (if applicable)

### Contributing Code

We follow a standard GitHub workflow:

#### 1. Fork and Clone

```bash
git clone https://github.com/yourusername/auric.git
cd auric
```

#### 2. Create a Branch

```bash
git checkout -b feature/your-feature-name
```

Use descriptive branch names:
- `feature/` for new features
- `fix/` for bug fixes
- `docs/` for documentation
- `refactor/` for code improvements

#### 3. Set Up Development Environment

```bash
# Create virtual environment
python -m venv venv
venv\Scripts\activate  # On Windows
# source venv/bin/activate  # On Linux/Mac

# Install in development mode with dev dependencies
pip install -e ".[dev]"
```

#### 4. Make Your Changes

- Write clean, readable code
- Follow existing code style
- Add type hints (100% coverage required)
- Update documentation
- Add tests for new features

#### 5. Test Your Changes

```bash
# Run linter (must pass with 0 errors)
flake8 auric --exclude=venv

# Format code
black auric
isort auric

# Type check (optional but recommended)
mypy auric

# Run tests (if available)
pytest
```

#### 6. Commit Your Changes

Write clear, descriptive commit messages:

```bash
git add .
git commit -m "Add support for stage channels

- Implement StageChannel model
- Add stage instance management
- Include examples in docs"
```

Follow these guidelines:
- Use present tense ("Add feature" not "Added feature")
- Capitalize first letter
- No period at the end of the subject
- Include details in the body if needed

#### 7. Push and Create Pull Request

```bash
git push origin feature/your-feature-name
```

Then open a pull request on GitHub with:
- Clear title summarizing the changes
- Description explaining what and why
- Link to related issues
- Screenshots (if UI-related)

## Code Style Guidelines

### Python Style

We follow PEP 8 with these specifics:

- **Line length**: 100 characters max
- **Imports**: Group by standard library, third-party, local (use `isort`)
- **Quotes**: Prefer single quotes for strings
- **Type hints**: **Required** for all public APIs
- **Linting**: Code must pass `flake8` with zero errors

Example:

```python
from typing import Optional

class Example:
    """
    A simple example class.
    
    This class demonstrates our code style conventions.
    
    Args:
        name: The example name
        value: An optional value
    """
    
    def __init__(self, name: str, value: Optional[int] = None):
        self.name = name
        self.value = value
    
    def get_display_name(self) -> str:
        """Return the formatted display name."""
        return f'Example: {self.name}'
```

### Documentation Style

- **Docstrings**: Use Google style
- **Comments**: Explain "why", not "what"
- **Examples**: Include usage examples in docstrings
- **Type hints**: Required for IDE support

Example:

```python
async def send_message(
    channel_id: int,
    content: str,
    *,
    embed: Optional[Embed] = None,
    components: Optional[list[ActionRow]] = None
) -> Message:
    """
    Send a message to a channel.
    
    This function sends a message with optional embeds and components.
    
    Args:
        channel_id: The ID of the target channel
        content: The message text content
        embed: Optional embed to include
        components: Optional list of action rows with components
    
    Returns:
        The created message object
    
    Raises:
        HTTPException: If the request fails
        Forbidden: If the bot lacks permissions
    
    Example:
        >>> await send_message(
        ...     123456789,
        ...     'Hello!',
        ...     embed=Embed(title='Greeting')
        ... )
    """
    # Implementation
```

## Project Structure

Understanding the codebase:

```
auric/
├── core/           # Core client and connection logic
├── models/         # Data models (Guild, User, Message, etc.)
├── managers/       # Resource managers (GuildManager, etc.)
├── builders/       # Fluent builders for embeds, commands, etc.
├── collectors/     # Message/reaction/interaction collectors
├── commands/       # Command framework
├── components/     # UI components (buttons, selects, etc.)
├── events/         # Event handling and dispatching
├── utils/          # Utility functions and helpers
└── voice/          # Voice channel support
```

## Development Workflow

### Before Committing

```bash
# 1. Run linter (MUST pass)
flake8 auric --exclude=venv

# 2. Format code
black auric
isort auric

# 3. Run tests (if available)
pytest
```

### For Maintainers: Publishing Releases

See **[WORKFLOW.md](WORKFLOW.md)** for complete publishing guide.

Quick summary:
1. Update version in `auric/__init__.py`
2. Update `CHANGELOG.md`
3. Clean old builds: `Remove-Item -Recurse -Force dist, build, auric.egg-info`
4. Build: `python -m build`
5. Upload: `python -m twine upload dist/*`
6. Tag: `git tag -a v0.0.3 -m "Version 0.0.3"`

## Testing

### Writing Tests

- Place tests in `tests/` directory
- Mirror the source structure
- Use descriptive test names
- Test both success and error cases

Example:

```python
import pytest
from auric import Embed

def test_embed_creation():
    """Test basic embed creation."""
    embed = Embed(title='Test', description='Description')
    assert embed.title == 'Test'
    assert embed.description == 'Description'

def test_embed_color():
    """Test embed color setting."""
    embed = Embed()
    embed.color = 0xFF0000
    assert embed.color == 0xFF0000

@pytest.mark.asyncio
async def test_send_message(bot_client):
    """Test sending a message."""
    message = await bot_client.send_message(
        channel_id=123456789,
        content='Test'
    )
    assert message.content == 'Test'
```

### Running Tests

```bash
# Run all tests
pytest

# Run specific test file
pytest tests/test_embed.py

# Run with coverage
pytest --cov=auric --cov-report=html

# Run only fast tests (skip slow integration tests)
pytest -m "not slow"
```

## Review Process

After submitting a pull request:

1. **Automated checks** run (linting with flake8, tests if available)
2. **Maintainer review** - we'll review your code and may request changes
3. **Discussion** - feel free to discuss and ask questions
4. **Approval** - once approved, we'll merge your contribution

Reviews typically happen within a few days. Be patient and responsive to feedback.

## Quality Standards

All contributions must meet these standards:

✅ **Zero flake8 errors** - Run `flake8 auric --exclude=venv`  
✅ **Full type hints** - All public APIs must be type-hinted  
✅ **Code formatting** - Use `black` and `isort`  
✅ **Documentation** - Docstrings for all public functions/classes  
✅ **No breaking changes** - Unless discussed and approved  

## Code of Conduct

Be respectful and inclusive. We welcome contributors of all backgrounds and skill levels.

- Be kind and courteous
- Respect differing viewpoints
- Give constructive feedback
- Focus on what's best for the project

## Getting Help

Need help contributing?

- **GitHub Issues**: Tag issues with "good first issue" or "help wanted"
- **GitHub Discussions**: Ask questions and discuss ideas
- **Discord**: Coming soon!

## Recognition

Contributors are recognized in:
- GitHub's contributors page
- Release notes in CHANGELOG.md
- Project README

Thank you for making Auric better! 🎉

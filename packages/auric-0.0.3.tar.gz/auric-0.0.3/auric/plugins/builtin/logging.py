"""Built-in logging plugin"""

import logging
from typing import Optional

from ..base import Plugin, PluginMeta

__all__ = ["LoggingPlugin"]


class LoggingPlugin(Plugin):
    """
    Event logging plugin.

    Logs Discord events to files or console.
    """

    def __init__(self, bot):
        super().__init__(bot)
        self.logger: Optional[logging.Logger] = None

    @property
    def meta(self) -> PluginMeta:
        return PluginMeta(
            name="logging", version="1.0.0", author="Auric", description="Event logging plugin"
        )

    async def on_load(self) -> None:
        """Initialize logging"""
        # Setup logger
        self.logger = logging.getLogger("auric.events")
        self.logger.setLevel(logging.INFO)

        # Add console handler
        handler = logging.StreamHandler()
        handler.setFormatter(
            logging.Formatter(
                "[%(asctime)s] [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
            )
        )
        self.logger.addHandler(handler)

        # Add file handler if configured
        log_file = self.get_config("log_file")
        if log_file:
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(
                logging.Formatter(
                    "[%(asctime)s] [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
                )
            )
            self.logger.addHandler(file_handler)

    async def on_enable(self) -> None:
        """Start logging"""
        self.add_listener("message_create", self.on_message_create)
        self.add_listener("message_delete", self.on_message_delete)
        self.add_listener("message_update", self.on_message_update)
        self.add_listener("member_join", self.on_member_join)
        self.add_listener("member_remove", self.on_member_remove)
        self.add_listener("member_ban", self.on_member_ban)
        self.add_listener("member_unban", self.on_member_unban)

        self.logger.info("Logging plugin enabled")

    async def on_disable(self) -> None:
        """Stop logging"""
        self.logger.info("Logging plugin disabled")

    async def on_message_create(self, message) -> None:
        """Log message creation"""
        if message.author.bot:
            return

        self.logger.info(
            f"[MESSAGE] {message.author} in #{message.channel}: {message.content[:50]}"
        )

    async def on_message_delete(self, message) -> None:
        """Log message deletion"""
        self.logger.info(f"[DELETE] Message by {message.author} deleted in #{message.channel}")

    async def on_message_update(self, old_message, new_message) -> None:
        """Log message edit"""
        if old_message.content != new_message.content:
            self.logger.info(
                f"[EDIT] {new_message.author} edited message in #{new_message.channel}"
            )

    async def on_member_join(self, member) -> None:
        """Log member join"""
        self.logger.info(f"[JOIN] {member} joined guild {member.guild_id}")

    async def on_member_remove(self, member) -> None:
        """Log member leave"""
        self.logger.info(f"[LEAVE] {member} left guild {member.guild_id}")

    async def on_member_ban(self, guild_id, user) -> None:
        """Log member ban"""
        self.logger.info(f"[BAN] {user} was banned from guild {guild_id}")

    async def on_member_unban(self, guild_id, user) -> None:
        """Log member unban"""
        self.logger.info(f"[UNBAN] {user} was unbanned from guild {guild_id}")

"""Built-in auto-responder plugin"""

import re
from typing import Dict, List

from ..base import Plugin, PluginMeta

__all__ = ["AutoResponderPlugin"]


class AutoResponderPlugin(Plugin):
    """
    Auto-responder plugin.

    Automatically responds to messages matching patterns.
    """

    def __init__(self, bot):
        super().__init__(bot)
        self._responses: Dict[str, str] = {}
        self._regex_responses: List[tuple] = []

    @property
    def meta(self) -> PluginMeta:
        return PluginMeta(
            name="autoresponder",
            version="1.0.0",
            author="Auric",
            description="Auto-responder plugin",
        )

    async def on_load(self) -> None:
        """Load auto-responses"""
        # Load simple responses
        responses = self.get_config("responses", {})
        self._responses = {k.lower(): v for k, v in responses.items()}

        # Load regex responses
        regex_responses = self.get_config("regex_responses", [])
        self._regex_responses = [
            (re.compile(pattern, re.IGNORECASE), response) for pattern, response in regex_responses
        ]

    async def on_enable(self) -> None:
        """Start auto-responding"""
        self.add_listener("message_create", self.on_message)

    async def on_message(self, message) -> None:
        """Check message for auto-responses"""
        if message.author.bot:
            return

        content = message.content.lower().strip()

        # Check simple responses
        if content in self._responses:
            await message.channel.send(self._responses[content])
            return

        # Check regex responses
        for pattern, response in self._regex_responses:
            match = pattern.search(message.content)
            if match:
                # Format response with groups
                formatted = response
                for i, group in enumerate(match.groups(), 1):
                    formatted = formatted.replace(f"{{{i}}}", group)

                await message.channel.send(formatted)
                return

    def add_response(self, trigger: str, response: str) -> None:
        """
        Add a simple auto-response.

        Args:
            trigger: Trigger text (case-insensitive)
            response: Response text
        """
        self._responses[trigger.lower()] = response
        self.set_config("responses", self._responses)

    def remove_response(self, trigger: str) -> None:
        """
        Remove an auto-response.

        Args:
            trigger: Trigger text
        """
        self._responses.pop(trigger.lower(), None)
        self.set_config("responses", self._responses)

    def add_regex_response(self, pattern: str, response: str) -> None:
        """
        Add a regex auto-response.

        Args:
            pattern: Regex pattern
            response: Response text (use {1}, {2}, etc. for groups)
        """
        compiled = re.compile(pattern, re.IGNORECASE)
        self._regex_responses.append((compiled, response))

        # Save to config
        regex_list = [(p.pattern, r) for p, r in self._regex_responses]
        self.set_config("regex_responses", regex_list)

    def clear_responses(self) -> None:
        """Clear all auto-responses"""
        self._responses.clear()
        self._regex_responses.clear()
        self.set_config("responses", {})
        self.set_config("regex_responses", [])

    def list_responses(self) -> Dict[str, str]:
        """
        Get all simple responses.

        Returns:
            dict: Trigger -> Response mapping
        """
        return self._responses.copy()

"""Built-in plugins for Auric"""

from .autoresponder import AutoResponderPlugin
from .logging import LoggingPlugin
from .moderation import ModerationPlugin
from .welcome import WelcomePlugin

__all__ = [
    "ModerationPlugin",
    "LoggingPlugin",
    "WelcomePlugin",
    "AutoResponderPlugin",
]

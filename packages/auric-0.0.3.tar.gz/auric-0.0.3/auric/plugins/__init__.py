"""Plugin system for Auric"""

from .base import Plugin, PluginHook, PluginMeta, plugin_command, plugin_listener
from .loader import PluginLoader
from .registry import PluginRegistry, register_plugin

__all__ = [
    "Plugin",
    "PluginMeta",
    "PluginHook",
    "PluginLoader",
    "PluginRegistry",
    "plugin_command",
    "plugin_listener",
    "register_plugin",
]

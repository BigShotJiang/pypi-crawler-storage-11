"""
Models for guild features
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..core.types import Snowflake

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class WelcomeChannel:
    """
    Represents a channel in the welcome screen.

    Attributes:
        channel_id: The ID of the channel.
        description: The description of the channel.
        emoji_id: The ID of the emoji.
        emoji_name: The name of the emoji.
    """

    __slots__ = ("channel_id", "description", "emoji_id", "emoji_name")

    def __init__(self, *, data: Dict[str, Any]):
        self.channel_id: Snowflake = int(data["channel_id"])
        self.description: str = data["description"]
        self.emoji_id: Optional[Snowflake] = (
            int(data["emoji_id"]) if data["emoji_id"] else None
        )
        self.emoji_name: Optional[str] = data["emoji_name"]


class VanityURL:
    """
    Represents a guild's vanity URL.

    Attributes:
        code: The vanity URL code.
        uses: The number of times the vanity URL has been used.
    """

    __slots__ = ("code", "uses")

    def __init__(self, *, data: Dict[str, Any]):
        self.code: str = data["code"]
        self.uses: int = data["uses"]


class WelcomeScreen:
    """
    Represents a guild's welcome screen.

    Attributes:
        description: The description of the welcome screen.
        welcome_channels: A list of welcome channels.
    """

    __slots__ = ("description", "welcome_channels")

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        self.description: Optional[str] = data.get("description")
        self.welcome_channels: List[WelcomeChannel] = [
            WelcomeChannel(data=channel) for channel in data.get("welcome_channels", [])
        ]

"""
Forum Tag Model

Represents a tag that can be applied to a forum post.
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Dict, Optional


if TYPE_CHECKING:
    pass


class ForumTag:
    """
    Represents a tag for a forum channel.

    Attributes:
        id: The ID of the tag.
        name: The name of the tag.
        moderated: Whether the tag can only be used by moderators.
        emoji_id: The ID of the emoji for the tag.
        emoji_name: The name of the emoji for the tag.
    """

    __slots__ = ("id", "name", "moderated", "emoji_id", "emoji_name")

    def __init__(self, *, data: Dict[str, Any]):
        self.id: int = int(data["id"])
        self.name: str = data["name"]
        self.moderated: bool = data.get("moderated", False)
        self.emoji_id: Optional[int] = (
            int(data["emoji_id"]) if data.get("emoji_id") else None
        )
        self.emoji_name: Optional[str] = data.get("emoji_name")

    def __repr__(self) -> str:
        return f"<ForumTag id={self.id} name={self.name!r}>"

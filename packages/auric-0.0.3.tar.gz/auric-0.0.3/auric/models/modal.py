"""
Modal Components - Interactive popup forms
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union


from .components import (
    ComponentType,
    StringSelect,
    TextInput,
    UserSelect,
    RoleSelect,
    MentionableSelect,
    ChannelSelect,
)

if TYPE_CHECKING:
    from ..core.types import Snowflake


class Label:
    """
    A label container for modal components

    Associates a label and description with a component.
    Used in modals to organize and describe form fields.

    Attributes:
        label: The label text
        description: Optional description text
        component: The component (TextInput or StringSelect)
        required: Whether the field is required

    Example:
        ```python
        label = Label(
            label="What's your name?",
            description="Please enter your full name",
            component=TextInput(
                custom_id="name",
                style=TextInputStyle.SHORT,
                label="Name",
                placeholder="John Doe"
            )
        )
        ```
    """

    __slots__ = ("label", "description", "component", "required", "id")

    def __init__(
        self,
        *,
        label: str,
        component: Union[TextInput, StringSelect, UserSelect, RoleSelect, MentionableSelect, ChannelSelect],
        description: Optional[str] = None,
        required: bool = True,
        id: Optional[int] = None,
    ):
        if len(label) > 45:
            raise ValueError("Label must be 45 characters or less")
        if description and len(description) > 100:
            raise ValueError("Description must be 100 characters or less")

        # Validate component type
        valid_types = (
            TextInput,
            StringSelect,
            UserSelect,
            RoleSelect,
            MentionableSelect,
            ChannelSelect,
        )
        if not isinstance(component, valid_types):
            raise ValueError(
                "Label component must be one of: TextInput, StringSelect, "
                "UserSelect, RoleSelect, MentionableSelect, ChannelSelect"
            )

        self.label = label
        self.description = description
        self.component = component
        self.required = required
        self.id = id

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        data = {
            "type": ComponentType.LABEL,
            "label": self.label,
            "component": (
                self.component.to_dict() if hasattr(self.component, "to_dict") else self.component
            ),
        }

        if self.id is not None:
            data["id"] = self.id

        if self.description:
            data["description"] = self.description

        if not self.required:
            data["required"] = False

        return data

    def __repr__(self) -> str:
        return f"<Label label={self.label!r}>"


class Modal:
    """
    A modal dialog for collecting user input

    Modals are popup forms that appear in response to interactions.
    They can contain TextInput fields and StringSelect menus wrapped in Labels.

    Attributes:
        custom_id: Developer-defined identifier (max 100 chars)
        title: Modal title (max 45 chars)
        components: List of Label components (max 5)

    Example:
        ```python
        modal = Modal(
            custom_id="feedback_modal",
            title="Feedback Form",
            components=[
                Label(
                    label="Subject",
                    component=TextInput(
                        custom_id="subject",
                        style=TextInputStyle.SHORT,
                        label="Subject",
                        max_length=100
                    )
                ),
                Label(
                    label="Feedback",
                    description="Tell us what you think!",
                    component=TextInput(
                        custom_id="feedback",
                        style=TextInputStyle.PARAGRAPH,
                        label="Your Feedback",
                        min_length=10,
                        max_length=1000
                    )
                )
            ]
        )

        # Send modal as interaction response
        await interaction.send_modal(modal)
        ```
    """

    __slots__ = ("custom_id", "title", "components")

    def __init__(
        self, *, custom_id: str, title: str, components: List[Union[Label, Dict[str, Any]]]
    ):
        if len(custom_id) > 100:
            raise ValueError("custom_id must be 100 characters or less")
        if len(title) > 45:
            raise ValueError("Title must be 45 characters or less")
        if not components or len(components) > 5:
            raise ValueError("Modal must have 1-5 components")

        self.custom_id = custom_id
        self.title = title
        self.components = components

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        return {
            "custom_id": self.custom_id,
            "title": self.title,
            "components": [c.to_dict() if hasattr(c, "to_dict") else c for c in self.components],
        }

    def __repr__(self) -> str:
        return f"<Modal custom_id={self.custom_id!r} title={self.title!r}>"


class ModalSubmit:
    """
    Data from a modal submission

    When a user submits a modal, you receive a MODAL_SUBMIT interaction
    with the form data.

    Attributes:
        custom_id: The modal's custom_id
        components: List of submitted components with values

    Example:
        ```python
        @client.event
        async def on_interaction(interaction):
            if interaction.type.value == 5:  # MODAL_SUBMIT
                submit = ModalSubmit.from_data(interaction.data)

                # Get text input values
                subject = submit.get_value('subject')
                feedback = submit.get_value('feedback')

                await interaction.respond(f"Thanks! Subject: {subject}")
        ```
    """

    __slots__ = ("custom_id", "components", "_values")

    def __init__(self, custom_id: str, components: List[Dict[str, Any]]):
        self.custom_id = custom_id
        self.components = components
        self._values: Dict[str, Any] = {}
        self._parse_values()

    def _parse_values(self):
        """Parse component values into a dict for easy access"""
        for component in self.components:
            # Handle Labels
            if component.get("type") == ComponentType.LABEL:
                inner_component = component.get("component", {})
                custom_id = inner_component.get("custom_id")

                # Text input
                if inner_component.get("type") == ComponentType.TEXT_INPUT:
                    value = inner_component.get("value", "")
                    if custom_id:
                        self._values[custom_id] = value

                # String select
                elif inner_component.get("type") in (
                    ComponentType.STRING_SELECT,
                    ComponentType.USER_SELECT,
                    ComponentType.ROLE_SELECT,
                    ComponentType.MENTIONABLE_SELECT,
                    ComponentType.CHANNEL_SELECT,
                ):
                    values = inner_component.get("values", [])
                    if custom_id:
                        self._values[custom_id] = values

            # Handle bare components (legacy)
            else:
                custom_id = component.get("custom_id")

                if component.get("type") == ComponentType.TEXT_INPUT:
                    value = component.get("value", "")
                    if custom_id:
                        self._values[custom_id] = value

                elif component.get("type") == ComponentType.STRING_SELECT:
                    values = component.get("values", [])
                    if custom_id:
                        self._values[custom_id] = values

    def get_value(self, custom_id: str, default: Any = None) -> Any:
        """
        Get a component value by custom_id

        Args:
            custom_id: The component's custom_id
            default: Default value if not found

        Returns:
            The component's value (str for TextInput, list for StringSelect)
        """
        return self._values.get(custom_id, default)

    def get_text(self, custom_id: str, default: str = "") -> str:
        """
        Get a TextInput value

        Args:
            custom_id: The TextInput's custom_id
            default: Default value if not found

        Returns:
            The text input value
        """
        value = self._values.get(custom_id, default)
        return str(value) if value is not None else default

    def get_selected(self, custom_id: str, default: Optional[List[str]] = None) -> List[str]:
        """
        Get a StringSelect value

        Args:
            custom_id: The StringSelect's custom_id
            default: Default value if not found

        Returns:
            List of selected values
        """
        value = self._values.get(custom_id)
        if value is None:
            return default or []
        if isinstance(value, list):
            return value
        return [value]

    def get_selected_users(self, custom_id: str, default: Optional[List[Snowflake]] = None) -> List[Snowflake]:
        """
        Get a UserSelect value

        Args:
            custom_id: The UserSelect's custom_id
            default: Default value if not found

        Returns:
            List of selected user IDs
        """
        value = self._values.get(custom_id)
        if value is None:
            return default or []
        if isinstance(value, list):
            return [int(v) for v in value]
        return [int(value)]

    def get_selected_roles(self, custom_id: str, default: Optional[List[Snowflake]] = None) -> List[Snowflake]:
        """
        Get a RoleSelect value

        Args:
            custom_id: The RoleSelect's custom_id
            default: Default value if not found

        Returns:
            List of selected role IDs
        """
        value = self._values.get(custom_id)
        if value is None:
            return default or []
        if isinstance(value, list):
            return [int(v) for v in value]
        return [int(value)]

    def get_selected_mentionables(
        self, custom_id: str, default: Optional[List[Snowflake]] = None
    ) -> List[Snowflake]:
        """
        Get a MentionableSelect value

        Args:
            custom_id: The MentionableSelect's custom_id
            default: Default value if not found

        Returns:
            List of selected user or role IDs
        """
        value = self._values.get(custom_id)
        if value is None:
            return default or []
        if isinstance(value, list):
            return [int(v) for v in value]
        return [int(value)]

    def get_selected_channels(
        self, custom_id: str, default: Optional[List[Snowflake]] = None
    ) -> List[Snowflake]:
        """
        Get a ChannelSelect value

        Args:
            custom_id: The ChannelSelect's custom_id
            default: Default value if not found

        Returns:
            List of selected channel IDs
        """
        value = self._values.get(custom_id)
        if value is None:
            return default or []
        if isinstance(value, list):
            return [int(v) for v in value]
        return [int(value)]

    @classmethod
    def from_data(cls, data: Dict[str, Any]) -> ModalSubmit:
        """Create ModalSubmit from interaction data"""
        return cls(custom_id=data.get("custom_id", ""), components=data.get("components", []))

    def __repr__(self) -> str:
        return f"<ModalSubmit custom_id={self.custom_id!r} values={len(self._values)}>"


# Convenience function for creating modals
def create_modal(custom_id: str, title: str, *fields: Union[Label, tuple]) -> Modal:
    """
    Convenience function for creating modals

    Args:
        custom_id: Modal identifier
        title: Modal title
        *fields: Label components or tuples of (label, component)

    Example:
        ```python
        # Using Label objects
        modal = create_modal(
            "my_modal",
            "My Form",
            Label(label="Name", component=TextInput(...)),
            Label(label="Email", component=TextInput(...))
        )

        # Using tuples (auto-creates Labels)
        modal = create_modal(
            "my_modal",
            "My Form",
            ("Name", TextInput(custom_id="name", ...)),
            ("Email", TextInput(custom_id="email", ...))
        )
        ```
    """
    components = []

    for field in fields:
        if isinstance(field, Label):
            components.append(field)
        elif isinstance(field, tuple) and len(field) == 2:
            label_text, component = field
            components.append(Label(label=label_text, component=component))
        else:
            raise ValueError("Fields must be Label objects or (label, component) tuples")

    return Modal(custom_id=custom_id, title=title, components=components)

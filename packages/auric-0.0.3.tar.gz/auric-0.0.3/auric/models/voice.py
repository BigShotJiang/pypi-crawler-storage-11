"""
Voice resource models for Discord API.

Represents voice connection status and regions.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..http import HTTPClient
    from .member import Member


@dataclass
class VoiceState:
    """Represents a user's voice connection status.

    Attributes:
        user_id: User this voice state is for
        session_id: Session ID for this voice state
        deaf: Whether user is server deafened
        mute: Whether user is server muted
        self_deaf: Whether user is locally deafened
        self_mute: Whether user is locally muted
        self_video: Whether user's camera is enabled
        suppress: Whether user's permission to speak is denied
        channel_id: Channel user is connected to (None if disconnected)
        guild_id: Guild this voice state is for
        member: Guild member object
        self_stream: Whether user is streaming
        request_to_speak_timestamp: When user requested to speak (stage channels)
    """

    user_id: int
    session_id: str
    deaf: bool
    mute: bool
    self_deaf: bool
    self_mute: bool
    self_video: bool
    suppress: bool
    channel_id: Optional[int] = None
    guild_id: Optional[int] = None
    member: Optional["Member"] = None
    self_stream: Optional[bool] = None
    request_to_speak_timestamp: Optional[datetime] = None

    _http: Optional["HTTPClient"] = None

    @classmethod
    def from_dict(cls, data: dict, http: "HTTPClient" = None) -> "VoiceState":
        """Create a VoiceState from API data."""
        from .member import Member

        # Parse timestamp
        rts = data.get("request_to_speak_timestamp")
        request_to_speak = None
        if rts:
            try:
                request_to_speak = datetime.fromisoformat(rts.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                pass

        return cls(
            user_id=int(data["user_id"]),
            session_id=data["session_id"],
            deaf=data["deaf"],
            mute=data["mute"],
            self_deaf=data["self_deaf"],
            self_mute=data["self_mute"],
            self_video=data["self_video"],
            suppress=data["suppress"],
            channel_id=int(data["channel_id"]) if data.get("channel_id") else None,
            guild_id=int(data["guild_id"]) if data.get("guild_id") else None,
            member=Member(data=data["member"], http=http) if data.get("member") else None,
            self_stream=data.get("self_stream"),
            request_to_speak_timestamp=request_to_speak,
            _http=http,
        )

    def to_dict(self) -> dict:
        """Convert to API format."""
        data = {
            "user_id": str(self.user_id),
            "session_id": self.session_id,
            "deaf": self.deaf,
            "mute": self.mute,
            "self_deaf": self.self_deaf,
            "self_mute": self.self_mute,
            "self_video": self.self_video,
            "suppress": self.suppress,
            "channel_id": str(self.channel_id) if self.channel_id else None,
        }

        if self.guild_id:
            data["guild_id"] = str(self.guild_id)
        if self.member:
            data["member"] = self.member.to_dict()
        if self.self_stream is not None:
            data["self_stream"] = self.self_stream
        if self.request_to_speak_timestamp:
            data["request_to_speak_timestamp"] = self.request_to_speak_timestamp.isoformat()

        return data

    @property
    def is_connected(self) -> bool:
        """Check if user is connected to a voice channel."""
        return self.channel_id is not None

    @property
    def is_speaking(self) -> bool:
        """Check if user can speak (not muted/suppressed)."""
        return not (self.mute or self.suppress or self.self_mute)

    @property
    def is_listening(self) -> bool:
        """Check if user can hear (not deafened)."""
        return not (self.deaf or self.self_deaf)

    @property
    def is_streaming(self) -> bool:
        """Check if user is streaming via Go Live."""
        return self.self_stream is True

    @property
    def is_on_camera(self) -> bool:
        """Check if user has camera enabled."""
        return self.self_video

    @property
    def is_stage_speaker(self) -> bool:
        """Check if user is a speaker in stage channel."""
        return not self.suppress

    @property
    def is_stage_audience(self) -> bool:
        """Check if user is in audience (suppressed)."""
        return self.suppress

    @property
    def requested_to_speak(self) -> bool:
        """Check if user has requested to speak."""
        return self.request_to_speak_timestamp is not None

    async def update(
        self,
        *,
        channel_id: Optional[int] = None,
        suppress: Optional[bool] = None,
        request_to_speak_timestamp: Optional[datetime] = None,
    ) -> None:
        """Update the current user's voice state.

        Only works for current user in guilds.

        Args:
            channel_id: Move to this channel (or None to disconnect)
            suppress: Set suppress state (stage channels)
            request_to_speak_timestamp: Request to speak timestamp (stage channels)

        Raises:
            ValueError: Missing guild ID
            Forbidden: Missing permissions
            HTTPException: Update failed
        """
        if not self.guild_id:
            raise ValueError("Cannot update voice state without guild_id")

        if not self._http:
            raise ValueError("Cannot update voice state without HTTP client")

        json_data = {}
        if channel_id is not None:
            json_data["channel_id"] = str(channel_id) if channel_id else None
        if suppress is not None:
            json_data["suppress"] = suppress
        if request_to_speak_timestamp is not None:
            json_data["request_to_speak_timestamp"] = request_to_speak_timestamp.isoformat()

        await self._http.modify_current_user_voice_state(self.guild_id, json=json_data)

    async def edit_other(
        self, user_id: int, *, channel_id: Optional[int] = None, suppress: Optional[bool] = None
    ) -> None:
        """Edit another user's voice state.

        Requires MUTE_MEMBERS and MOVE_MEMBERS permissions.

        Args:
            user_id: User to edit
            channel_id: Move user to this channel
            suppress: Set suppress state

        Raises:
            ValueError: Missing guild ID
            Forbidden: Missing permissions
            HTTPException: Edit failed
        """
        if not self.guild_id:
            raise ValueError("Cannot edit voice state without guild_id")

        if not self._http:
            raise ValueError("Cannot edit voice state without HTTP client")

        json_data = {}
        if channel_id is not None:
            json_data["channel_id"] = str(channel_id)
        if suppress is not None:
            json_data["suppress"] = suppress

        await self._http.modify_user_voice_state(self.guild_id, user_id, json=json_data)

    def __str__(self) -> str:
        """String representation."""
        status = []
        if self.is_streaming:
            status.append("streaming")
        if self.self_video:
            status.append("camera")
        if self.deaf or self.self_deaf:
            status.append("deafened")
        if self.mute or self.self_mute:
            status.append("muted")
        if self.suppress:
            status.append("suppressed")

        status_str = ", ".join(status) if status else "active"
        channel = f"in {self.channel_id}" if self.channel_id else "disconnected"
        return f"VoiceState({status_str}, {channel})"

    def __repr__(self) -> str:
        """Developer representation."""
        return f"<VoiceState user_id={self.user_id} channel_id={self.channel_id}>"


@dataclass
class VoiceRegion:
    """Represents a voice server region.

    Attributes:
        id: Unique region ID
        name: Region name
        optimal: Whether this is optimal for current user
        deprecated: Whether this region is deprecated
        custom: Whether this is a custom region (events)
    """

    id: str
    name: str
    optimal: bool = False
    deprecated: bool = False
    custom: bool = False

    @classmethod
    def from_dict(cls, data: dict) -> "VoiceRegion":
        """Create a VoiceRegion from API data."""
        return cls(
            id=data["id"],
            name=data["name"],
            optimal=data.get("optimal", False),
            deprecated=data.get("deprecated", False),
            custom=data.get("custom", False),
        )

    def to_dict(self) -> dict:
        """Convert to API format."""
        return {
            "id": self.id,
            "name": self.name,
            "optimal": self.optimal,
            "deprecated": self.deprecated,
            "custom": self.custom,
        }

    @property
    def is_optimal(self) -> bool:
        """Check if this is the optimal region."""
        return self.optimal

    @property
    def is_deprecated(self) -> bool:
        """Check if this region is deprecated."""
        return self.deprecated

    @property
    def is_custom(self) -> bool:
        """Check if this is a custom region."""
        return self.custom

    def __str__(self) -> str:
        """String representation."""
        flags = []
        if self.optimal:
            flags.append("optimal")
        if self.deprecated:
            flags.append("deprecated")
        if self.custom:
            flags.append("custom")

        flag_str = f' ({", ".join(flags)})' if flags else ""
        return f"{self.name}{flag_str}"

    def __repr__(self) -> str:
        """Developer representation."""
        return f"<VoiceRegion id={self.id!r} name={self.name!r}>"


# HTTP Client Methods (to be added to HTTPClient)
"""
async def list_voice_regions(self) -> list[dict]:
    '''Get available voice regions.'''
    return await self.request('GET', '/voice/regions')

async def get_current_user_voice_state(self, guild_id: int) -> dict:
    '''Get current user's voice state in a guild.'''
    return await self.request('GET', f'/guilds/{guild_id}/voice-states/@me')

async def get_user_voice_state(self, guild_id: int, user_id: int) -> dict:
    '''Get a user's voice state in a guild.'''
    return await self.request('GET', f'/guilds/{guild_id}/voice-states/{user_id}')

async def modify_current_user_voice_state(
    self,
    guild_id: int,
    *,
    json: dict
) -> None:
    '''Modify current user's voice state.

    JSON params:
        - channel_id (snowflake): Move to channel
        - suppress (bool): Set suppress state
        - request_to_speak_timestamp (ISO8601): Request to speak
    '''
    await self.request('PATCH', f'/guilds/{guild_id}/voice-states/@me', json=json)

async def modify_user_voice_state(
    self,
    guild_id: int,
    user_id: int,
    *,
    json: dict
) -> None:
    '''Modify another user's voice state.

    Requires MUTE_MEMBERS and MOVE_MEMBERS permissions.

    JSON params:
        - channel_id (snowflake): Move to channel
        - suppress (bool): Set suppress state
    '''
    await self.request('PATCH', f'/guilds/{guild_id}/voice-states/{user_id}', json=json)
"""

"""
Webhook model - represents Discord webhooks
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Dict, List, Optional


from enum import IntEnum

from ..core.types import MISSING, Snowflake

if TYPE_CHECKING:
    from ..core.http import HTTPClient, Route
    from .embed import Embed
    from .message import Message
    from .user import User


class WebhookType(IntEnum):
    """Webhook types"""

    INCOMING = 1
    CHANNEL_FOLLOWER = 2
    APPLICATION = 3


class Webhook:
    """
    Represents a Discord webhook

    Attributes:
        id: Webhook ID
        type: Webhook type
        guild_id: Guild ID (if any)
        channel_id: Channel ID (if any)
        user: User that created webhook
        name: Default name
        avatar: Default avatar hash
        token: Secure token (for incoming webhooks)
        application_id: Bot/OAuth2 app that created this
        source_guild: Guild of followed channel
        source_channel: Followed channel
        url: Webhook execution URL
    """

    __slots__ = (
        "_http",
        "id",
        "type",
        "guild_id",
        "channel_id",
        "user",
        "name",
        "avatar",
        "token",
        "application_id",
        "source_guild",
        "source_channel",
        "url",
        "_state",
    )

    def __init__(self, *, data: Dict[str, Any], http: HTTPClient):
        self._http = http
        self._state = data
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update webhook from API data"""

        self.id: Snowflake = int(data["id"])
        self.type: WebhookType = WebhookType(data.get("type", 1))
        self.guild_id: Optional[Snowflake] = int(data["guild_id"]) if data.get("guild_id") else None
        self.channel_id: Optional[Snowflake] = (
            int(data["channel_id"]) if data.get("channel_id") else None
        )

        user_data = data.get("user")
        self.user: Optional[User] = User(data=user_data, http=self._http) if user_data else None

        self.name: Optional[str] = data.get("name")
        self.avatar: Optional[str] = data.get("avatar")
        self.token: Optional[str] = data.get("token")
        self.application_id: Optional[Snowflake] = (
            int(data["application_id"]) if data.get("application_id") else None
        )

        # Channel follower webhook specific
        self.source_guild = data.get("source_guild")
        self.source_channel = data.get("source_channel")

        self.url: Optional[str] = data.get("url")

    def __repr__(self) -> str:
        return f"<Webhook id={self.id} name={self.name!r} type={self.type.name}>"

    def __str__(self) -> str:
        return self.name or f"Webhook {self.id}"

    @property
    def is_authenticated(self) -> bool:
        """Whether this webhook has authentication (requires token)"""
        return self.token is not None

    @property
    def avatar_url(self) -> Optional[str]:
        """Get avatar URL"""
        if self.avatar:
            return f"https://cdn.discordapp.com/avatars/{self.id}/{self.avatar}.png"
        return None

    async def edit(
        self,
        *,
        name: str = MISSING,
        avatar: Optional[bytes] = MISSING,
        channel_id: Snowflake = MISSING,
        reason: Optional[str] = None,
    ) -> Webhook:
        """
        Edit webhook

        Args:
            name: New name (1-80 characters)
            avatar: New avatar image data
            channel_id: Move to new channel (requires MANAGE_WEBHOOKS)
            reason: Audit log reason

        Returns:
            Updated Webhook

        Raises:
            Forbidden: Missing MANAGE_WEBHOOKS permission
            HTTPException: Edit failed
        """
        payload = {}

        if name is not MISSING:
            payload["name"] = name

        if avatar is not MISSING:
            if avatar is None:
                payload["avatar"] = None
            else:
                import base64

                payload["avatar"] = (
                    f"data:image/png;base64,{base64.b64encode(avatar).decode('ascii')}"
                )

        if channel_id is not MISSING:
            payload["channel_id"] = str(channel_id)

        if self.token:
            # Edit with token (no auth required, but can't change channel)
            if "channel_id" in payload:
                del payload["channel_id"]

            data = await self._http.request(
                Route(
                    "PATCH",
                    "/webhooks/{webhook_id}/{webhook_token}",
                    webhook_id=self.id,
                    webhook_token=self.token,
                ),
                json=payload,
            )
        else:
            # Edit with auth (requires MANAGE_WEBHOOKS)
            data = await self._http.request(
                Route("PATCH", "/webhooks/{webhook_id}", webhook_id=self.id),
                json=payload,
                reason=reason,
            )

        self._update(data)
        return self

    async def delete(self, *, reason: Optional[str] = None) -> None:
        """
        Delete webhook permanently

        Args:
            reason: Audit log reason

        Raises:
            Forbidden: Missing MANAGE_WEBHOOKS permission
            HTTPException: Delete failed
        """
        if self.token:
            # Delete with token (no auth required)
            await self._http.request(
                Route(
                    "DELETE",
                    "/webhooks/{webhook_id}/{webhook_token}",
                    webhook_id=self.id,
                    webhook_token=self.token,
                )
            )
        else:
            # Delete with auth (requires MANAGE_WEBHOOKS)
            await self._http.request(
                Route("DELETE", "/webhooks/{webhook_id}", webhook_id=self.id), reason=reason
            )

    async def execute(
        self,
        content: Optional[str] = None,
        *,
        username: Optional[str] = None,
        avatar_url: Optional[str] = None,
        tts: bool = False,
        embeds: Optional[List[Embed]] = None,
        allowed_mentions: Optional[Dict[str, Any]] = None,
        components: Optional[List[Dict[str, Any]]] = None,
        wait: bool = False,
        thread_id: Optional[Snowflake] = None,
        thread_name: Optional[str] = None,
        applied_tags: Optional[List[Snowflake]] = None,
        flags: Optional[int] = None,
    ) -> Optional[Message]:
        """
        Execute webhook (send a message)

        Args:
            content: Message content (up to 2000 characters)
            username: Override default username
            avatar_url: Override default avatar
            tts: Text-to-speech message
            embeds: List of embeds (max 10)
            allowed_mentions: Allowed mentions
            components: Message components
            wait: Wait for message confirmation
            thread_id: Send to specific thread
            thread_name: Create thread with this name (forum/media channels)
            applied_tags: Tags for thread (forum/media channels)
            flags: Message flags (only SUPPRESS_EMBEDS, SUPPRESS_NOTIFICATIONS, IS_COMPONENTS_V2)

        Returns:
            Message if wait=True, else None

        Raises:
            Forbidden: Missing permissions
            HTTPException: Send failed
            ValueError: No token available or no content provided

        Note:
            Must provide at least one of: content, embeds, components, file, or poll
        """
        if not self.token:
            raise ValueError("Cannot execute webhook without token")

        if not any([content, embeds, components]):
            raise ValueError("Must provide at least one of: content, embeds, components")

        payload = {}

        if content:
            payload["content"] = content

        if username:
            payload["username"] = username

        if avatar_url:
            payload["avatar_url"] = avatar_url

        if tts:
            payload["tts"] = tts

        if embeds:
            payload["embeds"] = [e.to_dict() for e in embeds]

        if allowed_mentions:
            payload["allowed_mentions"] = allowed_mentions

        if components:
            payload["components"] = components

        if thread_name:
            payload["thread_name"] = thread_name

        if applied_tags:
            payload["applied_tags"] = [str(tag) for tag in applied_tags]

        if flags is not None:
            payload["flags"] = flags

        params = {}
        if wait:
            params["wait"] = "true"

        if thread_id:
            params["thread_id"] = str(thread_id)

        data = await self._http.request(
            Route(
                "POST",
                "/webhooks/{webhook_id}/{webhook_token}",
                webhook_id=self.id,
                webhook_token=self.token,
            ),
            json=payload,
            params=params if params else None,
        )

        if wait and data:
            from .message import Message

            return Message(data=data, http=self._http)

        return None

    async def send(
        self,
        content: Optional[str] = None,
        *,
        username: Optional[str] = None,
        avatar_url: Optional[str] = None,
        tts: bool = False,
        embed: Optional[Embed] = None,
        embeds: Optional[List[Embed]] = None,
        allowed_mentions: Optional[Dict[str, Any]] = None,
        thread_id: Optional[Snowflake] = None,
        thread_name: Optional[str] = None,
        wait: bool = True,
    ) -> Optional[Message]:
        """
        Send a message via webhook (alias for execute with wait=True)

        Args:
            content: Message content
            username: Override username
            avatar_url: Override avatar
            tts: Text-to-speech
            embed: Single embed
            embeds: Multiple embeds
            allowed_mentions: Allowed mentions
            thread_id: Send to thread
            thread_name: Create thread
            wait: Wait for confirmation (default True)

        Returns:
            Message object
        """
        if embed and embeds:
            raise ValueError("Cannot specify both embed and embeds")

        if embed:
            embeds = [embed]

        return await self.execute(
            content,
            username=username,
            avatar_url=avatar_url,
            tts=tts,
            embeds=embeds,
            allowed_mentions=allowed_mentions,
            wait=wait,
            thread_id=thread_id,
            thread_name=thread_name,
        )

    async def fetch_message(
        self, message_id: Snowflake, *, thread_id: Optional[Snowflake] = None
    ) -> Message:
        """
        Fetch a message sent by this webhook

        Args:
            message_id: Message ID to fetch
            thread_id: ID of the thread the message is in

        Returns:
            Message object

        Raises:
            NotFound: Message not found
            HTTPException: Fetch failed
            ValueError: No token available
        """
        if not self.token:
            raise ValueError("Cannot fetch message without token")

        params = {}
        if thread_id:
            params["thread_id"] = str(thread_id)

        data = await self._http.request(
            Route(
                "GET",
                "/webhooks/{webhook_id}/{webhook_token}/messages/{message_id}",
                webhook_id=self.id,
                webhook_token=self.token,
                message_id=message_id,
            ),
            params=params if params else None,
        )

        from .message import Message

        return Message(data=data, http=self._http)

    async def edit_message(
        self,
        message_id: Snowflake,
        *,
        content: Optional[str] = MISSING,
        embeds: Optional[List[Embed]] = MISSING,
        allowed_mentions: Optional[Dict[str, Any]] = MISSING,
        thread_id: Optional[Snowflake] = None,
    ) -> Message:
        """
        Edit a message sent by this webhook

        Args:
            message_id: Message ID to edit
            content: New content
            embeds: New embeds
            allowed_mentions: New allowed mentions
            thread_id: ID of the thread the message is in

        Returns:
            Updated Message

        Raises:
            HTTPException: Edit failed
            ValueError: No token available

        Note:
            All parameters are optional and nullable.
        """
        if not self.token:
            raise ValueError("Cannot edit message without token")

        payload = {}

        if content is not MISSING:
            payload["content"] = content

        if embeds is not MISSING:
            payload["embeds"] = [e.to_dict() for e in embeds] if embeds else []

        if allowed_mentions is not MISSING:
            payload["allowed_mentions"] = allowed_mentions

        params = {}
        if thread_id:
            params["thread_id"] = str(thread_id)

        data = await self._http.request(
            Route(
                "PATCH",
                "/webhooks/{webhook_id}/{webhook_token}/messages/{message_id}",
                webhook_id=self.id,
                webhook_token=self.token,
                message_id=message_id,
            ),
            json=payload if payload else None,
            params=params if params else None,
        )

        from .message import Message

        return Message(data=data, http=self._http)

    async def delete_message(
        self, message_id: Snowflake, *, thread_id: Optional[Snowflake] = None
    ) -> None:
        """
        Delete a message sent by this webhook

        Args:
            message_id: Message ID to delete
            thread_id: ID of the thread the message is in

        Raises:
            HTTPException: Delete failed
            ValueError: No token available
        """
        if not self.token:
            raise ValueError("Cannot delete message without token")

        params = {}
        if thread_id:
            params["thread_id"] = str(thread_id)

        await self._http.request(
            Route(
                "DELETE",
                "/webhooks/{webhook_id}/{webhook_token}/messages/{message_id}",
                webhook_id=self.id,
                webhook_token=self.token,
                message_id=message_id,
            ),
            params=params if params else None,
        )

    @classmethod
    async def from_url(cls, url: str, *, http: HTTPClient) -> Webhook:
        """
        Create a Webhook from a webhook URL

        Args:
            url: Webhook URL
            http: HTTP client

        Returns:
            Webhook object

        Raises:
            ValueError: Invalid webhook URL
        """
        import re

        # Parse webhook URL
        pattern = r"https://(?:canary\.|ptb\.)?discord\.com/api/webhooks/(\d+)/([A-Za-z0-9_-]+)"
        match = re.match(pattern, url)

        if not match:
            raise ValueError(f"Invalid webhook URL: {url}")

        webhook_id = int(match.group(1))
        webhook_token = match.group(2)

        data = await http.request(
            Route(
                "GET",
                "/webhooks/{webhook_id}/{webhook_token}",
                webhook_id=webhook_id,
                webhook_token=webhook_token,
            )
        )

        return cls(data=data, http=http)


__all__ = [
    "Webhook",
    "WebhookType",
]

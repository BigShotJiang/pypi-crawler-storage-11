"""
Emoji - Custom and standard emojis
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Dict, List, Optional


if TYPE_CHECKING:
    from ..core.http import HTTPClient
    from .user import User


class Emoji:
    """
    Represents a Discord emoji (custom or standard)

    Custom emojis can be used within a guild or by bots with access.
    Standard emojis are unicode emojis (like 🔥).

    Attributes:
        id: Emoji ID (None for standard emojis)
        name: Emoji name (or unicode character)
        roles: Role IDs allowed to use this emoji
        user: User who created this emoji
        require_colons: Whether emoji must be wrapped in colons
        managed: Whether emoji is managed by an integration
        animated: Whether emoji is animated
        available: Whether emoji can be used (may be false due to loss of boosts)

    Example:
        ```python
        # Custom emoji
        emoji = guild.get_emoji(123456789)
        print(f"{emoji.name} - Animated: {emoji.animated}")

        # Standard emoji
        await message.add_reaction("🔥")

        # Use custom emoji in message
        await channel.send(f"Check this out {emoji}")
        ```
    """

    __slots__ = (
        "id",
        "name",
        "roles",
        "user",
        "require_colons",
        "managed",
        "animated",
        "available",
        "guild_id",
        "_http",
    )

    def __init__(
        self,
        *,
        data: Dict[str, Any],
        http: Optional[HTTPClient] = None,
        guild_id: Optional[int] = None,
    ):
        self._http = http
        self.guild_id = guild_id
        self._update(data)

    def _update(self, data: Dict[str, Any]):
        """Update emoji from API data"""
        self.id: Optional[int] = data.get("id")
        self.name: Optional[str] = data.get("name")
        self.roles: List[int] = data.get("roles", [])
        self.user: Optional[User] = None  # Populated separately if needed
        self.require_colons: bool = data.get("require_colons", True)
        self.managed: bool = data.get("managed", False)
        self.animated: bool = data.get("animated", False)
        self.available: bool = data.get("available", True)

        # Parse user if present
        if "user" in data and self._http:

            self.user = User(data=data["user"], http=self._http)

    @property
    def is_custom(self) -> bool:
        """Whether this is a custom emoji (vs standard unicode)"""
        return self.id is not None

    @property
    def is_unicode(self) -> bool:
        """Whether this is a standard unicode emoji"""
        return self.id is None

    @property
    def url(self) -> Optional[str]:
        """
        URL for the emoji image

        Returns None for standard unicode emojis.
        """
        if not self.is_custom:
            return None

        ext = "gif" if self.animated else "png"
        return f"https://cdn.discordapp.com/emojis/{self.id}.{ext}"

    @property
    def created_at(self):
        """When the emoji was created (custom emojis only)"""
        if not self.id:
            return None
        from ..utils.snowflake import snowflake_time

        return snowflake_time(self.id)

    def __str__(self) -> str:
        """Format emoji for use in messages"""
        if self.is_unicode:
            return self.name or ""

        if self.animated:
            return f"<a:{self.name}:{self.id}>"
        return f"<:{self.name}:{self.id}>"

    def __repr__(self) -> str:
        if self.is_unicode:
            return f"<Emoji name={self.name!r}>"
        return f"<Emoji id={self.id} name={self.name!r} animated={self.animated}>"

    def __eq__(self, other) -> bool:
        if isinstance(other, Emoji):
            return self.id == other.id and self.name == other.name
        return False

    def __hash__(self) -> int:
        return hash((self.id, self.name))

    async def edit(
        self,
        *,
        name: Optional[str] = None,
        roles: Optional[List[int]] = None,
        reason: Optional[str] = None,
    ) -> Emoji:
        """
        Edit this emoji

        Requires MANAGE_GUILD_EXPRESSIONS permission.

        Args:
            name: New emoji name
            roles: Role IDs allowed to use emoji
            reason: Audit log reason

        Returns:
            Updated emoji object

        Raises:
            Forbidden: Missing permissions
            HTTPException: Edit failed
        """
        if not self._http or not self.id:
            raise ValueError("Cannot edit standard emoji or emoji without HTTP client")

        if not self._http or not self.id or not self.guild_id:
            raise ValueError(
                "Cannot edit standard emoji or emoji without HTTP client/guild context"
            )

        payload = {}
        if name is not None:
            payload["name"] = name
        if roles is not None:
            payload["roles"] = roles

        from ..core.http import Route

        route = Route("PATCH", f"/guilds/{self.guild_id}/emojis/{self.id}")
        data = await self._http.request(route, json=payload, reason=reason)
        self._update(data)

    async def delete(self, *, reason: Optional[str] = None) -> None:
        """
        Delete this emoji

        Requires MANAGE_GUILD_EXPRESSIONS permission.

        Args:
            reason: Audit log reason

        Raises:
            Forbidden: Missing permissions
            HTTPException: Delete failed
        """
        if not self._http or not self.id or not self.guild_id:
            raise ValueError(
                "Cannot delete standard emoji or emoji without HTTP client/guild context"
            )

        from ..core.http import Route

        route = Route("DELETE", f"/guilds/{self.guild_id}/emojis/{self.id}")
        await self._http.request(route, reason=reason)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict format"""
        data: Dict[str, Any] = {}

        if self.id is not None:
            data["id"] = str(self.id)

        if self.name is not None:
            data["name"] = self.name

        if self.animated:
            data["animated"] = True

        return data

    @classmethod
    def from_str(cls, emoji_str: str) -> Emoji:
        """
        Parse emoji from string format

        Args:
            emoji_str: Emoji string (unicode or <:name:id> format)

        Returns:
            Emoji object

        Example:
            ```python
            # Parse custom emoji
            emoji = Emoji.from_str("<:python:123456789>")

            # Parse unicode emoji
            emoji = Emoji.from_str("🔥")
            ```
        """
        # Check if it's a custom emoji
        if emoji_str.startswith("<") and emoji_str.endswith(">"):
            # <:name:id> or <a:name:id>
            animated = emoji_str.startswith("<a:")
            parts = emoji_str[1:-1].split(":")

            if len(parts) == 3:
                # ['' or 'a', name, id]
                name = parts[1]
                emoji_id = int(parts[2])

                return cls(data={"id": emoji_id, "name": name, "animated": animated})

        # Standard unicode emoji
        return cls(data={"id": None, "name": emoji_str})


class PartialEmoji:
    """
    Partial emoji data (used in reactions)

    Contains minimal emoji information for rendering.

    Attributes:
        id: Emoji ID (None for unicode)
        name: Emoji name
        animated: Whether emoji is animated
    """

    __slots__ = ("id", "name", "animated")

    def __init__(self, *, data: Dict[str, Any]):
        self.id: Optional[int] = data.get("id")
        self.name: Optional[str] = data.get("name")
        self.animated: bool = data.get("animated", False)

    @property
    def is_custom(self) -> bool:
        """Whether this is a custom emoji"""
        return self.id is not None

    @property
    def is_unicode(self) -> bool:
        """Whether this is a unicode emoji"""
        return self.id is None

    def __str__(self) -> str:
        if self.is_unicode:
            return self.name or ""

        if self.animated:
            return f"<a:{self.name}:{self.id}>"
        return f"<:{self.name}:{self.id}>"

    def __repr__(self) -> str:
        return f"<PartialEmoji id={self.id} name={self.name!r}>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        data: Dict[str, Any] = {}

        if self.id is not None:
            data["id"] = str(self.id)

        if self.name is not None:
            data["name"] = self.name

        if self.animated:
            data["animated"] = True

        return data


# Convenience function for creating emojis
def parse_emoji(value: Any) -> Dict[str, Any]:
    """
    Parse various emoji formats into API dict

    Args:
        value: Emoji (Emoji object, PartialEmoji, or string)

    Returns:
        Dict suitable for API requests

    Example:
        ```python
        # From Emoji object
        emoji_data = parse_emoji(emoji)

        # From string
        emoji_data = parse_emoji("🔥")
        emoji_data = parse_emoji("<:python:123456789>")
        ```
    """
    if isinstance(value, (Emoji, PartialEmoji)):
        return value.to_dict()

    if isinstance(value, str):
        emoji = Emoji.from_str(value)
        return emoji.to_dict()

    if isinstance(value, dict):
        return value

    raise TypeError(f"Cannot parse emoji from type {type(value)}")

"""
Command (slash command) interaction
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ...types.interaction import ApplicationCommandOptionType, ApplicationCommandType
from .base import BaseInteraction


@dataclass
class CommandInteractionOption:
    """Represents a command option value"""

    name: str
    type: ApplicationCommandOptionType
    value: Optional[Any] = None
    options: Optional[List["CommandInteractionOption"]] = None
    focused: bool = False

    def get_option(self, name: str) -> Optional["CommandInteractionOption"]:
        """Get a sub-option by name"""
        if not self.options:
            return None
        return next((opt for opt in self.options if opt.name == name), None)


@dataclass
class CommandInteraction(BaseInteraction):
    """Represents a slash command interaction"""

    command_name: Optional[str] = None
    command_type: Optional[ApplicationCommandType] = None
    command_id: Optional[str] = None
    options: Optional[List[CommandInteractionOption]] = None
    resolved: Optional[Dict[str, Any]] = None

    def __post_init__(self):
        """Parse interaction data"""
        if self.data:
            self.command_name = self.data.get("name")
            self.command_type = self.data.get("type", ApplicationCommandType.CHAT_INPUT)
            self.command_id = self.data.get("id")
            self.resolved = self.data.get("resolved", {})

            # Parse options
            raw_options = self.data.get("options", [])
            self.options = [self._parse_option(opt) for opt in raw_options]

    def _parse_option(self, data: Dict[str, Any]) -> CommandInteractionOption:
        """Parse a single option"""
        return CommandInteractionOption(
            name=data["name"],
            type=data["type"],
            value=data.get("value"),
            options=[self._parse_option(opt) for opt in data.get("options", [])],
            focused=data.get("focused", False),
        )

    def get_option(self, name: str) -> Optional[CommandInteractionOption]:
        """Get an option by name"""
        if not self.options:
            return None
        return next((opt for opt in self.options if opt.name == name), None)

    def get_string(self, name: str) -> Optional[str]:
        """Get a string option value"""
        opt = self.get_option(name)
        return opt.value if opt else None

    def get_integer(self, name: str) -> Optional[int]:
        """Get an integer option value"""
        opt = self.get_option(name)
        return opt.value if opt else None

    def get_boolean(self, name: str) -> Optional[bool]:
        """Get a boolean option value"""
        opt = self.get_option(name)
        return opt.value if opt else None

    def get_user(self, name: str) -> Optional[str]:
        """Get a user ID from option"""
        opt = self.get_option(name)
        return opt.value if opt else None

    def get_channel(self, name: str) -> Optional[str]:
        """Get a channel ID from option"""
        opt = self.get_option(name)
        return opt.value if opt else None

    def get_role(self, name: str) -> Optional[str]:
        """Get a role ID from option"""
        opt = self.get_option(name)
        return opt.value if opt else None

"""
Component (button/select) interaction
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional

from ...types.interaction import InteractionCallbackType
from .base import BaseInteraction


@dataclass
class ComponentInteraction(BaseInteraction):
    """Represents a button or select menu interaction"""

    custom_id: Optional[str] = None
    component_type: Optional[int] = None
    values: Optional[list] = None

    def __post_init__(self):
        """Parse component data"""
        if self.data:
            self.custom_id = self.data.get("custom_id")
            self.component_type = self.data.get("component_type")
            self.values = self.data.get("values", [])

    async def update(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Dict[str, Any]] = None,
        embeds: Optional[list] = None,
        components: Optional[list] = None,
    ) -> None:
        """
        Update the message this component is attached to

        Args:
            content: New message content
            embed: Single embed
            embeds: List of embeds
            components: New components
        """
        if self._responded:
            raise ValueError("Already responded to this interaction")

        data = {"type": InteractionCallbackType.UPDATE_MESSAGE, "data": {}}

        if content is not None:
            data["data"]["content"] = content
        if embed:
            data["data"]["embeds"] = [embed]
        elif embeds:
            data["data"]["embeds"] = embeds
        if components is not None:
            data["data"]["components"] = components

        await self._client.http.create_interaction_response(self.id, self.token, data)
        self._responded = True

    async def defer_update(self) -> None:
        """
        Defer an update to the component message
        """
        if self._responded or self._deferred:
            raise ValueError("Already responded/deferred to this interaction")

        data = {"type": InteractionCallbackType.DEFERRED_UPDATE_MESSAGE}

        await self._client.http.create_interaction_response(self.id, self.token, data)
        self._deferred = True

"""
Sticker Pack Model

Represents a pack of standard stickers.
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class StickerPack:
    """
    A pack of standard stickers.

    Attributes:
        id: Pack ID
        stickers: Stickers in the pack
        name: Pack name
        sku_id: Pack's SKU ID
        cover_sticker_id: ID of cover sticker
        description: Pack description
        banner_asset_id: Banner image ID
    """

    __slots__ = (
        "id",
        "stickers",
        "name",
        "sku_id",
        "cover_sticker_id",
        "description",
        "banner_asset_id",
    )

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        from .sticker import Sticker

        self.id: int = int(data["id"])
        self.stickers: List[Sticker] = [
            Sticker(data=s, http=http) for s in data.get("stickers", [])
        ]
        self.name: str = data["name"]
        self.sku_id: int = int(data["sku_id"])
        self.cover_sticker_id: Optional[int] = (
            int(data["cover_sticker_id"]) if "cover_sticker_id" in data else None
        )
        self.description: str = data["description"]
        self.banner_asset_id: Optional[int] = (
            int(data["banner_asset_id"]) if "banner_asset_id" in data else None
        )

    @property
    def banner_url(self) -> Optional[str]:
        """URL for the pack's banner image"""
        if not self.banner_asset_id:
            return None
        return f"https://cdn.discordapp.com/app-assets/710982414301790216/store/{self.banner_asset_id}.png"

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"<StickerPack id={self.id} name={self.name!r} stickers={len(self.stickers)}>"

    def __eq__(self, other) -> bool:
        return isinstance(other, StickerPack) and self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

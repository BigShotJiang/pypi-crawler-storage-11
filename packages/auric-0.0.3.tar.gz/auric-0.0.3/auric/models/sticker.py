"""
Sticker - Guild and standard stickers
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from enum import IntEnum

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class StickerType(IntEnum):
    """Type of sticker"""

    STANDARD = 1  # Official sticker in a pack
    GUILD = 2  # Sticker uploaded to a guild


class StickerFormatType(IntEnum):
    """Sticker format type"""

    PNG = 1  # PNG image
    APNG = 2  # Animated PNG
    LOTTIE = 3  # Lottie animation
    GIF = 4  # GIF image


class Sticker:
    """
    Represents a sticker that can be sent in messages

    Stickers can be standard (from packs) or guild-specific.

    Attributes:
        id: Sticker ID
        pack_id: Pack ID (for standard stickers)
        name: Sticker name
        description: Sticker description
        tags: Autocomplete/suggestion tags
        type: Sticker type (STANDARD or GUILD)
        format_type: Format type (PNG, APNG, LOTTIE, GIF)
        available: Whether sticker can be used
        guild_id: Guild ID (for guild stickers)
        user: User who uploaded the sticker
        sort_value: Sort order within pack

    Example:
        ```python
        # Send message with sticker
        sticker = guild.get_sticker(123456789)
        await channel.send("Check this out!", stickers=[sticker])

        # Create guild sticker
        with open('sticker.png', 'rb') as f:
            sticker = await guild.create_sticker(
                name="Cool Sticker",
                description="A very cool sticker",
                emoji="😎",
                file=f
            )
        ```
    """

    __slots__ = (
        "id",
        "pack_id",
        "name",
        "description",
        "tags",
        "type",
        "format_type",
        "available",
        "guild_id",
        "user",
        "sort_value",
        "_http",
    )

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]):
        """Update sticker from API data"""
        self.id: int = int(data["id"])
        self.pack_id: Optional[int] = int(data["pack_id"]) if "pack_id" in data else None
        self.name: str = data["name"]
        self.description: Optional[str] = data.get("description")
        self.tags: str = data.get("tags", "")
        self.type: StickerType = StickerType(data["type"])
        self.format_type: StickerFormatType = StickerFormatType(data["format_type"])
        self.available: bool = data.get("available", True)
        self.guild_id: Optional[int] = int(data["guild_id"]) if "guild_id" in data else None
        self.sort_value: Optional[int] = data.get("sort_value")

        self.user: Optional[User] = None
        if "user" in data and self._http:
            from .user import User
            self.user = User(data=data["user"], http=self._http)

    @property
    def is_guild_sticker(self) -> bool:
        """Whether this is a guild sticker"""
        return self.type == StickerType.GUILD

    @property
    def is_standard_sticker(self) -> bool:
        """Whether this is a standard sticker from a pack"""
        return self.type == StickerType.STANDARD

    @property
    def url(self) -> str:
        """URL for the sticker image"""
        # Determine extension based on format
        if self.format_type == StickerFormatType.LOTTIE:
            ext = "json"  # Lottie files are JSON
        elif self.format_type == StickerFormatType.PNG:
            ext = "png"
        elif self.format_type == StickerFormatType.APNG:
            ext = "png"
        elif self.format_type == StickerFormatType.GIF:
            ext = "gif"
        else:
            ext = "png"

        return f"https://media.discordapp.net/stickers/{self.id}.{ext}"

    @property
    def created_at(self):
        """When the sticker was created"""
        from ..utils.snowflake import snowflake_time

        return snowflake_time(self.id)

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"<Sticker id={self.id} name={self.name!r} type={self.type.name}>"

    def __eq__(self, other) -> bool:
        return isinstance(other, Sticker) and self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    async def edit(
        self,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> Sticker:
        """
        Edit this guild sticker

        Requires MANAGE_GUILD_EXPRESSIONS permission.
        Only works for guild stickers.

        Args:
            name: New sticker name
            description: New description
            tags: New tags
            reason: Audit log reason

        Returns:
            Updated sticker object

        Raises:
            Forbidden: Missing permissions
            HTTPException: Edit failed
        """
        if not self.is_guild_sticker:
            raise ValueError("Can only edit guild stickers")

        if not self._http or not self.guild_id:
            raise ValueError("Cannot edit sticker without HTTP client or guild ID")

        from ..core.http import Route

        payload = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if tags is not None:
            payload["tags"] = tags

        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        route = Route(
            "PATCH",
            "/guilds/{guild_id}/stickers/{sticker_id}",
            guild_id=self.guild_id,
            sticker_id=self.id,
        )

        data = await self._http.request(route, json=payload, headers=headers)
        self._update(data)
        return self

    async def delete(self, *, reason: Optional[str] = None) -> None:
        """
        Delete this guild sticker

        Requires MANAGE_GUILD_EXPRESSIONS permission.
        Only works for guild stickers.

        Args:
            reason: Audit log reason

        Raises:
            Forbidden: Missing permissions
            HTTPException: Delete failed
        """
        if not self.is_guild_sticker:
            raise ValueError("Can only delete guild stickers")

        if not self._http or not self.guild_id:
            raise ValueError("Cannot delete sticker without HTTP client or guild ID")

        from ..core.http import Route

        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        route = Route(
            "DELETE",
            "/guilds/{guild_id}/stickers/{sticker_id}",
            guild_id=self.guild_id,
            sticker_id=self.id,
        )

        await self._http.request(route, headers=headers)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict format"""
        return {"id": str(self.id), "name": self.name, "format_type": self.format_type.value}


class StickerItem:
    """
    Minimal sticker data for rendering

    Used in messages to represent stickers without full data.

    Attributes:
        id: Sticker ID
        name: Sticker name
        format_type: Sticker format type
    """

    __slots__ = ("id", "name", "format_type")

    def __init__(self, *, data: Dict[str, Any]):
        self.id: int = int(data["id"])
        self.name: str = data["name"]
        self.format_type: StickerFormatType = StickerFormatType(data["format_type"])

    @property
    def url(self) -> str:
        """URL for the sticker"""
        if self.format_type == StickerFormatType.LOTTIE:
            ext = "json"
        elif self.format_type == StickerFormatType.PNG:
            ext = "png"
        elif self.format_type == StickerFormatType.APNG:
            ext = "png"
        elif self.format_type == StickerFormatType.GIF:
            ext = "gif"
        else:
            ext = "png"

        return f"https://media.discordapp.net/stickers/{self.id}.{ext}"

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"<StickerItem id={self.id} name={self.name!r}>"

    def __eq__(self, other) -> bool:
        return isinstance(other, StickerItem) and self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API dict"""
        return {"id": str(self.id), "name": self.name, "format_type": self.format_type.value}


class StickerPack:
    """
    A pack of standard stickers

    Attributes:
        id: Pack ID
        stickers: Stickers in the pack
        name: Pack name
        sku_id: Pack's SKU ID
        cover_sticker_id: ID of cover sticker
        description: Pack description
        banner_asset_id: Banner image ID

    Example:
        ```python
        # Get sticker packs
        packs = await client.fetch_sticker_packs()

        for pack in packs:
            print(f"{pack.name}: {len(pack.stickers)} stickers")
        ```
    """

    __slots__ = (
        "id",
        "stickers",
        "name",
        "sku_id",
        "cover_sticker_id",
        "description",
        "banner_asset_id",
    )

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self.id: int = int(data["id"])
        self.stickers: List[Sticker] = [
            Sticker(data=s, http=http) for s in data.get("stickers", [])
        ]
        self.name: str = data["name"]
        self.sku_id: int = int(data["sku_id"])
        self.cover_sticker_id: Optional[int] = (
            int(data["cover_sticker_id"]) if "cover_sticker_id" in data else None
        )
        self.description: str = data["description"]
        self.banner_asset_id: Optional[int] = (
            int(data["banner_asset_id"]) if "banner_asset_id" in data else None
        )

    @property
    def banner_url(self) -> Optional[str]:
        """URL for the pack's banner image"""
        if not self.banner_asset_id:
            return None
        return f"https://cdn.discordapp.com/app-assets/710982414301790216/store/{self.banner_asset_id}.png"

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"<StickerPack id={self.id} name={self.name!r} stickers={len(self.stickers)}>"

    def __eq__(self, other) -> bool:
        return isinstance(other, StickerPack) and self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

"""
Auto Moderation - Discord auto-moderation system

Auto-moderation automatically filters and moderates content.
"""

from __future__ import annotations

from enum import IntEnum
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class AutoModTriggerType(IntEnum):
    """Types of auto-mod triggers"""

    KEYWORD = 1  # Check message content for keywords
    SPAM = 3  # Check for spam
    KEYWORD_PRESET = 4  # Check for preset keyword lists
    MENTION_SPAM = 5  # Check for mention spam


class AutoModKeywordPresetType(IntEnum):
    """Preset keyword lists"""

    PROFANITY = 1  # Words that may be considered swearing/cursing
    SEXUAL_CONTENT = 2  # Words that refer to sexually explicit behavior/anatomy
    SLURS = 3  # Personal insults or words that may be offensive


class AutoModEventType(IntEnum):
    """When auto-mod rule is triggered"""

    MESSAGE_SEND = 1  # When a message is sent


class AutoModActionType(IntEnum):
    """Actions to take when rule is triggered"""

    BLOCK_MESSAGE = 1  # Block the content
    SEND_ALERT_MESSAGE = 2  # Log to a specified channel
    TIMEOUT = 3  # Timeout the user


class AutoModTriggerMetadata:
    """
    Metadata for auto-mod triggers.

    Attributes:
        keyword_filter: Keywords to filter (KEYWORD type)
        regex_patterns: Regex patterns to match (KEYWORD type)
        presets: Preset keyword lists (KEYWORD_PRESET type)
        allow_list: Keywords exempt from checks
        mention_total_limit: Max mentions allowed (MENTION_SPAM type)
        mention_raid_protection: Enable mention raid protection
    """

    __slots__ = (
        "keyword_filter",
        "regex_patterns",
        "presets",
        "allow_list",
        "mention_total_limit",
        "mention_raid_protection",
    )

    def __init__(self, data: Dict[str, Any]):
        self.keyword_filter: List[str] = data.get("keyword_filter", [])
        self.regex_patterns: List[str] = data.get("regex_patterns", [])

        presets_data = data.get("presets", [])
        self.presets: List[AutoModKeywordPresetType] = [
            AutoModKeywordPresetType(p) for p in presets_data
        ]

        self.allow_list: List[str] = data.get("allow_list", [])
        self.mention_total_limit: Optional[int] = data.get(
            "mention_total_limit"
        )
        self.mention_raid_protection: bool = data.get(
            "mention_raid_protection_enabled", False
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        data = {}

        if self.keyword_filter:
            data["keyword_filter"] = self.keyword_filter

        if self.regex_patterns:
            data["regex_patterns"] = self.regex_patterns

        if self.presets:
            data["presets"] = [int(p) for p in self.presets]

        if self.allow_list:
            data["allow_list"] = self.allow_list

        if self.mention_total_limit is not None:
            data["mention_total_limit"] = self.mention_total_limit

        if self.mention_raid_protection:
            data["mention_raid_protection_enabled"] = True

        return data


class AutoModActionMetadata:
    """
    Metadata for auto-mod actions.

    Attributes:
        channel_id: Channel to send alert to (SEND_ALERT_MESSAGE)
        duration_seconds: Timeout duration in seconds (TIMEOUT)
        custom_message: Custom message to show
    """

    __slots__ = ("channel_id", "duration_seconds", "custom_message")

    def __init__(self, data: Dict[str, Any]):
        channel_id = data.get("channel_id")
        self.channel_id: Optional[int] = (
            int(channel_id) if channel_id else None
        )
        self.duration_seconds: Optional[int] = data.get("duration_seconds")
        self.custom_message: Optional[str] = data.get("custom_message")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        data = {}

        if self.channel_id:
            data["channel_id"] = str(self.channel_id)

        if self.duration_seconds is not None:
            data["duration_seconds"] = self.duration_seconds

        if self.custom_message:
            data["custom_message"] = self.custom_message

        return data


class AutoModAction:
    """
    An action to take when auto-mod rule triggers.

    Attributes:
        type: Type of action
        metadata: Additional action info
    """

    __slots__ = ("type", "metadata")

    def __init__(self, data: Dict[str, Any]):
        self.type: AutoModActionType = AutoModActionType(data.get("type", 1))

        metadata_data = data.get("metadata", {})
        self.metadata: AutoModActionMetadata = AutoModActionMetadata(
            metadata_data
        )

    @classmethod
    def block_message(
        cls, custom_message: Optional[str] = None
    ) -> AutoModAction:
        """Create a block message action"""
        data = {
            "type": AutoModActionType.BLOCK_MESSAGE,
            "metadata": {},
        }
        if custom_message:
            data["metadata"]["custom_message"] = custom_message
        return cls(data)

    @classmethod
    def send_alert(
        cls, channel_id: int, custom_message: Optional[str] = None
    ) -> AutoModAction:
        """Create a send alert action"""
        data = {
            "type": AutoModActionType.SEND_ALERT_MESSAGE,
            "metadata": {"channel_id": str(channel_id)},
        }
        if custom_message:
            data["metadata"]["custom_message"] = custom_message
        return cls(data)

    @classmethod
    def timeout(cls, duration_seconds: int) -> AutoModAction:
        """Create a timeout action"""
        if not 60 <= duration_seconds <= 2419200:  # 1 min to 28 days
            raise ValueError("Timeout must be 60-2419200 seconds")

        return cls(
            {
                "type": AutoModActionType.TIMEOUT,
                "metadata": {"duration_seconds": duration_seconds},
            }
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        data = {"type": int(self.type)}

        metadata_dict = self.metadata.to_dict()
        if metadata_dict:
            data["metadata"] = metadata_dict

        return data

    def __repr__(self) -> str:
        return f"<AutoModAction type={self.type.name}>"


class AutoModRule:
    """
    An auto-moderation rule.

    Attributes:
        id: Rule ID
        guild_id: Guild ID
        name: Rule name
        creator_id: User who created the rule
        event_type: Event type that triggers the rule
        trigger_type: Type of trigger
        trigger_metadata: Trigger metadata
        actions: Actions to take
        enabled: Whether rule is enabled
        exempt_roles: Roles exempt from rule
        exempt_channels: Channels exempt from rule

    Example:
        ```python
        # Create profanity filter
        rule = await guild.create_auto_mod_rule(
            name="Profanity Filter",
            trigger_type=AutoModTriggerType.KEYWORD_PRESET,
            presets=[AutoModKeywordPresetType.PROFANITY],
            actions=[
                AutoModAction.block_message("Please keep chat family-friendly!"),
                AutoModAction.send_alert(log_channel_id)
            ]
        )
        ```
    """

    __slots__ = (
        "id",
        "guild_id",
        "name",
        "creator_id",
        "event_type",
        "trigger_type",
        "trigger_metadata",
        "actions",
        "enabled",
        "exempt_roles",
        "exempt_channels",
        "_http",
    )

    def __init__(
        self, data: Dict[str, Any], http: Optional[HTTPClient] = None
    ):
        self.id: int = int(data.get("id", 0))
        self.guild_id: int = int(data.get("guild_id", 0))
        self.name: str = data.get("name", "")

        creator_id = data.get("creator_id")
        self.creator_id: int = int(creator_id) if creator_id else 0

        self.event_type: AutoModEventType = AutoModEventType(
            data.get("event_type", 1)
        )

        self.trigger_type: AutoModTriggerType = AutoModTriggerType(
            data.get("trigger_type", 1)
        )

        trigger_metadata = data.get("trigger_metadata", {})
        self.trigger_metadata: AutoModTriggerMetadata = AutoModTriggerMetadata(
            trigger_metadata
        )

        actions_data = data.get("actions", [])
        self.actions: List[AutoModAction] = [
            AutoModAction(action) for action in actions_data
        ]

        self.enabled: bool = data.get("enabled", True)

        exempt_roles = data.get("exempt_roles", [])
        self.exempt_roles: List[int] = [int(r) for r in exempt_roles]

        exempt_channels = data.get("exempt_channels", [])
        self.exempt_channels: List[int] = [int(c) for c in exempt_channels]

        self._http = http

    async def edit(
        self,
        *,
        name: Optional[str] = None,
        event_type: Optional[AutoModEventType] = None,
        trigger_metadata: Optional[AutoModTriggerMetadata] = None,
        actions: Optional[List[AutoModAction]] = None,
        enabled: Optional[bool] = None,
        exempt_roles: Optional[List[int]] = None,
        exempt_channels: Optional[List[int]] = None,
        reason: Optional[str] = None,
    ) -> AutoModRule:
        """
        Edit the auto-mod rule.

        Args:
            name: New name
            event_type: New event type
            trigger_metadata: New trigger metadata
            actions: New actions
            enabled: Whether to enable
            exempt_roles: New exempt roles
            exempt_channels: New exempt channels
            reason: Audit log reason

        Returns:
            Updated rule
        """
        if not self._http:
            raise ValueError("Cannot edit rule without HTTP client")

        payload = {}

        if name is not None:
            payload["name"] = name

        if event_type is not None:
            payload["event_type"] = int(event_type)

        if trigger_metadata is not None:
            payload["trigger_metadata"] = trigger_metadata.to_dict()

        if actions is not None:
            payload["actions"] = [a.to_dict() for a in actions]

        if enabled is not None:
            payload["enabled"] = enabled

        if exempt_roles is not None:
            payload["exempt_roles"] = [str(r) for r in exempt_roles]

        if exempt_channels is not None:
            payload["exempt_channels"] = [str(c) for c in exempt_channels]

        data = await self._http.request(
            "PATCH",
            f"/guilds/{self.guild_id}/auto-moderation/rules/{self.id}",
            json=payload,
            reason=reason,
        )

        return AutoModRule(data, self._http)

    async def delete(self, *, reason: Optional[str] = None) -> None:
        """
        Delete the auto-mod rule.

        Args:
            reason: Audit log reason
        """
        if not self._http:
            raise ValueError("Cannot delete rule without HTTP client")

        await self._http.request(
            "DELETE",
            f"/guilds/{self.guild_id}/auto-moderation/rules/{self.id}",
            reason=reason,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        return {
            "name": self.name,
            "event_type": int(self.event_type),
            "trigger_type": int(self.trigger_type),
            "trigger_metadata": self.trigger_metadata.to_dict(),
            "actions": [a.to_dict() for a in self.actions],
            "enabled": self.enabled,
            "exempt_roles": [str(r) for r in self.exempt_roles],
            "exempt_channels": [str(c) for c in self.exempt_channels],
        }

    def __repr__(self) -> str:
        return (
            f"<AutoModRule id={self.id} name={self.name!r} "
            f"enabled={self.enabled}>"
        )

"""
Guild Widget model.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class GuildWidget:
    """
    Represents a guild widget.

    Attributes:
        id: The guild ID.
        enabled: Whether the widget is enabled.
        channel_id: The widget channel ID.
    """

    __slots__ = ("id", "enabled", "channel_id", "_http")

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self.id: int = int(data["id"])
        self.enabled: bool = data.get("enabled", False)
        self.channel_id: Optional[int] = (
            int(data["channel_id"]) if data.get("channel_id") else None
        )
        self._http = http

    async def image_url(self, *, style: str = "shield") -> str:
        """Returns the widget image URL."""
        return await self._http.get_guild_widget_image(self.id, style=style)

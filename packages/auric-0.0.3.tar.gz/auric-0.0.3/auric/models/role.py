"""
Role model - represents guild roles
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntFlag
from typing import Any, Dict, Optional, TYPE_CHECKING

from ..core.types import Snowflake
from .color import Color

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class Permissions(IntFlag):
    """
    Discord permissions bit flags

    Complete list of all 65+ permissions
    """

    NONE = 0
    CREATE_INSTANT_INVITE = 1 << 0
    KICK_MEMBERS = 1 << 1
    BAN_MEMBERS = 1 << 2
    ADMINISTRATOR = 1 << 3
    MANAGE_CHANNELS = 1 << 4
    MANAGE_GUILD = 1 << 5
    ADD_REACTIONS = 1 << 6
    VIEW_AUDIT_LOG = 1 << 7
    PRIORITY_SPEAKER = 1 << 8
    STREAM = 1 << 9
    VIEW_CHANNEL = 1 << 10
    SEND_MESSAGES = 1 << 11
    SEND_TTS_MESSAGES = 1 << 12
    MANAGE_MESSAGES = 1 << 13
    EMBED_LINKS = 1 << 14
    ATTACH_FILES = 1 << 15
    READ_MESSAGE_HISTORY = 1 << 16
    MENTION_EVERYONE = 1 << 17
    USE_EXTERNAL_EMOJIS = 1 << 18
    VIEW_GUILD_INSIGHTS = 1 << 19
    CONNECT = 1 << 20
    SPEAK = 1 << 21
    MUTE_MEMBERS = 1 << 22
    DEAFEN_MEMBERS = 1 << 23
    MOVE_MEMBERS = 1 << 24
    USE_VAD = 1 << 25
    CHANGE_NICKNAME = 1 << 26
    MANAGE_NICKNAMES = 1 << 27
    MANAGE_ROLES = 1 << 28
    MANAGE_WEBHOOKS = 1 << 29
    MANAGE_GUILD_EXPRESSIONS = 1 << 30
    USE_APPLICATION_COMMANDS = 1 << 31
    REQUEST_TO_SPEAK = 1 << 32
    MANAGE_EVENTS = 1 << 33
    MANAGE_THREADS = 1 << 34
    CREATE_PUBLIC_THREADS = 1 << 35
    CREATE_PRIVATE_THREADS = 1 << 36
    USE_EXTERNAL_STICKERS = 1 << 37
    SEND_MESSAGES_IN_THREADS = 1 << 38
    USE_EMBEDDED_ACTIVITIES = 1 << 39
    MODERATE_MEMBERS = 1 << 40
    VIEW_CREATOR_MONETIZATION_ANALYTICS = 1 << 41
    USE_SOUNDBOARD = 1 << 42
    CREATE_GUILD_EXPRESSIONS = 1 << 43
    CREATE_EVENTS = 1 << 44
    USE_EXTERNAL_SOUNDS = 1 << 45
    SEND_VOICE_MESSAGES = 1 << 46
    SEND_POLLS = 1 << 49
    USE_EXTERNAL_APPS = 1 << 50

    @classmethod
    def none(cls) -> Permissions:
        """No permissions"""
        return cls(0)

    @classmethod
    def all(cls) -> Permissions:
        """All permissions"""
        return cls(
            cls.CREATE_INSTANT_INVITE
            | cls.KICK_MEMBERS
            | cls.BAN_MEMBERS
            | cls.ADMINISTRATOR
            | cls.MANAGE_CHANNELS
            | cls.MANAGE_GUILD
            | cls.ADD_REACTIONS
            | cls.VIEW_AUDIT_LOG
            | cls.PRIORITY_SPEAKER
            | cls.STREAM
            | cls.VIEW_CHANNEL
            | cls.SEND_MESSAGES
            | cls.SEND_TTS_MESSAGES
            | cls.MANAGE_MESSAGES
            | cls.EMBED_LINKS
            | cls.ATTACH_FILES
            | cls.READ_MESSAGE_HISTORY
            | cls.MENTION_EVERYONE
            | cls.USE_EXTERNAL_EMOJIS
            | cls.VIEW_GUILD_INSIGHTS
            | cls.CONNECT
            | cls.SPEAK
            | cls.MUTE_MEMBERS
            | cls.DEAFEN_MEMBERS
            | cls.MOVE_MEMBERS
            | cls.USE_VAD
            | cls.CHANGE_NICKNAME
            | cls.MANAGE_NICKNAMES
            | cls.MANAGE_ROLES
            | cls.MANAGE_WEBHOOKS
            | cls.MANAGE_GUILD_EXPRESSIONS
            | cls.USE_APPLICATION_COMMANDS
            | cls.REQUEST_TO_SPEAK
            | cls.MANAGE_EVENTS
            | cls.MANAGE_THREADS
            | cls.CREATE_PUBLIC_THREADS
            | cls.CREATE_PRIVATE_THREADS
            | cls.USE_EXTERNAL_STICKERS
            | cls.SEND_MESSAGES_IN_THREADS
            | cls.USE_EMBEDDED_ACTIVITIES
            | cls.MODERATE_MEMBERS
            | cls.VIEW_CREATOR_MONETIZATION_ANALYTICS
            | cls.USE_SOUNDBOARD
            | cls.CREATE_GUILD_EXPRESSIONS
            | cls.CREATE_EVENTS
            | cls.USE_EXTERNAL_SOUNDS
            | cls.SEND_VOICE_MESSAGES
            | cls.SEND_POLLS
            | cls.USE_EXTERNAL_APPS
        )

    @classmethod
    def general(cls) -> Permissions:
        """General permissions"""
        return cls(
            cls.VIEW_CHANNEL
            | cls.SEND_MESSAGES
            | cls.EMBED_LINKS
            | cls.ATTACH_FILES
            | cls.READ_MESSAGE_HISTORY
            | cls.ADD_REACTIONS
            | cls.USE_EXTERNAL_EMOJIS
            | cls.CONNECT
            | cls.SPEAK
            | cls.USE_VAD
            | cls.CHANGE_NICKNAME
        )

    @classmethod
    def text(cls) -> Permissions:
        """Text channel permissions"""
        return cls(
            cls.VIEW_CHANNEL
            | cls.SEND_MESSAGES
            | cls.EMBED_LINKS
            | cls.ATTACH_FILES
            | cls.READ_MESSAGE_HISTORY
            | cls.ADD_REACTIONS
            | cls.USE_EXTERNAL_EMOJIS
            | cls.MENTION_EVERYONE
            | cls.USE_APPLICATION_COMMANDS
        )

    @classmethod
    def voice(cls) -> Permissions:
        """Voice channel permissions"""
        return cls(
            cls.VIEW_CHANNEL
            | cls.CONNECT
            | cls.SPEAK
            | cls.USE_VAD
            | cls.STREAM
            | cls.USE_SOUNDBOARD
            | cls.USE_EXTERNAL_SOUNDS
            | cls.SEND_VOICE_MESSAGES
        )


class RoleFlags(IntFlag):
    """Role flags"""

    NONE = 0
    IN_PROMPT = 1 << 0  # Role can be selected in onboarding


@dataclass
class RoleColors:
    """Role gradient colors"""

    primary_color: int
    secondary_color: Optional[int] = None
    tertiary_color: Optional[int] = None


class RoleTags:
    """Role tags indicating special role types"""

    __slots__ = (
        "bot_id",
        "integration_id",
        "premium_subscriber",
        "subscription_listing_id",
        "available_for_purchase",
        "guild_connections",
    )

    def __init__(self, data: Dict[str, Any]):
        self.bot_id: Optional[Snowflake] = data.get("bot_id")
        self.integration_id: Optional[Snowflake] = data.get("integration_id")
        self.premium_subscriber: bool = "premium_subscriber" in data
        self.subscription_listing_id: Optional[Snowflake] = data.get("subscription_listing_id")
        self.available_for_purchase: bool = "available_for_purchase" in data
        self.guild_connections: bool = "guild_connections" in data

    @property
    def is_bot_managed(self) -> bool:
        """Whether this role is managed by a bot"""
        return self.bot_id is not None

    @property
    def is_integration(self) -> bool:
        """Whether this role is managed by an integration"""
        return self.integration_id is not None

    @property
    def is_premium_subscriber(self) -> bool:
        """Whether this is the premium subscriber (booster) role"""
        return self.premium_subscriber


class Role:
    """
    Represents a guild role

    Attributes:
        id: Role ID
        name: Role name
        color: Role color (single color or primary)
        colors: Role gradient colors
        hoist: Whether role is hoisted
        icon: Icon hash
        unicode_emoji: Unicode emoji for role
        position: Role position
        permissions: Role permissions
        managed: Whether role is managed by integration
        mentionable: Whether role is mentionable
        flags: Role flags
        tags: Role tags
    """

    __slots__ = (
        "id",
        "name",
        "color",
        "colors",
        "hoist",
        "icon",
        "unicode_emoji",
        "position",
        "permissions",
        "managed",
        "mentionable",
        "flags",
        "tags",
        "guild_id",
        "_http",
    )

    def __init__(
        self, *, data: Dict[str, Any], guild_id: Snowflake, http: Optional[HTTPClient] = None
    ):
        self.guild_id = guild_id
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update role from API data"""
        self.id: Snowflake = int(data["id"])
        self.name: str = data["name"]

        # Color
        color_value = data.get("color", 0)
        self.color: Color = Color(color_value) if color_value else Color(0)

        # Gradient colors
        colors_data = data.get("colors", {})
        self.colors = RoleColors(
            primary_color=colors_data.get("primary_color", color_value),
            secondary_color=colors_data.get("secondary_color"),
            tertiary_color=colors_data.get("tertiary_color"),
        )

        self.hoist: bool = data.get("hoist", False)
        self.icon: Optional[str] = data.get("icon")
        self.unicode_emoji: Optional[str] = data.get("unicode_emoji")
        self.position: int = data.get("position", 0)
        self.permissions: Permissions = Permissions(int(data.get("permissions", 0)))
        self.managed: bool = data.get("managed", False)
        self.mentionable: bool = data.get("mentionable", False)
        self.flags: RoleFlags = RoleFlags(data.get("flags", 0))

        # Tags
        tags_data = data.get("tags")
        self.tags: Optional[RoleTags] = RoleTags(tags_data) if tags_data else None

    def __repr__(self) -> str:
        return f"<Role id={self.id} name={self.name!r}>"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Role) and self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    def __lt__(self, other: Role) -> bool:
        """Roles are compared by position"""
        if not isinstance(other, Role):
            return NotImplemented

        if self.position < other.position:
            return True
        if self.position == other.position:
            return self.id < other.id
        return False

    @property
    def mention(self) -> str:
        """Returns a string that mentions the role"""
        return f"<@&{self.id}>"

    @property
    def icon_url(self) -> Optional[str]:
        """Returns the role's icon URL"""
        if self.icon is None:
            return None

        from ..core.types import CDN_URL

        ext = "gif" if self.icon.startswith("a_") else "png"
        return f"{CDN_URL}/role-icons/{self.id}/{self.icon}.{ext}"

    @property
    def is_default(self) -> bool:
        """Whether this is the @everyone role"""
        return self.id == self.guild_id

    @property
    def is_bot_managed(self) -> bool:
        """Whether this role is managed by a bot"""
        return self.tags is not None and self.tags.is_bot_managed

    @property
    def is_integration(self) -> bool:
        """Whether this role is managed by an integration"""
        return self.tags is not None and self.tags.is_integration

    @property
    def is_premium_subscriber(self) -> bool:
        """Whether this is the premium subscriber (booster) role"""
        return self.tags is not None and self.tags.is_premium_subscriber

    @property
    def is_assignable(self) -> bool:
        """Whether this role can be assigned/removed by the bot"""
        return not self.managed and not self.is_default

    @property
    def has_gradient(self) -> bool:
        """Whether this role has a gradient color"""
        return self.colors.secondary_color is not None

    @property
    def is_holographic(self) -> bool:
        """Whether this role has a holographic gradient"""
        return self.colors.tertiary_color is not None

    def to_dict(self) -> Dict[str, Any]:
        """Convert role to dictionary"""
        data = {
            "id": str(self.id),
            "name": self.name,
            "color": self.color.value,
            "hoist": self.hoist,
            "position": self.position,
            "permissions": str(int(self.permissions)),
            "managed": self.managed,
            "mentionable": self.mentionable,
        }

        if self.icon:
            data["icon"] = self.icon

        if self.unicode_emoji:
            data["unicode_emoji"] = self.unicode_emoji

        if self.has_gradient:
            data["colors"] = {
                "primary_color": self.colors.primary_color,
                "secondary_color": self.colors.secondary_color,
                "tertiary_color": self.colors.tertiary_color,
            }

        return data

    async def edit(
        self,
        *,
        name: Optional[str] = None,
        permissions: Optional[Permissions] = None,
        color: Optional[Color] = None,
        hoist: Optional[bool] = None,
        icon: Optional[bytes] = None,
        unicode_emoji: Optional[str] = None,
        mentionable: Optional[bool] = None,
        reason: Optional[str] = None,
    ) -> Role:
        """
        Edit the role

        Args:
            name: New role name
            permissions: New permissions
            color: New color
            hoist: Whether to hoist
            icon: New icon image bytes
            unicode_emoji: New unicode emoji
            mentionable: Whether mentionable
            reason: Reason for audit log
        """
        from ..core.http import Route

        payload = {}

        if name is not None:
            payload["name"] = name

        if permissions is not None:
            payload["permissions"] = str(int(permissions))

        if color is not None:
            payload["color"] = color.value

        if hoist is not None:
            payload["hoist"] = hoist

        if icon is not None:
            import base64

            payload["icon"] = f"data:image/png;base64,{base64.b64encode(icon).decode()}"

        if unicode_emoji is not None:
            payload["unicode_emoji"] = unicode_emoji

        if mentionable is not None:
            payload["mentionable"] = mentionable

        data = await self._http.request(
            Route(
                "PATCH",
                "/guilds/{guild_id}/roles/{role_id}",
                guild_id=self.guild_id,
                role_id=self.id,
            ),
            json=payload,
            reason=reason,
        )

        self._update(data)
        return self

    async def delete(self, *, reason: Optional[str] = None) -> None:
        """Delete the role"""
        from ..core.http import Route

        await self._http.request(
            Route(
                "DELETE",
                "/guilds/{guild_id}/roles/{role_id}",
                guild_id=self.guild_id,
                role_id=self.id,
            ),
            reason=reason,
        )


class PermissionOverwrite:
    """
    Permission overwrite for a channel

    Allows you to set channel-specific permissions for roles or members

    Attributes:
        id: Role or user ID
        type: 0 for role, 1 for member
        allow: Permissions explicitly allowed
        deny: Permissions explicitly denied
    """

    __slots__ = ("id", "type", "allow", "deny")

    def __init__(
        self,
        id: Snowflake,
        *,
        type: int = 0,
        allow: Permissions = Permissions.NONE,
        deny: Permissions = Permissions.NONE,
    ):
        """
        Create a permission overwrite

        Args:
            id: Role or user ID
            type: 0 for role, 1 for member
            allow: Permissions to allow
            deny: Permissions to deny
        """
        self.id = id
        self.type = type
        self.allow = allow
        self.deny = deny

    @classmethod
    def from_data(cls, data: Dict[str, Any]) -> PermissionOverwrite:
        """Create from API data"""
        return cls(
            id=int(data["id"]),
            type=int(data["type"]),
            allow=Permissions(int(data.get("allow", 0))),
            deny=Permissions(int(data.get("deny", 0))),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        return {
            "id": str(self.id),
            "type": self.type,
            "allow": str(int(self.allow)),
            "deny": str(int(self.deny)),
        }

    @classmethod
    def for_role(
        cls, role, *, allow: Permissions = Permissions.NONE, deny: Permissions = Permissions.NONE
    ) -> PermissionOverwrite:
        """
        Create overwrite for a role

        Args:
            role: Role object or role ID
            allow: Permissions to allow
            deny: Permissions to deny
        """
        role_id = role.id if hasattr(role, "id") else role
        return cls(role_id, type=0, allow=allow, deny=deny)

    @classmethod
    def for_member(
        cls, member, *, allow: Permissions = Permissions.NONE, deny: Permissions = Permissions.NONE
    ) -> PermissionOverwrite:
        """
        Create overwrite for a member

        Args:
            member: Member/User object or user ID
            allow: Permissions to allow
            deny: Permissions to deny
        """
        user_id = member.id if hasattr(member, "id") else member
        return cls(user_id, type=1, allow=allow, deny=deny)

    def is_empty(self) -> bool:
        """Check if overwrite has no permissions set"""
        return self.allow == Permissions.NONE and self.deny == Permissions.NONE

    def update(
        self, *, allow: Optional[Permissions] = None, deny: Optional[Permissions] = None
    ) -> PermissionOverwrite:
        """
        Update permissions

        Args:
            allow: New allow permissions
            deny: New deny permissions

        Returns:
            Self for chaining
        """
        if allow is not None:
            self.allow = allow
        if deny is not None:
            self.deny = deny
        return self

    def __repr__(self) -> str:
        return f"<PermissionOverwrite id={self.id} type={self.type} allow={self.allow} deny={self.deny}>"

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, PermissionOverwrite)
            and self.id == other.id
            and self.type == other.type
            and self.allow == other.allow
            and self.deny == other.deny
        )

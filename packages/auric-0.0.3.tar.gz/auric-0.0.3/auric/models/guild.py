"""
Guild model - represents Discord servers
"""

from __future__ import annotations

from enum import IntEnum
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from ..core.types import Snowflake

if TYPE_CHECKING:
    from ..core.http import HTTPClient

    from datetime import datetime
    from ..utils.snowflake import snowflake_time
    from .guild_onboarding import GuildOnboarding
    from ..managers.application_commands import ApplicationCommandManager
    from ..managers.mfa import MFAManager
    from .vanity_url import VanityURL
    from ..managers.prune import PruneManager
    from .welcome_screen import WelcomeScreen
    from ..managers.guild_template import GuildTemplateManager
    from ..managers.voice_region import VoiceRegionManager
    from ..managers.thread import ThreadManager
    from ..managers.sticker import StickerManager
    from ..managers.ban import BanManager
    from ..managers.channel import GuildChannelManager
    from ..managers.role import RoleManager
    from ..managers.member_manager import MemberManager
    from ..managers.emoji import EmojiManager
    from ..managers.webhook import WebhookManager
    from ..managers.integration import IntegrationManager
    from ..managers.invite import InviteManager
    from ..managers.audit_log import AuditLogManager
    from ..managers.stage_instance import StageInstanceManager
    from ..managers.scheduled_event import ScheduledEventManager
    from ..managers.auto_moderation import AutoModManager
    from ..managers.soundboard import SoundboardManager


class VerificationLevel(IntEnum):
    """Guild verification level"""

    NONE = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    VERY_HIGH = 4


class NSFWLevel(IntEnum):
    """Guild NSFW level"""

    DEFAULT = 0
    EXPLICIT = 1
    SAFE = 2
    AGE_RESTRICTED = 3


class PremiumTier(IntEnum):
    """Guild premium tier (boost level)"""

    NONE = 0
    TIER_1 = 1
    TIER_2 = 2
    TIER_3 = 3


class PartialGuild:
    """
    Represents a partial guild object (used in invites and other contexts)

    Attributes:
        id: Guild ID
        name: Guild name
        icon: Icon hash
        splash: Splash hash
        banner: Banner hash
        description: Guild description
        features: Guild features
        verification_level: Verification level
        vanity_url_code: Vanity URL code
    """

    __slots__ = (
        "id",
        "name",
        "icon",
        "splash",
        "banner",
        "description",
        "features",
        "verification_level",
        "vanity_url_code",
        "nsfw_level",
        "premium_subscription_count",
        "nsfw",
    )

    def __init__(self, *, data: Dict[str, Any]):
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update partial guild from API data"""
        self.id: Snowflake = int(data["id"])
        self.name: str = data.get("name", "Unknown")
        self.icon: Optional[str] = data.get("icon")
        self.splash: Optional[str] = data.get("splash")
        self.banner: Optional[str] = data.get("banner")
        self.description: Optional[str] = data.get("description")
        self.features: List[str] = data.get("features", [])
        self.verification_level: Optional[int] = data.get("verification_level")
        self.vanity_url_code: Optional[str] = data.get("vanity_url_code")
        self.nsfw_level: Optional[int] = data.get("nsfw_level")
        self.nsfw: Optional[bool] = data.get("nsfw")
        self.premium_subscription_count: Optional[int] = data.get("premium_subscription_count")

    def __repr__(self) -> str:
        return f"<PartialGuild id={self.id} name='{self.name}'>"

    def __str__(self) -> str:
        return self.name


class GuildPreview:
    """
    Represents a guild preview.

    Attributes:
        id: The ID of the guild.
        name: The name of the guild.
        icon: The icon hash of the guild.
        splash: The splash hash of the guild.
        discovery_splash: The discovery splash hash of the guild.
        emojis: A list of emojis in the guild.
        features: A list of features of the guild.
        approximate_member_count: The approximate number of members in the guild.
        approximate_presence_count: The approximate number of online members in the guild.
        description: The description of the guild.
        stickers: A list of stickers in the guild.
    """

    __slots__ = (
        "id",
        "name",
        "icon",
        "splash",
        "discovery_splash",
        "emojis",
        "features",
        "approximate_member_count",
        "approximate_presence_count",
        "description",
        "stickers",
    )

    def __init__(self, *, data: Dict[str, Any]):
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        self.id: Snowflake = int(data["id"])
        self.name: str = data["name"]
        self.icon: Optional[str] = data.get("icon")
        self.splash: Optional[str] = data.get("splash")
        self.discovery_splash: Optional[str] = data.get("discovery_splash")
        self.emojis: List[Dict[str, Any]] = data["emojis"]
        self.features: List[str] = data["features"]
        self.approximate_member_count: int = data["approximate_member_count"]
        self.approximate_presence_count: int = data["approximate_presence_count"]
        self.description: Optional[str] = data.get("description")
        self.stickers: List[Dict[str, Any]] = data["stickers"]


class Guild:
    """
    Represents a Discord guild (server)

    Attributes:
        id: Guild ID
        name: Guild name
        icon: Icon hash
        owner_id: Owner's user ID
        member_count: Approximate member count
        verification_level: Verification level required
        ... (100+ attributes from Discord API)
    """

    __slots__ = (
        "id",
        "name",
        "icon",
        "icon_hash",
        "splash",
        "discovery_splash",
        "owner_id",
        "afk_channel_id",
        "afk_timeout",
        "widget_enabled",
        "widget_channel_id",
        "verification_level",
        "default_message_notifications",
        "explicit_content_filter",
        "roles",
        "emojis",
        "features",
        "mfa_level",
        "application_id",
        "system_channel_id",
        "system_channel_flags",
        "rules_channel_id",
        "max_presences",
        "max_members",
        "vanity_url_code",
        "description",
        "banner",
        "premium_tier",
        "premium_subscription_count",
        "preferred_locale",
        "public_updates_channel_id",
        "max_video_channel_users",
        "max_stage_video_channel_users",
        "approximate_member_count",
        "member_count",
        "approximate_presence_count",
        "nsfw_level",
        "stickers",
        "premium_progress_bar_enabled",
        "safety_alerts_channel_id",
        "_http",
        "_soundboard",
        "_auto_moderation",
        "_scheduled_events",
        "_stage_instances",
        "_audit_logs",
        "_widget",
        "_onboarding",
        "_invites",
        "_integrations",
        "_webhooks",
        "_emojis",
        "_members",
        "_roles",
        "_channels",
        "_bans",
        "_stickers",
        "_threads",
        "_voice_regions",
        "_templates",
        "_welcome_screen",
        "_preview",
        "_prune",
        "_vanity_url",
        "_mfa",
        "_commands",
        "_onboarding",
        "_widget",
        "created_at",
    )

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update guild from API data"""
        self.id: Snowflake = int(data["id"])
        self.name: str = data.get("name", "Unknown")
        self.icon: Optional[str] = data.get("icon")
        self.icon_hash: Optional[str] = data.get("icon_hash")
        self.splash: Optional[str] = data.get("splash")
        self.discovery_splash: Optional[str] = data.get("discovery_splash")
        self.owner_id: Snowflake = int(data.get("owner_id", 0))
        self.afk_channel_id: Optional[Snowflake] = data.get("afk_channel_id")
        self.afk_timeout: int = data.get("afk_timeout", 0)
        self.verification_level: VerificationLevel = VerificationLevel(
            data.get("verification_level", 0)
        )
        self.nsfw_level: NSFWLevel = NSFWLevel(data.get("nsfw_level", 0))
        self.premium_tier: PremiumTier = PremiumTier(data.get("premium_tier", 0))
        self.member_count: int = data.get("member_count", data.get("approximate_member_count", 0))
        self.approximate_member_count: int = data.get("approximate_member_count", 0)
        self.premium_subscription_count: int = data.get("premium_subscription_count", 0)
        self.description: Optional[str] = data.get("description")

        # Store raw roles, emojis, stickers for now
        self.roles = data.get("roles", [])
        self.emojis = data.get("emojis", [])
        self.stickers = data.get("stickers", [])
        self.features: List[str] = data.get("features", [])

        # Created timestamp from snowflake
        self.created_at: datetime = snowflake_time(self.id)

    @property
    def onboarding(self) -> "GuildOnboarding":
        """The guild's onboarding configuration"""
        if not hasattr(self, "_onboarding"):
            from .guild_feature import GuildOnboarding

            self._onboarding = GuildOnboarding(data=self._http.get_guild_onboarding(self.id), http=self._http)
        return self._onboarding

    @property
    def commands(self) -> "ApplicationCommandManager":
        """Manager for guild application commands"""
        if not hasattr(self, "_commands"):
            from ..managers.commands import ApplicationCommandManager

            self._commands = ApplicationCommandManager(self)
        return self._commands

    @property
    def mfa(self) -> "MFAManager":
        """Manager for guild MFA"""
        if not hasattr(self, "_mfa"):
            from ..managers.mfa import MFAManager

            self._mfa = MFAManager(self)
        return self._mfa

    @property
    def vanity_url(self) -> "VanityURL":
        """The guild's vanity URL"""
        if not hasattr(self, "_vanity_url"):
            from .guild_feature import VanityURL

            self._vanity_url = VanityURL(data=self._http.get_vanity_url(self.id))
        return self._vanity_url

    @property
    def prune(self) -> "PruneManager":
        """Manager for guild pruning"""
        if not hasattr(self, "_prune"):
            from ..managers.prune import PruneManager

            self._prune = PruneManager(self)
        return self._prune

    @property
    def preview(self) -> "GuildPreview":
        """The guild's preview"""
        if not hasattr(self, "_preview"):
            from .guild import GuildPreview

            self._preview = GuildPreview(data=self._http.get_guild_preview(self.id))
        return self._preview

    @property
    def welcome_screen(self) -> "WelcomeScreen":
        """The guild's welcome screen"""
        if not hasattr(self, "_welcome_screen"):
            from .guild_feature import WelcomeScreen

            self._welcome_screen = WelcomeScreen(data=self._http.get_guild_welcome_screen(self.id), http=self._http)
        return self._welcome_screen

    @property
    def voice_regions(self) -> "VoiceRegionManager":
        """Manager for guild voice regions"""
        if not hasattr(self, "_voice_regions"):
            from ..managers.voice import VoiceRegionManager

            self._voice_regions = VoiceRegionManager(self)
        return self._voice_regions

    @property
    def threads(self) -> "ThreadManager":
        """Manager for guild threads"""
        if not hasattr(self, "_threads"):
            from ..managers.thread import ThreadManager

            self._threads = ThreadManager(self)
        return self._threads

    @property
    def stickers(self) -> "StickerManager":
        """Manager for guild stickers"""
        if not hasattr(self, "_stickers"):
            from ..managers.sticker import StickerManager

            self._stickers = StickerManager(self)
        return self._stickers

    @property
    def bans(self) -> "BanManager":
        """Manager for guild bans"""
        if not hasattr(self, "_bans"):
            from ..managers.ban import BanManager

            self._bans = BanManager(self)
        return self._bans

    @property
    def channels(self) -> "GuildChannelManager":
        """Manager for guild channels"""
        if not hasattr(self, "_channels"):
            from ..managers.channel import GuildChannelManager

            self._channels = GuildChannelManager(self)
        return self._channels

    @property
    def roles(self) -> "RoleManager":
        """Manager for guild roles"""
        if not hasattr(self, "_roles"):
            from ..managers.role import RoleManager

            self._roles = RoleManager(self)
        return self._roles

    @property
    def members(self) -> "MemberManager":
        """Manager for guild members"""
        if not hasattr(self, "_members"):
            from ..managers.member_manager import MemberManager

            self._members = MemberManager(self)
        return self._members

    @property
    def emojis(self) -> "EmojiManager":
        """Manager for guild emojis"""
        if not hasattr(self, "_emojis"):
            from ..managers.emoji import EmojiManager

            self._emojis = EmojiManager(self)
        return self._emojis

    @property
    def webhooks(self) -> "WebhookManager":
        """Manager for guild webhooks"""
        if not hasattr(self, "_webhooks"):
            from ..managers.webhook import WebhookManager

            self._webhooks = WebhookManager(self)
        return self._webhooks

    @property
    def integrations(self) -> "IntegrationManager":
        """Manager for guild integrations"""
        if not hasattr(self, "_integrations"):
            from ..managers.integration import IntegrationManager

            self._integrations = IntegrationManager(self)
        return self._integrations

    @property
    def invites(self) -> "InviteManager":
        """Manager for guild invites"""
        if not hasattr(self, "_invites"):
            from ..managers.invite import InviteManager

            self._invites = InviteManager(self)
        return self._invites

    @property
    def audit_logs(self) -> "AuditLogManager":
        """Manager for guild audit logs"""
        if not hasattr(self, "_audit_logs"):
            from ..managers.audit_log import AuditLogManager

            self._audit_logs = AuditLogManager(self)
        return self._audit_logs

    @property
    def stage_instances(self) -> "StageInstanceManager":
        """Manager for guild stage instances"""
        if not hasattr(self, "_stage_instances"):
            from ..managers.stage_instance import StageInstanceManager

            self._stage_instances = StageInstanceManager(self)
        return self._stage_instances

    @property
    def scheduled_events(self) -> "ScheduledEventManager":
        """Manager for guild scheduled events"""
        if not hasattr(self, "_scheduled_events"):
            from ..managers.scheduled_event import ScheduledEventManager

            self._scheduled_events = ScheduledEventManager(self)
        return self._scheduled_events

    @property
    def auto_moderation(self) -> "AutoModManager":
        """Manager for guild auto-moderation rules"""
        if not hasattr(self, "_auto_moderation"):
            from ..managers.auto_moderation import AutoModManager

            self._auto_moderation = AutoModManager(self)
        return self._auto_moderation

    @property
    def soundboard(self) -> "SoundboardManager":
        """Manager for guild soundboard sounds"""
        if not hasattr(self, "_soundboard"):
            from ..managers.soundboard import SoundboardManager

            self._soundboard = SoundboardManager(self)
        return self._soundboard

    @property
    def templates(self) -> "GuildTemplateManager":
        """Manager for guild templates"""
        from ..managers.guild_template import GuildTemplateManager

        return GuildTemplateManager(self.id, self._http.client)

    def __repr__(self) -> str:
        return f"<Guild id={self.id} name={self.name!r}>"

    def __str__(self) -> str:
        return self.name

    @property
    def icon_url(self) -> Optional[str]:
        """Returns the guild's icon URL"""
        if self.icon is None:
            return None

        from ..core.types import CDN_URL

        ext = "gif" if self.icon.startswith("a_") else "png"
        return f"{CDN_URL}/icons/{self.id}/{self.icon}.{ext}"

    async def fetch_member(self, user_id: Snowflake):
        """
        Fetch a guild member by user ID

        Args:
            user_id: The user ID to fetch

        Returns:
            Member: The guild member object
        """
        from ..core.http import Route
        from .member import Member

        data = await self._http.request(
            Route("GET", "/guilds/{guild_id}/members/{user_id}", guild_id=self.id, user_id=user_id)
        )

        return Member(data=data, guild_id=self.id, http=self._http)

    async def fetch_members(self, *, limit: int = 1, after: Optional[Snowflake] = None):
        """
        Fetch guild members

        Args:
            limit: Max members to return (1-1000)
            after: Get members after this user ID

        Returns:
            list[Member]: List of guild members

        Note:
            Requires GUILD_MEMBERS privileged intent
        """
        from ..core.http import Route
        from .member import Member

        params = {"limit": min(max(limit, 1), 1000)}
        if after:
            params["after"] = str(after)

        data = await self._http.request(
            Route("GET", "/guilds/{guild_id}/members", guild_id=self.id), params=params
        )

        return [Member(data=m, guild_id=self.id, http=self._http) for m in data]

    async def search_members(self, query: str, *, limit: int = 1):
        """
        Search guild members by username or nickname

        Args:
            query: Username/nickname to search for
            limit: Max members to return (1-1000)

        Returns:
            list[Member]: List of matching members
        """
        from ..core.http import Route
        from .member import Member

        params = {"query": query, "limit": min(max(limit, 1), 1000)}

        data = await self._http.request(
            Route("GET", "/guilds/{guild_id}/members/search", guild_id=self.id), params=params
        )

        return [Member(data=m, guild_id=self.id, http=self._http) for m in data]

    async def kick(self, user_id: Snowflake, *, reason: Optional[str] = None) -> None:
        """
        Kick a member from the guild

        Args:
            user_id: ID of user to kick
            reason: Reason for audit log

        Requires:
            KICK_MEMBERS permission
        """
        from ..core.http import Route

        await self._http.request(
            Route(
                "DELETE", "/guilds/{guild_id}/members/{user_id}", guild_id=self.id, user_id=user_id
            ),
            reason=reason,
        )

    async def ban(
        self, user_id: Snowflake, *, delete_message_seconds: int = 0, reason: Optional[str] = None
    ) -> None:
        """
        Ban a member from the guild

        Args:
            user_id: ID of user to ban
            delete_message_seconds: Delete messages from last X seconds (0-604800)
            reason: Reason for audit log

        Requires:
            BAN_MEMBERS permission
        """
        from ..core.http import Route

        payload = {}
        if delete_message_seconds:
            payload["delete_message_seconds"] = delete_message_seconds

        await self._http.request(
            Route("PUT", "/guilds/{guild_id}/bans/{user_id}", guild_id=self.id, user_id=user_id),
            json=payload if payload else None,
            reason=reason,
        )

    async def unban(self, user_id: Snowflake, *, reason: Optional[str] = None) -> None:
        """
        Unban a user from the guild

        Args:
            user_id: ID of user to unban
            reason: Reason for audit log

        Requires:
            BAN_MEMBERS permission
        """
        from ..core.http import Route

        await self._http.request(
            Route("DELETE", "/guilds/{guild_id}/bans/{user_id}", guild_id=self.id, user_id=user_id),
            reason=reason,
        )

    async def fetch_channels(self):
        """
        Fetch all channels in this guild

        Returns:
            list[Channel]: List of guild channels (excludes threads)
        """
        from ..core.http import Route
        from .channel import Channel

        data = await self._http.request(
            Route("GET", "/guilds/{guild_id}/channels", guild_id=self.id)
        )

        return [Channel(data=c, http=self._http) for c in data]

    async def fetch_bans(
        self,
        *,
        limit: int = 1000,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
    ):
        """
        Fetch guild bans

        Args:
            limit: Max bans to return (1-1000)
            before: Get bans before this user ID
            after: Get bans after this user ID

        Returns:
            list[dict]: List of ban objects

        Requires:
            BAN_MEMBERS permission
        """
        from ..core.http import Route

        params = {"limit": min(max(limit, 1), 1000)}
        if before:
            params["before"] = str(before)
        if after:
            params["after"] = str(after)

        data = await self._http.request(
            Route("GET", "/guilds/{guild_id}/bans", guild_id=self.id), params=params
        )

        return data

    async def fetch_webhooks(self):
        """
        Get all webhooks for this guild

        Returns:
            List of Webhook objects

        Requires:
            MANAGE_WEBHOOKS permission
        """
        from ..core.http import Route
        from .webhook import Webhook

        data = await self._http.request(
            Route("GET", "/guilds/{guild_id}/webhooks", guild_id=self.id)
        )

        return [Webhook(data=wh, http=self._http) for wh in data]

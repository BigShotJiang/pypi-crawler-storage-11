"""
Embed model for rich message embeds
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from .color import Color


@dataclass
class EmbedFooter:
    """Embed footer"""

    text: str
    icon_url: Optional[str] = None
    proxy_icon_url: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        data = {"text": self.text}
        if self.icon_url:
            data["icon_url"] = self.icon_url
        return data


@dataclass
class EmbedImage:
    """Embed image"""

    url: str
    proxy_url: Optional[str] = None
    height: Optional[int] = None
    width: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {"url": self.url}


@dataclass
class EmbedThumbnail:
    """Embed thumbnail"""

    url: str
    proxy_url: Optional[str] = None
    height: Optional[int] = None
    width: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {"url": self.url}


@dataclass
class EmbedVideo:
    """Embed video"""

    url: str
    proxy_url: Optional[str] = None
    height: Optional[int] = None
    width: Optional[int] = None


@dataclass
class EmbedProvider:
    """Embed provider"""

    name: Optional[str] = None
    url: Optional[str] = None


@dataclass
class EmbedAuthor:
    """Embed author"""

    name: str
    url: Optional[str] = None
    icon_url: Optional[str] = None
    proxy_icon_url: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        data = {"name": self.name}
        if self.url:
            data["url"] = self.url
        if self.icon_url:
            data["icon_url"] = self.icon_url
        return data


@dataclass
class EmbedField:
    """Embed field"""

    name: str
    value: str
    inline: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "value": self.value,
            "inline": self.inline,
        }


class Embed:
    """
    Discord Embed for rich messages

    Embeds allow you to display rich, structured content in messages.
    """

    __slots__ = (
        "title",
        "description",
        "url",
        "timestamp",
        "color",
        "footer",
        "image",
        "thumbnail",
        "video",
        "provider",
        "author",
        "fields",
    )

    def __init__(
        self,
        *,
        title: Optional[str] = None,
        description: Optional[str] = None,
        url: Optional[str] = None,
        timestamp: Optional[datetime] = None,
        color: Optional[Union[int, Color]] = None,
        colour: Optional[Union[int, Color]] = None,  # UK spelling
    ):
        self.title = title
        self.description = description
        self.url = url
        self.timestamp = timestamp

        # Handle color/colour
        if colour is not None and color is not None:
            raise TypeError("Cannot specify both color and colour")

        final_color = colour or color
        if isinstance(final_color, int):
            self.color = Color(final_color)
        elif isinstance(final_color, Color):
            self.color = final_color
        else:
            self.color = None

        # Components
        self.footer: Optional[EmbedFooter] = None
        self.image: Optional[EmbedImage] = None
        self.thumbnail: Optional[EmbedThumbnail] = None
        self.video: Optional[EmbedVideo] = None
        self.provider: Optional[EmbedProvider] = None
        self.author: Optional[EmbedAuthor] = None
        self.fields: List[EmbedField] = []

    def __repr__(self) -> str:
        return f"<Embed title={self.title!r}>"

    def __len__(self) -> int:
        """Get total character count"""
        total = len(self.title or "")
        total += len(self.description or "")

        for embed_field in self.fields:
            total += len(field.name) + len(field.value)

        if self.footer:
            total += len(self.footer.text)

        if self.author:
            total += len(self.author.name)

        return total

    def set_footer(self, *, text: str, icon_url: Optional[str] = None) -> Embed:
        """Set embed footer"""
        self.footer = EmbedFooter(text=text, icon_url=icon_url)
        return self

    def set_image(self, *, url: str) -> Embed:
        """Set embed image"""
        self.image = EmbedImage(url=url)
        return self

    def set_thumbnail(self, *, url: str) -> Embed:
        """Set embed thumbnail"""
        self.thumbnail = EmbedThumbnail(url=url)
        return self

    def set_author(
        self, *, name: str, url: Optional[str] = None, icon_url: Optional[str] = None
    ) -> Embed:
        """Set embed author"""
        self.author = EmbedAuthor(name=name, url=url, icon_url=icon_url)
        return self

    def add_field(self, *, name: str, value: str, inline: bool = False) -> Embed:
        """Add a field to the embed"""
        self.fields.append(EmbedField(name=name, value=value, inline=inline))
        return self

    def insert_field_at(self, index: int, *, name: str, value: str, inline: bool = False) -> Embed:
        """Insert a field at a specific index"""
        self.fields.insert(index, EmbedField(name=name, value=value, inline=inline))
        return self

    def remove_field(self, index: int) -> None:
        """Remove a field by index"""
        del self.fields[index]

    def set_field_at(self, index: int, *, name: str, value: str, inline: bool = False) -> Embed:
        """Set a field at a specific index"""
        self.fields[index] = EmbedField(name=name, value=value, inline=inline)
        return self

    def clear_fields(self) -> None:
        """Remove all fields"""
        self.fields.clear()

    def to_dict(self) -> Dict[str, Any]:
        """Convert embed to dictionary for API"""
        data: Dict[str, Any] = {}

        if self.title:
            data["title"] = self.title

        if self.description:
            data["description"] = self.description

        if self.url:
            data["url"] = self.url

        if self.timestamp:
            data["timestamp"] = self.timestamp.isoformat()

        if self.color:
            data["color"] = self.color.value

        if self.footer:
            data["footer"] = self.footer.to_dict()

        if self.image:
            data["image"] = self.image.to_dict()

        if self.thumbnail:
            data["thumbnail"] = self.thumbnail.to_dict()

        if self.author:
            data["author"] = self.author.to_dict()

        if self.fields:
            data["fields"] = [field.to_dict() for field in self.fields]

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Embed:
        """Create embed from API data"""
        embed = cls(
            title=data.get("title"),
            description=data.get("description"),
            url=data.get("url"),
            color=data.get("color"),
        )

        if "timestamp" in data:
            embed.timestamp = datetime.fromisoformat(data["timestamp"].rstrip("Z"))

        if "footer" in data:
            footer_data = data["footer"]
            embed.footer = EmbedFooter(
                text=footer_data["text"],
                icon_url=footer_data.get("icon_url"),
                proxy_icon_url=footer_data.get("proxy_icon_url"),
            )

        if "image" in data:
            image_data = data["image"]
            embed.image = EmbedImage(
                url=image_data["url"],
                proxy_url=image_data.get("proxy_url"),
                height=image_data.get("height"),
                width=image_data.get("width"),
            )

        if "thumbnail" in data:
            thumb_data = data["thumbnail"]
            embed.thumbnail = EmbedThumbnail(
                url=thumb_data["url"],
                proxy_url=thumb_data.get("proxy_url"),
                height=thumb_data.get("height"),
                width=thumb_data.get("width"),
            )

        if "author" in data:
            author_data = data["author"]
            embed.author = EmbedAuthor(
                name=author_data["name"],
                url=author_data.get("url"),
                icon_url=author_data.get("icon_url"),
                proxy_icon_url=author_data.get("proxy_icon_url"),
            )

        if "fields" in data:
            for field_data in data["fields"]:
                embed.fields.append(
                    EmbedField(
                        name=field_data["name"],
                        value=field_data["value"],
                        inline=field_data.get("inline", False),
                    )
                )

        return embed

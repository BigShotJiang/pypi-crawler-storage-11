"""
Presence and Activity models
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Dict, List, Optional


from datetime import datetime
from enum import IntEnum

from ..core.types import Snowflake

if TYPE_CHECKING:
    pass


class ActivityType(IntEnum):
    """Activity types"""

    GAME = 0
    STREAMING = 1
    LISTENING = 2
    WATCHING = 3
    CUSTOM = 4
    COMPETING = 5


class ActivityFlags(IntEnum):
    """Activity flags"""

    INSTANCE = 1 << 0
    JOIN = 1 << 1
    SPECTATE = 1 << 2
    JOIN_REQUEST = 1 << 3
    SYNC = 1 << 4
    PLAY = 1 << 5
    PARTY_PRIVACY_FRIENDS = 1 << 6
    PARTY_PRIVACY_VOICE_CHANNEL = 1 << 7
    EMBEDDED = 1 << 8


class StatusType(IntEnum):
    """User status types"""

    ONLINE = 0
    DND = 1
    IDLE = 2
    INVISIBLE = 3
    OFFLINE = 4


class ActivityTimestamps:
    """Activity timestamps"""

    __slots__ = ("start", "end")

    def __init__(self, *, data: Dict[str, Any]):
        self.start: Optional[datetime] = None
        self.end: Optional[datetime] = None

        if start := data.get("start"):
            self.start = datetime.fromtimestamp(start / 1000.0)
        if end := data.get("end"):
            self.end = datetime.fromtimestamp(end / 1000.0)

    def to_dict(self) -> Dict[str, int]:
        """Convert to dict"""
        result = {}
        if self.start:
            result["start"] = int(self.start.timestamp() * 1000)
        if self.end:
            result["end"] = int(self.end.timestamp() * 1000)
        return result


class ActivityParty:
    """Activity party information"""

    __slots__ = ("id", "size")

    def __init__(self, *, data: Dict[str, Any]):
        self.id: Optional[str] = data.get("id")
        size = data.get("size", [])
        self.size: tuple = tuple(size) if size else ()

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict"""
        result = {}
        if self.id:
            result["id"] = self.id
        if self.size:
            result["size"] = list(self.size)
        return result


class ActivityAssets:
    """Activity assets (images)"""

    __slots__ = ("large_image", "large_text", "small_image", "small_text")

    def __init__(self, *, data: Dict[str, Any]):
        self.large_image: Optional[str] = data.get("large_image")
        self.large_text: Optional[str] = data.get("large_text")
        self.small_image: Optional[str] = data.get("small_image")
        self.small_text: Optional[str] = data.get("small_text")

    def to_dict(self) -> Dict[str, str]:
        """Convert to dict"""
        result = {}
        if self.large_image:
            result["large_image"] = self.large_image
        if self.large_text:
            result["large_text"] = self.large_text
        if self.small_image:
            result["small_image"] = self.small_image
        if self.small_text:
            result["small_text"] = self.small_text
        return result


class ActivitySecrets:
    """Activity secrets for join/spectate"""

    __slots__ = ("join", "spectate", "match")

    def __init__(self, *, data: Dict[str, Any]):
        self.join: Optional[str] = data.get("join")
        self.spectate: Optional[str] = data.get("spectate")
        self.match: Optional[str] = data.get("match")

    def to_dict(self) -> Dict[str, str]:
        """Convert to dict"""
        result = {}
        if self.join:
            result["join"] = self.join
        if self.spectate:
            result["spectate"] = self.spectate
        if self.match:
            result["match"] = self.match
        return result


class ActivityButton:
    """Activity button"""

    __slots__ = ("label", "url")

    def __init__(self, label: str, url: str):
        self.label = label
        self.url = url

    @classmethod
    def from_dict(cls, data: Dict[str, str]) -> ActivityButton:
        """Create from dict"""
        return cls(label=data["label"], url=data["url"])

    def to_dict(self) -> Dict[str, str]:
        """Convert to dict"""
        return {"label": self.label, "url": self.url}


class Activity:
    """
    Represents a Discord activity (presence)

    Attributes:
        name: Activity name
        type: Activity type
        url: Stream URL (for streaming)
        created_at: Unix timestamp when activity was added
        timestamps: Activity timestamps
        application_id: Application ID
        details: Activity details
        state: Activity state
        emoji: Emoji for custom status
        party: Party information
        assets: Activity assets
        secrets: Activity secrets
        instance: Whether activity is an instanced game session
        flags: Activity flags
        buttons: Activity buttons
    """

    __slots__ = (
        "name",
        "type",
        "url",
        "created_at",
        "timestamps",
        "application_id",
        "details",
        "state",
        "emoji",
        "party",
        "assets",
        "secrets",
        "instance",
        "flags",
        "buttons",
    )

    def __init__(
        self,
        name: str,
        *,
        type: ActivityType = ActivityType.GAME,
        url: Optional[str] = None,
        **kwargs,
    ):
        self.name = name
        self.type = type
        self.url = url
        self.created_at: Optional[int] = kwargs.get("created_at")
        self.timestamps: Optional[ActivityTimestamps] = None
        self.application_id: Optional[Snowflake] = kwargs.get("application_id")
        self.details: Optional[str] = kwargs.get("details")
        self.state: Optional[str] = kwargs.get("state")
        self.emoji: Optional[Dict[str, Any]] = kwargs.get("emoji")
        self.party: Optional[ActivityParty] = None
        self.assets: Optional[ActivityAssets] = None
        self.secrets: Optional[ActivitySecrets] = None
        self.instance: Optional[bool] = kwargs.get("instance")
        self.flags: int = kwargs.get("flags", 0)
        self.buttons: List[ActivityButton] = []

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Activity:
        """Create Activity from dict"""
        activity = cls(
            name=data["name"],
            type=ActivityType(data.get("type", 0)),
            url=data.get("url"),
            created_at=data.get("created_at"),
            application_id=data.get("application_id"),
            details=data.get("details"),
            state=data.get("state"),
            emoji=data.get("emoji"),
            instance=data.get("instance"),
            flags=data.get("flags", 0),
        )

        if timestamps := data.get("timestamps"):
            activity.timestamps = ActivityTimestamps(data=timestamps)
        if party := data.get("party"):
            activity.party = ActivityParty(data=party)
        if assets := data.get("assets"):
            activity.assets = ActivityAssets(data=assets)
        if secrets := data.get("secrets"):
            activity.secrets = ActivitySecrets(data=secrets)
        if buttons := data.get("buttons"):
            activity.buttons = [ActivityButton.from_dict(b) for b in buttons]

        return activity

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict"""
        result = {"name": self.name, "type": int(self.type)}

        if self.url:
            result["url"] = self.url
        if self.created_at:
            result["created_at"] = self.created_at
        if self.timestamps:
            result["timestamps"] = self.timestamps.to_dict()
        if self.application_id:
            result["application_id"] = str(self.application_id)
        if self.details:
            result["details"] = self.details
        if self.state:
            result["state"] = self.state
        if self.emoji:
            result["emoji"] = self.emoji
        if self.party:
            result["party"] = self.party.to_dict()
        if self.assets:
            result["assets"] = self.assets.to_dict()
        if self.secrets:
            result["secrets"] = self.secrets.to_dict()
        if self.instance is not None:
            result["instance"] = self.instance
        if self.flags:
            result["flags"] = self.flags
        if self.buttons:
            result["buttons"] = [b.to_dict() for b in self.buttons]

        return result

    def __repr__(self) -> str:
        return f"<Activity name={self.name!r} type={self.type.name}>"


class ClientStatus:
    """Client status for different platforms"""

    __slots__ = ("desktop", "mobile", "web")

    def __init__(self, *, data: Dict[str, Any]):
        self.desktop: Optional[str] = data.get("desktop")
        self.mobile: Optional[str] = data.get("mobile")
        self.web: Optional[str] = data.get("web")


class Presence:
    """
    Represents a user's presence

    Attributes:
        user_id: User ID
        status: User status
        activities: List of activities
        client_status: Status per client platform
    """

    __slots__ = ("user_id", "status", "activities", "client_status", "guild_id")

    def __init__(self, *, data: Dict[str, Any]):
        user_data = data.get("user", {})
        self.user_id: Optional[Snowflake] = int(user_data["id"]) if "id" in user_data else None
        self.status: str = data.get("status", "offline")
        self.activities: List[Activity] = [
            Activity.from_dict(activity) for activity in data.get("activities", [])
        ]
        self.client_status: Optional[ClientStatus] = None
        if client_status := data.get("client_status"):
            self.client_status = ClientStatus(data=client_status)
        self.guild_id: Optional[Snowflake] = data.get("guild_id")

    def __repr__(self) -> str:
        return f"<Presence user_id={self.user_id} status={self.status}>"

    @property
    def is_online(self) -> bool:
        """Whether user is online"""
        return self.status == "online"

    @property
    def is_idle(self) -> bool:
        """Whether user is idle"""
        return self.status == "idle"

    @property
    def is_dnd(self) -> bool:
        """Whether user is in Do Not Disturb"""
        return self.status == "dnd"

    @property
    def is_offline(self) -> bool:
        """Whether user is offline/invisible"""
        return self.status == "offline" or self.status == "invisible"

"""
Soundboard models for Discord API.

Users can play soundboard sounds in voice channels.
"""

from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..http import HTTPClient
    from .user import User


@dataclass(slots=True)
class SoundboardSound:
    """Represents a soundboard sound.

    Attributes:
        sound_id: The ID of the sound
        name: The name of the sound
        volume: Volume from 0.0 to 1.0
        emoji_id: Custom emoji ID for the sound
        emoji_name: Unicode emoji for the sound
        guild_id: Guild this sound belongs to (None for default sounds)
        available: Whether the sound can be used
        user: User who created this sound (guild sounds only)
    """

    sound_id: int
    name: str
    volume: float
    emoji_id: Optional[int] = None
    emoji_name: Optional[str] = None
    guild_id: Optional[int] = None
    available: bool = True
    user: Optional["User"] = None

    _http: Optional["HTTPClient"] = None

    @classmethod
    def from_dict(cls, data: dict, http: "HTTPClient" = None) -> "SoundboardSound":
        """Create a SoundboardSound from API data."""
        from .user import User

        return cls(
            sound_id=int(data["sound_id"]),
            name=data["name"],
            volume=float(data["volume"]),
            emoji_id=int(data["emoji_id"]) if data.get("emoji_id") else None,
            emoji_name=data.get("emoji_name"),
            guild_id=int(data["guild_id"]) if data.get("guild_id") else None,
            available=data.get("available", True),
            user=User(data=data["user"], http=http) if data.get("user") else None,
            _http=http,
        )

    def to_dict(self) -> dict:
        """Convert to API format."""
        data = {
            "sound_id": str(self.sound_id),
            "name": self.name,
            "volume": self.volume,
            "available": self.available,
        }

        if self.emoji_id:
            data["emoji_id"] = str(self.emoji_id)
        if self.emoji_name:
            data["emoji_name"] = self.emoji_name
        if self.guild_id:
            data["guild_id"] = str(self.guild_id)
        if self.user:
            data["user"] = self.user.to_dict()

        return data

    @property
    def url(self) -> str:
        """Get the CDN URL for this sound.

        Returns MP3/Ogg format audio file.
        """
        return f"https://cdn.discordapp.com/soundboard-sounds/{self.sound_id}"

    @property
    def is_default(self) -> bool:
        """Check if this is a default Discord sound."""
        return self.guild_id is None

    @property
    def is_guild_sound(self) -> bool:
        """Check if this is a custom guild sound."""
        return self.guild_id is not None

    async def delete(self, *, reason: Optional[str] = None) -> None:
        """Delete this soundboard sound.

        Only works for guild sounds. Requires MANAGE_GUILD_EXPRESSIONS permission.

        Args:
            reason: Audit log reason

        Raises:
            ValueError: If this is a default sound
            Forbidden: Missing permissions
            HTTPException: Deletion failed
        """
        if not self.guild_id:
            raise ValueError("Cannot delete default sounds")

        if not self._http:
            raise ValueError("Cannot delete sound without HTTP client")

        await self._http.delete_guild_soundboard_sound(self.guild_id, self.sound_id, reason=reason)

    async def edit(
        self,
        *,
        name: Optional[str] = None,
        volume: Optional[float] = None,
        emoji_id: Optional[int] = None,
        emoji_name: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> "SoundboardSound":
        """Edit this soundboard sound.

        Only works for guild sounds. Requires MANAGE_GUILD_EXPRESSIONS permission.

        Args:
            name: New name
            volume: New volume (0.0 to 1.0)
            emoji_id: New custom emoji ID
            emoji_name: New unicode emoji
            reason: Audit log reason

        Returns:
            Updated SoundboardSound

        Raises:
            ValueError: If this is a default sound or invalid volume
            Forbidden: Missing permissions
            HTTPException: Edit failed
        """
        if not self.guild_id:
            raise ValueError("Cannot edit default sounds")

        if not self._http:
            raise ValueError("Cannot edit sound without HTTP client")

        if volume is not None and not 0.0 <= volume <= 1.0:
            raise ValueError("Volume must be between 0.0 and 1.0")

        data = await self._http.modify_guild_soundboard_sound(
            self.guild_id,
            self.sound_id,
            name=name,
            volume=volume,
            emoji_id=emoji_id,
            emoji_name=emoji_name,
            reason=reason,
        )

        return SoundboardSound.from_dict(data, self._http)

    async def send_to_voice_channel(
        self, channel_id: int, *, source_guild_id: Optional[int] = None
    ) -> None:
        """Send this sound to a voice channel.

        User must be connected to the voice channel.
        Requires SPEAK and USE_SOUNDBOARD permissions.
        Requires USE_EXTERNAL_SOUNDS for sounds from other guilds.

        Args:
            channel_id: Voice channel to send sound to
            source_guild_id: Source guild ID (for external sounds)

        Raises:
            Forbidden: Missing permissions or not in voice channel
            HTTPException: Failed to send sound
        """
        if not self._http:
            raise ValueError("Cannot send sound without HTTP client")

        await self._http.send_soundboard_sound(
            channel_id, sound_id=self.sound_id, source_guild_id=source_guild_id or self.guild_id
        )

    def __str__(self) -> str:
        """String representation."""
        emoji = self.emoji_name or (f"<:{self.emoji_id}>" if self.emoji_id else "🔊")
        return f"{emoji} {self.name}"

    def __repr__(self) -> str:
        """Developer representation."""
        return f"<SoundboardSound id={self.sound_id} name={self.name!r}>"


# HTTP Client Methods (to be added to HTTPClient)
"""
async def list_default_soundboard_sounds(self) -> list[dict]:
    '''Get all default soundboard sounds.'''
    return await self.request('GET', '/soundboard-default-sounds')

async def list_guild_soundboard_sounds(self, guild_id: int) -> list[dict]:
    '''Get all soundboard sounds for a guild.'''
    return await self.request('GET', f'/guilds/{guild_id}/soundboard-sounds')

async def get_guild_soundboard_sound(self, guild_id: int, sound_id: int) -> dict:
    '''Get a specific guild soundboard sound.'''
    return await self.request('GET', f'/guilds/{guild_id}/soundboard-sounds/{sound_id}')

async def create_guild_soundboard_sound(
    self,
    guild_id: int,
    *,
    json: dict,
    reason: str = None
) -> dict:
    '''Create a new guild soundboard sound.

    Requires MANAGE_GUILD_EXPRESSIONS permission.

    JSON params:
        - name (str): Sound name (2-32 chars)
        - sound (str): Base64 encoded MP3 or OGG sound (max 512kb)
        - volume (float): Volume 0.0-1.0, default 1.0
        - emoji_id (snowflake): Custom emoji ID
        - emoji_name (str): Unicode emoji
    '''
    return await self.request(
        'POST',
        f'/guilds/{guild_id}/soundboard-sounds',
        json=json,
        reason=reason
    )

async def modify_guild_soundboard_sound(
    self,
    guild_id: int,
    sound_id: int,
    *,
    json: dict,
    reason: str = None
) -> dict:
    '''Modify a guild soundboard sound.'''
    return await self.request(
        'PATCH',
        f'/guilds/{guild_id}/soundboard-sounds/{sound_id}',
        json=json,
        reason=reason
    )

async def delete_guild_soundboard_sound(
    self,
    guild_id: int,
    sound_id: int,
    *,
    reason: str = None
) -> None:
    '''Delete a guild soundboard sound.'''
    await self.request(
        'DELETE',
        f'/guilds/{guild_id}/soundboard-sounds/{sound_id}',
        reason=reason
    )

async def send_soundboard_sound(self, channel_id: int, *, json: dict) -> None:
    '''Send a soundboard sound to a voice channel.

    JSON params:
        - sound_id (snowflake): Sound ID to play
        - source_guild_id (snowflake): Source guild for external sounds
    '''
    await self.request('POST', f'/channels/{channel_id}/send-soundboard-sound', json=json)
"""

"""
SKU (Stock Keeping Unit) Model - Discord Monetization
Represents a purchasable item in Discord's monetization system.
"""

from typing import TYPE_CHECKING, Any, Dict
from enum import IntEnum

if TYPE_CHECKING:
    pass


class SKUType(IntEnum):
    """SKU types in Discord."""

    SUBSCRIPTION = 5  # Recurring subscription
    SUBSCRIPTION_GROUP = 6  # System-generated group for each SUBSCRIPTION SKU


class SKUFlags(IntEnum):
    """SKU flags."""

    AVAILABLE = 1 << 2  # SKU is available for purchase
    GUILD_SUBSCRIPTION = 1 << 7  # Recurring guild subscription
    USER_SUBSCRIPTION = 1 << 8  # Recurring user subscription


class SKU:
    """
    Represents a Stock Keeping Unit (SKU) for Discord monetization.

    SKUs are purchasable items like subscriptions or one-time purchases.

    Attributes:
        id: Unique ID of the SKU
        type: Type of SKU
        application_id: ID of the parent application
        name: Customer-facing name
        slug: System-generated URL slug
        flags: SKU flags
    """

    def __init__(self, data: Dict[str, Any], http_client=None):
        """
        Initialize a SKU from API data.

        Args:
            data: Raw SKU data from Discord API
            http_client: Optional HTTP client for API operations
        """
        self._http = http_client
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update SKU with new data."""
        self.id: str = data.get("id", "")
        self.type: SKUType = SKUType(data.get("type", 5))
        self.application_id: str = data.get("application_id", "")
        self.name: str = data.get("name", "")
        self.slug: str = data.get("slug", "")
        self.flags: int = data.get("flags", 0)

        # Optional fields
        self._raw_data = data

    @property
    def is_available(self) -> bool:
        """Check if SKU is available for purchase."""
        return bool(self.flags & SKUFlags.AVAILABLE)

    @property
    def is_guild_subscription(self) -> bool:
        """Check if this is a guild subscription."""
        return bool(self.flags & SKUFlags.GUILD_SUBSCRIPTION)

    @property
    def is_user_subscription(self) -> bool:
        """Check if this is a user subscription."""
        return bool(self.flags & SKUFlags.USER_SUBSCRIPTION)

    @property
    def is_subscription(self) -> bool:
        """Check if this is any type of subscription."""
        return self.type == SKUType.SUBSCRIPTION

    @property
    def is_subscription_group(self) -> bool:
        """Check if this is a subscription group."""
        return self.type == SKUType.SUBSCRIPTION_GROUP

    def __repr__(self) -> str:
        return f"<SKU id={self.id} name='{self.name}' type={self.type.name}>"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other) -> bool:
        return isinstance(other, SKU) and other.id == self.id

    def __hash__(self) -> int:
        return hash(self.id)

    def to_dict(self) -> Dict[str, Any]:
        """Convert SKU to dictionary representation."""
        return {
            "id": self.id,
            "type": self.type,
            "application_id": self.application_id,
            "name": self.name,
            "slug": self.slug,
            "flags": self.flags,
        }


__all__ = [
    "SKU",
    "SKUType",
    "SKUFlags",
]

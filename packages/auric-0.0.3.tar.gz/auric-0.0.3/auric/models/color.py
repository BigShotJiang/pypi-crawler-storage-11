"""
Color utility class
"""

from __future__ import annotations

from typing import Tuple


class Color:
    """
    Represents a Discord color

    Colors are 24-bit RGB values stored as integers
    """

    __slots__ = ("value",)

    def __init__(self, value: int):
        if not isinstance(value, int):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        if value < 0 or value > 0xFFFFFF:
            raise ValueError("Color value must be between 0 and 16777215 (0xFFFFFF)")

        self.value = value

    def __int__(self) -> int:
        return self.value

    def __str__(self) -> str:
        return f"#{self.value:0>6x}"

    def __repr__(self) -> str:
        return f"<Color value={self.value}>"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Color) and self.value == other.value

    def __hash__(self) -> int:
        return hash(self.value)

    @property
    def r(self) -> int:
        """Red component (0-255)"""
        return (self.value >> 16) & 0xFF

    @property
    def g(self) -> int:
        """Green component (0-255)"""
        return (self.value >> 8) & 0xFF

    @property
    def b(self) -> int:
        """Blue component (0-255)"""
        return self.value & 0xFF

    def to_rgb(self) -> Tuple[int, int, int]:
        """Get RGB tuple"""
        return (self.r, self.g, self.b)

    @classmethod
    def from_rgb(cls, r: int, g: int, b: int) -> Color:
        """Create color from RGB values"""
        return cls((r << 16) + (g << 8) + b)

    @classmethod
    def from_hex(cls, hex_string: str) -> Color:
        """Create color from hex string (e.g. '#FF5733' or 'FF5733')"""
        hex_string = hex_string.lstrip("#")
        return cls(int(hex_string, 16))

    # Predefined colors
    @classmethod
    def default(cls) -> Color:
        return cls(0)

    @classmethod
    def teal(cls) -> Color:
        return cls(0x1ABC9C)

    @classmethod
    def dark_teal(cls) -> Color:
        return cls(0x11806A)

    @classmethod
    def brand_green(cls) -> Color:
        return cls(0x57F287)

    @classmethod
    def green(cls) -> Color:
        return cls(0x2ECC71)

    @classmethod
    def dark_green(cls) -> Color:
        return cls(0x1F8B4C)

    @classmethod
    def blue(cls) -> Color:
        return cls(0x3498DB)

    @classmethod
    def dark_blue(cls) -> Color:
        return cls(0x206694)

    @classmethod
    def purple(cls) -> Color:
        return cls(0x9B59B6)

    @classmethod
    def dark_purple(cls) -> Color:
        return cls(0x71368A)

    @classmethod
    def magenta(cls) -> Color:
        return cls(0xE91E63)

    @classmethod
    def dark_magenta(cls) -> Color:
        return cls(0xAD1457)

    @classmethod
    def gold(cls) -> Color:
        return cls(0xF1C40F)

    @classmethod
    def dark_gold(cls) -> Color:
        return cls(0xC27C0E)

    @classmethod
    def orange(cls) -> Color:
        return cls(0xE67E22)

    @classmethod
    def dark_orange(cls) -> Color:
        return cls(0xA84300)

    @classmethod
    def brand_red(cls) -> Color:
        return cls(0xED4245)

    @classmethod
    def red(cls) -> Color:
        return cls(0xE74C3C)

    @classmethod
    def dark_red(cls) -> Color:
        return cls(0x992D22)

    @classmethod
    def lighter_grey(cls) -> Color:
        return cls(0x95A5A6)

    @classmethod
    def dark_grey(cls) -> Color:
        return cls(0x607D8B)

    @classmethod
    def light_grey(cls) -> Color:
        return cls(0x979C9F)

    @classmethod
    def darker_grey(cls) -> Color:
        return cls(0x546E7A)

    @classmethod
    def og_blurple(cls) -> Color:
        return cls(0x7289DA)

    @classmethod
    def blurple(cls) -> Color:
        return cls(0x5865F2)

    @classmethod
    def greyple(cls) -> Color:
        return cls(0x99AAB5)

    @classmethod
    def dark_theme(cls) -> Color:
        return cls(0x313338)

    @classmethod
    def fuchsia(cls) -> Color:
        return cls(0xEB459E)

    @classmethod
    def yellow(cls) -> Color:
        return cls(0xFEE75C)

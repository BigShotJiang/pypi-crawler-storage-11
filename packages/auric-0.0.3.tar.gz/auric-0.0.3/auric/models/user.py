"""
User model - represents Discord users
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Dict, Optional


from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum, IntFlag

from ..core.types import CDN_URL, Snowflake, snowflake_time

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class PremiumType(IntEnum):
    """Discord Nitro subscription types"""

    NONE = 0
    NITRO_CLASSIC = 1
    NITRO = 2
    NITRO_BASIC = 3


class UserFlags(IntFlag):
    """User account flags"""

    NONE = 0
    STAFF = 1 << 0
    PARTNER = 1 << 1
    HYPESQUAD = 1 << 2
    BUG_HUNTER_LEVEL_1 = 1 << 3
    HYPESQUAD_ONLINE_HOUSE_1 = 1 << 6  # Bravery
    HYPESQUAD_ONLINE_HOUSE_2 = 1 << 7  # Brilliance
    HYPESQUAD_ONLINE_HOUSE_3 = 1 << 8  # Balance
    PREMIUM_EARLY_SUPPORTER = 1 << 9
    TEAM_PSEUDO_USER = 1 << 10
    BUG_HUNTER_LEVEL_2 = 1 << 14
    VERIFIED_BOT = 1 << 16
    VERIFIED_DEVELOPER = 1 << 17
    CERTIFIED_MODERATOR = 1 << 18
    BOT_HTTP_INTERACTIONS = 1 << 19
    ACTIVE_DEVELOPER = 1 << 22


@dataclass
class AvatarDecorationData:
    """Avatar decoration data"""

    asset: str
    sku_id: Snowflake


class User:
    """
    Represents a Discord user

    Attributes:
        id: User's unique ID
        username: User's username
        discriminator: User's 4-digit discriminator (legacy)
        global_name: User's display name
        avatar: Avatar hash
        bot: Whether the user is a bot
        system: Whether the user is an Official Discord System user
        mfa_enabled: Whether user has 2FA enabled
        banner: Banner hash
        accent_color: Banner color as integer
        locale: User's locale
        verified: Whether email is verified
        email: User's email
        flags: Public flags
        premium_type: Type of Nitro subscription
        public_flags: Public user flags
        avatar_decoration_data: Avatar decoration
    """

    __slots__ = (
        "id",
        "username",
        "discriminator",
        "global_name",
        "avatar",
        "bot",
        "system",
        "mfa_enabled",
        "banner",
        "accent_color",
        "locale",
        "verified",
        "email",
        "flags",
        "premium_type",
        "public_flags",
        "avatar_decoration_data",
        "_http",
    )

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update user from API data"""
        self.id: Snowflake = int(data["id"])
        self.username: str = data.get("username", "Unknown")
        self.discriminator: str = data.get("discriminator", "0")
        self.global_name: Optional[str] = data.get("global_name")
        self.avatar: Optional[str] = data.get("avatar")
        self.bot: bool = data.get("bot", False)
        self.system: bool = data.get("system", False)
        self.mfa_enabled: bool = data.get("mfa_enabled", False)
        self.banner: Optional[str] = data.get("banner")
        self.accent_color: Optional[int] = data.get("accent_color")
        self.locale: Optional[str] = data.get("locale")
        self.verified: bool = data.get("verified", False)
        self.email: Optional[str] = data.get("email")
        self.flags: UserFlags = UserFlags(data.get("flags", 0))
        self.premium_type: PremiumType = PremiumType(data.get("premium_type", 0))
        self.public_flags: UserFlags = UserFlags(data.get("public_flags", 0))

        # Avatar decoration
        decoration_data = data.get("avatar_decoration_data")
        if decoration_data:
            self.avatar_decoration_data = AvatarDecorationData(
                asset=decoration_data["asset"], sku_id=decoration_data["sku_id"]
            )
        else:
            self.avatar_decoration_data = None

    def __repr__(self) -> str:
        return f"<User id={self.id} username={self.username!r}>"

    def __str__(self) -> str:
        if self.discriminator != "0":
            return f"{self.username}#{self.discriminator}"
        return self.username

    def __eq__(self, other: object) -> bool:
        return isinstance(other, User) and self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    @property
    def mention(self) -> str:
        """Returns a string that mentions the user"""
        return f"<@{self.id}>"

    @property
    def display_name(self) -> str:
        """Returns the user's display name"""
        return self.global_name or self.username

    @property
    def created_at(self) -> datetime:
        """When the user account was created"""
        return snowflake_time(self.id)

    @property
    def avatar_url(self) -> str:
        """Returns the user's avatar URL"""
        if self.avatar is None:
            # Default avatar
            if self.discriminator != "0":
                # Legacy default avatar
                index = int(self.discriminator) % 5
            else:
                # New default avatar
                index = (self.id >> 22) % 6
            return f"{CDN_URL}/embed/avatars/{index}.png"

        # Custom avatar
        ext = "gif" if self.avatar.startswith("a_") else "png"
        return f"{CDN_URL}/avatars/{self.id}/{self.avatar}.{ext}"

    def avatar_url_as(self, *, format: str = "png", size: int = 1024) -> str:
        """
        Returns the user's avatar URL with custom format and size

        Args:
            format: Image format (png, jpg, jpeg, webp, gif)
            size: Image size (must be power of 2 between 16 and 4096)
        """
        if self.avatar is None:
            return self.avatar_url

        if format == "gif" and not self.avatar.startswith("a_"):
            format = "png"

        return f"{CDN_URL}/avatars/{self.id}/{self.avatar}.{format}?size={size}"

    @property
    def banner_url(self) -> Optional[str]:
        """Returns the user's banner URL"""
        if self.banner is None:
            return None

        ext = "gif" if self.banner.startswith("a_") else "png"
        return f"{CDN_URL}/banners/{self.id}/{self.banner}.{ext}"

    def banner_url_as(self, *, format: str = "png", size: int = 1024) -> Optional[str]:
        """Returns the user's banner URL with custom format and size"""
        if self.banner is None:
            return None

        if format == "gif" and not self.banner.startswith("a_"):
            format = "png"

        return f"{CDN_URL}/banners/{self.id}/{self.banner}.{format}?size={size}"

    @property
    def avatar_decoration_url(self) -> Optional[str]:
        """Returns the user's avatar decoration URL"""
        if self.avatar_decoration_data is None:
            return None

        return f"{CDN_URL}/avatar-decoration-presets/{self.avatar_decoration_data.asset}.png"

    @property
    def default_avatar_url(self) -> str:
        """Returns the default avatar URL"""
        if self.discriminator != "0":
            index = int(self.discriminator) % 5
        else:
            index = (self.id >> 22) % 6
        return f"{CDN_URL}/embed/avatars/{index}.png"

    @property
    def is_avatar_animated(self) -> bool:
        """Whether the user's avatar is animated"""
        return self.avatar is not None and self.avatar.startswith("a_")

    @property
    def is_banner_animated(self) -> bool:
        """Whether the user's banner is animated"""
        return self.banner is not None and self.banner.startswith("a_")

    # User flags checks
    @property
    def is_staff(self) -> bool:
        return UserFlags.STAFF in self.public_flags

    @property
    def is_partner(self) -> bool:
        return UserFlags.PARTNER in self.public_flags

    @property
    def is_hypesquad(self) -> bool:
        return UserFlags.HYPESQUAD in self.public_flags

    @property
    def is_bug_hunter(self) -> bool:
        return (
            UserFlags.BUG_HUNTER_LEVEL_1 in self.public_flags
            or UserFlags.BUG_HUNTER_LEVEL_2 in self.public_flags
        )

    @property
    def is_early_supporter(self) -> bool:
        return UserFlags.PREMIUM_EARLY_SUPPORTER in self.public_flags

    @property
    def is_verified_bot(self) -> bool:
        return UserFlags.VERIFIED_BOT in self.public_flags

    @property
    def is_verified_bot_developer(self) -> bool:
        return UserFlags.VERIFIED_DEVELOPER in self.public_flags

    @property
    def is_certified_moderator(self) -> bool:
        return UserFlags.CERTIFIED_MODERATOR in self.public_flags

    @property
    def is_active_developer(self) -> bool:
        return UserFlags.ACTIVE_DEVELOPER in self.public_flags

    @property
    def hypesquad_house(self) -> Optional[str]:
        """Returns the user's HypeSquad house"""
        if UserFlags.HYPESQUAD_ONLINE_HOUSE_1 in self.public_flags:
            return "bravery"
        elif UserFlags.HYPESQUAD_ONLINE_HOUSE_2 in self.public_flags:
            return "brilliance"
        elif UserFlags.HYPESQUAD_ONLINE_HOUSE_3 in self.public_flags:
            return "balance"
        return None

    def to_dict(self) -> Dict[str, Any]:
        """Convert user to dictionary"""
        data = {
            "id": str(self.id),
            "username": self.username,
            "discriminator": self.discriminator,
            "global_name": self.global_name,
            "avatar": self.avatar,
            "bot": self.bot,
        }

        if self.system:
            data["system"] = self.system

        if self.banner:
            data["banner"] = self.banner

        if self.accent_color:
            data["accent_color"] = self.accent_color

        return data


class ClientUser(User):
    """
    Represents the bot's user account

    Additional attributes:
        application_id: Bot's application ID
    """

    __slots__ = ("application_id",)

    def __init__(self, *, data: Dict[str, Any], http: HTTPClient):
        super().__init__(data=data, http=http)
        self.application_id: Optional[Snowflake] = None

    async def edit(
        self,
        *,
        username: Optional[str] = None,
        avatar: Optional[bytes] = None,
    ) -> ClientUser:
        """
        Edit the bot's user account

        Args:
            username: New username
            avatar: New avatar image bytes
        """
        from ..core.http import Route

        payload = {}

        if username is not None:
            payload["username"] = username

        if avatar is not None:
            import base64

            payload["avatar"] = f"data:image/png;base64,{base64.b64encode(avatar).decode()}"

        if not payload:
            return self

        data = await self._http.request(Route("PATCH", "/users/@me"), json=payload)
        self._update(data)
        return self

"""
Lobby Resource Implementation
Represents lobbies for Discord Social SDK
"""

from typing import Any, Dict, List, Optional
from dataclasses import dataclass
from .channel import Channel
import warnings


@dataclass
class LobbyMember:
    """Represents a member of a lobby"""

    def __init__(self, data: Dict[str, Any]):
        self.id: str = data.get("id")
        self.metadata: Optional[Dict[str, str]] = data.get("metadata")
        self.flags: int = data.get("flags", 0)

    def can_link_lobby(self) -> bool:
        """Check if user can link a text channel to a lobby"""
        return bool(self.flags & (1 << 0))

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result = {"id": self.id}
        if self.metadata is not None:
            result["metadata"] = self.metadata
        if self.flags:
            result["flags"] = self.flags
        return result


@dataclass
class Lobby:
    """Represents a lobby within Discord

    .. deprecated:: 0.1.0
        The Lobby API is part of the deprecated GameSDK. Please use the new Activities SDK instead.
    """

    def __init__(self, data: Dict[str, Any], client=None):
        warnings.warn(
            "The Lobby API is deprecated and will be removed in a future version.",
            DeprecationWarning,
            stacklevel=2,
        )
        self._client = client
        self.id: str = data.get("id")
        self.application_id: str = data.get("application_id")
        self.metadata: Optional[Dict[str, str]] = data.get("metadata")
        self.members: List[LobbyMember] = [LobbyMember(m) for m in data.get("members", [])]
        self.linked_channel: Optional[Channel] = None
        if "linked_channel" in data and data["linked_channel"]:
            self.linked_channel = Channel(data["linked_channel"], client)

    def get_member(self, user_id: str) -> Optional[LobbyMember]:
        """Get a specific lobby member by user ID"""
        for member in self.members:
            if member.id == user_id:
                return member
        return None

    async def add_member(
        self, user_id: str, metadata: Optional[Dict[str, str]] = None, flags: int = 0
    ) -> LobbyMember:
        """Add a member to the lobby"""
        if not self._client:
            raise ValueError("Client not available")

        data = await self._client.http.add_lobby_member(self.id, user_id, metadata, flags)
        member = LobbyMember(data)

        # Update local members list
        existing = self.get_member(user_id)
        if existing:
            self.members.remove(existing)
        self.members.append(member)

        return member

    async def remove_member(self, user_id: str) -> None:
        """Remove a member from the lobby"""
        if not self._client:
            raise ValueError("Client not available")

        await self._client.http.remove_lobby_member(self.id, user_id)

        # Update local members list
        member = self.get_member(user_id)
        if member:
            self.members.remove(member)

    async def modify(
        self,
        metadata: Optional[Dict[str, str]] = None,
        members: Optional[List[Dict[str, Any]]] = None,
        idle_timeout_seconds: Optional[int] = None,
    ) -> "Lobby":
        """Modify the lobby"""
        if not self._client:
            raise ValueError("Client not available")

        data = await self._client.http.modify_lobby(
            self.id, metadata=metadata, members=members, idle_timeout_seconds=idle_timeout_seconds
        )

        # Update self
        self.__init__(data, self._client)
        return self

    async def delete(self) -> None:
        """Delete the lobby"""
        if not self._client:
            raise ValueError("Client not available")

        await self._client.http.delete_lobby(self.id)

    async def link_channel(self, channel_id: Optional[str] = None) -> "Lobby":
        """
        Link or unlink a channel to/from the lobby.
        If channel_id is None, unlinks any currently linked channel.

        Requires Bearer token authorization and user must be a lobby member
        with CanLinkLobby flag.
        """
        if not self._client:
            raise ValueError("Client not available")

        data = await self._client.http.link_lobby_channel(self.id, channel_id)

        # Update self
        self.__init__(data, self._client)
        return self

    async def leave(self) -> None:
        """
        Remove the current user from the lobby.
        Requires Bearer token authorization.
        """
        if not self._client:
            raise ValueError("Client not available")

        await self._client.http.leave_lobby(self.id)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result = {
            "id": self.id,
            "application_id": self.application_id,
            "metadata": self.metadata,
            "members": [m.to_dict() for m in self.members],
        }
        if self.linked_channel:
            result["linked_channel"] = self.linked_channel.to_dict()
        return result

    def __repr__(self) -> str:
        return f"<Lobby id={self.id} members={len(self.members)}>"

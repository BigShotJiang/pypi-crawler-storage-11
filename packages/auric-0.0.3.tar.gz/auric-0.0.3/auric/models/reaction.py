"""
Reaction model - represents message reactions
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Dict, Optional

from ..core.types import Snowflake

if TYPE_CHECKING:
    from ..core.http import HTTPClient


class Reaction:
    """
    Represents a message reaction

    Attributes:
        count: Number of times the emoji has been used to react
        me: Whether the current user reacted using this emoji
        emoji: Emoji information
        channel_id: ID of the channel
        message_id: ID of the message
        user_id: ID of the user who reacted (for events)
    """

    __slots__ = ("count", "me", "emoji", "channel_id", "message_id", "user_id", "_http")

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self._http = http
        self._update(data)

    def _update(self, data: Dict[str, Any]) -> None:
        """Update reaction from API data"""
        self.count: int = data.get("count", 0)
        self.me: bool = data.get("me", False)
        self.emoji: Dict[str, Any] = data.get("emoji", {})

        # From reaction events
        self.channel_id: Optional[Snowflake] = (
            int(data["channel_id"]) if "channel_id" in data else None
        )
        self.message_id: Optional[Snowflake] = (
            int(data["message_id"]) if "message_id" in data else None
        )
        self.user_id: Optional[Snowflake] = int(data["user_id"]) if "user_id" in data else None

    def __str__(self) -> str:
        """String representation of the reaction"""
        if "name" in self.emoji:
            return self.emoji["name"]
        return f"<:{self.emoji.get('name', 'unknown')}:{self.emoji.get('id', '0')}>"

    def __repr__(self) -> str:
        return f"<Reaction emoji={self.emoji.get('name')} count={self.count} me={self.me}>"

    async def remove(self, user_id: Optional[Snowflake] = None) -> None:
        """
        Remove this reaction from the message

        Args:
            user_id: Optional user ID to remove reaction for (requires MANAGE_MESSAGES)
                    If not provided, removes own reaction
        """
        if not self._http or not self.channel_id or not self.message_id:
            raise ValueError(
                "Cannot remove reaction without channel_id, message_id, and http client"
            )

        from ..core.http import Route

        emoji_str = self._get_emoji_str()

        if user_id:
            route = Route(
                "DELETE",
                f"/channels/{self.channel_id}/messages/{self.message_id}/reactions/{emoji_str}/{user_id}",
            )
        else:
            route = Route(
                "DELETE",
                f"/channels/{self.channel_id}/messages/{self.message_id}/reactions/{emoji_str}/@me",
            )

        await self._http.request(route)

    def _get_emoji_str(self) -> str:
        """Get emoji string for API calls"""
        if "id" in self.emoji and self.emoji["id"]:
            return f"{self.emoji['name']}:{self.emoji['id']}"
        return self.emoji.get("name", "")

"""
Poll model - Discord polls in messages

Polls allow users to vote on questions with multiple answer options.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .message import Message


class PollMedia:
    """
    Media object for poll questions and answers.

    Attributes:
        text: The text of the question or answer (max 300 chars for question, 55 for answer)
        emoji: Emoji for the answer
    """

    __slots__ = ("text", "emoji")

    def __init__(self, data: Dict[str, Any]):
        self.text: Optional[str] = data.get("text")
        self.emoji: Optional[Dict[str, Any]] = data.get("emoji")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        data = {}
        if self.text:
            data["text"] = self.text
        if self.emoji:
            data["emoji"] = self.emoji
        return data


class PollAnswer:
    """
    Represents a poll answer option.

    Attributes:
        answer_id: ID of the answer
        poll_media: Media for the answer
    """

    __slots__ = ("answer_id", "poll_media")

    def __init__(self, data: Dict[str, Any]):
        self.answer_id: int = data.get("answer_id", 0)
        self.poll_media: PollMedia = PollMedia(data.get("poll_media", {}))

    @property
    def text(self) -> Optional[str]:
        """Shortcut to answer text"""
        return self.poll_media.text

    @property
    def emoji(self) -> Optional[Dict[str, Any]]:
        """Shortcut to answer emoji"""
        return self.poll_media.emoji

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        return {"poll_media": self.poll_media.to_dict()}


class PollAnswerCount:
    """
    Vote count for a poll answer.

    Attributes:
        id: Answer ID
        count: Number of votes
        me_voted: Whether current user voted for this
    """

    __slots__ = ("id", "count", "me_voted")

    def __init__(self, data: Dict[str, Any]):
        self.id: int = data.get("id", 0)
        self.count: int = data.get("count", 0)
        self.me_voted: bool = data.get("me_voted", False)


class PollResults:
    """
    Results of a poll.

    Attributes:
        is_finalized: Whether the poll is finalized
        answer_counts: Vote counts per answer
    """

    __slots__ = ("is_finalized", "answer_counts")

    def __init__(self, data: Dict[str, Any]):
        self.is_finalized: bool = data.get("is_finalized", False)

        answer_counts_data = data.get("answer_counts", [])
        self.answer_counts: List[PollAnswerCount] = [
            PollAnswerCount(ac) for ac in answer_counts_data
        ]

    def get_answer_count(self, answer_id: int) -> Optional[PollAnswerCount]:
        """Get vote count for a specific answer"""
        for ac in self.answer_counts:
            if ac.id == answer_id:
                return ac
        return None

    @property
    def total_votes(self) -> int:
        """Total number of votes across all answers"""
        return sum(ac.count for ac in self.answer_counts)


class Poll:
    """
    Represents a Discord poll.

    Polls can be attached to messages to gather user votes.

    Attributes:
        question: The poll question
        answers: List of answer options
        expiry: When the poll expires
        allow_multiselect: Whether multiple answers can be selected
        layout_type: Layout type (1 = default)
        results: Poll results (if available)

    Example:
        ```python
        # Create a poll
        poll = Poll.create(
            question="What's your favorite color?",
            answers=[
                {"text": "Red", "emoji": "🔴"},
                {"text": "Blue", "emoji": "🔵"},
                {"text": "Green", "emoji": "🟢"},
            ],
            duration_hours=24
        )

        await channel.send("Vote now!", poll=poll)
        ```
    """

    __slots__ = (
        "question",
        "answers",
        "expiry",
        "allow_multiselect",
        "layout_type",
        "results",
        "_message",
    )

    def __init__(self, data: Dict[str, Any]):
        question_data = data.get("question", {})
        self.question: PollMedia = PollMedia(question_data)

        answers_data = data.get("answers", [])
        self.answers: List[PollAnswer] = [PollAnswer(a) for a in answers_data]

        expiry_str = data.get("expiry")
        self.expiry: Optional[datetime] = None
        if expiry_str:
            try:
                self.expiry = datetime.fromisoformat(expiry_str.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                pass

        self.allow_multiselect: bool = data.get("allow_multiselect", False)
        self.layout_type: int = data.get("layout_type", 1)

        results_data = data.get("results")
        self.results: Optional[PollResults] = None
        if results_data:
            self.results = PollResults(results_data)

        self._message: Optional[Message] = None

    @classmethod
    def create(
        cls,
        question: str,
        answers: List[Dict[str, Any]],
        *,
        duration_hours: int = 24,
        allow_multiselect: bool = False,
    ) -> Poll:
        """
        Create a new poll.

        Args:
            question: The poll question (max 300 chars)
            answers: List of answer dicts with 'text' and optional 'emoji'
            duration_hours: How long the poll lasts (1-168 hours)
            allow_multiselect: Allow selecting multiple answers

        Returns:
            Poll object ready to be sent

        Example:
            ```python
            poll = Poll.create(
                question="Best programming language?",
                answers=[
                    {"text": "Python", "emoji": "🐍"},
                    {"text": "JavaScript", "emoji": "📜"},
                    {"text": "Rust", "emoji": "🦀"},
                ],
                duration_hours=48,
                allow_multiselect=True
            )
            ```
        """
        if not 1 <= duration_hours <= 168:
            raise ValueError("duration_hours must be between 1 and 168")

        if not 1 <= len(answers) <= 10:
            raise ValueError("Poll must have 1-10 answers")

        # Create expiry time
        from datetime import timedelta

        expiry = datetime.utcnow() + timedelta(hours=duration_hours)

        data = {
            "question": {"text": question},
            "answers": [
                {"answer_id": i + 1, "poll_media": answer} for i, answer in enumerate(answers)
            ],
            "expiry": expiry.isoformat() + "Z",
            "allow_multiselect": allow_multiselect,
            "layout_type": 1,
        }

        return cls(data)

    def to_dict(self) -> Dict[str, Any]:
        """Convert poll to API format for sending"""
        data = {
            "question": self.question.to_dict(),
            "answers": [a.to_dict() for a in self.answers],
            "duration": self._calculate_duration_hours(),
            "allow_multiselect": self.allow_multiselect,
        }

        return data

    def _calculate_duration_hours(self) -> int:
        """Calculate duration in hours from expiry"""
        if not self.expiry:
            return 24  # Default

        now = datetime.utcnow()
        if self.expiry > now:
            delta = self.expiry - now
            hours = int(delta.total_seconds() / 3600)
            return max(1, min(168, hours))
        return 1

    @property
    def is_expired(self) -> bool:
        """Check if poll has expired"""
        if not self.expiry:
            return False
        return datetime.utcnow() >= self.expiry

    @property
    def is_finalized(self) -> bool:
        """Check if poll results are finalized"""
        if not self.results:
            return False
        return self.results.is_finalized

    async def end(self) -> None:
        """
        End the poll early.

        Requires the message to be set.
        """
        if not self._message:
            raise ValueError("Cannot end poll without message reference")

        await self._message.end_poll()

    async def get_voters(self, answer_id: int) -> List[Any]:
        """
        Get users who voted for a specific answer.

        Args:
            answer_id: The answer ID to get voters for

        Returns:
            List of users who voted

        Note:
            Requires the message to be set.
        """
        if not self._message:
            raise ValueError("Cannot get voters without message reference")

        return await self._message.get_poll_voters(answer_id)

    def get_answer_by_id(self, answer_id: int) -> Optional[PollAnswer]:
        """Get answer by ID"""
        for answer in self.answers:
            if answer.answer_id == answer_id:
                return answer
        return None

    def get_winning_answers(self) -> List[PollAnswer]:
        """
        Get the answer(s) with the most votes.

        Returns:
            List of winning answers (can be multiple in case of tie)
        """
        if not self.results or not self.results.answer_counts:
            return []

        max_count = max(ac.count for ac in self.results.answer_counts)
        winning_ids = [ac.id for ac in self.results.answer_counts if ac.count == max_count]

        return [answer for answer in self.answers if answer.answer_id in winning_ids]

    def __repr__(self) -> str:
        question_text = self.question.text or "No question"
        return f"<Poll question={question_text!r} answers={len(self.answers)} expired={self.is_expired}>"

"""
Audio source implementations for voice

Provides ready-to-use audio sources for streaming to Discord.
"""

from __future__ import annotations

import audioop
import logging
import subprocess
from pathlib import Path
from typing import BinaryIO, Optional, Union

logger = logging.getLogger(__name__)


class AudioSource:
    """
    Base class for audio sources

    Audio sources provide 20ms Opus frames (960 samples at 48kHz stereo).
    """

    def read(self) -> Optional[bytes]:
        """
        Read next audio frame

        Returns:
            20ms Opus-encoded frame, or None if done
        """
        raise NotImplementedError

    def is_opus(self) -> bool:
        """Whether source provides Opus-encoded audio"""
        return False

    def cleanup(self) -> None:
        """Cleanup resources"""
        pass

    def __del__(self):
        self.cleanup()


class PCMAudio(AudioSource):
    """
    Raw PCM audio source

    Streams raw PCM audio (48kHz, 16-bit, stereo).

    Args:
        stream: File-like object with PCM data

    Example:
        with open('audio.pcm', 'rb') as f:
            source = PCMAudio(f)
            await voice_client.play(source)
    """

    FRAME_SIZE = 3840  # 20ms at 48kHz stereo 16-bit (960 * 2 * 2)

    def __init__(self, stream: BinaryIO):
        self.stream = stream
        self._end = False

    def read(self) -> Optional[bytes]:
        if self._end:
            return None

        data = self.stream.read(self.FRAME_SIZE)
        if len(data) != self.FRAME_SIZE:
            self._end = True
            return None

        return data

    def cleanup(self) -> None:
        if hasattr(self.stream, "close"):
            self.stream.close()


class FFmpegAudio(AudioSource):
    """
    Audio source using FFmpeg for decoding

    Supports any format FFmpeg can decode (MP3, WAV, OGG, FLAC, etc.).

    Args:
        source: File path or URL
        options: Additional FFmpeg options
        before_options: Options before input (-i)

    Example:
        # Play MP3 file
        source = FFmpegAudio('song.mp3')
        await voice_client.play(source)

        # Stream from YouTube (requires youtube-dl)
        source = FFmpegAudio(youtube_url)
        await voice_client.play(source)
    """

    def __init__(self, source: Union[str, Path], *, options: str = "", before_options: str = ""):
        self.source = str(source)
        self.before_options = before_options
        self.options = options

        # Build FFmpeg command
        args = ["ffmpeg"]

        # Before options (e.g., -reconnect 1 for URLs)
        if before_options:
            args.extend(before_options.split())

        # Input
        args.extend(["-i", self.source])

        # Output format (48kHz stereo PCM)
        args.extend(["-f", "s16le", "-ar", "48000", "-ac", "2", "-loglevel", "warning"])

        # Additional options
        if options:
            args.extend(options.split())

        # Output to pipe
        args.append("pipe:1")

        self._process: Optional[subprocess.Popen] = None
        self._stdout: Optional[BinaryIO] = None
        self._start_process(args)

    def _start_process(self, args: list[str]) -> None:
        """Start FFmpeg process"""
        try:
            self._process = subprocess.Popen(
                args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL
            )
            self._stdout = self._process.stdout
        except FileNotFoundError:
            raise RuntimeError("FFmpeg not found. Install FFmpeg to use FFmpegAudio.")
        except Exception as e:
            raise RuntimeError(f"Failed to start FFmpeg: {e}")

    def read(self) -> Optional[bytes]:
        if not self._stdout:
            return None

        data = self._stdout.read(PCMAudio.FRAME_SIZE)
        if len(data) != PCMAudio.FRAME_SIZE:
            return None

        return data

    def cleanup(self) -> None:
        if self._process:
            try:
                self._process.kill()
                self._process.wait(timeout=2)
            except Exception:
                pass
            self._process = None

        if self._stdout:
            self._stdout.close()
            self._stdout = None


class FFmpegPCMAudio(FFmpegAudio):
    """
    Alias for FFmpegAudio (for compatibility)
    """

    pass


class FFmpegOpusAudio(AudioSource):
    """
    Audio source using FFmpeg with Opus encoding

    More efficient than PCM as audio is already Opus-encoded.

    Args:
        source: File path or URL
        bitrate: Audio bitrate in kbps (default: 128)
        options: Additional FFmpeg options
        before_options: Options before input

    Example:
        source = FFmpegOpusAudio('song.mp3', bitrate=192)
        await voice_client.play(source)
    """

    def __init__(
        self,
        source: Union[str, Path],
        *,
        bitrate: int = 128,
        options: str = "",
        before_options: str = "",
    ):
        self.source = str(source)
        self.bitrate = bitrate

        # Build FFmpeg command
        args = ["ffmpeg"]

        if before_options:
            args.extend(before_options.split())

        args.extend(["-i", self.source])

        # Opus encoding
        args.extend(
            [
                "-f",
                "opus",
                "-ar",
                "48000",
                "-ac",
                "2",
                "-b:a",
                f"{bitrate}k",
                "-frame_duration",
                "20",
                "-loglevel",
                "warning",
            ]
        )

        if options:
            args.extend(options.split())

        args.append("pipe:1")

        self._process: Optional[subprocess.Popen] = None
        self._stdout: Optional[BinaryIO] = None
        self._start_process(args)

    def _start_process(self, args: list[str]) -> None:
        """Start FFmpeg process"""
        try:
            self._process = subprocess.Popen(
                args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL
            )
            self._stdout = self._process.stdout
        except FileNotFoundError:
            raise RuntimeError("FFmpeg not found")
        except Exception as e:
            raise RuntimeError(f"Failed to start FFmpeg: {e}")

    def read(self) -> Optional[bytes]:
        if not self._stdout:
            return None

        # Read Opus packet (variable size, typically ~120 bytes for 20ms)
        # We need to parse Ogg container or use raw opus
        # For simplicity, read fixed size
        data = self._stdout.read(4096)
        if not data:
            return None

        return data

    def is_opus(self) -> bool:
        return True

    def cleanup(self) -> None:
        if self._process:
            try:
                self._process.kill()
                self._process.wait(timeout=2)
            except Exception:
                pass
            self._process = None

        if self._stdout:
            self._stdout.close()
            self._stdout = None


class PCMVolumeTransformer(AudioSource):
    """
    Transforms audio volume for PCM sources

    Args:
        original: Original audio source
        volume: Volume level (0.0 to 2.0, default 1.0)

    Example:
        source = FFmpegAudio('song.mp3')
        source = PCMVolumeTransformer(source, volume=0.5)
        await voice_client.play(source)
    """

    def __init__(self, original: AudioSource, volume: float = 1.0):
        if original.is_opus():
            raise ValueError("Cannot transform Opus audio volume")

        self.original = original
        self._volume = max(0.0, min(volume, 2.0))

    @property
    def volume(self) -> float:
        """Current volume level"""
        return self._volume

    @volume.setter
    def volume(self, value: float):
        """Set volume level (0.0 to 2.0)"""
        self._volume = max(0.0, min(value, 2.0))

    def read(self) -> Optional[bytes]:
        data = self.original.read()
        if data is None:
            return None

        # Transform volume
        if self._volume != 1.0:
            # audioop.mul requires factor as integer
            # Factor of 256 = 1.0 volume
            factor = int(self._volume * 256)
            data = audioop.mul(data, 2, factor)  # 2 = 16-bit samples

        return data

    def cleanup(self) -> None:
        self.original.cleanup()


class AudioBuffer(AudioSource):
    """
    In-memory audio buffer

    Useful for short sounds or pre-loaded audio.

    Args:
        data: Raw PCM audio data

    Example:
        # Load audio into memory
        with open('sound.pcm', 'rb') as f:
            data = f.read()

        source = AudioBuffer(data)
        await voice_client.play(source)
    """

    def __init__(self, data: bytes):
        self.data = data
        self.position = 0

    def read(self) -> Optional[bytes]:
        if self.position >= len(self.data):
            return None

        end = self.position + PCMAudio.FRAME_SIZE
        frame = self.data[self.position : end]

        if len(frame) < PCMAudio.FRAME_SIZE:
            # Pad with silence
            frame += b"\x00" * (PCMAudio.FRAME_SIZE - len(frame))

        self.position = end
        return frame

    def seek(self, position: int = 0):
        """Seek to position in bytes"""
        self.position = max(0, min(position, len(self.data)))

    def reset(self):
        """Reset to beginning"""
        self.position = 0


class SilenceSource(AudioSource):
    """
    Silent audio source

    Generates silence for specified duration.

    Args:
        duration: Duration in seconds (None = infinite)

    Example:
        # Play 5 seconds of silence
        source = SilenceSource(5.0)
        await voice_client.play(source)
    """

    SILENCE_FRAME = b"\x00" * PCMAudio.FRAME_SIZE

    def __init__(self, duration: Optional[float] = None):
        self.duration = duration
        self.frames_sent = 0

        if duration is not None:
            # Calculate total frames (50 frames per second)
            self.total_frames = int(duration * 50)
        else:
            self.total_frames = None

    def read(self) -> Optional[bytes]:
        if self.total_frames is not None and self.frames_sent >= self.total_frames:
            return None

        self.frames_sent += 1
        return self.SILENCE_FRAME


# Helper functions


def create_audio_source(
    source: Union[str, Path, BinaryIO], *, volume: Optional[float] = None, **kwargs
) -> AudioSource:
    """
    Create appropriate audio source from input

    Automatically detects source type and creates suitable AudioSource.

    Args:
        source: File path, URL, or file-like object
        volume: Optional volume level (0.0 to 2.0)
        **kwargs: Additional arguments for source

    Returns:
        AudioSource instance

    Example:
        # From file
        source = create_audio_source('song.mp3', volume=0.8)

        # From URL
        source = create_audio_source('https://example.com/audio.mp3')

        # From file object
        with open('audio.pcm', 'rb') as f:
            source = create_audio_source(f)
    """
    audio: AudioSource

    # File-like object
    if hasattr(source, "read"):
        audio = PCMAudio(source)

    # File path or URL
    else:
        source_str = str(source)

        # Check if it's a URL
        if source_str.startswith(("http://", "https://", "rtmp://", "rtsp://")):
            # URL - use FFmpeg with reconnect
            audio = FFmpegAudio(
                source_str,
                before_options="-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
                **kwargs,
            )

        # Check file extension
        elif source_str.endswith(".pcm"):
            with open(source_str, "rb") as f:
                audio = PCMAudio(f)

        else:
            # Use FFmpeg for everything else
            audio = FFmpegAudio(source_str, **kwargs)

    # Apply volume if specified
    if volume is not None and not audio.is_opus():
        audio = PCMVolumeTransformer(audio, volume)

    return audio


__all__ = [
    "AudioSource",
    "PCMAudio",
    "FFmpegAudio",
    "FFmpegPCMAudio",
    "FFmpegOpusAudio",
    "PCMVolumeTransformer",
    "AudioBuffer",
    "SilenceSource",
    "create_audio_source",
]

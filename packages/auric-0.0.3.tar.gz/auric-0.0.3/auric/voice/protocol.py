"""
Voice UDP protocol for sending audio
"""

from __future__ import annotations

import logging
import socket
import struct
from typing import Optional

logger = logging.getLogger(__name__)


class VoiceProtocol:
    """
    UDP protocol for Discord voice

    Handles audio packet transmission with encryption.
    """

    RTP_HEADER_SIZE = 12

    def __init__(self, gateway, ssrc: int, ip: str, port: int):
        self.gateway = gateway
        self.ssrc = ssrc
        self.ip = ip
        self.port = port

        self.socket: Optional[socket.socket] = None
        self.sequence = 0
        self.timestamp = 0

        self._speaking = False

        # Create UDP socket
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.setblocking(False)

    def close(self) -> None:
        """Close UDP socket"""
        if self.socket:
            self.socket.close()
            self.socket = None

    def send_audio(self, data: bytes) -> None:
        """
        Send audio packet

        Args:
            data: Opus-encoded audio data (20ms frame)
        """
        if not self.socket or not self.gateway.secret_key:
            return

        # Create RTP header
        header = bytearray(self.RTP_HEADER_SIZE)

        # Version (2 bits) = 2, Padding (1 bit) = 0, Extension (1 bit) = 0
        # CSRC Count (4 bits) = 0
        header[0] = 0x80  # Version 2

        # Marker (1 bit) = 0, Payload Type (7 bits) = 78 (Opus)
        header[1] = 0x78

        # Sequence number (16 bits)
        struct.pack_into(">H", header, 2, self.sequence)

        # Timestamp (32 bits)
        struct.pack_into(">I", header, 4, self.timestamp)

        # SSRC (32 bits)
        struct.pack_into(">I", header, 8, self.ssrc)

        # Encrypt packet using xsalsa20_poly1305
        nonce = bytearray(24)
        nonce[: self.RTP_HEADER_SIZE] = header

        encrypted = self._encrypt(bytes(header) + data, bytes(nonce))

        # Send packet
        try:
            self.socket.sendto(encrypted, (self.ip, self.port))
        except Exception as e:
            logger.error(f"Error sending audio: {e}")

        # Update sequence and timestamp
        self.sequence = (self.sequence + 1) % 65536
        self.timestamp = (self.timestamp + 960) % 4294967296  # 20ms at 48kHz

    def _encrypt(self, data: bytes, nonce: bytes) -> bytes:
        """
        Encrypt data using xsalsa20_poly1305

        Note: Requires nacl library (PyNaCl)
        """
        try:
            from nacl.secret import SecretBox

            box = SecretBox(self.gateway.secret_key)
            return box.encrypt(data, nonce).ciphertext
        except ImportError:
            logger.error("PyNaCl not installed. Voice encryption unavailable.")
            return data
        except Exception as e:
            logger.error(f"Encryption error: {e}")
            return data

    async def set_speaking(self, speaking: bool) -> None:
        """
        Set speaking state

        Args:
            speaking: Whether bot is speaking
        """
        if speaking != self._speaking:
            self._speaking = speaking
            await self.gateway.speak(speaking)

    def is_speaking(self) -> bool:
        """Whether bot is currently speaking"""
        return self._speaking

"""
Voice support for Auric Discord wrapper

Provides voice connection, audio streaming, and voice state management.

This module includes:
- Voice client for connections
- Audio sources (PCM, FFmpeg, custom)
- Audio filters and effects
- Playlist management
- Voice utilities
"""

# TODO: Investigate and update the voice implementation for E2EE and DAVE.

from .filters import *
from .opus import *
from .player import *
from .playlist import *
from .protocol import *
from .region import *
from .sources import *
from .voice_client import *
from .voice_gateway import *
from .voice_utils import *


__all__ = [
    # Core
    "VoiceClient",
    "VoiceGatewayClient",
    "VoiceProtocol",
    "AudioPlayer",
    "AudioSource",
    "OpusEncoder",
    "OpusDecoder",
    "VoiceRegion",
    # Audio sources
    "PCMAudio",
    "FFmpegAudio",
    "FFmpegPCMAudio",
    "FFmpegOpusAudio",
    "PCMVolumeTransformer",
    "AudioBuffer",
    "SilenceSource",
    "create_audio_source",
    # Filters
    "AudioFilter",
    "VolumeFilter",
    "BassBoostFilter",
    "SpeedFilter",
    "NormalizeFilter",
    "FadeInFilter",
    "FadeOutFilter",
    "ChannelMixFilter",
    "TremoloFilter",
    "apply_filters",
    # Playlist
    "Playlist",
    # Utilities
    "is_ffmpeg_available",
    "get_ffmpeg_version",
    "calculate_bitrate",
    "format_duration",
    "get_audio_info",
    "download_audio",
    "create_playlist",
    "is_connected",
    "is_playing",
    "is_paused",
    "is_supported_format",
    "get_format_name",
    "SUPPORTED_FORMATS",
]

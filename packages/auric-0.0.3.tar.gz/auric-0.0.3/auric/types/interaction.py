"""
Interaction type enums and constants
"""

from enum import IntEnum


class InteractionType(IntEnum):
    """Interaction types"""

    PING = 1
    APPLICATION_COMMAND = 2
    MESSAGE_COMPONENT = 3
    APPLICATION_COMMAND_AUTOCOMPLETE = 4
    MODAL_SUBMIT = 5


class InteractionCallbackType(IntEnum):
    """Interaction callback types"""

    PONG = 1
    CHANNEL_MESSAGE_WITH_SOURCE = 4
    DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE = 5
    DEFERRED_UPDATE_MESSAGE = 6
    UPDATE_MESSAGE = 7
    APPLICATION_COMMAND_AUTOCOMPLETE_RESULT = 8
    MODAL = 9
    PREMIUM_REQUIRED = 10


class ApplicationCommandType(IntEnum):
    """Application command types"""

    CHAT_INPUT = 1  # Slash commands
    USER = 2  # User context menu
    MESSAGE = 3  # Message context menu


class ApplicationCommandOptionType(IntEnum):
    """Command option types"""

    SUB_COMMAND = 1
    SUB_COMMAND_GROUP = 2
    STRING = 3
    INTEGER = 4
    BOOLEAN = 5
    USER = 6
    CHANNEL = 7
    ROLE = 8
    MENTIONABLE = 9
    NUMBER = 10
    ATTACHMENT = 11


class TextInputStyle(IntEnum):
    """Text input styles"""

    SHORT = 1
    PARAGRAPH = 2


class ComponentType(IntEnum):
    """Component types"""

    ACTION_ROW = 1
    BUTTON = 2
    STRING_SELECT = 3
    TEXT_INPUT = 4
    USER_SELECT = 5
    ROLE_SELECT = 6
    MENTIONABLE_SELECT = 7
    CHANNEL_SELECT = 8

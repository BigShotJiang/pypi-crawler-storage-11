"""
Auric Resources - Discord API Resources
Includes all Discord API resource implementations
"""

# Auto Moderation Resources
from .auto_moderation import (
    ActionType,
    AutoModerationAction,
    AutoModerationActionMetadata,
    AutoModerationAPI,
    AutoModerationRule,
    AutoModerationTriggerMetadata,
    EventType,
    KeywordPresetType,
    TriggerType,
)

# Entitlement Resources
from .entitlement import Entitlement, EntitlementAPI, EntitlementType

# Poll Resources
from .poll import (
    Poll,
    PollAnswer,
    PollAnswerCount,
    PollAPI,
    PollCreateRequest,
    PollLayoutType,
    PollMedia,
    PollResults,
)

# SKU Resources
from .sku import SKU, SKUAPI, SKUFlags, SKUType

# Soundboard Resources
from .soundboard import SoundboardAPI, SoundboardSound

# Subscription Resources
from .subscription import Subscription, SubscriptionAPI, SubscriptionStatus

__all__ = [
    # Poll
    "Poll",
    "PollMedia",
    "PollAnswer",
    "PollResults",
    "PollAnswerCount",
    "PollCreateRequest",
    "PollLayoutType",
    "PollAPI",
    # Soundboard
    "SoundboardSound",
    "SoundboardAPI",
    # Auto Moderation
    "AutoModerationRule",
    "AutoModerationAction",
    "AutoModerationActionMetadata",
    "AutoModerationTriggerMetadata",
    "TriggerType",
    "EventType",
    "ActionType",
    "KeywordPresetType",
    "AutoModerationAPI",
    # Entitlement
    "Entitlement",
    "EntitlementType",
    "EntitlementAPI",
    # SKU
    "SKU",
    "SKUType",
    "SKUFlags",
    "SKUAPI",
    # Subscription
    "Subscription",
    "SubscriptionStatus",
    "SubscriptionAPI",
]

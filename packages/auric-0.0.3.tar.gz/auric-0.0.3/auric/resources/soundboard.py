"""
Soundboard Resource Implementation
Implements Discord Soundboard API with all structures and endpoints.
"""

from typing import List, Optional

from ..http import HTTPClient
from ..types import Snowflake


class SoundboardSound:
    """Represents a soundboard sound."""

    def __init__(self, data: dict):
        self.name: str = data["name"]
        self.sound_id: Snowflake = data["sound_id"]
        self.volume: float = data["volume"]
        self.emoji_id: Optional[Snowflake] = data.get("emoji_id")
        self.emoji_name: Optional[str] = data.get("emoji_name")
        self.guild_id: Optional[Snowflake] = data.get("guild_id")
        self.available: bool = data["available"]
        self.user: Optional[dict] = data.get("user")

    @property
    def is_default(self) -> bool:
        """Check if this is a default Discord sound."""
        return self.guild_id is None

    @property
    def cdn_url(self) -> str:
        """Get CDN URL for this sound file."""
        return f"https://cdn.discordapp.com/soundboard-sounds/{self.sound_id}"

    def __repr__(self) -> str:
        return f"<SoundboardSound id={self.sound_id} name='{self.name}' volume={self.volume}>"


class SoundboardAPI:
    """API methods for Soundboard operations."""

    def __init__(self, http: HTTPClient):
        self.http = http

    async def send_soundboard_sound(
        self,
        channel_id: Snowflake,
        sound_id: Snowflake,
        source_guild_id: Optional[Snowflake] = None,
    ) -> None:
        """
        Send a soundboard sound to a voice channel.

        Requires:
        - SPEAK and USE_SOUNDBOARD permissions
        - USE_EXTERNAL_SOUNDS if sound is from different server
        - User must be connected to voice channel
        - Voice state must not have deaf, self_deaf, mute, or suppress

        Args:
            channel_id: Voice channel ID
            sound_id: Soundboard sound ID to play
            source_guild_id: Guild ID if sound is from different server

        Fires: Voice Channel Effect Send gateway event
        """
        payload = {"sound_id": sound_id}
        if source_guild_id:
            payload["source_guild_id"] = source_guild_id

        await self.http.request(
            "POST", f"/channels/{channel_id}/send-soundboard-sound", json=payload
        )

    async def list_default_soundboard_sounds(self) -> List[SoundboardSound]:
        """
        Get all default soundboard sounds available to all users.

        Returns:
            List of default soundboard sounds
        """
        data = await self.http.request("GET", "/soundboard-default-sounds")
        return [SoundboardSound(sound) for sound in data]

    async def list_guild_soundboard_sounds(self, guild_id: Snowflake) -> List[SoundboardSound]:
        """
        Get all soundboard sounds for a guild.

        Includes user fields if bot has CREATE_GUILD_EXPRESSIONS or
        MANAGE_GUILD_EXPRESSIONS permission.

        Args:
            guild_id: Guild ID

        Returns:
            List of guild soundboard sounds
        """
        data = await self.http.request("GET", f"/guilds/{guild_id}/soundboard-sounds")
        return [SoundboardSound(sound) for sound in data.get("items", [])]

    async def get_guild_soundboard_sound(
        self, guild_id: Snowflake, sound_id: Snowflake
    ) -> SoundboardSound:
        """
        Get a specific guild soundboard sound.

        Includes user field if bot has CREATE_GUILD_EXPRESSIONS or
        MANAGE_GUILD_EXPRESSIONS permission.

        Args:
            guild_id: Guild ID
            sound_id: Sound ID

        Returns:
            Soundboard sound object
        """
        data = await self.http.request("GET", f"/guilds/{guild_id}/soundboard-sounds/{sound_id}")
        return SoundboardSound(data)

    async def create_guild_soundboard_sound(
        self,
        guild_id: Snowflake,
        name: str,
        sound: str,
        volume: Optional[float] = 1.0,
        emoji_id: Optional[Snowflake] = None,
        emoji_name: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> SoundboardSound:
        """
        Create a new soundboard sound for the guild.

        Requires: CREATE_GUILD_EXPRESSIONS permission

        Note:
        - Max file size: 512kb
        - Max duration: 5.2 seconds
        - Name: 2-32 characters
        - Sound must be base64 encoded MP3 or OGG data URI

        Args:
            guild_id: Guild ID
            name: Sound name (2-32 characters)
            sound: Base64 encoded MP3/OGG data URI
            volume: Sound volume (0.0-1.0)
            emoji_id: Custom emoji ID
            emoji_name: Standard emoji unicode
            reason: Audit log reason

        Returns:
            Created soundboard sound

        Fires: Guild Soundboard Sound Create gateway event
        """
        if len(name) < 2 or len(name) > 32:
            raise ValueError("Sound name must be 2-32 characters")
        if volume is not None and (volume < 0 or volume > 1):
            raise ValueError("Volume must be between 0 and 1")

        payload = {"name": name, "sound": sound}
        if volume is not None:
            payload["volume"] = volume
        if emoji_id:
            payload["emoji_id"] = emoji_id
        if emoji_name:
            payload["emoji_name"] = emoji_name

        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        data = await self.http.request(
            "POST", f"/guilds/{guild_id}/soundboard-sounds", json=payload, headers=headers
        )
        return SoundboardSound(data)

    async def modify_guild_soundboard_sound(
        self,
        guild_id: Snowflake,
        sound_id: Snowflake,
        name: Optional[str] = None,
        volume: Optional[float] = None,
        emoji_id: Optional[Snowflake] = None,
        emoji_name: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> SoundboardSound:
        """
        Modify a guild soundboard sound.

        Requires:
        - For own sounds: CREATE_GUILD_EXPRESSIONS or MANAGE_GUILD_EXPRESSIONS
        - For other sounds: MANAGE_GUILD_EXPRESSIONS

        Args:
            guild_id: Guild ID
            sound_id: Sound ID
            name: New sound name (2-32 characters)
            volume: New volume (0.0-1.0)
            emoji_id: New custom emoji ID (use explicit None to remove)
            emoji_name: New standard emoji (use explicit None to remove)
            reason: Audit log reason

        Returns:
            Updated soundboard sound

        Fires: Guild Soundboard Sound Update gateway event
        """
        if name is not None and (len(name) < 2 or len(name) > 32):
            raise ValueError("Sound name must be 2-32 characters")
        if volume is not None and (volume < 0 or volume > 1):
            raise ValueError("Volume must be between 0 and 1")

        payload = {}
        if name is not None:
            payload["name"] = name
        if volume is not None:
            payload["volume"] = volume
        if emoji_id is not None:
            payload["emoji_id"] = emoji_id
        if emoji_name is not None:
            payload["emoji_name"] = emoji_name

        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        data = await self.http.request(
            "PATCH",
            f"/guilds/{guild_id}/soundboard-sounds/{sound_id}",
            json=payload,
            headers=headers,
        )
        return SoundboardSound(data)

    async def delete_guild_soundboard_sound(
        self, guild_id: Snowflake, sound_id: Snowflake, reason: Optional[str] = None
    ) -> None:
        """
        Delete a guild soundboard sound.

        Requires:
        - For own sounds: CREATE_GUILD_EXPRESSIONS or MANAGE_GUILD_EXPRESSIONS
        - For other sounds: MANAGE_GUILD_EXPRESSIONS

        Args:
            guild_id: Guild ID
            sound_id: Sound ID
            reason: Audit log reason

        Fires: Guild Soundboard Sound Delete gateway event
        """
        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        await self.http.request(
            "DELETE", f"/guilds/{guild_id}/soundboard-sounds/{sound_id}", headers=headers
        )

# Auto Moderation API - Complete Implementation
# Based on discord-api-docs-main/docs/resources/auto-moderation.mdx

from enum import IntEnum
from typing import List, Optional

from ..http import HTTPClient
from ..types import Snowflake


class TriggerType(IntEnum):
    KEYWORD = 1
    SPAM = 3
    KEYWORD_PRESET = 4
    MENTION_SPAM = 5
    MEMBER_PROFILE = 6


class EventType(IntEnum):
    MESSAGE_SEND = 1
    MEMBER_UPDATE = 2


class KeywordPresetType(IntEnum):
    PROFANITY = 1
    SEXUAL_CONTENT = 2
    SLURS = 3


class ActionType(IntEnum):
    BLOCK_MESSAGE = 1
    SEND_ALERT_MESSAGE = 2
    TIMEOUT = 3
    BLOCK_MEMBER_INTERACTION = 4


class AutoModerationTriggerMetadata:
    def __init__(self, data: dict):
        self.keyword_filter: Optional[List[str]] = data.get("keyword_filter")
        self.regex_patterns: Optional[List[str]] = data.get("regex_patterns")
        self.presets: Optional[List[int]] = data.get("presets")
        self.allow_list: Optional[List[str]] = data.get("allow_list")
        self.mention_total_limit: Optional[int] = data.get("mention_total_limit")
        self.mention_raid_protection_enabled: Optional[bool] = data.get(
            "mention_raid_protection_enabled"
        )

    def to_dict(self) -> dict:
        result = {}
        if self.keyword_filter is not None:
            result["keyword_filter"] = self.keyword_filter
        if self.regex_patterns is not None:
            result["regex_patterns"] = self.regex_patterns
        if self.presets is not None:
            result["presets"] = self.presets
        if self.allow_list is not None:
            result["allow_list"] = self.allow_list
        if self.mention_total_limit is not None:
            result["mention_total_limit"] = self.mention_total_limit
        if self.mention_raid_protection_enabled is not None:
            result["mention_raid_protection_enabled"] = self.mention_raid_protection_enabled
        return result


class AutoModerationActionMetadata:
    def __init__(self, data: dict):
        self.channel_id: Optional[Snowflake] = data.get("channel_id")
        self.duration_seconds: Optional[int] = data.get("duration_seconds")
        self.custom_message: Optional[str] = data.get("custom_message")

    def to_dict(self) -> dict:
        result = {}
        if self.channel_id is not None:
            result["channel_id"] = self.channel_id
        if self.duration_seconds is not None:
            result["duration_seconds"] = self.duration_seconds
        if self.custom_message is not None:
            result["custom_message"] = self.custom_message
        return result


class AutoModerationAction:
    def __init__(self, data: dict):
        self.type: ActionType = ActionType(data["type"])
        self.metadata: Optional[AutoModerationActionMetadata] = None
        if "metadata" in data:
            self.metadata = AutoModerationActionMetadata(data["metadata"])

    def to_dict(self) -> dict:
        result = {"type": self.type.value}
        if self.metadata:
            result["metadata"] = self.metadata.to_dict()
        return result


class AutoModerationRule:
    def __init__(self, data: dict):
        self.id: Snowflake = data["id"]
        self.guild_id: Snowflake = data["guild_id"]
        self.name: str = data["name"]
        self.creator_id: Snowflake = data["creator_id"]
        self.event_type: EventType = EventType(data["event_type"])
        self.trigger_type: TriggerType = TriggerType(data["trigger_type"])
        self.trigger_metadata: AutoModerationTriggerMetadata = AutoModerationTriggerMetadata(
            data.get("trigger_metadata", {})
        )
        self.actions: List[AutoModerationAction] = [
            AutoModerationAction(a) for a in data.get("actions", [])
        ]
        self.enabled: bool = data["enabled"]
        self.exempt_roles: List[Snowflake] = data.get("exempt_roles", [])
        self.exempt_channels: List[Snowflake] = data.get("exempt_channels", [])


class AutoModerationAPI:
    def __init__(self, http: HTTPClient):
        self.http = http

    async def list_auto_moderation_rules(self, guild_id: Snowflake) -> List[AutoModerationRule]:
        data = await self.http.request("GET", f"/guilds/{guild_id}/auto-moderation/rules")
        return [AutoModerationRule(rule) for rule in data]

    async def get_auto_moderation_rule(
        self, guild_id: Snowflake, rule_id: Snowflake
    ) -> AutoModerationRule:
        data = await self.http.request("GET", f"/guilds/{guild_id}/auto-moderation/rules/{rule_id}")
        return AutoModerationRule(data)

    async def create_auto_moderation_rule(
        self,
        guild_id: Snowflake,
        name: str,
        event_type: EventType,
        trigger_type: TriggerType,
        trigger_metadata: AutoModerationTriggerMetadata,
        actions: List[AutoModerationAction],
        enabled: bool = True,
        exempt_roles: Optional[List[Snowflake]] = None,
        exempt_channels: Optional[List[Snowflake]] = None,
        reason: Optional[str] = None,
    ) -> AutoModerationRule:
        payload = {
            "name": name,
            "event_type": event_type.value,
            "trigger_type": trigger_type.value,
            "trigger_metadata": trigger_metadata.to_dict(),
            "actions": [a.to_dict() for a in actions],
            "enabled": enabled,
        }
        if exempt_roles:
            payload["exempt_roles"] = exempt_roles
        if exempt_channels:
            payload["exempt_channels"] = exempt_channels

        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        data = await self.http.request(
            "POST", f"/guilds/{guild_id}/auto-moderation/rules", json=payload, headers=headers
        )
        return AutoModerationRule(data)

    async def modify_auto_moderation_rule(
        self,
        guild_id: Snowflake,
        rule_id: Snowflake,
        name: Optional[str] = None,
        event_type: Optional[EventType] = None,
        trigger_metadata: Optional[AutoModerationTriggerMetadata] = None,
        actions: Optional[List[AutoModerationAction]] = None,
        enabled: Optional[bool] = None,
        exempt_roles: Optional[List[Snowflake]] = None,
        exempt_channels: Optional[List[Snowflake]] = None,
        reason: Optional[str] = None,
    ) -> AutoModerationRule:
        payload = {}
        if name is not None:
            payload["name"] = name
        if event_type is not None:
            payload["event_type"] = event_type.value
        if trigger_metadata is not None:
            payload["trigger_metadata"] = trigger_metadata.to_dict()
        if actions is not None:
            payload["actions"] = [a.to_dict() for a in actions]
        if enabled is not None:
            payload["enabled"] = enabled
        if exempt_roles is not None:
            payload["exempt_roles"] = exempt_roles
        if exempt_channels is not None:
            payload["exempt_channels"] = exempt_channels

        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        data = await self.http.request(
            "PATCH",
            f"/guilds/{guild_id}/auto-moderation/rules/{rule_id}",
            json=payload,
            headers=headers,
        )
        return AutoModerationRule(data)

    async def delete_auto_moderation_rule(
        self, guild_id: Snowflake, rule_id: Snowflake, reason: Optional[str] = None
    ) -> None:
        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason
        await self.http.request(
            "DELETE", f"/guilds/{guild_id}/auto-moderation/rules/{rule_id}", headers=headers
        )

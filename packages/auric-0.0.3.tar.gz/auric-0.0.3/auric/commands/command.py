"""
Command - Base command class for Auric bot commands
"""

from __future__ import annotations

from typing import Any, Callable, Optional


class Command:
    """
    Base command class.

    Represents a bot command that can be invoked.
    """

    __slots__ = ("name", "callback", "description", "aliases", "enabled")

    def __init__(
        self,
        name: str,
        callback: Callable,
        description: Optional[str] = None,
        aliases: Optional[list[str]] = None,
        enabled: bool = True,
    ) -> None:
        """
        Initialize a command.

        Parameters
        ----------
        name : str
            The command name.
        callback : Callable
            The function to call when the command is invoked.
        description : str | None
            Command description.
        aliases : list[str] | None
            Alternative names for the command.
        enabled : bool
            Whether the command is enabled.
        """
        self.name = name
        self.callback = callback
        self.description = description or "No description provided"
        self.aliases = aliases or []
        self.enabled = enabled

    async def invoke(self, *args, **kwargs) -> Any:
        """
        Invoke the command.

        Returns
        -------
        Any
            The result of the command callback.
        """
        return await self.callback(*args, **kwargs)

    def __repr__(self) -> str:
        return f"<Command name={self.name!r}>"


class Group(Command):
    """
    Command group - a command that can have subcommands.
    """

    __slots__ = ("commands",)

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.commands: dict[str, Command] = {}

    def add_command(self, command: Command) -> None:
        """Add a subcommand to this group."""
        self.commands[command.name] = command

    def remove_command(self, name: str) -> Optional[Command]:
        """Remove and return a subcommand."""
        return self.commands.pop(name, None)

    def get_command(self, name: str) -> Optional[Command]:
        """Get a subcommand by name."""
        return self.commands.get(name)

    def __repr__(self) -> str:
        return f"<Group name={self.name!r} commands={len(self.commands)}>"


__all__ = ("Command", "Group")

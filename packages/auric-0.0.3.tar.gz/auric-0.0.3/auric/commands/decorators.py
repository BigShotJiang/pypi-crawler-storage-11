"""
Command decorators - Decorators for command creation and checks
"""

from typing import Any, Callable, List, Optional, Union

from .command import Command, Group


def command(
    name: Optional[str] = None,
    *,
    description: Optional[str] = None,
    aliases: Optional[List[str]] = None,
    enabled: bool = True,
    hidden: bool = False,
    help: Optional[str] = None,
):
    """
    Decorator to create a command.

    Args:
        name: Command name (defaults to function name)
        description: Command description
        aliases: Alternative names
        enabled: Whether command is enabled
        hidden: Whether to hide from help
        help: Extended help text

    Example:
        ```python
        @bot.command(name='hello', aliases=['hi', 'hey'])
        async def hello_command(ctx):
            '''Say hello'''
            await ctx.send("Hello!")
        ```
    """

    def decorator(func: Callable) -> Command:
        cmd = Command(
            name=name or func.__name__,
            callback=func,
            description=description,
            aliases=aliases,
            enabled=enabled,
        )
        return cmd

    return decorator


def option(
    name: str,
    description: str = "No description",
    *,
    required: bool = False,
    choices: Optional[List[Any]] = None,
    **kwargs,
):
    """
    Decorator to add an option to a command.

    Args:
        name: Option name
        description: Option description
        required: Whether the option is required
        choices: List of valid choices
    """

    def decorator(func: Callable) -> Callable:
        if not hasattr(func, "__command_options__"):
            func.__command_options__ = []
        func.__command_options__.append(
            {
                "name": name,
                "description": description,
                "required": required,
                "choices": choices,
                **kwargs,
            }
        )
        return func

    return decorator


def permission(*perms):
    """
    Decorator to require specific permissions.

    Args:
        *perms: Permission names or values
    """

    def decorator(func: Callable) -> Callable:
        if not hasattr(func, "__required_permissions__"):
            func.__required_permissions__ = []
        func.__required_permissions__.extend(perms)
        return func

    return decorator


def group(
    name: Optional[str] = None,
    *,
    description: Optional[str] = None,
    aliases: Optional[List[str]] = None,
    enabled: bool = True,
    hidden: bool = False,
    help: Optional[str] = None,
):
    """
    Decorator to create a command group.

    Groups can have subcommands.

    Args:
        name: Group name (defaults to function name)
        description: Group description
        aliases: Alternative names
        enabled: Whether group is enabled
        hidden: Whether to hide from help
        help: Extended help text

    Example:
        ```python
        @bot.group()
        async def config(ctx):
            '''Configuration commands'''
            pass

        @config.command()
        async def set(ctx, key, value):
            '''Set a config value'''
            await ctx.send(f"Set {key} = {value}")
        ```
    """

    def decorator(func: Callable) -> Group:
        cmd = Group(
            func,
            name=name,
            description=description,
            aliases=aliases,
            enabled=enabled,
            hidden=hidden,
            help=help,
        )
        return cmd

    return decorator


def check(predicate: Callable) -> Callable:
    """
    Decorator to add a check to a command.

    Args:
        predicate: Function that takes ctx and returns bool

    Example:
        ```python
        def is_owner(ctx):
            return ctx.author.id == 123456789

        @bot.command()
        @check(is_owner)
        async def admin(ctx):
            await ctx.send("Admin only!")
        ```
    """

    def decorator(func: Union[Command, Callable]) -> Union[Command, Callable]:
        if isinstance(func, Command):
            func.add_check(predicate)
        else:
            # Store checks on function for later
            if not hasattr(func, "__command_checks__"):
                func.__command_checks__ = []
            func.__command_checks__.append(predicate)
        return func

    return decorator


def has_role(role_id: int) -> Callable:
    """
    Check if user has a specific role.

    Args:
        role_id: Role ID to check for

    Example:
        ```python
        @bot.command()
        @has_role(123456789)
        async def moderator(ctx):
            await ctx.send("Moderator command!")
        ```
    """

    def predicate(ctx) -> bool:
        if not ctx.guild or not hasattr(ctx.author, "roles"):
            return False
        return any(role.id == role_id for role in ctx.author.roles)

    return check(predicate)


def has_permissions(**perms: bool) -> Callable:
    """
    Check if user has specific permissions.

    Args:
        **perms: Permission flags (e.g., manage_guild=True)

    Example:
        ```python
        @bot.command()
        @has_permissions(manage_guild=True, ban_members=True)
        async def ban(ctx, user):
            await ctx.send(f"Banning {user}...")
        ```
    """

    def predicate(ctx) -> bool:
        if not ctx.guild:
            return False

        permissions = ctx.channel.permissions_for(ctx.author)
        return all(getattr(permissions, perm, False) == value for perm, value in perms.items())

    return check(predicate)


def bot_has_permissions(**perms: bool) -> Callable:
    """
    Check if bot has specific permissions.

    Args:
        **perms: Permission flags

    Example:
        ```python
        @bot.command()
        @bot_has_permissions(ban_members=True)
        async def ban(ctx, user):
            await ctx.send(f"Banning {user}...")
        ```
    """

    def predicate(ctx) -> bool:
        if not ctx.guild or not ctx.me:
            return False

        permissions = ctx.channel.permissions_for(ctx.me)
        return all(getattr(permissions, perm, False) == value for perm, value in perms.items())

    return check(predicate)


def is_owner() -> Callable:
    """
    Check if user is the bot owner.

    Example:
        ```python
        @bot.command()
        @is_owner()
        async def shutdown(ctx):
            await ctx.send("Shutting down...")
            await ctx.bot.close()
        ```
    """

    def predicate(ctx) -> bool:
        if hasattr(ctx.bot, "owner_id"):
            return ctx.author.id == ctx.bot.owner_id
        if hasattr(ctx.bot, "owner_ids"):
            return ctx.author.id in ctx.bot.owner_ids
        return False

    return check(predicate)


def guild_only() -> Callable:
    """
    Command can only be used in guilds (not DMs).

    Example:
        ```python
        @bot.command()
        @guild_only()
        async def server_info(ctx):
            await ctx.send(f"Server: {ctx.guild.name}")
        ```
    """

    def predicate(ctx) -> bool:
        return ctx.guild is not None

    return check(predicate)


def dm_only() -> Callable:
    """
    Command can only be used in DMs.

    Example:
        ```python
        @bot.command()
        @dm_only()
        async def privacy(ctx):
            await ctx.send("This is private!")
        ```
    """

    def predicate(ctx) -> bool:
        return ctx.guild is None

    return check(predicate)


class Cooldown:
    """
    Cooldown tracker for commands.

    Attributes:
        rate: Number of invocations allowed
        per: Time period in seconds
        type: Cooldown type (user, guild, channel, global)
    """

    def __init__(self, rate: int, per: float, type: str = "user"):
        self.rate = rate
        self.per = per
        self.type = type
        self._cache: dict = {}

    def get_key(self, ctx) -> Any:
        """Get cache key for this context"""
        if self.type == "user":
            return ctx.author.id
        elif self.type == "guild":
            return ctx.guild.id if ctx.guild else None
        elif self.type == "channel":
            return ctx.channel.id
        elif self.type == "global":
            return "global"
        return None

    def is_rate_limited(self, ctx) -> bool:
        """Check if this context is rate limited"""
        import time

        key = self.get_key(ctx)
        if key is None:
            return False

        now = time.time()

        if key not in self._cache:
            self._cache[key] = []

        # Remove old timestamps
        self._cache[key] = [ts for ts in self._cache[key] if now - ts < self.per]

        # Check if rate limited
        if len(self._cache[key]) >= self.rate:
            return True

        # Add new timestamp
        self._cache[key].append(now)
        return False


def cooldown(rate: int, per: float, type: str = "user") -> Callable:
    """
    Add a cooldown to a command.

    Args:
        rate: Number of times command can be used
        per: Time period in seconds
        type: Cooldown type (user, guild, channel, global)

    Example:
        ```python
        @bot.command()
        @cooldown(1, 60.0)  # Once per minute
        async def daily(ctx):
            await ctx.send("Here's your daily reward!")
        ```
    """
    cd = Cooldown(rate, per, type)

    def predicate(ctx) -> bool:
        return not cd.is_rate_limited(ctx)

    def decorator(func: Union[Command, Callable]) -> Union[Command, Callable]:
        if isinstance(func, Command):
            func.cooldown = {"rate": rate, "per": per, "type": type}
            func.add_check(predicate)
        else:
            if not hasattr(func, "__command_checks__"):
                func.__command_checks__ = []
            func.__command_checks__.append(predicate)
            func.__command_cooldown__ = {"rate": rate, "per": per, "type": type}
        return func

    return decorator

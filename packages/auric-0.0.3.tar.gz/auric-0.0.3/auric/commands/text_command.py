"""
Command - Represents a bot command
"""

from __future__ import annotations

import asyncio
import inspect
from typing import Any, Awaitable, Callable, Dict, List, Optional


class Command:
    """
    Represents a bot command.

    Attributes:
        name: Command name
        callback: The async function to call
        description: Command description
        aliases: Alternative names for the command
        enabled: Whether the command is enabled
        hidden: Whether to hide from help
        checks: List of check functions
        cooldown: Cooldown configuration
        help: Extended help text

    Example:
        ```python
        async def hello_func(ctx):
            await ctx.send("Hello!")

        command = Command(
            name="hello",
            callback=hello_func,
            description="Says hello"
        )
        ```
    """

    __slots__ = (
        "name",
        "callback",
        "description",
        "aliases",
        "enabled",
        "hidden",
        "checks",
        "cooldown",
        "help",
        "_usage",
        "_params",
    )

    def __init__(
        self,
        callback: Callable[[Any], Awaitable[Any]],
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        aliases: Optional[List[str]] = None,
        enabled: bool = True,
        hidden: bool = False,
        help: Optional[str] = None,
    ):
        self.callback = callback
        self.name = name or callback.__name__
        self.description = description or callback.__doc__ or "No description"
        self.aliases = aliases or []
        self.enabled = enabled
        self.hidden = hidden
        self.help = help or self.description
        self.checks: List[Callable] = []
        self.cooldown: Optional[Dict[str, Any]] = None

        # Parse parameters from function signature
        self._params = self._parse_parameters()
        self._usage = self._generate_usage()

    def _parse_parameters(self) -> List[inspect.Parameter]:
        """Parse command parameters from function signature"""
        sig = inspect.signature(self.callback)
        params = []

        for param_name, param in sig.parameters.items():
            # Skip 'self' and 'ctx'
            if param_name in ("self", "ctx"):
                continue
            params.append(param)

        return params

    def _generate_usage(self) -> str:
        """Generate usage string from parameters"""
        if not self._params:
            return self.name

        usage_parts = [self.name]
        for param in self._params:
            if param.default == inspect.Parameter.empty:
                # Required parameter
                usage_parts.append(f"<{param.name}>")
            else:
                # Optional parameter
                usage_parts.append(f"[{param.name}]")

        return " ".join(usage_parts)

    @property
    def usage(self) -> str:
        """Command usage string"""
        return self._usage

    @property
    def qualified_name(self) -> str:
        """Qualified command name (includes parent for subcommands)"""
        return self.name

    @property
    def signature(self) -> str:
        """Command signature (parameters only)"""
        if not self._params:
            return ""

        parts = []
        for param in self._params:
            if param.default == inspect.Parameter.empty:
                parts.append(f"<{param.name}>")
            else:
                parts.append(f"[{param.name}]")

        return " ".join(parts)

    def add_check(self, check: Callable) -> Command:
        """
        Add a check to this command.

        Args:
            check: Check function (async or sync)

        Returns:
            Self for chaining
        """
        self.checks.append(check)
        return self

    async def can_run(self, ctx) -> bool:
        """
        Check if the command can be run in this context.

        Args:
            ctx: Command context

        Returns:
            True if all checks pass

        Raises:
            CheckFailure: If a check fails
        """
        if not self.enabled:
            return False

        for check in self.checks:
            if asyncio.iscoroutinefunction(check):
                result = await check(ctx)
            else:
                result = check(ctx)

            if not result:
                return False

        return True

    async def invoke(self, ctx) -> Any:
        """
        Invoke the command.

        Args:
            ctx: Command context

        Returns:
            Command result
        """
        if not await self.can_run(ctx):
            raise RuntimeError(f"Command {self.name} cannot be run")

        # Parse arguments from ctx.args based on parameters
        args = []
        kwargs = {}

        # Simple argument parsing - can be enhanced
        for i, param in enumerate(self._params):
            if i < len(ctx.args):
                value = ctx.args[i]
                # Type conversion could go here
                args.append(value)
            elif param.default != inspect.Parameter.empty:
                # Use default value
                args.append(param.default)

        # Call the command
        return await self.callback(ctx, *args, **kwargs)

    async def __call__(self, ctx, *args, **kwargs):
        """Allow command to be called directly"""
        return await self.callback(ctx, *args, **kwargs)

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"<Command name={self.name!r}>"


class Group(Command):
    """
    A command that can have subcommands.

    Example:
        ```python
        @bot.group()
        async def config(ctx):
            '''Configuration commands'''
            if ctx.invoked_subcommand is None:
                await ctx.send("Use a subcommand!")

        @config.command()
        async def set(ctx, key, value):
            '''Set a config value'''
            await ctx.send(f"Set {key} = {value}")
        ```
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.commands: Dict[str, Command] = {}

    def add_command(self, command: Command) -> None:
        """Add a subcommand"""
        self.commands[command.name] = command
        for alias in command.aliases:
            self.commands[alias] = command

    def remove_command(self, name: str) -> Optional[Command]:
        """Remove a subcommand"""
        return self.commands.pop(name, None)

    def get_command(self, name: str) -> Optional[Command]:
        """Get a subcommand by name"""
        return self.commands.get(name)

    def command(self, **kwargs):
        """
        Decorator to add a subcommand.

        Example:
            @group.command()
            async def subcommand(ctx):
                pass
        """

        def decorator(func):
            cmd = Command(func, **kwargs)
            self.add_command(cmd)
            return cmd

        return decorator

    async def invoke(self, ctx) -> Any:
        """Invoke the group or its subcommand"""
        # Check if there's a subcommand
        if ctx.args and ctx.args[0] in self.commands:
            subcommand_name = ctx.args[0]
            subcommand = self.commands[subcommand_name]

            # Create new context with remaining args
            ctx.invoked_subcommand = subcommand
            ctx.args = ctx.args[1:]

            return await subcommand.invoke(ctx)
        else:
            ctx.invoked_subcommand = None
            return await super().invoke(ctx)

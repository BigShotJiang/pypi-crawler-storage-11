"""
Command context - Context object passed to command callbacks
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional, Union

if TYPE_CHECKING:
    from ..core.client import Client
    from ..models.channel import DMChannel, TextChannel
    from ..models.embed import Embed
    from ..models.guild import Guild
    from ..models.member import Member
    from ..models.message import Message
    from ..models.user import User
    from ..utils.file import File


class Context:
    """
    Represents the context in which a command is being invoked.

    This is passed as the first argument to all command callbacks.

    Attributes:
        bot: The bot instance
        message: The message that triggered the command
        command: The command that was invoked
        args: Positional arguments passed to the command
        kwargs: Keyword arguments passed to the command
        prefix: The prefix used to invoke the command
        invoked_with: The command name or alias used

    Example:
        ```python
        @bot.command()
        async def hello(ctx):
            await ctx.send(f"Hello {ctx.author.name}!")
        ```
    """

    __slots__ = ("bot", "message", "command", "args", "kwargs", "prefix", "invoked_with", "_state")

    def __init__(
        self,
        *,
        bot: Client,
        message: Message,
        command: Optional[Any] = None,
        prefix: str = "!",
        invoked_with: str = "",
        args: tuple = (),
        kwargs: dict = None,
    ):
        self.bot = bot
        self.message = message
        self.command = command
        self.prefix = prefix
        self.invoked_with = invoked_with
        self.args = args
        self.kwargs = kwargs or {}
        self._state = getattr(message, "_state", bot)

    # Convenience properties

    @property
    def author(self) -> Union[User, Member]:
        """The user/member who invoked the command"""
        return self.message.author

    @property
    def guild(self) -> Optional[Guild]:
        """The guild the command was invoked in (None in DMs)"""
        return self.message.guild

    @property
    def channel(self) -> Union[TextChannel, DMChannel]:
        """The channel the command was invoked in"""
        # Get channel from message or fetch from bot's cache
        if hasattr(self.message, "channel"):
            return self.message.channel

        # Fallback: Get channel from bot's cache using channel_id
        if hasattr(self.message, "channel_id"):
            channel_id = self.message.channel_id
            if channel_id in self.bot._channels:
                return self.bot._channels[channel_id]

            # Create a basic channel object if not cached
            from ..models.channel import TextChannel

            channel_data = {"id": str(channel_id), "type": 0}
            if hasattr(self.message, "guild_id") and self.message.guild_id:
                channel_data["guild_id"] = str(self.message.guild_id)

            channel = TextChannel(data=channel_data, http=self.bot._http)
            self.bot._channels[channel_id] = channel
            return channel

        return None

    @property
    def me(self) -> Optional[Member]:
        """The bot's member object in the guild (None in DMs)"""
        if self.guild:
            return self.guild.me
        return None

    @property
    def voice_client(self) -> Optional[Any]:
        """The voice client connected to this guild (if any)"""
        if self.guild:
            return self.guild.voice_client
        return None

    # Message sending helpers

    async def send(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Embed] = None,
        embeds: Optional[List[Embed]] = None,
        file: Optional[File] = None,
        files: Optional[List[File]] = None,
        delete_after: Optional[float] = None,
        reference: Optional[Message] = None,
        mention_author: bool = True,
        **kwargs,
    ) -> Message:
        """
        Send a message to the channel.

        Args:
            content: Message content
            embed: Single embed
            embeds: List of embeds
            file: Single file
            files: List of files
            delete_after: Seconds to wait before deleting
            reference: Message to reply to
            mention_author: Whether to mention the author in reply
            **kwargs: Additional keyword arguments

        Returns:
            The sent message
        """
        # Use HTTP client directly to avoid issues with Channel.send()
        payload = {}
        if content:
            payload["content"] = content
        if embed:
            payload["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        if embeds:
            payload["embeds"] = [e.to_dict() if hasattr(e, "to_dict") else e for e in embeds]

        from ..models.message import Message as MessageModel

        result = await self.bot._http.create_message(self.channel.id, **payload)
        return MessageModel(data=result, http=self.bot._http)

    async def reply(
        self,
        content: Optional[str] = None,
        *,
        embed: Optional[Embed] = None,
        embeds: Optional[List[Embed]] = None,
        file: Optional[File] = None,
        files: Optional[List[File]] = None,
        mention_author: bool = True,
        **kwargs,
    ) -> Message:
        """
        Reply to the message that invoked the command.

        Args:
            content: Message content
            embed: Single embed
            embeds: List of embeds
            file: Single file
            files: List of files
            mention_author: Whether to mention the author
            **kwargs: Additional keyword arguments

        Returns:
            The sent message
        """
        return await self.message.reply(
            content,
            embed=embed,
            embeds=embeds,
            file=file,
            files=files,
            mention_author=mention_author,
            **kwargs,
        )

    async def typing(self):
        """
        Trigger typing indicator.

        Can be used as a context manager:
            async with ctx.typing():
                # do long operation
                await ctx.send("Done!")
        """
        return await self.channel.trigger_typing()

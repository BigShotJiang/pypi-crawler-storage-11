"""
Event handler decorators and utilities
"""

from __future__ import annotations

from functools import wraps
from typing import Any, Awaitable, Callable, Optional

EventHandler = Callable[[Any], Awaitable[None]]


def event(name: Optional[str] = None):
    """
    Decorator to mark a function as an event handler

    Args:
        name: Optional event name override. If not provided, uses function name.

    Example:
        ```python
        @client.event
        async def on_message(message):
            print(f"Message: {message.content}")

        @client.event("message_create")
        async def custom_handler(message):
            print(f"Custom: {message.content}")
        ```
    """

    def decorator(func: EventHandler) -> EventHandler:
        event_name = name or func.__name__
        if event_name.startswith("on_"):
            event_name = event_name[3:]  # Remove 'on_' prefix

        func.__event_name__ = event_name
        func.__is_event_handler__ = True

        return func

    return decorator


def once(name: Optional[str] = None):
    """
    Decorator to mark a function as a one-time event handler

    The handler will be removed after first execution.

    Example:
        ```python
        @client.once
        async def on_ready():
            print("Bot is ready!")  # Only prints once
        ```
    """

    def decorator(func: EventHandler) -> EventHandler:
        event_name = name or func.__name__
        if event_name.startswith("on_"):
            event_name = event_name[3:]

        @wraps(func)
        async def wrapper(*args, **kwargs):
            result = await func(*args, **kwargs)
            # Signal that handler should be removed
            wrapper.__remove_handler__ = True
            return result

        wrapper.__event_name__ = event_name
        wrapper.__is_event_handler__ = True
        wrapper.__is_once__ = True

        return wrapper

    return decorator


def listener(name: Optional[str] = None):
    """
    Decorator for cog event listeners

    Similar to @event but for use in cogs/plugins.

    Example:
        ```python
        class MyCog:
            @listener()
            async def on_message(self, message):
                print(message.content)
        ```
    """

    def decorator(func: EventHandler) -> EventHandler:
        event_name = name or func.__name__
        if event_name.startswith("on_"):
            event_name = event_name[3:]

        func.__event_name__ = event_name
        func.__is_listener__ = True

        return func

    return decorator


def wait_for(
    event: str, *, check: Optional[Callable[[Any], bool]] = None, timeout: Optional[float] = None
) -> Awaitable[Any]:
    """
    Wait for a specific event to occur

    Args:
        event: Event name to wait for
        check: Optional predicate to filter events
        timeout: Optional timeout in seconds

    Returns:
        Event data when condition is met

    Raises:
        asyncio.TimeoutError: If timeout is reached

    Example:
        ```python
        def check_message(msg):
            return msg.author.id == user_id and msg.channel.id == channel_id

        message = await client.wait_for('message', check=check_message, timeout=60.0)
        ```

    Note:
        This is a helper function. Actual implementation requires client integration.
    """
    # This is a placeholder - actual implementation would be in the client
    raise NotImplementedError("wait_for must be called on a client instance")


class EventDispatcher:
    """
    Event dispatcher for managing and calling event handlers

    Used internally by the client to dispatch events.
    """

    def __init__(self):
        self._handlers: dict[str, list[EventHandler]] = {}
        self._once_handlers: dict[str, list[EventHandler]] = {}

    def register(self, event_name: str, handler: EventHandler, once: bool = False) -> None:
        """Register an event handler"""
        event_name = event_name.lower()

        if once:
            if event_name not in self._once_handlers:
                self._once_handlers[event_name] = []
            self._once_handlers[event_name].append(handler)
        else:
            if event_name not in self._handlers:
                self._handlers[event_name] = []
            self._handlers[event_name].append(handler)

    def unregister(self, event_name: str, handler: EventHandler) -> bool:
        """Unregister an event handler"""
        event_name = event_name.lower()

        # Try to remove from regular handlers
        if event_name in self._handlers and handler in self._handlers[event_name]:
            self._handlers[event_name].remove(handler)
            return True

        # Try to remove from once handlers
        if event_name in self._once_handlers and handler in self._once_handlers[event_name]:
            self._once_handlers[event_name].remove(handler)
            return True

        return False

    async def dispatch(self, event_name: str, *args, **kwargs) -> None:
        """Dispatch an event to all registered handlers"""
        event_name = event_name.lower()

        # Dispatch to regular handlers
        if event_name in self._handlers:
            for handler in self._handlers[event_name]:
                try:
                    await handler(*args, **kwargs)
                except Exception as e:
                    # Log error but don't stop other handlers
                    print(f"Error in event handler for {event_name}: {e}")

        # Dispatch to once handlers and remove them
        if event_name in self._once_handlers:
            handlers = self._once_handlers[event_name].copy()
            self._once_handlers[event_name].clear()

            for handler in handlers:
                try:
                    await handler(*args, **kwargs)
                except Exception as e:
                    print(f"Error in once handler for {event_name}: {e}")

    def get_handlers(self, event_name: str) -> list[EventHandler]:
        """Get all handlers for an event"""
        event_name = event_name.lower()
        handlers = []

        if event_name in self._handlers:
            handlers.extend(self._handlers[event_name])

        if event_name in self._once_handlers:
            handlers.extend(self._once_handlers[event_name])

        return handlers

    def clear(self, event_name: Optional[str] = None) -> None:
        """Clear all handlers, or handlers for a specific event"""
        if event_name:
            event_name = event_name.lower()
            self._handlers.pop(event_name, None)
            self._once_handlers.pop(event_name, None)
        else:
            self._handlers.clear()
            self._once_handlers.clear()

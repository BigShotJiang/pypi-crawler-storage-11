"""
Base event classes for Discord gateway events
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional


class BaseEvent:
    """
    Base class for all Discord events

    All gateway events inherit from this class and provide
    structured access to event data.
    """

    __slots__ = ("_data", "timestamp")

    def __init__(self, data: Dict[str, Any]):
        self._data = data
        self.timestamp = datetime.utcnow()

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}>"

    @property
    def raw_data(self) -> Dict[str, Any]:
        """Get raw event data"""
        return self._data


class GuildEvent(BaseEvent):
    """Base class for guild-related events"""

    __slots__ = ("guild_id",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.guild_id: Optional[int] = None
        if "guild_id" in data:
            self.guild_id = int(data["guild_id"])


class ChannelEvent(GuildEvent):
    """Base class for channel-related events"""

    __slots__ = ("channel_id",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.channel_id: Optional[int] = None
        if "channel_id" in data:
            self.channel_id = int(data["channel_id"])


class MessageEvent(ChannelEvent):
    """Base class for message-related events"""

    __slots__ = ("message_id",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.message_id: Optional[int] = None
        if "id" in data:
            self.message_id = int(data["id"])
        elif "message_id" in data:
            self.message_id = int(data["message_id"])


class UserEvent(BaseEvent):
    """Base class for user-related events"""

    __slots__ = ("user_id",)

    def __init__(self, data: Dict[str, Any]):
        super().__init__(data)
        self.user_id: Optional[int] = None
        if "user" in data and "id" in data["user"]:
            self.user_id = int(data["user"]["id"])
        elif "id" in data:
            self.user_id = int(data["id"])

"""
Fluent builders for message components (buttons, select menus, etc.)
"""

from __future__ import annotations

from typing import Any, Optional, Union

from ..components.button import Button, ButtonStyle
from ..components.select import Select, SelectOption, SelectType, StringSelect


class ButtonBuilder:
    """
    Fluent builder for creating buttons.

    Example:
        button = (ButtonBuilder()
            .set_label("Click Me")
            .set_style(ButtonStyle.PRIMARY)
            .set_custom_id("my_button")
            .build())
    """

    def __init__(self):
        self._style: ButtonStyle = ButtonStyle.PRIMARY
        self._label: Optional[str] = None
        self._emoji: Optional[Union[str, dict]] = None
        self._custom_id: Optional[str] = None
        self._url: Optional[str] = None
        self._disabled: bool = False

    def set_label(self, label: str) -> ButtonBuilder:
        """Set button label (max 80 characters)"""
        if len(label) > 80:
            raise ValueError("Label must be 80 characters or less")
        self._label = label
        return self

    def set_style(self, style: ButtonStyle) -> ButtonBuilder:
        """Set button style (PRIMARY, SECONDARY, SUCCESS, DANGER, LINK)"""
        self._style = style
        return self

    def set_custom_id(self, custom_id: str) -> ButtonBuilder:
        """Set custom ID for button interactions (max 100 characters)"""
        if len(custom_id) > 100:
            raise ValueError("Custom ID must be 100 characters or less")
        self._custom_id = custom_id
        return self

    def set_url(self, url: str) -> ButtonBuilder:
        """Set URL for link buttons (automatically sets style to LINK)"""
        self._url = url
        self._style = ButtonStyle.LINK
        return self

    def set_emoji(self, emoji: Union[str, dict]) -> ButtonBuilder:
        """Set button emoji"""
        self._emoji = emoji
        return self

    def set_disabled(self, disabled: bool = True) -> ButtonBuilder:
        """Set whether button is disabled"""
        self._disabled = disabled
        return self

    def build(self) -> Button:
        """Build and return the Button object"""
        if self._style == ButtonStyle.LINK:
            if not self._url:
                raise ValueError("Link buttons must have a URL")
            if self._custom_id:
                raise ValueError("Link buttons cannot have a custom_id")
        else:
            if not self._custom_id:
                raise ValueError("Non-link buttons must have a custom_id")
            if self._url:
                raise ValueError("Non-link buttons cannot have a URL")

        return Button(
            style=self._style,
            label=self._label,
            emoji=self._emoji,
            custom_id=self._custom_id,
            url=self._url,
            disabled=self._disabled,
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary"""
        return self.build().to_dict()

    # Convenience methods for common button types
    @classmethod
    def primary(cls, label: str, custom_id: str) -> Button:
        """Create a primary (blue) button"""
        return (
            cls().set_label(label).set_custom_id(custom_id).set_style(ButtonStyle.PRIMARY).build()
        )

    @classmethod
    def secondary(cls, label: str, custom_id: str) -> Button:
        """Create a secondary (gray) button"""
        return (
            cls().set_label(label).set_custom_id(custom_id).set_style(ButtonStyle.SECONDARY).build()
        )

    @classmethod
    def success(cls, label: str, custom_id: str) -> Button:
        """Create a success (green) button"""
        return (
            cls().set_label(label).set_custom_id(custom_id).set_style(ButtonStyle.SUCCESS).build()
        )

    @classmethod
    def danger(cls, label: str, custom_id: str) -> Button:
        """Create a danger (red) button"""
        return cls().set_label(label).set_custom_id(custom_id).set_style(ButtonStyle.DANGER).build()

    @classmethod
    def link(cls, label: str, url: str) -> Button:
        """Create a link button"""
        return cls().set_label(label).set_url(url).build()


class SelectMenuBuilder:
    """
    Fluent builder for creating select menus.

    Example:
        menu = (SelectMenuBuilder()
            .set_custom_id("color_select")
            .set_placeholder("Choose a color")
            .add_option("Red", "red", emoji="🔴")
            .add_option("Green", "green", emoji="🟢")
            .add_option("Blue", "blue", emoji="🔵")
            .build())
    """

    def __init__(self, menu_type: SelectType = SelectType.STRING):
        self._type: SelectType = menu_type
        self._custom_id: Optional[str] = None
        self._options: list[SelectOption] = []
        self._placeholder: Optional[str] = None
        self._min_values: int = 1
        self._max_values: int = 1
        self._disabled: bool = False

    def set_custom_id(self, custom_id: str) -> SelectMenuBuilder:
        """Set custom ID for the select menu (max 100 characters)"""
        if len(custom_id) > 100:
            raise ValueError("Custom ID must be 100 characters or less")
        self._custom_id = custom_id
        return self

    def set_placeholder(self, placeholder: str) -> SelectMenuBuilder:
        """Set placeholder text (max 150 characters)"""
        if len(placeholder) > 150:
            raise ValueError("Placeholder must be 150 characters or less")
        self._placeholder = placeholder
        return self

    def set_min_values(self, min_values: int) -> SelectMenuBuilder:
        """Set minimum number of selections (0-25)"""
        if min_values < 0 or min_values > 25:
            raise ValueError("min_values must be between 0 and 25")
        self._min_values = min_values
        return self

    def set_max_values(self, max_values: int) -> SelectMenuBuilder:
        """Set maximum number of selections (1-25)"""
        if max_values < 1 or max_values > 25:
            raise ValueError("max_values must be between 1 and 25")
        self._max_values = max_values
        return self

    def set_disabled(self, disabled: bool = True) -> SelectMenuBuilder:
        """Set whether select menu is disabled"""
        self._disabled = disabled
        return self

    def add_option(
        self,
        label: str,
        value: str,
        *,
        description: Optional[str] = None,
        emoji: Optional[Union[str, dict]] = None,
        default: bool = False,
    ) -> SelectMenuBuilder:
        """
        Add an option to the select menu (max 25 options).

        Args:
            label: Option label (max 100 chars)
            value: Option value (max 100 chars)
            description: Option description (max 100 chars)
            emoji: Option emoji
            default: Whether this option is selected by default
        """
        if len(self._options) >= 25:
            raise ValueError("Select menus can have a maximum of 25 options")
        if len(label) > 100:
            raise ValueError("Label must be 100 characters or less")
        if len(value) > 100:
            raise ValueError("Value must be 100 characters or less")
        if description and len(description) > 100:
            raise ValueError("Description must be 100 characters or less")

        self._options.append(
            SelectOption(
                label=label, value=value, description=description, emoji=emoji, default=default
            )
        )
        return self

    def add_options(self, *options: tuple[str, str]) -> SelectMenuBuilder:
        """
        Add multiple options at once.

        Args:
            options: Tuples of (label, value)

        Example:
            builder.add_options(
                ("Red", "red"),
                ("Green", "green"),
                ("Blue", "blue")
            )
        """
        for label, value in options:
            self.add_option(label, value)
        return self

    def clear_options(self) -> SelectMenuBuilder:
        """Remove all options"""
        self._options.clear()
        return self

    def build(self) -> Select:
        """Build and return the Select object"""
        if not self._custom_id:
            raise ValueError("Select menu must have a custom_id")
        if self._type == SelectType.STRING and not self._options:
            raise ValueError("String select menus must have at least one option")
        if self._min_values > self._max_values:
            raise ValueError("min_values cannot be greater than max_values")

        if self._type == SelectType.STRING:
            return StringSelect(
                custom_id=self._custom_id,
                options=self._options,
                placeholder=self._placeholder,
                min_values=self._min_values,
                max_values=self._max_values,
                disabled=self._disabled,
            )
        else:
            return Select(
                custom_id=self._custom_id,
                placeholder=self._placeholder,
                min_values=self._min_values,
                max_values=self._max_values,
                disabled=self._disabled,
                select_type=self._type,
            )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary"""
        return self.build().to_dict()

    @classmethod
    def string_select(cls, custom_id: str, placeholder: str = "Select...") -> SelectMenuBuilder:
        """Create a string select menu builder"""
        return cls(SelectType.STRING).set_custom_id(custom_id).set_placeholder(placeholder)

    @classmethod
    def user_select(
        cls, custom_id: str, placeholder: str = "Select a user..."
    ) -> SelectMenuBuilder:
        """Create a user select menu builder"""
        return cls(SelectType.USER).set_custom_id(custom_id).set_placeholder(placeholder)

    @classmethod
    def role_select(
        cls, custom_id: str, placeholder: str = "Select a role..."
    ) -> SelectMenuBuilder:
        """Create a role select menu builder"""
        return cls(SelectType.ROLE).set_custom_id(custom_id).set_placeholder(placeholder)

    @classmethod
    def mentionable_select(
        cls, custom_id: str, placeholder: str = "Select..."
    ) -> SelectMenuBuilder:
        """Create a mentionable (user/role) select menu builder"""
        return cls(SelectType.MENTIONABLE).set_custom_id(custom_id).set_placeholder(placeholder)

    @classmethod
    def channel_select(
        cls, custom_id: str, placeholder: str = "Select a channel..."
    ) -> SelectMenuBuilder:
        """Create a channel select menu builder"""
        return cls(SelectType.CHANNEL).set_custom_id(custom_id).set_placeholder(placeholder)


class ActionRowBuilder:
    """
    Fluent builder for creating action rows (component containers).

    Action rows can contain up to 5 buttons or 1 select menu.

    Example:
        row = (ActionRowBuilder()
            .add_button(ButtonBuilder.primary("Button 1", "btn1"))
            .add_button(ButtonBuilder.secondary("Button 2", "btn2"))
            .build())
    """

    def __init__(self):
        self._components: list[Union[Button, Select]] = []

    def add_button(self, button: Button) -> ActionRowBuilder:
        """Add a button to the action row (max 5 buttons total)"""
        if len(self._components) >= 5:
            raise ValueError("Action rows can have a maximum of 5 buttons")
        if any(isinstance(c, (Select, StringSelect)) for c in self._components):
            raise ValueError("Action rows cannot mix buttons and select menus")
        self._components.append(button)
        return self

    def add_select_menu(self, select_menu: Union[Select, StringSelect]) -> ActionRowBuilder:
        """Add a select menu to the action row (max 1 select menu)"""
        if self._components:
            raise ValueError("Action rows with select menus cannot contain other components")
        self._components.append(select_menu)
        return self

    def clear_components(self) -> ActionRowBuilder:
        """Remove all components"""
        self._components.clear()
        return self

    def build(self) -> dict[str, Any]:
        """Build and return the action row data"""
        if not self._components:
            raise ValueError("Action row must have at least one component")

        return {"type": 1, "components": [c.to_dict() for c in self._components]}  # ACTION_ROW

    def to_dict(self) -> dict[str, Any]:
        """Alias for build()"""
        return self.build()

    @classmethod
    def with_buttons(cls, *buttons: Button) -> dict[str, Any]:
        """Create an action row with buttons"""
        row = cls()
        for button in buttons:
            row.add_button(button)
        return row.build()

    @classmethod
    def with_select_menu(cls, select_menu: Union[Select, StringSelect]) -> dict[str, Any]:
        """Create an action row with a select menu"""
        return cls().add_select_menu(select_menu).build()

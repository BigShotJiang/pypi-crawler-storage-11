"""
Context Menu Command Builder

Discord.js equivalent: ContextMenuCommandBuilder
"""

from enum import IntEnum
from typing import Any, Dict, Optional


class ApplicationCommandType(IntEnum):
    """Application command types"""

    CHAT_INPUT = 1
    USER = 2
    MESSAGE = 3


class ContextMenuCommandBuilder:
    """
    Build context menu commands (user and message commands)

    Discord.js equivalent: ContextMenuCommandBuilder

    Example:
        ```python
        # User context menu
        cmd = (ContextMenuCommandBuilder()
            .set_name("Get User Info")
            .set_type(ApplicationCommandType.USER)
            .set_dm_permission(True))

        # Message context menu
        cmd = (ContextMenuCommandBuilder()
            .set_name("Report Message")
            .set_type(ApplicationCommandType.MESSAGE)
            .set_default_member_permissions(0))
        ```
    """

    def __init__(self):
        self._name: Optional[str] = None
        self._type: ApplicationCommandType = ApplicationCommandType.USER
        self._default_member_permissions: Optional[str] = None
        self._dm_permission: bool = True
        self._nsfw: bool = False

    def set_name(self, name: str) -> "ContextMenuCommandBuilder":
        """
        Set command name (1-32 characters)

        Note: Context menu names are shown in UI, so use proper casing
        """
        if not 1 <= len(name) <= 32:
            raise ValueError("Name must be 1-32 characters")
        self._name = name
        return self

    def set_type(self, type: ApplicationCommandType) -> "ContextMenuCommandBuilder":
        """
        Set command type (USER or MESSAGE)

        Args:
            type: ApplicationCommandType.USER or ApplicationCommandType.MESSAGE
        """
        if type not in (ApplicationCommandType.USER, ApplicationCommandType.MESSAGE):
            raise ValueError("Context menu must be USER or MESSAGE type")
        self._type = type
        return self

    def set_default_member_permissions(
        self, permissions: Optional[int]
    ) -> "ContextMenuCommandBuilder":
        """
        Set default member permissions required to use command

        Args:
            permissions: Permissions bitfield or None for everyone
        """
        self._default_member_permissions = str(permissions) if permissions is not None else None
        return self

    def set_dm_permission(self, enabled: bool) -> "ContextMenuCommandBuilder":
        """Set whether command can be used in DMs"""
        self._dm_permission = enabled
        return self

    def set_nsfw(self, nsfw: bool) -> "ContextMenuCommandBuilder":
        """Set whether command is age-restricted"""
        self._nsfw = nsfw
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Convert to Discord API format"""
        if not self._name:
            raise ValueError("Name is required")

        data = {
            "name": self._name,
            "type": int(self._type),
            "dm_permission": self._dm_permission,
        }

        if self._default_member_permissions is not None:
            data["default_member_permissions"] = self._default_member_permissions

        if self._nsfw:
            data["nsfw"] = True

        return data

    def to_json(self) -> Dict[str, Any]:
        """Alias for to_dict()"""
        return self.to_dict()


class UserContextMenuCommandBuilder(ContextMenuCommandBuilder):
    """
    User context menu command builder

    Convenience class that sets type to USER automatically
    """

    def __init__(self):
        super().__init__()
        self._type = ApplicationCommandType.USER


class MessageContextMenuCommandBuilder(ContextMenuCommandBuilder):
    """
    Message context menu command builder

    Convenience class that sets type to MESSAGE automatically
    """

    def __init__(self):
        super().__init__()
        self._type = ApplicationCommandType.MESSAGE


__all__ = [
    "ApplicationCommandType",
    "ContextMenuCommandBuilder",
    "UserContextMenuCommandBuilder",
    "MessageContextMenuCommandBuilder",
]

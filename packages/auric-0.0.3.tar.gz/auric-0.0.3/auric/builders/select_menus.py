"""
Select Menu Builders - All 5 types of select menus

Discord.js has 5 types:
- StringSelectMenu
- UserSelectMenu
- RoleSelectMenu
- MentionableSelectMenu
- ChannelSelectMenu
"""

from enum import IntEnum
from typing import Any, Dict, List, Optional


class SelectMenuType(IntEnum):
    """Select menu types"""

    STRING = 3
    USER = 5
    ROLE = 6
    MENTIONABLE = 7
    CHANNEL = 8


class SelectOption:
    """Option for string select menus"""

    def __init__(
        self,
        label: str,
        value: str,
        *,
        description: Optional[str] = None,
        emoji: Optional[Dict[str, Any]] = None,
        default: bool = False,
    ):
        self.label = label
        self.value = value
        self.description = description
        self.emoji = emoji
        self.default = default

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        data = {"label": self.label, "value": self.value, "default": self.default}
        if self.description:
            data["description"] = self.description
        if self.emoji:
            data["emoji"] = self.emoji
        return data


class BaseSelectMenuBuilder:
    """Base class for all select menus"""

    def __init__(self, type: SelectMenuType):
        self._type = type
        self._custom_id: Optional[str] = None
        self._placeholder: Optional[str] = None
        self._min_values: int = 1
        self._max_values: int = 1
        self._disabled: bool = False

    def set_custom_id(self, custom_id: str) -> "BaseSelectMenuBuilder":
        """Set custom ID"""
        self._custom_id = custom_id
        return self

    def set_placeholder(self, placeholder: str) -> "BaseSelectMenuBuilder":
        """Set placeholder text"""
        self._placeholder = placeholder
        return self

    def set_min_values(self, min_values: int) -> "BaseSelectMenuBuilder":
        """Set minimum selections (0-25)"""
        if not 0 <= min_values <= 25:
            raise ValueError("min_values must be 0-25")
        self._min_values = min_values
        return self

    def set_max_values(self, max_values: int) -> "BaseSelectMenuBuilder":
        """Set maximum selections (1-25)"""
        if not 1 <= max_values <= 25:
            raise ValueError("max_values must be 1-25")
        self._max_values = max_values
        return self

    def set_disabled(self, disabled: bool = True) -> "BaseSelectMenuBuilder":
        """Set disabled state"""
        self._disabled = disabled
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        if not self._custom_id:
            raise ValueError("custom_id is required")

        return {
            "type": self._type,
            "custom_id": self._custom_id,
            "placeholder": self._placeholder,
            "min_values": self._min_values,
            "max_values": self._max_values,
            "disabled": self._disabled,
        }


class StringSelectMenuBuilder(BaseSelectMenuBuilder):
    """
    String select menu builder (dropdown with custom options)

    Discord.js equivalent: StringSelectMenuBuilder

    Example:
        ```python
        select = (StringSelectMenuBuilder()
            .set_custom_id("color_select")
            .set_placeholder("Choose a color")
            .add_option("Red", "red", emoji={"name": "🔴"})
            .add_option("Blue", "blue", emoji={"name": "🔵"})
            .set_min_values(1)
            .set_max_values(1))
        ```
    """

    def __init__(self):
        super().__init__(SelectMenuType.STRING)
        self._options: List[SelectOption] = []

    def add_option(
        self,
        label: str,
        value: str,
        *,
        description: Optional[str] = None,
        emoji: Optional[Dict[str, Any]] = None,
        default: bool = False,
    ) -> "StringSelectMenuBuilder":
        """Add an option"""
        if len(self._options) >= 25:
            raise ValueError("Maximum 25 options allowed")

        option = SelectOption(
            label=label, value=value, description=description, emoji=emoji, default=default
        )
        self._options.append(option)
        return self

    def add_options(self, *options: SelectOption) -> "StringSelectMenuBuilder":
        """Add multiple options"""
        for option in options:
            if len(self._options) >= 25:
                raise ValueError("Maximum 25 options allowed")
            self._options.append(option)
        return self

    def set_options(self, options: List[SelectOption]) -> "StringSelectMenuBuilder":
        """Set all options (replaces existing)"""
        if len(options) > 25:
            raise ValueError("Maximum 25 options allowed")
        self._options = options
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        if not self._options:
            raise ValueError("At least one option is required")

        data = super().to_dict()
        data["options"] = [opt.to_dict() for opt in self._options]
        return data


class UserSelectMenuBuilder(BaseSelectMenuBuilder):
    """
    User select menu builder (select users)

    Discord.js equivalent: UserSelectMenuBuilder

    Example:
        ```python
        select = (UserSelectMenuBuilder()
            .set_custom_id("user_select")
            .set_placeholder("Select users")
            .set_min_values(1)
            .set_max_values(5))
        ```
    """

    def __init__(self):
        super().__init__(SelectMenuType.USER)


class RoleSelectMenuBuilder(BaseSelectMenuBuilder):
    """
    Role select menu builder (select roles)

    Discord.js equivalent: RoleSelectMenuBuilder

    Example:
        ```python
        select = (RoleSelectMenuBuilder()
            .set_custom_id("role_select")
            .set_placeholder("Select roles")
            .set_min_values(1)
            .set_max_values(3))
        ```
    """

    def __init__(self):
        super().__init__(SelectMenuType.ROLE)


class MentionableSelectMenuBuilder(BaseSelectMenuBuilder):
    """
    Mentionable select menu builder (select users AND roles)

    Discord.js equivalent: MentionableSelectMenuBuilder

    Example:
        ```python
        select = (MentionableSelectMenuBuilder()
            .set_custom_id("mention_select")
            .set_placeholder("Select users or roles")
            .set_max_values(10))
        ```
    """

    def __init__(self):
        super().__init__(SelectMenuType.MENTIONABLE)


class ChannelSelectMenuBuilder(BaseSelectMenuBuilder):
    """
    Channel select menu builder (select channels)

    Discord.js equivalent: ChannelSelectMenuBuilder

    Example:
        ```python
        select = (ChannelSelectMenuBuilder()
            .set_custom_id("channel_select")
            .set_placeholder("Select channels")
            .set_channel_types([0, 2])  # Text and voice
            .set_max_values(5))
        ```
    """

    def __init__(self):
        super().__init__(SelectMenuType.CHANNEL)
        self._channel_types: Optional[List[int]] = None

    def set_channel_types(self, types: List[int]) -> "ChannelSelectMenuBuilder":
        """
        Set allowed channel types

        Args:
            types: List of channel type integers
                   0=text, 2=voice, 4=category, 5=announcement, etc.
        """
        self._channel_types = types
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        data = super().to_dict()
        if self._channel_types:
            data["channel_types"] = self._channel_types
        return data


# Export all
__all__ = [
    "SelectMenuType",
    "SelectOption",
    "StringSelectMenuBuilder",
    "UserSelectMenuBuilder",
    "RoleSelectMenuBuilder",
    "MentionableSelectMenuBuilder",
    "ChannelSelectMenuBuilder",
]

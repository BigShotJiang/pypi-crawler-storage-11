"""
Thread Manager - Manage threads in a channel

Discord.js equivalent: ThreadManager
"""
from typing import List


from ..models.channel import Thread
from ..models.guild import Guild
from .base import BaseManager


class ThreadManager(BaseManager[Thread]):
    """
    A manager for a guild's threads.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch_public_archived(self) -> List[Thread]:
        """
        Fetches all public archived threads for the guild.

        Returns:
            A list of threads.
        """
        threads_data = await self._http.list_public_archived_threads(
            self.guild.id
        )
        threads = [
            Thread(thread, self._http) for thread in threads_data["threads"]
        ]
        for thread in threads:
            self._cache[thread.id] = thread
        return threads

    async def fetch_private_archived(self) -> List[Thread]:
        """
        Fetches all private archived threads for the guild.

        Returns:
            A list of threads.
        """
        threads_data = await self._http.list_private_archived_threads(
            self.guild.id
        )
        threads = [
            Thread(thread, self._http) for thread in threads_data["threads"]
        ]
        for thread in threads:
            self._cache[thread.id] = thread
        return threads

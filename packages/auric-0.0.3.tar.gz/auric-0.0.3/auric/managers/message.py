"""
Message Manager - Handles message caching and operations
"""

from typing import Dict, List, Optional

from ..core.types import Snowflake
from ..models.message import Message
from .base import BaseManager


class MessageManager(BaseManager[Message]):
    """
    Manages messages in a channel

    Example:
        ```python
        # Fetch a message
        message = await channel.messages.fetch(message_id)

        # Send a message
        message = await channel.messages.create(content="Hello!")

        # Get cached messages
        recent = channel.messages.cache.last(10)
        ```
    """

    def __init__(self, channel, http):
        super().__init__(http, cache=True, max_size=100)
        self.channel = channel
        self.channel_id = channel.id if hasattr(channel, "id") else channel

    async def fetch(self, message_id: Snowflake) -> Message:
        """
        Fetch a message from the API

        Args:
            message_id: Message ID to fetch

        Returns:
            The fetched message
        """
        data = await self._http.get_message(self.channel_id, message_id)
        message = Message(data=data, http=self._http)
        return self._add(message_id, message)

    async def fetch_multiple(
        self,
        *,
        limit: int = 50,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
        around: Optional[Snowflake] = None,
    ) -> List[Message]:
        """
        Fetch multiple messages

        Args:
            limit: Number of messages to fetch (1-100)
            before: Get messages before this ID
            after: Get messages after this ID
            around: Get messages around this ID

        Returns:
            List of messages
        """
        data = await self._http.get_channel_messages(
            self.channel_id,
            limit=limit,
            before=before,
            after=after,
            around=around,
        )

        messages = []
        for msg_data in data:
            message = Message(data=msg_data, http=self._http)
            self._add(int(msg_data["id"]), message)
            messages.append(message)

        return messages

    async def create(
        self,
        content: Optional[str] = None,
        *,
        embed=None,
        embeds=None,
        file=None,
        files=None,
        tts: bool = False,
        nonce: Optional[str] = None,
        allowed_mentions: Optional[Dict] = None,
        message_reference: Optional[Dict] = None,
        components=None,
        sticker_ids: Optional[List[Snowflake]] = None,
        attachments: Optional[List[Dict]] = None,
        flags: Optional[int] = None,
        poll: Optional[Dict] = None,
    ) -> Message:
        """
        Send a message to the channel

        Args:
            content: Message content
            embed: Single embed
            embeds: List of embeds
            file: Single file
            files: List of files
            tts: Text-to-speech
            nonce: Nonce for message
            allowed_mentions: Allowed mentions object
            message_reference: Message reference for replies
            components: Message components
            sticker_ids: Sticker IDs
            attachments: Attachments
            flags: Message flags
            poll: Poll object

        Returns:
            The created message
        """
        # Build embeds list
        embed_data = None
        if embed is not None:
            embed_data = [
                embed.to_dict() if hasattr(embed, "to_dict") else embed
            ]
        if embeds is not None:
            embed_data = [
                e.to_dict() if hasattr(e, "to_dict") else e for e in embeds
            ]

        # Build components list
        component_data = None
        if components is not None:
            component_data = [
                c.to_dict() if hasattr(c, "to_dict") else c for c in components
            ]

        data = await self._http.create_message(
            self.channel_id,
            content=content,
            embeds=embed_data,
            tts=tts,
            nonce=nonce,
            allowed_mentions=allowed_mentions,
            message_reference=message_reference,
            components=component_data,
            sticker_ids=sticker_ids,
            attachments=attachments,
            flags=flags,
            poll=poll,
        )

        message = Message(data=data, http=self._http)
        return self._add(int(data["id"]), message)

    async def edit(
        self,
        message_id: Snowflake,
        *,
        content: Optional[str] = None,
        embed=None,
        embeds=None,
        attachments: Optional[List[Dict]] = None,
        components=None,
        flags: Optional[int] = None,
    ) -> Message:
        """
        Edit a message

        Args:
            message_id: Message ID to edit
            content: New content
            embed: New embed
            embeds: New embeds
            attachments: New attachments
            components: New components
            flags: New flags

        Returns:
            The edited message
        """
        # Build embeds list
        embed_data = None
        if embed is not None:
            embed_data = [
                embed.to_dict() if hasattr(embed, "to_dict") else embed
            ]
        if embeds is not None:
            embed_data = [
                e.to_dict() if hasattr(e, "to_dict") else e for e in embeds
            ]

        # Build components list
        component_data = None
        if components is not None:
            component_data = [
                c.to_dict() if hasattr(c, "to_dict") else c for c in components
            ]

        data = await self._http.edit_message(
            self.channel_id,
            message_id,
            content=content,
            embeds=embed_data,
            attachments=attachments,
            components=component_data,
            flags=flags,
        )

        message = Message(data=data, http=self._http)
        return self._add(message_id, message)

    async def delete(
        self, message_id: Snowflake, *, reason: Optional[str] = None
    ) -> bool:
        """
        Delete a message

        Args:
            message_id: Message ID to delete
            reason: Audit log reason

        Returns:
            True if deleted
        """
        await self._http.delete_message(
            self.channel_id, message_id, reason=reason
        )
        self._remove(message_id)
        return True

    async def bulk_delete(self, message_ids: List[Snowflake]) -> int:
        """
        Bulk delete messages

        Args:
            message_ids: List of message IDs (2-100)

        Returns:
            Number of messages deleted
        """
        await self._http.bulk_delete_messages(
            self.channel_id, message_ids=message_ids
        )

        for msg_id in message_ids:
            self._remove(msg_id)

        return len(message_ids)

    async def purge(
        self,
        limit: int,
        *,
        check: Optional[callable] = None,
        before: Optional[Snowflake] = None,
        after: Optional[Snowflake] = None,
        around: Optional[Snowflake] = None,
        reason: Optional[str] = None,
    ) -> int:
        """
        Purge messages from channel

        Args:
            limit: Number of messages to check
            check: Function to filter messages
            before: Only purge messages before this ID
            after: Only purge messages after this ID
            around: Only purge messages around this ID
            reason: Audit log reason

        Returns:
            Number of messages deleted
        """
        messages = await self.fetch_multiple(
            limit=min(limit, 100),
            before=before,
            after=after,
            around=around,
        )

        if check:
            messages = [m for m in messages if check(m)]

        if not messages:
            return 0

        message_ids = [m.id for m in messages]

        if len(message_ids) == 1:
            await self.delete(message_ids[0], reason=reason)
            return 1
        else:
            return await self.bulk_delete(message_ids)

    async def fetch_pins(self) -> List[Message]:
        """
        Fetch all pinned messages from the channel.

        Returns:
            List of pinned messages.
        """
        data = await self._http.get_pins(self.channel_id)
        messages = []
        for msg_data in data:
            message = Message(data=msg_data, http=self._http)
            self._add(int(msg_data["id"]), message)
            messages.append(message)
        return messages

    async def pin_message(
        self, message_id: Snowflake, *, reason: Optional[str] = None
    ) -> None:
        """
        Pin a message in the channel.

        Args:
            message_id: The ID of the message to pin.
            reason: Reason for audit log.
        """
        await self._http.pin_message(self.channel_id, message_id, reason=reason)

    async def unpin_message(
        self, message_id: Snowflake, *, reason: Optional[str] = None
    ) -> None:
        """
        Unpin a message in the channel.

        Args:
            message_id: The ID of the message to unpin.
            reason: Reason for audit log.
        """
        await self._http.unpin_message(
            self.channel_id, message_id, reason=reason
        )

"""
Application Command Manager - Manage application commands (slash commands)

Discord.js equivalent: ApplicationCommandManager
"""

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..utils.collection import Collection

if TYPE_CHECKING:
    from ..core.client import Client
    from ..models.command import ApplicationCommand


class ApplicationCommandManager:
    """
    Manages application commands for the client.

    Similar to discord.js ApplicationCommandManager.

    Example:
        ```python
        # Get all commands
        commands = await client.commands.fetch()

        # Create a command
        await client.commands.create(data={
            'name': 'test',
            'description': 'Test command'
        })

        # Delete a command
        await client.commands.delete(command_id)
        ```
    """

    def __init__(self, client: "Client"):
        self.client = client
        self.cache: Collection[int, "ApplicationCommand"] = Collection()

    async def fetch(self, command_id: Optional[int] = None, *, force: bool = False) -> Any:
        """
        Fetch application command(s)

        Args:
            command_id: Specific command to fetch, or None for all
            force: Force fetch even if cached
        """
        from ..models.command import ApplicationCommand

        if command_id:
            if not force and self.cache.has(command_id):
                return self.cache.get(command_id)

            data = await self.client._http.get_application_command(
                self.client.application_id, command_id
            )
            cmd = ApplicationCommand(data, self.client)
            self.cache.set(cmd.id, cmd)
            return cmd
        else:
            data = await self.client._http.get_application_commands(self.client.application_id)
            for cmd_data in data:
                cmd = ApplicationCommand(cmd_data, self.client)
                self.cache.set(cmd.id, cmd)
            return self.cache

    async def create(self, data: Dict[str, Any], *, contexts: Optional[List[int]] = None) -> "ApplicationCommand":
        """Create a new application command"""
        from ..models.command import ApplicationCommand

        if contexts is not None:
            data["contexts"] = contexts

        result = await self.client._http.create_application_command(
            self.client.application_id, json=data
        )
        cmd = ApplicationCommand(result, self.client)
        self.cache.set(cmd.id, cmd)
        return cmd

    async def edit(
        self, command_id: int, data: Dict[str, Any], *, contexts: Optional[List[int]] = None
    ) -> "ApplicationCommand":
        """Edit an application command"""
        from ..models.command import ApplicationCommand

        if contexts is not None:
            data["contexts"] = contexts

        result = await self.client._http.edit_application_command(
            self.client.application_id, command_id, json=data
        )
        cmd = ApplicationCommand(result, self.client)
        self.cache.set(cmd.id, cmd)
        return cmd

    async def delete(self, command_id: int) -> None:
        """Delete an application command"""
        await self.client._http.delete_application_command(self.client.application_id, command_id)
        self.cache.delete(command_id)

    async def set(self, commands: List[Dict[str, Any]]) -> Collection[int, "ApplicationCommand"]:
        """
        Bulk overwrite all application commands

        Args:
            commands: List of command data
        """
        from ..models.command import ApplicationCommand

        data = await self.client._http.bulk_overwrite_application_commands(
            self.client.application_id, commands
        )

        self.cache.clear()
        for cmd_data in data:
            cmd = ApplicationCommand(cmd_data, self.client)
            self.cache.set(cmd.id, cmd)

        return self.cache


class GuildApplicationCommandManager:
    """
    Manages application commands for a specific guild.

    Similar to discord.js GuildApplicationCommandManager.
    """

    def __init__(self, guild_id: int, client: "Client"):
        self.guild_id = guild_id
        self.client = client
        self.cache: Collection[int, "ApplicationCommand"] = Collection()

    async def fetch(self, command_id: Optional[int] = None, *, force: bool = False) -> Any:
        """Fetch guild command(s)"""
        from ..models.command import ApplicationCommand

        if command_id:
            if not force and self.cache.has(command_id):
                return self.cache.get(command_id)

            data = await self.client._http.get_guild_application_command(
                self.client.application_id, self.guild_id, command_id
            )
            cmd = ApplicationCommand(data, self.client)
            self.cache.set(cmd.id, cmd)
            return cmd
        else:
            data = await self.client._http.get_guild_application_commands(
                self.client.application_id, self.guild_id
            )
            for cmd_data in data:
                cmd = ApplicationCommand(cmd_data, self.client)
                self.cache.set(cmd.id, cmd)
            return self.cache

    async def create(self, data: Dict[str, Any], *, contexts: Optional[List[int]] = None) -> "ApplicationCommand":
        """Create a guild command"""
        from ..models.command import ApplicationCommand

        if contexts is not None:
            data["contexts"] = contexts

        result = await self.client._http.create_guild_application_command(
            self.client.application_id, self.guild_id, json=data
        )
        cmd = ApplicationCommand(result, self.client)
        self.cache.set(cmd.id, cmd)
        return cmd

    async def edit(
        self, command_id: int, data: Dict[str, Any], *, contexts: Optional[List[int]] = None
    ) -> "ApplicationCommand":
        """Edit a guild command"""
        from ..models.command import ApplicationCommand

        if contexts is not None:
            data["contexts"] = contexts

        result = await self.client._http.edit_guild_application_command(
            self.client.application_id, self.guild_id, command_id, json=data
        )
        cmd = ApplicationCommand(result, self.client)
        self.cache.set(cmd.id, cmd)
        return cmd

    async def delete(self, command_id: int) -> None:
        """Delete a guild command"""
        await self.client._http.delete_guild_application_command(
            self.client.application_id, self.guild_id, command_id
        )
        self.cache.delete(command_id)

    async def set(self, commands: List[Dict[str, Any]]) -> Collection[int, "ApplicationCommand"]:
        """Bulk overwrite guild commands"""
        from ..models.command import ApplicationCommand

        data = await self.client._http.bulk_overwrite_guild_application_commands(
            self.client.application_id, self.guild_id, commands
        )

        self.cache.clear()
        for cmd_data in data:
            cmd = ApplicationCommand(cmd_data, self.client)
            self.cache.set(cmd.id, cmd)

        return self.cache

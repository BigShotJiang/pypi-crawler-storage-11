"""
Manager for Pruning for a guild.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from .base import BaseManager

if TYPE_CHECKING:
    from ..models.guild import Guild


class PruneManager(BaseManager[Any]):
    """
    A manager for a guild's prune.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def get_count(self, days: int = 7) -> int:
        """
        Gets the number of members that would be pruned.

        Args:
            days: The number of days to prune.

        Returns:
            The number of members that would be pruned.
        """
        data = await self._http.get_guild_prune_count(self.guild.id, days=days)
        return data["pruned"]

    async def begin(self, days: int = 7, *, reason: Optional[str] = None) -> int:
        """
        Begins a prune.

        Args:
            days: The number of days to prune.
            reason: The reason for the prune.

        Returns:
            The number of members that were pruned.
        """
        data = await self._http.begin_guild_prune(
            self.guild.id, days=days, reason=reason
        )
        return data["pruned"]

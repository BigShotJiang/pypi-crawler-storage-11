"""
Manager for Typing for a channel.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .base import BaseManager

if TYPE_CHECKING:
    from ..models.channel import TextChannel


class TypingManager(BaseManager[Any]):
    """
    A manager for a channel's typing.

    Attributes:
        channel: The channel this manager belongs to.
    """

    __slots__ = ("channel",)

    def __init__(self, channel: TextChannel) -> None:
        super().__init__(channel._http)
        self.channel = channel

    async def trigger(self) -> None:
        """
        Triggers the typing indicator for the channel.
        """
        await self._http.trigger_typing_indicator(self.channel.id)

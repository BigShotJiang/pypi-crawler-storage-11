"""
Emoji Manager - Manage guild emojis

Discord.js equivalent: GuildEmojiManager
"""

from typing import TYPE_CHECKING, Any, List, Optional

from ..core.types import Snowflake
from ..models.guild import Guild
from ..utils.collection import Collection
from .base import BaseManager

if TYPE_CHECKING:
    from ..core.client import Client
    from ..models.emoji import Emoji


class GuildEmojiManager(BaseManager[Emoji]):
    """
    A manager for a guild's emojis.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(self) -> List[Emoji]:
        """
        Fetches all emojis for the guild.

        Returns:
            A list of emojis.
        """
        emojis_data = await self._http.list_guild_emojis(self.guild.id)
        emojis = [Emoji(emoji, self._http) for emoji in emojis_data]
        for emoji in emojis:
            self._cache[emoji.id] = emoji
        return emojis


class GuildStickerManager:
    """
    Manages stickers for a guild.

    Similar to discord.js GuildStickerManager.
    """

    def __init__(self, guild_id: Snowflake, client: "Client"):
        self.guild_id = guild_id
        self.client = client
        self.cache: Collection[int, Any] = Collection()

    async def fetch(
        self, sticker_id: Optional[Snowflake] = None, *, force: bool = False
    ) -> Any:
        """Fetch sticker(s) from the guild"""
        if sticker_id:
            if not force and self.cache.has(sticker_id):
                return self.cache.get(sticker_id)

            data = await self.client._http.get_guild_sticker(
                self.guild_id, sticker_id
            )
            self.cache.set(int(data["id"]), data)
            return data
        else:
            data = await self.client._http.list_guild_stickers(self.guild_id)
            self.cache.clear()
            for sticker in data:
                self.cache.set(int(sticker["id"]), sticker)
            return self.cache

    async def create(
        self,
        *,
        name: str,
        description: str,
        tags: str,
        file: bytes,
        reason: Optional[str] = None,
    ) -> Any:
        """Create a guild sticker"""
        data = await self.client._http.create_guild_sticker(
            self.guild_id,
            name=name,
            description=description,
            tags=tags,
            file=file,
            reason=reason,
        )
        self.cache.set(int(data["id"]), data)
        return data

    async def edit(
        self,
        sticker_id: Snowflake,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> Any:
        """Edit a guild sticker"""
        json = {}
        if name is not None:
            json["name"] = name
        if description is not None:
            json["description"] = description
        if tags is not None:
            json["tags"] = tags

        data = await self.client._http.modify_guild_sticker(
            self.guild_id, sticker_id, json=json, reason=reason
        )
        self.cache.set(sticker_id, data)
        return data

    async def delete(self, sticker_id: Snowflake, *, reason: Optional[str] = None) -> None:
        """Delete a guild sticker"""
        await self.client._http.delete_guild_sticker(self.guild_id, sticker_id, reason=reason)
        self.cache.delete(sticker_id)


__all__ = ["GuildEmojiManager", "GuildStickerManager"]

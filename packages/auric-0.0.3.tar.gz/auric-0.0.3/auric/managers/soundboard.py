"""
Manager for Soundboard sounds for a guild.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from ..models.soundboard import SoundboardSound
from .base import BaseManager

if TYPE_CHECKING:
    from ..models.guild import Guild


class SoundboardManager(BaseManager[SoundboardSound]):
    """
    A manager for a guild's soundboard sounds.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(self) -> list[SoundboardSound]:
        """
        Fetches all soundboard sounds for the guild.

        Returns:
            A list of soundboard sounds.
        """
        sounds_data = await self._http.list_guild_soundboard_sounds(
            self.guild.id
        )
        sounds = [SoundboardSound.from_dict(sound, self._http) for sound in sounds_data]
        for sound in sounds:
            self._cache[sound.sound_id] = sound
        return sounds

    async def create(
        self,
        *,
        name: str,
        sound: bytes,
        volume: float = 1.0,
        emoji_id: Optional[int] = None,
        emoji_name: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> SoundboardSound:
        """
        Creates a new soundboard sound for the guild.

        Args:
            name: The name of the sound.
            sound: The sound file in bytes.
            volume: The volume of the sound.
            emoji_id: The ID of a custom emoji to use.
            emoji_name: The name of a unicode emoji to use.
            reason: The reason for creating the sound.

        Returns:
            The created soundboard sound.
        """
        import base64

        payload = {
            "name": name,
            "sound": base64.b64encode(sound).decode("utf-8"),
            "volume": volume,
        }
        if emoji_id:
            payload["emoji_id"] = emoji_id
        if emoji_name:
            payload["emoji_name"] = emoji_name

        sound_data = await self._http.create_guild_soundboard_sound(
            self.guild.id, json=payload, reason=reason
        )
        sound = SoundboardSound.from_dict(sound_data, self._http)
        self._cache[sound.sound_id] = sound
        return sound

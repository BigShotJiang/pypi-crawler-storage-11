"""
Manager for Bans for a guild.
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional, TYPE_CHECKING


from ..models.user import User
from .base import BaseManager

if TYPE_CHECKING:
    from ..core.http import HTTPClient
    from ..models.guild import Guild


class Ban:
    """
    Represents a ban in a guild.

    Attributes:
        user: The banned user.
        reason: The reason for the ban.
    """

    __slots__ = ("user", "reason")

    def __init__(self, *, data: Dict[str, Any], http: Optional[HTTPClient] = None):
        self.user: User = User(data=data["user"], http=http)
        self.reason: Optional[str] = data.get("reason")


class BanManager(BaseManager[Ban]):
    """
    A manager for a guild's bans.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(self) -> List[Ban]:
        """
        Fetches all bans for the guild.

        Returns:
            A list of bans.
        """
        bans_data = await self._http.get_guild_bans(self.guild.id)
        bans = [Ban(ban, self._http) for ban in bans_data]
        for ban in bans:
            self._cache[ban.user.id] = ban
        return bans

    async def create(self, user_id: int, *, reason: Optional[str] = None) -> None:
        """
        Bans a user from the guild.

        Args:
            user_id: The ID of the user to ban.
            reason: The reason for the ban.
        """
        await self._http.ban_user(self.guild.id, user_id, reason=reason)

    async def remove(self, user_id: int, *, reason: Optional[str] = None) -> None:
        """
        Unbans a user from the guild.

        Args:
            user_id: The ID of the user to unban.
            reason: The reason for the unban.
        """
        await self._http.unban_user(self.guild.id, user_id, reason=reason)

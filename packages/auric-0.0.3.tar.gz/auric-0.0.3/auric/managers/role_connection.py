"""
Application Role Connection Manager
"""

from typing import Dict, List

from ..models.role_connection import (
    ApplicationRoleConnectionMetadata,
    UserApplicationRoleConnection,
)
from .base import BaseManager


class ApplicationRoleConnectionManager(
    BaseManager[ApplicationRoleConnectionMetadata]
):
    """
    Manages application role connection metadata.
    """

    def __init__(self, http):
        super().__init__(http)

    async def fetch_metadata_records(self) -> List[ApplicationRoleConnectionMetadata]:
        """Fetch all role connection metadata records for the application."""
        data = await self._http.get_application_role_connection_metadata(
            self.client.application_id
        )
        return [ApplicationRoleConnectionMetadata(d) for d in data]

    async def update_metadata_records(
        self, records: List[ApplicationRoleConnectionMetadata]
    ) -> List[ApplicationRoleConnectionMetadata]:
        """Update all role connection metadata records for the application."""
        payload = [r.to_dict() for r in records]
        data = await self._http.update_application_role_connection_metadata(
            self.client.application_id, metadata=payload
        )
        return [ApplicationRoleConnectionMetadata(d) for d in data]

    async def fetch_user_connection(self) -> UserApplicationRoleConnection:
        """Fetch the current user's role connection for the application."""
        data = await self._http.get_user_application_role_connection(
            self.client.application_id
        )
        return UserApplicationRoleConnection(data)

    async def update_user_connection(
        self, *, platform_name: str, platform_username: str, metadata: Dict[str, str]
    ) -> UserApplicationRoleConnection:
        """Update the current user's role connection for the application."""
        data = await self._http.update_user_application_role_connection(
            self.client.application_id,
            platform_name=platform_name,
            platform_username=platform_username,
            metadata=metadata,
        )
        return UserApplicationRoleConnection(data)

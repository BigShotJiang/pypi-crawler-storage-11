"""
Manager for Integrations for a guild.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from ..models.integration import Integration
from .base import BaseManager

if TYPE_CHECKING:
    from ..models.guild import Guild


class IntegrationManager(BaseManager[Integration]):
    """
    A manager for a guild's integrations.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(self) -> List[Integration]:
        """
        Fetches all integrations for the guild.

        Returns:
            A list of integrations.
        """
        integrations_data = await self._http.get_guild_integrations(self.guild.id)
        integrations = [Integration(integration, self._http) for integration in integrations_data]
        for integration in integrations:
            self._cache[integration.id] = integration
        return integrations

"""
Sticker Manager - Manage guild stickers and sticker packs
"""

from typing import List, Optional, Union

from ..core.types import Snowflake
from ..models.sticker import Sticker
from ..models.sticker_pack import StickerPack
from .base import BaseManager


class StickerManager(BaseManager[Sticker]):
    """
    Manages stickers for a guild.
    """

    def __init__(self, guild_id: Snowflake, http):
        super().__init__(http)
        self.guild_id = guild_id

    async def fetch(
        self, sticker_id: Optional[Snowflake] = None, *, force: bool = False
    ) -> Union[Sticker, List[Sticker]]:
        """Fetch sticker(s) from the guild"""
        if sticker_id:
            if not force and self.cache.has(sticker_id):
                return self.cache.get(sticker_id)

            data = await self._http.get_guild_sticker(self.guild_id, sticker_id)
            sticker = Sticker(data=data, http=self._http)
            self.cache.set(sticker.id, sticker)
            return sticker
        else:
            data = await self._http.list_guild_stickers(self.guild_id)
            self.cache.clear()
            stickers = []
            for sticker_data in data:
                sticker = Sticker(data=sticker_data, http=self._http)
                self.cache.set(sticker.id, sticker)
                stickers.append(sticker)
            return stickers

    async def create(
        self,
        *,
        name: str,
        description: str,
        tags: str,
        file: bytes,
        reason: Optional[str] = None,
    ) -> Sticker:
        """Create a guild sticker"""
        data = await self._http.create_guild_sticker(
            self.guild_id,
            name=name,
            description=description,
            tags=tags,
            file=file,
            reason=reason,
        )
        sticker = Sticker(data=data, http=self._http)
        self.cache.set(sticker.id, sticker)
        return sticker

    async def edit(
        self,
        sticker_id: Snowflake,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> Sticker:
        """Edit a guild sticker"""
        data = await self._http.modify_guild_sticker(
            self.guild_id,
            sticker_id,
            name=name,
            description=description,
            tags=tags,
            reason=reason,
        )
        sticker = Sticker(data=data, http=self._http)
        self.cache.set(sticker.id, sticker)
        return sticker

    async def delete(
        self, sticker_id: Snowflake, *, reason: Optional[str] = None
    ) -> None:
        """Delete a guild sticker"""
        await self._http.delete_guild_sticker(
            self.guild_id, sticker_id, reason=reason
        )
        self.cache.delete(sticker_id)


class StickerPackManager(BaseManager[StickerPack]):
    """
    Manages sticker packs.
    """

    def __init__(self, http):
        super().__init__(http)

    async def fetch(
        self, pack_id: Optional[Snowflake] = None, *, force: bool = False
    ) -> Union[StickerPack, List[StickerPack]]:
        """Fetch sticker pack(s)"""
        if pack_id:
            if not force and self.cache.has(pack_id):
                return self.cache.get(pack_id)

            data = await self._http.get_sticker_pack(pack_id)
            pack = StickerPack(data=data, http=self._http)
            self.cache.set(pack.id, pack)
            return pack
        else:
            data = await self._http.list_sticker_packs()
            self.cache.clear()
            packs = []
            for pack_data in data["sticker_packs"]:
                pack = StickerPack(data=pack_data, http=self._http)
                self.cache.set(pack.id, pack)
                packs.append(pack)
            return packs

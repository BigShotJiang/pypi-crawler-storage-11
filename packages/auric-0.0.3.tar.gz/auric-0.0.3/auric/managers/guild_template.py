"""
Guild Template Manager
"""

from typing import List, Optional, Union

from ..core.types import Snowflake
from ..models.guild_template import GuildTemplate
from .base import BaseManager


class GuildTemplateManager(BaseManager[GuildTemplate]):
    """
    Manages guild templates.
    """

    def __init__(self, guild_id: Snowflake, http):
        super().__init__(http)
        self.guild_id = guild_id

    async def fetch(
        self, code: Optional[str] = None, *, force: bool = False
    ) -> Union[GuildTemplate, List[GuildTemplate]]:
        """Fetch template(s) from the guild"""
        if code:
            if not force and self.cache.has(code):
                return self.cache.get(code)

            data = await self._http.get_template(code)
            template = GuildTemplate(data=data, http=self._http)
            self.cache.set(template.code, template)
            return template
        else:
            data = await self._http.get_guild_templates(self.guild_id)
            self.cache.clear()
            templates = []
            for template_data in data:
                template = GuildTemplate(data=template_data, http=self._http)
                self.cache.set(template.code, template)
                templates.append(template)
            return templates

    async def create(
        self, *, name: str, description: Optional[str] = None
    ) -> GuildTemplate:
        """Create a guild template"""
        data = await self._http.create_guild_template(
            self.guild_id, json={"name": name, "description": description}
        )
        template = GuildTemplate(data=data, http=self._http)
        self.cache.set(template.code, template)
        return template

    async def sync(self, code: str) -> GuildTemplate:
        """Sync a guild template"""
        data = await self._http.sync_guild_template(self.guild_id, code)
        template = GuildTemplate(data=data, http=self._http)
        self.cache.set(template.code, template)
        return template

    async def edit(
        self, code: str, *, name: Optional[str] = None, description: Optional[str] = None
    ) -> GuildTemplate:
        """Edit a guild template"""
        data = await self._http.modify_guild_template(
            self.guild_id, code, json={"name": name, "description": description}
        )
        template = GuildTemplate(data=data, http=self._http)
        self.cache.set(template.code, template)
        return template

    async def delete(self, code: str) -> None:
        """Delete a guild template"""
        await self._http.delete_guild_template(self.guild_id, code)
        self.cache.delete(code)

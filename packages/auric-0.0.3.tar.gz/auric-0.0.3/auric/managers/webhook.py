"""
Manager for Webhooks for a guild.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from ..models.webhook import Webhook
from .base import BaseManager

if TYPE_CHECKING:
    from ..models.guild import Guild


class WebhookManager(BaseManager[Webhook]):
    """
    A manager for a guild's webhooks.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(self) -> List[Webhook]:
        """
        Fetches all webhooks for the guild.

        Returns:
            A list of webhooks.
        """
        webhooks_data = await self._http.get_guild_webhooks(self.guild.id)
        webhooks = [Webhook(webhook, self._http) for webhook in webhooks_data]
        for webhook in webhooks:
            self._cache[webhook.id] = webhook
        return webhooks

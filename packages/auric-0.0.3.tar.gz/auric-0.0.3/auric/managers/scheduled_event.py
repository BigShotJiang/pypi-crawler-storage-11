"""
Manager for Scheduled Events for a guild.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional, List
from datetime import datetime

from ..models.scheduled_event import (
    ScheduledEvent,
    ScheduledEventEntityType,
    ScheduledEventPrivacyLevel,
)
from .base import BaseManager

if TYPE_CHECKING:
    from ..models.guild import Guild


class ScheduledEventManager(BaseManager[ScheduledEvent]):
    """
    A manager for a guild's scheduled events.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(self) -> List[ScheduledEvent]:
        """
        Fetches all scheduled events for the guild.

        Returns:
            A list of scheduled events.
        """
        events_data = await self._http.get_scheduled_events(self.guild.id)
        events = [ScheduledEvent(event, self._http) for event in events_data]
        for event in events:
            self._cache[event.id] = event
        return events

    async def create(
        self,
        *,
        name: str,
        entity_type: ScheduledEventEntityType,
        scheduled_start_time: datetime,
        channel_id: Optional[int] = None,
        description: Optional[str] = None,
        scheduled_end_time: Optional[datetime] = None,
        privacy_level: ScheduledEventPrivacyLevel = (
            ScheduledEventPrivacyLevel.GUILD_ONLY
        ),
        location: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> ScheduledEvent:
        """
        Creates a new scheduled event for the guild.

        Args:
            name: The name of the event.
            entity_type: The type of entity for the event.
            scheduled_start_time: The time to schedule the event.
            channel_id: The channel ID for the event.
            description: The description of the event.
            scheduled_end_time: The time to end the event.
            privacy_level: The privacy level of the event.
            location: The location of the event (for external events).
            reason: The reason for creating the event.

        Returns:
            The created scheduled event.
        """
        payload = {
            "name": name,
            "entity_type": int(entity_type),
            "scheduled_start_time": scheduled_start_time.isoformat(),
            "privacy_level": int(privacy_level),
        }
        if channel_id:
            payload["channel_id"] = channel_id
        if description:
            payload["description"] = description
        if scheduled_end_time:
            payload["scheduled_end_time"] = scheduled_end_time.isoformat()
        if location:
            payload["entity_metadata"] = {"location": location}

        event_data = await self._http.create_scheduled_event(
            self.guild.id,
            json=payload,
            reason=reason
        )
        return ScheduledEvent(event_data, self._http)

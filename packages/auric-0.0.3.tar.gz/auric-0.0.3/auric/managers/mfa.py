"""
Manager for MFA for a guild.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .base import BaseManager

if TYPE_CHECKING:
    from ..models.guild import Guild


class MFAManager(BaseManager[Any]):
    """
    A manager for a guild's MFA.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def enable(self) -> None:
        """
        Enables MFA for the guild.
        """
        await self._http.enable_mfa(self.guild.id)

    async def disable(self) -> None:
        """
        Disables MFA for the guild.
        """
        await self._http.disable_mfa(self.guild.id)

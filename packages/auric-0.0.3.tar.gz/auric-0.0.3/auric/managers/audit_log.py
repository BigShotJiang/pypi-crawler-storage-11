"""
Manager for Audit Logs for a guild.
"""
from __future__ import annotations
from typing import Optional, TYPE_CHECKING


from ..models.audit_log import AuditLog, AuditLogEvent
from .base import BaseManager

if TYPE_CHECKING:
    from ..models.guild import Guild


class AuditLogManager(BaseManager[AuditLog]):
    """
    A manager for a guild's audit logs.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(
        self,
        *,
        user_id: Optional[int] = None,
        action_type: Optional[AuditLogEvent] = None,
        before: Optional[int] = None,
        after: Optional[int] = None,
        limit: int = 50,
    ) -> AuditLog:
        """
        Fetches the audit logs for the guild.

        Args:
            user_id: The user ID to filter by.
            action_type: The action type to filter by.
            before: The entry ID to fetch before.
            after: The entry ID to fetch after.
            limit: The number of entries to fetch.

        Returns:
            An AuditLog object.
        """
        log_data = await self._http.get_audit_logs(
            self.guild.id,
            user_id=user_id,
            action_type=action_type,
            before=before,
            after=after,
            limit=limit,
        )
        return AuditLog(log_data, self._http, self.guild.id)

"""
Member Manager for advanced member operations
"""
from typing import Any, Dict, List, Optional

from ..models.guild import Guild
from ..utils.exceptions import NotFound
from ..models.member import Member
from ..utils.collection import Collection
from .base import BaseManager


class MemberManager(BaseManager[Member]):
    """
    A manager for a guild's members.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(self, user_id: int) -> Member:
        """
        Fetches a member from the guild.

        Args:
            user_id: The ID of the user to fetch.

        Returns:
            A member.
        """
        member_data = await self._http.get_guild_member(self.guild.id, user_id)
        member = Member(data=member_data, http=self._http)
        self._cache[member.id] = member
        return member

    async def search(self, query: str, limit: int = 1) -> List[Member]:
        """
        Searches for members in the guild.

        Args:
            query: The query to search for.
            limit: The maximum number of members to return.

        Returns:
            A list of members.
        """
        members_data = await self._http.search_guild_members(
            self.guild.id, query=query, limit=limit
        )
        return [Member(data=member, http=self._http) for member in members_data]

    async def add(
        self, user_id: int, access_token: str, *, nick: str = None, roles: List[int] = None
    ) -> Member:
        """
        Adds a member to the guild.

        Args:
            user_id: The ID of the user to add.
            access_token: The access token of the user.
            nick: The nickname of the user.
            roles: A list of role IDs to assign to the user.

        Returns:
            The added member.
        """
        member_data = await self._http.add_guild_member(
            self.guild.id,
            user_id,
            access_token=access_token,
            nick=nick,
            roles=roles,
        )
        member = Member(data=member_data, http=self._http)
        self._cache[member.id] = member
        return member

    async def remove(self, user_id: int, *, reason: str = None) -> None:
        """
        Removes a member from the guild.

        Args:
            user_id: The ID of the user to remove.
            reason: The reason for removing the member.
        """
        await self._http.remove_guild_member(self.guild.id, user_id, reason=reason)

    async def modify(self, user_id: int, *, nick: str = None) -> Member:
        """
        Modifies a member in the guild.

        Args:
            user_id: The ID of the user to modify.
            nick: The new nickname of the user.

        Returns:
            The modified member.
        """
        member_data = await self._http.modify_guild_member(
            self.guild.id, user_id, nick=nick
        )
        member = Member(data=member_data, http=self._http)
        self._cache[member.id] = member
        return member


class RoleManager(BaseManager):
    """
    Manages guild roles.

    Example:
        ```python
        # Create role
        role = await guild.roles.create(name='Moderator', color=0x00ff00)

        # Get role
        role = guild.roles.get(role_id)

        # Modify role
        await guild.roles.modify(role_id, name='Admin')
        ```
    """

    def __init__(self, http, guild_id: int):
        super().__init__(http)
        self.guild_id = guild_id
        self.cache: Collection[int, Any] = Collection()  # Role model

    async def fetch(self, role_id: int):
        """Fetch role (via guild roles)"""
        roles = await self._http.get_guild_roles(self.guild_id)
        role_data = next((r for r in roles if int(r["id"]) == role_id), None)
        if not role_data:
            raise NotFound(f"Role {role_id} not found")
        return role_data

    async def fetch_all(self) -> List[Any]:
        """Fetch all guild roles"""
        data = await self._http.get_guild_roles(self.guild_id)
        return data

    async def create(
        self,
        *,
        name: str = "new role",
        permissions: int = 0,
        color: int = 0,
        hoist: bool = False,
        icon: Optional[str] = None,
        unicode_emoji: Optional[str] = None,
        mentionable: bool = False,
        reason: Optional[str] = None,
    ):
        """
        Create guild role.

        Args:
            name: Role name
            permissions: Permission bitfield
            color: RGB color value
            hoist: Show separately in sidebar
            icon: Role icon (base64)
            unicode_emoji: Unicode emoji for role
            mentionable: Can be mentioned
            reason: Audit log reason

        Returns:
            Created role
        """
        payload = {
            "name": name,
            "permissions": str(permissions),
            "color": color,
            "hoist": hoist,
            "mentionable": mentionable,
        }

        if icon:
            payload["icon"] = icon
        if unicode_emoji:
            payload["unicode_emoji"] = unicode_emoji

        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        data = await self._http.create_guild_role(self.guild_id, json=payload, headers=headers)
        return data

    async def modify(self, role_id: int, **kwargs):
        """
        Modify guild role.

        Args:
            role_id: Role ID
            **kwargs: Fields to modify

        Returns:
            Modified role
        """
        reason = kwargs.pop("reason", None)
        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        data = await self._http.modify_guild_role(
            self.guild_id, role_id, json=kwargs, headers=headers
        )
        return data

    async def delete(self, role_id: int, *, reason: Optional[str] = None) -> None:
        """
        Delete guild role.

        Args:
            role_id: Role ID
            reason: Audit log reason
        """
        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        await self._http.delete_guild_role(self.guild_id, role_id, headers=headers)

    async def modify_positions(
        self, positions: List[Dict[str, int]], *, reason: Optional[str] = None
    ) -> List[Any]:
        """
        Modify role positions.

        Args:
            positions: List of {id, position} dicts
            reason: Audit log reason

        Returns:
            Updated roles
        """
        headers = {}
        if reason:
            headers["X-Audit-Log-Reason"] = reason

        data = await self._http.modify_guild_role_positions(
            self.guild_id, json=positions, headers=headers
        )
        return data

    def __repr__(self) -> str:
        return f"<RoleManager guild={self.guild_id}>"


__all__ = ["MemberManager", "RoleManager"]

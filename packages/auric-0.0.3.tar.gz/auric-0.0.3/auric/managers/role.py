"""
Role Manager - Manage roles in a guild

Discord.js equivalent: RoleManager
"""

from typing import TYPE_CHECKING, List, Optional

from ..models.guild import Guild
from .base import BaseManager

if TYPE_CHECKING:
    from ..models.role import Role


class RoleManager(BaseManager[Role]):
    """
    A manager for a guild's roles.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(self) -> List[Role]:
        """
        Fetches all roles for the guild.

        Returns:
            A list of roles.
        """
        roles_data = await self._http.get_guild_roles(self.guild.id)
        roles = [Role(role, self.guild.id, self._http) for role in roles_data]
        for role in roles:
            self._cache[role.id] = role
        return roles

    async def create(
        self, *, name: str, reason: Optional[str] = None, **kwargs
    ) -> Role:
        """
        Creates a new role in the guild.

        Args:
            name: The name of the role.
            reason: The reason for creating the role.
            **kwargs: Additional role attributes.

        Returns:
            The created role.
        """
        role_data = await self._http.create_guild_role(
            self.guild.id, name=name, reason=reason, **kwargs
        )
        role = Role(role_data, self.guild.id, self._http)
        self._cache[role.id] = role
        return role

    async def delete(self, role_id: int, *, reason: Optional[str] = None) -> None:
        """
        Deletes a role from the guild.

        Args:
            role_id: The ID of the role to delete.
            reason: The reason for deleting the role.
        """
        await self._http.delete_guild_role(self.guild.id, role_id, reason=reason)
        self._cache.pop(role_id, None)

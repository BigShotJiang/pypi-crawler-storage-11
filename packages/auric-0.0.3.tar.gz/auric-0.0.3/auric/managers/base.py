"""
Base Manager class for all Discord resource managers
"""
from typing import Any, Callable, Generic, Optional, TypeVar


from ..core.types import Snowflake
from ..utils.collection import Collection

T = TypeVar("T")


class BaseManager(Generic[T]):
    """
    Base class for all managers.

    Managers handle caching, fetching, and managing Discord resources.
    Similar to discord.js Manager pattern.

    Example:
        ```python
        class MessageManager(BaseManager[Message]):
            async def fetch(self, message_id: Snowflake) -> Message:
                data = await self._http.get_message(self.channel_id, message_id)
                return self._add(message_id, Message(data, http=self._http))
        ```
    """

    def __init__(self, http, cache: bool = True, max_size: int = 1000):
        """
        Initialize manager

        Args:
            client: The Discord client
            http: HTTP client for API requests
            cache: Whether to cache items
            max_size: Maximum cache size
        """
        self._client = http._client if hasattr(http, "_client") else None
        self._http = http
        self._cache_enabled = cache
        self._max_size = max_size
        self.cache: Collection[Snowflake, T] = Collection()

    def _add(self, key: Snowflake, value: T, replace: bool = True) -> T:
        """
        Add item to cache

        Args:
            key: Item ID
            value: Item to cache
            replace: Whether to replace existing item

        Returns:
            The cached item
        """
        if not self._cache_enabled:
            return value

        # Check cache size limit
        if self.cache.size >= self._max_size:
            # Remove oldest item (FIFO)
            first_key = (
                self.cache.first_key()
                if hasattr(self.cache, "first_key")
                else next(iter(self.cache.keys()))
            )
            self.cache.delete(first_key)

        if replace or not self.cache.has(key):
            self.cache.set(key, value)

        return value

    def _remove(self, key: Snowflake) -> Optional[T]:
        """Remove item from cache"""
        item = self.cache.get(key)
        if item:
            self.cache.delete(key)
        return item

    def resolve(self, resolvable: Any) -> Optional[T]:
        """
        Resolve an ID or object to a cached object

        Args:
            resolvable: Snowflake ID, string ID, or object

        Returns:
            Resolved object or None
        """
        # If it's already the object type, return it
        if hasattr(resolvable, "id"):
            return resolvable

        # Try to resolve as ID
        try:
            snowflake = int(resolvable)
            return self.cache.get(snowflake)
        except (ValueError, TypeError):
            return None

    def resolve_id(self, resolvable: Any) -> Optional[Snowflake]:
        """
        Resolve to an ID

        Args:
            resolvable: Snowflake ID, string ID, or object with .id

        Returns:
            Snowflake ID or None
        """
        if hasattr(resolvable, "id"):
            return resolvable.id

        try:
            return int(resolvable)
        except (ValueError, TypeError):
            return None

    async def fetch(self, id: Snowflake, **kwargs) -> Optional[T]:
        """
        Fetch item from API

        Must be implemented by subclasses.

        Args:
            id: Item ID
            **kwargs: Additional fetch options

        Returns:
            Fetched item
        """
        raise NotImplementedError("Subclasses must implement fetch()")

    async def create(self, **kwargs) -> T:
        """
        Create a new resource

        Must be implemented by subclasses if creation is supported.

        Args:
            **kwargs: Creation parameters

        Returns:
            Created item
        """
        raise NotImplementedError("This manager does not support creation")

    async def edit(self, id: Snowflake, **kwargs) -> T:
        """
        Edit a resource

        Must be implemented by subclasses if editing is supported.

        Args:
            id: Item ID
            **kwargs: Edit parameters

        Returns:
            Edited item
        """
        raise NotImplementedError("This manager does not support editing")

    async def delete(self, id: Snowflake, **kwargs) -> bool:
        """
        Delete a resource

        Must be implemented by subclasses if deletion is supported.

        Args:
            id: Item ID
            **kwargs: Delete options

        Returns:
            True if deleted successfully
        """
        raise NotImplementedError("This manager does not support deletion")

    def sweep(self, fn: Callable[[T], bool]) -> int:
        """
        Remove cached items matching predicate

        Args:
            fn: Predicate function

        Returns:
            Number of items removed
        """
        return self.cache.sweep(fn)

    @property
    def size(self) -> int:
        """Get cache size"""
        return self.cache.size

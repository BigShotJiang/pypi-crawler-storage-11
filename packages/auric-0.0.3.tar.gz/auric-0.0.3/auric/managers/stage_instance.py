"""
Manager for Stage Instances for a guild.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..models.stage_instance import StageInstance
from .base import BaseManager

if TYPE_CHECKING:
    from ..models.guild import Guild


class StageInstanceManager(BaseManager[StageInstance]):
    """
    A manager for a guild's stage instances.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(self, channel_id: int) -> StageInstance:
        """
        Fetches a stage instance for a channel.

        Args:
            channel_id: The ID of the stage channel.

        Returns:
            A stage instance.
        """
        instance_data = await self._http.get_stage_instance(channel_id)
        instance = StageInstance(instance_data, self._http)
        self._cache[instance.id] = instance
        return instance

"""
Manager for Voice Regions for a guild.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from ..models.voice import VoiceRegion
from .base import BaseManager

if TYPE_CHECKING:
    from ..models.guild import Guild


class VoiceRegionManager(BaseManager[VoiceRegion]):
    """
    A manager for a guild's voice regions.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(self) -> List[VoiceRegion]:
        """
        Fetches all voice regions for the guild.

        Returns:
            A list of voice regions.
        """
        regions_data = await self._http.list_voice_regions()
        regions = [VoiceRegion(region) for region in regions_data]
        for region in regions:
            self._cache[region.id] = region
        return regions

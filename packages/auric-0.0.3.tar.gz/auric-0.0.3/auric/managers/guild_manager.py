"""
Guild Manager for advanced guild operations and caching
"""
from typing import Dict, List, Optional, Callable


from ..models.guild import Guild
from ..utils.collection import Collection
from .base import BaseManager


class GuildManager(BaseManager):
    """
    Manages guilds with caching and advanced operations.

    Provides efficient guild management, caching, search,
    and batch operations.

    Example:
        ```python
        # Get guild
        guild = await client.guilds.fetch(guild_id)

        # Search guilds
        large_guilds = client.guilds.filter(lambda g: g.member_count > 1000)

        # Get cached
        guild = client.guilds.get(guild_id)
        ```
    """

    def __init__(self, http):
        super().__init__(http)
        self.cache: Collection[int, Guild] = Collection()

    def add(self, guild: Guild) -> Guild:
        """
        Add guild to cache.

        Args:
            guild: Guild to cache

        Returns:
            The cached guild
        """
        self.cache.set(guild.id, guild)
        return guild

    def remove(self, guild_id: int) -> Optional[Guild]:
        """
        Remove guild from cache.

        Args:
            guild_id: Guild ID to remove

        Returns:
            Removed guild or None
        """
        return self.cache.delete(guild_id)

    def get(self, guild_id: int) -> Optional[Guild]:
        """
        Get cached guild by ID.

        Args:
            guild_id: Guild ID

        Returns:
            Cached guild or None
        """
        return self.cache.get(guild_id)

    async def fetch(self, guild_id: int, *, with_counts: bool = False) -> Guild:
        """
        Fetch guild from API.

        Args:
            guild_id: Guild ID
            with_counts: Include approximate member and presence counts

        Returns:
            Guild object

        Raises:
            NotFound: Guild not found
            Forbidden: No access to guild
        """
        params = {}
        if with_counts:
            params["with_counts"] = "true"

        data = await self._http.get_guild(guild_id, params=params)
        guild = Guild(data, self._client)
        return self.add(guild)

    async def fetch_preview(self, guild_id: int):
        """
        Fetch guild preview (for discovery).

        Args:
            guild_id: Guild ID

        Returns:
            Guild preview data
        """
        return await self._http.get_guild_preview(guild_id)

    async def create(
        self,
        name: str,
        *,
        icon: Optional[str] = None,
        verification_level: int = 0,
        default_message_notifications: int = 0,
        explicit_content_filter: int = 0,
        roles: Optional[List[Dict]] = None,
        channels: Optional[List[Dict]] = None,
        afk_channel_id: Optional[int] = None,
        afk_timeout: int = 300,
        system_channel_id: Optional[int] = None,
        system_channel_flags: int = 0,
    ) -> Guild:
        """
        Create a new guild.

        Bot must be in fewer than 10 guilds.

        Args:
            name: Guild name (2-100 characters)
            icon: Base64 icon data
            verification_level: Verification level (0-4)
            default_message_notifications: Notification level (0-1)
            explicit_content_filter: Content filter level (0-2)
            roles: Initial roles
            channels: Initial channels
            afk_channel_id: AFK channel ID
            afk_timeout: AFK timeout in seconds
            system_channel_id: System messages channel
            system_channel_flags: System channel flags

        Returns:
            Created guild
        """
        payload = {
            "name": name,
            "verification_level": verification_level,
            "default_message_notifications": default_message_notifications,
            "explicit_content_filter": explicit_content_filter,
            "afk_timeout": afk_timeout,
            "system_channel_flags": system_channel_flags,
        }

        if icon:
            payload["icon"] = icon
        if roles:
            payload["roles"] = roles
        if channels:
            payload["channels"] = channels
        if afk_channel_id:
            payload["afk_channel_id"] = str(afk_channel_id)
        if system_channel_id:
            payload["system_channel_id"] = str(system_channel_id)

        data = await self._http.create_guild(json=payload)
        guild = Guild(data, self._client)
        return self.add(guild)

    async def modify(self, guild_id: int, **kwargs) -> Guild:
        """
        Modify a guild.

        Args:
            guild_id: Guild ID
            **kwargs: Fields to modify

        Returns:
            Modified guild
        """
        data = await self._http.modify_guild(guild_id, json=kwargs)
        guild = Guild(data, self._client)
        return self.add(guild)

    async def delete(self, guild_id: int) -> None:
        """
        Delete a guild.

        Args:
            guild_id: Guild ID
        """
        await self._http.delete_guild(guild_id)
        self.remove(guild_id)

    async def leave(self, guild_id: int) -> None:
        """
        Leave a guild.

        Args:
            guild_id: Guild ID to leave
        """
        await self._http.leave_guild(guild_id)
        self.remove(guild_id)

    def filter(self, predicate: Callable[[Guild], bool]) -> List[Guild]:
        """
        Filter cached guilds.

        Args:
            predicate: Filter function

        Returns:
            List of matching guilds
        """
        return [g for g in self.cache.values() if predicate(g)]

    def find(self, predicate: Callable[[Guild], bool]) -> Optional[Guild]:
        """
        Find first matching guild.

        Args:
            predicate: Filter function

        Returns:
            First matching guild or None
        """
        return next((g for g in self.cache.values() if predicate(g)), None)

    def search(self, name: str, *, case_sensitive: bool = False) -> List[Guild]:
        """
        Search guilds by name.

        Args:
            name: Name to search for
            case_sensitive: Case-sensitive search

        Returns:
            Matching guilds
        """
        if case_sensitive:
            return self.filter(lambda g: name in g.name)
        else:
            name_lower = name.lower()
            return self.filter(lambda g: name_lower in g.name.lower())

    @property
    def count(self) -> int:
        """Get cached guild count"""
        return len(self.cache)

    @property
    def total_members(self) -> int:
        """Get total member count across all cached guilds"""
        return sum(g.member_count or 0 for g in self.cache.values())

    def get_largest(self, limit: int = 10) -> List[Guild]:
        """
        Get largest guilds by member count.

        Args:
            limit: Maximum guilds to return

        Returns:
            List of largest guilds
        """
        sorted_guilds = sorted(self.cache.values(), key=lambda g: g.member_count or 0, reverse=True)
        return sorted_guilds[:limit]

    def get_oldest(self, limit: int = 10) -> List[Guild]:
        """
        Get oldest guilds by creation date.

        Args:
            limit: Maximum guilds to return

        Returns:
            List of oldest guilds
        """
        sorted_guilds = sorted(
            self.cache.values(), key=lambda g: g.id  # Snowflake IDs are chronological
        )
        return sorted_guilds[:limit]

    def get_newest(self, limit: int = 10) -> List[Guild]:
        """
        Get newest guilds by creation date.

        Args:
            limit: Maximum guilds to return

        Returns:
            List of newest guilds
        """
        sorted_guilds = sorted(self.cache.values(), key=lambda g: g.id, reverse=True)
        return sorted_guilds[:limit]

    def clear_cache(self) -> None:
        """Clear guild cache"""
        self.cache.clear()

    def __len__(self) -> int:
        return self.count

    def __iter__(self):
        return iter(self.cache.values())

    def __repr__(self) -> str:
        return f"<GuildManager guilds={self.count}>"

"""
Manager for Auto Moderation rules for a guild.
"""
from __future__ import annotations
from typing import List, Optional, TYPE_CHECKING


from ..models.auto_moderation import AutoModRule, AutoModTriggerType, AutoModAction
from .base import BaseManager

if TYPE_CHECKING:
    from ..models.guild import Guild


class AutoModManager(BaseManager[AutoModRule]):
    """
    A manager for a guild's auto-moderation rules.

    Attributes:
        guild: The guild this manager belongs to.
    """

    __slots__ = ("guild",)

    def __init__(self, guild: Guild) -> None:
        super().__init__(guild._http)
        self.guild = guild

    async def fetch(self) -> List[AutoModRule]:
        """
        Fetches all auto-moderation rules for the guild.

        Returns:
            A list of auto-moderation rules.
        """
        rules_data = await self._http.get_auto_mod_rules(self.guild.id)
        rules = [AutoModRule(rule, self._http) for rule in rules_data]
        for rule in rules:
            self._cache[rule.id] = rule
        return rules

    async def create(
        self,
        *,
        name: str,
        trigger_type: AutoModTriggerType,
        actions: List[AutoModAction],
        event_type: int = 1,
        trigger_metadata: Optional[dict] = None,
        enabled: bool = True,
        exempt_roles: Optional[List[int]] = None,
        exempt_channels: Optional[List[int]] = None,
        reason: Optional[str] = None,
    ) -> AutoModRule:
        """
        Creates a new auto-moderation rule for the guild.

        Args:
            name: The name of the rule.
            trigger_type: The type of trigger for the rule.
            actions: The actions to take when the rule is triggered.
            event_type: The event type for the rule.
            trigger_metadata: The metadata for the trigger.
            enabled: Whether the rule is enabled.
            exempt_roles: A list of role IDs to exempt from the rule.
            exempt_channels: A list of channel IDs to exempt from the rule.
            reason: The reason for creating the rule.

        Returns:
            The created auto-moderation rule.
        """
        payload = {
            "name": name,
            "trigger_type": trigger_type,
            "actions": [action.to_dict() for action in actions],
            "event_type": event_type,
            "enabled": enabled,
        }
        if trigger_metadata:
            payload["trigger_metadata"] = trigger_metadata
        if exempt_roles:
            payload["exempt_roles"] = exempt_roles
        if exempt_channels:
            payload["exempt_channels"] = exempt_channels

        rule_data = await self._http.create_auto_moderation_rule(
            self.guild.id, json=payload, reason=reason
        )
        rule = AutoModRule(rule_data, self._http)
        self._cache[rule.id] = rule
        return rule

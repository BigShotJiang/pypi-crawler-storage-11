"""Helper utilities for Auric Discord wrapper"""

import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

__all__ = [
    "snowflake_time",
    "time_snowflake",
    "parse_mention",
    "parse_emoji",
    "escape_markdown",
    "escape_mentions",
    "chunk_list",
    "get_user_avatar_url",
    "get_guild_icon_url",
    "resolve_invite",
]


def snowflake_time(snowflake: Union[int, str]) -> datetime:
    """
    Convert a Discord snowflake ID to a datetime object.

    Args:
        snowflake: The snowflake ID to convert

    Returns:
        datetime: The timestamp when the snowflake was created
    """
    snowflake = int(snowflake)
    timestamp = ((snowflake >> 22) + 1420070400000) / 1000
    return datetime.fromtimestamp(timestamp, tz=timezone.utc)


def time_snowflake(dt: datetime) -> int:
    """
    Convert a datetime object to a Discord snowflake ID.

    Args:
        dt: The datetime to convert

    Returns:
        int: The snowflake ID
    """
    timestamp = int(dt.timestamp() * 1000) - 1420070400000
    return timestamp << 22


def parse_mention(content: str) -> Dict[str, List[int]]:
    """
    Parse mentions from message content.

    Args:
        content: The message content

    Returns:
        dict: Dictionary with 'users', 'roles', and 'channels' keys containing IDs
    """
    result = {"users": [], "roles": [], "channels": []}

    # User mentions: <@123456789> or <@!123456789>
    result["users"] = [int(id) for id in re.findall(r"<@!?(\d+)>", content)]

    # Role mentions: <@&123456789>
    result["roles"] = [int(id) for id in re.findall(r"<@&(\d+)>", content)]

    # Channel mentions: <#123456789>
    result["channels"] = [int(id) for id in re.findall(r"<#(\d+)>", content)]

    return result


def parse_emoji(emoji: str) -> Optional[Dict[str, Any]]:
    """
    Parse emoji string to extract ID and name.

    Args:
        emoji: The emoji string (e.g., '<:name:123456789>' or '👍')

    Returns:
        dict: Dictionary with 'name', 'id', and 'animated' keys, or None for unicode emoji
    """
    # Custom emoji: <:name:id> or <a:name:id>
    match = re.match(r"<(a)?:([^:]+):(\d+)>", emoji)
    if match:
        return {"animated": bool(match.group(1)), "name": match.group(2), "id": int(match.group(3))}

    # Unicode emoji
    return None


def escape_markdown(text: str, *, as_needed: bool = False, ignore_links: bool = True) -> str:
    """
    Escape markdown characters in text.

    Args:
        text: The text to escape
        as_needed: Only escape when necessary
        ignore_links: Don't escape links

    Returns:
        str: The escaped text
    """
    if ignore_links:
        # Don't escape characters in URLs
        def escape_part(part: str) -> str:
            return re.sub(r"([\\*_`~|])", r"\\\1", part)

        # Split by URLs and escape non-URL parts
        url_pattern = r"https?://[^\s]+"
        parts = re.split(f"({url_pattern})", text)
        return "".join(part if re.match(url_pattern, part) else escape_part(part) for part in parts)

    return re.sub(r"([\\*_`~|])", r"\\\1", text)


def escape_mentions(text: str) -> str:
    """
    Escape mentions in text to prevent pinging.

    Args:
        text: The text to escape

    Returns:
        str: The escaped text
    """
    # Add zero-width space to break mentions
    text = re.sub(r"@(everyone|here)", r"@\u200b\1", text)
    text = re.sub(r"<@([!&]?\d+)>", r"<@\u200b\1>", text)
    return text


def chunk_list(items: List[Any], chunk_size: int) -> List[List[Any]]:
    """
    Split a list into chunks of specified size.

    Args:
        items: The list to chunk
        chunk_size: Maximum size of each chunk

    Returns:
        list: List of chunked lists
    """
    return [items[i : i + chunk_size] for i in range(0, len(items), chunk_size)]


def get_user_avatar_url(
    user_id: int, avatar_hash: Optional[str], *, format: str = "png", size: int = 1024
) -> str:
    """
    Get the avatar URL for a user.

    Args:
        user_id: The user's ID
        avatar_hash: The avatar hash
        format: Image format (png, jpg, webp, gif)
        size: Image size (must be power of 2 between 16 and 4096)

    Returns:
        str: The avatar URL
    """
    if not avatar_hash:
        # Default avatar
        return f"https://cdn.discordapp.com/embed/avatars/{(user_id >> 22) % 6}.png"

    if avatar_hash.startswith("a_"):
        # Animated avatar
        format = "gif"

    return f"https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.{format}?size={size}"


def get_guild_icon_url(
    guild_id: int, icon_hash: Optional[str], *, format: str = "png", size: int = 1024
) -> str:
    """
    Get the icon URL for a guild.

    Args:
        guild_id: The guild's ID
        icon_hash: The icon hash
        format: Image format (png, jpg, webp, gif)
        size: Image size (must be power of 2 between 16 and 4096)

    Returns:
        str: The icon URL or empty string if no icon
    """
    if not icon_hash:
        return ""

    if icon_hash.startswith("a_"):
        # Animated icon
        format = "gif"

    return f"https://cdn.discordapp.com/icons/{guild_id}/{icon_hash}.{format}?size={size}"


def resolve_invite(invite: str) -> str:
    """
    Extract invite code from various invite formats.

    Args:
        invite: The invite string (code, URL, etc.)

    Returns:
        str: The invite code
    """
    # discord.gg/code
    match = re.search(r"discord\.gg/([a-zA-Z0-9-]+)", invite)
    if match:
        return match.group(1)

    # discord.com/invite/code
    match = re.search(r"discord\.com/invite/([a-zA-Z0-9-]+)", invite)
    if match:
        return match.group(1)

    # discordapp.com/invite/code
    match = re.search(r"discordapp\.com/invite/([a-zA-Z0-9-]+)", invite)
    if match:
        return match.group(1)

    # Just the code
    return invite

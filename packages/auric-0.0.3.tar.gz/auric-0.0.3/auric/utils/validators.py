"""Validators for Discord data"""

import re
from typing import Optional

__all__ = [
    "validate_token",
    "validate_snowflake",
    "validate_color",
    "validate_username",
    "validate_discriminator",
    "validate_invite_code",
    "validate_webhook_url",
    "is_valid_url",
    "is_valid_image_url",
]


def validate_token(token: str) -> bool:
    """
    Validate a Discord bot token format.

    Args:
        token: The token to validate

    Returns:
        bool: True if valid format
    """
    if not token or not isinstance(token, str):
        return False

    # Bot tokens have 3 parts separated by dots
    parts = token.split(".")
    if len(parts) != 3:
        return False

    # Each part should be base64-like
    return all(part and part.replace("_", "").replace("-", "").isalnum() for part in parts)


def validate_snowflake(snowflake: any) -> bool:
    """
    Validate a Discord snowflake ID.

    Args:
        snowflake: The snowflake to validate

    Returns:
        bool: True if valid snowflake
    """
    try:
        value = int(snowflake)
        # Snowflakes should be positive and reasonable size
        return 0 < value < (1 << 63)
    except (ValueError, TypeError):
        return False


def validate_color(color: int) -> bool:
    """
    Validate a Discord color value.

    Args:
        color: The color value (0-16777215)

    Returns:
        bool: True if valid color
    """
    return isinstance(color, int) and 0 <= color <= 0xFFFFFF


def validate_username(username: str) -> tuple[bool, Optional[str]]:
    """
    Validate a Discord username.

    Args:
        username: The username to validate

    Returns:
        tuple: (is_valid, error_message)
    """
    if not username:
        return False, "Username cannot be empty"

    if len(username) < 2:
        return False, "Username must be at least 2 characters"

    if len(username) > 32:
        return False, "Username must be at most 32 characters"

    # Check for prohibited characters
    if "@" in username or "#" in username or ":" in username:
        return False, "Username cannot contain @, #, or :"

    # Check for discord clyde
    if username.lower() in ("discord", "clyde", "everyone", "here"):
        return False, f"Username cannot be '{username}'"

    return True, None


def validate_discriminator(discriminator: str) -> bool:
    """
    Validate a Discord discriminator.

    Args:
        discriminator: The discriminator to validate

    Returns:
        bool: True if valid discriminator
    """
    if not discriminator:
        return False

    # Must be 4 digits
    return discriminator.isdigit() and len(discriminator) == 4


def validate_invite_code(code: str) -> bool:
    """
    Validate a Discord invite code.

    Args:
        code: The invite code

    Returns:
        bool: True if valid format
    """
    if not code:
        return False

    # Invite codes are alphanumeric and hyphens, 2-32 characters
    return bool(re.match(r"^[a-zA-Z0-9-]{2,32}$", code))


def validate_webhook_url(url: str) -> bool:
    """
    Validate a Discord webhook URL.

    Args:
        url: The webhook URL

    Returns:
        bool: True if valid webhook URL
    """
    if not url:
        return False

    # Match Discord webhook URL pattern
    pattern = r"https://(?:discord|discordapp)\.com/api/webhooks/\d+/[\w-]+"
    return bool(re.match(pattern, url))


def is_valid_url(url: str) -> bool:
    """
    Check if string is a valid URL.

    Args:
        url: The URL to check

    Returns:
        bool: True if valid URL
    """
    if not url:
        return False

    # Basic URL pattern
    pattern = r"https?://(?:[\w-]+\.)+[\w-]+(?:/[\w-./?%&=]*)?"
    return bool(re.match(pattern, url))


def is_valid_image_url(url: str) -> bool:
    """
    Check if URL is a valid image URL.

    Args:
        url: The URL to check

    Returns:
        bool: True if valid image URL
    """
    if not is_valid_url(url):
        return False

    # Check for common image extensions
    image_extensions = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp")
    url_lower = url.lower()

    # Check extension or known CDN patterns
    return (
        url_lower.endswith(image_extensions)
        or "cdn.discordapp.com" in url_lower
        or "media.discordapp.net" in url_lower
    )


def validate_content_length(content: str, max_length: int = 2000) -> tuple[bool, Optional[str]]:
    """
    Validate message content length.

    Args:
        content: The message content
        max_length: Maximum allowed length

    Returns:
        tuple: (is_valid, error_message)
    """
    if not content:
        return False, "Content cannot be empty"

    if len(content) > max_length:
        return False, f"Content exceeds maximum length of {max_length} characters"

    return True, None


def validate_embed_limits(embed_dict: dict) -> tuple[bool, Optional[str]]:
    """
    Validate embed against Discord limits.

    Args:
        embed_dict: The embed dictionary

    Returns:
        tuple: (is_valid, error_message)
    """
    # Title limit
    title = embed_dict.get("title", "")
    if len(title) > 256:
        return False, "Embed title exceeds 256 characters"

    # Description limit
    description = embed_dict.get("description", "")
    if len(description) > 4096:
        return False, "Embed description exceeds 4096 characters"

    # Fields limit
    fields = embed_dict.get("fields", [])
    if len(fields) > 25:
        return False, "Embed cannot have more than 25 fields"

    # Field limits
    for i, field in enumerate(fields):
        if len(field.get("name", "")) > 256:
            return False, f"Field {i} name exceeds 256 characters"
        if len(field.get("value", "")) > 1024:
            return False, f"Field {i} value exceeds 1024 characters"

    # Footer limit
    footer = embed_dict.get("footer", {})
    if len(footer.get("text", "")) > 2048:
        return False, "Footer text exceeds 2048 characters"

    # Author limit
    author = embed_dict.get("author", {})
    if len(author.get("name", "")) > 256:
        return False, "Author name exceeds 256 characters"

    # Total length limit
    total_length = (
        len(title)
        + len(description)
        + sum(len(f.get("name", "")) + len(f.get("value", "")) for f in fields)
        + len(footer.get("text", ""))
        + len(author.get("name", ""))
    )

    if total_length > 6000:
        return False, "Total embed length exceeds 6000 characters"

    return True, None

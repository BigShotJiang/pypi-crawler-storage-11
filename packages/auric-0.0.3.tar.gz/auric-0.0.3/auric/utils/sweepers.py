"""
Cache Sweepers - Automatic cache management

Discord.js has automatic cache sweeping to manage memory.
"""

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Callable, Dict, Optional

logger = logging.getLogger(__name__)


@dataclass
class SweeperOptions:
    """Options for a sweeper"""

    interval: float  # Seconds between sweeps
    lifetime: float  # Seconds before item is considered old
    filter: Optional[Callable] = None  # Optional filter function


class Sweepers:
    """
    Manages automatic cache sweeping.

    Similar to discord.js Sweepers.

    Example:
        ```python
        # Sweep messages older than 1 hour every 30 minutes
        client.sweepers.sweep_messages(
            interval=1800,  # 30 minutes
            lifetime=3600   # 1 hour
        )

        # Sweep users not in any guild cache
        client.sweepers.sweep_users(
            interval=3600,
            filter=lambda u: not any(g.members.cache.has(u.id) for g in client.guilds.cache.array())
        )
        ```
    """

    def __init__(self, client):
        self.client = client
        self._tasks: Dict[str, asyncio.Task] = {}
        self._running = False

    def start(self):
        """Start all sweepers"""
        self._running = True
        logger.info("Cache sweepers started")

    def stop(self):
        """Stop all sweepers"""
        self._running = False
        for task in self._tasks.values():
            task.cancel()
        self._tasks.clear()
        logger.info("Cache sweepers stopped")

    async def _sweep_loop(self, name: str, cache, options: SweeperOptions):
        """Internal sweep loop"""
        while self._running:
            try:
                await asyncio.sleep(options.interval)

                if not self._running:
                    break

                # Perform sweep
                current_time = time.time()
                removed = 0

                def should_remove(item, key):
                    # Check lifetime
                    if hasattr(item, "created_at"):
                        age = current_time - item.created_at.timestamp()
                        if age < options.lifetime:
                            return False

                    # Check custom filter
                    if options.filter:
                        return options.filter(item, key)

                    return True

                removed = cache.sweep(should_remove)

                if removed > 0:
                    logger.debug(f"Swept {removed} items from {name} cache")

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in {name} sweeper: {e}", exc_info=True)

    def sweep_messages(
        self, interval: float = 3600, lifetime: float = 1800, filter: Optional[Callable] = None
    ):
        """
        Sweep message caches

        Args:
            interval: Seconds between sweeps (default 1 hour)
            lifetime: Seconds before message is swept (default 30 min)
            filter: Optional filter function
        """
        if "messages" in self._tasks:
            self._tasks["messages"].cancel()

        options = SweeperOptions(interval, lifetime, filter)

        # Sweep all channel message caches
        async def sweep_all_messages():
            while self._running:
                try:
                    await asyncio.sleep(interval)

                    total_removed = 0
                    for channel in self.client.channels.cache.array():
                        if hasattr(channel, "messages"):
                            removed = channel.messages.cache.sweep(
                                lambda m, k: should_remove(m, k, options)
                            )
                            total_removed += removed

                    if total_removed > 0:
                        logger.debug(f"Swept {total_removed} messages")

                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"Error sweeping messages: {e}", exc_info=True)

        def should_remove(item, key, opts):
            current_time = time.time()
            if hasattr(item, "timestamp"):
                age = current_time - item.timestamp.timestamp()
                if age < opts.lifetime:
                    return False

            if opts.filter:
                return opts.filter(item, key)

            return True

        self._tasks["messages"] = asyncio.create_task(sweep_all_messages())

    def sweep_users(self, interval: float = 3600, filter: Optional[Callable] = None):
        """
        Sweep user cache

        Args:
            interval: Seconds between sweeps
            filter: Filter function (required for users)
        """
        if not filter:
            # Default: remove users not in any guild
            def default_filter(user, key):
                return not any(
                    g.members.cache.has(user.id)
                    for g in self.client.guilds.cache.array()
                    if hasattr(g, "members")
                )

            filter = default_filter

        if "users" in self._tasks:
            self._tasks["users"].cancel()

        options = SweeperOptions(interval, 0, filter)
        self._tasks["users"] = asyncio.create_task(
            self._sweep_loop("users", self.client.users.cache, options)
        )

    def sweep_guilds(self, interval: float = 3600, filter: Optional[Callable] = None):
        """Sweep guild cache (careful with this!)"""
        if not filter:
            logger.warning("Sweeping guilds without filter is not recommended")
            return

        if "guilds" in self._tasks:
            self._tasks["guilds"].cancel()

        options = SweeperOptions(interval, 0, filter)
        self._tasks["guilds"] = asyncio.create_task(
            self._sweep_loop("guilds", self.client.guilds.cache, options)
        )

    def sweep_emojis(
        self, interval: float = 3600, lifetime: float = 3600, filter: Optional[Callable] = None
    ):
        """Sweep emoji caches"""
        if "emojis" in self._tasks:
            self._tasks["emojis"].cancel()

        options = SweeperOptions(interval, lifetime, filter)

        async def sweep_all_emojis():
            while self._running:
                try:
                    await asyncio.sleep(interval)

                    total_removed = 0
                    for guild in self.client.guilds.cache.array():
                        if hasattr(guild, "emojis"):
                            removed = guild.emojis.cache.sweep(
                                lambda e, k: should_remove(e, k, options)
                            )
                            total_removed += removed

                    if total_removed > 0:
                        logger.debug(f"Swept {total_removed} emojis")

                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"Error sweeping emojis: {e}", exc_info=True)

        def should_remove(item, key, opts):
            if opts.filter:
                return opts.filter(item, key)
            return False

        self._tasks["emojis"] = asyncio.create_task(sweep_all_emojis())

    def sweep_threads(
        self, interval: float = 3600, lifetime: float = 3600, filter: Optional[Callable] = None
    ):
        """Sweep archived thread caches"""
        if "threads" in self._tasks:
            self._tasks["threads"].cancel()

        options = SweeperOptions(interval, lifetime, filter)

        async def sweep_all_threads():
            while self._running:
                try:
                    await asyncio.sleep(interval)

                    total_removed = 0
                    for channel in self.client.channels.cache.array():
                        if hasattr(channel, "threads"):
                            removed = channel.threads.cache.sweep(
                                lambda t, k: should_remove_thread(t, k, options)
                            )
                            total_removed += removed

                    if total_removed > 0:
                        logger.debug(f"Swept {total_removed} threads")

                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"Error sweeping threads: {e}", exc_info=True)

        def should_remove_thread(item, key, opts):
            # Remove archived threads
            if hasattr(item, "archived") and item.archived:
                current_time = time.time()
                if hasattr(item, "archive_timestamp"):
                    age = current_time - item.archive_timestamp.timestamp()
                    if age >= opts.lifetime:
                        return True

            if opts.filter:
                return opts.filter(item, key)

            return False

        self._tasks["threads"] = asyncio.create_task(sweep_all_threads())

    def sweep_all(self, interval: float = 3600, lifetime: float = 1800):
        """
        Start sweeping all caches with default settings

        Args:
            interval: Seconds between sweeps (default 1 hour)
            lifetime: Seconds before item is swept (default 30 min)
        """
        self.sweep_messages(interval=interval, lifetime=lifetime)
        self.sweep_emojis(interval=interval, lifetime=lifetime)
        self.sweep_threads(interval=interval, lifetime=lifetime)

        logger.info(f"Started sweeping all caches (interval={interval}s, lifetime={lifetime}s)")


__all__ = ["Sweepers", "SweeperOptions"]

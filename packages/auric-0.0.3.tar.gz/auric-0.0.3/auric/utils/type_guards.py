"""
Type Guards for Interactions - Check interaction types

Discord.js has interaction.isButton(), interaction.isCommand(), etc.
"""

from ..types.interaction import ComponentType, InteractionType


class InteractionTypeGuards:
    """
    Mixin class to add type guard methods to Interaction.

    Similar to discord.js interaction type guards.
    """

    def is_command(self) -> bool:
        """Check if interaction is an application command"""
        return self.type == InteractionType.APPLICATION_COMMAND

    def is_button(self) -> bool:
        """Check if interaction is a button"""
        return (
            self.type == InteractionType.MESSAGE_COMPONENT
            and self.data.get("component_type") == ComponentType.BUTTON
        )

    def is_select_menu(self) -> bool:
        """Check if interaction is any select menu"""
        if self.type != InteractionType.MESSAGE_COMPONENT:
            return False
        component_type = self.data.get("component_type")
        return component_type in (
            ComponentType.STRING_SELECT,
            ComponentType.USER_SELECT,
            ComponentType.ROLE_SELECT,
            ComponentType.MENTIONABLE_SELECT,
            ComponentType.CHANNEL_SELECT,
        )

    def is_string_select(self) -> bool:
        """Check if interaction is a string select menu"""
        return (
            self.type == InteractionType.MESSAGE_COMPONENT
            and self.data.get("component_type") == ComponentType.STRING_SELECT
        )

    def is_user_select(self) -> bool:
        """Check if interaction is a user select menu"""
        return (
            self.type == InteractionType.MESSAGE_COMPONENT
            and self.data.get("component_type") == ComponentType.USER_SELECT
        )

    def is_role_select(self) -> bool:
        """Check if interaction is a role select menu"""
        return (
            self.type == InteractionType.MESSAGE_COMPONENT
            and self.data.get("component_type") == ComponentType.ROLE_SELECT
        )

    def is_mentionable_select(self) -> bool:
        """Check if interaction is a mentionable select menu"""
        return (
            self.type == InteractionType.MESSAGE_COMPONENT
            and self.data.get("component_type") == ComponentType.MENTIONABLE_SELECT
        )

    def is_channel_select(self) -> bool:
        """Check if interaction is a channel select menu"""
        return (
            self.type == InteractionType.MESSAGE_COMPONENT
            and self.data.get("component_type") == ComponentType.CHANNEL_SELECT
        )

    def is_message_component(self) -> bool:
        """Check if interaction is any message component"""
        return self.type == InteractionType.MESSAGE_COMPONENT

    def is_autocomplete(self) -> bool:
        """Check if interaction is autocomplete"""
        return self.type == InteractionType.APPLICATION_COMMAND_AUTOCOMPLETE

    def is_modal_submit(self) -> bool:
        """Check if interaction is modal submit"""
        return self.type == InteractionType.MODAL_SUBMIT

    def is_context_menu(self) -> bool:
        """Check if interaction is a context menu command"""
        if self.type != InteractionType.APPLICATION_COMMAND:
            return False
        return self.data.get("type") in (2, 3)

    def is_user_context_menu(self) -> bool:
        """Check if interaction is a user context menu"""
        return self.type == InteractionType.APPLICATION_COMMAND and self.data.get("type") == 2

    def is_message_context_menu(self) -> bool:
        """Check if interaction is a message context menu"""
        return self.type == InteractionType.APPLICATION_COMMAND and self.data.get("type") == 3

    def is_chat_input_command(self) -> bool:
        """Check if interaction is a chat input (slash) command"""
        return self.type == InteractionType.APPLICATION_COMMAND and self.data.get("type") == 1

    def is_repliable(self) -> bool:
        """Check if interaction can be replied to"""
        return self.type in (
            InteractionType.APPLICATION_COMMAND,
            InteractionType.MESSAGE_COMPONENT,
            InteractionType.APPLICATION_COMMAND_AUTOCOMPLETE,
            InteractionType.MODAL_SUBMIT,
        )

    def is_from_guild(self) -> bool:
        """Check if interaction is from a guild"""
        return self.guild_id is not None


__all__ = ["InteractionTypeGuards"]

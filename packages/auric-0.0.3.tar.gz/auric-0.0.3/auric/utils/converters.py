"""Type converters for Discord data"""

import re
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from ..core.client import Client
    from ..models.channel import Channel
    from ..models.emoji import Emoji
    from ..models.member import Member
    from ..models.role import Role
    from ..models.user import User

__all__ = [
    "to_snowflake",
    "to_bool",
    "to_color",
    "MemberConverter",
    "UserConverter",
    "ChannelConverter",
    "RoleConverter",
    "EmojiConverter",
    "ColorConverter",
]


def to_snowflake(value: Any) -> Optional[int]:
    """
    Convert value to snowflake ID.

    Args:
        value: Value to convert

    Returns:
        int: Snowflake ID or None
    """
    if value is None:
        return None

    if isinstance(value, int):
        return value

    if isinstance(value, str):
        # Try to extract ID from mention
        match = re.match(r"<[@#&!]*(\d+)>", value)
        if match:
            return int(match.group(1))

        # Try direct conversion
        try:
            return int(value)
        except ValueError:
            return None

    # Try to get ID attribute
    if hasattr(value, "id"):
        return int(value.id)

    return None


def to_bool(value: Any) -> bool:
    """
    Convert value to boolean.

    Args:
        value: Value to convert

    Returns:
        bool: Boolean value
    """
    if isinstance(value, bool):
        return value

    if isinstance(value, str):
        return value.lower() in ("yes", "true", "1", "on", "enable", "enabled")

    return bool(value)


def to_color(value: Any) -> Optional[int]:
    """
    Convert value to color integer.

    Args:
        value: Color value (hex string, int, or tuple)

    Returns:
        int: Color value or None
    """
    if value is None:
        return None

    if isinstance(value, int):
        return min(max(value, 0), 0xFFFFFF)

    if isinstance(value, str):
        # Remove # prefix if present
        value = value.lstrip("#")

        try:
            return int(value, 16) & 0xFFFFFF
        except ValueError:
            return None

    if isinstance(value, (tuple, list)) and len(value) == 3:
        # RGB tuple
        r, g, b = value
        return ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF)

    return None


class Converter:
    """Base converter class"""

    async def convert(self, client: "Client", argument: str) -> Any:
        """Convert string argument to target type"""
        raise NotImplementedError


class MemberConverter(Converter):
    """Convert string to Member"""

    async def convert(self, client: "Client", guild_id: int, argument: str) -> Optional["Member"]:
        """
        Convert string to Member.

        Args:
            client: The client instance
            guild_id: The guild ID
            argument: The argument to convert (mention, ID, or name)

        Returns:
            Member: The member or None
        """
        # Try ID/mention
        member_id = to_snowflake(argument)
        if member_id:
            return await client.http.get_guild_member(guild_id, member_id)

        # Try username
        members = await client.http.list_guild_members(guild_id, limit=1000)
        for member_data in members:
            user = member_data.get("user", {})
            if user.get("username", "").lower() == argument.lower():
                from ..models.member import Member

                return Member(data=member_data, http=client.http, guild_id=guild_id)

        return None


class UserConverter(Converter):
    """Convert string to User"""

    async def convert(self, client: "Client", argument: str) -> Optional["User"]:
        """
        Convert string to User.

        Args:
            client: The client instance
            argument: The argument to convert (mention or ID)

        Returns:
            User: The user or None
        """
        user_id = to_snowflake(argument)
        if user_id:
            return await client.http.get_user(user_id)

        return None


class ChannelConverter(Converter):
    """Convert string to Channel"""

    async def convert(self, client: "Client", guild_id: int, argument: str) -> Optional["Channel"]:
        """
        Convert string to Channel.

        Args:
            client: The client instance
            guild_id: The guild ID
            argument: The argument to convert (mention, ID, or name)

        Returns:
            Channel: The channel or None
        """
        # Try ID/mention
        channel_id = to_snowflake(argument)
        if channel_id:
            return await client.http.get_channel(channel_id)

        # Try name
        channels = await client.http.get_guild_channels(guild_id)
        for channel_data in channels:
            if channel_data.get("name", "").lower() == argument.lower():
                from ..models.channel import Channel

                return Channel(data=channel_data, http=client.http)

        return None


class RoleConverter(Converter):
    """Convert string to Role"""

    async def convert(self, client: "Client", guild_id: int, argument: str) -> Optional["Role"]:
        """
        Convert string to Role.

        Args:
            client: The client instance
            guild_id: The guild ID
            argument: The argument to convert (mention, ID, or name)

        Returns:
            Role: The role or None
        """
        # Try ID/mention
        role_id = to_snowflake(argument)
        if role_id:
            roles = await client.http.get_guild_roles(guild_id)
            for role_data in roles:
                if role_data["id"] == str(role_id):
                    from ..models.role import Role

                    return Role(role_data, client.http, guild_id)

        # Try name
        roles = await client.http.get_guild_roles(guild_id)
        for role_data in roles:
            if role_data.get("name", "").lower() == argument.lower():
                from ..models.role import Role

                return Role(role_data, client.http, guild_id)

        return None


class EmojiConverter(Converter):
    """Convert string to Emoji"""

    async def convert(self, client: "Client", guild_id: int, argument: str) -> Optional["Emoji"]:
        """
        Convert string to Emoji.

        Args:
            client: The client instance
            guild_id: The guild ID
            argument: The argument to convert (emoji string or name)

        Returns:
            Emoji: The emoji or None
        """
        # Try custom emoji format
        match = re.match(r"<(a)?:([^:]+):(\d+)>", argument)
        if match:
            emoji_id = int(match.group(3))
            return await client.http.get_guild_emoji(guild_id, emoji_id)

        # Try name
        emojis = await client.http.list_guild_emojis(guild_id)
        for emoji_data in emojis:
            if emoji_data.get("name", "").lower() == argument.lower():
                from ..models.emoji import Emoji

                return Emoji(emoji_data, client.http, guild_id)

        return None


class ColorConverter(Converter):
    """Convert string to color integer"""

    async def convert(self, client: "Client", argument: str) -> Optional[int]:
        """
        Convert string to color.

        Args:
            client: The client instance
            argument: The argument to convert (hex or color name)

        Returns:
            int: Color value or None
        """
        # Try direct conversion
        color = to_color(argument)
        if color is not None:
            return color

        # Try color names
        from ..models.color import Color

        color_name = argument.upper().replace(" ", "_")
        if hasattr(Color, color_name):
            return getattr(Color, color_name)

        return None

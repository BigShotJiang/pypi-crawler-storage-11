"""Time and timestamp utilities for Discord"""

from datetime import datetime, timezone
from enum import IntEnum
from typing import Optional, Union

__all__ = [
    "TimestampStyle",
    "format_timestamp",
    "parse_iso_timestamp",
    "snowflake_time",
    "relative_time",
    "duration",
    "duration_short",
    "parse_duration",
    "time_until",
    "time_since",
    "is_recent",
    "SECOND",
    "MINUTE",
    "HOUR",
    "DAY",
    "WEEK",
]


DISCORD_EPOCH = 1420070400000  # First second of 2015 in milliseconds


def snowflake_time(snowflake: Union[int, str]) -> datetime:
    """
    Extract timestamp from a Discord snowflake ID.

    Args:
        snowflake: The snowflake ID

    Returns:
        datetime: The creation time of the snowflake
    """
    snowflake_int = int(snowflake)
    timestamp_ms = (snowflake_int >> 22) + DISCORD_EPOCH
    return datetime.fromtimestamp(timestamp_ms / 1000, tz=timezone.utc)


class TimestampStyle(IntEnum):
    """Discord timestamp styles"""

    SHORT_TIME = 0  # 16:20
    LONG_TIME = 1  # 16:20:30
    SHORT_DATE = 2  # 20/04/2021
    LONG_DATE = 3  # 20 April 2021
    SHORT_DATETIME = 4  # 20 April 2021 16:20
    LONG_DATETIME = 5  # Tuesday, 20 April 2021 16:20
    RELATIVE = 6  # 2 months ago


# Style format strings
TIMESTAMP_STYLES = {
    TimestampStyle.SHORT_TIME: "t",
    TimestampStyle.LONG_TIME: "T",
    TimestampStyle.SHORT_DATE: "d",
    TimestampStyle.LONG_DATE: "D",
    TimestampStyle.SHORT_DATETIME: "f",
    TimestampStyle.LONG_DATETIME: "F",
    TimestampStyle.RELATIVE: "R",
}


def format_timestamp(
    dt: Union[datetime, int], style: TimestampStyle = TimestampStyle.SHORT_DATETIME
) -> str:
    """
    Format a timestamp for Discord messages.

    This creates a dynamic timestamp that displays in the user's local timezone.

    Args:
        dt: The datetime object or Unix timestamp
        style: The display style (default: SHORT_DATETIME)

    Returns:
        str: Discord timestamp markdown string

    Examples:
        >>> now = datetime.now(timezone.utc)
        >>> format_timestamp(now, TimestampStyle.RELATIVE)
        '<t:1234567890:R>'
        >>> format_timestamp(now, TimestampStyle.LONG_DATE)
        '<t:1234567890:D>'
    """
    if isinstance(dt, datetime):
        timestamp = int(dt.timestamp())
    else:
        timestamp = int(dt)

    style_char = TIMESTAMP_STYLES.get(style, "f")
    return f"<t:{timestamp}:{style_char}>"


def parse_iso_timestamp(timestamp: str) -> Optional[datetime]:
    """
    Parse an ISO 8601 timestamp from Discord API.

    Args:
        timestamp: The ISO timestamp string

    Returns:
        datetime: Parsed datetime object in UTC, or None if invalid

    Examples:
        >>> parse_iso_timestamp('2021-04-20T16:20:00.000000+00:00')
        datetime.datetime(2021, 4, 20, 16, 20, tzinfo=datetime.timezone.utc)
    """
    if not timestamp:
        return None

    try:
        # Try with microseconds
        return datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
    except ValueError:
        try:
            # Try without microseconds
            return datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S%z")
        except ValueError:
            return None


def utcnow() -> datetime:
    """
    Get current UTC time with timezone info.

    Returns:
        datetime: Current UTC datetime
    """
    return datetime.now(timezone.utc)


def discord_epoch() -> datetime:
    """
    Get Discord epoch (first second of 2015).

    Returns:
        datetime: Discord epoch datetime
    """
    return datetime(2015, 1, 1, tzinfo=timezone.utc)


def calculate_age(snowflake: Union[int, str]) -> float:
    """
    Calculate age of a snowflake in seconds.

    Args:
        snowflake: The snowflake ID

    Returns:
        float: Age in seconds
    """
    created = snowflake_time(snowflake)
    now = utcnow()
    return (now - created).total_seconds()


def format_duration(seconds: float) -> str:
    """
    Format duration in human-readable format.

    Args:
        seconds: Duration in seconds

    Returns:
        str: Formatted duration (e.g., "2h 30m 15s")
    """
    if seconds < 60:
        return f"{int(seconds)}s"

    minutes = int(seconds // 60)
    seconds = int(seconds % 60)

    if minutes < 60:
        return f"{minutes}m {seconds}s"

    hours = int(minutes // 60)
    minutes = int(minutes % 60)

    if hours < 24:
        return f"{hours}h {minutes}m {seconds}s"

    days = int(hours // 24)
    hours = int(hours % 24)

    return f"{days}d {hours}h {minutes}m {seconds}s"


def relative_time(dt: Union[datetime, int, float], precision: int = 2) -> str:
    """
    Format time relative to now (e.g., "2 hours ago")

    Args:
        dt: datetime object or Unix timestamp
        precision: Number of units to show (default: 2)

    Example:
        >>> relative_time(datetime.now() - timedelta(hours=2, minutes=30))
        '2 hours, 30 minutes ago'
    """
    from datetime import timedelta  # noqa: F401

    if isinstance(dt, (int, float)):
        dt = datetime.fromtimestamp(dt, tz=timezone.utc)

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)

    now = datetime.now(timezone.utc)
    delta = now - dt

    is_past = delta.total_seconds() >= 0
    delta = abs(delta)

    parts = []

    # Years
    years = delta.days // 365
    if years > 0:
        parts.append(f"{years} {'year' if years == 1 else 'years'}")

    # Months (approximate)
    if len(parts) < precision:
        remaining_days = delta.days - (years * 365)
        months = remaining_days // 30
        if months > 0:
            parts.append(f"{months} {'month' if months == 1 else 'months'}")

    # Days
    if len(parts) < precision:
        days = delta.days % 30
        if days > 0:
            parts.append(f"{days} {'day' if days == 1 else 'days'}")

    # Hours
    if len(parts) < precision:
        hours = delta.seconds // 3600
        if hours > 0:
            parts.append(f"{hours} {'hour' if hours == 1 else 'hours'}")

    # Minutes
    if len(parts) < precision:
        minutes = (delta.seconds % 3600) // 60
        if minutes > 0:
            parts.append(f"{minutes} {'minute' if minutes == 1 else 'minutes'}")

    # Seconds
    if len(parts) < precision:
        seconds = delta.seconds % 60
        if seconds > 0:
            parts.append(f"{seconds} {'second' if seconds == 1 else 'seconds'}")

    if not parts:
        return "just now"

    result = ", ".join(parts)
    return f"{result} ago" if is_past else f"in {result}"


def duration(seconds: Union[int, float], precision: int = 2) -> str:
    """
    Format duration in seconds as human-readable string

    Args:
        seconds: Duration in seconds
        precision: Number of units to show

    Example:
        >>> duration(3665)
        '1 hour, 1 minute'
    """
    if seconds < 0:
        return f"-{duration(abs(seconds), precision)}"

    parts = []

    # Days
    days = int(seconds // 86400)
    if days > 0:
        parts.append(f"{days} {'day' if days == 1 else 'days'}")
        seconds -= days * 86400

    # Hours
    hours = int(seconds // 3600)
    if hours > 0 and len(parts) < precision:
        parts.append(f"{hours} {'hour' if hours == 1 else 'hours'}")
        seconds -= hours * 3600

    # Minutes
    minutes = int(seconds // 60)
    if minutes > 0 and len(parts) < precision:
        parts.append(f"{minutes} {'minute' if minutes == 1 else 'minutes'}")
        seconds -= minutes * 60

    # Seconds
    secs = int(seconds)
    if secs > 0 and len(parts) < precision:
        parts.append(f"{secs} {'second' if secs == 1 else 'seconds'}")

    if not parts:
        return "0 seconds"

    return ", ".join(parts)


def duration_short(seconds: Union[int, float]) -> str:
    """
    Format duration in short format (HH:MM:SS)

    Example:
        >>> duration_short(3665)
        '1:01:05'
    """
    seconds = int(seconds)

    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60

    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    else:
        return f"{minutes}:{secs:02d}"


def parse_duration(text: str) -> int:
    """
    Parse duration string to seconds

    Supports: "5s", "30m", "2h", "1d", "1h 30m"

    Example:
        >>> parse_duration("1h 30m")
        5400
    """
    import re

    text = text.lower().strip()
    total = 0

    pattern = r"(\d+)\s*([a-z]+)"
    matches = re.findall(pattern, text)

    for value, unit in matches:
        value = int(value)

        if unit in ("s", "sec", "secs", "second", "seconds"):
            total += value
        elif unit in ("m", "min", "mins", "minute", "minutes"):
            total += value * 60
        elif unit in ("h", "hr", "hrs", "hour", "hours"):
            total += value * 3600
        elif unit in ("d", "day", "days"):
            total += value * 86400
        elif unit in ("w", "wk", "week", "weeks"):
            total += value * 604800

    return total


def time_until(dt: Union[datetime, int]) -> str:
    """Get time until a future datetime"""
    return relative_time(dt)


def time_since(dt: Union[datetime, int]) -> str:
    """Get time since a past datetime"""
    return relative_time(dt)


def is_recent(dt: Union[datetime, int], threshold_seconds: int = 300) -> bool:
    """
    Check if datetime is recent (within threshold)

    Args:
        dt: datetime or timestamp to check
        threshold_seconds: How many seconds is "recent" (default: 5 minutes)
    """
    if isinstance(dt, (int, float)):
        dt = datetime.fromtimestamp(dt, tz=timezone.utc)

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)

    now = datetime.now(timezone.utc)
    delta = abs((now - dt).total_seconds())

    return delta <= threshold_seconds


# Time constants (in seconds)
SECOND = 1
MINUTE = 60
HOUR = 3600
DAY = 86400
WEEK = 604800

"""Pagination utilities for Discord"""

from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

__all__ = ["Paginator", "PaginatorView", "chunk_list"]


def chunk_list(items: List[Any], chunk_size: int) -> List[List[Any]]:
    """
    Split a list into chunks.

    Args:
        items: List to chunk
        chunk_size: Size of each chunk

    Returns:
        list: List of chunks
    """
    return [items[i : i + chunk_size] for i in range(0, len(items), chunk_size)]


@dataclass
class Page:
    """Represents a page in a paginator"""

    content: Optional[str] = None
    embed: Optional[Dict] = None
    index: int = 0
    total: int = 0


class Paginator:
    """
    Text paginator for splitting content into pages.

    Useful for splitting long text into multiple Discord messages.
    """

    def __init__(
        self, prefix: str = "```", suffix: str = "```", max_size: int = 2000, linesep: str = "\n"
    ):
        """
        Initialize paginator.

        Args:
            prefix: Prefix for each page
            suffix: Suffix for each page
            max_size: Maximum characters per page
            linesep: Line separator
        """
        self.prefix = prefix
        self.suffix = suffix
        self.max_size = max_size
        self.linesep = linesep
        self._pages: List[str] = []
        self._current: List[str] = []
        self._count = len(prefix) + len(suffix)

    def add_line(self, line: str = "", *, empty: bool = False) -> None:
        """
        Add a line to the paginator.

        Args:
            line: The line to add
            empty: Whether to allow empty lines
        """
        if not empty and not line:
            return

        line_len = len(line) + len(self.linesep)

        if self._count + line_len > self.max_size:
            self.close_page()

        self._count += line_len
        self._current.append(line)

    def close_page(self) -> None:
        """Close the current page and start a new one"""
        if self._current:
            page = self.prefix + self.linesep.join(self._current) + self.suffix
            self._pages.append(page)
            self._current = []
            self._count = len(self.prefix) + len(self.suffix)

    @property
    def pages(self) -> List[str]:
        """Get all pages"""
        if self._current:
            self.close_page()
        return self._pages.copy()

    def __len__(self) -> int:
        """Get number of pages"""
        return len(self.pages)


class PaginatorView:
    """
    Interactive paginator with navigation buttons.

    This would typically use Discord components (buttons) for navigation.
    """

    def __init__(self, pages: List[Page], *, timeout: float = 180.0):
        """
        Initialize paginator view.

        Args:
            pages: List of pages to display
            timeout: Timeout in seconds
        """
        self.pages = pages
        self.timeout = timeout
        self.current_page = 0
        self.message = None
        self._stopped = False

    @property
    def page_count(self) -> int:
        """Get total number of pages"""
        return len(self.pages)

    def get_page(self, index: int) -> Page:
        """
        Get page at index.

        Args:
            index: Page index

        Returns:
            Page: The page
        """
        index = max(0, min(index, self.page_count - 1))
        page = self.pages[index]
        page.index = index + 1
        page.total = self.page_count
        return page

    def first_page(self) -> Page:
        """Go to first page"""
        return self.get_page(0)

    def last_page(self) -> Page:
        """Go to last page"""
        return self.get_page(self.page_count - 1)

    def next_page(self) -> Page:
        """Go to next page"""
        new_index = (self.current_page + 1) % self.page_count
        return self.get_page(new_index)

    def previous_page(self) -> Page:
        """Go to previous page"""
        new_index = (self.current_page - 1) % self.page_count
        return self.get_page(new_index)

    def stop(self) -> None:
        """Stop the paginator"""
        self._stopped = True


class EmbedPaginator:
    """Paginator specifically for embeds"""

    def __init__(self, *, max_fields: int = 25, max_description: int = 4096):
        """
        Initialize embed paginator.

        Args:
            max_fields: Maximum fields per page
            max_description: Maximum description length per page
        """
        self.max_fields = max_fields
        self.max_description = max_description
        self.embeds: List[Dict] = []
        self.current_embed: Dict = {"fields": []}

    def add_field(self, name: str, value: str, inline: bool = False) -> None:
        """
        Add a field to the current embed.

        Args:
            name: Field name
            value: Field value
            inline: Whether field is inline
        """
        if len(self.current_embed["fields"]) >= self.max_fields:
            self.close_embed()

        self.current_embed["fields"].append({"name": name, "value": value, "inline": inline})

    def set_base_embed(self, **kwargs) -> None:
        """
        Set base embed properties for all pages.

        Args:
            **kwargs: Embed properties
        """
        self.current_embed.update(kwargs)

    def close_embed(self) -> None:
        """Close current embed and start new one"""
        if self.current_embed.get("fields"):
            self.embeds.append(self.current_embed.copy())
            self.current_embed = {"fields": []}

    def get_embeds(self) -> List[Dict]:
        """Get all embed pages"""
        if self.current_embed.get("fields"):
            self.close_embed()
        return self.embeds.copy()

    def __len__(self) -> int:
        """Get number of embed pages"""
        return len(self.get_embeds())


class ListPaginator:
    """Paginator for lists of items"""

    def __init__(
        self,
        items: List[Any],
        per_page: int = 10,
        formatter: Optional[Callable[[Any, int], str]] = None,
    ):
        """
        Initialize list paginator.

        Args:
            items: Items to paginate
            per_page: Items per page
            formatter: Optional formatter function for items
        """
        self.items = items
        self.per_page = per_page
        self.formatter = formatter or (lambda item, idx: f"{idx}. {item}")
        self.pages = chunk_list(items, per_page)

    def format_page(self, page_index: int) -> str:
        """
        Format a page.

        Args:
            page_index: Page index

        Returns:
            str: Formatted page content
        """
        if page_index < 0 or page_index >= len(self.pages):
            return ""

        page = self.pages[page_index]
        start_index = page_index * self.per_page

        lines = [self.formatter(item, start_index + i + 1) for i, item in enumerate(page)]

        return "\n".join(lines)

    def __len__(self) -> int:
        """Get number of pages"""
        return len(self.pages)

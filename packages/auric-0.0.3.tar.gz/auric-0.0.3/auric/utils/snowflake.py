"""
Snowflake utilities - Parse Discord IDs and extract information

Discord uses Twitter Snowflakes for IDs - they encode timestamps!
"""

from datetime import datetime, timezone
from typing import Union

# Discord epoch (first second of 2015)
DISCORD_EPOCH = 1420070400000


class Snowflake:
    """
    Represents a Discord snowflake ID.

    Snowflakes are unique 64-bit integers that Discord uses as IDs.
    They contain timestamp information and can be used for sorting.

    Attributes
    ----------
    value : int
        The snowflake as an integer.
    """

    __slots__ = ("value",)

    def __init__(self, value: Union[int, str, "Snowflake"]) -> None:
        """
        Initialize a Snowflake.

        Parameters
        ----------
        value : int | str | Snowflake
            The snowflake value.
        """
        if isinstance(value, Snowflake):
            self.value = value.value
        elif isinstance(value, str):
            self.value = int(value)
        else:
            self.value = int(value)

    def __int__(self) -> int:
        return self.value

    def __str__(self) -> str:
        return str(self.value)

    def __repr__(self) -> str:
        return f"Snowflake({self.value})"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, (Snowflake, int, str)):
            return int(self) == int(Snowflake(other))
        return NotImplemented

    def __ne__(self, other: object) -> bool:
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __hash__(self) -> int:
        return hash(self.value)

    def __lt__(self, other: "Snowflake") -> bool:
        return self.value < int(other)

    def __le__(self, other: "Snowflake") -> bool:
        return self.value <= int(other)

    def __gt__(self, other: "Snowflake") -> bool:
        return self.value > int(other)

    def __ge__(self, other: "Snowflake") -> bool:
        return self.value >= int(other)

    @property
    def timestamp(self) -> int:
        """
        The timestamp of when this snowflake was created in milliseconds since Discord epoch.

        Returns
        -------
        int
            Milliseconds since Discord epoch.
        """
        return (self.value >> 22) + DISCORD_EPOCH

    @property
    def created_at(self) -> datetime:
        """
        When the snowflake was created.

        Returns
        -------
        datetime
            The creation datetime in UTC.
        """
        timestamp_seconds = self.timestamp / 1000
        return datetime.fromtimestamp(timestamp_seconds, tz=timezone.utc)

    @property
    def worker_id(self) -> int:
        """
        The internal worker ID that created this snowflake.

        Returns
        -------
        int
            The worker ID (0-31).
        """
        return (self.value & 0x3E0000) >> 17

    @property
    def process_id(self) -> int:
        """
        The internal process ID that created this snowflake.

        Returns
        -------
        int
            The process ID (0-31).
        """
        return (self.value & 0x1F000) >> 12

    @property
    def increment(self) -> int:
        """
        The increment for every snowflake generated on that process.

        Returns
        -------
        int
            The increment (0-4095).
        """
        return self.value & 0xFFF

    @classmethod
    def from_datetime(cls, dt: datetime) -> "Snowflake":
        """
        Create a snowflake from a datetime.

        This creates a "minimum" snowflake for that timestamp with all other
        fields set to 0. Useful for snowflake-based pagination.

        Parameters
        ----------
        dt : datetime
            The datetime to convert.

        Returns
        -------
        Snowflake
            A snowflake representing that timestamp.
        """
        timestamp_ms = int(dt.timestamp() * 1000)
        discord_ms = timestamp_ms - DISCORD_EPOCH
        return cls(discord_ms << 22)

    @classmethod
    def min(cls) -> "Snowflake":
        """
        Get the minimum possible snowflake value (0).

        Returns
        -------
        Snowflake
            The minimum snowflake.
        """
        return cls(0)

    @classmethod
    def max(cls) -> "Snowflake":
        """
        Get the maximum possible snowflake value.

        Returns
        -------
        Snowflake
            The maximum snowflake.
        """
        return cls((1 << 63) - 1)


def snowflake_time(snowflake: Union[str, int]) -> datetime:
    """
    Quick helper to get creation time from snowflake

    Example:
        ```python
        from auric.utils.snowflake import snowflake_time

        created = snowflake_time("1234567890123456789")
        print(f"Created at: {created}")
        ```
    """
    return Snowflake(snowflake).created_at


def snowflake_age(snowflake: Union[str, int]) -> float:
    """
    Get age of a snowflake in seconds

    Example:
        ```python
        from auric.utils.snowflake import snowflake_age

        age = snowflake_age("1234567890123456789")
        print(f"Age: {age} seconds")
        ```
    """
    created = Snowflake(snowflake).created_at
    now = datetime.now(timezone.utc)
    return (now - created).total_seconds()


def is_snowflake(value: Union[str, int]) -> bool:
    """
    Check if a value is a valid snowflake

    Example:
        ```python
        from auric.utils.snowflake import is_snowflake

        if is_snowflake("1234567890123456789"):
            print("Valid!")
        ```
    """
    try:
        Snowflake(value)
        return True
    except (ValueError, TypeError):
        return False

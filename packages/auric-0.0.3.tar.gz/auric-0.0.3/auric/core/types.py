"""
Core utilities and types used throughout Auric
"""

from datetime import datetime
from typing import TypeVar, Union

# Type aliases
Snowflake = Union[int, str]
ISO8601 = str

# Generic type vars
T = TypeVar("T")
T_co = TypeVar("T_co", covariant=True)

# Discord API constants
DISCORD_EPOCH = 1420070400000
API_VERSION = 10
BASE_URL = f"https://discord.com/api/v{API_VERSION}"
CDN_URL = "https://cdn.discordapp.com"
GATEWAY_URL = "wss://gateway.discord.gg"


def snowflake_time(snowflake: Snowflake) -> datetime:
    """
    Extract timestamp from a Discord snowflake ID

    Args:
        snowflake: Discord snowflake ID

    Returns:
        datetime object representing when the snowflake was created
    """
    timestamp_ms = (int(snowflake) >> 22) + DISCORD_EPOCH
    return datetime.fromtimestamp(timestamp_ms / 1000.0)


def parse_snowflake(snowflake: Snowflake) -> dict:
    """
    Parse a snowflake into its components

    Args:
        snowflake: Discord snowflake ID

    Returns:
        Dictionary with timestamp, worker_id, process_id, and increment
    """
    snowflake_int = int(snowflake)
    timestamp = (snowflake_int >> 22) + DISCORD_EPOCH
    worker_id = (snowflake_int & 0x3E0000) >> 17
    process_id = (snowflake_int & 0x1F000) >> 12
    increment = snowflake_int & 0xFFF

    return {
        "timestamp": datetime.fromtimestamp(timestamp / 1000.0),
        "worker_id": worker_id,
        "process_id": process_id,
        "increment": increment,
    }


class MISSING:
    """Sentinel value for missing optional parameters"""

    def __repr__(self) -> str:
        return "..."

    def __bool__(self) -> bool:
        return False


# Singleton instance
MISSING = MISSING()

"""
Base Collector - Foundation for all event collectors
"""

import asyncio
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set


class CollectorEndReason(Enum):
    """Reasons why a collector ended"""

    TIME = "time"  # Timeout reached
    MAX = "max"  # Max items collected
    USER = "user"  # User stopped it
    IDLE = "idle"  # Idle timeout
    CHANNEL_DELETE = "channel_delete"  # Channel was deleted
    MESSAGE_DELETE = "message_delete"  # Message was deleted
    GUILD_DELETE = "guild_delete"  # Guild was deleted


class BaseCollector(ABC):
    """
    Base class for all collectors

    Collectors allow you to collect events (messages, reactions, interactions, etc.)
    with custom filters, timeouts, and limits.

    This is inspired by discord.js collectors and brings that powerful pattern to Python!

    Args:
        filter: Function to filter collected items (return True to collect)
        time: Time in seconds before collector ends (None = no timeout)
        max: Maximum number of items to collect (None = unlimited)
        idle: Time in seconds of inactivity before ending (None = no idle timeout)
        dispose: Whether to dispose items when collector ends

    Events:
        on_collect: Called when an item is collected
        on_dispose: Called when an item is disposed
        on_end: Called when collector ends
        on_ignore: Called when an item is rejected by filter

    Example:
        ```python
        collector = MessageCollector(
            channel=channel,
            filter=lambda m: m.author == user,
            time=60,
            max=10
        )

        @collector.event
        async def on_collect(message):
            print(f"Collected: {message.content}")

        @collector.event
        async def on_end(collected, reason):
            print(f"Collected {len(collected)} messages")

        collected = await collector.start()
        ```
    """

    def __init__(
        self,
        filter: Optional[Callable[[Any], bool]] = None,
        *,
        time: Optional[float] = None,
        max: Optional[int] = None,
        idle: Optional[float] = None,
        dispose: bool = False,
    ):
        self.filter = filter or (lambda x: True)
        self.time = time
        self.max = max
        self.idle = idle
        self.dispose_on_end = dispose

        # Internal state
        self.collected: List[Any] = []
        self.collected_set: Set[Any] = set()  # For fast lookup
        self._ended = False
        self._task: Optional[asyncio.Task] = None
        self._idle_task: Optional[asyncio.Task] = None
        self._event_handlers: Dict[str, List[Callable]] = {
            "collect": [],
            "dispose": [],
            "end": [],
            "ignore": [],
        }
        self._last_collected_time: Optional[float] = None

    def event(self, func: Callable) -> Callable:
        """
        Decorator to register event handlers

        Example:
            @collector.event
            async def on_collect(item):
                print(f"Collected {item}")
        """
        event_name = func.__name__.replace("on_", "")
        if event_name in self._event_handlers:
            self._event_handlers[event_name].append(func)
        return func

    def on(self, event_name: str, handler: Callable) -> None:
        """
        Register an event handler

        Args:
            event_name: Name of event (collect, dispose, end, ignore)
            handler: Async function to call
        """
        if event_name in self._event_handlers:
            self._event_handlers[event_name].append(handler)

    async def _emit(self, event_name: str, *args, **kwargs) -> None:
        """Emit an event to all registered handlers"""
        for handler in self._event_handlers.get(event_name, []):
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(*args, **kwargs)
                else:
                    handler(*args, **kwargs)
            except Exception as e:
                print(f"Error in collector event handler: {e}")

    async def collect(self, item: Any) -> bool:
        """
        Attempt to collect an item

        Args:
            item: Item to collect

        Returns:
            True if item was collected, False if rejected
        """
        if self._ended:
            return False

        # Apply filter
        try:
            if not self.filter(item):
                await self._emit("ignore", item)
                return False
        except Exception as e:
            print(f"Error in collector filter: {e}")
            return False

        # Check if already collected (for unique items)
        item_id = self._get_item_id(item)
        if item_id in self.collected_set:
            return False

        # Collect the item
        self.collected.append(item)
        if item_id is not None:
            self.collected_set.add(item_id)

        self._last_collected_time = asyncio.get_event_loop().time()

        # Reset idle timer
        if self.idle and self._idle_task:
            self._idle_task.cancel()
            self._idle_task = asyncio.create_task(self._idle_timeout())

        # Emit collect event
        await self._emit("collect", item)

        # Check if we hit the max
        if self.max and len(self.collected) >= self.max:
            await self.stop(CollectorEndReason.MAX)

        return True

    def _get_item_id(self, item: Any) -> Optional[Any]:
        """
        Get unique ID for an item (override in subclasses)

        Returns None if items can be collected multiple times
        """
        return getattr(item, "id", None)

    async def _idle_timeout(self) -> None:
        """Handle idle timeout"""
        if self.idle:
            await asyncio.sleep(self.idle)
            if not self._ended:
                await self.stop(CollectorEndReason.IDLE)

    async def _time_timeout(self) -> None:
        """Handle time timeout"""
        if self.time:
            await asyncio.sleep(self.time)
            if not self._ended:
                await self.stop(CollectorEndReason.TIME)

    async def start(self) -> List[Any]:
        """
        Start the collector

        Returns:
            List of collected items
        """
        if self._ended:
            raise RuntimeError("Collector has already ended")

        # Start timeout tasks
        if self.time:
            self._task = asyncio.create_task(self._time_timeout())

        if self.idle:
            self._idle_task = asyncio.create_task(self._idle_timeout())

        # Start listening for events
        await self._setup_listeners()

        # Wait until collector ends
        while not self._ended:
            await asyncio.sleep(0.1)

        return self.collected

    async def stop(self, reason: CollectorEndReason = CollectorEndReason.USER) -> None:
        """
        Stop the collector

        Args:
            reason: Reason for stopping
        """
        if self._ended:
            return

        self._ended = True

        # Cancel timeout tasks
        if self._task:
            self._task.cancel()
        if self._idle_task:
            self._idle_task.cancel()

        # Cleanup listeners
        await self._cleanup_listeners()

        # Dispose items if requested
        if self.dispose_on_end:
            for item in self.collected:
                await self._emit("dispose", item)

        # Emit end event
        await self._emit("end", self.collected, reason)

    def reset_timer(self) -> None:
        """Reset the timeout timer"""
        if self._task:
            self._task.cancel()
            self._task = asyncio.create_task(self._time_timeout())

    def is_ended(self) -> bool:
        """Check if collector has ended"""
        return self._ended

    @abstractmethod
    async def _setup_listeners(self) -> None:
        """Setup event listeners (implement in subclasses)"""
        pass

    @abstractmethod
    async def _cleanup_listeners(self) -> None:
        """Cleanup event listeners (implement in subclasses)"""
        pass

    def __len__(self) -> int:
        """Get number of collected items"""
        return len(self.collected)

    def __iter__(self):
        """Iterate over collected items"""
        return iter(self.collected)

    def __repr__(self) -> str:
        status = "ended" if self._ended else "active"
        return f"<{self.__class__.__name__} collected={len(self.collected)} {status}>"

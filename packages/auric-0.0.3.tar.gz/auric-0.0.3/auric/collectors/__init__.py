"""
Collectors - Event collection with filters and timeouts

Collectors allow you to collect events (messages, reactions, interactions)
with custom filters, timeouts, and limits. This is inspired by discord.js
collectors and is a powerful pattern for interactive bots!

Example:
    ```python
    from auric.collectors import MessageCollector, filters

    # Collect messages from a specific user
    collector = MessageCollector(
        channel=channel,
        client=bot,
        filter=filters.author_filter(user.id),
        time=60,
        max=10
    )

    @collector.event
    async def on_collect(message):
        print(f"Collected: {message.content}")

    @collector.event
    async def on_end(collected, reason):
        print(f"Collected {len(collected)} messages")

    messages = await collector.start()
    ```
"""

from . import filters
from .base import BaseCollector, CollectorEndReason
from .interaction import AwaitInteractionCollector, ComponentCollector, InteractionCollector
from .message import AwaitMessageCollector, MessageCollector
from .reaction import AwaitReactionCollector, ReactionCollector

__all__ = [
    # Base
    "BaseCollector",
    "CollectorEndReason",
    # Collectors
    "MessageCollector",
    "ReactionCollector",
    "InteractionCollector",
    "ComponentCollector",
    # Await variants
    "AwaitMessageCollector",
    "AwaitReactionCollector",
    "AwaitInteractionCollector",
    # Filters
    "filters",
]

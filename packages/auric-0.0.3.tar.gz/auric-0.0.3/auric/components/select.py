"""
Select menu components - Dropdown menus for Discord messages
"""

from __future__ import annotations

from enum import IntEnum
from typing import TYPE_CHECKING, Any, Awaitable, Callable, List, Optional

if TYPE_CHECKING:
    from ..models.interaction import Interaction


class SelectType(IntEnum):
    """Select menu types"""

    STRING = 3  # String select
    USER = 5  # User select
    ROLE = 6  # Role select
    MENTIONABLE = 7  # User or role select
    CHANNEL = 8  # Channel select


class SelectOption:
    """
    Represents an option in a string select menu.

    Attributes:
        label: Option label (max 100 chars)
        value: Option value (max 100 chars)
        description: Option description (max 100 chars)
        emoji: Emoji to display
        default: Whether this option is default

    Example:
        ```python
        option = SelectOption(
            label="Option 1",
            value="opt1",
            description="First option",
            emoji="1️⃣"
        )
        ```
    """

    __slots__ = ("label", "value", "description", "emoji", "default")

    def __init__(
        self,
        label: str,
        value: str,
        *,
        description: Optional[str] = None,
        emoji: Optional[str] = None,
        default: bool = False,
    ):
        self.label = label
        self.value = value
        self.description = description
        self.emoji = emoji
        self.default = default

    def to_dict(self) -> dict:
        """Convert to API format"""
        data = {
            "label": self.label,
            "value": self.value,
            "default": self.default,
        }

        if self.description:
            data["description"] = self.description

        if self.emoji:
            if isinstance(self.emoji, str):
                data["emoji"] = {"name": self.emoji}
            else:
                data["emoji"] = self.emoji

        return data

    def __repr__(self) -> str:
        return f"<SelectOption label={self.label!r} value={self.value!r}>"


class Select:
    """
    Base select menu component.

    Attributes:
        custom_id: Custom ID for callback routing
        placeholder: Placeholder text
        min_values: Minimum selections (1-25)
        max_values: Maximum selections (1-25)
        disabled: Whether select is disabled
        callback: Async function to call on selection
    """

    __slots__ = (
        "custom_id",
        "placeholder",
        "min_values",
        "max_values",
        "disabled",
        "callback",
        "type",
        "_row",
    )

    def __init__(
        self,
        *,
        custom_id: str,
        placeholder: Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        callback: Optional[Callable[[Interaction], Awaitable[Any]]] = None,
        select_type: SelectType = SelectType.STRING,
    ):
        self.custom_id = custom_id
        self.placeholder = placeholder
        self.min_values = min_values
        self.max_values = max_values
        self.disabled = disabled
        self.callback = callback
        self.type = select_type
        self._row: Optional[int] = None

        # Validation
        if not (1 <= min_values <= 25):
            raise ValueError("min_values must be between 1 and 25")
        if not (1 <= max_values <= 25):
            raise ValueError("max_values must be between 1 and 25")
        if min_values > max_values:
            raise ValueError("min_values cannot be greater than max_values")

    def to_dict(self) -> dict:
        """Convert to API format (override in subclasses)"""
        data = {
            "type": int(self.type),
            "custom_id": self.custom_id,
            "min_values": self.min_values,
            "max_values": self.max_values,
            "disabled": self.disabled,
        }

        if self.placeholder:
            data["placeholder"] = self.placeholder

        return data

    async def invoke(self, interaction: Interaction) -> Any:
        """Invoke the select's callback"""
        if self.callback:
            return await self.callback(interaction)

    def __repr__(self) -> str:
        return f"<Select custom_id={self.custom_id!r} type={self.type.name}>"


class StringSelect(Select):
    """
    String select menu - choose from predefined options.

    Example:
        ```python
        select = StringSelect(
            custom_id="color_select",
            placeholder="Choose a color",
            options=[
                SelectOption(label="Red", value="red", emoji="🔴"),
                SelectOption(label="Blue", value="blue", emoji="🔵"),
                SelectOption(label="Green", value="green", emoji="🟢"),
            ]
        )
        ```
    """

    __slots__ = ("options",)

    def __init__(
        self,
        *,
        custom_id: str,
        options: List[SelectOption],
        placeholder: Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        callback: Optional[Callable[[Interaction], Awaitable[Any]]] = None,
    ):
        super().__init__(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=min_values,
            max_values=max_values,
            disabled=disabled,
            callback=callback,
            select_type=SelectType.STRING,
        )
        self.options = options

        if not options:
            raise ValueError("StringSelect must have at least one option")
        if len(options) > 25:
            raise ValueError("StringSelect can have at most 25 options")

    def to_dict(self) -> dict:
        data = super().to_dict()
        data["options"] = [opt.to_dict() for opt in self.options]
        return data


class UserSelect(Select):
    """
    User select menu - choose users.

    Example:
        ```python
        select = UserSelect(
            custom_id="user_select",
            placeholder="Select users",
            max_values=5
        )
        ```
    """

    def __init__(
        self,
        *,
        custom_id: str,
        placeholder: Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        callback: Optional[Callable[[Interaction], Awaitable[Any]]] = None,
    ):
        super().__init__(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=min_values,
            max_values=max_values,
            disabled=disabled,
            callback=callback,
            select_type=SelectType.USER,
        )


class RoleSelect(Select):
    """
    Role select menu - choose roles.

    Example:
        ```python
        select = RoleSelect(
            custom_id="role_select",
            placeholder="Select roles",
            max_values=3
        )
        ```
    """

    def __init__(
        self,
        *,
        custom_id: str,
        placeholder: Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        callback: Optional[Callable[[Interaction], Awaitable[Any]]] = None,
    ):
        super().__init__(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=min_values,
            max_values=max_values,
            disabled=disabled,
            callback=callback,
            select_type=SelectType.ROLE,
        )


class MentionableSelect(Select):
    """
    Mentionable select menu - choose users or roles.

    Example:
        ```python
        select = MentionableSelect(
            custom_id="mention_select",
            placeholder="Select users or roles"
        )
        ```
    """

    def __init__(
        self,
        *,
        custom_id: str,
        placeholder: Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        callback: Optional[Callable[[Interaction], Awaitable[Any]]] = None,
    ):
        super().__init__(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=min_values,
            max_values=max_values,
            disabled=disabled,
            callback=callback,
            select_type=SelectType.MENTIONABLE,
        )


class ChannelSelect(Select):
    """
    Channel select menu - choose channels.

    Example:
        ```python
        select = ChannelSelect(
            custom_id="channel_select",
            placeholder="Select a channel",
            channel_types=[0, 2]  # Text and voice
        )
        ```
    """

    __slots__ = ("channel_types",)

    def __init__(
        self,
        *,
        custom_id: str,
        placeholder: Optional[str] = None,
        min_values: int = 1,
        max_values: int = 1,
        channel_types: Optional[List[int]] = None,
        disabled: bool = False,
        callback: Optional[Callable[[Interaction], Awaitable[Any]]] = None,
    ):
        super().__init__(
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=min_values,
            max_values=max_values,
            disabled=disabled,
            callback=callback,
            select_type=SelectType.CHANNEL,
        )
        self.channel_types = channel_types

    def to_dict(self) -> dict:
        data = super().to_dict()
        if self.channel_types:
            data["channel_types"] = self.channel_types
        return data

# Changelog

All notable changes to Auric will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.0.3] - 2025-11-02

### Changed
- Complete README overhaul with professional, technical writing style
- Simplified installation instructions
- Improved code examples with clearer, more practical demonstrations
- Updated all repository URLs to point to Auric-Team organization
- Enhanced documentation sections with better structure

### Fixed
- Fixed GitHub badge links in README
- Updated pyproject.toml with correct repository URLs
- Corrected license badge to use static version

## [0.0.2] - 2024-11-02

### Fixed
- Fixed all 74 flake8 linting issues across the codebase
- Removed unused imports (34 instances)
- Fixed undefined names and missing type imports (33 instances)
- Removed duplicate method definitions in Guild and Channel models
- Fixed circular import issues using TYPE_CHECKING
- Cleaned up file formatting issues

### Changed
- Improved code quality and consistency throughout
- Better type safety with proper TYPE_CHECKING usage
- Renamed conflicting async methods (e.g., `webhooks()` → `fetch_webhooks()`)
- Updated README with professional formatting and comprehensive examples
- Improved project structure and removed temporary development files

### Removed
- Removed development files (GEMINI.md, flake8.log, flake8-report.log)
- Cleaned up unnecessary imports across all modules

## [0.0.1] - 2024-10-31

### Added
- Initial alpha release
- **Complete Discord API v10 support**
- Full gateway connection with auto-reconnect and resume
- Comprehensive event system for all Discord events
- HTTP client with automatic rate limiting
- Smart caching with automatic memory management

#### Commands & Interactions
- Slash command support with full builder API
- Context menu commands (user and message)
- Auto-completion for command options
- Modal support with text inputs
- Subcommands and subcommand groups

#### Components
- Button components with all styles
- Select menus (5 types: string, user, role, mentionable, channel)
- Action rows for component layout
- Component collectors for waiting on interactions

#### Message Features
- Rich embed builder with fluent API
- File attachments with spoiler support
- Message editing and deletion
- Reactions and reaction collectors
- Message formatting utilities
- Markdown escaping functions

#### Guild Features
- Guild management (create, edit, delete)
- Role management with position control
- Channel management (text, voice, category, forum, stage)
- Thread support (create, join, archive)
- Member management with bulk operations
- Emoji and sticker management
- Invite management
- Scheduled events CRUD operations
- Auto-moderation rules

#### Voice Features
- Voice channel connection
- Audio playback support
- Voice state management
- Voice region selection

#### Collectors
- MessageCollector - Collect messages
- ReactionCollector - Collect reactions
- InteractionCollector - Collect button/menu interactions
- Customizable filters and timeout handling

#### Utilities
- Permission calculator with overwrites
- Color utilities (hex, RGB, int conversion)
- Timestamp formatters
- User, role, and channel mention formatters
- Emoji parsing and formatting
- URL validation and formatting

#### Developer Experience
- 100% type hints throughout
- Comprehensive error handling
- Detailed logging support
- Smart cache sweeping
- Production-ready patterns

### Performance
- Efficient caching strategy
- Automatic rate limit handling
- Connection pooling
- Minimal memory footprint

### Documentation
- Complete getting started guide
- Slash commands tutorial
- Components guide
- API reference for all classes
- 10+ example bots
- Migration guides from other libraries

## [0.9.0] - 2024-10-15 (Pre-release)

### Added
- Beta release for testing
- Core client and gateway implementation
- Basic command framework
- Initial builder implementations

### Fixed
- Gateway reconnection issues
- Rate limiting edge cases
- Memory leaks in cache

## Future Plans

### [1.1.0] - Planned
- Forum channel support improvements
- Media channels
- Enhanced voice features (recording, filters)
- Plugin system
- Performance optimizations

### [1.2.0] - Planned
- Advanced caching strategies
- Redis cache backend
- Metrics and monitoring
- Health check endpoints

### [2.0.0] - Future
- Support for Discord API v11
- Breaking changes for better API design
- Advanced features for large bots
- Machine learning integrations

---

## Release Types

- **Major (X.0.0)**: Breaking changes, major new features
- **Minor (1.X.0)**: New features, backwards compatible
- **Patch (1.0.X)**: Bug fixes, small improvements

## Upgrade Notes

When upgrading between major versions, always check the [Upgrading Guide](docs/guides/upgrading.md) for migration instructions.

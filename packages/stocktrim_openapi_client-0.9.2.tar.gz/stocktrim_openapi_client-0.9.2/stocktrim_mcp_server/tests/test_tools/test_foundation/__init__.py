"""Tests for foundation tools."""

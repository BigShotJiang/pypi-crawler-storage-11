# StructuralPy

This module provides functions for analysis and design of structural steel and reinforced concrete members in accordance with NSCP 2015 provisions.

## Features (currently a work in progress)

- Analyze RC beams for flexure

## Installation

Install using

```bash
pip install structuralpy
```

## Usage

```python
from structuralpy import rc_beam

rc_beam.analyze_flexure(300, 600, 65, 20.7, 415, 600)`
# returns 129174322.3
```
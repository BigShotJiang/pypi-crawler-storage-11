# tests/test_rc_beam.py

import pytest
from structuralpy.rc_beam import analyze_flexure

def test_analyze_flexure() :
    assert analyze_flexure(300, 600, 65, 20.7, 415, 600) == pytest.approx(129174322.3, rel=1e-9)

if __name__ == "__main__" :
    pytest.main()
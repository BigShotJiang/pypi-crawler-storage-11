# structuralpy/__init__.py

"""
**StructuralPy**

This module provides functions for analysis and design of structural steel and reinforced concrete members in accordance with NSCP 2015 provisions.

Included functions (currently a work in progress):
 - RC beam analysis
"""

from .rc_beam import analyze_flexure

__all__ = ['analyze_flexure']

def __version__() :
    return "0.0.1"

def describe() :
    description = (
        "StructuralPy\n"
        "Version: {0}\n\n"
        "This module provides functions for analysis and design of structural steel and reinforced concrete members in accordance with NSCP 2015 provisions.\n\n"
        "Included functions (currently a work in progress):\n"
        " - RC beam analysis\n"
    ).format(__version__())
    
    print(description)
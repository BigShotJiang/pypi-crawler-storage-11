# structuralpy/rc_beam.py

def analyze_flexure(b, d, dp, fcp, fy, As, Asp=0, n_iter=10) :
    """
    Calculate the ultimate moment capacity of a rectangular RC beam in flexure.

    Parameters:

    - `b` (float)    : Beam width in mm.
    - `d` (float)    : Beam effective depth in mm.
    - `dp` (float)   : Distance of center of compression bars to extreme concrete compression fiber in mm.
    - `fcp` (float)  : Concrete 28-day compressive strength in MPa.
    - `fy` (float)   : Reinforcement yield strength in MPa.
    - `As` (float)   : Tension main reinforcement area in mm^2.
    - `Asp` (float)  : Compression main reinforcement area in mm^2. Default value is 0 (no reinforcement).
    - `n_iter` (int) : Number of iterations for iterative solving of equilibrium equation. Default value is 10.

    Returns:
    
    - (float) : The ultimate moment capacity in flexure in N-mm.
    """
    beta1 = max(min(0.85 - 0.05/7*(fcp - 28), 0.85), 0.65)
    
    # First assume both top and bottom reinforcements yield.
    fs = fy
    fsp = fy
    for iter in range(n_iter) :
        # Locate the neutral axis.
        c = (As*min(fs, fy) - Asp*(min(fsp, fy) - 0.85*fcp))/(0.85*fcp*beta1*b)
        # Update the stresses in both reinforcements.
        fs = min(600*(d - c)/c, fy)
        fsp = min(600*(c - dp)/c, fy)

    # Strength reduction factor
    phi = max(min(0.65 + 0.25*(fs - fy)/(1000 - fy), 0.9), 0.65)
    # Depth of compression block
    a = beta1*c
    # Nominal moment capacity.
    Mn = 0.85*fcp*a*b*(d - a/2) + Asp*fsp*(d - dp)

    return phi*Mn

    

from .storagemaptype import StorageMapType

from boa3.internal.model.builtin.interop.storage.getcheck.istoragetrygetmethod import IStorageTryGetMethod


class StorageTryGetDictMethod(IStorageTryGetMethod):
    def __init__(self):
        from boa3.internal.model.type.type import Type

        identifier = 'try_get_dict'
        value_type = Type.dict

        super().__init__(identifier, value_type=value_type)

    def generate_default_value_opcodes(self, code_generator):
        from boa3.internal.model.type.type import Type
        # default_value = {}
        code_generator.convert_new_map(Type.dict)

    def generate_deserialize_value_opcodes(self, code_generator):
        from boa3.internal.model.builtin.interop.interop import Interop

        converter = Interop.Deserialize
        code_generator.convert_builtin_method_call(converter, is_internal=True)

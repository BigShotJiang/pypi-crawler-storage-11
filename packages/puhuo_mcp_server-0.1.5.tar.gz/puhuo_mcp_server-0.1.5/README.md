# Puhuo MCP Server

普货 MCP 服务器，提供运单号拦截和快递公司编码查询功能。

## 功能

1. **intercept_waybill** - 拦截运单号检查
   - 参数：`waybill_no` (运单号)
   - 返回：是否拦截及原因

2. **suggest_cp_code** - 查询快递公司编码
   - 参数：`waybill_no` (运单号)
   - 返回：快递公司编码（cpCode）

## 安装

### 从 PyPI 安装（推荐）

```bash
pip install puhuo-mcp-server
```

或使用 uv：

```bash
uv pip install puhuo-mcp-server
```

### 从源码安装（开发模式）

```bash
git clone <repository-url>
cd puhuo-mcp-server
pip install -e .
```

## 配置

### 方式一：在 Cursor MCP 配置中设置

在 Cursor 的 MCP 配置文件中添加：

**配置文件路径**: `~/.cursor/mcp.json`

```json
{
  "mcpServers": {
    "puhuo-tool": {
      "command": "uvx",
      "args": [
        "puhuo-mcp-server"
      ],
      "env": {
        "CAINIAO_TOKEN": "your_token_here"
      }
    }
  }
}
```

**说明**：
- 使用 `uvx` 可以自动从 PyPI 下载并运行最新版本
- 也可以指定版本：`"puhuo-mcp-server==0.1.5"`
- 如果本地已安装，可以直接使用 `"command": "puhuo-mcp-server"`

### 方式二：系统环境变量

```bash
export CAINIAO_TOKEN="your_token_here"
puhuo-mcp-server
```

### 方式三：直接运行时设置

```bash
CAINIAO_TOKEN="your_token_here" puhuo-mcp-server
```

## Token 配置

`CAINIAO_TOKEN` 需要设置为有效的认证 Token。

示例 Token（需要替换为实际的 Token）：
```
**
```

## 开发

### 启动服务器

```bash
python -m puhuo_mcp_server.server
```

服务器将在 `http://127.0.0.1:8000` 上运行。

### 调试模式

服务器默认启用 DEBUG 日志，可以查看详细的请求和响应信息。


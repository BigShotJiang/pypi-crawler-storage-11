"""Core module."""

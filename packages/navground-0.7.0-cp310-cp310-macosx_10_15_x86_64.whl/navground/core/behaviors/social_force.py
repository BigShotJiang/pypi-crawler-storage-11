"""
    Helbing, Dirk, and Peter Molnar. 
    "Social force model for pedestrian dynamics." 
    Physical review E 51.5 (1995): 4282.

    https://arxiv.org/pdf/cond-mat/9805244

    Missing (not specified in the paper):
    - attractive forces
    - fluctuation
    - cit. "potentials with a hard core that would be more realistic"
    - gradient in case of divergence
"""
from __future__ import annotations

from collections.abc import Callable
from typing import SupportsFloat, cast

import numpy as np
from navground.core import (Behavior, Disc, GeometricState, Kinematics,
                            LineSegment, Neighbor, Vector2, Vector2Like,
                            register, schema, zeros2)

# TODO(Jerome): what about the radius and safety margin?


# value and gradient
# in the paper, called b
def neighbor_distance(position: Vector2, neighbor: Neighbor,
                      step_duration: float) -> tuple[float, Vector2]:
    delta = position - neighbor.position
    step = neighbor.velocity * step_duration
    n1 = np.linalg.norm(delta, axis=-1)
    n2 = np.linalg.norm(delta - step, axis=-1)
    n3 = np.linalg.norm(step)
    # Can this be negative?
    b = 0.5 * np.sqrt((n1 + n2)**2 - n3**2)
    if b:
        grad = (0.5 / b * (2 * delta + 2 * (delta - step) + 0.5 * n1 / n2 *
                           (delta - step) + 0.5 * n2 / n1 * delta))
    else:
        # TODO
        grad = np.zeros(2)
    return b, grad


def disc_distance(position: Vector2, disc: Disc) -> tuple[float, Vector2]:
    delta = position - disc.position
    distance = cast(float, np.linalg.norm(delta))
    if distance:
        grad = delta / distance
    else:
        grad = zeros2()
    return distance, grad


def segment_distance(position: Vector2,
                     line: LineSegment) -> tuple[float, Vector2]:
    delta = position - line.p1
    x = delta.dot(line.e1)
    if x < 0:
        distance = np.linalg.norm(delta)
        grad = delta / distance
    elif x > line.length:
        delta = position - line.p2
        distance = np.linalg.norm(delta)
        grad = delta / distance
    else:
        y = delta.dot(line.e2)
        distance = abs(delta.dot(line.e2))
        grad = line.e2 if y > 0 else -line.e2
    return cast(float, distance), grad


class Potential:
    """A monotonic decreasing function of the distance"""

    def __call__(self, x: float) -> tuple[float, Vector2]:
        """Returns the value and gradient of the potential

        :param x:  The distance
        :returns:  ``(value, gradient)``
        """
        return 0.0, zeros2()


class ExponentialPotential(Potential):
    """
    A potential of form :math:`V(x) = a e^{-\\frac{x}{r}}`
    """

    def __init__(self, a: float, r: float):
        """
        Constructs a new instance.

        :param      a:    The amplitude
        :param      r:    The scale
        """
        self.a = a
        self.r = r

    def __call__(self, x: float) -> tuple[float, Vector2]:
        v = self.a * np.exp(-x / self.r)
        return v, -v / self.r


# TODO cit "Potentials with a hard core would be more realistic"


class SocialForceBehavior(Behavior, name="SocialForce"):
    """
    Basic social force algorithm from

        Helbing, Dirk, and Peter Molnar.
        "Social force model for pedestrian dynamics."
        Physical review E 51.5 (1995): 4282.

    *Registered properties*:

    - :py:attr:`tau` [float]
    - :py:attr:`phi` [float]
    - :py:attr:`c` [float]
    - :py:attr:`u_a` [float]
    - :py:attr:`u_r` [float]
    - :py:attr:`v_a` [float]
    - :py:attr:`v_r` [float]
    - :py:attr:`step_duration` [float]

    *State*: :py:class:`GeometricState`
    """

    def __init__(self,
                 kinematics: Kinematics | None = None,
                 radius: float = 0.0,
                 tau: float = 0.5,
                 step_duration: float = 1.0,
                 phi: float = 1.75,
                 c: float = 0.5,
                 v: Potential | None = None,
                 u: Potential | None = None):
        """
        Constructs a new instance.

        :param      kinematics:     The kinematics
        :param      radius:         The radius
        :param      tau:            The tau
        :param      step_duration:  The step duration
        :param      phi:            The phi
        :param      c:              The weight of 'non-in-sight' forces
        :param      v:              The neighbor potential. Will use default if not set.
        :param      u:              The obstacle potential. Will use default if not set.
        """
        Behavior.__init__(self, kinematics, radius)
        self._tau = tau
        self._step_duration = step_duration
        self.cos_phi = np.cos(phi)
        self._c = c
        self.v = v or ExponentialPotential(2.1, 0.3)
        self.u = u or ExponentialPotential(10, 0.2)
        self._state = GeometricState()

    @property
    @register(0.5, "Relaxation time", schema.positive)
    def tau(self) -> float:
        """
        The relaxation time [s].
        """
        return self._tau

    @tau.setter
    def tau(self, value: float) -> None:
        self._tau = max(0, value)

    @property
    @register(1.0, "Step duration", schema.positive)
    def step_duration(self) -> float:
        """
        The duration of a step [s].
        """
        return self._step_duration

    @step_duration.setter
    def step_duration(self, value: float) -> None:
        self._step_duration = max(0, value)

    @property
    @register(1.75, "Field of sight half-length")
    def phi(self) -> float:
        """
        The field of sight half-length
        """
        return float(np.arccos(self.cos_phi))

    @phi.setter
    def phi(self, value: float) -> None:
        self.cos_phi = np.cos(value)

    @property
    @register(0.5, "Weight of 'non-in-sight' forces", schema.positive)
    def c(self) -> float:
        """
        The weight of 'non-in-sight' forces
        """
        return self._c

    @c.setter
    def c(self, value: float) -> None:
        self._c = max(0, value)

    @property
    @register(2.1, "Neighbors potential amplitude")
    def v_a(self) -> float:
        """
        The neighbors potential amplitude
        """
        if isinstance(self.v, ExponentialPotential):
            return self.v.a
        return 0

    @v_a.setter
    def v_a(self, value: float) -> None:
        if isinstance(self.v, ExponentialPotential):
            self.v.a = value

    @property
    @register(0.3, "Neighbors potential length scale", schema.positive)
    def v_r(self) -> float:
        """
        The neighbors potential length scale
        """
        if isinstance(self.v, ExponentialPotential):
            return self.v.r
        return 0

    @v_r.setter
    def v_r(self, value: float) -> None:
        if isinstance(self.v, ExponentialPotential):
            self.v.r = max(0, value)

    @property
    @register(10, "Obstacles potential amplitude")
    def u_a(self) -> float:
        """
        The obstacles potential amplitude
        """
        if isinstance(self.u, ExponentialPotential):
            return self.u.a
        return 0

    @u_a.setter
    def u_a(self, value: float) -> None:
        if isinstance(self.u, ExponentialPotential):
            self.u.a = value

    @property
    @register(0.2, "Obstacles potential length scale", schema.positive)
    def u_r(self) -> float:
        """
        The obstacles potential length scale
        """
        if isinstance(self.u, ExponentialPotential):
            return self.u.r
        return 0

    @u_r.setter
    def u_r(self, value: float) -> None:
        if isinstance(self.u, ExponentialPotential):
            self.u.r = max(0, value)

    def get_environment_state(self) -> GeometricState:
        """
        Overridden to define a :py:class:`GeometricState`.

        :returns:   The environment state.
        """
        return self._state

    def potential(self) -> Callable[[Vector2], float]:
        ps = ([
            self.neighbor_potential(neighbor)
            for neighbor in self._state.neighbors
        ] + [
            self.obstacle_potential(obstacle)
            for obstacle in self._state.static_obstacles
        ] + [
            self.segment_potential(line) for line in self._state.line_obstacles
        ])

        def f(position: Vector2) -> float:
            return sum(p(position) for p in ps)

        return f

    def neighbor_potential(self,
                           neighbor: Neighbor) -> Callable[[Vector2], float]:

        def f(position: Vector2) -> float:
            value, _ = neighbor_distance(position, neighbor,
                                         self.step_duration)
            return self.v(value)[0]

        return f

    def neighbor_repulsion_force(self, neighbor: Neighbor) -> Vector2:
        value, grad = neighbor_distance(self.position, neighbor,
                                        self.step_duration)
        _, p_grad = self.v(value)
        return -grad * p_grad

    def obstacle_potential(self, obstacle: Disc) -> Callable[[Vector2], float]:

        def f(position: Vector2) -> float:
            value, _ = disc_distance(position, obstacle)
            return self.u(value)[0]

        return f

    def obstacle_repulsion_force(self, obstacle: Disc) -> Vector2:
        value, grad = disc_distance(self.position, obstacle)
        _, p_grad = self.u(value)
        return -grad * p_grad

    def segment_potential(self,
                          line: LineSegment) -> Callable[[Vector2], float]:

        def f(position: Vector2) -> float:
            value, _ = segment_distance(position, line)
            return self.u(value)[0]

        return f

    def segment_repulsion_force(self, line: LineSegment) -> Vector2:
        value, grad = segment_distance(self.position, line)
        _, p_grad = self.u(value)
        return -grad * p_grad

    def in_sight(self, force: Vector2, e: Vector2) -> bool:
        return bool(
            np.all(np.dot(e, force) > self.cos_phi * np.linalg.norm(force)))

    def weight(self, force: Vector2, e: Vector2) -> float:
        return 1.0 if self.in_sight(force, e) else self.c

    def weighted(self, force: Vector2, e: Vector2, sign: int) -> Vector2:
        return self.weight(sign * force, e) * force

    # TODO attractive effects
    # TODO fluctuations
    def desired_velocity_towards_velocity(self, target_velocity: Vector2Like,
                                          time_step: SupportsFloat) -> Vector2:
        """
        Overridden: applies social forces to deviate from target velocity.

        :param      target_velocity:  The target velocity
        :param      time_step:        The time step

        :returns:   The desired velocity
        """
        # acceleration towards desired velocity
        target_velocity = np.asarray(target_velocity)
        speed = np.linalg.norm(target_velocity)
        if not speed:
            return zeros2()
        e = target_velocity / speed
        force = (target_velocity - self.velocity) / self.tau
        # repulsion from neighbors
        force += sum(
            self.weighted(self.neighbor_repulsion_force(neighbor), e, -1)
            for neighbor in self._state.neighbors)
        force += sum(
            self.weighted(self.obstacle_repulsion_force(obstacle), e, -1)
            for obstacle in self._state.static_obstacles)
        force += sum(
            self.weighted(self.segment_repulsion_force(line), e, -1)
            for line in self._state.line_obstacles)
        desired_velocity = self.actuated_twist.velocity + float(
            time_step) * force
        # no need to clamp norm ... this will be done the superclass
        # are we sure?
        return desired_velocity

    def desired_velocity_towards_point(self, point: Vector2Like,
                                       speed: SupportsFloat,
                                       time_step: SupportsFloat) -> Vector2:
        """
        Overridden: computes an optimal target velocity and calls
        :py:meth:`desired_velocity_towards_velocity`.

        :param      point:      The point
        :param      speed:      The speed
        :param      time_step:  The time step

        :returns:   The desired velocity
        """
        # Target is in general an area,
        # then target position is the closed point in that area
        delta = np.asarray(point) - self.position
        dist = np.linalg.norm(delta)
        if not dist:
            return zeros2()
        velocity = delta / np.linalg.norm(delta) * float(speed)
        return self.desired_velocity_towards_velocity(velocity, time_step)

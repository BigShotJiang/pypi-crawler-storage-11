from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

import numpy as np
import numpy.typing

from .. import World
from .to_svg import svg_for_world

if TYPE_CHECKING:
    from cairosvg.surface import PNGSurface  # type: ignore[import-untyped]

Image = np.typing.NDArray[np.uint8]


def _surface_to_npim(surface: PNGSurface) -> Image:
    """ Transforms a Cairo surface into a numpy array. """
    im = +np.frombuffer(surface.get_data(), np.uint8)
    H, W = surface.get_height(), surface.get_width()
    im.shape = (H, W, 4)  # for RGBA
    return im[:, :, 2::-1]


def _svg_to_npim(svg_bytestring: str,
                 dpi: int = 96,
                 background_color: str = "snow") -> Image:
    """ Renders a svg bytestring as a RGB image in a numpy array """
    import cairosvg  # type: ignore[import-untyped]

    tree = cairosvg.parser.Tree(bytestring=svg_bytestring)
    surf = cairosvg.surface.PNGSurface(tree,
                                       None,
                                       dpi,
                                       background_color=background_color).cairo
    return _surface_to_npim(surf)


def image_for_world(world: World,
                    background_color: str = "snow",
                    **kwargs: Any) -> Image:
    """
    Renders the world as a raw image

    :param      world:             The world to be rendered
    :param      background_color:  A valid SVG color for the background
    :param      kwargs:                 Optional configuration:
        same fields as :py:class:`navground.sim.ui.RenderConfig`.

    The actual configuration is computed by looking (in order) to

    1. the arguments of this function;
    2. the world-specific configuration :py:attr:`navground.sim.World.render_kwargs`;
    3. the default configuration :py:attr:`navground.sim.ui.render_default_config`.

    :returns:   An RGB image as a numpy array
    """
    svg_data = svg_for_world(world, **kwargs)
    return _svg_to_npim(svg_data, background_color=background_color)


def png_for_world(
    world: World,
    background_color: str = "snow",
    dpi: int = 96,
    **kwargs: Any,
) -> bytes:
    """
    Renders the world as an png image

    :param      world:             The world to be rendered
    :param      background_color:  A valid SVG color for the background
    :param      kwargs:                 Optional configuration:
        same fields as :py:class:`navground.sim.ui.RenderConfig`.

    The actual configuration is computed by looking (in order) to

    1. the arguments of this function;
    2. the world-specific configuration :py:attr:`navground.sim.World.render_kwargs`;
    3. the default configuration :py:attr:`navground.sim.ui.render_default_config`.

    :returns:   A png bytestring
    """
    import cairosvg

    svg_data = svg_for_world(world, **kwargs)
    return cast(
        bytes,
        cairosvg.svg2png(bytestring=svg_data,
                         background_color=background_color,
                         dpi=dpi))


def pdf_for_world(world: World,
                  background_color: str = "snow",
                  **kwargs: Any) -> bytes:
    """
    Renders the world as an pdf image

    :param      world:             The world to be rendered
    :param      background_color:  A valid SVG color for the background
    :param      kwargs:                 Optional configuration:
        same fields as :py:class:`navground.sim.ui.RenderConfig`.

    The actual configuration is computed by looking (in order) to

    1. the arguments of this function;
    2. the world-specific configuration :py:attr:`navground.sim.World.render_kwargs`;
    3. the default configuration :py:attr:`navground.sim.ui.render_default_config`.

    :returns:   A pdf bytestring
    """
    import cairosvg

    svg_data = svg_for_world(world, **kwargs)
    return cast(
        bytes,
        cairosvg.svg2pdf(bytestring=svg_data,
                         background_color=background_color))

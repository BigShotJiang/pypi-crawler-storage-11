from cocoindex_mcp.cli import main


if __name__ == "__main__":
    main()

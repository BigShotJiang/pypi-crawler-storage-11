"""
Node Connection API endpoints
"""
from fastapi import APIRouter, HTTPException, Request, Depends
from typing import Dict, Any, Optional
from pydantic import BaseModel
import logging
import sys
from pathlib import Path

# Add app directory to path for imports
node_be_dir = Path(__file__).parent.parent
if str(node_be_dir) not in sys.path:
    sys.path.insert(0, str(node_be_dir))

from node_manager import get_node_manager

logger = logging.getLogger(__name__)

router = APIRouter()


class NodeConfigUpdate(BaseModel):
    """Node configuration update request"""
    api_domain: Optional[str] = None
    auto_reconnect: Optional[bool] = None
    heartbeat_interval: Optional[int] = None
    connection_timeout: Optional[int] = None


@router.get("/health")
async def health_check():
    """Health check endpoint (public)"""
    return {
        "status": "healthy",
        "service": "node-connection",
        "version": "1.0.0"
    }


@router.get("/status")
async def get_status(request: Request):
    """Get current node connection status"""
    try:
        manager = get_node_manager()
        
        # Ensure the node is connected (auto-startup if needed)
        await manager.ensure_connected()
        
        status = manager.get_status()
        
        return {
            "success": True,
            "status": status
        }
    except Exception as e:
        logger.error(f"Error getting node status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/connection-details")
async def get_connection_details(request: Request):
    """Get connection details for authenticated user"""
    try:
        # Get user from request (set by auth middleware)
        user = getattr(request.state, "user", None)
        if not user:
            raise HTTPException(status_code=401, detail="User not authenticated")
        
        user_id = user.get("user_id") or user.get("sub") or user.get("username", "unknown")
        
        manager = get_node_manager()
        
        # Ensure the node is connected (auto-startup if needed)
        await manager.ensure_connected()
        
        details = manager.get_connection_details(user_id)
        
        if not details:
            raise HTTPException(status_code=503, detail="Node not connected")
        
        return {
            "success": True,
            "connection_details": details
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting connection details: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/reconnect")
async def reconnect_node(request: Request):
    """Reconnect to API domain"""
    try:
        manager = get_node_manager()
        success = await manager.reconnect()
        
        if success:
            return {
                "success": True,
                "message": "Successfully reconnected to API domain",
                "status": manager.get_status()
            }
        else:
            raise HTTPException(status_code=503, detail="Failed to reconnect")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error reconnecting node: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/config")
async def update_config(config_update: NodeConfigUpdate, request: Request):
    """Update node configuration"""
    try:
        manager = get_node_manager()
        
        # Convert to dict, excluding None values
        updates = config_update.dict(exclude_none=True)
        
        if not updates:
            raise HTTPException(status_code=400, detail="No configuration updates provided")
        
        updated_config = manager.update_config(updates)
        
        return {
            "success": True,
            "message": "Configuration updated successfully",
            "config": updated_config
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating config: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/restart")
async def restart_node(request: Request):
    """
    Restart this specific node connection (CLIENT-SIDE ONLY)
    
    IMPORTANT: This only resets this particular node's connection state and reconnects.
    It NEVER restarts the server process. Each node can be restarted independently.
    Safe for production use.
    """
    try:
        logger.info("Node connection restart requested by user")
        
        manager = get_node_manager()
        
        # Reset connection state for this node (client-side only)
        logger.info(f"Resetting connection state for node {manager.node_id}...")
        manager.connected = False
        manager.connected_at = None
        manager.user_connections.clear()
        manager._startup_called = False
        
        # Reconnect this node
        logger.info("Reconnecting node to API domain...")
        success = await manager.reconnect()
        
        if success:
            logger.info(f"Node {manager.node_id} successfully restarted")
            return {
                "success": True,
                "message": f"Node {manager.node_id} connection restarted successfully",
                "status": manager.get_status()
            }
        else:
            raise HTTPException(
                status_code=503, 
                detail="Failed to reconnect after restart"
            )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error restarting node connection: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/execution-node-status")
async def get_execution_node_status(request: Request):
    """
    Get the status of the user's local execution node.
    
    This endpoint checks the digital-twin discovery service to find
    the user's execution node and fetch its status remotely.
    """
    try:
        user = getattr(request.state, "user", None)
        if not user:
            raise HTTPException(status_code=401, detail="User not authenticated")
        
        user_id = user.get("user_id") or user.get("sub") or user.get("username", "unknown")
        
        # Try to discover the execution node
        import httpx
        
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                # Check discovery service
                base_url = str(request.base_url).rstrip('/')
                discovery_url = f"{base_url}/digital-twin/api/direct_connection/discover/{user_id}"
                
                logger.info(f"Checking discovery service for user {user_id}: {discovery_url}")
                
                discovery_response = await client.get(discovery_url)
                
                if discovery_response.status_code == 200:
                    discovery_data = discovery_response.json()
                    
                    if discovery_data.get("found"):
                        # Node is registered, try to get its status
                        node_url = discovery_data.get("local_url", "").rstrip('/')
                        
                        try:
                            # Try to reach the execution node's status endpoint
                            node_status_url = f"{node_url}/node-connection/api/node/status"
                            
                            # Get auth token to authenticate with execution node
                            auth_token = request.headers.get("authorization", "")
                            
                            node_response = await client.get(
                                node_status_url,
                                headers={"Authorization": auth_token} if auth_token else {},
                                timeout=5.0
                            )
                            
                            if node_response.status_code == 200:
                                node_data = node_response.json()
                                return {
                                    "success": True,
                                    "execution_node_found": True,
                                    "execution_node_reachable": True,
                                    "execution_node_url": node_url,
                                    "status": node_data.get("status", {}),
                                    "message": "Your execution node is online and reachable"
                                }
                            else:
                                # Registered but not reachable
                                return {
                                    "success": True,
                                    "execution_node_found": True,
                                    "execution_node_reachable": False,
                                    "execution_node_url": node_url,
                                    "status": None,
                                    "message": "Your execution node is registered but not currently reachable"
                                }
                        except Exception as e:
                            logger.warning(f"Could not reach execution node: {e}")
                            return {
                                "success": True,
                                "execution_node_found": True,
                                "execution_node_reachable": False,
                                "execution_node_url": node_url,
                                "status": None,
                                "message": "Your execution node is registered but not currently reachable"
                            }
                    else:
                        # Not registered
                        return {
                            "success": True,
                            "execution_node_found": False,
                            "execution_node_reachable": False,
                            "status": None,
                            "message": "Your execution node is not currently registered. Start your local server to register."
                        }
                else:
                    # Discovery service not available
                    return {
                        "success": True,
                        "execution_node_found": False,
                        "execution_node_reachable": False,
                        "status": None,
                        "message": "Discovery service unavailable. Cannot check execution node status."
                    }
        except Exception as e:
            logger.error(f"Error checking execution node: {e}")
            return {
                "success": True,
                "execution_node_found": False,
                "execution_node_reachable": False,
                "status": None,
                "message": f"Error checking execution node: {str(e)}"
            }
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in execution node status check: {e}")
        raise HTTPException(status_code=500, detail=str(e))

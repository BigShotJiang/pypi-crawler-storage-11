clinic_super = []

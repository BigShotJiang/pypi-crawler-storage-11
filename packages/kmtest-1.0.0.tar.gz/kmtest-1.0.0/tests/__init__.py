"""
Tests for kmtest package
"""

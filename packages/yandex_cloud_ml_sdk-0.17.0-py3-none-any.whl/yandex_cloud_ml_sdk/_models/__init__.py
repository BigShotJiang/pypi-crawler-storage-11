# pylint: disable=protected-access
from __future__ import annotations

from yandex_cloud_ml_sdk._types.domain import DomainWithFunctions

from .completions.function import AsyncCompletions, BaseCompletions, Completions
from .image_generation.function import AsyncImageGeneration, BaseImageGeneration, ImageGeneration
from .text_classifiers.function import AsyncTextClassifiers, BaseTextClassifiers, TextClassifiers
from .text_embeddings.function import AsyncTextEmbeddings, BaseTextEmbeddings, TextEmbeddings


class BaseModels(DomainWithFunctions):
    """Domain for working with `Yandex Foundation Models <https://yandex.cloud/ru/services/foundation-models>`_."""

    completions: BaseCompletions
    text_classifiers: BaseTextClassifiers
    image_generation: BaseImageGeneration
    text_embeddings: BaseTextEmbeddings


class AsyncModels(BaseModels):
    completions: AsyncCompletions
    text_embeddings: AsyncTextEmbeddings
    text_classifiers: AsyncTextClassifiers
    image_generation: AsyncImageGeneration


class Models(BaseModels):
    completions: Completions
    text_embeddings: TextEmbeddings
    text_classifiers: TextClassifiers
    image_generation: ImageGeneration

====================
collective.categorize
====================

User documentation

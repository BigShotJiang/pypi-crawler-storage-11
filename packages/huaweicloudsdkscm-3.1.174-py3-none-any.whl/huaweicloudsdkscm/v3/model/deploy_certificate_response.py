# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeployCertificateResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'failure_list': 'list[FaiureResource]'
    }

    attribute_map = {
        'failure_list': 'failure_list'
    }

    def __init__(self, failure_list=None):
        r"""DeployCertificateResponse

        The model defined in huaweicloud sdk

        :param failure_list: 部署失败的资源列表。
        :type failure_list: list[:class:`huaweicloudsdkscm.v3.FaiureResource`]
        """
        
        super().__init__()

        self._failure_list = None
        self.discriminator = None

        if failure_list is not None:
            self.failure_list = failure_list

    @property
    def failure_list(self):
        r"""Gets the failure_list of this DeployCertificateResponse.

        部署失败的资源列表。

        :return: The failure_list of this DeployCertificateResponse.
        :rtype: list[:class:`huaweicloudsdkscm.v3.FaiureResource`]
        """
        return self._failure_list

    @failure_list.setter
    def failure_list(self, failure_list):
        r"""Sets the failure_list of this DeployCertificateResponse.

        部署失败的资源列表。

        :param failure_list: The failure_list of this DeployCertificateResponse.
        :type failure_list: list[:class:`huaweicloudsdkscm.v3.FaiureResource`]
        """
        self._failure_list = failure_list

    def to_dict(self):
        import warnings
        warnings.warn("DeployCertificateResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeployCertificateResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

# DJ Press Documentation

Welcome to the documentation site for DJ Press: a blog application for Django sites, inspired by classic WordPress.
[Available on PyPI](https://pypi.org/project/djpress/).

## Getting Started

- [Installation](installation.md) - Installing and configuring DJ Press
- [Configuration](configuration.md) - Available settings and customisation options

## Core Features

- [URL Structure](url_structure.md) - How URLs are structured in DJ Press
- [Template Tags](templatetags.md) - Template tags for displaying blog content
- [Themes](themes.md) - Creating and customising blog themes
- [Plugins](plugins.md) - Extending DJ Press with plugins
- [Search](search.md) - Search functionality and customisation
- [Markdown Customisation](markdown_customisation.md) - Customising Markdown rendering

## Content Management

- [Categories](categories.md) - Using categories to organise content
- [Tags](tags.md) - Using tags to organise content
- [Media Management](media.md) - Managing images and other media files

## Advanced Topics

- [Management Commands](management_commands.md) - Command-line tools for content management
- [Sitemap](sitemap.md) - SEO and sitemap generation
- [Groups and Permissions](groups.md) - User roles and access control

## Table of Contents

```{toctree}
---
maxdepth: 2
---
installation
configuration
url_structure
templatetags
themes
plugins
search
markdown_customisation
categories
tags
media
management_commands
sitemap
groups
```

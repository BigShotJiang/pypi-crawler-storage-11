"""OpenAI/ChatGPT examples."""


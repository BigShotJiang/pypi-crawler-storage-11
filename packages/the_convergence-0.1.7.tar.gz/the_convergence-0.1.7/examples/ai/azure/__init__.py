"""Azure OpenAI examples."""


from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from galileo.utils.headers_data import get_package_version
from galileo_core.constants.request_method import RequestMethod
from galileo_core.helpers.api_client import ApiClient

from ... import errors
from ...models.collaborator_update import CollaboratorUpdate
from ...models.http_validation_error import HTTPValidationError
from ...models.user_collaborator import UserCollaborator
from ...types import Response


def _get_kwargs(project_id: str, user_id: str, *, body: CollaboratorUpdate) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": RequestMethod.PATCH,
        "return_raw_response": True,
        "path": f"/projects/{project_id}/users/{user_id}",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    headers["X-Galileo-SDK"] = f"galileo-python/{get_package_version()}"

    _kwargs["content_headers"] = headers
    return _kwargs


def _parse_response(
    *, client: ApiClient, response: httpx.Response
) -> Optional[Union[HTTPValidationError, UserCollaborator]]:
    if response.status_code == 200:
        return UserCollaborator.from_dict(response.json())

    if response.status_code == 422:
        return HTTPValidationError.from_dict(response.json())

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(
    *, client: ApiClient, response: httpx.Response
) -> Response[Union[HTTPValidationError, UserCollaborator]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str, user_id: str, *, client: ApiClient, body: CollaboratorUpdate
) -> Response[Union[HTTPValidationError, UserCollaborator]]:
    """Update User Project Collaborator.

     Update the sharing permissions of a user on a project.

    Args:
        project_id (str):
        user_id (str):
        body (CollaboratorUpdate):

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Response[Union[HTTPValidationError, UserCollaborator]]
    """
    kwargs = _get_kwargs(project_id=project_id, user_id=user_id, body=body)

    response = client.request(**kwargs)

    return _build_response(client=client, response=response)


def sync(
    project_id: str, user_id: str, *, client: ApiClient, body: CollaboratorUpdate
) -> Optional[Union[HTTPValidationError, UserCollaborator]]:
    """Update User Project Collaborator.

     Update the sharing permissions of a user on a project.

    Args:
        project_id (str):
        user_id (str):
        body (CollaboratorUpdate):

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Union[HTTPValidationError, UserCollaborator]
    """
    return sync_detailed(project_id=project_id, user_id=user_id, client=client, body=body).parsed


async def asyncio_detailed(
    project_id: str, user_id: str, *, client: ApiClient, body: CollaboratorUpdate
) -> Response[Union[HTTPValidationError, UserCollaborator]]:
    """Update User Project Collaborator.

     Update the sharing permissions of a user on a project.

    Args:
        project_id (str):
        user_id (str):
        body (CollaboratorUpdate):

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Response[Union[HTTPValidationError, UserCollaborator]]
    """
    kwargs = _get_kwargs(project_id=project_id, user_id=user_id, body=body)

    response = await client.arequest(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str, user_id: str, *, client: ApiClient, body: CollaboratorUpdate
) -> Optional[Union[HTTPValidationError, UserCollaborator]]:
    """Update User Project Collaborator.

     Update the sharing permissions of a user on a project.

    Args:
        project_id (str):
        user_id (str):
        body (CollaboratorUpdate):

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Union[HTTPValidationError, UserCollaborator]
    """
    return (await asyncio_detailed(project_id=project_id, user_id=user_id, client=client, body=body)).parsed

from .core import BeaverDB
from .types import Model
from .collections import Document, WalkDirection

__version__ = "0.21.1"

"""OKX WebSocket provider implementation."""

"""Bybit WebSocket provider implementation."""

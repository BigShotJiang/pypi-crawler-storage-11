"""
Tests for custom evaluators.
"""

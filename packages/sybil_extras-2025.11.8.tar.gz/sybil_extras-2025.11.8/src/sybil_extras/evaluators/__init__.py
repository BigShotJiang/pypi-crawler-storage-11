"""
Evaluators for Sybil.
"""

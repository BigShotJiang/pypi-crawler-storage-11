"""
Custom parsers for Markdown.
"""

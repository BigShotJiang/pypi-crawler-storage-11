"""
Boards Backend SDK
Open-source creative toolkit for AI-generated content
"""

__version__ = "0.2.0"

from .config import settings

__all__ = ["settings", "__version__"]

from typing import TYPE_CHECKING, Optional, Union

from ..constants import VALID_COLS
from . import row_types as rt
from .compare import compare_year as _compare_year
from .table_class import Table
from .table_generator import generate_table_from_template

if TYPE_CHECKING:
    from pyproforma import Model


class Tables:
    """
    A namespace for table creation methods within a Pyproforma model.

    The Tables class provides a comprehensive interface for generating various types
    of tables from a Pyproforma Model. It serves as the primary entry point for
    creating formatted tables that display model data, including line items,
    categories, constraints, and custom templates.

    This class is typically accessed through a Model instance's `tables` attribute
    and provides methods to generate tables for different aspects of the financial
    model, such as individual line items, category summaries, constraint analysis,
    and comprehensive model overviews.

    Attributes:
        _model (Model): The underlying Pyproforma model containing the data
            and definitions used for table generation.

    Examples:
        >>> model = Model(...)  # Initialize with required parameters
        >>> table = model.tables.category('revenue')
    """

    def __init__(self, model: "Model"):
        """Initialize the main tables namespace with a Model."""
        self._model = model

    def from_template(
        self, template: list[dict], col_labels: Union[str, list[str]] = "Years"
    ) -> Table:
        """
        Generate a table from a template of row configurations.

        Args:
            template (list[dict]): A list of row configuration dictionaries that define
                the structure and content of the table. Each dictionary should specify
                the row type and its parameters (e.g., ItemRow, LabelRow, etc.).
            col_labels: String or list of strings for label columns. Defaults to "Years".

        Returns:
            Table: A Table object containing the rows and data as specified by the template.

        Examples:
            >>> template = [
            ...     rt.LabelRow(label='Revenue', bold=True),
            ...     rt.ItemRow(name='sales_revenue', included_cols=['label']),
            ...     rt.ItemRow(name='other_revenue', included_cols=['label'])
            ... ]
            >>> table = tables.from_template(template, col_labels="Years")
        """  # noqa: E501
        table = generate_table_from_template(
            self._model, template, col_labels=col_labels
        )
        return table

    def line_items(
        self,
        line_items: Optional[list[str]] = None,
        include_name: bool = True,
        include_label: bool = False,
        include_category: bool = False,
        col_order: Optional[list[str]] = None,
        col_labels: Optional[Union[str, list[str]]] = None,
        group_by_category: bool = False,
        include_percent_change: bool = False,
        include_totals: bool = False,
        hardcoded_color: Optional[str] = None,
    ) -> Table:
        """
        Generate a table containing line items with optional category organization.

        Creates a table that displays line items from the model. If no specific
        line items are provided, includes all line items from the model. When
        group_by_category is True, groups items by category with category
        headers.

        Args:
            line_items (Optional[list[str]]): List of line item names to include.
                                             If None, includes all line items. Defaults to None.
            include_name (bool): Whether to include the name column. Defaults to True.
            include_label (bool): Whether to include the label column. Defaults to False.
            include_category (bool): Whether to include the category column. Defaults to False.
            col_order (Optional[list[str]]): Order of columns (name, label, category).
                                            If provided, only columns in this list are included,
                                            overriding include_name, include_label, and include_category.
                                            Must only contain valid column names: 'name', 'label', 'category'.
                                            Defaults to None.
            col_labels (Optional[str | list[str]]): Label columns specification. Can be a string
                                                   or list of strings. Defaults to None.
            group_by_category (bool, optional): Whether to group line items by category
                                                     and include category header rows. Defaults to False.
            include_percent_change (bool, optional): Whether to include a percent change row
                                                    after each item row. Defaults to False.
            include_totals (bool, optional): Whether to include a totals row at the end
                                           of the table. Defaults to False.
            hardcoded_color (Optional[str]): CSS color string to use for hardcoded values.
                                           If provided, cells with hardcoded values will be
                                           displayed in this color. Defaults to None.

        Returns:
            Table: A Table object containing the specified line items.

        Examples:
            >>> table = model.tables.line_items()
            >>> table = model.tables.line_items(line_items=['revenue_sales', 'cost_of_goods'])
            >>> table = model.tables.line_items(include_name=False, include_label=True)
            >>> table = model.tables.line_items(col_order=['label', 'category'])
            >>> table = model.tables.line_items(group_by_category=True)
            >>> table = model.tables.line_items(include_percent_change=True)
            >>> table = model.tables.line_items(include_totals=True)
        """  # noqa: E501
        # Determine which columns to include
        if col_order is not None:
            # Validate col_order entries
            for col in col_order:
                if col not in VALID_COLS:
                    raise ValueError(
                        f"Invalid column '{col}' in col_order. "
                        f"Must be one of: {VALID_COLS}"
                    )
            included_cols = col_order
        else:
            # Build included_cols from individual flags
            included_cols = []
            if include_name:
                included_cols.append("name")
            if include_label:
                included_cols.append("label")
            if include_category:
                included_cols.append("category")

            # If no columns specified, default to just name
            if not included_cols:
                included_cols = ["name"]

        # Set default col_labels if not provided
        if col_labels is None:
            col_labels = included_cols

        # Get line items to include
        if line_items is None:
            # Get all line items in their existing order using metadata
            items_metadata = self._model.line_item_metadata.copy()
        else:
            # Filter metadata to only include specified items
            items_metadata = [
                item
                for item in self._model.line_item_metadata
                if item["name"] in line_items
            ]

        # Sort by category if we need category labels
        if group_by_category:
            # Create a mapping of category names to their order in the model
            category_order = {
                name: i for i, name in enumerate(self._model.category_names)
            }
            # Sort by category order, then by original order within category
            items_metadata = sorted(
                items_metadata,
                key=lambda x: category_order.get(x["category"], float("inf")),
            )

        # Create template
        template = []
        current_category = None

        for item in items_metadata:
            # Add category label if needed and this is a new category
            if group_by_category:
                item_category = item["category"]
                if item_category != current_category:
                    # Get category label from model
                    category_metadata = self._model._get_category_metadata(
                        item_category
                    )
                    category_label = category_metadata["label"]

                    template.append(
                        rt.LabelRow(
                            label=category_label, bold=True, included_cols=included_cols
                        )
                    )
                    current_category = item_category

            # Add the item row
            template.append(
                rt.ItemRow(
                    name=item["name"],
                    included_cols=included_cols,
                    hardcoded_color=hardcoded_color,
                )
            )

            # Add percent change row if requested
            if include_percent_change:
                template.append(rt.PercentChangeRow(name=item["name"]))

        # Add totals row if requested
        if include_totals:
            # Get the list of line item names for the total calculation
            total_line_item_names = [item["name"] for item in items_metadata]
            template.append(
                rt.LineItemsTotalRow(
                    line_item_names=total_line_item_names,
                    included_cols=included_cols,
                    label="Total",
                    bold=True,
                    top_border="single",
                )
            )

        return self.from_template(template, col_labels=col_labels)

    def category(
        self,
        category_name: str,
        include_totals: bool = True,
        hardcoded_color: Optional[str] = None,
    ) -> Table:
        """
        Generate a table for a specific category showing all line items in that category.

        Args:
            category_name (str): The name of the category to generate the table for.
            include_totals (bool, optional): Whether to include a totals row at the end
                                           of the table. Defaults to True.
            hardcoded_color (Optional[str]): CSS color string to use for hardcoded values.
                                           If provided, cells with hardcoded values will be
                                           displayed in this color. Defaults to None.

        Returns:
            Table: A Table object containing all line items in the specified category.
        """  # noqa: E501
        # Get all line item names for this category
        line_item_names = self._model.line_item_names_by_category(category_name)

        # Use the line_items method with the include_totals parameter
        return self.line_items(
            line_items=line_item_names,
            include_name=False,
            include_label=True,
            group_by_category=True,
            hardcoded_color=hardcoded_color,
            include_totals=include_totals,
        )

    def line_item(
        self,
        name: str,
        include_name: bool = False,
        hardcoded_color: Optional[str] = None,
    ) -> Table:
        """
        Generate a table for a specific line item showing its label and values by year.

        Args:
            name (str): The name of the line item to generate the table for.
            include_name (bool, optional): Whether to include the name column. Defaults to False.
            hardcoded_color (Optional[str]): CSS color string to use for hardcoded values.
                                           If provided, cells with hardcoded values will be
                                           displayed in this color. Defaults to None.

        Returns:
            Table: A Table object containing the line item's label and values across years.
        """  # noqa: E501
        # Determine columns to include based on include_name parameter
        cols = ["name", "label"] if include_name else ["label"]

        rows = [
            rt.ItemRow(name=name, included_cols=cols, hardcoded_color=hardcoded_color),
            rt.PercentChangeRow(name=name, label="% Change"),
            rt.CumulativeChangeRow(name=name, label="Cumulative Change"),
            rt.CumulativePercentChangeRow(name=name, label="Cumulative % Change"),
        ]
        return self.from_template(rows)

    def constraint(self, constraint_name: str, color_code: bool = True) -> Table:
        """
        Generate a table for a specific constraint showing its line item, target, variance, and pass/fail status.

        Args:
            constraint_name (str): The name of the constraint to generate the table for.
            color_code (bool, optional): Whether to apply color coding to the table. Defaults to True.

        Returns:
            Table: A Table object containing the constraint's line item, target, variance, and pass/fail rows.
        """  # noqa: E501
        constraint_results = self._model.constraint(constraint_name)
        rows = [
            rt.LabelRow(label=constraint_results.label, bold=True),
            rt.ItemRow(name=constraint_results.line_item_name, included_cols=["label"]),
            rt.ConstraintTargetRow(constraint_name=constraint_name, label="Target"),
            rt.ConstraintVarianceRow(constraint_name=constraint_name, label="Variance"),
            rt.ConstraintPassRow(
                constraint_name=constraint_name,
                label="Pass/Fail",
                color_code=color_code,
            ),
        ]
        return self.from_template(rows)

    def compare_year(
        self,
        year: int,
        names: Optional[list[str]] = None,
        include_change: bool = True,
        include_percent_change: bool = True,
        sort_by: Optional[str] = None,
    ) -> Table:
        """
        Create a year-over-year comparison table.

        Args:
            year (int): The year to compare (will compare year-1 to year)
            names (Optional[list[str]]): List of line item names to include.
                                       If None, includes all line items. Defaults to None.
            include_change (bool): Whether to include the Change column. Defaults to True.
            include_percent_change (bool): Whether to include the Percent Change column. Defaults to True.
            sort_by (Optional[str]): How to sort the items. Options: None, 'value', 'change', 'percent_change'.
                                     None keeps the original order. Defaults to None.

        Returns:
            Table: A table with columns for previous year, current year, and optional change columns

        Raises:
            ValueError: If year or year-1 are not in the model's years, or if sort_by is invalid

        Examples:
            >>> table = model.tables.compare_year(2024, ['revenue_sales', 'cost_of_goods'])
            >>> table = model.tables.compare_year(2024, ['revenue_sales'], sort_by='change')
            >>> table = model.tables.compare_year(2024)  # Uses all line items
        """  # noqa: E501
        return _compare_year(
            self._model,
            year,
            names,
            include_change=include_change,
            include_percent_change=include_percent_change,
            sort_by=sort_by,
        )

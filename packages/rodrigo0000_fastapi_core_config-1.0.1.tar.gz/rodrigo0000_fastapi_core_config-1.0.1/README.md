# rodrigo0000-fastapi-core-config

Configuration, security, and repository utilities for FastAPI.

## Features

- Environment-based configuration management
- Centralized settings using Pydantic
- Security configuration
- Repository pattern utilities

## Installation

```bash
pip install rodrigo0000-fastapi-core-config
```

## Usage

```python
from rodrigo0000_fastapi_core_config import Settings

settings = Settings()
print(settings.DATABASE_URL)
print(settings.SECRET_KEY)
```

## Components

- **Settings**: Centralized configuration management
- **Security Config**: Security-related settings
- **Repository Utils**: Base utilities for repository pattern

## Requirements

- Python >= 3.8
- Pydantic >= 2.0.0
- Pydantic-settings >= 2.0.0

## License

MIT License

## Author

R Firm - Professional SaaS Development

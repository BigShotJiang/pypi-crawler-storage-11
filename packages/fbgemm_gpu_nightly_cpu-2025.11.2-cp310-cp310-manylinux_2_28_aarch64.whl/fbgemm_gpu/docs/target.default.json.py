
{
    "version": "2025.11.2",
    "target": "default",
    "variant": "cpu"
}

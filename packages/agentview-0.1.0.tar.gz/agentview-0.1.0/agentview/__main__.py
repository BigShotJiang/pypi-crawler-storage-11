"""Entry point for agentview CLI (to be implemented)."""

def main():
    print("agentview - Causality Analysis for LangGraph Agents")
    print("Version 0.1.0")
    print("\nThis package is currently in development.")
    print("See https://pypi.org/project/agentview/ for updates.")

if __name__ == "__main__":
    main()



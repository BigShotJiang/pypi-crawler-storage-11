"""
agentview: Causality Analysis for LangGraph Agents

A lightweight Python library that extracts and visualizes causal relationships
in LangGraph agent executions, providing decision provenance and debugging insights.
"""

__version__ = "0.1.0"
__author__ = "Varun"

# Core imports (will be implemented)
# from agentview.tracer import trace_causality, CausalityTracer
# from agentview.analysis import get_causal_graph, explain_decision

__all__ = [
    "__version__",
    # "trace_causality",
    # "CausalityTracer",
    # "get_causal_graph",
    # "explain_decision",
]



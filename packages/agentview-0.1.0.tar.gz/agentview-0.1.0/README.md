# agentview

Causality Analysis and Decision Provenance for LangGraph Agents

## Overview

agentview is a lightweight Python library that extracts and visualizes causal relationships in LangGraph agent executions. Unlike observability tools that log what happened, agentview explains **why** decisions were made by analyzing state transitions, conditional routing logic, and LLM reasoning within graph nodes.

## Features

- 🎯 **Decision Provenance**: Automatically extracts why agents made specific decisions
- 🔗 **Causal Graph Analysis**: Builds causal relationships from execution traces
- 📊 **Visualization**: Local web UI for exploring agent executions
- 🧩 **Minimal Integration**: Works with existing LangGraph agents with <100 lines of code
- 🔒 **Local-First**: No external services, runs entirely offline

## Status

**Early Development**: This package is currently under active development. The initial release is primarily to reserve the package name on PyPI.

## Planned Capabilities

- Instrument LangGraph StateGraph executions with minimal code changes
- Capture state transitions and conditional routing decisions
- Extract LLM reasoning traces and tool selection rationale
- Generate natural language explanations for agent decisions
- Visualize causal graphs and execution timelines
- Identify alternative paths not taken

## Installation

```bash
pip install agentview
```

## Planned Usage

```python
from agentview import trace_causality
from langgraph.graph import StateGraph

# Build your LangGraph agent
graph = StateGraph(AgentState)
graph.add_node("plan", plan_node)
graph.add_node("act", act_node)
graph.add_conditional_edges("plan", route_function)

# Compile and wrap with agentview
app = graph.compile()
traced_app = trace_causality(app, output_dir="./traces")

# Run normally - agentview captures everything
result = traced_app.invoke({"query": "Book a flight to Paris"})

# Access causality analysis
causal_graph = traced_app.get_causal_graph()
explanation = traced_app.explain_decision(node="plan", transition="plan→act")
```

## Requirements

- Python 3.10+
- LangGraph 0.2.0+

## Roadmap

See [requirements.md](requirements.md) for detailed project goals and research contributions.

## Contributing

Contributions are welcome! This project is in early development and feedback is appreciated.

## License

MIT License

## Authors

Varun

## Links

- PyPI: https://pypi.org/project/agentview/
- Documentation: Coming soon

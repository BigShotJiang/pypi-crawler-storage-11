

class Receive:
    def __init__(self):
        pass


    def execute(self):
        for i in range(1, 10):
            print(i)
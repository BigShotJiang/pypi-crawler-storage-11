
class Send:
    def __init__(self):
        pass


    def execute(self, message):
        for i in range(1, 10):
            print(f'mensagem {i} {message}')
from abc import ABC, abstractmethod
from typing import Optional, Tuple

from .models.api_models import (
    APIMessage,
    APIMessageInfo,
    APIQueryMessageURIParams,
    APIReact,
    APISignFile,
    APISignFileInfo,
    ListAPIMessageInfo,
    ListAPIReactInfo,
)
from .models.base_models import QueryParams


class IPachca(ABC):
    _base_url = "https://api.pachca.com/api/shared/v1"

    @abstractmethod
    async def send_message(
        self, mes: APIMessage
    ) -> Tuple[Optional[Exception], Optional[APIMessageInfo]]:
        pass

    @abstractmethod
    async def get_message(
        self, msg_id: int
    ) -> Tuple[Optional[Exception], Optional[APIMessageInfo]]:
        pass

    @abstractmethod
    async def get_messages(
        self, query_params: APIQueryMessageURIParams
    ) -> Tuple[Optional[Exception], Optional[ListAPIMessageInfo]]:
        pass

    @abstractmethod
    async def set_react(
        self, msg_id: int, react: APIReact
    ) -> Tuple[Optional[Exception], None]:
        pass

    @abstractmethod
    async def get_reacts(
        self, msg_id: int, query_params: QueryParams = QueryParams()
    ) -> Tuple[Optional[Exception], Optional[ListAPIReactInfo]]:
        pass

    @abstractmethod
    async def get_credentials_for_file(
        self,
    ) -> Tuple[Optional[Exception], Optional[APISignFileInfo]]:
        pass

    @abstractmethod
    async def upload_file(
        self, credentials: APISignFile
    ) -> Tuple[Optional[Exception], None]:
        pass

    @abstractmethod
    async def delete_message(self, msg_id: int) -> Tuple[Optional[Exception], None]:
        pass

    @abstractmethod
    async def get_read_members(
        self, msg_id: int, query_params: QueryParams = QueryParams()
    ) -> Tuple[Optional[Exception], Optional[list[int]]]:
        pass

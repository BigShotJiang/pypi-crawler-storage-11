from types import MappingProxyType
from typing import Optional, Tuple, Type

from aiohttp import ClientSession
from pydantic import BaseModel

from .ipachca import IPachca
from .models.api_models import (
    APIListReadMembers,
    APIMessage,
    APIMessageInfo,
    APIQueryMessageURIParams,
    APIReact,
    APISignFile,
    APISignFileInfo,
    ListAPIMessageInfo,
    ListAPIReactInfo,
)
from .models.base_models import QueryParams


class PachcaImpl(IPachca):
    def __init__(self, session: ClientSession):
        self._session = session

    async def _get(
        self, url: str, query_params: dict = MappingProxyType({})
    ) -> Tuple[Optional[Exception], Optional[dict]]:
        try:
            async with self._session.get(url, params=query_params) as resp:
                resp.raise_for_status()
                return None, await resp.json()
        except Exception as err:
            return err, None

    async def _post(
        self, url: str, json_payload: dict = MappingProxyType({})
    ) -> Tuple[Optional[Exception], Optional[dict]]:
        try:
            async with self._session.post(url, json=json_payload) as resp:
                resp.raise_for_status()
                return None, await resp.json()
        except Exception as err:
            return err, None

    async def _delete(
        self, url: str, query_params: dict = MappingProxyType({})
    ) -> Tuple[Optional[Exception], Optional[dict]]:
        try:
            async with self._session.delete(url, params=query_params) as resp:
                resp.raise_for_status()
                return None, await resp.json()
        except Exception as err:
            return err, None

    @staticmethod
    async def try_cast(
        obj_dict: dict, model: Type[BaseModel]
    ) -> Tuple[Optional[Exception], Optional[BaseModel]]:
        try:
            return None, model.model_validate(obj_dict)
        except Exception as err:
            return err, None

    # URL: https://crm.pachca.com/dev/messages/new/
    async def send_message(
        self, mes: APIMessage
    ) -> Tuple[Optional[Exception], Optional[APIMessageInfo]]:
        err, answer = await self._post(
            f"{self._base_url}/messages", json_payload=mes.model_dump()
        )

        if err:
            return err, None

        return await self.try_cast(
            answer,
            APIMessageInfo,
        )

    # URL: https://crm.pachca.com/dev/messages/get/
    async def get_message(
        self, msg_id: int
    ) -> Tuple[Optional[Exception], Optional[APIMessageInfo]]:
        err, ans = await self._get(f"{self._base_url}/messages/{msg_id}")

        if err:
            return err, None

        return await self.try_cast(ans, APIMessageInfo)

    # URL: https://crm.pachca.com/dev/messages/list/
    async def get_messages(
        self, query_params: APIQueryMessageURIParams
    ) -> Tuple[Optional[Exception], Optional[ListAPIMessageInfo]]:
        err, ans = await self._get(
            f"{self._base_url}/messages", query_params=query_params.model_dump()
        )

        if err:
            return err, None

        return await self.try_cast(
            ans,
            ListAPIMessageInfo,
        )

    # URL: https://crm.pachca.com/dev/reactions/new/
    async def set_react(
        self, msg_id: int, react: APIReact
    ) -> Tuple[Optional[Exception], None]:
        err, ans = await self._post(
            f"{self._base_url}/messages/{msg_id}/reactions",
            json_payload=react.model_dump(),
        )

        return err, None

    # URL: https://crm.pachca.com/dev/reactions/list/
    async def get_reacts(
        self, msg_id: int, query_params: QueryParams = QueryParams()
    ) -> Tuple[Optional[Exception], Optional[ListAPIReactInfo]]:
        err, ans = await self._get(
            f"{self._base_url}/messages/{msg_id}/reactions",
            query_params=query_params.model_dump(),
        )

        if err:
            return err, None

        return await self.try_cast(
            ans,
            ListAPIReactInfo,
        )

    # URL: https://crm.pachca.com/dev/common/files/
    async def get_credentials_for_file(
        self,
    ) -> Tuple[Optional[Exception], Optional[APISignFile]]:
        err, ans = await self._post(f"{self._base_url}/uploads")

        if err:
            return err, None

        return await self.try_cast(ans, APISignFile)

    # URL: https://crm.pachca.com/dev/common/files/
    async def upload_file(
        self, credentials: APISignFileInfo
    ) -> Tuple[Optional[Exception], None]:
        return await self._post(
            str(credentials.direct_url), json_payload=credentials.model_dump()
        )

    # URL: https://crm.pachca.com/dev/messages/delete/
    async def delete_message(self, msg_id: int) -> Tuple[Optional[Exception], None]:
        return await self._delete(f"{self._base_url}/messages/{msg_id}")

    # URL: https://crm.pachca.com/dev/read_members/list/
    async def get_read_members(
        self, msg_id: int, query_params: QueryParams = QueryParams()
    ) -> Tuple[Optional[Exception], Optional[APIListReadMembers]]:
        err, ans = await self._get(
            f"{self._base_url}/messages/{msg_id}/read_member_ids",
            query_params=query_params.model_dump(),
        )

        if err:
            return err, None

        return await self.try_cast(ans, APIListReadMembers)


class PachcaManager(PachcaImpl):
    """Для взаимодействия в рамках одной сессии с Пачкой используй PachcaManager"""

    def __init__(self, token):
        self._session = ClientSession(headers={"Authorization": f"Bearer {token}"})
        super().__init__(self._session)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._session.close()

"""Tests for todozi package."""

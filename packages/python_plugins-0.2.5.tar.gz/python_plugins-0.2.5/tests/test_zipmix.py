import pytest
import os
import os.path as op
import shutil
from python_plugins.crypto.zipmix import ZipMix

def test_z7_available():
    zm = ZipMix()
    assert zm.z7_available is True

def test_int_bytes_roundtrip():
    zm = ZipMix()
    for v in (0, 1, 255, 256, 65535, 2**24 - 1):
        b = zm.int_to_bytes(v)
        assert isinstance(b, bytes)
        assert zm.int_from_bytes(b) == v


def test_create_and_extract_mix_flag():
    zm = ZipMix()
    pos = 0x01020304
    nlen = 7
    flag = zm.create_mix_flag(pos, nlen)
    assert isinstance(flag, bytes)
    assert len(flag) == 8
    extracted = zm.extract_from_mix_flag(flag)
    assert extracted == (pos, nlen)
    with pytest.raises(ValueError):
        zm.extract_from_mix_flag(b"0" * 8)


def test_insert_string_to_binary():
    zm = ZipMix()
    data = os.urandom(500)
    insert = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    new_1 = zm.insert_string_to_binary(data, insert)
    assert len(new_1) - len(data) == len(insert) * 5 + 4
    old_insert, old = zm.extract_string_from_binary(new_1)
    assert old_insert == insert
    assert data == old
    new_2 = zm.insert_string_to_binary(data, insert)
    assert len(new_2) == len(new_1)
    assert new_2 != new_1
    old_insert, old = zm.extract_string_from_binary(new_2)
    assert old_insert == insert
    assert data == old


def test_zip7():
    parent_dir = op.realpath(op.dirname(__file__))
    f_test = op.join(parent_dir, "tmp","test.txt")
    f_test_7z = op.join(parent_dir, "tmp","test.txt.7z")
    if os.path.exists(f_test_7z):
        os.unlink(f_test_7z)
    dir_test_out = op.join(parent_dir, "tmp","out")
    f_test_out = op.join(parent_dir, "tmp","out","test.txt")
    
    zm = ZipMix()
    r_zip=zm.zip7(f_test)
    assert len(r_zip)==2
    assert r_zip[0] == "ok"
    f_zip = r_zip[1]
    # r_list = zm.unzip7_list_archive(f_zip)
    # assert r_list[0] == "ok"
    r_unzip = zm.unzip7(f_zip,dir_test_out)
    assert r_unzip[0] == "ok"
    r_cmp = zm.filecmp(f_test,f_test_out)
    assert r_cmp is True
    if os.path.exists(f_zip):
        os.unlink(f_zip)
    if os.path.exists(f_test_out):
        os.unlink(f_test_out)

def test_zip7_dir():
    parent_dir = op.realpath(op.dirname(__file__))
    f_test = op.join(parent_dir, "tmp","testdir")
    f_test_7z = op.join(parent_dir, "tmp","testdir.7z")
    if os.path.exists(f_test_7z):
        os.unlink(f_test_7z)
    dir_test_out = op.join(parent_dir, "tmp","out","testdir")
    zm = ZipMix()
    r_zip=zm.zip7(f_test)
    assert len(r_zip)==2
    assert r_zip[0] == "ok"
    f_zip = r_zip[1]
    # r_list = zm.unzip7_list_archive(f_zip)
    # assert r_list[0] == "ok"
    r_unzip = zm.unzip7(f_zip,dir_test_out)
    assert r_unzip[0] == "ok"
    # r_cmp = zm.filecmp(f_test,f_test_out)
    # assert r_cmp is True
    if os.path.exists(f_zip):
        os.unlink(f_zip)
    if os.path.exists(dir_test_out):
        shutil.rmtree(dir_test_out)

def test_zip7_force_password():
    parent_dir = op.realpath(op.dirname(__file__))
    f_test = op.join(parent_dir, "tmp","test.txt")
    f_test_7z = op.join(parent_dir, "tmp","test.txt.7z")
    if os.path.exists(f_test_7z):
        os.unlink(f_test_7z)
    dir_test_out = op.join(parent_dir, "tmp","out")
    f_test_out = op.join(parent_dir, "tmp","out","test.txt")
    zm = ZipMix()
    r_zip=zm.zip7(f_test,force_pwd=True)
    assert len(r_zip)==3
    assert r_zip[0] == "ok"
    f_zip = r_zip[1]
    pwd = r_zip[2]
    # r_list = zm.unzip7_list_archive(f_zip)
    # assert r_list[0] == "ok"
    r_unzip = zm.unzip7(f_zip,dir_test_out,pwd=pwd)
    assert r_unzip[0] == "ok"
    r_cmp = zm.filecmp(f_test,f_test_out)
    assert r_cmp is True
    if os.path.exists(f_zip):
        os.unlink(f_zip)
    if os.path.exists(f_test_out):
        os.unlink(f_test_out)

def test_zip7_mix():
    parent_dir = op.realpath(op.dirname(__file__))
    f_test = op.join(parent_dir, "tmp","test.txt")
    f_test_7z = op.join(parent_dir, "tmp","test.txt.7z")
    if os.path.exists(f_test_7z):
        os.unlink(f_test_7z)
    dir_test_out = op.join(parent_dir, "tmp","out")
    f_test_out = op.join(parent_dir, "tmp","out","test.txt")
    zm = ZipMix()
    r_zip=zm.zip7mix(f_test)
    assert len(r_zip)==2
    assert r_zip[0] == "ok"
    f_zipmix = r_zip[1]
    r_unzip = zm.unzip7mix(f_zipmix,dir_test_out)
    assert r_unzip[0] == "ok"
    r_cmp = zm.filecmp(f_test,f_test_out)
    assert r_cmp is True
    if os.path.exists(f_zipmix):
        os.unlink(f_zipmix)
    if os.path.exists(f_test_out):
        os.unlink(f_test_out)
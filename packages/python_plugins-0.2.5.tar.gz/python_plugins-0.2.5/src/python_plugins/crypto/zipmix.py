import os
import random
import hashlib
import tempfile
import filecmp
from pathlib import Path
import subprocess


class ZipMix:
    def __init__(self, zipcmd="7z"):
        self.zipcmd = zipcmd
        self.z7_available = self.check_7z_available()

    def check_7z_available(self) -> bool:
        try:
            subprocess.run([self.zipcmd], capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def create_mix_flag(self, pos: int, nlen: int) -> bytes:
        """m{}i{}x{}{nlen}{}"""
        start_bytes = pos.to_bytes(4, byteorder="big")
        return b"m%si%sx%s%s%s" % (
            start_bytes[0:1],
            start_bytes[1:2],
            start_bytes[2:3],
            nlen.to_bytes(1, byteorder="big"),
            start_bytes[3:4],
        )

    def int_to_bytes(self, pos: int):
        return pos.to_bytes(4, byteorder="big")

    def int_from_bytes(self, intbs):
        return int.from_bytes(intbs, byteorder="big")

    def extract_from_mix_flag(self, mix_flag):
        fix_flag = mix_flag[0:1] + mix_flag[2:3] + mix_flag[4:5]
        if fix_flag != b"mix":
            raise ValueError("not match mix.")
        nlen = self.int_from_bytes(mix_flag[6:7])
        pos = self.int_from_bytes(
            mix_flag[1:2] + mix_flag[3:4] + mix_flag[5:6] + mix_flag[7:8]
        )
        return (pos, nlen)

    def insert_string_to_binary(self, data, insert_bytes):
        n_data = len(data)
        n_ibytes = len(insert_bytes)
        pos_list = sorted(random.sample(range(min(n_data, 0xFFFFFFFF)), n_ibytes))

        parts = []
        pre_pos = 0

        for i, curr_pos in enumerate(pos_list):
            if i == 0:
                end_flag = self.create_mix_flag(curr_pos, n_ibytes)
            else:
                parts.append(self.int_to_bytes(curr_pos))

            parts.append(data[pre_pos:curr_pos])
            parts.append(insert_bytes[i : i + 1])
            pre_pos = curr_pos

        parts.append(data[pre_pos:])
        parts.append(end_flag)
        return b"".join(parts)

    def extract_string_from_binary(self, data):
        start_pos, n_insert_bytes = self.extract_from_mix_flag(data[-8:])
        parts = []
        insert_parts = []
        pos_list = [start_pos]
        data_pre_pos = 0
        curr_pos = start_pos

        for k in range(n_insert_bytes):
            data_curr_pos = curr_pos + 5 * k
            parts.append(data[data_pre_pos:data_curr_pos])
            insert_parts.append(data[data_curr_pos : data_curr_pos + 1])
            if k < n_insert_bytes - 1:
                curr_pos = self.int_from_bytes(
                    data[data_curr_pos + 1 : data_curr_pos + 5]
                )
                pos_list.append(curr_pos)
                data_pre_pos = data_curr_pos + 5
            else:
                curr_pos = None
                data_pre_pos = data_curr_pos + 1

        parts.append(data[data_pre_pos:-8])
        return b"".join(insert_parts), b"".join(parts)

    def _generate_password(self) -> str:
        return hashlib.sha256(os.urandom(1000)).hexdigest()[:32]

    def zip7(self, file_or_dir, archive_path=None, pwd=None, force_pwd=False,silent = True):
        path_obj = Path(file_or_dir)
        if not path_obj.exists():
            return None

        if archive_path is None:
            archive_path = file_or_dir + ".7z"

        if pwd is None:
            if force_pwd:
                pwd = self._generate_password()
        else:
            pwd = pwd[:32]

        cmd = [self.zipcmd, "a"]
        if silent:
            cmd.append("-bso0")
        if pwd:
            cmd.extend([f"-p{pwd}", "-mhe=on"])
        cmd.extend([archive_path, file_or_dir])

        try:
            subprocess.run(cmd, check=True)
            if pwd is not None:
                return ("ok", archive_path, pwd)
            else:
                return ("ok", archive_path)
        except subprocess.CalledProcessError as e:
            return ("fail", f"{e}")

    def unzip7_list_archive(self, archive_path, pwd=None,silent = True):
        cmd = [self.zipcmd, "l"]
        if silent:
            cmd.append("-bso0")
        if pwd:
            cmd.append(f"-p{pwd}")
        cmd.append(archive_path)

        try:
            subprocess.run(cmd, check=True)
            return ("ok", archive_path)
        except subprocess.CalledProcessError as e:
            return ("fail", f"{e}")

    def unzip7(self, archive_path, output_path=None, pwd=None, overwrite: bool = True,silent = True):
        archive_obj = Path(archive_path)

        if output_path is None:
            output_dir = archive_obj.parent
        else:
            output_dir = Path(output_path)

        if not output_dir.exists():
            output_dir.mkdir(parents=True, exist_ok=True)

        if not output_dir.is_dir():
            return ("fail", f"{output_dir} is not dir")

        cmd = [self.zipcmd, "x", "-y"]
        if silent:
            cmd.append("-bso0")
        if not overwrite:
            cmd.append("-aos")
        if pwd:
            cmd.append(f"-p{pwd}")
        cmd.extend([archive_path, f"-o{output_dir}"])

        try:
            subprocess.run(cmd, check=True)
            return ("ok", f"{output_dir}")
        except subprocess.CalledProcessError as e:
            return ("fail", f"{e}")

    def zip7mix(self, file_or_dir, archive_path=None,silent = True):
        path_obj = Path(file_or_dir)
        if not path_obj.exists():
            return None

        if archive_path is None:
            archive_path = file_or_dir + ".7z"

        tmp_archive_path = archive_path+".tmp"

        tmp_obj = Path(tmp_archive_path)
        if tmp_obj.exists():
            tmp_obj.unlink()

        pwd = self._generate_password()

        cmd = [self.zipcmd, "a"]
        if silent:
            cmd.append("-bso0")
        cmd.extend([f"-p{pwd}", "-mhe=on"])
        cmd.extend([tmp_archive_path, file_or_dir])

        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            return ("fail", f"{e}")
        
        with open(tmp_archive_path,"rb") as f1:
            data = f1.read()

        # remove tmp file  
        tmp_obj.unlink()
        
        new_data = self.insert_string_to_binary(data,pwd.encode('utf-8'))

        # append fake 7z tail
        new_data += data[-100:]

        with open(archive_path,"wb") as f2:
            f2.write(new_data)

        return ("ok", archive_path)

    def unzip7mix(self, archive_path, output_path=None, overwrite: bool = True,silent = True):
        archive_obj = Path(archive_path)

        tmp_archive_path = archive_path+".tmp"

        tmp_obj = Path(tmp_archive_path)
        if tmp_obj.exists():
            tmp_obj.unlink()

        if output_path is None:
            output_dir = archive_obj.parent
        else:
            output_dir = Path(output_path)

        if not output_dir.exists():
            output_dir.mkdir(parents=True, exist_ok=True)

        if not output_dir.is_dir():
            return ("fail", f"{output_dir} is not dir")
        
        with open(archive_path,"rb") as f1:
            data = f1.read()
            # remove fake 7z tail
            data = data[:-100]

        pwdbts,new_data = self.extract_string_from_binary(data)

        pwd = pwdbts.decode("utf-8")

        with open(tmp_archive_path,"wb") as f2:
            f2.write(new_data)
        
        cmd = [self.zipcmd, "x", "-y"]
        if silent:
            cmd.append("-bso0")
        if not overwrite:
            cmd.append("-aos")
        cmd.append(f"-p{pwd}")
        cmd.extend([tmp_archive_path, f"-o{output_dir}"])

        try:
            subprocess.run(cmd, check=True)
            tmp_obj.unlink()
            return ("ok", f"{output_dir}")
        except subprocess.CalledProcessError as e:
            return ("fail", f"{e}")

    def filecmp(self,f1,f2):
        result = filecmp.cmp(f1, f2, shallow=False)
        return result
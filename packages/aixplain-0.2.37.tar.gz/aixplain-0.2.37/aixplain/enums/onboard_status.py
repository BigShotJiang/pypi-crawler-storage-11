__author__ = "aiXplain"

"""
Copyright 2023 The aiXplain SDK authors

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Author: aiXplain team
Date: March 22th 2023
Description:
    Onboard Status Enum
"""

from enum import Enum


class OnboardStatus(Enum):
    """Enumeration of possible onboarding status values.

    This enum defines all possible states that an onboarding process can be in,
    from initial onboarding to completed or failed states.

    Attributes:
        ONBOARDING (str): Initial onboarding state.
        ONBOARDED (str): Successful onboarding state.
        FAILED (str): Failed onboarding state.
        DELETED (str): Deleted onboarding state.
    """
    ONBOARDING = "onboarding"
    ONBOARDED = "onboarded"
    FAILED = "failed"
    DELETED = "deleted"

"""
pfSense Redactor Test Suite
"""
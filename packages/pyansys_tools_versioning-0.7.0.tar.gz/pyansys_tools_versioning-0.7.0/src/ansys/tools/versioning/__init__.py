# Copyright (C) 2022 - 2025 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""
PyAnsys Tools Versioning.

Utilities for backwards and forwards server support.
"""
import importlib.metadata as importlib_metadata

from ansys.tools.common.versioning import requires_version, server_meets_version

__version__ = importlib_metadata.version("pyansys-tools-versioning")
__all__ = ["requires_version", "server_meets_version"]

import warnings

warnings.warn(
    "This library is deprecated and will no longer be maintained. "
    "Functionality from this library has been migrated to ``ansys-tools-common``. "
    "Please consider migrating to ``ansys-tools-common``. "
    "For more information check https://github.com/ansys/pyansys-tools-versioning/issues/417",
    DeprecationWarning,
)

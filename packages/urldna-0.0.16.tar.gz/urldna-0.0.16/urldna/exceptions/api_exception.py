class ApiException(Exception):
    pass

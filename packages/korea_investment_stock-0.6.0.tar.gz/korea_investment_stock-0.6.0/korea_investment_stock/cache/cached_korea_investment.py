from typing import Optional, Dict, Any
from ..korea_investment_stock import KoreaInvestment
from .cache_manager import CacheManager


class CachedKoreaInvestment:
    """캐싱 기능이 추가된 KoreaInvestment 래퍼"""

    DEFAULT_TTL = {
        'price': 5,           # 실시간 가격: 5초
        'stock_info': 300,    # 종목 정보: 5분
        'symbols': 3600,      # 종목 리스트: 1시간
        'ipo': 1800           # IPO 일정: 30분
    }

    def __init__(
        self,
        broker: KoreaInvestment,
        enable_cache: bool = True,
        price_ttl: Optional[int] = None,
        stock_info_ttl: Optional[int] = None,
        symbols_ttl: Optional[int] = None,
        ipo_ttl: Optional[int] = None
    ):
        """
        Args:
            broker: KoreaInvestment 인스턴스
            enable_cache: 캐싱 활성화 여부
            price_ttl: 실시간 가격 TTL (초)
            stock_info_ttl: 종목정보 TTL (초)
            symbols_ttl: 종목리스트 TTL (초)
            ipo_ttl: IPO 일정 TTL (초)
        """
        self.broker = broker
        self.enable_cache = enable_cache
        self.cache = CacheManager() if enable_cache else None

        # TTL 설정
        self.ttl = {
            'price': price_ttl or self.DEFAULT_TTL['price'],
            'stock_info': stock_info_ttl or self.DEFAULT_TTL['stock_info'],
            'symbols': symbols_ttl or self.DEFAULT_TTL['symbols'],
            'ipo': ipo_ttl or self.DEFAULT_TTL['ipo']
        }

    def _make_cache_key(self, method: str, *args, **kwargs) -> str:
        """캐시 키 생성"""
        args_str = "_".join(str(arg) for arg in args)
        kwargs_str = "_".join(f"{k}={v}" for k, v in sorted(kwargs.items()))
        return f"{method}:{args_str}:{kwargs_str}"

    def fetch_price(self, symbol: str, market: str = "KR") -> dict:
        """가격 조회 (캐싱 지원)"""
        if not self.enable_cache:
            return self.broker.fetch_price(symbol, market)

        cache_key = self._make_cache_key("fetch_price", symbol, market)
        cached_data = self.cache.get(cache_key)

        if cached_data is not None:
            return cached_data

        result = self.broker.fetch_price(symbol, market)

        if result.get('rt_cd') == '0':
            self.cache.set(cache_key, result, self.ttl['price'])

        return result

    def fetch_domestic_price(self, market_code: str, symbol: str) -> dict:
        """국내 주식 가격 조회 (캐싱 지원)"""
        if not self.enable_cache:
            return self.broker.fetch_domestic_price(market_code, symbol)

        cache_key = self._make_cache_key("fetch_domestic_price", market_code, symbol)
        cached_data = self.cache.get(cache_key)

        if cached_data is not None:
            return cached_data

        result = self.broker.fetch_domestic_price(market_code, symbol)

        if result.get('rt_cd') == '0':
            self.cache.set(cache_key, result, self.ttl['price'])

        return result

    def fetch_etf_domestic_price(self, market_code: str, symbol: str) -> dict:
        """ETF 가격 조회 (캐싱 지원)"""
        if not self.enable_cache:
            return self.broker.fetch_etf_domestic_price(market_code, symbol)

        cache_key = self._make_cache_key("fetch_etf_domestic_price", market_code, symbol)
        cached_data = self.cache.get(cache_key)

        if cached_data is not None:
            return cached_data

        result = self.broker.fetch_etf_domestic_price(market_code, symbol)

        if result.get('rt_cd') == '0':
            self.cache.set(cache_key, result, self.ttl['price'])

        return result

    def fetch_price_detail_oversea(self, symbol: str, market: str = "KR") -> dict:
        """해외 주식 가격 조회 (캐싱 지원)"""
        if not self.enable_cache:
            return self.broker.fetch_price_detail_oversea(symbol, market)

        cache_key = self._make_cache_key("fetch_price_detail_oversea", symbol, market)
        cached_data = self.cache.get(cache_key)

        if cached_data is not None:
            return cached_data

        result = self.broker.fetch_price_detail_oversea(symbol, market)

        if result.get('rt_cd') == '0':
            self.cache.set(cache_key, result, self.ttl['price'])

        return result

    def fetch_stock_info(self, symbol: str, market: str = "KR") -> dict:
        """종목 정보 조회 (캐싱 지원)"""
        if not self.enable_cache:
            return self.broker.fetch_stock_info(symbol, market)

        cache_key = self._make_cache_key("fetch_stock_info", symbol, market)
        cached_data = self.cache.get(cache_key)

        if cached_data is not None:
            return cached_data

        result = self.broker.fetch_stock_info(symbol, market)

        if result.get('rt_cd') == '0':
            self.cache.set(cache_key, result, self.ttl['stock_info'])

        return result

    def fetch_search_stock_info(self, symbol: str, market: str = "KR") -> dict:
        """종목 검색 (캐싱 지원)"""
        if not self.enable_cache:
            return self.broker.fetch_search_stock_info(symbol, market)

        cache_key = self._make_cache_key("fetch_search_stock_info", symbol, market)
        cached_data = self.cache.get(cache_key)

        if cached_data is not None:
            return cached_data

        result = self.broker.fetch_search_stock_info(symbol, market)

        if result.get('rt_cd') == '0':
            self.cache.set(cache_key, result, self.ttl['stock_info'])

        return result

    def fetch_kospi_symbols(self) -> dict:
        """KOSPI 종목 리스트 (캐싱 지원)"""
        if not self.enable_cache:
            return self.broker.fetch_kospi_symbols()

        cache_key = "fetch_kospi_symbols"
        cached_data = self.cache.get(cache_key)

        if cached_data is not None:
            return cached_data

        result = self.broker.fetch_kospi_symbols()
        self.cache.set(cache_key, result, self.ttl['symbols'])

        return result

    def fetch_kosdaq_symbols(self) -> dict:
        """KOSDAQ 종목 리스트 (캐싱 지원)"""
        if not self.enable_cache:
            return self.broker.fetch_kosdaq_symbols()

        cache_key = "fetch_kosdaq_symbols"
        cached_data = self.cache.get(cache_key)

        if cached_data is not None:
            return cached_data

        result = self.broker.fetch_kosdaq_symbols()
        self.cache.set(cache_key, result, self.ttl['symbols'])

        return result

    def fetch_ipo_schedule(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        symbol: str = ""
    ) -> dict:
        """IPO 일정 조회 (캐싱 지원)"""
        if not self.enable_cache:
            return self.broker.fetch_ipo_schedule(from_date, to_date, symbol)

        cache_key = self._make_cache_key("fetch_ipo_schedule", from_date, to_date, symbol)
        cached_data = self.cache.get(cache_key)

        if cached_data is not None:
            return cached_data

        result = self.broker.fetch_ipo_schedule(from_date, to_date, symbol)

        if result.get('rt_cd') == '0':
            self.cache.set(cache_key, result, self.ttl['ipo'])

        return result

    def invalidate_cache(self, method: Optional[str] = None):
        """캐시 무효화"""
        if not self.enable_cache:
            return

        self.cache.clear()

    def get_cache_stats(self) -> Dict[str, Any]:
        """캐시 통계 반환"""
        if not self.enable_cache:
            return {'cache_enabled': False}

        stats = self.cache.get_stats()
        stats['cache_enabled'] = True
        stats['ttl_config'] = self.ttl
        return stats

    def __enter__(self):
        """컨텍스트 매니저 진입"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """컨텍스트 매니저 종료"""
        if self.enable_cache:
            self.cache.clear()
        return False

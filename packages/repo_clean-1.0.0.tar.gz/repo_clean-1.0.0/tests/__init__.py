"""
Test suite for repo-clean
"""
class AuthApiRequestError(Exception):
    pass

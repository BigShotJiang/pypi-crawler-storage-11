import pygame
import os

class Window:
    def __init__(self, width=640, height=480, title="Game Window", icon=None):
        pygame.init()
        self.width = width
        self.height = height
        self.title = title
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption(title)

        # --- ICON HANDLING ---
        if icon:
            if isinstance(icon, str):
                icon_path = icon
                if not os.path.isabs(icon_path):
                    icon_path = os.path.join(os.getcwd(), icon)
                if os.path.exists(icon_path):
                    img = pygame.image.load(icon_path).convert_alpha()
                    pygame.display.set_icon(img)
                else:
                    print(f"⚠️ Icon file not found: {icon_path}")
            else:
                pygame.display.set_icon(icon)
        else:
            # default block icon
            default_icon = pygame.Surface((32,32))
            default_icon.fill((0,255,0))
            pygame.draw.rect(default_icon, (0,200,0), (8,8,16,16))
            pygame.display.set_icon(default_icon)

        self.clock = pygame.time.Clock()
        self.running = True

        # input
        self.keys = {}
        self.mouse_pos = (0,0)
        self.mouse_pressed = (False, False, False)

        # draw calls
        self.draw_calls = []

    # === input helpers ===
    def is_key_pressed(self, key):
        return self.keys.get(key, False)

    def is_mouse_pressed(self, button=1):
        return self.mouse_pressed[button-1]

    # === drawing helpers ===
    def draw_rect(self, color, rect):
        self.draw_calls.append(("rect", color, rect))

    def draw_circle(self, color, pos, radius):
        self.draw_calls.append(("circle", color, pos, radius))

    def draw_sprite(self, sprite):
        self.draw_calls.append(("sprite", sprite))

    # === main loop ===
    def run(self, update_func=None):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    self.keys[event.key] = True
                elif event.type == pygame.KEYUP:
                    self.keys[event.key] = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.mouse_pressed = pygame.mouse.get_pressed()
                elif event.type == pygame.MOUSEBUTTONUP:
                    self.mouse_pressed = pygame.mouse.get_pressed()
                elif event.type == pygame.MOUSEMOTION:
                    self.mouse_pos = event.pos

            if update_func:
                update_func(self)

            self.screen.fill((20,20,50))
            for call in self.draw_calls:
                if call[0] == "rect":
                    pygame.draw.rect(self.screen, call[1], call[2])
                elif call[0] == "circle":
                    pygame.draw.circle(self.screen, call[1], call[2], call[3])
                elif call[0] == "sprite":
                    call[1].draw(self.screen)
            self.draw_calls.clear()

            pygame.display.flip()
            self.clock.tick(60)

        pygame.quit()

from setuptools import setup, find_packages

setup(
    name="CrystalWindowLib",
    version="0.7.5",
    packages=find_packages(),
    install_requires=["pygame"],
    description="Mini Crystal-style game engine with window, sprites, animations, tilemap, music",
    author="Crystal friendo",
)

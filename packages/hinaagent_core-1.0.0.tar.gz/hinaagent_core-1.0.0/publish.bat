@echo off
REM 设置 PyPI Token（请替换为你的实际 token）
set UV_PUBLISH_TOKEN=pypi-你的token内容

REM 发布到 PyPI
uv publish


# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowProtectionGroupResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'server_group': 'ShowProtectionGroupParams'
    }

    attribute_map = {
        'server_group': 'server_group'
    }

    def __init__(self, server_group=None):
        r"""ShowProtectionGroupResponse

        The model defined in huaweicloud sdk

        :param server_group: 
        :type server_group: :class:`huaweicloudsdksdrs.v1.ShowProtectionGroupParams`
        """
        
        super().__init__()

        self._server_group = None
        self.discriminator = None

        if server_group is not None:
            self.server_group = server_group

    @property
    def server_group(self):
        r"""Gets the server_group of this ShowProtectionGroupResponse.

        :return: The server_group of this ShowProtectionGroupResponse.
        :rtype: :class:`huaweicloudsdksdrs.v1.ShowProtectionGroupParams`
        """
        return self._server_group

    @server_group.setter
    def server_group(self, server_group):
        r"""Sets the server_group of this ShowProtectionGroupResponse.

        :param server_group: The server_group of this ShowProtectionGroupResponse.
        :type server_group: :class:`huaweicloudsdksdrs.v1.ShowProtectionGroupParams`
        """
        self._server_group = server_group

    def to_dict(self):
        import warnings
        warnings.warn("ShowProtectionGroupResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowProtectionGroupResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

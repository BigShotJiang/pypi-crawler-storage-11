def task():
    raise Exception()

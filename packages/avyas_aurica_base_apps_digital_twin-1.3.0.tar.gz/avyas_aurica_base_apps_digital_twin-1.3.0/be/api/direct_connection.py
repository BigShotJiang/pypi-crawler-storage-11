"""
Direct Client Connection - Browser connects directly to local execution node

The cloud API only provides:
1. Authentication
2. Discovery (where is user's execution node?)
3. Optional relay if direct connection fails (NAT traversal)

The browser connects DIRECTLY to the user's local machine!
"""

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from typing import Dict, Optional, List
from datetime import datetime, timedelta
import uuid

router = APIRouter()


class ExecutionNodeInfo(BaseModel):
    """Information about an execution node"""
    user_id: str
    node_id: str
    local_url: str  # e.g., "http://192.168.1.100:8000"
    public_url: Optional[str] = None  # If port-forwarded
    capabilities: Dict = {}
    last_heartbeat: str


# Registry of execution nodes: {user_id: node_info}
# In production, this would be Redis or database
execution_nodes: Dict[str, ExecutionNodeInfo] = {}


class RegisterNodeRequest(BaseModel):
    """Register an execution node"""
    local_url: str
    public_url: Optional[str] = None
    capabilities: Dict = {}


class HeartbeatRequest(BaseModel):
    """Heartbeat to keep node registered"""
    node_id: str


@router.post("/register")
async def register_execution_node(request: Request, req: RegisterNodeRequest):
    """
    Register your local execution node.
    
    The node announces itself with its local network URL.
    Clients can then connect directly to this URL.
    
    This endpoint is called by the execution node (your computer)
    to announce its availability.
    """
    # Get user from auth
    try:
        from src.aurica_auth import get_current_user
        user = get_current_user(request)
    except:
        user = type('User', (), {"user_id": "unknown"})()
    
    node_id = str(uuid.uuid4())
    
    node_info = ExecutionNodeInfo(
        user_id=user.user_id,
        node_id=node_id,
        local_url=req.local_url,
        public_url=req.public_url,
        capabilities=req.capabilities,
        last_heartbeat=datetime.utcnow().isoformat()
    )
    
    execution_nodes[user.user_id] = node_info
    
    print(f"📍 Registered execution node for {user.user_id}: {req.local_url}")
    
    return {
        "success": True,
        "node_id": node_id,
        "message": "Execution node registered. Clients can now connect directly.",
        "expires_in_seconds": 300  # Needs heartbeat every 5 minutes
    }


@router.post("/heartbeat")
async def execution_node_heartbeat(request: Request, req: HeartbeatRequest):
    """
    Heartbeat endpoint for execution nodes.
    
    Call this every minute to keep your node registered.
    """
    try:
        from src.aurica_auth import get_current_user
        user = get_current_user(request)
    except:
        user = type('User', (), {"user_id": "unknown"})()
    
    if user.user_id in execution_nodes:
        execution_nodes[user.user_id].last_heartbeat = datetime.utcnow().isoformat()
        return {
            "success": True,
            "message": "Heartbeat received"
        }
    else:
        raise HTTPException(
            status_code=404,
            detail="Node not registered. Please register first."
        )


@router.get("/discover/{user_id}")
async def discover_execution_node(user_id: str):
    """
    Discover where a user's execution node is running.
    
    PUBLIC endpoint - clients use this to find the execution node URL.
    
    Returns the URL the browser should connect to directly.
    """
    if user_id not in execution_nodes:
        return {
            "found": False,
            "message": "Execution node not registered or offline"
        }
    
    node_info = execution_nodes[user_id]
    
    # Check if heartbeat is recent (within last 5 minutes)
    last_heartbeat = datetime.fromisoformat(node_info.last_heartbeat)
    if datetime.utcnow() - last_heartbeat > timedelta(minutes=5):
        del execution_nodes[user_id]
        return {
            "found": False,
            "message": "Execution node timed out"
        }
    
    return {
        "found": True,
        "node_id": node_info.node_id,
        "local_url": node_info.local_url,
        "public_url": node_info.public_url,
        "capabilities": node_info.capabilities,
        "connection_instructions": {
            "preferred": node_info.public_url or node_info.local_url,
            "fallback": node_info.local_url if node_info.public_url else None,
            "note": "Browser will connect directly to this URL"
        }
    }


@router.get("/list")
async def list_execution_nodes():
    """List all registered execution nodes (for debugging)"""
    
    # Clean up stale nodes
    now = datetime.utcnow()
    stale_users = []
    for user_id, node_info in execution_nodes.items():
        last_heartbeat = datetime.fromisoformat(node_info.last_heartbeat)
        if now - last_heartbeat > timedelta(minutes=5):
            stale_users.append(user_id)
    
    for user_id in stale_users:
        del execution_nodes[user_id]
    
    return {
        "total_nodes": len(execution_nodes),
        "nodes": [
            {
                "user_id": node.user_id,
                "node_id": node.node_id,
                "local_url": node.local_url,
                "last_seen": node.last_heartbeat
            }
            for node in execution_nodes.values()
        ]
    }


@router.get("/health")
async def direct_connection_health():
    """Health check for direct connection service"""
    return {
        "status": "healthy",
        "service": "direct-connection",
        "registered_nodes": len(execution_nodes),
        "timestamp": datetime.utcnow().isoformat()
    }

"""
Smart Cloud Digital Twin

This is a cloud-based DT that:
1. Responds directly to simple queries (no local execution needed)
2. For complex tasks, it provides connection info to user's local execution node
3. Acts as a bridge/router based on task complexity

This enables:
- Instant responses from anywhere (mobile, desktop)
- Local execution only when truly needed
- No polling required!
"""

from fastapi import APIRouter, HTTPException, Request, Depends
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime
import os
import openai

# Import auth decorator
try:
    from src.aurica_auth import protected, get_current_user, public
except ImportError:
    def protected(func):
        return func
    def get_current_user(request, required=True):
        return type('User', (), {"username": "unknown", "user_id": "unknown"})()
    def public(func):
        return func
router = APIRouter()

# OpenAI configuration
openai.api_key = os.getenv("OPENAI_API_KEY")
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4")


class ThinkRequest(BaseModel):
    """Request for DT to think/respond"""
    input: str
    context: Dict[str, Any]
    history: List[Dict[str, str]] = []


class SmartRoutingDecision(BaseModel):
    """Decision about where to execute"""
    execution_mode: str  # "cloud", "local", "hybrid"
    reason: str
    requires_local: bool
    local_capabilities_needed: List[str] = []


async def analyze_execution_needs(user_input: str, context: Dict) -> SmartRoutingDecision:
    """
    Analyze if task needs local execution or can run in cloud.
    
    Local execution needed for:
    - File system access
    - Running local apps/tools
    - Accessing local data
    - System commands
    
    Cloud execution sufficient for:
    - General conversation
    - Information queries
    - Advice/recommendations
    - Explanations
    """
    
    # Simple keyword detection (can be enhanced with LLM classification)
    local_keywords = [
        "file", "folder", "directory", "execute", "run", "install",
        "my computer", "my machine", "local", "system", "app",
        "weather", "profile", "dashboard"  # Your local apps
    ]
    
    user_input_lower = user_input.lower()
    needs_local = any(keyword in user_input_lower for keyword in local_keywords)
    
    if needs_local:
        return SmartRoutingDecision(
            execution_mode="local",
            reason="Task requires local execution node capabilities",
            requires_local=True,
            local_capabilities_needed=["execution_node", "local_apps"]
        )
    else:
        return SmartRoutingDecision(
            execution_mode="cloud",
            reason="Can be handled by cloud Digital Twin",
            requires_local=False
        )


@router.post("/cloud-think/")
@protected
async def cloud_think(request: Request, req: ThinkRequest):
    """
    Smart cloud-based thinking endpoint.
    
    This DT:
    - Responds directly when possible (fast!)
    - Routes to local when needed
    - Never polls - instant decisions
    """
    user = get_current_user(request)
    
    # Analyze execution needs
    routing = await analyze_execution_needs(req.input, req.context)
    
    if not routing.requires_local:
        # Handle in cloud - instant response!
        print(f"☁️ Handling in cloud for {user.username}")
        
        # Build conversation for LLM
        messages = [
            {
                "role": "system",
                "content": """You are a helpful Digital Twin assistant. You're running in the cloud,
so you can answer questions, provide information, and have conversations, but you cannot
access the user's local files or execute local commands.

If the user asks for something that requires local access, politely explain that they
need their local execution node running for that."""
            }
        ]
        
        # Add history
        for msg in req.history[-10:]:  # Last 10 messages
            messages.append({
                "role": "user" if msg.get("sender") == "user" else "assistant",
                "content": msg.get("content", "")
            })
        
        # Add current input
        messages.append({
            "role": "user",
            "content": req.input
        })
        
        try:
            # Call OpenAI
            response = openai.chat.completions.create(
                model=LLM_MODEL,
                messages=messages,
                temperature=0.7,
                max_tokens=1000
            )
            
            ai_response = response.choices[0].message.content
            
            return {
                "dt_active": True,
                "execution_mode": "cloud",
                "response": ai_response,
                "thought_process": "Handled directly in cloud - no local execution needed",
                "tools_used": [],
                "dt_confidence": 0.9,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            print(f"❌ OpenAI error: {e}")
            return {
                "dt_active": False,
                "error": "llm_error",
                "response": f"I encountered an error: {str(e)}",
                "thought_process": "Failed to get LLM response"
            }
    
    else:
        # Needs local execution
        print(f"🏠 Requires local execution for {user.username}")
        
        return {
            "dt_active": False,
            "execution_mode": "local_required",
            "response": """🏠 This task requires your local execution node.

Your Digital Twin can handle this, but it needs to run on your computer where it can access local apps and files.

**To enable local execution:**
1. Your backend is already running at `localhost:8000`
2. Your Digital Twin is loaded and ready
3. Just make sure you're accessing it from `localhost:8000/chat-app/` when you need local execution

**Why?**
When you chat from `api.oneaurica.com`, I'm running in the cloud and can't access your local machine.
When you chat from `localhost:8000`, I can access your local apps directly!

Would you like me to help with something else, or would you prefer to switch to your local chat?""",
            "thought_process": "Task needs local capabilities - user should use localhost interface",
            "requires_local": True,
            "local_capabilities_needed": routing.local_capabilities_needed,
            "suggestion": "Access chat from localhost:8000/chat-app/ for local execution"
        }

@router.get("/cloud-health/")
@public
async def cloud_health():
    """Health check for cloud DT"""
    return {
        "status": "healthy",
        "service": "cloud-digital-twin",
        "mode": "smart_routing",
        "capabilities": [
            "conversation",
            "information_queries",
            "recommendations",
            "routing_to_local"
        ],
        "timestamp": datetime.utcnow().isoformat()
    }

"""
Auto-registration service for execution nodes

When a user authenticates locally, automatically register this machine
as their execution node with the cloud discovery service.
"""

import asyncio
import httpx
import os
import socket
from datetime import datetime
from typing import Optional

CLOUD_URL = os.getenv("CLOUD_URL", "https://api.oneaurica.com")
LOCAL_PORT = os.getenv("PORT", "8000")


def get_local_ip():
    """Get local network IP address"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except:
        return "127.0.0.1"


async def register_execution_node(user_id: str, auth_token: str) -> bool:
    """
    Register this machine as user's execution node.
    Called automatically when user logs in.
    """
    try:
        local_ip = get_local_ip()
        local_url = f"http://{local_ip}:{LOCAL_PORT}"
        
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                f"{CLOUD_URL}/digital-twin/api/direct_connection/register",
                json={
                    "local_url": local_url,
                    "public_url": None,
                    "capabilities": {
                        "dt_available": True,
                        "local_apps": True,
                        "file_access": True,
                        "direct_connection": True
                    }
                },
                headers={"Authorization": f"Bearer {auth_token}"}
            )
            
            if response.status_code == 200:
                print(f"✅ Registered execution node: {local_url}")
                # Start background heartbeat
                asyncio.create_task(heartbeat_loop(user_id, auth_token))
                return True
            else:
                print(f"⚠️  Registration failed: {response.status_code}")
                return False
                
    except Exception as e:
        print(f"⚠️  Could not register with cloud: {e}")
        return False


async def heartbeat_loop(user_id: str, auth_token: str):
    """
    Background task to send periodic heartbeats.
    Keeps the node registered while server is running.
    """
    node_id = None
    
    while True:
        try:
            await asyncio.sleep(60)  # Every minute
            
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.post(
                    f"{CLOUD_URL}/digital-twin/api/direct_connection/heartbeat",
                    json={"node_id": node_id or ""},
                    headers={"Authorization": f"Bearer {auth_token}"}
                )
                
                if response.status_code == 200:
                    print(f"💓 Heartbeat sent ({datetime.now().strftime('%H:%M:%S')})")
                elif response.status_code == 404:
                    # Node expired, re-register
                    print("🔄 Re-registering...")
                    await register_execution_node(user_id, auth_token)
                    
        except asyncio.CancelledError:
            break
        except Exception as e:
            print(f"⚠️  Heartbeat error: {e}")


async def unregister_execution_node(user_id: str, auth_token: str):
    """
    Unregister execution node on logout or shutdown.
    Optional - nodes auto-expire after 5 minutes without heartbeat.
    """
    # Implementation if needed for explicit cleanup
    pass

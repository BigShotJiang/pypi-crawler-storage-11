# Author(s): Silvio Gregorini (silviogregorini@openforce.it)
# Copyright 2019 Openforce Srls Unipersonale (www.openforce.it)
# Copyright 2023 Simone Rubino - Aion Tech
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from odoo import api, fields, models
from odoo.exceptions import ValidationError
from odoo.fields import Command


class Asset(models.Model):
    _name = "asset.asset"
    _description = "Assets"
    _inherit = ["mail.thread", "mail.activity.mixin", "portal.mixin"]
    _order = "purchase_date desc, name asc"

    @api.model
    def get_default_company_id(self):
        return self.env.company

    asset_accounting_info_ids = fields.One2many(
        "asset.accounting.info", "l10n_it_asset_id", string="Accounting Info"
    )

    category_id = fields.Many2one(
        "asset.category",
        required=True,
        string="Category",
    )

    code = fields.Char(
        default="",
    )

    company_id = fields.Many2one(
        "res.company",
        default=get_default_company_id,
        required=True,
        string="Company",
        tracking=True,
    )

    currency_id = fields.Many2one(
        "res.currency",
        required=True,
        string="Currency",
    )

    customer_id = fields.Many2one("res.partner", string="Customer")

    depreciation_ids = fields.One2many(
        "asset.depreciation",
        "l10n_it_asset_id",
        string="Depreciations",
    )

    name = fields.Char(
        required=True,
        tracking=True,
    )

    purchase_amount = fields.Monetary(
        string="Purchase Value",
        tracking=True,
    )

    purchase_date = fields.Date(
        default=fields.Date.today(),
        tracking=True,
    )

    purchase_move_id = fields.Many2one("account.move", string="Purchase Move")

    sale_amount = fields.Monetary(
        string="Sale Value",
    )

    sale_date = fields.Date()

    dismiss_date = fields.Date()

    sale_move_id = fields.Many2one("account.move", string="Sale Move")

    sold = fields.Boolean()
    dismissed = fields.Boolean()

    state = fields.Selection(
        [
            ("non_depreciated", "Non Depreciated"),
            ("partially_depreciated", "Partially Depreciated"),
            ("totally_depreciated", "Depreciated"),
        ],
        compute="_compute_state",
        default="non_depreciated",
        store=True,
    )

    supplier_id = fields.Many2one("res.partner", string="Supplier")

    supplier_ref = fields.Char(string="Supplier Ref.")

    used = fields.Boolean()

    @api.model_create_multi
    def create(self, vals_list):
        # Add depreciation if it's missing while category is set
        assets = self.browse()
        for vals in vals_list:
            create_deps_from_categ = False
            if vals.get("category_id") and not vals.get("depreciation_ids"):
                create_deps_from_categ = True
            if vals.get("code"):
                vals["code"] = " ".join(vals.get("code").split())
            asset = super().create(vals)
            if create_deps_from_categ:
                asset.onchange_category_id()
            assets |= asset
        return assets

    def write(self, vals):
        if vals.get("code"):
            vals["code"] = " ".join(vals.get("code").split())
        return super().write(vals)

    def unlink(self):
        self.mapped("asset_accounting_info_ids").unlink()
        self.mapped("depreciation_ids").unlink()
        return super().unlink()

    def name_get(self):
        return [(asset.id, asset.make_name()) for asset in self]

    @api.constrains("company_id")
    def check_company(self):
        for asset in self:
            comp = asset.get_linked_aa_info_records().mapped("company_id")
            if len(comp) > 1 or (comp and comp != asset.company_id):
                raise ValidationError(
                    self.env._(
                        "`%(asset)s`: cannot change asset's company once it's already"
                        " related to accounting info.",
                        asset=asset.make_name(),
                    )
                )

    @api.depends("depreciation_ids", "depreciation_ids.state")
    def _compute_state(self):
        for asset in self:
            asset.state = asset.get_asset_state()

    @api.onchange("category_id")
    def onchange_category_id(self):
        # Do not allow category changes if any depreciation line is already
        # linked to an account move
        if any(self.depreciation_ids.mapped("line_ids.move_id")):
            raise ValidationError(
                self.env._(
                    "Cannot change category for an asset that's already been"
                    " depreciated."
                )
            )

        if self.category_id:
            # Remove depreciation lines
            self.depreciation_ids = False

            # Set new lines
            vals = self.category_id.get_depreciation_vals(self.purchase_amount)
            self.depreciation_ids = [Command.create(v) for v in vals]
            self.onchange_purchase_amount()
            self.onchange_purchase_date()

    @api.onchange("company_id")
    def onchange_company_currency(self):
        if self.company_id:
            self.currency_id = self.company_id.currency_id

    @api.onchange("purchase_amount")
    def onchange_purchase_amount(self):
        if self.purchase_amount:
            for dep in self.depreciation_ids:
                dep.amount_depreciable = dep._get_depreciable_amount(
                    self.purchase_amount
                )
            if self.depreciation_ids.mapped("line_ids").filtered(
                lambda line: line.move_type == "depreciated"
            ):
                title = self.env._("Warning!")
                msg = self.env._(
                    "Current asset has already been depreciated. Changes upon"
                    " its purchase value will not be automatically reflected"
                    " upon depreciation lines, which will have to be updated"
                    " manually."
                )
                return {"warning": {"title": title, "message": msg}}

    @api.onchange("purchase_date")
    def onchange_purchase_date(self):
        if self.purchase_date:
            for dep in self.depreciation_ids:
                dep.date_start = self.purchase_date

    def launch_wizard_generate_depreciations(self):
        self.ensure_one()
        xmlid = "l10n_it_asset_management.action_wizard_asset_generate_depreciation"
        [act] = self.env.ref(xmlid).read()
        ctx = dict(self._context)
        ctx.update(
            {
                "default_l10n_it_asset_ids": [Command.set(self.ids)],
                "default_category_ids": [Command.set(self.category_id.ids)],
                "default_company_id": self.company_id.id,
                "default_date": fields.Date.today(),
                "default_type_ids": [
                    Command.set(self.depreciation_ids.mapped("type_id").ids)
                ],
            }
        )
        act["context"] = ctx
        return act

    def get_asset_state(self):
        self.ensure_one()
        if not self.depreciation_ids:
            return "non_depreciated"

        states = tuple(set(self.depreciation_ids.mapped("state")))

        if not states:
            return "non_depreciated"
        elif len(states) == 1:
            return states[0]
        else:
            return "partially_depreciated"

    def get_linked_aa_info_records(self):
        self.ensure_one()
        return self.env["asset.accounting.info"].search(
            [
                "|",
                ("l10n_it_asset_id", "=", self.id),
                ("dep_line_id.l10n_it_asset_id", "=", self.id),
            ]
        )

    def make_name(self):
        self.ensure_one()
        name = self.name.strip()
        if self.code:
            return f"[{self.code.strip()}] {name}"
        return name

__version__ = "0.1.2"

from .client import RpsGame
from .exceptions import RpsGameError

__all__ = ["RpsGame", "RpsGameError"]

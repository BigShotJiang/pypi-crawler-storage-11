"""
Utility functions for pyautoprocess
"""
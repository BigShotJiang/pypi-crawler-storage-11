<h1 style="text-align: center; font-size: 200px; font-weight: 500;">
    <i>Pyloid</i>
</h1>

![example image](example.png)

<h2 align="center" style="font-size: 28px;"><b>Pyloid: Electron for Python Developer • Modern Web-based desktop app framework</b></h2>

## 💡 Key Features

- **All Frontend Frameworks** are supported
- **All Backend Frameworks** are supported
- **All features necessary** for a desktop application are implemented
- **Cross-Platform Support** (Windows, macOS, Linux)
- **Many Built-in Tools** (Builder, Server, Tray, Store, Timer, Monitor, Optimizer, etc.)

## Getting Started

```bash
npm create pyloid-app@latest
```

go to [Pyloid](https://pyloid.com/) for more information.

## Discord 🎉

[Our Discord!](https://discord.gg/VTqexxxTy9)

## Documentation 📚

[Pyloid Documentation](https://pyloid.com/)

## Repositories

- [pyloid](https://github.com/pyloid/pyloid)
- [pyloid-builder](https://github.com/pyloid/pyloid-builder)
- [pyloid-adapter](https://github.com/pyloid/pyloid-adapter)
- [pyloid-js](https://github.com/pyloid/pyloid-js)
- [create-pyloid-app](https://github.com/pyloid/create-pyloid-app)
- [website](https://github.com/pyloid/website)

## License

This project is licensed under the terms of the Apache License 2.0. See the [LICENSE](./LICENSE) file for details.

This project uses PySide6, which is licensed under the LGPL (Lesser General Public License).

## Contributing 🤝

⚙

## Issues

If you encounter any issues or have suggestions for improvements, please open an issue on the [GitHub repository](https://github.com/Pyloid/pyloid/issues).

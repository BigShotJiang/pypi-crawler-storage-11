::: sgnts.base.audioadapter

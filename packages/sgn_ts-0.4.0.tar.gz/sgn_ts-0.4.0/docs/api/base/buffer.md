::: sgnts.base.buffer

::: sgnts.transforms.sumindex

::: sgnts.transforms.gate

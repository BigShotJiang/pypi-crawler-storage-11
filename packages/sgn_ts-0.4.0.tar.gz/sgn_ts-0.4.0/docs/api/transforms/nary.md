::: sgnts.transforms.nary

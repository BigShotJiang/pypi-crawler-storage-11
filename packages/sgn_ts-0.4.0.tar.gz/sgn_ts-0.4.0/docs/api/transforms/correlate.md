::: sgnts.transforms.correlate

::: sgnts.transforms.adder

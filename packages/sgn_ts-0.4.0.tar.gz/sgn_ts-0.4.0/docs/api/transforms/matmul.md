::: sgnts.transforms.matmul

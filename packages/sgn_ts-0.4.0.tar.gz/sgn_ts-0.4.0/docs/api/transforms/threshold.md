::: sgnts.transforms.threshold

# Venv Cleaner

A simple GUI tool for cleaning up old or unused Python virtual environments (`venv` directories).

## How to Use

The easiest way to run Venv Cleaner is using [uvx](https://docs.astral.sh/uv/guides/tools/):

```bash
uvx venvcleaner
```

You can also specify a target directory:

```bash
uvx venvcleaner /path/to/target-directory
```

If you are using Linux, you will need to build wxPython via pip. Please see [Building wxPython for Linux via Pip](https://wxpython.org/blog/2017-08-17-builds-for-linux-with-pip/) and [wxWidgets for GTK installation](https://docs.wxwidgets.org/3.2/plat_gtk_install.html).

Alternatively, on [some Linux systems](https://wxpython.org/pages/downloads/index.html), you can use the `-f` (`--find-links`) option to specify [the download URL of wxPython package](https://extras.wxpython.org/wxPython4/extras/linux/):

```bash
# for Ubuntu 24.04
uvx -f https://extras.wxpython.org/wxPython4/extras/linux/gtk3/ubuntu-24.04 venvcleaner
```

If you want to install to the persistent environment:

```bash
uv tool install venvcleaner@latest

# for Ubuntu 24.04
uv tool install -f https://extras.wxpython.org/wxPython4/extras/linux/gtk3/ubuntu-24.04 venvcleaner@latest

# run Venv Cleaner
venvcleaner
```

![screenshot](https://raw.githubusercontent.com/yamakox/VenvCleaner/main/screenshot.png)

## Features

- Scans the target directory for virtual environments (`.venv` directories containing a `pyvenv.cfg` file).
- You can change or refresh the target directory with the __Select...__ or __Refresh__ buttons.
- Choose which venvs to clean using the selection list.
  - __Select All__ selects all detected venvs.
  - __Select None__ clears the selection.
- __Copy Paths__ copies the paths of selected venvs to your clipboard.
You can paste them into a terminal to run shell commands manually. For example:

```bash
ls /path/to/project-1/.venv "/path/to/project 2/.venv"
rm -r /path/to/project-1/.venv "/path/to/project 2/.venv"
```

- __Cleanup Venvs__ deletes the selected venv directories.
Before using this button, you must check the agreement box:

> I agree to take responsibility for my actions.

## License

This software is distributed under the terms of the [MIT License](https://raw.githubusercontent.com/yamakox/VenvCleaner/main/LICENSE).

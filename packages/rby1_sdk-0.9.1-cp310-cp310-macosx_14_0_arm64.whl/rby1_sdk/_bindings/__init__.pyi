"""

RBY1-SDK Python bindings.

This module provides high-level APIs for RB-Y1 communication, control, modeling, etc.
It includes mathematical operations, dynamics calculations, robot control,
and various utility functions for working with RB-Y1 robots.

Submodules
----------
math : Mathematical operations and Lie group utilities
dynamics : Robot dynamics calculations
upc : Utilities for controlling and communicating with devices on the user PC
"""
from __future__ import annotations
import datetime
import numpy
import pybind11_stubgen.typing_ext
import typing
from . import dynamics
from . import math
from . import upc
__all__: list[str] = ['ArmCommandBuilder', 'ArmCommandFeedback', 'BatteryInfo', 'BatteryState', 'BodyCommandBuilder', 'BodyCommandFeedback', 'BodyComponentBasedCommandBuilder', 'BodyComponentBasedCommandFeedback', 'CartesianCommandBuilder', 'CartesianCommandFeedback', 'CartesianImpedanceControlCommandBuilder', 'CartesianImpedanceControlCommandFeedback', 'Color', 'CommandFeedback', 'CommandHeaderBuilder', 'CommandHeaderFeedback', 'ComponentBasedCommandBuilder', 'ComponentBasedCommandFeedback', 'ControlManagerState', 'DynamixelBus', 'EMOInfo', 'EMOState', 'FTSensorData', 'Feedback', 'GravityCompensationCommandBuilder', 'GravityCompensationCommandFeedback', 'HeadCommandBuilder', 'HeadCommandFeedback', 'ImpedanceControlCommandBuilder', 'ImpedanceControlCommandFeedback', 'JogCommandBuilder', 'JogCommandFeedback', 'JointGroupPositionCommandBuilder', 'JointGroupPositionCommandFeedback', 'JointImpedanceControlCommandBuilder', 'JointImpedanceControlCommandFeedback', 'JointInfo', 'JointPositionCommandBuilder', 'JointPositionCommandFeedback', 'JointState', 'JointVelocityCommandBuilder', 'JointVelocityCommandFeedback', 'Log', 'MobilityCommandBuilder', 'MobilityCommandFeedback', 'Model_A', 'Model_M', 'Model_UB', 'OptimalControlCommandBuilder', 'OptimalControlCommandFeedback', 'PIDGain', 'PowerInfo', 'PowerState', 'RobotCommandBuilder', 'RobotCommandFeedback', 'RobotInfo', 'RobotState_A', 'RobotState_M', 'RobotState_UB', 'Robot_A', 'Robot_A_CommandHandler', 'Robot_A_CommandStreamHandler', 'Robot_A_ControlInput', 'Robot_A_ControlState', 'Robot_M', 'Robot_M_CommandHandler', 'Robot_M_CommandStreamHandler', 'Robot_M_ControlInput', 'Robot_M_ControlState', 'Robot_UB', 'Robot_UB_CommandHandler', 'Robot_UB_CommandStreamHandler', 'Robot_UB_ControlInput', 'Robot_UB_ControlState', 'SE2VelocityCommandBuilder', 'SE2VelocityCommandFeedback', 'SerialDevice', 'SerialStream', 'StopCommandBuilder', 'StopCommandFeedback', 'SystemStat', 'ToolFlangeState', 'TorsoCommandBuilder', 'TorsoCommandFeedback', 'WholeBodyCommandBuilder', 'WholeBodyCommandFeedback', 'WifiNetwork', 'WifiStatus', 'create_robot_a', 'create_robot_m', 'create_robot_ub', 'dynamics', 'math', 'printoptions', 'set_printoptions', 'upc']
class ArmCommandBuilder:
    """
    
    Arm command builder.
    
    Wraps a command for an arm component.  
    This builder accepts multiple command types, such as joint position,
    gravity compensation, Cartesian impedance, or joint impedance commands,
    and provides a unified interface to send them to an arm.
    
    Notes
    -----
    - In practice, you often do **not** need to explicitly construct an
      ArmCommandBuilder.  
      Functions like ``set_right_arm_command(...)`` or ``set_left_arm_command(...)``
      automatically cast and wrap a command (e.g., JointPositionCommandBuilder)
      into an ArmCommandBuilder.  
      For example:
    
      >>> body.set_right_arm_command(rby.JointPositionCommandBuilder().set_position(...))
    
      is equivalent to:
    
      >>> body.set_right_arm_command(rby.ArmCommandBuilder(
      ...     rby.JointPositionCommandBuilder().set_position(...)))
    
    - Therefore, explicitly constructing ArmCommandBuilder is usually unnecessary
      unless you want to be explicit; repeatedly wrapping it is inefficient.
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> # Send a joint position command to the right arm
    >>> jp = (
    ...     rby.JointPositionCommandBuilder()
    ...     .set_position(np.zeros(7))
    ...     .set_minimum_time(2.0)
    ... )
    >>> body = rby.BodyComponentBasedCommandBuilder()
    >>> # Implicit wrapping into ArmCommandBuilder
    >>> body.set_right_arm_command(jp)
    >>> cmd = rby.RobotCommandBuilder().set_command(body)
    >>> # robot.send_command(cmd, priority=1).get()
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Construct an empty ArmCommandBuilder instance.
        """
    @typing.overload
    def __init__(self, joint_position_command_builder: JointPositionCommandBuilder) -> None:
        """
        Construct an ArmCommandBuilder with a joint position command.
        
        Parameters
        ----------
        joint_position_command_builder : JointPositionCommandBuilder
            Joint position command to wrap.
        """
    @typing.overload
    def __init__(self, gravity_compensation_command_builder: GravityCompensationCommandBuilder) -> None:
        """
        Construct an ArmCommandBuilder with a gravity compensation command.
        
        Parameters
        ----------
        gravity_compensation_command_builder : GravityCompensationCommandBuilder
            Gravity compensation command to wrap.
        """
    @typing.overload
    def __init__(self, cartesian_command_builder: CartesianCommandBuilder) -> None:
        """
        Construct an ArmCommandBuilder with a Cartesian command.
        
        Parameters
        ----------
        cartesian_command_builder : CartesianCommandBuilder
            Cartesian command to wrap.
        """
    @typing.overload
    def __init__(self, impedance_control_command_builder: ImpedanceControlCommandBuilder) -> None:
        """
        Construct an ArmCommandBuilder with an impedance control command.
        
        Parameters
        ----------
        impedance_control_command_builder : ImpedanceControlCommandBuilder
            Cartesian impedance command to wrap.
        """
    @typing.overload
    def __init__(self, joint_impedance_control_command_builder: JointImpedanceControlCommandBuilder) -> None:
        """
        Construct an ArmCommandBuilder with a joint impedance control command.
        
        Parameters
        ----------
        joint_impedance_control_command_builder : JointImpedanceControlCommandBuilder
            Joint impedance control command to wrap.
        """
    @typing.overload
    def __init__(self, cartesian_impedance_control_command_builder: CartesianImpedanceControlCommandBuilder) -> None:
        """
        Construct an ArmCommandBuilder with a Cartesian impedance control command.
        
        Parameters
        ----------
        cartesian_impedance_control_command_builder : CartesianImpedanceControlCommandBuilder
            Cartesian impedance control command to wrap.
        """
    @typing.overload
    def set_command(self, joint_position_command_builder: JointPositionCommandBuilder) -> ArmCommandBuilder:
        """
        Set a joint position command for the arm.
        
        Parameters
        ----------
        joint_position_command_builder : JointPositionCommandBuilder
            Joint position command to wrap.
        
        Returns
        -------
        ArmCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, gravity_compensation_command_builder: GravityCompensationCommandBuilder) -> ArmCommandBuilder:
        """
        Set a gravity compensation command for the arm.
        
        Parameters
        ----------
        gravity_compensation_command_builder : GravityCompensationCommandBuilder
            Gravity compensation command to wrap.
        
        Returns
        -------
        ArmCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, cartesian_command_builder: CartesianCommandBuilder) -> ArmCommandBuilder:
        """
        Set a Cartesian command for the arm.
        
        Parameters
        ----------
        cartesian_command_builder : CartesianCommandBuilder
            Cartesian command to wrap.
        
        Returns
        -------
        ArmCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, impedance_control_command_builder: ImpedanceControlCommandBuilder) -> ArmCommandBuilder:
        """
        Set an impedance control command for the arm.
        
        Parameters
        ----------
        impedance_control_command_builder : ImpedanceControlCommandBuilder
            Cartesian impedance control command to wrap.
        
        Returns
        -------
        ArmCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, joint_impedance_control_command_builder: JointImpedanceControlCommandBuilder) -> ArmCommandBuilder:
        """
        Set a joint impedance control command for the arm.
        
        Parameters
        ----------
        joint_impedance_control_command_builder : JointImpedanceControlCommandBuilder
            Joint impedance control command to wrap.
        
        Returns
        -------
        ArmCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, cartesian_impedance_control_command_builder: CartesianImpedanceControlCommandBuilder) -> ArmCommandBuilder:
        """
        Set a Cartesian impedance control command for the arm.
        
        Parameters
        ----------
        cartesian_impedance_control_command_builder : CartesianImpedanceControlCommandBuilder
            Cartesian impedance control command to wrap.
        
        Returns
        -------
        ArmCommandBuilder
            Self reference for method chaining.
        """
class ArmCommandFeedback(CommandFeedback):
    """
    
    Feedback for an arm command container.
    
    Attributes
    ----------
    joint_position_command : JointPositionCommandFeedback
        Feedback for a joint position command (if present).
    gravity_compensation_command : GravityCompensationCommandFeedback
        Feedback for a gravity compensation command (if present).
    cartesian_command : CartesianCommandFeedback
        Feedback for a Cartesian command (if present).
    impedance_control_command : ImpedanceControlCommandFeedback
        Feedback for a Cartesian impedance command (if present).
    cartesian_impedance_control_command : CartesianImpedanceControlCommandFeedback
        Feedback for a Cartesian impedance (OC + joint-space impedance) command (if present).
    joint_impedance_control_command : JointImpedanceControlCommandFeedback
        Feedback for a joint-space impedance command (if present).
    """
    def __init__(self) -> None:
        """
              Construct an ``ArmCommandFeedback`` instance.
        """
    @property
    def cartesian_command(self) -> CartesianCommandFeedback:
        """
        Cartesian command feedback.
        
        Returns
        -------
        CartesianCommandFeedback
            Feedback object.
        """
    @property
    def cartesian_impedance_control_command(self) -> CartesianImpedanceControlCommandFeedback:
        """
        Cartesian impedance (OC + joint-space impedance) command feedback.
        
        Returns
        -------
        CartesianImpedanceControlCommandFeedback
            Feedback object.
        """
    @property
    def gravity_compensation_command(self) -> GravityCompensationCommandFeedback:
        """
        Gravity compensation command feedback.
        
        Returns
        -------
        GravityCompensationCommandFeedback
            Feedback object.
        """
    @property
    def impedance_control_command(self) -> ImpedanceControlCommandFeedback:
        """
        Cartesian impedance command feedback.
        
        Returns
        -------
        ImpedanceControlCommandFeedback
            Feedback object.
        """
    @property
    def joint_impedance_control_command(self) -> JointImpedanceControlCommandFeedback:
        """
        Joint-space impedance command feedback.
        
        Returns
        -------
        JointImpedanceControlCommandFeedback
            Feedback object.
        """
    @property
    def joint_position_command(self) -> JointPositionCommandFeedback:
        """
        Joint position command feedback.
        
        Returns
        -------
        JointPositionCommandFeedback
            Feedback object.
        """
class BatteryInfo:
    """
    
    Battery information.
    
    This class represents battery information for the robot.
    **Currently contains no specific attributes.**
    """
    def __init__(self) -> None:
        """
        Construct an ``BatteryInfo`` instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
class BatteryState:
    """
    
    Battery state information.
    
    Provides information about battery status including voltage, current, and charge level.
    
    Attributes
    ----------
    voltage : float
        Battery voltage in V.
    current : float
        Battery current [A].
    level_percent : float
        Battery charge level percentage (0.0 to 100.0).
      
    """
    def __init__(self) -> None:
        """
              Construct a ``BatteryState`` instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def current(self) -> float:
        ...
    @property
    def level_percent(self) -> float:
        ...
    @property
    def voltage(self) -> float:
        ...
class BodyCommandBuilder:
    """
    
    Body command builder.
    
    Wraps commands for the robot’s body subsystem (torso + both arms).  
    It can hold a variety of command types including joint position,
    optimal control, gravity compensation, Cartesian motion, and impedance control.
    
    Notes
    -----
    - Typically used with ``set_body_command(...)`` of a ComponentBasedCommandBuilder.
    - You do not need to explicitly wrap commands in BodyCommandBuilder;
      passing a supported builder (e.g., JointPositionCommandBuilder) into
      ``set_body_command`` will automatically cast it to BodyCommandBuilder.
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> # Example 1: Joint position body command
    >>> jp = rby.JointPositionCommandBuilder().set_position(np.zeros(20))  # full body, N=20
    >>> body = rby.BodyCommandBuilder().set_command(jp)
    >>> comp = rby.ComponentBasedCommandBuilder().set_body_command(body)
    >>> rc = rby.RobotCommandBuilder().set_command(comp)
    >>> # robot.send_command(rc, priority=1).get()
    >>>
    >>> # Example 2: Gravity compensation
    >>> gc = rby.GravityCompensationCommandBuilder().set_on(True)
    >>> comp = rby.ComponentBasedCommandBuilder().set_body_command(gc)  # implicit wrap
    >>> rc = rby.RobotCommandBuilder().set_command(comp)
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Construct a BodyCommandBuilder instance.
        """
    @typing.overload
    def __init__(self, joint_position_command_builder: JointPositionCommandBuilder) -> None:
        """
        Construct from a joint position command.
        """
    @typing.overload
    def __init__(self, optimal_control_command_builder: OptimalControlCommandBuilder) -> None:
        """
        Construct from an optimal control command.
        """
    @typing.overload
    def __init__(self, gravity_compensation_command_builder: GravityCompensationCommandBuilder) -> None:
        """
        Construct from a gravity compensation command.
        """
    @typing.overload
    def __init__(self, cartesian_command_builder: CartesianCommandBuilder) -> None:
        """
        Construct from a Cartesian command.
        """
    @typing.overload
    def __init__(self, body_component_based_command_builder: BodyComponentBasedCommandBuilder) -> None:
        """
        Construct from a body component–based command (right/left arms, torso).
        """
    @typing.overload
    def __init__(self, joint_impedance_control_command_builder: JointImpedanceControlCommandBuilder) -> None:
        """
        Construct from a joint impedance control command.
        """
    @typing.overload
    def __init__(self, cartesian_impedance_control_command_builder: CartesianImpedanceControlCommandBuilder) -> None:
        """
        Construct from a Cartesian impedance control command.
        """
    @typing.overload
    def set_command(self, joint_position_command_builder: JointPositionCommandBuilder) -> BodyCommandBuilder:
        """
        Assign a joint position command.
        
        Parameters
        ----------
        joint_position_command_builder : JointPositionCommandBuilder
            Joint-space position command (vector length N = body DOF).
        
        Returns
        -------
        BodyCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, optimal_control_command_builder: OptimalControlCommandBuilder) -> BodyCommandBuilder:
        """
        Assign an optimal control command.
        
        Parameters
        ----------
        optimal_control_command_builder : OptimalControlCommandBuilder
            Optimal control objective.
        
        Returns
        -------
        BodyCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, gravity_compensation_command_builder: GravityCompensationCommandBuilder) -> BodyCommandBuilder:
        """
        Assign a gravity compensation command.
        
        Parameters
        ----------
        gravity_compensation_command_builder : GravityCompensationCommandBuilder
            Command enabling or disabling gravity compensation.
        
        Returns
        -------
        BodyCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, cartesian_command_builder: CartesianCommandBuilder) -> BodyCommandBuilder:
        """
        Assign a Cartesian command.
        
        Parameters
        ----------
        cartesian_command_builder : CartesianCommandBuilder
            Cartesian trajectory command.
        
        Returns
        -------
        BodyCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, body_component_based_command_builder: BodyComponentBasedCommandBuilder) -> BodyCommandBuilder:
        """
        Assign a body component–based command (arms, torso).
        
        Parameters
        ----------
        body_component_based_command_builder : BodyComponentBasedCommandBuilder
            Command composed of right arm, left arm, and torso subcommands.
        
        Returns
        -------
        BodyCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, joint_impedance_control_command_builder: JointImpedanceControlCommandBuilder) -> BodyCommandBuilder:
        """
        Assign a joint impedance control command.
        
        Parameters
        ----------
        joint_impedance_control_command_builder : JointImpedanceControlCommandBuilder
            Joint-space impedance control command.
        
        Returns
        -------
        BodyCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, cartesian_impedance_control_command_builder: CartesianImpedanceControlCommandBuilder) -> BodyCommandBuilder:
        """
        Assign a Cartesian impedance control command.
        
        Parameters
        ----------
        cartesian_impedance_control_command_builder : CartesianImpedanceControlCommandBuilder
            Cartesian impedance control command.
        
        Returns
        -------
        BodyCommandBuilder
            Self reference for method chaining.
        """
class BodyCommandFeedback(CommandFeedback):
    """
    
    Feedback for a body command container.
    
    Attributes
    ----------
    joint_position_command : JointPositionCommandFeedback
        Feedback for a joint position command (if present).
    optimal_control_command : OptimalControlCommandFeedback
        Feedback for an optimal-control command (if present).
    gravity_compensation_command : GravityCompensationCommandFeedback
        Feedback for a gravity compensation command (if present).
    cartesian_command : CartesianCommandFeedback
        Feedback for a Cartesian command (if present).
    body_component_based_command : BodyComponentBasedCommandFeedback
        Feedback for a component-based body command (if present).
    cartesian_impedance_control_command : CartesianImpedanceControlCommandFeedback
        Feedback for a Cartesian impedance (OC + joint-space impedance) command (if present).
    joint_impedance_control_command : JointImpedanceControlCommandFeedback
        Feedback for a joint-space impedance command (if present).
    """
    def __init__(self) -> None:
        """
              Construct a ``BodyCommandFeedback`` instance.
        """
    @property
    def body_component_based_command(self) -> BodyComponentBasedCommandFeedback:
        """
        Component-based body command feedback.
        
        Returns
        -------
        BodyComponentBasedCommandFeedback
            Feedback object.
        """
    @property
    def cartesian_command(self) -> CartesianCommandFeedback:
        """
        Cartesian command feedback.
        
        Returns
        -------
        CartesianCommandFeedback
            Feedback object.
        """
    @property
    def cartesian_impedance_control_command(self) -> CartesianImpedanceControlCommandFeedback:
        """
        Cartesian impedance (OC + joint-space impedance) command feedback.
        
        Returns
        -------
        CartesianImpedanceControlCommandFeedback
            Feedback object.
        """
    @property
    def gravity_compensation_command(self) -> GravityCompensationCommandFeedback:
        """
        Gravity compensation command feedback.
        
        Returns
        -------
        GravityCompensationCommandFeedback
            Feedback object.
        """
    @property
    def joint_impedance_control_command(self) -> JointImpedanceControlCommandFeedback:
        """
        Joint-space impedance command feedback.
        
        Returns
        -------
        JointImpedanceControlCommandFeedback
            Feedback object.
        """
    @property
    def joint_position_command(self) -> JointPositionCommandFeedback:
        """
        Joint position command feedback.
        
        Returns
        -------
        JointPositionCommandFeedback
            Feedback object.
        """
    @property
    def optimal_control_command(self) -> OptimalControlCommandFeedback:
        """
        Optimal-control command feedback.
        
        Returns
        -------
        OptimalControlCommandFeedback
            Feedback object.
        """
class BodyComponentBasedCommandBuilder:
    """
    
    Body component-based command builder.
    
    Provides methods to assign commands to specific body parts: right arm,
    left arm, and torso.  
    Each setter accepts either the corresponding *CommandBuilder wrapper*
    (e.g., ArmCommandBuilder, TorsoCommandBuilder) **or** a lower-level builder
    like JointPositionCommandBuilder, which will be automatically cast.
    
    Notes
    -----
    - For convenience, you can directly pass a JointPositionCommandBuilder
      (or other valid builders) without explicitly wrapping it in an
      ArmCommandBuilder or TorsoCommandBuilder. The system will automatically
      perform the conversion.
    - This avoids redundant wrapping and makes usage more concise.
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> body = rby.BodyComponentBasedCommandBuilder()
    >>> # Implicitly wraps into ArmCommandBuilder
    >>> body.set_right_arm_command(
    ...     rby.JointPositionCommandBuilder().set_position(np.zeros(7))
    ... )
    >>> # Implicitly wraps into TorsoCommandBuilder
    >>> body.set_torso_command(
    ...     rby.JointPositionCommandBuilder().set_position(np.zeros(6))
    ... )
    >>> cmd = rby.RobotCommandBuilder().set_command(body)
    >>> # robot.send_command(cmd, priority=1).get()
    """
    def __init__(self) -> None:
        """
        Construct a BodyComponentBasedCommandBuilder instance.
        """
    def set_left_arm_command(self, arm_command_builder: ArmCommandBuilder) -> BodyComponentBasedCommandBuilder:
        """
        Assign a command to the left arm.
        
        Parameters
        ----------
        arm_command_builder : ArmCommandBuilder or compatible builder
            Command for the left arm. If a lower-level builder is provided
            (e.g., JointPositionCommandBuilder), it will be automatically
            wrapped into an ArmCommandBuilder.
        
        Returns
        -------
        BodyComponentBasedCommandBuilder
            Self reference for method chaining.
        """
    def set_right_arm_command(self, arm_command_builder: ArmCommandBuilder) -> BodyComponentBasedCommandBuilder:
        """
        Assign a command to the right arm.
        
        Parameters
        ----------
        arm_command_builder : ArmCommandBuilder or compatible builder
            Command for the right arm. If a lower-level builder is provided
            (e.g., JointPositionCommandBuilder), it will be automatically
            wrapped into an ArmCommandBuilder.
        
        Returns
        -------
        BodyComponentBasedCommandBuilder
            Self reference for method chaining.
        """
    def set_torso_command(self, torso_command_builder: TorsoCommandBuilder) -> BodyComponentBasedCommandBuilder:
        """
        Assign a command to the torso.
        
        Parameters
        ----------
        torso_command_builder : TorsoCommandBuilder or compatible builder
            Command for the torso. If a lower-level builder is provided
            (e.g., JointPositionCommandBuilder, OptimalControlCommandBuilder),
            it will be automatically wrapped into a TorsoCommandBuilder.
        
        Returns
        -------
        BodyComponentBasedCommandBuilder
            Self reference for method chaining.
        """
class BodyComponentBasedCommandFeedback(CommandFeedback):
    """
    
    Feedback for a body command composed of named components.
    
    Attributes
    ----------
    right_arm_command : ArmCommandFeedback
        Feedback for the right arm component.
    left_arm_command : ArmCommandFeedback
        Feedback for the left arm component.
    torso_command : TorsoCommandFeedback
        Feedback for the torso component.
    """
    def __init__(self) -> None:
        """
              Construct a ``BodyComponentBasedCommandFeedback`` instance.
        """
    @property
    def left_arm_command(self) -> ArmCommandFeedback:
        """
        Left-arm component feedback.
        
        Returns
        -------
        ArmCommandFeedback
            Feedback object.
        """
    @property
    def right_arm_command(self) -> ArmCommandFeedback:
        """
        Right-arm component feedback.
        
        Returns
        -------
        ArmCommandFeedback
            Feedback object.
        """
    @property
    def torso_command(self) -> TorsoCommandFeedback:
        """
        Torso component feedback.
        
        Returns
        -------
        TorsoCommandFeedback
            Feedback object.
        """
class CartesianCommandBuilder:
    """
    
    Cartesian command builder.
    
    Builds end-effector Cartesian pose targets and optional per-joint auxiliary
    targets. Each Cartesian target specifies a desired homogeneous transform
    :math:`{}^{ref}\\!T^{link}_d \\in SE(3)` together with velocity/acceleration
    constraints used to time the motion.
    
    Notes
    -----
    - Cartesian error is computed in the reference frame and tracked subject to
      velocity/acceleration limits provided per target.
    - Joint targets added via ``add_joint_position_target`` are auxiliary hints
      that can help disambiguate IK or bias the posture during Cartesian tracking.
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> T = np.eye(4); T[0,3] = 0.40; T[2,3] = 0.60           # 40 cm forward, 60 cm up
    >>> cart = (
    ...   rby.CartesianCommandBuilder()
    ...   .add_target("base", "link_torso_5", T,
    ...               linear_velocity_limit=0.4,     # [m/s]
    ...               angular_velocity_limit=1.0,    # [rad/s]
    ...               acceleration_limit_scaling=0.6)
    ...   .add_joint_position_target("right_arm_3", 0.3, velocity_limit=1.2)
    ...   .set_minimum_time(2.0)
    ... )
    """
    def __init__(self) -> None:
        """
        Construct a CartesianCommandBuilder instance.
        """
    def add_joint_position_target(self, joint_name: str, target_position: float, velocity_limit: float | None = None, acceleration_limit: float | None = None) -> CartesianCommandBuilder:
        """
        Add an auxiliary joint position target.
        
        Parameters
        ----------
        joint_name : str
            Joint name to bias.
        target_position : float
            Desired joint position [rad].
        velocity_limit : Optional[float], default=None
            Per-joint velocity limit [rad/s] for this target (if provided).
        acceleration_limit : Optional[float], default=None
            Per-joint acceleration limit [rad/s²] for this target (if provided).
        
        Returns
        -------
        CartesianCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - Useful to resolve redundancy or bias posture while tracking Cartesian goals.
        - If limits are omitted, internal defaults/URDF-derived limits are used.
        """
    def add_target(self, ref_link_name: str, link_name: str, T: numpy.ndarray[tuple[typing.Literal[4], typing.Literal[4]], numpy.dtype[numpy.float64]], linear_velocity_limit: float, angular_velocity_limit: float, acceleration_limit_scaling: float) -> CartesianCommandBuilder:
        """
        Add a Cartesian pose target for a link.
        
        Parameters
        ----------
        ref_link_name : str
            Reference frame (link) in which the target pose is expressed.
        link_name : str
            Controlled link name (end-effector).
        T : numpy.ndarray, shape (4,4), dtype=float64
            Desired homogeneous transform :math:`{}^{ref}\\!T^{link}_d \\in SE(3)`.
        linear_velocity_limit : float
            Maximum allowed translational speed [m/s].
        angular_velocity_limit : float
            Maximum allowed rotational speed [rad/s].
        acceleration_limit_scaling : float
            Dimensionless scaling applied to internal Cartesian acceleration limits
            (e.g., ``0.5`` halves the default internal limits).
        
        Returns
        -------
        CartesianCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - Limits here shape trajectory timing; they do **not** redefine hardware limits.
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> CartesianCommandBuilder:
        """
        Attach a command header.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header configuration (e.g., control hold time).
        
        Returns
        -------
        CartesianCommandBuilder
            Self reference for method chaining.
        """
    def set_minimum_time(self, minimum_time: float) -> CartesianCommandBuilder:
        """
        Set the minimum execution time for the motion.
        
        Parameters
        ----------
        minimum_time : float
            The shortest allowed duration (in seconds) to reach the target.
        
            - If the motion profile based on velocity/acceleration limits would finish earlier,
              the motion is slowed down to take exactly `minimum_time`.
            - If the natural motion takes longer than `minimum_time`, this parameter is ignored.
        
            This parameter provides an additional degree of freedom to control
            arrival time. Instead of relying solely on velocity and acceleration limits,
            you can set high limits and then enforce the desired duration using `minimum_time`.
        
            For streaming commands, this prevents the robot from arriving too early
            and waiting idly, thereby ensuring smooth and continuous motion.
        
        Returns
        -------
        CartesianCommandBuilder
            Self reference for method chaining.
        """
    def set_stop_joint_position_tracking_error(self, stop_joint_position_tracking_error: float) -> CartesianCommandBuilder:
        """
        Set the stop threshold on joint-space position tracking error.
        
        Parameters
        ----------
        stop_joint_position_tracking_error : float
            Threshold on per-joint position error [rad]. When joint errors fall below
            this value (and other conditions are met), the controller may stop.
        
        Returns
        -------
        CartesianCommandBuilder
            Self reference for method chaining.
        """
    def set_stop_orientation_tracking_error(self, stop_orientation_tracking_error: float) -> CartesianCommandBuilder:
        """
        Set the stop threshold on rotational tracking error.
        
        Parameters
        ----------
        stop_orientation_tracking_error : float
            Threshold on orientation error [rad]. When the
            orientation error falls below this value, the controller may stop.
        
        Returns
        -------
        CartesianCommandBuilder
            Self reference for method chaining.
        """
    def set_stop_position_tracking_error(self, stop_position_tracking_error: float) -> CartesianCommandBuilder:
        """
        Set the stop threshold on translational tracking error.
        
        Parameters
        ----------
        stop_position_tracking_error : float
            Threshold on :math:`\\|\\Delta x\\|` [m]. When the position error falls below
            this value (and other conditions are met), the controller may stop.
        
        Returns
        -------
        CartesianCommandBuilder
            Self reference for method chaining.
        """
class CartesianCommandFeedback(CommandFeedback):
    """
    
    Feedback for a Cartesian command with one or more SE(3) pose targets.
    
    Attributes
    ----------
    se3_pose_tracking_errors : list[CartesianCommandFeedback.TrackingError]
        Per-target pose tracking errors (position/orientation).
    joint_position_tracking_errors : list[float]
        Per-joint position tracking errors [rad].
    remain_time : float
        Estimated remaining time to reach targets [s].
    manipulability : float
        Manipulability index (dimensionless).
    """
    class TrackingError:
        """
        
        Per-target SE(3) tracking error.
        
        Attributes
        ----------
        position_error : float
            Translational error magnitude [m].
        orientation_error : float
            Rotational error magnitude [rad] (e.g., angle-axis norm).
        """
        def __init__(self) -> None:
            """
                  Construct a ``CartesianCommandFeedback.TrackingError`` instance.
            """
        @property
        def orientation_error(self) -> float:
            ...
        @property
        def position_error(self) -> float:
            ...
    def __init__(self) -> None:
        """
              Construct a ``CartesianCommandFeedback`` instance.
        """
    @property
    def joint_position_tracking_errors(self) -> list[float]:
        """
        Per-joint position tracking errors.
        
        Returns
        -------
        list[float]
            Joint-wise position error magnitudes [rad].
        """
    @property
    def manipulability(self) -> float:
        """
        Manipulability index.
        
        Returns
        -------
        float
            Dimensionless manipulability measure (higher is generally better).
        """
    @property
    def remain_time(self) -> float:
        """
        Estimated remaining time to reach targets.
        
        Returns
        -------
        float
            Time remaining [s].
        """
    @property
    def se3_pose_tracking_errors(self) -> list[CartesianCommandFeedback.TrackingError]:
        """
        Per-target SE(3) pose tracking errors.
        
        Returns
        -------
        list[CartesianCommandFeedback.TrackingError]
            Tracking error objects for each Cartesian target.
        """
class CartesianImpedanceControlCommandBuilder:
    """
    
    Cartesian impedance control command builder.
    
    Takes **Cartesian pose targets** (in SE(3)) but executes control in **joint space**:
    first, an **optimal control / inverse-kinematics** problem finds joint targets
    :math:`q^\\*` that best realize the Cartesian objectives; then a **joint-space
    impedance controller** tracks :math:`q^\\*` using the stiffness/damping/torque
    limits you set.
    
    Pipeline
    --------
    1) **Cartesian objective (se(3) error):** for each target transform
       :math:`{}^{ref}\\!T^{link}_d`, an error
       :math:`\\xi = [\\,\\Delta x;\\,\\Delta\\phi\\,] \\in \\mathbb{R}^6` is formed
       (translation/orientation in se(3)) and contributes to an optimal-control cost.
    2) **Optimal control solve:** solves for joint configuration :math:`q^\\*`
       (and, if needed, velocities/accelerations) that minimize a weighted sum of
       Cartesian errors and optional joint terms while respecting internal
       (scaled) velocity/acceleration limits and joint bounds.
    3) **Joint-space impedance tracking:** applies
    
       .. math::
    
          \\tau \\;=\\; K \\,(q^\\* - q) \\;+\\; D \\,(\\dot{q}^\\* - \\dot{q}) \\;+\\; \\tau_{ff},
    
       where :math:`K=\\mathrm{diag}(k_1,\\ldots,k_N)` is set via
       ``set_joint_stiffness(...)`` (diagonal terms only), :math:`D` is built from a
       damping ratio :math:`\\zeta` as
    
       .. math::
    
          D \\;=\\; \\zeta \\left(\\sqrt{M}\\sqrt{K} \\;+\\; \\sqrt{K}\\sqrt{M}\\right),
    
       with :math:`M` the joint-space inertia, and :math:`\\tau_{ff}` is the
       **gravity feed-forward** torque. The final torque is saturated per-joint by
       ``set_joint_torque_limit(...)``:
    
       .. math::
    
          \\tau_{\\text{applied}} \\;=\\; \\mathrm{clip}(\\tau,\\,-\\tau_{\\max},\\,\\tau_{\\max}).
    
    What each setting affects
    ------------------------
    - ``add_target(...)``: defines Cartesian pose costs used **only in the optimal-control
      solve** that produces :math:`q^\\*`.
    - ``set_joint_stiffness(...)``, ``set_joint_damping_ratio(...)``,
      ``set_joint_torque_limit(...)``: shape the **joint-space impedance** that tracks
      :math:`q^\\*` (they do not change the Cartesian cost; they change how :math:`q^\\*`
      is followed).
    - ``add_joint_position_target(...)`` and ``add_joint_limit(...)``: add joint-space
      costs/constraints to the **optimal-control** stage.
    - Velocity/acceleration limits passed to ``add_target(...)`` are used as **internal
      bounds/scalings** for the solver, not hardware limits.
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> T = np.eye(4); T[0,3] = 0.45; T[2,3] = 0.60   # desired wrist pose in base_link
    >>> cmd = (
    ...   rby.CartesianImpedanceControlCommandBuilder()
    ...   .add_target("base_link", "right_wrist", T,
    ...               linear_velocity_limit=0.3,    # solver internal bounds
    ...               angular_velocity_limit=0.8)
    ...   .add_joint_position_target("right_arm_3", 0.5)  # joint hint in the OC stage
    ...   .set_joint_stiffness(np.full(7, 40.0))          # K diag for joint impedance
    ...   .set_joint_damping_ratio(0.7)                   # ζ → D
    ...   .set_joint_torque_limit(np.full(7, 35.0))       # τ saturation
    ...   .set_minimum_time(2.0)
    ... )
    """
    def __init__(self) -> None:
        """
        Construct a CartesianImpedanceControlCommandBuilder instance.
        """
    def add_joint_limit(self, joint_name: str, lower: float, upper: float) -> CartesianImpedanceControlCommandBuilder:
        """
        Add a joint position limit.
        
        Parameters
        ----------
        joint_name : str
            Joint name.
        lower : float
            Lower limit [rad].
        upper : float
            Upper limit [rad].
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def add_joint_position_target(self, joint_name: str, target_position: float, velocity_limit: float | None = None, acceleration_limit: float | None = None) -> CartesianImpedanceControlCommandBuilder:
        """
        Add an auxiliary joint position target.
        
        Parameters
        ----------
        joint_name : str
            Joint name.
        target_position : float
            Desired position [rad].
        velocity_limit : Optional[float]
            Max velocity [rad/s].
        acceleration_limit : Optional[float]
            Max acceleration [rad/s²].
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def add_target(self, ref_link_name: str, link_name: str, T: numpy.ndarray[tuple[typing.Literal[4], typing.Literal[4]], numpy.dtype[numpy.float64]], linear_velocity_limit: float | None = None, angular_velocity_limit: float | None = None, linear_acceleration_limit: float | None = None, angular_acceleration_limit: float | None = None) -> CartesianImpedanceControlCommandBuilder:
        """
        Add a Cartesian impedance target.
        
        Parameters
        ----------
        ref_link_name : str
            Reference frame (link) name.
        link_name : str
            Controlled link name (end-effector).
        T : numpy.ndarray, shape (4,4), dtype=float64
            Desired homogeneous transform :math:`{}^{ref}\\!T^{link}_d`.
        linear_velocity_limit : Optional[float]
            Max translational velocity [m/s].
        angular_velocity_limit : Optional[float]
            Max angular velocity [rad/s].
        linear_acceleration_limit : Optional[float]
            Max translational acceleration [m/s²].
        angular_acceleration_limit : Optional[float]
            Max angular acceleration [rad/s²].
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> CartesianImpedanceControlCommandBuilder:
        """
        Attach a command header.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header configuration (e.g., control hold time).
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_joint_damping_ratio(self, damping_ratio: float) -> CartesianImpedanceControlCommandBuilder:
        """
        Set joint damping ratio.
        
        Parameters
        ----------
        damping_ratio : float
            Dimensionless damping ratio ζ.
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_joint_stiffness(self, stiffness: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> CartesianImpedanceControlCommandBuilder:
        """
        Set per-joint stiffness.
        
        Parameters
        ----------
        stiffness : numpy.ndarray, shape (N,), dtype=float64
            Joint stiffness values (Nm/rad).
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_joint_torque_limit(self, torque_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> CartesianImpedanceControlCommandBuilder:
        """
        Set per-joint torque limits.
        
        Parameters
        ----------
        torque_limit : numpy.ndarray, shape (N,), dtype=float64
            Max torques [Nm].
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_minimum_time(self, minimum_time: float) -> CartesianImpedanceControlCommandBuilder:
        """
        Set minimum execution time.
        
        Parameters
        ----------
        minimum_time : float
            Minimum time [s] to execute trajectory.
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_nullspace_joint_target(self, target_position: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]], weight: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]], k_p: float | None = 0.2, k_d: float | None = 0.2, cost_weight: float | None = 0.001) -> CartesianImpedanceControlCommandBuilder:
        """
        Set nullspace joint target.
        
        Parameters
        ----------
        target_position : numpy.ndarray, shape (N,), dtype=float64
            Desired position [rad].
        weight : numpy.ndarray, shape (N,), dtype=float64
            Weight for the nullspace term.
        k_p : float, optional, default=0.2
            Proportional gain for the nullspace term.
        k_d : float, optional, default=0.2
            Derivative gain for the nullspace term.
        cost_weight : float, optional, default=1e-3
            Cost weight for the nullspace term.
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_reset_reference(self, reset_reference: bool) -> CartesianImpedanceControlCommandBuilder:
        """
        Set whether to reset the reference pose.
        
        Parameters
        ----------
        reset_reference : bool
            If True, resets the reference configuration before applying new targets.
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_stop_joint_position_tracking_error(self, stop_joint_position_tracking_error: float) -> CartesianImpedanceControlCommandBuilder:
        """
        Set stop threshold on joint position error.
        
        Parameters
        ----------
        stop_joint_position_tracking_error : float
            Threshold [rad].
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_stop_orientation_tracking_error(self, stop_orientation_tracking_error: float) -> CartesianImpedanceControlCommandBuilder:
        """
        Set stop threshold on orientation error.
        
        Parameters
        ----------
        stop_orientation_tracking_error : float
            Threshold [rad].
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_stop_position_tracking_error(self, stop_position_tracking_error: float) -> CartesianImpedanceControlCommandBuilder:
        """
        Set stop threshold on translational error.
        
        Parameters
        ----------
        stop_position_tracking_error : float
            Threshold [m].
        
        Returns
        -------
        CartesianImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
class CartesianImpedanceControlCommandFeedback(CommandFeedback):
    """
    
    Feedback for a Cartesian-impedance control command.
    
    Attributes
    ----------
    set_position : numpy.ndarray, shape (N,), dtype=float64
        Current joint setpoint used by the internal joint-space controller [rad].
    remain_time : float
        Estimated remaining time to settle [s].
    manipulability : float
        Manipulability index (dimensionless).
    """
    def __init__(self) -> None:
        """
              Construct a ``CartesianImpedanceControlCommandFeedback`` instance.
        """
    @property
    def manipulability(self) -> float:
        """
        Manipulability index.
        
        Returns
        -------
        float
            Dimensionless manipulability measure.
        """
    @property
    def remain_time(self) -> float:
        """
        Estimated remaining time to settle.
        
        Returns
        -------
        float
            Time remaining [s].
        """
    @property
    def set_position(self) -> numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint setpoint used by the internal joint-space controller.
        
        Returns
        -------
        numpy.ndarray
            Joint setpoint vector [rad], shape (N,).
        """
class Color:
    """
    
    RGB color representation.
    
    Represents a color using red, green, and blue components.
    
    Attributes
    ----------
    r : int
        Red component [0, 255].
    g : int
        Green component [0, 255].
    b : int
        Blue component [0, 255].
    """
    b: int
    g: int
    r: int
    @typing.overload
    def __init__(self) -> None:
        """
        Construct a Color instance with default values (0, 0, 0).
        """
    @typing.overload
    def __init__(self, r: int, g: int, b: int) -> None:
        """
        Construct a Color instance with specified RGB values.
        
        Parameters
        ----------
        r : int
            Red component [0, 255].
        g : int
            Green component [0, 255].
        b : int
            Blue component [0, 255].
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
class CommandFeedback(Feedback):
    """
    
    Base type of feedback for specific command categories.
    
    Attributes
    ----------
    command_header : CommandHeaderFeedback
        Header-level feedback shared by all command types.
    """
    def __init__(self) -> None:
        """
              Construct a ``CommandFeedback`` instance.
        """
    @property
    def command_header(self) -> CommandHeaderFeedback:
        """
        Header-level feedback.
        
        Returns
        -------
        CommandHeaderFeedback
            Header feedback (e.g., finished flag).
        """
class CommandHeaderBuilder:
    """
    
    Command header builder.
    
    Builds command headers with control hold time settings.
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> header = rby.CommandHeaderBuilder().set_control_hold_time(5.0)
    >>> # Use this header in any command builder:
    >>> jp = rby.JointPositionCommandBuilder().set_command_header(header)
    >>> # Control hold time keeps the command active for 5 seconds
    """
    def __init__(self) -> None:
        """
              Construct a CommandHeaderBuilder instance.
        """
    def set_control_hold_time(self, control_hold_time: float) -> CommandHeaderBuilder:
        """
        Set the control hold time.
        
        Parameters
        ----------
        control_hold_time : float
            Control hold time in seconds.
        
        Returns
        -------
        CommandHeaderBuilder
            Self reference for method chaining.
        """
class CommandHeaderFeedback(Feedback):
    """
    
    Header-level feedback common to all commands.
    
    Attributes
    ----------
    finished : bool
        Whether the command has finished (as assessed by the controller).
    """
    def __init__(self) -> None:
        """
              Construct a ``CommandHeaderFeedback`` instance.
        """
    @property
    def finished(self) -> bool:
        """
        Whether the command has finished.
        
        Returns
        -------
        bool
            ``True`` if the command is finished; otherwise ``False``.
        """
class ComponentBasedCommandBuilder:
    """
    
    Component-based command builder.
    
    Provides a unified builder interface to compose commands for the robot’s
    main subsystems: mobility, body, and head.  
    Each setter accepts either the corresponding *CommandBuilder wrapper*
    (e.g., MobilityCommandBuilder, BodyCommandBuilder, HeadCommandBuilder)  
    or lower-level builders (e.g., JointVelocityCommandBuilder, JointPositionCommandBuilder),
    which are automatically cast into the appropriate wrapper.
    
    Notes
    -----
    - This is typically used inside a RobotCommandBuilder to assemble
      subsystem-level commands into a single robot command.
    - Automatic casting removes the need to explicitly wrap builders,
      simplifying code.
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> comp = rby.ComponentBasedCommandBuilder()
    >>> # Mobility: send SE2 velocity
    >>> comp.set_mobility_command(
    ...     rby.SE2VelocityCommandBuilder().set_velocity(np.array([0.1, 0.0]), 0.2)
    ... )
    >>> # Body: send a joint position command to the right arm
    >>> comp.set_body_command(
    ...     rby.BodyComponentBasedCommandBuilder().set_right_arm_command(
    ...         rby.JointPositionCommandBuilder().set_position(np.zeros(7))
    ...     )
    ... )
    >>> # Head: send a joint position command to head joints
    >>> comp.set_head_command(
    ...     rby.JointPositionCommandBuilder().set_position(np.zeros(2))
    ... )
    >>> cmd = rby.RobotCommandBuilder().set_command(comp)
    >>> # robot.send_command(cmd, priority=1).get()
    """
    def __init__(self) -> None:
        """
        Construct a ComponentBasedCommandBuilder instance.
        """
    def set_body_command(self, body_command_builder: BodyCommandBuilder) -> ComponentBasedCommandBuilder:
        """
        Assign a body command.
        
        Parameters
        ----------
        body_command_builder : BodyCommandBuilder or compatible builder
            Command for the body subsystem. If a lower-level builder is provided
            (e.g., BodyComponentBasedCommandBuilder, JointPositionCommandBuilder),
            it will be automatically wrapped into a BodyCommandBuilder.
        
        Returns
        -------
        ComponentBasedCommandBuilder
            Self reference for method chaining.
        """
    def set_head_command(self, head_command_builder: HeadCommandBuilder) -> ComponentBasedCommandBuilder:
        """
        Assign a head command.
        
        Parameters
        ----------
        head_command_builder : HeadCommandBuilder or compatible builder
            Command for the head subsystem. If a lower-level builder is provided
            (e.g., JointPositionCommandBuilder),
            it will be automatically wrapped into a HeadCommandBuilder.
        
        Returns
        -------
        ComponentBasedCommandBuilder
            Self reference for method chaining.
        """
    def set_mobility_command(self, mobility_command_builder: MobilityCommandBuilder) -> ComponentBasedCommandBuilder:
        """
        Assign a mobility command.
        
        Parameters
        ----------
        mobility_command_builder : MobilityCommandBuilder or compatible builder
            Command for the mobility subsystem. If a lower-level builder is provided
            (e.g., SE2VelocityCommandBuilder, JointVelocityCommandBuilder),
            it will be automatically wrapped into a MobilityCommandBuilder.
        
        Returns
        -------
        ComponentBasedCommandBuilder
            Self reference for method chaining.
        """
class ComponentBasedCommandFeedback(CommandFeedback):
    """
    
    Feedback for a component-based command container.
    
    Attributes
    ----------
    head_command : HeadCommandFeedback
        Feedback for the head component (if present).
    body_command : BodyCommandFeedback
        Feedback for the body component (if present).
    mobility_command : MobilityCommandFeedback
        Feedback for the mobility component (if present).
    """
    def __init__(self) -> None:
        """
              Construct a ``ComponentBasedCommandFeedback`` instance.
        """
    @property
    def body_command(self) -> BodyCommandFeedback:
        """
        Body component feedback.
        
        Returns
        -------
        BodyCommandFeedback
            Feedback object.
        """
    @property
    def head_command(self) -> HeadCommandFeedback:
        """
        Head component feedback.
        
        Returns
        -------
        HeadCommandFeedback
            Feedback object.
        """
    @property
    def mobility_command(self) -> MobilityCommandFeedback:
        """
        Mobility component feedback.
        
        Returns
        -------
        MobilityCommandFeedback
            Feedback object.
        """
class ControlManagerState:
    """
    
    Control manager state information.
    
    This class represents the current state of the robot's control manager,
    including operational status, time scaling, and joint enablement.
    
    Attributes
    ----------
    state : State
        Current operational state of the control manager.
    time_scale : float
        Time scaling factor from 0.0 (stopped) to 1.0 (normal speed).
    control_state : ControlState
        Current control execution state.
    enabled_joint_idx : list[int]
        Indices of currently enabled joints.
    unlimited_mode_enabled : bool
        Whether unlimited mode is currently enabled.
    """
    class ControlState:
        """
        
        Control execution state enumeration.
        
        Defines the current state of control execution within the control manager.
        
        Members
        -------
        Unknown : int
            Control state is unknown or undefined.
        Idle : int
            No control commands are being executed.
        Executing : int
            Control commands are actively being executed.
        Switching : int
            Control is switching between different modes or commands.
        
        
        Members:
        
          Unknown
        
          Idle
        
          Executing
        
          Switching
        """
        Executing: typing.ClassVar[ControlManagerState.ControlState]  # value = <ControlState.Executing: 2>
        Idle: typing.ClassVar[ControlManagerState.ControlState]  # value = <ControlState.Idle: 1>
        Switching: typing.ClassVar[ControlManagerState.ControlState]  # value = <ControlState.Switching: 3>
        Unknown: typing.ClassVar[ControlManagerState.ControlState]  # value = <ControlState.Unknown: 0>
        __members__: typing.ClassVar[dict[str, ControlManagerState.ControlState]]  # value = {'Unknown': <ControlState.Unknown: 0>, 'Idle': <ControlState.Idle: 1>, 'Executing': <ControlState.Executing: 2>, 'Switching': <ControlState.Switching: 3>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class State:
        """
        
        Control manager operational state enumeration.
        
        Defines the possible operational states of the control manager,
        from normal operation to various fault conditions.
        
        Members
        -------
        Unknown : int
            State is unknown or undefined.
        Idle : int
            Control manager is idle and ready for commands.
        Enabled : int
            Control manager is enabled and actively controlling.
        MinorFault : int
            Minor fault condition detected.
        MajorFault : int
            Major fault condition detected.
        
        
        Members:
        
          Unknown
        
          Idle
        
          Enabled
        
          MinorFault
        
          MajorFault
        """
        Enabled: typing.ClassVar[ControlManagerState.State]  # value = <State.Enabled: 2>
        Idle: typing.ClassVar[ControlManagerState.State]  # value = <State.Idle: 1>
        MajorFault: typing.ClassVar[ControlManagerState.State]  # value = <State.MajorFault: 4>
        MinorFault: typing.ClassVar[ControlManagerState.State]  # value = <State.MinorFault: 3>
        Unknown: typing.ClassVar[ControlManagerState.State]  # value = <State.Unknown: 0>
        __members__: typing.ClassVar[dict[str, ControlManagerState.State]]  # value = {'Unknown': <State.Unknown: 0>, 'Idle': <State.Idle: 1>, 'Enabled': <State.Enabled: 2>, 'MinorFault': <State.MinorFault: 3>, 'MajorFault': <State.MajorFault: 4>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        """
        Construct a ControlManagerState instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def control_state(self) -> ControlManagerState.ControlState:
        ...
    @property
    def enabled_joint_idx(self) -> list[int]:
        ...
    @property
    def state(self) -> ControlManagerState.State:
        ...
    @property
    def time_scale(self) -> float:
        ...
    @property
    def unlimited_mode_enabled(self) -> bool:
        ...
class DynamixelBus:
    """
    
    Dynamixel bus communication interface.
    
    This class provides low-level communication with Dynamixel servos
    including motor control, PID tuning, and status monitoring.
    
    Attributes
    ----------
    ProtocolVersion : float
        Dynamixel protocol version (2.0).
    DefaultBaudrate : int
        Default communication baudrate (2000000).
    AddrTorqueEnable : int
        Memory address for torque enable/disable (64).
    AddrPresentCurrent : int
        Memory address for current reading (126).
    AddrPresentVelocity : int
        Memory address for velocity reading (128).
    AddrPresentPosition : int
        Memory address for position reading (132).
    AddrGoalCurrent : int
        Memory address for current goal setting (102).
    AddrGoalPosition : int
        Memory address for position goal setting (104).
    AddrOperatingMode : int
        Memory address for operating mode setting (11).
    AddrPresentButtonState : int
        Memory address for button state reading (12).
    AddrGoalVibrationLevel : int
        Memory address for vibration level setting (13).
    AddrPositionPGain : int
        Memory address for position P gain (80).
    AddrPositionIGain : int
        Memory address for position I gain (81).
    AddrPositionDGain : int
        Memory address for position D gain (82).
    TorqueEnable : int
        Value to enable torque (1).
    TorqueDisable : int
        Value to disable torque (0).
    CurrentControlMode : int
        Operating mode for current control (0).
    CurrentBasedPositionControlMode : int
        Operating mode for current-based position control (5).
    AddrCurrentTemperature : int
        Memory address for temperature reading (146).
    """
    class ButtonState:
        """
        
        Button state information for gripper devices.
        
        This class represents the state of buttons and triggers
        on gripper or tool devices.
        
        Attributes
        ----------
        button : int
            Button state: 0 (released) or 1 (pressed).
        trigger : int
            Trigger value ranging from 0 to 255.
        """
        def __init__(self) -> None:
            """
            Construct a ButtonState instance with default values.
            """
        def __repr__(self) -> str:
            ...
        def __str__(self) -> str:
            ...
        @property
        def button(self) -> int:
            ...
        @property
        def trigger(self) -> int:
            ...
    class MotorState:
        """
        
        Motor state information.
        
        This class represents the current state of a Dynamixel motor
        including position, velocity, current, and temperature.
        
        Attributes
        ----------
        torque_enable : bool
            Whether torque is currently enabled.
        position : float
            Current position [rad].
        velocity : float
            Current velocity [rad/s].
        current : float
            Current current [A].
        torque : float
            Current torque [Nm].
        temperature : int
            Current temperature in degrees Celsius.
        """
        def __init__(self) -> None:
            """
            Construct a MotorState instance with default values.
            """
        def __repr__(self) -> str:
            ...
        def __str__(self) -> str:
            ...
        @property
        def current(self) -> float:
            ...
        @property
        def position(self) -> float:
            ...
        @property
        def temperature(self) -> int:
            ...
        @property
        def torque(self) -> float:
            ...
        @property
        def torque_enable(self) -> bool:
            ...
        @property
        def velocity(self) -> float:
            ...
    class PIDGain:
        """
        
        PID gain parameters for position control.
        
        This class represents the proportional, integral, and derivative
        gains used for position control of Dynamixel motors.
        
        Attributes
        ----------
        p_gain : int
            Proportional gain (0-65535).
        i_gain : int
            Integral gain (0-65535).
        d_gain : int
            Derivative gain (0-65535).
        """
        d_gain: int
        i_gain: int
        p_gain: int
        def __init__(self) -> None:
            """
            Construct a PIDGain instance with default values.
            """
    AddrCurrentTemperature: typing.ClassVar[int] = 146
    AddrGoalCurrent: typing.ClassVar[int] = 102
    AddrGoalPosition: typing.ClassVar[int] = 116
    AddrGoalVibrationLevel: typing.ClassVar[int] = 102
    AddrOperatingMode: typing.ClassVar[int] = 11
    AddrPositionDGain: typing.ClassVar[int] = 80
    AddrPositionIGain: typing.ClassVar[int] = 82
    AddrPositionPGain: typing.ClassVar[int] = 84
    AddrPresentButtonState: typing.ClassVar[int] = 132
    AddrPresentCurrent: typing.ClassVar[int] = 126
    AddrPresentPosition: typing.ClassVar[int] = 132
    AddrPresentVelocity: typing.ClassVar[int] = 128
    AddrTorqueEnable: typing.ClassVar[int] = 64
    CurrentBasedPositionControlMode: typing.ClassVar[int] = 5
    CurrentControlMode: typing.ClassVar[int] = 0
    DefaultBaudrate: typing.ClassVar[int] = 2000000
    ProtocolVersion: typing.ClassVar[float] = 2.0
    TorqueDisable: typing.ClassVar[int] = 0
    TorqueEnable: typing.ClassVar[int] = 1
    def __init__(self, dev_name: str) -> None:
        """
        Construct a DynamixelBus instance.
        
        Parameters
        ----------
        dev_name : str
            Device name (e.g., "/dev/ttyUSB0" on Linux).
        """
    def get_motor_states(self, ids: list[int]) -> list[tuple[int, DynamixelBus.MotorState]] | None:
        """
        Get motor states for multiple motors.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        
        Returns
        -------
        list[tuple[int, MotorState]] or None
            List of (id, motor_state) tuples if successful, None otherwise.
        """
    def get_position_d_gain(self, id: int) -> int | None:
        """
        Get position D gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        int or None
            D gain value if successful, None otherwise.
        """
    def get_position_i_gain(self, id: int) -> int | None:
        """
        Get position I gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        int or None
            I gain value if successful, None otherwise.
        """
    def get_position_p_gain(self, id: int) -> int | None:
        """
        Get position P gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        int or None
            P gain value if successful, None otherwise.
        """
    def get_position_pid_gain(self, id: int) -> DynamixelBus.PIDGain | None:
        """
        Get position PID gains for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        PIDGain or None
            PIDGain struct if successful, None otherwise.
        """
    def group_fast_sync_read(self, ids: list[int], addr: int, len: int) -> list[tuple[int, int]] | None:
        """
        Perform fast synchronous read for multiple motors.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        addr : int
            Memory address to read from.
        len : int
            Number of bytes to read.
        
        Returns
        -------
        list[tuple[int, int]] or None
            List of (id, value) tuples if successful, None otherwise.
        """
    def group_fast_sync_read_encoder(self, ids: list[int]) -> list[tuple[int, float]] | None:
        """
        Perform fast synchronous read of encoder values.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        
        Returns
        -------
        list[tuple[int, float]] or None
            List of (id, encoder_value) tuples if successful, None otherwise.
        """
    def group_fast_sync_read_operating_mode(self, ids: list[int], use_cache: bool) -> list[tuple[int, int]] | None:
        """
        Perform fast synchronous read of operating modes.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        use_cache : bool, optional
            Whether to use cached values. Default is False.
        
        Returns
        -------
        list[tuple[int, int]] or None
            List of (id, operating_mode) tuples if successful, None otherwise.
        """
    def group_fast_sync_read_torque_enable(self, ids: list[int]) -> list[tuple[int, int]] | None:
        """
        Perform fast synchronous read of torque enable states.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        
        Returns
        -------
        list[tuple[int, int]] or None
            List of (id, torque_enable) tuples if successful, None otherwise.
        """
    def group_sync_write_operating_mode(self, id_and_mode_vector: list[tuple[int, int]]) -> None:
        """
        Perform synchronous write of operating modes.
        
        Parameters
        ----------
        id_and_mode_vector : list[tuple[int, int]]
            List of (id, mode) tuples.
        """
    def group_sync_write_send_position(self, id_and_position_vector: list[tuple[int, float]]) -> None:
        """
        Perform synchronous write of goal positions.
        
        Parameters
        ----------
        id_and_position_vector : list[tuple[int, int]]
            List of (id, position) tuples.
        """
    def group_sync_write_send_torque(self, id_and_torque_vector: list[tuple[int, float]]) -> None:
        """
        Perform synchronous write of torque commands.
        
        Parameters
        ----------
        id_and_torque_vector : list[tuple[int, float]]
            List of (id, torque) tuples.
        """
    @typing.overload
    def group_sync_write_torque_enable(self, id_and_enable_vector: list[tuple[int, int]]) -> None:
        """
        Perform synchronous write of torque enable states.
        
        Parameters
        ----------
        id_and_enable_vector : list[tuple[int, int]]
            List of (id, enable) tuples.
        """
    @typing.overload
    def group_sync_write_torque_enable(self, ids: list[int], enable: int) -> None:
        """
        Perform synchronous write of torque enable states.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        enable : int
            Enable value (1=enabled, 0=disabled).
        """
    def open_port(self) -> bool:
        """
        Open the communication port.
        
        Returns
        -------
        bool
            True if port opened successfully, False otherwise.
        """
    def ping(self, id: int) -> bool:
        """
        Ping a motor to check if it's responding.
        
        Parameters
        ----------
        id : int
            Motor ID to ping.
        
        Returns
        -------
        bool
            True if motor responds, False otherwise.
        """
    def read_button_status(self, arg0: int) -> tuple[int, DynamixelBus.ButtonState] | None:
        """
        Read button status from a device.
        
        Parameters
        ----------
        id : int
            Device ID to read from.
        
        Returns
        -------
        tuple[int, ButtonState] or None
            Tuple of (id, button_state) if successful, None otherwise.
        """
    def read_encoder(self, id: int) -> float | None:
        """
        Read encoder position for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        float or None
            Encoder position in radians if successful, None otherwise.
        """
    def read_operating_mode(self, id: int, use_cache: bool) -> int | None:
        """
        Read operating mode for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        use_cache : bool, optional
            Whether to use cached value. Default is False.
        
        Returns
        -------
        int or None
            Operating mode value if successful, None otherwise.
        """
    def read_temperature(self, id: int) -> int | None:
        """
        Read temperature for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        int or None
            Temperature in degrees Celsius if successful, None otherwise.
        """
    def read_torque_enable(self, id: int) -> int | None:
        """
        Read torque enable state for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        int or None
            Torque state (1=enabled, 0=disabled) if successful, None otherwise.
        """
    def send_current(self, id: int, current: float) -> None:
        """
        Send current command to a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        current : float
            Current value [A].
        """
    def send_goal_position(self, id: int, goal_position: int) -> None:
        """
        Send goal position to a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        goal_position : int
            Goal position in encoder units.
        """
    def send_operating_mode(self, id: int, operating_mode: int) -> bool:
        """
        Send operating mode to a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        mode : int
            Operating mode value.
        
        Returns
        -------
        bool
            True if successful, False otherwise.
        """
    def send_torque(self, id: int, torque: float) -> None:
        """
        Send torque command to a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        joint_torque : float
            Torque value [Nm].
        """
    def send_torque_enable(self, id: int, onoff: int) -> None:
        """
        Enable or disable torque for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        onoff : int
            Torque state: 1 (enable) or 0 (disable).
        """
    def send_vibration(self, id: int, vibration: int) -> None:
        """
        Send vibration command to a device.
        
        Parameters
        ----------
        id : int
            Device ID.
        level : int
            Vibration level (0-255).
        """
    def set_baud_rate(self, baudrate: int) -> bool:
        """
        Set the communication baudrate.
        
        Parameters
        ----------
        baudrate : int
            Baudrate value (e.g., 2000000).
        
        Returns
        -------
        bool
            True if baudrate set successfully, False otherwise.
        """
    def set_position_d_gain(self, id: int, d_gain: int) -> None:
        """
        Set position D gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        d_gain : int
            D gain value (0-65535).
        """
    def set_position_i_gain(self, id: int, i_gain: int) -> None:
        """
        Set position I gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        i_gain : int
            I gain value (0-65535).
        """
    def set_position_p_gain(self, id: int, p_gain: int) -> None:
        """
        Set position P gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        p_gain : int
            P gain value (0-65535).
        """
    @typing.overload
    def set_position_pid_gain(self, id: int, p_gain: int | None, i_gain: int | None, d_gain: int | None) -> None:
        """
        Set position PID gains for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        p_gain : int or None, optional
            P gain value (0-65535). If None, current value is preserved.
        i_gain : int or None, optional
            I gain value (0-65535). If None, current value is preserved.
        d_gain : int or None, optional
            D gain value (0-65535). If None, current value is preserved.
        """
    @typing.overload
    def set_position_pid_gain(self, id: int, pid_gain: DynamixelBus.PIDGain) -> None:
        """
        Set position PID gains for a motor using PIDGain struct.
        
        Parameters
        ----------
        id : int
            Motor ID.
        pid_gain : PIDGain
            PIDGain struct containing P, I, and D values.
        """
    def set_torque_constant(self, torque_constant: list[float]) -> None:
        """
        Set torque constants for motors.
        
        Parameters
        ----------
        torque_constant : list[float]
            List of torque constants for each motor.
        """
class EMOInfo:
    """
    
    Emergency stop button information.
    
    This class represents information about an emergency stop
    button connected to the robot.
    
    Attributes
    ----------
    name : str
        Name identifier for the emergency stop button.
    """
    def __init__(self) -> None:
        """
        Construct an ``EMOInfo`` instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
class EMOState:
    """
    
    Emergency stop button state.
    
    Provides information about emergency stop button status.
    
    Attributes
    ----------
    state : State
        Current emergency stop button state.
    """
    class State:
        """
        
        Emergency stop button state enumeration.
        
        Defines the possible emergency stop button states.
        
        Members
        -------
        Released : int
            Emergency stop button is released.
        Pressed : int
            Emergency stop button is pressed.
        
        
        Members:
        
          Released
        
          Pressed
        """
        Pressed: typing.ClassVar[EMOState.State]  # value = <State.Pressed: 1>
        Released: typing.ClassVar[EMOState.State]  # value = <State.Released: 0>
        __members__: typing.ClassVar[dict[str, EMOState.State]]  # value = {'Released': <State.Released: 0>, 'Pressed': <State.Pressed: 1>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def state(self) -> EMOState.State:
        ...
class FTSensorData:
    """
    
    Force/Torque sensor data.
    
    Provides information about force and torque measurements from a sensor.
    
    Attributes
    ----------
    time_since_last_update : datetime.timedelta
        Time since last update as a Python timedelta.
    force : numpy.ndarray, shape (3,), dtype=float64
        Force readings in N.
    torque : numpy.ndarray, shape (3,), dtype=float64
        Torque readings [Nm].
    """
    def __init__(self) -> None:
        """
        Construct a FTSensorData instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def force(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def time_since_last_update(self) -> datetime.timedelta:
        ...
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
class Feedback:
    """
    
    Base type for all feedback messages.
    
    Use :py:meth:`valid` to check whether the parser filled this feedback instance.
    
    Attributes
    ----------
    valid : bool
        Whether this feedback object contains valid data.
    """
    def __init__(self) -> None:
        """
              Construct a ``Feedback`` instance.
        """
    @property
    def valid(self) -> bool:
        """
        Whether this feedback object contains valid data.
        
        Returns
        -------
        bool
            ``True`` if the parser filled this feedback; otherwise ``False``.
        """
class GravityCompensationCommandBuilder:
    """
    
    Gravity compensation command builder.
    
    Creates a command that enables or disables gravity compensation on a
    component (e.g., an arm or the whole body). When enabled, the controller
    generates feed-forward torques to cancel the effect of gravity so the
    robot feels weightless.
    
    Examples
    --------
    >>> import rby1_sdk as rby
    >>> # Enable gravity compensation for the right arm
    >>> gc = rby.GravityCompensationCommandBuilder().set_on(True)
    >>> cmd = rby.RobotCommandBuilder().set_command(
    ...     rby.ArmCommandBuilder().set_command(gc)
    ... )
    >>> # robot.send_command(cmd, priority=1).get()
    """
    def __init__(self) -> None:
        """
        Construct a GravityCompensationCommandBuilder instance.
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> GravityCompensationCommandBuilder:
        """
        Attach a command header.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header configuration (e.g., control hold time).
        
        Returns
        -------
        GravityCompensationCommandBuilder
            Self reference for method chaining.
        """
    def set_on(self, on: bool) -> GravityCompensationCommandBuilder:
        """
        Enable or disable gravity compensation.
        
        Parameters
        ----------
        on : bool
            ``True`` to enable gravity compensation, ``False`` to disable.
        
        Returns
        -------
        GravityCompensationCommandBuilder
            Self reference for method chaining.
        """
class GravityCompensationCommandFeedback(CommandFeedback):
    """
    
    Feedback for a gravity-compensation command.
    
    (Contains only header-level fields via :pyattr:`CommandFeedback.command_header`.)
    """
    def __init__(self) -> None:
        """
              Construct a ``GravityCompensationCommandFeedback`` instance.
        """
class HeadCommandBuilder:
    """
    
    Head command builder.
    
    Wraps commands for the robot head.  
    Currently, it supports **JointPositionCommandBuilder** to control the head joints.
    
    Notes
    -----
    - You can pass a JointPositionCommandBuilder directly into
      ``set_head_command(...)`` without explicitly wrapping it in a HeadCommandBuilder,
      since implicit casting is provided.
    - Explicit construction is only needed if you want to be verbose; otherwise,
      ``set_head_command(JointPositionCommandBuilder(...))`` is sufficient.
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> # Example 1: Explicit HeadCommandBuilder
    >>> jp = rby.JointPositionCommandBuilder().set_position(np.zeros(2))  # assume 2 DOF head
    >>> head = rby.HeadCommandBuilder(jp)
    >>> comp = rby.ComponentBasedCommandBuilder().set_head_command(head)
    >>> rc = rby.RobotCommandBuilder().set_command(comp)
    >>> # robot.send_command(rc, priority=1).get()
    >>>
    >>> # Example 2: Implicit wrapping (preferred)
    >>> comp = rby.ComponentBasedCommandBuilder().set_head_command(
    ...     rby.JointPositionCommandBuilder().set_position(np.zeros(2))
    ... )
    >>> rc = rby.RobotCommandBuilder().set_command(comp)
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Construct a HeadCommandBuilder instance.
        """
    @typing.overload
    def __init__(self, joint_position_command_builder: JointPositionCommandBuilder) -> None:
        """
        Construct a HeadCommandBuilder from a joint position command.
        
        Parameters
        ----------
        joint_position_command_builder : JointPositionCommandBuilder
            Command specifying target joint positions for the head.
        """
    def set_command(self, joint_position_command_builder: JointPositionCommandBuilder) -> HeadCommandBuilder:
        """
        Assign a joint position command to the head.
        
        Parameters
        ----------
        joint_position_command_builder : JointPositionCommandBuilder
            Joint position command for the head.
        
        Returns
        -------
        HeadCommandBuilder
            Self reference for method chaining.
        """
class HeadCommandFeedback(CommandFeedback):
    """
    
    Feedback for a head command container.
    
    Attributes
    ----------
    joint_position_command : JointPositionCommandFeedback
        Feedback for a joint position command (if present).
    """
    def __init__(self) -> None:
        """
              Construct a ``HeadCommandFeedback`` instance.
        """
    @property
    def joint_position_command(self) -> JointPositionCommandFeedback:
        """
        Head joint position command feedback.
        
        Returns
        -------
        JointPositionCommandFeedback
            Feedback object.
        """
class ImpedanceControlCommandBuilder:
    """
    
    Cartesian impedance control command builder.
    
    Builds a Cartesian impedance command for a given link in a reference frame.
    The control is formulated in the **se(3)** space with a 6D error
    :math:`\\xi = [\\,\\Delta x;\\,\\Delta\\phi\\,] \\in \\mathbb{R}^6` (translation and
    rotation in the Lie algebra), yielding the wrench:
    
    .. math::
    
        w = K\\,\\xi \\;+\\; D\\,\\dot{\\xi}
    
    where :math:`K \\in \\mathbb{R}^{6\\times 6}` is the stiffness matrix and
    :math:`D \\in \\mathbb{R}^{6\\times 6}` is the damping matrix.
    
    Notes
    -----
    - The stiffness matrix :math:`K` is assumed **block-diagonal**:
    
      .. math::
    
          K \\;=\\; \\mathrm{diag}(K_t,\\; K_r), \\qquad
          K_t, K_r \\in \\mathbb{R}^{3\\times 3}\\ \\text{(diagonal)}
    
      ``set_translation_weight([k_x,k_y,k_z])`` fills :math:`K_t=\\mathrm{diag}(k_x,k_y,k_z)`,
      and ``set_rotation_weight([k_{rx},k_{ry},k_{rz}])`` fills
      :math:`K_r=\\mathrm{diag}(k_{rx},k_{ry},k_{rz})`.
    
    - Damping is derived from a dimensionless ratio :math:`\\zeta`:
    
      .. math::
    
          D \\;=\\; \\zeta \\left(\\sqrt{M}\\sqrt{K} \\;+\\; \\sqrt{K}\\sqrt{M}\\right),
    
      with :math:`M \\in \\mathbb{R}^{6\\times 6}` the Cartesian inertia matrix.
    
    - ``set_reference_link_name`` and ``set_link_name`` must be set before
      applying the target pose (``set_transformation``).
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> T = np.eye(4); T[0,3] = 0.30  # desired pose, 30 cm forward
    >>> cmd = (
    ...   rby.ImpedanceControlCommandBuilder()
    ...   .set_reference_link_name("base_link")
    ...   .set_link_name("right_wrist")
    ...   .set_transformation(T)
    ...   .set_translation_weight(np.array([1200.0, 1200.0, 1600.0]))  # N/m
    ...   .set_rotation_weight(np.array([60.0, 60.0, 60.0]))           # Nm/rad
    ...   .set_damping_ratio(0.7)
    ... )
    """
    def __init__(self) -> None:
        ...
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> ImpedanceControlCommandBuilder:
        """
        Attach a command header.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header configuration (e.g., control hold time).
        
        Returns
        -------
        ImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_damping_ratio(self, damping_ratio: float) -> ImpedanceControlCommandBuilder:
        """
        Set the (dimensionless) damping ratio used to build the 6×6 damping matrix.
        
        Parameters
        ----------
        damping_ratio : float
            Damping ratio :math:`\\zeta` (typically :math:`0 < \\zeta \\le 1.5`).
        
        Returns
        -------
        ImpedanceControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - Damping in se(3) space is computed from :math:`K` and the Cartesian inertia 
          (reflective inertia) :math:`M` as:
        
          .. math::
        
              D \\;=\\; \\zeta \\left(\\sqrt{M}\\sqrt{K} \\;+\\; \\sqrt{K}\\sqrt{M}\\right).
        
        - :math:`\\zeta=1` approximates critical damping; lower/higher values yield
          under/over-damped responses.
        """
    def set_link_name(self, link_name: str) -> ImpedanceControlCommandBuilder:
        """
        Set the controlled link name.
        
        Parameters
        ----------
        link_name : str
            Name of the robot link to be regulated in Cartesian impedance.
        
        Returns
        -------
        ImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_reference_link_name(self, reference_link_name: str) -> ImpedanceControlCommandBuilder:
        """
        Set the reference frame (link) name in which the pose is expressed.
        
        Parameters
        ----------
        reference_link_name : str
            Reference link/frame name.
        
        Returns
        -------
        ImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_rotation_weight(self, weight: numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> ImpedanceControlCommandBuilder:
        """
        Set rotational stiffness (fills the rotational block of K).
        
        Parameters
        ----------
        weight : numpy.ndarray, shape (3,), dtype=float64
            Per-axis rotational stiffness (Nm/rad), used to form
            :math:`K_r=\\mathrm{diag}(k_{rx},k_{ry},k_{rz})`.
        
        Returns
        -------
        ImpedanceControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - The rotational wrench component is :math:`\\tau = K_r\\,\\Delta\\phi`.
        """
    def set_transformation(self, T: numpy.ndarray[tuple[typing.Literal[4], typing.Literal[4]], numpy.dtype[numpy.float64]]) -> ImpedanceControlCommandBuilder:
        """
        Set the desired Cartesian pose (homogeneous transform).
        
        Parameters
        ----------
        T : numpy.ndarray, shape (4,4), dtype=float64
            Desired pose :math:`{}^{ref}\\!T^{link}_d`.
        
        Returns
        -------
        ImpedanceControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - The se(3) error :math:`\\xi = [\\Delta x;\\Delta\\phi]` is computed from
          :math:`T_d` and the current pose.
        """
    def set_translation_weight(self, weight: numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> ImpedanceControlCommandBuilder:
        """
        Set translational stiffness (fills the translational block of K).
        
        Parameters
        ----------
        weight : numpy.ndarray, shape (3,), dtype=float64
            Per-axis translational stiffness (N/m), used to form
            :math:`K_t=\\mathrm{diag}(k_x,k_y,k_z)`.
        
        Returns
        -------
        ImpedanceControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - The 6×6 stiffness matrix is :math:`K=\\mathrm{diag}(K_t,K_r)`.
        - The translational wrench component is :math:`F = K_t\\,\\Delta x`.
        """
class ImpedanceControlCommandFeedback(CommandFeedback):
    """
    
    Feedback for a Cartesian impedance control (single-link) command.
    
    Attributes
    ----------
    tracking_error : ImpedanceControlCommandFeedback.TrackingError
        Current tracking error (translation/rotation).
    """
    class TrackingError:
        """
        
        Tracking error for Cartesian impedance.
        
        Attributes
        ----------
        position_error : float
            Translational error magnitude [m].
        rotation_error : float
            Rotational error magnitude [rad] (e.g., angle-axis norm).
        """
        def __init__(self) -> None:
            """
                  Construct an ``ImpedanceControlCommandFeedback.TrackingError`` instance.
            """
        @property
        def position_error(self) -> float:
            ...
        @property
        def rotation_error(self) -> float:
            ...
    def __init__(self) -> None:
        """
              Construct an ``ImpedanceControlCommandFeedback`` instance.
        """
    @property
    def tracking_error(self) -> ImpedanceControlCommandFeedback.TrackingError:
        """
        Current tracking error.
        
        Returns
        -------
        ImpedanceControlCommandFeedback.TrackingError
            Translational and rotational error magnitudes.
        """
class JogCommandBuilder:
    """
    
    Jog command builder.
    
    Builds a jog command for a single joint. A jog command applies an incremental
    position change using one of three types: AbsolutePosition, RelativePosition,
    or OneStep.
    
    Notes
    -----
    - Jog is an incremental **position** command, not a velocity command.
    - To repeat or accumulate jogs on the same joint, send additional jog commands
      or use a stream command.
    
    Examples
    --------
    >>> import rby1_sdk as rby
    >>> jog = (
    ...     rby.JogCommandBuilder()
    ...     .set_joint_name("right_arm_0")
    ...     .set_command(rby.JogCommandBuilder.RelativePosition(0.1))
    ... )
    >>> cmd = rby.RobotCommandBuilder().set_command(jog)
    >>> robot.send_command(cmd, priority=1)
    """
    class AbsolutePosition:
        """
        
        Absolute jog target.
        
        Sets the joint to an absolute angle in radians.
        
        Parameters
        ----------
        value : float
            Target absolute joint angle [rad].
        
        Examples
        --------
        >>> rby.JogCommandBuilder.AbsolutePosition(1.57)  # ~90 degrees
        """
        def __init__(self, arg0: float) -> None:
            ...
        def value(self) -> float:
            """
            Get the target absolute angle in radians.
            """
    class OneStep:
        """
        
        One-step jog target.
        
        Applies a single incremental step to the joint angle in radians.
        Useful for discrete button/step interfaces.
        
        Parameters
        ----------
        value : float
            Step size [rad].
        
        Examples
        --------
        >>> rby.JogCommandBuilder.OneStep(-0.05)  # one step backward
        """
        def __init__(self, arg0: float) -> None:
            ...
        def value(self) -> bool:
            """
            Get the step size in radians.
            """
    class RelativePosition:
        """
        
        Relative jog target.
        
        Offsets the current joint angle by a relative amount in radians.
        
        Parameters
        ----------
        value : float
            Relative offset [rad]. Positive values increase the angle; negative values decrease it.
        
        Examples
        --------
        >>> rby.JogCommandBuilder.RelativePosition(0.1)  # +0.1 rad
        """
        def __init__(self, arg0: float) -> None:
            ...
        def value(self) -> float:
            """
            Get the relative offset in radians.
            """
    def __init__(self) -> None:
        ...
    def set_acceleration_limit(self, acceleration_limit: float) -> JogCommandBuilder:
        """
        Set the maximum acceleration used during the jog.
        
        Parameters
        ----------
        acceleration_limit : float
            Maximum allowed joint acceleration [rad/s²].
        
        Returns
        -------
        JogCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, absolute_position: JogCommandBuilder.AbsolutePosition) -> JogCommandBuilder:
        """
        Set the jog as an absolute position target.
        
        Parameters
        ----------
        absolute_position : JogCommandBuilder.AbsolutePosition
            Absolute target angle [rad].
        
        Returns
        -------
        JogCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, relative_position: JogCommandBuilder.RelativePosition) -> JogCommandBuilder:
        """
        Set the jog as a relative position target.
        
        Parameters
        ----------
        relative_position : JogCommandBuilder.RelativePosition
            Relative offset [rad] from the current joint angle.
        
        Returns
        -------
        JogCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, one_step: JogCommandBuilder.OneStep) -> JogCommandBuilder:
        """
        Set the jog as a single incremental step.
        
        Parameters
        ----------
        one_step : JogCommandBuilder.OneStep
            Step size [rad] to apply once.
        
        Returns
        -------
        JogCommandBuilder
            Self reference for method chaining.
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> JogCommandBuilder:
        """
        Attach a command header.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header configuration (e.g., control hold time).
        
        Returns
        -------
        JogCommandBuilder
            Self reference for method chaining.
        """
    def set_joint_name(self, joint_name: str) -> JogCommandBuilder:
        """
        Specify the joint to jog.
        
        Parameters
        ----------
        joint_name : str
            Name of the single joint to control.
        
        Returns
        -------
        JogCommandBuilder
            Self reference for method chaining.
        """
    def set_velocity_limit(self, velocity_limit: float) -> JogCommandBuilder:
        """
        Set the maximum velocity used during the jog.
        
        Parameters
        ----------
        velocity_limit : float
            Maximum allowed joint velocity [rad/s].
        
        Returns
        -------
        JogCommandBuilder
            Self reference for method chaining.
        """
class JogCommandFeedback(CommandFeedback):
    """
    
    Feedback for a single-joint jog command.
    
    Attributes
    ----------
    target_joint_name : str
        The name of the jogged joint.
    """
    def __init__(self) -> None:
        """
              Construct a ``JogCommandFeedback`` instance.
        """
    @property
    def target_joint_name(self) -> str:
        """
        Name of the jogged joint.
        
        Returns
        -------
        str
            Target joint name.
        """
class JointGroupPositionCommandBuilder:
    """
    
    Joint group position command builder.
    
    Builds joint position commands for a named subset (group) of joints.
    
    Notes
    -----
    - **Vector length rule**: For vector arguments (e.g., ``position``, ``velocity_limit``, ``acceleration_limit``),
      ``N`` equals the number of joint names set by ``set_joint_names(...)``.
    
    Examples
    --------
    Command 3 torso joints by name:
    
    >>> import numpy as np, rby1_sdk as rby
    >>> torso = (
    ...   rby.JointGroupPositionCommandBuilder()
    ...   .set_joint_names(["torso_3","torso_4","torso_5"])
    ...   .set_position(np.zeros(3))        # N=3
    ...   .set_minimum_time(2.0)
    ... )
    """
    def __init__(self) -> None:
        ...
    def set_acceleration_limit(self, acceleration_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointGroupPositionCommandBuilder:
        """
        Set per-joint acceleration limits for the group.
        
        Parameters
        ----------
        acceleration_limit : numpy.ndarray, shape (N,), dtype=float64
            Acceleration limits [rad/s²].
        
        Returns
        -------
        JointGroupPositionCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        **Vector length rule**: ``N`` equals the number of joint names set by ``set_joint_names(...)``.
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> JointGroupPositionCommandBuilder:
        ...
    def set_joint_names(self, joint_names: list[str]) -> JointGroupPositionCommandBuilder:
        """
        Set the joint names that this group command applies to.
        
        Parameters
        ----------
        joint_names : list of str
            List of joint name identifiers. The order defines the mapping for
            subsequent vector arguments such as ``position``, ``velocity_limit``,
            and ``acceleration_limit``.
        
        Returns
        -------
        JointGroupPositionCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - **Vector length rule**: After calling ``set_joint_names([...])``,
          the length ``N`` for all vector arguments must match the number of names provided.
          For example, if 6 joint names are given, ``position``, ``velocity_limit``,
          and ``acceleration_limit`` must all be length 6.
        
        Examples
        --------
        >>> import numpy as np, rby1_sdk as rby
        >>> torso = (
        ...   rby.JointGroupPositionCommandBuilder()
        ...   .set_joint_names(["torso_0","torso_1","torso_2","torso_3","torso_4","torso_5"])
        ...   .set_position(np.zeros(6))                 # N=6
        ...   .set_velocity_limit(np.full(6, 1.0))
        ...   .set_acceleration_limit(np.full(6, 2.0))
        ...   .set_minimum_time(2.0)
        ... )
        """
    def set_minimum_time(self, minimum_time: float) -> JointGroupPositionCommandBuilder:
        """
        Set the minimum execution time for the motion.
        
        Parameters
        ----------
        minimum_time : float
            The shortest allowed duration (in seconds) to reach the target.
        
            - If the motion profile based on velocity/acceleration limits would finish earlier,
              the motion is slowed down to take exactly `minimum_time`.
            - If the natural motion takes longer than `minimum_time`, this parameter is ignored.
        
            This parameter provides an additional degree of freedom to control
            arrival time. Instead of relying solely on velocity and acceleration limits,
            you can set high limits and then enforce the desired duration using `minimum_time`.
        
            For streaming commands, this prevents the robot from arriving too early
            and waiting idly, thereby ensuring smooth and continuous motion.
        
        Returns
        -------
        JointGroupPositionCommandBuilder
            Self reference for method chaining.
        """
    def set_position(self, position: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointGroupPositionCommandBuilder:
        """
        Set group joint target positions in radians.
        
        Parameters
        ----------
        position : numpy.ndarray, shape (N,), dtype=float64
            Target joint positions (radians) for the group.
        
        Returns
        -------
        JointGroupPositionCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        **Vector length rule**: ``N`` equals the number of joint names set by ``set_joint_names(...)``.
        """
    def set_velocity_limit(self, velocity_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointGroupPositionCommandBuilder:
        """
        Set per-joint velocity limits for the group.
        
        Parameters
        ----------
        velocity_limit : numpy.ndarray, shape (N,), dtype=float64
            Velocity limits [rad/s].
        
        Returns
        -------
        JointGroupPositionCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        **Vector length rule**: ``N`` equals the number of joint names set by ``set_joint_names(...)``.
        """
class JointGroupPositionCommandFeedback(CommandFeedback):
    """
    
    Feedback for a joint group position command.
    
    Attributes
    ----------
    joint_indices : list[int]
        Indices of the joints targeted by this group command (model order).
    time_based_progress : float
        Progress estimate [0.0, 1.0] based on time.
    position_based_progress : float
        Progress estimate [0.0, 1.0] based on position error reduction.
    """
    def __init__(self) -> None:
        """
              Construct a ``JointGroupPositionCommandFeedback`` instance.
        """
    @property
    def joint_indices(self) -> list[int]:
        """
        Indices of the joints in the group command.
        
        Returns
        -------
        list[int]
            Model-order joint indices.
        """
    @property
    def position_based_progress(self) -> float:
        """
        Position-based progress estimate.
        
        Returns
        -------
        float
            Value in [0.0, 1.0].
        """
    @property
    def time_based_progress(self) -> float:
        """
        Time-based progress estimate.
        
        Returns
        -------
        float
            Value in [0.0, 1.0].
        """
class JointImpedanceControlCommandBuilder:
    """
    
    Joint impedance control command builder.
    
    Creates joint-space impedance commands with position targets, stiffness, damping ratio,
    optional velocity/acceleration limits, and per-joint torque limits.
    
    Notes
    -----
    - **Vector length rule**: All vector arguments (``position``, ``stiffness``, ``torque_limit``,
      ``velocity_limit``, ``acceleration_limit``) must have length :math:`N` equal to the DOF of
      the component where this builder is applied.
    
      Examples (Model ``A``):
      
      - ``set_right_arm_command(...)`` → right arm has :math:`N=7`
      - ``set_body_command(...)``      → whole body has :math:`N=20`
    
    - Impedance control model:
    
      .. math::
    
          \\tau = K (q_d - q) + D (\\dot{q}_d - \\dot{q}) + \\tau_{ff}
    
      with :math:`K` (stiffness), :math:`D` (damping), and :math:`\\tau_{ff}` the
      feed-forward torque.
    
    - Damping from damping ratio :math:`\\zeta`:
    
      .. math::
    
          D = \\zeta \\left( \\sqrt{M}\\sqrt{K} + \\sqrt{K}\\sqrt{M} \\right)
    
      where :math:`M` is the (joint) inertia matrix.
    
    - Feed-forward torque :math:`\\tau_{ff}` is the gravity compensation torque.
      The final applied torque is saturated by the per-joint limits:
    
      .. math::
    
          \\tau_{applied} = \\mathrm{clip}(\\tau,\\; -\\tau_{max},\\; \\tau_{max})
    
    Examples
    --------
    Compliant positioning on one arm (Model A):
    
    >>> import numpy as np, rby1_sdk as rby
    >>> imp = (
    ...   rby.JointImpedanceControlCommandBuilder()
    ...   .set_position(np.zeros(7))                # N=7
    ...   .set_stiffness(np.full(7, 50.0))          # Nm/rad
    ...   .set_damping_ratio(0.7)                   # ζ
    ...   .set_torque_limit(np.full(7, 60.0))       # Nm
    ...   .set_velocity_limit(np.full(7, np.pi))    # rad/s
    ...   .set_acceleration_limit(np.full(7, 2.0))  # rad/s²
    ...   .set_minimum_time(1.0)                    # s
    ... )
    """
    def __init__(self) -> None:
        ...
    def set_acceleration_limit(self, acceleration_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointImpedanceControlCommandBuilder:
        """
        Set per-joint acceleration limits.
        
        Parameters
        ----------
        acceleration_limit : numpy.ndarray, shape (N,), dtype=float64
            Acceleration limits [rad/s²].
        
        Returns
        -------
        JointImpedanceControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - Vector length :math:`N` must match the component DOF.
        - If not set, limits from the current robot URDF are used (see ``get_robot_model``).
        - Values beyond hardware capability may be accepted for profiling; actual tracking is not guaranteed.
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> JointImpedanceControlCommandBuilder:
        """
        Attach a command header to this builder.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header configuration (e.g., control hold time).
        
        Returns
        -------
        JointImpedanceControlCommandBuilder
            Self reference for method chaining.
        
        Examples
        --------
        >>> header = rby.CommandHeaderBuilder().set_control_hold_time(3.0)
        >>> imp = rby.JointImpedanceControlCommandBuilder().set_command_header(header)
        """
    def set_damping_ratio(self, damping_ratio: float) -> JointImpedanceControlCommandBuilder:
        """
        Set the damping ratio.
        
        Parameters
        ----------
        damping_ratio : float
            Damping ratio :math:`\\zeta` (dimensionless) in [0, 1].
        
        Returns
        -------
        JointImpedanceControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        The damping matrix is computed from :math:`\\zeta`, stiffness :math:`K`, and inertia :math:`M`:
        
        .. math::
        
            D = \\zeta \\left( \\sqrt{M}\\sqrt{K} + \\sqrt{K}\\sqrt{M} \\right)
        """
    def set_minimum_time(self, minimum_time: float) -> JointImpedanceControlCommandBuilder:
        """
        Set the minimum execution time for the motion.
        
        Parameters
        ----------
        minimum_time : float
            The shortest allowed duration (in seconds) to reach the target.
        
            - If the motion profile based on velocity/acceleration limits would finish earlier,
              the motion is slowed down to take exactly `minimum_time`.
            - If the natural motion takes longer than `minimum_time`, this parameter is ignored.
        
            This parameter provides an additional degree of freedom to control
            arrival time. Instead of relying solely on velocity and acceleration limits,
            you can set high limits and then enforce the desired duration using `minimum_time`.
        
            For streaming commands, this prevents the robot from arriving too early
            and waiting idly, thereby ensuring smooth and continuous motion.
        
        Returns
        -------
        JointImpedanceControlCommandBuilder
            Self reference for method chaining.
        """
    def set_position(self, position: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointImpedanceControlCommandBuilder:
        """
        Set target joint positions.
        
        Parameters
        ----------
        position : numpy.ndarray, shape (N,), dtype=float64
            Desired joint positions :math:`q_d` [rad]
        
        Returns
        -------
        JointImpedanceControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        Vector length :math:`N` must match the DOF of the target component
        (e.g., Model A arm :math:`N=7`, whole body :math:`N=20`).
        """
    def set_stiffness(self, stiffness: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointImpedanceControlCommandBuilder:
        """
        Set per-joint stiffness values.
        
        Parameters
        ----------
        stiffness : numpy.ndarray, shape (N,), dtype=float64
            Per-joint stiffness values, interpreted as the diagonal elements of
            the stiffness matrix :math:`K \\in \\mathbb{R}^{N \\times N}` (Nm/rad).
        
        Returns
        -------
        JointImpedanceControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - Vector length :math:`N` must match the component DOF.
        - The full stiffness matrix is assumed to be diagonal:
        
          .. math::
        
              K = \\mathrm{diag}(k_1, k_2, \\ldots, k_N)
        
        - Stiffness contributes torque as:
        
          .. math::
        
              \\tau_K = K (q_d - q)
        """
    def set_torque_limit(self, torque_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointImpedanceControlCommandBuilder:
        """
        Set per-joint torque limits.
        
        Parameters
        ----------
        torque_limit : numpy.ndarray, shape (N,), dtype=float64
            Maximum allowable torque :math:`\\tau_{max}` [Nm].
        
        Returns
        -------
        JointImpedanceControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - The controller torque is:
        
          .. math::
        
              \\tau = K (q_d - q) + D (\\dot{q}_d - \\dot{q}) + \\tau_{ff}
        
          where :math:`\\tau_{ff}` is the feed-forward gravity compensation torque.
        
        - The applied torque is saturated per joint:
        
          .. math::
        
              \\tau_{applied} = \\mathrm{clip}(\\tau,\\; -\\tau_{max},\\; \\tau_{max})
        """
    def set_velocity_limit(self, velocity_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointImpedanceControlCommandBuilder:
        """
        Set per-joint velocity limits.
        
        Parameters
        ----------
        velocity_limit : numpy.ndarray, shape (N,), dtype=float64
            Velocity limits [rad/s].
        
        Returns
        -------
        JointImpedanceControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - Vector length :math:`N` must match the component DOF.
        - If not set, limits from the current robot URDF are used (see ``get_robot_model``).
        - Values beyond hardware capability may be accepted for profiling; actual tracking is not guaranteed.
        """
class JointImpedanceControlCommandFeedback(CommandFeedback):
    """
    
    Feedback for a joint-space impedance control command.
    
    Attributes
    ----------
    set_position : list[float]
        Current joint setpoints [rad].
    error : list[float]
        Joint-space errors (q_d - q) [rad].
    """
    def __init__(self) -> None:
        """
              Construct a ``JointImpedanceControlCommandFeedback`` instance.
        """
    @property
    def error(self) -> list[float]:
        """
        Joint-space errors.
        
        Returns
        -------
        list[float]
            Per-joint position errors [rad].
        """
    @property
    def set_position(self) -> list[float]:
        """
        Current joint setpoints.
        
        Returns
        -------
        list[float]
            Joint setpoints [rad].
        """
class JointInfo:
    """
    
    Joint information.
    
    Stores hardware/firmware metadata for a single joint.
    
    Attributes
    ----------
    name : str
        Joint name (e.g., "right_arm_2").
    has_brake : bool
        Whether the joint includes a brake.
    product_name : str
        Actuator/driver product name.
    firmware_version : str
        Firmware revision running on the motor driver / servo drive.
    """
    def __init__(self) -> None:
        """
        Construct a ``JointInfo`` with default-initialized fields.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def firmware_version(self) -> str:
        ...
    @property
    def has_brake(self) -> bool:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def product_name(self) -> str:
        ...
class JointPositionCommandBuilder:
    """
    
    Joint position command builder.
    
    Builds joint position commands with optional velocity/acceleration limits and a minimum execution time.
    
    Notes
    -----
    - **Vector length rule**: For any vector argument (e.g., ``position``, ``velocity_limit``, ``acceleration_limit``),
      the length **N must equal the DOF of the component this builder commands**.
      Examples:
      - ``set_right_arm_command(...)`` on model ``A`` → right arm N = 7
      - ``set_body_command(...)`` on model ``A`` → body N = 20
    
    Examples
    --------
    Move the right arm to zero with limits and a 3-second minimum time:
    
    >>> import numpy as np, rby1_sdk as rby
    >>> jp = (
    ...     rby.JointPositionCommandBuilder()
    ...     .set_position(np.zeros(7))                      # N=7 (right arm)
    ...     .set_velocity_limit(np.full(7, np.pi))          # rad/s
    ...     .set_acceleration_limit(np.full(7, 1.0))        # rad/s^2
    ...     .set_minimum_time(3.0)
    ... )
    >>> body = rby.BodyComponentBasedCommandBuilder().set_right_arm_command(
    ...     rby.ArmCommandBuilder().set_command(jp)
    ... )
    >>> rc = rby.RobotCommandBuilder().set_command(
    ...     rby.ComponentBasedCommandBuilder().set_body_command(body)
    ... )
    >>> # Send with priority 10
    >>> # robot.send_command(rc, 10).get()
    """
    def __init__(self) -> None:
        """
              Construct a JointPositionCommandBuilder instance.
        """
    def set_acceleration_limit(self, acceleration_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointPositionCommandBuilder:
        """
        Set joint acceleration limits.
        
        Parameters
        ----------
        acceleration_limit : numpy.ndarray, shape (N,), dtype=float64
            Per-joint acceleration limits [rad/s²].
        
        Returns
        -------
        JointPositionCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - **Vector length rule**: ``N`` must equal the DOF of the commanded component
          (e.g., model ``A`` right arm ``N=7``, full body ``N=20``).
        - If not set, URDF limits for the current robot model are used (see ``get_robot_model``).
        - Values beyond hardware limits may be accepted for profiling; actual tracking is not guaranteed.
        
        Examples
        --------
        >>> import numpy as np, rby1_sdk as rby
        >>> jp = rby.JointPositionCommandBuilder().set_acceleration_limit(np.full(7, 1.0))
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> JointPositionCommandBuilder:
        """
        Set the command header.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header builder.
        
        Returns
        -------
        JointPositionCommandBuilder
            Self reference for method chaining.
        """
    def set_minimum_time(self, minimum_time: float) -> JointPositionCommandBuilder:
        """
        Set the minimum execution time for the motion.
        
        Parameters
        ----------
        minimum_time : float
            The shortest allowed duration (in seconds) to reach the target.
        
            - If the motion profile based on velocity/acceleration limits would finish earlier,
              the motion is slowed down to take exactly `minimum_time`.
            - If the natural motion takes longer than `minimum_time`, this parameter is ignored.
        
            This parameter provides an additional degree of freedom to control
            arrival time. Instead of relying solely on velocity and acceleration limits,
            you can set high limits and then enforce the desired duration using `minimum_time`.
        
            For streaming commands, this prevents the robot from arriving too early
            and waiting idly, thereby ensuring smooth and continuous motion.
        
        Returns
        -------
        JointPositionCommandBuilder
            Self reference for method chaining.
        """
    def set_position(self, position: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointPositionCommandBuilder:
        """
        Set the target joint positions in radians.
        
        Parameters
        ----------
        position : numpy.ndarray, shape (N,), dtype=float64
            Target joint positions [rad]
        
        Returns
        -------
        JointPositionCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        **Vector length rule**: ``N`` must equal the DOF of the commanded component.
        Examples on model ``A``: right arm → ``N=7``; full body → ``N=20``.
        
        Examples
        --------
        >>> import numpy as np, rby1_sdk as rby
        >>> jp = rby.JointPositionCommandBuilder().set_position(np.zeros(7))  # right arm
        """
    def set_velocity_limit(self, velocity_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointPositionCommandBuilder:
        """
        Set joint velocity limits.
        
        Parameters
        ----------
        velocity_limit : numpy.ndarray, shape (N,), dtype=float64
            Per-joint velocity limits [rad/s].
        
        Returns
        -------
        JointPositionCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - **Vector length rule**: ``N`` must equal the DOF of the commanded component
          (e.g., model ``A`` right arm ``N=7``, full body ``N=20``).
        - If not set, URDF limits for the current robot model are used (see ``get_robot_model``).
        - Values beyond hardware limits may be accepted for profiling; actual tracking is not guaranteed.
        
        Examples
        --------
        >>> import numpy as np, rby1_sdk as rby
        >>> jp = rby.JointPositionCommandBuilder().set_velocity_limit(np.full(7, np.pi))
        """
class JointPositionCommandFeedback(CommandFeedback):
    """
    
    Feedback for a joint-space position command.
    
    Attributes
    ----------
    time_based_progress : float
        Progress estimate [0.0, 1.0] based on time.
    position_based_progress : float
        Progress estimate [0.0, 1.0] based on position error reduction.
    """
    def __init__(self) -> None:
        """
              Construct a ``JointPositionCommandFeedback`` instance.
        """
    @property
    def position_based_progress(self) -> float:
        """
        Position-based progress estimate.
        
        Returns
        -------
        float
            Value in [0.0, 1.0].
        """
    @property
    def time_based_progress(self) -> float:
        """
        Time-based progress estimate.
        
        Returns
        -------
        float
            Value in [0.0, 1.0].
        """
class JointState:
    """
    
    Joint state information.
    
    Provides information about the state of a single joint, including its readiness,
    FET state, run state, initialization state, motor type, motor state, power,
    position, velocity, current, torque, and target values.
    
    Attributes
    ----------
    time_since_last_update : datetime.timedelta
        Time since last update as a Python timedelta.
    is_ready : bool
        Indicates if the joint is ready to operate.
    fet_state : FETState
        Current FET state of the joint.
    run_state : RunState
        Current run state of the joint.
    init_state : InitializationState
        Current initialization state of the joint.
    motor_type : str
        Type of the joint's motor.
    motor_state : str
        Current state of the joint's motor.
    power_on : bool
        Indicates if the joint's power is on.
    position : float
        Current position of the joint [rad].
    velocity : float
        Current velocity of the joint [rad/s].
    current : float
        Current current of the joint [A].
    torque : float
        Current torque of the joint in Nm.
    target_position : float
        Target position of the joint [rad].
    target_velocity : float
        Target velocity of the joint [rad/s].
    target_feedback_gain : float
        Target feedback gain of the joint.
    target_feedforward_torque : float
        Target feedforward torque of the joint.
    temperature : float
        Current temperature of the joint in °C.
    """
    class FETState:
        """
        
        FET (power stage) state.
        
        Members
        -------
        Unknown : int
            State is unknown or not reported.
        On : int
            Power stage is enabled.
        Off : int
            Power stage is disabled.
        
        
        Members:
        
          Unknown
        
          On
        
          Off
        """
        Off: typing.ClassVar[JointState.FETState]  # value = <FETState.Off: 2>
        On: typing.ClassVar[JointState.FETState]  # value = <FETState.On: 1>
        Unknown: typing.ClassVar[JointState.FETState]  # value = <FETState.Unknown: 0>
        __members__: typing.ClassVar[dict[str, JointState.FETState]]  # value = {'Unknown': <FETState.Unknown: 0>, 'On': <FETState.On: 1>, 'Off': <FETState.Off: 2>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class InitializationState:
        """
        
        Initialization state of the joint.
        
        Members
        -------
        Unknown : int
            Initialization state is unknown.
        Initialized : int
            Joint has been initialized/homed.
        Uninitialized : int
            Joint has not been initialized/homed yet.
        
        
        Members:
        
          Unknown
        
          Initialized
        
          Uninitialized
        """
        Initialized: typing.ClassVar[JointState.InitializationState]  # value = <InitializationState.Initialized: 1>
        Uninitialized: typing.ClassVar[JointState.InitializationState]  # value = <InitializationState.Uninitialized: 2>
        Unknown: typing.ClassVar[JointState.InitializationState]  # value = <InitializationState.Unknown: 0>
        __members__: typing.ClassVar[dict[str, JointState.InitializationState]]  # value = {'Unknown': <InitializationState.Unknown: 0>, 'Initialized': <InitializationState.Initialized: 1>, 'Uninitialized': <InitializationState.Uninitialized: 2>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class RunState:
        """
        
        Current run state of the joint.
        
        Members
        -------
        Unknown : int
            State is unknown or not reported.
        ControlOn : int
            Closed-loop control is enabled (actively controlling).
        ControlOff : int
            Closed-loop control is disabled.
        
        
        Members:
        
          Unknown
        
          ControlOn
        
          ControlOff
        """
        ControlOff: typing.ClassVar[JointState.RunState]  # value = <RunState.ControlOff: 2>
        ControlOn: typing.ClassVar[JointState.RunState]  # value = <RunState.ControlOn: 1>
        Unknown: typing.ClassVar[JointState.RunState]  # value = <RunState.Unknown: 0>
        __members__: typing.ClassVar[dict[str, JointState.RunState]]  # value = {'Unknown': <RunState.Unknown: 0>, 'ControlOn': <RunState.ControlOn: 1>, 'ControlOff': <RunState.ControlOff: 2>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def current(self) -> float:
        ...
    @property
    def fet_state(self) -> JointState.FETState:
        ...
    @property
    def init_state(self) -> JointState.InitializationState:
        ...
    @property
    def is_ready(self) -> bool:
        ...
    @property
    def motor_state(self) -> int:
        ...
    @property
    def motor_type(self) -> int:
        ...
    @property
    def position(self) -> float:
        ...
    @property
    def power_on(self) -> bool:
        ...
    @property
    def run_state(self) -> JointState.RunState:
        ...
    @property
    def target_feedback_gain(self) -> int:
        ...
    @property
    def target_feedforward_torque(self) -> float:
        ...
    @property
    def target_position(self) -> float:
        ...
    @property
    def target_velocity(self) -> float:
        ...
    @property
    def temperature(self) -> int:
        ...
    @property
    def time_since_last_update(self) -> datetime.timedelta:
        ...
    @property
    def torque(self) -> float:
        ...
    @property
    def velocity(self) -> float:
        ...
class JointVelocityCommandBuilder:
    """
    
    Joint velocity command builder.
    
    Builds a joint-space velocity command with optional acceleration limits.
    When a target velocity vector :math:`v_d` is set, the command generates a
    linear ramp from the current velocity :math:`v_{curr}` to :math:`v_d`,
    considering both acceleration limits and the specified minimum time.
    
    The controller’s objective is to **reach the target velocity**.
    If you need the robot to **hold the target velocity after reaching it, you
    must specify a control hold time in the command header.**
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> # Ramp torso joints to 0.5 rad/s with acceleration limits
    >>> cmd = (
    ...     rby.JointVelocityCommandBuilder()
    ...     .set_velocity(np.full(6, 0.5))
    ...     .set_acceleration_limit(np.full(6, 2.0))
    ...     .set_minimum_time(1.0)
    ... )
    >>> # To maintain the velocity after reaching 0.5 rad/s,
    >>> # add a CommandHeader with control_hold_time.
    >>> header = rby.CommandHeaderBuilder().set_control_hold_time(5.0)
    >>> cmd.set_command_header(header)
    """
    def __init__(self) -> None:
        ...
    def set_acceleration_limit(self, acceleration_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointVelocityCommandBuilder:
        """
        Set per-joint acceleration limits.
        
        Parameters
        ----------
        acceleration_limit : numpy.ndarray, shape (N,), dtype=float64
            Maximum allowable accelerations [rad/s²].
            Length :math:`N` must equal the number of joints in the targeted component.
        
        Returns
        -------
        JointVelocityCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - These limits shape the linear ramp profile toward the target velocity.
        - If not set, URDF defaults are used (see ``get_robot_model``).
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> JointVelocityCommandBuilder:
        """
        Attach a command header.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header configuration (e.g., control hold time).
        
        Returns
        -------
        JointVelocityCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - Use ``control_hold_time`` to maintain the commanded velocity once reached.
        """
    def set_minimum_time(self, minimum_time: float) -> JointVelocityCommandBuilder:
        """
        Set the minimum execution time.
        
        Parameters
        ----------
        minimum_time : float
            Minimum execution time in seconds. Ensures the ramping process to the
            target velocity is stretched at least over this duration.
        
        Returns
        -------
        JointVelocityCommandBuilder
            Self reference for method chaining.
        """
    def set_velocity(self, velocity: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointVelocityCommandBuilder:
        """
        Set desired joint velocities.
        
        Parameters
        ----------
        velocity : numpy.ndarray, shape (N,), dtype=float64
            Per-joint target velocities [rad/s].
            Length :math:`N` must equal the number of joints in the targeted component.
        
        Returns
        -------
        JointVelocityCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - The command ramps linearly from the current velocity to the target velocity.
        - To **hold** the target velocity after reaching it, add a command header with
          a control hold time.
        """
class JointVelocityCommandFeedback(CommandFeedback):
    """
    
    Feedback for a joint-space velocity command.
    
    (Contains only header-level fields via :pyattr:`CommandFeedback.command_header`.)
    """
    def __init__(self) -> None:
        """
              Construct a ``JointVelocityCommandFeedback`` instance.
        """
class Log:
    """
    
    Robot log entry with timestamp and message.
    
    This class represents a single log entry from the robot system,
    including timestamps, log level, and message content.
    
    Attributes
    ----------
    timestamp : datetime.datetime
        Timestamp when the log was created (client system time).
    robot_system_timestamp : datetime.datetime
        Timestamp when the log was created (robot system time).
    level : Level
        Log level indicating the severity of the message.
    message : str
        The log message content.
    """
    class Level:
        """
        
        Log level enumeration.
        
        Defines the severity levels for log messages, from least to most severe.
        
        Members
        -------
        Trace : int
            Trace level for detailed debugging information.
        Debug : int
            Debug level for debugging information.
        Info : int
            Info level for general information messages.
        Warn : int
            Warning level for warning messages.
        Error : int
            Error level for error messages.
        Critical : int
            Critical level for critical error messages.
        
        
        Members:
        
          Trace
        
          Debug
        
          Info
        
          Warn
        
          Error
        
          Critical
        """
        Critical: typing.ClassVar[Log.Level]  # value = <Level.Critical: 5>
        Debug: typing.ClassVar[Log.Level]  # value = <Level.Debug: 1>
        Error: typing.ClassVar[Log.Level]  # value = <Level.Error: 4>
        Info: typing.ClassVar[Log.Level]  # value = <Level.Info: 2>
        Trace: typing.ClassVar[Log.Level]  # value = <Level.Trace: 0>
        Warn: typing.ClassVar[Log.Level]  # value = <Level.Warn: 3>
        __members__: typing.ClassVar[dict[str, Log.Level]]  # value = {'Trace': <Level.Trace: 0>, 'Debug': <Level.Debug: 1>, 'Info': <Level.Info: 2>, 'Warn': <Level.Warn: 3>, 'Error': <Level.Error: 4>, 'Critical': <Level.Critical: 5>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        """
        Construct a ``Log`` instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def level(self) -> Log.Level:
        ...
    @property
    def message(self) -> str:
        ...
    @property
    def robot_system_timestamp(self) -> datetime.datetime:
        ...
    @property
    def timestamp(self) -> datetime.datetime:
        ...
class MobilityCommandBuilder:
    """
    
    Mobility command builder.
    
    Wraps commands for the robot’s mobility subsystem.  
    It supports both joint-space velocity commands (e.g., differential/mecanum wheels)
    and planar SE(2) velocity commands.
    
    Notes
    -----
    - Typically used inside ``set_mobility_command(...)`` of a ComponentBasedCommandBuilder.
    - You do not need to explicitly construct MobilityCommandBuilder if passing
      a JointVelocityCommandBuilder or SE2VelocityCommandBuilder, as implicit casting
      will wrap them automatically.
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> # Example 1: Joint velocity mobility (e.g., wheel joints)
    >>> vel = rby.JointVelocityCommandBuilder().set_velocity(np.full(4, 1.0))
    >>> mobility = rby.MobilityCommandBuilder().set_command(vel)
    >>> comp = rby.ComponentBasedCommandBuilder().set_mobility_command(mobility)
    >>> rc = rby.RobotCommandBuilder().set_command(comp)
    >>> # robot.send_command(rc, priority=1).get()
    >>>
    >>> # Example 2: SE(2) velocity mobility
    >>> se2 = rby.SE2VelocityCommandBuilder().set_velocity(np.array([0.2, 0.0]), 0.1)  # vx=0.2 m/s, yaw=0.1 rad/s
    >>> comp = rby.ComponentBasedCommandBuilder().set_mobility_command(se2)  # implicit wrap
    >>> rc = rby.RobotCommandBuilder().set_command(comp)
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Construct a MobilityCommandBuilder instance.
        """
    @typing.overload
    def __init__(self, joint_velocity_command_builder: JointVelocityCommandBuilder) -> None:
        """
        Construct a MobilityCommandBuilder from a joint velocity command.
        
        Parameters
        ----------
        joint_velocity_command_builder : JointVelocityCommandBuilder
            Joint-space velocity command (e.g., wheel joint velocities).
        """
    @typing.overload
    def __init__(self, se2_velocity_command_builder: SE2VelocityCommandBuilder) -> None:
        """
        Construct a MobilityCommandBuilder from an SE(2) velocity command.
        
        Parameters
        ----------
        se2_velocity_command_builder : SE2VelocityCommandBuilder
            Planar velocity command in SE(2).
        """
    @typing.overload
    def set_command(self, joint_velocity_command_builder: JointVelocityCommandBuilder) -> MobilityCommandBuilder:
        """
        Assign a joint velocity command.
        
        Parameters
        ----------
        joint_velocity_command_builder : JointVelocityCommandBuilder
            Joint-space velocity command (rad/s for each mobility joint).
        
        Returns
        -------
        MobilityCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, se2_velocity_command_builder: SE2VelocityCommandBuilder) -> MobilityCommandBuilder:
        """
        Assign an SE(2) velocity command.
        
        Parameters
        ----------
        se2_velocity_command_builder : SE2VelocityCommandBuilder
            Planar velocity command with linear [m/s] and angular [rad/s] components.
        
        Returns
        -------
        MobilityCommandBuilder
            Self reference for method chaining.
        """
class MobilityCommandFeedback(CommandFeedback):
    """
    
    Feedback for a mobility command container.
    
    Attributes
    ----------
    joint_velocity_command : JointVelocityCommandFeedback
        Feedback for a joint velocity command (if present).
    se2_velocity_command : SE2VelocityCommandFeedback
        Feedback for a base SE(2) velocity command (if present).
    """
    def __init__(self) -> None:
        """
              Construct a ``MobilityCommandFeedback`` instance.
        """
    @property
    def joint_velocity_command(self) -> JointVelocityCommandFeedback:
        """
        Joint velocity command feedback.
        
        Returns
        -------
        JointVelocityCommandFeedback
            Feedback object.
        """
    @property
    def se2_velocity_command(self) -> SE2VelocityCommandFeedback:
        """
        SE(2) velocity command feedback.
        
        Returns
        -------
        SE2VelocityCommandFeedback
            Feedback object.
        """
class Model_A:
    """
    Robot model configuration (``A``).
    
    This class provides access to robot model specifications including
    joint configurations, degrees of freedom, and component indices.
    
    Attributes
    ----------
    model_name : str
        'A'
    
        Name identifier for the robot model.
    robot_dof : int
        24
    
        Total degrees of freedom.
    robot_joint_names : list[str]
        ['right_wheel', 'left_wheel', 'torso_0', 'torso_1', 'torso_2', 'torso_3', 'torso_4', 'torso_5', 'right_arm_0', 'right_arm_1', 'right_arm_2', 'right_arm_3', 'right_arm_4', 'right_arm_5', 'right_arm_6', 'left_arm_0', 'left_arm_1', 'left_arm_2', 'left_arm_3', 'left_arm_4', 'left_arm_5', 'left_arm_6', 'head_0', 'head_1']
    
        List of joint names in index order.
    mobility_idx : list[int]
        [0, 1]
    
        Indices of mobility components (e.g., wheels).
    body_idx : list[int]
        [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]
    
        Indices of main body components (excluding mobility and head).
    head_idx : list[int]
        [22, 23]
    
        Indices of head components.
    right_arm_idx : list[int]
        [8, 9, 10, 11, 12, 13, 14]
    
        Indices of right arm components.
    left_arm_idx : list[int]
        [15, 16, 17, 18, 19, 20, 21]
    
        Indices of left arm components.
    torso_idx : list[int]
        [2, 3, 4, 5, 6, 7]
    
        Indices of torso components.
    velocity_estimation_required_idx : list[int]
        [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]
    
        Indices of joints requiring velocity estimation.
    control_period : float
        0.002000
    
        Control update period in seconds.
    """
    def __init__(self) -> None:
        """
        Construct a model instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def body_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(20)]:
        """
        [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]
        
        Indices of main body components (excluding mobility and head).
        """
    @property
    def control_period(self) -> float:
        """
        0.002000
        
        Control period in seconds.
        """
    @property
    def head_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        [22, 23]
        
        Indices of head components.
        """
    @property
    def left_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        [15, 16, 17, 18, 19, 20, 21]
        
        Indices of left arm components.
        """
    @property
    def mobility_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        [0, 1]
        
        Indices of mobility components (e.g., wheels).
        """
    @property
    def model_name(self) -> str:
        """
        'A'
        
        Name identifier for the robot model.
        """
    @property
    def right_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        [8, 9, 10, 11, 12, 13, 14]
        
        Indices of right arm components.
        """
    @property
    def robot_dof(self) -> int:
        """
        24
        
        Total degrees of freedom.
        """
    @property
    def robot_joint_names(self) -> typing.Annotated[list[str], pybind11_stubgen.typing_ext.FixedSize(24)]:
        """
        ['right_wheel', 'left_wheel', 'torso_0', 'torso_1', 'torso_2', 'torso_3', 'torso_4', 'torso_5', 'right_arm_0', 'right_arm_1', 'right_arm_2', 'right_arm_3', 'right_arm_4', 'right_arm_5', 'right_arm_6', 'left_arm_0', 'left_arm_1', 'left_arm_2', 'left_arm_3', 'left_arm_4', 'left_arm_5', 'left_arm_6', 'head_0', 'head_1']
        
        List of joint names in index order.
        """
    @property
    def torso_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(6)]:
        """
        [2, 3, 4, 5, 6, 7]
        
        Indices of torso components.
        """
    @property
    def velocity_estimation_required_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(20)]:
        """
        [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]
        
        Indices of joints where velocity estimation is essential.
        """
class Model_M:
    """
    Robot model configuration (``M``).
    
    This class provides access to robot model specifications including
    joint configurations, degrees of freedom, and component indices.
    
    Attributes
    ----------
    model_name : str
        'M'
    
        Name identifier for the robot model.
    robot_dof : int
        26
    
        Total degrees of freedom.
    robot_joint_names : list[str]
        ['wheel_fr', 'wheel_fl', 'wheel_rr', 'wheel_rl', 'torso_0', 'torso_1', 'torso_2', 'torso_3', 'torso_4', 'torso_5', 'right_arm_0', 'right_arm_1', 'right_arm_2', 'right_arm_3', 'right_arm_4', 'right_arm_5', 'right_arm_6', 'left_arm_0', 'left_arm_1', 'left_arm_2', 'left_arm_3', 'left_arm_4', 'left_arm_5', 'left_arm_6', 'head_0', 'head_1']
    
        List of joint names in index order.
    mobility_idx : list[int]
        [0, 1, 2, 3]
    
        Indices of mobility components (e.g., wheels).
    body_idx : list[int]
        [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
    
        Indices of main body components (excluding mobility and head).
    head_idx : list[int]
        [24, 25]
    
        Indices of head components.
    right_arm_idx : list[int]
        [10, 11, 12, 13, 14, 15, 16]
    
        Indices of right arm components.
    left_arm_idx : list[int]
        [17, 18, 19, 20, 21, 22, 23]
    
        Indices of left arm components.
    torso_idx : list[int]
        [4, 5, 6, 7, 8, 9]
    
        Indices of torso components.
    velocity_estimation_required_idx : list[int]
        [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
    
        Indices of joints requiring velocity estimation.
    control_period : float
        0.002000
    
        Control update period in seconds.
    """
    def __init__(self) -> None:
        """
        Construct a model instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def body_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(20)]:
        """
        [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
        
        Indices of main body components (excluding mobility and head).
        """
    @property
    def control_period(self) -> float:
        """
        0.002000
        
        Control period in seconds.
        """
    @property
    def head_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        [24, 25]
        
        Indices of head components.
        """
    @property
    def left_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        [17, 18, 19, 20, 21, 22, 23]
        
        Indices of left arm components.
        """
    @property
    def mobility_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(4)]:
        """
        [0, 1, 2, 3]
        
        Indices of mobility components (e.g., wheels).
        """
    @property
    def model_name(self) -> str:
        """
        'M'
        
        Name identifier for the robot model.
        """
    @property
    def right_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        [10, 11, 12, 13, 14, 15, 16]
        
        Indices of right arm components.
        """
    @property
    def robot_dof(self) -> int:
        """
        26
        
        Total degrees of freedom.
        """
    @property
    def robot_joint_names(self) -> typing.Annotated[list[str], pybind11_stubgen.typing_ext.FixedSize(26)]:
        """
        ['wheel_fr', 'wheel_fl', 'wheel_rr', 'wheel_rl', 'torso_0', 'torso_1', 'torso_2', 'torso_3', 'torso_4', 'torso_5', 'right_arm_0', 'right_arm_1', 'right_arm_2', 'right_arm_3', 'right_arm_4', 'right_arm_5', 'right_arm_6', 'left_arm_0', 'left_arm_1', 'left_arm_2', 'left_arm_3', 'left_arm_4', 'left_arm_5', 'left_arm_6', 'head_0', 'head_1']
        
        List of joint names in index order.
        """
    @property
    def torso_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(6)]:
        """
        [4, 5, 6, 7, 8, 9]
        
        Indices of torso components.
        """
    @property
    def velocity_estimation_required_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(20)]:
        """
        [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
        
        Indices of joints where velocity estimation is essential.
        """
class Model_UB:
    """
    Robot model configuration (``UB``).
    
    This class provides access to robot model specifications including
    joint configurations, degrees of freedom, and component indices.
    
    Attributes
    ----------
    model_name : str
        'UB'
    
        Name identifier for the robot model.
    robot_dof : int
        18
    
        Total degrees of freedom.
    robot_joint_names : list[str]
        ['torso_hp', 'torso_5', 'right_arm_0', 'right_arm_1', 'right_arm_2', 'right_arm_3', 'right_arm_4', 'right_arm_5', 'right_arm_6', 'left_arm_0', 'left_arm_1', 'left_arm_2', 'left_arm_3', 'left_arm_4', 'left_arm_5', 'left_arm_6', 'head_0', 'head_1']
    
        List of joint names in index order.
    mobility_idx : list[int]
        []
    
        Indices of mobility components (e.g., wheels).
    body_idx : list[int]
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    
        Indices of main body components (excluding mobility and head).
    head_idx : list[int]
        [16, 17]
    
        Indices of head components.
    right_arm_idx : list[int]
        [2, 3, 4, 5, 6, 7, 8]
    
        Indices of right arm components.
    left_arm_idx : list[int]
        [9, 10, 11, 12, 13, 14, 15]
    
        Indices of left arm components.
    torso_idx : list[int]
        [0, 1]
    
        Indices of torso components.
    velocity_estimation_required_idx : list[int]
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    
        Indices of joints requiring velocity estimation.
    control_period : float
        0.002000
    
        Control update period in seconds.
    """
    def __init__(self) -> None:
        """
        Construct a model instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def body_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(16)]:
        """
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
        
        Indices of main body components (excluding mobility and head).
        """
    @property
    def control_period(self) -> float:
        """
        0.002000
        
        Control period in seconds.
        """
    @property
    def head_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        [16, 17]
        
        Indices of head components.
        """
    @property
    def left_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        [9, 10, 11, 12, 13, 14, 15]
        
        Indices of left arm components.
        """
    @property
    def mobility_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(0)]:
        """
        []
        
        Indices of mobility components (e.g., wheels).
        """
    @property
    def model_name(self) -> str:
        """
        'UB'
        
        Name identifier for the robot model.
        """
    @property
    def right_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        [2, 3, 4, 5, 6, 7, 8]
        
        Indices of right arm components.
        """
    @property
    def robot_dof(self) -> int:
        """
        18
        
        Total degrees of freedom.
        """
    @property
    def robot_joint_names(self) -> typing.Annotated[list[str], pybind11_stubgen.typing_ext.FixedSize(18)]:
        """
        ['torso_hp', 'torso_5', 'right_arm_0', 'right_arm_1', 'right_arm_2', 'right_arm_3', 'right_arm_4', 'right_arm_5', 'right_arm_6', 'left_arm_0', 'left_arm_1', 'left_arm_2', 'left_arm_3', 'left_arm_4', 'left_arm_5', 'left_arm_6', 'head_0', 'head_1']
        
        List of joint names in index order.
        """
    @property
    def torso_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        [0, 1]
        
        Indices of torso components.
        """
    @property
    def velocity_estimation_required_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(16)]:
        """
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
        
        Indices of joints where velocity estimation is essential.
        """
class OptimalControlCommandBuilder:
    """
    
    Optimal control command builder.
    
    Constructs an optimal control objective composed of Cartesian pose costs,
    center-of-mass (COM) costs, and joint position costs, with global error and
    limit scalings.
    
    Notes
    -----
    - The overall objective can be viewed as a weighted least-squares form:
    
      .. math::
    
          J \\;=\\; \\sum_{i} w_t^{(i)} \\,\\|\\, p^{(i)}_d - p^{(i)} \\,\\|^2
          \\;+\\; \\sum_{i} w_r^{(i)} \\,\\|\\, r^{(i)}_d \\ominus r^{(i)} \\,\\|^2
          \\;+\\; w_{\\mathrm{com}} \\,\\|\\, c_d - c \\,\\|^2
          \\;+\\; \\sum_j w_q^{(j)} \\,(q^{(j)}_d - q^{(j)})^2
    
      where :math:`p, r` denote translation and rotation of a link in a reference
      frame, :math:`c` is the COM position, and :math:`q` are joint positions.
    
    - Velocity/acceleration limit **scalings** multiply internal limits used by the
      optimizer; they do **not** redefine hardware limits.
    
    Examples
    --------
    Set a right-wrist Cartesian target and a joint hint, with moderate limit scalings:
    
    >>> import numpy as np, rby1_sdk as rby
    >>> T = np.eye(4); T[0,3] = 0.35; T[2,3] = 0.55
    >>> oc = (
    ...   rby.OptimalControlCommandBuilder()
    ...   .add_cartesian_target("base_link", "ee_right", T, translation_weight=1.0, rotation_weight=0.5)
    ...   .add_joint_position_target("right_arm_4", 0.4, weight=0.2)
    ...   .set_velocity_limit_scaling(0.8)
    ...   .set_acceleration_limit_scaling(0.6)
    ...   .set_error_scaling(1.0)
    ... )
    """
    def __init__(self) -> None:
        ...
    def add_cartesian_target(self, ref_link_name: str, link_name: str, T: numpy.ndarray[tuple[typing.Literal[4], typing.Literal[4]], numpy.dtype[numpy.float64]], translation_weight: float, rotation_weight: float) -> OptimalControlCommandBuilder:
        """
        Add a Cartesian pose target for a link.
        
        Parameters
        ----------
        ref_link_name : str
            Reference frame (link) name in which the target pose is expressed.
        link_name : str
            Controlled link name.
        T : numpy.ndarray, shape (4,4), dtype=float64
            Target homogeneous transform :math:`{}^{ref}\\!T^{link}_d`.
        translation_weight : float
            Weight :math:`w_t` for translational error.
        rotation_weight : float
            Weight :math:`w_r` for rotational error.
        
        Returns
        -------
        OptimalControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - The cost terms are typically of the form
        
          .. math::
        
              J_t = w_t \\, \\|\\, p_d - p \\,\\|^2, \\qquad
              J_r = w_r \\, \\|\\, r_d \\ominus r \\,\\|^2,
        
          where :math:`p` is position and :math:`r` is orientation (e.g., axis-angle error)
          of ``link_name`` measured in ``ref_link_name``.
        """
    def add_joint_position_target(self, joint_name: str, target_position: float, weight: float) -> OptimalControlCommandBuilder:
        """
        Add a joint position target.
        
        Parameters
        ----------
        joint_name : str
            Joint name.
        target_position : float
            Desired joint position :math:`q_d` [rad].
        weight : float
            Weight :math:`w_q` for this joint's position error.
        
        Returns
        -------
        OptimalControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - The joint cost term is:
        
          .. math::
        
              J_q \\;=\\; w_q \\,(q_d - q)^2 .
        """
    def set_acceleration_limit_scaling(self, acceleration_limit_scaling: float) -> OptimalControlCommandBuilder:
        """
        Scale internal joint acceleration limits used by the optimizer.
        
        Parameters
        ----------
        acceleration_limit_scaling : float
            Scaling factor :math:`\\alpha_a > 0`. The internal acceleration limits become
            :math:`\\alpha_a \\cdot a_{\\max}`.
        
        Returns
        -------
        OptimalControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - Like velocity scaling, this only affects internal optimization constraints.
        """
    def set_center_of_mass_target(self, ref_link_name: str, pose: numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]], weight: float) -> OptimalControlCommandBuilder:
        """
        Set a center-of-mass (COM) position target.
        
        Parameters
        ----------
        ref_link_name : str
            Reference frame (link) name for the COM target.
        pose : numpy.ndarray, shape (3,), dtype=float64
            Desired COM position :math:`c_d = [x,y,z]^\\\\top` in meters, expressed in ``ref_link_name``.
        weight : float
            Weight :math:`w_{\\mathrm{com}}` for COM position error.
        
        Returns
        -------
        OptimalControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - The COM cost is:
        
          .. math::
        
              J_{\\mathrm{com}} \\;=\\; w_{\\mathrm{com}} \\,\\|\\, c_d - c \\,\\|^2 .
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> OptimalControlCommandBuilder:
        """
        Attach a command header to this builder.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header configuration (e.g., control hold time).
        
        Returns
        -------
        OptimalControlCommandBuilder
            Self reference for method chaining.
        """
    def set_error_scaling(self, error_scaling: float) -> OptimalControlCommandBuilder:
        """
        Set a global error scaling applied to cost terms.
        
        Parameters
        ----------
        error_scaling : float
            A positive scalar multiplying error magnitudes internally (e.g., to balance
            different unit scales).
        
        Returns
        -------
        OptimalControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - Conceptually, this scales error vectors before squaring, e.g., :math:`e \\leftarrow \\alpha e`,
          which yields :math:`\\alpha^2` scaling on quadratic costs.
        """
    def set_min_delta_cost(self, min_delta_cost: float) -> OptimalControlCommandBuilder:
        """
        Set the minimum required improvement in cost between iterations.
        
        Parameters
        ----------
        min_delta_cost : float
            If the reduction :math:`\\Delta J` between iterations drops below this value,
            the optimizer may stop (convergence).
        
        Returns
        -------
        OptimalControlCommandBuilder
            Self reference for method chaining.
        """
    def set_patience(self, patience: int) -> OptimalControlCommandBuilder:
        """
        Set the iteration patience before stopping on small improvements.
        
        Parameters
        ----------
        patience : int
            Number of iterations to tolerate without sufficient cost improvement
            (in combination with ``set_min_delta_cost``).
        
        Returns
        -------
        OptimalControlCommandBuilder
            Self reference for method chaining.
        """
    def set_stop_cost(self, stop_cost: float) -> OptimalControlCommandBuilder:
        """
        Set the absolute objective threshold to consider the problem "solved".
        
        Parameters
        ----------
        stop_cost : float
            If the total cost :math:`J` falls below this value, the optimizer may terminate early.
        
        Returns
        -------
        OptimalControlCommandBuilder
            Self reference for method chaining.
        """
    def set_velocity_limit_scaling(self, velocity_limit_scaling: float) -> OptimalControlCommandBuilder:
        """
        Scale internal joint velocity limits used by the optimizer.
        
        Parameters
        ----------
        velocity_limit_scaling : float
            Scaling factor :math:`\\alpha_v > 0`. The internal velocity limits become
            :math:`\\alpha_v \\cdot v_{\\max}`.
        
        Returns
        -------
        OptimalControlCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - This does **not** change hardware limits; it affects only the optimization's
          internal constraints and trajectory shaping.
        """
class OptimalControlCommandFeedback(CommandFeedback):
    """
    
    Feedback for an optimal-control command.
    
    Attributes
    ----------
    total_cost : float
        Total objective value (dimensionless).
    cartesian_costs : list[float]
        Per-Cartesian-target costs (dimensionless).
    center_of_mass_cost : float
        Center-of-mass cost (dimensionless).
    joint_position_costs : list[float]
        Per-joint position costs (dimensionless).
    """
    def __init__(self) -> None:
        """
              Construct an ``OptimalControlCommandFeedback`` instance.
        """
    @property
    def cartesian_costs(self) -> list[float]:
        """
        Per-target Cartesian costs.
        
        Returns
        -------
        list[float]
            Dimensionless cost values for each Cartesian target.
        """
    @property
    def center_of_mass_cost(self) -> float:
        """
        Center-of-mass cost.
        
        Returns
        -------
        float
            Dimensionless COM cost.
        """
    @property
    def joint_position_costs(self) -> list[float]:
        """
        Per-joint position costs.
        
        Returns
        -------
        list[float]
            Dimensionless cost values for joint position terms.
        """
    @property
    def total_cost(self) -> float:
        """
        Total objective value.
        
        Returns
        -------
        float
            Dimensionless cost value.
        """
class PIDGain:
    """
    
    PID gain configuration.
    
    Represents proportional, integral, and derivative gains for PID control.
    
    Attributes
    ----------
    p_gain : int
        Proportional gain value.
    i_gain : int
        Integral gain value.
    d_gain : int
        Derivative gain value.
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Construct a PIDGain instance with default values.
        """
    @typing.overload
    def __init__(self, arg0: int, arg1: int, arg2: int) -> None:
        """
        Construct a PIDGain instance with specified values.
        
        Parameters
        ----------
        p_gain : int
            Proportional gain value.
        i_gain : int
            Integral gain value.
        d_gain : int
            Derivative gain value.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def d_gain(self) -> int:
        ...
    @property
    def i_gain(self) -> int:
        ...
    @property
    def p_gain(self) -> int:
        ...
class PowerInfo:
    """
    
    Power information
    
    Information about robot-controlled external (auxiliary) power outputs.
    
    Attributes
    ----------
    name : str
        Name/label of an externally controllable power output (e.g., "5v", "12v", "24v").
    """
    def __init__(self) -> None:
        """
        Construct an ``PowerInfo`` instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
class PowerState:
    """
    
      Power state information.
    
      Provides information about power supply status and voltage.
    
      Attributes
      ----------
      state : State
          Current power state.
      voltage : float
          Power supply voltage in volts.
      
    """
    class State:
        """
        
        Power state enumeration.
        
        Defines the possible power states.
        
        Members
        -------
        Unknown : int
            Power state is unknown.
        PowerOff : int
            Power is off.
        PowerOn : int
            Power is on.
        
        
        Members:
        
          Unknown
        
          PowerOff
        
          PowerOn
        """
        PowerOff: typing.ClassVar[PowerState.State]  # value = <State.PowerOff: 2>
        PowerOn: typing.ClassVar[PowerState.State]  # value = <State.PowerOn: 1>
        Unknown: typing.ClassVar[PowerState.State]  # value = <State.Unknown: 0>
        __members__: typing.ClassVar[dict[str, PowerState.State]]  # value = {'Unknown': <State.Unknown: 0>, 'PowerOff': <State.PowerOff: 2>, 'PowerOn': <State.PowerOn: 1>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        """
        Construct a ``PowerState`` instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def state(self) -> PowerState.State:
        ...
    @property
    def voltage(self) -> float:
        ...
class RobotCommandBuilder:
    """
    
    Robot command builder.
    
    Top-level builder that aggregates all types of commands into a single
    robot command.  
    It can wrap a **WholeBodyCommandBuilder**, **ComponentBasedCommandBuilder**, or
    **JogCommandBuilder**, and is the final object passed to
    ``robot.send_command(...)``.
    
    Notes
    -----
    - Typically, you do not build this manually for each subsystem.  
      Instead, construct subsystem builders (e.g., ComponentBasedCommandBuilder
      with body/head/mobility commands) and wrap them in RobotCommandBuilder.
    - Jog commands can also be wrapped directly for lightweight incremental motions.
    - Implicit casting is supported, so passing compatible builders automatically
      creates the appropriate wrapper.
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> # Example 1: Full stop
    >>> stop = rby.StopCommandBuilder()
    >>> whole = rby.WholeBodyCommandBuilder().set_command(stop)
    >>> rc = rby.RobotCommandBuilder().set_command(whole)
    >>> # robot.send_command(rc, priority=0).get()
    >>>
    >>> # Example 2: Move right arm with a joint position command
    >>> jp = rby.JointPositionCommandBuilder().set_position(np.zeros(7))
    >>> body = rby.BodyComponentBasedCommandBuilder().set_right_arm_command(jp)
    >>> comp = rby.ComponentBasedCommandBuilder().set_body_command(body)
    >>> rc = rby.RobotCommandBuilder().set_command(comp)
    >>> # robot.send_command(rc, priority=1).get()
    >>>
    >>> # Example 3: Send a jog command
    >>> jog = rby.JogCommandBuilder().set_joint_name("right_arm_0") \\
    ...     .set_command(rby.JogCommandBuilder.RelativePosition(0.1))
    >>> rc = rby.RobotCommandBuilder().set_command(jog)
    >>> # robot.send_command(rc, priority=1).get()
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Construct a RobotCommandBuilder instance.
        """
    @typing.overload
    def __init__(self, whole_body_command_builder: WholeBodyCommandBuilder) -> None:
        """
        Construct a RobotCommandBuilder from a WholeBodyCommandBuilder.
        
        Parameters
        ----------
        whole_body_command_builder : WholeBodyCommandBuilder
            Whole-body command wrapper.
        """
    @typing.overload
    def __init__(self, component_based_command_builder: ComponentBasedCommandBuilder) -> None:
        """
        Construct a RobotCommandBuilder from a ComponentBasedCommandBuilder.
        
        Parameters
        ----------
        component_based_command_builder : ComponentBasedCommandBuilder
            Component-based command wrapper (mobility, body, head).
        """
    @typing.overload
    def __init__(self, jog_command_builder: JogCommandBuilder) -> None:
        """
        Construct a RobotCommandBuilder from a JogCommandBuilder.
        
        Parameters
        ----------
        jog_command_builder : JogCommandBuilder
            Jog command wrapper for single-joint incremental motion.
        """
    @typing.overload
    def set_command(self, whole_body_command_builder: WholeBodyCommandBuilder) -> RobotCommandBuilder:
        """
        Assign a whole-body command.
        
        Parameters
        ----------
        whole_body_command_builder : WholeBodyCommandBuilder
            Command to apply to the entire robot.
        
        Returns
        -------
        RobotCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, component_based_command_builder: ComponentBasedCommandBuilder) -> RobotCommandBuilder:
        """
        Assign a component-based command.
        
        Parameters
        ----------
        component_based_command_builder : ComponentBasedCommandBuilder
            Command to apply to subsystems (mobility, body, head).
        
        Returns
        -------
        RobotCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, jog_command_builder: JogCommandBuilder) -> RobotCommandBuilder:
        """
        Assign a jog command.
        
        Parameters
        ----------
        jog_command_builder : JogCommandBuilder
            Jog command for single-joint incremental motion.
        
        Returns
        -------
        RobotCommandBuilder
            Self reference for method chaining.
        """
class RobotCommandFeedback(CommandFeedback):
    """
    
    Top-level feedback for a robot command.
    
    Attributes
    ----------
    whole_body_command : WholeBodyCommandFeedback
        Feedback for a whole-body command (if present).
    component_based_command : ComponentBasedCommandFeedback
        Feedback for a component-based command (if present).
    jog_command : JogCommandFeedback
        Feedback for a jog command (if present).
    status : RobotCommandFeedback.Status
        High-level status of the command execution.
    finish_code : RobotCommandFeedback.FinishCode
        Finish code indicating why execution finished (if finished).
    """
    class FinishCode:
        """
        
        Reason for finishing (if any).
        
        Members
        -------
        Unknown : int
            Unknown reason.
        Ok : int
            Finished successfully.
        Canceled : int
            Canceled by user/system.
        Preempted : int
            Preempted by another command.
        InitializationFailed : int
            Failed during initialization.
        ControlManagerIdle : int
            Control manager entered idle unexpectedly.
        ControlManagerFault : int
            Control manager reported a fault.
        UnexpectedState : int
            Reached an unexpected state.
        
        
        Members:
        
          Unknown
        
          Ok
        
          Canceled
        
          Preempted
        
          InitializationFailed
        
          ControlManagerIdle
        
          ControlManagerFault
        
          UnexpectedState
        """
        Canceled: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.Canceled: 2>
        ControlManagerFault: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.ControlManagerFault: 6>
        ControlManagerIdle: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.ControlManagerIdle: 5>
        InitializationFailed: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.InitializationFailed: 4>
        Ok: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.Ok: 1>
        Preempted: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.Preempted: 3>
        UnexpectedState: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.UnexpectedState: 7>
        Unknown: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.Unknown: 0>
        __members__: typing.ClassVar[dict[str, RobotCommandFeedback.FinishCode]]  # value = {'Unknown': <FinishCode.Unknown: 0>, 'Ok': <FinishCode.Ok: 1>, 'Canceled': <FinishCode.Canceled: 2>, 'Preempted': <FinishCode.Preempted: 3>, 'InitializationFailed': <FinishCode.InitializationFailed: 4>, 'ControlManagerIdle': <FinishCode.ControlManagerIdle: 5>, 'ControlManagerFault': <FinishCode.ControlManagerFault: 6>, 'UnexpectedState': <FinishCode.UnexpectedState: 7>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Status:
        """
        
        High-level execution status.
        
        Members
        -------
        Idle : int
            No command is active.
        Initializing : int
            Command is initializing.
        Running : int
            Command is running.
        Finished : int
            Command has finished.
        
        
        Members:
        
          Idle
        
          Initializing
        
          Running
        
          Finished
        """
        Finished: typing.ClassVar[RobotCommandFeedback.Status]  # value = <Status.Finished: 3>
        Idle: typing.ClassVar[RobotCommandFeedback.Status]  # value = <Status.Idle: 0>
        Initializing: typing.ClassVar[RobotCommandFeedback.Status]  # value = <Status.Initializing: 1>
        Running: typing.ClassVar[RobotCommandFeedback.Status]  # value = <Status.Running: 2>
        __members__: typing.ClassVar[dict[str, RobotCommandFeedback.Status]]  # value = {'Idle': <Status.Idle: 0>, 'Initializing': <Status.Initializing: 1>, 'Running': <Status.Running: 2>, 'Finished': <Status.Finished: 3>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        """
              Construct a ``RobotCommandFeedback`` instance.
        """
    @property
    def component_based_command(self) -> ComponentBasedCommandFeedback:
        """
        Component-based command feedback.
        
        Returns
        -------
        ComponentBasedCommandFeedback
            Feedback object (if present).
        """
    @property
    def finish_code(self) -> RobotCommandFeedback.FinishCode:
        """
        Finish reason (if finished).
        
        Returns
        -------
        RobotCommandFeedback.FinishCode
            One of :pydata:`RobotCommandFeedback.FinishCode`.
        """
    @property
    def jog_command(self) -> JogCommandFeedback:
        """
        Jog command feedback.
        
        Returns
        -------
        JogCommandFeedback
            Feedback object (if present).
        """
    @property
    def status(self) -> RobotCommandFeedback.Status:
        """
        High-level execution status.
        
        Returns
        -------
        RobotCommandFeedback.Status
            One of :pydata:`RobotCommandFeedback.Status`.
        """
    @property
    def whole_body_command(self) -> WholeBodyCommandFeedback:
        """
        Whole-body command feedback.
        
        Returns
        -------
        WholeBodyCommandFeedback
            Feedback object (if present).
        """
class RobotInfo:
    """
    
    Robot information and configuration.
    
    This class provides comprehensive information about the robot
    including version details, hardware configuration, and joint
    specifications.
    
    Attributes
    ----------
    version : str
        Robot software version.
    sdk_version : str
        SDK version.
    robot_version : str
        Robot version (deprecated, use robot_model_name instead).
    robot_model_name : str
        Name of the robot model.
    robot_model_version : str
        Version of the robot model.
    sdk_commit_id : str
        SDK commit identifier (deprecated, use sdk_version instead).
    battery_info : BatteryInfo
        Battery information.
    power_infos : list[PowerInfo]
        Robot-controlled external (auxiliary) power outputs (e.g., "5V", "12V", "24V").
    emo_infos : list[EMOInfo]
        List of emergency stop button information.
    degree_of_freedom : int
        Total number of degrees of freedom.
    joint_infos : list[JointInfo]
        List of joint information.
    mobility_joint_idx : list[int]
        Indices of mobility joints (e.g., wheels).
    body_joint_idx : list[int]
        Indices of body joints.
    head_joint_idx : list[int]
        Indices of head joints.
    torso_joint_idx : list[int]
        Indices of torso joints.
    right_arm_joint_idx : list[int]
        Indices of right arm joints.
    left_arm_joint_idx : list[int]
        Indices of left arm joints.
    """
    def __init__(self) -> None:
        """
        Construct a ``RobotInfo`` instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def battery_info(self) -> BatteryInfo:
        ...
    @property
    def body_joint_idx(self) -> list[int]:
        ...
    @property
    def degree_of_freedom(self) -> int:
        ...
    @property
    def emo_infos(self) -> list[EMOInfo]:
        ...
    @property
    def head_joint_idx(self) -> list[int]:
        ...
    @property
    def joint_infos(self) -> list[JointInfo]:
        ...
    @property
    def left_arm_joint_idx(self) -> list[int]:
        ...
    @property
    def mobility_joint_idx(self) -> list[int]:
        ...
    @property
    def power_infos(self) -> list[PowerInfo]:
        ...
    @property
    def right_arm_joint_idx(self) -> list[int]:
        ...
    @property
    def robot_model_name(self) -> str:
        ...
    @property
    def robot_model_version(self) -> str:
        ...
    @property
    def robot_version(self) -> str:
        ...
    @property
    def sdk_commit_id(self) -> str:
        ...
    @property
    def sdk_version(self) -> str:
        ...
    @property
    def torso_joint_idx(self) -> list[int]:
        ...
    @property
    def version(self) -> str:
        ...
class RobotState_A:
    """
    
    Robot state information.
    
    Provides information about the overall state of the robot, including system
    statistics, battery state, power states, emergency stop button states, joint
    states, tool flange states, force/torque sensor data, and odometry.
    
    Attributes
    ----------
    timestamp : datetime.datetime
        Timestamp of the robot state (system clock).
    system_stat : SystemStat
        System statistics (CPU, memory, uptimes).
    battery_state : BatteryState
        Battery voltage/current/level.
    power_states : list of PowerState
        Power supply states for each module.
    emo_states : list of EMOState
        Emergency-stop button states for each module.
    joint_states : list of JointState
        Per-joint status and measurements.
    
    tool_flange_right : ToolFlangeState
        Tool flange sensor and IO state for the right arm.
    tool_flange_left : ToolFlangeState
        Tool flange sensor and IO state for the left arm.
    ft_sensor_right : FTSensorData
        Force/torque readings on the right arm.
    ft_sensor_left : FTSensorData
        Force/torque readings on the left arm.
    
    is_ready : numpy.ndarray of bool, shape (DOF,)
        Whether each joint is ready.
    position : numpy.ndarray, shape (DOF,)
        Joint positions [rad].
    velocity : numpy.ndarray, shape (DOF,)
        Joint velocities [rad/s].
    current : numpy.ndarray, shape (DOF,)
        Joint currents [A].
    torque : numpy.ndarray, shape (DOF,)
        Joint torques in Nm.
    
    target_position : numpy.ndarray, shape (DOF,)
        Target joint positions [rad].
    target_velocity : numpy.ndarray, shape (DOF,)
        Target joint velocities [rad/s].
    target_feedback_gain : numpy.ndarray, shape (DOF,)
        Target feedback gains per joint. Range is [0, 10].
    target_feedforward_torque : numpy.ndarray, shape (DOF,)
        Target feedforward torques per joint in Nm.
    
    odometry : numpy.ndarray, shape (3, 3)
        Base pose as a 2D homogeneous transform (SE(2)): rotation (R) and translation (t).
    center_of_mass : numpy.ndarray, shape (3,)
        Center of mass position in base frame in meters.
    
    collisions : list of CollisionResult
        Detected collisions or nearest link pairs (links, closest points, signed distance).
    temperature : numpy.ndarray, shape (DOF,)
        Joint temperatures in degrees Celsius.
    gravity : numpy.ndarray, shape (DOF,)
        Gravity compensation torques per joint in Nm.
    
    Notes
    -----
    Unless noted otherwise, joint-wise vectors are NumPy arrays with shape ``(DOF,)``,
    where ``DOF = robot.model().robot_dof``.
    ``odometry`` uses a 2D homogeneous transform (SE(2)).
    ``signed distance`` is negative when penetrating.
    """
    def __init__(self) -> None:
        """
        Construct a RobotState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def battery_state(self) -> BatteryState:
        ...
    @property
    def center_of_mass(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def collisions(self) -> list[dynamics.CollisionResult]:
        ...
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def emo_states(self) -> list[EMOState]:
        ...
    @property
    def ft_sensor_left(self) -> FTSensorData:
        ...
    @property
    def ft_sensor_right(self) -> FTSensorData:
        ...
    @property
    def gravity(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        ...
    @property
    def joint_states(self) -> typing.Annotated[list[JointState], pybind11_stubgen.typing_ext.FixedSize(24)]:
        ...
    @property
    def odometry(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[3]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def power_states(self) -> list[PowerState]:
        ...
    @property
    def system_stat(self) -> SystemStat:
        ...
    @property
    def target_feedback_gain(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.uint32]]:
        ...
    @property
    def target_feedforward_torque(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def target_position(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def target_velocity(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def temperature(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.int32]]:
        ...
    @property
    def timestamp(self) -> datetime.datetime:
        ...
    @property
    def tool_flange_left(self) -> ToolFlangeState:
        ...
    @property
    def tool_flange_right(self) -> ToolFlangeState:
        ...
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
class RobotState_M:
    """
    
    Robot state information.
    
    Provides information about the overall state of the robot, including system
    statistics, battery state, power states, emergency stop button states, joint
    states, tool flange states, force/torque sensor data, and odometry.
    
    Attributes
    ----------
    timestamp : datetime.datetime
        Timestamp of the robot state (system clock).
    system_stat : SystemStat
        System statistics (CPU, memory, uptimes).
    battery_state : BatteryState
        Battery voltage/current/level.
    power_states : list of PowerState
        Power supply states for each module.
    emo_states : list of EMOState
        Emergency-stop button states for each module.
    joint_states : list of JointState
        Per-joint status and measurements.
    
    tool_flange_right : ToolFlangeState
        Tool flange sensor and IO state for the right arm.
    tool_flange_left : ToolFlangeState
        Tool flange sensor and IO state for the left arm.
    ft_sensor_right : FTSensorData
        Force/torque readings on the right arm.
    ft_sensor_left : FTSensorData
        Force/torque readings on the left arm.
    
    is_ready : numpy.ndarray of bool, shape (DOF,)
        Whether each joint is ready.
    position : numpy.ndarray, shape (DOF,)
        Joint positions [rad].
    velocity : numpy.ndarray, shape (DOF,)
        Joint velocities [rad/s].
    current : numpy.ndarray, shape (DOF,)
        Joint currents [A].
    torque : numpy.ndarray, shape (DOF,)
        Joint torques in Nm.
    
    target_position : numpy.ndarray, shape (DOF,)
        Target joint positions [rad].
    target_velocity : numpy.ndarray, shape (DOF,)
        Target joint velocities [rad/s].
    target_feedback_gain : numpy.ndarray, shape (DOF,)
        Target feedback gains per joint. Range is [0, 10].
    target_feedforward_torque : numpy.ndarray, shape (DOF,)
        Target feedforward torques per joint in Nm.
    
    odometry : numpy.ndarray, shape (3, 3)
        Base pose as a 2D homogeneous transform (SE(2)): rotation (R) and translation (t).
    center_of_mass : numpy.ndarray, shape (3,)
        Center of mass position in base frame in meters.
    
    collisions : list of CollisionResult
        Detected collisions or nearest link pairs (links, closest points, signed distance).
    temperature : numpy.ndarray, shape (DOF,)
        Joint temperatures in degrees Celsius.
    gravity : numpy.ndarray, shape (DOF,)
        Gravity compensation torques per joint in Nm.
    
    Notes
    -----
    Unless noted otherwise, joint-wise vectors are NumPy arrays with shape ``(DOF,)``,
    where ``DOF = robot.model().robot_dof``.
    ``odometry`` uses a 2D homogeneous transform (SE(2)).
    ``signed distance`` is negative when penetrating.
    """
    def __init__(self) -> None:
        """
        Construct a RobotState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def battery_state(self) -> BatteryState:
        ...
    @property
    def center_of_mass(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def collisions(self) -> list[dynamics.CollisionResult]:
        ...
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def emo_states(self) -> list[EMOState]:
        ...
    @property
    def ft_sensor_left(self) -> FTSensorData:
        ...
    @property
    def ft_sensor_right(self) -> FTSensorData:
        ...
    @property
    def gravity(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        ...
    @property
    def joint_states(self) -> typing.Annotated[list[JointState], pybind11_stubgen.typing_ext.FixedSize(26)]:
        ...
    @property
    def odometry(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[3]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def power_states(self) -> list[PowerState]:
        ...
    @property
    def system_stat(self) -> SystemStat:
        ...
    @property
    def target_feedback_gain(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.uint32]]:
        ...
    @property
    def target_feedforward_torque(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def target_position(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def target_velocity(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def temperature(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.int32]]:
        ...
    @property
    def timestamp(self) -> datetime.datetime:
        ...
    @property
    def tool_flange_left(self) -> ToolFlangeState:
        ...
    @property
    def tool_flange_right(self) -> ToolFlangeState:
        ...
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
class RobotState_UB:
    """
    
    Robot state information.
    
    Provides information about the overall state of the robot, including system
    statistics, battery state, power states, emergency stop button states, joint
    states, tool flange states, force/torque sensor data, and odometry.
    
    Attributes
    ----------
    timestamp : datetime.datetime
        Timestamp of the robot state (system clock).
    system_stat : SystemStat
        System statistics (CPU, memory, uptimes).
    battery_state : BatteryState
        Battery voltage/current/level.
    power_states : list of PowerState
        Power supply states for each module.
    emo_states : list of EMOState
        Emergency-stop button states for each module.
    joint_states : list of JointState
        Per-joint status and measurements.
    
    tool_flange_right : ToolFlangeState
        Tool flange sensor and IO state for the right arm.
    tool_flange_left : ToolFlangeState
        Tool flange sensor and IO state for the left arm.
    ft_sensor_right : FTSensorData
        Force/torque readings on the right arm.
    ft_sensor_left : FTSensorData
        Force/torque readings on the left arm.
    
    is_ready : numpy.ndarray of bool, shape (DOF,)
        Whether each joint is ready.
    position : numpy.ndarray, shape (DOF,)
        Joint positions [rad].
    velocity : numpy.ndarray, shape (DOF,)
        Joint velocities [rad/s].
    current : numpy.ndarray, shape (DOF,)
        Joint currents [A].
    torque : numpy.ndarray, shape (DOF,)
        Joint torques in Nm.
    
    target_position : numpy.ndarray, shape (DOF,)
        Target joint positions [rad].
    target_velocity : numpy.ndarray, shape (DOF,)
        Target joint velocities [rad/s].
    target_feedback_gain : numpy.ndarray, shape (DOF,)
        Target feedback gains per joint. Range is [0, 10].
    target_feedforward_torque : numpy.ndarray, shape (DOF,)
        Target feedforward torques per joint in Nm.
    
    odometry : numpy.ndarray, shape (3, 3)
        Base pose as a 2D homogeneous transform (SE(2)): rotation (R) and translation (t).
    center_of_mass : numpy.ndarray, shape (3,)
        Center of mass position in base frame in meters.
    
    collisions : list of CollisionResult
        Detected collisions or nearest link pairs (links, closest points, signed distance).
    temperature : numpy.ndarray, shape (DOF,)
        Joint temperatures in degrees Celsius.
    gravity : numpy.ndarray, shape (DOF,)
        Gravity compensation torques per joint in Nm.
    
    Notes
    -----
    Unless noted otherwise, joint-wise vectors are NumPy arrays with shape ``(DOF,)``,
    where ``DOF = robot.model().robot_dof``.
    ``odometry`` uses a 2D homogeneous transform (SE(2)).
    ``signed distance`` is negative when penetrating.
    """
    def __init__(self) -> None:
        """
        Construct a RobotState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def battery_state(self) -> BatteryState:
        ...
    @property
    def center_of_mass(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def collisions(self) -> list[dynamics.CollisionResult]:
        ...
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def emo_states(self) -> list[EMOState]:
        ...
    @property
    def ft_sensor_left(self) -> FTSensorData:
        ...
    @property
    def ft_sensor_right(self) -> FTSensorData:
        ...
    @property
    def gravity(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        ...
    @property
    def joint_states(self) -> typing.Annotated[list[JointState], pybind11_stubgen.typing_ext.FixedSize(18)]:
        ...
    @property
    def odometry(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[3]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def power_states(self) -> list[PowerState]:
        ...
    @property
    def system_stat(self) -> SystemStat:
        ...
    @property
    def target_feedback_gain(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.uint32]]:
        ...
    @property
    def target_feedforward_torque(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def target_position(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def target_velocity(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def temperature(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.int32]]:
        ...
    @property
    def timestamp(self) -> datetime.datetime:
        ...
    @property
    def tool_flange_left(self) -> ToolFlangeState:
        ...
    @property
    def tool_flange_right(self) -> ToolFlangeState:
        ...
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
class Robot_A:
    """
    Robot (model: ``Model_A``) control interface.
    
    Provides high-level control interface for robot operations including
    connection management, power control, and command execution.
    
    Attributes
    ----------
    model : Model_A
        Robot model configuration.
    """
    @staticmethod
    def create(address: str) -> Robot_A:
        """
        Create a robot instance.
        
        Parameters
        ----------
        address : str
            Robot network address, e.g. "192.168.1.100:50051".
        
        Returns
        -------
        Robot
            Robot instance.
        
        Examples
        --------
        >>> import rby1_sdk
        >>> robot = rby.Robot_A.create("192.168.30.1:50051")
        >>> robot.connect()
        >>> if robot.is_connected():
        ...     print("Robot connected successfully")
        ...     robot_info = robot.get_robot_info()
        ...     print(f"Robot model: {robot.model().model_name}")
        ...     # Note: Model A has mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        ...     # Total joints: 2 + 6 + 7 + 7 + 2 = 24 DOF for model A
        """
    @staticmethod
    def model() -> Model_A:
        """
        Get the robot model configuration.
        
        Returns
        -------
        Model_A
            Robot model configuration object.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def break_engage(self, dev_name: str) -> bool:
        """
        Engage the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to engage brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Engage brake for manitance
        >>> robot.break_engage("right_arm_0")
        """
    def break_release(self, dev_name: str) -> bool:
        """
        break_release(dev_name)
        
        Release the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to release brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Release brake to allow movement
        >>> robot.break_release("right_arm_0")
        """
    def cancel_control(self) -> bool:
        """
        Cancel current control operation.
        """
    def connect(self, max_retries: int = 5, timeout_ms: int = 1000) -> bool:
        """
        Attempts to establish a connection with the robot.
        
        Parameters
        ----------
        max_retries : int, optional
            Maximum number of retries to connect. Default is 5.
        timeout_ms : int, optional
            Timeout in milliseconds for each connection attempt. Default is 1000.
        
        Returns
        -------
        bool
            ``True`` if the connection was successful, ``False`` otherwise.
        
        Examples
        --------
        >>> robot = rby1_sdk.create_robot("192.168.1.100", "a")
        >>> if robot.connect():
        ...     print("Connected to robot")
        ... else:
        ...     print("Failed to connect")
        >>> # Default: max_retries=5, timeout_ms=1000
        >>> # Custom: robot.connect(max_retries=10, timeout_ms=2000)
        """
    def connect_wifi(self, ssid: str, password: str = '', use_dhcp: bool = True, ip_address: str = '', gateway: str = '', dns: list[str] = []) -> bool:
        """
        Connect to WiFi network.
        
        Parameters
        ----------
        ssid : str
            WiFi network name.
        password : str, optional
            WiFi password. Default is empty string.
        use_dhcp : bool, optional
            Use DHCP. Default is True.
        ip_address : str, optional
            Static IP address. Default is empty string.
        gateway : str, optional
            Gateway address. Default is empty string.
        dns : list[str], optional
            DNS servers. Default is empty string.
        
        Examples
        --------
        >>> # Connect using DHCP (automatic IP)
        >>> robot.connect_wifi("MyWiFi", "mypassword123")
        >>> # Connect with static IP configuration
        >>> robot.connect_wifi("MyWiFi", "mypassword123", use_dhcp=False,
        ...                    ip_address="192.168.1.100/24", gateway="192.168.1.1")
        >>> # Connect to open network
        >>> robot.connect_wifi("OpenNetwork")
        >>> # Check connection status
        >>> status = robot.get_wifi_status()
        >>> print(f"Connected: {status.connected}, SSID: {status.ssid}")
        """
    def control(self, control: typing.Callable[[Robot_A_ControlState], Robot_A_ControlInput], port: int = 0, priority: int = 1) -> bool:
        """
        Start a **blocking** real-time control loop using a custom control callback.
        
        This function runs a UDP-based real-time loop that repeatedly calls the user-provided
        ``control(ControlState) -> ControlInput``. The loop exits when the callback returns a
        ``ControlInput`` with ``finish=True``, or when an error/abort occurs. The function
        returns ``True`` only if it finished via ``finish=True``; otherwise ``False``.
        
        Parameters
        ----------
        control : callable
            A callable that accepts a ``ControlState`` and returns a ``ControlInput``.
            The callback is invoked for each received RT state packet.
        port : int, optional
            UDP port to bind for the RT server. Use ``0`` to let the OS choose an available port
            (recommended). Default is ``0``.
        priority : int, optional
            Command priority sent with the RT control request. Default is ``1``.
        
        Returns
        -------
        bool
            ``True`` if the loop terminated because the callback set ``finish=True`` in
            ``ControlInput``. ``False`` if the loop ended due to an error or abort
            (e.g., UDP bind failure, connection issue).
        
        Notes
        -----
        - **Blocking:** This call blocks until the control loop ends. There is no handler for
          external cancellation. Design the callback to set ``finish=True`` when you want to stop.
        - **GIL behavior:** The function releases the Python GIL around I/O and reacquires it
          only when invoking your Python callback, allowing other Python threads to run between
          callbacks.
        - **Performance:** Keep the callback lightweight—avoid long computations or blocking I/O
          inside the callback to maintain RT responsiveness.
        - **State fields:** The provided ``ControlState`` includes timestamp ``t``, and arrays 
          such as ``position``, ``velocity``, ``current``, and ``torque`` for all DoFs of the robot.
        - **Errors:** If the UDP server fails to bind (e.g., port unavailable), the function
          returns ``False`` immediately (and prints the error to ``stderr``).
        
        Examples
        --------
        >>> import numpy as np
        >>> 
        >>> # Stop after ~2 seconds using state.t
        >>> t0 = {"t": None}
        >>> def control_fn(state):
        ...     if t0["t"] is None:
        ...         t0["t"] = state.t
        ...     finish = (state.t - t0["t"]) >= 2.0
        ...     i = ControlInput()
        ...     i.mode.fill(rby.ControlMode.Position)
        ...     i.target = np.zeros_like(state.position)   # hold home
        ...     i.feedback_gain.fill(10)                   # simple P gain
        ...     i.feedforward_torque.fill(0)               # no torque feedforward
        ...     i.finish = finish
        ...     return i
        >>> ok = robot.control(control_fn)
        >>> print(ok)   # True if finished via finish=True
        """
    def create_command_stream(self, priority: int = 1) -> Robot_A_CommandStreamHandler:
        """
        Create a command stream for continuous command sending.
        
        Parameters
        ----------
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandStreamHandler
            Command stream handler.
        
        Examples
        --------
        >>> # Create command stream for continuous operation
        >>> stream_handler = robot.create_command_stream(priority=1)
        >>> # Send commands continuously
        >>> for i in range(10):
        ...     command_builder = create_command(i)
        ...     stream_handler.send_command(command_builder, timeout_ms=1000)
        ...     time.sleep(1)
        >>> # Through the handler, you can terminate control or check the current state
        >>> stream_handler.cancel()
        >>> # See examples/python/cartesian_command_stream.py for complete usage
        """
    def disable_control_manager(self) -> bool:
        """
        Disable the control manager.
        """
    def disconnect(self) -> None:
        """
        Disconnects from the robot.
        """
    def disconnect_wifi(self) -> bool:
        """
        Disconnect from WiFi network.
        """
    def download_file(self, path: str, file_like: typing.Any) -> bool:
        """
        Downloads a file from the robot and writes it into a file-like object.
        
        Parameters
        ----------
        path : str
            Relative path to the file on the robot's file system.
            The base directory is defined by the `RBY1_HOME` environment variable (default: `/root/.rby1`).
        file_like : file-like object
            Any object with a `.write(bytes)` method (e.g., `io.BytesIO`, a real file).
        
        Returns
        -------
        bool
            ``True`` if the file was downloaded successfully.
        
        Raises
        ------
        RuntimeError
            If the gRPC call fails (e.g., network issue, file not found, internal error).
        """
    def enable_control_manager(self, unlimited_mode_enabled: bool = False) -> bool:
        """
        Enable the control manager.
        
        Parameters
        ----------
        unlimited_mode_enabled : bool, optional
            Whether to enable unlimited mode. Default is False.
        
        Examples
        --------
        >>> # Enable control manager for robot control
        >>> robot.enable_control_manager()
        >>> # Enable with unlimited mode (use with caution)
        >>> robot.enable_control_manager(unlimited_mode_enabled=True)
        >>> # Must be called before sending commands
        """
    def factory_reset_all_parameters(self) -> None:
        """
        Factory reset all parameters to their default values.
        """
    def factory_reset_parameter(self, name: str) -> bool:
        """
        Factory reset a parameter to its default value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def get_control_manager_state(self) -> ControlManagerState:
        """
        Get control manager state.
        
        Returns
        -------
        ControlManagerState
            Current control manager state.
        
        Examples
        --------
        >>> # Get control manager state
        >>> ctrl_state = robot.get_control_manager_state()
        >>> print(f"Control Manager state: {ctrl_state.state}")
        >>> print(f"Control state: {ctrl_state.control_state}")
        >>> # Check if control manager is enabled
        >>> if ctrl_state.state == rby1_sdk.ControlManagerState.State.Enabled:
        ...     print("Control manager is enabled")
        """
    def get_dynamics(self, urdf_model: str = '') -> dynamics.Robot_24:
        """
        Get robot dynamics model.
        
        Parameters
        ----------
        urdf_model : str, optional
            URDF model path. Default is empty string.
        
        Returns
        -------
        dyn.Robot
            Robot dynamics model.
        
        Examples
        --------
        >>> # Get dynamics model with the model from connected robot
        >>> dynamics_robot = robot.get_dynamics()
        >>> # Get dynamics model with custom URDF
        >>> dynamics_robot = robot.get_dynamics("/path/to/custom.urdf")
        >>> # Useful for advanced control algorithms
        """
    def get_fault_log_list(self) -> list[str]:
        """
        Get fault log list.
        
        Returns
        -------
        list
            List of fault log entries.
        """
    def get_head_position_pid_gains(self) -> list[PIDGain]:
        """
        Get head position PID gains.
        
        Returns
        -------
        PIDGain
            Head position PID gains.
        """
    def get_last_log(self, count: int) -> list[Log]:
        """
        Get last log entries.
        
        Parameters
        ----------
        count : int
            Number of log entries to retrieve.
        
        Returns
        -------
        list
            List of log entries.
        """
    def get_left_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        Get left arm position PID gains.
        
        Returns
        -------
        PIDGain
            Left arm position PID gains.
        """
    def get_parameter(self, name: str) -> str:
        """
        Retrieve a robot parameter.
        
        Parameters
        ----------
        name : str
            Name of the parameter to retrieve.
        
        Returns
        -------
        any
            Parameter value.
            Returned as a JSON value: numeric values are returned as-is, strings are enclosed in quotes ("...").
        
        Examples
        --------
        >>> # Retrieve current parameter values
        >>> acc_scaling = robot.get_parameter("default.acceleration_limit_scaling")
        >>> cutoff_freq = robot.get_parameter("joint_position_command.cutoff_frequency")
        >>> model_name = robot.get_parameter("robot_model_name")
        >>> print(f"Acceleration scaling: {acc_scaling}")
        >>> print(f"Cutoff frequency: {cutoff_freq}")
        >>> print(f"Model name: {model_name}")
        """
    def get_parameter_list(self) -> list[tuple[str, int]]:
        """
        Get list of available parameters.
        
        Returns
        -------
        list
            List of parameter names.
        
        Examples
        --------
        >>> # Get all available parameters
        >>> param_list = robot.get_parameter_list()
        >>> print(f"Total parameters: {len(param_list)}")
        >>> # List common parameter categories
        >>> for param in param_list:
        ...     if param[0].startswith("default."):
        ...         print(f"Default param: {param}")
        ...     elif param[0].startswith("joint_position_command."):
        ...         print(f"Joint position param: {param}")
        >>> # Common categories: default.*, joint_position_command.*, cartesian_command.*
        """
    def get_position_pid_gain(self, dev_name: str) -> PIDGain:
        """
        Get position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        
        Returns
        -------
        PIDGain
            Position PID gains for the device.
        
        Examples
        --------
        >>> # Get PID gains for specific device
        >>> torso_pid = robot.get_position_pid_gain("torso_5")
        >>> print(f"Torso 5 P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> # Get PID gains for arm
        >>> arm_pid = robot.get_position_pid_gain("right_arm_0")
        >>> print(f"Right arm 0 P: {arm_pid.p_gain}")
        >>> devices = ["torso_5", "right_arm_0", "left_arm_1", "head_0"]
        >>> for device in devices:
        ...     pid = robot.get_position_pid_gain(device)
        ...     print(f"{device}: P={pid.p_gain}, I={pid.i_gain}, D={pid.d_gain}")
        """
    def get_right_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        Get right arm position PID gains.
        
        Returns
        -------
        PIDGain
            Right arm position PID gains.
        """
    def get_robot_info(self) -> RobotInfo:
        """
        Retrieves static information about the robot, such as model name, SDK version, and joint configuration.
        
        Returns
        -------
        RobotInfo
            Structured metadata including joint details, device names, and robot model information.
        
        Examples
        --------
        >>> # Get robot information
        >>> robot_info = robot.get_robot_info()
        >>> print(f"SDK version: {robot_info.sdk_version}")
        >>> print(f"Robot model name: {robot_info.robot_model_name}")
        >>> print(f"Robot model version: {robot_info.robot_model_version}")
        >>> print(f"Joint count: {len(robot_info.joint_infos)}")
        >>> # Access joint information
        >>> for joint in robot_info.joint_infos:
        ...     print(f"Joint: {joint.name}, Brake: {joint.has_brake}, Product name: {joint.product_name}, Firmware version: {joint.firmware_version}")
        """
    def get_robot_model(self) -> str:
        """
        Get the current robot URDF model.
        
        Returns
        -------
        RobotModel
            Current robot model.
        """
    def get_serial_device_list(self) -> list[SerialDevice]:
        """
        Get list of available serial devices on the robot.
        
        Returns
        -------
        list
            List of available serial devices.
        
        Examples
        --------
        >>> # Get available serial devices
        >>> devices = robot.get_serial_device_list()
        >>> print(f"Found {len(devices)} serial devices")
        >>> # List device information
        >>> for device in devices:
        ...     print(f"Path: {device.path}, Description: {device.description}")
        >>> # Open serial stream to first device
        >>> if devices:
        ...     stream = robot.open_serial_stream(devices[0].path, 115200)
        >>> # Common device paths: /dev/ttyUSB0, /dev/ttyACM0, COM1, COM2
        """
    def get_state(self) -> RobotState_A:
        """
        Get current robot state.
        
        Returns
        -------
        RobotState
            Current robot state.
        
        Examples
        --------
        >>> robot_state = robot.get_state()
        >>> model = robot.model()
        >>> print(f"Joint positions: {robot_state.position}")
        >>> print(f"Right arm position: {robot_state.position[model.right_arm_idx]}")
        >>> # Note: Joint positions include mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        >>> # Total: 24 DOF for model A, 23 DOF for model M, 26 DOF for model M, 18 DOF for model UB
        """
    def get_system_time(self) -> tuple[typing.Any, str]:
        """
        Get robot system time.
        
        Returns
        -------
        tuple
            (datetime, str): Robot system time and local time string.
        """
    def get_time_scale(self) -> float:
        """
        Get the current time scale.
        
        Returns
        -------
        float
            Current time scale value.
        
        Examples
        --------
        >>> # Get current time scale
        >>> current_scale = robot.get_time_scale()
        >>> print(f"Current time scale: {current_scale}")
        >>> # Check if robot is running at full speed
        >>> if current_scale == 1.0:
        ...     print("Robot running at full speed")
        >>> # Check if robot is slowed down
        >>> elif current_scale < 1.0:
        ...     print(f"Robot running at {current_scale * 100}% speed")
        """
    def get_torso_position_pid_gains(self) -> list[PIDGain]:
        """
        Get torso position PID gains.
        
        Returns
        -------
        PIDGain
            Torso position PID gains.
        
        Examples
        --------
        >>> # Get current PID gains for torso
        >>> torso_pid = robot.get_torso_position_pid_gains()[0]  # Get first (and only) torso device
        >>> print(f"Torso P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> right_arm_pid = robot.get_right_arm_position_pid_gains()[0]
        >>> print(f"Right arm: {right_arm_pid}")
        """
    def get_wifi_status(self) -> WifiStatus | None:
        """
        Get WiFi connection status.
        
        Returns
        -------
        WifiStatus
            Current WiFi status.
        """
    def has_established_time_sync(self) -> bool:
        """
        Check if time synchronization is established.
        
        Returns
        -------
        bool
            True if time sync is established, False otherwise.
        """
    def home_offset_reset(self, dev_name: str) -> bool:
        """
        Reset home offset for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to reset home offset. Supports regex patterns.
        """
    def import_robot_model(self, name: str, model: str) -> bool:
        """
        Import a robot model.
        
        Parameters
        ----------
        name : str
            Model name.
        model : RobotModel
            Robot model to import.
        """
    def is_connected(self) -> bool:
        """
        Checks whether the robot is currently connected.
        
        Returns
        -------
        bool
            ``True`` if the robot is connected to the robot, ``False`` otherwise.
        """
    def is_power_on(self, dev_name: str) -> bool:
        """
        Check if a device is powered on.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if device is powered on, ``False`` otherwise.
        """
    def is_servo_on(self, dev_name: str) -> bool:
        """
        Check if servo control is enabled for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if servo control is enabled, ``False`` otherwise.
        """
    def open_serial_stream(self, device_path: str, baudrate: int, bytesize: int = 8, parity: str = 'N', stopbits: int = 1) -> SerialStream:
        """
        Open a serial stream.
        
        Parameters
        ----------
        device_path : str
            Path to serial device.
        baudrate : int
            Baud rate.
        bytesize : int, optional
            Data bits. Default is 8.
        parity : str, optional
            Parity setting. Default is 'N'.
        stopbits : int, optional
            Stop bits. Default is 1.
        
        Returns
        -------
        SerialStream
            Serial stream object.
        
        Examples
        --------
        >>> # Open serial stream with default settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB0", 115200)
        >>> # Open with custom settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB1", 9600, bytesize=7, parity='E', stopbits=2)
        >>> # Common baudrates: 9600, 19200, 38400, 57600, 115200
        >>> # Parity: 'N' (none), 'E' (even), 'O' (odd)
        >>> # Stop bits: 1, 2
        """
    def power_off(self, dev_name: str) -> bool:
        """
        Power off a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power off. Supports regex patterns.
        """
    def power_on(self, dev_name: str) -> bool:
        """
        Power on a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power on. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_power_on(".*"):
        ...     robot.power_on(".*")
        ...     print("Robot powered on")
        >>> # Pattern ".*" powers on all devices
        >>> # Specific device: robot.power_on("12v"), robot.power_on("24v"), etc.
        """
    def reset_all_parameters(self) -> None:
        """
        Reset all parameters to their current values.
        """
    def reset_all_parameters_to_default(self) -> None:
        """
        Reset all parameters to their default values (deprecated).
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_all_parameters` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_all_parameters() instead.
        """
    def reset_battery_config(self) -> bool:
        """
        Reset battery configuration to default.
        """
    def reset_fault_control_manager(self) -> bool:
        """
        Reset fault in the control manager.
        """
    def reset_network_setting(self) -> bool:
        """
        Reset network settings to default.
        """
    def reset_odometry(self, angle: float, position: numpy.ndarray[tuple[typing.Literal[2], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> bool:
        """
        reset_odometry(angle, position)
        
        Reset odometry to specified values.
        
        Parameters
        ----------
        angle : float
            New angle [rad].
        position : numpy.ndarray
            New position [m].
        
        Examples
        --------
        >>> import numpy as np
        >>> # Reset odometry to origin
        >>> robot.reset_odometry(angle=0.0, position=np.array([0.0, 0.0]))
        >>> # Reset to specific position and orientation
        >>> robot.reset_odometry(angle=np.pi/2, position=np.array([1.0, 2.0]))
        >>> # Useful for mobile base navigation
        >>> # Position is [x, y] in meters, angle is yaw in rad
        """
    def reset_parameter(self, name: str) -> bool:
        """
        Reset a parameter to its current value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def reset_parameter_to_default(self, name: str) -> bool:
        """
        Reset a parameter to its default value (deprecated).
        
        Parameters
        ----------
        name : str
            Parameter name.
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_parameter` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_parameter() instead.
        """
    def scan_wifi(self) -> list[WifiNetwork]:
        """
        Scan for available WiFi networks.
        
        Returns
        -------
        list
            List of available WiFi networks.
        
        Examples
        --------
        >>> # Scan for available WiFi networks
        >>> networks = robot.scan_wifi()
        >>> print(f"Found {len(networks)} networks")
        >>> # List network information
        >>> for network in networks:
        ...     print(f"SSID: {network.ssid}, Signal: {network.signal_strength}")
        >>> # Connect to a network
        >>> if networks:
        ...     robot.connect_wifi(networks[0].ssid, "password")
        """
    def send_command(self, builder: RobotCommandBuilder, priority: int = 1) -> Robot_A_CommandHandler:
        """
        Send a command to the robot.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandHandler
            Command handler for monitoring execution.
        
        Examples
        --------
        >>> from rby1_sdk import RobotCommandBuilder, ComponentBasedCommandBuilder
        >>> from rby1_sdk import BodyComponentBasedCommandBuilder, JointPositionCommandBuilder
        >>> # Create command with method chaining (standard pattern)
        >>> command = RobotCommandBuilder().set_command(
        ...     ComponentBasedCommandBuilder().set_body_command(
        ...         BodyComponentBasedCommandBuilder()
        ...             .set_torso_command(
        ...                 JointPositionCommandBuilder()
        ...                     .set_position([0, 0, 0, 0, 0, 0])  # 6-DOF torso
        ...                     .set_minimum_time(2.0)
        ...             )
        ...     )
        ... )
        >>> handler = robot.send_command(command)
        >>> handler.wait()  # Wait for completion
        >>> # This pattern is used in most examples: examples/python/07_impedance_control.py, 09_demo_motion.py, etc.
        """
    def servo_off(self, dev_name: str) -> bool:
        """
        Disable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to disable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> # Disable servo control for safety
        >>> robot.servo_off(".*")  # All motor drivers
        >>> # Specific device: robot.servo_off("^torso_.*")
        """
    def servo_on(self, dev_name: str) -> bool:
        """
        Enable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to enable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_servo_on(".*"):
        ...     robot.servo_on(".*")  # Servo on all devices
        ...     print("All devices servoed on")
        >>> # Specific device: robot.servo_on("^torso_.*"), robot.servo_on("^right_arm_.*"), etc.
        """
    def set_battery_config(self, cutoff_voltage: float, fully_charged_voltage: float, coefficients: typing.Annotated[list[float], pybind11_stubgen.typing_ext.FixedSize(4)]) -> bool:
        """
        Set battery configuration.
        """
    def set_battery_level(self, arg0: float) -> bool:
        """
        Set battery level.
        
        Parameters
        ----------
        level : float
            Battery level percentage (0.0 to 100.0).
        
        Examples
        --------
        >>> # Set battery level for testing
        >>> robot.set_battery_level(100.0)  # Full battery
        >>> robot.set_battery_level(50.0)   # Half battery
        >>> robot.set_battery_level(25.0)   # Quarter battery
        >>> robot.set_battery_level(0.0)    # Empty battery
        >>> # Range: 0.0 to 100.0
        >>> # Useful for using custom battery
        """
    def set_led_color(self, color: Color, duration: float = 1, transition_time: float = 0, blinking: bool = False, blinking_freq: float = 1) -> bool:
        """
        Set LED color.
        
        Parameters
        ----------
        color : Color
            LED color.
        duration : float, optional
            Duration in seconds. Default is 1.
        transition_time : float, optional
            Transition time in seconds. Default is 0.
        blinking : bool, optional
            Whether to blink. Default is False.
        blinking_freq : float, optional
            Blinking frequency in Hz. Default is 1.
        
        Examples
        --------
        >>> from rby1_sdk import Color
        >>> # Set LED to red for 5 seconds
        >>> robot.set_led_color(Color(255, 0, 0), duration=5.0)
        >>> # Set LED to green with 1 second transition
        >>> robot.set_led_color(Color(0, 255, 0), transition_time=1.0)
        >>> # Set LED to blue with blinking
        >>> robot.set_led_color(Color(0, 0, 255), blinking=True, blinking_freq=2.0)
        >>> # Set LED to white with custom duration and transition
        >>> robot.set_led_color(Color(255, 255, 255), duration=10.0, transition_time=2.0)
        """
    def set_parameter(self, name: str, value: str, write_db: bool = True) -> bool:
        """
        Set a robot parameter.
        
        Parameters
        ----------
        name : str
            Parameter name.
        value : any
            Parameter value.
        write_db : bool, optional
            Whether to write to database. Default is True.
        
        Examples
        --------
        >>> # Set acceleration limit scaling
        >>> robot.set_parameter("default.acceleration_limit_scaling", "0.8")
        >>> # Set joint position command cutoff frequency
        >>> robot.set_parameter("joint_position_command.cutoff_frequency", "5")
        >>> # Set hotspot SSID name
        >>> robot.set_parameter("hotspot.ssid", "\\"RBY1_HOTSPOT\\"") # For str value, use escaped quotes
        >>> # Set without writing to database (Return ``False`` if matching parameter not found)
        >>> robot.set_parameter("temp.parameter", "value", write_db=False)
        False
        """
    def set_position_d_gain(self, dev_name: str, d_gain: int) -> bool:
        """
        Set position D gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        d_gain : int
            D gain value.
        
        Examples
        --------
        >>> # Set D gain for specific devices
        >>> robot.set_position_d_gain("torso_5", 400)
        """
    def set_position_i_gain(self, dev_name: str, i_gain: int) -> bool:
        """
        Set position I gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        i_gain : int
            I gain value.
        
        Examples
        --------
        >>> # Set I gain for specific devices
        >>> robot.set_position_i_gain("torso_5", 40)
        """
    def set_position_p_gain(self, dev_name: str, p_gain: int) -> bool:
        """
        Set position P gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        
        Examples
        --------
        >>> # Set P gain for specific devices
        >>> robot.set_position_p_gain("torso_5", 220)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, p_gain: int, i_gain: int, d_gain: int) -> bool:
        """
        Set position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        i_gain : int
            I gain value.
        d_gain : int
            D gain value.
        
        Returns
        -------
        bool
            True if successful, False otherwise.
        
        Examples
        --------
        >>> # Set all PID gains at once for a device
        >>> robot.set_position_pid_gain("right_arm_0", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_1", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_2", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_3", 35, 5, 80)
        >>> robot.set_position_pid_gain("right_arm_4", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_5", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_6", 100, 5, 120)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, pid_gain: PIDGain) -> bool:
        """
        Set position PID gains for a device using PIDGain object.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        pid_gain : PIDGain
            PID gain object.
        
        Returns
        -------
        bool
            True if successful, False otherwise.
        """
    def set_preset_position(self, joint_name: str) -> bool:
        """
        Set preset position for a joint (only available for PVL-based motors).
        
        Parameters
        ----------
        joint_name : str
            Joint name to set preset position.
        
        Examples
        --------
        >>> # Set preset position for specific joints
        >>> robot.set_preset_position("right_arm_6")  # Right arm joint 6
        >>> # Preset position is used as reference for home offset
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any) -> bool:
        """
        Set robot system time.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any, time_zone: str) -> bool:
        """
        Set robot system time with timezone.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        time_zone : str
            Timezone string.
        """
    def set_time_scale(self, time_scale: float) -> float:
        """
        Set the time scale for motion execution.
        
        Parameters
        ----------
        time_scale : float
            Time scale value (0.0 to 1.0).
        
        Examples
        --------
        >>> # Set time scale for motion execution
        >>> robot.set_time_scale(1.0)   # Normal speed (100%)
        >>> robot.set_time_scale(0.5)   # Half speed (50%)
        >>> robot.set_time_scale(0.25)  # Quarter speed (25%)
        >>> # Range: 0.0 (stopped) to 1.0 (full speed)
        >>> # Useful for testing and safety
        """
    def set_tool_flange_digital_output(self, name: str, channel: int, state: bool) -> bool:
        """
        Set the digital output state of a specific channel on the tool flange
        of the specified arm.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        channel : int
            Digital output channel index.
        state : bool
            Desired state of the digital output (``True`` = ON, ``False`` = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 on the right arm tool flange
        >>> robot.set_tool_flange_digital_output("right", 0, True)
        """
    def set_tool_flange_digital_output_dual(self, name: str, state_0: bool, state_1: bool) -> bool:
        """
        Set the digital output states of two channels on the tool flange
        of the specified arm simultaneously.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        state_0 : bool
            Desired state for digital output channel 0 (True = ON, False = OFF).
        state_1 : bool
            Desired state for digital output channel 1 (True = ON, False = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 and turn off channel 1 on the left arm tool flange
        >>> robot.set_tool_flange_digital_output_dual("left", True, False)
        """
    def set_tool_flange_output_voltage(self, name: str, voltage: int) -> bool:
        """
        Set tool flange output voltage.
        
        Parameters
        ----------
        name : str
            Tool flange name `"right"` or `"left"`.
        
        voltage : int
            Output voltage in volts.
        
        Examples
        --------
        >>> # Set tool flange output voltage
        >>> robot.set_tool_flange_output_voltage("right", 12)  # 12V output
        >>> robot.set_tool_flange_output_voltage("left", 24)  # 24V output
        >>> # Common voltages: 12V, 24V
        >>> # Use 0V to turn off output
        >>> # Note: This method sets voltage for both tool flanges (right and left)
        """
    def start_log_stream(self, cb: typing.Callable[[list[Log]], None], rate: float) -> None:
        """
        Start log stream callback.
        
        Parameters
        ----------
        cb : callable
            Callback function for log updates.
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def log_callback(log_entries):
        ...     for log in log_entries:
        ...         print(f"{log.timestamp} - {log.level} - {log.message}")
        >>> # Start log stream at 10 Hz
        >>> robot.start_log_stream(log_callback, 10.0)
        >>> # Stop when done: robot.stop_log_stream()
        """
    def start_state_update(self, cb: typing.Callable, rate: float) -> None:
        """
        Start state update callback.
        
        Parameters
        ----------
        cb : callable
            Callback function with 1 or 2 parameters:
            - cb(robot_state) or cb(robot_state, control_manager_state)
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def state_callback(robot_state):
        ...     print(f"Timestamp: {robot_state.timestamp}, Joint positions: {robot_state.position}")
        >>> # Start state updates at 100 Hz
        >>> robot.start_state_update(state_callback, 100.0)
        >>> # Stop when done: robot.stop_state_update()
        """
    def start_time_sync(self, period_sec: int) -> bool:
        """
        Start time synchronization.
        
        Parameters
        ----------
        period_sec : float
            Synchronization period in seconds.
        """
    def stop_log_stream(self) -> None:
        """
        Stop log stream callback.
        """
    def stop_state_update(self) -> None:
        """
        Stop state update callback.
        """
    def stop_time_sync(self) -> bool:
        """
        Stop time synchronization.
        """
    def sync_time(self) -> bool:
        """
        Synchronizes the timestamp of ``RobotState`` to UPC time instead of UTC. 
        Useful when synchronizing multiple devices to UPC time.
        """
    def wait_for_control_ready(self, timeout_ms: int) -> bool:
        """
        Wait until the robot is ready to accept control commands.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if the robot is ready to accept control (you can now set control).
            ``False`` if the timeout expired before the robot became ready.
        
        Examples
        --------
        >>> # Wait for control to be ready
        >>> if robot.wait_for_control_ready(timeout_ms=5000):
        ...     print("Control is ready, you can now set control commands.")
        ... else:
        ...     print("Timeout: control is not ready.")
        >>> # Call after servo_on() and before sending control commands
        """
class Robot_A_CommandHandler:
    """
    Robot (model: ``Model_A``) command handler.
    
    Handles robot command execution and provides status monitoring.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        Cancel the command execution.
        """
    def get(self) -> RobotCommandFeedback:
        """
        Wait for the command execution and get feedback
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def get_status(self) -> bool:
        """
        Get gRPC status
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            ``True`` if command is complete, ``False`` otherwise.
        """
    def wait(self) -> None:
        """
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
    def wait_for(self, timeout_ms: int) -> bool:
        """
        Wait for the command execution with timeout.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if command completed, ``False`` if timeout.
        """
class Robot_A_CommandStreamHandler:
    """
    Robot (model: ``Model_A``) command stream handler.
    
    Handles robot command execution through streaming with send and feedback capabilities.
    
    Attributes
    ----------
    is_done : bool
        Whether the command execution is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        Cancel the current command execution.
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            True if command is complete, False otherwise.
        """
    def request_feedback(self, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        Request feedback from the robot.
        
        Parameters
        ----------
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def send_command(self, builder: RobotCommandBuilder, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        Send a command through the stream.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def wait(self) -> None:
        ...
    def wait_for(self, timeout_ms: int) -> bool:
        """
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
class Robot_A_ControlInput:
    """
    Robot (model: ``Model_A``) control input.
    
    Represents control input parameters for robot real-time control including mode, target, and gains.
    
    Attributes
    ----------
    mode : numpy.ndarray
        Control mode for each joint (boolean array).
    target : numpy.ndarray
        Target positions for each joint [rad].
    feedback_gain : numpy.ndarray
        Feedback gains for each joint.
    feedforward_torque : numpy.ndarray
        Feedforward torque for each joint [Nm].
    finish : bool
        Whether to finish the current control operation.
    """
    feedback_gain: numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.uint32]]
    feedforward_torque: numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]
    finish: bool
    mode: numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.bool_]]
    target: numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]
    def __init__(self) -> None:
        """
        Construct a ``ControlInput`` instance.
        
        Attributes
        ----------
        mode : numpy.ndarray, shape (DOF,)
            Control mode for each joint (boolean array).
        target : numpy.ndarray, shape (DOF,)
            Target positions for each joint [rad].
        feedback_gain : numpy.ndarray, shape (DOF,)
            Feedback gains for each joint.
        feedforward_torque : numpy.ndarray, shape (DOF,)
            Feedforward torque for each joint [Nm].
        finish : bool
            Whether to finish the current control operation.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
class Robot_A_ControlState:
    """
    Robot (model: ``Model_A``) control state.
    
    Represents the current state of robot real-time control including position, velocity, and torque.
    
    Attributes
    ----------
    t : float
        Current time in seconds.
    is_ready : numpy.ndarray
        Whether the joint is ready for control.
    position : numpy.ndarray, shape (DOF,)
        Current joint positions [rad].
    velocity : numpy.ndarray, shape (DOF,)
        Current joint velocities [rad/s].
    current : numpy.ndarray, shape (DOF,)
        Current joint currents [A].
    torque : numpy.ndarray, shape (DOF,)
        Current joint torques [Nm].
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        ...
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def t(self) -> float:
        ...
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
class Robot_M:
    """
    Robot (model: ``Model_M``) control interface.
    
    Provides high-level control interface for robot operations including
    connection management, power control, and command execution.
    
    Attributes
    ----------
    model : Model_M
        Robot model configuration.
    """
    @staticmethod
    def create(address: str) -> Robot_M:
        """
        Create a robot instance.
        
        Parameters
        ----------
        address : str
            Robot network address, e.g. "192.168.1.100:50051".
        
        Returns
        -------
        Robot
            Robot instance.
        
        Examples
        --------
        >>> import rby1_sdk
        >>> robot = rby.Robot_A.create("192.168.30.1:50051")
        >>> robot.connect()
        >>> if robot.is_connected():
        ...     print("Robot connected successfully")
        ...     robot_info = robot.get_robot_info()
        ...     print(f"Robot model: {robot.model().model_name}")
        ...     # Note: Model A has mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        ...     # Total joints: 2 + 6 + 7 + 7 + 2 = 24 DOF for model A
        """
    @staticmethod
    def model() -> Model_M:
        """
        Get the robot model configuration.
        
        Returns
        -------
        Model_M
            Robot model configuration object.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def break_engage(self, dev_name: str) -> bool:
        """
        Engage the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to engage brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Engage brake for manitance
        >>> robot.break_engage("right_arm_0")
        """
    def break_release(self, dev_name: str) -> bool:
        """
        break_release(dev_name)
        
        Release the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to release brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Release brake to allow movement
        >>> robot.break_release("right_arm_0")
        """
    def cancel_control(self) -> bool:
        """
        Cancel current control operation.
        """
    def connect(self, max_retries: int = 5, timeout_ms: int = 1000) -> bool:
        """
        Attempts to establish a connection with the robot.
        
        Parameters
        ----------
        max_retries : int, optional
            Maximum number of retries to connect. Default is 5.
        timeout_ms : int, optional
            Timeout in milliseconds for each connection attempt. Default is 1000.
        
        Returns
        -------
        bool
            ``True`` if the connection was successful, ``False`` otherwise.
        
        Examples
        --------
        >>> robot = rby1_sdk.create_robot("192.168.1.100", "a")
        >>> if robot.connect():
        ...     print("Connected to robot")
        ... else:
        ...     print("Failed to connect")
        >>> # Default: max_retries=5, timeout_ms=1000
        >>> # Custom: robot.connect(max_retries=10, timeout_ms=2000)
        """
    def connect_wifi(self, ssid: str, password: str = '', use_dhcp: bool = True, ip_address: str = '', gateway: str = '', dns: list[str] = []) -> bool:
        """
        Connect to WiFi network.
        
        Parameters
        ----------
        ssid : str
            WiFi network name.
        password : str, optional
            WiFi password. Default is empty string.
        use_dhcp : bool, optional
            Use DHCP. Default is True.
        ip_address : str, optional
            Static IP address. Default is empty string.
        gateway : str, optional
            Gateway address. Default is empty string.
        dns : list[str], optional
            DNS servers. Default is empty string.
        
        Examples
        --------
        >>> # Connect using DHCP (automatic IP)
        >>> robot.connect_wifi("MyWiFi", "mypassword123")
        >>> # Connect with static IP configuration
        >>> robot.connect_wifi("MyWiFi", "mypassword123", use_dhcp=False,
        ...                    ip_address="192.168.1.100/24", gateway="192.168.1.1")
        >>> # Connect to open network
        >>> robot.connect_wifi("OpenNetwork")
        >>> # Check connection status
        >>> status = robot.get_wifi_status()
        >>> print(f"Connected: {status.connected}, SSID: {status.ssid}")
        """
    def control(self, control: typing.Callable[[Robot_M_ControlState], Robot_M_ControlInput], port: int = 0, priority: int = 1) -> bool:
        """
        Start a **blocking** real-time control loop using a custom control callback.
        
        This function runs a UDP-based real-time loop that repeatedly calls the user-provided
        ``control(ControlState) -> ControlInput``. The loop exits when the callback returns a
        ``ControlInput`` with ``finish=True``, or when an error/abort occurs. The function
        returns ``True`` only if it finished via ``finish=True``; otherwise ``False``.
        
        Parameters
        ----------
        control : callable
            A callable that accepts a ``ControlState`` and returns a ``ControlInput``.
            The callback is invoked for each received RT state packet.
        port : int, optional
            UDP port to bind for the RT server. Use ``0`` to let the OS choose an available port
            (recommended). Default is ``0``.
        priority : int, optional
            Command priority sent with the RT control request. Default is ``1``.
        
        Returns
        -------
        bool
            ``True`` if the loop terminated because the callback set ``finish=True`` in
            ``ControlInput``. ``False`` if the loop ended due to an error or abort
            (e.g., UDP bind failure, connection issue).
        
        Notes
        -----
        - **Blocking:** This call blocks until the control loop ends. There is no handler for
          external cancellation. Design the callback to set ``finish=True`` when you want to stop.
        - **GIL behavior:** The function releases the Python GIL around I/O and reacquires it
          only when invoking your Python callback, allowing other Python threads to run between
          callbacks.
        - **Performance:** Keep the callback lightweight—avoid long computations or blocking I/O
          inside the callback to maintain RT responsiveness.
        - **State fields:** The provided ``ControlState`` includes timestamp ``t``, and arrays 
          such as ``position``, ``velocity``, ``current``, and ``torque`` for all DoFs of the robot.
        - **Errors:** If the UDP server fails to bind (e.g., port unavailable), the function
          returns ``False`` immediately (and prints the error to ``stderr``).
        
        Examples
        --------
        >>> import numpy as np
        >>> 
        >>> # Stop after ~2 seconds using state.t
        >>> t0 = {"t": None}
        >>> def control_fn(state):
        ...     if t0["t"] is None:
        ...         t0["t"] = state.t
        ...     finish = (state.t - t0["t"]) >= 2.0
        ...     i = ControlInput()
        ...     i.mode.fill(rby.ControlMode.Position)
        ...     i.target = np.zeros_like(state.position)   # hold home
        ...     i.feedback_gain.fill(10)                   # simple P gain
        ...     i.feedforward_torque.fill(0)               # no torque feedforward
        ...     i.finish = finish
        ...     return i
        >>> ok = robot.control(control_fn)
        >>> print(ok)   # True if finished via finish=True
        """
    def create_command_stream(self, priority: int = 1) -> Robot_M_CommandStreamHandler:
        """
        Create a command stream for continuous command sending.
        
        Parameters
        ----------
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandStreamHandler
            Command stream handler.
        
        Examples
        --------
        >>> # Create command stream for continuous operation
        >>> stream_handler = robot.create_command_stream(priority=1)
        >>> # Send commands continuously
        >>> for i in range(10):
        ...     command_builder = create_command(i)
        ...     stream_handler.send_command(command_builder, timeout_ms=1000)
        ...     time.sleep(1)
        >>> # Through the handler, you can terminate control or check the current state
        >>> stream_handler.cancel()
        >>> # See examples/python/cartesian_command_stream.py for complete usage
        """
    def disable_control_manager(self) -> bool:
        """
        Disable the control manager.
        """
    def disconnect(self) -> None:
        """
        Disconnects from the robot.
        """
    def disconnect_wifi(self) -> bool:
        """
        Disconnect from WiFi network.
        """
    def download_file(self, path: str, file_like: typing.Any) -> bool:
        """
        Downloads a file from the robot and writes it into a file-like object.
        
        Parameters
        ----------
        path : str
            Relative path to the file on the robot's file system.
            The base directory is defined by the `RBY1_HOME` environment variable (default: `/root/.rby1`).
        file_like : file-like object
            Any object with a `.write(bytes)` method (e.g., `io.BytesIO`, a real file).
        
        Returns
        -------
        bool
            ``True`` if the file was downloaded successfully.
        
        Raises
        ------
        RuntimeError
            If the gRPC call fails (e.g., network issue, file not found, internal error).
        """
    def enable_control_manager(self, unlimited_mode_enabled: bool = False) -> bool:
        """
        Enable the control manager.
        
        Parameters
        ----------
        unlimited_mode_enabled : bool, optional
            Whether to enable unlimited mode. Default is False.
        
        Examples
        --------
        >>> # Enable control manager for robot control
        >>> robot.enable_control_manager()
        >>> # Enable with unlimited mode (use with caution)
        >>> robot.enable_control_manager(unlimited_mode_enabled=True)
        >>> # Must be called before sending commands
        """
    def factory_reset_all_parameters(self) -> None:
        """
        Factory reset all parameters to their default values.
        """
    def factory_reset_parameter(self, name: str) -> bool:
        """
        Factory reset a parameter to its default value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def get_control_manager_state(self) -> ControlManagerState:
        """
        Get control manager state.
        
        Returns
        -------
        ControlManagerState
            Current control manager state.
        
        Examples
        --------
        >>> # Get control manager state
        >>> ctrl_state = robot.get_control_manager_state()
        >>> print(f"Control Manager state: {ctrl_state.state}")
        >>> print(f"Control state: {ctrl_state.control_state}")
        >>> # Check if control manager is enabled
        >>> if ctrl_state.state == rby1_sdk.ControlManagerState.State.Enabled:
        ...     print("Control manager is enabled")
        """
    def get_dynamics(self, urdf_model: str = '') -> dynamics.Robot_26:
        """
        Get robot dynamics model.
        
        Parameters
        ----------
        urdf_model : str, optional
            URDF model path. Default is empty string.
        
        Returns
        -------
        dyn.Robot
            Robot dynamics model.
        
        Examples
        --------
        >>> # Get dynamics model with the model from connected robot
        >>> dynamics_robot = robot.get_dynamics()
        >>> # Get dynamics model with custom URDF
        >>> dynamics_robot = robot.get_dynamics("/path/to/custom.urdf")
        >>> # Useful for advanced control algorithms
        """
    def get_fault_log_list(self) -> list[str]:
        """
        Get fault log list.
        
        Returns
        -------
        list
            List of fault log entries.
        """
    def get_head_position_pid_gains(self) -> list[PIDGain]:
        """
        Get head position PID gains.
        
        Returns
        -------
        PIDGain
            Head position PID gains.
        """
    def get_last_log(self, count: int) -> list[Log]:
        """
        Get last log entries.
        
        Parameters
        ----------
        count : int
            Number of log entries to retrieve.
        
        Returns
        -------
        list
            List of log entries.
        """
    def get_left_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        Get left arm position PID gains.
        
        Returns
        -------
        PIDGain
            Left arm position PID gains.
        """
    def get_parameter(self, name: str) -> str:
        """
        Retrieve a robot parameter.
        
        Parameters
        ----------
        name : str
            Name of the parameter to retrieve.
        
        Returns
        -------
        any
            Parameter value.
            Returned as a JSON value: numeric values are returned as-is, strings are enclosed in quotes ("...").
        
        Examples
        --------
        >>> # Retrieve current parameter values
        >>> acc_scaling = robot.get_parameter("default.acceleration_limit_scaling")
        >>> cutoff_freq = robot.get_parameter("joint_position_command.cutoff_frequency")
        >>> model_name = robot.get_parameter("robot_model_name")
        >>> print(f"Acceleration scaling: {acc_scaling}")
        >>> print(f"Cutoff frequency: {cutoff_freq}")
        >>> print(f"Model name: {model_name}")
        """
    def get_parameter_list(self) -> list[tuple[str, int]]:
        """
        Get list of available parameters.
        
        Returns
        -------
        list
            List of parameter names.
        
        Examples
        --------
        >>> # Get all available parameters
        >>> param_list = robot.get_parameter_list()
        >>> print(f"Total parameters: {len(param_list)}")
        >>> # List common parameter categories
        >>> for param in param_list:
        ...     if param[0].startswith("default."):
        ...         print(f"Default param: {param}")
        ...     elif param[0].startswith("joint_position_command."):
        ...         print(f"Joint position param: {param}")
        >>> # Common categories: default.*, joint_position_command.*, cartesian_command.*
        """
    def get_position_pid_gain(self, dev_name: str) -> PIDGain:
        """
        Get position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        
        Returns
        -------
        PIDGain
            Position PID gains for the device.
        
        Examples
        --------
        >>> # Get PID gains for specific device
        >>> torso_pid = robot.get_position_pid_gain("torso_5")
        >>> print(f"Torso 5 P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> # Get PID gains for arm
        >>> arm_pid = robot.get_position_pid_gain("right_arm_0")
        >>> print(f"Right arm 0 P: {arm_pid.p_gain}")
        >>> devices = ["torso_5", "right_arm_0", "left_arm_1", "head_0"]
        >>> for device in devices:
        ...     pid = robot.get_position_pid_gain(device)
        ...     print(f"{device}: P={pid.p_gain}, I={pid.i_gain}, D={pid.d_gain}")
        """
    def get_right_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        Get right arm position PID gains.
        
        Returns
        -------
        PIDGain
            Right arm position PID gains.
        """
    def get_robot_info(self) -> RobotInfo:
        """
        Retrieves static information about the robot, such as model name, SDK version, and joint configuration.
        
        Returns
        -------
        RobotInfo
            Structured metadata including joint details, device names, and robot model information.
        
        Examples
        --------
        >>> # Get robot information
        >>> robot_info = robot.get_robot_info()
        >>> print(f"SDK version: {robot_info.sdk_version}")
        >>> print(f"Robot model name: {robot_info.robot_model_name}")
        >>> print(f"Robot model version: {robot_info.robot_model_version}")
        >>> print(f"Joint count: {len(robot_info.joint_infos)}")
        >>> # Access joint information
        >>> for joint in robot_info.joint_infos:
        ...     print(f"Joint: {joint.name}, Brake: {joint.has_brake}, Product name: {joint.product_name}, Firmware version: {joint.firmware_version}")
        """
    def get_robot_model(self) -> str:
        """
        Get the current robot URDF model.
        
        Returns
        -------
        RobotModel
            Current robot model.
        """
    def get_serial_device_list(self) -> list[SerialDevice]:
        """
        Get list of available serial devices on the robot.
        
        Returns
        -------
        list
            List of available serial devices.
        
        Examples
        --------
        >>> # Get available serial devices
        >>> devices = robot.get_serial_device_list()
        >>> print(f"Found {len(devices)} serial devices")
        >>> # List device information
        >>> for device in devices:
        ...     print(f"Path: {device.path}, Description: {device.description}")
        >>> # Open serial stream to first device
        >>> if devices:
        ...     stream = robot.open_serial_stream(devices[0].path, 115200)
        >>> # Common device paths: /dev/ttyUSB0, /dev/ttyACM0, COM1, COM2
        """
    def get_state(self) -> RobotState_M:
        """
        Get current robot state.
        
        Returns
        -------
        RobotState
            Current robot state.
        
        Examples
        --------
        >>> robot_state = robot.get_state()
        >>> model = robot.model()
        >>> print(f"Joint positions: {robot_state.position}")
        >>> print(f"Right arm position: {robot_state.position[model.right_arm_idx]}")
        >>> # Note: Joint positions include mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        >>> # Total: 24 DOF for model A, 23 DOF for model M, 26 DOF for model M, 18 DOF for model UB
        """
    def get_system_time(self) -> tuple[typing.Any, str]:
        """
        Get robot system time.
        
        Returns
        -------
        tuple
            (datetime, str): Robot system time and local time string.
        """
    def get_time_scale(self) -> float:
        """
        Get the current time scale.
        
        Returns
        -------
        float
            Current time scale value.
        
        Examples
        --------
        >>> # Get current time scale
        >>> current_scale = robot.get_time_scale()
        >>> print(f"Current time scale: {current_scale}")
        >>> # Check if robot is running at full speed
        >>> if current_scale == 1.0:
        ...     print("Robot running at full speed")
        >>> # Check if robot is slowed down
        >>> elif current_scale < 1.0:
        ...     print(f"Robot running at {current_scale * 100}% speed")
        """
    def get_torso_position_pid_gains(self) -> list[PIDGain]:
        """
        Get torso position PID gains.
        
        Returns
        -------
        PIDGain
            Torso position PID gains.
        
        Examples
        --------
        >>> # Get current PID gains for torso
        >>> torso_pid = robot.get_torso_position_pid_gains()[0]  # Get first (and only) torso device
        >>> print(f"Torso P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> right_arm_pid = robot.get_right_arm_position_pid_gains()[0]
        >>> print(f"Right arm: {right_arm_pid}")
        """
    def get_wifi_status(self) -> WifiStatus | None:
        """
        Get WiFi connection status.
        
        Returns
        -------
        WifiStatus
            Current WiFi status.
        """
    def has_established_time_sync(self) -> bool:
        """
        Check if time synchronization is established.
        
        Returns
        -------
        bool
            True if time sync is established, False otherwise.
        """
    def home_offset_reset(self, dev_name: str) -> bool:
        """
        Reset home offset for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to reset home offset. Supports regex patterns.
        """
    def import_robot_model(self, name: str, model: str) -> bool:
        """
        Import a robot model.
        
        Parameters
        ----------
        name : str
            Model name.
        model : RobotModel
            Robot model to import.
        """
    def is_connected(self) -> bool:
        """
        Checks whether the robot is currently connected.
        
        Returns
        -------
        bool
            ``True`` if the robot is connected to the robot, ``False`` otherwise.
        """
    def is_power_on(self, dev_name: str) -> bool:
        """
        Check if a device is powered on.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if device is powered on, ``False`` otherwise.
        """
    def is_servo_on(self, dev_name: str) -> bool:
        """
        Check if servo control is enabled for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if servo control is enabled, ``False`` otherwise.
        """
    def open_serial_stream(self, device_path: str, baudrate: int, bytesize: int = 8, parity: str = 'N', stopbits: int = 1) -> SerialStream:
        """
        Open a serial stream.
        
        Parameters
        ----------
        device_path : str
            Path to serial device.
        baudrate : int
            Baud rate.
        bytesize : int, optional
            Data bits. Default is 8.
        parity : str, optional
            Parity setting. Default is 'N'.
        stopbits : int, optional
            Stop bits. Default is 1.
        
        Returns
        -------
        SerialStream
            Serial stream object.
        
        Examples
        --------
        >>> # Open serial stream with default settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB0", 115200)
        >>> # Open with custom settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB1", 9600, bytesize=7, parity='E', stopbits=2)
        >>> # Common baudrates: 9600, 19200, 38400, 57600, 115200
        >>> # Parity: 'N' (none), 'E' (even), 'O' (odd)
        >>> # Stop bits: 1, 2
        """
    def power_off(self, dev_name: str) -> bool:
        """
        Power off a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power off. Supports regex patterns.
        """
    def power_on(self, dev_name: str) -> bool:
        """
        Power on a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power on. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_power_on(".*"):
        ...     robot.power_on(".*")
        ...     print("Robot powered on")
        >>> # Pattern ".*" powers on all devices
        >>> # Specific device: robot.power_on("12v"), robot.power_on("24v"), etc.
        """
    def reset_all_parameters(self) -> None:
        """
        Reset all parameters to their current values.
        """
    def reset_all_parameters_to_default(self) -> None:
        """
        Reset all parameters to their default values (deprecated).
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_all_parameters` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_all_parameters() instead.
        """
    def reset_battery_config(self) -> bool:
        """
        Reset battery configuration to default.
        """
    def reset_fault_control_manager(self) -> bool:
        """
        Reset fault in the control manager.
        """
    def reset_network_setting(self) -> bool:
        """
        Reset network settings to default.
        """
    def reset_odometry(self, angle: float, position: numpy.ndarray[tuple[typing.Literal[2], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> bool:
        """
        reset_odometry(angle, position)
        
        Reset odometry to specified values.
        
        Parameters
        ----------
        angle : float
            New angle [rad].
        position : numpy.ndarray
            New position [m].
        
        Examples
        --------
        >>> import numpy as np
        >>> # Reset odometry to origin
        >>> robot.reset_odometry(angle=0.0, position=np.array([0.0, 0.0]))
        >>> # Reset to specific position and orientation
        >>> robot.reset_odometry(angle=np.pi/2, position=np.array([1.0, 2.0]))
        >>> # Useful for mobile base navigation
        >>> # Position is [x, y] in meters, angle is yaw in rad
        """
    def reset_parameter(self, name: str) -> bool:
        """
        Reset a parameter to its current value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def reset_parameter_to_default(self, name: str) -> bool:
        """
        Reset a parameter to its default value (deprecated).
        
        Parameters
        ----------
        name : str
            Parameter name.
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_parameter` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_parameter() instead.
        """
    def scan_wifi(self) -> list[WifiNetwork]:
        """
        Scan for available WiFi networks.
        
        Returns
        -------
        list
            List of available WiFi networks.
        
        Examples
        --------
        >>> # Scan for available WiFi networks
        >>> networks = robot.scan_wifi()
        >>> print(f"Found {len(networks)} networks")
        >>> # List network information
        >>> for network in networks:
        ...     print(f"SSID: {network.ssid}, Signal: {network.signal_strength}")
        >>> # Connect to a network
        >>> if networks:
        ...     robot.connect_wifi(networks[0].ssid, "password")
        """
    def send_command(self, builder: RobotCommandBuilder, priority: int = 1) -> Robot_M_CommandHandler:
        """
        Send a command to the robot.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandHandler
            Command handler for monitoring execution.
        
        Examples
        --------
        >>> from rby1_sdk import RobotCommandBuilder, ComponentBasedCommandBuilder
        >>> from rby1_sdk import BodyComponentBasedCommandBuilder, JointPositionCommandBuilder
        >>> # Create command with method chaining (standard pattern)
        >>> command = RobotCommandBuilder().set_command(
        ...     ComponentBasedCommandBuilder().set_body_command(
        ...         BodyComponentBasedCommandBuilder()
        ...             .set_torso_command(
        ...                 JointPositionCommandBuilder()
        ...                     .set_position([0, 0, 0, 0, 0, 0])  # 6-DOF torso
        ...                     .set_minimum_time(2.0)
        ...             )
        ...     )
        ... )
        >>> handler = robot.send_command(command)
        >>> handler.wait()  # Wait for completion
        >>> # This pattern is used in most examples: examples/python/07_impedance_control.py, 09_demo_motion.py, etc.
        """
    def servo_off(self, dev_name: str) -> bool:
        """
        Disable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to disable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> # Disable servo control for safety
        >>> robot.servo_off(".*")  # All motor drivers
        >>> # Specific device: robot.servo_off("^torso_.*")
        """
    def servo_on(self, dev_name: str) -> bool:
        """
        Enable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to enable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_servo_on(".*"):
        ...     robot.servo_on(".*")  # Servo on all devices
        ...     print("All devices servoed on")
        >>> # Specific device: robot.servo_on("^torso_.*"), robot.servo_on("^right_arm_.*"), etc.
        """
    def set_battery_config(self, cutoff_voltage: float, fully_charged_voltage: float, coefficients: typing.Annotated[list[float], pybind11_stubgen.typing_ext.FixedSize(4)]) -> bool:
        """
        Set battery configuration.
        """
    def set_battery_level(self, arg0: float) -> bool:
        """
        Set battery level.
        
        Parameters
        ----------
        level : float
            Battery level percentage (0.0 to 100.0).
        
        Examples
        --------
        >>> # Set battery level for testing
        >>> robot.set_battery_level(100.0)  # Full battery
        >>> robot.set_battery_level(50.0)   # Half battery
        >>> robot.set_battery_level(25.0)   # Quarter battery
        >>> robot.set_battery_level(0.0)    # Empty battery
        >>> # Range: 0.0 to 100.0
        >>> # Useful for using custom battery
        """
    def set_led_color(self, color: Color, duration: float = 1, transition_time: float = 0, blinking: bool = False, blinking_freq: float = 1) -> bool:
        """
        Set LED color.
        
        Parameters
        ----------
        color : Color
            LED color.
        duration : float, optional
            Duration in seconds. Default is 1.
        transition_time : float, optional
            Transition time in seconds. Default is 0.
        blinking : bool, optional
            Whether to blink. Default is False.
        blinking_freq : float, optional
            Blinking frequency in Hz. Default is 1.
        
        Examples
        --------
        >>> from rby1_sdk import Color
        >>> # Set LED to red for 5 seconds
        >>> robot.set_led_color(Color(255, 0, 0), duration=5.0)
        >>> # Set LED to green with 1 second transition
        >>> robot.set_led_color(Color(0, 255, 0), transition_time=1.0)
        >>> # Set LED to blue with blinking
        >>> robot.set_led_color(Color(0, 0, 255), blinking=True, blinking_freq=2.0)
        >>> # Set LED to white with custom duration and transition
        >>> robot.set_led_color(Color(255, 255, 255), duration=10.0, transition_time=2.0)
        """
    def set_parameter(self, name: str, value: str, write_db: bool = True) -> bool:
        """
        Set a robot parameter.
        
        Parameters
        ----------
        name : str
            Parameter name.
        value : any
            Parameter value.
        write_db : bool, optional
            Whether to write to database. Default is True.
        
        Examples
        --------
        >>> # Set acceleration limit scaling
        >>> robot.set_parameter("default.acceleration_limit_scaling", "0.8")
        >>> # Set joint position command cutoff frequency
        >>> robot.set_parameter("joint_position_command.cutoff_frequency", "5")
        >>> # Set hotspot SSID name
        >>> robot.set_parameter("hotspot.ssid", "\\"RBY1_HOTSPOT\\"") # For str value, use escaped quotes
        >>> # Set without writing to database (Return ``False`` if matching parameter not found)
        >>> robot.set_parameter("temp.parameter", "value", write_db=False)
        False
        """
    def set_position_d_gain(self, dev_name: str, d_gain: int) -> bool:
        """
        Set position D gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        d_gain : int
            D gain value.
        
        Examples
        --------
        >>> # Set D gain for specific devices
        >>> robot.set_position_d_gain("torso_5", 400)
        """
    def set_position_i_gain(self, dev_name: str, i_gain: int) -> bool:
        """
        Set position I gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        i_gain : int
            I gain value.
        
        Examples
        --------
        >>> # Set I gain for specific devices
        >>> robot.set_position_i_gain("torso_5", 40)
        """
    def set_position_p_gain(self, dev_name: str, p_gain: int) -> bool:
        """
        Set position P gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        
        Examples
        --------
        >>> # Set P gain for specific devices
        >>> robot.set_position_p_gain("torso_5", 220)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, p_gain: int, i_gain: int, d_gain: int) -> bool:
        """
        Set position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        i_gain : int
            I gain value.
        d_gain : int
            D gain value.
        
        Returns
        -------
        bool
            True if successful, False otherwise.
        
        Examples
        --------
        >>> # Set all PID gains at once for a device
        >>> robot.set_position_pid_gain("right_arm_0", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_1", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_2", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_3", 35, 5, 80)
        >>> robot.set_position_pid_gain("right_arm_4", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_5", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_6", 100, 5, 120)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, pid_gain: PIDGain) -> bool:
        """
        Set position PID gains for a device using PIDGain object.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        pid_gain : PIDGain
            PID gain object.
        
        Returns
        -------
        bool
            True if successful, False otherwise.
        """
    def set_preset_position(self, joint_name: str) -> bool:
        """
        Set preset position for a joint (only available for PVL-based motors).
        
        Parameters
        ----------
        joint_name : str
            Joint name to set preset position.
        
        Examples
        --------
        >>> # Set preset position for specific joints
        >>> robot.set_preset_position("right_arm_6")  # Right arm joint 6
        >>> # Preset position is used as reference for home offset
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any) -> bool:
        """
        Set robot system time.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any, time_zone: str) -> bool:
        """
        Set robot system time with timezone.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        time_zone : str
            Timezone string.
        """
    def set_time_scale(self, time_scale: float) -> float:
        """
        Set the time scale for motion execution.
        
        Parameters
        ----------
        time_scale : float
            Time scale value (0.0 to 1.0).
        
        Examples
        --------
        >>> # Set time scale for motion execution
        >>> robot.set_time_scale(1.0)   # Normal speed (100%)
        >>> robot.set_time_scale(0.5)   # Half speed (50%)
        >>> robot.set_time_scale(0.25)  # Quarter speed (25%)
        >>> # Range: 0.0 (stopped) to 1.0 (full speed)
        >>> # Useful for testing and safety
        """
    def set_tool_flange_digital_output(self, name: str, channel: int, state: bool) -> bool:
        """
        Set the digital output state of a specific channel on the tool flange
        of the specified arm.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        channel : int
            Digital output channel index.
        state : bool
            Desired state of the digital output (``True`` = ON, ``False`` = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 on the right arm tool flange
        >>> robot.set_tool_flange_digital_output("right", 0, True)
        """
    def set_tool_flange_digital_output_dual(self, name: str, state_0: bool, state_1: bool) -> bool:
        """
        Set the digital output states of two channels on the tool flange
        of the specified arm simultaneously.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        state_0 : bool
            Desired state for digital output channel 0 (True = ON, False = OFF).
        state_1 : bool
            Desired state for digital output channel 1 (True = ON, False = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 and turn off channel 1 on the left arm tool flange
        >>> robot.set_tool_flange_digital_output_dual("left", True, False)
        """
    def set_tool_flange_output_voltage(self, name: str, voltage: int) -> bool:
        """
        Set tool flange output voltage.
        
        Parameters
        ----------
        name : str
            Tool flange name `"right"` or `"left"`.
        
        voltage : int
            Output voltage in volts.
        
        Examples
        --------
        >>> # Set tool flange output voltage
        >>> robot.set_tool_flange_output_voltage("right", 12)  # 12V output
        >>> robot.set_tool_flange_output_voltage("left", 24)  # 24V output
        >>> # Common voltages: 12V, 24V
        >>> # Use 0V to turn off output
        >>> # Note: This method sets voltage for both tool flanges (right and left)
        """
    def start_log_stream(self, cb: typing.Callable[[list[Log]], None], rate: float) -> None:
        """
        Start log stream callback.
        
        Parameters
        ----------
        cb : callable
            Callback function for log updates.
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def log_callback(log_entries):
        ...     for log in log_entries:
        ...         print(f"{log.timestamp} - {log.level} - {log.message}")
        >>> # Start log stream at 10 Hz
        >>> robot.start_log_stream(log_callback, 10.0)
        >>> # Stop when done: robot.stop_log_stream()
        """
    def start_state_update(self, cb: typing.Callable, rate: float) -> None:
        """
        Start state update callback.
        
        Parameters
        ----------
        cb : callable
            Callback function with 1 or 2 parameters:
            - cb(robot_state) or cb(robot_state, control_manager_state)
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def state_callback(robot_state):
        ...     print(f"Timestamp: {robot_state.timestamp}, Joint positions: {robot_state.position}")
        >>> # Start state updates at 100 Hz
        >>> robot.start_state_update(state_callback, 100.0)
        >>> # Stop when done: robot.stop_state_update()
        """
    def start_time_sync(self, period_sec: int) -> bool:
        """
        Start time synchronization.
        
        Parameters
        ----------
        period_sec : float
            Synchronization period in seconds.
        """
    def stop_log_stream(self) -> None:
        """
        Stop log stream callback.
        """
    def stop_state_update(self) -> None:
        """
        Stop state update callback.
        """
    def stop_time_sync(self) -> bool:
        """
        Stop time synchronization.
        """
    def sync_time(self) -> bool:
        """
        Synchronizes the timestamp of ``RobotState`` to UPC time instead of UTC. 
        Useful when synchronizing multiple devices to UPC time.
        """
    def wait_for_control_ready(self, timeout_ms: int) -> bool:
        """
        Wait until the robot is ready to accept control commands.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if the robot is ready to accept control (you can now set control).
            ``False`` if the timeout expired before the robot became ready.
        
        Examples
        --------
        >>> # Wait for control to be ready
        >>> if robot.wait_for_control_ready(timeout_ms=5000):
        ...     print("Control is ready, you can now set control commands.")
        ... else:
        ...     print("Timeout: control is not ready.")
        >>> # Call after servo_on() and before sending control commands
        """
class Robot_M_CommandHandler:
    """
    Robot (model: ``Model_M``) command handler.
    
    Handles robot command execution and provides status monitoring.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        Cancel the command execution.
        """
    def get(self) -> RobotCommandFeedback:
        """
        Wait for the command execution and get feedback
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def get_status(self) -> bool:
        """
        Get gRPC status
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            ``True`` if command is complete, ``False`` otherwise.
        """
    def wait(self) -> None:
        """
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
    def wait_for(self, timeout_ms: int) -> bool:
        """
        Wait for the command execution with timeout.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if command completed, ``False`` if timeout.
        """
class Robot_M_CommandStreamHandler:
    """
    Robot (model: ``Model_M``) command stream handler.
    
    Handles robot command execution through streaming with send and feedback capabilities.
    
    Attributes
    ----------
    is_done : bool
        Whether the command execution is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        Cancel the current command execution.
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            True if command is complete, False otherwise.
        """
    def request_feedback(self, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        Request feedback from the robot.
        
        Parameters
        ----------
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def send_command(self, builder: RobotCommandBuilder, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        Send a command through the stream.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def wait(self) -> None:
        ...
    def wait_for(self, timeout_ms: int) -> bool:
        """
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
class Robot_M_ControlInput:
    """
    Robot (model: ``Model_M``) control input.
    
    Represents control input parameters for robot real-time control including mode, target, and gains.
    
    Attributes
    ----------
    mode : numpy.ndarray
        Control mode for each joint (boolean array).
    target : numpy.ndarray
        Target positions for each joint [rad].
    feedback_gain : numpy.ndarray
        Feedback gains for each joint.
    feedforward_torque : numpy.ndarray
        Feedforward torque for each joint [Nm].
    finish : bool
        Whether to finish the current control operation.
    """
    feedback_gain: numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.uint32]]
    feedforward_torque: numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]
    finish: bool
    mode: numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.bool_]]
    target: numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]
    def __init__(self) -> None:
        """
        Construct a ``ControlInput`` instance.
        
        Attributes
        ----------
        mode : numpy.ndarray, shape (DOF,)
            Control mode for each joint (boolean array).
        target : numpy.ndarray, shape (DOF,)
            Target positions for each joint [rad].
        feedback_gain : numpy.ndarray, shape (DOF,)
            Feedback gains for each joint.
        feedforward_torque : numpy.ndarray, shape (DOF,)
            Feedforward torque for each joint [Nm].
        finish : bool
            Whether to finish the current control operation.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
class Robot_M_ControlState:
    """
    Robot (model: ``Model_M``) control state.
    
    Represents the current state of robot real-time control including position, velocity, and torque.
    
    Attributes
    ----------
    t : float
        Current time in seconds.
    is_ready : numpy.ndarray
        Whether the joint is ready for control.
    position : numpy.ndarray, shape (DOF,)
        Current joint positions [rad].
    velocity : numpy.ndarray, shape (DOF,)
        Current joint velocities [rad/s].
    current : numpy.ndarray, shape (DOF,)
        Current joint currents [A].
    torque : numpy.ndarray, shape (DOF,)
        Current joint torques [Nm].
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        ...
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def t(self) -> float:
        ...
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
class Robot_UB:
    """
    Robot (model: ``Model_UB``) control interface.
    
    Provides high-level control interface for robot operations including
    connection management, power control, and command execution.
    
    Attributes
    ----------
    model : Model_UB
        Robot model configuration.
    """
    @staticmethod
    def create(address: str) -> Robot_UB:
        """
        Create a robot instance.
        
        Parameters
        ----------
        address : str
            Robot network address, e.g. "192.168.1.100:50051".
        
        Returns
        -------
        Robot
            Robot instance.
        
        Examples
        --------
        >>> import rby1_sdk
        >>> robot = rby.Robot_A.create("192.168.30.1:50051")
        >>> robot.connect()
        >>> if robot.is_connected():
        ...     print("Robot connected successfully")
        ...     robot_info = robot.get_robot_info()
        ...     print(f"Robot model: {robot.model().model_name}")
        ...     # Note: Model A has mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        ...     # Total joints: 2 + 6 + 7 + 7 + 2 = 24 DOF for model A
        """
    @staticmethod
    def model() -> Model_UB:
        """
        Get the robot model configuration.
        
        Returns
        -------
        Model_UB
            Robot model configuration object.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def break_engage(self, dev_name: str) -> bool:
        """
        Engage the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to engage brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Engage brake for manitance
        >>> robot.break_engage("right_arm_0")
        """
    def break_release(self, dev_name: str) -> bool:
        """
        break_release(dev_name)
        
        Release the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to release brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Release brake to allow movement
        >>> robot.break_release("right_arm_0")
        """
    def cancel_control(self) -> bool:
        """
        Cancel current control operation.
        """
    def connect(self, max_retries: int = 5, timeout_ms: int = 1000) -> bool:
        """
        Attempts to establish a connection with the robot.
        
        Parameters
        ----------
        max_retries : int, optional
            Maximum number of retries to connect. Default is 5.
        timeout_ms : int, optional
            Timeout in milliseconds for each connection attempt. Default is 1000.
        
        Returns
        -------
        bool
            ``True`` if the connection was successful, ``False`` otherwise.
        
        Examples
        --------
        >>> robot = rby1_sdk.create_robot("192.168.1.100", "a")
        >>> if robot.connect():
        ...     print("Connected to robot")
        ... else:
        ...     print("Failed to connect")
        >>> # Default: max_retries=5, timeout_ms=1000
        >>> # Custom: robot.connect(max_retries=10, timeout_ms=2000)
        """
    def connect_wifi(self, ssid: str, password: str = '', use_dhcp: bool = True, ip_address: str = '', gateway: str = '', dns: list[str] = []) -> bool:
        """
        Connect to WiFi network.
        
        Parameters
        ----------
        ssid : str
            WiFi network name.
        password : str, optional
            WiFi password. Default is empty string.
        use_dhcp : bool, optional
            Use DHCP. Default is True.
        ip_address : str, optional
            Static IP address. Default is empty string.
        gateway : str, optional
            Gateway address. Default is empty string.
        dns : list[str], optional
            DNS servers. Default is empty string.
        
        Examples
        --------
        >>> # Connect using DHCP (automatic IP)
        >>> robot.connect_wifi("MyWiFi", "mypassword123")
        >>> # Connect with static IP configuration
        >>> robot.connect_wifi("MyWiFi", "mypassword123", use_dhcp=False,
        ...                    ip_address="192.168.1.100/24", gateway="192.168.1.1")
        >>> # Connect to open network
        >>> robot.connect_wifi("OpenNetwork")
        >>> # Check connection status
        >>> status = robot.get_wifi_status()
        >>> print(f"Connected: {status.connected}, SSID: {status.ssid}")
        """
    def control(self, control: typing.Callable[[Robot_UB_ControlState], Robot_UB_ControlInput], port: int = 0, priority: int = 1) -> bool:
        """
        Start a **blocking** real-time control loop using a custom control callback.
        
        This function runs a UDP-based real-time loop that repeatedly calls the user-provided
        ``control(ControlState) -> ControlInput``. The loop exits when the callback returns a
        ``ControlInput`` with ``finish=True``, or when an error/abort occurs. The function
        returns ``True`` only if it finished via ``finish=True``; otherwise ``False``.
        
        Parameters
        ----------
        control : callable
            A callable that accepts a ``ControlState`` and returns a ``ControlInput``.
            The callback is invoked for each received RT state packet.
        port : int, optional
            UDP port to bind for the RT server. Use ``0`` to let the OS choose an available port
            (recommended). Default is ``0``.
        priority : int, optional
            Command priority sent with the RT control request. Default is ``1``.
        
        Returns
        -------
        bool
            ``True`` if the loop terminated because the callback set ``finish=True`` in
            ``ControlInput``. ``False`` if the loop ended due to an error or abort
            (e.g., UDP bind failure, connection issue).
        
        Notes
        -----
        - **Blocking:** This call blocks until the control loop ends. There is no handler for
          external cancellation. Design the callback to set ``finish=True`` when you want to stop.
        - **GIL behavior:** The function releases the Python GIL around I/O and reacquires it
          only when invoking your Python callback, allowing other Python threads to run between
          callbacks.
        - **Performance:** Keep the callback lightweight—avoid long computations or blocking I/O
          inside the callback to maintain RT responsiveness.
        - **State fields:** The provided ``ControlState`` includes timestamp ``t``, and arrays 
          such as ``position``, ``velocity``, ``current``, and ``torque`` for all DoFs of the robot.
        - **Errors:** If the UDP server fails to bind (e.g., port unavailable), the function
          returns ``False`` immediately (and prints the error to ``stderr``).
        
        Examples
        --------
        >>> import numpy as np
        >>> 
        >>> # Stop after ~2 seconds using state.t
        >>> t0 = {"t": None}
        >>> def control_fn(state):
        ...     if t0["t"] is None:
        ...         t0["t"] = state.t
        ...     finish = (state.t - t0["t"]) >= 2.0
        ...     i = ControlInput()
        ...     i.mode.fill(rby.ControlMode.Position)
        ...     i.target = np.zeros_like(state.position)   # hold home
        ...     i.feedback_gain.fill(10)                   # simple P gain
        ...     i.feedforward_torque.fill(0)               # no torque feedforward
        ...     i.finish = finish
        ...     return i
        >>> ok = robot.control(control_fn)
        >>> print(ok)   # True if finished via finish=True
        """
    def create_command_stream(self, priority: int = 1) -> Robot_UB_CommandStreamHandler:
        """
        Create a command stream for continuous command sending.
        
        Parameters
        ----------
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandStreamHandler
            Command stream handler.
        
        Examples
        --------
        >>> # Create command stream for continuous operation
        >>> stream_handler = robot.create_command_stream(priority=1)
        >>> # Send commands continuously
        >>> for i in range(10):
        ...     command_builder = create_command(i)
        ...     stream_handler.send_command(command_builder, timeout_ms=1000)
        ...     time.sleep(1)
        >>> # Through the handler, you can terminate control or check the current state
        >>> stream_handler.cancel()
        >>> # See examples/python/cartesian_command_stream.py for complete usage
        """
    def disable_control_manager(self) -> bool:
        """
        Disable the control manager.
        """
    def disconnect(self) -> None:
        """
        Disconnects from the robot.
        """
    def disconnect_wifi(self) -> bool:
        """
        Disconnect from WiFi network.
        """
    def download_file(self, path: str, file_like: typing.Any) -> bool:
        """
        Downloads a file from the robot and writes it into a file-like object.
        
        Parameters
        ----------
        path : str
            Relative path to the file on the robot's file system.
            The base directory is defined by the `RBY1_HOME` environment variable (default: `/root/.rby1`).
        file_like : file-like object
            Any object with a `.write(bytes)` method (e.g., `io.BytesIO`, a real file).
        
        Returns
        -------
        bool
            ``True`` if the file was downloaded successfully.
        
        Raises
        ------
        RuntimeError
            If the gRPC call fails (e.g., network issue, file not found, internal error).
        """
    def enable_control_manager(self, unlimited_mode_enabled: bool = False) -> bool:
        """
        Enable the control manager.
        
        Parameters
        ----------
        unlimited_mode_enabled : bool, optional
            Whether to enable unlimited mode. Default is False.
        
        Examples
        --------
        >>> # Enable control manager for robot control
        >>> robot.enable_control_manager()
        >>> # Enable with unlimited mode (use with caution)
        >>> robot.enable_control_manager(unlimited_mode_enabled=True)
        >>> # Must be called before sending commands
        """
    def factory_reset_all_parameters(self) -> None:
        """
        Factory reset all parameters to their default values.
        """
    def factory_reset_parameter(self, name: str) -> bool:
        """
        Factory reset a parameter to its default value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def get_control_manager_state(self) -> ControlManagerState:
        """
        Get control manager state.
        
        Returns
        -------
        ControlManagerState
            Current control manager state.
        
        Examples
        --------
        >>> # Get control manager state
        >>> ctrl_state = robot.get_control_manager_state()
        >>> print(f"Control Manager state: {ctrl_state.state}")
        >>> print(f"Control state: {ctrl_state.control_state}")
        >>> # Check if control manager is enabled
        >>> if ctrl_state.state == rby1_sdk.ControlManagerState.State.Enabled:
        ...     print("Control manager is enabled")
        """
    def get_dynamics(self, urdf_model: str = '') -> dynamics.Robot_18:
        """
        Get robot dynamics model.
        
        Parameters
        ----------
        urdf_model : str, optional
            URDF model path. Default is empty string.
        
        Returns
        -------
        dyn.Robot
            Robot dynamics model.
        
        Examples
        --------
        >>> # Get dynamics model with the model from connected robot
        >>> dynamics_robot = robot.get_dynamics()
        >>> # Get dynamics model with custom URDF
        >>> dynamics_robot = robot.get_dynamics("/path/to/custom.urdf")
        >>> # Useful for advanced control algorithms
        """
    def get_fault_log_list(self) -> list[str]:
        """
        Get fault log list.
        
        Returns
        -------
        list
            List of fault log entries.
        """
    def get_head_position_pid_gains(self) -> list[PIDGain]:
        """
        Get head position PID gains.
        
        Returns
        -------
        PIDGain
            Head position PID gains.
        """
    def get_last_log(self, count: int) -> list[Log]:
        """
        Get last log entries.
        
        Parameters
        ----------
        count : int
            Number of log entries to retrieve.
        
        Returns
        -------
        list
            List of log entries.
        """
    def get_left_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        Get left arm position PID gains.
        
        Returns
        -------
        PIDGain
            Left arm position PID gains.
        """
    def get_parameter(self, name: str) -> str:
        """
        Retrieve a robot parameter.
        
        Parameters
        ----------
        name : str
            Name of the parameter to retrieve.
        
        Returns
        -------
        any
            Parameter value.
            Returned as a JSON value: numeric values are returned as-is, strings are enclosed in quotes ("...").
        
        Examples
        --------
        >>> # Retrieve current parameter values
        >>> acc_scaling = robot.get_parameter("default.acceleration_limit_scaling")
        >>> cutoff_freq = robot.get_parameter("joint_position_command.cutoff_frequency")
        >>> model_name = robot.get_parameter("robot_model_name")
        >>> print(f"Acceleration scaling: {acc_scaling}")
        >>> print(f"Cutoff frequency: {cutoff_freq}")
        >>> print(f"Model name: {model_name}")
        """
    def get_parameter_list(self) -> list[tuple[str, int]]:
        """
        Get list of available parameters.
        
        Returns
        -------
        list
            List of parameter names.
        
        Examples
        --------
        >>> # Get all available parameters
        >>> param_list = robot.get_parameter_list()
        >>> print(f"Total parameters: {len(param_list)}")
        >>> # List common parameter categories
        >>> for param in param_list:
        ...     if param[0].startswith("default."):
        ...         print(f"Default param: {param}")
        ...     elif param[0].startswith("joint_position_command."):
        ...         print(f"Joint position param: {param}")
        >>> # Common categories: default.*, joint_position_command.*, cartesian_command.*
        """
    def get_position_pid_gain(self, dev_name: str) -> PIDGain:
        """
        Get position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        
        Returns
        -------
        PIDGain
            Position PID gains for the device.
        
        Examples
        --------
        >>> # Get PID gains for specific device
        >>> torso_pid = robot.get_position_pid_gain("torso_5")
        >>> print(f"Torso 5 P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> # Get PID gains for arm
        >>> arm_pid = robot.get_position_pid_gain("right_arm_0")
        >>> print(f"Right arm 0 P: {arm_pid.p_gain}")
        >>> devices = ["torso_5", "right_arm_0", "left_arm_1", "head_0"]
        >>> for device in devices:
        ...     pid = robot.get_position_pid_gain(device)
        ...     print(f"{device}: P={pid.p_gain}, I={pid.i_gain}, D={pid.d_gain}")
        """
    def get_right_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        Get right arm position PID gains.
        
        Returns
        -------
        PIDGain
            Right arm position PID gains.
        """
    def get_robot_info(self) -> RobotInfo:
        """
        Retrieves static information about the robot, such as model name, SDK version, and joint configuration.
        
        Returns
        -------
        RobotInfo
            Structured metadata including joint details, device names, and robot model information.
        
        Examples
        --------
        >>> # Get robot information
        >>> robot_info = robot.get_robot_info()
        >>> print(f"SDK version: {robot_info.sdk_version}")
        >>> print(f"Robot model name: {robot_info.robot_model_name}")
        >>> print(f"Robot model version: {robot_info.robot_model_version}")
        >>> print(f"Joint count: {len(robot_info.joint_infos)}")
        >>> # Access joint information
        >>> for joint in robot_info.joint_infos:
        ...     print(f"Joint: {joint.name}, Brake: {joint.has_brake}, Product name: {joint.product_name}, Firmware version: {joint.firmware_version}")
        """
    def get_robot_model(self) -> str:
        """
        Get the current robot URDF model.
        
        Returns
        -------
        RobotModel
            Current robot model.
        """
    def get_serial_device_list(self) -> list[SerialDevice]:
        """
        Get list of available serial devices on the robot.
        
        Returns
        -------
        list
            List of available serial devices.
        
        Examples
        --------
        >>> # Get available serial devices
        >>> devices = robot.get_serial_device_list()
        >>> print(f"Found {len(devices)} serial devices")
        >>> # List device information
        >>> for device in devices:
        ...     print(f"Path: {device.path}, Description: {device.description}")
        >>> # Open serial stream to first device
        >>> if devices:
        ...     stream = robot.open_serial_stream(devices[0].path, 115200)
        >>> # Common device paths: /dev/ttyUSB0, /dev/ttyACM0, COM1, COM2
        """
    def get_state(self) -> RobotState_UB:
        """
        Get current robot state.
        
        Returns
        -------
        RobotState
            Current robot state.
        
        Examples
        --------
        >>> robot_state = robot.get_state()
        >>> model = robot.model()
        >>> print(f"Joint positions: {robot_state.position}")
        >>> print(f"Right arm position: {robot_state.position[model.right_arm_idx]}")
        >>> # Note: Joint positions include mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        >>> # Total: 24 DOF for model A, 23 DOF for model M, 26 DOF for model M, 18 DOF for model UB
        """
    def get_system_time(self) -> tuple[typing.Any, str]:
        """
        Get robot system time.
        
        Returns
        -------
        tuple
            (datetime, str): Robot system time and local time string.
        """
    def get_time_scale(self) -> float:
        """
        Get the current time scale.
        
        Returns
        -------
        float
            Current time scale value.
        
        Examples
        --------
        >>> # Get current time scale
        >>> current_scale = robot.get_time_scale()
        >>> print(f"Current time scale: {current_scale}")
        >>> # Check if robot is running at full speed
        >>> if current_scale == 1.0:
        ...     print("Robot running at full speed")
        >>> # Check if robot is slowed down
        >>> elif current_scale < 1.0:
        ...     print(f"Robot running at {current_scale * 100}% speed")
        """
    def get_torso_position_pid_gains(self) -> list[PIDGain]:
        """
        Get torso position PID gains.
        
        Returns
        -------
        PIDGain
            Torso position PID gains.
        
        Examples
        --------
        >>> # Get current PID gains for torso
        >>> torso_pid = robot.get_torso_position_pid_gains()[0]  # Get first (and only) torso device
        >>> print(f"Torso P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> right_arm_pid = robot.get_right_arm_position_pid_gains()[0]
        >>> print(f"Right arm: {right_arm_pid}")
        """
    def get_wifi_status(self) -> WifiStatus | None:
        """
        Get WiFi connection status.
        
        Returns
        -------
        WifiStatus
            Current WiFi status.
        """
    def has_established_time_sync(self) -> bool:
        """
        Check if time synchronization is established.
        
        Returns
        -------
        bool
            True if time sync is established, False otherwise.
        """
    def home_offset_reset(self, dev_name: str) -> bool:
        """
        Reset home offset for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to reset home offset. Supports regex patterns.
        """
    def import_robot_model(self, name: str, model: str) -> bool:
        """
        Import a robot model.
        
        Parameters
        ----------
        name : str
            Model name.
        model : RobotModel
            Robot model to import.
        """
    def is_connected(self) -> bool:
        """
        Checks whether the robot is currently connected.
        
        Returns
        -------
        bool
            ``True`` if the robot is connected to the robot, ``False`` otherwise.
        """
    def is_power_on(self, dev_name: str) -> bool:
        """
        Check if a device is powered on.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if device is powered on, ``False`` otherwise.
        """
    def is_servo_on(self, dev_name: str) -> bool:
        """
        Check if servo control is enabled for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if servo control is enabled, ``False`` otherwise.
        """
    def open_serial_stream(self, device_path: str, baudrate: int, bytesize: int = 8, parity: str = 'N', stopbits: int = 1) -> SerialStream:
        """
        Open a serial stream.
        
        Parameters
        ----------
        device_path : str
            Path to serial device.
        baudrate : int
            Baud rate.
        bytesize : int, optional
            Data bits. Default is 8.
        parity : str, optional
            Parity setting. Default is 'N'.
        stopbits : int, optional
            Stop bits. Default is 1.
        
        Returns
        -------
        SerialStream
            Serial stream object.
        
        Examples
        --------
        >>> # Open serial stream with default settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB0", 115200)
        >>> # Open with custom settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB1", 9600, bytesize=7, parity='E', stopbits=2)
        >>> # Common baudrates: 9600, 19200, 38400, 57600, 115200
        >>> # Parity: 'N' (none), 'E' (even), 'O' (odd)
        >>> # Stop bits: 1, 2
        """
    def power_off(self, dev_name: str) -> bool:
        """
        Power off a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power off. Supports regex patterns.
        """
    def power_on(self, dev_name: str) -> bool:
        """
        Power on a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power on. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_power_on(".*"):
        ...     robot.power_on(".*")
        ...     print("Robot powered on")
        >>> # Pattern ".*" powers on all devices
        >>> # Specific device: robot.power_on("12v"), robot.power_on("24v"), etc.
        """
    def reset_all_parameters(self) -> None:
        """
        Reset all parameters to their current values.
        """
    def reset_all_parameters_to_default(self) -> None:
        """
        Reset all parameters to their default values (deprecated).
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_all_parameters` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_all_parameters() instead.
        """
    def reset_battery_config(self) -> bool:
        """
        Reset battery configuration to default.
        """
    def reset_fault_control_manager(self) -> bool:
        """
        Reset fault in the control manager.
        """
    def reset_network_setting(self) -> bool:
        """
        Reset network settings to default.
        """
    def reset_odometry(self, angle: float, position: numpy.ndarray[tuple[typing.Literal[2], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> bool:
        """
        reset_odometry(angle, position)
        
        Reset odometry to specified values.
        
        Parameters
        ----------
        angle : float
            New angle [rad].
        position : numpy.ndarray
            New position [m].
        
        Examples
        --------
        >>> import numpy as np
        >>> # Reset odometry to origin
        >>> robot.reset_odometry(angle=0.0, position=np.array([0.0, 0.0]))
        >>> # Reset to specific position and orientation
        >>> robot.reset_odometry(angle=np.pi/2, position=np.array([1.0, 2.0]))
        >>> # Useful for mobile base navigation
        >>> # Position is [x, y] in meters, angle is yaw in rad
        """
    def reset_parameter(self, name: str) -> bool:
        """
        Reset a parameter to its current value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def reset_parameter_to_default(self, name: str) -> bool:
        """
        Reset a parameter to its default value (deprecated).
        
        Parameters
        ----------
        name : str
            Parameter name.
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_parameter` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_parameter() instead.
        """
    def scan_wifi(self) -> list[WifiNetwork]:
        """
        Scan for available WiFi networks.
        
        Returns
        -------
        list
            List of available WiFi networks.
        
        Examples
        --------
        >>> # Scan for available WiFi networks
        >>> networks = robot.scan_wifi()
        >>> print(f"Found {len(networks)} networks")
        >>> # List network information
        >>> for network in networks:
        ...     print(f"SSID: {network.ssid}, Signal: {network.signal_strength}")
        >>> # Connect to a network
        >>> if networks:
        ...     robot.connect_wifi(networks[0].ssid, "password")
        """
    def send_command(self, builder: RobotCommandBuilder, priority: int = 1) -> Robot_UB_CommandHandler:
        """
        Send a command to the robot.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandHandler
            Command handler for monitoring execution.
        
        Examples
        --------
        >>> from rby1_sdk import RobotCommandBuilder, ComponentBasedCommandBuilder
        >>> from rby1_sdk import BodyComponentBasedCommandBuilder, JointPositionCommandBuilder
        >>> # Create command with method chaining (standard pattern)
        >>> command = RobotCommandBuilder().set_command(
        ...     ComponentBasedCommandBuilder().set_body_command(
        ...         BodyComponentBasedCommandBuilder()
        ...             .set_torso_command(
        ...                 JointPositionCommandBuilder()
        ...                     .set_position([0, 0, 0, 0, 0, 0])  # 6-DOF torso
        ...                     .set_minimum_time(2.0)
        ...             )
        ...     )
        ... )
        >>> handler = robot.send_command(command)
        >>> handler.wait()  # Wait for completion
        >>> # This pattern is used in most examples: examples/python/07_impedance_control.py, 09_demo_motion.py, etc.
        """
    def servo_off(self, dev_name: str) -> bool:
        """
        Disable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to disable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> # Disable servo control for safety
        >>> robot.servo_off(".*")  # All motor drivers
        >>> # Specific device: robot.servo_off("^torso_.*")
        """
    def servo_on(self, dev_name: str) -> bool:
        """
        Enable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to enable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_servo_on(".*"):
        ...     robot.servo_on(".*")  # Servo on all devices
        ...     print("All devices servoed on")
        >>> # Specific device: robot.servo_on("^torso_.*"), robot.servo_on("^right_arm_.*"), etc.
        """
    def set_battery_config(self, cutoff_voltage: float, fully_charged_voltage: float, coefficients: typing.Annotated[list[float], pybind11_stubgen.typing_ext.FixedSize(4)]) -> bool:
        """
        Set battery configuration.
        """
    def set_battery_level(self, arg0: float) -> bool:
        """
        Set battery level.
        
        Parameters
        ----------
        level : float
            Battery level percentage (0.0 to 100.0).
        
        Examples
        --------
        >>> # Set battery level for testing
        >>> robot.set_battery_level(100.0)  # Full battery
        >>> robot.set_battery_level(50.0)   # Half battery
        >>> robot.set_battery_level(25.0)   # Quarter battery
        >>> robot.set_battery_level(0.0)    # Empty battery
        >>> # Range: 0.0 to 100.0
        >>> # Useful for using custom battery
        """
    def set_led_color(self, color: Color, duration: float = 1, transition_time: float = 0, blinking: bool = False, blinking_freq: float = 1) -> bool:
        """
        Set LED color.
        
        Parameters
        ----------
        color : Color
            LED color.
        duration : float, optional
            Duration in seconds. Default is 1.
        transition_time : float, optional
            Transition time in seconds. Default is 0.
        blinking : bool, optional
            Whether to blink. Default is False.
        blinking_freq : float, optional
            Blinking frequency in Hz. Default is 1.
        
        Examples
        --------
        >>> from rby1_sdk import Color
        >>> # Set LED to red for 5 seconds
        >>> robot.set_led_color(Color(255, 0, 0), duration=5.0)
        >>> # Set LED to green with 1 second transition
        >>> robot.set_led_color(Color(0, 255, 0), transition_time=1.0)
        >>> # Set LED to blue with blinking
        >>> robot.set_led_color(Color(0, 0, 255), blinking=True, blinking_freq=2.0)
        >>> # Set LED to white with custom duration and transition
        >>> robot.set_led_color(Color(255, 255, 255), duration=10.0, transition_time=2.0)
        """
    def set_parameter(self, name: str, value: str, write_db: bool = True) -> bool:
        """
        Set a robot parameter.
        
        Parameters
        ----------
        name : str
            Parameter name.
        value : any
            Parameter value.
        write_db : bool, optional
            Whether to write to database. Default is True.
        
        Examples
        --------
        >>> # Set acceleration limit scaling
        >>> robot.set_parameter("default.acceleration_limit_scaling", "0.8")
        >>> # Set joint position command cutoff frequency
        >>> robot.set_parameter("joint_position_command.cutoff_frequency", "5")
        >>> # Set hotspot SSID name
        >>> robot.set_parameter("hotspot.ssid", "\\"RBY1_HOTSPOT\\"") # For str value, use escaped quotes
        >>> # Set without writing to database (Return ``False`` if matching parameter not found)
        >>> robot.set_parameter("temp.parameter", "value", write_db=False)
        False
        """
    def set_position_d_gain(self, dev_name: str, d_gain: int) -> bool:
        """
        Set position D gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        d_gain : int
            D gain value.
        
        Examples
        --------
        >>> # Set D gain for specific devices
        >>> robot.set_position_d_gain("torso_5", 400)
        """
    def set_position_i_gain(self, dev_name: str, i_gain: int) -> bool:
        """
        Set position I gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        i_gain : int
            I gain value.
        
        Examples
        --------
        >>> # Set I gain for specific devices
        >>> robot.set_position_i_gain("torso_5", 40)
        """
    def set_position_p_gain(self, dev_name: str, p_gain: int) -> bool:
        """
        Set position P gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        
        Examples
        --------
        >>> # Set P gain for specific devices
        >>> robot.set_position_p_gain("torso_5", 220)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, p_gain: int, i_gain: int, d_gain: int) -> bool:
        """
        Set position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        i_gain : int
            I gain value.
        d_gain : int
            D gain value.
        
        Returns
        -------
        bool
            True if successful, False otherwise.
        
        Examples
        --------
        >>> # Set all PID gains at once for a device
        >>> robot.set_position_pid_gain("right_arm_0", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_1", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_2", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_3", 35, 5, 80)
        >>> robot.set_position_pid_gain("right_arm_4", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_5", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_6", 100, 5, 120)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, pid_gain: PIDGain) -> bool:
        """
        Set position PID gains for a device using PIDGain object.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        pid_gain : PIDGain
            PID gain object.
        
        Returns
        -------
        bool
            True if successful, False otherwise.
        """
    def set_preset_position(self, joint_name: str) -> bool:
        """
        Set preset position for a joint (only available for PVL-based motors).
        
        Parameters
        ----------
        joint_name : str
            Joint name to set preset position.
        
        Examples
        --------
        >>> # Set preset position for specific joints
        >>> robot.set_preset_position("right_arm_6")  # Right arm joint 6
        >>> # Preset position is used as reference for home offset
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any) -> bool:
        """
        Set robot system time.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any, time_zone: str) -> bool:
        """
        Set robot system time with timezone.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        time_zone : str
            Timezone string.
        """
    def set_time_scale(self, time_scale: float) -> float:
        """
        Set the time scale for motion execution.
        
        Parameters
        ----------
        time_scale : float
            Time scale value (0.0 to 1.0).
        
        Examples
        --------
        >>> # Set time scale for motion execution
        >>> robot.set_time_scale(1.0)   # Normal speed (100%)
        >>> robot.set_time_scale(0.5)   # Half speed (50%)
        >>> robot.set_time_scale(0.25)  # Quarter speed (25%)
        >>> # Range: 0.0 (stopped) to 1.0 (full speed)
        >>> # Useful for testing and safety
        """
    def set_tool_flange_digital_output(self, name: str, channel: int, state: bool) -> bool:
        """
        Set the digital output state of a specific channel on the tool flange
        of the specified arm.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        channel : int
            Digital output channel index.
        state : bool
            Desired state of the digital output (``True`` = ON, ``False`` = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 on the right arm tool flange
        >>> robot.set_tool_flange_digital_output("right", 0, True)
        """
    def set_tool_flange_digital_output_dual(self, name: str, state_0: bool, state_1: bool) -> bool:
        """
        Set the digital output states of two channels on the tool flange
        of the specified arm simultaneously.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        state_0 : bool
            Desired state for digital output channel 0 (True = ON, False = OFF).
        state_1 : bool
            Desired state for digital output channel 1 (True = ON, False = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 and turn off channel 1 on the left arm tool flange
        >>> robot.set_tool_flange_digital_output_dual("left", True, False)
        """
    def set_tool_flange_output_voltage(self, name: str, voltage: int) -> bool:
        """
        Set tool flange output voltage.
        
        Parameters
        ----------
        name : str
            Tool flange name `"right"` or `"left"`.
        
        voltage : int
            Output voltage in volts.
        
        Examples
        --------
        >>> # Set tool flange output voltage
        >>> robot.set_tool_flange_output_voltage("right", 12)  # 12V output
        >>> robot.set_tool_flange_output_voltage("left", 24)  # 24V output
        >>> # Common voltages: 12V, 24V
        >>> # Use 0V to turn off output
        >>> # Note: This method sets voltage for both tool flanges (right and left)
        """
    def start_log_stream(self, cb: typing.Callable[[list[Log]], None], rate: float) -> None:
        """
        Start log stream callback.
        
        Parameters
        ----------
        cb : callable
            Callback function for log updates.
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def log_callback(log_entries):
        ...     for log in log_entries:
        ...         print(f"{log.timestamp} - {log.level} - {log.message}")
        >>> # Start log stream at 10 Hz
        >>> robot.start_log_stream(log_callback, 10.0)
        >>> # Stop when done: robot.stop_log_stream()
        """
    def start_state_update(self, cb: typing.Callable, rate: float) -> None:
        """
        Start state update callback.
        
        Parameters
        ----------
        cb : callable
            Callback function with 1 or 2 parameters:
            - cb(robot_state) or cb(robot_state, control_manager_state)
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def state_callback(robot_state):
        ...     print(f"Timestamp: {robot_state.timestamp}, Joint positions: {robot_state.position}")
        >>> # Start state updates at 100 Hz
        >>> robot.start_state_update(state_callback, 100.0)
        >>> # Stop when done: robot.stop_state_update()
        """
    def start_time_sync(self, period_sec: int) -> bool:
        """
        Start time synchronization.
        
        Parameters
        ----------
        period_sec : float
            Synchronization period in seconds.
        """
    def stop_log_stream(self) -> None:
        """
        Stop log stream callback.
        """
    def stop_state_update(self) -> None:
        """
        Stop state update callback.
        """
    def stop_time_sync(self) -> bool:
        """
        Stop time synchronization.
        """
    def sync_time(self) -> bool:
        """
        Synchronizes the timestamp of ``RobotState`` to UPC time instead of UTC. 
        Useful when synchronizing multiple devices to UPC time.
        """
    def wait_for_control_ready(self, timeout_ms: int) -> bool:
        """
        Wait until the robot is ready to accept control commands.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if the robot is ready to accept control (you can now set control).
            ``False`` if the timeout expired before the robot became ready.
        
        Examples
        --------
        >>> # Wait for control to be ready
        >>> if robot.wait_for_control_ready(timeout_ms=5000):
        ...     print("Control is ready, you can now set control commands.")
        ... else:
        ...     print("Timeout: control is not ready.")
        >>> # Call after servo_on() and before sending control commands
        """
class Robot_UB_CommandHandler:
    """
    Robot (model: ``Model_UB``) command handler.
    
    Handles robot command execution and provides status monitoring.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        Cancel the command execution.
        """
    def get(self) -> RobotCommandFeedback:
        """
        Wait for the command execution and get feedback
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def get_status(self) -> bool:
        """
        Get gRPC status
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            ``True`` if command is complete, ``False`` otherwise.
        """
    def wait(self) -> None:
        """
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
    def wait_for(self, timeout_ms: int) -> bool:
        """
        Wait for the command execution with timeout.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if command completed, ``False`` if timeout.
        """
class Robot_UB_CommandStreamHandler:
    """
    Robot (model: ``Model_UB``) command stream handler.
    
    Handles robot command execution through streaming with send and feedback capabilities.
    
    Attributes
    ----------
    is_done : bool
        Whether the command execution is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        Cancel the current command execution.
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            True if command is complete, False otherwise.
        """
    def request_feedback(self, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        Request feedback from the robot.
        
        Parameters
        ----------
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def send_command(self, builder: RobotCommandBuilder, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        Send a command through the stream.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def wait(self) -> None:
        ...
    def wait_for(self, timeout_ms: int) -> bool:
        """
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
class Robot_UB_ControlInput:
    """
    Robot (model: ``Model_UB``) control input.
    
    Represents control input parameters for robot real-time control including mode, target, and gains.
    
    Attributes
    ----------
    mode : numpy.ndarray
        Control mode for each joint (boolean array).
    target : numpy.ndarray
        Target positions for each joint [rad].
    feedback_gain : numpy.ndarray
        Feedback gains for each joint.
    feedforward_torque : numpy.ndarray
        Feedforward torque for each joint [Nm].
    finish : bool
        Whether to finish the current control operation.
    """
    feedback_gain: numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.uint32]]
    feedforward_torque: numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]
    finish: bool
    mode: numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.bool_]]
    target: numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]
    def __init__(self) -> None:
        """
        Construct a ``ControlInput`` instance.
        
        Attributes
        ----------
        mode : numpy.ndarray, shape (DOF,)
            Control mode for each joint (boolean array).
        target : numpy.ndarray, shape (DOF,)
            Target positions for each joint [rad].
        feedback_gain : numpy.ndarray, shape (DOF,)
            Feedback gains for each joint.
        feedforward_torque : numpy.ndarray, shape (DOF,)
            Feedforward torque for each joint [Nm].
        finish : bool
            Whether to finish the current control operation.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
class Robot_UB_ControlState:
    """
    Robot (model: ``Model_UB``) control state.
    
    Represents the current state of robot real-time control including position, velocity, and torque.
    
    Attributes
    ----------
    t : float
        Current time in seconds.
    is_ready : numpy.ndarray
        Whether the joint is ready for control.
    position : numpy.ndarray, shape (DOF,)
        Current joint positions [rad].
    velocity : numpy.ndarray, shape (DOF,)
        Current joint velocities [rad/s].
    current : numpy.ndarray, shape (DOF,)
        Current joint currents [A].
    torque : numpy.ndarray, shape (DOF,)
        Current joint torques [Nm].
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        ...
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def t(self) -> float:
        ...
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
class SE2VelocityCommandBuilder:
    """
    
    SE(2) velocity command builder.
    
    Defines planar velocity commands in SE(2) space (x, y translation and yaw rotation).
    The target velocity is reached by linear ramp-up/ramp-down subject to acceleration
    limits and the specified minimum execution time.
    
    Examples
    --------
    Move forward at 0.5 m/s while yawing at 0.2 rad/s, with limits and minimum time:
    
    >>> import numpy as np, rby1_sdk as rby
    >>> se2 = (
    ...     rby.SE2VelocityCommandBuilder()
    ...     .set_velocity(np.array([0.5, 0.0]), 0.2)        # [vx, vy], wz
    ...     .set_acceleration_limit(np.array([1.0, 1.0]), 0.5)
    ...     .set_minimum_time(1.0)
    ... )
    >>> # (Optional) hold the commanded velocity after ramping:
    >>> header = rby.CommandHeaderBuilder().set_control_hold_time(3.0)
    >>> se2.set_command_header(header)
    >>> cmd = rby.RobotCommandBuilder().set_command(
    ...     rby.ComponentBasedCommandBuilder().set_mobility_command(
    ...         rby.MobilityCommandBuilder().set_command(se2)
    ...     )
    ... )
    >>> # robot.send_command(cmd, priority=1).get()
    """
    def __init__(self) -> None:
        """
        Construct an SE2VelocityCommandBuilder instance.
        """
    def set_acceleration_limit(self, linear: numpy.ndarray[tuple[typing.Literal[2], typing.Literal[1]], numpy.dtype[numpy.float64]], angular: float) -> SE2VelocityCommandBuilder:
        """
        Set maximum acceleration limits for the SE(2) command.
        
        Parameters
        ----------
        linear : numpy.ndarray, shape (2,), dtype=float64
            Maximum linear accelerations along x and y axes [m/s²].
        angular : float
            Maximum angular acceleration around the z-axis [rad/s²].
        
        Returns
        -------
        SE2VelocityCommandBuilder
            Self reference for method chaining.
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> SE2VelocityCommandBuilder:
        """
        Attach a command header.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header configuration (e.g., control hold time).
        
        Returns
        -------
        SE2VelocityCommandBuilder
            Self reference for method chaining.
        """
    def set_minimum_time(self, minimum_time: float) -> SE2VelocityCommandBuilder:
        """
        Set the minimum execution time.
        
        Parameters
        ----------
        minimum_time : float
            Minimum execution time [s]. Ensures the ramp toward the target velocity
            spans at least this duration.
        
        Returns
        -------
        SE2VelocityCommandBuilder
            Self reference for method chaining.
        """
    def set_velocity(self, linear: numpy.ndarray[tuple[typing.Literal[2], typing.Literal[1]], numpy.dtype[numpy.float64]], angular: float) -> SE2VelocityCommandBuilder:
        """
        Set the target SE(2) velocity.
        
        Parameters
        ----------
        linear : numpy.ndarray, shape (2,), dtype=float64
            Linear velocity along x and y axes [m/s].
        angular : float
            Angular velocity around the z-axis [rad/s].
        
        Returns
        -------
        SE2VelocityCommandBuilder
            Self reference for method chaining.
        
        Notes
        -----
        - To maintain the commanded velocity after reaching it, set a control hold time
          via ``CommandHeaderBuilder`` and attach it with ``set_command_header``.
        """
class SE2VelocityCommandFeedback(CommandFeedback):
    """
    
    Feedback for an SE(2) base velocity command.
    
    (Contains only header-level fields via :pyattr:`CommandFeedback.command_header`.)
    """
    def __init__(self) -> None:
        """
              Construct an ``SE2VelocityCommandFeedback`` instance.
        """
class SerialDevice:
    """
    
    Serial device information.
    
    Represents information about a serial device.
    
    Attributes
    ----------
    path : str
        Device path (e.g., "/dev/ttyUSB0").
    description : str
        Device description.
    """
    def __init__(self) -> None:
        """
        Construct a ``SerialDevice`` instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def description(self) -> str:
        ...
    @property
    def path(self) -> str:
        ...
class SerialStream:
    """
    
    Serial communication stream.
    
    Provides serial communication functionality with read/write operations
    and callback support.
    
    Attributes
    ----------
    is_opened : bool
        Whether the stream is currently open.
    is_cancelled : bool
        Whether the stream operation was cancelled.
    is_done : bool
        Whether the stream operation is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def connect(self, verbose: bool) -> bool:
        """
        Connect to the serial device.
        
        Parameters
        ----------
        verbose : bool
            Whether to enable verbose output.
        
        Returns
        -------
        bool
            True if connection successful, False otherwise.
        """
    def disconnect(self) -> None:
        """
        Disconnect from the serial device.
        """
    def is_cancelled(self) -> bool:
        """
        Check if the stream operation was cancelled.
        
        Returns
        -------
        bool
            True if operation was cancelled, False otherwise.
        """
    def is_done(self) -> bool:
        """
        is_done()
        
        Check if the stream operation is complete.
        
        Returns
        -------
        bool
            True if operation is complete, False otherwise.
        """
    def is_opened(self) -> bool:
        """
        is_opened()
        
        Check if the stream is currently open.
        
        Returns
        -------
        bool
            True if stream is open, False otherwise.
        """
    def set_read_callback(self, arg0: typing.Callable[[bytes], None]) -> None:
        """
        Set a callback function for read operations.
        
        Parameters
        ----------
        cb : callable
            Callback function that receives bytes data.
        
        Examples
        --------
        >>> dev = robot.open_serial_stream(device_path, baudrate)
        >>> connected = dev.connect(verbose=True)
        >>> if not connected:
        ...     print("Failed to connect")
        ...     exit(1)
        >>> print("Listening for incoming data...\\n")
        >>> def print_hex(data):
        ...     hex_string = "".join(f"{int(ch):02X}" for ch in data)
        ...     print(f"<< {hex_string}", flush=True)
        >>> dev.set_read_callback(print_hex)
        """
    def wait(self) -> None:
        """
        Wait for the stream operation to complete.
        
        This method blocks until the operation is done or cancelled.
        """
    def wait_for(self, timeout_ms: int) -> bool:
        """
        Wait for the stream operation with timeout.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if operation completed, ``False`` if timeout.
        """
    @typing.overload
    def write(self, data: str) -> bool:
        """
        Write character data to the serial stream.
        
        Parameters
        ----------
        data : str
            Character data to write.
        """
    @typing.overload
    def write(self, data: str) -> bool:
        """
        Write character data with specified length to the serial stream.
        
        Parameters
        ----------
        data : str
            Character data to write.
        n : int
            Number of characters to write.
        """
    @typing.overload
    def write(self, data: str, n: int) -> bool:
        """
        Write character data with specified length to the serial stream.
        
        Parameters
        ----------
        data : str
            Character data to write.
        n : int
            Number of characters to write.
        """
    def write_byte(self, ch: str) -> bool:
        """
        Write a single byte to the serial stream.
        
        Parameters
        ----------
        ch : int
            Byte value to write [0, 255].
        """
class StopCommandBuilder:
    """
    
    Stop command builder.
    
    Generates a stop command that halts all robot motion immediately.
    Typically used in whole-body command contexts to enforce a safe and
    deterministic stop.
    
    Examples
    --------
    >>> import rby1_sdk as rby
    >>> stop = rby.StopCommandBuilder()
    >>> cmd = rby.RobotCommandBuilder().set_command(
    ...     rby.WholeBodyCommandBuilder().set_command(stop)
    ... )
    >>> # robot.send_command(cmd, priority=1).get()
    """
    def __init__(self) -> None:
        """
        Construct a StopCommandBuilder instance.
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> StopCommandBuilder:
        """
        Attach a command header.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header configuration (e.g., control hold time).
        
        Returns
        -------
        StopCommandBuilder
            Self reference for method chaining.
        """
class StopCommandFeedback(CommandFeedback):
    """
    
    Feedback for a whole-body stop command.
    
    (Contains only header-level fields via :pyattr:`CommandFeedback.command_header`.)
    """
    def __init__(self) -> None:
        """
              Construct a ``StopCommandFeedback`` instance.
        """
class SystemStat:
    """
    
    System statistics information.
    
    Provides information about system performance including CPU and memory usage.
    
    Attributes
    ----------
    cpu_usage : float
        CPU usage percentage [0.0, 100.0].
    memory_usage : float
        Memory usage percentage [0.0, 100.0].
    uptime : float
        System uptime in seconds.
    program_uptime : float
        Program uptime in seconds.
      
    """
    def __init__(self) -> None:
        """
              Construct a ``SystemStat`` instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def cpu_usage(self) -> float:
        ...
    @property
    def memory_usage(self) -> float:
        ...
    @property
    def program_uptime(self) -> float:
        ...
    @property
    def uptime(self) -> float:
        ...
class ToolFlangeState:
    """
    
    Tool flange state information.
    
    Provides information about tool flange sensors and outputs.
    
    Attributes
    ----------
    time_since_last_update : datetime.timedelta
        Time since last update as a Python timedelta.
    gyro : numpy.ndarray, shape (3,), dtype=float64
        Gyroscope readings [rad/s].
    acceleration : numpy.ndarray, shape (3,), dtype=float64
        Acceleration readings in m/s².
    switch_A : bool
        Status of switch A.
    output_voltage : float
        Output voltage in volts.
    digital_input_A : bool
        Status of digital input A.
    digital_input_B : bool
        Status of digital input B.
    digital_output_A : bool
        Status of digital output A.
    digital_output_B : bool
        Status of digital output B.
    """
    def __init__(self) -> None:
        """
        Construct a ToolFlangeState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def acceleration(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def digital_input_A(self) -> bool:
        ...
    @property
    def digital_input_B(self) -> bool:
        ...
    @property
    def digital_output_A(self) -> bool:
        ...
    @property
    def digital_output_B(self) -> bool:
        ...
    @property
    def gyro(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
    @property
    def output_voltage(self) -> int:
        ...
    @property
    def switch_A(self) -> bool:
        ...
    @property
    def time_since_last_update(self) -> datetime.timedelta:
        ...
class TorsoCommandBuilder:
    """
    
    Torso command builder.
    
    Builds commands specifically for the torso component.  
    Accepts different command types (joint position, impedance, Cartesian, etc.) and wraps them into a torso command.
    
    Notes
    -----
    - You can pass a command builder (e.g., `JointPositionCommandBuilder`) directly into
      `.set_torso_command(...)` without explicitly creating a `TorsoCommandBuilder`.  
      Implicit casting automatically wraps it:  
      `TorsoCommandBuilder(JointPositionCommandBuilder)` is created internally.  
      Therefore, directly using `TorsoCommandBuilder` is often unnecessary unless you want
      to explicitly wrap or extend torso-specific logic.
    
    Examples
    --------
    >>> import numpy as np, rby1_sdk as rby
    >>> torso_cmd = (
    ...     rby.TorsoCommandBuilder(
    ...         rby.JointPositionCommandBuilder().set_position(np.zeros(6))
    ...     )
    ... )
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Construct an empty TorsoCommandBuilder.
        """
    @typing.overload
    def __init__(self, joint_position_command_builder: JointPositionCommandBuilder) -> None:
        """
        Construct from a joint position command.
        
        Parameters
        ----------
        joint_position_command_builder : JointPositionCommandBuilder
            Command specifying torso joint positions.
        """
    @typing.overload
    def __init__(self, gravity_compensation_command_builder: GravityCompensationCommandBuilder) -> None:
        """
        Construct from a gravity compensation command.
        
        Parameters
        ----------
        gravity_compensation_command_builder : GravityCompensationCommandBuilder
            Command enabling/disabling gravity compensation for the torso.
        """
    @typing.overload
    def __init__(self, cartesian_command_builder: CartesianCommandBuilder) -> None:
        """
        Construct from a Cartesian command.
        
        Parameters
        ----------
        cartesian_command_builder : CartesianCommandBuilder
            Command specifying Cartesian targets for the torso.
        """
    @typing.overload
    def __init__(self, impedance_control_command_builder: ImpedanceControlCommandBuilder) -> None:
        """
        Construct from a Cartesian impedance control command.
        
        Parameters
        ----------
        impedance_control_command_builder : ImpedanceControlCommandBuilder
            Command specifying Cartesian impedance for the torso.
        """
    @typing.overload
    def __init__(self, optimal_control_command_builder: OptimalControlCommandBuilder) -> None:
        """
        Construct from an optimal control command.
        
        Parameters
        ----------
        optimal_control_command_builder : OptimalControlCommandBuilder
            Command specifying optimal control targets/costs for the torso.
        """
    @typing.overload
    def __init__(self, joint_impedance_control_command_builder: JointImpedanceControlCommandBuilder) -> None:
        """
        Construct from a joint impedance control command.
        
        Parameters
        ----------
        joint_impedance_control_command_builder : JointImpedanceControlCommandBuilder
            Command specifying joint-space impedance for the torso.
        """
    @typing.overload
    def __init__(self, cartesian_impedance_control_command_builder: CartesianImpedanceControlCommandBuilder) -> None:
        """
        Construct from a Cartesian impedance control command.
        
        Parameters
        ----------
        cartesian_impedance_control_command_builder : CartesianImpedanceControlCommandBuilder
            Command specifying Cartesian impedance control for the torso.
        """
    @typing.overload
    def __init__(self, joint_group_position_command_builder: JointGroupPositionCommandBuilder) -> None:
        """
        Construct from a joint group position command.
        
        Parameters
        ----------
        joint_group_position_command_builder : JointGroupPositionCommandBuilder
            Command specifying joint positions for a named torso joint group.
        """
    @typing.overload
    def set_command(self, joint_position_command_builder: JointPositionCommandBuilder) -> TorsoCommandBuilder:
        """
        Set the torso command from a joint position builder.
        
        Parameters
        ----------
        joint_position_command_builder : JointPositionCommandBuilder
            Command specifying torso joint positions.
        
        Returns
        -------
        TorsoCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, gravity_compensation_command_builder: GravityCompensationCommandBuilder) -> TorsoCommandBuilder:
        """
        Set the torso command from a gravity compensation builder.
        
        Parameters
        ----------
        gravity_compensation_command_builder : GravityCompensationCommandBuilder
            Command enabling/disabling torso gravity compensation.
        
        Returns
        -------
        TorsoCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, cartesian_command_builder: CartesianCommandBuilder) -> TorsoCommandBuilder:
        """
        Set the torso command from a Cartesian builder.
        
        Parameters
        ----------
        cartesian_command_builder : CartesianCommandBuilder
            Command specifying Cartesian pose targets for the torso.
        
        Returns
        -------
        TorsoCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, impedance_control_command_builder: ImpedanceControlCommandBuilder) -> TorsoCommandBuilder:
        """
        Set the torso command from a Cartesian impedance builder.
        
        Parameters
        ----------
        impedance_control_command_builder : ImpedanceControlCommandBuilder
            Command specifying Cartesian impedance for the torso.
        
        Returns
        -------
        TorsoCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, optimal_control_command_builder: OptimalControlCommandBuilder) -> TorsoCommandBuilder:
        """
        Set the torso command from an optimal control builder.
        
        Parameters
        ----------
        optimal_control_command_builder : OptimalControlCommandBuilder
            Command specifying optimal control targets/costs for the torso.
        
        Returns
        -------
        TorsoCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, joint_impedance_control_command_builder: JointImpedanceControlCommandBuilder) -> TorsoCommandBuilder:
        """
        Set the torso command from a joint impedance builder.
        
        Parameters
        ----------
        joint_impedance_control_command_builder : JointImpedanceControlCommandBuilder
            Command specifying joint-space impedance for the torso.
        
        Returns
        -------
        TorsoCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, cartesian_impedance_control_command_builder: CartesianImpedanceControlCommandBuilder) -> TorsoCommandBuilder:
        """
        Set the torso command from a Cartesian impedance builder.
        
        Parameters
        ----------
        cartesian_impedance_control_command_builder : CartesianImpedanceControlCommandBuilder
            Command specifying Cartesian impedance control for the torso.
        
        Returns
        -------
        TorsoCommandBuilder
            Self reference for method chaining.
        """
    @typing.overload
    def set_command(self, joint_group_position_command_builder: JointGroupPositionCommandBuilder) -> TorsoCommandBuilder:
        """
        Set the torso command from a joint group position builder.
        
        Parameters
        ----------
        joint_group_position_command_builder : JointGroupPositionCommandBuilder
            Command specifying joint positions for a named torso joint group.
        
        Returns
        -------
        TorsoCommandBuilder
            Self reference for method chaining.
        """
class TorsoCommandFeedback(CommandFeedback):
    """
    
    Feedback for a torso command container.
    
    Attributes
    ----------
    joint_position_command : JointPositionCommandFeedback
        Feedback for a joint position command (if present).
    gravity_compensation_command : GravityCompensationCommandFeedback
        Feedback for a gravity compensation command (if present).
    cartesian_command : CartesianCommandFeedback
        Feedback for a Cartesian command (if present).
    impedance_control_command : ImpedanceControlCommandFeedback
        Feedback for a Cartesian impedance command (if present).
    optimal_control_command : OptimalControlCommandFeedback
        Feedback for an optimal-control command (if present).
    cartesian_impedance_control_command : CartesianImpedanceControlCommandFeedback
        Feedback for a Cartesian impedance (OC + joint-space impedance) command (if present).
    joint_impedance_control_command : JointImpedanceControlCommandFeedback
        Feedback for a joint-space impedance command (if present).
    joint_group_position_command : JointGroupPositionCommandFeedback
        Feedback for a joint-group position command (if present).
    """
    def __init__(self) -> None:
        """
              Construct a ``TorsoCommandFeedback`` instance.
        """
    @property
    def cartesian_command(self) -> CartesianCommandFeedback:
        """
        Cartesian command feedback.
        
        Returns
        -------
        CartesianCommandFeedback
            Feedback object.
        """
    @property
    def cartesian_impedance_control_command(self) -> CartesianImpedanceControlCommandFeedback:
        """
        Cartesian impedance (OC + joint-space impedance) command feedback.
        
        Returns
        -------
        CartesianImpedanceControlCommandFeedback
            Feedback object.
        """
    @property
    def gravity_compensation_command(self) -> GravityCompensationCommandFeedback:
        """
        Gravity compensation command feedback.
        
        Returns
        -------
        GravityCompensationCommandFeedback
            Feedback object.
        """
    @property
    def impedance_control_command(self) -> ImpedanceControlCommandFeedback:
        """
        Cartesian impedance command feedback.
        
        Returns
        -------
        ImpedanceControlCommandFeedback
            Feedback object.
        """
    @property
    def joint_group_position_command(self) -> JointGroupPositionCommandFeedback:
        """
        Joint-group position command feedback.
        
        Returns
        -------
        JointGroupPositionCommandFeedback
            Feedback object.
        """
    @property
    def joint_impedance_control_command(self) -> JointImpedanceControlCommandFeedback:
        """
        Joint-space impedance command feedback.
        
        Returns
        -------
        JointImpedanceControlCommandFeedback
            Feedback object.
        """
    @property
    def joint_position_command(self) -> JointPositionCommandFeedback:
        """
        Joint position command feedback.
        
        Returns
        -------
        JointPositionCommandFeedback
            Feedback object.
        """
    @property
    def optimal_control_command(self) -> OptimalControlCommandFeedback:
        """
        Optimal-control command feedback.
        
        Returns
        -------
        OptimalControlCommandFeedback
            Feedback object.
        """
class WholeBodyCommandBuilder:
    """
    
    Whole-body command builder.
    
    Provides a builder interface to construct commands that apply to the **entire robot**.  
    Currently, its primary role is to wrap and send a StopCommand to halt all motion.
    
    Notes
    -----
    - While ComponentBasedCommandBuilder targets subsystems (mobility, body, head),
      WholeBodyCommandBuilder applies at the global level.
    
    Examples
    --------
    >>> import rby1_sdk as rby
    >>> # Construct a stop command for the whole robot
    >>> stop = rby.StopCommandBuilder()
    >>> whole = rby.WholeBodyCommandBuilder().set_command(stop)
    >>> cmd = rby.RobotCommandBuilder().set_command(whole)
    >>> # robot.send_command(cmd, priority=0).get()
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Construct a WholeBodyCommandBuilder instance.
        """
    @typing.overload
    def __init__(self, stop_command_builder: StopCommandBuilder) -> None:
        """
        Construct a WholeBodyCommandBuilder with an initial stop command.
        
        Parameters
        ----------
        stop_command_builder : StopCommandBuilder
            Stop command to initialize this builder with.
        """
    def set_command(self, stop_command_builder: StopCommandBuilder) -> WholeBodyCommandBuilder:
        """
        Assign a stop command to the whole body.
        
        Parameters
        ----------
        stop_command_builder : StopCommandBuilder
            Stop command to apply globally.
        
        Returns
        -------
        WholeBodyCommandBuilder
            Self reference for method chaining.
        """
class WholeBodyCommandFeedback(CommandFeedback):
    """
    
    Feedback for a whole-body command container.
    
    Attributes
    ----------
    stop_command : StopCommandFeedback
        Feedback of the contained stop command (if present).
    """
    def __init__(self) -> None:
        """
              Construct a ``WholeBodyCommandFeedback`` instance.
        """
    @property
    def stop_command(self) -> StopCommandFeedback:
        """
        Contained stop command feedback.
        
        Returns
        -------
        StopCommandFeedback
            Stop command feedback object.
        """
class WifiNetwork:
    """
    
    WiFi network information.
    
    This class represents information about a detected WiFi network
    including its SSID, signal strength, and security status.
    
    Attributes
    ----------
    ssid : str
        Service Set Identifier (network name).
    signal_strength : int
        Signal strength in dBm (decibels relative to milliwatts).
        Higher values indicate stronger signals.
        Typical range: -100 (very weak) to -30 (very strong).
    secured : bool
        Whether the network requires a password for connection.
        (True if the network requires a password, False otherwise.)
    """
    def __init__(self) -> None:
        """
          Construct a WifiNetwork instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def secured(self) -> bool:
        ...
    @property
    def signal_strength(self) -> int:
        ...
    @property
    def ssid(self) -> str:
        ...
class WifiStatus:
    """
    
    Current WiFi connection status.
    
    This class represents the current status of a WiFi connection
    including connection details and network configuration.
    
    Attributes
    ----------
    ssid : str
        Service Set Identifier of the connected network.
    ip_address : str
        IP address assigned to the device.
    gateway : str
        Gateway IP address for the network.
    dns : list[str]
        List of DNS server IP addresses.
    connected : bool
        Whether the device is currently connected to WiFi.
    """
    def __init__(self) -> None:
        """
        Construct a WifiStatus instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def connected(self) -> bool:
        ...
    @property
    def dns(self) -> list[str]:
        ...
    @property
    def gateway(self) -> str:
        ...
    @property
    def ip_address(self) -> str:
        ...
    @property
    def ssid(self) -> str:
        ...
class printoptions:
    """
    
    Context manager for temporary print options.
    
    Creates a thread-local scoped override of printing behavior for SDK objects and
    NumPy arrays. Upon exit, previous options are restored.
    
    `array_mode='numpy'` delegates arrays to NumPy's global printoptions; scalar formatting
    and `multiline_repr` still apply as configured.
    
    Examples
    --------
    >>> import rby1_sdk as sdk
    >>> with sdk.printoptions(array_mode='preview', precision=3, multiline_repr=False):
    ...     print(obj)        # one-line **str**, precision=3
    ...     print(repr(obj))  # one-line **repr** (multiline_repr=False)
    >>> with sdk.printoptions(array_mode='full', multiline_repr=True):
    ...     print(repr(obj))  # multi-line repr with full arrays
          
    """
    def __enter__(self) -> printoptions:
        """
        Return self and activate the context.
        """
    def __exit__(self, arg0: typing.Any, arg1: typing.Any, arg2: typing.Any) -> bool:
        """
        Restore previous options and propagate exceptions.
        """
    def __init__(self, array_mode: str | None = None, linewidth: int | None = None, precision: int | None = None, edgeitems: int | None = None, threshold: int | None = None, suppress_small: bool | None = None, multiline_repr: bool | None = None, float_style: str | None = None, sign: str | None = None, trim_trailing_zeros: bool | None = None) -> None:
        """
        __init__(array_mode=None, linewidth=None, precision=None, edgeitems=None, threshold=None,
                 suppress_small=None, multiline_repr=None, float_style=None, sign=None,
                 trim_trailing_zeros=None)
        
        All parameters are optional; only those provided are overridden in this context.
        """
def _create_robot(address: str, model: typing.Any = 'a') -> typing.Any:
    """
    Create a robot instance based on the provided model and address.
    
    Parameters
    ----------
    address : str
        Network address of the robot, e.g. "192.168.1.100:50051".
    model : str or Model, default='a'
        Robot model specification. Can be a string identifier or model object.
    
    Returns
    -------
    Robot
        Configured robot instance for the specified model.
    
    Raises
    ------
    RuntimeError
        If the model name is unknown or invalid.
    
    See Also
    --------
    create_robot_a : Create a Robot A model instance.
    create_robot_m : Create a Robot M model instance.
    create_robot_ub : Create a Robot UB model instance.
    
    Examples
    --------
    >>> import rby1_sdk as rby
    >>> robot = rby._create_robot("192.168.1.100:50051", "a")
    
    >>> robot = rby._create_robot("192.168.1.100:50051", model_a)
    """
def create_robot_a(address: str) -> Robot_A:
    """
    Create a ``Robot_A`` instance.
    
    Parameters
    ----------
    address : str
        Network address of the robot, e.g. "192.168.1.100:50051".
    
    Returns
    -------
    Robot
        Configured Robot A instance.
    
    Examples
    --------
    >>> from rby1_sdk import create_robot_a
    >>> robot = create_robot_a("192.168.1.100:50051")
    """
def create_robot_m(address: str) -> Robot_M:
    """
    Create a ``Robot_M`` instance.
    
    Parameters
    ----------
    address : str
        Network address of the robot, e.g. "192.168.1.100:50051".
    
    Returns
    -------
    Robot
        Configured Robot M instance.
    
    Examples
    --------
    >>> from rby1_sdk import create_robot_m
    >>> robot = create_robot_m("192.168.1.100:50051")
    """
def create_robot_ub(address: str) -> Robot_UB:
    """
    Create a ``Robot_UB`` instance.
    
    Parameters
    ----------
    address : str
        Network address of the robot, e.g. "192.168.1.100:50051".
    
    Returns
    -------
    Robot
        Configured Robot UB instance.
    
    Examples
    --------
    >>> from rby1_sdk import create_robot_ub
    >>> robot = create_robot_ub("192.168.1.100:50051")
    """
def set_printoptions(array_mode: str | None = None, linewidth: int | None = None, precision: int | None = None, edgeitems: int | None = None, threshold: int | None = None, suppress_small: bool | None = None, multiline_repr: bool | None = None, float_style: str | None = None, sign: str | None = None, trim_trailing_zeros: bool | None = None, scope: str | None = 'thread') -> None:
    """
    Set global or thread-local rby1_sdk print options.
    
    Controls how SDK objects and NumPy arrays are rendered by `__repr__`/`__str__`.
    `array_mode='numpy'` delegates array printing entirely to NumPy's global
    printoptions. `preview`/`full` make the SDK pass its options explicitly.
    
    `multiline_repr` toggles **`__repr__` only**; by convention `__str__` is kept one line.
    
    Parameters
    ----------
    array_mode : {'numpy', 'preview', 'full'}, optional
        - 'numpy'  : Fully delegate arrays to NumPy's global printoptions.
        - 'preview': Use SDK preview policy (threshold/edgeitems/linewidth/precision/sign/…).
        - 'full'   : Print full arrays (ignore threshold), other options still apply.
    linewidth : int, optional
        Target maximum line width for arrays (passed to NumPy when not 'numpy').
    precision : int, optional
        Decimal precision for scalars and arrays.
    edgeitems : int, optional
        Number of leading/trailing items to show when summarizing arrays.
    threshold : int, optional
        Total number of array elements that triggers summarization (ellipsis).
    suppress_small : bool, optional
        If True, very small floats are printed as 0 in arrays (when not 'numpy').
    multiline_repr : bool, optional
        If True, top-level `__repr__` of complex SDK objects uses multi-line, field-per-line
        formatting. Nested objects should be rendered one-line where reasonable.
    float_style : {'auto', 'default', 'fixed', 'scientific'}, optional
        Floating formatting style for scalars and (when not 'numpy') arrays.
    sign : {'auto', 'minus', 'plus', 'space'}, optional
        Sign policy. 'space' shows a leading space for positive numbers.
    trim_trailing_zeros : bool, optional
        If True, trailing zeros after the decimal point are trimmed (1.200 -> '1.2').
    scope : {'thread', 'global'}, optional
        - 'thread' (default): apply to the current Python thread (thread-local stack top).
        - 'global'          : update process-wide defaults.
    
    Notes
    -----
    - Options are maintained on a thread-local stack. Repeated calls update the top-of-stack
      for the current thread; using scope='global' updates process-wide defaults.
    - For temporary changes, prefer the context manager `printoptions(...)` below.
    
    Examples
    --------
    >>> import rby1_sdk as rby
    >>> rby.set_printoptions(array_mode='numpy', precision=4)  # arrays follow NumPy global config; scalars use precision=4
    >>> with rby.printoptions(array_mode='preview', precision=2, multiline_repr=True):
    ...     print(obj)        # one-line **str** with precision=2
    ...     print(repr(obj))  # multi-line **repr** (since multiline_repr=True)
    """
__version__: str = '0.9.1'

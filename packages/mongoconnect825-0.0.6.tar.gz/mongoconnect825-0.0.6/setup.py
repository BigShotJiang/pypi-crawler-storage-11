from setuptools import setup, find_packages
from typing import List

HYPEN_E_DOT = '-e .'

def get_requirements(file_path: str) -> List[str]:
    """Read requirements from a file and remove '-e .' if present."""
    requirements = []
    with open(file_path, "r") as f:
        requirements = f.readlines()
        requirements = [req.strip() for req in requirements if req.strip()]
        if HYPEN_E_DOT in requirements:
            requirements.remove(HYPEN_E_DOT)
    return requirements


with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

__version__ = "0.0.6"
REPO_NAME = "mongodb_connector"
PKG_NAME = "MongoConnect825"
AUTHOR_USER_NAME = "owais825"
AUTHOR_EMAIL = "owais825@gmail.com"

setup(
    name=PKG_NAME,
    version=__version__,
    author=AUTHOR_USER_NAME,
    author_email=AUTHOR_EMAIL,
    description="A Python package for connecting with MongoDB.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url=f"https://github.com/{AUTHOR_USER_NAME}/{REPO_NAME}",
    project_urls={
        "Bug Tracker": f"https://github.com/{AUTHOR_USER_NAME}/{REPO_NAME}/issues",
    },
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=get_requirements("requirements.txt"),
    python_requires =">=3.11",
)


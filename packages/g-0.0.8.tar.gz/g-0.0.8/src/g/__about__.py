"""Metadata package for g."""

from __future__ import annotations

__title__ = "g"
__package_name__ = "g"
__description__ = "CLI alias for your current directory's VCS command: git, svn, hg"
__version__ = "0.0.8"
__author__ = "Tony Narlock"
__github__ = "https://github.com/vcs-python/g"
__docs__ = "https://g.git-pull.com"
__tracker__ = "https://github.com/vcs-python/g/issues"
__pypi__ = "https://pypi.org/project/g/"
__email__ = "tony@git-pull.com"
__license__ = "MIT"
__copyright__ = "Copyright 2022- Tony Narlock"

class UserError(Exception):
    pass

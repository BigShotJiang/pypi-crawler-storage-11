"""entitysdk tests."""

"""Tests for SourceScribe."""

def main():
    print("Hello, time to take rest.")


if __name__ == "__main__":
    main()

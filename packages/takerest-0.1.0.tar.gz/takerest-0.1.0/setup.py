from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="takerest",
    version="0.1.0",
    author="anirudhisonline",
    description="takerest cli",
    url="https://github.com/takerestdev/takerest",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "takerest=takerest.cli:main",
        ],
    },
)

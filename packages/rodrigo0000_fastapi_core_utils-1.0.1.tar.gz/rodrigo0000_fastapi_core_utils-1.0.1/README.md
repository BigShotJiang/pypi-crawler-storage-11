# rodrigo0000-fastapi-core-utils

Utility functions for FastAPI applications.

## Features

- Common utility functions
- Validation helpers
- Data transformation utilities
- String manipulation
- Date/time utilities

## Installation

```bash
pip install rodrigo0000-fastapi-core-utils
```

## Usage

```python
from rodrigo0000_fastapi_core_utils import validate_email, generate_random_string

# Validate email
is_valid = validate_email("user@example.com")

# Generate random string
random_str = generate_random_string(length=32)
```

## Components

- **Validation Utils**: Email, phone, URL validation
- **String Utils**: Random string generation, slugify, etc.
- **Date Utils**: Date formatting and parsing
- **Data Utils**: Data transformation and manipulation

## Requirements

- Python >= 3.8
- Pydantic >= 2.0.0

## License

MIT License

## Author

R Firm - Professional SaaS Development

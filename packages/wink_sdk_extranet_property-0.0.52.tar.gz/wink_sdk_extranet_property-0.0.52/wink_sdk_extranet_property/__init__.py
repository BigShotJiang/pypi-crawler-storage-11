# coding: utf-8

# flake8: noqa

"""
    Wink API

     # Introduction  Welcome to the Wink API - A programmer-friendly way to manage, sell and book travel inventory on the Wink platform. The API gives you all the tools you need to ready your properties and inventory for sale across 1000s of our native sales channels.  Integrators, affiliates, travel agents and content creators have the ability search for your travel inventory and promote / sell it in a wide variety of ways.   # Integrations  We have already integrated with the most well-known channel managers so you don't have to. To see our current integrations, please go to https://extranet.wink.travel and scroll to Connectivity section. Once your properties are set up, you can finish the setup by mapping your property to Wink using your channel manager partner portal. If your properties don't have a channel manager, you can easily manage rates and availability with this API.   # Intended Audience  Programmers are [most likely] a requirement to start integrating with Wink. Companies and organizations that would most benefit from integrating with us are new and existing travel companies that have relationships with suppliers and that need an advanced system from which to manage their travel inventory and get that same inventory out to as many eyeballs as possible at the lowest price possible.  - Hotel chains  - Hotel brands  - Travel tech companies  - Destination sites  - Integrators  - Aggregators  - Destination management companies  - Travel agencies  - OTAs   ## APIs  Not every integrator needs every API. For that reason, we have separated APIs into context.  ### Test API   - [Ping](/ping): The Ping API is a quick test endpoint to verify that your credentials work Wink.  ### Common APIs  - [Notifications](/notifications): The Notifications API is a way for us to stay in touch with your user, property or affiliate account. - [User Settings](/user-settings): The User Settings API exposes endpoints to allow 3rd party integrators to communicate with Wink.  ### Consume APIs Consume endpoints are for developers who want to find existing travel inventory and either book it or use it to advertise through one of their Wink affiliate accounts.   - [Configuration](/customization-client): A single endpoint to retrieve whitelabel + customization information for the booking customization.  - [Lookup](/lookup): All APIs related to locating inventory by region, locale and property flags.  - [Inventory](/inventory): All APIs related to retrieve known travel inventory as it was found using the Lookup API..  - [Booking](/booking): All APIs related to creating bookings on the platform.  - [Travel Agent](/travel-agent): The Travel Agent API exposes endpoints to manage agent-facilitated bookings.   ### Produce APIs  Produce endpoints are for developers who want to create and manage travel inventory.   #### Property  - [Property registration](/extranet/property/register): As a producer, this is, oftentimes, where you start your journey. These endpoints let you create properties on Wink.  - [Property](/extranet/property): This collection of property endpoints are mostly management endpoints that let you display, change status and similar for your existing properties.  - [Facilities](/extranet/facilities): This collection of endpoints let you manage facilities; such as room types.  - [Experiences](/extranet/experiences): This collection of endpoints let you manage experiences, such as activities.  - [Monetize](/extranet/monetize): The Monetize API exposes endpoints for managing cancellation polies, rate plans, promotions and more on Wink.  - [Distribution](/extranet/distribution): The Distribution API exposes endpoints for sales channels, connecting with affiliates, managing rates and inventory calendars and more on Wink.  - [Property Booking](/extranet/booking): The Property Booking API exposes endpoints for managing bookings and reviews at the property-level.   #### Affiliate  - [Affiliate](/affiliate): This collection of affiliate endpoints are mostly management endpoints that let you display, change status and similar for your existing accounts.  - [Browse](/affiliate/browse): The Browse API exposes endpoints for affiliates to find suppliers and inventory to sell.  - [Inventory](/affiliate/inventory): The Inventory API exposes endpoints for affiliates to manage the inventory they want to sell and how they want to sell it.  - [Sales Channel](/affiliate/sales-channel): The Sales Channel API exposes endpoints for affiliates to manage existing sales channels as well as find new ones.  - [WinkLinks](/affiliate/winklinks): The WinkLinks API exposes endpoints for affiliates to manage their WinkLinks page.   #### Rate provider  - [Channel manager](/channel-manager): The Channel Manager API enables external channel manager partners to map, exchange rate / availability information with us as well as be informed of bookings that occur on the Wink platform for one of their properties.   ### Taxonomy APIs  Taxonomy endpoints are for developers who want to consume and produce travel inventory and need taxonomies of standard and non-standard codes for inventory types, classes, statuses etc.   - [Reference](/reference): All APIs related to retrieving platform-supported taxonomies.   ### Insight APIs  Insight endpoints do exactly what the name implies - They offer platform-level insight into the activities of producers and consumers.   - [Analytics](/analytics): All APIs related to tracking metrics across a wide variety of data source segments including, more entertaining, leaderboard metrics.   ### Payment APIs  Payment endpoints are for developers who want to purchase travel inventory. This can be done via the API as a registered Travel Agent or using our API in conjunction with our PCI compliant payment widget for all other entities.   - [TripPay](/payment): All APIs related to TripPay account management, booking, mapping and integration features.   ## SDKs  We are actively working on supporting the most used languages out there. If you don't see your language here, reach out to us with a request to officially add your language. In the meantime, if you want to roll your own SDK, you can do so by downloading the OpenAPI spec and using one of the many available OpenAPI generators available: [https://openapi-generator.tech/docs/generators](https://openapi-generator.tech/docs/generators).   - Java SDK [https://github.com/wink-travel/wink-sdk-java](https://github.com/wink-travel/wink-sdk-java)   ## Usage  These features are made available to you via a [REST API](https://en.wikipedia.org/wiki/Representational_state_transfer). This API is language agnostic.   ## Versioning  We chose to version our endpoints in a way that we hope affects your integration minimally. You request the version of our API you wish to work with via the `Wink-Version` header. When it's time for you to upgrade, you only have to change the version number to get access to our updated endpoints.   ## Release history  - Follow updates on Github: https://github.com/wink-travel/wink-sdk-java/blob/master/CHANGELOG.md    # Extranet Property API This part of the documentation concerns itself with basic property management. It can:  1. Property: List existing properties. Manage property status. Change name and similar. 2. Notification: Read internal messages sent from Wink to your properties. 3. Announcement: Show pertinent messages to travelers in a pop-up window. 4. Geo-location: Set property geo-location. 5. Green Index: Answer eco-related questions regarding the property's recycling practices and much more. 6. Lifestyles: Manage lifestyles the property caters to. 7. Photos / Videos: Manage property media. 8. Policy: Manage property policy. I.e. Children, pets, wi-fi, parking etc. 9. Reputation: Manage awards, online / offline ratings etc. 10. Services: Manage property amenities. 11. Social media: Manage property social media networks. 12. Welcome text: Manage property descriptions  Browse the endpoints in the left navigation bar to get started.  

    The version of the OpenAPI document: 30.27.1
    Contact: bjorn@wink.travel
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


__version__ = "0.0.52"

# Define package exports
__all__ = [
    "ChannelManagerApi",
    "GeoLocationApi",
    "LifestyleApi",
    "MediaApi",
    "PolicyApi",
    "PropertyApi",
    "RecognitionApi",
    "ReferenceApi",
    "SocialNetworkApi",
    "ApiResponse",
    "ApiClient",
    "Configuration",
    "OpenApiException",
    "ApiTypeError",
    "ApiValueError",
    "ApiKeyError",
    "ApiAttributeError",
    "ApiException",
    "AddressSupplier",
    "AggregateDescriptorSupplier",
    "CompositeFilterDescriptorSupplier",
    "ContactSupplier",
    "CountryLightweightSupplier",
    "CustomMonetaryAmount",
    "FilterDescriptorSupplier",
    "GeneralManagerSupplier",
    "GenericErrorMessage",
    "GeoJsonPointSupplier",
    "GeoNameLightweightSupplier",
    "GroupDescriptorSupplier",
    "ImproveWelcomeTextRequestSupplier",
    "KeyValuePairNonAuthenticatedEntity",
    "KeyValuePairSupplier",
    "LifestylesResponseSupplier",
    "LocalizedDescriptionSupplier",
    "MediaAuthorAttributionSupplier",
    "PagePropertySupplier",
    "PageableObjectSupplier",
    "PropertyAggregateGreenIndexAnswerSupplier",
    "PropertyAggregateGreenIndexAnswersSupplier",
    "PropertyAggregateGreenIndexScoreByCategorySupplier",
    "PropertyLightweightSupplier",
    "PropertyPolicySupplier",
    "PropertySupplier",
    "ShowRecognition400Response",
    "SimpleDescriptionSupplier",
    "SimpleMultimediaSupplier",
    "SocialNetworksRequestSupplier",
    "SocialNetworksResponseSupplier",
    "SocialSupplier",
    "SortDescriptorSupplier",
    "SortObjectSupplier",
    "StateSupplier",
    "SubCountryLightweightSupplier",
    "SubSubCountryLightweightSupplier",
    "SuggestAmenitiesRequestSupplier",
    "SuggestProfileRequestSupplier",
    "SuggestProfileResponseSupplier",
    "SuggestWelcomeTextRequestSupplier",
    "TravelInventoryRecognitionSupplier",
    "UniqueResultSupplier",
    "UpdateChannelManagerRequestSupplier",
    "UpdateExternalHotelStatusRequestSupplier",
    "UpdateLifestylesRequestSupplier",
    "UpdateLocationRequestSupplier",
    "UpdatePropertyAmenitiesAndServicesRequestSupplier",
    "UpsertAddressRequestSupplier",
    "UpsertContactInfoRequestSupplier",
    "UpsertPropertyAddressRequestSupplier",
    "UpsertPropertyProfileRequestSupplier",
    "UpsertRecognitionSupplier",
    "UpsertSimpleDescriptionSupplier",
    "UpsertWelcomeTextRequestSupplier",
]

# import apis into sdk package
from wink_sdk_extranet_property.api.channel_manager_api import ChannelManagerApi as ChannelManagerApi
from wink_sdk_extranet_property.api.geo_location_api import GeoLocationApi as GeoLocationApi
from wink_sdk_extranet_property.api.lifestyle_api import LifestyleApi as LifestyleApi
from wink_sdk_extranet_property.api.media_api import MediaApi as MediaApi
from wink_sdk_extranet_property.api.policy_api import PolicyApi as PolicyApi
from wink_sdk_extranet_property.api.property_api import PropertyApi as PropertyApi
from wink_sdk_extranet_property.api.recognition_api import RecognitionApi as RecognitionApi
from wink_sdk_extranet_property.api.reference_api import ReferenceApi as ReferenceApi
from wink_sdk_extranet_property.api.social_network_api import SocialNetworkApi as SocialNetworkApi

# import ApiClient
from wink_sdk_extranet_property.api_response import ApiResponse as ApiResponse
from wink_sdk_extranet_property.api_client import ApiClient as ApiClient
from wink_sdk_extranet_property.configuration import Configuration as Configuration
from wink_sdk_extranet_property.exceptions import OpenApiException as OpenApiException
from wink_sdk_extranet_property.exceptions import ApiTypeError as ApiTypeError
from wink_sdk_extranet_property.exceptions import ApiValueError as ApiValueError
from wink_sdk_extranet_property.exceptions import ApiKeyError as ApiKeyError
from wink_sdk_extranet_property.exceptions import ApiAttributeError as ApiAttributeError
from wink_sdk_extranet_property.exceptions import ApiException as ApiException

# import models into sdk package
from wink_sdk_extranet_property.models.address_supplier import AddressSupplier as AddressSupplier
from wink_sdk_extranet_property.models.aggregate_descriptor_supplier import AggregateDescriptorSupplier as AggregateDescriptorSupplier
from wink_sdk_extranet_property.models.composite_filter_descriptor_supplier import CompositeFilterDescriptorSupplier as CompositeFilterDescriptorSupplier
from wink_sdk_extranet_property.models.contact_supplier import ContactSupplier as ContactSupplier
from wink_sdk_extranet_property.models.country_lightweight_supplier import CountryLightweightSupplier as CountryLightweightSupplier
from wink_sdk_extranet_property.models.custom_monetary_amount import CustomMonetaryAmount as CustomMonetaryAmount
from wink_sdk_extranet_property.models.filter_descriptor_supplier import FilterDescriptorSupplier as FilterDescriptorSupplier
from wink_sdk_extranet_property.models.general_manager_supplier import GeneralManagerSupplier as GeneralManagerSupplier
from wink_sdk_extranet_property.models.generic_error_message import GenericErrorMessage as GenericErrorMessage
from wink_sdk_extranet_property.models.geo_json_point_supplier import GeoJsonPointSupplier as GeoJsonPointSupplier
from wink_sdk_extranet_property.models.geo_name_lightweight_supplier import GeoNameLightweightSupplier as GeoNameLightweightSupplier
from wink_sdk_extranet_property.models.group_descriptor_supplier import GroupDescriptorSupplier as GroupDescriptorSupplier
from wink_sdk_extranet_property.models.improve_welcome_text_request_supplier import ImproveWelcomeTextRequestSupplier as ImproveWelcomeTextRequestSupplier
from wink_sdk_extranet_property.models.key_value_pair_non_authenticated_entity import KeyValuePairNonAuthenticatedEntity as KeyValuePairNonAuthenticatedEntity
from wink_sdk_extranet_property.models.key_value_pair_supplier import KeyValuePairSupplier as KeyValuePairSupplier
from wink_sdk_extranet_property.models.lifestyles_response_supplier import LifestylesResponseSupplier as LifestylesResponseSupplier
from wink_sdk_extranet_property.models.localized_description_supplier import LocalizedDescriptionSupplier as LocalizedDescriptionSupplier
from wink_sdk_extranet_property.models.media_author_attribution_supplier import MediaAuthorAttributionSupplier as MediaAuthorAttributionSupplier
from wink_sdk_extranet_property.models.page_property_supplier import PagePropertySupplier as PagePropertySupplier
from wink_sdk_extranet_property.models.pageable_object_supplier import PageableObjectSupplier as PageableObjectSupplier
from wink_sdk_extranet_property.models.property_aggregate_green_index_answer_supplier import PropertyAggregateGreenIndexAnswerSupplier as PropertyAggregateGreenIndexAnswerSupplier
from wink_sdk_extranet_property.models.property_aggregate_green_index_answers_supplier import PropertyAggregateGreenIndexAnswersSupplier as PropertyAggregateGreenIndexAnswersSupplier
from wink_sdk_extranet_property.models.property_aggregate_green_index_score_by_category_supplier import PropertyAggregateGreenIndexScoreByCategorySupplier as PropertyAggregateGreenIndexScoreByCategorySupplier
from wink_sdk_extranet_property.models.property_lightweight_supplier import PropertyLightweightSupplier as PropertyLightweightSupplier
from wink_sdk_extranet_property.models.property_policy_supplier import PropertyPolicySupplier as PropertyPolicySupplier
from wink_sdk_extranet_property.models.property_supplier import PropertySupplier as PropertySupplier
from wink_sdk_extranet_property.models.show_recognition400_response import ShowRecognition400Response as ShowRecognition400Response
from wink_sdk_extranet_property.models.simple_description_supplier import SimpleDescriptionSupplier as SimpleDescriptionSupplier
from wink_sdk_extranet_property.models.simple_multimedia_supplier import SimpleMultimediaSupplier as SimpleMultimediaSupplier
from wink_sdk_extranet_property.models.social_networks_request_supplier import SocialNetworksRequestSupplier as SocialNetworksRequestSupplier
from wink_sdk_extranet_property.models.social_networks_response_supplier import SocialNetworksResponseSupplier as SocialNetworksResponseSupplier
from wink_sdk_extranet_property.models.social_supplier import SocialSupplier as SocialSupplier
from wink_sdk_extranet_property.models.sort_descriptor_supplier import SortDescriptorSupplier as SortDescriptorSupplier
from wink_sdk_extranet_property.models.sort_object_supplier import SortObjectSupplier as SortObjectSupplier
from wink_sdk_extranet_property.models.state_supplier import StateSupplier as StateSupplier
from wink_sdk_extranet_property.models.sub_country_lightweight_supplier import SubCountryLightweightSupplier as SubCountryLightweightSupplier
from wink_sdk_extranet_property.models.sub_sub_country_lightweight_supplier import SubSubCountryLightweightSupplier as SubSubCountryLightweightSupplier
from wink_sdk_extranet_property.models.suggest_amenities_request_supplier import SuggestAmenitiesRequestSupplier as SuggestAmenitiesRequestSupplier
from wink_sdk_extranet_property.models.suggest_profile_request_supplier import SuggestProfileRequestSupplier as SuggestProfileRequestSupplier
from wink_sdk_extranet_property.models.suggest_profile_response_supplier import SuggestProfileResponseSupplier as SuggestProfileResponseSupplier
from wink_sdk_extranet_property.models.suggest_welcome_text_request_supplier import SuggestWelcomeTextRequestSupplier as SuggestWelcomeTextRequestSupplier
from wink_sdk_extranet_property.models.travel_inventory_recognition_supplier import TravelInventoryRecognitionSupplier as TravelInventoryRecognitionSupplier
from wink_sdk_extranet_property.models.unique_result_supplier import UniqueResultSupplier as UniqueResultSupplier
from wink_sdk_extranet_property.models.update_channel_manager_request_supplier import UpdateChannelManagerRequestSupplier as UpdateChannelManagerRequestSupplier
from wink_sdk_extranet_property.models.update_external_hotel_status_request_supplier import UpdateExternalHotelStatusRequestSupplier as UpdateExternalHotelStatusRequestSupplier
from wink_sdk_extranet_property.models.update_lifestyles_request_supplier import UpdateLifestylesRequestSupplier as UpdateLifestylesRequestSupplier
from wink_sdk_extranet_property.models.update_location_request_supplier import UpdateLocationRequestSupplier as UpdateLocationRequestSupplier
from wink_sdk_extranet_property.models.update_property_amenities_and_services_request_supplier import UpdatePropertyAmenitiesAndServicesRequestSupplier as UpdatePropertyAmenitiesAndServicesRequestSupplier
from wink_sdk_extranet_property.models.upsert_address_request_supplier import UpsertAddressRequestSupplier as UpsertAddressRequestSupplier
from wink_sdk_extranet_property.models.upsert_contact_info_request_supplier import UpsertContactInfoRequestSupplier as UpsertContactInfoRequestSupplier
from wink_sdk_extranet_property.models.upsert_property_address_request_supplier import UpsertPropertyAddressRequestSupplier as UpsertPropertyAddressRequestSupplier
from wink_sdk_extranet_property.models.upsert_property_profile_request_supplier import UpsertPropertyProfileRequestSupplier as UpsertPropertyProfileRequestSupplier
from wink_sdk_extranet_property.models.upsert_recognition_supplier import UpsertRecognitionSupplier as UpsertRecognitionSupplier
from wink_sdk_extranet_property.models.upsert_simple_description_supplier import UpsertSimpleDescriptionSupplier as UpsertSimpleDescriptionSupplier
from wink_sdk_extranet_property.models.upsert_welcome_text_request_supplier import UpsertWelcomeTextRequestSupplier as UpsertWelcomeTextRequestSupplier


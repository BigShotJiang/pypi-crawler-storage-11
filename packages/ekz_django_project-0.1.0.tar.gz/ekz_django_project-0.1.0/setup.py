from setuptools import setup, find_packages

setup(
    name="ekz-django-project",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "Django>=4.0",
        "Pillow>=9.0",
        # добавьте другие зависимости
    ],
)
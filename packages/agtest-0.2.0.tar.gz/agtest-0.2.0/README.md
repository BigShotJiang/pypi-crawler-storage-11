Purpose:
The Agent AI tool automatically analyzes FastAPI controller/service files and generates correct unit tests based on strict project rules.

Core Features

-Detect whether the input file is a controller or service
-Generate FastAPI test cases with mandatory project standards:
   -Mock DB Session (MagicMock(spec=Session))
   -TestClient with middleware injecting request state
   -CustomException handler setup
   -Dependency override for get_db
   -Cleanup overrides after each test
   -Ensure success + negative case per endpoint
   -Follow session-per-request mocking pattern
   -Handle async + TaskGroup errors (ExceptionGroup) gracefully

Flow-
agent_ai -> detect_file_type -> detect_controller_prefix -> run_agent
detect_controller_prefix -> get_prefix_for_controller
run_agent -> build_prompt -> get_model_client -> generate_response

build_prompt -> extract_schemas_and_modules -> extract_schema_metadata_from_ast 

extract_schema_metadata_from_ast  -> find_schema_file -> parse_ast_file -> get_schema_type -> extract_fields -> extract_validators

Configuration-
   It should have MODEL_NAME , MAX_TOKENS , TEMPERATURE , GOOGLE_API_KEY.
   To change output dir go in run_agent and change it.

All files will be kept at same level in a folder. 

Functions list
    agent-ai.py :- agent_ai
    agent-services.py :- get_model_client , generate_response , build_prompt, run_agent
    utilities.py :- extract_schema_metadata_from_ast , find_schema_file , parse_ast_file , get_schema_type ,extract_fields , extract_validators ,    extract_schemas_and_modules , detect_controller_prefix , get_prefix_for_controller , detect_file_type 


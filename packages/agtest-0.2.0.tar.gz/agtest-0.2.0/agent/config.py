import os
MODEL_NAME="models/gemini-2.5-flash"
TEMPERATURE=0.7
MAX_TOKENS=1024
GOOGLE_API_KEY=os.getenv("GOOGLE_API_KEY", "")

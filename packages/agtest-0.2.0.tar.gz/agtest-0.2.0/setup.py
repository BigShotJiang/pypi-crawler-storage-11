from setuptools import setup, find_packages

setup(
    name="agtest",
    version="0.2.0",
    packages=find_packages(),
    install_requires=[
    "google-generativeai>=0.8.5",
    ],
    entry_points={
        "console_scripts": [
            "agent-cli = agent.agent_ai:agent_ai"
        ]
    }
)

Proposals
=========

.. toctree::
    :glob:

    proposals/*

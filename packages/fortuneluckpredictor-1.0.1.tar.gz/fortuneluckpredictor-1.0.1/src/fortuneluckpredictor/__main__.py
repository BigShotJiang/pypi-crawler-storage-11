from .fortune import get_fortune
from .futurePredictions import futurePrediction
from .compatibility_score import compatibility_score
from .luckyNumber import get_lucky_number
from .predictDay import predict_day

def main() -> None:

    print("\n✨🔮✨==============================✨🔮✨")
    print("   Welcome to Fortune Luck Predictor!   ")
    print("✨🔮✨==============================✨🔮✨")
    print("        (づ｡◕‿‿◕｡)づ  ✨  🧙‍♂️  🍀  🦄  ")

    while True:
        print("1. Get your fortune ✨")
        print("2. Predict your future 🔮")
        print("3. Predict your day ☀️")
        print("4. Compatibility score 💞")
        print("5. Get your lucky number 🍀")
        print("6. Exit 🚪")
        choice = input("Choose an option (1-6): ").strip()

        if choice == "1":
            print("\nYour fortune:")
            print(get_fortune())
        elif choice == "2":
            name = input("Enter your name: ").strip()
            print("\n" + futurePrediction(name))
        elif choice == "3":
            day = input("Enter a day of the week: ").strip()
            try:
                print("\n" + predict_day(day or None))
            except Exception as e:
                print(f"Error: {e}")
        elif choice == "4":
            name1 = input("Enter the first name: ").strip()
            name2 = input("Enter the second name: ").strip()
            print("\n" + compatibility_score(name1, name2))
        elif choice == "5":
            print("Your lucky number:")
            print(get_lucky_number())
        elif choice == "6":
            print("Goodbye! ✨")
            break
        else:
            print("Invalid choice. Please enter a number from 1 to 6.")
        
        continue_prompt = input("\nWould you like to try another option? (yes/no): ").strip().lower()
        if continue_prompt not in ('yes', 'y'):
            print("Goodbye! ✨")
            break

        print("\n")

if __name__ == "__main__":
    main()

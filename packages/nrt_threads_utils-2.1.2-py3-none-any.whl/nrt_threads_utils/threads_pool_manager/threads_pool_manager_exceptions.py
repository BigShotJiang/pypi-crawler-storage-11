
class FullQueueException(Exception):
    pass


from email_manager.factory.provider_factory import ProviderFactory
from email_manager.providers.exceptions import EmailSendError

class EmailNotificationManager:
    def __init__(self, config, logger=None, force_mailtrap=False):
        self.logger = logger
        self.force_mailtrap = force_mailtrap

        if force_mailtrap:
            self.provider = ProviderFactory.create_provider(config, override="mailtrap")
            self.fallback_provider = None
        else:
            self.provider = ProviderFactory.create_provider(config, override="mailgun")
            self.fallback_provider = ProviderFactory.create_provider(config, override="smtp")

    def send_notification(self, to: str, subject: str, body: str) -> bool:
        try:
            return self.provider.send_email(to, subject, body)
        except EmailSendError as e:
            print(f"⚠️ Fallback [SMTP] activado por error en {e.provider_name}: {e}")
            try:
                return self.fallback_provider.send_email(to, subject, body)
            except EmailSendError as fallback_error:
                print(f"❌ Fallback también falló: {fallback_error}")
                return False

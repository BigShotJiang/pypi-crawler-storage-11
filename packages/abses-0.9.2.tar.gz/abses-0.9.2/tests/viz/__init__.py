"""Tests for visualization utilities."""

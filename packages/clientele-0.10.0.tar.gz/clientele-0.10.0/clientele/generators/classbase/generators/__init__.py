# Client generators for classbase

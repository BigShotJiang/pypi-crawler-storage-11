"""Efference Python SDK - Official client for the Efference ML API."""

from .client import EfferenceClient

__version__ = "0.1.4"
__author__ = "EfferenceAI"
__license__ = "MIT"

__all__ = [
    "EfferenceClient",
    "__version__",
]

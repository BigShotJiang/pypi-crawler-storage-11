class SearchError(Exception):
    pass

"""Example games and demonstrations."""

"""
Startup handler for node-connection app
This module is automatically called when the app is loaded
"""
import asyncio
from pathlib import Path
import sys

# Add app directory to path for imports
node_be_dir = Path(__file__).parent
if str(node_be_dir) not in sys.path:
    sys.path.insert(0, str(node_be_dir))

from node_manager import get_node_manager


async def startup():
    """
    Startup routine - called when app is loaded
    Logs into API domain and establishes connection
    """
    print("🔌 Node Connection Manager: Starting up...")
    
    manager = get_node_manager()
    success = await manager.startup()
    
    if success:
        print("✅ Node Connection Manager: Successfully connected to API domain")
        status = manager.get_status()
        print(f"   📍 Node ID: {status['node_id']}")
        print(f"   🌐 API Domain: {status['api_domain']}")
        print(f"   🟢 Status: {'Connected' if status['connected'] else 'Disconnected'}")
        print("   🔐 Using existing JWT authentication system")
    else:
        print("⚠️  Node Connection Manager: Failed to connect to API domain")
    
    return success


async def shutdown():
    """
    Shutdown routine - called when app is unloaded
    """
    print("🔌 Node Connection Manager: Shutting down...")
    
    manager = get_node_manager()
    await manager.shutdown()
    
    print("✅ Node Connection Manager: Shutdown complete")


# For backward compatibility - export the manager
def get_manager():
    """Get the global node manager instance"""
    return get_node_manager()

from typing import List, Optional, Dict, Any
from ctyunsdk_ebs20220909.core.client import CtyunClient
from ctyunsdk_ebs20220909.core.credential import Credential
from ctyunsdk_ebs20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsNewEbsLabelsRequest:
    key: str  # 标签的key值，长度不能超过32个字符。
    value: str  # 标签的value值，长度不能超过32个字符。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsNewEbsRequest:
    regionID: str  # 资源池ID。
    diskName: str  # 磁盘命名，单账户单资源池下，命名需唯一。; 仅允许英文字母、数字及_或者-，长度为2-63字符，不能以特殊字符开头。
    diskSize: Any  # 云硬盘大小，单位GB。数据盘的取值范围：; ●超高IO/高IO/极速型SSD/普通IO：10GB~32768GB; ●XSSD-0：10GB-65536GB; ●XSSD-1：20GB-65536GB; ●XSSD-2：512GB-65536GB
    diskMode: str  # 云硬盘磁盘模式，分为：; ●VBD（Virtual Block Device）：虚拟块存储设备。; ●ISCSI （Internet Small Computer System Interface）：小型计算机系统接口。; ●FCSAN（Fibre Channel SAN）：光纤通道协议的SAN网络。
    diskType: str  # 云硬盘类型及相关限制：; ●SATA：普通IO; ●SAS：高IO，只有该类型支持FCSAN模式; ●SSD：超高IO; ●FAST-SSD：极速型SSD，不支持ISCSI模式; ●XSSD-0、XSSD-1、XSSD-2：X系列云硬盘，不支持加密，不支持ISCSI模式或FCSAN模式
    cycleCount: Optional[int]  # 包周期数。onDemand为false时必须指定。; 周期为年（year）时，周期最大长度不能超过5年。; 周期为月（month）时，周期最大长度不能超过60月。
    clientToken: Optional[str] = None  # 客户端存根，用于保证订单幂等性。要求单个云平台账户内唯一。
    multiAttach: Optional[bool] = None # 是否多云主机挂载，取值范围：; ●true：是; ●false：否; 默认值：false
    isEncrypt: Optional[bool] = None # 是否加密盘，取值范围：; ●true：是; ●false：否; 默认值：false; 共享盘、ISCSI模式磁盘、极速型SSD类型盘、XSSD系列盘不支持加密。
    kmsUUID: Optional[str]  = None# 如果是加密盘，需要提供kms的uuid，传入空字符串""则使用默认密钥。
    projectID: Optional[str]  = None# 企业项目ID，默认为0。
    onDemand: Optional[bool] = None # 是否按需下单，取值范围：; ●true：是; ●false：否; 默认值：true
    cycleType: Optional[str]  = None# 包周期类型，year：年，month：月。; onDemand为false时，必须指定year和month的值。
    imageID: Optional[str] = None # 镜像ID，如果用镜像创建，只支持数据盘的私有镜像和共享镜像，所创建的数据盘的所在地域要与镜像源一致，容量不可小于镜像对应的磁盘容量。; 不支持批量创建操作，从镜像创建的数据盘不支持加密、ISCSI和FCSAN高级配置。
    azName: Optional[str]  = None# 多可用区资源池下，必须指定可用区。
    provisionedIops: Any  = None# XSSD类型盘的预配置iops值，最小值为1，其他类型的盘不支持设置。具体取值范围如下：; ●XSSD-0：（基础IOPS（min{1800+12×容量， 10,000}）   + 预配置IOPS） ≤ min{500×容量，50,000}; ●XSSD-1：（基础IOPS（min{1800+50×容量， 50000}） + 预配置IOPS） ≤ min{500×容量，100000}; ●XSSD-2：（基础IOPS（min{3000+50×容量， 100000}） + 预配置IOPS） ≤ min{500×容量，1000000}
    deleteSnapWithEbs: Optional[bool]  = None# 设置全部快照是否随盘删除，取值范围：; ●true：是; ●false：否; 默认值：false;
    labels: Optional[List[Optional[EbsNewEbsLabelsRequest]]] = None # 设置云硬盘标签，实际绑定标签的结果请查询云硬盘详情的labels返回值是否如预期。
    backupID: Optional[str]  = None# 云硬盘备份ID参数，有以下限制：; ●从备份创建盘仅支持VBD模式。; ●新盘容量不能小于备份源盘容量。; ●不支持配置加密属性（自动与备份源盘保持一致）。; ●备份状态必须是可用。
    decPoolID: Optional[str]  = None# 专属云存储池ID，对应的资源池ID需要是专属云的资源池ID。
    volumeDescription: Optional[str]  = None# 云硬盘描述，长度为0-255

    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}



@dataclass
class EbsNewEbsReturnObjResourcesResponse:
    diskID: Optional[str]  # 资源底层ID，即云硬盘ID。
    orderID: Optional[str]  # 订单ID。
    startTime: Any  # 启动时刻，epoch时戳，毫秒精度。
    createTime: Any  # 创建时刻，epoch时戳，毫秒精度。
    updateTime: Any  # 更新时刻，epoch时戳，毫秒精度。
    status: Any  # 资源状态。
    isMaster: Optional[bool]  # 是否是主资源项。
    itemValue: Any  # 资源规格，即为磁盘大小，单位为GB。
    resourceType: Optional[str]  # 资源类型，云硬盘为EBS。
    diskName: Optional[str]  # 云硬盘名称。
    masterOrderID: Optional[str]  # 订单ID。调用方在拿到masterOrderID之后，在若干错误情况下，可以使用materOrderID进一步确认订单状态及资源状态。
    masterResourceID: Optional[str]  # 主资源ID。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsNewEbsReturnObjResourcesResponse']:
        if not json_data:
            return None
        obj = EbsNewEbsReturnObjResourcesResponse(
            diskID=json_data.get('diskID'),
            orderID=json_data.get('orderID'),
            startTime=json_data.get('startTime'),
            createTime=json_data.get('createTime'),
            updateTime=json_data.get('updateTime'),
            status=json_data.get('status'),
            isMaster=json_data.get('isMaster'),
            itemValue=json_data.get('itemValue'),
            resourceType=json_data.get('resourceType'),
            diskName=json_data.get('diskName'),
            masterOrderID=json_data.get('masterOrderID'),
            masterResourceID=json_data.get('masterResourceID')
        )
        return obj

@dataclass
class EbsNewEbsErrorDetailResponse:
    """错误明细。一般情况下，会对订单侧(bss)的云硬盘订单业务相关的错误做明确的错误映射和提升，有唯一对应的errorCode。<br> 其他订单侧(bss)的错误，以Ebs.Order.ProcFailed的errorCode统一映射返回，并在errorDetail中返回订单侧的详细错误信息。"""
    bssErrCode: Optional[str]  # bss错误明细码，包含于bss格式化JSON错误信息中。
    bssErrMsg: Optional[str]  # bss错误信息，包含于bss格式化JSON错误信息中。
    bssOrigErr: Optional[str]  # 无法明确解码bss错误信息时，原样透出的bss错误信息。
    bssErrPrefixHint: Optional[str]  # bss格式化JSON错误信息的前置提示信息。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsNewEbsErrorDetailResponse']:
        if not json_data:
            return None
        obj = EbsNewEbsErrorDetailResponse(
            bssErrMsg=json_data.get('bssErrMsg'),
            bssErrCode=json_data.get('bssErrCode'),
            bssOrigErr=json_data.get('bssOrigErr'),
            bssErrPrefixHint=json_data.get('bssErrPrefixHint')
        )
        return obj

@dataclass
class EbsNewEbsReturnObjResponse:
    """返回数据结构体。"""
    masterOrderID: Optional[str]  # 订单ID。调用方在拿到masterOrderID之后，在若干错误情况下，可以使用materOrderID进一步确认订单状态及资源状态。参考错误码。
    masterOrderNO: Optional[str]  # 订单号。
    masterResourceID: Optional[str]  # 主资源ID。
    masterResourceStatus: Optional[str]  # 主资源状态。只有主订单资源会返回。
    regionID: Optional[str]  # 资源所属资源池ID。
    resources: Optional[List[Optional[EbsNewEbsReturnObjResourcesResponse]]]  # 资源明细列表，参考表resources。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsNewEbsReturnObjResponse']:
        if not json_data:
            return None
        resources = None
        if "resources" in json_data:
            json_resources = json_data.get("resources")
            if json_resources is not None and isinstance(json_resources, list):
                resources = [EbsNewEbsReturnObjResourcesResponse.from_json(resource) for resource in json_resources]

        obj = EbsNewEbsReturnObjResponse(
            masterOrderID=json_data.get('masterOrderID'),
            masterOrderNO=json_data.get('masterOrderNO'),
            masterResourceID=json_data.get('masterResourceID'),
            masterResourceStatus=json_data.get('masterResourceStatus'),
            regionID=json_data.get('regionID'),
            resources=resources
        )
        return obj

@dataclass
class EbsNewEbsResponse:
    statusCode: Any  # 返回状态码(800为成功，900为处理中/失败)。
    message: Optional[str]  # 成功或失败时的描述，一般为英文描述。
    description: Optional[str]  # 成功或失败时的描述，一般为中文描述。
    returnObj: Optional[EbsNewEbsReturnObjResponse]  # 返回数据结构体。
    errorCode: Optional[str]  # 业务细分码，为Product.Module.Code三段式码.请参考错误码。
    error: Optional[str]  # 业务细分码，为Product.Module.Code三段式大驼峰码. 请参考错误码。
    errorDetail: Optional[EbsNewEbsErrorDetailResponse]  # 错误明细。一般情况下，会对订单侧(bss)的云硬盘订单业务相关的错误做明确的错误映射和提升，有唯一对应的errorCode。<br> 其他订单侧(bss)的错误，以Ebs.Order.ProcFailed的errorCode统一映射返回，并在errorDetail中返回订单侧的详细错误信息。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsNewEbsResponse']:
        if not json_data:
            return None

        return_obj = None
        if "returnObj" in json_data:
            returnObj = json_data.get("returnObj")
            if returnObj is not None:
                return_obj = EbsNewEbsReturnObjResponse.from_json(returnObj)

        error_detail = None
        if "errorDetail" in json_data:
            errorDetail = json_data.get("errorDetail")
            if errorDetail is not None:
                error_detail = EbsNewEbsErrorDetailResponse.from_json(errorDetail)

        obj = EbsNewEbsResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=return_obj,
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error'),
            errorDetail=error_detail
        )
        return obj


# 支持按需/包年包月创建云硬盘。
class EbsNewEbsApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsNewEbsRequest) -> EbsNewEbsResponse:
        url = endpoint + "/v4/ebs/new-ebs"
        params = {}
        try:
            header_params = {}
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.post(url=url, params=params, header_params=header_params, data=request_dict, credential=credential)
            return EbsNewEbsResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

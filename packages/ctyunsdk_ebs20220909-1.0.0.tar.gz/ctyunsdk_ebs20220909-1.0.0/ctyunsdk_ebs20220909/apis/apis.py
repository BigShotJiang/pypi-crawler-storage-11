from typing import Optional
from ctyunsdk_ebs20220909.core.client import CtyunClient
from .ebs_attach_ebs_api import EbsAttachEbsApi
from .ebs_detach_ebs_api import EbsDetachEbsApi
from .ebs_renew_ebs_api import EbsRenewEbsApi
from .ebs_refund_ebs_api import EbsRefundEbsApi
from .ebs_new_ebs_api import EbsNewEbsApi
from .ebs_update_ebs_attr_api import EbsUpdateEbsAttrApi
from .ebs_query_ebs_list_api import EbsQueryEbsListApi
from .ebs_query_ebs_by_i_d_api import EbsQueryEbsByIDApi
from .ebs_query_ebs_by_name_api import EbsQueryEbsByNameApi
from .ebs_resize_ebs_api import EbsResizeEbsApi


ENDPOINT_NAME = "ebs"

class Apis:
    _ebsattachebsapi: EbsAttachEbsApi
    _ebsdetachebsapi: EbsDetachEbsApi
    _ebsrenewebsapi: EbsRenewEbsApi
    _ebsrefundebsapi: EbsRefundEbsApi
    _ebsnewebsapi: EbsNewEbsApi
    _ebsupdateebsattrapi: EbsUpdateEbsAttrApi
    _ebsqueryebslistapi: EbsQueryEbsListApi
    _ebsqueryebsbyidapi: EbsQueryEbsByIDApi
    _ebsqueryebsbynameapi: EbsQueryEbsByNameApi
    _ebsresizeebsapi: EbsResizeEbsApi

    def __init__(self, endpoint_url: str, client: Optional[CtyunClient] = None):
        self.client = client or CtyunClient()
        self.endpoint = endpoint_url
        self._ebsattachebsapi = EbsAttachEbsApi(self.client)
        self._ebsattachebsapi.set_endpoint(self.endpoint)
        self._ebsdetachebsapi = EbsDetachEbsApi(self.client)
        self._ebsdetachebsapi.set_endpoint(self.endpoint)
        self._ebsrenewebsapi = EbsRenewEbsApi(self.client)
        self._ebsrenewebsapi.set_endpoint(self.endpoint)
        self._ebsrefundebsapi = EbsRefundEbsApi(self.client)
        self._ebsrefundebsapi.set_endpoint(self.endpoint)
        self._ebsnewebsapi = EbsNewEbsApi(self.client)
        self._ebsnewebsapi.set_endpoint(self.endpoint)
        self._ebsupdateebsattrapi = EbsUpdateEbsAttrApi(self.client)
        self._ebsupdateebsattrapi.set_endpoint(self.endpoint)
        self._ebsqueryebslistapi = EbsQueryEbsListApi(self.client)
        self._ebsqueryebslistapi.set_endpoint(self.endpoint)
        self._ebsqueryebsbyidapi = EbsQueryEbsByIDApi(self.client)
        self._ebsqueryebsbyidapi.set_endpoint(self.endpoint)
        self._ebsqueryebsbynameapi = EbsQueryEbsByNameApi(self.client)
        self._ebsqueryebsbynameapi.set_endpoint(self.endpoint)
        self._ebsresizeebsapi = EbsResizeEbsApi(self.client)
        self._ebsresizeebsapi.set_endpoint(self.endpoint)


    @property  # noqa
    def ebsattachebsapi(self) -> EbsAttachEbsApi:  # noqa
        return self._ebsattachebsapi

    @property  # noqa
    def ebsdetachebsapi(self) -> EbsDetachEbsApi:  # noqa
        return self._ebsdetachebsapi

    @property  # noqa
    def ebsrenewebsapi(self) -> EbsRenewEbsApi:  # noqa
        return self._ebsrenewebsapi

    @property  # noqa
    def ebsrefundebsapi(self) -> EbsRefundEbsApi:  # noqa
        return self._ebsrefundebsapi

    @property  # noqa
    def ebsnewebsapi(self) -> EbsNewEbsApi:  # noqa
        return self._ebsnewebsapi


    @property  # noqa
    def ebsqueryebslistapi(self) -> EbsQueryEbsListApi:  # noqa
        return self._ebsqueryebslistapi

    @property  # noqa
    def ebsqueryebsbyidapi(self) -> EbsQueryEbsByIDApi:  # noqa
        return self._ebsqueryebsbyidapi

    @property  # noqa
    def ebsqueryebsbynameapi(self) -> EbsQueryEbsByNameApi:  # noqa
        return self._ebsqueryebsbynameapi


    @property  # noqa
    def ebsresizeebsapi(self) -> EbsResizeEbsApi:  # noqa
        return self._ebsresizeebsapi

    @property
    def ebsupdateebsattrapi(self) -> EbsUpdateEbsAttrApi:
        return self._ebsupdateebsattrapi

from typing import List, Optional, Dict, Any
from ctyunsdk_ebs20220909.core.client import CtyunClient
from ctyunsdk_ebs20220909.core.credential import Credential
from ctyunsdk_ebs20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsResizeEbsRequest:
    diskSize: Any  # 变配后的云硬盘大小，数据盘的取值范围为：; ●超高IO/高IO/极速型SSD/普通IO：10GB~32768GB; ●XSSD-0：10GB-65536GB; ●XSSD-1：20GB-65536GB; ●XSSD-2：512GB-65536GB; 系统盘的取值范围为：; ●超高IO/高IO/极速型SSD/普通IO：40GB~2048GB; ●XSSD-0：40GB-2048GB; ●XSSD-1：40GB-2048GB; ●XSSD-2：512GB-2048GB
    diskID: str  # 待扩容的云硬盘ID。
    regionID: Optional[str]  # 如本地语境支持保存regionID，那么建议传递。
    clientToken: Optional[str]  # 客户端存根，用于保证订单幂等性。<br/>要求单个云平台账户内唯一。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsResizeEbsErrorDetailResponse:
    """错误明细。一般情况下，会对订单侧(bss)的云硬盘订单业务相关的错误做明确的错误映射和提升，有唯一对应的errorCode。<br> 其他订单侧(bss)的错误，以Ebs.Order.ProcFailed的errorCode统一映射返回，并在errorDetail中返回订单侧的详细错误信息。"""
    bssErrCode: Optional[str]  # bss错误明细码，包含于bss格式化JSON错误信息中。
    bssErrMsg: Optional[str]  # bss错误信息，包含于bss格式化JSON错误信息中。
    bssOrigErr: Optional[str]  # 无法明确解码bss错误信息时，原样透出的bss错误信息。
    bssErrPrefixHint: Optional[str]  # bss格式化JSON错误信息的前置提示信息。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsResizeEbsErrorDetailResponse']:
        if not json_data:
            return None
        obj = EbsResizeEbsErrorDetailResponse(
            bssErrCode=json_data.get('bssErrCode'),
            bssErrMsg=json_data.get('bssErrMsg'),
            bssOrigErr=json_data.get('bssOrigErr'),
            bssErrPrefixHint=json_data.get('bssErrPrefixHint')
        )
        return obj

@dataclass
class EbsResizeEbsReturnObjResponse:
    """返回结构体。"""
    masterOrderID: Optional[str]  # 订单ID。调用方在拿到masterOrderID之后，<br/>在若干错误情况下，可以使用masterOrderID进一步确认订单状态及资源状态。
    masterOrderNO: Optional[str]  # 订单号。
    masterResourceID: Optional[str]  # 主资源ID。
    masterResourceStatus: Optional[str]  # 主资源状态。只有主订单资源会返回。
    regionID: Optional[str]  # 资源所属资源池ID。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsResizeEbsReturnObjResponse']:
        if not json_data:
            return None
        obj = EbsResizeEbsReturnObjResponse(
            masterOrderID=json_data.get('masterOrderID'),
            masterOrderNO=json_data.get('masterOrderNO'),
            masterResourceID=json_data.get('masterResourceID'),
            masterResourceStatus=json_data.get('masterResourceStatus'),
            regionID=json_data.get('regionID')
        )
        return obj

@dataclass
class EbsResizeEbsResponse:
    statusCode: Any  # 返回状态码(800为成功，900为处理中/失败)。
    message: Optional[str]  # 成功或失败时的描述，一般为英文描述。
    description: Optional[str]  # 成功或失败时的描述，一般为中文描述。
    returnObj: Optional[EbsResizeEbsReturnObjResponse]  # 返回结构体。
    errorCode: Optional[str]  # 业务细分码，为product.module.code三段式码，请参考错误码。
    error: Optional[str]  # 业务细分码，为product.module.code三段式大驼峰码，请参考错误码。
    errorDetail: Optional[EbsResizeEbsErrorDetailResponse]  # 错误明细。一般情况下，会对订单侧(bss)的云硬盘订单业务相关的错误做明确的错误映射和提升，有唯一对应的errorCode。<br> 其他订单侧(bss)的错误，以Ebs.Order.ProcFailed的errorCode统一映射返回，并在errorDetail中返回订单侧的详细错误信息。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsResizeEbsResponse']:
        if not json_data:
            return None

        return_obj = None
        if "returnObj" in json_data:
            returnObj = json_data.get("returnObj")
            if returnObj is not None:
                return_obj = EbsResizeEbsReturnObjResponse.from_json(returnObj)

        error_detail = None
        if "errorDetail" in json_data:
            errorDetail = json_data.get("errorDetail")
            if errorDetail is not None:
                error_detail = EbsResizeEbsErrorDetailResponse.from_json(errorDetail)

        obj = EbsResizeEbsResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=return_obj,
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error'),
            errorDetail=error_detail
        )

        return obj


# 当云硬盘空间不足时，您可以扩大云硬盘的容量，也就是云硬盘扩容。此接口也支持随云主机订购的系统盘及数据盘的扩容。
# 当您扩容成功后，需要将扩容部分的容量划分至原有分区内，或者对扩容部分的云硬盘分配新的分区。详见：
# <a href="https://www.ctyun.cn/document/10027696/10029076">云硬盘扩容概述</a>
class EbsResizeEbsApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsResizeEbsRequest) -> EbsResizeEbsResponse:
        url = endpoint + "/v4/ebs/resize-ebs"
        params = {}
        try:
            header_params = {}
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.post(url=url, params=params, header_params=header_params, data=request_dict, credential=credential)
            return EbsResizeEbsResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

from typing import List, Optional, Dict, Any
from ctyunsdk_ebs20220909.core.client import CtyunClient
from ctyunsdk_ebs20220909.core.credential import Credential
from ctyunsdk_ebs20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsRefundEbsRequest:
    clientToken: Optional[str]  # 客户端存根，用于保证订单幂等性。要求单个云平台账户内唯一。
    diskID: str  # 需要退订的云硬盘ID。
    regionID: Optional[str]  # 资源池ID。如本地语境支持保存regionID，那么建议传递。
    deleteSnapWithEbs: Optional[bool]  # 设置快照是否随盘删除，只能设置为true。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsRefundEbsErrorDetailResponse:
    """错误明细。一般情况下，会对订单侧(bss)的云硬盘订单业务相关的错误做明确的错误映射和提升，有唯一对应的errorCode。<br> 其他订单侧(bss)的错误，以Ebs.Order.ProcFailed的errorCode统一映射返回，并在errorDetail中返回订单侧的详细错误信息。"""
    bssErrCode: Optional[str]  # bss错误明细码，包含于bss格式化JSON错误信息中。
    bssErrMsg: Optional[str]  # bss错误信息，包含于bss格式化JSON错误信息中。
    bssOrigErr: Optional[str]  # 无法明确解码bss错误信息时，原样透出的bss错误信息。
    bssErrPrefixHint: Optional[str]  # bss格式化JSON错误信息的前置提示信息。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsRefundEbsErrorDetailResponse']:
        if not json_data:
            return None
        obj = EbsRefundEbsErrorDetailResponse(
            bssErrCode=json_data.get('bssErrCode'),
            bssErrMsg=json_data.get('bssErrMsg'),
            bssOrigErr=json_data.get('bssOrigErr'),
            bssErrPrefixHint=json_data.get('bssErrPrefixHint')
        )

        return obj

@dataclass
class EbsRefundEbsReturnObjResponse:
    """返回结构体。"""
    masterOrderID: Optional[str]  # 退订订单号，可以使用该订单号确认资源的最终退订状态。
    masterOrderNO: Optional[str]  # 退订订单号。
    regionID: Optional[str]  # 资源池ID。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> 'EbsRefundEbsReturnObjResponse':
        if not json_data:
            return None
        obj = EbsRefundEbsReturnObjResponse(
            masterOrderNO=json_data.get('masterOrderNO'),
            masterOrderID=json_data.get('masterOrderID'),
            regionID=json_data.get('regionID')
        )

        return obj

@dataclass
class EbsRefundEbsResponse:
    statusCode: Any  # 返回状态码(800为成功，900为处理中/失败)。
    message: Optional[str]  # 成功或失败时的描述，一般为英文描述。
    description: Optional[str]  # 成功或失败时的描述，一般为中文描述。
    returnObj: Optional[EbsRefundEbsReturnObjResponse]  # 返回结构体。
    errorCode: Optional[str]  # 业务细分码，为product.module.code三段式码，请参考错误码。
    error: Optional[str]  # 业务细分码，为product.module.code三段式大驼峰码，请参考错误码。
    errorDetail: Optional[EbsRefundEbsErrorDetailResponse]  # 错误明细。一般情况下，会对订单侧(bss)的云硬盘订单业务相关的错误做明确的错误映射和提升，有唯一对应的errorCode。<br> 其他订单侧(bss)的错误，以Ebs.Order.ProcFailed的errorCode统一映射返回，并在errorDetail中返回订单侧的详细错误信息。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsRefundEbsResponse']:
        if not json_data:
            return None

        return_obj = None
        if "returnObj" in json_data:
            returnObj = json_data.get("returnObj")
            if returnObj is not None:
                return_obj = EbsRefundEbsReturnObjResponse.from_json(returnObj)

        error_detail = None
        if "errorDetail" in json_data:
            errorDetail = json_data.get("errorDetail")
            if errorDetail is not None:
                error_detail = EbsRefundEbsErrorDetailResponse.from_json(errorDetail)
        obj = EbsRefundEbsResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=return_obj,
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error'),
            errorDetail=error_detail
        )

        return obj


# 您可以退订/删除一块包周期/按需的云硬盘，以释放存储空间资源。退订/删除云硬盘后，将停止对云硬盘收费。
# 包周期云硬盘退订时，按照原始订单实付价格折算退订金额并进行返还。
# 当云硬盘被退订/删除后，云硬盘的数据将无法被访问。
class EbsRefundEbsApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsRefundEbsRequest) -> EbsRefundEbsResponse:
        url = endpoint + "/v4/ebs/refund-ebs"
        params = {}
        try:
            header_params = {}
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.post(url=url, params=params, header_params=header_params, data=request_dict, credential=credential)
            return EbsRefundEbsResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

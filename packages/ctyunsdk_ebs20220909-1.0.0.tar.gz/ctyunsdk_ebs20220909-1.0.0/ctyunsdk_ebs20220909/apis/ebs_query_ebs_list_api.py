from typing import List, Optional, Dict, Any
from ctyunsdk_ebs20220909.core.client import CtyunClient
from ctyunsdk_ebs20220909.core.credential import Credential
from ctyunsdk_ebs20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsQueryEbsListRequest:
    regionID: str  # 资源池ID。
    diskStatus: Optional[str] = None # 云硬盘状态
    pageNo: Any  = None# 页编号，默认1。当使用分页浏览方案查询可用区账户云硬盘时，此参数用于指定返回页的页编号。当nextToken或maxResults参数有指定参数值时，即采用据token浏览方案查询，此参数失去作用。
    pageSize: Any = None # 页大小，默认10，最大值为300。当使用分页浏览方案查询可用区账户云硬盘时，此参数用于指定返回页的页大小，即单页的盘数量。当nextToken或maxResults参数有指定参数值时，即采用据token浏览方案查询，此参数失去作用。
    decPoolID: Optional[str]  = None# 专属云存储池ID，可以查询该专属池下的所有磁盘。
    decPoolName: Optional[str]  = None# 专属云存储池名称，可以查询该专属池下的所有磁盘。
    azName: Optional[str]  = None# 可用区。
    projectID: Optional[str]  = None# 企业项目。
    diskType: Optional[str]  = None# 云硬盘类型。取值为：<br>●SATA：普通IO。<br>●SAS：高IO。<br>●SSD：超高IO。<br>●FAST-SSD：极速型SSD、<br>●XSSD-0、XSSD-1、XSSD-2：X系列云硬盘。
    diskMode: Optional[str]  = None# 云硬盘模式。取值为：<br>●VBD：虚拟块存储设备。<br>●ISCSI：小型计算机系统接口。<br>●FCSAN：光纤通道协议的SAN网络。
    multiAttach: Optional[str]  = None# 是否共享盘。取值为：<br>●true：共享盘。<br>●false：非共享盘。
    isSystemVolume: Optional[str]  = None# 是否为系统盘。取值为：<br>●true：系统盘。<br>●false：数据盘。
    isEncrypt: Optional[str]  = None# 是否加密盘。取值为：<br>●true：加密盘。<br>●false：非加密盘。
    queryContent: Optional[str]  = None# 模糊查询盘的信息，包括盘ID、盘名称、挂载主机ID、挂载主机名称等信息。
    queryKeys: Optional[str]  = None# 指定模糊查询的键。只有传入queryContent才生效，目前支持的值为name（云硬盘名称）、diskID（云硬盘id）、instanceID(挂载云主机id)。指定多个键则用“,”分隔。
    maxResults: Any  = None# 期望返回盘的数量，默认10，最大值为1000。使用此参数时，参数pageNo和pageSize将失去作用。受此参数限制而未返回的盘，可通过nextToken参数带入响应参数中的nextToken参数值进行接续查询。
    nextToken: Optional[str]  = None# 期望返回的首个盘的标志，默认为满足以上请求参数过滤条件的最后创建的盘的标志。使用此参数时，参数pageNo和pageSize失去作用，返回的盘数受参数maxResults限制。一般使用据token浏览方案查询可用区账户云硬盘时，首次请求不为此参数指定参数值，后续指定返回消息中returnObj对象里同名参数的值进行接续查询。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsQueryEbsListReturnObjDiskListAttachmentsResponse:
    instanceID: Optional[str]  # 绑定的云主机ID。
    attachmentID: Optional[str]  # 挂载ID。
    device: Optional[str]  # 挂载的设备名，例如/dev/sda。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsQueryEbsListReturnObjDiskListAttachmentsResponse']:
        if not json_data:
            return None
        obj = EbsQueryEbsListReturnObjDiskListAttachmentsResponse(
            instanceID=json_data.get("instanceID"),
            attachmentID=json_data.get("attachmentID"),
            device=json_data.get("device")
        )
        return obj

@dataclass
class EbsQueryEbsListReturnObjDiskListResponse:
    diskName: Optional[str]  # 云硬盘名称。
    diskID: Optional[str]  # 云硬盘ID。
    diskSize: Any  # 磁盘大小，单位为GB。
    diskType: Optional[str]  # 磁盘规格类型，取值为：; ●SATA：普通IO。; ●SAS：高IO。; ●SSD：超高IO。; ●FAST-SSD：极速型SSD。; ●XSSD-0、XSSD-1、XSSD-2：X系列云硬盘。
    diskMode: Optional[str]  # 云硬盘磁盘模式，取值为：; ●VBD（Virtual Block Device）：虚拟块存储设备。; ●ISCSI （Internet Small Computer System Interface）：小型计算机系统接口。; ●FCSAN（Fibre Channel SAN）：光纤通道协议的SAN网络。
    diskStatus: Optional[str]  # 参考 <a href='https://www.ctyun.cn/document/10027696/10168629'>云硬盘使用状态</a>
    createTime: Any  # 创建时刻，epoch时戳，精度为毫秒。
    updateTime: Any  # 更新时刻，epoch时戳，精度为毫秒。
    expireTime: Any  # 过期时刻，epoch时戳，精度为毫秒。
    isSystemVolume: Optional[bool]  # 只有为系统盘时才返回该字段。
    isPackaged: Optional[bool]  # 是否随云主机一起订购。
    instanceName: Optional[str]  # 绑定的云主机名称，有挂载时才返回。多挂载情况下只返回第一个。
    instanceID: Optional[str]  # 绑定的云主机ID，有挂载时才返回。多挂载情况下只返回第一个。
    instanceStatus: Optional[str]  # 云主机状态，参考<a href='https://www.ctyun.cn/document/10027696/10168629'>云主机使用状态</a>
    multiAttach: Optional[bool]  # 是否是共享云硬盘。
    attachments: Optional[List[Optional[EbsQueryEbsListReturnObjDiskListAttachmentsResponse]]]  # 挂载信息。如果是共享挂载云硬盘，则返回多项；无挂载时不返回该字段。
    projectID: Optional[str]  # 云硬盘所属的企业项目ID。
    isEncrypt: Optional[bool]  # 是否是加密盘。
    kmsUUID: Optional[str]  # 加密盘密钥UUID，是加密盘时才返回。
    regionID: Optional[str]  # 资源池ID。
    azName: Optional[str]  # 多可用区下的可用区名字，非多可用区不返回该字段。
    diskFreeze: Optional[bool]  # 云硬盘是否已冻结。
    provisionedIops: Any  # XSSD类型盘的预配置iops，未配置返回0，其他类型云硬盘不返回。
    decPoolID: Optional[str]  # 专属云存储池ID，只有磁盘为专属云盘时才返回。
    decPoolName: Optional[str]  # 专属云存储池名称，只有磁盘为专属云盘时才返回。
    deleteSnapWithEbs: Optional[str]  # 是否随云硬盘释放快照。只有支持快照的资源池会返回。
    snapshotPolicyID: Optional[str]  # 云硬盘绑定的快照策略。只有支持快照的资源池会返回。
    iops: Any  # 云硬盘iops。只有资源池支持展示iops才会返回。
    throughput: Any  # 云硬盘吞吐量，单位MB/s。只有资源池支持展示吞吐量才会返回。
    volumeSourceType: Optional[str]  # 云硬盘创建源类型。只有单独订购的盘在有数据源场景下返回，取值为:image/snapshot/backup。
    volumeSourceID: Optional[str]  # 云硬盘创建源ID。只有单独订购的盘在有数据源场景下返回。
    volumeDescription: Optional[str]  # 云硬盘描述。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsQueryEbsListReturnObjDiskListResponse']:
        if not json_data:
            return None
        attachments = None
        if "attachments" in json_data:
            attachs = json_data.get("attachments")
            if attachs is not None and isinstance(attachs, list):
                attachments = [EbsQueryEbsListReturnObjDiskListAttachmentsResponse.from_json(attach) for attach in attachs]
        obj = EbsQueryEbsListReturnObjDiskListResponse(
            diskName=json_data.get("diskName"),
            diskID=json_data.get("diskID"),
            diskSize=json_data.get("diskSize"),
            diskType=json_data.get("diskType"),
            diskMode=json_data.get("diskMode"),
            diskStatus=json_data.get("diskStatus"),
            createTime=json_data.get("createTime"),
            updateTime=json_data.get("updateTime"),
            expireTime=json_data.get("expireTime"),
            isSystemVolume=json_data.get("isSystemVolume"),
            isPackaged=json_data.get("isPackaged"),
            instanceName=json_data.get("instanceName"),
            instanceID=json_data.get("instanceID"),
            instanceStatus=json_data.get("instanceStatus"),
            multiAttach=json_data.get("multiAttach"),
            attachments=attachments,
            projectID=json_data.get("projectID"),
            isEncrypt=json_data.get("isEncrypt"),
            kmsUUID=json_data.get("kmsUUID"),
            regionID=json_data.get("regionID"),
            azName=json_data.get("azName"),
            diskFreeze=json_data.get("diskFreeze"),
            provisionedIops=json_data.get("provisionedIops"),
            decPoolID=json_data.get("decPoolID"),
            decPoolName=json_data.get("decPoolName"),
            deleteSnapWithEbs=json_data.get("deleteSnapWithEbs"),
            snapshotPolicyID=json_data.get("snapshotPolicyID"),
            iops=json_data.get("iops"),
            throughput=json_data.get("throughput"),
            volumeSourceType=json_data.get("volumeSourceType"),
            volumeSourceID=json_data.get("volumeSourceID"),
            volumeDescription=json_data.get("volumeDescription")
        )
        return obj

@dataclass
class EbsQueryEbsListReturnObjResponse:
    """返回数据体。"""
    diskList: Optional[List[Optional[EbsQueryEbsListReturnObjDiskListResponse]]]  # 返回数据集合。
    diskTotal: Any  # 云硬盘总数。diskTotal即将废弃，建议使用totalCount。
    currentCount: Any  # 当前页记录数目。
    totalCount: Any  # 总记录数。
    totalPage: Any  # 总页数。
    nextToken: Optional[str]  # 下一个盘的标志。当下一个盘不存在时，此字段没有有效返回值。当使用分页浏览方案查询可用区账户云硬盘时，此参数没有意义。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsQueryEbsListReturnObjResponse']:
        if not json_data:
            return None

        disk_list = None
        if "diskList" in json_data:
            disks = json_data.get("diskList")
            if disks is not None and isinstance(disks, list):
                disk_list = [EbsQueryEbsListReturnObjDiskListResponse.from_json(disk) for disk in disks]

        obj = EbsQueryEbsListReturnObjResponse(
            diskList=disk_list,
            diskTotal= json_data.get("diskTotal"),
            currentCount= json_data.get("currentCount"),
            totalCount = json_data.get("totalCount"),
            totalPage= json_data.get("totalPage"),
            nextToken= json_data.get("nextToken")
        )

        return obj

@dataclass
class EbsQueryEbsListResponse:
    statusCode: Any  # 返回状态码(800为成功，900为失败)。
    message: Optional[str]  # 成功或失败时的描述，一般为英文描述。
    description: Optional[str]  # 成功或失败时的描述，一般为中文描述。
    returnObj: Optional[EbsQueryEbsListReturnObjResponse]  # 返回数据体。
    errorCode: Optional[str]  # 业务细分码，为product.module.code三段式码，请参考错误码。
    error: Optional[str]  # 业务细分码，为product.module.code三段式大驼峰码，请参考错误码。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsQueryEbsListResponse']:
        if not json_data:
            return None
        return_obj = None
        if "returnObj" in json_data:
            returnObj = json_data.get("returnObj")
            if returnObj is not None:
                return_obj = EbsQueryEbsListReturnObjResponse.from_json(returnObj)

        obj = EbsQueryEbsListResponse(
            statusCode=json_data.get('statusCode'),
            error=json_data.get('error'),
            errorCode=json_data.get('errorCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=return_obj,
        )
        return obj


# 查询某地域全部云硬盘详情。
class EbsQueryEbsListApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsQueryEbsListRequest) -> EbsQueryEbsListResponse:
        url = endpoint + "/v4/ebs/list-ebs"
        params = {'regionID':request.regionID, 'pageNo':request.pageNo, 'pageSize':request.pageSize, 'decPoolID':request.decPoolID, 'decPoolName':request.decPoolName, 'azName':request.azName, 'projectID':request.projectID, 'diskType':request.diskType, 'diskMode':request.diskMode, 'multiAttach':request.multiAttach, 'isSystemVolume':request.isSystemVolume, 'isEncrypt':request.isEncrypt, 'queryContent':request.queryContent, 'queryKeys':request.queryKeys, 'maxResults':request.maxResults, 'nextToken':request.nextToken,
                  'diskStatus':request.diskStatus}
        try:
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.get(url=url, params=params, header_params=request_dict, credential=credential)
            return EbsQueryEbsListResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

from typing import List, Optional, Dict, Any
from ctyunsdk_ebs20220909.core.client import CtyunClient
from ctyunsdk_ebs20220909.core.credential import Credential
from ctyunsdk_ebs20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsAttachEbsRequest:
    diskID: str  # 待挂载的云硬盘ID。
    regionID: Optional[str]  # 如本地语境支持保存regionID，那么建议传递。
    instanceID: str  # 待挂载云主机的ID。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsAttachEbsErrorDetailResponse:
    """错误明细。一般情况下，会对订单侧(bss)的云硬盘订单业务相关的错误做明确的错误映射和提升，有唯一对应的errorCode。<br> 其他订单侧(bss)的错误，以Ebs.Order.ProcFailed的errorCode统一映射返回，并在errorDetail中返回订单侧的详细错误信息。"""
    bssErrCode: Optional[str]  # bss错误明细码，包含于bss格式化JSON错误信息中。
    bssErrMsg: Optional[str]  # bss错误信息，包含于bss格式化JSON错误信息中。
    bssOrigErr: Optional[str]  # 无法明确解码bss错误信息时，原样透出的bss错误信息。
    bssErrPrefixHint: Optional[str]  # bss格式化JSON错误信息的前置提示信息。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> 'EbsAttachEbsErrorDetailResponse':
        if not json_data:
            return None
        obj = EbsAttachEbsErrorDetailResponse(
            bssErrCode=json_data.get('bssErrCode'),
            bssErrMsg=json_data.get('bssErrMsg'),
            bssOrigErr=json_data.get('bssOrigErr'),
            bssErrPrefixHint=json_data.get('bssErrPrefixHint')
        )

        return obj

@dataclass
class EbsAttachEbsReturnObjResponse:
    """返回结构体。"""
    diskJobID: Optional[str]  # 异步任务ID，可通过公共接口/v4/job/info查询该jobID来查看异步任务最终执行结果（该参数即将被弃用，为提高兼容性，请尽量使用diskRequestID参数）。
    diskRequestID: Optional[str]  # 异步任务ID，可通过公共接口/v4/job/info查询该jobID来查看异步任务最终执行结果。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsAttachEbsReturnObjResponse']:
        if not json_data:
            return None

        obj = EbsAttachEbsReturnObjResponse(
            diskJobID=json_data.get('diskJobID'),
            diskRequestID=json_data.get('diskRequestID')
        )

        return obj

@dataclass
class EbsAttachEbsResponse:
    statusCode: Any  # 返回状态码(800为成功，900为失败)。
    message: Optional[str]  # 成功或失败时的描述，一般为英文描述。
    description: Optional[str]  # 成功或失败时的描述，一般为中文描述。
    returnObj: Optional[EbsAttachEbsReturnObjResponse]  # 返回结构体。
    errorCode: Optional[str]  # 业务细分码，为product.module.code三段式码，请参考错误码。
    error: Optional[str]  # 业务细分码，为product.module.code三段式大驼峰码，请参考错误码。
    errorDetail: Optional[EbsAttachEbsErrorDetailResponse]  # 错误明细。一般情况下，会对订单侧(bss)的云硬盘订单业务相关的错误做明确的错误映射和提升，有唯一对应的errorCode。<br> 其他订单侧(bss)的错误，以Ebs.Order.ProcFailed的errorCode统一映射返回，并在errorDetail中返回订单侧的详细错误信息。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsAttachEbsResponse']:
        if not json_data:
            return None

        return_obj = None
        if "returnObj" in json_data:
            returnObj = json_data.get("returnObj")
            if returnObj is not None:
                return_obj = EbsAttachEbsReturnObjResponse.from_json(returnObj)

        error_detail = None
        if "errorDetail" in json_data:
            errorDetail = json_data.get("errorDetail")
            if errorDetail is not None:
                error_detail = EbsAttachEbsErrorDetailResponse.from_json(errorDetail)
        obj = EbsAttachEbsResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            returnObj=return_obj,
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error'),
            errorDetail=error_detail
        )

        return obj


# 将云硬盘挂载至某一云主机，支持非共享云硬盘和共享云硬盘的挂载。
class EbsAttachEbsApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsAttachEbsRequest) -> EbsAttachEbsResponse:
        url = endpoint + "/v4/ebs/attach-ebs"
        params = {}
        try:
            header_params = {}
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.post(url=url, params=params, header_params=header_params, data=request_dict, credential=credential)
            return EbsAttachEbsResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

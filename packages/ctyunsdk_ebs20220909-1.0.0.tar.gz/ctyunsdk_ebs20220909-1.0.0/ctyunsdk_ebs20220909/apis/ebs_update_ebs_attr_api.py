from typing import List, Optional, Dict, Any
from ctyunsdk_ebs20220909.core.client import CtyunClient
from ctyunsdk_ebs20220909.core.credential import Credential
from ctyunsdk_ebs20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsUpdateEbsAttrRequest:
    diskID: str  # 云硬盘ID。
    diskName: Optional[str]  # 磁盘名称。仅允许英文字母、数字及_或者-，长度为2-63字符，不能以特殊字符开头。
    regionID: Optional[str]   # 如本地语境支持保存regionID，那么建议传递。
    volumeDescription: Optional[str]  = None# 磁盘描述信息。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsUpdateEbsAttrResponse:
    statusCode: Any  # 返回状态码(800为成功，900为失败)。
    message: Optional[str]  # 成功或失败时的描述，一般为英文描述。
    description: Optional[str]  # 成功或失败时的描述，一般为中文描述。
    errorCode: Optional[str]  # 业务细分码，为product.module.code三段式码。请参考错误码。
    error: Optional[str]  # 业务细分码，为product.module.code三段式大驼峰码。请参考错误码。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsUpdateEbsAttrResponse']:
        if not json_data:
            return None

        obj = EbsUpdateEbsAttrResponse(
            statusCode=json_data.get('statusCode'),
            message=json_data.get('message'),
            description=json_data.get('description'),
            errorCode=json_data.get('errorCode'),
            error=json_data.get('error')
        )
        return obj


# 更新云硬盘属性：名称、描述
class EbsUpdateEbsAttrApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsUpdateEbsAttrRequest) -> EbsUpdateEbsAttrResponse:
        url = endpoint + "/v4/ebs/update-attr-ebs"
        params = {}
        try:
            header_params = {}
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.post(url=url, params=params, header_params=header_params, data=request_dict, credential=credential)
            return EbsUpdateEbsAttrResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

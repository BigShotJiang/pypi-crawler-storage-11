from typing import List, Optional, Dict, Any
from ctyunsdk_ebs20220909.core.client import CtyunClient
from ctyunsdk_ebs20220909.core.credential import Credential
from ctyunsdk_ebs20220909.core.exception import CtyunRequestException

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class EbsQueryEbsByIDRequest:
    diskID: str  # 云硬盘ID。
    regionID: Optional[str]  # 资源池ID。如本地语境支持保存regionID，那么建议传递。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}


@dataclass
class EbsQueryEbsByIDReturnObjLabelsResponse:
    key: Optional[str]  # 标签键。
    value: Optional[str]  # 标签值。
    labelId: Optional[str]  # 标签ID。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsQueryEbsByIDReturnObjLabelsResponse']:
        if not json_data:
            return None
        obj = EbsQueryEbsByIDReturnObjLabelsResponse(
            key=json_data.get('key'),
            value=json_data.get('value'),
            labelId=json_data.get('labelId')
        )
        return obj

@dataclass
class EbsQueryEbsByIDReturnObjAttachmentsResponse:
    instanceID: Optional[str]  # 绑定的云主机ID。
    attachmentID: Optional[str]  # 挂载ID。
    device: Optional[str]  # 挂载设备名，例如/dev/sda。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsQueryEbsByIDReturnObjAttachmentsResponse']:
        if not json_data:
            return None
        obj = EbsQueryEbsByIDReturnObjAttachmentsResponse(
            instanceID=json_data.get('instanceID'),
            attachmentID=json_data.get('attachmentID'),
            device=json_data.get('device')
        )
        return obj

@dataclass
class EbsQueryEbsByIDReturnObjResponse:
    """云硬盘详情对象。"""
    diskName: Optional[str]  # 云硬盘名称。
    diskID: Optional[str]  # 云硬盘ID。
    diskSize: Any  # 磁盘大小，单位为GB。
    diskType: Optional[str]  # 磁盘规格类型，取值为：; ●SATA：普通IO。; ●SAS：高IO。; ●SSD：超高IO。; ●FAST-SSD：极速型SSD。; ●XSSD-0、XSSD-1、XSSD-2：X系列云硬盘。
    diskMode: Optional[str]  # 云硬盘磁盘模式，取值为：; ●VBD（Virtual Block Device）：虚拟块存储设备。; ●ISCSI （Internet Small Computer System Interface）：小型计算机系统接口。; ●FCSAN（Fibre Channel SAN）：光纤通道协议的SAN网络。
    diskStatus: Optional[str]  # 参考 <a href='https://www.ctyun.cn/document/10027696/10168629'>云硬盘使用状态</a>
    createTime: Any  # 创建时刻，epoch时戳，精度毫秒。
    updateTime: Any  # 更新时刻，epoch时戳，精度毫秒。
    expireTime: Any  # 过期时刻，epoch时戳，精度毫秒。
    isSystemVolume: Optional[bool]  # 只有为系统盘时才返回该字段。
    isPackaged: Optional[bool]  # 是否随云主机一起订购。
    instanceName: Optional[str]  # 绑定的云主机名称，有挂载时才返回。
    instanceID: Optional[str]  # 绑定的云主机ID，有挂载时才返回。
    instanceStatus: Optional[str]  # 云主机状态，参考<a href='https://www.ctyun.cn/document/10027696/10168629'>云主机使用状态</a>
    multiAttach: Optional[bool]  # 是否是共享云硬盘。
    attachments: Optional[List[Optional[EbsQueryEbsByIDReturnObjAttachmentsResponse]]]  # 挂载信息。如果是共享挂载云硬盘，则返回多项；无挂载时不返回该字段。
    projectID: Optional[str]  # 资源所属的企业项目ID。
    isEncrypt: Optional[bool]  # 是否是加密盘。
    kmsUUID: Optional[str]  # 加密盘密钥UUID，是加密盘时才返回。
    onDemand: Optional[bool]  # 是否按需订购，按需时才返回该字段。
    cycleType: Optional[str]  # 包周期类型，year：年，month：月。非按需时才返回。
    cycleCount: Any  # 包周期数，非按需时才返回。
    regionID: Optional[str]  # 资源池ID。
    azName: Optional[str]  # 多可用区下的可用区名称。
    diskFreeze: Optional[bool]  # 云硬盘是否已冻结。
    provisionedIops: Any  # XSSD类型盘的预配置iops，未配置返回0，其他类型盘不返回。
    snapshotPolicyID: Optional[str]  # 云硬盘绑定的快照策略ID，若没有绑定则返回null。
    labels: Optional[List[Optional[EbsQueryEbsByIDReturnObjLabelsResponse]]]  # 标签信息。资源池支持标签功能才返回。
    decPoolID: Optional[str]  # 专属云存储池ID，只有磁盘为专属云盘时才返回。
    decPoolName: Optional[str]  # 专属云存储池名称，只有磁盘为专属云盘时才返回。
    deleteSnapWithEbs: Optional[str]  # 是否随云硬盘释放快照。只有支持快照的资源池会返回。
    iops: Any  # 云硬盘iops。只有资源池支持展示iops才会返回。
    throughput: Any  # 云硬盘吞吐量，单位为MB/s。只有资源池支持展示吞吐量才会返回。
    volumeSourceType: Optional[str]  # 云硬盘创建源类型。只有单独订购的盘在有数据源场景下返回，取值为：image/snapshot/backup。
    volumeSourceID: Optional[str]  # 云硬盘创建源ID。只有单独订购的盘在有数据源场景下返回。
    volumeDescription: Optional[str]  # 云硬盘描述.


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsQueryEbsByIDReturnObjResponse']:
        if not json_data:
            return None

        attachments = None
        if "attachments" in json_data:
            attachs = json_data.get("attachments")
            if attachs is not None and isinstance(attachs, list):
                attachments = [EbsQueryEbsByIDReturnObjAttachmentsResponse.from_json(attach) for attach in attachs]

        labels = None
        if "labels" in json_data:
            json_labels = json_data.get("labels")
            if json_labels is not None and isinstance(json_labels, list):
                labels = [EbsQueryEbsByIDReturnObjLabelsResponse.from_json(label) for label in json_labels]


        obj = EbsQueryEbsByIDReturnObjResponse(
            diskName=json_data.get("diskName"),
            diskID=json_data.get("diskID"),
            diskSize=json_data.get("diskSize"),
            diskType=json_data.get("diskType"),
            diskMode=json_data.get("diskMode"),
            diskStatus=json_data.get("diskStatus"),
            createTime=json_data.get("createTime"),
            updateTime=json_data.get("updateTime"),
            expireTime=json_data.get("expireTime"),
            isSystemVolume=json_data.get("isSystemVolume"),
            isPackaged=json_data.get("isPackaged"),
            instanceName=json_data.get("instanceName"),
            instanceID=json_data.get("instanceID"),
            instanceStatus=json_data.get("instanceStatus"),
            multiAttach=json_data.get("multiAttach"),
            attachments=attachments,
            projectID=json_data.get("projectID"),
            isEncrypt=json_data.get("isEncrypt"),
            kmsUUID=json_data.get("kmsUUID"),
            regionID=json_data.get("regionID"),
            azName=json_data.get("azName"),
            diskFreeze=json_data.get("diskFreeze"),
            provisionedIops=json_data.get("provisionedIops"),
            decPoolID=json_data.get("decPoolID"),
            decPoolName=json_data.get("decPoolName"),
            deleteSnapWithEbs=json_data.get("deleteSnapWithEbs"),
            snapshotPolicyID=json_data.get("snapshotPolicyID"),
            iops=json_data.get("iops"),
            throughput=json_data.get("throughput"),
            volumeSourceType=json_data.get("volumeSourceType"),
            volumeSourceID=json_data.get("volumeSourceID"),
            labels=labels,
            onDemand=json_data.get("onDemand"),
            cycleType=json_data.get("cycleType"),
            cycleCount=json_data.get("cycleCount"),
            volumeDescription=json_data.get("volumeDescription")
        )

        return obj

@dataclass
class EbsQueryEbsByIDResponse:
    statusCode: Any  # 返回状态码(800为成功，900为失败)。
    message: Optional[str]  # 成功或失败时的描述，一般为英文描述。
    description: Optional[str]  # 成功或失败时的描述，一般为中文描述。
    returnObj: Optional[EbsQueryEbsByIDReturnObjResponse]  # 云硬盘详情对象。
    errorCode: Optional[str]  # 业务细分码，为product.module.code三段式码，请参考错误码。
    error: Optional[str]  # 业务细分码，为product.module.code三段式大驼峰码，请参考错误码。


    def to_dict(self) -> dict:
        return {k: v for k, v in vars(self).items() if not k.startswith('_')}

    @staticmethod
    def from_json(json_data: dict) -> Optional['EbsQueryEbsByIDResponse']:
        if not json_data:
            return None

        return_obj = None
        if "returnObj" in json_data:
            returnObj = json_data.get("returnObj")
            if returnObj is not None:
                return_obj = EbsQueryEbsByIDReturnObjResponse.from_json(returnObj)
        obj = EbsQueryEbsByIDResponse(
            statusCode=json_data.get("statusCode"),
            message=json_data.get("message"),
            description=json_data.get("description"),
            returnObj=return_obj,
            errorCode=json_data.get("errorCode"),
            error=json_data.get("error")
        )

        return obj


# 基于磁盘ID查询云硬盘详情。
class EbsQueryEbsByIDApi:
    def __init__(self, ak: str = None, sk: str = None):
        self.endpoint = None
        self.credential = Credential(ak, sk)

    def set_endpoint(self, endpoint: str) -> None:
        self.endpoint = endpoint

    @staticmethod
    def do(credential: Credential, client: CtyunClient, endpoint: str, request: EbsQueryEbsByIDRequest) -> EbsQueryEbsByIDResponse:
        url = endpoint + "/v4/ebs/info-ebs"
        params = {'diskID':request.diskID, 'regionID':request.regionID}
        try:
            request_dict = request.to_dict() if hasattr(request, 'to_dict') else request
            request_dict = {key: value for key, value in request_dict.items() if value is not None}
            response = client.get(url=url, params=params, header_params=request_dict, credential=credential)
            return EbsQueryEbsByIDResponse.from_json(response.json())
        except Exception as e:
            raise CtyunRequestException(str(e))

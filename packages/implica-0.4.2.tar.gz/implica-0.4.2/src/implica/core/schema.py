"""
Type schema system for pattern matching types with type variables.

This module defines TypeSchema, which allows pattern matching of types
against templates containing type variables, similar to unification in
type systems.
"""

from typing import Dict, Optional, Set, Mapping
from pydantic import BaseModel, ConfigDict, Field

from .types import BaseType, Variable, Application


class TypeMatch(BaseModel):
    """
    Result of a successful type schema match.

    Contains the original type that was matched and the binding of
    type variables to their matched types.

    Attributes:
        original_type: The type that was successfully matched
        bindings: Dictionary mapping variable names to their matched types
    """

    original_type: BaseType = Field(
        ..., description="The type that was successfully matched"
    )
    bindings: Mapping[str, BaseType] = Field(
        default_factory=dict,
        description="Mapping from type variable names to their matched types",
    )

    model_config = ConfigDict(frozen=True)

    def __str__(self) -> str:
        """Return a human-readable representation of the match."""
        bindings_str = ", ".join(
            f"{name} = {type_}" for name, type_ in self.bindings.items()
        )
        return f"Match({bindings_str})"

    def __repr__(self) -> str:
        """Return a detailed representation."""
        return f"TypeMatch(original_type={repr(self.original_type)}, bindings={self.bindings})"


class TypeSchema(BaseModel):
    """
    A type schema that can match types with type variables.

    A type schema represents a pattern with type variables that can be matched
    against concrete types. When matching succeeds, it returns a TypeMatch with
    bindings for each type variable.

    Variable Matching Modes:
    - Pattern variables (e.g., X, Y): Act as wildcards that can match any type
    - Exact match variables (e.g., $A, $B): Must match exactly the named type

    Example:
        # Pattern variables act as wildcards
        schema = TypeSchema(pattern=type_from_string("A -> B -> A"))
        result = schema.match(type_from_string("(X -> Y) -> Z -> (X -> Y)"))
        assert result is not None
        assert result.bindings["A"] == type_from_string("X -> Y")
        assert result.bindings["B"] == type_from_string("Z")

        # Exact match variables require exact name match
        schema = TypeSchema(pattern=var("$A"))  # Must match exactly "A"
        result = schema.match(var("A"))  # Matches!
        assert result is not None
        result = schema.match(var("B"))  # Does not match
        assert result is None

    Attributes:
        pattern: The type pattern to match against, containing type variables
    """

    pattern: BaseType = Field(..., description="The type pattern to match against")

    model_config = ConfigDict(frozen=True)

    def match(self, target: BaseType) -> Optional[TypeMatch]:
        """
        Try to match a type against this schema's pattern.

        Attempts to find a consistent binding of type variables in the pattern
        to subtypes of the target type. Returns None if no match is possible.

        Args:
            target: The type to match against the pattern

        Returns:
            TypeMatch if successful with variable bindings, None otherwise

        Examples:
            >>> schema = TypeSchema(pattern=type_from_string("A -> B"))
            >>> result = schema.match(type_from_string("X -> Y"))
            >>> result.bindings
            {'A': Variable(name='X'), 'B': Variable(name='Y')}

            >>> schema = TypeSchema(pattern=type_from_string("A -> A"))
            >>> result = schema.match(type_from_string("X -> Y"))
            >>> result is None  # X and Y don't match
            True
        """
        bindings: Dict[str, BaseType] = {}

        if self._unify(self.pattern, target, bindings):
            return TypeMatch(original_type=target, bindings=bindings)

        return None

    def _unify(
        self, pattern: BaseType, target: BaseType, bindings: Dict[str, BaseType]
    ) -> bool:
        """
        Recursively unify pattern with target, updating bindings.

        This implements the core unification algorithm:
        - If pattern is a Variable starting with '$', require exact match
        - If pattern is a Variable (without '$'), bind it to target (if consistent)
        - If both are Applications, recursively unify their components
        - Otherwise, they don't match

        Args:
            pattern: The pattern type (may contain variables)
            target: The concrete type to match
            bindings: Dictionary to update with variable bindings

        Returns:
            True if unification succeeds, False otherwise
        """
        # If pattern is a variable
        if isinstance(pattern, Variable):
            # Check if this is an exact-match variable (starts with '$')
            if pattern.name.startswith("$"):
                # Exact match required: target must be a Variable with matching name (without '$')
                if isinstance(target, Variable):
                    return target.name == pattern.name[1:]  # Strip '$' prefix
                return False
            else:
                # Pattern variable: bind it to target
                return self._bind_variable(pattern.name, target, bindings)

        # If pattern is an Application, target must also be an Application
        if isinstance(pattern, Application):
            if not isinstance(target, Application):
                return False

            # Both input and output must unify
            return self._unify(
                pattern.input_type, target.input_type, bindings
            ) and self._unify(pattern.output_type, target.output_type, bindings)

        # If pattern is neither Variable nor Application, this shouldn't happen
        # with the current type system, but return False for safety
        return False

    def _bind_variable(
        self, var_name: str, target: BaseType, bindings: Dict[str, BaseType]
    ) -> bool:
        """
        Try to bind a variable to a type.

        If the variable is already bound, check that the existing binding
        matches the target. Otherwise, create a new binding.

        Args:
            var_name: Name of the variable to bind
            target: The type to bind to
            bindings: Dictionary to update with the binding

        Returns:
            True if binding succeeds (either new or consistent), False otherwise
        """
        if var_name in bindings:
            # Variable already bound - check consistency
            # Two types are consistent if they have the same UID
            return bindings[var_name].uid == target.uid
        else:
            # Create new binding
            bindings[var_name] = target
            return True

    def get_pattern_variables(self) -> Set[str]:
        """
        Get the set of all variable names in the pattern.

        Returns:
            Set of variable names used in the pattern
        """
        return {var.name for var in self.pattern.variables}

    def __str__(self) -> str:
        """Return a string representation of the schema."""
        return f"TypeSchema({self.pattern})"

    def __repr__(self) -> str:
        """Return a detailed representation."""
        return f"TypeSchema(pattern={repr(self.pattern)})"


def schema(pattern: BaseType) -> TypeSchema:
    """
    Helper function to create a TypeSchema.

    Args:
        pattern: The type pattern to match against

    Returns:
        TypeSchema: A new TypeSchema instance
    """
    return TypeSchema(pattern=pattern)

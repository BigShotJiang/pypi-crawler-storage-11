"""
Combinator system for minimal implicational logic.

This module defines combinators that represent transformations between types
in the implicational logic graph.
"""

import hashlib
from functools import cached_property

from pydantic import BaseModel, ConfigDict, Field

from .types import BaseType, Application, app


class Combinator(BaseModel):
    """
    A combinator with a specific type.

    In combinatory logic:
    - S combinator: S x y z = x z (y z) with type (A -> B -> C) -> (A -> B) -> A -> C
    - K combinator: K x y = x with type A -> B -> A

    Each combinator has a name (e.g., "S", "K") and an Application type that
    represents the transformation it performs. The type must be an Application
    (function type), not a simple Variable, as combinators represent transformations
    from input types to output types.

    Attributes:
        name: The name/identifier of the combinator (e.g., "S", "K", "I")
        type: The Application type of the combinator, representing the function
              signature (input -> output). Must be an Application instance.

    Raises:
        ValidationError: If type is not an Application instance
    """

    name: str = Field(..., min_length=1, description="Name of the combinator")
    type: Application = Field(
        ...,
        description="Application type of the combinator (must be input -> output form)",
    )

    model_config = ConfigDict(frozen=True)  # Make immutable

    @cached_property
    def uid(self) -> str:
        """
        Return a unique identifier for this combinator.

        The uid includes both the name and the type, as combinators with the same
        name but different types are different combinators.

        Returns:
            str: SHA256 hash of the combinator name and type
        """
        content = f"Comb({self.name},{self.type.uid})"
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def __str__(self) -> str:
        """Return the combinator name and type."""
        return f"{self.name}: {self.type}"

    def __repr__(self) -> str:
        """Return a detailed representation."""
        return f"Combinator(name='{self.name}', type={self.type})"

    def __hash__(self) -> int:
        """Make combinator hashable for use in sets and dicts."""
        return hash((self.name, self.type.uid))


# Helper functions for creating S and K combinators with specific types
def S(A: BaseType, B: BaseType, C: BaseType) -> Combinator:
    """
    Create the S combinator with specific types.

    Type: (A -> B -> C) -> (A -> B) -> A -> C

    The S combinator implements the following computation:
    S x y z = x z (y z)

    Args:
        A: Type variable A
        B: Type variable B
        C: Type variable C

    Returns:
        Combinator: The S combinator with the specified types
    """
    s_type = app(
        app(A, app(B, C)),  # (A -> B -> C)
        app(app(A, B), app(A, C)),  # (A -> B) -> A -> C
    )
    return Combinator(name="S", type=s_type)


def K(A: BaseType, B: BaseType) -> Combinator:
    """
    Create the K combinator with specific types.

    Type: A -> B -> A

    The K combinator implements the following computation:
    K x y = x

    Args:
        A: Type variable A
        B: Type variable B

    Returns:
        Combinator: The K combinator with type A -> B -> A
    """
    k_type = app(A, app(B, A))  # A -> B -> A
    return Combinator(name="K", type=k_type)


def combinator(name: str, type: Application) -> Combinator:
    """
    Helper function to create a combinator with a given name and type.

    Args:
        name: Name/identifier for the combinator (e.g., "S", "K", "I")
        type: Application type representing the combinator's function signature.
              Must be an Application instance (input -> output form).

    Returns:
        Combinator: A new Combinator instance

    Raises:
        ValidationError: If type is not an Application instance
    """
    return Combinator(name=name, type=type)

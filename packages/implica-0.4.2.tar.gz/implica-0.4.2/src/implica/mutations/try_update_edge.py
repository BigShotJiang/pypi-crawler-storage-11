from typing import TYPE_CHECKING, Any

from .base import Mutation

if TYPE_CHECKING:
    from ..graph import Graph


class TryUpdateEdge(Mutation):
    """Mutation to update an edge's properties, or do nothing if it doesn't exist."""

    def __init__(self, edge_uid: str, properties: dict[str, Any]):
        """
        Initialize the TryUpdateEdge mutation.

        Args:
            edge_uid: The uid of the edge to update
            properties: Dictionary with properties to update
        """
        self.edge_uid = edge_uid
        self.properties = properties
        self._old_properties: dict[str, Any] | None = None
        self._edge_existed = False

    def forward(self, graph: "Graph") -> None:
        """
        Update the edge's properties if it exists.

        Args:
            graph: The graph to modify
        """
        if graph.has_edge(self.edge_uid):
            self._edge_existed = True
            self._old_properties = graph._update_edge(self.edge_uid, self.properties)

    def backward(self, graph: "Graph") -> None:
        """
        Restore the edge's old properties if it was updated.

        Args:
            graph: The graph to modify
        """
        if self._edge_existed and self._old_properties is not None:
            edge = graph.get_edge(self.edge_uid)
            edge.properties.clear()
            edge.properties.update(self._old_properties)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"TryUpdateEdge(edge_uid={self.edge_uid}, properties={self.properties})"

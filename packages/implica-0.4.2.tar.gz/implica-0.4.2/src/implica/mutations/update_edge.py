from typing import TYPE_CHECKING, Any

from .base import Mutation

if TYPE_CHECKING:
    from ..graph import Graph


class UpdateEdge(Mutation):
    """Mutation to update an edge's properties in the graph."""

    def __init__(self, edge_uid: str, properties: dict[str, Any]):
        """
        Initialize the UpdateEdge mutation.

        Args:
            edge_uid: The uid of the edge to update
            properties: Dictionary with properties to update
        """
        self.edge_uid = edge_uid
        self.properties = properties
        self._old_properties: dict[str, Any] | None = None

    def forward(self, graph: "Graph") -> None:
        """
        Update the edge's properties in the graph.

        Args:
            graph: The graph to modify

        Raises:
            KeyError: If the edge doesn't exist
        """
        self._old_properties = graph._update_edge(self.edge_uid, self.properties)

    def backward(self, graph: "Graph") -> None:
        """
        Restore the edge's old properties.

        Args:
            graph: The graph to modify
        """
        if self._old_properties is not None:
            edge = graph.get_edge(self.edge_uid)
            edge.properties.clear()
            edge.properties.update(self._old_properties)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"UpdateEdge(edge_uid={self.edge_uid}, properties={self.properties})"

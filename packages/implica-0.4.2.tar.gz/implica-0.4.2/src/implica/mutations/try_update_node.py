from typing import TYPE_CHECKING, Any

from .base import Mutation

if TYPE_CHECKING:
    from ..graph import Graph


class TryUpdateNode(Mutation):
    """Mutation to update a node's properties, or do nothing if it doesn't exist."""

    def __init__(self, node_uid: str, properties: dict[str, Any]):
        """
        Initialize the TryUpdateNode mutation.

        Args:
            node_uid: The uid of the node to update
            properties: Dictionary with properties to update
        """
        self.node_uid = node_uid
        self.properties = properties
        self._old_properties: dict[str, Any] | None = None
        self._node_existed = False

    def forward(self, graph: "Graph") -> None:
        """
        Update the node's properties if it exists.

        Args:
            graph: The graph to modify
        """
        if graph.has_node(self.node_uid):
            self._node_existed = True
            self._old_properties = graph._update_node(self.node_uid, self.properties)

    def backward(self, graph: "Graph") -> None:
        """
        Restore the node's old properties if it was updated.

        Args:
            graph: The graph to modify
        """
        if self._node_existed and self._old_properties is not None:
            node = graph.get_node(self.node_uid)
            node.properties.clear()
            node.properties.update(self._old_properties)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"TryUpdateNode(node_uid={self.node_uid}, properties={self.properties})"

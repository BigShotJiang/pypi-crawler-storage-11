"""
Connection system for transactional graph modifications.

This module defines the Connection class which accumulates mutations and
executes them transactionally with automatic rollback on failure.
"""

from typing import TYPE_CHECKING, Any, Optional

from .elements import Node
from ..core.combinator import Combinator
from ..core.schema import TypeSchema
from ..mutations import (
    Mutation,
    AddNode,
    RemoveNode,
    AddEdge,
    RemoveEdge,
    AddManyNodes,
    AddManyEdges,
    TryAddNode,
    TryAddEdge,
    RemoveManyNodes,
    RemoveManyEdges,
    TryRemoveNode,
    TryRemoveEdge,
    TryAddManyNodes,
    TryAddManyEdges,
    TryRemoveManyNodes,
    TryRemoveManyEdges,
    UpdateNode,
    UpdateEdge,
    TryUpdateNode,
    TryUpdateEdge,
)

if TYPE_CHECKING:
    from .graph import Graph


class Connection:
    """
    A connection for making transactional modifications to a graph.

    Usage:
        with graph.connect() as conn:
            conn.add_node(node1)
            conn.add_edge(edge1)
        # Changes are committed automatically if no exception occurs
        # Otherwise, all changes are rolled back

    Can also be used without context manager:
        conn = graph.connect()
        conn.add_node(node1)
        conn.commit()  # or conn.rollback()
    """

    def __init__(self, graph: "Graph"):
        """
        Initialize a connection.

        Args:
            graph: The graph to operate on
        """
        self.graph = graph
        self.mutations: list[Mutation] = []
        self._committed = False
        self._rolled_back = False

    def add_node(
        self,
        node: Node | None = None,
        *,
        type=None,
        properties: dict[str, Any] | None = None,
    ) -> "Connection":
        """
        Add a mutation to create a node.

        Args:
            node: The node to add (if provided, type and properties are ignored)
            type: The type for the node (used only if node is None)
            properties: Optional properties for the node (used only if node is None)

        Returns:
            Connection: Self for method chaining

        Raises:
            ValueError: If neither node nor type is provided
        """
        self._check_state()

        if node is None:
            if type is None:
                raise ValueError("Either node or type must be provided")
            from .elements import node as create_node

            node = create_node(type, properties=properties)

        self.mutations.append(AddNode(node))
        return self

    def remove_node(self, node_uid: str) -> "Connection":
        """
        Add a mutation to remove a node.

        Args:
            node_uid: The uid of the node to remove

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(RemoveNode(node_uid))
        return self

    def add_edge(
        self, combinator: Combinator, properties: dict[str, Any] | None = None
    ) -> "Connection":
        """
        Add a mutation to create an edge from a combinator.

        The edge will be created with nodes corresponding to the combinator's
        input and output types. The nodes must exist when the mutation is applied.

        Args:
            combinator: The combinator for this edge
            properties: Optional properties for the edge

        Returns:
            Connection: Self for method chaining

        Raises:
            ValueError: If the combinator doesn't have an Application type
        """
        self._check_state()

        # Import here to avoid circular import
        from .elements import edge
        from ..core.types import Application

        # Validate combinator type
        if not isinstance(combinator.type, Application):
            raise ValueError(
                f"Combinator must have an Application type to create an edge, "
                f"got {type(combinator.type).__name__}"
            )

        # Create the edge - validation that nodes exist will happen at forward() time
        e = edge(combinator, properties=properties)
        self.mutations.append(AddEdge(e))
        return self

    def remove_edge(self, edge_uid: str) -> "Connection":
        """
        Add a mutation to remove an edge.

        Args:
            edge_uid: The uid of the edge to remove

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(RemoveEdge(edge_uid))
        return self

    def add_many_nodes(
        self,
        nodes: list[Node] | None = None,
        *,
        types=None,
        properties: dict[str, Any] | list[dict[str, Any]] | None = None,
    ) -> "Connection":
        """
        Add a mutation to create multiple nodes.

        Args:
            nodes: List of nodes to add (if provided, types and properties are ignored)
            types: List of types for the nodes (used only if nodes is None)
            properties: Optional properties - either a single dict (applied to all nodes)
                       or a list of dicts (one per node, must match length of types)

        Returns:
            Connection: Self for method chaining

        Raises:
            ValueError: If neither nodes nor types is provided, or if properties list
                       length doesn't match types length
        """
        self._check_state()

        if nodes is None:
            if types is None:
                raise ValueError("Either nodes or types must be provided")

            from .elements import node as create_node

            # Handle properties: single dict for all or list of dicts
            if properties is None:
                # No properties for any node
                nodes = [create_node(t) for t in types]
            elif isinstance(properties, dict):
                # Single dict: apply to all nodes
                nodes = [create_node(t, properties=properties) for t in types]
            elif isinstance(properties, list):
                # List of dicts: one per node
                if len(properties) != len(types):
                    raise ValueError(
                        f"Length of properties list ({len(properties)}) must match "
                        f"length of types list ({len(types)})"
                    )
                nodes = [
                    create_node(t, properties=p) for t, p in zip(types, properties)
                ]
            else:
                raise ValueError("properties must be a dict or list of dicts")

        self.mutations.append(AddManyNodes(nodes))
        return self

    def add_many_edges(
        self,
        combinators: list[Combinator],
        properties: dict[str, Any] | list[dict[str, Any]] | None = None,
    ) -> "Connection":
        """
        Add a mutation to create multiple edges from combinators.

        Args:
            combinators: List of combinators for the edges
            properties: Optional properties - either a single dict (applied to all edges)
                       or a list of dicts (one per edge, must match length of combinators)

        Returns:
            Connection: Self for method chaining

        Raises:
            ValueError: If any combinator doesn't have an Application type, or if
                       properties list length doesn't match combinators length
        """
        self._check_state()

        # Import here to avoid circular import
        from .elements import edge
        from ..core.types import Application

        # Handle properties: single dict for all or list of dicts
        if properties is None:
            # No properties for any edge
            props_list = [None] * len(combinators)
        elif isinstance(properties, dict):
            # Single dict: apply to all edges
            props_list = [properties] * len(combinators)
        elif isinstance(properties, list):
            # List of dicts: one per edge
            if len(properties) != len(combinators):
                raise ValueError(
                    f"Length of properties list ({len(properties)}) must match "
                    f"length of combinators list ({len(combinators)})"
                )
            props_list = properties
        else:
            raise ValueError("properties must be a dict or list of dicts")

        # Validate all combinators and create edges
        edges = []
        for combinator, props in zip(combinators, props_list):
            if not isinstance(combinator.type, Application):
                raise ValueError(
                    f"Combinator must have an Application type to create an edge, "
                    f"got {type(combinator.type).__name__}"
                )
            edges.append(edge(combinator, properties=props))

        self.mutations.append(AddManyEdges(edges))
        return self

    def try_add_node(
        self,
        node: Node | None = None,
        *,
        type=None,
        properties: dict[str, Any] | None = None,
    ) -> "Connection":
        """
        Add a mutation to create a node, or do nothing if it already exists.

        Args:
            node: The node to add (if provided, type and properties are ignored)
            type: The type for the node (used only if node is None)
            properties: Optional properties for the node (used only if node is None)

        Returns:
            Connection: Self for method chaining

        Raises:
            ValueError: If neither node nor type is provided
        """
        self._check_state()

        if node is None:
            if type is None:
                raise ValueError("Either node or type must be provided")
            from .elements import node as create_node

            node = create_node(type, properties=properties)

        self.mutations.append(TryAddNode(node))
        return self

    def try_add_edge(
        self, combinator: Combinator, properties: dict[str, Any] | None = None
    ) -> "Connection":
        """
        Add a mutation to create an edge from a combinator, or do nothing if it already exists.

        Args:
            combinator: The combinator for this edge
            properties: Optional properties for the edge

        Returns:
            Connection: Self for method chaining

        Raises:
            ValueError: If the combinator doesn't have an Application type
        """
        self._check_state()

        # Import here to avoid circular import
        from .elements import edge
        from ..core.types import Application

        # Validate combinator type
        if not isinstance(combinator.type, Application):
            raise ValueError(
                f"Combinator must have an Application type to create an edge, "
                f"got {type(combinator.type).__name__}"
            )

        # Create the edge
        e = edge(combinator, properties=properties)
        self.mutations.append(TryAddEdge(e))
        return self

    def try_add_many_nodes(
        self,
        nodes: list[Node] | None = None,
        *,
        types=None,
        properties: dict[str, Any] | list[dict[str, Any]] | None = None,
    ) -> "Connection":
        """
        Add a mutation to create multiple nodes, or do nothing for nodes that already exist.

        Args:
            nodes: List of nodes to add (if provided, types and properties are ignored)
            types: List of types for the nodes (used only if nodes is None)
            properties: Optional properties - either a single dict (applied to all nodes)
                       or a list of dicts (one per node, must match length of types)

        Returns:
            Connection: Self for method chaining

        Raises:
            ValueError: If neither nodes nor types is provided, or if properties list
                       length doesn't match types length
        """
        self._check_state()

        if nodes is None:
            if types is None:
                raise ValueError("Either nodes or types must be provided")

            from .elements import node as create_node

            # Handle properties: single dict for all or list of dicts
            if properties is None:
                # No properties for any node
                nodes = [create_node(t) for t in types]
            elif isinstance(properties, dict):
                # Single dict: apply to all nodes
                nodes = [create_node(t, properties=properties) for t in types]
            elif isinstance(properties, list):
                # List of dicts: one per node
                if len(properties) != len(types):
                    raise ValueError(
                        f"Length of properties list ({len(properties)}) must match "
                        f"length of types list ({len(types)})"
                    )
                nodes = [
                    create_node(t, properties=p) for t, p in zip(types, properties)
                ]
            else:
                raise ValueError("properties must be a dict or list of dicts")

        self.mutations.append(TryAddManyNodes(nodes))
        return self

    def try_add_many_edges(
        self,
        combinators: list[Combinator],
        properties: dict[str, Any] | list[dict[str, Any]] | None = None,
    ) -> "Connection":
        """
        Add a mutation to create multiple edges from combinators, or do nothing for edges that already exist.

        Args:
            combinators: List of combinators for the edges
            properties: Optional properties - either a single dict (applied to all edges)
                       or a list of dicts (one per edge, must match length of combinators)

        Returns:
            Connection: Self for method chaining

        Raises:
            ValueError: If any combinator doesn't have an Application type, or if
                       properties list length doesn't match combinators length
        """
        self._check_state()

        # Import here to avoid circular import
        from .elements import edge
        from ..core.types import Application

        # Handle properties: single dict for all or list of dicts
        if properties is None:
            # No properties for any edge
            props_list = [None] * len(combinators)
        elif isinstance(properties, dict):
            # Single dict: apply to all edges
            props_list = [properties] * len(combinators)
        elif isinstance(properties, list):
            # List must contain only dicts
            if not all(isinstance(p, dict) for p in properties):
                raise ValueError("properties must be a dict or list of dicts")
            # List of dicts: one per edge
            if len(properties) != len(combinators):
                raise ValueError(
                    f"Length of properties list ({len(properties)}) must match "
                    f"length of combinators list ({len(combinators)})"
                )
            props_list = properties
        else:
            raise ValueError("properties must be a dict or list of dicts")

        # Validate all combinators and create edges
        edges = []
        for combinator, props in zip(combinators, props_list):
            if not isinstance(combinator.type, Application):
                raise ValueError(
                    f"Combinator must have an Application type to create an edge, "
                    f"got {type(combinator.type).__name__}"
                )
            edges.append(edge(combinator, properties=props))

        self.mutations.append(TryAddManyEdges(edges))
        return self

    def remove_many_nodes(self, node_uids: list[str]) -> "Connection":
        """
        Add a mutation to remove multiple nodes.

        Args:
            node_uids: List of node uids to remove

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(RemoveManyNodes(node_uids))
        return self

    def remove_many_edges(self, edge_uids: list[str]) -> "Connection":
        """
        Add a mutation to remove multiple edges.

        Args:
            edge_uids: List of edge uids to remove

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(RemoveManyEdges(edge_uids))
        return self

    def try_remove_node(self, node_uid: str) -> "Connection":
        """
        Add a mutation to remove a node, or do nothing if it doesn't exist.

        Args:
            node_uid: The uid of the node to remove

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(TryRemoveNode(node_uid))
        return self

    def try_remove_edge(self, edge_uid: str) -> "Connection":
        """
        Add a mutation to remove an edge, or do nothing if it doesn't exist.

        Args:
            edge_uid: The uid of the edge to remove

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(TryRemoveEdge(edge_uid))
        return self

    def try_remove_many_nodes(self, node_uids: list[str]) -> "Connection":
        """
        Add a mutation to remove multiple nodes, or do nothing for nodes that don't exist.

        Args:
            node_uids: List of node uids to remove

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(TryRemoveManyNodes(node_uids))
        return self

    def try_remove_many_edges(self, edge_uids: list[str]) -> "Connection":
        """
        Add a mutation to remove multiple edges, or do nothing for edges that don't exist.

        Args:
            edge_uids: List of edge uids to remove

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(TryRemoveManyEdges(edge_uids))
        return self

    def update_node(self, node_uid: str, properties: dict[str, Any]) -> "Connection":
        """
        Add a mutation to update a node's properties.

        Args:
            node_uid: The uid of the node to update
            properties: Dictionary with properties to update

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(UpdateNode(node_uid, properties))
        return self

    def update_edge(self, edge_uid: str, properties: dict[str, Any]) -> "Connection":
        """
        Add a mutation to update an edge's properties.

        Args:
            edge_uid: The uid of the edge to update
            properties: Dictionary with properties to update

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(UpdateEdge(edge_uid, properties))
        return self

    def try_update_node(
        self, node_uid: str, properties: dict[str, Any]
    ) -> "Connection":
        """
        Add a mutation to update a node's properties, or do nothing if it doesn't exist.

        Args:
            node_uid: The uid of the node to update
            properties: Dictionary with properties to update

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(TryUpdateNode(node_uid, properties))
        return self

    def try_update_edge(
        self, edge_uid: str, properties: dict[str, Any]
    ) -> "Connection":
        """
        Add a mutation to update an edge's properties, or do nothing if it doesn't exist.

        Args:
            edge_uid: The uid of the edge to update
            properties: Dictionary with properties to update

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()
        self.mutations.append(TryUpdateEdge(edge_uid, properties))
        return self

    # ========== Schema-based operations ==========

    def add_nodes_for_schema(
        self,
        schema: TypeSchema,
        types: list,
        properties: dict[str, Any] | list[dict[str, Any]] | None = None,
    ) -> "Connection":
        """
        Add nodes for types that match the given schema.

        Only adds nodes for types that match the schema pattern.
        This is useful for bulk operations where you want to filter types first.

        Args:
            schema: The type schema to match against
            types: List of types to check and potentially add
            properties: Optional properties - either a single dict (applied to all nodes)
                       or a list of dicts (one per type, must match length of types)

        Returns:
            Connection: Self for method chaining

        Example:
            >>> schema = TypeSchema(pattern=type_from_string("A -> B"))
            >>> conn.add_nodes_for_schema(schema, [type1, type2, type3])
        """
        self._check_state()

        # Filter types that match the schema
        matching_types = [t for t in types if schema.match(t) is not None]

        if not matching_types:
            return self

        # Handle properties
        if properties is None:
            props_to_use = None
        elif isinstance(properties, dict):
            props_to_use = properties
        elif isinstance(properties, list):
            # Need to filter properties to match filtered types
            matching_props = []
            for i, t in enumerate(types):
                if schema.match(t) is not None:
                    matching_props.append(properties[i] if i < len(properties) else {})
            props_to_use = matching_props
        else:
            raise ValueError("properties must be a dict or list of dicts")

        return self.add_many_nodes(types=matching_types, properties=props_to_use)

    def try_add_nodes_for_schema(
        self,
        schema: TypeSchema,
        types: list,
        properties: dict[str, Any] | list[dict[str, Any]] | None = None,
    ) -> "Connection":
        """
        Try to add nodes for types that match the given schema (skip existing).

        Args:
            schema: The type schema to match against
            types: List of types to check and potentially add
            properties: Optional properties - either a single dict or list of dicts

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()

        # Filter types that match the schema
        matching_types = [t for t in types if schema.match(t) is not None]

        if not matching_types:
            return self

        # Handle properties
        if properties is None:
            props_to_use = None
        elif isinstance(properties, dict):
            props_to_use = properties
        elif isinstance(properties, list):
            # Filter properties to match filtered types
            matching_props = []
            for i, t in enumerate(types):
                if schema.match(t) is not None:
                    matching_props.append(properties[i] if i < len(properties) else {})
            props_to_use = matching_props
        else:
            raise ValueError("properties must be a dict or list of dicts")

        return self.try_add_many_nodes(types=matching_types, properties=props_to_use)

    def remove_nodes_matching_schema(
        self, schema: TypeSchema, properties: Optional[dict[str, Any]] = None
    ) -> "Connection":
        """
        Remove all nodes in the graph whose types match the given schema.

        This queries the graph at mutation-building time to identify nodes to remove.

        Args:
            schema: The type schema to match against
            properties: Optional dict of properties to filter by

        Returns:
            Connection: Self for method chaining

        Example:
            >>> schema = TypeSchema(pattern=type_from_string("A -> B"))
            >>> conn.remove_nodes_matching_schema(schema)
        """
        self._check_state()

        # Query the graph for matching nodes
        matching_nodes = self.graph.filter_nodes_by_schema(schema, properties)
        node_uids = [node.uid for node in matching_nodes]

        if node_uids:
            self.mutations.append(RemoveManyNodes(node_uids))

        return self

    def try_remove_nodes_matching_schema(
        self, schema: TypeSchema, properties: Optional[dict[str, Any]] = None
    ) -> "Connection":
        """
        Try to remove all nodes matching the schema (skip if not found).

        Args:
            schema: The type schema to match against
            properties: Optional dict of properties to filter by

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()

        # Query the graph for matching nodes
        matching_nodes = self.graph.filter_nodes_by_schema(schema, properties)
        node_uids = [node.uid for node in matching_nodes]

        if node_uids:
            self.mutations.append(TryRemoveManyNodes(node_uids))

        return self

    def remove_edges_matching_schema(
        self,
        src_schema: Optional[TypeSchema] = None,
        dst_schema: Optional[TypeSchema] = None,
        combinator_schema: Optional[TypeSchema] = None,
        properties: Optional[dict[str, Any]] = None,
    ) -> "Connection":
        """
        Remove all edges in the graph matching the given schema patterns.

        Args:
            src_schema: Optional schema to match source node types
            dst_schema: Optional schema to match destination node types
            combinator_schema: Optional schema to match combinator types
            properties: Optional dict of properties to filter by

        Returns:
            Connection: Self for method chaining

        Example:
            >>> src_schema = TypeSchema(pattern=type_from_string("A"))
            >>> conn.remove_edges_matching_schema(src_schema=src_schema)
        """
        self._check_state()

        # Query the graph for matching edges
        matching_edges = self.graph.filter_edges_by_schema(
            src_schema, dst_schema, combinator_schema, properties
        )
        edge_uids = [edge.uid for edge in matching_edges]

        if edge_uids:
            self.mutations.append(RemoveManyEdges(edge_uids))

        return self

    def try_remove_edges_matching_schema(
        self,
        src_schema: Optional[TypeSchema] = None,
        dst_schema: Optional[TypeSchema] = None,
        combinator_schema: Optional[TypeSchema] = None,
        properties: Optional[dict[str, Any]] = None,
    ) -> "Connection":
        """
        Try to remove all edges matching the schema patterns (skip if not found).

        Args:
            src_schema: Optional schema to match source node types
            dst_schema: Optional schema to match destination node types
            combinator_schema: Optional schema to match combinator types
            properties: Optional dict of properties to filter by

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()

        # Query the graph for matching edges
        matching_edges = self.graph.filter_edges_by_schema(
            src_schema, dst_schema, combinator_schema, properties
        )
        edge_uids = [edge.uid for edge in matching_edges]

        if edge_uids:
            self.mutations.append(TryRemoveManyEdges(edge_uids))

        return self

    def update_nodes_matching_schema(
        self,
        schema: TypeSchema,
        properties: dict[str, Any],
        filter_properties: Optional[dict[str, Any]] = None,
    ) -> "Connection":
        """
        Update properties of all nodes matching the given schema.

        Args:
            schema: The type schema to match against
            properties: Dictionary with properties to update
            filter_properties: Optional dict to filter nodes before updating

        Returns:
            Connection: Self for method chaining

        Example:
            >>> schema = TypeSchema(pattern=type_from_string("A -> B"))
            >>> conn.update_nodes_matching_schema(schema, {"processed": True})
        """
        self._check_state()

        # Query the graph for matching nodes
        matching_nodes = self.graph.filter_nodes_by_schema(schema, filter_properties)

        for node in matching_nodes:
            self.mutations.append(UpdateNode(node.uid, properties))

        return self

    def try_update_nodes_matching_schema(
        self,
        schema: TypeSchema,
        properties: dict[str, Any],
        filter_properties: Optional[dict[str, Any]] = None,
    ) -> "Connection":
        """
        Try to update properties of all nodes matching the schema (skip if not found).

        Args:
            schema: The type schema to match against
            properties: Dictionary with properties to update
            filter_properties: Optional dict to filter nodes before updating

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()

        # Query the graph for matching nodes
        matching_nodes = self.graph.filter_nodes_by_schema(schema, filter_properties)

        for node in matching_nodes:
            self.mutations.append(TryUpdateNode(node.uid, properties))

        return self

    def update_edges_matching_schema(
        self,
        properties: dict[str, Any],
        src_schema: Optional[TypeSchema] = None,
        dst_schema: Optional[TypeSchema] = None,
        combinator_schema: Optional[TypeSchema] = None,
        filter_properties: Optional[dict[str, Any]] = None,
    ) -> "Connection":
        """
        Update properties of all edges matching the given schema patterns.

        Args:
            properties: Dictionary with properties to update
            src_schema: Optional schema to match source node types
            dst_schema: Optional schema to match destination node types
            combinator_schema: Optional schema to match combinator types
            filter_properties: Optional dict to filter edges before updating

        Returns:
            Connection: Self for method chaining

        Example:
            >>> src_schema = TypeSchema(pattern=type_from_string("A"))
            >>> conn.update_edges_matching_schema({"weight": 2.0}, src_schema=src_schema)
        """
        self._check_state()

        # Query the graph for matching edges
        matching_edges = self.graph.filter_edges_by_schema(
            src_schema, dst_schema, combinator_schema, filter_properties
        )

        for edge in matching_edges:
            self.mutations.append(UpdateEdge(edge.uid, properties))

        return self

    def try_update_edges_matching_schema(
        self,
        properties: dict[str, Any],
        src_schema: Optional[TypeSchema] = None,
        dst_schema: Optional[TypeSchema] = None,
        combinator_schema: Optional[TypeSchema] = None,
        filter_properties: Optional[dict[str, Any]] = None,
    ) -> "Connection":
        """
        Try to update properties of all edges matching the schema patterns (skip if not found).

        Args:
            properties: Dictionary with properties to update
            src_schema: Optional schema to match source node types
            dst_schema: Optional schema to match destination node types
            combinator_schema: Optional schema to match combinator types
            filter_properties: Optional dict to filter edges before updating

        Returns:
            Connection: Self for method chaining
        """
        self._check_state()

        # Query the graph for matching edges
        matching_edges = self.graph.filter_edges_by_schema(
            src_schema, dst_schema, combinator_schema, filter_properties
        )

        for edge in matching_edges:
            self.mutations.append(TryUpdateEdge(edge.uid, properties))

        return self

    def commit(self) -> None:
        """
        Commit all mutations to the graph.

        If any mutation fails or the graph doesn't validate after all mutations,
        all changes are rolled back.

        Raises:
            RuntimeError: If already committed or rolled back
            Exception: Any exception from mutations or validation
        """
        self._check_state()

        applied_count = 0

        try:
            # Apply all mutations
            for mutation in self.mutations:
                mutation.forward(self.graph)
                applied_count += 1

            # Validate the graph
            self.graph.validate()

            # Mark as committed
            self._committed = True

        except Exception as e:
            # Rollback all applied mutations in reverse order
            for i in range(applied_count - 1, -1, -1):
                try:
                    self.mutations[i].backward(self.graph)
                except Exception as rollback_error:
                    # Log rollback error but continue rolling back
                    print(f"Warning: Error during rollback: {rollback_error}")

            self._rolled_back = True

            # Re-raise the original exception
            raise RuntimeError(
                f"Transaction failed and was rolled back. "
                f"Applied {applied_count}/{len(self.mutations)} mutations before failure."
            ) from e

    def rollback(self) -> None:
        """
        Explicitly rollback all mutations without applying them.

        Raises:
            RuntimeError: If already committed or rolled back
        """
        self._check_state()
        self._rolled_back = True

    def _check_state(self) -> None:
        """
        Check that the connection is in a valid state for operations.

        Raises:
            RuntimeError: If already committed or rolled back
        """
        if self._committed:
            raise RuntimeError("Connection has already been committed")
        if self._rolled_back:
            raise RuntimeError("Connection has already been rolled back")

    def __enter__(self) -> "Connection":
        """Enter the context manager."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        """
        Exit the context manager.

        Commits if no exception occurred, otherwise rolls back.

        Returns:
            bool: False to propagate any exception
        """
        if exc_type is None:
            # No exception, commit
            self.commit()  # Let any exception from commit propagate naturally
        else:
            # Exception occurred, rollback
            if not self._rolled_back:
                self.rollback()

        # Don't suppress the exception
        return False

    def __str__(self) -> str:
        """Return a string representation."""
        status = (
            "committed"
            if self._committed
            else ("rolled_back" if self._rolled_back else "open")
        )
        return f"Connection(mutations={len(self.mutations)}, status={status})"

    def __repr__(self) -> str:
        """Return a detailed representation."""
        return f"Connection(graph={self.graph}, mutations={self.mutations}, committed={self._committed}, rolled_back={self._rolled_back})"

"""Custom celery worker pools"""

class AbortException(Exception):
    pass

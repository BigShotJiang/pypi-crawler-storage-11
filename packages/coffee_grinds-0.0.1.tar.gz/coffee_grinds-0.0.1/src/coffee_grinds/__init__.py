"""Sample doc string."""

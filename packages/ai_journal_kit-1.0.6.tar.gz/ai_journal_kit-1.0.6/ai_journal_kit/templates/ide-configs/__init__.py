"""IDE configuration templates."""


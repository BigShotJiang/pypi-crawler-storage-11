# Macroeconomy  _0.1.2_

A macroeconomic analysis package followed the philosophy and methods of the New Classical Macro Theory.

### Model Introduction

New Classical Economy

This basic macroeconomic model is adapted from a dynamically multiple Ramsey Model, which could be extended into many occasions.
It follows the philosophy and methods of the New Classical Macro Theory where macroeconomic model must have micro-foundation,
and thus basic assumptions in the theory, for instance, Say's Law, Inda Conditions and CRS, are accepted here.
For the perspective of production, the model adopts the traditional choice: Cobb Douglas Production Function,
while Logarithmic form is chosen as the utility function.
In order to simplify calculation, labor is normalized into 1, and TFP(A) is assumed as a const 1.
All variables below are counted by consumer goods, reflecting the real economy.
Therefore, monetary factors are neglected in this very brief model.
As a result of the New Classical Macro Assumptions, this model has it structural limitation,
which means it is absolutely a terrible idea to apply this model to analyze an economy with Insufficient Aggregate Demand, such as China's.

China's Economy

Aimed to describe a realer economy with Insufficient Consumption, or Excess Savings in otherwise,
such as China's economy since the visionary policy Reform and Opening-up was implemented in 1978，
this adapted new classical model assumes that theta precents of firms in the economy are state-owned,
which means their operational target is to maximize their scales, and they are rigid savers,
observing China's reality.

### User Guide
Call the classes directly is quite a practical method, for instance,

`from macroenonmy.base import *`

`state = NewClassicalEconomy(1.0, 0.0085, 0.6, 20)`

`state = ChinaEconomy(1.0, 0.01, 0.4, 0.6, 20)`

Detailed introduction of every class is available in their own code areas, and a brief example is available in the `if __name__=='__main__'` part at the end of some main files.

### Download

Here is my website:
* https://github.com/JerrySkywolf

This package could be downloaded through PyPi by:

`pip install macroeconomy`

View at the webpage
* https://pypi.org/project/macroeconomy
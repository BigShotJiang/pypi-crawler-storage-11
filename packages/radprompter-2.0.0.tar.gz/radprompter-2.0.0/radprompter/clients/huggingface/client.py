from ..client import Client
import os
try:
    from transformers import StoppingCriteria, StoppingCriteriaList, set_seed # type: ignore
    import torch # type: ignore
    os.environ['HAS_TRANSFORMERS'] = str(True)
except ImportError:
    from abc import ABC
    StoppingCriteria = ABC
    os.environ['HAS_TRANSFORMERS'] = str(False)

class StopStringCriteria(StoppingCriteria):
    def __init__(self, stop_string, tokenizer):
        self.stop_string = stop_string
        self.tokenizer = tokenizer
        self.stop_ids = tokenizer.encode(stop_string, add_special_tokens=False)

    def __call__(self, input_ids, scores, **kwargs):
        # Check if the last generated tokens match the stop string tokens
        if input_ids.shape[1] < len(self.stop_ids):
            return torch.zeros(input_ids.shape[0], dtype=torch.bool, device=input_ids.device)

        for stop_id in self.stop_ids:
            if stop_id not in input_ids[0, -len(self.stop_ids):]:
                return torch.zeros(input_ids.shape[0], dtype=torch.bool, device=input_ids.device)
        
        return torch.ones(input_ids.shape[0], dtype=torch.bool, device=input_ids.device)

class HuggingFaceClient(Client):
    def __init__(self, hf_model, hf_tokenizer, **kwargs):
        if os.environ['HAS_TRANSFORMERS'] != "True":
            raise ImportError("HuggingFaceClient requires the `transformers` package to be installed.")

        model_name = hf_model.__class__.__name__
        self.hf_tokenizer = hf_tokenizer
        self.hf_model = hf_model
        self.temperature = kwargs.pop("temperature", 0.7)
        self.top_p = kwargs.pop("top_p", 0.9)
        self.seed = kwargs.pop("seed", None)
        self.frequency_penalty = kwargs.pop("frequency_penalty", 0.0)
        self.model_device = next(self.hf_model.parameters()).device

        self.provider = "huggingface"
        
        super().__init__(model_name)
        
    def chat_complete(self, messages, stop=None, max_tokens=None, response_format=None, **kwargs):
        if self.seed:
            set_seed(self.seed)
            
        if max_tokens is None:
            max_tokens = self.max_tokens

        if messages[-1]['role'] == "assistant":
            # Use continue_final_message=True to properly handle turn tokens
            tokenized_chat = self.hf_tokenizer.apply_chat_template(
                messages, 
                return_dict=True, 
                continue_final_message=True, 
                return_tensors="pt"
            )
        else:
            tokenized_chat = self.hf_tokenizer.apply_chat_template(
                messages, 
                return_dict=True, 
                add_generation_prompt=True, 
                return_tensors="pt"
            )

        tokenized_chat = {k: v.to(self.model_device) for k, v in tokenized_chat.items()}

        stopping_criteria_list = StoppingCriteriaList()
        if stop:
            stopping_criteria_list.append(StopStringCriteria(stop, self.hf_tokenizer))

        generation_kwargs = {
            "max_new_tokens": max_tokens,
            "num_return_sequences": 1,
            "stopping_criteria": stopping_criteria_list
        }
        
        if self.temperature == 0:
            generation_kwargs["do_sample"] = False
            generation_kwargs["temperature"] = None
            generation_kwargs["top_p"] = None
            generation_kwargs["top_k"] = None
        else:
            generation_kwargs["do_sample"] = True
            generation_kwargs["temperature"] = self.temperature
            generation_kwargs["top_p"] = self.top_p

        outputs = self.hf_model.generate(
            **tokenized_chat, 
            **generation_kwargs
        )

        prompt_size = tokenized_chat['input_ids'].size(-1)
        answer_tokens = outputs[0, prompt_size:]
        answer_text = self.hf_tokenizer.decode(answer_tokens, skip_special_tokens=True)

        return answer_text
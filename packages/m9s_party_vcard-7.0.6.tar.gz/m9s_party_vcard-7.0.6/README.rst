Party Vcard Module
##################

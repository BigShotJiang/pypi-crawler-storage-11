Party Vcard Modul
##################

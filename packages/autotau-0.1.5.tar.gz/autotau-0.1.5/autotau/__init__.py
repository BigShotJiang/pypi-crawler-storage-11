from .core import (
    TauFitter, 
    AutoTauFitter, 
    CyclesAutoTauFitter,
    ParallelAutoTauFitter,
    ParallelCyclesAutoTauFitter
)

__all__ = [
    'TauFitter',
    'AutoTauFitter',
    'CyclesAutoTauFitter',
    'ParallelAutoTauFitter',
    'ParallelCyclesAutoTauFitter'
]

__version__ = '0.1.5'

class MeltanoCommandError(Exception):
    pass

from setuptools import setup, find_packages
import io
import os

def read(fname):
    return io.open(os.path.join(os.path.dirname(__file__), fname), encoding="utf-8").read()

setup(
    name="scipyy",  # must be unique on PyPI
    version="0.1.2",
    author="Spoof",
    author_email="xyz@gmail.com",
    description="A Python library containing ADS practical codes and utilities.",
    long_description=read("README.md"),
    long_description_content_type="text/markdown",
    url="",  # optional
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    license="MIT",  # ✅ SPDX-compliant license declaration
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)

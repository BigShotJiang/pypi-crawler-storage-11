import subprocess
import os
from pathlib import Path

def run():
    """Run the Node.js Paytm API server"""
    server_js = Path(__file__).parent / "api.js"
    subprocess.Popen(["node", str(server_js)])
    print("✅ Paytm API server started at http://localhost:8080")

# Paytm API (Python Wrapper)

A Python package that Paytm transaction status API server.

## Installation

```bash
pip install paytm-api

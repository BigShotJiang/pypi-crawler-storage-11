#include "utility.hpp"
#include "build_mdd.hpp"
#include "load_inst.hpp"
#include <iostream>

namespace largehm {

using namespace std;

// storage for mined patterns (each pattern = vector<int>)
std::vector<std::vector<int>> collectedPatterns;

bool check_parent(unsigned long long int cur_anct,
                  unsigned long long int str_pnt,
                  unsigned long long int start,
                  vector<unsigned long long int>& strpnt_vec) {

    vector<unsigned long long int> ancestors;

    while (abs(Tree[cur_anct].itmset) > abs(Tree[str_pnt].itmset)) {
        if (Tree[cur_anct].item > 0)
            ancestors.push_back(cur_anct);
        cur_anct = Tree[cur_anct].anct;
    }

    if (abs(Tree[cur_anct].itmset) == abs(Tree[str_pnt].itmset))
        return 1;
    else {
        for (vector<unsigned long long int>::reverse_iterator it = ancestors.rbegin();
             it != ancestors.rend(); ++it) {
            for (unsigned int i = start; i < strpnt_vec.size(); ++i) {
                if (strpnt_vec[i] == *it)
                    return 1;
            }
        }
    }

    return 0;
}

float give_time(clock_t kk) {
    float ll = ((float)kk) / CLOCKS_PER_SEC;
    return ll;
}

// clear vector used to return patterns to Python
void ClearCollected() {
    collectedPatterns.clear();
}

// return reference so Python wrapper can build list[list[int]]
const std::vector<std::vector<int>>& GetCollected() {
    return collectedPatterns;
}

} // namespace largehm

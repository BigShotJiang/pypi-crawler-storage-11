# gmtorch

Probabilistic Generative AI Using Gaussian Mixture

import enum
from typing import Annotated, overload

from numpy.typing import NDArray

import _pyxpg.imgui


class Axis(enum.IntEnum):
    X1 = 0

    X2 = 1

    X3 = 2

    Y1 = 3

    Y2 = 4

    Y3 = 5

class PlotFlags(enum.IntFlag):
    NONE = 0

    NO_TITLE = 1

    NO_LEGEND = 2

    NO_MOUSE_TEXT = 4

    NO_INPUTS = 8

    NO_MENUS = 16

    NO_BOX_SELECT = 32

    NO_FRAME = 64

    EQUAL = 128

    CROSSHAIRS = 256

    CANVAS_ONLY = 55

class AxisFlags(enum.IntFlag):
    NONE = 0

    NO_LABEL = 1

    NO_GRID_LINES = 2

    NO_TICK_MARKS = 4

    NO_TICK_LABELS = 8

    NO_INITIAL_FIT = 16

    NO_MENUS = 32

    NO_SIDE_SWITCH = 64

    NO_HIGHLIGHT = 128

    OPPOSITE = 256

    FOREGROUND = 512

    INVERT = 1024

    AUTO_FIT = 2048

    RANGE_FIT = 4096

    PAN_STRETCH = 8192

    LOCK_MIN = 16384

    LOCK_MAX = 32768

    LOCK = 49152

    NO_DECORATIONS = 15

    AUX_DEFAULT = 258

class SubplotFlags(enum.IntFlag):
    NONE = 0

    NO_TITLE = 1

    NO_LEGEND = 2

    NO_MENUS = 4

    NO_RESIZE = 8

    NO_ALIGN = 16

    SHARE_ITEMS = 32

    LINK_ROWS = 64

    LINK_COLS = 128

    LINK_ALL_X = 256

    LINK_ALL_Y = 512

    COL_MAJOR = 1024

class LegendFlags(enum.IntFlag):
    NONE = 0

    NO_BUTTONS = 1

    NO_HIGHLIGHT_ITEM = 2

    NO_HIGHLIGHT_AXIS = 4

    NO_MENUS = 8

    OUTSIDE = 16

    HORIZONTAL = 32

    SORT = 64

class MouseTextFlags(enum.IntFlag):
    NONE = 0

    NO_AUX_AXES = 1

    NO_FORMAT = 2

    SHOW_ALWAYS = 4

class DragToolFlags(enum.IntFlag):
    NONE = 0

    NO_CURSORS = 1

    NO_FIT = 2

    NO_INPUTS = 4

    DELAYED = 8

class ColormapScaleFlags(enum.IntFlag):
    NONE = 0

    NO_LABEL = 1

    OPPOSITE = 2

    INVERT = 4

class ItemFlags(enum.IntFlag):
    NONE = 0

    NO_LEGEND = 1

    NO_FIT = 2

class LineFlags(enum.IntFlag):
    NONE = 0

    SEGMENTS = 1024

    LOOP = 2048

    SKIP_NA_N = 4096

    NO_CLIP = 8192

    SHADED = 16384

class ScatterFlags(enum.IntFlag):
    NONE = 0

    NO_CLIP = 1024

class StairsFlags(enum.IntFlag):
    NONE = 0

    PRE_STEP = 1024

    SHADED = 2048

class ShadedFlags(enum.IntFlag):
    NONE = 0

class BarsFlags(enum.IntFlag):
    NONE = 0

    HORIZONTAL = 1024

class BarGroupsFlags(enum.IntFlag):
    NONE = 0

    HORIZONTAL = 1024

    STACKED = 2048

class ErrorBarsFlags(enum.IntFlag):
    NONE = 0

    HORIZONTAL = 1024

class StemsFlags(enum.IntFlag):
    NONE = 0

    HORIZONTAL = 1024

class InfLinesFlags(enum.IntFlag):
    NONE = 0

    HORIZONTAL = 1024

class PieChartFlags(enum.IntFlag):
    NONE = 0

    NORMALIZE = 1024

    IGNORE_HIDDEN = 2048

    EXPLODING = 4096

class HeatmapFlags(enum.IntFlag):
    NONE = 0

    COL_MAJOR = 1024

class HistogramFlags(enum.IntFlag):
    NONE = 0

    HORIZONTAL = 1024

    CUMULATIVE = 2048

    DENSITY = 4096

    NO_OUTLIERS = 8192

    COL_MAJOR = 16384

class DigitalFlags(enum.IntFlag):
    NONE = 0

class ImageFlags(enum.IntFlag):
    NONE = 0

class TextFlags(enum.IntFlag):
    NONE = 0

    VERTICAL = 1024

class DummyFlags(enum.IntFlag):
    NONE = 0

class Cond(enum.IntEnum):
    NONE = 0

    ALWAYS = 1

    ONCE = 2

class Color(enum.IntEnum):
    LINE = 0

    FILL = 1

    MARKER_OUTLINE = 2

    MARKER_FILL = 3

    ERROR_BAR = 4

    FRAME_BG = 5

    PLOT_BG = 6

    PLOT_BORDER = 7

    LEGEND_BG = 8

    LEGEND_BORDER = 9

    LEGEND_TEXT = 10

    TITLE_TEXT = 11

    INLAY_TEXT = 12

    AXIS_TEXT = 13

    AXIS_GRID = 14

    AXIS_TICK = 15

    AXIS_BG = 16

    AXIS_BG_HOVERED = 17

    AXIS_BG_ACTIVE = 18

    SELECTION = 19

    CROSSHAIRS = 20

class StyleVar(enum.IntEnum):
    LINE_WEIGHT = 0

    MARKER = 1

    MARKER_SIZE = 2

    MARKER_WEIGHT = 3

    FILL_ALPHA = 4

    ERROR_BAR_SIZE = 5

    ERROR_BAR_WEIGHT = 6

    DIGITAL_BIT_HEIGHT = 7

    DIGITAL_BIT_GAP = 8

    PLOT_BORDER_SIZE = 9

    MINOR_ALPHA = 10

    MAJOR_TICK_LEN = 11

    MINOR_TICK_LEN = 12

    MAJOR_TICK_SIZE = 13

    MINOR_TICK_SIZE = 14

    MAJOR_GRID_SIZE = 15

    MINOR_GRID_SIZE = 16

    PLOT_PADDING = 17

    LABEL_PADDING = 18

    LEGEND_PADDING = 19

    LEGEND_INNER_PADDING = 20

    LEGEND_SPACING = 21

    MOUSE_POS_PADDING = 22

    ANNOTATION_PADDING = 23

    FIT_PADDING = 24

    PLOT_DEFAULT_SIZE = 25

    PLOT_MIN_SIZE = 26

class Scale(enum.IntEnum):
    LINEAR = 0

    TIME = 1

    LOG10 = 2

    SYM_LOG = 3

class Marker(enum.IntEnum):
    NONE = -1

    CIRCLE = 0

    SQUARE = 1

    DIAMOND = 2

    UP = 3

    DOWN = 4

    LEFT = 5

    RIGHT = 6

    CROSS = 7

    PLUS = 8

    ASTERISK = 9

class Colormap(enum.IntEnum):
    DEEP = 0

    DARK = 1

    PASTEL = 2

    PAIRED = 3

    VIRIDIS = 4

    PLASMA = 5

    HOT = 6

    COOL = 7

    PINK = 8

    JET = 9

    TWILIGHT = 10

    RD_BU = 11

    BR_B_G = 12

    PI_Y_G = 13

    SPECTRAL = 14

    GREYS = 15

class Location(enum.IntEnum):
    CENTER = 0

    NORTH = 1

    SOUTH = 2

    WEST = 4

    EAST = 8

    NORTH_WEST = 5

    NORTH_EAST = 9

    SOUTH_WEST = 6

    SOUTH_EAST = 10

class Bin(enum.IntEnum):
    SQRT = -1

    STURGES = -2

    RICE = -3

    SCOTT = -4

class Style:
    @property
    def line_weight(self) -> float: ...

    @line_weight.setter
    def line_weight(self, arg: float, /) -> None: ...

    @property
    def marker(self) -> int: ...

    @marker.setter
    def marker(self, arg: int, /) -> None: ...

    @property
    def marker_size(self) -> float: ...

    @marker_size.setter
    def marker_size(self, arg: float, /) -> None: ...

    @property
    def marker_weight(self) -> float: ...

    @marker_weight.setter
    def marker_weight(self, arg: float, /) -> None: ...

    @property
    def fill_alpha(self) -> float: ...

    @fill_alpha.setter
    def fill_alpha(self, arg: float, /) -> None: ...

    @property
    def error_bar_size(self) -> float: ...

    @error_bar_size.setter
    def error_bar_size(self, arg: float, /) -> None: ...

    @property
    def error_bar_weight(self) -> float: ...

    @error_bar_weight.setter
    def error_bar_weight(self, arg: float, /) -> None: ...

    @property
    def digital_bit_height(self) -> float: ...

    @digital_bit_height.setter
    def digital_bit_height(self, arg: float, /) -> None: ...

    @property
    def digital_bit_gap(self) -> float: ...

    @digital_bit_gap.setter
    def digital_bit_gap(self, arg: float, /) -> None: ...

    @property
    def plot_border_size(self) -> float: ...

    @plot_border_size.setter
    def plot_border_size(self, arg: float, /) -> None: ...

    @property
    def minor_alpha(self) -> float: ...

    @minor_alpha.setter
    def minor_alpha(self, arg: float, /) -> None: ...

    @property
    def major_tick_len(self) -> _pyxpg.imgui.Vec2: ...

    @major_tick_len.setter
    def major_tick_len(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def minor_tick_len(self) -> _pyxpg.imgui.Vec2: ...

    @minor_tick_len.setter
    def minor_tick_len(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def major_tick_size(self) -> _pyxpg.imgui.Vec2: ...

    @major_tick_size.setter
    def major_tick_size(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def minor_tick_size(self) -> _pyxpg.imgui.Vec2: ...

    @minor_tick_size.setter
    def minor_tick_size(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def major_grid_size(self) -> _pyxpg.imgui.Vec2: ...

    @major_grid_size.setter
    def major_grid_size(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def minor_grid_size(self) -> _pyxpg.imgui.Vec2: ...

    @minor_grid_size.setter
    def minor_grid_size(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def plot_padding(self) -> _pyxpg.imgui.Vec2: ...

    @plot_padding.setter
    def plot_padding(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def label_padding(self) -> _pyxpg.imgui.Vec2: ...

    @label_padding.setter
    def label_padding(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def legend_padding(self) -> _pyxpg.imgui.Vec2: ...

    @legend_padding.setter
    def legend_padding(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def legend_inner_padding(self) -> _pyxpg.imgui.Vec2: ...

    @legend_inner_padding.setter
    def legend_inner_padding(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def legend_spacing(self) -> _pyxpg.imgui.Vec2: ...

    @legend_spacing.setter
    def legend_spacing(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def mouse_pos_padding(self) -> _pyxpg.imgui.Vec2: ...

    @mouse_pos_padding.setter
    def mouse_pos_padding(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def annotation_padding(self) -> _pyxpg.imgui.Vec2: ...

    @annotation_padding.setter
    def annotation_padding(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def fit_padding(self) -> _pyxpg.imgui.Vec2: ...

    @fit_padding.setter
    def fit_padding(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def plot_default_size(self) -> _pyxpg.imgui.Vec2: ...

    @plot_default_size.setter
    def plot_default_size(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def plot_min_size(self) -> _pyxpg.imgui.Vec2: ...

    @plot_min_size.setter
    def plot_min_size(self, arg: _pyxpg.imgui.Vec2, /) -> None: ...

    @property
    def color_line(self) -> _pyxpg.imgui.Vec4: ...

    @color_line.setter
    def color_line(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_fill(self) -> _pyxpg.imgui.Vec4: ...

    @color_fill.setter
    def color_fill(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_marker_outline(self) -> _pyxpg.imgui.Vec4: ...

    @color_marker_outline.setter
    def color_marker_outline(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_marker_fill(self) -> _pyxpg.imgui.Vec4: ...

    @color_marker_fill.setter
    def color_marker_fill(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_error_bar(self) -> _pyxpg.imgui.Vec4: ...

    @color_error_bar.setter
    def color_error_bar(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_frame_bg(self) -> _pyxpg.imgui.Vec4: ...

    @color_frame_bg.setter
    def color_frame_bg(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_plot_bg(self) -> _pyxpg.imgui.Vec4: ...

    @color_plot_bg.setter
    def color_plot_bg(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_plot_border(self) -> _pyxpg.imgui.Vec4: ...

    @color_plot_border.setter
    def color_plot_border(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_legend_bg(self) -> _pyxpg.imgui.Vec4: ...

    @color_legend_bg.setter
    def color_legend_bg(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_legend_border(self) -> _pyxpg.imgui.Vec4: ...

    @color_legend_border.setter
    def color_legend_border(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_legend_text(self) -> _pyxpg.imgui.Vec4: ...

    @color_legend_text.setter
    def color_legend_text(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_title_text(self) -> _pyxpg.imgui.Vec4: ...

    @color_title_text.setter
    def color_title_text(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_inlay_text(self) -> _pyxpg.imgui.Vec4: ...

    @color_inlay_text.setter
    def color_inlay_text(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_axis_text(self) -> _pyxpg.imgui.Vec4: ...

    @color_axis_text.setter
    def color_axis_text(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_axis_grid(self) -> _pyxpg.imgui.Vec4: ...

    @color_axis_grid.setter
    def color_axis_grid(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_axis_tick(self) -> _pyxpg.imgui.Vec4: ...

    @color_axis_tick.setter
    def color_axis_tick(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_axis_bg(self) -> _pyxpg.imgui.Vec4: ...

    @color_axis_bg.setter
    def color_axis_bg(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_axis_bg_hovered(self) -> _pyxpg.imgui.Vec4: ...

    @color_axis_bg_hovered.setter
    def color_axis_bg_hovered(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_axis_bg_active(self) -> _pyxpg.imgui.Vec4: ...

    @color_axis_bg_active.setter
    def color_axis_bg_active(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_selection(self) -> _pyxpg.imgui.Vec4: ...

    @color_selection.setter
    def color_selection(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def color_crosshairs(self) -> _pyxpg.imgui.Vec4: ...

    @color_crosshairs.setter
    def color_crosshairs(self, arg: _pyxpg.imgui.Vec4, /) -> None: ...

    @property
    def colormap(self) -> int: ...

    @colormap.setter
    def colormap(self, arg: int, /) -> None: ...

    @property
    def use_local_time(self) -> bool: ...

    @use_local_time.setter
    def use_local_time(self, arg: bool, /) -> None: ...

    @property
    def use_i_s_o8601(self) -> bool: ...

    @use_i_s_o8601.setter
    def use_i_s_o8601(self, arg: bool, /) -> None: ...

    @property
    def use24_hour_clock(self) -> bool: ...

    @use24_hour_clock.setter
    def use24_hour_clock(self, arg: bool, /) -> None: ...

class InputMap:
    @property
    def pan(self) -> int: ...

    @pan.setter
    def pan(self, arg: int, /) -> None: ...

    @property
    def pan_mod(self) -> int: ...

    @pan_mod.setter
    def pan_mod(self, arg: int, /) -> None: ...

    @property
    def fit(self) -> int: ...

    @fit.setter
    def fit(self, arg: int, /) -> None: ...

    @property
    def select(self) -> int: ...

    @select.setter
    def select(self, arg: int, /) -> None: ...

    @property
    def select_cancel(self) -> int: ...

    @select_cancel.setter
    def select_cancel(self, arg: int, /) -> None: ...

    @property
    def select_mod(self) -> int: ...

    @select_mod.setter
    def select_mod(self, arg: int, /) -> None: ...

    @property
    def select_horz_mod(self) -> int: ...

    @select_horz_mod.setter
    def select_horz_mod(self, arg: int, /) -> None: ...

    @property
    def select_vert_mod(self) -> int: ...

    @select_vert_mod.setter
    def select_vert_mod(self, arg: int, /) -> None: ...

    @property
    def menu(self) -> int: ...

    @menu.setter
    def menu(self, arg: int, /) -> None: ...

    @property
    def override_mod(self) -> int: ...

    @override_mod.setter
    def override_mod(self, arg: int, /) -> None: ...

    @property
    def zoom_mod(self) -> int: ...

    @zoom_mod.setter
    def zoom_mod(self, arg: int, /) -> None: ...

    @property
    def zoom_rate(self) -> float: ...

    @zoom_rate.setter
    def zoom_rate(self, arg: float, /) -> None: ...

def begin_plot(title_id: str, size: _pyxpg.imgui.Vec2 = (-1, 0), flags: PlotFlags = 0) -> bool: ...

def end_plot() -> None: ...

def begin_subplots(title_id: str, rows: int, cols: int, size: _pyxpg.imgui.Vec2, flags: SubplotFlags = 0) -> bool: ...

def end_subplots() -> None: ...

def setup_axis(axis: Axis, label: str | None = None, flags: AxisFlags = 0) -> None: ...

def setup_axis_limits(axis: Axis, v_min: float, v_max: float, cond: Cond = Cond.ONCE) -> None: ...

def setup_axis_format(axis: Axis, fmt: str) -> None: ...

def setup_axis_scale(axis: Axis, scale: Scale) -> None: ...

def setup_axis_limits_constraints(axis: Axis, v_min: float, v_max: float) -> None: ...

def setup_axis_zoom_constraints(axis: Axis, z_min: float, z_max: float) -> None: ...

def setup_axes(x_label: str, y_label: str, x_flags: AxisFlags = 0, y_flags: AxisFlags = 0) -> None: ...

def setup_axes_limits(x_min: float, x_max: float, y_min: float, y_max: float, cond: Cond = Cond.ONCE) -> None: ...

def setup_legend(location: Location, flags: LegendFlags = 0) -> None: ...

def setup_mouse_text(location: Location, flags: MouseTextFlags = 0) -> None: ...

def setup_finish() -> None: ...

def set_next_axis_limits(axis: Axis, v_min: float, v_max: float, cond: Cond = Cond.ONCE) -> None: ...

def set_next_axis_to_fit(axis: Axis) -> None: ...

def set_next_axes_limits(x_min: float, x_max: float, y_min: float, y_max: float, cond: Cond = Cond.ONCE) -> None: ...

def set_next_axes_to_fit() -> None: ...

def plot_text(text: str, x: float, y: float, pix_offset: _pyxpg.imgui.Vec2 = (0, 0), flags: TextFlags = 0) -> None: ...

def plot_dummy(label_id: str, flags: DummyFlags = 0) -> None: ...

def annotation(x: float, y: float, col: _pyxpg.imgui.Vec4, pix_offset: _pyxpg.imgui.Vec2, clamp: bool, round: bool = False) -> None: ...

def annotation_str(x: float, y: float, col: _pyxpg.imgui.Vec4, pix_offset: _pyxpg.imgui.Vec2, clamp: bool, fmt: str) -> None: ...

def tag_x(x: float, col: _pyxpg.imgui.Vec4, round: bool = False) -> None: ...

def tag_x_str(x: float, col: _pyxpg.imgui.Vec4, fmt: str) -> None: ...

def tag_y(y: float, col: _pyxpg.imgui.Vec4, round: bool = False) -> None: ...

def tag_y_str(y: float, col: _pyxpg.imgui.Vec4, fmt: str) -> None: ...

def set_axis(axis: Axis) -> None: ...

def set_axes(x_axis: Axis, y_axis: Axis) -> None: ...

def pixels_to_plot(pix: _pyxpg.imgui.Vec2, x_axis: Axis = -1, y_axis: Axis = -1) -> "ImPlotPoint": ...

def pixels_to_plot_float(x: float, y: float, x_axis: Axis = -1, y_axis: Axis = -1) -> "ImPlotPoint": ...

def plot_to_pixels(plt: "ImPlotPoint", x_axis: Axis = -1, y_axis: Axis = -1) -> _pyxpg.imgui.Vec2: ...

def plot_to_pixels_double(x: float, y: float, x_axis: Axis = -1, y_axis: Axis = -1) -> _pyxpg.imgui.Vec2: ...

def get_plot_pos() -> _pyxpg.imgui.Vec2: ...

def get_plot_size() -> _pyxpg.imgui.Vec2: ...

def get_plot_mouse_pos(x_axis: Axis = -1, y_axis: Axis = -1) -> "ImPlotPoint": ...

def get_plot_limits(x_axis: Axis = -1, y_axis: Axis = -1) -> "ImPlotRect": ...

def is_plot_hovered() -> bool: ...

def is_axis_hovered(axis: Axis) -> bool: ...

def is_subplots_hovered() -> bool: ...

def is_plot_selected() -> bool: ...

def get_plot_selection(x_axis: Axis = -1, y_axis: Axis = -1) -> "ImPlotRect": ...

def cancel_plot_selection() -> None: ...

def hide_next_item(hidden: bool = True, cond: Cond = Cond.ONCE) -> None: ...

def begin_aligned_plots(group_id: str, vertical: bool = True) -> bool: ...

def end_aligned_plots() -> None: ...

def begin_legend_popup(label_id: str, mouse_button: int = 1) -> bool: ...

def end_legend_popup() -> None: ...

def is_legend_entry_hovered(label_id: str) -> bool: ...

def begin_drag_drop_target_plot() -> bool: ...

def begin_drag_drop_target_axis(axis: Axis) -> bool: ...

def begin_drag_drop_target_legend() -> bool: ...

def end_drag_drop_target() -> None: ...

def begin_drag_drop_source_plot(flags: int = 0) -> bool: ...

def begin_drag_drop_source_axis(axis: Axis, flags: int = 0) -> bool: ...

def begin_drag_drop_source_item(label_id: str, flags: int = 0) -> bool: ...

def end_drag_drop_source() -> None: ...

def style_colors_auto() -> None: ...

def style_colors_classic() -> None: ...

def style_colors_dark() -> None: ...

def style_colors_light() -> None: ...

def push_style_color(idx: Color, col: int) -> None: ...

def push_style_color_im_vec4(idx: Color, col: _pyxpg.imgui.Vec4) -> None: ...

def pop_style_color(count: int = 1) -> None: ...

def push_style_var(idx: StyleVar, val: float) -> None: ...

def push_style_var_int(idx: StyleVar, val: int) -> None: ...

def push_style_var_im_vec2(idx: StyleVar, val: _pyxpg.imgui.Vec2) -> None: ...

def pop_style_var(count: int = 1) -> None: ...

def set_next_line_style(col: _pyxpg.imgui.Vec4 = ..., weight: float = -1) -> None: ...

def set_next_fill_style(col: _pyxpg.imgui.Vec4 = ..., alpha_mod: float = -1) -> None: ...

def set_next_marker_style(marker: Marker = -1, size: float = -1, fill: _pyxpg.imgui.Vec4 = ..., weight: float = -1, outline: _pyxpg.imgui.Vec4 = ...) -> None: ...

def set_next_error_bar_style(col: _pyxpg.imgui.Vec4 = ..., size: float = -1, weight: float = -1) -> None: ...

def get_last_item_color() -> _pyxpg.imgui.Vec4: ...

def get_style_color_name(idx: Color) -> str: ...

def get_marker_name(idx: Marker) -> str: ...

def add_colormap(name: str, cols: _pyxpg.imgui.Vec4, size: int, qual: bool = True) -> Colormap: ...

def get_colormap_count() -> int: ...

def get_colormap_name(cmap: Colormap) -> str: ...

def get_colormap_index(name: str) -> Colormap: ...

def push_colormap(cmap: Colormap) -> None: ...

def push_colormap_str(name: str) -> None: ...

def pop_colormap(count: int = 1) -> None: ...

def next_colormap_color() -> _pyxpg.imgui.Vec4: ...

def get_colormap_size(cmap: Colormap = -1) -> int: ...

def get_colormap_color(idx: int, cmap: Colormap = -1) -> _pyxpg.imgui.Vec4: ...

def sample_colormap(t: float, cmap: Colormap = -1) -> _pyxpg.imgui.Vec4: ...

def colormap_scale(label: str, scale_min: float, scale_max: float, size: _pyxpg.imgui.Vec2 = (0, 0), format: str = '%g', flags: ColormapScaleFlags = 0, cmap: Colormap = -1) -> None: ...

def colormap_button(label: str, size: _pyxpg.imgui.Vec2 = (0, 0), cmap: Colormap = -1) -> bool: ...

def bust_color_cache(plot_title_id: str | None = None) -> None: ...

def item_icon(col: _pyxpg.imgui.Vec4) -> None: ...

def item_icon_im_u32(col: int) -> None: ...

def colormap_icon(cmap: Colormap) -> None: ...

def get_plot_draw_list() -> _pyxpg.imgui.DrawList: ...

def push_plot_clip_rect(expand: float = 0) -> None: ...

def pop_plot_clip_rect() -> None: ...

def show_style_selector(label: str) -> bool: ...

def show_colormap_selector(label: str) -> bool: ...

def show_input_map_selector(label: str) -> bool: ...

def show_style_editor() -> None: ...

def show_user_guide() -> None: ...

def show_metrics_window(p_popen: bool | None = None) -> bool: ...

@overload
def plot_line(label_id: str, values: Annotated[NDArray, dict(order='A', device='cpu')], xscale: float = 1, xstart: float = 0, flags: int = 0) -> None: ...

@overload
def plot_line(label_id: str, xs: Annotated[NDArray, dict(order='A', device='cpu')], ys: Annotated[NDArray, dict(order='A', device='cpu')], flags: int = 0) -> None: ...

@overload
def plot_scatter(label_id: str, values: Annotated[NDArray, dict(order='A', device='cpu')], xscale: float = 1, xstart: float = 0, flags: int = 0) -> None: ...

@overload
def plot_scatter(label_id: str, xs: Annotated[NDArray, dict(order='A', device='cpu')], ys: Annotated[NDArray, dict(order='A', device='cpu')], flags: int = 0) -> None: ...

@overload
def plot_stairs(label_id: str, values: Annotated[NDArray, dict(order='A', device='cpu')], xscale: float = 1, xstart: float = 0, flags: int = 0) -> None: ...

@overload
def plot_stairs(label_id: str, xs: Annotated[NDArray, dict(order='A', device='cpu')], ys: Annotated[NDArray, dict(order='A', device='cpu')], flags: int = 0) -> None: ...

@overload
def plot_shaded(label_id: str, values: Annotated[NDArray, dict(order='A', device='cpu')], yref: float = 0, xscale: float = 1, xstart: float = 0, flags: int = 0) -> None: ...

@overload
def plot_shaded(label_id: str, xs: Annotated[NDArray, dict(order='A', device='cpu')], ys: Annotated[NDArray, dict(order='A', device='cpu')], flags: int = 0) -> None: ...

@overload
def plot_shaded(label_id: str, xs: Annotated[NDArray, dict(order='A', device='cpu')], ys1: Annotated[NDArray, dict(order='A', device='cpu')] = 1, ys2: Annotated[NDArray, dict(order='A', device='cpu')] = 1, flags: int = 0) -> None: ...

@overload
def plot_bars(label_id: str, values: Annotated[NDArray, dict(order='A', device='cpu')], bar_size: float = 0.67, shift: float = 0, flags: int = 0) -> None: ...

@overload
def plot_bars(label_id: str, xs: Annotated[NDArray, dict(order='A', device='cpu')], ys: Annotated[NDArray, dict(order='A', device='cpu')], bar_size: float = 0.67, flags: int = 0) -> None: ...

@overload
def plot_bars(label_id: str, values: Annotated[NDArray, dict(order='A', device='cpu')], bar_size: float = 0.67, shift: float = 0, flags: int = 0) -> None: ...

@overload
def plot_bars(label_id: str, xs: Annotated[NDArray, dict(order='A', device='cpu')], ys: Annotated[NDArray, dict(order='A', device='cpu')], bar_size: float = 0.67, flags: int = 0) -> None: ...

def plot_error_bars(label_id: str, xs: Annotated[NDArray, dict(order='A', device='cpu')], ys: Annotated[NDArray, dict(order='A', device='cpu')], err: Annotated[NDArray, dict(order='A', device='cpu')], flags: int = 0) -> None: ...

@overload
def plot_stems(label_id: str, values: Annotated[NDArray, dict(order='A', device='cpu')], ref: float = 0, scale: float = 1, start: float = 0, flags: int = 0) -> None: ...

@overload
def plot_stems(label_id: str, xs: Annotated[NDArray, dict(order='A', device='cpu')], ys: Annotated[NDArray, dict(order='A', device='cpu')], ref: float = 0, flags: int = 0) -> None: ...

def plot_inf_lines(label_id: str, values: Annotated[NDArray, dict(order='A', device='cpu')], flags: int = 0) -> None: ...

def plot_histogram(label_id: str, values: Annotated[NDArray, dict(order='A', device='cpu')], bins: int = Bin.STURGES, bar_scale: float = 1.0, range: tuple[float, float] = (0, 0), flags: int = 0) -> None: ...

def plot_digital(label_id: str, xs: Annotated[NDArray, dict(order='A', device='cpu')], ys: Annotated[NDArray, dict(order='A', device='cpu')], flags: int = 0) -> None: ...

# check_installation.py
import site
import os

print("🔍 Checking installation...")

# Check all package locations
for package_dir in site.getsitepackages():
    print(f"📁 Checking: {package_dir}")
    
    # Look for anything with 'kaiiddo'
    for item in os.listdir(package_dir):
        if 'kaiiddo' in item.lower():
            print(f"   Found: {item}")
            item_path = os.path.join(package_dir, item)
            if os.path.isdir(item_path):
                print(f"   📂 Directory contents: {os.listdir(item_path)}")
            else:
                print(f"   📄 File")
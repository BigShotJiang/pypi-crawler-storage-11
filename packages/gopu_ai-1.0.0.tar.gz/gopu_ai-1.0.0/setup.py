from setuptools import setup, find_packages

setup(
    name="gopu-ai",
    version="1.0.0",
    author="Ceoseshell",
    author_email="your-email@example.com",
    description="Système d'IA Gopu avec modèles personnalisés",
    long_description="Système d'IA similaire à Ollama avec des modèles personnalisés Gopu",
    long_description_content_type="text/plain",
    url="https://github.com/ceoseshell/gopu-ai",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "torch>=2.0.0",
        "transformers>=4.30.0",
        "fastapi>=0.100.0",
        "uvicorn>=0.23.0",
        "huggingface-hub>=0.16.0",
        "accelerate>=0.21.0",
        "sentencepiece>=0.1.99",
        "protobuf>=3.20.0",
        "numpy>=1.24.0",
        "requests>=2.28.0",
        "python-multipart>=0.0.6",
    ],
    entry_points={
        "console_scripts": [
            "gopu-ai=gopu_ai.cli:main",
        ],
    },
)

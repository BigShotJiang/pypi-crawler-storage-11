import torch
from transformers import pipeline
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn
from typing import Optional, Dict, Any
import threading

class GopuAI:
    def __init__(self):
        self.models_config = {
            "agent-ai": "Mauricio-100/agent-ai",
            "gopu-agent-2k-fdf": "Gopu-poss/gopu-agent-2k-fdf", 
            "unity-tinny-go": "Gopu-poss/unity-tinny-go",
            "gopu-unity-pro": "Gopu-poss/gopu-unity-pro",
            "unity-tinny-go-advanced": "Gopu-poss/unity-tinny-go-advanced",
            "unity-tinny-go-12b": "Gopu-poss/unity-tinny-go-12b"
        }
        self.pipelines = {}
        self.app = None
        self.server_thread = None
        
    def load_model(self, model_name: str) -> bool:
        if model_name not in self.models_config:
            raise ValueError(f"Modèle {model_name} non trouvé")
            
        model_id = self.models_config[model_name]
        
        try:
            print(f"Chargement du modèle: {model_name}...")
            
            pipe = pipeline(
                "text-generation",
                model=model_id,
                torch_dtype=torch.float16 if torch.cuda.is_available() else "auto",
                device_map="auto",
                trust_remote_code=True
            )
            
            self.pipelines[model_name] = pipe
            print(f"Modèle {model_name} chargé avec succès")
            return True
            
        except Exception as e:
            print(f"Erreur lors du chargement de {model_name}: {str(e)}")
            return False
    
    def chat(self, model: str, prompt: str, max_tokens: int = 512, temperature: float = 0.7) -> str:
        if model not in self.models_config:
            raise ValueError(f"Modèle {model} non trouvé")
        
        if model not in self.pipelines:
            success = self.load_model(model)
            if not success:
                raise RuntimeError(f"Impossible de charger le modèle {model}")
        
        try:
            pipeline = self.pipelines[model]
            result = pipeline(
                prompt,
                max_new_tokens=max_tokens,
                temperature=temperature,
                do_sample=True,
                pad_token_id=pipeline.tokenizer.eos_token_id
            )
            
            response_text = result[0]['generated_text']
            if response_text.startswith(prompt):
                response_text = response_text[len(prompt):].strip()
            
            return response_text
            
        except Exception as e:
            raise RuntimeError(f"Erreur de génération: {str(e)}")
    
    def start_server(self, host: str = "0.0.0.0", port: int = 8080):
        self.app = FastAPI(title="Gopu AI", version="1.0.0")
        
        class ChatRequest(BaseModel):
            model: str
            prompt: str
            max_tokens: Optional[int] = 512
            temperature: Optional[float] = 0.7
        
        @self.app.get("/")
        async def root():
            return {
                "message": "Gopu AI System", 
                "version": "1.0.0",
                "models_available": list(self.models_config.keys())
            }
        
        @self.app.get("/models")
        async def list_models():
            models_info = []
            for model_name in self.models_config.keys():
                models_info.append({
                    "name": model_name,
                    "status": "available",
                    "loaded": model_name in self.pipelines
                })
            return {"models": models_info}
        
        @self.app.post("/chat")
        async def chat_completion(request: ChatRequest):
            try:
                response = self.chat(
                    model=request.model,
                    prompt=request.prompt,
                    max_tokens=request.max_tokens,
                    temperature=request.temperature
                )
                return {
                    "response": response,
                    "model": request.model,
                    "tokens_used": len(response.split())
                }
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.post("/models/{model_name}/load")
        async def load_model_endpoint(model_name: str):
            success = self.load_model(model_name)
            if success:
                return {"status": "success", "message": f"Modèle {model_name} chargé"}
            else:
                raise HTTPException(status_code=500, detail="Erreur lors du chargement")
        
        @self.app.get("/health")
        async def health_check():
            return {"status": "healthy", "loaded_models": list(self.pipelines.keys())}
        
        def run_server():
            uvicorn.run(self.app, host=host, port=port)
        
        self.server_thread = threading.Thread(target=run_server, daemon=True)
        self.server_thread.start()
        print(f"Serveur Gopu AI démarré sur http://{host}:{port}")
    
    def stop_server(self):
        if self.server_thread:
            print("Arrêt du serveur Gopu AI")

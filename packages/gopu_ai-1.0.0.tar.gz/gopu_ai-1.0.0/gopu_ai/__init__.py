"""
Gopu AI - Système d'IA avec modèles personnalisés
"""

from gopu_ai.core import GopuAI
from gopu_ai.cli import main

__version__ = "1.0.0"
__author__ = "Ceoseshell"
__all__ = ["GopuAI", "main"]

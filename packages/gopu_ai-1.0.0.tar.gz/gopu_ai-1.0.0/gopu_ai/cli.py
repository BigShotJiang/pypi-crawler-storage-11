import argparse
import sys
from gopu_ai.core import GopuAI

def main():
    parser = argparse.ArgumentParser(description="Gopu AI CLI")
    subparsers = parser.add_subparsers(dest="command", help="Commandes disponibles")
    
    serve_parser = subparsers.add_parser("serve", help="Démarrer le serveur web")
    serve_parser.add_argument("--host", default="0.0.0.0", help="Adresse d'écoute")
    serve_parser.add_argument("--port", type=int, default=8080, help="Port d'écoute")
    
    chat_parser = subparsers.add_parser("chat", help="Chat en ligne de commande")
    chat_parser.add_argument("--model", required=True, help="Nom du modèle")
    chat_parser.add_argument("--prompt", required=True, help="Prompt")
    chat_parser.add_argument("--max-tokens", type=int, default=512, help="Tokens maximum")
    chat_parser.add_argument("--temperature", type=float, default=0.7, help="Température")
    
    args = parser.parse_args()
    
    if args.command == "serve":
        gopu = GopuAI()
        gopu.start_server(host=args.host, port=args.port)
        try:
            while True:
                input("Appuyez sur Entrée pour arrêter le serveur...")
                break
        except KeyboardInterrupt:
            print("Arrêt du serveur...")
    
    elif args.command == "chat":
        gopu = GopuAI()
        try:
            response = gopu.chat(
                model=args.model,
                prompt=args.prompt,
                max_tokens=args.max_tokens,
                temperature=args.temperature
            )
            print("Réponse:")
            print(response)
        except Exception as e:
            print(f"Erreur: {e}")
            sys.exit(1)
    
    else:
        parser.print_help()

if __name__ == "__main__":
    main()

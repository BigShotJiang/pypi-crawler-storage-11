class DirExists(Exception):
    pass


class DirNotExistsError(Exception):
    pass


class ToManyFiles(Exception):
    pass


class ASTError(Exception):
    pass


class OutOfRange(Exception):
    pass


class EmptyLib(Exception):
    pass


class NotADictionary(Exception):
    pass


class LoadError(Exception):
    pass


class MoveError(Exception):
    pass


class BuiltInPkg(Exception):
    pass


class NotAFile(Exception):
    pass


class SourceNotFoundError(Exception):
    pass


class PathExistsError(Exception):
    pass


class ModuleExistsError(Exception):
    pass


class PkgNotFoundError(Exception):
    pass


ImporterException = (
        DirExists,
        ToManyFiles,
        ASTError,
        OutOfRange,
        EmptyLib,
        NotADictionary,
        LoadError,
        MoveError,
        BuiltInPkg,
        DirNotExistsError,
        NotAFile,
        SourceNotFoundError,
        PathExistsError,
        ModuleExistsError,
        PkgNotFoundError,
)


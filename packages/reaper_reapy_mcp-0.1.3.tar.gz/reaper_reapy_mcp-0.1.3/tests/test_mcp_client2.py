import logging
import os
import sys

# Add the parent directory to sys.path to import the reaper_controller module
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.reaper_controller import ReaperController

def main():
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)

    try:
        # Create Reaper controller
        controller = ReaperController(debug=True)
        
        # Test basic operations
        logger.info("Testing basic operations...")
        
        # Create a track
        track_index = controller.create_track("Test Track")
        logger.info(f"Created track {track_index}")
        

        # Create a MIDI track
        midi_track_index = controller.create_track("MIDI Track")
        logger.info(f"Created MIDI track {midi_track_index}")
        
        # Create a MIDI item
        midi_item_id = controller.create_midi_item(midi_track_index, 0.0, 4.0)
        logger.info(f"Created MIDI item {midi_item_id}")
        
        # Add MIDI notes - C major chord
        controller.add_midi_note(midi_track_index, midi_item_id, 60, 0.0, 1.0, 100)  # C
        controller.add_midi_note(midi_track_index, midi_item_id, 64, 0.0, 1.0, 100)  # E
        controller.add_midi_note(midi_track_index, midi_item_id, 67, 0.0, 1.0, 100)  # G
        logger.info("Added MIDI notes (C major chord)")
        
        # Create another MIDI item and duplicate it
        midi_item2_id = controller.create_midi_item(midi_track_index, 4.0, 2.0)
        logger.info(f"Created second MIDI item {midi_item2_id}")
        
        # Add a MIDI note
        controller.add_midi_note(midi_track_index, midi_item2_id, 72, 0.0, 0.5, 90)  # C an octave up
        logger.info("Added MIDI note to second item")
        
        # Duplicate the MIDI item
        duplicated_item_id = controller.duplicate_item(midi_track_index, midi_item2_id)
        logger.info(f"Duplicated MIDI item, new ID: {duplicated_item_id}")


        # Get items in time range
        items = controller.get_items_in_time_range(midi_track_index, 0.0, 10.0)
        logger.info(f"Found {len(items)} items in time range 0-10 seconds on MIDI track")


        # create midi item in offset from start
        


        logger.info("All tests completed successfully!")
        
    except Exception as e:
        logger.error(f"Error during testing: {e}")
        raise

if __name__ == "__main__":
    main()
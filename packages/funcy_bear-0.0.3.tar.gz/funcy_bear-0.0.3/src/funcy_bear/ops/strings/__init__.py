"""Various string operations."""

# """Console script for chap_core."""
#
# import dataclasses
# import json
# from pathlib import Path
# from typing import Literal, Optional
#
# import numpy as np
# import pandas as pd
# import yaml
# from cyclopts import App
#
# from chap_core.assessment.dataset_splitting import train_test_generator
# from chap_core.climate_predictor import QuickForecastFetcher
# from chap_core.database.model_templates_and_config_tables import ModelConfiguration
# from chap_core.datatypes import FullData
# from chap_core.exceptions import NoPredictionsError
# from chap_core.models.model_template import ModelTemplate
# from chap_core.models.utils import (
#     get_model_from_directory_or_github_url,
#     get_model_template_from_directory_or_github_url,
# )
# from chap_core.geometry import Polygons
# from chap_core.log_config import initialize_logging
# from chap_core.predictor.model_registry import registry
#
# from chap_core.rest_api_src.worker_functions import samples_to_evaluation_response, dataset_to_datalist
# from chap_core.spatio_temporal_data.multi_country_dataset import (
#     MultiCountryDataSet,
# )
# from chap_core.spatio_temporal_data.temporal_dataclass import DataSet
# from chap_core import api
# from chap_core.plotting.prediction_plot import plot_forecast_from_summaries
# from chap_core.predictor import ModelType
# from chap_core.file_io.example_data_set import datasets, DataSetType
# from chap_core.time_period.date_util_wrapper import delta_month
# from chap_core.assessment.prediction_evaluator import evaluate_model, backtest as _backtest
# from chap_core.assessment.forecast import multi_forecast as do_multi_forecast
#
# from .hpoModel import Tuner, Direction
# from .objective import Objective
# from .searcher import GridSearch
#
# import logging
#
# logger = logging.getLogger()
# logger.setLevel(logging.INFO)
#
# app = App()
#
#
# def append_to_csv(file_object, data_frame: pd.DataFrame):
#     data_frame.to_csv(file_object, mode="a", header=False)
#
#
# @app.command()
# def run(
#     model_name: ModelType | str,
#     dataset_name: Optional[DataSetType] = None,
#     dataset_country: Optional[str] = None,
#     dataset_csv: Optional[Path] = None,
#     polygons_json: Optional[Path] = None,
#     polygons_id_field: Optional[str] = "id",
#     prediction_length: int = 3, # 6,
#     n_splits: int = 7,
#     report_filename: Optional[str] = "report.pdf",
#     ignore_environment: bool = False,
#     debug: bool = False,
#     log_file: Optional[str] = None,
#     run_directory_type: Optional[Literal["latest", "timestamp", "use_existing"]] = "timestamp",
#     model_configuration_yaml: Optional[str] = None,
#     optimize_metric: str = "MSE",
#     direction: Direction = "minimize"
# ):
#     initialize_logging(debug, log_file)
#     if dataset_name is None:
#         assert dataset_csv is not None, "Must specify a dataset name or a dataset csv file"
#         logging.info(f"Loading dataset from {dataset_csv}")
#         dataset = DataSet.from_csv(dataset_csv, FullData)
#         if polygons_json is not None:
#             logging.info(f"Loading polygons from {polygons_json}")
#             polygons = Polygons.from_file(polygons_json, id_property=polygons_id_field)
#             polygons.filter_locations(dataset.locations())
#             dataset.set_polygons(polygons.data)
#     else:
#         logger.info(f"Evaluating model {model_name} on dataset {dataset_name}")
#
#         dataset = datasets[dataset_name]
#         dataset = dataset.load()
#
#         if isinstance(dataset, MultiCountryDataSet):
#             assert dataset_country is not None, "Must specify a country for multi country datasets"
#             assert (
#                 dataset_country in dataset.countries
#             ), f"Country {dataset_country} not found in dataset. Countries: {dataset.countries}"
#             dataset = dataset[dataset_country]
#
#     if "," in model_name:
#         # model_name is not only one model, but contains a list of models
#         model_list = model_name.split(",")
#         model_configuration_yaml_list = [None for _ in model_list]
#         if model_configuration_yaml is not None:
#             model_configuration_yaml_list = model_configuration_yaml.split(",")
#             assert len(model_list) == len(
#                 model_configuration_yaml_list
#             ), "Number of model configurations does not match number of models"
#     else:
#         model_list = [model_name]
#         model_configuration_yaml_list = [model_configuration_yaml]
#
#     logging.info(f"Model configuration: {model_configuration_yaml_list}")
#
#     results_dict = {}
#     # think all models can reuse the splits
#     train_data, test_generator = train_test_generator(
#         dataset,
#         prediction_length=prediction_length,
#         n_test_sets=n_splits,
#     )
#     for model_name, config_yaml in zip(model_list, model_configuration_yaml_list):
#         # metrics = []
#         # for train, test in splits, nested CV:
#         tuner = Tuner(GridSearch(), direction=direction)
#         objective = Objective(model_name, train_data, optimize_metric, prediction_length, n_splits)
#         model_name, params = tuner.optimize(model_name, train_data, objective, model_configuration_yaml=config_yaml)
#
#         template = ModelTemplate.from_directory_or_github_url(
#             model_name,
#             base_working_dir=Path("./runs/"),
#             ignore_env=ignore_environment,
#             run_dir_type=run_directory_type,
#         )
#         logging.info(f"Model template loaded: {template}")
#
#         logger.info("Validating model configuration")
#         model_config = ModelConfiguration.model_validate(params)
#         logger.info("Validated model configuration")
#
#         model = template.get_model(model_config)
#         model = model()
#         try:
#             results = evaluate_model(
#                 model,
#                 train_data, # need to change method declaration
#                 test_generator, # -- || --
#                 report_filename=report_filename,
#             )
#         except NoPredictionsError as e:
#             logger.error(f"No predictions were made: {e}")
#             return
#         results_dict[model_name] = results
#             # metrics.append(results[0][optimize_metric])
#         # mean = np.mena(metrics)
#
#     # need to iterate through the dict, like key and value or something and then extract the relevant metrics
#     # to a pandas dataframe, and save it as a csv file.
#     # it seems like results contain two dictionairies, one for aggregate metrics and one with seperate ones for each ts
#
#     data = []
#     first_model = True
#     for key, value in results_dict.items():
#         aggregate_metric_dist = value[0]
#         row = [key]
#         for k, v in aggregate_metric_dist.items():
#             row.append(v)
#         if first_model:
#             data.append(["Model"] + list(aggregate_metric_dist.keys()))
#             first_model = False
#         data.append(row)
#     dataframe = pd.DataFrame(data)
#     csvname = Path(report_filename).with_suffix(".csv")
#
#     # write dataframe to csvname
#     dataframe.to_csv(csvname, index=False, header=False)
#     logger.info(f"Evaluation complete. Results saved to {csvname}")
#
#     return results_dict
#
#
# @app.command()
# def sanity_check_model(
#     model_url: str, use_local_environement: bool = False, dataset_path=None, model_config_path: str = None
# ):
#     """
#     Check that a model can be loaded, trained and used to make predictions
#     """
#     if dataset_path is None:
#         dataset = datasets["hydromet_5_filtered"].load()
#     else:
#         dataset = DataSet.from_csv(dataset_path, FullData)
#     train, tests = train_test_generator(dataset, 3, n_test_sets=2)
#     context, future, truth = next(tests)
#     logger.info("Dataset: ")
#     logger.info(dataset.to_pandas())
#
#     if model_config_path is not None:
#         model_config = ModelConfiguration.model_validate(yaml.safe_load(open(model_config_path)))
#     else:
#         model_config = None
#     try:
#         model_template = get_model_template_from_directory_or_github_url(model_url, ignore_env=use_local_environement)
#         model = model_template.get_model(
#             model_config
#         )  # get_model_from_directory_or_github_url(model_url, ignore_env=use_local_environement)
#         estimator = model()
#     except Exception as e:
#         logger.error(f"Error while creating model: {e}")
#         raise e
#     try:
#         predictor = estimator.train(train)
#     except Exception as e:
#         logger.error(f"Error while training model: {e}")
#         raise e
#     try:
#         predictions = predictor.predict(context, future)
#     except Exception as e:
#         logger.error(f"Error while forecasting: {e}")
#         raise e
#     for location, prediction in predictions.items():
#         assert not np.isnan(
#             prediction.samples
#         ).any(), f"NaNs in predictions for location {location}, {prediction.samples}"
#     context, future, truth = next(tests)
#     try:
#         predictions = predictor.predict(context, future)
#     except Exception as e:
#         logger.error(f"Error while forecasting from a future time point: {e}")
#         raise e
#     for location, prediction in predictions.items():
#         assert not np.isnan(
#             prediction.samples
#         ).any(), f"NaNs in futuresplit predictions for location {location}, {prediction.samples}"
#
#
# @app.command()
# def forecast(
#     model_name: str,
#     dataset_name: DataSetType,
#     n_months: int,
#     model_path: Optional[str] = None,
#     out_path: Optional[str] = Path("./"),
# ):
#     """
#     Forecast n_months ahead using the given model and dataset
#
#     Parameters:
#         model_name: Name of the model to use, set to external to use an external model and specify the external model with model_path
#         dataset_name: Name of the dataset to use, e.g. hydromet_5_filtered
#         n_months: int: Number of months to forecast ahead
#         model_path: Optional[str]: Path to the model if model_name is external. Can ge a github repo url starting with https://github.com and ending with .git or a path to a local directory.
#         out_path: Optional[str]: Path to save the output file, default is the current directory
#     """
#
#     out_file = Path(out_path) / f"{model_name}_{dataset_name}_forecast_results_{n_months}.html"
#     f = open(out_file, "w")
#     figs = api.forecast(model_name, dataset_name, n_months, model_path)
#     for fig in figs:
#         f.write(fig.to_html())
#     f.close()
#
#
# @app.command()
# def multi_forecast(
#     model_name: str,
#     dataset_name: DataSetType,
#     n_months: int,
#     pre_train_months: int,
#     out_path: Path = Path(""),
# ):
#     model = get_model_from_directory_or_github_url(model_name)
#     model_name = model.name
#
#     model = model()
#     filename = out_path / f"{model_name}_{dataset_name}_multi_forecast_results_{n_months}.html"
#     logger.info(f"Saving to {filename}")
#     f = open(filename, "w")
#     dataset = datasets[dataset_name].load()
#     predictions_list = list(
#         do_multi_forecast(
#             model,
#             dataset,
#             n_months * delta_month,
#             pre_train_delta=pre_train_months * delta_month,
#         )
#     )
#
#     for location, true_data in dataset.items():
#         local_predictions = [pred.get_location(location).data() for pred in predictions_list]
#         fig = plot_forecast_from_summaries(local_predictions, true_data.data())
#         f.write(fig.to_html())
#     f.close()
#
#
# @app.command()
# def serve(seedfile: Optional[str] = None, debug: bool = False, auto_reload: bool = False):
#     """
#     Start CHAP as a backend server
#     """
#     from .rest_api_src.v1.rest_api import main_backend
#
#     logger.info("Running chap serve")
#     if seedfile is not None:
#         data = json.load(open(seedfile))
#     else:
#         data = None
#     main_backend(data, auto_reload=auto_reload)
#
#
# @app.command()
# def write_open_api_spec(out_path: str):
#     """
#     Write the OpenAPI spec to a file
#     """
#     from chap_core.rest_api_src.v1.rest_api import get_openapi_schema
#
#     schema = get_openapi_schema()
#     with open(out_path, "w") as f:
#         json.dump(schema, f, indent=4)
#
#
# def base_args(func, *args, **kwargs):
#     """
#     Decorator that adds some base arguments to a command
#     """
#     base_args = [("debug", bool, False), ("log_file", Optional[str], None)]
#
#     def new_func(*args, **kwargs):
#         for arg_name, arg_type, default in base_args:
#             if arg_name not in kwargs:
#                 kwargs[arg_name] = default
#         return func(*args, **kwargs)
#
#
# @app.command()
# def test(**base_kwargs):
#     """
#     Simple test-command to check that the chap command works
#     """
#     initialize_logging()
#
#     logger.debug("Debug message")
#     logger.info("Info message")
#
#
# @dataclasses.dataclass
# class AreaPolygons: ...
#
#
# @app.command()
# def backtest(
#     data_filename: Path,
#     model_name: registry.model_type | str,
#     out_folder: Path,
#     prediction_length: int = 12,
#     n_test_sets: int = 20,
#     stride: int = 2,
# ):
#     """
#     Run a backtest on a dataset using the specified model
#
#     Parameters:
#         data_filename: Path: Path to the data file
#         model_name: str: Name of the model to use
#         out_folder: Path: Path to the output folder
#     """
#     dataset = DataSet.from_csv(data_filename, FullData)
#     logger.info(f"Running backtest on {data_filename} with model {model_name}")
#     logger.info(f"Dataset period range: {dataset.period_range}, locations: {list(dataset.locations())}")
#
#     if "/" in model_name:
#         estimator = get_model_from_directory_or_github_url(model_name)
#         model_name = "development_model"
#     else:
#         estimator = registry.get_model(model_name)
#     predictions_list = _backtest(
#         estimator,
#         dataset,
#         prediction_length=prediction_length,
#         n_test_sets=n_test_sets,
#         stride=stride,
#         weather_provider=QuickForecastFetcher,
#     )
#     response = samples_to_evaluation_response(
#         predictions_list, quantiles=[0.05, 0.25, 0.5, 0.75, 0.95], real_data=dataset_to_datalist(dataset, "dengue")
#     )
#     dataframe = pd.DataFrame([entry.model_dump() for entry in response.predictions])
#     data_name = data_filename.stem
#     dataframe.to_csv(out_folder / f"{data_name}_evaluation_{model_name}.csv")
#     serialized_response = response.json()
#     out_filename = out_folder / f"{data_name}_evaluation_response_{model_name}.json"
#
#     with open(out_filename, "w") as out_file:
#         out_file.write(serialized_response)
#
#
# def main_function():
#     """
#     This function should just be type hinted with common types,
#     and it will run as a command line function
#     Simple function<
#
#     >>> main()
#
#     """
#     return
#
#
# def main():
#     app()
#
#
# if __name__ == "__main__":
#     app()
#
#
#
#
# # even order version below
# """Console script for chap_core."""
#
# import dataclasses
# from pathlib import Path
# from typing import Literal, Optional
#
# import pandas as pd
# from cyclopts import App
#
# from typing import Any, Tuple
# import itertools
#
# from chap_core.predictor.model_registry import registry
#
# from chap_core.predictor import ModelType
# from chap_core.file_io.example_data_set import DataSetType
#
# import logging
#
# logger = logging.getLogger()
# logger.setLevel(logging.INFO)
#
# app = App()
#
#
# def append_to_csv(file_object, data_frame: pd.DataFrame):
#     data_frame.to_csv(file_object, mode="a", header=False)
#
#
# def _dedup(values):
#     """Deduplicate while preserving order; works for scalars, lists, dicts, None."""
#     seen = set()
#     out = []
#     for v in values if isinstance(values, list) else [values]:
#         try:
#             key = json.dumps(v, sort_keys=True, separators=(",", ":"), default=str)
#         except Exception:
#             key = repr(v)
#         if key not in seen:
#             seen.add(key)
#             out.append(v)
#     return out
#
#
# def _write_yaml(path: str, data: dict) -> None:
#     with open(path, "w", encoding="utf-8") as f:
#         yaml.safe_dump(data, f, sort_keys=False)
#
#
# @app.command()
# def hpo(
#     model_name: ModelType | str,
#     dataset_name: Optional[DataSetType] = None,
#     dataset_country: Optional[str] = None,
#     dataset_csv: Optional[Path] = None,
#     polygons_json: Optional[Path] = None,
#     polygons_id_field: Optional[str] = "id",
#     prediction_length: int = 6,
#     n_splits: int = 7,
#     report_filename: Optional[str] = "report.pdf",
#     ignore_environment: bool = False,
#     debug: bool = False,
#     log_file: Optional[str] = None,
#     run_directory_type: Optional[Literal["latest", "timestamp", "use_existing"]] = "timestamp",
#     model_configuration_yaml: Optional[str] = None,
#     output_config_yaml: Optional[str] = "output_config.yaml",
#     optimize_metric: str = "MSE",
#     lower_is_better: bool = True
# ) -> Tuple[float, dict[str, Any]]:
#     """
#     Iterate over all hyperparameter combinations from a grid-style YAML and, for each
#     combo, write a single-value YAML to `output_config_yaml` and call `evaluate`.
#
#     Returns (best_score, best_params) and leaves `output_config_yaml` written with the best config.
#
#     The grid YAML must have:
#       user_option_values:
#         param_a: [v1, v2, ...]
#         param_b: [w1, w2, ...]
#       # any other top-level keys are preserved
#     """
#     with open(model_configuration_yaml, "r", encoding="utf-8") as f:
#         base_cfg = yaml.safe_load(f) or {}
#
#     if "user_option_values" not in base_cfg or not isinstance(base_cfg["user_option_values"], dict):
#         raise ValueError("Expected top-level key 'user_option_values' mapping to a dict of lists.")
#
#     keys = list(base_cfg["user_option_values"].keys())
#     values_lists = []
#     for k in keys:
#         vals = _dedup(base_cfg["user_option_values"][k])
#         if not vals:
#             raise ValueError(f"'user_option_values.{k}' has no values to try.")
#         values_lists.append(vals)
#
#     best_score = float("inf") if lower_is_better else float("-inf")
#     best_cfg = None
#     best_params: dict[str, Any] = {}
#
#     base_cfg.pop("user_option_values")
#
#     for combo in itertools.product(*values_lists):
#         params = dict(zip(keys, combo))
#         cfg = base_cfg.copy()
#         cfg["user_option_values"] = params
#
#         _write_yaml(output_config_yaml, cfg)
#
#         results_dict = evaluate(model_name, dataset_name, prediction_length=3, model_configuration_yaml=output_config_yaml)
#         score = results_dict[model_name][0][optimize_metric]
#
#         is_better = (score < best_score) if lower_is_better else (score > best_score)
#         if is_better or best_cfg is None:
#             best_score = score
#             best_cfg = cfg
#             best_params = params
#
#         print(f"Tried {params} -> score={score}")
#
#     if best_cfg is not None:
#         _write_yaml(output_config_yaml, best_cfg)
#         print(f"\nBest params: {best_params} | best score: {best_score}")
#     else:
#         print("No combinations evaluated.")
#
#     return best_score, best_params
#
#
# @app.command()
# def evaluate(
#     model_name: ModelType | str,
#     dataset_name: Optional[DataSetType] = None,
#     dataset_country: Optional[str] = None,
#     dataset_csv: Optional[Path] = None,
#     polygons_json: Optional[Path] = None,
#     polygons_id_field: Optional[str] = "id",
#     prediction_length: int = 6,
#     n_splits: int = 7,
#     report_filename: Optional[str] = "report.pdf",
#     ignore_environment: bool = False,
#     debug: bool = False,
#     log_file: Optional[str] = None,
#     run_directory_type: Optional[Literal["latest", "timestamp", "use_existing"]] = "timestamp",
#     model_configuration_yaml: Optional[str] = None,
# ):
#     """
#     Evaluate a model's predictive performance using time series cross-validation.
#
#     This command performs systematic evaluation of a model by training on historical data
#     and testing predictions on held-out future periods. It generates comprehensive metrics
#     and visualizations to assess model accuracy and reliability.
#
#     Parameters
#     ----------
#     model_name : str
#         Model identifier. Can be:
#         - Built-in model name (e.g., 'naive_model')
#         - Local directory path to external model
#         - GitHub URL (e.g., 'https://github.com/user/model@commit')
#         - Comma-separated list for comparing multiple models
#     dataset_name : str, optional
#         Name of built-in dataset (e.g., 'ISIMIP_dengue_harmonized', 'hydromet_5_filtered')
#         Use --dataset-csv if providing custom data
#     dataset_country : str, optional
#         Country to filter from multi-country datasets (e.g., 'vietnam', 'laos')
#     dataset_csv : Path, optional
#         Path to custom CSV dataset with columns: location, time_period, disease_cases, etc.
#     polygons_json : Path, optional
#         Path to GeoJSON file with geographic boundaries for locations
#     polygons_id_field : str, default 'id'
#         Field name in polygons JSON to match with dataset locations
#     prediction_length : int, default 6
#         Number of time periods to forecast ahead (e.g., 6 months)
#     n_splits : int, default 7
#         Number of train/test splits for cross-validation
#         More splits = more robust evaluation but longer runtime
#     report_filename : str, default 'report.pdf'
#         Output PDF file with evaluation plots and metrics
#         Also generates CSV with same name containing numerical results
#     ignore_environment : bool, default False
#         Skip environment validation for external models (for development)
#     debug : bool, default False
#         Enable debug logging for troubleshooting
#     log_file : str, optional
#         Path to log file (logs to console if not specified)
#     run_directory_type : {'latest', 'timestamp', 'use_existing'}, default 'timestamp'
#         How to handle model execution directory:
#         - 'timestamp': Create new timestamped directory
#         - 'latest': Overwrite existing directory
#         - 'use_existing': Use existing directory if available
#     model_configuration_yaml : str, optional
#         Path to YAML file with model-specific configuration parameters
#         For multiple models, provide comma-separated list of config files
#
#     Examples
#     --------
#     Basic evaluation:
#         chap evaluate --model-name naive_model --dataset-name hydromet_5_filtered
#
#     Multi-country dataset:
#         chap evaluate --model-name naive_model --dataset-name ISIMIP_dengue_harmonized --dataset-country vietnam
#
#     External model from GitHub:
#         chap evaluate --model-name https://github.com/user/dengue-model@main --dataset-name hydromet_5_filtered
#
#     Custom dataset with polygons:
#         chap evaluate --model-name naive_model --dataset-csv ./data.csv --polygons-json ./boundaries.geojson
#
#     Compare multiple models:
#         chap evaluate --model-name model1,model2,model3 --dataset-name hydromet_5_filtered
#
#     With custom configuration:
#         chap evaluate --model-name external_model --dataset-name hydromet_5_filtered --model-configuration-yaml config.yaml
#
#     Notes
#     -----
#     - Evaluation uses time series cross-validation to avoid data leakage
#     - Results include metrics like MAE, RMSE, CRPS, and coverage probabilities
#     - PDF report contains forecast plots for visual inspection
#     - CSV output contains detailed numerical results for further analysis
#     """
#
#     initialize_logging(debug, log_file)
#     if dataset_name is None:
#         assert dataset_csv is not None, "Must specify a dataset name or a dataset csv file"
#         logging.info(f"Loading dataset from {dataset_csv}")
#         dataset = DataSet.from_csv(dataset_csv, FullData)
#         if polygons_json is not None:
#             logging.info(f"Loading polygons from {polygons_json}")
#             polygons = Polygons.from_file(polygons_json, id_property=polygons_id_field)
#             polygons.filter_locations(dataset.locations())
#             dataset.set_polygons(polygons.data)
#     else:
#         logger.info(f"Evaluating model {model_name} on dataset {dataset_name}")
#
#         dataset = datasets[dataset_name]
#         dataset = dataset.load()
#
#         if isinstance(dataset, MultiCountryDataSet):
#             assert dataset_country is not None, "Must specify a country for multi country datasets"
#             assert (
#                 dataset_country in dataset.countries
#             ), f"Country {dataset_country} not found in dataset. Countries: {dataset.countries}"
#             dataset = dataset[dataset_country]
#
#     if "," in model_name:
#         # model_name is not only one model, but contains a list of models
#         model_list = model_name.split(",")
#         model_configuration_yaml_list = [None for _ in model_list]
#         if model_configuration_yaml is not None:
#             model_configuration_yaml_list = model_configuration_yaml.split(",")
#             assert len(model_list) == len(
#                 model_configuration_yaml_list
#             ), "Number of model configurations does not match number of models"
#     else:
#         model_list = [model_name]
#         model_configuration_yaml_list = [model_configuration_yaml]
#
#     logging.info(f"Model configuration: {model_configuration_yaml_list}")
#
#     results_dict = {}
#     for name, configuration in zip(model_list, model_configuration_yaml_list):
#         template = ModelTemplate.from_directory_or_github_url(
#             name,
#             base_working_dir=Path("./runs/"),
#             ignore_env=ignore_environment,
#             run_dir_type=run_directory_type,
#         )
#         logging.info(f"Model template loaded: {template}")
#         if configuration is not None:
#             logger.info(f"Loading model configuration from yaml file {configuration}")
#             configuration = ModelConfiguration.model_validate(
#                 yaml.safe_load(open(configuration))
#             )  # template.get_model_configuration_from_yaml(Path(configuration))
#             logger.info(f"Loaded model configuration from yaml file: {configuration}")
#
#         model = template.get_model(configuration)
#         model = model()
#         try:
#             results = evaluate_model(
#                 model,
#                 dataset,
#                 prediction_length=prediction_length,
#                 n_test_sets=n_splits,
#                 report_filename=report_filename,
#             )
#         except NoPredictionsError as e:
#             logger.error(f"No predictions were made: {e}")
#             return
#         print("!!RESULTS:")
#         print(results)
#         results_dict[name] = results
#
#     # need to iterate through the dict, like key and value or something and then extract the relevant metrics
#     # to a pandas dataframe, and save it as a csv file.
#     # it seems like results contain two dictionairies, one for aggregate metrics and one with seperate ones for each ts
#
#     data = []
#     first_model = True
#     for key, value in results_dict.items():
#         aggregate_metric_dist = value[0]
#         row = [key]
#         for k, v in aggregate_metric_dist.items():
#             row.append(v)
#         if first_model:
#             data.append(["Model"] + list(aggregate_metric_dist.keys()))
#             first_model = False
#         data.append(row)
#     dataframe = pd.DataFrame(data)
#     csvname = Path(report_filename).with_suffix(".csv")
#
#     # write dataframe to csvname
#     dataframe.to_csv(csvname, index=False, header=False)
#     logger.info(f"Evaluation complete. Results saved to {csvname}")
#
#     return results_dict
#
#
# @app.command()
# def sanity_check_model(
#     model_url: str, use_local_environement: bool = False, dataset_path=None, model_config_path: str = None
# ):
#     """
#     Check that a model can be loaded, trained and used to make predictions
#     """
#     if dataset_path is None:
#         dataset = datasets["hydromet_5_filtered"].load()
#     else:
#         dataset = DataSet.from_csv(dataset_path, FullData)
#     train, tests = train_test_generator(dataset, 3, n_test_sets=2)
#     context, future, truth = next(tests)
#     logger.info("Dataset: ")
#     logger.info(dataset.to_pandas())
#
#     if model_config_path is not None:
#         model_config = ModelConfiguration.model_validate(yaml.safe_load(open(model_config_path)))
#     else:
#         model_config = None
#     try:
#         model_template = get_model_template_from_directory_or_github_url(model_url, ignore_env=use_local_environement)
#         model = model_template.get_model(
#             model_config
#         )  # get_model_from_directory_or_github_url(model_url, ignore_env=use_local_environement)
#         estimator = model()
#     except Exception as e:
#         logger.error(f"Error while creating model: {e}")
#         raise e
#     try:
#         predictor = estimator.train(train)
#     except Exception as e:
#         logger.error(f"Error while training model: {e}")
#         raise e
#     try:
#         predictions = predictor.predict(context, future)
#     except Exception as e:
#         logger.error(f"Error while forecasting: {e}")
#         raise e
#     for location, prediction in predictions.items():
#         assert not np.isnan(
#             prediction.samples
#         ).any(), f"NaNs in predictions for location {location}, {prediction.samples}"
#     context, future, truth = next(tests)
#     try:
#         predictions = predictor.predict(context, future)
#     except Exception as e:
#         logger.error(f"Error while forecasting from a future time point: {e}")
#         raise e
#     for location, prediction in predictions.items():
#         assert not np.isnan(
#             prediction.samples
#         ).any(), f"NaNs in futuresplit predictions for location {location}, {prediction.samples}"
#
#
# @app.command()
# def forecast(
#     model_name: str,
#     dataset_name: DataSetType,
#     n_months: int,
#     model_path: Optional[str] = None,
#     out_path: Optional[str] = Path("./"),
# ):
#     """
#     Forecast n_months ahead using the given model and dataset
#
#     Parameters:
#         model_name: Name of the model to use, set to external to use an external model and specify the external model with model_path
#         dataset_name: Name of the dataset to use, e.g. hydromet_5_filtered
#         n_months: int: Number of months to forecast ahead
#         model_path: Optional[str]: Path to the model if model_name is external. Can ge a github repo url starting with https://github.com and ending with .git or a path to a local directory.
#         out_path: Optional[str]: Path to save the output file, default is the current directory
#     """
#
#     out_file = Path(out_path) / f"{model_name}_{dataset_name}_forecast_results_{n_months}.html"
#     f = open(out_file, "w")
#     figs = api.forecast(model_name, dataset_name, n_months, model_path)
#     for fig in figs:
#         f.write(fig.to_html())
#     f.close()
#
#
# @app.command()
# def multi_forecast(
#     model_name: str,
#     dataset_name: DataSetType,
#     n_months: int,
#     pre_train_months: int,
#     out_path: Path = Path(""),
# ):
#     model = get_model_from_directory_or_github_url(model_name)
#     model_name = model.name
#
#     model = model()
#     filename = out_path / f"{model_name}_{dataset_name}_multi_forecast_results_{n_months}.html"
#     logger.info(f"Saving to {filename}")
#     f = open(filename, "w")
#     dataset = datasets[dataset_name].load()
#     predictions_list = list(
#         do_multi_forecast(
#             model,
#             dataset,
#             n_months * delta_month,
#             pre_train_delta=pre_train_months * delta_month,
#         )
#     )
#
#     for location, true_data in dataset.items():
#         local_predictions = [pred.get_location(location).data() for pred in predictions_list]
#         fig = plot_forecast_from_summaries(local_predictions, true_data.data())
#         f.write(fig.to_html())
#     f.close()
#
#
# @app.command()
# def serve(seedfile: Optional[str] = None, debug: bool = False, auto_reload: bool = False):
#     """
#     Start CHAP as a backend server
#     """
#     from .rest_api_src.v1.rest_api import main_backend
#
#     logger.info("Running chap serve")
#     if seedfile is not None:
#         data = json.load(open(seedfile))
#     else:
#         data = None
#     main_backend(data, auto_reload=auto_reload)
#
#
# @app.command()
# def write_open_api_spec(out_path: str):
#     """
#     Write the OpenAPI spec to a file
#     """
#     from chap_core.rest_api_src.v1.rest_api import get_openapi_schema
#
#     schema = get_openapi_schema()
#     with open(out_path, "w") as f:
#         json.dump(schema, f, indent=4)
#
#
# def base_args(func, *args, **kwargs):
#     """
#     Decorator that adds some base arguments to a command
#     """
#     base_args = [("debug", bool, False), ("log_file", Optional[str], None)]
#
#     def new_func(*args, **kwargs):
#         for arg_name, arg_type, default in base_args:
#             if arg_name not in kwargs:
#                 kwargs[arg_name] = default
#         return func(*args, **kwargs)
#
#
# @app.command()
# def test(**base_kwargs):
#     """
#     Simple test-command to check that the chap command works
#     """
#     initialize_logging()
#
#     logger.debug("Debug message")
#     logger.info("Info message")
#
#
# @dataclasses.dataclass
# class AreaPolygons: ...
#
#
# @app.command()
# def backtest(
#     data_filename: Path,
#     model_name: registry.model_type | str,
#     out_folder: Path,
#     prediction_length: int = 12,
#     n_test_sets: int = 20,
#     stride: int = 2,
# ):
#     """
#     Run a backtest on a dataset using the specified model
#
#     Parameters:
#         data_filename: Path: Path to the data file
#         model_name: str: Name of the model to use
#         out_folder: Path: Path to the output folder
#     """
#     dataset = DataSet.from_csv(data_filename, FullData)
#     logger.info(f"Running backtest on {data_filename} with model {model_name}")
#     logger.info(f"Dataset period range: {dataset.period_range}, locations: {list(dataset.locations())}")
#
#     if "/" in model_name:
#         estimator = get_model_from_directory_or_github_url(model_name)
#         model_name = "development_model"
#     else:
#         estimator = registry.get_model(model_name)
#     predictions_list = _backtest(
#         estimator,
#         dataset,
#         prediction_length=prediction_length,
#         n_test_sets=n_test_sets,
#         stride=stride,
#         weather_provider=QuickForecastFetcher,
#     )
#     response = samples_to_evaluation_response(
#         predictions_list, quantiles=[0.05, 0.25, 0.5, 0.75, 0.95], real_data=dataset_to_datalist(dataset, "dengue")
#     )
#     dataframe = pd.DataFrame([entry.model_dump() for entry in response.predictions])
#     data_name = data_filename.stem
#     dataframe.to_csv(out_folder / f"{data_name}_evaluation_{model_name}.csv")
#     serialized_response = response.json()
#     out_filename = out_folder / f"{data_name}_evaluation_response_{model_name}.json"
#
#     with open(out_filename, "w") as out_file:
#         out_file.write(serialized_response)
#
#
# def main_function():
#     """
#     This function should just be type hinted with common types,
#     and it will run as a command line function
#     Simple function<
#
#     >>> main()
#
#     """
#     return
#
#
# def main():
#     app()
#
#
# if __name__ == "__main__":
#     app()

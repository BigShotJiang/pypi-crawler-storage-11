import asyncio
from typing import List, Dict
from dotenv import load_dotenv

from browser_use import Agent, Browser, ChatOpenAI

from ace import (
    LiteLLMClient,
    Generator,
    Reflector,
    Curator,
    OnlineAdapter,
    Sample,
    TaskEnvironment,
)
load_dotenv()

def print_history_details(history):
    """Print all history information in a nice formatted way."""
    print("\n" + "=" * 80)
    print("📊 BROWSER HISTORY DETAILS")
    print("=" * 80)
    
    # Access useful information
    print("\n🔗 VISITED URLS:")
    print("-" * 80)
    try:
        urls = history.urls() if hasattr(history, "urls") else []
        if urls:
            for i, url in enumerate(urls, 1):
                print(f"  {i}. {url}")
        else:
            print("  (no URLs)")
    except Exception as e:
        print(f"  Error: {e}")
    
    print("\n📸 SCREENSHOT PATHS:")
    print("-" * 80)
    try:
        screenshot_paths = history.screenshot_paths() if hasattr(history, "screenshot_paths") else []
        if screenshot_paths:
            for i, path in enumerate(screenshot_paths, 1):
                print(f"  {i}. {path}")
        else:
            print("  (no screenshots)")
    except Exception as e:
        print(f"  Error: {e}")
    
    print("\n🖼️  SCREENSHOTS (Base64):")
    print("-" * 80)
    try:
        screenshots = history.screenshots() if hasattr(history, "screenshots") else []
        if screenshots:
            for i, screenshot in enumerate(screenshots, 1):
                preview = screenshot[:50] + "..." if len(screenshot) > 50 else screenshot
                print(f"  {i}. {preview} ({len(screenshot)} chars)")
        else:
            print("  (no screenshots)")
    except Exception as e:
        print(f"  Error: {e}")
    
    print("\n⚙️  ACTION NAMES:")
    print("-" * 80)
    try:
        action_names = history.action_names() if hasattr(history, "action_names") else []
        if action_names:
            for i, name in enumerate(action_names, 1):
                print(f"  {i}. {name}")
        else:
            print("  (no actions)")
    except Exception as e:
        print(f"  Error: {e}")
    
    print("\n📝 EXTRACTED CONTENT:")
    print("-" * 80)
    try:
        extracted = history.extracted_content() if hasattr(history, "extracted_content") else []
        if extracted:
            for i, content in enumerate(extracted, 1):
                preview = str(content)[:100] + "..." if len(str(content)) > 100 else str(content)
                print(f"  {i}. {preview}")
        else:
            print("  (no extracted content)")
    except Exception as e:
        print(f"  Error: {e}")
    
    print("\n❌ ERRORS:")
    print("-" * 80)
    try:
        errors = history.errors() if hasattr(history, "errors") else []
        if errors:
            for i, error in enumerate(errors, 1):
                if error is not None:
                    print(f"  {i}. {error}")
                else:
                    print(f"  {i}. (no error)")
        else:
            print("  (no errors)")
    except Exception as e:
        print(f"  Error: {e}")
    
    print("\n🎯 MODEL ACTIONS:")
    print("-" * 80)
    try:
        model_actions = history.model_actions() if hasattr(history, "model_actions") else []
        if model_actions:
            for i, action in enumerate(model_actions, 1):
                action_str = str(action)[:150] + "..." if len(str(action)) > 150 else str(action)
                print(f"  {i}. {action_str}")
        else:
            print("  (no model actions)")
    except Exception as e:
        print(f"  Error: {e}")
    
    print("\n🤖 MODEL OUTPUTS:")
    print("-" * 80)
    try:
        model_outputs = history.model_outputs() if hasattr(history, "model_outputs") else []
        if model_outputs:
            for i, output in enumerate(model_outputs, 1):
                output_str = str(output)[:150] + "..." if len(str(output)) > 150 else str(output)
                print(f"  {i}. {output_str}")
        else:
            print("  (no model outputs)")
    except Exception as e:
        print(f"  Error: {e}")
    
    print("\n🔄 LAST ACTION:")
    print("-" * 80)
    try:
        last_action = history.last_action() if hasattr(history, "last_action") else None
        if last_action:
            print(f"  {last_action}")
        else:
            print("  (no last action)")
    except Exception as e:
        print(f"  Error: {e}")
    
    # Analysis methods
    print("\n📊 ANALYSIS RESULTS:")
    print("-" * 80)
    
    try:
        final_result = history.final_result() if hasattr(history, "final_result") else None
        print(f"  Final Result: {final_result}")
    except Exception as e:
        print(f"  Final Result Error: {e}")
    
    try:
        is_done = history.is_done() if hasattr(history, "is_done") else None
        print(f"  Is Done: {is_done}")
    except Exception as e:
        print(f"  Is Done Error: {e}")
    
    try:
        is_successful = history.is_successful() if hasattr(history, "is_successful") else None
        print(f"  Is Successful: {is_successful}")
    except Exception as e:
        print(f"  Is Successful Error: {e}")
    
    try:
        has_errors = history.has_errors() if hasattr(history, "has_errors") else None
        print(f"  Has Errors: {has_errors}")
    except Exception as e:
        print(f"  Has Errors Error: {e}")
    
    try:
        model_thoughts = history.model_thoughts() if hasattr(history, "model_thoughts") else []
        print(f"  Model Thoughts Count: {len(model_thoughts)}")
        if model_thoughts:
            for i, thought in enumerate(model_thoughts[:3], 1):  # Show first 3
                thought_str = str(thought)[:100] + "..." if len(str(thought)) > 100 else str(thought)
                print(f"    {i}. {thought_str}")
    except Exception as e:
        print(f"  Model Thoughts Error: {e}")
    
    try:
        action_results = history.action_results() if hasattr(history, "action_results") else []
        print(f"  Action Results Count: {len(action_results)}")
    except Exception as e:
        print(f"  Action Results Error: {e}")
    
    try:
        action_history = history.action_history() if hasattr(history, "action_history") else []
        print(f"  Action History Count: {len(action_history)}")
        if action_history:
            for i, action in enumerate(action_history[:3], 1):  # Show first 3
                action_str = str(action)[:100] + "..." if len(str(action)) > 100 else str(action)
                print(f"    {i}. {action_str}")
    except Exception as e:
        print(f"  Action History Error: {e}")
    
    try:
        num_steps = history.number_of_steps() if hasattr(history, "number_of_steps") else None
        print(f"  Number of Steps: {num_steps}")
    except Exception as e:
        print(f"  Number of Steps Error: {e}")
    
    try:
        duration = history.total_duration_seconds() if hasattr(history, "total_duration_seconds") else None
        print(f"  Total Duration: {duration} seconds" if duration is not None else "  Total Duration: N/A")
    except Exception as e:
        print(f"  Total Duration Error: {e}")

    try:
        structured_output = history.structured_output if hasattr(history, "structured_output") else None
        print("\n📋 STRUCTURED OUTPUT:")
        print("-" * 80)
        if structured_output is not None:
            output_str = str(structured_output)[:200] + "..." if len(str(structured_output)) > 200 else str(structured_output)
            print(f"  {output_str}")
        else:
            print("  (no structured output)")
    except Exception as e:
        print(f"  Structured Output Error: {e}")

    print("\n" + "=" * 80 + "\n")

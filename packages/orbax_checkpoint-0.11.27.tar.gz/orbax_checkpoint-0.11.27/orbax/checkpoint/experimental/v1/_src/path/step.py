# Copyright 2025 The Orbax Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Utilities for working with paths constructed from steps."""

from orbax.checkpoint._src.path import step as step_lib


NameFormat = step_lib.NameFormat
Metadata = step_lib.Metadata

standard_name_format = step_lib.standard_name_format
composite_name_format = step_lib.composite_name_format

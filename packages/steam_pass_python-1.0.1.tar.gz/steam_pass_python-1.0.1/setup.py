import setuptools
with open('README.md', 'r', encoding='utf-8') as fh:
	long_description = fh.read()

setuptools.setup(
	name='steam-pass-python',
	version='1.0.1',
	author='DedKlaus',
	author_email='rroman321@yandex.ru',
	description='Script changes Steam account password. It works only for accounts with Steam Guard',
	long_description=long_description,
	long_description_content_type='text/markdown',
	packages=['steam-pass-python'],
	include_package_data=True,
	classifiers=[
		"Programming Language :: Python :: 3",
		"License :: OSI Approved :: MIT License",
		"Operating System :: OS Independent",
	],
	python_requires='>=3.11',
)
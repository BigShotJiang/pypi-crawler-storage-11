#!/usr/bin/env python3
"""
Test Execution Node Discovery

Tests that the Digital Twin can discover tools from app.json files.
"""

import sys
from pathlib import Path
import asyncio

# Add be directory to path
sys.path.insert(0, str(Path(__file__).parent / 'be'))

from execution_node import ExecutionNode, AutonomyLevel

async def test_execution_node_discovery():
    """Test execution node app discovery"""
    print("\n🧪 Testing Execution Node Discovery...")
    
    # Path to apps directory
    apps_dir = Path(__file__).parent.parent
    
    # Create execution node (mock user)
    execution_node = ExecutionNode(
        apps_dir=apps_dir,
        user_id="test_user_123",
        jwt_token="mock_token",
        base_url="http://localhost:8000"
    )
    
    # Discover all capabilities
    print("\n🔍 Discovering capabilities...")
    discovery = await execution_node.discover_all()
    
    print(f"\n✅ Discovery complete!")
    print(f"   Apps discovered: {len(discovery['apps'])}")
    print(f"   Total tools: {discovery['total_tools']}")
    print(f"   Autonomous tools: {discovery['autonomous_tools']}")
    print(f"   Ask-first tools: {discovery['ask_tools']}")
    print(f"   Restricted tools: {discovery['restricted_tools']}")
    
    print("\n📦 Apps with tools:")
    for app in discovery['apps']:
        print(f"   • {app['name']}: {app['tool_count']} tools")
        for tool_name in app['tools']:
            tool = execution_node.tools[tool_name]
            print(f"     - {tool_name} ({tool.autonomy_level.value})")
    
    # Test tool lookup
    print("\n🔧 Testing tool lookup...")
    if 'get_current_weather' in execution_node.tools:
        weather_tool = execution_node.tools['get_current_weather']
        print(f"   Found: {weather_tool}")
        print(f"   Can use autonomously: {execution_node.can_use_autonomously('get_current_weather')}")
        print(f"   OpenAI function format:")
        print(f"   {weather_tool.to_openai_function()}")
    
    # Test capabilities summary
    print("\n📊 Capabilities summary:")
    summary = execution_node.get_capabilities_summary()
    print(f"   {summary}")
    
    return discovery['total_tools'] > 0

async def test_tool_metadata():
    """Test that tool metadata is correctly parsed"""
    print("\n🧪 Testing Tool Metadata Parsing...")
    
    apps_dir = Path(__file__).parent.parent
    execution_node = ExecutionNode(
        apps_dir=apps_dir,
        user_id="test_user",
        jwt_token="mock_token"
    )
    
    await execution_node.discover_all()
    
    # Check specific tools
    tests = [
        ("get_current_weather", AutonomyLevel.FULL, "none"),
        ("get_user_profile", AutonomyLevel.FULL, "none"),
        ("update_user_profile", AutonomyLevel.ASK, "write"),
        ("get_dashboard_stats", AutonomyLevel.FULL, "none"),
    ]
    
    all_passed = True
    for tool_name, expected_autonomy, expected_side_effects in tests:
        if tool_name in execution_node.tools:
            tool = execution_node.tools[tool_name]
            autonomy_ok = tool.autonomy_level == expected_autonomy
            side_effects_ok = tool.side_effects == expected_side_effects
            
            status = "✅" if (autonomy_ok and side_effects_ok) else "❌"
            print(f"   {status} {tool_name}:")
            print(f"      Autonomy: {tool.autonomy_level.value} (expected: {expected_autonomy.value})")
            print(f"      Side effects: {tool.side_effects} (expected: {expected_side_effects})")
            
            if not (autonomy_ok and side_effects_ok):
                all_passed = False
        else:
            print(f"   ⚠️  {tool_name} not found")
            all_passed = False
    
    return all_passed

async def main():
    """Run all tests"""
    print("=" * 60)
    print("🤖 Execution Node & Tool Discovery Tests")
    print("=" * 60)
    
    test1 = await test_execution_node_discovery()
    test2 = await test_tool_metadata()
    
    print("\n" + "=" * 60)
    print("📊 Test Summary")
    print("=" * 60)
    print(f"{'✅ PASS' if test1 else '❌ FAIL'}: Discovery")
    print(f"{'✅ PASS' if test2 else '❌ FAIL'}: Tool Metadata")
    
    all_passed = test1 and test2
    total = 2
    passed = sum([test1, test2])
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if all_passed:
        print("\n🎉 All tests passed! Execution Node is working!")
        print("\nNext steps:")
        print("1. Restart the server if running")
        print("2. Test with real JWT token")
        print("3. Move to Step 4: Chat Integration")
    else:
        print("\n⚠️  Some tests failed. Check the output above.")

if __name__ == "__main__":
    asyncio.run(main())

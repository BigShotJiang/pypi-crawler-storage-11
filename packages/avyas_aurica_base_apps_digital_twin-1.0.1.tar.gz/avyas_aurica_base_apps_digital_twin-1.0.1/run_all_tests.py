#!/usr/bin/env python3
"""
Run All Digital Twin Tests

Comprehensive test suite for the Digital Twin system.
"""

import asyncio
import sys
from pathlib import Path
import subprocess
import os

# Color codes
GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
BLUE = "\033[94m"
BOLD = "\033[1m"
RESET = "\033[0m"


def print_header(text):
    """Print a formatted header"""
    print(f"\n{BOLD}{BLUE}{'=' * 70}{RESET}")
    print(f"{BOLD}{BLUE}{text.center(70)}{RESET}")
    print(f"{BOLD}{BLUE}{'=' * 70}{RESET}\n")


def print_test_result(test_name, passed, details=""):
    """Print test result"""
    status = f"{GREEN}✅ PASSED{RESET}" if passed else f"{RED}❌ FAILED{RESET}"
    print(f"{status} - {test_name}")
    if details:
        print(f"        {details}")


async def check_server_running():
    """Check if the server is running"""
    print_header("PRE-FLIGHT CHECK: Server Status")
    
    try:
        import httpx
        async with httpx.AsyncClient(timeout=3.0) as client:
            response = await client.get("http://localhost:8000/health")
            if response.status_code == 200:
                print(f"{GREEN}✅ Server is running on http://localhost:8000{RESET}")
                return True
            else:
                print(f"{RED}❌ Server responded with status {response.status_code}{RESET}")
                return False
    except ImportError:
        print(f"{YELLOW}⚠️  httpx not installed - skipping server check{RESET}")
        return True
    except Exception as e:
        print(f"{RED}❌ Server is not running{RESET}")
        print(f"{YELLOW}   Please start the server:{RESET}")
        print(f"{YELLOW}   cd aurica-base-be && uv run python -m uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload{RESET}")
        return False


def run_test_file(test_file):
    """Run a test file and return success status"""
    print(f"\n{BOLD}Running: {test_file.name}{RESET}")
    print("-" * 70)
    
    try:
        result = subprocess.run(
            [sys.executable, str(test_file)],
            capture_output=False,
            text=True,
            cwd=test_file.parent
        )
        return result.returncode == 0
    except Exception as e:
        print(f"{RED}Error running {test_file.name}: {e}{RESET}")
        return False


async def main():
    """Run all tests"""
    print_header("DIGITAL TWIN TEST SUITE")
    
    print(f"{BOLD}Testing Environment:{RESET}")
    print(f"  Python: {sys.version.split()[0]}")
    print(f"  Working Directory: {Path.cwd()}")
    print(f"  Test Location: {Path(__file__).parent}")
    
    # Check if server is running
    server_running = await check_server_running()
    
    if not server_running:
        print(f"\n{YELLOW}⚠️  Some tests may fail without the server running{RESET}")
        response = input(f"\n{BOLD}Continue anyway? (y/N): {RESET}").strip().lower()
        if response != 'y':
            print(f"\n{YELLOW}Tests cancelled. Start the server and try again.{RESET}")
            return
    
    # Test files to run (in order)
    test_files = [
        Path(__file__).parent / "test_dt.py",
        Path(__file__).parent / "test_discovery.py",
        Path(__file__).parent / "test_security.py",
        Path(__file__).parent / "test_state.py",
    ]
    
    # Check if chat-app test exists
    chat_test = Path(__file__).parent.parent / "chat-app" / "test_dt_integration.py"
    if chat_test.exists():
        test_files.append(chat_test)
    
    results = {}
    
    print_header("RUNNING TESTS")
    
    for test_file in test_files:
        if test_file.exists():
            passed = run_test_file(test_file)
            results[test_file.name] = passed
        else:
            print(f"{YELLOW}⚠️  Test file not found: {test_file.name}{RESET}")
            results[test_file.name] = None
    
    # Summary
    print_header("TEST RESULTS SUMMARY")
    
    passed_count = sum(1 for v in results.values() if v is True)
    failed_count = sum(1 for v in results.values() if v is False)
    skipped_count = sum(1 for v in results.values() if v is None)
    total_count = len(results)
    
    for test_name, result in results.items():
        if result is True:
            status = f"{GREEN}✅ PASSED{RESET}"
        elif result is False:
            status = f"{RED}❌ FAILED{RESET}"
        else:
            status = f"{YELLOW}⏭️  SKIPPED{RESET}"
        print(f"{status} - {test_name}")
    
    print(f"\n{BOLD}Overall Results:{RESET}")
    print(f"  Total Tests: {total_count}")
    print(f"  {GREEN}Passed: {passed_count}{RESET}")
    print(f"  {RED}Failed: {failed_count}{RESET}")
    print(f"  {YELLOW}Skipped: {skipped_count}{RESET}")
    
    if failed_count == 0 and passed_count > 0:
        print(f"\n{GREEN}{BOLD}🎉 ALL TESTS PASSED! 🎉{RESET}")
        print(f"\n{BOLD}Next Steps:{RESET}")
        print(f"  1. Review the implementation plan for completion status")
        print(f"  2. Test the full end-to-end flow via chat interface")
        print(f"  3. Ready to publish! 🚀")
        return 0
    elif failed_count > 0:
        print(f"\n{RED}{BOLD}❌ SOME TESTS FAILED{RESET}")
        print(f"\nPlease review the failures above and fix before publishing.")
        return 1
    else:
        print(f"\n{YELLOW}{BOLD}⚠️  NO TESTS RAN{RESET}")
        return 2


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)

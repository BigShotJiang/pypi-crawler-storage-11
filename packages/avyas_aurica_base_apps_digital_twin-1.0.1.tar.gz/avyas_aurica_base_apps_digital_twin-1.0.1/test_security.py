"""
Test Security Features for Digital Twin

Tests autonomy control, rate limiting, and audit logging.
"""

import asyncio
import sys
from pathlib import Path

# Add digital-twin app to path
sys.path.insert(0, str(Path(__file__).parent))

from be.autonomy_controller import AutonomyController, validate_tool_parameters
from be.rate_limiter import DTRateLimiter
from be.audit_logger import DTAuditLogger


async def test_autonomy_controller():
    """Test autonomy controller"""
    print("\n" + "="*60)
    print("TEST 1: Autonomy Controller")
    print("="*60)
    
    controller = AutonomyController("test_user_123")
    
    # Test FULL autonomy
    can_exec, reason = await controller.can_execute("get_weather", "full", autonomous=True)
    assert can_exec, f"FULL autonomy should work: {reason}"
    print("✅ FULL autonomy tool - autonomous execution allowed")
    
    # Test ASK level without permission
    can_exec, reason = await controller.can_execute("send_email", "ask", autonomous=True)
    assert not can_exec, "ASK level should require confirmation"
    assert reason == "requires_user_confirmation", f"Wrong reason: {reason}"
    print("✅ ASK level tool - confirmation required")
    
    # Grant standing permission
    await controller.grant_standing_permission("send_email")
    can_exec, reason = await controller.can_execute("send_email", "ask", autonomous=True)
    assert can_exec, f"Should work with standing permission: {reason}"
    print("✅ ASK level tool - works with standing permission")
    
    # Test RESTRICTED
    can_exec, reason = await controller.can_execute("delete_all", "restricted", autonomous=True)
    assert not can_exec, "RESTRICTED should never be autonomous"
    print("✅ RESTRICTED tool - blocked for autonomous execution")
    
    # Test blocking a tool
    await controller.block_tool("get_weather")
    can_exec, reason = await controller.can_execute("get_weather", "full", autonomous=True)
    assert not can_exec, "Blocked tool should not execute"
    print("✅ Tool blocking works")
    
    # Unblock
    await controller.unblock_tool("get_weather")
    can_exec, reason = await controller.can_execute("get_weather", "full", autonomous=True)
    assert can_exec, "Unblocked tool should work"
    print("✅ Tool unblocking works")
    
    print("\n✅ All autonomy controller tests passed!")


def test_parameter_validation():
    """Test parameter validation"""
    print("\n" + "="*60)
    print("TEST 2: Parameter Validation")
    print("="*60)
    
    # Define a tool schema
    tool_def = {
        "parameters": {
            "type": "object",
            "properties": {
                "city": {
                    "type": "string",
                    "description": "City name"
                },
                "units": {
                    "type": "string",
                    "enum": ["celsius", "fahrenheit"]
                }
            },
            "required": ["city"]
        }
    }
    
    # Test valid parameters
    valid, msg = validate_tool_parameters(tool_def, {"city": "London", "units": "celsius"})
    assert valid, f"Should be valid: {msg}"
    print("✅ Valid parameters accepted")
    
    # Test missing required parameter
    valid, msg = validate_tool_parameters(tool_def, {"units": "celsius"})
    assert not valid, "Should reject missing required param"
    assert "city" in msg.lower(), f"Wrong error message: {msg}"
    print("✅ Missing required parameter rejected")
    
    # Test invalid enum value
    valid, msg = validate_tool_parameters(tool_def, {"city": "London", "units": "kelvin"})
    assert not valid, "Should reject invalid enum value"
    print("✅ Invalid enum value rejected")
    
    # Test wrong type
    valid, msg = validate_tool_parameters(tool_def, {"city": 123})
    assert not valid, "Should reject wrong type"
    assert "string" in msg.lower(), f"Wrong error message: {msg}"
    print("✅ Type mismatch rejected")
    
    print("\n✅ All parameter validation tests passed!")


def test_rate_limiter():
    """Test rate limiter"""
    print("\n" + "="*60)
    print("TEST 3: Rate Limiter")
    print("="*60)
    
    limiter = DTRateLimiter(
        max_actions_per_minute=5,
        max_actions_per_hour=10,
        max_tool_calls_per_minute=3
    )
    
    dt_id = "test_dt_456"
    
    # Test normal actions
    for i in range(5):
        can_act, msg = limiter.can_act(dt_id)
        assert can_act, f"Action {i+1} should be allowed: {msg}"
        limiter.record_action(dt_id)
    print("✅ Actions within limit allowed")
    
    # Test exceeding limit
    can_act, msg = limiter.can_act(dt_id)
    assert not can_act, "Should reject when limit exceeded"
    assert "Rate limit exceeded" in msg, f"Wrong message: {msg}"
    print("✅ Rate limit enforcement works")
    
    # Reset and test tool calls
    limiter.reset(dt_id)
    for i in range(3):
        can_call, msg = limiter.can_call_tool(dt_id, "test_tool")
        assert can_call, f"Tool call {i+1} should be allowed"
        limiter.record_tool_call(dt_id, "test_tool")
    print("✅ Tool calls within limit allowed")
    
    # Test tool call limit
    can_call, msg = limiter.can_call_tool(dt_id, "test_tool")
    assert not can_call, "Should reject tool call when limit exceeded"
    print("✅ Tool call rate limit enforcement works")
    
    # Test stats
    stats = limiter.get_stats(dt_id)
    assert stats["actions_last_minute"] == 3, f"Wrong action count: {stats}"
    assert stats["tool_calls_last_minute"] == 3, f"Wrong tool call count: {stats}"
    print("✅ Rate limit statistics correct")
    
    print("\n✅ All rate limiter tests passed!")


def test_audit_logger():
    """Test audit logger"""
    print("\n" + "="*60)
    print("TEST 4: Audit Logger")
    print("="*60)
    
    logger = DTAuditLogger("test_user_789")
    
    # Test successful action logging
    logger.log_dt_action(
        action_type="tool_execution",
        tool_name="get_weather",
        parameters={"city": "London"},
        result={"temperature": 15},
        autonomous=True,
        execution_time_ms=250.5
    )
    print("✅ Successful action logged")
    
    # Test failed action logging
    logger.log_dt_action(
        action_type="tool_execution",
        tool_name="send_email",
        parameters={"to": "user@example.com"},
        autonomous=False,
        user_confirmed=True,
        error="SMTP connection failed"
    )
    print("✅ Failed action logged")
    
    # Test parameter sanitization
    logger.log_dt_action(
        action_type="authentication",
        tool_name="login",
        parameters={"username": "john", "password": "secret123", "api_key": "sk-1234"},
        autonomous=False
    )
    
    # Check that password was sanitized
    recent = logger.get_recent_logs(limit=1)
    assert recent[0]["parameters"]["password"] == "***REDACTED***", "Password not sanitized!"
    assert recent[0]["parameters"]["api_key"] == "***REDACTED***", "API key not sanitized!"
    print("✅ Sensitive parameters sanitized")
    
    # Test searching logs
    all_logs = logger.get_recent_logs(limit=10)
    assert len(all_logs) >= 3, f"Should have at least 3 logs, got {len(all_logs)}"
    print("✅ Audit log retrieval works")
    
    # Test filtering
    failed_logs = logger.search_logs(failed_only=True)
    assert all(log["result_status"] == "failed" for log in failed_logs), "Filter not working"
    print("✅ Audit log filtering works")
    
    # Test summary
    summary = logger.get_action_summary(days=7)
    assert summary["total_actions"] >= 3, f"Wrong action count: {summary}"
    assert summary["failed_actions"] >= 1, "Should have failed actions"
    assert summary["autonomous_actions"] >= 1, "Should have autonomous actions"
    print("✅ Audit summary generation works")
    
    print("\n✅ All audit logger tests passed!")


async def test_integrated_security():
    """Test integrated security flow"""
    print("\n" + "="*60)
    print("TEST 5: Integrated Security Flow")
    print("="*60)
    
    # This simulates the full security check flow in execute_as_user
    
    controller = AutonomyController("test_user_integrated")
    rate_limiter = DTRateLimiter(max_actions_per_minute=3)
    audit_logger = DTAuditLogger("test_user_integrated")
    
    dt_id = "dt_test_user_integrated"
    tool_name = "get_weather"
    parameters = {"city": "London"}
    
    # Step 1: Check autonomy
    can_exec, reason = await controller.can_execute(tool_name, "full", autonomous=True)
    if not can_exec:
        audit_logger.log_dt_action(
            action_type="tool_execution",
            tool_name=tool_name,
            parameters=parameters,
            autonomous=True,
            error=f"Autonomy check failed: {reason}"
        )
        print(f"❌ Blocked by autonomy: {reason}")
        return False
    
    # Step 2: Check rate limit
    can_act, limit_msg = rate_limiter.can_act(dt_id)
    if not can_act:
        audit_logger.log_dt_action(
            action_type="tool_execution",
            tool_name=tool_name,
            parameters=parameters,
            autonomous=True,
            error=limit_msg
        )
        print(f"❌ Blocked by rate limit: {limit_msg}")
        return False
    
    # Step 3: Validate parameters
    tool_def = {
        "parameters": {
            "type": "object",
            "properties": {"city": {"type": "string"}},
            "required": ["city"]
        }
    }
    valid, validation_msg = validate_tool_parameters(tool_def, parameters)
    if not valid:
        audit_logger.log_dt_action(
            action_type="tool_execution",
            tool_name=tool_name,
            parameters=parameters,
            autonomous=True,
            error=f"Parameter validation failed: {validation_msg}"
        )
        print(f"❌ Blocked by validation: {validation_msg}")
        return False
    
    # Step 4: Record action
    rate_limiter.record_tool_call(dt_id, tool_name)
    
    # Step 5: Execute (simulated)
    result = {"temperature": 15, "condition": "cloudy"}
    
    # Step 6: Audit log success
    audit_logger.log_dt_action(
        action_type="tool_execution",
        tool_name=tool_name,
        parameters=parameters,
        result=result,
        autonomous=True,
        execution_time_ms=250.0
    )
    
    print("✅ Tool execution passed all security checks")
    print("✅ Action recorded and audited")
    
    # Test that rate limit is enforced after multiple calls
    for i in range(3):
        can_act, _ = rate_limiter.can_act(dt_id)
        if can_act:
            rate_limiter.record_action(dt_id)
    
    can_act, limit_msg = rate_limiter.can_act(dt_id)
    assert not can_act, "Rate limit should be triggered"
    print("✅ Rate limit enforced after multiple actions")
    
    print("\n✅ All integrated security tests passed!")


async def run_all_tests():
    """Run all security tests"""
    print("\n" + "="*70)
    print(" "*20 + "DIGITAL TWIN SECURITY TESTS")
    print("="*70)
    
    try:
        await test_autonomy_controller()
        test_parameter_validation()
        test_rate_limiter()
        test_audit_logger()
        await test_integrated_security()
        
        print("\n" + "="*70)
        print("🎉 "*15)
        print(" "*15 + "ALL SECURITY TESTS PASSED!")
        print("🎉 "*15)
        print("="*70)
        print("\n✅ Step 5: Security & Autonomy Controls - COMPLETE")
        print("\nSecurity features implemented:")
        print("  ✅ Autonomy Controller - enforces full/ask/restricted levels")
        print("  ✅ Parameter Validation - validates tool inputs")
        print("  ✅ Rate Limiting - prevents abuse and over-execution")
        print("  ✅ Audit Logging - comprehensive action logging")
        print("  ✅ Security APIs - manage settings and view logs")
        print("\nNext: Step 6 - State & Memory Management")
        
        return True
        
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)

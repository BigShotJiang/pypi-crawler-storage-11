"""
State Endpoint

Get current Digital Twin state and context.
"""

from fastapi import APIRouter, Request, HTTPException

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from dt_core import DigitalTwin
from dt_identity import DTIdentity

router = APIRouter()


@router.get("/state")
async def get_state(request: Request):
    """
    Get current DT state.
    
    Returns the Digital Twin's current state including:
    - User context
    - Memory and preferences
    - Statistics
    - Capabilities
    
    Requires: JWT authentication
    """
    # Extract JWT
    auth_header = request.headers.get("authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid authorization header")
    
    jwt_token = auth_header.replace("Bearer ", "")
    
    try:
        # Create DT identity
        identity = DTIdentity.from_jwt(jwt_token)
        
        # Initialize Digital Twin
        dt = DigitalTwin(identity)
        
        # Get DT state
        state = dt.get_state()
        
        return state
        
    except ValueError as e:
        raise HTTPException(status_code=401, detail=f"Invalid JWT: {str(e)}")
    except Exception as e:
        print(f"❌ Error in state endpoint: {e}")
        raise HTTPException(status_code=500, detail=f"Digital Twin error: {str(e)}")

#!/usr/bin/env python3
"""
Digital Twin Test Script

Tests the Digital Twin core functionality without needing full server setup.
"""

import sys
from pathlib import Path
import os
import json

# Add be directory to path
sys.path.insert(0, str(Path(__file__).parent / 'be'))

from dt_identity import DTIdentity
from dt_state import DTState
from dt_core import DigitalTwin

def test_dt_identity():
    """Test DT Identity creation"""
    print("\n🧪 Testing DT Identity...")
    
    # Create a mock JWT payload
    mock_jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdF91c2VyXzEyMyIsInVzZXJuYW1lIjoidGVzdHVzZXIiLCJuYW1lIjoiVGVzdCBVc2VyIn0.mock"
    
    try:
        identity = DTIdentity.from_jwt(mock_jwt)
        print(f"✅ Identity created: {identity}")
        print(f"   DT Introduction: {identity.get_dt_introduction()}")
        return True
    except Exception as e:
        print(f"❌ Identity creation failed: {e}")
        return False

def test_dt_state():
    """Test DT State management"""
    print("\n🧪 Testing DT State...")
    
    try:
        state = DTState("test_user_123")
        print(f"✅ State created: {state}")
        
        # Test adding to memory
        state.add_to_memory("conversations", {"test": "data"})
        state.increment_action_count(autonomous=True)
        state.save()
        
        print(f"   Stats: {state.state['stats']}")
        return True
    except Exception as e:
        print(f"❌ State management failed: {e}")
        return False

def test_dt_capabilities():
    """Test DT capabilities (without OpenAI key)"""
    print("\n🧪 Testing DT Capabilities...")
    
    mock_jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdF91c2VyXzEyMyIsInVzZXJuYW1lIjoidGVzdHVzZXIiLCJuYW1lIjoiVGVzdCBVc2VyIn0.mock"
    
    try:
        # Set a dummy API key for testing structure
        os.environ["OPENAI_API_KEY"] = "sk-test-dummy-key"
        
        identity = DTIdentity.from_jwt(mock_jwt)
        dt = DigitalTwin(identity)
        
        capabilities = dt.get_capabilities()
        print(f"✅ Digital Twin initialized: {dt}")
        print(f"   Capabilities: {json.dumps(capabilities, indent=2)}")
        
        state = dt.get_state()
        print(f"   State: DT ID={state['dt_id']}, Active={state['dt_active']}")
        
        return True
    except Exception as e:
        print(f"❌ DT initialization failed: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("🤖 Digital Twin Agent - Component Tests")
    print("=" * 60)
    
    results = []
    
    # Run tests
    results.append(("Identity", test_dt_identity()))
    results.append(("State", test_dt_state()))
    results.append(("Capabilities", test_dt_capabilities()))
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 Test Summary")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {test_name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed! Digital Twin core is working!")
        print("\nNext steps:")
        print("1. Set OPENAI_API_KEY environment variable")
        print("2. Start the server: cd aurica-base-be && uvicorn src.main:app --reload")
        print("3. Test health endpoint: curl http://localhost:8000/digital-twin/api/health")
        return 0
    else:
        print("\n⚠️  Some tests failed. Please check the errors above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())

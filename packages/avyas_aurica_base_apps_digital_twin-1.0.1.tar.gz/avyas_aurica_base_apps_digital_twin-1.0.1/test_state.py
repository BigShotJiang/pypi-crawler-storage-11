"""
Test State Management & Memory for Digital Twin

Tests conversation history, learning, context management, and persistence.
"""

import asyncio
import sys
import tempfile
import shutil
from pathlib import Path

# Add digital-twin app to path
sys.path.insert(0, str(Path(__file__).parent))

from be.dt_state import (
    DTState,
    build_conversation_context,
    generate_dt_system_prompt,
    format_tools_list
)


def test_dt_state_creation():
    """Test DTState creation and initialization"""
    print("\n" + "="*60)
    print("TEST 1: DTState Creation")
    print("="*60)
    
    # Use temp directory
    temp_dir = tempfile.mkdtemp()
    
    try:
        state = DTState("test_user_state", storage_dir=Path(temp_dir))
        
        # Check initialization
        assert state.user_id == "test_user_state"
        assert state.dt_id == "dt_test_user_state"
        assert state.state["stats"]["total_actions"] == 0
        assert state.state["stats"]["total_conversations"] == 0
        print("✅ DTState created with correct initialization")
        
        # Check state file was created
        assert state.state_file.exists()
        print("✅ State file created on disk")
        
        return state, temp_dir
        
    except Exception as e:
        shutil.rmtree(temp_dir)
        raise e


def test_conversation_management(state: DTState):
    """Test conversation history management"""
    print("\n" + "="*60)
    print("TEST 2: Conversation Management")
    print("="*60)
    
    # Add conversation messages
    state.add_conversation_message("user", "Hello DT!", metadata={"intent": "greeting"})
    state.add_conversation_message("assistant", "Hello! How can I help you?")
    state.add_conversation_message("user", "What's the weather?", metadata={"needs_tool": True})
    state.add_conversation_message("assistant", "Let me check the weather for you.")
    
    assert len(state.state["memory"]["conversations"]) == 4
    print("✅ Conversation messages added correctly")
    
    # Get conversation history
    history = state.get_conversation_history(max_messages=10)
    assert len(history) == 4
    assert history[0]["role"] == "user"
    assert history[0]["content"] == "Hello DT!"
    print("✅ Conversation history retrieval works")
    
    # Test conversation count
    assert state.state["stats"]["total_conversations"] == 2  # Only user messages count
    print("✅ Conversation count tracking works")
    
    # Test token limiting
    for i in range(20):
        state.add_conversation_message("user", f"Message {i}" * 100)
        state.add_conversation_message("assistant", f"Response {i}" * 100)
    
    # Get with token limit
    history_limited = state.get_conversation_history(max_messages=50, max_tokens=1000)
    assert len(history_limited) < 50  # Should be truncated by token limit
    print("✅ Token-based conversation limiting works")


def test_learning_system(state: DTState):
    """Test preference learning from interactions"""
    print("\n" + "="*60)
    print("TEST 3: Learning System")
    print("="*60)
    
    # Test preference extraction
    user_messages = [
        "I prefer using Celsius for temperature",
        "I like getting weather updates in the morning",
        "I always check my email before meetings",
        "I usually work from 9am to 5pm"
    ]
    
    for msg in user_messages:
        state.learn_from_interaction(
            user_message=msg,
            dt_response="Understood!",
            tools_used=[],
            autonomous=False
        )
    
    preferences = state.state["memory"]["learned_preferences"]
    assert len(preferences) > 0, f"Should have learned preferences, got: {preferences}"
    print(f"✅ Learned {len(preferences)} preferences from interactions")
    
    # Check specific preferences
    pref_keys = list(preferences.keys())
    print(f"  Learned preferences: {pref_keys}")
    
    # Test tool usage learning
    state.learn_from_interaction(
        user_message="Check the weather",
        dt_response="Weather is sunny",
        tools_used=["get_weather", "get_forecast"],
        autonomous=True
    )
    
    tool_history = state.state["memory"]["tool_usage_history"]
    assert len(tool_history) > 0
    print(f"✅ Tool usage history tracked ({len(tool_history)} entries)")


def test_state_persistence(temp_dir: str):
    """Test state persistence across restarts"""
    print("\n" + "="*60)
    print("TEST 4: State Persistence")
    print("="*60)
    
    # Create state and add data
    state1 = DTState("persistence_test", storage_dir=Path(temp_dir))
    state1.add_conversation_message("user", "Test message 1")
    state1.add_conversation_message("assistant", "Response 1")
    state1.update_learned_preferences("test_key", "test_value")
    state1.increment_action_count(autonomous=True)
    state1.save()
    
    initial_actions = state1.state["stats"]["total_actions"]
    print(f"✅ State saved with {initial_actions} actions")
    
    # Create new state instance (simulates restart)
    state2 = DTState("persistence_test", storage_dir=Path(temp_dir))
    
    # Check data was loaded
    assert state2.state["stats"]["total_actions"] == initial_actions
    assert len(state2.state["memory"]["conversations"]) == 2
    assert "test_key" in state2.state["memory"]["learned_preferences"]
    print("✅ State loaded correctly after restart")
    
    # Verify specific values
    assert state2.state["memory"]["conversations"][0]["content"] == "Test message 1"
    assert state2.state["memory"]["learned_preferences"]["test_key"]["value"] == "test_value"
    print("✅ All state data preserved accurately")


def test_context_building():
    """Test conversation context building"""
    print("\n" + "="*60)
    print("TEST 5: Context Building")
    print("="*60)
    
    temp_dir = tempfile.mkdtemp()
    
    try:
        state = DTState("context_test", storage_dir=Path(temp_dir))
        
        # Add conversation history
        for i in range(10):
            state.add_conversation_message("user", f"User message {i}")
            state.add_conversation_message("assistant", f"Assistant response {i}")
        
        # Build context
        context = build_conversation_context(state, max_messages=6)
        
        # Should have system message + conversation messages
        assert len(context) > 1
        assert context[0]["role"] == "system"
        assert "Current Context" in context[0]["content"]
        print("✅ Context includes system message with DT state")
        
        # Check conversation messages are included
        user_msgs = [msg for msg in context if msg["role"] == "user"]
        assert len(user_msgs) <= 6
        print(f"✅ Conversation context limited correctly ({len(user_msgs)} messages)")
        
    finally:
        shutil.rmtree(temp_dir)


def test_system_prompt_generation():
    """Test dynamic system prompt generation"""
    print("\n" + "="*60)
    print("TEST 6: System Prompt Generation")
    print("="*60)
    
    temp_dir = tempfile.mkdtemp()
    
    try:
        state = DTState("prompt_test", storage_dir=Path(temp_dir))
        
        # Add some state
        state.update_learned_preferences("language", "English")
        state.update_learned_preferences("timezone", "UTC")
        state.increment_action_count(autonomous=True)
        state.increment_action_count(autonomous=True)
        state.increment_action_count(autonomous=False)
        
        # Mock tools
        tools = [
            {"name": "get_weather", "description": "Get weather", "autonomy_level": "full"},
            {"name": "send_email", "description": "Send email", "autonomy_level": "ask"},
            {"name": "delete_data", "description": "Delete data", "autonomy_level": "restricted"}
        ]
        
        # Generate prompt
        prompt = generate_dt_system_prompt(
            user_id="test_user",
            user_name="Test User",
            dt_state=state,
            available_tools=tools
        )
        
        # Verify prompt contents
        assert "Test User" in prompt
        assert "test_user" in prompt
        assert "Digital Twin" in prompt
        assert "first-class citizen" in prompt
        print("✅ System prompt includes user identity")
        
        assert "Autonomous Tools" in prompt
        assert "Confirmation Tools" in prompt
        assert "Restricted Tools" in prompt
        print("✅ System prompt categorizes tools by autonomy")
        
        assert "Total actions taken: 3" in prompt
        assert "Autonomous actions: 2" in prompt
        print("✅ System prompt includes DT statistics")
        
        assert "language" in prompt and "English" in prompt
        assert "timezone" in prompt and "UTC" in prompt
        print("✅ System prompt includes learned preferences")
        
        print(f"\nGenerated prompt length: {len(prompt)} characters")
        
    finally:
        shutil.rmtree(temp_dir)


def test_state_summary():
    """Test state summary generation"""
    print("\n" + "="*60)
    print("TEST 7: State Summary")
    print("="*60)
    
    temp_dir = tempfile.mkdtemp()
    
    try:
        state = DTState("summary_test", storage_dir=Path(temp_dir))
        
        # Add various activities
        for i in range(5):
            state.add_conversation_message("user", f"Message {i}")
            state.add_conversation_message("assistant", f"Response {i}")
        
        state.update_learned_preferences("pref1", "value1")
        state.update_learned_preferences("pref2", "value2")
        
        for i in range(10):
            state.increment_action_count(autonomous=(i % 2 == 0))
        
        state.state["capabilities"]["discovered_tools"] = ["tool1", "tool2", "tool3"]
        
        # Get summary
        summary = state.summarize_state()
        
        assert summary["total_actions"] == 10
        assert summary["autonomous_actions"] == 5
        assert summary["total_conversations"] == 5
        assert summary["learned_preferences"] == 2
        assert summary["tools_discovered"] == 3
        assert summary["conversation_messages"] == 10
        
        print("✅ State summary includes all key metrics")
        print(f"  Summary: {summary}")
        
    finally:
        shutil.rmtree(temp_dir)


def test_recent_topics():
    """Test recent topics extraction"""
    print("\n" + "="*60)
    print("TEST 8: Recent Topics Extraction")
    print("="*60)
    
    temp_dir = tempfile.mkdtemp()
    
    try:
        state = DTState("topics_test", storage_dir=Path(temp_dir))
        
        # Add messages with different topics
        topics_messages = [
            "What's the weather today?",
            "Check my email please",
            "Show me the dashboard",
            "Update my profile information",
            "Tell me about the news"
        ]
        
        for msg in topics_messages:
            state.add_conversation_message("user", msg)
            state.add_conversation_message("assistant", "Sure, let me help with that.")
        
        # Get recent topics
        topics = state.get_recent_topics(limit=5)
        
        assert len(topics) == 5
        assert "weather" in topics[0].lower()
        assert "email" in topics[1].lower()
        print(f"✅ Recent topics extracted: {topics}")
        
    finally:
        shutil.rmtree(temp_dir)


async def run_all_tests():
    """Run all state management tests"""
    print("\n" + "="*70)
    print(" "*15 + "DIGITAL TWIN STATE MANAGEMENT TESTS")
    print("="*70)
    
    temp_dir = None
    
    try:
        # Test 1: Creation
        state, temp_dir = test_dt_state_creation()
        
        # Test 2: Conversations
        test_conversation_management(state)
        
        # Test 3: Learning
        test_learning_system(state)
        
        # Test 4: Persistence
        test_state_persistence(temp_dir)
        
        # Test 5: Context
        test_context_building()
        
        # Test 6: System Prompt
        test_system_prompt_generation()
        
        # Test 7: Summary
        test_state_summary()
        
        # Test 8: Topics
        test_recent_topics()
        
        print("\n" + "="*70)
        print("🎉 "*15)
        print(" "*10 + "ALL STATE MANAGEMENT TESTS PASSED!")
        print("🎉 "*15)
        print("="*70)
        print("\n✅ Step 6: State & Memory Management - COMPLETE")
        print("\nState management features implemented:")
        print("  ✅ Conversation history with token management")
        print("  ✅ Automatic preference learning from interactions")
        print("  ✅ State persistence across restarts")
        print("  ✅ Dynamic system prompt generation")
        print("  ✅ Context building with DT state")
        print("  ✅ Recent topics extraction")
        print("  ✅ Comprehensive state summaries")
        print("\nNext: Step 7 - Final Testing & Polish")
        
        return True
        
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        # Cleanup
        if temp_dir and Path(temp_dir).exists():
            shutil.rmtree(temp_dir)


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)

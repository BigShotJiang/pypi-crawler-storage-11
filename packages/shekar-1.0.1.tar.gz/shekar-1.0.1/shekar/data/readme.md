#### Vocabulary


#### Persian Stop Words






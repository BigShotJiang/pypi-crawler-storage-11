# Copyright (c) 2025, HaiyangLi <quantocean.li at gmail dot com>
# SPDX-License-Identifier: Apache-2.0

from .errors import (
    AmbiguousMatchError,
    InvalidConstructorError,
    LNDLError,
    MissingFieldError,
    MissingLvarError,
    MissingOutBlockError,
    TypeMismatchError,
)
from .fuzzy import parse_lndl_fuzzy
from .parser import (
    extract_lvars,
    extract_lvars_prefixed,
    extract_out_block,
    parse_out_block_array,
)
from .prompt import LNDL_SYSTEM_PROMPT, get_lndl_system_prompt
from .resolver import parse_lndl, resolve_references_prefixed
from .types import LNDLOutput, LvarMetadata, ParsedConstructor

__all__ = (
    "LNDL_SYSTEM_PROMPT",
    "AmbiguousMatchError",
    "InvalidConstructorError",
    "LNDLError",
    "LNDLOutput",
    "LvarMetadata",
    "MissingFieldError",
    "MissingLvarError",
    "MissingOutBlockError",
    "ParsedConstructor",
    "TypeMismatchError",
    "extract_lvars",  # backward compatibility
    "extract_lvars_prefixed",
    "extract_out_block",
    "get_lndl_system_prompt",
    "parse_lndl",
    "parse_lndl_fuzzy",
    "parse_out_block_array",
    "resolve_references_prefixed",
)

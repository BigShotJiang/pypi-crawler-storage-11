1. [ ] # customTraceback
2. [ ] 
3. [ ] ## A quick and easy way to customize your Python tracebacks.
4. [ ] 
5. [ ] ```py
6. [ ] import customTraceback
7. [ ] 
8. [ ] def myTraceback(name, value, tb):
9. [ ]     print(f"🔥 Exception: {name}")
10. [ ]     print(f"💬 {value}")
11. [ ]     print(f"📜 Trace: {tb}")
12. [ ] 
13. [ ] customTraceback.setTraceBack(myTraceback)
14. [ ] 
15. [ ] 1 / 0
16. [ ] ```
17. [ ] ### This replaces the division by 0 error with a custom traceback
18. [ ] **This is a basic example this package is a fun package to make cool tracebacks**
"""
Эксперименты с визуализацией логов - различные стили и акценты
"""

import asyncio
from bose_request import BossAsyncSessionCurlCffi
from action import LOG_ACTION
from request_handlers import ResponseValidator, as_validator
from functools import wraps
from typing import Callable, Any, Literal
import time
import json


# ========== ЦВЕТОВАЯ ПАЛИТРА ==========

class Colors:
    """Расширенная палитра цветов"""
    # Основные
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"

    # Основные цвета
    BLACK = "\033[30m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    GRAY = "\033[90m"

    # Фоновые цвета
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"
    BG_MAGENTA = "\033[45m"
    BG_CYAN = "\033[46m"
    BG_WHITE = "\033[47m"
    BG_GRAY = "\033[100m"

    # RGB цвета (True Color)
    @staticmethod
    def rgb(r: int, g: int, b: int) -> str:
        return f"\033[38;2;{r};{g};{b}m"

    @staticmethod
    def bg_rgb(r: int, g: int, b: int) -> str:
        return f"\033[48;2;{r};{g};{b}m"


# ========== СТИЛЬ 1: МИНИМАЛИСТИЧНЫЙ С АКЦЕНТАМИ ==========

class MinimalLogger:
    """Минималистичный стиль с акцентами на важном"""

    @staticmethod
    def log(action: str, **options):
        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                start = time.time()

                # Извлекаем URL
                url = "N/A"
                for v in list(args) + list(kwargs.values()):
                    if isinstance(v, str) and ("http://" in v or "https://" in v):
                        url = v.replace("https://", "").replace("http://", "")
                        break

                result = await func(*args, **kwargs)
                elapsed = time.time() - start
                validated = as_validator(result)

                if hasattr(validated, "url"):
                    url = str(validated.url).replace("https://", "").replace("http://", "")

                has_errors = validated.valid.has_errors()
                status = validated.status_code

                # Акцент на статус
                if status == 200:
                    status_badge = f"{Colors.BG_GREEN}{Colors.BLACK} 200 {Colors.RESET}"
                elif 200 <= status < 300:
                    status_badge = f"{Colors.BG_GREEN}{Colors.BLACK} {status} {Colors.RESET}"
                elif 400 <= status < 500:
                    status_badge = f"{Colors.BG_RED}{Colors.WHITE} {status} {Colors.RESET}"
                else:
                    status_badge = f"{Colors.BG_YELLOW}{Colors.BLACK} {status} {Colors.RESET}"

                # Акцент на время (если медленно)
                if elapsed > 3.0:
                    time_str = f"{Colors.BOLD}{Colors.RED}{elapsed:.3f}с{Colors.RESET}"
                elif elapsed > 1.5:
                    time_str = f"{Colors.YELLOW}{elapsed:.3f}с{Colors.RESET}"
                else:
                    time_str = f"{Colors.DIM}{elapsed:.3f}с{Colors.RESET}"

                # Icon
                icon = "✓" if not has_errors else "✗"
                icon_color = Colors.GREEN if not has_errors else Colors.RED

                print(f"{icon_color}{icon}{Colors.RESET} {time_str} {Colors.CYAN}{action}{Colors.RESET} {Colors.DIM}→{Colors.RESET} {url[:40]} {status_badge}")

                return validated
            return wrapper
        return decorator


# ========== СТИЛЬ 2: BOXED С ГРАНИЦАМИ ==========

class BoxedLogger:
    """Стиль с рамками и блоками"""

    @staticmethod
    def log(action: str, **options):
        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                start = time.time()

                url = "N/A"
                for v in list(args) + list(kwargs.values()):
                    if isinstance(v, str) and ("http://" in v or "https://" in v):
                        url = v.replace("https://", "").replace("http://", "")
                        break

                result = await func(*args, **kwargs)
                elapsed = time.time() - start
                validated = as_validator(result)

                if hasattr(validated, "url"):
                    url = str(validated.url).replace("https://", "").replace("http://", "")

                has_errors = validated.valid.has_errors()
                status = validated.status_code

                # Box drawing
                print(f"\n{Colors.DIM}┌─ {Colors.CYAN}{action}{Colors.RESET}")
                print(f"{Colors.DIM}│{Colors.RESET}  {Colors.WHITE}{url[:50]}{Colors.RESET}")

                # Status line
                status_color = Colors.GREEN if 200 <= status < 300 else Colors.RED
                print(f"{Colors.DIM}│{Colors.RESET}  Status: {status_color}{Colors.BOLD}{status}{Colors.RESET}  Time: {elapsed:.3f}s")

                # Details if requested
                if options.get('show_body'):
                    try:
                        body = validated.json()
                        body_str = json.dumps(body, indent=2, ensure_ascii=False)[:200]
                        print(f"{Colors.DIM}│{Colors.RESET}  {Colors.GRAY}{body_str}{Colors.RESET}")
                    except:
                        pass

                print(f"{Colors.DIM}└{'─' * 60}{Colors.RESET}")

                return validated
            return wrapper
        return decorator


# ========== СТИЛЬ 3: ГРАДИЕНТНЫЕ АКЦЕНТЫ ==========

class GradientLogger:
    """Стиль с RGB градиентами для важных элементов"""

    @staticmethod
    def log(action: str, **options):
        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                start = time.time()

                url = "N/A"
                for v in list(args) + list(kwargs.values()):
                    if isinstance(v, str) and ("http://" in v or "https://" in v):
                        url = v.replace("https://", "").replace("http://", "")
                        break

                result = await func(*args, **kwargs)
                elapsed = time.time() - start
                validated = as_validator(result)

                if hasattr(validated, "url"):
                    url = str(validated.url).replace("https://", "").replace("http://", "")

                status = validated.status_code

                # Gradient для успеха (зеленый градиент)
                if 200 <= status < 300:
                    # От светло-зеленого к темно-зеленому
                    status_str = (
                        f"{Colors.rgb(144, 238, 144)}{status//100}"
                        f"{Colors.rgb(50, 205, 50)}{(status//10)%10}"
                        f"{Colors.rgb(34, 139, 34)}{status%10}{Colors.RESET}"
                    )
                # Gradient для ошибки (красный градиент)
                elif 400 <= status < 500:
                    status_str = (
                        f"{Colors.rgb(255, 99, 71)}{status//100}"
                        f"{Colors.rgb(220, 20, 60)}{(status//10)%10}"
                        f"{Colors.rgb(178, 34, 34)}{status%10}{Colors.RESET}"
                    )
                else:
                    status_str = f"{Colors.YELLOW}{status}{Colors.RESET}"

                # Rainbow для action (если важный)
                action_colors = [
                    Colors.rgb(255, 0, 0),    # Red
                    Colors.rgb(255, 127, 0),  # Orange
                    Colors.rgb(255, 255, 0),  # Yellow
                    Colors.rgb(0, 255, 0),    # Green
                    Colors.rgb(0, 0, 255),    # Blue
                    Colors.rgb(75, 0, 130),   # Indigo
                    Colors.rgb(148, 0, 211),  # Violet
                ]

                # Красим каждую букву action в радужный градиент
                colored_action = ""
                for i, char in enumerate(action[:20]):
                    color = action_colors[i % len(action_colors)]
                    colored_action += f"{color}{char}"
                colored_action += Colors.RESET

                print(f"  {status_str} {Colors.DIM}|{Colors.RESET} {colored_action} {Colors.DIM}→{Colors.RESET} {Colors.CYAN}{url[:40]}{Colors.RESET} {Colors.DIM}({elapsed:.3f}s){Colors.RESET}")

                return validated
            return wrapper
        return decorator


# ========== СТИЛЬ 4: ЭМОДЗИ АКЦЕНТЫ ==========

class EmojiLogger:
    """Стиль с эмодзи для быстрой идентификации"""

    @staticmethod
    def log(action: str, **options):
        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                start = time.time()

                url = "N/A"
                for v in list(args) + list(kwargs.values()):
                    if isinstance(v, str) and ("http://" in v or "https://" in v):
                        url = v.replace("https://", "").replace("http://", "")
                        break

                result = await func(*args, **kwargs)
                elapsed = time.time() - start
                validated = as_validator(result)

                if hasattr(validated, "url"):
                    url = str(validated.url).replace("https://", "").replace("http://", "")

                status = validated.status_code

                # Эмодзи для метода
                if 'POST' in action or 'SEND' in action:
                    method_emoji = "📤"
                elif 'GET' in action or 'FETCH' in action:
                    method_emoji = "📥"
                elif 'DELETE' in action:
                    method_emoji = "🗑️"
                elif 'PUT' in action or 'UPDATE' in action:
                    method_emoji = "✏️"
                else:
                    method_emoji = "📡"

                # Эмодзи для статуса
                if status == 200:
                    status_emoji = "✅"
                elif 200 <= status < 300:
                    status_emoji = "🟢"
                elif 300 <= status < 400:
                    status_emoji = "🔵"
                elif status == 404:
                    status_emoji = "🔍"
                elif 400 <= status < 500:
                    status_emoji = "🔴"
                else:
                    status_emoji = "🟡"

                # Эмодзи для времени
                if elapsed > 3.0:
                    time_emoji = "🐌"
                elif elapsed > 1.5:
                    time_emoji = "🐢"
                elif elapsed < 0.5:
                    time_emoji = "⚡"
                else:
                    time_emoji = "⏱️"

                print(f"{method_emoji} {status_emoji} {Colors.BOLD}{action}{Colors.RESET} {Colors.DIM}→{Colors.RESET} {url[:40]} {time_emoji} {Colors.CYAN}{elapsed:.3f}s{Colors.RESET} {Colors.DIM}[{status}]{Colors.RESET}")

                return validated
            return wrapper
        return decorator


# ========== СТИЛЬ 5: ПРОГРЕСС-БАР СТИЛЬ ==========

class ProgressLogger:
    """Стиль с прогресс-баром для времени выполнения"""

    @staticmethod
    def log(action: str, max_time: float = 5.0, **options):
        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                start = time.time()

                url = "N/A"
                for v in list(args) + list(kwargs.values()):
                    if isinstance(v, str) and ("http://" in v or "https://" in v):
                        url = v.replace("https://", "").replace("http://", "")
                        break

                result = await func(*args, **kwargs)
                elapsed = time.time() - start
                validated = as_validator(result)

                if hasattr(validated, "url"):
                    url = str(validated.url).replace("https://", "").replace("http://", "")

                status = validated.status_code

                # Прогресс-бар для времени
                bar_width = 20
                percent = min(elapsed / max_time, 1.0)
                filled = int(bar_width * percent)

                if percent < 0.3:
                    bar_color = Colors.GREEN
                elif percent < 0.7:
                    bar_color = Colors.YELLOW
                else:
                    bar_color = Colors.RED

                bar = f"{bar_color}{'█' * filled}{Colors.DIM}{'░' * (bar_width - filled)}{Colors.RESET}"

                # Status badge
                if 200 <= status < 300:
                    status_str = f"{Colors.GREEN}●{Colors.RESET}"
                elif 400 <= status < 500:
                    status_str = f"{Colors.RED}●{Colors.RESET}"
                else:
                    status_str = f"{Colors.YELLOW}●{Colors.RESET}"

                print(f"{status_str} {bar} {Colors.CYAN}{action:<25}{Colors.RESET} {url[:30]:<30} {elapsed:.3f}s")

                return validated
            return wrapper
        return decorator


# ========== СТИЛЬ 6: КОМПАКТНЫЙ С HIGHLIGHTS ==========

class CompactLogger:
    """Компактный стиль с подсветкой ключевых моментов"""

    @staticmethod
    def log(action: str, **options):
        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                start = time.time()

                url = "N/A"
                for v in list(args) + list(kwargs.values()):
                    if isinstance(v, str) and ("http://" in v or "https://" in v):
                        url = v.replace("https://", "").replace("http://", "")
                        break

                result = await func(*args, **kwargs)
                elapsed = time.time() - start
                validated = as_validator(result)

                if hasattr(validated, "url"):
                    url = str(validated.url).replace("https://", "").replace("http://", "")

                has_errors = validated.valid.has_errors()
                status = validated.status_code

                # Highlight статуса (инвертированные цвета для акцента)
                if status == 200:
                    status_hl = f"{Colors.BG_GREEN}{Colors.BLACK}{Colors.BOLD} {status} {Colors.RESET}"
                elif 200 <= status < 300:
                    status_hl = f"{Colors.BG_CYAN}{Colors.BLACK} {status} {Colors.RESET}"
                elif status == 404:
                    status_hl = f"{Colors.BG_YELLOW}{Colors.BLACK} 404 {Colors.RESET}"
                elif 400 <= status < 500:
                    status_hl = f"{Colors.BG_RED}{Colors.WHITE} {status} {Colors.RESET}"
                else:
                    status_hl = f"{Colors.BG_MAGENTA}{Colors.WHITE} {status} {Colors.RESET}"

                # Подсветка медленных запросов
                time_hl = f"{elapsed:.3f}s"
                if elapsed > 2.0:
                    time_hl = f"{Colors.BG_RED}{Colors.WHITE} {time_hl} {Colors.RESET}"
                elif elapsed > 1.0:
                    time_hl = f"{Colors.YELLOW}{Colors.BOLD}{time_hl}{Colors.RESET}"
                else:
                    time_hl = f"{Colors.DIM}{time_hl}{Colors.RESET}"

                # Icon
                if has_errors:
                    icon = f"{Colors.RED}⚠{Colors.RESET}"
                elif elapsed > 2.0:
                    icon = f"{Colors.YELLOW}⏱{Colors.RESET}"
                else:
                    icon = f"{Colors.GREEN}✓{Colors.RESET}"

                print(f"{icon} {status_hl} {time_hl} {Colors.CYAN}{action}{Colors.RESET} {Colors.DIM}|{Colors.RESET} {url[:45]}")

                # Детали ошибок если есть
                if has_errors and options.get('show_errors', True):
                    for err in validated.valid.ERRORS:
                        print(f"  {Colors.RED}↳{Colors.RESET} {Colors.DIM}{err.key}:{Colors.RESET} {err.expected} {Colors.RED}≠{Colors.RESET} {err.actual}")

                return validated
            return wrapper
        return decorator


# ========== ДЕМОНСТРАЦИЯ ==========

if __name__ == "__main__":

    print("=" * 80)
    print(f"{Colors.BOLD}{Colors.CYAN}ЭКСПЕРИМЕНТЫ С ВИЗУАЛИЗАЦИЕЙ ЛОГОВ{Colors.RESET}")
    print("=" * 80)

    # Тестовые функции для каждого стиля

    # СТИЛЬ 1: Минималистичный
    @MinimalLogger.log(LOG_ACTION.FETCH.PROFILE)
    @ResponseValidator.status([200])
    async def test_minimal_success(client):
        return await client.get('https://httpbin.org/get')

    @MinimalLogger.log(LOG_ACTION.SEND.FORM)
    @ResponseValidator.status([200])
    async def test_minimal_error(client):
        return await client.get('https://httpbin.org/status/404')

    # СТИЛЬ 2: Boxed
    @BoxedLogger.log(LOG_ACTION.FETCH.COOKIES, show_body=True)
    @ResponseValidator.status([200])
    async def test_boxed(client):
        return await client.get('https://httpbin.org/get')

    # СТИЛЬ 3: Gradient
    @GradientLogger.log(LOG_ACTION.SEND.FORM)
    @ResponseValidator.status([200])
    async def test_gradient_success(client):
        return await client.post('https://httpbin.org/post', json={"test": "data"})

    @GradientLogger.log(LOG_ACTION.FETCH.BALANCE)
    @ResponseValidator.status([200])
    async def test_gradient_error(client):
        return await client.get('https://httpbin.org/status/404')

    # СТИЛЬ 4: Emoji
    @EmojiLogger.log(LOG_ACTION.SEND.FORM)
    @ResponseValidator.status([200])
    async def test_emoji_post(client):
        return await client.post('https://httpbin.org/post', json={"action": "test"})

    @EmojiLogger.log(LOG_ACTION.FETCH.PROFILE)
    @ResponseValidator.status([200])
    async def test_emoji_get(client):
        return await client.get('https://httpbin.org/get')

    @EmojiLogger.log(LOG_ACTION.FETCH.BALANCE)
    @ResponseValidator.status([200])
    async def test_emoji_error(client):
        return await client.get('https://httpbin.org/status/404')

    # СТИЛЬ 5: Progress
    @ProgressLogger.log(LOG_ACTION.FETCH.COOKIES, max_time=3.0)
    @ResponseValidator.status([200])
    async def test_progress_fast(client):
        return await client.get('https://httpbin.org/get')

    @ProgressLogger.log(LOG_ACTION.FETCH.PROFILE, max_time=3.0)
    @ResponseValidator.status([200])
    async def test_progress_slow(client):
        return await client.get('https://httpbin.org/delay/2')

    # СТИЛЬ 6: Compact
    @CompactLogger.log(LOG_ACTION.SEND.FORM, show_errors=True)
    @ResponseValidator.status([200])
    async def test_compact_success(client):
        return await client.post('https://httpbin.org/post', json={"data": "test"})

    @CompactLogger.log(LOG_ACTION.FETCH.BALANCE, show_errors=True)
    @ResponseValidator.status([200])
    async def test_compact_error(client):
        return await client.get('https://httpbin.org/status/404')


    async def main():
        async with BossAsyncSessionCurlCffi() as client:

            print(f"\n{Colors.BOLD}━━━ СТИЛЬ 1: МИНИМАЛИСТИЧНЫЙ С АКЦЕНТАМИ ━━━{Colors.RESET}\n")
            await test_minimal_success(client)
            try:
                await test_minimal_error(client)
            except:
                pass

            print(f"\n{Colors.BOLD}━━━ СТИЛЬ 2: BOXED С ГРАНИЦАМИ ━━━{Colors.RESET}\n")
            await test_boxed(client)

            print(f"\n{Colors.BOLD}━━━ СТИЛЬ 3: ГРАДИЕНТНЫЕ АКЦЕНТЫ ━━━{Colors.RESET}\n")
            await test_gradient_success(client)
            try:
                await test_gradient_error(client)
            except:
                pass

            print(f"\n{Colors.BOLD}━━━ СТИЛЬ 4: ЭМОДЗИ АКЦЕНТЫ ━━━{Colors.RESET}\n")
            await test_emoji_post(client)
            await test_emoji_get(client)
            try:
                await test_emoji_error(client)
            except:
                pass

            print(f"\n{Colors.BOLD}━━━ СТИЛЬ 5: ПРОГРЕСС-БАР ━━━{Colors.RESET}\n")
            await test_progress_fast(client)
            await test_progress_slow(client)

            print(f"\n{Colors.BOLD}━━━ СТИЛЬ 6: КОМПАКТНЫЙ С HIGHLIGHTS ━━━{Colors.RESET}\n")
            await test_compact_success(client)
            try:
                await test_compact_error(client)
            except:
                pass

            print("\n" + "=" * 80)
            print(f"{Colors.BOLD}{Colors.GREEN}ЭКСПЕРИМЕНТЫ ЗАВЕРШЕНЫ{Colors.RESET}")
            print("=" * 80)

    asyncio.run(main())

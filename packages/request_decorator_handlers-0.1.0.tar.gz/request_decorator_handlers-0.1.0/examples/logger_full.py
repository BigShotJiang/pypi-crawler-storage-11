"""
Полный тест декоратора логов с показом тела запроса
"""

import asyncio
import sys

from bose_request import BossAsyncSessionCurlCffi
from loguru import logger

# Настройка логгера
logger.remove()
logger.level("DEBUG", icon="•", color="<fg #61afef>")
logger.level("SUCCESS", icon="✓", color="<fg #98c379>")

console_format = (
    "<fg #5c6370>{time:HH:mm:ss}</fg #5c6370> <dim>|</dim> "
    "<level>{level.icon} {level:<8}</level>"
    "{message}"
)

logger.add(sys.stdout, format=console_format, colorize=True, level="DEBUG")

from src.request_decorator_handlers import RequestLogger, ResponseValidator


# Тест с телом запроса
@RequestLogger.log(
    "AUTH.LOGIN",
    log_level="full",
    show_request_body=True,
    show_response_headers=True,
    show_body=True,
    len_text=300
)
@ResponseValidator.status([200])
async def test_post_with_body(client):
    return await client.post(
        'https://httpbin.org/post',
        json={
            "username": "testuser123",
            "password": "secret_password",
            "email": "test@example.com",
            "remember_me": True
        }
    )


# Тест с телом запроса + заголовками
@RequestLogger.log(
    "SEND.FORM",
    log_level="full",
    show_request_body=True,
    show_request_headers=True,
    show_response_headers=True,
    show_body=True,
    len_text=400
)
@ResponseValidator.status([200])
async def test_full_with_all(client):
    return await client.post(
        'https://httpbin.org/post',
        json={
            "action": "create_user",
            "user_data": {
                "name": "John Doe",
                "age": 30,
                "email": "john@example.com"
            },
            "metadata": {
                "timestamp": "2025-10-31",
                "source": "api"
            }
        },
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer token123",
            "X-Request-ID": "req-12345",
            "User-Agent": "TestClient/2.0"
        }
    )


async def main():
    async with BossAsyncSessionCurlCffi() as client:

        print("\n" + "=" * 80)
        print("ТЕСТ: Отображение тела запроса и ответа")
        print("=" * 80)

        print("\n--- Тест 1: POST с телом запроса (show_request_body=True) ---")
        await test_post_with_body(client)

        print("\n--- Тест 2: POST с телом + заголовками (все опции) ---")
        await test_full_with_all(client)

        print("\n" + "=" * 80)
        print("ТЕСТЫ ЗАВЕРШЕНЫ")
        print("=" * 80)


if __name__ == "__main__":
    asyncio.run(main())

"""
Тесты для regex валидатора ResponseValidator.regex()
"""

import asyncio
import re
from typing import Optional
from curl_cffi.requests import AsyncSession

# Импорт из локальных модулей
from request_handlers import ResponseValidator


# ============================================================================
# MOCK RESPONSE для тестирования
# ============================================================================

class MockResponse:
    """Mock объект для имитации response"""

    def __init__(self, text: str, status_code: int = 200, headers: Optional[dict] = None, json_data: Optional[dict] = None):
        self.__dict__['_text'] = text
        self.__dict__['_json_data'] = json_data
        self.__dict__['status_code'] = status_code
        self.__dict__['headers'] = headers or {'Content-Type': 'text/html; charset=utf-8'}
        self.__dict__['url'] = 'https://test.example.com'
        self.__dict__['cookies'] = {}
        self.__dict__['elapsed'] = 0.1

    @property
    def text(self) -> str:
        return self._text

    @property
    def content(self) -> bytes:
        return self._text.encode('utf-8')

    def json(self, **kwargs):
        if self._json_data:
            return self._json_data
        import json
        return json.loads(self._text)

    def raise_for_status(self):
        """Mock method"""
        pass


# ============================================================================
# ТЕСТОВЫЕ ФУНКЦИИ
# ============================================================================

async def test_regex_extract_email():
    """Тест: извлечение email из HTML"""
    print("\n=== Test 1: Извлечение email из HTML ===")

    @ResponseValidator.regex(
        r'\b[\w.-]+@[\w.-]+\.\w+\b',
        target='text',
        save_to='email',
        error_key='EMAIL_NOT_FOUND'
    )
    async def fetch_page():
        html = """
        <html>
            <body>
                <p>Contact us: support@example.com</p>
            </body>
        </html>
        """
        return MockResponse(html)

    response = await fetch_page()

    print(f"Status: {response.status_code}")
    print(f"PARSED: {getattr(response, 'PARSED', {})}")

    if hasattr(response, 'PARSED') and 'email' in response.PARSED:
        print(f"✓ Email найден: {response.PARSED['email']}")
    else:
        print("✗ Email НЕ найден")

    if response.has_validation_errors():
        print(f"✗ Ошибки валидации: {response.get_validation_errors()}")
    else:
        print("✓ Ошибок валидации нет")


async def test_regex_multiple_matches():
    """Тест: извлечение нескольких совпадений"""
    print("\n=== Test 2: Извлечение нескольких email ===")

    @ResponseValidator.regex(
        r'\b[\w.-]+@[\w.-]+\.\w+\b',
        target='text',
        save_to='emails'
    )
    async def fetch_page():
        html = """
        <html>
            <body>
                <p>Contact: support@example.com</p>
                <p>Sales: sales@example.com</p>
                <p>Info: info@test.org</p>
            </body>
        </html>
        """
        return MockResponse(html)

    response = await fetch_page()

    if hasattr(response, 'PARSED') and 'emails' in response.PARSED:
        emails = response.PARSED['emails']
        print(f"✓ Найдено {len(emails)} email(s): {emails}")
    else:
        print("✗ Email НЕ найдены")


async def test_regex_expect_no_match():
    """Тест: проверка что паттерн НЕ найден"""
    print("\n=== Test 3: Проверка отсутствия слова 'error' ===")

    @ResponseValidator.regex(
        r'error|exception|fail',
        flags=re.IGNORECASE,
        expect_match=False,
        error_key='ERROR_IN_RESPONSE'
    )
    async def fetch_safe_data():
        return MockResponse('{"status": "success", "data": [1, 2, 3]}')

    response = await fetch_safe_data()

    if response.has_validation_errors():
        print(f"✗ Ошибки валидации: {response.get_validation_errors()}")
    else:
        print("✓ Ошибок валидации нет (слово 'error' не найдено)")


async def test_regex_expect_no_match_fail():
    """Тест: проверка что паттерн НЕ найден (негативный тест)"""
    print("\n=== Test 4: Проверка отсутствия слова 'error' (должно упасть) ===")

    @ResponseValidator.regex(
        r'error|exception',
        flags=re.IGNORECASE,
        expect_match=False,
        error_key='ERROR_IN_RESPONSE'
    )
    async def fetch_error_data():
        return MockResponse('{"status": "error", "message": "Something went wrong"}')

    response = await fetch_error_data()

    if response.has_validation_errors():
        print(f"✓ Ошибка валидации (как и ожидалось): {response.get_validation_errors()}")
    else:
        print("✗ Ошибок валидации нет (НЕправильно, должна быть ошибка!)")


async def test_regex_json_target():
    """Тест: извлечение данных из JSON"""
    print("\n=== Test 5: Извлечение токена из JSON ===")

    @ResponseValidator.regex(
        r'"access_token":\s*"([^"]+)"',
        target='json',
        save_to='access_token',
        error_key='TOKEN_NOT_FOUND'
    )
    async def login():
        json_data = {
            "status": "success",
            "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9",
            "user_id": 12345
        }
        return MockResponse('', json_data=json_data)

    response = await login()

    if hasattr(response, 'PARSED') and 'access_token' in response.PARSED:
        token = response.PARSED['access_token']
        print(f"✓ Токен извлечен: {token}")
    else:
        print("✗ Токен НЕ извлечен")

    if response.has_validation_errors():
        print(f"✗ Ошибки валидации: {response.get_validation_errors()}")


async def test_regex_capture_groups():
    """Тест: работа с группами захвата"""
    print("\n=== Test 6: Извлечение title из HTML с группой захвата ===")

    @ResponseValidator.regex(
        r'<title>([^<]+)</title>',
        target='text',
        save_to='title'
    )
    async def fetch_html():
        html = "<html><head><title>My Awesome Page</title></head></html>"
        return MockResponse(html)

    response = await fetch_html()

    if hasattr(response, 'PARSED') and 'title' in response.PARSED:
        title = response.PARSED['title']
        print(f"✓ Title извлечен: {title}")
    else:
        print("✗ Title НЕ извлечен")


async def test_regex_pattern_not_found():
    """Тест: паттерн не найден (должна быть ошибка)"""
    print("\n=== Test 7: Паттерн не найден (негативный тест) ===")

    @ResponseValidator.regex(
        r'<meta name="csrf-token" content="([^"]+)"',
        target='text',
        save_to='csrf_token',
        error_key='CSRF_TOKEN_NOT_FOUND'
    )
    async def fetch_html():
        html = "<html><head><title>Page without CSRF</title></head></html>"
        return MockResponse(html)

    response = await fetch_html()

    if response.has_validation_errors():
        errors = response.get_validation_errors()
        print(f"✓ Ожидаемая ошибка: {errors.get('CSRF_TOKEN_NOT_FOUND')}")
    else:
        print("✗ Ошибки валидации нет (НЕправильно!)")


async def test_regex_multiple_decorators():
    """Тест: несколько regex декораторов на одной функции"""
    print("\n=== Test 8: Несколько regex валидаторов ===")

    @ResponseValidator.status([200])
    @ResponseValidator.regex(r'<title>([^<]+)</title>', save_to='title')
    @ResponseValidator.regex(r'<meta name="description" content="([^"]+)"', save_to='description')
    @ResponseValidator.regex(r'<h1>([^<]+)</h1>', save_to='heading')
    async def fetch_html():
        html = """
        <html>
            <head>
                <title>Test Page</title>
                <meta name="description" content="This is a test page">
            </head>
            <body>
                <h1>Welcome</h1>
            </body>
        </html>
        """
        return MockResponse(html)

    response = await fetch_html()

    print(f"Status: {response.status_code}")

    if hasattr(response, 'PARSED'):
        print(f"✓ PARSED: {response.PARSED}")
        print(f"  - title: {response.PARSED.get('title')}")
        print(f"  - description: {response.PARSED.get('description')}")
        print(f"  - heading: {response.PARSED.get('heading')}")

    if response.has_validation_errors():
        print(f"Ошибки: {response.get_validation_errors()}")


async def test_regex_with_flags():
    """Тест: использование флагов regex (case-insensitive)"""
    print("\n=== Test 9: Regex с флагом IGNORECASE ===")

    @ResponseValidator.regex(
        r'error|warning',
        flags=re.IGNORECASE,
        expect_match=True,
        save_to='found_issues'
    )
    async def fetch_logs():
        logs = "INFO: Starting application\nWARNING: Low memory\nINFO: Done"
        return MockResponse(logs)

    response = await fetch_logs()

    if hasattr(response, 'PARSED') and 'found_issues' in response.PARSED:
        issues = response.PARSED['found_issues']
        print(f"✓ Найдены issues: {issues}")
    else:
        print("✗ Issues НЕ найдены")


# ============================================================================
# ЗАПУСК ВСЕХ ТЕСТОВ
# ============================================================================

async def run_all_tests():
    """Запустить все тесты"""
    print("=" * 80)
    print("REGEX VALIDATOR TESTS")
    print("=" * 80)

    await test_regex_extract_email()
    await test_regex_multiple_matches()
    await test_regex_expect_no_match()
    await test_regex_expect_no_match_fail()
    await test_regex_json_target()
    await test_regex_capture_groups()
    await test_regex_pattern_not_found()
    await test_regex_multiple_decorators()
    await test_regex_with_flags()

    print("\n" + "=" * 80)
    print("ВСЕ ТЕСТЫ ЗАВЕРШЕНЫ")
    print("=" * 80)


if __name__ == '__main__':
    asyncio.run(run_all_tests())

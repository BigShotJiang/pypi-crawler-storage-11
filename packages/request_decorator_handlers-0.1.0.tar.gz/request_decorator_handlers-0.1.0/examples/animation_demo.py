"""
Демонстрация анимаций для логов - спиннеры и индикаторы статуса
"""

import sys
import time
import threading
from itertools import cycle


class LogAnimator:
    """Класс для анимированных индикаторов в логах"""

    # Различные стили спиннеров
    SPINNERS = {
        "dots": ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"],
        "line": ["-", "\\", "|", "/"],
        "dots2": ["⣾", "⣽", "⣻", "⢿", "⡿", "⣟", "⣯", "⣷"],
        "dots3": ["⠁", "⠂", "⠄", "⡀", "⢀", "⠠", "⠐", "⠈"],
        "circle": ["◐", "◓", "◑", "◒"],
        "square": ["◰", "◳", "◲", "◱"],
        "arrow": ["←", "↖", "↑", "↗", "→", "↘", "↓", "↙"],
        "bounce": ["⠁", "⠂", "⠄", "⠂"],
        "pulse": ["●", "○", "●", "○"],
        "grow": ["▁", "▂", "▃", "▄", "▅", "▆", "▇", "█", "▇", "▆", "▅", "▄", "▃", "▂"],
    }

    # Цвета ANSI
    COLORS = {
        "reset": "\033[0m",
        "gray": "\033[90m",
        "red": "\033[91m",
        "green": "\033[92m",
        "yellow": "\033[93m",
        "blue": "\033[94m",
        "magenta": "\033[95m",
        "cyan": "\033[96m",
        "white": "\033[97m",
    }

    def __init__(self):
        self._stop = False
        self._thread = None

    @staticmethod
    def colorize(text: str, color: str) -> str:
        """Окрасить текст в указанный цвет"""
        return f"{LogAnimator.COLORS.get(color, '')}{text}{LogAnimator.COLORS['reset']}"

    def spin(self, message: str, spinner_type: str = "dots", color: str = "cyan", duration: float = 3.0):
        """
        Показать анимированный спиннер

        Args:
            message: Текст сообщения
            spinner_type: Тип спиннера из SPINNERS
            color: Цвет спиннера
            duration: Длительность в секундах (0 = бесконечно, остановить через stop())
        """
        frames = cycle(self.SPINNERS.get(spinner_type, self.SPINNERS["dots"]))
        self._stop = False
        start_time = time.time()

        try:
            while not self._stop:
                frame = next(frames)
                colored_frame = self.colorize(frame, color)
                # \r возвращает каретку в начало строки, перезаписываем
                sys.stdout.write(f"\r{colored_frame} {message}")
                sys.stdout.flush()
                time.sleep(0.1)

                if duration > 0 and (time.time() - start_time) >= duration:
                    break
        finally:
            # Очищаем строку
            sys.stdout.write("\r" + " " * (len(message) + 5) + "\r")
            sys.stdout.flush()

    def spin_async(self, message: str, spinner_type: str = "dots", color: str = "cyan"):
        """
        Запустить спиннер в отдельном потоке (асинхронно)

        Returns:
            self - для chain вызовов (animator.spin_async().stop())
        """
        self._stop = False
        self._thread = threading.Thread(
            target=self.spin,
            args=(message, spinner_type, color, 0),  # duration=0 для бесконечной анимации
            daemon=True
        )
        self._thread.start()
        return self

    def stop(self):
        """Остановить анимацию"""
        self._stop = True
        if self._thread:
            self._thread.join(timeout=0.5)

    @staticmethod
    def success(message: str, icon: str = "✓"):
        """Показать сообщение об успехе"""
        colored_icon = LogAnimator.colorize(icon, "green")
        print(f"{colored_icon} {message}")

    @staticmethod
    def error(message: str, icon: str = "✗"):
        """Показать сообщение об ошибке"""
        colored_icon = LogAnimator.colorize(icon, "red")
        print(f"{colored_icon} {message}")

    @staticmethod
    def warning(message: str, icon: str = "⚠"):
        """Показать предупреждение"""
        colored_icon = LogAnimator.colorize(icon, "yellow")
        print(f"{colored_icon} {message}")

    @staticmethod
    def info(message: str, icon: str = "ℹ"):
        """Показать информационное сообщение"""
        colored_icon = LogAnimator.colorize(icon, "blue")
        print(f"{colored_icon} {message}")

    @staticmethod
    def animate_success(message: str, duration: float = 0.5):
        """
        Анимированный переход к успеху - круг заполняется
        """
        frames = ["○", "◔", "◑", "◕", "●"]
        for i, frame in enumerate(frames):
            color = "green" if i == len(frames) - 1 else "yellow"
            colored_frame = LogAnimator.colorize(frame, color)
            sys.stdout.write(f"\r{colored_frame} {message}")
            sys.stdout.flush()
            time.sleep(duration / len(frames))

        # Финальный успех
        final_icon = LogAnimator.colorize("✓", "green")
        sys.stdout.write(f"\r{final_icon} {message}\n")
        sys.stdout.flush()

    @staticmethod
    def animate_error(message: str, duration: float = 0.5):
        """
        Анимированный переход к ошибке - круг заполняется красным
        """
        frames = ["○", "◔", "◑", "◕", "●"]
        for i, frame in enumerate(frames):
            color = "red" if i == len(frames) - 1 else "yellow"
            colored_frame = LogAnimator.colorize(frame, color)
            sys.stdout.write(f"\r{colored_frame} {message}")
            sys.stdout.flush()
            time.sleep(duration / len(frames))

        # Финальная ошибка
        final_icon = LogAnimator.colorize("✗", "red")
        sys.stdout.write(f"\r{final_icon} {message}\n")
        sys.stdout.flush()

    @staticmethod
    def progress_bar(current: int, total: int, message: str = "", width: int = 30):
        """
        Показать прогресс-бар

        Args:
            current: Текущее значение
            total: Максимальное значение
            message: Дополнительное сообщение
            width: Ширина бара
        """
        percent = current / total
        filled = int(width * percent)
        bar = "█" * filled + "░" * (width - filled)

        # Цвет в зависимости от процента
        if percent < 0.5:
            color = "red"
        elif percent < 0.8:
            color = "yellow"
        else:
            color = "green"

        colored_bar = LogAnimator.colorize(bar, color)
        percent_str = f"{percent * 100:5.1f}%"

        sys.stdout.write(f"\r{colored_bar} {percent_str} {message}")
        sys.stdout.flush()

        if current >= total:
            print()  # Новая строка в конце


# ========== ДЕМОНСТРАЦИЯ ==========

if __name__ == "__main__":
    animator = LogAnimator()

    print("=" * 80)
    print("ДЕМОНСТРАЦИЯ АНИМАЦИЙ ДЛЯ ЛОГОВ")
    print("=" * 80)

    # 1. Базовые статусы
    print("\n--- 1. Базовые индикаторы статуса ---\n")
    animator.success("Запрос успешно выполнен [200 OK]")
    animator.error("Ошибка валидации [STATUS_CODE] → [200] ≠ [404]")
    animator.warning("Медленный ответ: 15.3 секунд")
    animator.info("Отправка запроса на httpbin.org/post")

    # 2. Различные спиннеры
    print("\n--- 2. Различные типы спиннеров ---\n")

    spinner_demos = [
        ("dots", "cyan", "Загрузка с точками"),
        ("circle", "magenta", "Круговая анимация"),
        ("dots2", "blue", "Продвинутые точки"),
        ("arrow", "yellow", "Стрелки по кругу"),
        ("pulse", "green", "Пульсация"),
        ("grow", "cyan", "Растущий бар"),
    ]

    for spinner_type, color, description in spinner_demos:
        animator.spin(f"{description}...", spinner_type=spinner_type, color=color, duration=1.5)
        animator.success(f"{description} - завершено")

    # 3. Анимированные переходы
    print("\n--- 3. Анимированные результаты ---\n")

    animator.animate_success("Запрос выполнен успешно [200]", duration=0.8)
    time.sleep(0.3)
    animator.animate_error("Ошибка валидации [404]", duration=0.8)

    # 4. Асинхронный спиннер
    print("\n--- 4. Асинхронный спиннер (имитация запроса) ---\n")

    animator.spin_async("Отправка POST запроса...", spinner_type="dots", color="cyan")
    time.sleep(2.0)  # Имитация работы
    animator.stop()
    animator.success("POST запрос выполнен за 2.045с [200]")

    # 5. Прогресс-бар
    print("\n--- 5. Прогресс-бар ---\n")

    for i in range(101):
        animator.progress_bar(i, 100, f"Обработка запросов ({i}/100)")
        time.sleep(0.02)

    # 6. Имитация реального HTTP запроса
    print("\n--- 6. Имитация HTTP запроса с анимацией ---\n")

    print("23:45:12 | ", end="")
    animator.spin_async("SEND.FORM → httpbin.org/post", spinner_type="dots", color="cyan")
    time.sleep(2.5)  # Имитация запроса
    animator.stop()

    # Случайный успех или ошибка
    import random
    if random.choice([True, False]):
        animator.animate_success("SEND.FORM → httpbin.org/post [200]", duration=0.5)
    else:
        animator.animate_error("SEND.FORM → httpbin.org/post [404]", duration=0.5)

    # 7. Цветные круги для статусов
    print("\n--- 7. Цветные индикаторы статусов ---\n")

    statuses = [
        ("●", "green", "200 OK"),
        ("●", "yellow", "301 Redirect"),
        ("●", "red", "404 Not Found"),
        ("●", "red", "500 Server Error"),
        ("●", "blue", "202 Accepted"),
    ]

    for icon, color, status in statuses:
        colored_icon = animator.colorize(icon, color)
        print(f"{colored_icon} {status}")

    print("\n" + "=" * 80)
    print("ДЕМОНСТРАЦИЯ ЗАasdasdasdasdasdВЕРШЕНА")
    print("=")




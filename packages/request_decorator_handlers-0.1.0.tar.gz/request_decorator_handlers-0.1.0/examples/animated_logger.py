"""
RequestLogger с анимациями - тестовая интеграция
"""

import sys
import time
import threading
from functools import wraps
from typing import Callable, Literal, Any
from itertools import cycle

from loguru import logger
from bose_request import BossAsyncSessionCurlCffi

# Импортируем оригинальные компоненты
from action import LOG_ACTION
from request_handlers import Validator, ResponseValidator, as_validator


# ========== АНИМАЦИЯ ==========

class _Spinner:
    """Спиннер для анимации запросов"""

    FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self, message: str, color: str = "\033[96m"):
        self.message = message
        self.color = color
        self.reset = "\033[0m"
        self._stop = False
        self._thread = None

    def start(self):
        """Запустить спиннер в отдельном потоке"""
        self._stop = False
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()
        return self

    def _spin(self):
        """Внутренняя функция анимации"""
        frames = cycle(self.FRAMES)
        while not self._stop:
            frame = next(frames)
            sys.stdout.write(f"\r{self.color}{frame}{self.reset} {self.message}")
            sys.stdout.flush()
            time.sleep(0.1)

        # Очищаем строку
        sys.stdout.write("\r" + " " * (len(self.message) + 5) + "\r")
        sys.stdout.flush()

    def stop(self):
        """Остановить спиннер"""
        self._stop = True
        if self._thread:
            self._thread.join(timeout=0.5)


def _animate_result(success: bool, message: str, duration: float = 0.4):
    """
    Анимированный переход к результату

    Args:
        success: True для успеха, False для ошибки
        message: Сообщение лога
        duration: Длительность анимации
    """
    frames = ["○", "◔", "◑", "◕", "●"]

    # Цвета
    yellow = "\033[93m"
    green = "\033[92m"
    red = "\033[91m"
    reset = "\033[0m"

    for i, frame in enumerate(frames):
        if i == len(frames) - 1:
            # Последний кадр - финальный цвет
            color = green if success else red
        else:
            # Промежуточные кадры - желтый
            color = yellow

        sys.stdout.write(f"\r{color}{frame}{reset} {message}")
        sys.stdout.flush()
        time.sleep(duration / len(frames))

    # Финальный символ
    final_icon = f"{green}✓{reset}" if success else f"{red}✗{reset}"
    print(f"\r{final_icon} {message}")


# ========== ЛОГГЕР С АНИМАЦИЕЙ ==========

class AnimatedRequestLogger:
    """Декоратор для логирования HTTP запросов с анимациями"""

    @staticmethod
    def log(
        action: str,
        log_level: Literal["full", "success_error", "error_only"] = "full",
        show_body: bool = False,
        len_text: int = 150,
        show_response_headers: bool = False,
        show_request_headers: bool = False,
        animate: bool = True,  # Включить/выключить анимацию
        spinner_color: str = "\033[96m",  # Цвет спиннера (cyan по умолчанию)
        enabled: bool = True,
    ):
        """
        Декоратор с анимациями

        Args:
            action: Название действия (например, LOG_ACTION.SEND.FORM)
            log_level: Уровень логирования
            show_body: Показывать тело ответа
            len_text: Максимальная длина текста
            show_response_headers: Показывать заголовки ответа
            show_request_headers: Показывать заголовки запроса
            animate: Включить анимации (спиннер + анимированный результат)
            spinner_color: ANSI код цвета для спиннера
            enabled: Включить/выключить логирование
        """

        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs) -> Validator:
                if not enabled:
                    return await func(*args, **kwargs)

                # Извлекаем URL
                request_url = "N/A"
                for v in list(args) + list(kwargs.values()):
                    if isinstance(v, str) and ("http://" in v or "https://" in v):
                        request_url = v
                        break

                # Форматируем URL
                fmt_url = request_url.replace("https://", "").replace("http://", "")
                if len(fmt_url) > 30:
                    fmt_url = fmt_url[:27] + "..."

                # Извлекаем данные запроса
                req_headers = None
                if show_request_headers:
                    req_headers = kwargs.get('headers')

                # === АНИМАЦИЯ НАЧАЛА (только для full) ===
                spinner = None
                if log_level == "full" and animate:
                    # Запускаем спиннер
                    timestamp = time.strftime("%H:%M:%S")
                    spinner_msg = f"{timestamp} | {action:<20} | {fmt_url:<30}"
                    spinner = _Spinner(spinner_msg, color=spinner_color)
                    spinner.start()

                # Запускаем запрос
                start_ts = time.time()

                try:
                    result = await func(*args, **kwargs)
                    elapsed = time.time() - start_ts

                    validated = as_validator(result)
                    validated.valid.ACTION = action

                    # Обновляем URL если известен
                    if hasattr(validated, "url"):
                        request_url = str(validated.url) or request_url
                        fmt_url = request_url.replace("https://", "").replace("http://", "")
                        if len(fmt_url) > 30:
                            fmt_url = fmt_url[:27] + "..."

                    has_errors = validated.valid.has_errors()

                    # Останавливаем спиннер
                    if spinner:
                        spinner.stop()

                    # Извлекаем заголовки ответа
                    resp_headers = None
                    if show_response_headers:
                        try:
                            resp_headers = dict(validated.headers) if hasattr(validated, 'headers') else None
                        except Exception:
                            pass

                    # Обновить request_headers из response.request если не были
                    if show_request_headers and not req_headers:
                        if hasattr(validated, 'request') and hasattr(validated.request, 'headers'):
                            try:
                                req_headers = dict(validated.request.headers)
                            except Exception:
                                pass

                    # Извлекаем body
                    response_body_str = None
                    if show_body and not has_errors:
                        response_body_str = _extract_response_body(validated, len_text)

                    # Формируем сообщение
                    timestamp = time.strftime("%H:%M:%S")
                    status_code = validated.status_code

                    # Цвет статус кода
                    if 200 <= status_code < 300:
                        status_color = "\033[92m"  # green
                    elif 400 <= status_code < 600:
                        status_color = "\033[91m"  # red
                    else:
                        status_color = "\033[95m"  # magenta
                    reset = "\033[0m"

                    # Основная строка
                    main_msg = (
                        f"{timestamp} | "
                        f"{f'{elapsed:6.3f}с':<10} | "
                        f"{action:<20} | "
                        f"{fmt_url:<30} "
                        f"[{status_color}{status_code}{reset}]"
                    )

                    # === АНИМАЦИЯ РЕЗУЛЬТАТА ===
                    if animate:
                        _animate_result(not has_errors, main_msg, duration=0.4)
                    else:
                        # Без анимации - обычный вывод
                        icon = f"\033[92m✓{reset}" if not has_errors else f"\033[91m✗{reset}"
                        print(f"{icon} {main_msg}")

                    # Детали (request/response)
                    _print_details(
                        req_headers=req_headers,
                        resp_headers=resp_headers,
                        resp_body=response_body_str
                    )

                    return validated

                except Exception as exc:
                    elapsed = time.time() - start_ts

                    # Останавливаем спиннер
                    if spinner:
                        spinner.stop()

                    # Сообщение об ошибке
                    timestamp = time.strftime("%H:%M:%S")
                    exc_type = type(exc).__name__
                    exc_msg = str(exc)[:50]

                    error_msg = (
                        f"{timestamp} | "
                        f"{f'{elapsed:6.3f}с':<10} | "
                        f"{action:<20} | "
                        f"{fmt_url:<30} "
                        f"[\033[91m000\033[0m] | {exc_type}: {exc_msg}"
                    )

                    # Анимация ошибки
                    if animate:
                        _animate_result(False, error_msg, duration=0.4)
                    else:
                        print(f"\033[91m✗\033[0m {error_msg}")

                    raise

            return wrapper
        return decorator


def _extract_response_body(response_obj: Any, len_text: int) -> str | None:
    """Умное извлечение тела ответа"""
    import json

    try:
        json_data = response_obj.json()

        # Очищаем от headers и пустых полей
        cleaned_data = _clean_body_json(json_data)

        if cleaned_data:
            body_str = json.dumps(cleaned_data, ensure_ascii=False, indent=2)
            if len(body_str) > len_text:
                return body_str[:len_text] + "..."
            return body_str
    except Exception:
        pass

    try:
        text = response_obj.text
        if text:
            return text[:len_text] + ("..." if len(text) > len_text else "")
    except Exception:
        pass

    return None


def _clean_body_json(data: Any) -> Any:
    """Очистка JSON от headers и пустых полей"""
    if isinstance(data, dict):
        cleaned = {}
        for key, value in data.items():
            if key == "headers":
                continue

            cleaned_value = _clean_body_json(value)

            if cleaned_value in ({}, [], "", None):
                continue

            cleaned[key] = cleaned_value
        return cleaned

    elif isinstance(data, list):
        cleaned = [_clean_body_json(item) for item in data]
        return [item for item in cleaned if item not in ({}, [], "", None)]

    else:
        return data


def _print_details(req_headers=None, resp_headers=None, resp_body=None):
    """Печать деталей request/response"""

    # Цвета
    dim = "\033[2m"
    green = "\033[92m"
    gray = "\033[90m"
    reset = "\033[0m"

    has_request = req_headers is not None
    has_response = resp_headers is not None or resp_body is not None

    # === REQUEST BLOCK ===
    if has_request:
        request_symbol = "├─" if has_response else "└─"
        print(f"  {dim}{request_symbol} request:{reset}")

        if req_headers:
            prefix = "│" if has_response else " "
            headers_str = str(req_headers)
            print(f"  {dim}{prefix}  └─ headers:{reset} {green}{headers_str}{reset}")

    # === RESPONSE BLOCK ===
    if has_response:
        print(f"  {dim}└─ response:{reset}")

        response_items = []
        if resp_headers:
            response_items.append(("headers", resp_headers))
        if resp_body:
            response_items.append(("body", resp_body))

        for idx, (item_type, item_data) in enumerate(response_items):
            is_last = (idx == len(response_items) - 1)
            item_symbol = "└─" if is_last else "├─"

            if item_type == "headers":
                headers_str = str(item_data)
                print(f"  {dim}   {item_symbol} headers:{reset} {gray}{headers_str}{reset}")
            elif item_type == "body":
                print(f"  {dim}   {item_symbol} body:{reset} {gray}{item_data}{reset}")


# ========== ДЕМОНСТРАЦИЯ ==========

if __name__ == "__main__":
    import asyncio

    # Настройка loguru (для совместимости)
    logger.remove()
    logger.level("SUCCESS", icon="✓", color="<fg #98c379>")

    print("=" * 80)
    print("ДЕМОНСТРАЦИЯ АНИМИРОВАННОГО ЛОГГЕРА")
    print("=" * 80)

    # === Тест 1: Простой GET запрос с анимацией ===
    @AnimatedRequestLogger.log(
        LOG_ACTION.FETCH.PROFILE,
        log_level="full",
        show_body=True,
        len_text=200,
        animate=True
    )
    @ResponseValidator.status([200])
    async def test_simple_get(client):
        return await client.get('https://httpbin.org/get')

    # === Тест 2: POST с заголовками и анимацией ===
    @AnimatedRequestLogger.log(
        LOG_ACTION.SEND.FORM,
        log_level="full",
        show_body=True,
        show_response_headers=True,
        show_request_headers=True,
        len_text=300,
        animate=True,
        spinner_color="\033[95m"  # Magenta спиннер
    )
    @ResponseValidator.status([200])
    async def test_post_with_headers(client):
        return await client.post(
            'https://httpbin.org/post',
            json={"action": "test", "user_id": 12345},
            headers={"X-API-Key": "secret123", "User-Agent": "AnimatedBot/1.0"}
        )

    # === Тест 3: Запрос с ошибкой (404) ===
    @AnimatedRequestLogger.log(
        LOG_ACTION.FETCH.BALANCE,
        log_level="full",
        animate=True,
        spinner_color="\033[93m"  # Yellow спиннер
    )
    @ResponseValidator.status([200])  # Ожидаем 200, но получим 404
    async def test_error_404(client):
        return await client.get('https://httpbin.org/status/404')

    # === Тест 4: Медленный запрос (задержка) ===
    @AnimatedRequestLogger.log(
        LOG_ACTION.FETCH.COOKIES,
        log_level="full",
        show_body=True,
        animate=True
    )
    @ResponseValidator.status([200])
    async def test_slow_request(client):
        return await client.get('https://httpbin.org/delay/2')

    # === Тест 5: Несколько быстрых запросов подряд ===
    @AnimatedRequestLogger.log(
        LOG_ACTION.SEND.FORM,
        log_level="success_error",
        animate=True
    )
    @ResponseValidator.status([200])
    async def test_quick_request(client, n):
        return await client.get(f'https://httpbin.org/get?request={n}')

    # === Тест 6: Без анимации (для сравнения) ===
    @AnimatedRequestLogger.log(
        LOG_ACTION.FETCH.PROFILE,
        log_level="success_error",
        show_body=True,
        len_text=150,
        animate=False  # БЕЗ АНИМАЦИИ
    )
    @ResponseValidator.status([200])
    async def test_without_animation(client):
        return await client.get('https://httpbin.org/get')


    async def main():
        async with BossAsyncSessionCurlCffi() as client:

            print("\n" + "-" * 80)
            print("1. Простой GET запрос с анимацией")
            print("-" * 80)
            await test_simple_get(client)

            print("\n" + "-" * 80)
            print("2. POST с заголовками и анимацией (magenta спиннер)")
            print("-" * 80)
            await test_post_with_headers(client)

            print("\n" + "-" * 80)
            print("3. Запрос с ошибкой 404 (yellow спиннер)")
            print("-" * 80)
            try:
                await test_error_404(client)
            except Exception:
                pass  # Игнорируем ошибку валидации

            print("\n" + "-" * 80)
            print("4. Медленный запрос с задержкой 2 секунды")
            print("-" * 80)
            await test_slow_request(client)

            print("\n" + "-" * 80)
            print("5. Несколько быстрых запросов подряд")
            print("-" * 80)
            for i in range(3):
                await test_quick_request(client, i + 1)
                await asyncio.sleep(0.2)  # Небольшая пауза

            print("\n" + "-" * 80)
            print("6. Запрос БЕЗ анимации (для сравнения)")
            print("-" * 80)
            await test_without_animation(client)

            print("\n" + "=" * 80)
            print("ДЕМОНСТРАЦИЯ ЗАВЕРШЕНА")
            print("=" * 80)


    asyncio.run(main())

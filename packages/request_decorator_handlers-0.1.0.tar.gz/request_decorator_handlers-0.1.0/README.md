# request_decorator_handlers

Библиотека декораторов для асинхронных HTTP‑клиентов на базе `curl_cffi` и `boss-request`:

- 🎯 единая обёртка `Validator` со складом ошибок и распарсенных полей;
- 🧪 валидаторы ответов (`status`, `headers`, `cookies`, `content-type`, `regex`);
- 📦 парсеры (`JSONPath`, html‑селекторы);
- 🪵 продвинутый логгер запросов с цветными бейджами статуса и блоком `ERRORS`;
- 🧾 декоратор `RequestDebugger` для записи невалидных запросов и уникальных JSON структур.

## Установка

```bash
pip install request-decorator-handlers
```

## Быстрый пример

```python
from request_handlers import RequestLogger, ResponseValidator, LOG_ACTION
from request_handlers.decorators import RequestDebugger

@RequestDebugger.debug(save_errors=True)
@RequestLogger.log(LOG_ACTION.FETCH.PROFILE, log_level="success_error")
@ResponseValidator.status([200])
async def fetch_profile(client):
    return await client.get("https://httpbin.org/get")
```

## Что внутри

```
src/request_handlers/
  core/          # Validator, ValidationError, action константы
  logging/       # RequestLogger + RequestLogFormatter
  validation/    # ResponseValidator (status, headers, regex ...)
  parsing/       # JSONPathParser, HTMLParser
  decorators/    # RequestDebugger
examples/        # демо-скрипты
```

Подробности и расширенные примеры смотрите в `docs/index.md` и файлах каталога
`examples/`.

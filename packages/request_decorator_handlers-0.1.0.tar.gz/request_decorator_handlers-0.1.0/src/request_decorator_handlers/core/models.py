from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

from bose_request import CurlCffiBossResponse as ResponseT


@dataclass
class ValidationError:
    """Descriptor of a single validation failure."""

    key: str
    expected: Union[List, str, int, Any]
    actual: Union[List, str, int, Any]
    message: Optional[str] = None

    def __str__(self) -> str:
        return self.message or f"Expected {self.expected}, got {self.actual}"


@dataclass
class ValidationData:
    """Runtime validation state attached to a response."""

    ERRORS: List[ValidationError] = field(default_factory=list)
    EVENT: Optional[str] = None
    ACTION: Optional[str] = None
    PARSED: Dict[str, Any] = field(default_factory=dict)

    def add_error(
        self,
        *,
        key: str,
        expected: Any,
        actual: Any,
        message: Optional[str] = None,
    ) -> None:
        self.ERRORS.append(
            ValidationError(
                key=key,
                expected=expected,
                actual=actual,
                message=message,
            )
        )

    def has_errors(self) -> bool:
        return bool(self.ERRORS)

    def as_dict(self) -> Dict[str, str]:
        return {err.key: str(err) for err in self.ERRORS}


class Validator(ResponseT):
    """Envelope over the original response with validation data attached."""

    def __init__(self, response: ResponseT):
        for key, value in response.__dict__.items():
            setattr(self, key, value)
        self.valid = ValidationData()

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        extras: list[str] = [f"status={self.status_code}"]
        if self.valid.has_errors():
            extras.append(f"errors={list(self.valid.as_dict().keys())}")
        if self.valid.EVENT:
            extras.append(f"event={self.valid.EVENT}")
        if self.valid.ACTION:
            extras.append(f"action={self.valid.ACTION}")
        return f"Validator({' '.join(extras)})"


def as_validator(result: Any) -> Validator:
    """Cast arbitrary response to Validator, reusing existing wrapper when possible."""
    return result if isinstance(result, Validator) else Validator(result)


from __future__ import annotations

import time
from functools import wraps
from typing import Any, Callable, Literal

from loguru import logger

from ..core import Validator, as_validator
from .formatter import RequestLogFormatter


LogLevel = Literal["full", "success_error", "error_only"]


class RequestLogger:
    """Decorator that logs request/response lifecycle with validation support."""

    @staticmethod
    def log(
        action: str,
        log_level: LogLevel = "full",
        show_body: bool = False,
        len_text: int = 150,
        show_response_headers: bool = False,
        show_request_body: bool = False,
        show_request_headers: bool = False,
        enabled: bool = True,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            @wraps(func)
            async def wrapper(*args, **kwargs) -> Validator:
                if not enabled:
                    return await func(*args, **kwargs)

                request_url = RequestLogger._extract_url(args, kwargs)
                req_body = RequestLogger._extract_request_body(kwargs) if show_request_body else None
                req_headers = kwargs.get("headers") if show_request_headers else None

                if log_level == "full":
                    logger.opt(colors=True).debug(
                        RequestLogFormatter.build(
                            kind="start",
                            action=action,
                            url=request_url,
                            request_headers=req_headers,
                            request_body=req_body,
                            len_text=len_text,
                        )
                    )

                started_at = time.time()

                try:
                    result = await func(*args, **kwargs)
                    elapsed = time.time() - started_at

                    validated = as_validator(result)
                    validated.valid.ACTION = action
                    if hasattr(validated, "url"):
                        request_url = str(validated.url) or request_url

                    has_errors = validated.valid.has_errors()
                    resp_headers = (
                        RequestLogger._to_dict(getattr(validated, "headers", None))
                        if show_response_headers
                        else None
                    )

                    if show_request_headers and not req_headers:
                        req_headers = RequestLogger._extract_headers_from_response(validated)

                    message = RequestLogFormatter.build(
                        kind="error" if has_errors else "ok",
                        action=action,
                        elapsed=elapsed,
                        status_code=getattr(validated, "status_code", None),
                        url=request_url,
                        errors=validated.valid.ERRORS if has_errors else None,
                        response_obj=validated if show_body and not has_errors else None,
                        response_headers=resp_headers,
                        request_headers=req_headers,
                        request_body=req_body,
                        len_text=len_text,
                    )

                    if has_errors:
                        if log_level in {"full", "success_error", "error_only"}:
                            logger.opt(colors=True).error(message)
                    else:
                        if log_level in {"full", "success_error"}:
                            logger.opt(colors=True).success(message)

                    return validated

                except Exception as exc:  # pragma: no cover - pass-through
                    elapsed = time.time() - started_at
                    if log_level in {"full", "success_error", "error_only"}:
                        logger.opt(colors=True).error(
                            RequestLogFormatter.build(
                                kind="fail",
                                action=action,
                                elapsed=elapsed,
                                url=request_url,
                                exc_type=type(exc).__name__,
                                exc_msg=str(exc),
                                request_body=req_body,
                                request_headers=req_headers,
                                len_text=len_text,
                            )
                        )
                    raise

            return wrapper

        return decorator

    @staticmethod
    def _extract_url(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str:
        for value in list(args) + list(kwargs.values()):
            if isinstance(value, str) and value.startswith(("http://", "https://")):
                return value
        return "N/A"

    @staticmethod
    def _extract_request_body(kwargs: dict[str, Any]) -> Any:
        if "json" in kwargs:
            return kwargs["json"]
        if "data" in kwargs:
            return kwargs["data"]
        return None

    @staticmethod
    def _extract_headers_from_response(response: Any) -> dict | None:
        try:
            request = getattr(response, "request", None)
            headers = getattr(request, "headers", None)
            return dict(headers) if headers else None
        except Exception:  # pragma: no cover - optional path
            return None

    @staticmethod
    def _to_dict(headers: Any) -> dict | None:
        try:
            return dict(headers) if headers else None
        except Exception:  # pragma: no cover
            return None


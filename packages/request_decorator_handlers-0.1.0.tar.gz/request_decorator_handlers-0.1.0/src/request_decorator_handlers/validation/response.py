from __future__ import annotations

from functools import wraps
from typing import Any, Callable, Iterable, List, Literal

from ..core import Validator, as_validator


class ResponseValidator:
    """Collection of decorators for validating HTTP responses."""

    @staticmethod
    def status(allowed: Iterable[int], *, error_key: str = "STATUS_CODE") -> Callable:
        allowed_set = set(allowed)

        def decorator(func: Callable[..., Any]) -> Callable[..., Validator]:
            @wraps(func)
            async def wrapper(*args, **kwargs) -> Validator:
                validated = as_validator(await func(*args, **kwargs))
                if validated.status_code not in allowed_set:
                    validated.valid.add_error(
                        key=error_key,
                        expected=sorted(allowed_set),
                        actual=validated.status_code,
                    )
                return validated

            return wrapper

        return decorator

    @staticmethod
    def headers(required: Iterable[str], *, error_key: str = "HEADERS") -> Callable:
        required_list = list(required)

        def decorator(func: Callable[..., Any]) -> Callable[..., Validator]:
            @wraps(func)
            async def wrapper(*args, **kwargs) -> Validator:
                validated = as_validator(await func(*args, **kwargs))
                present = {key.lower(): value for key, value in validated.headers.items()}
                missing = [header for header in required_list if header.lower() not in present]
                if missing:
                    validated.valid.add_error(
                        key=error_key,
                        expected=required_list,
                        actual=[h for h in required_list if h.lower() in present],
                    )
                return validated

            return wrapper

        return decorator

    @staticmethod
    def cookies(
        domain: str,
        required: Iterable[str],
        *,
        error_key: str = "COOKIES",
    ) -> Callable:
        required_list = list(required)

        def decorator(func: Callable[..., Any]) -> Callable[..., Validator]:
            @wraps(func)
            async def wrapper(*args, **kwargs) -> Validator:
                session = next((arg for arg in args if hasattr(arg, "cookies")), None)
                validated = as_validator(await func(*args, **kwargs))

                if session:
                    cookies = ResponseValidator._collect_domain_cookies(session, domain)
                    present = [cookie for cookie in required_list if cookie in cookies]
                    missing = [cookie for cookie in required_list if cookie not in cookies]
                    if missing:
                        validated.valid.add_error(
                            key=error_key,
                            expected=required_list,
                            actual=present,
                        )
                return validated

            return wrapper

        return decorator

    @staticmethod
    def content_type(
        expected: Literal["json", "html", "image", "text", "bytes"],
        *,
        error_key: str = "CONTENT_TYPE",
    ) -> Callable:
        def decorator(func: Callable[..., Any]) -> Callable[..., Validator]:
            @wraps(func)
            async def wrapper(*args, **kwargs) -> Validator:
                validated = as_validator(await func(*args, **kwargs))
                content_type = (validated.headers.get("content-type", "") or "").lower()
                matches = {
                    "json": "application/json" in content_type,
                    "html": "text/html" in content_type,
                    "image": "image/" in content_type,
                    "text": "text/" in content_type,
                    "bytes": True,
                }[expected]

                if not matches:
                    actual = content_type.split(";")[0].strip() if content_type else "unknown"
                    validated.valid.add_error(
                        key=error_key,
                        expected=expected,
                        actual=actual,
                    )
                return validated

            return wrapper

        return decorator

    @staticmethod
    def regex(
        pattern: str,
        *,
        flags: int = 0,
        target: Literal["text", "json", "content"] = "text",
        save_to: str | None = None,
        expect_match: bool = True,
        group: int | None = None,
        error_key: str = "REGEX",
    ) -> Callable:
        import re

        compiled = re.compile(pattern, flags)

        def decorator(func: Callable[..., Any]) -> Callable[..., Validator]:
            @wraps(func)
            async def wrapper(*args, **kwargs) -> Validator:
                validated = as_validator(await func(*args, **kwargs))
                source = ResponseValidator._extract_target(validated, target)

                if source is None:
                    validated.valid.add_error(
                        key=error_key,
                        expected=target,
                        actual="unavailable",
                    )
                    return validated

                matches = list(compiled.finditer(source))

                if expect_match and not matches:
                    validated.valid.add_error(
                        key=error_key,
                        expected=pattern,
                        actual="not matched",
                    )
                elif not expect_match and matches:
                    validated.valid.add_error(
                        key=error_key,
                        expected="no matches",
                        actual=f"found {len(matches)}",
                    )

                if save_to and matches:
                    values = [ResponseValidator._extract_group(match, group) for match in matches]
                    validated.valid.PARSED[save_to] = values[0] if len(values) == 1 else values
                elif save_to and not matches:
                    validated.valid.PARSED[save_to] = None

                return validated

            return wrapper

        return decorator

    @staticmethod
    def _extract_target(response: Validator, target: str) -> str | None:
        if target == "text":
            return getattr(response, "text", None)
        if target == "content":
            content = getattr(response, "content", None)
            return content.decode("utf-8", errors="ignore") if content else None
        if target == "json":
            try:
                import json

                data = response.json()
                return json.dumps(data, ensure_ascii=False)
            except Exception:  # pragma: no cover - json decoding issues
                return None
        return None

    @staticmethod
    def _extract_group(match, group: int | None) -> str:
        try:
            if group is None:
                if match.groups():
                    return match.group(1)
                return match.group(0)
            return match.group(group)
        except IndexError:  # pragma: no cover - invalid group index
            return match.group(0)

    @staticmethod
    def _collect_domain_cookies(session: Any, domain: str) -> dict[str, str]:
        from urllib.parse import urlparse

        parsed = urlparse(domain)
        host = parsed.netloc or parsed.path or domain
        jar = getattr(session, "cookies", None)
        if not jar:
            return {}

        result: dict[str, str] = {}
        for cookie in jar.jar:
            if host.endswith(cookie.domain.lstrip(".")):
                result[cookie.name] = cookie.value
        return result

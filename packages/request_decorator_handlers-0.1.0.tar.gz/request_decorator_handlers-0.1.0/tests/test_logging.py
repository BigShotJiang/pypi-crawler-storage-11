import unittest

from src.request_decorator_handlers.logging import RequestLogFormatter


class RequestLogFormatterTests(unittest.TestCase):
    def test_formatter_success_message_contains_action_and_status(self):
        message = RequestLogFormatter.build(
            kind="ok",
            action="FETCH.DATA",
            elapsed=0.42,
            status_code=200,
            url="https://example.com/data",
            errors=None,
            response_obj=None,
            request_headers=None,
            response_headers=None,
            request_body=None,
        )

        self.assertIn("FETCH.DATA", message)
        self.assertIn("200", message)
        self.assertIn("example.com", message)

    def test_formatter_renders_errors_block(self):
        error = type("Err", (), {"key": "STATUS_CODE", "expected": 200, "actual": 500, "message": None})()

        message = RequestLogFormatter.build(
            kind="error",
            action="FETCH.DATA",
            elapsed=1.2,
            status_code=500,
            url="https://example.com/data",
            errors=[error],
            response_obj=None,
            request_headers=None,
            response_headers=None,
            request_body=None,
        )

        self.assertIn("ERRORS", message)
        self.assertIn("STATUS_CODE", message)


if __name__ == "__main__":
    unittest.main()

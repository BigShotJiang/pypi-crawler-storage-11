import unittest

from request_handlers import ResponseValidator


class DummyResponse:
    def __init__(self, *, status_code=200, headers=None, text="", json_data=None):
        default_headers = {"content-type": "application/json"}
        self.status_code = status_code
        self.headers = headers or default_headers
        self._text = text
        self._json_data = json_data
        self.url = "https://example.com/api"
        self.request = type("Req", (), {"method": "GET", "headers": {"X-Test": "1"}})()
        self.json = lambda **kwargs: self._json_data  # ensure copy into Validator

    @property
    def text(self):
        return self._text

    @property
    def content(self):
        return self._text.encode("utf-8")

    def json(self, **kwargs):
        if self._json_data is None:
            raise ValueError("no json body")
        return self._json_data


class ResponseValidatorTests(unittest.IsolatedAsyncioTestCase):
    async def test_status_validator_marks_error(self):
        @ResponseValidator.status([200])
        async def fetch():
            return DummyResponse(status_code=404, headers={"content-type": "text/html"})

        response = await fetch()
        self.assertTrue(response.valid.has_errors())
        self.assertEqual(response.valid.ERRORS[0].key, "STATUS_CODE")

    async def test_regex_parser_saves_capture(self):
        sample_json = {"token": "abc123", "user": {"email": "user@example.com"}}

        @ResponseValidator.regex(r'"token"\s*:\s*"([^\"]+)"', target="json", save_to="token")
        async def fetch():
            return DummyResponse(json_data=sample_json)

        response = await fetch()
        self.assertEqual(response.valid.PARSED["token"], "abc123")
        self.assertFalse(response.valid.has_errors())

    async def test_regex_expect_no_match_records_error(self):
        @ResponseValidator.regex(r"error", expect_match=False)
        async def fetch_ok():
            return DummyResponse(text="everything is ok")

        ok_response = await fetch_ok()
        self.assertFalse(ok_response.valid.has_errors())

        @ResponseValidator.regex(r"error", expect_match=False)
        async def fetch_error():
            return DummyResponse(text="error occurred")

        error_response = await fetch_error()
        self.assertTrue(error_response.valid.has_errors())
        self.assertEqual(error_response.valid.ERRORS[0].key, "REGEX")


if __name__ == "__main__":
    unittest.main()

from setuptools import setup
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="rodrigo0000-fastapi-core-auth",
    version="1.0.2",
    author="R Firm",
    author_email="rodrigo@rfirm.com",
    description="Authentication module for FastAPI with JWT, OAuth2, and user management",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/rfirm/fastapi-core-auth",
    packages=["fastapi_core_auth"],
    package_dir={"fastapi_core_auth": "."},
    package_data={"fastapi_core_auth": ["*.py"]},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: FastAPI",
    ],
    python_requires=">=3.8",
    install_requires=['fastapi>=0.104.0', 'sqlalchemy>=2.0.0', 'pydantic>=2.0.0', 'python-jose[cryptography]>=3.3.0', 'passlib[bcrypt]>=1.7.4', 'python-multipart>=0.0.6'],
)

"""Error classes for SecureAPI."""

"""Router module for SecureAPI."""

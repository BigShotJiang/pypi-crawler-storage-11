# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class HistoryDatabaseInstance:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'name': 'str',
        'total_tables': 'int',
        'databases': 'list[HistoryDatabaseInfo]'
    }

    attribute_map = {
        'id': 'id',
        'name': 'name',
        'total_tables': 'total_tables',
        'databases': 'databases'
    }

    def __init__(self, id=None, name=None, total_tables=None, databases=None):
        r"""HistoryDatabaseInstance

        The model defined in huaweicloud sdk

        :param id: 实例ID
        :type id: str
        :param name: 实例名称
        :type name: str
        :param total_tables: 表的个数
        :type total_tables: int
        :param databases: 数据库信息
        :type databases: list[:class:`huaweicloudsdkrds.v3.HistoryDatabaseInfo`]
        """
        
        

        self._id = None
        self._name = None
        self._total_tables = None
        self._databases = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if name is not None:
            self.name = name
        if total_tables is not None:
            self.total_tables = total_tables
        if databases is not None:
            self.databases = databases

    @property
    def id(self):
        r"""Gets the id of this HistoryDatabaseInstance.

        实例ID

        :return: The id of this HistoryDatabaseInstance.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this HistoryDatabaseInstance.

        实例ID

        :param id: The id of this HistoryDatabaseInstance.
        :type id: str
        """
        self._id = id

    @property
    def name(self):
        r"""Gets the name of this HistoryDatabaseInstance.

        实例名称

        :return: The name of this HistoryDatabaseInstance.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this HistoryDatabaseInstance.

        实例名称

        :param name: The name of this HistoryDatabaseInstance.
        :type name: str
        """
        self._name = name

    @property
    def total_tables(self):
        r"""Gets the total_tables of this HistoryDatabaseInstance.

        表的个数

        :return: The total_tables of this HistoryDatabaseInstance.
        :rtype: int
        """
        return self._total_tables

    @total_tables.setter
    def total_tables(self, total_tables):
        r"""Sets the total_tables of this HistoryDatabaseInstance.

        表的个数

        :param total_tables: The total_tables of this HistoryDatabaseInstance.
        :type total_tables: int
        """
        self._total_tables = total_tables

    @property
    def databases(self):
        r"""Gets the databases of this HistoryDatabaseInstance.

        数据库信息

        :return: The databases of this HistoryDatabaseInstance.
        :rtype: list[:class:`huaweicloudsdkrds.v3.HistoryDatabaseInfo`]
        """
        return self._databases

    @databases.setter
    def databases(self, databases):
        r"""Sets the databases of this HistoryDatabaseInstance.

        数据库信息

        :param databases: The databases of this HistoryDatabaseInstance.
        :type databases: list[:class:`huaweicloudsdkrds.v3.HistoryDatabaseInfo`]
        """
        self._databases = databases

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, HistoryDatabaseInstance):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

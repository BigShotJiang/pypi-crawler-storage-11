# -*- coding: utf-8 -*-
"""
NEXUS QUANTUM DEFENSE - 量子计算核心库 v1.5.0
"""

# 从 quantum_core 模块中导入所有公共 API
from .quantum_core import (
    # 核心数据结构
    QuantumState,
    QuantumCircuit,
    PauliString,
    Hamiltonian,
    TranspiledUnitary,

    # 噪声模型
    NoiseModel,
    PrebuiltNoiseModels,
    
    # 算法构建器
    AlgorithmBuilders,
    
    # 公共 API 函数
    create_quantum_state,
    run_circuit_on_state,
    get_effective_unitary,
    get_state_data,
    get_measurement_probabilities,
    get_marginal_probability,
    calculate_entanglement_entropy,
    get_bloch_vector,
    calculate_hamiltonian_expectation_value,
    build_trotter_step_circuit,
    apply_readout_noise,
    
    # 配置与并行化
    configure_quantum_core,
    enable_parallelism,
    disable_parallelism,
)

__version__ = "1.5.0"
__author__ = "跳舞的火公子"
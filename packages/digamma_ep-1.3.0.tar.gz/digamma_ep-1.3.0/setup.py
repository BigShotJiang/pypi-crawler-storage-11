from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="digamma_ep",
    version="1.3.0",
    author="Cesar (Epe Piancé Maria II)",
    description="Symbolic audit framework for divergence, drift, and compliance",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "scipy",
        "fastapi",
        "streamlit",
        "psycopg2-binary"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ],
    python_requires='>=3.8',
)

# Digamma Prime Framework

Symbolic audit framework for divergence, drift, and compliance — deployed under Piancé IV.

## 🔖 Badge Endpoint

```http
GET /badge/{table}
Result:
Returns a symbolic audit badge for any live PostgreSQL table, including:

Field count

Field types

Issuer: Epe Piancé Maria II

Frameworks: Digamma Prime, Variação Δ, Variação A

Launch with:
streamlit run dashboard.py

Installation
pip install digamma_ep

Symbolic Operators
ϝ(f, g): Structural divergence

δϝ(f, g): Rate divergence

ϝ*(f, g): Fusion metric

drift(f, g): Directional drift

curvature(f): Internal variation

Framework authored by Epe Piancé Maria II. For curriculum deployment, see epe_maria/__init__.py.


---

Once saved, rerun:

```powershell
python setup.py sdist bdist_wheel


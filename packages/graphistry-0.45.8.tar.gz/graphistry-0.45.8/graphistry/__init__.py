"""PyGraphistry: A visual graph analytics library for big graphs."""

from graphistry.pygraphistry import (  # noqa: E402, F401
    client_protocol_hostname,
    protocol,
    server,
    register,
    sso_get_token,
    privacy,
    login,
    refresh,
    api_token,
    verify_token,
    store_token_creds_in_memory,
    name,
    description,
    bind,
    client,
    set_client_for,
    style,
    addStyle,
    edges,
    nodes,
    graph,
    settings,
    encode_point_color,
    encode_point_size,
    encode_point_icon,
    encode_edge_color,
    encode_edge_icon,
    encode_point_badge,
    encode_edge_badge,
    hypergraph,
    bolt,
    cypher,
    tigergraph,
    configure_spanner,
    spanner_from_client,
    spanner_gql,
    spanner_gql_to_df,
    configure_kusto,
    kusto_from_client,
    kql,
    kusto_graph,
    gsql,
    gsql_endpoint,
    cosmos,
    neptune,
    gremlin,
    gremlin_client,
    drop_graph,
    layout_settings,
    org_name,
    scene_settings,
    nodexl,
    ArrowUploader,
    ArrowFileUploader,
    PyGraphistry,
    GraphistryClient,
    from_igraph,
    from_cugraph
)

from graphistry.compute import (
    n, e, e_forward, e_reverse, e_undirected,
    let, ref,
    Chain,
    call, CallMethodName,

    is_in, IsIn,

    duplicated, Duplicated,

    is_month_start, IsMonthStart,
    is_month_end, IsMonthEnd,
    is_quarter_start, IsQuarterStart,
    is_quarter_end, IsQuarterEnd,
    is_year_start, IsYearStart,
    is_year_end, IsYearEnd,
    is_leap_year, IsLeapYear,

    gt, GT,
    lt, LT,
    ge, GE,
    le, LE,
    eq, EQ,
    ne, NE,
    between, Between,
    isna, IsNA,
    notna, NotNA,

    contains, Contains,
    startswith, Startswith,
    endswith, Endswith,
    match, Match,
    fullmatch, Fullmatch,
    isnumeric, IsNumeric,
    isalpha, IsAlpha,
    isdigit, IsDigit,
    islower, IsLower,
    isupper, IsUpper,
    isspace, IsSpace,
    isalnum, IsAlnum,
    isdecimal, IsDecimal,
    istitle, IsTitle,
    isnull, IsNull,
    notnull, NotNull,
)

from graphistry.Engine import Engine

from graphistry.privacy import (
    Mode, Privacy
)

from ._version import get_versions

__version__ = get_versions()["version"]
del get_versions

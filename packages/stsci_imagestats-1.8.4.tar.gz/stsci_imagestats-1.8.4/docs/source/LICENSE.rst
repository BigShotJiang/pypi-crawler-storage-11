*******
LICENSE
*******

.. include:: ../../LICENSE.txt
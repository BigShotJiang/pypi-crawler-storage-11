import math
import numbers
import torch
from torch import nn
from torch.nn import functional as F

"""
Gaussian smoothing with Pytorch.
Source:
https://discuss.pytorch.org/t/is-there-anyway-to-do-gaussian-filtering-for-an-image-2d-3d-in-pytorch/12351/10
https://dsp.stackexchange.com/questions/78280/are-scipy-second-order-gaussian-derivatives-correct
https://github.com/ilyas-sid/SoftFrangiFilter2D
"""


class GaussianSmoothing(nn.Module):
    """
    Apply gaussian smoothing on a
    1d, 2d or 3d tensor. Filtering is performed seperately for each channel
    in the input using a depthwise convolution.
    Arguments:
        channels (int, sequence): Number of channels of the input tensors. Output will
            have this number of channels as well.
        kernel_size (int, sequence): Size of the gaussian kernel.
        sigma (float, sequence): Standard deviation of the gaussian kernel.
        dim (int, optional): The number of dimensions of the data.
            Default value is 2 (spatial).
    """

    def __init__(self, channels, kernel_size, sigma, dim=2, order=0, device=None):
        super(GaussianSmoothing, self).__init__()
        self.padd = kernel_size // 2
        self.dim = dim
        self.std = sigma
        if isinstance(kernel_size, numbers.Number):
            kernel_size = [kernel_size] * dim
        if isinstance(sigma, numbers.Number):
            sigma = [sigma] * dim

        # The gaussian kernel is the product of the
        # gaussian function of each dimension.
        kernel = 1
        meshgrids = torch.meshgrid(
            [
                torch.arange(-self.padd, self.padd+1, dtype=torch.float32)
                for size in kernel_size
            ],
            indexing = 'ij'
        )
        for size, std, mgrid in zip(kernel_size, sigma, meshgrids):
            mean = size // 2
            kernel *= 1 / (std * math.sqrt(2 * math.pi)) * \
                      torch.exp(-(mgrid / std) ** 2 / 2)
        
        # Make sure sum of values in gaussian kernel equals 1.
        kernel = kernel / torch.sum(kernel)

        # Reshape to depthwise convolutional weight
        kernel = kernel.view(1, 1, *kernel.size())

        # Derivatives
        if dim == 2:
            if order == 'x':
                kernel[0, 0] = - meshgrids[1] / self.std ** 2 * kernel[0, 0]
            elif order == 'y':
                kernel[0, 0] = - meshgrids[0] / self.std ** 2 * kernel[0, 0]
        else:
            if order == 'x':
                kernel[0, 0] = - meshgrids[2] / self.std ** 2 * kernel[0, 0]
            if order == 'y':
                kernel[0, 0] = - meshgrids[1] / self.std ** 2 * kernel[0, 0]
            if order == 'z':
                kernel[0, 0] = - meshgrids[0] / self.std ** 2 * kernel[0, 0]

        kernel = kernel.repeat(channels, *[1] * (kernel.dim() - 1))
        kernel.requires_grad = False
        if device is not None:
            kernel = kernel.to(device)
        self.register_buffer('weight', kernel)
        self.groups = channels

        if dim == 1:
            self.conv = F.conv1d
        elif dim == 2:
            self.conv = F.conv2d
        elif dim == 3:
            self.conv = F.conv3d
        else:
            raise RuntimeError(
                'Only 1, 2 and 3 dimensions are supported. Received {}.'.format(dim)
            )

    def forward(self, x):
        """
        Apply gaussian filter to input.
        Arguments:
            x (torch.Tensor): Input to apply gaussian filter on.
        Returns:
            filtered (torch.Tensor): Filtered output.
        """
        if self.dim == 2:
            x = F.pad(x, (self.padd, self.padd, self.padd, self.padd), mode='reflect')
        else:
            x = F.pad(x, (self.padd, self.padd, self.padd, self.padd, self.padd, self.padd), mode='reflect')
        return -self.conv(x, weight=self.weight, groups=self.groups)

"""Funcy Bear: A collection of functional programming utilities."""

from funcy_bear.ops.collections_ops.dict_stuffs import key_counts, merge as merge_dicts
from funcy_bear.ops.collections_ops.iter_stuffs import merge, merge_lists, merge_sets, merge_tuples, pairwise, window
from funcy_bear.ops.curried_ops import (
    abs,  # noqa: A004
    add,
    append,
    clamp,
    decrement,
    default,
    delete,
    div,
    extend,
    format,  # noqa: A004
    if_else,
    increment,
    lower,
    mod,
    multiply,
    pop,
    pow,  # noqa: A004
    prepend,
    push,
    replace,
    setter,
    subtract,
    toggle,
    upper,
)
from funcy_bear.ops.func_stuffs import if_in_list
from funcy_bear.type_stuffs.constants import LitFalse, LitTrue

__all__ = [
    "LitFalse",
    "LitTrue",
    "abs",
    "add",
    "append",
    "clamp",
    "decrement",
    "default",
    "delete",
    "div",
    "extend",
    "format",
    "if_else",
    "if_in_list",
    "increment",
    "key_counts",
    "lower",
    "merge",
    "merge_dicts",
    "merge_lists",
    "merge_sets",
    "merge_tuples",
    "mod",
    "multiply",
    "pairwise",
    "pop",
    "pow",
    "prepend",
    "push",
    "replace",
    "setter",
    "subtract",
    "toggle",
    "upper",
    "window",
]
